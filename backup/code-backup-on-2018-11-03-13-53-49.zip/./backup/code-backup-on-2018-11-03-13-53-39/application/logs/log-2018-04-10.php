<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-04-10 18:37:28 --> Config Class Initialized
INFO - 2018-04-10 18:37:28 --> Hooks Class Initialized
DEBUG - 2018-04-10 18:37:28 --> UTF-8 Support Enabled
INFO - 2018-04-10 18:37:28 --> Utf8 Class Initialized
INFO - 2018-04-10 18:37:28 --> URI Class Initialized
INFO - 2018-04-10 18:37:28 --> Router Class Initialized
INFO - 2018-04-10 18:37:28 --> Output Class Initialized
INFO - 2018-04-10 18:37:28 --> Security Class Initialized
DEBUG - 2018-04-10 18:37:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 18:37:28 --> CSRF cookie sent
INFO - 2018-04-10 18:37:28 --> Input Class Initialized
INFO - 2018-04-10 18:37:28 --> Language Class Initialized
INFO - 2018-04-10 18:37:29 --> Loader Class Initialized
INFO - 2018-04-10 18:37:29 --> Helper loaded: url_helper
INFO - 2018-04-10 18:37:29 --> Helper loaded: form_helper
DEBUG - 2018-04-10 18:37:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 18:37:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 18:37:29 --> User Agent Class Initialized
INFO - 2018-04-10 18:37:29 --> Controller Class Initialized
INFO - 2018-04-10 18:38:13 --> Config Class Initialized
INFO - 2018-04-10 18:38:13 --> Hooks Class Initialized
DEBUG - 2018-04-10 18:38:13 --> UTF-8 Support Enabled
INFO - 2018-04-10 18:38:13 --> Utf8 Class Initialized
INFO - 2018-04-10 18:38:14 --> URI Class Initialized
INFO - 2018-04-10 18:38:14 --> Router Class Initialized
INFO - 2018-04-10 18:38:14 --> Output Class Initialized
INFO - 2018-04-10 18:38:14 --> Security Class Initialized
DEBUG - 2018-04-10 18:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 18:38:14 --> CSRF cookie sent
INFO - 2018-04-10 18:38:14 --> Input Class Initialized
INFO - 2018-04-10 18:38:14 --> Language Class Initialized
INFO - 2018-04-10 18:38:14 --> Loader Class Initialized
INFO - 2018-04-10 18:38:14 --> Helper loaded: url_helper
INFO - 2018-04-10 18:38:14 --> Helper loaded: form_helper
DEBUG - 2018-04-10 18:38:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 18:38:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 18:38:14 --> User Agent Class Initialized
INFO - 2018-04-10 18:38:14 --> Controller Class Initialized
ERROR - 2018-04-10 18:38:14 --> Language file contains no data: language/en/common_lang.php
INFO - 2018-04-10 18:38:25 --> Config Class Initialized
INFO - 2018-04-10 18:38:25 --> Hooks Class Initialized
DEBUG - 2018-04-10 18:38:25 --> UTF-8 Support Enabled
INFO - 2018-04-10 18:38:25 --> Utf8 Class Initialized
INFO - 2018-04-10 18:38:25 --> URI Class Initialized
INFO - 2018-04-10 18:38:25 --> Router Class Initialized
INFO - 2018-04-10 18:38:25 --> Output Class Initialized
INFO - 2018-04-10 18:38:25 --> Security Class Initialized
DEBUG - 2018-04-10 18:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 18:38:25 --> CSRF cookie sent
INFO - 2018-04-10 18:38:25 --> Input Class Initialized
INFO - 2018-04-10 18:38:25 --> Language Class Initialized
INFO - 2018-04-10 18:38:25 --> Loader Class Initialized
INFO - 2018-04-10 18:38:25 --> Helper loaded: url_helper
INFO - 2018-04-10 18:38:25 --> Helper loaded: form_helper
DEBUG - 2018-04-10 18:38:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 18:38:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 18:38:26 --> User Agent Class Initialized
INFO - 2018-04-10 18:38:26 --> Controller Class Initialized
ERROR - 2018-04-10 18:38:26 --> Language file contains no data: language/en/common_lang.php
ERROR - 2018-04-10 18:38:26 --> Language file contains no data: language/en/form_validation_lang.php
INFO - 2018-04-10 18:38:26 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 18:38:26 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 18:38:26 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-10 18:38:26 --> File loaded: E:\www\yacopoo\application\views\01_register.php
INFO - 2018-04-10 18:38:26 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 18:38:26 --> Final output sent to browser
DEBUG - 2018-04-10 18:38:26 --> Total execution time: 0.6207
INFO - 2018-04-10 19:02:01 --> Config Class Initialized
INFO - 2018-04-10 19:02:01 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:02:01 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:02:01 --> Utf8 Class Initialized
INFO - 2018-04-10 19:02:01 --> URI Class Initialized
INFO - 2018-04-10 19:02:01 --> Router Class Initialized
INFO - 2018-04-10 19:02:01 --> Output Class Initialized
INFO - 2018-04-10 19:02:01 --> Security Class Initialized
DEBUG - 2018-04-10 19:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:02:01 --> CSRF cookie sent
INFO - 2018-04-10 19:02:01 --> Input Class Initialized
INFO - 2018-04-10 19:02:01 --> Language Class Initialized
INFO - 2018-04-10 19:02:01 --> Loader Class Initialized
INFO - 2018-04-10 19:02:02 --> Helper loaded: url_helper
INFO - 2018-04-10 19:02:02 --> Helper loaded: form_helper
DEBUG - 2018-04-10 19:02:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 19:02:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 19:02:02 --> User Agent Class Initialized
INFO - 2018-04-10 19:02:02 --> Controller Class Initialized
INFO - 2018-04-10 19:02:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 19:02:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-10 19:02:02 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 19:02:02 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 19:02:02 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-10 19:02:02 --> Severity: Error --> Call to undefined function lang() E:\www\yacopoo\application\views\register\signup.php 15
INFO - 2018-04-10 19:02:47 --> Config Class Initialized
INFO - 2018-04-10 19:02:47 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:02:47 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:02:47 --> Utf8 Class Initialized
INFO - 2018-04-10 19:02:47 --> URI Class Initialized
INFO - 2018-04-10 19:02:47 --> Router Class Initialized
INFO - 2018-04-10 19:02:47 --> Output Class Initialized
INFO - 2018-04-10 19:02:47 --> Security Class Initialized
DEBUG - 2018-04-10 19:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:02:47 --> CSRF cookie sent
INFO - 2018-04-10 19:02:47 --> Input Class Initialized
INFO - 2018-04-10 19:02:47 --> Language Class Initialized
INFO - 2018-04-10 19:02:47 --> Loader Class Initialized
INFO - 2018-04-10 19:02:47 --> Helper loaded: url_helper
INFO - 2018-04-10 19:02:47 --> Helper loaded: form_helper
INFO - 2018-04-10 19:02:47 --> Helper loaded: language_helper
DEBUG - 2018-04-10 19:02:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 19:02:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 19:02:48 --> User Agent Class Initialized
INFO - 2018-04-10 19:02:48 --> Controller Class Initialized
INFO - 2018-04-10 19:02:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 19:02:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-10 19:02:48 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 19:02:48 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 19:02:48 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-10 19:02:48 --> Severity: Error --> Class 'Constants' not found E:\www\yacopoo\application\views\register\signup.php 17
INFO - 2018-04-10 19:03:09 --> Config Class Initialized
INFO - 2018-04-10 19:03:09 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:03:09 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:03:09 --> Utf8 Class Initialized
INFO - 2018-04-10 19:03:09 --> URI Class Initialized
INFO - 2018-04-10 19:03:09 --> Router Class Initialized
INFO - 2018-04-10 19:03:09 --> Output Class Initialized
INFO - 2018-04-10 19:03:09 --> Security Class Initialized
DEBUG - 2018-04-10 19:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:03:09 --> CSRF cookie sent
INFO - 2018-04-10 19:03:09 --> Input Class Initialized
INFO - 2018-04-10 19:03:09 --> Language Class Initialized
INFO - 2018-04-10 19:03:09 --> Loader Class Initialized
INFO - 2018-04-10 19:03:09 --> Helper loaded: url_helper
INFO - 2018-04-10 19:03:09 --> Helper loaded: form_helper
INFO - 2018-04-10 19:03:09 --> Helper loaded: language_helper
DEBUG - 2018-04-10 19:03:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 19:03:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 19:03:09 --> User Agent Class Initialized
INFO - 2018-04-10 19:03:09 --> Controller Class Initialized
INFO - 2018-04-10 19:03:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 19:03:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-10 19:03:09 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 19:03:09 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 19:03:09 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-10 19:03:09 --> Severity: Error --> Access to undeclared static property: Smart::$REGEX_SAFE_NO_TAG E:\www\yacopoo\application\libraries\Smart.php 116
INFO - 2018-04-10 19:04:21 --> Config Class Initialized
INFO - 2018-04-10 19:04:21 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:04:21 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:04:21 --> Utf8 Class Initialized
INFO - 2018-04-10 19:04:21 --> URI Class Initialized
INFO - 2018-04-10 19:04:21 --> Router Class Initialized
INFO - 2018-04-10 19:04:21 --> Output Class Initialized
INFO - 2018-04-10 19:04:21 --> Security Class Initialized
DEBUG - 2018-04-10 19:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:04:21 --> CSRF cookie sent
INFO - 2018-04-10 19:04:21 --> Input Class Initialized
INFO - 2018-04-10 19:04:21 --> Language Class Initialized
INFO - 2018-04-10 19:04:21 --> Loader Class Initialized
INFO - 2018-04-10 19:04:21 --> Helper loaded: url_helper
INFO - 2018-04-10 19:04:21 --> Helper loaded: form_helper
INFO - 2018-04-10 19:04:21 --> Helper loaded: language_helper
DEBUG - 2018-04-10 19:04:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 19:04:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 19:04:21 --> User Agent Class Initialized
INFO - 2018-04-10 19:04:21 --> Controller Class Initialized
INFO - 2018-04-10 19:04:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 19:04:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-10 19:04:21 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 19:04:21 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 19:04:21 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-10 19:04:21 --> Could not find the language line "req_email"
INFO - 2018-04-10 19:04:21 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-04-10 19:04:21 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 19:04:21 --> Final output sent to browser
DEBUG - 2018-04-10 19:04:21 --> Total execution time: 0.2936
INFO - 2018-04-10 19:06:57 --> Config Class Initialized
INFO - 2018-04-10 19:06:57 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:06:57 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:06:57 --> Utf8 Class Initialized
INFO - 2018-04-10 19:06:57 --> URI Class Initialized
INFO - 2018-04-10 19:06:57 --> Router Class Initialized
INFO - 2018-04-10 19:06:57 --> Output Class Initialized
INFO - 2018-04-10 19:06:58 --> Security Class Initialized
DEBUG - 2018-04-10 19:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:06:58 --> CSRF cookie sent
INFO - 2018-04-10 19:06:58 --> Input Class Initialized
INFO - 2018-04-10 19:06:58 --> Language Class Initialized
INFO - 2018-04-10 19:06:58 --> Loader Class Initialized
INFO - 2018-04-10 19:06:58 --> Helper loaded: url_helper
INFO - 2018-04-10 19:06:58 --> Helper loaded: form_helper
INFO - 2018-04-10 19:06:58 --> Helper loaded: language_helper
DEBUG - 2018-04-10 19:06:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 19:06:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 19:06:58 --> User Agent Class Initialized
INFO - 2018-04-10 19:06:58 --> Controller Class Initialized
INFO - 2018-04-10 19:06:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 19:06:58 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 19:06:58 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 19:06:58 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 19:06:58 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 19:06:58 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-10 19:06:58 --> Could not find the language line "req_email"
INFO - 2018-04-10 19:06:58 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-04-10 19:06:58 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 19:06:58 --> Final output sent to browser
DEBUG - 2018-04-10 19:06:58 --> Total execution time: 0.2901
INFO - 2018-04-10 19:07:23 --> Config Class Initialized
INFO - 2018-04-10 19:07:23 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:07:23 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:07:23 --> Utf8 Class Initialized
INFO - 2018-04-10 19:07:23 --> URI Class Initialized
INFO - 2018-04-10 19:07:23 --> Router Class Initialized
INFO - 2018-04-10 19:07:23 --> Output Class Initialized
INFO - 2018-04-10 19:07:23 --> Security Class Initialized
DEBUG - 2018-04-10 19:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:07:23 --> CSRF cookie sent
INFO - 2018-04-10 19:07:23 --> Input Class Initialized
INFO - 2018-04-10 19:07:23 --> Language Class Initialized
INFO - 2018-04-10 19:07:23 --> Loader Class Initialized
INFO - 2018-04-10 19:07:23 --> Helper loaded: url_helper
INFO - 2018-04-10 19:07:23 --> Helper loaded: form_helper
INFO - 2018-04-10 19:07:23 --> Helper loaded: language_helper
DEBUG - 2018-04-10 19:07:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 19:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 19:07:23 --> User Agent Class Initialized
INFO - 2018-04-10 19:07:23 --> Controller Class Initialized
INFO - 2018-04-10 19:07:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 19:07:23 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 19:07:23 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 19:07:23 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 19:07:23 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 19:07:23 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-10 19:07:23 --> Could not find the language line "req_email"
INFO - 2018-04-10 19:07:23 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-04-10 19:07:23 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 19:07:23 --> Final output sent to browser
DEBUG - 2018-04-10 19:07:23 --> Total execution time: 0.3556
INFO - 2018-04-10 19:09:42 --> Config Class Initialized
INFO - 2018-04-10 19:09:42 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:09:42 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:09:42 --> Utf8 Class Initialized
INFO - 2018-04-10 19:09:42 --> URI Class Initialized
INFO - 2018-04-10 19:09:42 --> Router Class Initialized
INFO - 2018-04-10 19:09:42 --> Output Class Initialized
INFO - 2018-04-10 19:09:42 --> Security Class Initialized
DEBUG - 2018-04-10 19:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:09:42 --> CSRF cookie sent
INFO - 2018-04-10 19:09:42 --> Input Class Initialized
INFO - 2018-04-10 19:09:42 --> Language Class Initialized
INFO - 2018-04-10 19:09:42 --> Loader Class Initialized
INFO - 2018-04-10 19:09:42 --> Helper loaded: url_helper
INFO - 2018-04-10 19:09:42 --> Helper loaded: form_helper
INFO - 2018-04-10 19:09:42 --> Helper loaded: language_helper
DEBUG - 2018-04-10 19:09:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 19:09:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 19:09:42 --> User Agent Class Initialized
INFO - 2018-04-10 19:09:42 --> Controller Class Initialized
INFO - 2018-04-10 19:09:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 19:09:42 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 19:09:42 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 19:09:42 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 19:09:42 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 19:09:42 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-10 19:09:42 --> Could not find the language line "req_email"
INFO - 2018-04-10 19:09:42 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-04-10 19:09:42 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 19:09:42 --> Final output sent to browser
DEBUG - 2018-04-10 19:09:42 --> Total execution time: 0.2912
INFO - 2018-04-10 19:09:58 --> Config Class Initialized
INFO - 2018-04-10 19:09:58 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:09:58 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:09:59 --> Utf8 Class Initialized
INFO - 2018-04-10 19:09:59 --> URI Class Initialized
INFO - 2018-04-10 19:09:59 --> Router Class Initialized
INFO - 2018-04-10 19:09:59 --> Output Class Initialized
INFO - 2018-04-10 19:09:59 --> Security Class Initialized
DEBUG - 2018-04-10 19:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:09:59 --> CSRF cookie sent
INFO - 2018-04-10 19:09:59 --> Input Class Initialized
INFO - 2018-04-10 19:09:59 --> Language Class Initialized
ERROR - 2018-04-10 19:09:59 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 19:10:18 --> Config Class Initialized
INFO - 2018-04-10 19:10:18 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:10:18 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:10:18 --> Utf8 Class Initialized
INFO - 2018-04-10 19:10:18 --> URI Class Initialized
INFO - 2018-04-10 19:10:18 --> Router Class Initialized
INFO - 2018-04-10 19:10:18 --> Output Class Initialized
INFO - 2018-04-10 19:10:18 --> Security Class Initialized
DEBUG - 2018-04-10 19:10:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:10:18 --> CSRF cookie sent
INFO - 2018-04-10 19:10:18 --> Input Class Initialized
INFO - 2018-04-10 19:10:18 --> Language Class Initialized
INFO - 2018-04-10 19:10:18 --> Loader Class Initialized
INFO - 2018-04-10 19:10:18 --> Helper loaded: url_helper
INFO - 2018-04-10 19:10:18 --> Helper loaded: form_helper
INFO - 2018-04-10 19:10:18 --> Helper loaded: language_helper
DEBUG - 2018-04-10 19:10:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 19:10:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 19:10:18 --> User Agent Class Initialized
INFO - 2018-04-10 19:10:18 --> Controller Class Initialized
INFO - 2018-04-10 19:10:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 19:10:18 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 19:10:18 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 19:10:18 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 19:10:18 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 19:10:18 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-10 19:10:18 --> Could not find the language line "req_email"
INFO - 2018-04-10 19:10:18 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-04-10 19:10:18 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 19:10:18 --> Final output sent to browser
DEBUG - 2018-04-10 19:10:18 --> Total execution time: 0.3357
INFO - 2018-04-10 19:10:19 --> Config Class Initialized
INFO - 2018-04-10 19:10:19 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:10:19 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:10:19 --> Utf8 Class Initialized
INFO - 2018-04-10 19:10:19 --> URI Class Initialized
INFO - 2018-04-10 19:10:19 --> Router Class Initialized
INFO - 2018-04-10 19:10:19 --> Output Class Initialized
INFO - 2018-04-10 19:10:19 --> Security Class Initialized
DEBUG - 2018-04-10 19:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:10:19 --> CSRF cookie sent
INFO - 2018-04-10 19:10:19 --> Input Class Initialized
INFO - 2018-04-10 19:10:19 --> Language Class Initialized
ERROR - 2018-04-10 19:10:19 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 19:13:26 --> Config Class Initialized
INFO - 2018-04-10 19:13:26 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:13:26 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:13:26 --> Utf8 Class Initialized
INFO - 2018-04-10 19:13:26 --> URI Class Initialized
INFO - 2018-04-10 19:13:26 --> Router Class Initialized
INFO - 2018-04-10 19:13:26 --> Output Class Initialized
INFO - 2018-04-10 19:13:27 --> Security Class Initialized
DEBUG - 2018-04-10 19:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:13:27 --> CSRF cookie sent
INFO - 2018-04-10 19:13:27 --> Input Class Initialized
INFO - 2018-04-10 19:13:27 --> Language Class Initialized
INFO - 2018-04-10 19:13:27 --> Loader Class Initialized
INFO - 2018-04-10 19:13:27 --> Helper loaded: url_helper
INFO - 2018-04-10 19:13:27 --> Helper loaded: form_helper
INFO - 2018-04-10 19:13:27 --> Helper loaded: language_helper
DEBUG - 2018-04-10 19:13:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 19:13:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 19:13:27 --> User Agent Class Initialized
INFO - 2018-04-10 19:13:27 --> Controller Class Initialized
INFO - 2018-04-10 19:13:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 19:13:27 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 19:13:27 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 19:13:27 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 19:13:27 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 19:13:27 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-10 19:13:27 --> Could not find the language line "req_email"
INFO - 2018-04-10 19:13:27 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-04-10 19:13:27 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 19:13:27 --> Final output sent to browser
DEBUG - 2018-04-10 19:13:27 --> Total execution time: 0.3009
INFO - 2018-04-10 19:13:27 --> Config Class Initialized
INFO - 2018-04-10 19:13:27 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:13:27 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:13:27 --> Utf8 Class Initialized
INFO - 2018-04-10 19:13:27 --> URI Class Initialized
INFO - 2018-04-10 19:13:27 --> Router Class Initialized
INFO - 2018-04-10 19:13:27 --> Output Class Initialized
INFO - 2018-04-10 19:13:27 --> Security Class Initialized
DEBUG - 2018-04-10 19:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:13:27 --> CSRF cookie sent
INFO - 2018-04-10 19:13:27 --> Input Class Initialized
INFO - 2018-04-10 19:13:27 --> Language Class Initialized
ERROR - 2018-04-10 19:13:27 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 19:13:48 --> Config Class Initialized
INFO - 2018-04-10 19:13:48 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:13:48 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:13:48 --> Utf8 Class Initialized
INFO - 2018-04-10 19:13:48 --> URI Class Initialized
INFO - 2018-04-10 19:13:48 --> Router Class Initialized
INFO - 2018-04-10 19:13:48 --> Output Class Initialized
INFO - 2018-04-10 19:13:48 --> Security Class Initialized
DEBUG - 2018-04-10 19:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:13:48 --> CSRF cookie sent
INFO - 2018-04-10 19:13:48 --> Input Class Initialized
INFO - 2018-04-10 19:13:48 --> Language Class Initialized
ERROR - 2018-04-10 19:13:48 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 19:13:50 --> Config Class Initialized
INFO - 2018-04-10 19:13:50 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:13:50 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:13:50 --> Utf8 Class Initialized
INFO - 2018-04-10 19:13:50 --> URI Class Initialized
INFO - 2018-04-10 19:13:50 --> Router Class Initialized
INFO - 2018-04-10 19:13:50 --> Output Class Initialized
INFO - 2018-04-10 19:13:51 --> Security Class Initialized
DEBUG - 2018-04-10 19:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:13:51 --> CSRF cookie sent
INFO - 2018-04-10 19:13:51 --> Input Class Initialized
INFO - 2018-04-10 19:13:51 --> Language Class Initialized
INFO - 2018-04-10 19:13:51 --> Loader Class Initialized
INFO - 2018-04-10 19:13:51 --> Helper loaded: url_helper
INFO - 2018-04-10 19:13:51 --> Helper loaded: form_helper
INFO - 2018-04-10 19:13:51 --> Helper loaded: language_helper
DEBUG - 2018-04-10 19:13:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 19:13:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 19:13:51 --> User Agent Class Initialized
INFO - 2018-04-10 19:13:51 --> Controller Class Initialized
INFO - 2018-04-10 19:13:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 19:13:51 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 19:13:51 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 19:13:51 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 19:13:51 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 19:13:51 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-10 19:13:51 --> Could not find the language line "req_email"
INFO - 2018-04-10 19:13:51 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-04-10 19:13:51 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 19:13:51 --> Final output sent to browser
DEBUG - 2018-04-10 19:13:51 --> Total execution time: 0.3471
INFO - 2018-04-10 19:13:51 --> Config Class Initialized
INFO - 2018-04-10 19:13:51 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:13:51 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:13:51 --> Utf8 Class Initialized
INFO - 2018-04-10 19:13:51 --> URI Class Initialized
INFO - 2018-04-10 19:13:51 --> Router Class Initialized
INFO - 2018-04-10 19:13:51 --> Output Class Initialized
INFO - 2018-04-10 19:13:51 --> Security Class Initialized
DEBUG - 2018-04-10 19:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:13:51 --> CSRF cookie sent
INFO - 2018-04-10 19:13:51 --> Input Class Initialized
INFO - 2018-04-10 19:13:51 --> Language Class Initialized
ERROR - 2018-04-10 19:13:51 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 19:14:16 --> Config Class Initialized
INFO - 2018-04-10 19:14:16 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:14:16 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:14:16 --> Utf8 Class Initialized
INFO - 2018-04-10 19:14:16 --> URI Class Initialized
INFO - 2018-04-10 19:14:16 --> Router Class Initialized
INFO - 2018-04-10 19:14:16 --> Output Class Initialized
INFO - 2018-04-10 19:14:16 --> Security Class Initialized
DEBUG - 2018-04-10 19:14:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:14:16 --> CSRF cookie sent
INFO - 2018-04-10 19:14:16 --> Input Class Initialized
INFO - 2018-04-10 19:14:16 --> Language Class Initialized
INFO - 2018-04-10 19:14:16 --> Loader Class Initialized
INFO - 2018-04-10 19:14:16 --> Helper loaded: url_helper
INFO - 2018-04-10 19:14:16 --> Helper loaded: form_helper
INFO - 2018-04-10 19:14:16 --> Helper loaded: language_helper
DEBUG - 2018-04-10 19:14:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 19:14:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 19:14:16 --> User Agent Class Initialized
INFO - 2018-04-10 19:14:16 --> Controller Class Initialized
INFO - 2018-04-10 19:14:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 19:14:16 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 19:14:16 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 19:14:16 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 19:14:16 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 19:14:16 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-10 19:14:16 --> Could not find the language line "req_email"
INFO - 2018-04-10 19:14:16 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-04-10 19:14:16 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 19:14:16 --> Final output sent to browser
DEBUG - 2018-04-10 19:14:16 --> Total execution time: 0.2978
INFO - 2018-04-10 19:14:17 --> Config Class Initialized
INFO - 2018-04-10 19:14:17 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:14:17 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:14:17 --> Utf8 Class Initialized
INFO - 2018-04-10 19:14:17 --> URI Class Initialized
INFO - 2018-04-10 19:14:17 --> Router Class Initialized
INFO - 2018-04-10 19:14:17 --> Output Class Initialized
INFO - 2018-04-10 19:14:17 --> Security Class Initialized
DEBUG - 2018-04-10 19:14:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:14:17 --> CSRF cookie sent
INFO - 2018-04-10 19:14:17 --> Input Class Initialized
INFO - 2018-04-10 19:14:17 --> Language Class Initialized
ERROR - 2018-04-10 19:14:17 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 19:14:18 --> Config Class Initialized
INFO - 2018-04-10 19:14:18 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:14:18 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:14:18 --> Utf8 Class Initialized
INFO - 2018-04-10 19:14:18 --> URI Class Initialized
INFO - 2018-04-10 19:14:18 --> Router Class Initialized
INFO - 2018-04-10 19:14:18 --> Output Class Initialized
INFO - 2018-04-10 19:14:18 --> Security Class Initialized
DEBUG - 2018-04-10 19:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:14:18 --> CSRF cookie sent
INFO - 2018-04-10 19:14:18 --> Input Class Initialized
INFO - 2018-04-10 19:14:18 --> Language Class Initialized
INFO - 2018-04-10 19:14:18 --> Loader Class Initialized
INFO - 2018-04-10 19:14:18 --> Helper loaded: url_helper
INFO - 2018-04-10 19:14:18 --> Helper loaded: form_helper
INFO - 2018-04-10 19:14:18 --> Helper loaded: language_helper
DEBUG - 2018-04-10 19:14:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 19:14:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 19:14:18 --> User Agent Class Initialized
INFO - 2018-04-10 19:14:18 --> Controller Class Initialized
INFO - 2018-04-10 19:14:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 19:14:18 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 19:14:18 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 19:14:18 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 19:14:18 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 19:14:18 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-10 19:14:18 --> Could not find the language line "req_email"
INFO - 2018-04-10 19:14:18 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-04-10 19:14:18 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 19:14:18 --> Final output sent to browser
DEBUG - 2018-04-10 19:14:18 --> Total execution time: 0.3369
INFO - 2018-04-10 19:14:19 --> Config Class Initialized
INFO - 2018-04-10 19:14:19 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:14:19 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:14:19 --> Utf8 Class Initialized
INFO - 2018-04-10 19:14:19 --> URI Class Initialized
INFO - 2018-04-10 19:14:19 --> Router Class Initialized
INFO - 2018-04-10 19:14:19 --> Output Class Initialized
INFO - 2018-04-10 19:14:19 --> Security Class Initialized
DEBUG - 2018-04-10 19:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:14:19 --> CSRF cookie sent
INFO - 2018-04-10 19:14:19 --> Input Class Initialized
INFO - 2018-04-10 19:14:19 --> Language Class Initialized
ERROR - 2018-04-10 19:14:19 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 19:18:55 --> Config Class Initialized
INFO - 2018-04-10 19:18:55 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:18:55 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:18:55 --> Utf8 Class Initialized
INFO - 2018-04-10 19:18:55 --> URI Class Initialized
INFO - 2018-04-10 19:18:55 --> Router Class Initialized
INFO - 2018-04-10 19:18:55 --> Output Class Initialized
INFO - 2018-04-10 19:18:55 --> Security Class Initialized
DEBUG - 2018-04-10 19:18:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:18:55 --> CSRF cookie sent
INFO - 2018-04-10 19:18:55 --> Input Class Initialized
INFO - 2018-04-10 19:18:55 --> Language Class Initialized
INFO - 2018-04-10 19:18:55 --> Loader Class Initialized
INFO - 2018-04-10 19:18:55 --> Helper loaded: url_helper
INFO - 2018-04-10 19:18:55 --> Helper loaded: form_helper
INFO - 2018-04-10 19:18:55 --> Helper loaded: language_helper
DEBUG - 2018-04-10 19:18:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 19:18:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 19:18:55 --> User Agent Class Initialized
INFO - 2018-04-10 19:18:55 --> Controller Class Initialized
INFO - 2018-04-10 19:18:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 19:18:55 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 19:18:55 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 19:18:55 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 19:18:55 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 19:18:55 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-10 19:18:55 --> Could not find the language line "req_email"
INFO - 2018-04-10 19:18:55 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-04-10 19:18:55 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 19:18:55 --> Final output sent to browser
DEBUG - 2018-04-10 19:18:55 --> Total execution time: 0.2998
INFO - 2018-04-10 19:18:56 --> Config Class Initialized
INFO - 2018-04-10 19:18:56 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:18:56 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:18:56 --> Utf8 Class Initialized
INFO - 2018-04-10 19:18:56 --> URI Class Initialized
INFO - 2018-04-10 19:18:56 --> Router Class Initialized
INFO - 2018-04-10 19:18:56 --> Output Class Initialized
INFO - 2018-04-10 19:18:56 --> Security Class Initialized
DEBUG - 2018-04-10 19:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:18:56 --> CSRF cookie sent
INFO - 2018-04-10 19:18:56 --> Input Class Initialized
INFO - 2018-04-10 19:18:56 --> Language Class Initialized
ERROR - 2018-04-10 19:18:56 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 19:19:00 --> Config Class Initialized
INFO - 2018-04-10 19:19:00 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:19:00 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:19:00 --> Utf8 Class Initialized
INFO - 2018-04-10 19:19:00 --> URI Class Initialized
INFO - 2018-04-10 19:19:00 --> Router Class Initialized
INFO - 2018-04-10 19:19:00 --> Output Class Initialized
INFO - 2018-04-10 19:19:00 --> Security Class Initialized
DEBUG - 2018-04-10 19:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:19:00 --> CSRF cookie sent
INFO - 2018-04-10 19:19:00 --> Input Class Initialized
INFO - 2018-04-10 19:19:00 --> Language Class Initialized
INFO - 2018-04-10 19:19:00 --> Loader Class Initialized
INFO - 2018-04-10 19:19:00 --> Helper loaded: url_helper
INFO - 2018-04-10 19:19:00 --> Helper loaded: form_helper
INFO - 2018-04-10 19:19:00 --> Helper loaded: language_helper
DEBUG - 2018-04-10 19:19:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 19:19:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 19:19:00 --> User Agent Class Initialized
INFO - 2018-04-10 19:19:00 --> Controller Class Initialized
INFO - 2018-04-10 19:19:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 19:19:00 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 19:19:00 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 19:19:00 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 19:19:00 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 19:19:00 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-10 19:19:00 --> Could not find the language line "req_email"
INFO - 2018-04-10 19:19:00 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-04-10 19:19:00 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 19:19:00 --> Final output sent to browser
DEBUG - 2018-04-10 19:19:00 --> Total execution time: 0.3009
INFO - 2018-04-10 19:19:00 --> Config Class Initialized
INFO - 2018-04-10 19:19:00 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:19:00 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:19:00 --> Utf8 Class Initialized
INFO - 2018-04-10 19:19:00 --> URI Class Initialized
INFO - 2018-04-10 19:19:00 --> Router Class Initialized
INFO - 2018-04-10 19:19:00 --> Output Class Initialized
INFO - 2018-04-10 19:19:00 --> Security Class Initialized
DEBUG - 2018-04-10 19:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:19:00 --> CSRF cookie sent
INFO - 2018-04-10 19:19:00 --> Input Class Initialized
INFO - 2018-04-10 19:19:00 --> Language Class Initialized
ERROR - 2018-04-10 19:19:00 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 19:19:11 --> Config Class Initialized
INFO - 2018-04-10 19:19:11 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:19:11 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:19:11 --> Utf8 Class Initialized
INFO - 2018-04-10 19:19:11 --> URI Class Initialized
INFO - 2018-04-10 19:19:11 --> Router Class Initialized
INFO - 2018-04-10 19:19:11 --> Output Class Initialized
INFO - 2018-04-10 19:19:11 --> Security Class Initialized
DEBUG - 2018-04-10 19:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:19:11 --> CSRF cookie sent
INFO - 2018-04-10 19:19:11 --> Input Class Initialized
INFO - 2018-04-10 19:19:11 --> Language Class Initialized
INFO - 2018-04-10 19:19:11 --> Loader Class Initialized
INFO - 2018-04-10 19:19:11 --> Helper loaded: url_helper
INFO - 2018-04-10 19:19:11 --> Helper loaded: form_helper
INFO - 2018-04-10 19:19:11 --> Helper loaded: language_helper
DEBUG - 2018-04-10 19:19:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 19:19:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 19:19:11 --> User Agent Class Initialized
INFO - 2018-04-10 19:19:11 --> Controller Class Initialized
INFO - 2018-04-10 19:19:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 19:19:11 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 19:19:11 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 19:19:11 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 19:19:11 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 19:19:11 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-10 19:19:11 --> Could not find the language line "req_email"
INFO - 2018-04-10 19:19:11 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-04-10 19:19:11 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 19:19:11 --> Final output sent to browser
DEBUG - 2018-04-10 19:19:11 --> Total execution time: 0.3033
INFO - 2018-04-10 19:19:11 --> Config Class Initialized
INFO - 2018-04-10 19:19:11 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:19:11 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:19:11 --> Utf8 Class Initialized
INFO - 2018-04-10 19:19:11 --> URI Class Initialized
INFO - 2018-04-10 19:19:11 --> Router Class Initialized
INFO - 2018-04-10 19:19:11 --> Output Class Initialized
INFO - 2018-04-10 19:19:11 --> Security Class Initialized
DEBUG - 2018-04-10 19:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:19:11 --> CSRF cookie sent
INFO - 2018-04-10 19:19:11 --> Input Class Initialized
INFO - 2018-04-10 19:19:11 --> Language Class Initialized
ERROR - 2018-04-10 19:19:11 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 19:19:35 --> Config Class Initialized
INFO - 2018-04-10 19:19:35 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:19:35 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:19:35 --> Utf8 Class Initialized
INFO - 2018-04-10 19:19:35 --> URI Class Initialized
INFO - 2018-04-10 19:19:35 --> Router Class Initialized
INFO - 2018-04-10 19:19:35 --> Output Class Initialized
INFO - 2018-04-10 19:19:35 --> Security Class Initialized
DEBUG - 2018-04-10 19:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:19:35 --> CSRF cookie sent
INFO - 2018-04-10 19:19:35 --> Input Class Initialized
INFO - 2018-04-10 19:19:35 --> Language Class Initialized
INFO - 2018-04-10 19:19:35 --> Loader Class Initialized
INFO - 2018-04-10 19:19:35 --> Helper loaded: url_helper
INFO - 2018-04-10 19:19:35 --> Helper loaded: form_helper
INFO - 2018-04-10 19:19:35 --> Helper loaded: language_helper
DEBUG - 2018-04-10 19:19:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 19:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 19:19:35 --> User Agent Class Initialized
INFO - 2018-04-10 19:19:35 --> Controller Class Initialized
INFO - 2018-04-10 19:19:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 19:19:35 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 19:19:35 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 19:19:35 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 19:19:35 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 19:19:35 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-10 19:19:35 --> Could not find the language line "req_email"
INFO - 2018-04-10 19:19:35 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-04-10 19:19:35 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 19:19:35 --> Final output sent to browser
DEBUG - 2018-04-10 19:19:35 --> Total execution time: 0.3091
INFO - 2018-04-10 19:19:36 --> Config Class Initialized
INFO - 2018-04-10 19:19:36 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:19:36 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:19:36 --> Utf8 Class Initialized
INFO - 2018-04-10 19:19:36 --> URI Class Initialized
INFO - 2018-04-10 19:19:36 --> Router Class Initialized
INFO - 2018-04-10 19:19:36 --> Output Class Initialized
INFO - 2018-04-10 19:19:36 --> Security Class Initialized
DEBUG - 2018-04-10 19:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:19:36 --> CSRF cookie sent
INFO - 2018-04-10 19:19:36 --> Input Class Initialized
INFO - 2018-04-10 19:19:36 --> Language Class Initialized
ERROR - 2018-04-10 19:19:36 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 19:20:12 --> Config Class Initialized
INFO - 2018-04-10 19:20:12 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:20:12 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:20:12 --> Utf8 Class Initialized
INFO - 2018-04-10 19:20:12 --> URI Class Initialized
INFO - 2018-04-10 19:20:12 --> Router Class Initialized
INFO - 2018-04-10 19:20:12 --> Output Class Initialized
INFO - 2018-04-10 19:20:12 --> Security Class Initialized
DEBUG - 2018-04-10 19:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:20:12 --> CSRF cookie sent
INFO - 2018-04-10 19:20:12 --> Input Class Initialized
INFO - 2018-04-10 19:20:12 --> Language Class Initialized
INFO - 2018-04-10 19:20:12 --> Loader Class Initialized
INFO - 2018-04-10 19:20:12 --> Helper loaded: url_helper
INFO - 2018-04-10 19:20:12 --> Helper loaded: form_helper
INFO - 2018-04-10 19:20:12 --> Helper loaded: language_helper
DEBUG - 2018-04-10 19:20:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 19:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 19:20:12 --> User Agent Class Initialized
INFO - 2018-04-10 19:20:12 --> Controller Class Initialized
INFO - 2018-04-10 19:20:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 19:20:12 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 19:20:12 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 19:20:12 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 19:20:12 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 19:20:12 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-10 19:20:12 --> Could not find the language line "req_email"
INFO - 2018-04-10 19:20:12 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-04-10 19:20:12 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 19:20:12 --> Final output sent to browser
DEBUG - 2018-04-10 19:20:12 --> Total execution time: 0.3060
INFO - 2018-04-10 19:20:13 --> Config Class Initialized
INFO - 2018-04-10 19:20:13 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:20:13 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:20:13 --> Utf8 Class Initialized
INFO - 2018-04-10 19:20:13 --> URI Class Initialized
INFO - 2018-04-10 19:20:13 --> Router Class Initialized
INFO - 2018-04-10 19:20:13 --> Output Class Initialized
INFO - 2018-04-10 19:20:13 --> Security Class Initialized
DEBUG - 2018-04-10 19:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:20:13 --> CSRF cookie sent
INFO - 2018-04-10 19:20:13 --> Input Class Initialized
INFO - 2018-04-10 19:20:13 --> Language Class Initialized
ERROR - 2018-04-10 19:20:13 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 19:21:09 --> Config Class Initialized
INFO - 2018-04-10 19:21:09 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:21:09 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:21:09 --> Utf8 Class Initialized
INFO - 2018-04-10 19:21:09 --> URI Class Initialized
INFO - 2018-04-10 19:21:09 --> Router Class Initialized
INFO - 2018-04-10 19:21:09 --> Output Class Initialized
INFO - 2018-04-10 19:21:09 --> Security Class Initialized
DEBUG - 2018-04-10 19:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:21:09 --> CSRF cookie sent
INFO - 2018-04-10 19:21:09 --> Input Class Initialized
INFO - 2018-04-10 19:21:09 --> Language Class Initialized
INFO - 2018-04-10 19:21:09 --> Loader Class Initialized
INFO - 2018-04-10 19:21:09 --> Helper loaded: url_helper
INFO - 2018-04-10 19:21:09 --> Helper loaded: form_helper
INFO - 2018-04-10 19:21:09 --> Helper loaded: language_helper
DEBUG - 2018-04-10 19:21:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 19:21:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 19:21:09 --> User Agent Class Initialized
INFO - 2018-04-10 19:21:09 --> Controller Class Initialized
INFO - 2018-04-10 19:21:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 19:21:09 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 19:21:09 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 19:21:09 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 19:21:09 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 19:21:09 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-10 19:21:09 --> Could not find the language line "req_email"
INFO - 2018-04-10 19:21:09 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-04-10 19:21:09 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 19:21:09 --> Final output sent to browser
DEBUG - 2018-04-10 19:21:09 --> Total execution time: 0.3114
INFO - 2018-04-10 19:21:10 --> Config Class Initialized
INFO - 2018-04-10 19:21:10 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:21:10 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:21:10 --> Utf8 Class Initialized
INFO - 2018-04-10 19:21:10 --> URI Class Initialized
INFO - 2018-04-10 19:21:10 --> Router Class Initialized
INFO - 2018-04-10 19:21:10 --> Output Class Initialized
INFO - 2018-04-10 19:21:10 --> Security Class Initialized
DEBUG - 2018-04-10 19:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:21:10 --> CSRF cookie sent
INFO - 2018-04-10 19:21:10 --> Input Class Initialized
INFO - 2018-04-10 19:21:10 --> Language Class Initialized
ERROR - 2018-04-10 19:21:10 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 19:21:41 --> Config Class Initialized
INFO - 2018-04-10 19:21:41 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:21:41 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:21:41 --> Utf8 Class Initialized
INFO - 2018-04-10 19:21:41 --> URI Class Initialized
INFO - 2018-04-10 19:21:41 --> Router Class Initialized
INFO - 2018-04-10 19:21:41 --> Output Class Initialized
INFO - 2018-04-10 19:21:41 --> Security Class Initialized
DEBUG - 2018-04-10 19:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:21:41 --> CSRF cookie sent
INFO - 2018-04-10 19:21:41 --> Input Class Initialized
INFO - 2018-04-10 19:21:41 --> Language Class Initialized
INFO - 2018-04-10 19:21:41 --> Loader Class Initialized
INFO - 2018-04-10 19:21:41 --> Helper loaded: url_helper
INFO - 2018-04-10 19:21:41 --> Helper loaded: form_helper
INFO - 2018-04-10 19:21:41 --> Helper loaded: language_helper
DEBUG - 2018-04-10 19:21:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 19:21:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 19:21:41 --> User Agent Class Initialized
INFO - 2018-04-10 19:21:41 --> Controller Class Initialized
INFO - 2018-04-10 19:21:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 19:21:41 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 19:21:41 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 19:21:41 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 19:21:41 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 19:21:41 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-10 19:21:41 --> Could not find the language line "req_email"
INFO - 2018-04-10 19:21:41 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-04-10 19:21:41 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 19:21:41 --> Final output sent to browser
DEBUG - 2018-04-10 19:21:41 --> Total execution time: 0.3113
INFO - 2018-04-10 19:21:41 --> Config Class Initialized
INFO - 2018-04-10 19:21:41 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:21:41 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:21:41 --> Utf8 Class Initialized
INFO - 2018-04-10 19:21:41 --> URI Class Initialized
INFO - 2018-04-10 19:21:41 --> Router Class Initialized
INFO - 2018-04-10 19:21:41 --> Output Class Initialized
INFO - 2018-04-10 19:21:41 --> Security Class Initialized
DEBUG - 2018-04-10 19:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:21:42 --> CSRF cookie sent
INFO - 2018-04-10 19:21:42 --> Input Class Initialized
INFO - 2018-04-10 19:21:42 --> Language Class Initialized
ERROR - 2018-04-10 19:21:42 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 19:32:22 --> Config Class Initialized
INFO - 2018-04-10 19:32:22 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:32:22 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:32:22 --> Utf8 Class Initialized
INFO - 2018-04-10 19:32:22 --> URI Class Initialized
INFO - 2018-04-10 19:32:22 --> Router Class Initialized
INFO - 2018-04-10 19:32:22 --> Output Class Initialized
INFO - 2018-04-10 19:32:22 --> Security Class Initialized
DEBUG - 2018-04-10 19:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:32:22 --> CSRF cookie sent
INFO - 2018-04-10 19:32:22 --> Input Class Initialized
INFO - 2018-04-10 19:32:22 --> Language Class Initialized
INFO - 2018-04-10 19:32:22 --> Loader Class Initialized
INFO - 2018-04-10 19:32:22 --> Helper loaded: url_helper
INFO - 2018-04-10 19:32:22 --> Helper loaded: form_helper
INFO - 2018-04-10 19:32:22 --> Helper loaded: language_helper
DEBUG - 2018-04-10 19:32:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 19:32:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 19:32:22 --> User Agent Class Initialized
INFO - 2018-04-10 19:32:22 --> Controller Class Initialized
INFO - 2018-04-10 19:32:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 19:32:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-10 19:32:22 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 19:32:22 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 19:32:22 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-10 19:32:22 --> Could not find the language line "req_email"
INFO - 2018-04-10 19:32:22 --> File loaded: E:\www\yacopoo\application\views\01_register.php
INFO - 2018-04-10 19:32:22 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 19:32:22 --> Final output sent to browser
DEBUG - 2018-04-10 19:32:22 --> Total execution time: 0.3427
INFO - 2018-04-10 19:32:22 --> Config Class Initialized
INFO - 2018-04-10 19:32:22 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:32:22 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:32:22 --> Utf8 Class Initialized
INFO - 2018-04-10 19:32:22 --> URI Class Initialized
INFO - 2018-04-10 19:32:22 --> Router Class Initialized
INFO - 2018-04-10 19:32:22 --> Output Class Initialized
INFO - 2018-04-10 19:32:22 --> Security Class Initialized
DEBUG - 2018-04-10 19:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:32:22 --> CSRF cookie sent
INFO - 2018-04-10 19:32:22 --> Input Class Initialized
INFO - 2018-04-10 19:32:22 --> Language Class Initialized
ERROR - 2018-04-10 19:32:22 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 19:32:57 --> Config Class Initialized
INFO - 2018-04-10 19:32:57 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:32:57 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:32:57 --> Utf8 Class Initialized
INFO - 2018-04-10 19:32:57 --> URI Class Initialized
INFO - 2018-04-10 19:32:57 --> Router Class Initialized
INFO - 2018-04-10 19:32:57 --> Output Class Initialized
INFO - 2018-04-10 19:32:57 --> Security Class Initialized
DEBUG - 2018-04-10 19:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:32:57 --> CSRF cookie sent
INFO - 2018-04-10 19:32:57 --> Input Class Initialized
INFO - 2018-04-10 19:32:57 --> Language Class Initialized
INFO - 2018-04-10 19:32:57 --> Loader Class Initialized
INFO - 2018-04-10 19:32:57 --> Helper loaded: url_helper
INFO - 2018-04-10 19:32:57 --> Helper loaded: form_helper
INFO - 2018-04-10 19:32:57 --> Helper loaded: language_helper
DEBUG - 2018-04-10 19:32:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 19:32:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 19:32:57 --> User Agent Class Initialized
INFO - 2018-04-10 19:32:57 --> Controller Class Initialized
INFO - 2018-04-10 19:32:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 19:32:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-10 19:32:57 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 19:32:57 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 19:32:57 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-10 19:32:57 --> Could not find the language line "req_email"
INFO - 2018-04-10 19:32:57 --> File loaded: E:\www\yacopoo\application\views\01_register.php
INFO - 2018-04-10 19:32:57 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 19:32:57 --> Final output sent to browser
DEBUG - 2018-04-10 19:32:57 --> Total execution time: 0.3036
INFO - 2018-04-10 19:32:58 --> Config Class Initialized
INFO - 2018-04-10 19:32:58 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:32:58 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:32:58 --> Utf8 Class Initialized
INFO - 2018-04-10 19:32:58 --> URI Class Initialized
INFO - 2018-04-10 19:32:58 --> Router Class Initialized
INFO - 2018-04-10 19:32:58 --> Output Class Initialized
INFO - 2018-04-10 19:32:58 --> Security Class Initialized
DEBUG - 2018-04-10 19:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:32:58 --> CSRF cookie sent
INFO - 2018-04-10 19:32:58 --> Input Class Initialized
INFO - 2018-04-10 19:32:58 --> Language Class Initialized
ERROR - 2018-04-10 19:32:58 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 19:33:13 --> Config Class Initialized
INFO - 2018-04-10 19:33:13 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:33:13 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:33:13 --> Utf8 Class Initialized
INFO - 2018-04-10 19:33:13 --> URI Class Initialized
INFO - 2018-04-10 19:33:13 --> Router Class Initialized
INFO - 2018-04-10 19:33:13 --> Output Class Initialized
INFO - 2018-04-10 19:33:13 --> Security Class Initialized
DEBUG - 2018-04-10 19:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:33:13 --> CSRF cookie sent
INFO - 2018-04-10 19:33:13 --> Input Class Initialized
INFO - 2018-04-10 19:33:13 --> Language Class Initialized
INFO - 2018-04-10 19:33:13 --> Loader Class Initialized
INFO - 2018-04-10 19:33:13 --> Helper loaded: url_helper
INFO - 2018-04-10 19:33:13 --> Helper loaded: form_helper
INFO - 2018-04-10 19:33:13 --> Helper loaded: language_helper
DEBUG - 2018-04-10 19:33:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 19:33:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 19:33:13 --> User Agent Class Initialized
INFO - 2018-04-10 19:33:13 --> Controller Class Initialized
INFO - 2018-04-10 19:33:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 19:33:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-10 19:33:13 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 19:33:13 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 19:33:13 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-10 19:33:13 --> Could not find the language line "req_email"
INFO - 2018-04-10 19:33:13 --> File loaded: E:\www\yacopoo\application\views\01_register.php
INFO - 2018-04-10 19:33:13 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 19:33:13 --> Final output sent to browser
DEBUG - 2018-04-10 19:33:13 --> Total execution time: 0.3445
INFO - 2018-04-10 19:33:13 --> Config Class Initialized
INFO - 2018-04-10 19:33:13 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:33:13 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:33:13 --> Utf8 Class Initialized
INFO - 2018-04-10 19:33:13 --> URI Class Initialized
INFO - 2018-04-10 19:33:13 --> Router Class Initialized
INFO - 2018-04-10 19:33:13 --> Output Class Initialized
INFO - 2018-04-10 19:33:13 --> Security Class Initialized
DEBUG - 2018-04-10 19:33:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:33:14 --> CSRF cookie sent
INFO - 2018-04-10 19:33:14 --> Input Class Initialized
INFO - 2018-04-10 19:33:14 --> Language Class Initialized
ERROR - 2018-04-10 19:33:14 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 19:34:20 --> Config Class Initialized
INFO - 2018-04-10 19:34:20 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:34:20 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:34:20 --> Utf8 Class Initialized
INFO - 2018-04-10 19:34:20 --> URI Class Initialized
INFO - 2018-04-10 19:34:20 --> Router Class Initialized
INFO - 2018-04-10 19:34:20 --> Output Class Initialized
INFO - 2018-04-10 19:34:21 --> Security Class Initialized
DEBUG - 2018-04-10 19:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:34:21 --> CSRF cookie sent
INFO - 2018-04-10 19:34:21 --> Input Class Initialized
INFO - 2018-04-10 19:34:21 --> Language Class Initialized
INFO - 2018-04-10 19:34:21 --> Loader Class Initialized
INFO - 2018-04-10 19:34:21 --> Helper loaded: url_helper
INFO - 2018-04-10 19:34:21 --> Helper loaded: form_helper
INFO - 2018-04-10 19:34:21 --> Helper loaded: language_helper
DEBUG - 2018-04-10 19:34:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 19:34:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 19:34:21 --> User Agent Class Initialized
INFO - 2018-04-10 19:34:21 --> Controller Class Initialized
INFO - 2018-04-10 19:34:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 19:34:21 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 19:34:21 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 19:34:21 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 19:34:21 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 19:34:21 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-10 19:34:21 --> Could not find the language line "req_email"
INFO - 2018-04-10 19:34:21 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-04-10 19:34:21 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 19:34:21 --> Final output sent to browser
DEBUG - 2018-04-10 19:34:21 --> Total execution time: 0.3142
INFO - 2018-04-10 19:34:21 --> Config Class Initialized
INFO - 2018-04-10 19:34:21 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:34:21 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:34:21 --> Utf8 Class Initialized
INFO - 2018-04-10 19:34:21 --> URI Class Initialized
INFO - 2018-04-10 19:34:21 --> Router Class Initialized
INFO - 2018-04-10 19:34:21 --> Output Class Initialized
INFO - 2018-04-10 19:34:21 --> Security Class Initialized
DEBUG - 2018-04-10 19:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:34:21 --> CSRF cookie sent
INFO - 2018-04-10 19:34:21 --> Input Class Initialized
INFO - 2018-04-10 19:34:21 --> Language Class Initialized
ERROR - 2018-04-10 19:34:21 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 19:35:02 --> Config Class Initialized
INFO - 2018-04-10 19:35:02 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:35:02 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:35:02 --> Utf8 Class Initialized
INFO - 2018-04-10 19:35:02 --> URI Class Initialized
INFO - 2018-04-10 19:35:02 --> Router Class Initialized
INFO - 2018-04-10 19:35:02 --> Output Class Initialized
INFO - 2018-04-10 19:35:02 --> Security Class Initialized
DEBUG - 2018-04-10 19:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:35:02 --> CSRF cookie sent
INFO - 2018-04-10 19:35:02 --> Input Class Initialized
INFO - 2018-04-10 19:35:02 --> Language Class Initialized
INFO - 2018-04-10 19:35:02 --> Loader Class Initialized
INFO - 2018-04-10 19:35:02 --> Helper loaded: url_helper
INFO - 2018-04-10 19:35:02 --> Helper loaded: form_helper
INFO - 2018-04-10 19:35:02 --> Helper loaded: language_helper
DEBUG - 2018-04-10 19:35:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 19:35:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 19:35:02 --> User Agent Class Initialized
INFO - 2018-04-10 19:35:02 --> Controller Class Initialized
INFO - 2018-04-10 19:35:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 19:35:02 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 19:35:02 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 19:35:02 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 19:35:02 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 19:35:02 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-10 19:35:02 --> Could not find the language line "req_email"
INFO - 2018-04-10 19:35:02 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-04-10 19:35:02 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 19:35:02 --> Final output sent to browser
DEBUG - 2018-04-10 19:35:02 --> Total execution time: 0.3615
INFO - 2018-04-10 19:35:03 --> Config Class Initialized
INFO - 2018-04-10 19:35:03 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:35:03 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:35:03 --> Utf8 Class Initialized
INFO - 2018-04-10 19:35:03 --> URI Class Initialized
INFO - 2018-04-10 19:35:03 --> Router Class Initialized
INFO - 2018-04-10 19:35:03 --> Output Class Initialized
INFO - 2018-04-10 19:35:03 --> Security Class Initialized
DEBUG - 2018-04-10 19:35:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:35:03 --> CSRF cookie sent
INFO - 2018-04-10 19:35:03 --> Input Class Initialized
INFO - 2018-04-10 19:35:03 --> Language Class Initialized
ERROR - 2018-04-10 19:35:03 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 19:36:10 --> Config Class Initialized
INFO - 2018-04-10 19:36:10 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:36:10 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:36:10 --> Utf8 Class Initialized
INFO - 2018-04-10 19:36:10 --> URI Class Initialized
INFO - 2018-04-10 19:36:10 --> Router Class Initialized
INFO - 2018-04-10 19:36:10 --> Output Class Initialized
INFO - 2018-04-10 19:36:10 --> Security Class Initialized
DEBUG - 2018-04-10 19:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:36:10 --> CSRF cookie sent
INFO - 2018-04-10 19:36:10 --> Input Class Initialized
INFO - 2018-04-10 19:36:10 --> Language Class Initialized
INFO - 2018-04-10 19:36:10 --> Loader Class Initialized
INFO - 2018-04-10 19:36:10 --> Helper loaded: url_helper
INFO - 2018-04-10 19:36:10 --> Helper loaded: form_helper
INFO - 2018-04-10 19:36:10 --> Helper loaded: language_helper
DEBUG - 2018-04-10 19:36:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 19:36:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 19:36:10 --> User Agent Class Initialized
INFO - 2018-04-10 19:36:10 --> Controller Class Initialized
INFO - 2018-04-10 19:36:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 19:36:10 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 19:36:10 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 19:36:10 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 19:36:10 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 19:36:10 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-10 19:36:10 --> Could not find the language line "req_email"
INFO - 2018-04-10 19:36:10 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-04-10 19:36:10 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 19:36:10 --> Final output sent to browser
DEBUG - 2018-04-10 19:36:10 --> Total execution time: 0.3278
INFO - 2018-04-10 19:36:11 --> Config Class Initialized
INFO - 2018-04-10 19:36:11 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:36:11 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:36:11 --> Utf8 Class Initialized
INFO - 2018-04-10 19:36:11 --> URI Class Initialized
INFO - 2018-04-10 19:36:11 --> Router Class Initialized
INFO - 2018-04-10 19:36:11 --> Output Class Initialized
INFO - 2018-04-10 19:36:11 --> Security Class Initialized
DEBUG - 2018-04-10 19:36:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:36:11 --> CSRF cookie sent
INFO - 2018-04-10 19:36:11 --> Input Class Initialized
INFO - 2018-04-10 19:36:11 --> Language Class Initialized
ERROR - 2018-04-10 19:36:11 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 19:36:50 --> Config Class Initialized
INFO - 2018-04-10 19:36:50 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:36:50 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:36:50 --> Utf8 Class Initialized
INFO - 2018-04-10 19:36:51 --> URI Class Initialized
INFO - 2018-04-10 19:36:51 --> Router Class Initialized
INFO - 2018-04-10 19:36:51 --> Output Class Initialized
INFO - 2018-04-10 19:36:51 --> Security Class Initialized
DEBUG - 2018-04-10 19:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:36:51 --> CSRF cookie sent
INFO - 2018-04-10 19:36:51 --> Input Class Initialized
INFO - 2018-04-10 19:36:51 --> Language Class Initialized
INFO - 2018-04-10 19:36:51 --> Loader Class Initialized
INFO - 2018-04-10 19:36:51 --> Helper loaded: url_helper
INFO - 2018-04-10 19:36:51 --> Helper loaded: form_helper
INFO - 2018-04-10 19:36:51 --> Helper loaded: language_helper
DEBUG - 2018-04-10 19:36:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 19:36:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 19:36:51 --> User Agent Class Initialized
INFO - 2018-04-10 19:36:51 --> Controller Class Initialized
INFO - 2018-04-10 19:36:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 19:36:51 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 19:36:51 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 19:36:51 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 19:36:51 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 19:36:51 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-10 19:36:51 --> Could not find the language line "req_email"
INFO - 2018-04-10 19:36:51 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-04-10 19:36:51 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 19:36:51 --> Final output sent to browser
DEBUG - 2018-04-10 19:36:51 --> Total execution time: 0.3501
INFO - 2018-04-10 19:36:51 --> Config Class Initialized
INFO - 2018-04-10 19:36:51 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:36:51 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:36:51 --> Utf8 Class Initialized
INFO - 2018-04-10 19:36:51 --> URI Class Initialized
INFO - 2018-04-10 19:36:51 --> Router Class Initialized
INFO - 2018-04-10 19:36:51 --> Output Class Initialized
INFO - 2018-04-10 19:36:51 --> Security Class Initialized
DEBUG - 2018-04-10 19:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:36:51 --> CSRF cookie sent
INFO - 2018-04-10 19:36:51 --> Input Class Initialized
INFO - 2018-04-10 19:36:51 --> Language Class Initialized
ERROR - 2018-04-10 19:36:51 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 19:38:38 --> Config Class Initialized
INFO - 2018-04-10 19:38:38 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:38:38 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:38:38 --> Utf8 Class Initialized
INFO - 2018-04-10 19:38:38 --> URI Class Initialized
INFO - 2018-04-10 19:38:38 --> Router Class Initialized
INFO - 2018-04-10 19:38:38 --> Output Class Initialized
INFO - 2018-04-10 19:38:38 --> Security Class Initialized
DEBUG - 2018-04-10 19:38:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:38:38 --> CSRF cookie sent
INFO - 2018-04-10 19:38:38 --> Input Class Initialized
INFO - 2018-04-10 19:38:38 --> Language Class Initialized
INFO - 2018-04-10 19:38:38 --> Loader Class Initialized
INFO - 2018-04-10 19:38:38 --> Helper loaded: url_helper
INFO - 2018-04-10 19:38:38 --> Helper loaded: form_helper
INFO - 2018-04-10 19:38:38 --> Helper loaded: language_helper
DEBUG - 2018-04-10 19:38:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 19:38:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 19:38:38 --> User Agent Class Initialized
INFO - 2018-04-10 19:38:38 --> Controller Class Initialized
INFO - 2018-04-10 19:38:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 19:38:38 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 19:38:38 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 19:38:38 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 19:38:38 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 19:38:38 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-10 19:38:38 --> Could not find the language line "req_email"
INFO - 2018-04-10 19:38:38 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-04-10 19:38:38 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 19:38:38 --> Final output sent to browser
DEBUG - 2018-04-10 19:38:38 --> Total execution time: 0.3831
INFO - 2018-04-10 19:38:39 --> Config Class Initialized
INFO - 2018-04-10 19:38:39 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:38:39 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:38:39 --> Utf8 Class Initialized
INFO - 2018-04-10 19:38:39 --> URI Class Initialized
INFO - 2018-04-10 19:38:39 --> Router Class Initialized
INFO - 2018-04-10 19:38:39 --> Output Class Initialized
INFO - 2018-04-10 19:38:39 --> Security Class Initialized
DEBUG - 2018-04-10 19:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:38:39 --> CSRF cookie sent
INFO - 2018-04-10 19:38:39 --> Input Class Initialized
INFO - 2018-04-10 19:38:39 --> Language Class Initialized
ERROR - 2018-04-10 19:38:39 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 19:39:20 --> Config Class Initialized
INFO - 2018-04-10 19:39:20 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:39:20 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:39:20 --> Utf8 Class Initialized
INFO - 2018-04-10 19:39:20 --> URI Class Initialized
INFO - 2018-04-10 19:39:20 --> Router Class Initialized
INFO - 2018-04-10 19:39:20 --> Output Class Initialized
INFO - 2018-04-10 19:39:20 --> Security Class Initialized
DEBUG - 2018-04-10 19:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:39:20 --> CSRF cookie sent
INFO - 2018-04-10 19:39:20 --> Input Class Initialized
INFO - 2018-04-10 19:39:20 --> Language Class Initialized
INFO - 2018-04-10 19:39:20 --> Loader Class Initialized
INFO - 2018-04-10 19:39:20 --> Helper loaded: url_helper
INFO - 2018-04-10 19:39:20 --> Helper loaded: form_helper
INFO - 2018-04-10 19:39:20 --> Helper loaded: language_helper
DEBUG - 2018-04-10 19:39:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 19:39:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 19:39:20 --> User Agent Class Initialized
INFO - 2018-04-10 19:39:20 --> Controller Class Initialized
INFO - 2018-04-10 19:39:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 19:39:20 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 19:39:20 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 19:39:20 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 19:39:20 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 19:39:20 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-10 19:39:20 --> Could not find the language line "req_email"
INFO - 2018-04-10 19:39:20 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-04-10 19:39:20 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 19:39:20 --> Final output sent to browser
DEBUG - 2018-04-10 19:39:20 --> Total execution time: 0.3335
INFO - 2018-04-10 19:39:21 --> Config Class Initialized
INFO - 2018-04-10 19:39:21 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:39:21 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:39:21 --> Utf8 Class Initialized
INFO - 2018-04-10 19:39:21 --> URI Class Initialized
INFO - 2018-04-10 19:39:21 --> Router Class Initialized
INFO - 2018-04-10 19:39:21 --> Output Class Initialized
INFO - 2018-04-10 19:39:21 --> Security Class Initialized
DEBUG - 2018-04-10 19:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:39:21 --> CSRF cookie sent
INFO - 2018-04-10 19:39:21 --> Input Class Initialized
INFO - 2018-04-10 19:39:21 --> Language Class Initialized
ERROR - 2018-04-10 19:39:21 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 19:41:34 --> Config Class Initialized
INFO - 2018-04-10 19:41:34 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:41:34 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:41:34 --> Utf8 Class Initialized
INFO - 2018-04-10 19:41:34 --> URI Class Initialized
INFO - 2018-04-10 19:41:34 --> Router Class Initialized
INFO - 2018-04-10 19:41:34 --> Output Class Initialized
INFO - 2018-04-10 19:41:34 --> Security Class Initialized
DEBUG - 2018-04-10 19:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:41:34 --> CSRF cookie sent
INFO - 2018-04-10 19:41:34 --> Input Class Initialized
INFO - 2018-04-10 19:41:34 --> Language Class Initialized
INFO - 2018-04-10 19:41:34 --> Loader Class Initialized
INFO - 2018-04-10 19:41:34 --> Helper loaded: url_helper
INFO - 2018-04-10 19:41:34 --> Helper loaded: form_helper
INFO - 2018-04-10 19:41:34 --> Helper loaded: language_helper
DEBUG - 2018-04-10 19:41:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 19:41:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 19:41:34 --> User Agent Class Initialized
INFO - 2018-04-10 19:41:34 --> Controller Class Initialized
INFO - 2018-04-10 19:41:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 19:41:34 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 19:41:34 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 19:41:34 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 19:41:34 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 19:41:34 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-10 19:41:34 --> Could not find the language line "req_email"
INFO - 2018-04-10 19:41:34 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-04-10 19:41:34 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 19:41:34 --> Final output sent to browser
DEBUG - 2018-04-10 19:41:34 --> Total execution time: 0.4833
INFO - 2018-04-10 19:41:35 --> Config Class Initialized
INFO - 2018-04-10 19:41:35 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:41:35 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:41:35 --> Utf8 Class Initialized
INFO - 2018-04-10 19:41:35 --> URI Class Initialized
INFO - 2018-04-10 19:41:35 --> Router Class Initialized
INFO - 2018-04-10 19:41:35 --> Output Class Initialized
INFO - 2018-04-10 19:41:35 --> Security Class Initialized
DEBUG - 2018-04-10 19:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:41:35 --> CSRF cookie sent
INFO - 2018-04-10 19:41:35 --> Input Class Initialized
INFO - 2018-04-10 19:41:35 --> Language Class Initialized
ERROR - 2018-04-10 19:41:35 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 19:41:36 --> Config Class Initialized
INFO - 2018-04-10 19:41:36 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:41:36 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:41:36 --> Utf8 Class Initialized
INFO - 2018-04-10 19:41:36 --> URI Class Initialized
INFO - 2018-04-10 19:41:36 --> Router Class Initialized
INFO - 2018-04-10 19:41:36 --> Output Class Initialized
INFO - 2018-04-10 19:41:36 --> Security Class Initialized
DEBUG - 2018-04-10 19:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:41:36 --> CSRF cookie sent
INFO - 2018-04-10 19:41:36 --> Input Class Initialized
INFO - 2018-04-10 19:41:36 --> Language Class Initialized
INFO - 2018-04-10 19:41:36 --> Loader Class Initialized
INFO - 2018-04-10 19:41:36 --> Helper loaded: url_helper
INFO - 2018-04-10 19:41:36 --> Helper loaded: form_helper
INFO - 2018-04-10 19:41:36 --> Helper loaded: language_helper
DEBUG - 2018-04-10 19:41:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 19:41:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 19:41:36 --> User Agent Class Initialized
INFO - 2018-04-10 19:41:36 --> Controller Class Initialized
INFO - 2018-04-10 19:41:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 19:41:36 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 19:41:36 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 19:41:36 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 19:41:36 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 19:41:36 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-10 19:41:36 --> Could not find the language line "req_email"
INFO - 2018-04-10 19:41:36 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-04-10 19:41:36 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 19:41:36 --> Final output sent to browser
DEBUG - 2018-04-10 19:41:36 --> Total execution time: 0.4826
INFO - 2018-04-10 19:41:37 --> Config Class Initialized
INFO - 2018-04-10 19:41:37 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:41:37 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:41:37 --> Utf8 Class Initialized
INFO - 2018-04-10 19:41:37 --> URI Class Initialized
INFO - 2018-04-10 19:41:37 --> Router Class Initialized
INFO - 2018-04-10 19:41:37 --> Output Class Initialized
INFO - 2018-04-10 19:41:37 --> Security Class Initialized
DEBUG - 2018-04-10 19:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:41:37 --> CSRF cookie sent
INFO - 2018-04-10 19:41:37 --> Input Class Initialized
INFO - 2018-04-10 19:41:37 --> Language Class Initialized
ERROR - 2018-04-10 19:41:37 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 19:43:01 --> Config Class Initialized
INFO - 2018-04-10 19:43:01 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:43:01 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:43:01 --> Utf8 Class Initialized
INFO - 2018-04-10 19:43:01 --> URI Class Initialized
INFO - 2018-04-10 19:43:01 --> Router Class Initialized
INFO - 2018-04-10 19:43:01 --> Output Class Initialized
INFO - 2018-04-10 19:43:01 --> Security Class Initialized
DEBUG - 2018-04-10 19:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:43:01 --> CSRF cookie sent
INFO - 2018-04-10 19:43:01 --> Input Class Initialized
INFO - 2018-04-10 19:43:01 --> Language Class Initialized
INFO - 2018-04-10 19:43:01 --> Loader Class Initialized
INFO - 2018-04-10 19:43:01 --> Helper loaded: url_helper
INFO - 2018-04-10 19:43:01 --> Helper loaded: form_helper
INFO - 2018-04-10 19:43:01 --> Helper loaded: language_helper
DEBUG - 2018-04-10 19:43:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 19:43:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 19:43:01 --> User Agent Class Initialized
INFO - 2018-04-10 19:43:01 --> Controller Class Initialized
INFO - 2018-04-10 19:43:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 19:43:01 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 19:43:01 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 19:43:01 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 19:43:01 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 19:43:01 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-10 19:43:01 --> Could not find the language line "req_email"
INFO - 2018-04-10 19:43:01 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-04-10 19:43:01 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 19:43:01 --> Final output sent to browser
DEBUG - 2018-04-10 19:43:01 --> Total execution time: 0.3732
INFO - 2018-04-10 19:43:01 --> Config Class Initialized
INFO - 2018-04-10 19:43:01 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:43:01 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:43:01 --> Utf8 Class Initialized
INFO - 2018-04-10 19:43:01 --> URI Class Initialized
INFO - 2018-04-10 19:43:01 --> Router Class Initialized
INFO - 2018-04-10 19:43:01 --> Output Class Initialized
INFO - 2018-04-10 19:43:01 --> Security Class Initialized
DEBUG - 2018-04-10 19:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:43:02 --> CSRF cookie sent
INFO - 2018-04-10 19:43:02 --> Input Class Initialized
INFO - 2018-04-10 19:43:02 --> Language Class Initialized
ERROR - 2018-04-10 19:43:02 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 19:43:02 --> Config Class Initialized
INFO - 2018-04-10 19:43:02 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:43:02 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:43:02 --> Utf8 Class Initialized
INFO - 2018-04-10 19:43:02 --> URI Class Initialized
INFO - 2018-04-10 19:43:02 --> Router Class Initialized
INFO - 2018-04-10 19:43:02 --> Output Class Initialized
INFO - 2018-04-10 19:43:02 --> Security Class Initialized
DEBUG - 2018-04-10 19:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:43:02 --> CSRF cookie sent
INFO - 2018-04-10 19:43:02 --> Input Class Initialized
INFO - 2018-04-10 19:43:02 --> Language Class Initialized
INFO - 2018-04-10 19:43:02 --> Loader Class Initialized
INFO - 2018-04-10 19:43:02 --> Helper loaded: url_helper
INFO - 2018-04-10 19:43:02 --> Helper loaded: form_helper
INFO - 2018-04-10 19:43:02 --> Helper loaded: language_helper
DEBUG - 2018-04-10 19:43:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 19:43:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 19:43:02 --> User Agent Class Initialized
INFO - 2018-04-10 19:43:02 --> Controller Class Initialized
INFO - 2018-04-10 19:43:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 19:43:02 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 19:43:02 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 19:43:02 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 19:43:02 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 19:43:02 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-10 19:43:02 --> Could not find the language line "req_email"
INFO - 2018-04-10 19:43:02 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-04-10 19:43:02 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 19:43:02 --> Final output sent to browser
DEBUG - 2018-04-10 19:43:02 --> Total execution time: 0.5230
INFO - 2018-04-10 19:43:03 --> Config Class Initialized
INFO - 2018-04-10 19:43:03 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:43:03 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:43:03 --> Utf8 Class Initialized
INFO - 2018-04-10 19:43:03 --> URI Class Initialized
INFO - 2018-04-10 19:43:03 --> Router Class Initialized
INFO - 2018-04-10 19:43:03 --> Output Class Initialized
INFO - 2018-04-10 19:43:03 --> Security Class Initialized
DEBUG - 2018-04-10 19:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:43:03 --> CSRF cookie sent
INFO - 2018-04-10 19:43:03 --> Input Class Initialized
INFO - 2018-04-10 19:43:03 --> Language Class Initialized
ERROR - 2018-04-10 19:43:03 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 19:43:51 --> Config Class Initialized
INFO - 2018-04-10 19:43:51 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:43:51 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:43:51 --> Utf8 Class Initialized
INFO - 2018-04-10 19:43:51 --> URI Class Initialized
INFO - 2018-04-10 19:43:51 --> Router Class Initialized
INFO - 2018-04-10 19:43:51 --> Output Class Initialized
INFO - 2018-04-10 19:43:51 --> Security Class Initialized
DEBUG - 2018-04-10 19:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:43:51 --> CSRF cookie sent
INFO - 2018-04-10 19:43:51 --> Input Class Initialized
INFO - 2018-04-10 19:43:51 --> Language Class Initialized
INFO - 2018-04-10 19:43:51 --> Loader Class Initialized
INFO - 2018-04-10 19:43:51 --> Helper loaded: url_helper
INFO - 2018-04-10 19:43:51 --> Helper loaded: form_helper
INFO - 2018-04-10 19:43:51 --> Helper loaded: language_helper
DEBUG - 2018-04-10 19:43:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 19:43:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 19:43:51 --> User Agent Class Initialized
INFO - 2018-04-10 19:43:51 --> Controller Class Initialized
INFO - 2018-04-10 19:43:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 19:43:51 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 19:43:51 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 19:43:51 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 19:43:51 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 19:43:51 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-10 19:43:51 --> Could not find the language line "req_email"
INFO - 2018-04-10 19:43:51 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-04-10 19:43:51 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 19:43:51 --> Final output sent to browser
DEBUG - 2018-04-10 19:43:51 --> Total execution time: 0.4111
INFO - 2018-04-10 19:43:51 --> Config Class Initialized
INFO - 2018-04-10 19:43:51 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:43:51 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:43:51 --> Utf8 Class Initialized
INFO - 2018-04-10 19:43:51 --> URI Class Initialized
INFO - 2018-04-10 19:43:52 --> Router Class Initialized
INFO - 2018-04-10 19:43:52 --> Output Class Initialized
INFO - 2018-04-10 19:43:52 --> Security Class Initialized
DEBUG - 2018-04-10 19:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:43:52 --> CSRF cookie sent
INFO - 2018-04-10 19:43:52 --> Input Class Initialized
INFO - 2018-04-10 19:43:52 --> Language Class Initialized
ERROR - 2018-04-10 19:43:52 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 19:44:56 --> Config Class Initialized
INFO - 2018-04-10 19:44:56 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:44:56 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:44:56 --> Utf8 Class Initialized
INFO - 2018-04-10 19:44:56 --> URI Class Initialized
INFO - 2018-04-10 19:44:56 --> Router Class Initialized
INFO - 2018-04-10 19:44:56 --> Output Class Initialized
INFO - 2018-04-10 19:44:56 --> Security Class Initialized
DEBUG - 2018-04-10 19:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:44:56 --> CSRF cookie sent
INFO - 2018-04-10 19:44:56 --> Input Class Initialized
INFO - 2018-04-10 19:44:56 --> Language Class Initialized
INFO - 2018-04-10 19:44:56 --> Loader Class Initialized
INFO - 2018-04-10 19:44:56 --> Helper loaded: url_helper
INFO - 2018-04-10 19:44:56 --> Helper loaded: form_helper
INFO - 2018-04-10 19:44:56 --> Helper loaded: language_helper
DEBUG - 2018-04-10 19:44:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 19:44:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 19:44:56 --> User Agent Class Initialized
INFO - 2018-04-10 19:44:56 --> Controller Class Initialized
INFO - 2018-04-10 19:44:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 19:44:56 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 19:44:56 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 19:44:56 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 19:44:56 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 19:44:56 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-10 19:44:56 --> Could not find the language line "req_email"
INFO - 2018-04-10 19:44:56 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-04-10 19:44:56 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 19:44:56 --> Final output sent to browser
DEBUG - 2018-04-10 19:44:56 --> Total execution time: 0.3542
INFO - 2018-04-10 19:44:57 --> Config Class Initialized
INFO - 2018-04-10 19:44:57 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:44:57 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:44:57 --> Utf8 Class Initialized
INFO - 2018-04-10 19:44:57 --> URI Class Initialized
INFO - 2018-04-10 19:44:57 --> Router Class Initialized
INFO - 2018-04-10 19:44:57 --> Output Class Initialized
INFO - 2018-04-10 19:44:57 --> Security Class Initialized
DEBUG - 2018-04-10 19:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:44:57 --> CSRF cookie sent
INFO - 2018-04-10 19:44:57 --> Input Class Initialized
INFO - 2018-04-10 19:44:57 --> Language Class Initialized
ERROR - 2018-04-10 19:44:57 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 19:46:03 --> Config Class Initialized
INFO - 2018-04-10 19:46:03 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:46:03 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:46:03 --> Utf8 Class Initialized
INFO - 2018-04-10 19:46:03 --> URI Class Initialized
INFO - 2018-04-10 19:46:03 --> Router Class Initialized
INFO - 2018-04-10 19:46:03 --> Output Class Initialized
INFO - 2018-04-10 19:46:03 --> Security Class Initialized
DEBUG - 2018-04-10 19:46:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:46:03 --> CSRF cookie sent
INFO - 2018-04-10 19:46:03 --> Input Class Initialized
INFO - 2018-04-10 19:46:03 --> Language Class Initialized
INFO - 2018-04-10 19:46:04 --> Loader Class Initialized
INFO - 2018-04-10 19:46:04 --> Helper loaded: url_helper
INFO - 2018-04-10 19:46:04 --> Helper loaded: form_helper
INFO - 2018-04-10 19:46:04 --> Helper loaded: language_helper
DEBUG - 2018-04-10 19:46:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 19:46:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 19:46:04 --> User Agent Class Initialized
INFO - 2018-04-10 19:46:04 --> Controller Class Initialized
INFO - 2018-04-10 19:46:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 19:46:04 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 19:46:04 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 19:46:04 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 19:46:04 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 19:46:04 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-10 19:46:04 --> Could not find the language line "req_email"
INFO - 2018-04-10 19:46:04 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-04-10 19:46:04 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 19:46:04 --> Final output sent to browser
DEBUG - 2018-04-10 19:46:04 --> Total execution time: 0.3295
INFO - 2018-04-10 19:46:04 --> Config Class Initialized
INFO - 2018-04-10 19:46:04 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:46:04 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:46:04 --> Utf8 Class Initialized
INFO - 2018-04-10 19:46:04 --> URI Class Initialized
INFO - 2018-04-10 19:46:04 --> Router Class Initialized
INFO - 2018-04-10 19:46:04 --> Output Class Initialized
INFO - 2018-04-10 19:46:04 --> Security Class Initialized
DEBUG - 2018-04-10 19:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:46:04 --> CSRF cookie sent
INFO - 2018-04-10 19:46:04 --> Input Class Initialized
INFO - 2018-04-10 19:46:04 --> Language Class Initialized
ERROR - 2018-04-10 19:46:04 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 19:46:23 --> Config Class Initialized
INFO - 2018-04-10 19:46:24 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:46:24 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:46:24 --> Utf8 Class Initialized
INFO - 2018-04-10 19:46:24 --> URI Class Initialized
INFO - 2018-04-10 19:46:24 --> Router Class Initialized
INFO - 2018-04-10 19:46:24 --> Output Class Initialized
INFO - 2018-04-10 19:46:24 --> Security Class Initialized
DEBUG - 2018-04-10 19:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:46:24 --> CSRF cookie sent
INFO - 2018-04-10 19:46:24 --> Input Class Initialized
INFO - 2018-04-10 19:46:24 --> Language Class Initialized
INFO - 2018-04-10 19:46:24 --> Loader Class Initialized
INFO - 2018-04-10 19:46:24 --> Helper loaded: url_helper
INFO - 2018-04-10 19:46:24 --> Helper loaded: form_helper
INFO - 2018-04-10 19:46:24 --> Helper loaded: language_helper
DEBUG - 2018-04-10 19:46:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 19:46:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 19:46:24 --> User Agent Class Initialized
INFO - 2018-04-10 19:46:24 --> Controller Class Initialized
INFO - 2018-04-10 19:46:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 19:46:24 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 19:46:24 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 19:46:24 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 19:46:24 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 19:46:24 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-10 19:46:24 --> Could not find the language line "req_email"
INFO - 2018-04-10 19:46:24 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-04-10 19:46:24 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 19:46:24 --> Final output sent to browser
DEBUG - 2018-04-10 19:46:24 --> Total execution time: 0.3357
INFO - 2018-04-10 19:46:24 --> Config Class Initialized
INFO - 2018-04-10 19:46:24 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:46:24 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:46:24 --> Utf8 Class Initialized
INFO - 2018-04-10 19:46:24 --> URI Class Initialized
INFO - 2018-04-10 19:46:24 --> Router Class Initialized
INFO - 2018-04-10 19:46:24 --> Output Class Initialized
INFO - 2018-04-10 19:46:24 --> Security Class Initialized
DEBUG - 2018-04-10 19:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:46:24 --> CSRF cookie sent
INFO - 2018-04-10 19:46:24 --> Input Class Initialized
INFO - 2018-04-10 19:46:24 --> Language Class Initialized
ERROR - 2018-04-10 19:46:24 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 19:48:48 --> Config Class Initialized
INFO - 2018-04-10 19:48:48 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:48:48 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:48:48 --> Utf8 Class Initialized
INFO - 2018-04-10 19:48:48 --> URI Class Initialized
INFO - 2018-04-10 19:48:48 --> Router Class Initialized
INFO - 2018-04-10 19:48:48 --> Output Class Initialized
INFO - 2018-04-10 19:48:48 --> Security Class Initialized
DEBUG - 2018-04-10 19:48:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:48:48 --> CSRF cookie sent
INFO - 2018-04-10 19:48:48 --> Input Class Initialized
INFO - 2018-04-10 19:48:48 --> Language Class Initialized
INFO - 2018-04-10 19:48:48 --> Loader Class Initialized
INFO - 2018-04-10 19:48:48 --> Helper loaded: url_helper
INFO - 2018-04-10 19:48:48 --> Helper loaded: form_helper
INFO - 2018-04-10 19:48:48 --> Helper loaded: language_helper
DEBUG - 2018-04-10 19:48:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 19:48:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 19:48:48 --> User Agent Class Initialized
INFO - 2018-04-10 19:48:48 --> Controller Class Initialized
INFO - 2018-04-10 19:48:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 19:48:48 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 19:48:48 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 19:48:48 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 19:48:48 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 19:48:48 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-10 19:48:48 --> Could not find the language line "req_email"
INFO - 2018-04-10 19:48:48 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-04-10 19:48:48 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 19:48:48 --> Final output sent to browser
DEBUG - 2018-04-10 19:48:48 --> Total execution time: 0.5708
INFO - 2018-04-10 19:48:49 --> Config Class Initialized
INFO - 2018-04-10 19:48:49 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:48:49 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:48:49 --> Utf8 Class Initialized
INFO - 2018-04-10 19:48:49 --> URI Class Initialized
INFO - 2018-04-10 19:48:49 --> Router Class Initialized
INFO - 2018-04-10 19:48:49 --> Output Class Initialized
INFO - 2018-04-10 19:48:49 --> Security Class Initialized
DEBUG - 2018-04-10 19:48:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:48:49 --> CSRF cookie sent
INFO - 2018-04-10 19:48:49 --> Input Class Initialized
INFO - 2018-04-10 19:48:49 --> Language Class Initialized
ERROR - 2018-04-10 19:48:49 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 19:49:43 --> Config Class Initialized
INFO - 2018-04-10 19:49:43 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:49:43 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:49:43 --> Utf8 Class Initialized
INFO - 2018-04-10 19:49:43 --> URI Class Initialized
INFO - 2018-04-10 19:49:43 --> Router Class Initialized
INFO - 2018-04-10 19:49:43 --> Output Class Initialized
INFO - 2018-04-10 19:49:43 --> Security Class Initialized
DEBUG - 2018-04-10 19:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:49:43 --> CSRF cookie sent
INFO - 2018-04-10 19:49:43 --> Input Class Initialized
INFO - 2018-04-10 19:49:43 --> Language Class Initialized
INFO - 2018-04-10 19:49:43 --> Loader Class Initialized
INFO - 2018-04-10 19:49:43 --> Helper loaded: url_helper
INFO - 2018-04-10 19:49:43 --> Helper loaded: form_helper
INFO - 2018-04-10 19:49:43 --> Helper loaded: language_helper
DEBUG - 2018-04-10 19:49:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 19:49:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 19:49:43 --> User Agent Class Initialized
INFO - 2018-04-10 19:49:43 --> Controller Class Initialized
INFO - 2018-04-10 19:49:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 19:49:43 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 19:49:43 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 19:49:43 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 19:49:43 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 19:49:43 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-10 19:49:43 --> Could not find the language line "req_email"
INFO - 2018-04-10 19:49:43 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-04-10 19:49:43 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 19:49:43 --> Final output sent to browser
DEBUG - 2018-04-10 19:49:43 --> Total execution time: 0.3372
INFO - 2018-04-10 19:49:43 --> Config Class Initialized
INFO - 2018-04-10 19:49:43 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:49:43 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:49:43 --> Utf8 Class Initialized
INFO - 2018-04-10 19:49:43 --> URI Class Initialized
INFO - 2018-04-10 19:49:43 --> Router Class Initialized
INFO - 2018-04-10 19:49:43 --> Output Class Initialized
INFO - 2018-04-10 19:49:43 --> Security Class Initialized
DEBUG - 2018-04-10 19:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:49:43 --> CSRF cookie sent
INFO - 2018-04-10 19:49:44 --> Input Class Initialized
INFO - 2018-04-10 19:49:44 --> Language Class Initialized
ERROR - 2018-04-10 19:49:44 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 19:50:31 --> Config Class Initialized
INFO - 2018-04-10 19:50:31 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:50:31 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:50:31 --> Utf8 Class Initialized
INFO - 2018-04-10 19:50:31 --> URI Class Initialized
INFO - 2018-04-10 19:50:31 --> Router Class Initialized
INFO - 2018-04-10 19:50:31 --> Output Class Initialized
INFO - 2018-04-10 19:50:31 --> Security Class Initialized
DEBUG - 2018-04-10 19:50:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:50:31 --> CSRF cookie sent
INFO - 2018-04-10 19:50:31 --> Input Class Initialized
INFO - 2018-04-10 19:50:31 --> Language Class Initialized
INFO - 2018-04-10 19:50:31 --> Loader Class Initialized
INFO - 2018-04-10 19:50:31 --> Helper loaded: url_helper
INFO - 2018-04-10 19:50:31 --> Helper loaded: form_helper
INFO - 2018-04-10 19:50:31 --> Helper loaded: language_helper
DEBUG - 2018-04-10 19:50:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 19:50:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 19:50:31 --> User Agent Class Initialized
INFO - 2018-04-10 19:50:31 --> Controller Class Initialized
INFO - 2018-04-10 19:50:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 19:50:31 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 19:50:31 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 19:50:31 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 19:50:31 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 19:50:31 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-10 19:50:31 --> Could not find the language line "req_email"
INFO - 2018-04-10 19:50:31 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-04-10 19:50:31 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 19:50:31 --> Final output sent to browser
DEBUG - 2018-04-10 19:50:31 --> Total execution time: 0.5188
INFO - 2018-04-10 19:50:32 --> Config Class Initialized
INFO - 2018-04-10 19:50:32 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:50:32 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:50:32 --> Utf8 Class Initialized
INFO - 2018-04-10 19:50:32 --> URI Class Initialized
INFO - 2018-04-10 19:50:32 --> Router Class Initialized
INFO - 2018-04-10 19:50:32 --> Output Class Initialized
INFO - 2018-04-10 19:50:32 --> Security Class Initialized
DEBUG - 2018-04-10 19:50:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:50:32 --> CSRF cookie sent
INFO - 2018-04-10 19:50:32 --> Input Class Initialized
INFO - 2018-04-10 19:50:32 --> Language Class Initialized
ERROR - 2018-04-10 19:50:32 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 19:56:37 --> Config Class Initialized
INFO - 2018-04-10 19:56:37 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:56:37 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:56:37 --> Utf8 Class Initialized
INFO - 2018-04-10 19:56:37 --> URI Class Initialized
INFO - 2018-04-10 19:56:37 --> Router Class Initialized
INFO - 2018-04-10 19:56:37 --> Output Class Initialized
INFO - 2018-04-10 19:56:37 --> Security Class Initialized
DEBUG - 2018-04-10 19:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:56:37 --> CSRF cookie sent
INFO - 2018-04-10 19:56:37 --> Input Class Initialized
INFO - 2018-04-10 19:56:37 --> Language Class Initialized
INFO - 2018-04-10 19:56:37 --> Loader Class Initialized
INFO - 2018-04-10 19:56:37 --> Helper loaded: url_helper
INFO - 2018-04-10 19:56:37 --> Helper loaded: form_helper
INFO - 2018-04-10 19:56:37 --> Helper loaded: language_helper
DEBUG - 2018-04-10 19:56:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 19:56:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 19:56:37 --> User Agent Class Initialized
INFO - 2018-04-10 19:56:37 --> Controller Class Initialized
INFO - 2018-04-10 19:56:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 19:56:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-10 19:56:37 --> Pixel_Model class loaded
INFO - 2018-04-10 19:56:38 --> Database Driver Class Initialized
INFO - 2018-04-10 19:56:41 --> Model "RegistrationModel" initialized
DEBUG - 2018-04-10 19:56:41 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 19:56:41 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 19:56:41 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 19:56:41 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-10 19:56:41 --> Could not find the language line "req_email"
INFO - 2018-04-10 19:56:41 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-04-10 19:56:41 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 19:56:41 --> Final output sent to browser
DEBUG - 2018-04-10 19:56:41 --> Total execution time: 3.6369
INFO - 2018-04-10 19:56:41 --> Config Class Initialized
INFO - 2018-04-10 19:56:41 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:56:41 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:56:41 --> Utf8 Class Initialized
INFO - 2018-04-10 19:56:41 --> URI Class Initialized
INFO - 2018-04-10 19:56:41 --> Router Class Initialized
INFO - 2018-04-10 19:56:41 --> Output Class Initialized
INFO - 2018-04-10 19:56:41 --> Security Class Initialized
DEBUG - 2018-04-10 19:56:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:56:41 --> CSRF cookie sent
INFO - 2018-04-10 19:56:41 --> Input Class Initialized
INFO - 2018-04-10 19:56:41 --> Language Class Initialized
ERROR - 2018-04-10 19:56:41 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 19:59:04 --> Config Class Initialized
INFO - 2018-04-10 19:59:04 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:59:04 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:59:04 --> Utf8 Class Initialized
INFO - 2018-04-10 19:59:04 --> URI Class Initialized
INFO - 2018-04-10 19:59:04 --> Router Class Initialized
INFO - 2018-04-10 19:59:04 --> Output Class Initialized
INFO - 2018-04-10 19:59:04 --> Security Class Initialized
DEBUG - 2018-04-10 19:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:59:04 --> CSRF cookie sent
INFO - 2018-04-10 19:59:04 --> Input Class Initialized
INFO - 2018-04-10 19:59:04 --> Language Class Initialized
INFO - 2018-04-10 19:59:04 --> Loader Class Initialized
INFO - 2018-04-10 19:59:04 --> Helper loaded: url_helper
INFO - 2018-04-10 19:59:04 --> Helper loaded: form_helper
INFO - 2018-04-10 19:59:04 --> Helper loaded: language_helper
DEBUG - 2018-04-10 19:59:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 19:59:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 19:59:04 --> User Agent Class Initialized
INFO - 2018-04-10 19:59:04 --> Controller Class Initialized
INFO - 2018-04-10 19:59:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 19:59:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-10 19:59:04 --> Pixel_Model class loaded
INFO - 2018-04-10 19:59:04 --> Database Driver Class Initialized
INFO - 2018-04-10 19:59:07 --> Model "RegistrationModel" initialized
DEBUG - 2018-04-10 19:59:07 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
ERROR - 2018-04-10 19:59:07 --> Severity: Notice --> Use of undefined constant COMPANY_NAME - assumed 'COMPANY_NAME' E:\www\yacopoo\application\libraries\Smart.php 43
INFO - 2018-04-10 19:59:07 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 19:59:07 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 19:59:07 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-10 19:59:07 --> Could not find the language line "req_email"
INFO - 2018-04-10 19:59:07 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-04-10 19:59:07 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 19:59:07 --> Final output sent to browser
DEBUG - 2018-04-10 19:59:07 --> Total execution time: 3.4102
INFO - 2018-04-10 19:59:07 --> Config Class Initialized
INFO - 2018-04-10 19:59:08 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:59:08 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:59:08 --> Utf8 Class Initialized
INFO - 2018-04-10 19:59:08 --> URI Class Initialized
INFO - 2018-04-10 19:59:08 --> Router Class Initialized
INFO - 2018-04-10 19:59:08 --> Output Class Initialized
INFO - 2018-04-10 19:59:08 --> Security Class Initialized
DEBUG - 2018-04-10 19:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:59:08 --> CSRF cookie sent
INFO - 2018-04-10 19:59:08 --> Input Class Initialized
INFO - 2018-04-10 19:59:08 --> Language Class Initialized
ERROR - 2018-04-10 19:59:08 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 19:59:53 --> Config Class Initialized
INFO - 2018-04-10 19:59:53 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:59:53 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:59:53 --> Utf8 Class Initialized
INFO - 2018-04-10 19:59:53 --> URI Class Initialized
INFO - 2018-04-10 19:59:53 --> Router Class Initialized
INFO - 2018-04-10 19:59:53 --> Output Class Initialized
INFO - 2018-04-10 19:59:53 --> Security Class Initialized
DEBUG - 2018-04-10 19:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:59:53 --> CSRF cookie sent
INFO - 2018-04-10 19:59:53 --> Input Class Initialized
INFO - 2018-04-10 19:59:53 --> Language Class Initialized
INFO - 2018-04-10 19:59:53 --> Loader Class Initialized
INFO - 2018-04-10 19:59:53 --> Helper loaded: url_helper
INFO - 2018-04-10 19:59:53 --> Helper loaded: form_helper
INFO - 2018-04-10 19:59:53 --> Helper loaded: language_helper
DEBUG - 2018-04-10 19:59:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 19:59:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 19:59:53 --> User Agent Class Initialized
INFO - 2018-04-10 19:59:53 --> Controller Class Initialized
INFO - 2018-04-10 19:59:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 19:59:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-10 19:59:53 --> Pixel_Model class loaded
INFO - 2018-04-10 19:59:53 --> Database Driver Class Initialized
INFO - 2018-04-10 19:59:56 --> Model "RegistrationModel" initialized
DEBUG - 2018-04-10 19:59:56 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 19:59:56 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 19:59:56 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 19:59:56 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-10 19:59:56 --> Could not find the language line "req_email"
INFO - 2018-04-10 19:59:56 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-04-10 19:59:56 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 19:59:57 --> Final output sent to browser
DEBUG - 2018-04-10 19:59:57 --> Total execution time: 3.4561
INFO - 2018-04-10 19:59:57 --> Config Class Initialized
INFO - 2018-04-10 19:59:57 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:59:57 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:59:57 --> Utf8 Class Initialized
INFO - 2018-04-10 19:59:57 --> URI Class Initialized
INFO - 2018-04-10 19:59:57 --> Router Class Initialized
INFO - 2018-04-10 19:59:57 --> Output Class Initialized
INFO - 2018-04-10 19:59:57 --> Security Class Initialized
DEBUG - 2018-04-10 19:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:59:57 --> CSRF cookie sent
INFO - 2018-04-10 19:59:57 --> Input Class Initialized
INFO - 2018-04-10 19:59:57 --> Language Class Initialized
ERROR - 2018-04-10 19:59:57 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 20:06:12 --> Config Class Initialized
INFO - 2018-04-10 20:06:12 --> Hooks Class Initialized
DEBUG - 2018-04-10 20:06:12 --> UTF-8 Support Enabled
INFO - 2018-04-10 20:06:12 --> Utf8 Class Initialized
INFO - 2018-04-10 20:06:12 --> URI Class Initialized
INFO - 2018-04-10 20:06:12 --> Router Class Initialized
INFO - 2018-04-10 20:06:12 --> Output Class Initialized
INFO - 2018-04-10 20:06:12 --> Security Class Initialized
DEBUG - 2018-04-10 20:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 20:06:12 --> CSRF cookie sent
INFO - 2018-04-10 20:06:12 --> Input Class Initialized
INFO - 2018-04-10 20:06:12 --> Language Class Initialized
INFO - 2018-04-10 20:06:12 --> Loader Class Initialized
INFO - 2018-04-10 20:06:12 --> Helper loaded: url_helper
INFO - 2018-04-10 20:06:12 --> Helper loaded: form_helper
INFO - 2018-04-10 20:06:12 --> Helper loaded: language_helper
DEBUG - 2018-04-10 20:06:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 20:06:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 20:06:12 --> User Agent Class Initialized
INFO - 2018-04-10 20:06:12 --> Controller Class Initialized
INFO - 2018-04-10 20:06:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 20:06:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-10 20:06:12 --> Pixel_Model class loaded
INFO - 2018-04-10 20:06:12 --> Database Driver Class Initialized
INFO - 2018-04-10 20:06:15 --> Model "RegistrationModel" initialized
DEBUG - 2018-04-10 20:06:15 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 20:06:15 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 20:06:15 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 20:06:15 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-10 20:06:15 --> Could not find the language line "req_email"
INFO - 2018-04-10 20:06:15 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-04-10 20:06:15 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 20:06:15 --> Final output sent to browser
DEBUG - 2018-04-10 20:06:15 --> Total execution time: 3.3902
INFO - 2018-04-10 20:06:16 --> Config Class Initialized
INFO - 2018-04-10 20:06:16 --> Hooks Class Initialized
DEBUG - 2018-04-10 20:06:16 --> UTF-8 Support Enabled
INFO - 2018-04-10 20:06:16 --> Utf8 Class Initialized
INFO - 2018-04-10 20:06:16 --> URI Class Initialized
INFO - 2018-04-10 20:06:16 --> Router Class Initialized
INFO - 2018-04-10 20:06:16 --> Output Class Initialized
INFO - 2018-04-10 20:06:16 --> Security Class Initialized
DEBUG - 2018-04-10 20:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 20:06:16 --> CSRF cookie sent
INFO - 2018-04-10 20:06:16 --> Input Class Initialized
INFO - 2018-04-10 20:06:16 --> Language Class Initialized
ERROR - 2018-04-10 20:06:16 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 20:07:15 --> Config Class Initialized
INFO - 2018-04-10 20:07:15 --> Hooks Class Initialized
DEBUG - 2018-04-10 20:07:15 --> UTF-8 Support Enabled
INFO - 2018-04-10 20:07:15 --> Utf8 Class Initialized
INFO - 2018-04-10 20:07:15 --> URI Class Initialized
INFO - 2018-04-10 20:07:15 --> Router Class Initialized
INFO - 2018-04-10 20:07:15 --> Output Class Initialized
INFO - 2018-04-10 20:07:15 --> Security Class Initialized
DEBUG - 2018-04-10 20:07:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 20:07:15 --> CSRF cookie sent
INFO - 2018-04-10 20:07:15 --> CSRF token verified
INFO - 2018-04-10 20:07:16 --> Input Class Initialized
INFO - 2018-04-10 20:07:16 --> Language Class Initialized
INFO - 2018-04-10 20:07:16 --> Loader Class Initialized
INFO - 2018-04-10 20:07:16 --> Helper loaded: url_helper
INFO - 2018-04-10 20:07:16 --> Helper loaded: form_helper
INFO - 2018-04-10 20:07:16 --> Helper loaded: language_helper
DEBUG - 2018-04-10 20:07:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 20:07:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 20:07:16 --> User Agent Class Initialized
INFO - 2018-04-10 20:07:16 --> Controller Class Initialized
INFO - 2018-04-10 20:07:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 20:07:16 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 20:07:16 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 20:07:16 --> Config Class Initialized
INFO - 2018-04-10 20:07:16 --> Hooks Class Initialized
DEBUG - 2018-04-10 20:07:16 --> UTF-8 Support Enabled
INFO - 2018-04-10 20:07:16 --> Utf8 Class Initialized
INFO - 2018-04-10 20:07:16 --> URI Class Initialized
INFO - 2018-04-10 20:07:16 --> Router Class Initialized
INFO - 2018-04-10 20:07:16 --> Output Class Initialized
INFO - 2018-04-10 20:07:16 --> Security Class Initialized
DEBUG - 2018-04-10 20:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 20:07:16 --> CSRF cookie sent
INFO - 2018-04-10 20:07:16 --> Input Class Initialized
INFO - 2018-04-10 20:07:16 --> Language Class Initialized
INFO - 2018-04-10 20:07:16 --> Loader Class Initialized
INFO - 2018-04-10 20:07:16 --> Helper loaded: url_helper
INFO - 2018-04-10 20:07:16 --> Helper loaded: form_helper
INFO - 2018-04-10 20:07:16 --> Helper loaded: language_helper
DEBUG - 2018-04-10 20:07:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 20:07:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 20:07:16 --> User Agent Class Initialized
INFO - 2018-04-10 20:07:16 --> Controller Class Initialized
INFO - 2018-04-10 20:07:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 20:07:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-10 20:07:16 --> Pixel_Model class loaded
INFO - 2018-04-10 20:07:16 --> Database Driver Class Initialized
INFO - 2018-04-10 20:07:16 --> Model "RegistrationModel" initialized
DEBUG - 2018-04-10 20:07:16 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 20:07:16 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 20:07:16 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 20:07:16 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-10 20:07:16 --> Could not find the language line "req_email"
INFO - 2018-04-10 20:07:16 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-04-10 20:07:16 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 20:07:16 --> Final output sent to browser
DEBUG - 2018-04-10 20:07:16 --> Total execution time: 0.3906
INFO - 2018-04-10 20:07:17 --> Config Class Initialized
INFO - 2018-04-10 20:07:17 --> Hooks Class Initialized
DEBUG - 2018-04-10 20:07:17 --> UTF-8 Support Enabled
INFO - 2018-04-10 20:07:17 --> Utf8 Class Initialized
INFO - 2018-04-10 20:07:17 --> URI Class Initialized
INFO - 2018-04-10 20:07:17 --> Router Class Initialized
INFO - 2018-04-10 20:07:17 --> Output Class Initialized
INFO - 2018-04-10 20:07:17 --> Security Class Initialized
DEBUG - 2018-04-10 20:07:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 20:07:17 --> CSRF cookie sent
INFO - 2018-04-10 20:07:17 --> Input Class Initialized
INFO - 2018-04-10 20:07:17 --> Language Class Initialized
ERROR - 2018-04-10 20:07:17 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 20:07:56 --> Config Class Initialized
INFO - 2018-04-10 20:07:56 --> Hooks Class Initialized
DEBUG - 2018-04-10 20:07:56 --> UTF-8 Support Enabled
INFO - 2018-04-10 20:07:56 --> Utf8 Class Initialized
INFO - 2018-04-10 20:07:56 --> URI Class Initialized
INFO - 2018-04-10 20:07:56 --> Router Class Initialized
INFO - 2018-04-10 20:07:56 --> Output Class Initialized
INFO - 2018-04-10 20:07:56 --> Security Class Initialized
DEBUG - 2018-04-10 20:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 20:07:57 --> CSRF cookie sent
INFO - 2018-04-10 20:07:57 --> CSRF token verified
INFO - 2018-04-10 20:07:57 --> Input Class Initialized
INFO - 2018-04-10 20:07:57 --> Language Class Initialized
INFO - 2018-04-10 20:07:57 --> Loader Class Initialized
INFO - 2018-04-10 20:07:57 --> Helper loaded: url_helper
INFO - 2018-04-10 20:07:57 --> Helper loaded: form_helper
INFO - 2018-04-10 20:07:57 --> Helper loaded: language_helper
DEBUG - 2018-04-10 20:07:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 20:07:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 20:07:57 --> User Agent Class Initialized
INFO - 2018-04-10 20:07:57 --> Controller Class Initialized
INFO - 2018-04-10 20:07:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 20:07:57 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 20:07:57 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 20:07:57 --> Config Class Initialized
INFO - 2018-04-10 20:07:57 --> Hooks Class Initialized
DEBUG - 2018-04-10 20:07:57 --> UTF-8 Support Enabled
INFO - 2018-04-10 20:07:57 --> Utf8 Class Initialized
INFO - 2018-04-10 20:07:57 --> URI Class Initialized
INFO - 2018-04-10 20:07:57 --> Router Class Initialized
INFO - 2018-04-10 20:07:57 --> Output Class Initialized
INFO - 2018-04-10 20:07:57 --> Security Class Initialized
DEBUG - 2018-04-10 20:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 20:07:57 --> CSRF cookie sent
INFO - 2018-04-10 20:07:57 --> Input Class Initialized
INFO - 2018-04-10 20:07:57 --> Language Class Initialized
INFO - 2018-04-10 20:07:57 --> Loader Class Initialized
INFO - 2018-04-10 20:07:57 --> Helper loaded: url_helper
INFO - 2018-04-10 20:07:57 --> Helper loaded: form_helper
INFO - 2018-04-10 20:07:57 --> Helper loaded: language_helper
DEBUG - 2018-04-10 20:07:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 20:07:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 20:07:57 --> User Agent Class Initialized
INFO - 2018-04-10 20:07:57 --> Controller Class Initialized
INFO - 2018-04-10 20:07:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 20:07:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-10 20:07:57 --> Pixel_Model class loaded
INFO - 2018-04-10 20:07:57 --> Database Driver Class Initialized
INFO - 2018-04-10 20:08:00 --> Model "RegistrationModel" initialized
DEBUG - 2018-04-10 20:08:00 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 20:08:00 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 20:08:00 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 20:08:00 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-10 20:08:00 --> Could not find the language line "req_email"
INFO - 2018-04-10 20:08:00 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-04-10 20:08:00 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 20:08:00 --> Final output sent to browser
DEBUG - 2018-04-10 20:08:00 --> Total execution time: 3.4079
INFO - 2018-04-10 20:08:01 --> Config Class Initialized
INFO - 2018-04-10 20:08:01 --> Hooks Class Initialized
DEBUG - 2018-04-10 20:08:01 --> UTF-8 Support Enabled
INFO - 2018-04-10 20:08:01 --> Utf8 Class Initialized
INFO - 2018-04-10 20:08:01 --> URI Class Initialized
INFO - 2018-04-10 20:08:01 --> Router Class Initialized
INFO - 2018-04-10 20:08:01 --> Output Class Initialized
INFO - 2018-04-10 20:08:01 --> Security Class Initialized
DEBUG - 2018-04-10 20:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 20:08:01 --> CSRF cookie sent
INFO - 2018-04-10 20:08:01 --> Input Class Initialized
INFO - 2018-04-10 20:08:01 --> Language Class Initialized
ERROR - 2018-04-10 20:08:01 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 20:09:45 --> Config Class Initialized
INFO - 2018-04-10 20:09:45 --> Hooks Class Initialized
DEBUG - 2018-04-10 20:09:45 --> UTF-8 Support Enabled
INFO - 2018-04-10 20:09:45 --> Utf8 Class Initialized
INFO - 2018-04-10 20:09:45 --> URI Class Initialized
INFO - 2018-04-10 20:09:45 --> Router Class Initialized
INFO - 2018-04-10 20:09:45 --> Output Class Initialized
INFO - 2018-04-10 20:09:45 --> Security Class Initialized
DEBUG - 2018-04-10 20:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 20:09:45 --> CSRF cookie sent
INFO - 2018-04-10 20:09:45 --> CSRF token verified
INFO - 2018-04-10 20:09:45 --> Input Class Initialized
INFO - 2018-04-10 20:09:45 --> Language Class Initialized
INFO - 2018-04-10 20:09:45 --> Loader Class Initialized
INFO - 2018-04-10 20:09:45 --> Helper loaded: url_helper
INFO - 2018-04-10 20:09:45 --> Helper loaded: form_helper
INFO - 2018-04-10 20:09:45 --> Helper loaded: language_helper
DEBUG - 2018-04-10 20:09:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 20:09:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 20:09:45 --> User Agent Class Initialized
INFO - 2018-04-10 20:09:45 --> Controller Class Initialized
INFO - 2018-04-10 20:09:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 20:09:45 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 20:09:45 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 20:09:45 --> Config Class Initialized
INFO - 2018-04-10 20:09:45 --> Hooks Class Initialized
DEBUG - 2018-04-10 20:09:45 --> UTF-8 Support Enabled
INFO - 2018-04-10 20:09:45 --> Utf8 Class Initialized
INFO - 2018-04-10 20:09:45 --> URI Class Initialized
INFO - 2018-04-10 20:09:45 --> Router Class Initialized
INFO - 2018-04-10 20:09:45 --> Output Class Initialized
INFO - 2018-04-10 20:09:45 --> Security Class Initialized
DEBUG - 2018-04-10 20:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 20:09:45 --> CSRF cookie sent
INFO - 2018-04-10 20:09:45 --> Input Class Initialized
INFO - 2018-04-10 20:09:45 --> Language Class Initialized
INFO - 2018-04-10 20:09:45 --> Loader Class Initialized
INFO - 2018-04-10 20:09:45 --> Helper loaded: url_helper
INFO - 2018-04-10 20:09:45 --> Helper loaded: form_helper
INFO - 2018-04-10 20:09:45 --> Helper loaded: language_helper
DEBUG - 2018-04-10 20:09:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 20:09:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 20:09:45 --> User Agent Class Initialized
INFO - 2018-04-10 20:09:46 --> Controller Class Initialized
INFO - 2018-04-10 20:09:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 20:09:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-10 20:09:46 --> Pixel_Model class loaded
INFO - 2018-04-10 20:09:46 --> Database Driver Class Initialized
INFO - 2018-04-10 20:09:49 --> Model "RegistrationModel" initialized
DEBUG - 2018-04-10 20:09:49 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 20:09:49 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 20:09:49 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 20:09:49 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-10 20:09:49 --> File loaded: E:\www\yacopoo\application\views\shared/_soft_error.php
ERROR - 2018-04-10 20:09:49 --> Could not find the language line "req_email"
INFO - 2018-04-10 20:09:49 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-04-10 20:09:49 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 20:09:49 --> Final output sent to browser
DEBUG - 2018-04-10 20:09:49 --> Total execution time: 3.5141
INFO - 2018-04-10 20:09:49 --> Config Class Initialized
INFO - 2018-04-10 20:09:49 --> Hooks Class Initialized
DEBUG - 2018-04-10 20:09:49 --> UTF-8 Support Enabled
INFO - 2018-04-10 20:09:49 --> Utf8 Class Initialized
INFO - 2018-04-10 20:09:49 --> URI Class Initialized
INFO - 2018-04-10 20:09:49 --> Router Class Initialized
INFO - 2018-04-10 20:09:49 --> Output Class Initialized
INFO - 2018-04-10 20:09:49 --> Security Class Initialized
DEBUG - 2018-04-10 20:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 20:09:49 --> CSRF cookie sent
INFO - 2018-04-10 20:09:49 --> Input Class Initialized
INFO - 2018-04-10 20:09:49 --> Language Class Initialized
ERROR - 2018-04-10 20:09:49 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 20:10:33 --> Config Class Initialized
INFO - 2018-04-10 20:10:33 --> Hooks Class Initialized
DEBUG - 2018-04-10 20:10:33 --> UTF-8 Support Enabled
INFO - 2018-04-10 20:10:33 --> Utf8 Class Initialized
INFO - 2018-04-10 20:10:33 --> URI Class Initialized
INFO - 2018-04-10 20:10:33 --> Router Class Initialized
INFO - 2018-04-10 20:10:33 --> Output Class Initialized
INFO - 2018-04-10 20:10:33 --> Security Class Initialized
DEBUG - 2018-04-10 20:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 20:10:33 --> CSRF cookie sent
INFO - 2018-04-10 20:10:33 --> Input Class Initialized
INFO - 2018-04-10 20:10:33 --> Language Class Initialized
INFO - 2018-04-10 20:10:33 --> Loader Class Initialized
INFO - 2018-04-10 20:10:33 --> Helper loaded: url_helper
INFO - 2018-04-10 20:10:33 --> Helper loaded: form_helper
INFO - 2018-04-10 20:10:33 --> Helper loaded: language_helper
DEBUG - 2018-04-10 20:10:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 20:10:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 20:10:33 --> User Agent Class Initialized
INFO - 2018-04-10 20:10:33 --> Controller Class Initialized
INFO - 2018-04-10 20:10:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 20:10:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-10 20:10:33 --> Pixel_Model class loaded
INFO - 2018-04-10 20:10:33 --> Database Driver Class Initialized
INFO - 2018-04-10 20:10:34 --> Model "RegistrationModel" initialized
DEBUG - 2018-04-10 20:10:34 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 20:10:34 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 20:10:34 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 20:10:34 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-10 20:10:34 --> Could not find the language line "req_email"
INFO - 2018-04-10 20:10:34 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-04-10 20:10:34 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 20:10:34 --> Final output sent to browser
DEBUG - 2018-04-10 20:10:34 --> Total execution time: 0.4010
INFO - 2018-04-10 20:10:34 --> Config Class Initialized
INFO - 2018-04-10 20:10:34 --> Hooks Class Initialized
DEBUG - 2018-04-10 20:10:34 --> UTF-8 Support Enabled
INFO - 2018-04-10 20:10:34 --> Utf8 Class Initialized
INFO - 2018-04-10 20:10:34 --> URI Class Initialized
INFO - 2018-04-10 20:10:34 --> Router Class Initialized
INFO - 2018-04-10 20:10:34 --> Output Class Initialized
INFO - 2018-04-10 20:10:34 --> Security Class Initialized
DEBUG - 2018-04-10 20:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 20:10:34 --> CSRF cookie sent
INFO - 2018-04-10 20:10:34 --> Input Class Initialized
INFO - 2018-04-10 20:10:34 --> Language Class Initialized
ERROR - 2018-04-10 20:10:34 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 20:10:52 --> Config Class Initialized
INFO - 2018-04-10 20:10:52 --> Hooks Class Initialized
DEBUG - 2018-04-10 20:10:52 --> UTF-8 Support Enabled
INFO - 2018-04-10 20:10:52 --> Utf8 Class Initialized
INFO - 2018-04-10 20:10:52 --> URI Class Initialized
INFO - 2018-04-10 20:10:52 --> Router Class Initialized
INFO - 2018-04-10 20:10:52 --> Output Class Initialized
INFO - 2018-04-10 20:10:52 --> Security Class Initialized
DEBUG - 2018-04-10 20:10:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 20:10:52 --> CSRF cookie sent
INFO - 2018-04-10 20:10:52 --> CSRF token verified
INFO - 2018-04-10 20:10:52 --> Input Class Initialized
INFO - 2018-04-10 20:10:52 --> Language Class Initialized
INFO - 2018-04-10 20:10:52 --> Loader Class Initialized
INFO - 2018-04-10 20:10:52 --> Helper loaded: url_helper
INFO - 2018-04-10 20:10:52 --> Helper loaded: form_helper
INFO - 2018-04-10 20:10:52 --> Helper loaded: language_helper
DEBUG - 2018-04-10 20:10:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 20:10:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 20:10:53 --> User Agent Class Initialized
INFO - 2018-04-10 20:10:53 --> Controller Class Initialized
INFO - 2018-04-10 20:10:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 20:10:53 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 20:10:53 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 20:10:53 --> Config Class Initialized
INFO - 2018-04-10 20:10:53 --> Hooks Class Initialized
DEBUG - 2018-04-10 20:10:53 --> UTF-8 Support Enabled
INFO - 2018-04-10 20:10:53 --> Utf8 Class Initialized
INFO - 2018-04-10 20:10:53 --> URI Class Initialized
INFO - 2018-04-10 20:10:53 --> Router Class Initialized
INFO - 2018-04-10 20:10:53 --> Output Class Initialized
INFO - 2018-04-10 20:10:53 --> Security Class Initialized
DEBUG - 2018-04-10 20:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 20:10:53 --> CSRF cookie sent
INFO - 2018-04-10 20:10:53 --> Input Class Initialized
INFO - 2018-04-10 20:10:53 --> Language Class Initialized
INFO - 2018-04-10 20:10:53 --> Loader Class Initialized
INFO - 2018-04-10 20:10:53 --> Helper loaded: url_helper
INFO - 2018-04-10 20:10:53 --> Helper loaded: form_helper
INFO - 2018-04-10 20:10:53 --> Helper loaded: language_helper
DEBUG - 2018-04-10 20:10:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 20:10:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 20:10:53 --> User Agent Class Initialized
INFO - 2018-04-10 20:10:53 --> Controller Class Initialized
INFO - 2018-04-10 20:10:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 20:10:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-10 20:10:53 --> Pixel_Model class loaded
INFO - 2018-04-10 20:10:53 --> Database Driver Class Initialized
INFO - 2018-04-10 20:10:53 --> Model "RegistrationModel" initialized
DEBUG - 2018-04-10 20:10:53 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 20:10:53 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 20:10:53 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 20:10:53 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-10 20:10:53 --> File loaded: E:\www\yacopoo\application\views\shared/_soft_error.php
ERROR - 2018-04-10 20:10:53 --> Could not find the language line "req_email"
INFO - 2018-04-10 20:10:53 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-04-10 20:10:53 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 20:10:53 --> Final output sent to browser
DEBUG - 2018-04-10 20:10:53 --> Total execution time: 0.4108
INFO - 2018-04-10 20:10:53 --> Config Class Initialized
INFO - 2018-04-10 20:10:53 --> Hooks Class Initialized
DEBUG - 2018-04-10 20:10:53 --> UTF-8 Support Enabled
INFO - 2018-04-10 20:10:53 --> Utf8 Class Initialized
INFO - 2018-04-10 20:10:53 --> URI Class Initialized
INFO - 2018-04-10 20:10:53 --> Router Class Initialized
INFO - 2018-04-10 20:10:53 --> Output Class Initialized
INFO - 2018-04-10 20:10:54 --> Security Class Initialized
DEBUG - 2018-04-10 20:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 20:10:54 --> CSRF cookie sent
INFO - 2018-04-10 20:10:54 --> Input Class Initialized
INFO - 2018-04-10 20:10:54 --> Language Class Initialized
ERROR - 2018-04-10 20:10:54 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 20:11:10 --> Config Class Initialized
INFO - 2018-04-10 20:11:10 --> Hooks Class Initialized
DEBUG - 2018-04-10 20:11:10 --> UTF-8 Support Enabled
INFO - 2018-04-10 20:11:10 --> Utf8 Class Initialized
INFO - 2018-04-10 20:11:10 --> URI Class Initialized
INFO - 2018-04-10 20:11:10 --> Router Class Initialized
INFO - 2018-04-10 20:11:10 --> Output Class Initialized
INFO - 2018-04-10 20:11:10 --> Security Class Initialized
DEBUG - 2018-04-10 20:11:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 20:11:10 --> CSRF cookie sent
INFO - 2018-04-10 20:11:10 --> CSRF token verified
INFO - 2018-04-10 20:11:10 --> Input Class Initialized
INFO - 2018-04-10 20:11:10 --> Language Class Initialized
INFO - 2018-04-10 20:11:10 --> Loader Class Initialized
INFO - 2018-04-10 20:11:10 --> Helper loaded: url_helper
INFO - 2018-04-10 20:11:10 --> Helper loaded: form_helper
INFO - 2018-04-10 20:11:10 --> Helper loaded: language_helper
DEBUG - 2018-04-10 20:11:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 20:11:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 20:11:10 --> User Agent Class Initialized
INFO - 2018-04-10 20:11:11 --> Controller Class Initialized
INFO - 2018-04-10 20:11:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 20:11:11 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 20:11:11 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
ERROR - 2018-04-10 20:11:11 --> Severity: Notice --> Undefined property: RegistrationController::$form_validation E:\www\yacopoo\application\controllers\RegistrationController.php 81
ERROR - 2018-04-10 20:11:11 --> Severity: Error --> Call to a member function set_rules() on null E:\www\yacopoo\application\controllers\RegistrationController.php 81
INFO - 2018-04-10 20:12:01 --> Config Class Initialized
INFO - 2018-04-10 20:12:01 --> Hooks Class Initialized
DEBUG - 2018-04-10 20:12:01 --> UTF-8 Support Enabled
INFO - 2018-04-10 20:12:01 --> Utf8 Class Initialized
INFO - 2018-04-10 20:12:01 --> URI Class Initialized
INFO - 2018-04-10 20:12:01 --> Router Class Initialized
INFO - 2018-04-10 20:12:01 --> Output Class Initialized
INFO - 2018-04-10 20:12:01 --> Security Class Initialized
DEBUG - 2018-04-10 20:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 20:12:01 --> CSRF cookie sent
INFO - 2018-04-10 20:12:01 --> CSRF token verified
INFO - 2018-04-10 20:12:01 --> Input Class Initialized
INFO - 2018-04-10 20:12:01 --> Language Class Initialized
INFO - 2018-04-10 20:12:01 --> Loader Class Initialized
INFO - 2018-04-10 20:12:01 --> Helper loaded: url_helper
INFO - 2018-04-10 20:12:01 --> Helper loaded: form_helper
INFO - 2018-04-10 20:12:01 --> Helper loaded: language_helper
DEBUG - 2018-04-10 20:12:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 20:12:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 20:12:01 --> User Agent Class Initialized
INFO - 2018-04-10 20:12:01 --> Controller Class Initialized
INFO - 2018-04-10 20:12:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 20:12:01 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 20:12:01 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 20:12:02 --> Form Validation Class Initialized
INFO - 2018-04-10 20:12:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-10 20:12:02 --> Pixel_Model class loaded
INFO - 2018-04-10 20:12:02 --> Database Driver Class Initialized
INFO - 2018-04-10 20:12:05 --> Model "RegistrationModel" initialized
INFO - 2018-04-10 20:12:05 --> Database Driver Class Initialized
INFO - 2018-04-10 20:12:05 --> Model "RegistrationModel" initialized
DEBUG - 2018-04-10 20:12:05 --> Recaptcha class already loaded. Second attempt ignored.
INFO - 2018-04-10 20:12:05 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 20:12:05 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 20:12:05 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-10 20:12:05 --> File loaded: E:\www\yacopoo\application\views\shared/_errors.php
ERROR - 2018-04-10 20:12:05 --> Could not find the language line "req_email"
INFO - 2018-04-10 20:12:05 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-04-10 20:12:05 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 20:12:05 --> Final output sent to browser
DEBUG - 2018-04-10 20:12:05 --> Total execution time: 3.8100
INFO - 2018-04-10 20:12:05 --> Config Class Initialized
INFO - 2018-04-10 20:12:05 --> Hooks Class Initialized
DEBUG - 2018-04-10 20:12:05 --> UTF-8 Support Enabled
INFO - 2018-04-10 20:12:05 --> Utf8 Class Initialized
INFO - 2018-04-10 20:12:05 --> URI Class Initialized
INFO - 2018-04-10 20:12:05 --> Router Class Initialized
INFO - 2018-04-10 20:12:05 --> Output Class Initialized
INFO - 2018-04-10 20:12:05 --> Security Class Initialized
DEBUG - 2018-04-10 20:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 20:12:05 --> CSRF cookie sent
INFO - 2018-04-10 20:12:05 --> Input Class Initialized
INFO - 2018-04-10 20:12:05 --> Language Class Initialized
ERROR - 2018-04-10 20:12:05 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 20:12:23 --> Config Class Initialized
INFO - 2018-04-10 20:12:23 --> Hooks Class Initialized
DEBUG - 2018-04-10 20:12:23 --> UTF-8 Support Enabled
INFO - 2018-04-10 20:12:23 --> Utf8 Class Initialized
INFO - 2018-04-10 20:12:23 --> URI Class Initialized
INFO - 2018-04-10 20:12:23 --> Router Class Initialized
INFO - 2018-04-10 20:12:23 --> Output Class Initialized
INFO - 2018-04-10 20:12:23 --> Security Class Initialized
DEBUG - 2018-04-10 20:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 20:12:23 --> CSRF cookie sent
INFO - 2018-04-10 20:12:24 --> CSRF token verified
INFO - 2018-04-10 20:12:24 --> Input Class Initialized
INFO - 2018-04-10 20:12:24 --> Language Class Initialized
INFO - 2018-04-10 20:12:24 --> Loader Class Initialized
INFO - 2018-04-10 20:12:24 --> Helper loaded: url_helper
INFO - 2018-04-10 20:12:24 --> Helper loaded: form_helper
INFO - 2018-04-10 20:12:24 --> Helper loaded: language_helper
DEBUG - 2018-04-10 20:12:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 20:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 20:12:24 --> User Agent Class Initialized
INFO - 2018-04-10 20:12:24 --> Controller Class Initialized
INFO - 2018-04-10 20:12:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 20:12:24 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 20:12:24 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 20:12:24 --> Form Validation Class Initialized
INFO - 2018-04-10 20:12:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-10 20:12:24 --> Pixel_Model class loaded
INFO - 2018-04-10 20:12:24 --> Database Driver Class Initialized
INFO - 2018-04-10 20:12:24 --> Model "RegistrationModel" initialized
INFO - 2018-04-10 20:12:24 --> Helper loaded: string_helper
ERROR - 2018-04-10 20:12:24 --> Query error: Table 'yacopo.activities' doesn't exist - Invalid query: SELECT count(id) as num
FROM `activities`
WHERE `session_id` = 'll5tecul3lmra37v57n0q5n4ubr1c0t8' and `module` = 'REGISTER' and TIMESTAMPDIFF(MINUTE,created_on,NOW()) <= 5
INFO - 2018-04-10 20:12:24 --> Language file loaded: language/english/db_lang.php
INFO - 2018-04-10 20:13:23 --> Config Class Initialized
INFO - 2018-04-10 20:13:23 --> Hooks Class Initialized
DEBUG - 2018-04-10 20:13:23 --> UTF-8 Support Enabled
INFO - 2018-04-10 20:13:23 --> Utf8 Class Initialized
INFO - 2018-04-10 20:13:23 --> URI Class Initialized
INFO - 2018-04-10 20:13:23 --> Router Class Initialized
INFO - 2018-04-10 20:13:23 --> Output Class Initialized
INFO - 2018-04-10 20:13:23 --> Security Class Initialized
DEBUG - 2018-04-10 20:13:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 20:13:23 --> CSRF cookie sent
INFO - 2018-04-10 20:13:23 --> CSRF token verified
INFO - 2018-04-10 20:13:23 --> Input Class Initialized
INFO - 2018-04-10 20:13:23 --> Language Class Initialized
INFO - 2018-04-10 20:13:23 --> Loader Class Initialized
INFO - 2018-04-10 20:13:23 --> Helper loaded: url_helper
INFO - 2018-04-10 20:13:23 --> Helper loaded: form_helper
INFO - 2018-04-10 20:13:24 --> Helper loaded: language_helper
DEBUG - 2018-04-10 20:13:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 20:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 20:13:24 --> User Agent Class Initialized
INFO - 2018-04-10 20:13:24 --> Controller Class Initialized
INFO - 2018-04-10 20:13:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 20:13:24 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 20:13:24 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 20:13:24 --> Form Validation Class Initialized
INFO - 2018-04-10 20:13:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-10 20:13:24 --> Pixel_Model class loaded
INFO - 2018-04-10 20:13:24 --> Database Driver Class Initialized
INFO - 2018-04-10 20:13:24 --> Model "RegistrationModel" initialized
INFO - 2018-04-10 20:13:24 --> Helper loaded: string_helper
ERROR - 2018-04-10 20:13:24 --> Severity: Error --> Access to undeclared static property: Constants::$AGENT E:\www\yacopoo\application\models\RegistrationModel.php 49
INFO - 2018-04-10 20:14:46 --> Config Class Initialized
INFO - 2018-04-10 20:14:46 --> Hooks Class Initialized
DEBUG - 2018-04-10 20:14:46 --> UTF-8 Support Enabled
INFO - 2018-04-10 20:14:46 --> Utf8 Class Initialized
INFO - 2018-04-10 20:14:46 --> URI Class Initialized
INFO - 2018-04-10 20:14:46 --> Router Class Initialized
INFO - 2018-04-10 20:14:46 --> Output Class Initialized
INFO - 2018-04-10 20:14:46 --> Security Class Initialized
DEBUG - 2018-04-10 20:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 20:14:46 --> CSRF cookie sent
INFO - 2018-04-10 20:14:46 --> CSRF token verified
INFO - 2018-04-10 20:14:46 --> Input Class Initialized
INFO - 2018-04-10 20:14:46 --> Language Class Initialized
INFO - 2018-04-10 20:14:46 --> Loader Class Initialized
INFO - 2018-04-10 20:14:46 --> Helper loaded: url_helper
INFO - 2018-04-10 20:14:46 --> Helper loaded: form_helper
INFO - 2018-04-10 20:14:46 --> Helper loaded: language_helper
DEBUG - 2018-04-10 20:14:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 20:14:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 20:14:46 --> User Agent Class Initialized
INFO - 2018-04-10 20:14:46 --> Controller Class Initialized
INFO - 2018-04-10 20:14:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 20:14:46 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 20:14:46 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 20:14:48 --> Form Validation Class Initialized
INFO - 2018-04-10 20:14:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-10 20:14:48 --> Pixel_Model class loaded
INFO - 2018-04-10 20:14:48 --> Database Driver Class Initialized
INFO - 2018-04-10 20:14:51 --> Model "RegistrationModel" initialized
INFO - 2018-04-10 20:14:51 --> Helper loaded: string_helper
ERROR - 2018-04-10 20:14:51 --> Severity: Notice --> Undefined property: stdClass::$password E:\www\yacopoo\application\models\RegistrationModel.php 28
ERROR - 2018-04-10 20:14:51 --> Could not find the language line "signup_head"
INFO - 2018-04-10 20:14:51 --> Config Class Initialized
INFO - 2018-04-10 20:14:51 --> Hooks Class Initialized
DEBUG - 2018-04-10 20:14:51 --> UTF-8 Support Enabled
INFO - 2018-04-10 20:14:51 --> Utf8 Class Initialized
INFO - 2018-04-10 20:14:51 --> URI Class Initialized
DEBUG - 2018-04-10 20:14:51 --> No URI present. Default controller set.
INFO - 2018-04-10 20:14:51 --> Router Class Initialized
INFO - 2018-04-10 20:14:51 --> Output Class Initialized
INFO - 2018-04-10 20:14:51 --> Security Class Initialized
DEBUG - 2018-04-10 20:14:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 20:14:51 --> CSRF cookie sent
INFO - 2018-04-10 20:14:51 --> Input Class Initialized
INFO - 2018-04-10 20:14:51 --> Language Class Initialized
INFO - 2018-04-10 20:14:51 --> Loader Class Initialized
INFO - 2018-04-10 20:14:51 --> Helper loaded: url_helper
INFO - 2018-04-10 20:14:51 --> Helper loaded: form_helper
INFO - 2018-04-10 20:14:51 --> Helper loaded: language_helper
DEBUG - 2018-04-10 20:14:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 20:14:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 20:14:51 --> User Agent Class Initialized
INFO - 2018-04-10 20:14:51 --> Controller Class Initialized
INFO - 2018-04-10 20:14:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 20:14:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-10 20:14:51 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 20:14:51 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-10 20:14:51 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 20:14:51 --> Final output sent to browser
DEBUG - 2018-04-10 20:14:51 --> Total execution time: 0.3541
INFO - 2018-04-10 20:14:52 --> Config Class Initialized
INFO - 2018-04-10 20:14:52 --> Hooks Class Initialized
DEBUG - 2018-04-10 20:14:52 --> UTF-8 Support Enabled
INFO - 2018-04-10 20:14:52 --> Utf8 Class Initialized
INFO - 2018-04-10 20:14:52 --> URI Class Initialized
INFO - 2018-04-10 20:14:52 --> Router Class Initialized
INFO - 2018-04-10 20:14:52 --> Output Class Initialized
INFO - 2018-04-10 20:14:52 --> Security Class Initialized
DEBUG - 2018-04-10 20:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 20:14:52 --> CSRF cookie sent
INFO - 2018-04-10 20:14:52 --> Input Class Initialized
INFO - 2018-04-10 20:14:52 --> Language Class Initialized
ERROR - 2018-04-10 20:14:52 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 20:14:53 --> Config Class Initialized
INFO - 2018-04-10 20:14:53 --> Hooks Class Initialized
DEBUG - 2018-04-10 20:14:53 --> UTF-8 Support Enabled
INFO - 2018-04-10 20:14:53 --> Utf8 Class Initialized
INFO - 2018-04-10 20:14:53 --> URI Class Initialized
INFO - 2018-04-10 20:14:53 --> Router Class Initialized
INFO - 2018-04-10 20:14:53 --> Output Class Initialized
INFO - 2018-04-10 20:14:54 --> Security Class Initialized
DEBUG - 2018-04-10 20:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 20:14:54 --> CSRF cookie sent
INFO - 2018-04-10 20:14:54 --> Input Class Initialized
INFO - 2018-04-10 20:14:54 --> Language Class Initialized
ERROR - 2018-04-10 20:14:54 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-10 21:03:12 --> Config Class Initialized
INFO - 2018-04-10 21:03:12 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:03:12 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:03:12 --> Utf8 Class Initialized
INFO - 2018-04-10 21:03:12 --> URI Class Initialized
DEBUG - 2018-04-10 21:03:12 --> No URI present. Default controller set.
INFO - 2018-04-10 21:03:12 --> Router Class Initialized
INFO - 2018-04-10 21:03:12 --> Output Class Initialized
INFO - 2018-04-10 21:03:12 --> Security Class Initialized
DEBUG - 2018-04-10 21:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:03:12 --> CSRF cookie sent
INFO - 2018-04-10 21:03:12 --> Input Class Initialized
INFO - 2018-04-10 21:03:12 --> Language Class Initialized
INFO - 2018-04-10 21:03:12 --> Loader Class Initialized
INFO - 2018-04-10 21:03:12 --> Helper loaded: url_helper
INFO - 2018-04-10 21:03:12 --> Helper loaded: form_helper
INFO - 2018-04-10 21:03:12 --> Helper loaded: language_helper
DEBUG - 2018-04-10 21:03:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 21:03:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 21:03:13 --> User Agent Class Initialized
INFO - 2018-04-10 21:03:13 --> Controller Class Initialized
INFO - 2018-04-10 21:03:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 21:03:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-10 21:03:13 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 21:03:13 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-10 21:03:13 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 21:03:13 --> Final output sent to browser
DEBUG - 2018-04-10 21:03:13 --> Total execution time: 0.4108
INFO - 2018-04-10 21:03:13 --> Config Class Initialized
INFO - 2018-04-10 21:03:13 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:03:13 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:03:13 --> Utf8 Class Initialized
INFO - 2018-04-10 21:03:13 --> URI Class Initialized
INFO - 2018-04-10 21:03:13 --> Router Class Initialized
INFO - 2018-04-10 21:03:13 --> Output Class Initialized
INFO - 2018-04-10 21:03:13 --> Security Class Initialized
DEBUG - 2018-04-10 21:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:03:13 --> CSRF cookie sent
INFO - 2018-04-10 21:03:13 --> Input Class Initialized
INFO - 2018-04-10 21:03:13 --> Language Class Initialized
ERROR - 2018-04-10 21:03:13 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 21:03:15 --> Config Class Initialized
INFO - 2018-04-10 21:03:15 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:03:15 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:03:15 --> Utf8 Class Initialized
INFO - 2018-04-10 21:03:15 --> URI Class Initialized
INFO - 2018-04-10 21:03:15 --> Router Class Initialized
INFO - 2018-04-10 21:03:15 --> Output Class Initialized
INFO - 2018-04-10 21:03:15 --> Security Class Initialized
DEBUG - 2018-04-10 21:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:03:15 --> CSRF cookie sent
INFO - 2018-04-10 21:03:15 --> Input Class Initialized
INFO - 2018-04-10 21:03:15 --> Language Class Initialized
ERROR - 2018-04-10 21:03:15 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-10 21:04:02 --> Config Class Initialized
INFO - 2018-04-10 21:04:02 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:04:02 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:04:02 --> Utf8 Class Initialized
INFO - 2018-04-10 21:04:02 --> URI Class Initialized
DEBUG - 2018-04-10 21:04:02 --> No URI present. Default controller set.
INFO - 2018-04-10 21:04:02 --> Router Class Initialized
INFO - 2018-04-10 21:04:02 --> Output Class Initialized
INFO - 2018-04-10 21:04:02 --> Security Class Initialized
DEBUG - 2018-04-10 21:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:04:02 --> CSRF cookie sent
INFO - 2018-04-10 21:04:02 --> Input Class Initialized
INFO - 2018-04-10 21:04:02 --> Language Class Initialized
INFO - 2018-04-10 21:04:02 --> Loader Class Initialized
INFO - 2018-04-10 21:04:02 --> Helper loaded: url_helper
INFO - 2018-04-10 21:04:02 --> Helper loaded: form_helper
INFO - 2018-04-10 21:04:02 --> Helper loaded: language_helper
DEBUG - 2018-04-10 21:04:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 21:04:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 21:04:02 --> User Agent Class Initialized
INFO - 2018-04-10 21:04:02 --> Controller Class Initialized
INFO - 2018-04-10 21:04:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 21:04:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-10 21:04:02 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 21:04:02 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-10 21:04:02 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 21:04:02 --> Final output sent to browser
DEBUG - 2018-04-10 21:04:02 --> Total execution time: 0.3431
INFO - 2018-04-10 21:04:03 --> Config Class Initialized
INFO - 2018-04-10 21:04:03 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:04:03 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:04:03 --> Utf8 Class Initialized
INFO - 2018-04-10 21:04:03 --> URI Class Initialized
INFO - 2018-04-10 21:04:03 --> Router Class Initialized
INFO - 2018-04-10 21:04:03 --> Output Class Initialized
INFO - 2018-04-10 21:04:03 --> Security Class Initialized
DEBUG - 2018-04-10 21:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:04:03 --> CSRF cookie sent
INFO - 2018-04-10 21:04:03 --> Input Class Initialized
INFO - 2018-04-10 21:04:03 --> Language Class Initialized
ERROR - 2018-04-10 21:04:03 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 21:04:04 --> Config Class Initialized
INFO - 2018-04-10 21:04:04 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:04:04 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:04:04 --> Utf8 Class Initialized
INFO - 2018-04-10 21:04:04 --> URI Class Initialized
INFO - 2018-04-10 21:04:04 --> Router Class Initialized
INFO - 2018-04-10 21:04:04 --> Output Class Initialized
INFO - 2018-04-10 21:04:04 --> Security Class Initialized
DEBUG - 2018-04-10 21:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:04:04 --> CSRF cookie sent
INFO - 2018-04-10 21:04:04 --> Input Class Initialized
INFO - 2018-04-10 21:04:04 --> Language Class Initialized
ERROR - 2018-04-10 21:04:04 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-10 21:05:25 --> Config Class Initialized
INFO - 2018-04-10 21:05:25 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:05:25 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:05:25 --> Utf8 Class Initialized
INFO - 2018-04-10 21:05:25 --> URI Class Initialized
DEBUG - 2018-04-10 21:05:25 --> No URI present. Default controller set.
INFO - 2018-04-10 21:05:25 --> Router Class Initialized
INFO - 2018-04-10 21:05:25 --> Output Class Initialized
INFO - 2018-04-10 21:05:25 --> Security Class Initialized
DEBUG - 2018-04-10 21:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:05:25 --> CSRF cookie sent
INFO - 2018-04-10 21:05:25 --> Input Class Initialized
INFO - 2018-04-10 21:05:25 --> Language Class Initialized
INFO - 2018-04-10 21:05:25 --> Loader Class Initialized
INFO - 2018-04-10 21:05:25 --> Helper loaded: url_helper
INFO - 2018-04-10 21:05:25 --> Helper loaded: form_helper
INFO - 2018-04-10 21:05:25 --> Helper loaded: language_helper
DEBUG - 2018-04-10 21:05:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 21:05:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 21:05:25 --> User Agent Class Initialized
INFO - 2018-04-10 21:05:25 --> Controller Class Initialized
INFO - 2018-04-10 21:05:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 21:05:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-10 21:05:25 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 21:05:25 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-10 21:05:25 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 21:05:25 --> Final output sent to browser
DEBUG - 2018-04-10 21:05:25 --> Total execution time: 0.3438
INFO - 2018-04-10 21:05:25 --> Config Class Initialized
INFO - 2018-04-10 21:05:25 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:05:25 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:05:25 --> Utf8 Class Initialized
INFO - 2018-04-10 21:05:25 --> URI Class Initialized
INFO - 2018-04-10 21:05:25 --> Router Class Initialized
INFO - 2018-04-10 21:05:25 --> Output Class Initialized
INFO - 2018-04-10 21:05:25 --> Security Class Initialized
DEBUG - 2018-04-10 21:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:05:25 --> CSRF cookie sent
INFO - 2018-04-10 21:05:25 --> Input Class Initialized
INFO - 2018-04-10 21:05:25 --> Language Class Initialized
ERROR - 2018-04-10 21:05:26 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 21:05:27 --> Config Class Initialized
INFO - 2018-04-10 21:05:27 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:05:27 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:05:27 --> Utf8 Class Initialized
INFO - 2018-04-10 21:05:27 --> URI Class Initialized
INFO - 2018-04-10 21:05:27 --> Router Class Initialized
INFO - 2018-04-10 21:05:27 --> Output Class Initialized
INFO - 2018-04-10 21:05:27 --> Security Class Initialized
DEBUG - 2018-04-10 21:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:05:27 --> CSRF cookie sent
INFO - 2018-04-10 21:05:27 --> Input Class Initialized
INFO - 2018-04-10 21:05:27 --> Language Class Initialized
ERROR - 2018-04-10 21:05:27 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-10 21:05:29 --> Config Class Initialized
INFO - 2018-04-10 21:05:29 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:05:29 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:05:29 --> Utf8 Class Initialized
INFO - 2018-04-10 21:05:29 --> URI Class Initialized
INFO - 2018-04-10 21:05:30 --> Router Class Initialized
INFO - 2018-04-10 21:05:30 --> Output Class Initialized
INFO - 2018-04-10 21:05:30 --> Security Class Initialized
DEBUG - 2018-04-10 21:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:05:30 --> CSRF cookie sent
INFO - 2018-04-10 21:05:30 --> Input Class Initialized
INFO - 2018-04-10 21:05:30 --> Language Class Initialized
INFO - 2018-04-10 21:05:30 --> Loader Class Initialized
INFO - 2018-04-10 21:05:30 --> Helper loaded: url_helper
INFO - 2018-04-10 21:05:30 --> Helper loaded: form_helper
INFO - 2018-04-10 21:05:30 --> Helper loaded: language_helper
DEBUG - 2018-04-10 21:05:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 21:05:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 21:05:30 --> User Agent Class Initialized
INFO - 2018-04-10 21:05:30 --> Controller Class Initialized
INFO - 2018-04-10 21:05:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 21:05:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-10 21:05:30 --> CSRF cookie sent
INFO - 2018-04-10 21:05:30 --> Config Class Initialized
INFO - 2018-04-10 21:05:30 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:05:30 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:05:30 --> Utf8 Class Initialized
INFO - 2018-04-10 21:05:30 --> URI Class Initialized
DEBUG - 2018-04-10 21:05:30 --> No URI present. Default controller set.
INFO - 2018-04-10 21:05:30 --> Router Class Initialized
INFO - 2018-04-10 21:05:30 --> Output Class Initialized
INFO - 2018-04-10 21:05:30 --> Security Class Initialized
DEBUG - 2018-04-10 21:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:05:30 --> CSRF cookie sent
INFO - 2018-04-10 21:05:30 --> Input Class Initialized
INFO - 2018-04-10 21:05:30 --> Language Class Initialized
INFO - 2018-04-10 21:05:30 --> Loader Class Initialized
INFO - 2018-04-10 21:05:30 --> Helper loaded: url_helper
INFO - 2018-04-10 21:05:30 --> Helper loaded: form_helper
INFO - 2018-04-10 21:05:30 --> Helper loaded: language_helper
DEBUG - 2018-04-10 21:05:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 21:05:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 21:05:30 --> User Agent Class Initialized
INFO - 2018-04-10 21:05:30 --> Controller Class Initialized
INFO - 2018-04-10 21:05:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 21:05:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-10 21:05:30 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 21:05:30 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-10 21:05:30 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 21:05:30 --> Final output sent to browser
DEBUG - 2018-04-10 21:05:30 --> Total execution time: 0.3400
INFO - 2018-04-10 21:05:31 --> Config Class Initialized
INFO - 2018-04-10 21:05:31 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:05:31 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:05:31 --> Utf8 Class Initialized
INFO - 2018-04-10 21:05:31 --> URI Class Initialized
INFO - 2018-04-10 21:05:31 --> Router Class Initialized
INFO - 2018-04-10 21:05:31 --> Output Class Initialized
INFO - 2018-04-10 21:05:31 --> Security Class Initialized
DEBUG - 2018-04-10 21:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:05:31 --> CSRF cookie sent
INFO - 2018-04-10 21:05:31 --> Input Class Initialized
INFO - 2018-04-10 21:05:31 --> Language Class Initialized
ERROR - 2018-04-10 21:05:31 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 21:05:32 --> Config Class Initialized
INFO - 2018-04-10 21:05:32 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:05:32 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:05:32 --> Utf8 Class Initialized
INFO - 2018-04-10 21:05:32 --> URI Class Initialized
INFO - 2018-04-10 21:05:32 --> Router Class Initialized
INFO - 2018-04-10 21:05:32 --> Output Class Initialized
INFO - 2018-04-10 21:05:32 --> Security Class Initialized
DEBUG - 2018-04-10 21:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:05:32 --> CSRF cookie sent
INFO - 2018-04-10 21:05:32 --> Input Class Initialized
INFO - 2018-04-10 21:05:32 --> Language Class Initialized
ERROR - 2018-04-10 21:05:32 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-10 21:05:39 --> Config Class Initialized
INFO - 2018-04-10 21:05:39 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:05:39 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:05:39 --> Utf8 Class Initialized
INFO - 2018-04-10 21:05:39 --> URI Class Initialized
INFO - 2018-04-10 21:05:39 --> Router Class Initialized
INFO - 2018-04-10 21:05:39 --> Output Class Initialized
INFO - 2018-04-10 21:05:39 --> Security Class Initialized
DEBUG - 2018-04-10 21:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:05:39 --> CSRF cookie sent
INFO - 2018-04-10 21:05:39 --> Input Class Initialized
INFO - 2018-04-10 21:05:39 --> Language Class Initialized
ERROR - 2018-04-10 21:05:39 --> 404 Page Not Found: Parents/index
INFO - 2018-04-10 21:10:09 --> Config Class Initialized
INFO - 2018-04-10 21:10:09 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:10:09 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:10:09 --> Utf8 Class Initialized
INFO - 2018-04-10 21:10:09 --> URI Class Initialized
DEBUG - 2018-04-10 21:10:09 --> No URI present. Default controller set.
INFO - 2018-04-10 21:10:09 --> Router Class Initialized
INFO - 2018-04-10 21:10:09 --> Output Class Initialized
INFO - 2018-04-10 21:10:09 --> Security Class Initialized
DEBUG - 2018-04-10 21:10:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:10:09 --> CSRF cookie sent
INFO - 2018-04-10 21:10:09 --> Input Class Initialized
INFO - 2018-04-10 21:10:09 --> Language Class Initialized
INFO - 2018-04-10 21:10:09 --> Loader Class Initialized
INFO - 2018-04-10 21:10:09 --> Helper loaded: url_helper
INFO - 2018-04-10 21:10:09 --> Helper loaded: form_helper
INFO - 2018-04-10 21:10:09 --> Helper loaded: language_helper
DEBUG - 2018-04-10 21:10:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 21:10:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 21:10:09 --> User Agent Class Initialized
INFO - 2018-04-10 21:10:09 --> Controller Class Initialized
INFO - 2018-04-10 21:10:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 21:10:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-10 21:10:09 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 21:10:09 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-10 21:10:09 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 21:10:09 --> Final output sent to browser
DEBUG - 2018-04-10 21:10:09 --> Total execution time: 0.3485
INFO - 2018-04-10 21:10:10 --> Config Class Initialized
INFO - 2018-04-10 21:10:10 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:10:10 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:10:10 --> Utf8 Class Initialized
INFO - 2018-04-10 21:10:10 --> URI Class Initialized
INFO - 2018-04-10 21:10:10 --> Router Class Initialized
INFO - 2018-04-10 21:10:10 --> Output Class Initialized
INFO - 2018-04-10 21:10:10 --> Security Class Initialized
DEBUG - 2018-04-10 21:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:10:10 --> CSRF cookie sent
INFO - 2018-04-10 21:10:10 --> Input Class Initialized
INFO - 2018-04-10 21:10:10 --> Language Class Initialized
ERROR - 2018-04-10 21:10:10 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 21:10:11 --> Config Class Initialized
INFO - 2018-04-10 21:10:11 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:10:11 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:10:11 --> Utf8 Class Initialized
INFO - 2018-04-10 21:10:11 --> URI Class Initialized
INFO - 2018-04-10 21:10:11 --> Router Class Initialized
INFO - 2018-04-10 21:10:12 --> Output Class Initialized
INFO - 2018-04-10 21:10:12 --> Security Class Initialized
DEBUG - 2018-04-10 21:10:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:10:12 --> CSRF cookie sent
INFO - 2018-04-10 21:10:12 --> Input Class Initialized
INFO - 2018-04-10 21:10:12 --> Language Class Initialized
ERROR - 2018-04-10 21:10:12 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-10 21:10:13 --> Config Class Initialized
INFO - 2018-04-10 21:10:13 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:10:13 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:10:13 --> Utf8 Class Initialized
INFO - 2018-04-10 21:10:13 --> URI Class Initialized
INFO - 2018-04-10 21:10:13 --> Router Class Initialized
INFO - 2018-04-10 21:10:13 --> Output Class Initialized
INFO - 2018-04-10 21:10:13 --> Security Class Initialized
DEBUG - 2018-04-10 21:10:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:10:13 --> CSRF cookie sent
INFO - 2018-04-10 21:10:13 --> Input Class Initialized
INFO - 2018-04-10 21:10:13 --> Language Class Initialized
INFO - 2018-04-10 21:10:13 --> Loader Class Initialized
INFO - 2018-04-10 21:10:13 --> Helper loaded: url_helper
INFO - 2018-04-10 21:10:13 --> Helper loaded: form_helper
INFO - 2018-04-10 21:10:13 --> Helper loaded: language_helper
DEBUG - 2018-04-10 21:10:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 21:10:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 21:10:13 --> User Agent Class Initialized
INFO - 2018-04-10 21:10:13 --> Controller Class Initialized
INFO - 2018-04-10 21:10:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 21:10:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-10 21:10:13 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 21:16:03 --> Config Class Initialized
INFO - 2018-04-10 21:16:03 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:16:03 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:16:03 --> Utf8 Class Initialized
INFO - 2018-04-10 21:16:03 --> URI Class Initialized
INFO - 2018-04-10 21:16:03 --> Router Class Initialized
INFO - 2018-04-10 21:16:03 --> Output Class Initialized
INFO - 2018-04-10 21:16:03 --> Security Class Initialized
DEBUG - 2018-04-10 21:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:16:03 --> CSRF cookie sent
INFO - 2018-04-10 21:16:03 --> Input Class Initialized
INFO - 2018-04-10 21:16:03 --> Language Class Initialized
INFO - 2018-04-10 21:16:03 --> Loader Class Initialized
INFO - 2018-04-10 21:16:03 --> Helper loaded: url_helper
INFO - 2018-04-10 21:16:03 --> Helper loaded: form_helper
INFO - 2018-04-10 21:16:03 --> Helper loaded: language_helper
DEBUG - 2018-04-10 21:16:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 21:16:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 21:16:03 --> User Agent Class Initialized
INFO - 2018-04-10 21:16:03 --> Controller Class Initialized
INFO - 2018-04-10 21:16:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 21:16:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-10 21:16:03 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 21:16:03 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 21:16:03 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-10 21:16:03 --> Could not find the language line "req_email"
ERROR - 2018-04-10 21:16:03 --> Severity: Notice --> Undefined variable: widget E:\www\yacopoo\application\views\myaccount\signin.php 33
ERROR - 2018-04-10 21:16:03 --> Severity: Notice --> Undefined variable: script E:\www\yacopoo\application\views\myaccount\signin.php 34
INFO - 2018-04-10 21:16:03 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-04-10 21:16:03 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 21:16:03 --> Final output sent to browser
DEBUG - 2018-04-10 21:16:03 --> Total execution time: 0.3860
INFO - 2018-04-10 21:16:04 --> Config Class Initialized
INFO - 2018-04-10 21:16:04 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:16:04 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:16:04 --> Utf8 Class Initialized
INFO - 2018-04-10 21:16:04 --> URI Class Initialized
INFO - 2018-04-10 21:16:04 --> Router Class Initialized
INFO - 2018-04-10 21:16:04 --> Output Class Initialized
INFO - 2018-04-10 21:16:04 --> Security Class Initialized
DEBUG - 2018-04-10 21:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:16:04 --> CSRF cookie sent
INFO - 2018-04-10 21:16:04 --> Input Class Initialized
INFO - 2018-04-10 21:16:04 --> Language Class Initialized
ERROR - 2018-04-10 21:16:04 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 21:16:31 --> Config Class Initialized
INFO - 2018-04-10 21:16:31 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:16:31 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:16:31 --> Utf8 Class Initialized
INFO - 2018-04-10 21:16:31 --> URI Class Initialized
INFO - 2018-04-10 21:16:31 --> Router Class Initialized
INFO - 2018-04-10 21:16:31 --> Output Class Initialized
INFO - 2018-04-10 21:16:31 --> Security Class Initialized
DEBUG - 2018-04-10 21:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:16:31 --> CSRF cookie sent
INFO - 2018-04-10 21:16:31 --> Input Class Initialized
INFO - 2018-04-10 21:16:31 --> Language Class Initialized
INFO - 2018-04-10 21:16:31 --> Loader Class Initialized
INFO - 2018-04-10 21:16:31 --> Helper loaded: url_helper
INFO - 2018-04-10 21:16:31 --> Helper loaded: form_helper
INFO - 2018-04-10 21:16:31 --> Helper loaded: language_helper
DEBUG - 2018-04-10 21:16:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 21:16:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 21:16:31 --> User Agent Class Initialized
INFO - 2018-04-10 21:16:31 --> Controller Class Initialized
INFO - 2018-04-10 21:16:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 21:16:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-10 21:16:31 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 21:16:31 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 21:16:31 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-10 21:16:31 --> Could not find the language line "req_email"
ERROR - 2018-04-10 21:16:31 --> Severity: Notice --> Undefined variable: widget E:\www\yacopoo\application\views\myaccount\signin.php 33
ERROR - 2018-04-10 21:16:31 --> Severity: Notice --> Undefined variable: script E:\www\yacopoo\application\views\myaccount\signin.php 34
INFO - 2018-04-10 21:16:31 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-04-10 21:16:31 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 21:16:31 --> Final output sent to browser
DEBUG - 2018-04-10 21:16:31 --> Total execution time: 0.4141
INFO - 2018-04-10 21:16:31 --> Config Class Initialized
INFO - 2018-04-10 21:16:31 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:16:31 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:16:31 --> Utf8 Class Initialized
INFO - 2018-04-10 21:16:31 --> URI Class Initialized
INFO - 2018-04-10 21:16:31 --> Router Class Initialized
INFO - 2018-04-10 21:16:31 --> Output Class Initialized
INFO - 2018-04-10 21:16:31 --> Security Class Initialized
DEBUG - 2018-04-10 21:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:16:31 --> CSRF cookie sent
INFO - 2018-04-10 21:16:32 --> Input Class Initialized
INFO - 2018-04-10 21:16:32 --> Language Class Initialized
ERROR - 2018-04-10 21:16:32 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 21:24:51 --> Config Class Initialized
INFO - 2018-04-10 21:24:51 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:24:51 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:24:51 --> Utf8 Class Initialized
INFO - 2018-04-10 21:24:51 --> URI Class Initialized
INFO - 2018-04-10 21:24:51 --> Router Class Initialized
INFO - 2018-04-10 21:24:51 --> Output Class Initialized
INFO - 2018-04-10 21:24:51 --> Security Class Initialized
DEBUG - 2018-04-10 21:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:24:51 --> CSRF cookie sent
INFO - 2018-04-10 21:24:51 --> Input Class Initialized
INFO - 2018-04-10 21:24:51 --> Language Class Initialized
INFO - 2018-04-10 21:24:51 --> Loader Class Initialized
INFO - 2018-04-10 21:24:51 --> Helper loaded: url_helper
INFO - 2018-04-10 21:24:51 --> Helper loaded: form_helper
INFO - 2018-04-10 21:24:51 --> Helper loaded: language_helper
DEBUG - 2018-04-10 21:24:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 21:24:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 21:24:51 --> User Agent Class Initialized
INFO - 2018-04-10 21:24:51 --> Controller Class Initialized
INFO - 2018-04-10 21:24:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 21:24:51 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 21:24:51 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 21:24:51 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 21:24:51 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 21:24:51 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-10 21:24:51 --> Could not find the language line "req_email"
INFO - 2018-04-10 21:24:51 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-04-10 21:24:51 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 21:24:51 --> Final output sent to browser
DEBUG - 2018-04-10 21:24:51 --> Total execution time: 0.3895
INFO - 2018-04-10 21:24:52 --> Config Class Initialized
INFO - 2018-04-10 21:24:52 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:24:52 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:24:52 --> Utf8 Class Initialized
INFO - 2018-04-10 21:24:52 --> URI Class Initialized
INFO - 2018-04-10 21:24:52 --> Router Class Initialized
INFO - 2018-04-10 21:24:52 --> Output Class Initialized
INFO - 2018-04-10 21:24:52 --> Security Class Initialized
DEBUG - 2018-04-10 21:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:24:52 --> CSRF cookie sent
INFO - 2018-04-10 21:24:52 --> Input Class Initialized
INFO - 2018-04-10 21:24:52 --> Language Class Initialized
ERROR - 2018-04-10 21:24:52 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 21:25:16 --> Config Class Initialized
INFO - 2018-04-10 21:25:16 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:25:16 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:25:16 --> Utf8 Class Initialized
INFO - 2018-04-10 21:25:16 --> URI Class Initialized
INFO - 2018-04-10 21:25:16 --> Router Class Initialized
INFO - 2018-04-10 21:25:16 --> Output Class Initialized
INFO - 2018-04-10 21:25:17 --> Security Class Initialized
DEBUG - 2018-04-10 21:25:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:25:17 --> CSRF cookie sent
INFO - 2018-04-10 21:25:17 --> CSRF token verified
INFO - 2018-04-10 21:25:17 --> Input Class Initialized
INFO - 2018-04-10 21:25:17 --> Language Class Initialized
INFO - 2018-04-10 21:25:17 --> Loader Class Initialized
INFO - 2018-04-10 21:25:17 --> Helper loaded: url_helper
INFO - 2018-04-10 21:25:17 --> Helper loaded: form_helper
INFO - 2018-04-10 21:25:17 --> Helper loaded: language_helper
DEBUG - 2018-04-10 21:25:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 21:25:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 21:25:17 --> User Agent Class Initialized
INFO - 2018-04-10 21:25:17 --> Controller Class Initialized
INFO - 2018-04-10 21:25:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 21:25:17 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 21:25:17 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 21:25:17 --> Config Class Initialized
INFO - 2018-04-10 21:25:17 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:25:17 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:25:17 --> Utf8 Class Initialized
INFO - 2018-04-10 21:25:17 --> URI Class Initialized
INFO - 2018-04-10 21:25:17 --> Router Class Initialized
INFO - 2018-04-10 21:25:17 --> Output Class Initialized
INFO - 2018-04-10 21:25:17 --> Security Class Initialized
DEBUG - 2018-04-10 21:25:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:25:17 --> CSRF cookie sent
INFO - 2018-04-10 21:25:17 --> Input Class Initialized
INFO - 2018-04-10 21:25:17 --> Language Class Initialized
INFO - 2018-04-10 21:25:17 --> Loader Class Initialized
INFO - 2018-04-10 21:25:17 --> Helper loaded: url_helper
INFO - 2018-04-10 21:25:17 --> Helper loaded: form_helper
INFO - 2018-04-10 21:25:17 --> Helper loaded: language_helper
DEBUG - 2018-04-10 21:25:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 21:25:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 21:25:17 --> User Agent Class Initialized
INFO - 2018-04-10 21:25:17 --> Controller Class Initialized
INFO - 2018-04-10 21:25:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 21:25:17 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 21:25:17 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 21:25:17 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 21:25:17 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 21:25:17 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-10 21:25:17 --> File loaded: E:\www\yacopoo\application\views\shared/_soft_error.php
ERROR - 2018-04-10 21:25:17 --> Could not find the language line "req_email"
INFO - 2018-04-10 21:25:17 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-04-10 21:25:17 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 21:25:17 --> Final output sent to browser
DEBUG - 2018-04-10 21:25:17 --> Total execution time: 0.3802
INFO - 2018-04-10 21:25:18 --> Config Class Initialized
INFO - 2018-04-10 21:25:18 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:25:18 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:25:18 --> Utf8 Class Initialized
INFO - 2018-04-10 21:25:18 --> URI Class Initialized
INFO - 2018-04-10 21:25:18 --> Router Class Initialized
INFO - 2018-04-10 21:25:18 --> Output Class Initialized
INFO - 2018-04-10 21:25:18 --> Security Class Initialized
DEBUG - 2018-04-10 21:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:25:18 --> CSRF cookie sent
INFO - 2018-04-10 21:25:18 --> Input Class Initialized
INFO - 2018-04-10 21:25:18 --> Language Class Initialized
ERROR - 2018-04-10 21:25:18 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 21:25:28 --> Config Class Initialized
INFO - 2018-04-10 21:25:28 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:25:28 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:25:28 --> Utf8 Class Initialized
INFO - 2018-04-10 21:25:28 --> URI Class Initialized
INFO - 2018-04-10 21:25:28 --> Router Class Initialized
INFO - 2018-04-10 21:25:28 --> Output Class Initialized
INFO - 2018-04-10 21:25:28 --> Security Class Initialized
DEBUG - 2018-04-10 21:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:25:28 --> CSRF cookie sent
INFO - 2018-04-10 21:25:28 --> CSRF token verified
INFO - 2018-04-10 21:25:28 --> Input Class Initialized
INFO - 2018-04-10 21:25:28 --> Language Class Initialized
INFO - 2018-04-10 21:25:28 --> Loader Class Initialized
INFO - 2018-04-10 21:25:28 --> Helper loaded: url_helper
INFO - 2018-04-10 21:25:28 --> Helper loaded: form_helper
INFO - 2018-04-10 21:25:29 --> Helper loaded: language_helper
DEBUG - 2018-04-10 21:25:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 21:25:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 21:25:29 --> User Agent Class Initialized
INFO - 2018-04-10 21:25:29 --> Controller Class Initialized
INFO - 2018-04-10 21:25:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 21:25:29 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 21:25:29 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 21:25:29 --> Form Validation Class Initialized
INFO - 2018-04-10 21:25:29 --> Config Class Initialized
INFO - 2018-04-10 21:25:29 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:25:29 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:25:29 --> Utf8 Class Initialized
INFO - 2018-04-10 21:25:29 --> URI Class Initialized
INFO - 2018-04-10 21:25:29 --> Router Class Initialized
INFO - 2018-04-10 21:25:29 --> Output Class Initialized
INFO - 2018-04-10 21:25:29 --> Security Class Initialized
DEBUG - 2018-04-10 21:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:25:29 --> CSRF cookie sent
INFO - 2018-04-10 21:25:29 --> Input Class Initialized
INFO - 2018-04-10 21:25:29 --> Language Class Initialized
INFO - 2018-04-10 21:25:29 --> Loader Class Initialized
INFO - 2018-04-10 21:25:29 --> Helper loaded: url_helper
INFO - 2018-04-10 21:25:29 --> Helper loaded: form_helper
INFO - 2018-04-10 21:25:29 --> Helper loaded: language_helper
DEBUG - 2018-04-10 21:25:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 21:25:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 21:25:29 --> User Agent Class Initialized
INFO - 2018-04-10 21:25:29 --> Controller Class Initialized
INFO - 2018-04-10 21:25:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 21:25:29 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 21:25:29 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 21:25:29 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 21:25:29 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 21:25:29 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-10 21:25:29 --> Could not find the language line "req_email"
INFO - 2018-04-10 21:25:29 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-04-10 21:25:29 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 21:25:29 --> Final output sent to browser
DEBUG - 2018-04-10 21:25:29 --> Total execution time: 0.3693
INFO - 2018-04-10 21:25:30 --> Config Class Initialized
INFO - 2018-04-10 21:25:30 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:25:30 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:25:30 --> Utf8 Class Initialized
INFO - 2018-04-10 21:25:30 --> URI Class Initialized
INFO - 2018-04-10 21:25:30 --> Router Class Initialized
INFO - 2018-04-10 21:25:30 --> Output Class Initialized
INFO - 2018-04-10 21:25:30 --> Security Class Initialized
DEBUG - 2018-04-10 21:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:25:30 --> CSRF cookie sent
INFO - 2018-04-10 21:25:30 --> Input Class Initialized
INFO - 2018-04-10 21:25:30 --> Language Class Initialized
ERROR - 2018-04-10 21:25:30 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 21:26:06 --> Config Class Initialized
INFO - 2018-04-10 21:26:06 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:26:06 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:26:06 --> Utf8 Class Initialized
INFO - 2018-04-10 21:26:06 --> URI Class Initialized
INFO - 2018-04-10 21:26:06 --> Router Class Initialized
INFO - 2018-04-10 21:26:06 --> Output Class Initialized
INFO - 2018-04-10 21:26:06 --> Security Class Initialized
DEBUG - 2018-04-10 21:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:26:06 --> CSRF cookie sent
INFO - 2018-04-10 21:26:06 --> Input Class Initialized
INFO - 2018-04-10 21:26:06 --> Language Class Initialized
INFO - 2018-04-10 21:26:06 --> Loader Class Initialized
INFO - 2018-04-10 21:26:06 --> Helper loaded: url_helper
INFO - 2018-04-10 21:26:06 --> Helper loaded: form_helper
INFO - 2018-04-10 21:26:06 --> Helper loaded: language_helper
DEBUG - 2018-04-10 21:26:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 21:26:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 21:26:06 --> User Agent Class Initialized
INFO - 2018-04-10 21:26:06 --> Controller Class Initialized
INFO - 2018-04-10 21:26:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 21:26:06 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 21:26:06 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 21:26:06 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 21:26:06 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 21:26:06 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-10 21:26:06 --> Could not find the language line "req_email"
INFO - 2018-04-10 21:26:06 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-04-10 21:26:06 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 21:26:06 --> Final output sent to browser
DEBUG - 2018-04-10 21:26:06 --> Total execution time: 0.4174
INFO - 2018-04-10 21:26:06 --> Config Class Initialized
INFO - 2018-04-10 21:26:06 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:26:06 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:26:07 --> Utf8 Class Initialized
INFO - 2018-04-10 21:26:07 --> URI Class Initialized
INFO - 2018-04-10 21:26:07 --> Router Class Initialized
INFO - 2018-04-10 21:26:07 --> Output Class Initialized
INFO - 2018-04-10 21:26:07 --> Security Class Initialized
DEBUG - 2018-04-10 21:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:26:07 --> CSRF cookie sent
INFO - 2018-04-10 21:26:07 --> Input Class Initialized
INFO - 2018-04-10 21:26:07 --> Language Class Initialized
ERROR - 2018-04-10 21:26:07 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 21:26:20 --> Config Class Initialized
INFO - 2018-04-10 21:26:20 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:26:20 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:26:20 --> Utf8 Class Initialized
INFO - 2018-04-10 21:26:20 --> URI Class Initialized
INFO - 2018-04-10 21:26:20 --> Router Class Initialized
INFO - 2018-04-10 21:26:20 --> Output Class Initialized
INFO - 2018-04-10 21:26:20 --> Security Class Initialized
DEBUG - 2018-04-10 21:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:26:20 --> CSRF cookie sent
INFO - 2018-04-10 21:26:20 --> CSRF token verified
INFO - 2018-04-10 21:26:20 --> Input Class Initialized
INFO - 2018-04-10 21:26:20 --> Language Class Initialized
INFO - 2018-04-10 21:26:20 --> Loader Class Initialized
INFO - 2018-04-10 21:26:20 --> Helper loaded: url_helper
INFO - 2018-04-10 21:26:20 --> Helper loaded: form_helper
INFO - 2018-04-10 21:26:20 --> Helper loaded: language_helper
DEBUG - 2018-04-10 21:26:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 21:26:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 21:26:20 --> User Agent Class Initialized
INFO - 2018-04-10 21:26:20 --> Controller Class Initialized
INFO - 2018-04-10 21:26:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 21:26:20 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 21:26:20 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 21:26:20 --> Form Validation Class Initialized
INFO - 2018-04-10 21:26:20 --> Pixel_Model class loaded
INFO - 2018-04-10 21:26:20 --> Database Driver Class Initialized
INFO - 2018-04-10 21:26:23 --> Model "AuthenticationModel" initialized
INFO - 2018-04-10 21:26:23 --> Config Class Initialized
INFO - 2018-04-10 21:26:23 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:26:23 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:26:23 --> Utf8 Class Initialized
INFO - 2018-04-10 21:26:24 --> URI Class Initialized
INFO - 2018-04-10 21:26:24 --> Router Class Initialized
INFO - 2018-04-10 21:26:24 --> Output Class Initialized
INFO - 2018-04-10 21:26:24 --> Security Class Initialized
DEBUG - 2018-04-10 21:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:26:24 --> CSRF cookie sent
INFO - 2018-04-10 21:26:24 --> Input Class Initialized
INFO - 2018-04-10 21:26:24 --> Language Class Initialized
INFO - 2018-04-10 21:26:24 --> Loader Class Initialized
INFO - 2018-04-10 21:26:24 --> Helper loaded: url_helper
INFO - 2018-04-10 21:26:24 --> Helper loaded: form_helper
INFO - 2018-04-10 21:26:24 --> Helper loaded: language_helper
DEBUG - 2018-04-10 21:26:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 21:26:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 21:26:24 --> User Agent Class Initialized
INFO - 2018-04-10 21:26:24 --> Controller Class Initialized
INFO - 2018-04-10 21:26:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 21:26:24 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 21:26:24 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 21:26:24 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 21:26:24 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 21:26:24 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-10 21:26:24 --> File loaded: E:\www\yacopoo\application\views\shared/_soft_error.php
ERROR - 2018-04-10 21:26:24 --> Could not find the language line "req_email"
INFO - 2018-04-10 21:26:24 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-04-10 21:26:24 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 21:26:24 --> Final output sent to browser
DEBUG - 2018-04-10 21:26:24 --> Total execution time: 0.4129
INFO - 2018-04-10 21:26:24 --> Config Class Initialized
INFO - 2018-04-10 21:26:24 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:26:24 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:26:24 --> Utf8 Class Initialized
INFO - 2018-04-10 21:26:24 --> URI Class Initialized
INFO - 2018-04-10 21:26:24 --> Router Class Initialized
INFO - 2018-04-10 21:26:24 --> Output Class Initialized
INFO - 2018-04-10 21:26:24 --> Security Class Initialized
DEBUG - 2018-04-10 21:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:26:24 --> CSRF cookie sent
INFO - 2018-04-10 21:26:24 --> Input Class Initialized
INFO - 2018-04-10 21:26:24 --> Language Class Initialized
INFO - 2018-04-10 21:26:25 --> Config Class Initialized
ERROR - 2018-04-10 21:26:25 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 21:26:25 --> Config Class Initialized
INFO - 2018-04-10 21:26:25 --> Config Class Initialized
INFO - 2018-04-10 21:26:25 --> Hooks Class Initialized
INFO - 2018-04-10 21:26:25 --> Hooks Class Initialized
INFO - 2018-04-10 21:26:25 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:26:25 --> UTF-8 Support Enabled
DEBUG - 2018-04-10 21:26:25 --> UTF-8 Support Enabled
DEBUG - 2018-04-10 21:26:25 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:26:25 --> Utf8 Class Initialized
INFO - 2018-04-10 21:26:25 --> Utf8 Class Initialized
INFO - 2018-04-10 21:26:25 --> Utf8 Class Initialized
INFO - 2018-04-10 21:26:25 --> URI Class Initialized
INFO - 2018-04-10 21:26:25 --> URI Class Initialized
INFO - 2018-04-10 21:26:25 --> URI Class Initialized
INFO - 2018-04-10 21:26:25 --> Router Class Initialized
INFO - 2018-04-10 21:26:25 --> Router Class Initialized
INFO - 2018-04-10 21:26:25 --> Router Class Initialized
INFO - 2018-04-10 21:26:25 --> Output Class Initialized
INFO - 2018-04-10 21:26:25 --> Output Class Initialized
INFO - 2018-04-10 21:26:25 --> Output Class Initialized
INFO - 2018-04-10 21:26:25 --> Security Class Initialized
INFO - 2018-04-10 21:26:25 --> Security Class Initialized
INFO - 2018-04-10 21:26:25 --> Security Class Initialized
DEBUG - 2018-04-10 21:26:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-10 21:26:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-10 21:26:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:26:25 --> CSRF cookie sent
INFO - 2018-04-10 21:26:25 --> CSRF cookie sent
INFO - 2018-04-10 21:26:25 --> CSRF cookie sent
INFO - 2018-04-10 21:26:25 --> Input Class Initialized
INFO - 2018-04-10 21:26:25 --> Input Class Initialized
INFO - 2018-04-10 21:26:25 --> Input Class Initialized
INFO - 2018-04-10 21:26:25 --> Language Class Initialized
INFO - 2018-04-10 21:26:25 --> Language Class Initialized
INFO - 2018-04-10 21:26:25 --> Language Class Initialized
ERROR - 2018-04-10 21:26:25 --> 404 Page Not Found: Sign-in/assets
ERROR - 2018-04-10 21:26:25 --> 404 Page Not Found: Sign-in/assets
ERROR - 2018-04-10 21:26:25 --> 404 Page Not Found: Sign-in/assets
INFO - 2018-04-10 21:27:39 --> Config Class Initialized
INFO - 2018-04-10 21:27:39 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:27:39 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:27:39 --> Utf8 Class Initialized
INFO - 2018-04-10 21:27:39 --> URI Class Initialized
INFO - 2018-04-10 21:27:39 --> Router Class Initialized
INFO - 2018-04-10 21:27:39 --> Output Class Initialized
INFO - 2018-04-10 21:27:39 --> Security Class Initialized
DEBUG - 2018-04-10 21:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:27:39 --> CSRF cookie sent
INFO - 2018-04-10 21:27:39 --> CSRF token verified
INFO - 2018-04-10 21:27:39 --> Input Class Initialized
INFO - 2018-04-10 21:27:39 --> Language Class Initialized
INFO - 2018-04-10 21:27:39 --> Loader Class Initialized
INFO - 2018-04-10 21:27:39 --> Helper loaded: url_helper
INFO - 2018-04-10 21:27:39 --> Helper loaded: form_helper
INFO - 2018-04-10 21:27:39 --> Helper loaded: language_helper
DEBUG - 2018-04-10 21:27:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 21:27:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 21:27:39 --> User Agent Class Initialized
INFO - 2018-04-10 21:27:39 --> Controller Class Initialized
INFO - 2018-04-10 21:27:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 21:27:39 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 21:27:39 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 21:27:40 --> Form Validation Class Initialized
INFO - 2018-04-10 21:27:40 --> Pixel_Model class loaded
INFO - 2018-04-10 21:27:40 --> Database Driver Class Initialized
INFO - 2018-04-10 21:27:40 --> Model "AuthenticationModel" initialized
INFO - 2018-04-10 21:27:40 --> Config Class Initialized
INFO - 2018-04-10 21:27:40 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:27:40 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:27:40 --> Utf8 Class Initialized
INFO - 2018-04-10 21:27:40 --> URI Class Initialized
INFO - 2018-04-10 21:27:40 --> Router Class Initialized
INFO - 2018-04-10 21:27:40 --> Output Class Initialized
INFO - 2018-04-10 21:27:40 --> Security Class Initialized
DEBUG - 2018-04-10 21:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:27:40 --> CSRF cookie sent
INFO - 2018-04-10 21:27:40 --> Input Class Initialized
INFO - 2018-04-10 21:27:40 --> Language Class Initialized
INFO - 2018-04-10 21:27:40 --> Loader Class Initialized
INFO - 2018-04-10 21:27:40 --> Helper loaded: url_helper
INFO - 2018-04-10 21:27:40 --> Helper loaded: form_helper
INFO - 2018-04-10 21:27:40 --> Helper loaded: language_helper
DEBUG - 2018-04-10 21:27:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 21:27:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 21:27:40 --> User Agent Class Initialized
INFO - 2018-04-10 21:27:40 --> Controller Class Initialized
INFO - 2018-04-10 21:27:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 21:27:40 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 21:27:40 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 21:27:40 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 21:27:40 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 21:27:40 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-10 21:27:40 --> File loaded: E:\www\yacopoo\application\views\shared/_soft_error.php
ERROR - 2018-04-10 21:27:40 --> Could not find the language line "req_email"
INFO - 2018-04-10 21:27:40 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-04-10 21:27:40 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 21:27:40 --> Final output sent to browser
DEBUG - 2018-04-10 21:27:40 --> Total execution time: 0.3921
INFO - 2018-04-10 21:27:41 --> Config Class Initialized
INFO - 2018-04-10 21:27:41 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:27:41 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:27:41 --> Utf8 Class Initialized
INFO - 2018-04-10 21:27:41 --> URI Class Initialized
INFO - 2018-04-10 21:27:41 --> Router Class Initialized
INFO - 2018-04-10 21:27:41 --> Output Class Initialized
INFO - 2018-04-10 21:27:41 --> Security Class Initialized
DEBUG - 2018-04-10 21:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:27:41 --> CSRF cookie sent
INFO - 2018-04-10 21:27:41 --> Input Class Initialized
INFO - 2018-04-10 21:27:41 --> Language Class Initialized
ERROR - 2018-04-10 21:27:41 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 21:27:41 --> Config Class Initialized
INFO - 2018-04-10 21:27:41 --> Hooks Class Initialized
INFO - 2018-04-10 21:27:41 --> Config Class Initialized
INFO - 2018-04-10 21:27:41 --> Config Class Initialized
INFO - 2018-04-10 21:27:41 --> Hooks Class Initialized
INFO - 2018-04-10 21:27:41 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:27:41 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:27:41 --> Utf8 Class Initialized
DEBUG - 2018-04-10 21:27:41 --> UTF-8 Support Enabled
DEBUG - 2018-04-10 21:27:41 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:27:41 --> Utf8 Class Initialized
INFO - 2018-04-10 21:27:41 --> Utf8 Class Initialized
INFO - 2018-04-10 21:27:41 --> URI Class Initialized
INFO - 2018-04-10 21:27:41 --> URI Class Initialized
INFO - 2018-04-10 21:27:41 --> URI Class Initialized
INFO - 2018-04-10 21:27:41 --> Router Class Initialized
INFO - 2018-04-10 21:27:41 --> Output Class Initialized
INFO - 2018-04-10 21:27:41 --> Router Class Initialized
INFO - 2018-04-10 21:27:41 --> Router Class Initialized
INFO - 2018-04-10 21:27:41 --> Output Class Initialized
INFO - 2018-04-10 21:27:41 --> Security Class Initialized
INFO - 2018-04-10 21:27:41 --> Output Class Initialized
INFO - 2018-04-10 21:27:41 --> Security Class Initialized
INFO - 2018-04-10 21:27:41 --> Security Class Initialized
DEBUG - 2018-04-10 21:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:27:41 --> CSRF cookie sent
DEBUG - 2018-04-10 21:27:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-10 21:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:27:41 --> CSRF cookie sent
INFO - 2018-04-10 21:27:41 --> CSRF cookie sent
INFO - 2018-04-10 21:27:41 --> Input Class Initialized
INFO - 2018-04-10 21:27:41 --> Input Class Initialized
INFO - 2018-04-10 21:27:41 --> Language Class Initialized
INFO - 2018-04-10 21:27:41 --> Input Class Initialized
INFO - 2018-04-10 21:27:41 --> Language Class Initialized
INFO - 2018-04-10 21:27:41 --> Language Class Initialized
ERROR - 2018-04-10 21:27:41 --> 404 Page Not Found: Sign-in/assets
ERROR - 2018-04-10 21:27:41 --> 404 Page Not Found: Sign-in/assets
ERROR - 2018-04-10 21:27:41 --> 404 Page Not Found: Sign-in/assets
INFO - 2018-04-10 21:28:09 --> Config Class Initialized
INFO - 2018-04-10 21:28:09 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:28:09 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:28:09 --> Utf8 Class Initialized
INFO - 2018-04-10 21:28:09 --> URI Class Initialized
INFO - 2018-04-10 21:28:09 --> Router Class Initialized
INFO - 2018-04-10 21:28:09 --> Output Class Initialized
INFO - 2018-04-10 21:28:09 --> Security Class Initialized
DEBUG - 2018-04-10 21:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:28:09 --> CSRF cookie sent
INFO - 2018-04-10 21:28:09 --> CSRF token verified
INFO - 2018-04-10 21:28:09 --> Input Class Initialized
INFO - 2018-04-10 21:28:09 --> Language Class Initialized
INFO - 2018-04-10 21:28:09 --> Loader Class Initialized
INFO - 2018-04-10 21:28:09 --> Helper loaded: url_helper
INFO - 2018-04-10 21:28:09 --> Helper loaded: form_helper
INFO - 2018-04-10 21:28:09 --> Helper loaded: language_helper
DEBUG - 2018-04-10 21:28:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 21:28:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 21:28:09 --> User Agent Class Initialized
INFO - 2018-04-10 21:28:09 --> Controller Class Initialized
INFO - 2018-04-10 21:28:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 21:28:09 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 21:28:09 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 21:28:10 --> Form Validation Class Initialized
INFO - 2018-04-10 21:28:10 --> Pixel_Model class loaded
INFO - 2018-04-10 21:28:10 --> Database Driver Class Initialized
INFO - 2018-04-10 21:28:13 --> Model "AuthenticationModel" initialized
INFO - 2018-04-10 21:28:13 --> Config Class Initialized
INFO - 2018-04-10 21:28:13 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:28:14 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:28:14 --> Utf8 Class Initialized
INFO - 2018-04-10 21:28:14 --> URI Class Initialized
INFO - 2018-04-10 21:28:14 --> Router Class Initialized
INFO - 2018-04-10 21:28:14 --> Output Class Initialized
INFO - 2018-04-10 21:28:14 --> Security Class Initialized
DEBUG - 2018-04-10 21:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:28:14 --> CSRF cookie sent
INFO - 2018-04-10 21:28:14 --> Input Class Initialized
INFO - 2018-04-10 21:28:14 --> Language Class Initialized
INFO - 2018-04-10 21:28:14 --> Loader Class Initialized
INFO - 2018-04-10 21:28:14 --> Helper loaded: url_helper
INFO - 2018-04-10 21:28:14 --> Helper loaded: form_helper
INFO - 2018-04-10 21:28:14 --> Helper loaded: language_helper
DEBUG - 2018-04-10 21:28:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 21:28:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 21:28:14 --> User Agent Class Initialized
INFO - 2018-04-10 21:28:14 --> Controller Class Initialized
INFO - 2018-04-10 21:28:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 21:28:14 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 21:28:14 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 21:28:14 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 21:28:14 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 21:28:14 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-10 21:28:14 --> File loaded: E:\www\yacopoo\application\views\shared/_soft_error.php
ERROR - 2018-04-10 21:28:14 --> Could not find the language line "req_email"
INFO - 2018-04-10 21:28:14 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-04-10 21:28:14 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 21:28:14 --> Final output sent to browser
DEBUG - 2018-04-10 21:28:14 --> Total execution time: 0.4004
INFO - 2018-04-10 21:28:14 --> Config Class Initialized
INFO - 2018-04-10 21:28:14 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:28:14 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:28:14 --> Utf8 Class Initialized
INFO - 2018-04-10 21:28:14 --> URI Class Initialized
INFO - 2018-04-10 21:28:14 --> Router Class Initialized
INFO - 2018-04-10 21:28:14 --> Output Class Initialized
INFO - 2018-04-10 21:28:14 --> Security Class Initialized
DEBUG - 2018-04-10 21:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:28:14 --> CSRF cookie sent
INFO - 2018-04-10 21:28:14 --> Input Class Initialized
INFO - 2018-04-10 21:28:14 --> Language Class Initialized
ERROR - 2018-04-10 21:28:14 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 21:28:14 --> Config Class Initialized
INFO - 2018-04-10 21:28:15 --> Config Class Initialized
INFO - 2018-04-10 21:28:15 --> Config Class Initialized
INFO - 2018-04-10 21:28:15 --> Hooks Class Initialized
INFO - 2018-04-10 21:28:15 --> Hooks Class Initialized
INFO - 2018-04-10 21:28:15 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:28:15 --> UTF-8 Support Enabled
DEBUG - 2018-04-10 21:28:15 --> UTF-8 Support Enabled
DEBUG - 2018-04-10 21:28:15 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:28:15 --> Utf8 Class Initialized
INFO - 2018-04-10 21:28:15 --> Utf8 Class Initialized
INFO - 2018-04-10 21:28:15 --> Utf8 Class Initialized
INFO - 2018-04-10 21:28:15 --> URI Class Initialized
INFO - 2018-04-10 21:28:15 --> URI Class Initialized
INFO - 2018-04-10 21:28:15 --> URI Class Initialized
INFO - 2018-04-10 21:28:15 --> Router Class Initialized
INFO - 2018-04-10 21:28:15 --> Router Class Initialized
INFO - 2018-04-10 21:28:15 --> Router Class Initialized
INFO - 2018-04-10 21:28:15 --> Output Class Initialized
INFO - 2018-04-10 21:28:15 --> Output Class Initialized
INFO - 2018-04-10 21:28:15 --> Output Class Initialized
INFO - 2018-04-10 21:28:15 --> Security Class Initialized
INFO - 2018-04-10 21:28:15 --> Security Class Initialized
INFO - 2018-04-10 21:28:15 --> Security Class Initialized
DEBUG - 2018-04-10 21:28:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-10 21:28:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-10 21:28:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:28:15 --> CSRF cookie sent
INFO - 2018-04-10 21:28:15 --> CSRF cookie sent
INFO - 2018-04-10 21:28:15 --> CSRF cookie sent
INFO - 2018-04-10 21:28:15 --> Input Class Initialized
INFO - 2018-04-10 21:28:15 --> Input Class Initialized
INFO - 2018-04-10 21:28:15 --> Input Class Initialized
INFO - 2018-04-10 21:28:15 --> Language Class Initialized
INFO - 2018-04-10 21:28:15 --> Language Class Initialized
INFO - 2018-04-10 21:28:15 --> Language Class Initialized
ERROR - 2018-04-10 21:28:15 --> 404 Page Not Found: Sign-in/assets
ERROR - 2018-04-10 21:28:15 --> 404 Page Not Found: Sign-in/assets
ERROR - 2018-04-10 21:28:15 --> 404 Page Not Found: Sign-in/assets
INFO - 2018-04-10 21:28:55 --> Config Class Initialized
INFO - 2018-04-10 21:28:55 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:28:55 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:28:55 --> Utf8 Class Initialized
INFO - 2018-04-10 21:28:55 --> URI Class Initialized
INFO - 2018-04-10 21:28:55 --> Router Class Initialized
INFO - 2018-04-10 21:28:55 --> Output Class Initialized
INFO - 2018-04-10 21:28:55 --> Security Class Initialized
DEBUG - 2018-04-10 21:28:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:28:55 --> CSRF cookie sent
INFO - 2018-04-10 21:28:55 --> Input Class Initialized
INFO - 2018-04-10 21:28:55 --> Language Class Initialized
ERROR - 2018-04-10 21:28:55 --> 404 Page Not Found: Financial%20Advisors/index
INFO - 2018-04-10 21:28:58 --> Config Class Initialized
INFO - 2018-04-10 21:28:58 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:28:58 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:28:58 --> Utf8 Class Initialized
INFO - 2018-04-10 21:28:58 --> URI Class Initialized
INFO - 2018-04-10 21:28:58 --> Router Class Initialized
INFO - 2018-04-10 21:28:58 --> Output Class Initialized
INFO - 2018-04-10 21:28:58 --> Security Class Initialized
DEBUG - 2018-04-10 21:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:28:58 --> CSRF cookie sent
INFO - 2018-04-10 21:28:58 --> Input Class Initialized
INFO - 2018-04-10 21:28:58 --> Language Class Initialized
INFO - 2018-04-10 21:28:58 --> Loader Class Initialized
INFO - 2018-04-10 21:28:58 --> Helper loaded: url_helper
INFO - 2018-04-10 21:28:58 --> Helper loaded: form_helper
INFO - 2018-04-10 21:28:58 --> Helper loaded: language_helper
DEBUG - 2018-04-10 21:28:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 21:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 21:28:58 --> User Agent Class Initialized
INFO - 2018-04-10 21:28:58 --> Controller Class Initialized
INFO - 2018-04-10 21:28:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 21:28:58 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 21:28:58 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 21:28:58 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 21:28:58 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 21:28:58 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-10 21:28:58 --> Could not find the language line "req_email"
INFO - 2018-04-10 21:28:58 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-04-10 21:28:58 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 21:28:58 --> Final output sent to browser
DEBUG - 2018-04-10 21:28:58 --> Total execution time: 0.4009
INFO - 2018-04-10 21:28:58 --> Config Class Initialized
INFO - 2018-04-10 21:28:58 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:28:58 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:28:58 --> Utf8 Class Initialized
INFO - 2018-04-10 21:28:59 --> URI Class Initialized
INFO - 2018-04-10 21:28:59 --> Router Class Initialized
INFO - 2018-04-10 21:28:59 --> Output Class Initialized
INFO - 2018-04-10 21:28:59 --> Security Class Initialized
DEBUG - 2018-04-10 21:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:28:59 --> Config Class Initialized
INFO - 2018-04-10 21:28:59 --> Config Class Initialized
INFO - 2018-04-10 21:28:59 --> Config Class Initialized
INFO - 2018-04-10 21:28:59 --> Hooks Class Initialized
INFO - 2018-04-10 21:28:59 --> Hooks Class Initialized
INFO - 2018-04-10 21:28:59 --> CSRF cookie sent
INFO - 2018-04-10 21:28:59 --> Hooks Class Initialized
INFO - 2018-04-10 21:28:59 --> Input Class Initialized
DEBUG - 2018-04-10 21:28:59 --> UTF-8 Support Enabled
DEBUG - 2018-04-10 21:28:59 --> UTF-8 Support Enabled
DEBUG - 2018-04-10 21:28:59 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:28:59 --> Utf8 Class Initialized
INFO - 2018-04-10 21:28:59 --> Utf8 Class Initialized
INFO - 2018-04-10 21:28:59 --> Utf8 Class Initialized
INFO - 2018-04-10 21:28:59 --> Language Class Initialized
INFO - 2018-04-10 21:28:59 --> URI Class Initialized
INFO - 2018-04-10 21:28:59 --> URI Class Initialized
ERROR - 2018-04-10 21:28:59 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 21:28:59 --> URI Class Initialized
INFO - 2018-04-10 21:28:59 --> Router Class Initialized
INFO - 2018-04-10 21:28:59 --> Router Class Initialized
INFO - 2018-04-10 21:28:59 --> Router Class Initialized
INFO - 2018-04-10 21:28:59 --> Output Class Initialized
INFO - 2018-04-10 21:28:59 --> Output Class Initialized
INFO - 2018-04-10 21:28:59 --> Output Class Initialized
INFO - 2018-04-10 21:28:59 --> Security Class Initialized
INFO - 2018-04-10 21:28:59 --> Security Class Initialized
INFO - 2018-04-10 21:28:59 --> Security Class Initialized
DEBUG - 2018-04-10 21:28:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-10 21:28:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-10 21:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:28:59 --> CSRF cookie sent
INFO - 2018-04-10 21:28:59 --> CSRF cookie sent
INFO - 2018-04-10 21:28:59 --> CSRF cookie sent
INFO - 2018-04-10 21:28:59 --> Input Class Initialized
INFO - 2018-04-10 21:28:59 --> Input Class Initialized
INFO - 2018-04-10 21:28:59 --> Input Class Initialized
INFO - 2018-04-10 21:28:59 --> Language Class Initialized
INFO - 2018-04-10 21:28:59 --> Language Class Initialized
INFO - 2018-04-10 21:28:59 --> Language Class Initialized
ERROR - 2018-04-10 21:28:59 --> 404 Page Not Found: Sign-in/assets
ERROR - 2018-04-10 21:28:59 --> 404 Page Not Found: Sign-in/assets
ERROR - 2018-04-10 21:28:59 --> 404 Page Not Found: Sign-in/assets
INFO - 2018-04-10 21:29:05 --> Config Class Initialized
INFO - 2018-04-10 21:29:05 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:29:05 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:29:05 --> Utf8 Class Initialized
INFO - 2018-04-10 21:29:05 --> URI Class Initialized
INFO - 2018-04-10 21:29:05 --> Router Class Initialized
INFO - 2018-04-10 21:29:05 --> Output Class Initialized
INFO - 2018-04-10 21:29:05 --> Security Class Initialized
DEBUG - 2018-04-10 21:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:29:05 --> CSRF cookie sent
INFO - 2018-04-10 21:29:05 --> Input Class Initialized
INFO - 2018-04-10 21:29:05 --> Language Class Initialized
INFO - 2018-04-10 21:29:05 --> Loader Class Initialized
INFO - 2018-04-10 21:29:05 --> Helper loaded: url_helper
INFO - 2018-04-10 21:29:05 --> Helper loaded: form_helper
INFO - 2018-04-10 21:29:05 --> Helper loaded: language_helper
DEBUG - 2018-04-10 21:29:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 21:29:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 21:29:05 --> User Agent Class Initialized
INFO - 2018-04-10 21:29:05 --> Controller Class Initialized
INFO - 2018-04-10 21:29:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 21:29:05 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 21:29:05 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 21:29:05 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 21:29:05 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 21:29:05 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-10 21:29:05 --> Could not find the language line "req_email"
INFO - 2018-04-10 21:29:05 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-04-10 21:29:05 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 21:29:05 --> Final output sent to browser
DEBUG - 2018-04-10 21:29:05 --> Total execution time: 0.3999
INFO - 2018-04-10 21:29:06 --> Config Class Initialized
INFO - 2018-04-10 21:29:06 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:29:06 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:29:06 --> Utf8 Class Initialized
INFO - 2018-04-10 21:29:06 --> URI Class Initialized
INFO - 2018-04-10 21:29:06 --> Router Class Initialized
INFO - 2018-04-10 21:29:06 --> Output Class Initialized
INFO - 2018-04-10 21:29:06 --> Security Class Initialized
DEBUG - 2018-04-10 21:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:29:06 --> CSRF cookie sent
INFO - 2018-04-10 21:29:06 --> Input Class Initialized
INFO - 2018-04-10 21:29:06 --> Language Class Initialized
ERROR - 2018-04-10 21:29:06 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 21:29:09 --> Config Class Initialized
INFO - 2018-04-10 21:29:09 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:29:09 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:29:09 --> Utf8 Class Initialized
INFO - 2018-04-10 21:29:09 --> URI Class Initialized
INFO - 2018-04-10 21:29:10 --> Router Class Initialized
INFO - 2018-04-10 21:29:10 --> Output Class Initialized
INFO - 2018-04-10 21:29:10 --> Security Class Initialized
DEBUG - 2018-04-10 21:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:29:10 --> CSRF cookie sent
INFO - 2018-04-10 21:29:10 --> Input Class Initialized
INFO - 2018-04-10 21:29:10 --> Language Class Initialized
INFO - 2018-04-10 21:29:10 --> Loader Class Initialized
INFO - 2018-04-10 21:29:10 --> Helper loaded: url_helper
INFO - 2018-04-10 21:29:10 --> Helper loaded: form_helper
INFO - 2018-04-10 21:29:10 --> Helper loaded: language_helper
DEBUG - 2018-04-10 21:29:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 21:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 21:29:10 --> User Agent Class Initialized
INFO - 2018-04-10 21:29:10 --> Controller Class Initialized
INFO - 2018-04-10 21:29:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 21:29:10 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 21:29:10 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 21:29:10 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 21:29:10 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 21:29:10 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-10 21:29:10 --> Could not find the language line "req_email"
INFO - 2018-04-10 21:29:10 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-04-10 21:29:10 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 21:29:10 --> Final output sent to browser
DEBUG - 2018-04-10 21:29:10 --> Total execution time: 0.4620
INFO - 2018-04-10 21:29:10 --> Config Class Initialized
INFO - 2018-04-10 21:29:10 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:29:10 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:29:10 --> Utf8 Class Initialized
INFO - 2018-04-10 21:29:10 --> URI Class Initialized
INFO - 2018-04-10 21:29:10 --> Router Class Initialized
INFO - 2018-04-10 21:29:10 --> Output Class Initialized
INFO - 2018-04-10 21:29:10 --> Security Class Initialized
DEBUG - 2018-04-10 21:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:29:10 --> CSRF cookie sent
INFO - 2018-04-10 21:29:10 --> Input Class Initialized
INFO - 2018-04-10 21:29:10 --> Language Class Initialized
INFO - 2018-04-10 21:29:10 --> Config Class Initialized
INFO - 2018-04-10 21:29:10 --> Config Class Initialized
INFO - 2018-04-10 21:29:10 --> Config Class Initialized
INFO - 2018-04-10 21:29:10 --> Hooks Class Initialized
INFO - 2018-04-10 21:29:10 --> Hooks Class Initialized
INFO - 2018-04-10 21:29:10 --> Hooks Class Initialized
ERROR - 2018-04-10 21:29:10 --> 404 Page Not Found: Assets/css
DEBUG - 2018-04-10 21:29:11 --> UTF-8 Support Enabled
DEBUG - 2018-04-10 21:29:11 --> UTF-8 Support Enabled
DEBUG - 2018-04-10 21:29:11 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:29:11 --> Utf8 Class Initialized
INFO - 2018-04-10 21:29:11 --> Utf8 Class Initialized
INFO - 2018-04-10 21:29:11 --> Utf8 Class Initialized
INFO - 2018-04-10 21:29:11 --> URI Class Initialized
INFO - 2018-04-10 21:29:11 --> URI Class Initialized
INFO - 2018-04-10 21:29:11 --> URI Class Initialized
INFO - 2018-04-10 21:29:11 --> Router Class Initialized
INFO - 2018-04-10 21:29:11 --> Router Class Initialized
INFO - 2018-04-10 21:29:11 --> Router Class Initialized
INFO - 2018-04-10 21:29:11 --> Output Class Initialized
INFO - 2018-04-10 21:29:11 --> Output Class Initialized
INFO - 2018-04-10 21:29:11 --> Output Class Initialized
INFO - 2018-04-10 21:29:11 --> Security Class Initialized
INFO - 2018-04-10 21:29:11 --> Security Class Initialized
INFO - 2018-04-10 21:29:11 --> Security Class Initialized
DEBUG - 2018-04-10 21:29:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-10 21:29:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-10 21:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:29:11 --> CSRF cookie sent
INFO - 2018-04-10 21:29:11 --> CSRF cookie sent
INFO - 2018-04-10 21:29:11 --> CSRF cookie sent
INFO - 2018-04-10 21:29:11 --> Input Class Initialized
INFO - 2018-04-10 21:29:11 --> Input Class Initialized
INFO - 2018-04-10 21:29:11 --> Input Class Initialized
INFO - 2018-04-10 21:29:11 --> Language Class Initialized
INFO - 2018-04-10 21:29:11 --> Language Class Initialized
INFO - 2018-04-10 21:29:11 --> Language Class Initialized
ERROR - 2018-04-10 21:29:11 --> 404 Page Not Found: Sign-in/assets
ERROR - 2018-04-10 21:29:11 --> 404 Page Not Found: Sign-in/assets
ERROR - 2018-04-10 21:29:11 --> 404 Page Not Found: Sign-in/assets
INFO - 2018-04-10 21:29:14 --> Config Class Initialized
INFO - 2018-04-10 21:29:14 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:29:14 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:29:14 --> Utf8 Class Initialized
INFO - 2018-04-10 21:29:14 --> URI Class Initialized
INFO - 2018-04-10 21:29:14 --> Router Class Initialized
INFO - 2018-04-10 21:29:14 --> Output Class Initialized
INFO - 2018-04-10 21:29:14 --> Security Class Initialized
DEBUG - 2018-04-10 21:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:29:14 --> CSRF cookie sent
INFO - 2018-04-10 21:29:14 --> Input Class Initialized
INFO - 2018-04-10 21:29:14 --> Language Class Initialized
INFO - 2018-04-10 21:29:14 --> Loader Class Initialized
INFO - 2018-04-10 21:29:14 --> Helper loaded: url_helper
INFO - 2018-04-10 21:29:14 --> Helper loaded: form_helper
INFO - 2018-04-10 21:29:14 --> Helper loaded: language_helper
DEBUG - 2018-04-10 21:29:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 21:29:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 21:29:14 --> User Agent Class Initialized
INFO - 2018-04-10 21:29:14 --> Controller Class Initialized
INFO - 2018-04-10 21:29:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 21:29:14 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 21:29:14 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 21:29:14 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 21:29:14 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 21:29:14 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-10 21:29:14 --> Could not find the language line "req_email"
INFO - 2018-04-10 21:29:14 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-04-10 21:29:14 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 21:29:14 --> Final output sent to browser
DEBUG - 2018-04-10 21:29:14 --> Total execution time: 0.4598
INFO - 2018-04-10 21:29:15 --> Config Class Initialized
INFO - 2018-04-10 21:29:15 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:29:15 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:29:15 --> Utf8 Class Initialized
INFO - 2018-04-10 21:29:15 --> URI Class Initialized
INFO - 2018-04-10 21:29:15 --> Router Class Initialized
INFO - 2018-04-10 21:29:15 --> Output Class Initialized
INFO - 2018-04-10 21:29:15 --> Security Class Initialized
DEBUG - 2018-04-10 21:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:29:15 --> CSRF cookie sent
INFO - 2018-04-10 21:29:15 --> Input Class Initialized
INFO - 2018-04-10 21:29:15 --> Language Class Initialized
ERROR - 2018-04-10 21:29:15 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 21:31:23 --> Config Class Initialized
INFO - 2018-04-10 21:31:23 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:31:23 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:31:23 --> Utf8 Class Initialized
INFO - 2018-04-10 21:31:23 --> URI Class Initialized
DEBUG - 2018-04-10 21:31:23 --> No URI present. Default controller set.
INFO - 2018-04-10 21:31:23 --> Router Class Initialized
INFO - 2018-04-10 21:31:23 --> Output Class Initialized
INFO - 2018-04-10 21:31:23 --> Security Class Initialized
DEBUG - 2018-04-10 21:31:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:31:23 --> CSRF cookie sent
INFO - 2018-04-10 21:31:23 --> Input Class Initialized
INFO - 2018-04-10 21:31:23 --> Language Class Initialized
INFO - 2018-04-10 21:31:23 --> Loader Class Initialized
INFO - 2018-04-10 21:31:23 --> Helper loaded: url_helper
INFO - 2018-04-10 21:31:23 --> Helper loaded: form_helper
INFO - 2018-04-10 21:31:23 --> Helper loaded: language_helper
DEBUG - 2018-04-10 21:31:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 21:31:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 21:31:23 --> User Agent Class Initialized
INFO - 2018-04-10 21:31:23 --> Controller Class Initialized
INFO - 2018-04-10 21:31:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 21:31:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-10 21:31:23 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 21:31:23 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-10 21:31:23 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 21:31:23 --> Final output sent to browser
DEBUG - 2018-04-10 21:31:23 --> Total execution time: 0.8372
INFO - 2018-04-10 21:31:27 --> Config Class Initialized
INFO - 2018-04-10 21:31:27 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:31:27 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:31:27 --> Utf8 Class Initialized
INFO - 2018-04-10 21:31:27 --> URI Class Initialized
INFO - 2018-04-10 21:31:27 --> Router Class Initialized
INFO - 2018-04-10 21:31:27 --> Output Class Initialized
INFO - 2018-04-10 21:31:27 --> Security Class Initialized
DEBUG - 2018-04-10 21:31:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:31:27 --> CSRF cookie sent
INFO - 2018-04-10 21:31:27 --> Input Class Initialized
INFO - 2018-04-10 21:31:27 --> Language Class Initialized
INFO - 2018-04-10 21:31:27 --> Loader Class Initialized
INFO - 2018-04-10 21:31:27 --> Helper loaded: url_helper
INFO - 2018-04-10 21:31:27 --> Helper loaded: form_helper
INFO - 2018-04-10 21:31:27 --> Helper loaded: language_helper
DEBUG - 2018-04-10 21:31:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 21:31:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 21:31:27 --> User Agent Class Initialized
INFO - 2018-04-10 21:31:27 --> Controller Class Initialized
INFO - 2018-04-10 21:31:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 21:31:27 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 21:31:27 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 21:31:27 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 21:31:27 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 21:31:27 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-10 21:31:27 --> Could not find the language line "req_email"
INFO - 2018-04-10 21:31:27 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-04-10 21:31:27 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 21:31:27 --> Final output sent to browser
DEBUG - 2018-04-10 21:31:27 --> Total execution time: 0.4473
INFO - 2018-04-10 21:31:38 --> Config Class Initialized
INFO - 2018-04-10 21:31:38 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:31:38 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:31:38 --> Utf8 Class Initialized
INFO - 2018-04-10 21:31:38 --> URI Class Initialized
INFO - 2018-04-10 21:31:38 --> Router Class Initialized
INFO - 2018-04-10 21:31:38 --> Output Class Initialized
INFO - 2018-04-10 21:31:38 --> Security Class Initialized
DEBUG - 2018-04-10 21:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:31:38 --> CSRF cookie sent
INFO - 2018-04-10 21:31:38 --> CSRF token verified
INFO - 2018-04-10 21:31:38 --> Input Class Initialized
INFO - 2018-04-10 21:31:39 --> Language Class Initialized
INFO - 2018-04-10 21:31:39 --> Loader Class Initialized
INFO - 2018-04-10 21:31:39 --> Helper loaded: url_helper
INFO - 2018-04-10 21:31:39 --> Helper loaded: form_helper
INFO - 2018-04-10 21:31:39 --> Helper loaded: language_helper
DEBUG - 2018-04-10 21:31:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 21:31:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 21:31:39 --> User Agent Class Initialized
INFO - 2018-04-10 21:31:39 --> Controller Class Initialized
INFO - 2018-04-10 21:31:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 21:31:39 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 21:31:39 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 21:31:39 --> Form Validation Class Initialized
INFO - 2018-04-10 21:31:39 --> Pixel_Model class loaded
INFO - 2018-04-10 21:31:39 --> Database Driver Class Initialized
INFO - 2018-04-10 21:31:48 --> Model "AuthenticationModel" initialized
INFO - 2018-04-10 21:31:48 --> Config Class Initialized
INFO - 2018-04-10 21:31:48 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:31:48 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:31:48 --> Utf8 Class Initialized
INFO - 2018-04-10 21:31:48 --> URI Class Initialized
INFO - 2018-04-10 21:31:48 --> Router Class Initialized
INFO - 2018-04-10 21:31:48 --> Output Class Initialized
INFO - 2018-04-10 21:31:48 --> Security Class Initialized
DEBUG - 2018-04-10 21:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:31:48 --> CSRF cookie sent
INFO - 2018-04-10 21:31:48 --> Input Class Initialized
INFO - 2018-04-10 21:31:48 --> Language Class Initialized
INFO - 2018-04-10 21:31:48 --> Loader Class Initialized
INFO - 2018-04-10 21:31:48 --> Helper loaded: url_helper
INFO - 2018-04-10 21:31:48 --> Helper loaded: form_helper
INFO - 2018-04-10 21:31:48 --> Helper loaded: language_helper
DEBUG - 2018-04-10 21:31:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 21:31:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 21:31:49 --> User Agent Class Initialized
INFO - 2018-04-10 21:31:49 --> Controller Class Initialized
INFO - 2018-04-10 21:31:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 21:31:49 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 21:31:49 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 21:31:49 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 21:31:49 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 21:31:49 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-10 21:31:49 --> File loaded: E:\www\yacopoo\application\views\shared/_soft_error.php
ERROR - 2018-04-10 21:31:49 --> Could not find the language line "req_email"
INFO - 2018-04-10 21:31:49 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-04-10 21:31:49 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 21:31:49 --> Final output sent to browser
DEBUG - 2018-04-10 21:31:49 --> Total execution time: 0.4091
INFO - 2018-04-10 21:33:32 --> Config Class Initialized
INFO - 2018-04-10 21:33:32 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:33:32 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:33:32 --> Utf8 Class Initialized
INFO - 2018-04-10 21:33:32 --> URI Class Initialized
INFO - 2018-04-10 21:33:32 --> Router Class Initialized
INFO - 2018-04-10 21:33:32 --> Output Class Initialized
INFO - 2018-04-10 21:33:32 --> Security Class Initialized
DEBUG - 2018-04-10 21:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:33:32 --> CSRF cookie sent
INFO - 2018-04-10 21:33:32 --> CSRF token verified
INFO - 2018-04-10 21:33:32 --> Input Class Initialized
INFO - 2018-04-10 21:33:32 --> Language Class Initialized
INFO - 2018-04-10 21:33:32 --> Loader Class Initialized
INFO - 2018-04-10 21:33:32 --> Helper loaded: url_helper
INFO - 2018-04-10 21:33:32 --> Helper loaded: form_helper
INFO - 2018-04-10 21:33:32 --> Helper loaded: language_helper
DEBUG - 2018-04-10 21:33:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 21:33:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 21:33:32 --> User Agent Class Initialized
INFO - 2018-04-10 21:33:32 --> Controller Class Initialized
INFO - 2018-04-10 21:33:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 21:33:32 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 21:33:32 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 21:33:33 --> Form Validation Class Initialized
INFO - 2018-04-10 21:33:33 --> Pixel_Model class loaded
INFO - 2018-04-10 21:33:33 --> Database Driver Class Initialized
INFO - 2018-04-10 21:33:33 --> Model "AuthenticationModel" initialized
INFO - 2018-04-10 21:34:46 --> Config Class Initialized
INFO - 2018-04-10 21:34:46 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:34:46 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:34:46 --> Utf8 Class Initialized
INFO - 2018-04-10 21:34:46 --> URI Class Initialized
INFO - 2018-04-10 21:34:46 --> Router Class Initialized
INFO - 2018-04-10 21:34:46 --> Output Class Initialized
INFO - 2018-04-10 21:34:46 --> Security Class Initialized
DEBUG - 2018-04-10 21:34:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:34:46 --> CSRF cookie sent
INFO - 2018-04-10 21:34:46 --> CSRF token verified
INFO - 2018-04-10 21:34:46 --> Input Class Initialized
INFO - 2018-04-10 21:34:46 --> Language Class Initialized
INFO - 2018-04-10 21:34:46 --> Loader Class Initialized
INFO - 2018-04-10 21:34:46 --> Helper loaded: url_helper
INFO - 2018-04-10 21:34:46 --> Helper loaded: form_helper
INFO - 2018-04-10 21:34:46 --> Helper loaded: language_helper
DEBUG - 2018-04-10 21:34:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 21:34:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 21:34:46 --> User Agent Class Initialized
INFO - 2018-04-10 21:34:46 --> Controller Class Initialized
INFO - 2018-04-10 21:34:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 21:34:46 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 21:34:46 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 21:34:47 --> Config Class Initialized
INFO - 2018-04-10 21:34:47 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:34:47 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:34:47 --> Utf8 Class Initialized
INFO - 2018-04-10 21:34:47 --> URI Class Initialized
INFO - 2018-04-10 21:34:47 --> Router Class Initialized
INFO - 2018-04-10 21:34:47 --> Output Class Initialized
INFO - 2018-04-10 21:34:47 --> Security Class Initialized
DEBUG - 2018-04-10 21:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:34:47 --> CSRF cookie sent
INFO - 2018-04-10 21:34:47 --> Input Class Initialized
INFO - 2018-04-10 21:34:47 --> Language Class Initialized
INFO - 2018-04-10 21:34:47 --> Loader Class Initialized
INFO - 2018-04-10 21:34:47 --> Helper loaded: url_helper
INFO - 2018-04-10 21:34:47 --> Helper loaded: form_helper
INFO - 2018-04-10 21:34:47 --> Helper loaded: language_helper
DEBUG - 2018-04-10 21:34:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 21:34:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 21:34:47 --> User Agent Class Initialized
INFO - 2018-04-10 21:34:47 --> Controller Class Initialized
INFO - 2018-04-10 21:34:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 21:34:47 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 21:34:47 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 21:34:47 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 21:34:47 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 21:34:47 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-10 21:34:47 --> File loaded: E:\www\yacopoo\application\views\shared/_soft_error.php
ERROR - 2018-04-10 21:34:47 --> Could not find the language line "req_email"
INFO - 2018-04-10 21:34:47 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-04-10 21:34:47 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 21:34:47 --> Final output sent to browser
DEBUG - 2018-04-10 21:34:47 --> Total execution time: 0.4151
INFO - 2018-04-10 21:34:47 --> Config Class Initialized
INFO - 2018-04-10 21:34:47 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:34:47 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:34:47 --> Utf8 Class Initialized
INFO - 2018-04-10 21:34:47 --> URI Class Initialized
INFO - 2018-04-10 21:34:48 --> Router Class Initialized
INFO - 2018-04-10 21:34:48 --> Output Class Initialized
INFO - 2018-04-10 21:34:48 --> Security Class Initialized
DEBUG - 2018-04-10 21:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:34:48 --> CSRF cookie sent
INFO - 2018-04-10 21:34:48 --> Input Class Initialized
INFO - 2018-04-10 21:34:48 --> Language Class Initialized
ERROR - 2018-04-10 21:34:48 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 21:35:31 --> Config Class Initialized
INFO - 2018-04-10 21:35:31 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:35:31 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:35:31 --> Utf8 Class Initialized
INFO - 2018-04-10 21:35:31 --> URI Class Initialized
INFO - 2018-04-10 21:35:31 --> Router Class Initialized
INFO - 2018-04-10 21:35:31 --> Output Class Initialized
INFO - 2018-04-10 21:35:31 --> Security Class Initialized
DEBUG - 2018-04-10 21:35:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:35:31 --> CSRF cookie sent
INFO - 2018-04-10 21:35:31 --> CSRF token verified
INFO - 2018-04-10 21:35:31 --> Input Class Initialized
INFO - 2018-04-10 21:35:31 --> Language Class Initialized
INFO - 2018-04-10 21:35:31 --> Loader Class Initialized
INFO - 2018-04-10 21:35:31 --> Helper loaded: url_helper
INFO - 2018-04-10 21:35:31 --> Helper loaded: form_helper
INFO - 2018-04-10 21:35:31 --> Helper loaded: language_helper
DEBUG - 2018-04-10 21:35:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 21:35:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 21:35:31 --> User Agent Class Initialized
INFO - 2018-04-10 21:35:31 --> Controller Class Initialized
INFO - 2018-04-10 21:35:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 21:35:31 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 21:35:31 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 21:35:31 --> Form Validation Class Initialized
INFO - 2018-04-10 21:35:31 --> Pixel_Model class loaded
INFO - 2018-04-10 21:35:31 --> Database Driver Class Initialized
INFO - 2018-04-10 21:35:34 --> Model "AuthenticationModel" initialized
INFO - 2018-04-10 21:35:34 --> Config Class Initialized
INFO - 2018-04-10 21:35:34 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:35:34 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:35:34 --> Utf8 Class Initialized
INFO - 2018-04-10 21:35:34 --> URI Class Initialized
INFO - 2018-04-10 21:35:34 --> Router Class Initialized
INFO - 2018-04-10 21:35:34 --> Output Class Initialized
INFO - 2018-04-10 21:35:34 --> Security Class Initialized
DEBUG - 2018-04-10 21:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:35:34 --> CSRF cookie sent
INFO - 2018-04-10 21:35:35 --> Input Class Initialized
INFO - 2018-04-10 21:35:35 --> Language Class Initialized
INFO - 2018-04-10 21:35:35 --> Loader Class Initialized
INFO - 2018-04-10 21:35:35 --> Helper loaded: url_helper
INFO - 2018-04-10 21:35:35 --> Helper loaded: form_helper
INFO - 2018-04-10 21:35:35 --> Helper loaded: language_helper
DEBUG - 2018-04-10 21:35:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 21:35:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 21:35:35 --> User Agent Class Initialized
INFO - 2018-04-10 21:35:35 --> Controller Class Initialized
INFO - 2018-04-10 21:35:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 21:35:35 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 21:35:35 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 21:35:35 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 21:35:35 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 21:35:35 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-10 21:35:35 --> File loaded: E:\www\yacopoo\application\views\shared/_soft_error.php
ERROR - 2018-04-10 21:35:35 --> Could not find the language line "req_email"
INFO - 2018-04-10 21:35:35 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-04-10 21:35:35 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 21:35:35 --> Final output sent to browser
DEBUG - 2018-04-10 21:35:35 --> Total execution time: 0.4213
INFO - 2018-04-10 21:35:35 --> Config Class Initialized
INFO - 2018-04-10 21:35:35 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:35:35 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:35:35 --> Utf8 Class Initialized
INFO - 2018-04-10 21:35:35 --> URI Class Initialized
INFO - 2018-04-10 21:35:35 --> Router Class Initialized
INFO - 2018-04-10 21:35:35 --> Output Class Initialized
INFO - 2018-04-10 21:35:35 --> Security Class Initialized
DEBUG - 2018-04-10 21:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:35:35 --> CSRF cookie sent
INFO - 2018-04-10 21:35:35 --> Input Class Initialized
INFO - 2018-04-10 21:35:35 --> Language Class Initialized
ERROR - 2018-04-10 21:35:35 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 21:35:55 --> Config Class Initialized
INFO - 2018-04-10 21:35:55 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:35:55 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:35:55 --> Utf8 Class Initialized
INFO - 2018-04-10 21:35:55 --> URI Class Initialized
INFO - 2018-04-10 21:35:55 --> Router Class Initialized
INFO - 2018-04-10 21:35:55 --> Output Class Initialized
INFO - 2018-04-10 21:35:56 --> Security Class Initialized
DEBUG - 2018-04-10 21:35:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:35:56 --> CSRF cookie sent
INFO - 2018-04-10 21:35:56 --> CSRF token verified
INFO - 2018-04-10 21:35:56 --> Input Class Initialized
INFO - 2018-04-10 21:35:56 --> Language Class Initialized
INFO - 2018-04-10 21:35:56 --> Loader Class Initialized
INFO - 2018-04-10 21:35:56 --> Helper loaded: url_helper
INFO - 2018-04-10 21:35:56 --> Helper loaded: form_helper
INFO - 2018-04-10 21:35:56 --> Helper loaded: language_helper
DEBUG - 2018-04-10 21:35:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 21:35:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 21:35:56 --> User Agent Class Initialized
INFO - 2018-04-10 21:35:56 --> Controller Class Initialized
INFO - 2018-04-10 21:35:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 21:35:56 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 21:35:56 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 21:35:56 --> Form Validation Class Initialized
INFO - 2018-04-10 21:35:56 --> Pixel_Model class loaded
INFO - 2018-04-10 21:35:56 --> Database Driver Class Initialized
INFO - 2018-04-10 21:35:59 --> Model "AuthenticationModel" initialized
INFO - 2018-04-10 21:35:59 --> Config Class Initialized
INFO - 2018-04-10 21:35:59 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:35:59 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:35:59 --> Utf8 Class Initialized
INFO - 2018-04-10 21:35:59 --> URI Class Initialized
INFO - 2018-04-10 21:35:59 --> Router Class Initialized
INFO - 2018-04-10 21:35:59 --> Output Class Initialized
INFO - 2018-04-10 21:35:59 --> Security Class Initialized
DEBUG - 2018-04-10 21:35:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:35:59 --> CSRF cookie sent
INFO - 2018-04-10 21:35:59 --> Input Class Initialized
INFO - 2018-04-10 21:35:59 --> Language Class Initialized
INFO - 2018-04-10 21:35:59 --> Loader Class Initialized
INFO - 2018-04-10 21:35:59 --> Helper loaded: url_helper
INFO - 2018-04-10 21:35:59 --> Helper loaded: form_helper
INFO - 2018-04-10 21:35:59 --> Helper loaded: language_helper
DEBUG - 2018-04-10 21:35:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 21:35:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 21:35:59 --> User Agent Class Initialized
INFO - 2018-04-10 21:35:59 --> Controller Class Initialized
INFO - 2018-04-10 21:35:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 21:35:59 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 21:35:59 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 21:36:00 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 21:36:00 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 21:36:00 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-10 21:36:00 --> File loaded: E:\www\yacopoo\application\views\shared/_soft_error.php
ERROR - 2018-04-10 21:36:00 --> Could not find the language line "req_email"
INFO - 2018-04-10 21:36:00 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-04-10 21:36:00 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 21:36:00 --> Final output sent to browser
DEBUG - 2018-04-10 21:36:00 --> Total execution time: 0.4298
INFO - 2018-04-10 21:36:00 --> Config Class Initialized
INFO - 2018-04-10 21:36:00 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:36:00 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:36:00 --> Utf8 Class Initialized
INFO - 2018-04-10 21:36:00 --> URI Class Initialized
INFO - 2018-04-10 21:36:00 --> Router Class Initialized
INFO - 2018-04-10 21:36:00 --> Output Class Initialized
INFO - 2018-04-10 21:36:00 --> Security Class Initialized
DEBUG - 2018-04-10 21:36:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:36:00 --> CSRF cookie sent
INFO - 2018-04-10 21:36:00 --> Input Class Initialized
INFO - 2018-04-10 21:36:00 --> Language Class Initialized
ERROR - 2018-04-10 21:36:00 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 21:53:00 --> Config Class Initialized
INFO - 2018-04-10 21:53:00 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:53:00 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:53:00 --> Utf8 Class Initialized
INFO - 2018-04-10 21:53:00 --> URI Class Initialized
INFO - 2018-04-10 21:53:00 --> Router Class Initialized
INFO - 2018-04-10 21:53:00 --> Output Class Initialized
INFO - 2018-04-10 21:53:00 --> Security Class Initialized
DEBUG - 2018-04-10 21:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:53:00 --> CSRF cookie sent
INFO - 2018-04-10 21:53:00 --> CSRF token verified
INFO - 2018-04-10 21:53:00 --> Input Class Initialized
INFO - 2018-04-10 21:53:00 --> Language Class Initialized
INFO - 2018-04-10 21:53:00 --> Loader Class Initialized
INFO - 2018-04-10 21:53:00 --> Helper loaded: url_helper
INFO - 2018-04-10 21:53:00 --> Helper loaded: form_helper
INFO - 2018-04-10 21:53:00 --> Helper loaded: language_helper
DEBUG - 2018-04-10 21:53:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 21:53:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 21:53:00 --> User Agent Class Initialized
INFO - 2018-04-10 21:53:00 --> Controller Class Initialized
INFO - 2018-04-10 21:53:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 21:53:00 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 21:53:00 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 21:53:00 --> Form Validation Class Initialized
INFO - 2018-04-10 21:53:00 --> Pixel_Model class loaded
INFO - 2018-04-10 21:53:01 --> Database Driver Class Initialized
INFO - 2018-04-10 21:53:04 --> Model "AuthenticationModel" initialized
INFO - 2018-04-10 21:53:38 --> Config Class Initialized
INFO - 2018-04-10 21:53:38 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:53:38 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:53:38 --> Utf8 Class Initialized
INFO - 2018-04-10 21:53:38 --> URI Class Initialized
INFO - 2018-04-10 21:53:38 --> Router Class Initialized
INFO - 2018-04-10 21:53:38 --> Output Class Initialized
INFO - 2018-04-10 21:53:38 --> Security Class Initialized
DEBUG - 2018-04-10 21:53:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:53:38 --> CSRF cookie sent
INFO - 2018-04-10 21:53:38 --> CSRF token verified
INFO - 2018-04-10 21:53:38 --> Input Class Initialized
INFO - 2018-04-10 21:53:38 --> Language Class Initialized
INFO - 2018-04-10 21:53:38 --> Loader Class Initialized
INFO - 2018-04-10 21:53:38 --> Helper loaded: url_helper
INFO - 2018-04-10 21:53:38 --> Helper loaded: form_helper
INFO - 2018-04-10 21:53:38 --> Helper loaded: language_helper
DEBUG - 2018-04-10 21:53:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 21:53:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 21:53:39 --> User Agent Class Initialized
INFO - 2018-04-10 21:53:39 --> Controller Class Initialized
INFO - 2018-04-10 21:53:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 21:53:39 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 21:53:39 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 21:53:39 --> Form Validation Class Initialized
INFO - 2018-04-10 21:53:39 --> Pixel_Model class loaded
INFO - 2018-04-10 21:53:39 --> Database Driver Class Initialized
INFO - 2018-04-10 21:53:39 --> Model "AuthenticationModel" initialized
INFO - 2018-04-10 21:53:39 --> Config Class Initialized
INFO - 2018-04-10 21:53:39 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:53:39 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:53:39 --> Utf8 Class Initialized
INFO - 2018-04-10 21:53:39 --> URI Class Initialized
DEBUG - 2018-04-10 21:53:39 --> No URI present. Default controller set.
INFO - 2018-04-10 21:53:39 --> Router Class Initialized
INFO - 2018-04-10 21:53:39 --> Output Class Initialized
INFO - 2018-04-10 21:53:39 --> Security Class Initialized
DEBUG - 2018-04-10 21:53:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:53:39 --> CSRF cookie sent
INFO - 2018-04-10 21:53:39 --> Input Class Initialized
INFO - 2018-04-10 21:53:39 --> Language Class Initialized
INFO - 2018-04-10 21:53:39 --> Loader Class Initialized
INFO - 2018-04-10 21:53:39 --> Helper loaded: url_helper
INFO - 2018-04-10 21:53:39 --> Helper loaded: form_helper
INFO - 2018-04-10 21:53:39 --> Helper loaded: language_helper
DEBUG - 2018-04-10 21:53:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 21:53:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 21:53:39 --> User Agent Class Initialized
INFO - 2018-04-10 21:53:39 --> Controller Class Initialized
INFO - 2018-04-10 21:53:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 21:53:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-10 21:53:39 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 21:53:39 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-10 21:53:39 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 21:53:39 --> Final output sent to browser
DEBUG - 2018-04-10 21:53:39 --> Total execution time: 0.4570
INFO - 2018-04-10 21:53:40 --> Config Class Initialized
INFO - 2018-04-10 21:53:40 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:53:40 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:53:40 --> Utf8 Class Initialized
INFO - 2018-04-10 21:53:40 --> URI Class Initialized
INFO - 2018-04-10 21:53:40 --> Router Class Initialized
INFO - 2018-04-10 21:53:40 --> Output Class Initialized
INFO - 2018-04-10 21:53:40 --> Security Class Initialized
DEBUG - 2018-04-10 21:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:53:40 --> CSRF cookie sent
INFO - 2018-04-10 21:53:40 --> Input Class Initialized
INFO - 2018-04-10 21:53:40 --> Language Class Initialized
ERROR - 2018-04-10 21:53:40 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 21:53:41 --> Config Class Initialized
INFO - 2018-04-10 21:53:41 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:53:42 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:53:42 --> Utf8 Class Initialized
INFO - 2018-04-10 21:53:42 --> URI Class Initialized
INFO - 2018-04-10 21:53:42 --> Router Class Initialized
INFO - 2018-04-10 21:53:42 --> Output Class Initialized
INFO - 2018-04-10 21:53:42 --> Security Class Initialized
DEBUG - 2018-04-10 21:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:53:42 --> CSRF cookie sent
INFO - 2018-04-10 21:53:42 --> Input Class Initialized
INFO - 2018-04-10 21:53:42 --> Language Class Initialized
ERROR - 2018-04-10 21:53:42 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-10 21:53:47 --> Config Class Initialized
INFO - 2018-04-10 21:53:47 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:53:47 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:53:47 --> Utf8 Class Initialized
INFO - 2018-04-10 21:53:47 --> URI Class Initialized
INFO - 2018-04-10 21:53:47 --> Router Class Initialized
INFO - 2018-04-10 21:53:47 --> Output Class Initialized
INFO - 2018-04-10 21:53:47 --> Security Class Initialized
DEBUG - 2018-04-10 21:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:53:47 --> CSRF cookie sent
INFO - 2018-04-10 21:53:47 --> Input Class Initialized
INFO - 2018-04-10 21:53:47 --> Language Class Initialized
INFO - 2018-04-10 21:53:47 --> Loader Class Initialized
INFO - 2018-04-10 21:53:47 --> Helper loaded: url_helper
INFO - 2018-04-10 21:53:47 --> Helper loaded: form_helper
INFO - 2018-04-10 21:53:47 --> Helper loaded: language_helper
DEBUG - 2018-04-10 21:53:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 21:53:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 21:53:47 --> User Agent Class Initialized
INFO - 2018-04-10 21:53:47 --> Controller Class Initialized
INFO - 2018-04-10 21:53:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 21:53:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-10 21:53:47 --> CSRF cookie sent
INFO - 2018-04-10 21:53:47 --> Config Class Initialized
INFO - 2018-04-10 21:53:47 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:53:47 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:53:47 --> Utf8 Class Initialized
INFO - 2018-04-10 21:53:47 --> URI Class Initialized
DEBUG - 2018-04-10 21:53:47 --> No URI present. Default controller set.
INFO - 2018-04-10 21:53:47 --> Router Class Initialized
INFO - 2018-04-10 21:53:47 --> Output Class Initialized
INFO - 2018-04-10 21:53:47 --> Security Class Initialized
DEBUG - 2018-04-10 21:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:53:47 --> CSRF cookie sent
INFO - 2018-04-10 21:53:47 --> Input Class Initialized
INFO - 2018-04-10 21:53:47 --> Language Class Initialized
INFO - 2018-04-10 21:53:47 --> Loader Class Initialized
INFO - 2018-04-10 21:53:47 --> Helper loaded: url_helper
INFO - 2018-04-10 21:53:47 --> Helper loaded: form_helper
INFO - 2018-04-10 21:53:47 --> Helper loaded: language_helper
DEBUG - 2018-04-10 21:53:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 21:53:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 21:53:47 --> User Agent Class Initialized
INFO - 2018-04-10 21:53:47 --> Controller Class Initialized
INFO - 2018-04-10 21:53:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 21:53:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-10 21:53:47 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 21:53:47 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-10 21:53:47 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 21:53:47 --> Final output sent to browser
DEBUG - 2018-04-10 21:53:47 --> Total execution time: 0.3846
INFO - 2018-04-10 21:53:48 --> Config Class Initialized
INFO - 2018-04-10 21:53:48 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:53:48 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:53:48 --> Utf8 Class Initialized
INFO - 2018-04-10 21:53:48 --> URI Class Initialized
INFO - 2018-04-10 21:53:48 --> Router Class Initialized
INFO - 2018-04-10 21:53:48 --> Output Class Initialized
INFO - 2018-04-10 21:53:48 --> Security Class Initialized
DEBUG - 2018-04-10 21:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:53:48 --> CSRF cookie sent
INFO - 2018-04-10 21:53:48 --> Input Class Initialized
INFO - 2018-04-10 21:53:48 --> Language Class Initialized
ERROR - 2018-04-10 21:53:48 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 21:53:50 --> Config Class Initialized
INFO - 2018-04-10 21:53:50 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:53:50 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:53:50 --> Utf8 Class Initialized
INFO - 2018-04-10 21:53:50 --> URI Class Initialized
INFO - 2018-04-10 21:53:50 --> Router Class Initialized
INFO - 2018-04-10 21:53:50 --> Output Class Initialized
INFO - 2018-04-10 21:53:50 --> Security Class Initialized
DEBUG - 2018-04-10 21:53:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:53:50 --> CSRF cookie sent
INFO - 2018-04-10 21:53:50 --> Input Class Initialized
INFO - 2018-04-10 21:53:50 --> Language Class Initialized
ERROR - 2018-04-10 21:53:50 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-10 21:54:01 --> Config Class Initialized
INFO - 2018-04-10 21:54:01 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:54:01 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:54:01 --> Utf8 Class Initialized
INFO - 2018-04-10 21:54:01 --> URI Class Initialized
INFO - 2018-04-10 21:54:01 --> Router Class Initialized
INFO - 2018-04-10 21:54:01 --> Output Class Initialized
INFO - 2018-04-10 21:54:01 --> Security Class Initialized
DEBUG - 2018-04-10 21:54:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:54:01 --> CSRF cookie sent
INFO - 2018-04-10 21:54:01 --> Input Class Initialized
INFO - 2018-04-10 21:54:01 --> Language Class Initialized
INFO - 2018-04-10 21:54:01 --> Loader Class Initialized
INFO - 2018-04-10 21:54:01 --> Helper loaded: url_helper
INFO - 2018-04-10 21:54:01 --> Helper loaded: form_helper
INFO - 2018-04-10 21:54:01 --> Helper loaded: language_helper
DEBUG - 2018-04-10 21:54:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 21:54:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 21:54:01 --> User Agent Class Initialized
INFO - 2018-04-10 21:54:01 --> Controller Class Initialized
INFO - 2018-04-10 21:54:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 21:54:01 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 21:54:01 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 21:54:01 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 21:54:01 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 21:54:01 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-10 21:54:01 --> Could not find the language line "req_email"
INFO - 2018-04-10 21:54:01 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-04-10 21:54:01 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 21:54:01 --> Final output sent to browser
DEBUG - 2018-04-10 21:54:01 --> Total execution time: 0.4489
INFO - 2018-04-10 21:54:02 --> Config Class Initialized
INFO - 2018-04-10 21:54:02 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:54:02 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:54:02 --> Utf8 Class Initialized
INFO - 2018-04-10 21:54:02 --> URI Class Initialized
INFO - 2018-04-10 21:54:02 --> Router Class Initialized
INFO - 2018-04-10 21:54:02 --> Output Class Initialized
INFO - 2018-04-10 21:54:02 --> Security Class Initialized
DEBUG - 2018-04-10 21:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:54:02 --> CSRF cookie sent
INFO - 2018-04-10 21:54:02 --> Input Class Initialized
INFO - 2018-04-10 21:54:02 --> Language Class Initialized
ERROR - 2018-04-10 21:54:02 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 21:54:29 --> Config Class Initialized
INFO - 2018-04-10 21:54:29 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:54:29 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:54:29 --> Utf8 Class Initialized
INFO - 2018-04-10 21:54:29 --> URI Class Initialized
INFO - 2018-04-10 21:54:29 --> Router Class Initialized
INFO - 2018-04-10 21:54:29 --> Output Class Initialized
INFO - 2018-04-10 21:54:29 --> Security Class Initialized
DEBUG - 2018-04-10 21:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:54:29 --> CSRF cookie sent
INFO - 2018-04-10 21:54:29 --> CSRF token verified
INFO - 2018-04-10 21:54:29 --> Input Class Initialized
INFO - 2018-04-10 21:54:29 --> Language Class Initialized
INFO - 2018-04-10 21:54:29 --> Loader Class Initialized
INFO - 2018-04-10 21:54:30 --> Helper loaded: url_helper
INFO - 2018-04-10 21:54:30 --> Helper loaded: form_helper
INFO - 2018-04-10 21:54:30 --> Helper loaded: language_helper
DEBUG - 2018-04-10 21:54:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 21:54:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 21:54:30 --> User Agent Class Initialized
INFO - 2018-04-10 21:54:30 --> Controller Class Initialized
INFO - 2018-04-10 21:54:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 21:54:30 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 21:54:30 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 21:54:30 --> Form Validation Class Initialized
INFO - 2018-04-10 21:54:30 --> Pixel_Model class loaded
INFO - 2018-04-10 21:54:30 --> Database Driver Class Initialized
INFO - 2018-04-10 21:54:33 --> Model "AuthenticationModel" initialized
INFO - 2018-04-10 21:54:33 --> Config Class Initialized
INFO - 2018-04-10 21:54:33 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:54:33 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:54:33 --> Utf8 Class Initialized
INFO - 2018-04-10 21:54:33 --> URI Class Initialized
DEBUG - 2018-04-10 21:54:33 --> No URI present. Default controller set.
INFO - 2018-04-10 21:54:33 --> Router Class Initialized
INFO - 2018-04-10 21:54:33 --> Output Class Initialized
INFO - 2018-04-10 21:54:33 --> Security Class Initialized
DEBUG - 2018-04-10 21:54:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:54:33 --> CSRF cookie sent
INFO - 2018-04-10 21:54:33 --> Input Class Initialized
INFO - 2018-04-10 21:54:33 --> Language Class Initialized
INFO - 2018-04-10 21:54:33 --> Loader Class Initialized
INFO - 2018-04-10 21:54:33 --> Helper loaded: url_helper
INFO - 2018-04-10 21:54:33 --> Helper loaded: form_helper
INFO - 2018-04-10 21:54:33 --> Helper loaded: language_helper
DEBUG - 2018-04-10 21:54:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 21:54:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 21:54:33 --> User Agent Class Initialized
INFO - 2018-04-10 21:54:33 --> Controller Class Initialized
INFO - 2018-04-10 21:54:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 21:54:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-10 21:54:34 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 21:54:34 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-10 21:54:34 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 21:54:34 --> Final output sent to browser
DEBUG - 2018-04-10 21:54:34 --> Total execution time: 0.3712
INFO - 2018-04-10 21:54:34 --> Config Class Initialized
INFO - 2018-04-10 21:54:34 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:54:34 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:54:34 --> Utf8 Class Initialized
INFO - 2018-04-10 21:54:34 --> URI Class Initialized
INFO - 2018-04-10 21:54:34 --> Router Class Initialized
INFO - 2018-04-10 21:54:34 --> Output Class Initialized
INFO - 2018-04-10 21:54:34 --> Security Class Initialized
DEBUG - 2018-04-10 21:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:54:34 --> CSRF cookie sent
INFO - 2018-04-10 21:54:34 --> Input Class Initialized
INFO - 2018-04-10 21:54:34 --> Language Class Initialized
ERROR - 2018-04-10 21:54:34 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 21:54:35 --> Config Class Initialized
INFO - 2018-04-10 21:54:35 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:54:36 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:54:36 --> Utf8 Class Initialized
INFO - 2018-04-10 21:54:36 --> URI Class Initialized
INFO - 2018-04-10 21:54:36 --> Router Class Initialized
INFO - 2018-04-10 21:54:36 --> Output Class Initialized
INFO - 2018-04-10 21:54:36 --> Security Class Initialized
DEBUG - 2018-04-10 21:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:54:36 --> CSRF cookie sent
INFO - 2018-04-10 21:54:36 --> Input Class Initialized
INFO - 2018-04-10 21:54:36 --> Language Class Initialized
ERROR - 2018-04-10 21:54:36 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-10 21:54:38 --> Config Class Initialized
INFO - 2018-04-10 21:54:38 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:54:38 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:54:38 --> Utf8 Class Initialized
INFO - 2018-04-10 21:54:38 --> URI Class Initialized
INFO - 2018-04-10 21:54:38 --> Router Class Initialized
INFO - 2018-04-10 21:54:39 --> Output Class Initialized
INFO - 2018-04-10 21:54:39 --> Security Class Initialized
DEBUG - 2018-04-10 21:54:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:54:39 --> CSRF cookie sent
INFO - 2018-04-10 21:54:39 --> Input Class Initialized
INFO - 2018-04-10 21:54:39 --> Language Class Initialized
INFO - 2018-04-10 21:54:39 --> Loader Class Initialized
INFO - 2018-04-10 21:54:39 --> Helper loaded: url_helper
INFO - 2018-04-10 21:54:39 --> Helper loaded: form_helper
INFO - 2018-04-10 21:54:39 --> Helper loaded: language_helper
DEBUG - 2018-04-10 21:54:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 21:54:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 21:54:39 --> User Agent Class Initialized
INFO - 2018-04-10 21:54:39 --> Controller Class Initialized
INFO - 2018-04-10 21:54:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 21:54:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-10 21:54:39 --> CSRF cookie sent
INFO - 2018-04-10 21:54:39 --> Config Class Initialized
INFO - 2018-04-10 21:54:39 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:54:39 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:54:39 --> Utf8 Class Initialized
INFO - 2018-04-10 21:54:39 --> URI Class Initialized
DEBUG - 2018-04-10 21:54:39 --> No URI present. Default controller set.
INFO - 2018-04-10 21:54:39 --> Router Class Initialized
INFO - 2018-04-10 21:54:39 --> Output Class Initialized
INFO - 2018-04-10 21:54:39 --> Security Class Initialized
DEBUG - 2018-04-10 21:54:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:54:39 --> CSRF cookie sent
INFO - 2018-04-10 21:54:39 --> Input Class Initialized
INFO - 2018-04-10 21:54:39 --> Language Class Initialized
INFO - 2018-04-10 21:54:39 --> Loader Class Initialized
INFO - 2018-04-10 21:54:39 --> Helper loaded: url_helper
INFO - 2018-04-10 21:54:39 --> Helper loaded: form_helper
INFO - 2018-04-10 21:54:39 --> Helper loaded: language_helper
DEBUG - 2018-04-10 21:54:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 21:54:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 21:54:39 --> User Agent Class Initialized
INFO - 2018-04-10 21:54:39 --> Controller Class Initialized
INFO - 2018-04-10 21:54:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 21:54:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-10 21:54:39 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 21:54:39 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-10 21:54:39 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 21:54:39 --> Final output sent to browser
DEBUG - 2018-04-10 21:54:39 --> Total execution time: 0.3903
INFO - 2018-04-10 21:54:40 --> Config Class Initialized
INFO - 2018-04-10 21:54:40 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:54:40 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:54:40 --> Utf8 Class Initialized
INFO - 2018-04-10 21:54:40 --> URI Class Initialized
INFO - 2018-04-10 21:54:40 --> Router Class Initialized
INFO - 2018-04-10 21:54:40 --> Output Class Initialized
INFO - 2018-04-10 21:54:40 --> Security Class Initialized
DEBUG - 2018-04-10 21:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:54:40 --> CSRF cookie sent
INFO - 2018-04-10 21:54:40 --> Input Class Initialized
INFO - 2018-04-10 21:54:40 --> Language Class Initialized
ERROR - 2018-04-10 21:54:40 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 21:54:41 --> Config Class Initialized
INFO - 2018-04-10 21:54:41 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:54:41 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:54:41 --> Utf8 Class Initialized
INFO - 2018-04-10 21:54:41 --> URI Class Initialized
INFO - 2018-04-10 21:54:41 --> Router Class Initialized
INFO - 2018-04-10 21:54:41 --> Output Class Initialized
INFO - 2018-04-10 21:54:41 --> Security Class Initialized
DEBUG - 2018-04-10 21:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:54:42 --> CSRF cookie sent
INFO - 2018-04-10 21:54:42 --> Input Class Initialized
INFO - 2018-04-10 21:54:42 --> Language Class Initialized
ERROR - 2018-04-10 21:54:42 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-10 21:55:35 --> Config Class Initialized
INFO - 2018-04-10 21:55:35 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:55:35 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:55:35 --> Utf8 Class Initialized
INFO - 2018-04-10 21:55:35 --> URI Class Initialized
INFO - 2018-04-10 21:55:35 --> Router Class Initialized
INFO - 2018-04-10 21:55:35 --> Output Class Initialized
INFO - 2018-04-10 21:55:35 --> Security Class Initialized
DEBUG - 2018-04-10 21:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:55:35 --> CSRF cookie sent
INFO - 2018-04-10 21:55:35 --> Input Class Initialized
INFO - 2018-04-10 21:55:35 --> Language Class Initialized
INFO - 2018-04-10 21:55:35 --> Loader Class Initialized
INFO - 2018-04-10 21:55:35 --> Helper loaded: url_helper
INFO - 2018-04-10 21:55:35 --> Helper loaded: form_helper
INFO - 2018-04-10 21:55:35 --> Helper loaded: language_helper
DEBUG - 2018-04-10 21:55:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 21:55:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 21:55:35 --> User Agent Class Initialized
INFO - 2018-04-10 21:55:35 --> Controller Class Initialized
INFO - 2018-04-10 21:55:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 21:55:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-10 21:55:35 --> Pixel_Model class loaded
INFO - 2018-04-10 21:55:35 --> Database Driver Class Initialized
INFO - 2018-04-10 21:55:35 --> Model "RegistrationModel" initialized
DEBUG - 2018-04-10 21:55:35 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 21:55:35 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 21:55:35 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 21:55:35 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-10 21:55:35 --> Could not find the language line "req_email"
INFO - 2018-04-10 21:55:35 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-04-10 21:55:35 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 21:55:35 --> Final output sent to browser
DEBUG - 2018-04-10 21:55:35 --> Total execution time: 0.5179
INFO - 2018-04-10 21:55:36 --> Config Class Initialized
INFO - 2018-04-10 21:55:36 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:55:36 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:55:36 --> Utf8 Class Initialized
INFO - 2018-04-10 21:55:36 --> URI Class Initialized
INFO - 2018-04-10 21:55:36 --> Router Class Initialized
INFO - 2018-04-10 21:55:36 --> Output Class Initialized
INFO - 2018-04-10 21:55:36 --> Security Class Initialized
DEBUG - 2018-04-10 21:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:55:36 --> CSRF cookie sent
INFO - 2018-04-10 21:55:36 --> Input Class Initialized
INFO - 2018-04-10 21:55:36 --> Language Class Initialized
ERROR - 2018-04-10 21:55:36 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 21:56:13 --> Config Class Initialized
INFO - 2018-04-10 21:56:13 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:56:13 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:56:13 --> Utf8 Class Initialized
INFO - 2018-04-10 21:56:13 --> URI Class Initialized
INFO - 2018-04-10 21:56:13 --> Router Class Initialized
INFO - 2018-04-10 21:56:13 --> Output Class Initialized
INFO - 2018-04-10 21:56:13 --> Security Class Initialized
DEBUG - 2018-04-10 21:56:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:56:13 --> CSRF cookie sent
INFO - 2018-04-10 21:56:13 --> CSRF token verified
INFO - 2018-04-10 21:56:13 --> Input Class Initialized
INFO - 2018-04-10 21:56:13 --> Language Class Initialized
INFO - 2018-04-10 21:56:13 --> Loader Class Initialized
INFO - 2018-04-10 21:56:13 --> Helper loaded: url_helper
INFO - 2018-04-10 21:56:13 --> Helper loaded: form_helper
INFO - 2018-04-10 21:56:13 --> Helper loaded: language_helper
DEBUG - 2018-04-10 21:56:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 21:56:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 21:56:13 --> User Agent Class Initialized
INFO - 2018-04-10 21:56:13 --> Controller Class Initialized
INFO - 2018-04-10 21:56:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 21:56:13 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 21:56:13 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 21:56:17 --> Form Validation Class Initialized
INFO - 2018-04-10 21:56:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-10 21:56:17 --> Pixel_Model class loaded
INFO - 2018-04-10 21:56:17 --> Database Driver Class Initialized
INFO - 2018-04-10 21:56:20 --> Model "RegistrationModel" initialized
INFO - 2018-04-10 21:56:20 --> Helper loaded: string_helper
ERROR - 2018-04-10 21:56:20 --> Severity: Notice --> Undefined property: stdClass::$password E:\www\yacopoo\application\models\RegistrationModel.php 28
ERROR - 2018-04-10 21:56:21 --> Could not find the language line "signup_head"
INFO - 2018-04-10 21:56:21 --> Config Class Initialized
INFO - 2018-04-10 21:56:21 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:56:21 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:56:21 --> Utf8 Class Initialized
INFO - 2018-04-10 21:56:21 --> URI Class Initialized
DEBUG - 2018-04-10 21:56:21 --> No URI present. Default controller set.
INFO - 2018-04-10 21:56:21 --> Router Class Initialized
INFO - 2018-04-10 21:56:21 --> Output Class Initialized
INFO - 2018-04-10 21:56:21 --> Security Class Initialized
DEBUG - 2018-04-10 21:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:56:21 --> CSRF cookie sent
INFO - 2018-04-10 21:56:21 --> Input Class Initialized
INFO - 2018-04-10 21:56:21 --> Language Class Initialized
INFO - 2018-04-10 21:56:21 --> Loader Class Initialized
INFO - 2018-04-10 21:56:21 --> Helper loaded: url_helper
INFO - 2018-04-10 21:56:21 --> Helper loaded: form_helper
INFO - 2018-04-10 21:56:21 --> Helper loaded: language_helper
DEBUG - 2018-04-10 21:56:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 21:56:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 21:56:21 --> User Agent Class Initialized
INFO - 2018-04-10 21:56:21 --> Controller Class Initialized
INFO - 2018-04-10 21:56:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 21:56:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-10 21:56:21 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 21:56:21 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-10 21:56:21 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 21:56:21 --> Final output sent to browser
DEBUG - 2018-04-10 21:56:21 --> Total execution time: 0.4108
INFO - 2018-04-10 21:56:21 --> Config Class Initialized
INFO - 2018-04-10 21:56:21 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:56:21 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:56:21 --> Utf8 Class Initialized
INFO - 2018-04-10 21:56:21 --> URI Class Initialized
INFO - 2018-04-10 21:56:22 --> Router Class Initialized
INFO - 2018-04-10 21:56:22 --> Output Class Initialized
INFO - 2018-04-10 21:56:22 --> Security Class Initialized
DEBUG - 2018-04-10 21:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:56:22 --> CSRF cookie sent
INFO - 2018-04-10 21:56:22 --> Input Class Initialized
INFO - 2018-04-10 21:56:22 --> Language Class Initialized
ERROR - 2018-04-10 21:56:22 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 21:56:23 --> Config Class Initialized
INFO - 2018-04-10 21:56:23 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:56:23 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:56:23 --> Utf8 Class Initialized
INFO - 2018-04-10 21:56:23 --> URI Class Initialized
INFO - 2018-04-10 21:56:23 --> Router Class Initialized
INFO - 2018-04-10 21:56:23 --> Output Class Initialized
INFO - 2018-04-10 21:56:23 --> Security Class Initialized
DEBUG - 2018-04-10 21:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:56:23 --> CSRF cookie sent
INFO - 2018-04-10 21:56:23 --> Input Class Initialized
INFO - 2018-04-10 21:56:23 --> Language Class Initialized
ERROR - 2018-04-10 21:56:23 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-10 21:56:24 --> Config Class Initialized
INFO - 2018-04-10 21:56:24 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:56:24 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:56:24 --> Utf8 Class Initialized
INFO - 2018-04-10 21:56:24 --> URI Class Initialized
INFO - 2018-04-10 21:56:24 --> Router Class Initialized
INFO - 2018-04-10 21:56:24 --> Output Class Initialized
INFO - 2018-04-10 21:56:24 --> Security Class Initialized
DEBUG - 2018-04-10 21:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:56:24 --> CSRF cookie sent
INFO - 2018-04-10 21:56:24 --> Input Class Initialized
INFO - 2018-04-10 21:56:24 --> Language Class Initialized
INFO - 2018-04-10 21:56:24 --> Loader Class Initialized
INFO - 2018-04-10 21:56:24 --> Helper loaded: url_helper
INFO - 2018-04-10 21:56:24 --> Helper loaded: form_helper
INFO - 2018-04-10 21:56:24 --> Helper loaded: language_helper
DEBUG - 2018-04-10 21:56:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 21:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 21:56:25 --> User Agent Class Initialized
INFO - 2018-04-10 21:56:25 --> Controller Class Initialized
INFO - 2018-04-10 21:56:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 21:56:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-10 21:56:25 --> CSRF cookie sent
INFO - 2018-04-10 21:56:25 --> Config Class Initialized
INFO - 2018-04-10 21:56:25 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:56:25 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:56:25 --> Utf8 Class Initialized
INFO - 2018-04-10 21:56:25 --> URI Class Initialized
DEBUG - 2018-04-10 21:56:25 --> No URI present. Default controller set.
INFO - 2018-04-10 21:56:25 --> Router Class Initialized
INFO - 2018-04-10 21:56:25 --> Output Class Initialized
INFO - 2018-04-10 21:56:25 --> Security Class Initialized
DEBUG - 2018-04-10 21:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:56:25 --> CSRF cookie sent
INFO - 2018-04-10 21:56:25 --> Input Class Initialized
INFO - 2018-04-10 21:56:25 --> Language Class Initialized
INFO - 2018-04-10 21:56:25 --> Loader Class Initialized
INFO - 2018-04-10 21:56:25 --> Helper loaded: url_helper
INFO - 2018-04-10 21:56:25 --> Helper loaded: form_helper
INFO - 2018-04-10 21:56:25 --> Helper loaded: language_helper
DEBUG - 2018-04-10 21:56:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 21:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 21:56:25 --> User Agent Class Initialized
INFO - 2018-04-10 21:56:25 --> Controller Class Initialized
INFO - 2018-04-10 21:56:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 21:56:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-10 21:56:25 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 21:56:25 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-10 21:56:25 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 21:56:25 --> Final output sent to browser
DEBUG - 2018-04-10 21:56:25 --> Total execution time: 0.4501
INFO - 2018-04-10 21:56:26 --> Config Class Initialized
INFO - 2018-04-10 21:56:26 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:56:26 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:56:26 --> Utf8 Class Initialized
INFO - 2018-04-10 21:56:26 --> URI Class Initialized
INFO - 2018-04-10 21:56:26 --> Router Class Initialized
INFO - 2018-04-10 21:56:26 --> Output Class Initialized
INFO - 2018-04-10 21:56:26 --> Security Class Initialized
DEBUG - 2018-04-10 21:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:56:26 --> CSRF cookie sent
INFO - 2018-04-10 21:56:26 --> Input Class Initialized
INFO - 2018-04-10 21:56:26 --> Language Class Initialized
ERROR - 2018-04-10 21:56:26 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 21:56:27 --> Config Class Initialized
INFO - 2018-04-10 21:56:28 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:56:28 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:56:28 --> Utf8 Class Initialized
INFO - 2018-04-10 21:56:28 --> URI Class Initialized
INFO - 2018-04-10 21:56:28 --> Router Class Initialized
INFO - 2018-04-10 21:56:28 --> Output Class Initialized
INFO - 2018-04-10 21:56:28 --> Security Class Initialized
INFO - 2018-04-10 21:56:28 --> Config Class Initialized
INFO - 2018-04-10 21:56:28 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:56:28 --> CSRF cookie sent
DEBUG - 2018-04-10 21:56:28 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:56:28 --> Utf8 Class Initialized
INFO - 2018-04-10 21:56:28 --> Input Class Initialized
INFO - 2018-04-10 21:56:28 --> Language Class Initialized
INFO - 2018-04-10 21:56:28 --> URI Class Initialized
INFO - 2018-04-10 21:56:28 --> Router Class Initialized
ERROR - 2018-04-10 21:56:28 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-10 21:56:28 --> Output Class Initialized
INFO - 2018-04-10 21:56:28 --> Security Class Initialized
DEBUG - 2018-04-10 21:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:56:28 --> CSRF cookie sent
INFO - 2018-04-10 21:56:28 --> Input Class Initialized
INFO - 2018-04-10 21:56:28 --> Language Class Initialized
INFO - 2018-04-10 21:56:28 --> Loader Class Initialized
INFO - 2018-04-10 21:56:28 --> Helper loaded: url_helper
INFO - 2018-04-10 21:56:28 --> Helper loaded: form_helper
INFO - 2018-04-10 21:56:28 --> Helper loaded: language_helper
DEBUG - 2018-04-10 21:56:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 21:56:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 21:56:28 --> User Agent Class Initialized
INFO - 2018-04-10 21:56:28 --> Controller Class Initialized
INFO - 2018-04-10 21:56:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 21:56:28 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 21:56:28 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 21:56:28 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 21:56:28 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 21:56:28 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-10 21:56:28 --> Could not find the language line "req_email"
INFO - 2018-04-10 21:56:28 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-04-10 21:56:28 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 21:56:28 --> Final output sent to browser
DEBUG - 2018-04-10 21:56:28 --> Total execution time: 0.4389
INFO - 2018-04-10 21:56:28 --> Config Class Initialized
INFO - 2018-04-10 21:56:28 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:56:29 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:56:29 --> Utf8 Class Initialized
INFO - 2018-04-10 21:56:29 --> URI Class Initialized
INFO - 2018-04-10 21:56:29 --> Router Class Initialized
INFO - 2018-04-10 21:56:29 --> Output Class Initialized
INFO - 2018-04-10 21:56:29 --> Security Class Initialized
DEBUG - 2018-04-10 21:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:56:29 --> CSRF cookie sent
INFO - 2018-04-10 21:56:29 --> Input Class Initialized
INFO - 2018-04-10 21:56:29 --> Language Class Initialized
ERROR - 2018-04-10 21:56:29 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 21:56:54 --> Config Class Initialized
INFO - 2018-04-10 21:56:54 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:56:54 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:56:54 --> Utf8 Class Initialized
INFO - 2018-04-10 21:56:54 --> URI Class Initialized
INFO - 2018-04-10 21:56:54 --> Router Class Initialized
INFO - 2018-04-10 21:56:54 --> Output Class Initialized
INFO - 2018-04-10 21:56:54 --> Security Class Initialized
DEBUG - 2018-04-10 21:56:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:56:54 --> CSRF cookie sent
INFO - 2018-04-10 21:56:54 --> CSRF token verified
INFO - 2018-04-10 21:56:54 --> Input Class Initialized
INFO - 2018-04-10 21:56:54 --> Language Class Initialized
INFO - 2018-04-10 21:56:54 --> Loader Class Initialized
INFO - 2018-04-10 21:56:54 --> Helper loaded: url_helper
INFO - 2018-04-10 21:56:54 --> Helper loaded: form_helper
INFO - 2018-04-10 21:56:54 --> Helper loaded: language_helper
DEBUG - 2018-04-10 21:56:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 21:56:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 21:56:54 --> User Agent Class Initialized
INFO - 2018-04-10 21:56:54 --> Controller Class Initialized
INFO - 2018-04-10 21:56:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 21:56:54 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 21:56:54 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 21:56:55 --> Form Validation Class Initialized
INFO - 2018-04-10 21:56:55 --> Pixel_Model class loaded
INFO - 2018-04-10 21:56:55 --> Database Driver Class Initialized
INFO - 2018-04-10 21:56:55 --> Model "AuthenticationModel" initialized
INFO - 2018-04-10 21:56:55 --> Config Class Initialized
INFO - 2018-04-10 21:56:55 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:56:55 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:56:55 --> Utf8 Class Initialized
INFO - 2018-04-10 21:56:55 --> URI Class Initialized
INFO - 2018-04-10 21:56:55 --> Router Class Initialized
INFO - 2018-04-10 21:56:55 --> Output Class Initialized
INFO - 2018-04-10 21:56:55 --> Security Class Initialized
DEBUG - 2018-04-10 21:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:56:55 --> CSRF cookie sent
INFO - 2018-04-10 21:56:55 --> Input Class Initialized
INFO - 2018-04-10 21:56:55 --> Language Class Initialized
INFO - 2018-04-10 21:56:55 --> Loader Class Initialized
INFO - 2018-04-10 21:56:55 --> Helper loaded: url_helper
INFO - 2018-04-10 21:56:55 --> Helper loaded: form_helper
INFO - 2018-04-10 21:56:55 --> Helper loaded: language_helper
DEBUG - 2018-04-10 21:56:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 21:56:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 21:56:55 --> User Agent Class Initialized
INFO - 2018-04-10 21:56:55 --> Controller Class Initialized
INFO - 2018-04-10 21:56:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 21:56:55 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 21:56:55 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 21:56:55 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 21:56:55 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 21:56:55 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-10 21:56:55 --> File loaded: E:\www\yacopoo\application\views\shared/_soft_error.php
ERROR - 2018-04-10 21:56:55 --> Could not find the language line "req_email"
INFO - 2018-04-10 21:56:55 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-04-10 21:56:55 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 21:56:55 --> Final output sent to browser
DEBUG - 2018-04-10 21:56:55 --> Total execution time: 0.4384
INFO - 2018-04-10 21:56:56 --> Config Class Initialized
INFO - 2018-04-10 21:56:56 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:56:56 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:56:56 --> Utf8 Class Initialized
INFO - 2018-04-10 21:56:56 --> URI Class Initialized
INFO - 2018-04-10 21:56:56 --> Router Class Initialized
INFO - 2018-04-10 21:56:56 --> Output Class Initialized
INFO - 2018-04-10 21:56:56 --> Security Class Initialized
DEBUG - 2018-04-10 21:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:56:56 --> CSRF cookie sent
INFO - 2018-04-10 21:56:56 --> Input Class Initialized
INFO - 2018-04-10 21:56:56 --> Language Class Initialized
ERROR - 2018-04-10 21:56:56 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 21:58:32 --> Config Class Initialized
INFO - 2018-04-10 21:58:32 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:58:32 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:58:32 --> Utf8 Class Initialized
INFO - 2018-04-10 21:58:32 --> URI Class Initialized
INFO - 2018-04-10 21:58:32 --> Router Class Initialized
INFO - 2018-04-10 21:58:32 --> Output Class Initialized
INFO - 2018-04-10 21:58:32 --> Security Class Initialized
DEBUG - 2018-04-10 21:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:58:32 --> CSRF cookie sent
INFO - 2018-04-10 21:58:32 --> Input Class Initialized
INFO - 2018-04-10 21:58:32 --> Language Class Initialized
ERROR - 2018-04-10 21:58:32 --> 404 Page Not Found: Financial%20Advisors/index
INFO - 2018-04-10 21:58:36 --> Config Class Initialized
INFO - 2018-04-10 21:58:36 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:58:36 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:58:36 --> Utf8 Class Initialized
INFO - 2018-04-10 21:58:36 --> URI Class Initialized
INFO - 2018-04-10 21:58:36 --> Router Class Initialized
INFO - 2018-04-10 21:58:36 --> Output Class Initialized
INFO - 2018-04-10 21:58:36 --> Security Class Initialized
DEBUG - 2018-04-10 21:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:58:36 --> CSRF cookie sent
INFO - 2018-04-10 21:58:36 --> Input Class Initialized
INFO - 2018-04-10 21:58:36 --> Language Class Initialized
INFO - 2018-04-10 21:58:36 --> Loader Class Initialized
INFO - 2018-04-10 21:58:36 --> Helper loaded: url_helper
INFO - 2018-04-10 21:58:36 --> Helper loaded: form_helper
INFO - 2018-04-10 21:58:36 --> Helper loaded: language_helper
DEBUG - 2018-04-10 21:58:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 21:58:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 21:58:36 --> User Agent Class Initialized
INFO - 2018-04-10 21:58:36 --> Controller Class Initialized
INFO - 2018-04-10 21:58:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 21:58:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-10 21:58:36 --> Pixel_Model class loaded
INFO - 2018-04-10 21:58:36 --> Database Driver Class Initialized
INFO - 2018-04-10 21:58:39 --> Model "RegistrationModel" initialized
DEBUG - 2018-04-10 21:58:39 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 21:58:39 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 21:58:39 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 21:58:39 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-10 21:58:39 --> Could not find the language line "req_email"
INFO - 2018-04-10 21:58:39 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-04-10 21:58:39 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 21:58:39 --> Final output sent to browser
DEBUG - 2018-04-10 21:58:40 --> Total execution time: 3.5388
INFO - 2018-04-10 21:58:40 --> Config Class Initialized
INFO - 2018-04-10 21:58:40 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:58:40 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:58:40 --> Utf8 Class Initialized
INFO - 2018-04-10 21:58:40 --> URI Class Initialized
INFO - 2018-04-10 21:58:40 --> Router Class Initialized
INFO - 2018-04-10 21:58:40 --> Output Class Initialized
INFO - 2018-04-10 21:58:40 --> Security Class Initialized
DEBUG - 2018-04-10 21:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:58:40 --> CSRF cookie sent
INFO - 2018-04-10 21:58:40 --> Input Class Initialized
INFO - 2018-04-10 21:58:40 --> Language Class Initialized
ERROR - 2018-04-10 21:58:40 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 21:59:43 --> Config Class Initialized
INFO - 2018-04-10 21:59:43 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:59:43 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:59:43 --> Utf8 Class Initialized
INFO - 2018-04-10 21:59:43 --> URI Class Initialized
INFO - 2018-04-10 21:59:43 --> Router Class Initialized
INFO - 2018-04-10 21:59:43 --> Output Class Initialized
INFO - 2018-04-10 21:59:43 --> Security Class Initialized
DEBUG - 2018-04-10 21:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:59:43 --> CSRF cookie sent
INFO - 2018-04-10 21:59:43 --> CSRF token verified
INFO - 2018-04-10 21:59:43 --> Input Class Initialized
INFO - 2018-04-10 21:59:43 --> Language Class Initialized
INFO - 2018-04-10 21:59:43 --> Loader Class Initialized
INFO - 2018-04-10 21:59:43 --> Helper loaded: url_helper
INFO - 2018-04-10 21:59:43 --> Helper loaded: form_helper
INFO - 2018-04-10 21:59:44 --> Helper loaded: language_helper
DEBUG - 2018-04-10 21:59:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 21:59:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 21:59:44 --> User Agent Class Initialized
INFO - 2018-04-10 21:59:44 --> Controller Class Initialized
INFO - 2018-04-10 21:59:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 21:59:44 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 21:59:44 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 21:59:44 --> Form Validation Class Initialized
INFO - 2018-04-10 21:59:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-10 21:59:44 --> Pixel_Model class loaded
INFO - 2018-04-10 21:59:44 --> Database Driver Class Initialized
INFO - 2018-04-10 21:59:47 --> Model "RegistrationModel" initialized
INFO - 2018-04-10 21:59:47 --> Helper loaded: string_helper
ERROR - 2018-04-10 21:59:47 --> Could not find the language line "signup_head"
INFO - 2018-04-10 21:59:47 --> Config Class Initialized
INFO - 2018-04-10 21:59:47 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:59:47 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:59:47 --> Utf8 Class Initialized
INFO - 2018-04-10 21:59:47 --> URI Class Initialized
DEBUG - 2018-04-10 21:59:47 --> No URI present. Default controller set.
INFO - 2018-04-10 21:59:47 --> Router Class Initialized
INFO - 2018-04-10 21:59:47 --> Output Class Initialized
INFO - 2018-04-10 21:59:47 --> Security Class Initialized
DEBUG - 2018-04-10 21:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:59:47 --> CSRF cookie sent
INFO - 2018-04-10 21:59:48 --> Input Class Initialized
INFO - 2018-04-10 21:59:48 --> Language Class Initialized
INFO - 2018-04-10 21:59:48 --> Loader Class Initialized
INFO - 2018-04-10 21:59:48 --> Helper loaded: url_helper
INFO - 2018-04-10 21:59:48 --> Helper loaded: form_helper
INFO - 2018-04-10 21:59:48 --> Helper loaded: language_helper
DEBUG - 2018-04-10 21:59:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 21:59:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 21:59:48 --> User Agent Class Initialized
INFO - 2018-04-10 21:59:48 --> Controller Class Initialized
INFO - 2018-04-10 21:59:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 21:59:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-10 21:59:48 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 21:59:48 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-10 21:59:48 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 21:59:48 --> Final output sent to browser
DEBUG - 2018-04-10 21:59:48 --> Total execution time: 0.4169
INFO - 2018-04-10 21:59:48 --> Config Class Initialized
INFO - 2018-04-10 21:59:48 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:59:48 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:59:48 --> Utf8 Class Initialized
INFO - 2018-04-10 21:59:48 --> URI Class Initialized
INFO - 2018-04-10 21:59:48 --> Router Class Initialized
INFO - 2018-04-10 21:59:48 --> Output Class Initialized
INFO - 2018-04-10 21:59:48 --> Security Class Initialized
DEBUG - 2018-04-10 21:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:59:48 --> CSRF cookie sent
INFO - 2018-04-10 21:59:48 --> Input Class Initialized
INFO - 2018-04-10 21:59:48 --> Language Class Initialized
ERROR - 2018-04-10 21:59:48 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 21:59:50 --> Config Class Initialized
INFO - 2018-04-10 21:59:50 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:59:50 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:59:50 --> Utf8 Class Initialized
INFO - 2018-04-10 21:59:50 --> URI Class Initialized
INFO - 2018-04-10 21:59:50 --> Router Class Initialized
INFO - 2018-04-10 21:59:50 --> Output Class Initialized
INFO - 2018-04-10 21:59:50 --> Security Class Initialized
DEBUG - 2018-04-10 21:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:59:50 --> CSRF cookie sent
INFO - 2018-04-10 21:59:50 --> Input Class Initialized
INFO - 2018-04-10 21:59:50 --> Language Class Initialized
ERROR - 2018-04-10 21:59:50 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-10 21:59:51 --> Config Class Initialized
INFO - 2018-04-10 21:59:51 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:59:51 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:59:51 --> Utf8 Class Initialized
INFO - 2018-04-10 21:59:51 --> URI Class Initialized
INFO - 2018-04-10 21:59:51 --> Router Class Initialized
INFO - 2018-04-10 21:59:51 --> Output Class Initialized
INFO - 2018-04-10 21:59:51 --> Security Class Initialized
DEBUG - 2018-04-10 21:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:59:51 --> CSRF cookie sent
INFO - 2018-04-10 21:59:51 --> Input Class Initialized
INFO - 2018-04-10 21:59:51 --> Language Class Initialized
INFO - 2018-04-10 21:59:51 --> Loader Class Initialized
INFO - 2018-04-10 21:59:51 --> Helper loaded: url_helper
INFO - 2018-04-10 21:59:51 --> Helper loaded: form_helper
INFO - 2018-04-10 21:59:51 --> Helper loaded: language_helper
DEBUG - 2018-04-10 21:59:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 21:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 21:59:51 --> User Agent Class Initialized
INFO - 2018-04-10 21:59:51 --> Controller Class Initialized
INFO - 2018-04-10 21:59:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 21:59:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-10 21:59:51 --> CSRF cookie sent
INFO - 2018-04-10 21:59:51 --> Config Class Initialized
INFO - 2018-04-10 21:59:51 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:59:51 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:59:51 --> Utf8 Class Initialized
INFO - 2018-04-10 21:59:51 --> URI Class Initialized
DEBUG - 2018-04-10 21:59:51 --> No URI present. Default controller set.
INFO - 2018-04-10 21:59:51 --> Router Class Initialized
INFO - 2018-04-10 21:59:51 --> Output Class Initialized
INFO - 2018-04-10 21:59:51 --> Security Class Initialized
DEBUG - 2018-04-10 21:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:59:51 --> CSRF cookie sent
INFO - 2018-04-10 21:59:51 --> Input Class Initialized
INFO - 2018-04-10 21:59:51 --> Language Class Initialized
INFO - 2018-04-10 21:59:51 --> Loader Class Initialized
INFO - 2018-04-10 21:59:51 --> Helper loaded: url_helper
INFO - 2018-04-10 21:59:51 --> Helper loaded: form_helper
INFO - 2018-04-10 21:59:51 --> Helper loaded: language_helper
DEBUG - 2018-04-10 21:59:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 21:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 21:59:51 --> User Agent Class Initialized
INFO - 2018-04-10 21:59:51 --> Controller Class Initialized
INFO - 2018-04-10 21:59:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 21:59:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-10 21:59:51 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 21:59:51 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-10 21:59:51 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 21:59:51 --> Final output sent to browser
DEBUG - 2018-04-10 21:59:51 --> Total execution time: 0.4148
INFO - 2018-04-10 21:59:52 --> Config Class Initialized
INFO - 2018-04-10 21:59:52 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:59:52 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:59:52 --> Utf8 Class Initialized
INFO - 2018-04-10 21:59:52 --> URI Class Initialized
INFO - 2018-04-10 21:59:52 --> Router Class Initialized
INFO - 2018-04-10 21:59:52 --> Output Class Initialized
INFO - 2018-04-10 21:59:52 --> Security Class Initialized
DEBUG - 2018-04-10 21:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:59:52 --> CSRF cookie sent
INFO - 2018-04-10 21:59:52 --> Input Class Initialized
INFO - 2018-04-10 21:59:52 --> Language Class Initialized
ERROR - 2018-04-10 21:59:52 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 21:59:53 --> Config Class Initialized
INFO - 2018-04-10 21:59:53 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:59:53 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:59:53 --> Utf8 Class Initialized
INFO - 2018-04-10 21:59:53 --> URI Class Initialized
INFO - 2018-04-10 21:59:53 --> Config Class Initialized
INFO - 2018-04-10 21:59:53 --> Router Class Initialized
INFO - 2018-04-10 21:59:53 --> Hooks Class Initialized
INFO - 2018-04-10 21:59:53 --> Output Class Initialized
INFO - 2018-04-10 21:59:53 --> Security Class Initialized
DEBUG - 2018-04-10 21:59:53 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:59:53 --> Utf8 Class Initialized
DEBUG - 2018-04-10 21:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:59:53 --> CSRF cookie sent
INFO - 2018-04-10 21:59:53 --> URI Class Initialized
INFO - 2018-04-10 21:59:53 --> Input Class Initialized
INFO - 2018-04-10 21:59:53 --> Router Class Initialized
INFO - 2018-04-10 21:59:54 --> Language Class Initialized
INFO - 2018-04-10 21:59:54 --> Output Class Initialized
INFO - 2018-04-10 21:59:54 --> Security Class Initialized
ERROR - 2018-04-10 21:59:54 --> 404 Page Not Found: Revolution/assets
DEBUG - 2018-04-10 21:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:59:54 --> CSRF cookie sent
INFO - 2018-04-10 21:59:54 --> Input Class Initialized
INFO - 2018-04-10 21:59:54 --> Language Class Initialized
INFO - 2018-04-10 21:59:54 --> Loader Class Initialized
INFO - 2018-04-10 21:59:54 --> Helper loaded: url_helper
INFO - 2018-04-10 21:59:54 --> Helper loaded: form_helper
INFO - 2018-04-10 21:59:54 --> Helper loaded: language_helper
DEBUG - 2018-04-10 21:59:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 21:59:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 21:59:54 --> User Agent Class Initialized
INFO - 2018-04-10 21:59:54 --> Controller Class Initialized
INFO - 2018-04-10 21:59:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 21:59:54 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 21:59:54 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 21:59:54 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 21:59:54 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 21:59:54 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-10 21:59:54 --> Could not find the language line "req_email"
INFO - 2018-04-10 21:59:54 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-04-10 21:59:54 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 21:59:54 --> Final output sent to browser
DEBUG - 2018-04-10 21:59:54 --> Total execution time: 0.5419
INFO - 2018-04-10 21:59:54 --> Config Class Initialized
INFO - 2018-04-10 21:59:54 --> Hooks Class Initialized
DEBUG - 2018-04-10 21:59:54 --> UTF-8 Support Enabled
INFO - 2018-04-10 21:59:54 --> Utf8 Class Initialized
INFO - 2018-04-10 21:59:54 --> URI Class Initialized
INFO - 2018-04-10 21:59:54 --> Router Class Initialized
INFO - 2018-04-10 21:59:54 --> Output Class Initialized
INFO - 2018-04-10 21:59:54 --> Security Class Initialized
DEBUG - 2018-04-10 21:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 21:59:54 --> CSRF cookie sent
INFO - 2018-04-10 21:59:55 --> Input Class Initialized
INFO - 2018-04-10 21:59:55 --> Language Class Initialized
ERROR - 2018-04-10 21:59:55 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 22:00:16 --> Config Class Initialized
INFO - 2018-04-10 22:00:16 --> Hooks Class Initialized
DEBUG - 2018-04-10 22:00:16 --> UTF-8 Support Enabled
INFO - 2018-04-10 22:00:16 --> Utf8 Class Initialized
INFO - 2018-04-10 22:00:16 --> URI Class Initialized
INFO - 2018-04-10 22:00:16 --> Router Class Initialized
INFO - 2018-04-10 22:00:16 --> Output Class Initialized
INFO - 2018-04-10 22:00:16 --> Security Class Initialized
DEBUG - 2018-04-10 22:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 22:00:16 --> CSRF cookie sent
INFO - 2018-04-10 22:00:16 --> CSRF token verified
INFO - 2018-04-10 22:00:16 --> Input Class Initialized
INFO - 2018-04-10 22:00:16 --> Language Class Initialized
INFO - 2018-04-10 22:00:16 --> Loader Class Initialized
INFO - 2018-04-10 22:00:16 --> Helper loaded: url_helper
INFO - 2018-04-10 22:00:16 --> Helper loaded: form_helper
INFO - 2018-04-10 22:00:16 --> Helper loaded: language_helper
DEBUG - 2018-04-10 22:00:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 22:00:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 22:00:16 --> User Agent Class Initialized
INFO - 2018-04-10 22:00:16 --> Controller Class Initialized
INFO - 2018-04-10 22:00:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 22:00:16 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 22:00:16 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 22:00:16 --> Form Validation Class Initialized
INFO - 2018-04-10 22:00:16 --> Pixel_Model class loaded
INFO - 2018-04-10 22:00:17 --> Database Driver Class Initialized
INFO - 2018-04-10 22:00:17 --> Model "AuthenticationModel" initialized
INFO - 2018-04-10 22:00:17 --> Config Class Initialized
INFO - 2018-04-10 22:00:17 --> Hooks Class Initialized
DEBUG - 2018-04-10 22:00:17 --> UTF-8 Support Enabled
INFO - 2018-04-10 22:00:17 --> Utf8 Class Initialized
INFO - 2018-04-10 22:00:17 --> URI Class Initialized
DEBUG - 2018-04-10 22:00:17 --> No URI present. Default controller set.
INFO - 2018-04-10 22:00:17 --> Router Class Initialized
INFO - 2018-04-10 22:00:17 --> Output Class Initialized
INFO - 2018-04-10 22:00:17 --> Security Class Initialized
DEBUG - 2018-04-10 22:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 22:00:17 --> CSRF cookie sent
INFO - 2018-04-10 22:00:17 --> Input Class Initialized
INFO - 2018-04-10 22:00:17 --> Language Class Initialized
INFO - 2018-04-10 22:00:17 --> Loader Class Initialized
INFO - 2018-04-10 22:00:17 --> Helper loaded: url_helper
INFO - 2018-04-10 22:00:17 --> Helper loaded: form_helper
INFO - 2018-04-10 22:00:17 --> Helper loaded: language_helper
DEBUG - 2018-04-10 22:00:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 22:00:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 22:00:17 --> User Agent Class Initialized
INFO - 2018-04-10 22:00:17 --> Controller Class Initialized
INFO - 2018-04-10 22:00:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 22:00:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-10 22:00:17 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 22:00:17 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-10 22:00:17 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 22:00:17 --> Final output sent to browser
DEBUG - 2018-04-10 22:00:17 --> Total execution time: 0.3952
INFO - 2018-04-10 22:00:18 --> Config Class Initialized
INFO - 2018-04-10 22:00:18 --> Hooks Class Initialized
DEBUG - 2018-04-10 22:00:18 --> UTF-8 Support Enabled
INFO - 2018-04-10 22:00:18 --> Utf8 Class Initialized
INFO - 2018-04-10 22:00:18 --> URI Class Initialized
INFO - 2018-04-10 22:00:18 --> Router Class Initialized
INFO - 2018-04-10 22:00:18 --> Output Class Initialized
INFO - 2018-04-10 22:00:18 --> Security Class Initialized
DEBUG - 2018-04-10 22:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 22:00:18 --> CSRF cookie sent
INFO - 2018-04-10 22:00:18 --> Input Class Initialized
INFO - 2018-04-10 22:00:18 --> Language Class Initialized
ERROR - 2018-04-10 22:00:18 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 22:00:19 --> Config Class Initialized
INFO - 2018-04-10 22:00:19 --> Hooks Class Initialized
DEBUG - 2018-04-10 22:00:19 --> UTF-8 Support Enabled
INFO - 2018-04-10 22:00:19 --> Utf8 Class Initialized
INFO - 2018-04-10 22:00:19 --> URI Class Initialized
INFO - 2018-04-10 22:00:19 --> Router Class Initialized
INFO - 2018-04-10 22:00:19 --> Output Class Initialized
INFO - 2018-04-10 22:00:19 --> Security Class Initialized
DEBUG - 2018-04-10 22:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 22:00:20 --> CSRF cookie sent
INFO - 2018-04-10 22:00:20 --> Input Class Initialized
INFO - 2018-04-10 22:00:20 --> Language Class Initialized
ERROR - 2018-04-10 22:00:20 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-10 22:20:12 --> Config Class Initialized
INFO - 2018-04-10 22:20:12 --> Hooks Class Initialized
DEBUG - 2018-04-10 22:20:13 --> UTF-8 Support Enabled
INFO - 2018-04-10 22:20:13 --> Utf8 Class Initialized
INFO - 2018-04-10 22:20:13 --> URI Class Initialized
INFO - 2018-04-10 22:20:13 --> Router Class Initialized
INFO - 2018-04-10 22:20:13 --> Output Class Initialized
INFO - 2018-04-10 22:20:13 --> Security Class Initialized
DEBUG - 2018-04-10 22:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 22:20:13 --> CSRF cookie sent
INFO - 2018-04-10 22:20:13 --> Input Class Initialized
INFO - 2018-04-10 22:20:13 --> Language Class Initialized
INFO - 2018-04-10 22:20:13 --> Loader Class Initialized
INFO - 2018-04-10 22:20:14 --> Helper loaded: url_helper
INFO - 2018-04-10 22:20:14 --> Helper loaded: form_helper
INFO - 2018-04-10 22:20:14 --> Helper loaded: language_helper
DEBUG - 2018-04-10 22:20:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 22:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 22:20:14 --> User Agent Class Initialized
INFO - 2018-04-10 22:20:14 --> Controller Class Initialized
INFO - 2018-04-10 22:20:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 22:20:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-10 22:20:14 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 22:20:14 --> File loaded: E:\www\yacopoo\application\views\lawyer.php
INFO - 2018-04-10 22:20:14 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 22:20:14 --> Final output sent to browser
DEBUG - 2018-04-10 22:20:14 --> Total execution time: 2.0807
INFO - 2018-04-10 22:20:15 --> Config Class Initialized
INFO - 2018-04-10 22:20:15 --> Hooks Class Initialized
DEBUG - 2018-04-10 22:20:15 --> UTF-8 Support Enabled
INFO - 2018-04-10 22:20:15 --> Utf8 Class Initialized
INFO - 2018-04-10 22:20:16 --> URI Class Initialized
INFO - 2018-04-10 22:20:16 --> Router Class Initialized
INFO - 2018-04-10 22:20:16 --> Output Class Initialized
INFO - 2018-04-10 22:20:16 --> Security Class Initialized
DEBUG - 2018-04-10 22:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 22:20:16 --> CSRF cookie sent
INFO - 2018-04-10 22:20:16 --> Input Class Initialized
INFO - 2018-04-10 22:20:16 --> Language Class Initialized
ERROR - 2018-04-10 22:20:16 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 22:21:41 --> Config Class Initialized
INFO - 2018-04-10 22:21:41 --> Hooks Class Initialized
DEBUG - 2018-04-10 22:21:41 --> UTF-8 Support Enabled
INFO - 2018-04-10 22:21:41 --> Utf8 Class Initialized
INFO - 2018-04-10 22:21:41 --> URI Class Initialized
INFO - 2018-04-10 22:21:41 --> Router Class Initialized
INFO - 2018-04-10 22:21:41 --> Output Class Initialized
INFO - 2018-04-10 22:21:41 --> Security Class Initialized
DEBUG - 2018-04-10 22:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 22:21:41 --> CSRF cookie sent
INFO - 2018-04-10 22:21:41 --> Input Class Initialized
INFO - 2018-04-10 22:21:41 --> Language Class Initialized
INFO - 2018-04-10 22:21:41 --> Loader Class Initialized
INFO - 2018-04-10 22:21:41 --> Helper loaded: url_helper
INFO - 2018-04-10 22:21:41 --> Helper loaded: form_helper
INFO - 2018-04-10 22:21:41 --> Helper loaded: language_helper
DEBUG - 2018-04-10 22:21:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 22:21:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 22:21:41 --> User Agent Class Initialized
INFO - 2018-04-10 22:21:41 --> Controller Class Initialized
INFO - 2018-04-10 22:21:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 22:21:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-10 22:21:42 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 22:21:42 --> File loaded: E:\www\yacopoo\application\views\lawyer.php
INFO - 2018-04-10 22:21:42 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 22:21:42 --> Final output sent to browser
DEBUG - 2018-04-10 22:21:42 --> Total execution time: 0.4038
INFO - 2018-04-10 22:21:42 --> Config Class Initialized
INFO - 2018-04-10 22:21:42 --> Hooks Class Initialized
DEBUG - 2018-04-10 22:21:42 --> UTF-8 Support Enabled
INFO - 2018-04-10 22:21:42 --> Utf8 Class Initialized
INFO - 2018-04-10 22:21:42 --> URI Class Initialized
INFO - 2018-04-10 22:21:42 --> Router Class Initialized
INFO - 2018-04-10 22:21:42 --> Output Class Initialized
INFO - 2018-04-10 22:21:42 --> Security Class Initialized
DEBUG - 2018-04-10 22:21:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 22:21:42 --> CSRF cookie sent
INFO - 2018-04-10 22:21:42 --> Input Class Initialized
INFO - 2018-04-10 22:21:42 --> Language Class Initialized
ERROR - 2018-04-10 22:21:42 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 22:22:56 --> Config Class Initialized
INFO - 2018-04-10 22:22:56 --> Hooks Class Initialized
DEBUG - 2018-04-10 22:22:56 --> UTF-8 Support Enabled
INFO - 2018-04-10 22:22:56 --> Utf8 Class Initialized
INFO - 2018-04-10 22:22:56 --> URI Class Initialized
INFO - 2018-04-10 22:22:56 --> Router Class Initialized
INFO - 2018-04-10 22:22:56 --> Output Class Initialized
INFO - 2018-04-10 22:22:56 --> Security Class Initialized
DEBUG - 2018-04-10 22:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 22:22:56 --> CSRF cookie sent
INFO - 2018-04-10 22:22:56 --> Input Class Initialized
INFO - 2018-04-10 22:22:56 --> Language Class Initialized
INFO - 2018-04-10 22:22:56 --> Loader Class Initialized
INFO - 2018-04-10 22:22:56 --> Helper loaded: url_helper
INFO - 2018-04-10 22:22:57 --> Helper loaded: form_helper
INFO - 2018-04-10 22:22:57 --> Helper loaded: language_helper
DEBUG - 2018-04-10 22:22:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 22:22:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 22:22:57 --> User Agent Class Initialized
INFO - 2018-04-10 22:22:57 --> Controller Class Initialized
INFO - 2018-04-10 22:22:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 22:22:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-10 22:22:57 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 22:22:57 --> File loaded: E:\www\yacopoo\application\views\lawyer.php
INFO - 2018-04-10 22:22:57 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 22:22:57 --> Final output sent to browser
DEBUG - 2018-04-10 22:22:57 --> Total execution time: 0.4249
INFO - 2018-04-10 22:22:57 --> Config Class Initialized
INFO - 2018-04-10 22:22:57 --> Hooks Class Initialized
DEBUG - 2018-04-10 22:22:57 --> UTF-8 Support Enabled
INFO - 2018-04-10 22:22:57 --> Utf8 Class Initialized
INFO - 2018-04-10 22:22:57 --> URI Class Initialized
INFO - 2018-04-10 22:22:57 --> Router Class Initialized
INFO - 2018-04-10 22:22:57 --> Output Class Initialized
INFO - 2018-04-10 22:22:57 --> Security Class Initialized
DEBUG - 2018-04-10 22:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 22:22:57 --> CSRF cookie sent
INFO - 2018-04-10 22:22:57 --> Input Class Initialized
INFO - 2018-04-10 22:22:57 --> Language Class Initialized
ERROR - 2018-04-10 22:22:57 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 22:23:04 --> Config Class Initialized
INFO - 2018-04-10 22:23:04 --> Hooks Class Initialized
DEBUG - 2018-04-10 22:23:04 --> UTF-8 Support Enabled
INFO - 2018-04-10 22:23:04 --> Utf8 Class Initialized
INFO - 2018-04-10 22:23:04 --> URI Class Initialized
INFO - 2018-04-10 22:23:04 --> Router Class Initialized
INFO - 2018-04-10 22:23:04 --> Output Class Initialized
INFO - 2018-04-10 22:23:04 --> Security Class Initialized
DEBUG - 2018-04-10 22:23:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 22:23:05 --> CSRF cookie sent
INFO - 2018-04-10 22:23:05 --> Input Class Initialized
INFO - 2018-04-10 22:23:05 --> Language Class Initialized
INFO - 2018-04-10 22:23:05 --> Loader Class Initialized
INFO - 2018-04-10 22:23:05 --> Helper loaded: url_helper
INFO - 2018-04-10 22:23:05 --> Helper loaded: form_helper
INFO - 2018-04-10 22:23:05 --> Helper loaded: language_helper
DEBUG - 2018-04-10 22:23:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 22:23:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 22:23:05 --> User Agent Class Initialized
INFO - 2018-04-10 22:23:05 --> Controller Class Initialized
INFO - 2018-04-10 22:23:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 22:23:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-10 22:23:05 --> CSRF cookie sent
INFO - 2018-04-10 22:23:05 --> Config Class Initialized
INFO - 2018-04-10 22:23:05 --> Hooks Class Initialized
DEBUG - 2018-04-10 22:23:05 --> UTF-8 Support Enabled
INFO - 2018-04-10 22:23:05 --> Utf8 Class Initialized
INFO - 2018-04-10 22:23:05 --> URI Class Initialized
DEBUG - 2018-04-10 22:23:05 --> No URI present. Default controller set.
INFO - 2018-04-10 22:23:05 --> Router Class Initialized
INFO - 2018-04-10 22:23:05 --> Output Class Initialized
INFO - 2018-04-10 22:23:05 --> Security Class Initialized
DEBUG - 2018-04-10 22:23:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 22:23:05 --> CSRF cookie sent
INFO - 2018-04-10 22:23:05 --> Input Class Initialized
INFO - 2018-04-10 22:23:05 --> Language Class Initialized
INFO - 2018-04-10 22:23:05 --> Loader Class Initialized
INFO - 2018-04-10 22:23:05 --> Helper loaded: url_helper
INFO - 2018-04-10 22:23:05 --> Helper loaded: form_helper
INFO - 2018-04-10 22:23:05 --> Helper loaded: language_helper
DEBUG - 2018-04-10 22:23:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 22:23:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 22:23:05 --> User Agent Class Initialized
INFO - 2018-04-10 22:23:05 --> Controller Class Initialized
INFO - 2018-04-10 22:23:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 22:23:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-10 22:23:05 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 22:23:05 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-10 22:23:05 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 22:23:05 --> Final output sent to browser
DEBUG - 2018-04-10 22:23:05 --> Total execution time: 0.4227
INFO - 2018-04-10 22:23:06 --> Config Class Initialized
INFO - 2018-04-10 22:23:06 --> Hooks Class Initialized
DEBUG - 2018-04-10 22:23:06 --> UTF-8 Support Enabled
INFO - 2018-04-10 22:23:06 --> Utf8 Class Initialized
INFO - 2018-04-10 22:23:06 --> URI Class Initialized
INFO - 2018-04-10 22:23:06 --> Router Class Initialized
INFO - 2018-04-10 22:23:06 --> Output Class Initialized
INFO - 2018-04-10 22:23:06 --> Security Class Initialized
DEBUG - 2018-04-10 22:23:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 22:23:06 --> CSRF cookie sent
INFO - 2018-04-10 22:23:06 --> Input Class Initialized
INFO - 2018-04-10 22:23:06 --> Language Class Initialized
ERROR - 2018-04-10 22:23:06 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 22:23:07 --> Config Class Initialized
INFO - 2018-04-10 22:23:07 --> Hooks Class Initialized
DEBUG - 2018-04-10 22:23:07 --> UTF-8 Support Enabled
INFO - 2018-04-10 22:23:07 --> Utf8 Class Initialized
INFO - 2018-04-10 22:23:07 --> URI Class Initialized
INFO - 2018-04-10 22:23:07 --> Router Class Initialized
INFO - 2018-04-10 22:23:07 --> Output Class Initialized
INFO - 2018-04-10 22:23:07 --> Security Class Initialized
DEBUG - 2018-04-10 22:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 22:23:08 --> CSRF cookie sent
INFO - 2018-04-10 22:23:08 --> Input Class Initialized
INFO - 2018-04-10 22:23:08 --> Language Class Initialized
ERROR - 2018-04-10 22:23:08 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-10 22:26:20 --> Config Class Initialized
INFO - 2018-04-10 22:26:20 --> Hooks Class Initialized
DEBUG - 2018-04-10 22:26:20 --> UTF-8 Support Enabled
INFO - 2018-04-10 22:26:20 --> Utf8 Class Initialized
INFO - 2018-04-10 22:26:20 --> URI Class Initialized
INFO - 2018-04-10 22:26:20 --> Router Class Initialized
INFO - 2018-04-10 22:26:20 --> Output Class Initialized
INFO - 2018-04-10 22:26:20 --> Security Class Initialized
DEBUG - 2018-04-10 22:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 22:26:20 --> CSRF cookie sent
INFO - 2018-04-10 22:26:20 --> Input Class Initialized
INFO - 2018-04-10 22:26:20 --> Language Class Initialized
INFO - 2018-04-10 22:26:20 --> Loader Class Initialized
INFO - 2018-04-10 22:26:20 --> Helper loaded: url_helper
INFO - 2018-04-10 22:26:20 --> Helper loaded: form_helper
INFO - 2018-04-10 22:26:20 --> Helper loaded: language_helper
DEBUG - 2018-04-10 22:26:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 22:26:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 22:26:20 --> User Agent Class Initialized
INFO - 2018-04-10 22:26:20 --> Controller Class Initialized
INFO - 2018-04-10 22:26:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 22:26:20 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 22:26:20 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 22:26:20 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 22:26:20 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 22:26:21 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-10 22:26:21 --> Could not find the language line "req_email"
INFO - 2018-04-10 22:26:21 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-04-10 22:26:21 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 22:26:21 --> Final output sent to browser
DEBUG - 2018-04-10 22:26:21 --> Total execution time: 0.7504
INFO - 2018-04-10 22:26:21 --> Config Class Initialized
INFO - 2018-04-10 22:26:21 --> Hooks Class Initialized
DEBUG - 2018-04-10 22:26:21 --> UTF-8 Support Enabled
INFO - 2018-04-10 22:26:21 --> Utf8 Class Initialized
INFO - 2018-04-10 22:26:21 --> URI Class Initialized
INFO - 2018-04-10 22:26:21 --> Router Class Initialized
INFO - 2018-04-10 22:26:21 --> Output Class Initialized
INFO - 2018-04-10 22:26:21 --> Security Class Initialized
DEBUG - 2018-04-10 22:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 22:26:21 --> CSRF cookie sent
INFO - 2018-04-10 22:26:21 --> Input Class Initialized
INFO - 2018-04-10 22:26:21 --> Language Class Initialized
ERROR - 2018-04-10 22:26:21 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 22:26:23 --> Config Class Initialized
INFO - 2018-04-10 22:26:23 --> Hooks Class Initialized
DEBUG - 2018-04-10 22:26:23 --> UTF-8 Support Enabled
INFO - 2018-04-10 22:26:23 --> Utf8 Class Initialized
INFO - 2018-04-10 22:26:23 --> URI Class Initialized
INFO - 2018-04-10 22:26:23 --> Router Class Initialized
INFO - 2018-04-10 22:26:23 --> Output Class Initialized
INFO - 2018-04-10 22:26:23 --> Security Class Initialized
DEBUG - 2018-04-10 22:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 22:26:23 --> CSRF cookie sent
INFO - 2018-04-10 22:26:23 --> Input Class Initialized
INFO - 2018-04-10 22:26:23 --> Language Class Initialized
INFO - 2018-04-10 22:26:23 --> Loader Class Initialized
INFO - 2018-04-10 22:26:23 --> Helper loaded: url_helper
INFO - 2018-04-10 22:26:23 --> Helper loaded: form_helper
INFO - 2018-04-10 22:26:23 --> Helper loaded: language_helper
DEBUG - 2018-04-10 22:26:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 22:26:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 22:26:23 --> User Agent Class Initialized
INFO - 2018-04-10 22:26:23 --> Controller Class Initialized
INFO - 2018-04-10 22:26:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 22:26:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-10 22:26:24 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 22:28:09 --> Config Class Initialized
INFO - 2018-04-10 22:28:09 --> Hooks Class Initialized
DEBUG - 2018-04-10 22:28:09 --> UTF-8 Support Enabled
INFO - 2018-04-10 22:28:09 --> Utf8 Class Initialized
INFO - 2018-04-10 22:28:09 --> URI Class Initialized
INFO - 2018-04-10 22:28:09 --> Router Class Initialized
INFO - 2018-04-10 22:28:09 --> Output Class Initialized
INFO - 2018-04-10 22:28:09 --> Security Class Initialized
DEBUG - 2018-04-10 22:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 22:28:09 --> CSRF cookie sent
INFO - 2018-04-10 22:28:09 --> Input Class Initialized
INFO - 2018-04-10 22:28:09 --> Language Class Initialized
INFO - 2018-04-10 22:28:09 --> Loader Class Initialized
INFO - 2018-04-10 22:28:09 --> Helper loaded: url_helper
INFO - 2018-04-10 22:28:09 --> Helper loaded: form_helper
INFO - 2018-04-10 22:28:09 --> Helper loaded: language_helper
DEBUG - 2018-04-10 22:28:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 22:28:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 22:28:10 --> User Agent Class Initialized
INFO - 2018-04-10 22:28:10 --> Controller Class Initialized
INFO - 2018-04-10 22:28:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 22:28:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-10 22:28:10 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 22:28:10 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 22:28:10 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-10 22:28:10 --> Could not find the language line "req_email"
ERROR - 2018-04-10 22:28:10 --> Severity: Notice --> Undefined variable: widget E:\www\yacopoo\application\views\myaccount\forgot_password.php 23
ERROR - 2018-04-10 22:28:10 --> Severity: Notice --> Undefined variable: script E:\www\yacopoo\application\views\myaccount\forgot_password.php 24
INFO - 2018-04-10 22:28:10 --> File loaded: E:\www\yacopoo\application\views\myaccount/forgot_password.php
INFO - 2018-04-10 22:28:10 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 22:28:10 --> Final output sent to browser
DEBUG - 2018-04-10 22:28:10 --> Total execution time: 1.7941
INFO - 2018-04-10 22:28:11 --> Config Class Initialized
INFO - 2018-04-10 22:28:11 --> Hooks Class Initialized
DEBUG - 2018-04-10 22:28:11 --> UTF-8 Support Enabled
INFO - 2018-04-10 22:28:11 --> Utf8 Class Initialized
INFO - 2018-04-10 22:28:11 --> URI Class Initialized
INFO - 2018-04-10 22:28:11 --> Router Class Initialized
INFO - 2018-04-10 22:28:11 --> Output Class Initialized
INFO - 2018-04-10 22:28:11 --> Security Class Initialized
DEBUG - 2018-04-10 22:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 22:28:11 --> CSRF cookie sent
INFO - 2018-04-10 22:28:11 --> Input Class Initialized
INFO - 2018-04-10 22:28:11 --> Language Class Initialized
ERROR - 2018-04-10 22:28:11 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 22:29:03 --> Config Class Initialized
INFO - 2018-04-10 22:29:03 --> Hooks Class Initialized
DEBUG - 2018-04-10 22:29:03 --> UTF-8 Support Enabled
INFO - 2018-04-10 22:29:03 --> Utf8 Class Initialized
INFO - 2018-04-10 22:29:03 --> URI Class Initialized
INFO - 2018-04-10 22:29:03 --> Router Class Initialized
INFO - 2018-04-10 22:29:03 --> Output Class Initialized
INFO - 2018-04-10 22:29:03 --> Security Class Initialized
DEBUG - 2018-04-10 22:29:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 22:29:03 --> CSRF cookie sent
INFO - 2018-04-10 22:29:03 --> Input Class Initialized
INFO - 2018-04-10 22:29:04 --> Language Class Initialized
INFO - 2018-04-10 22:29:04 --> Loader Class Initialized
INFO - 2018-04-10 22:29:04 --> Helper loaded: url_helper
INFO - 2018-04-10 22:29:04 --> Helper loaded: form_helper
INFO - 2018-04-10 22:29:04 --> Helper loaded: language_helper
DEBUG - 2018-04-10 22:29:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 22:29:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 22:29:04 --> User Agent Class Initialized
INFO - 2018-04-10 22:29:04 --> Controller Class Initialized
INFO - 2018-04-10 22:29:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 22:29:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-10 22:29:04 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 22:29:04 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 22:29:04 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-10 22:29:04 --> Could not find the language line "req_email"
ERROR - 2018-04-10 22:29:04 --> Severity: Notice --> Undefined variable: widget E:\www\yacopoo\application\views\myaccount\forgot_password.php 23
ERROR - 2018-04-10 22:29:04 --> Severity: Notice --> Undefined variable: script E:\www\yacopoo\application\views\myaccount\forgot_password.php 24
INFO - 2018-04-10 22:29:04 --> File loaded: E:\www\yacopoo\application\views\myaccount/forgot_password.php
INFO - 2018-04-10 22:29:04 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 22:29:04 --> Final output sent to browser
DEBUG - 2018-04-10 22:29:04 --> Total execution time: 0.7903
INFO - 2018-04-10 22:29:05 --> Config Class Initialized
INFO - 2018-04-10 22:29:05 --> Hooks Class Initialized
DEBUG - 2018-04-10 22:29:05 --> UTF-8 Support Enabled
INFO - 2018-04-10 22:29:05 --> Utf8 Class Initialized
INFO - 2018-04-10 22:29:05 --> URI Class Initialized
INFO - 2018-04-10 22:29:05 --> Router Class Initialized
INFO - 2018-04-10 22:29:05 --> Output Class Initialized
INFO - 2018-04-10 22:29:05 --> Security Class Initialized
DEBUG - 2018-04-10 22:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 22:29:05 --> CSRF cookie sent
INFO - 2018-04-10 22:29:05 --> Input Class Initialized
INFO - 2018-04-10 22:29:05 --> Language Class Initialized
ERROR - 2018-04-10 22:29:05 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 22:31:33 --> Config Class Initialized
INFO - 2018-04-10 22:31:33 --> Hooks Class Initialized
DEBUG - 2018-04-10 22:31:33 --> UTF-8 Support Enabled
INFO - 2018-04-10 22:31:33 --> Utf8 Class Initialized
INFO - 2018-04-10 22:31:33 --> URI Class Initialized
INFO - 2018-04-10 22:31:33 --> Router Class Initialized
INFO - 2018-04-10 22:31:33 --> Output Class Initialized
INFO - 2018-04-10 22:31:33 --> Security Class Initialized
DEBUG - 2018-04-10 22:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 22:31:33 --> CSRF cookie sent
INFO - 2018-04-10 22:31:33 --> Input Class Initialized
INFO - 2018-04-10 22:31:33 --> Language Class Initialized
INFO - 2018-04-10 22:31:33 --> Loader Class Initialized
INFO - 2018-04-10 22:31:33 --> Helper loaded: url_helper
INFO - 2018-04-10 22:31:33 --> Helper loaded: form_helper
INFO - 2018-04-10 22:31:33 --> Helper loaded: language_helper
DEBUG - 2018-04-10 22:31:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 22:31:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 22:31:33 --> User Agent Class Initialized
INFO - 2018-04-10 22:31:33 --> Controller Class Initialized
INFO - 2018-04-10 22:31:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 22:31:33 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 22:31:34 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 22:31:34 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 22:31:34 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 22:31:34 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-10 22:31:34 --> Could not find the language line "req_email"
ERROR - 2018-04-10 22:31:34 --> Severity: Notice --> Undefined variable: widget E:\www\yacopoo\application\views\myaccount\forgot_password.php 23
ERROR - 2018-04-10 22:31:34 --> Severity: Notice --> Undefined variable: script E:\www\yacopoo\application\views\myaccount\forgot_password.php 24
INFO - 2018-04-10 22:31:34 --> File loaded: E:\www\yacopoo\application\views\myaccount/forgot_password.php
INFO - 2018-04-10 22:31:34 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 22:31:34 --> Final output sent to browser
DEBUG - 2018-04-10 22:31:34 --> Total execution time: 0.5719
INFO - 2018-04-10 22:31:35 --> Config Class Initialized
INFO - 2018-04-10 22:31:35 --> Hooks Class Initialized
DEBUG - 2018-04-10 22:31:35 --> UTF-8 Support Enabled
INFO - 2018-04-10 22:31:35 --> Utf8 Class Initialized
INFO - 2018-04-10 22:31:35 --> URI Class Initialized
INFO - 2018-04-10 22:31:35 --> Router Class Initialized
INFO - 2018-04-10 22:31:35 --> Output Class Initialized
INFO - 2018-04-10 22:31:35 --> Security Class Initialized
DEBUG - 2018-04-10 22:31:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 22:31:35 --> CSRF cookie sent
INFO - 2018-04-10 22:31:35 --> Input Class Initialized
INFO - 2018-04-10 22:31:35 --> Language Class Initialized
ERROR - 2018-04-10 22:31:35 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 22:31:49 --> Config Class Initialized
INFO - 2018-04-10 22:31:49 --> Hooks Class Initialized
DEBUG - 2018-04-10 22:31:49 --> UTF-8 Support Enabled
INFO - 2018-04-10 22:31:49 --> Utf8 Class Initialized
INFO - 2018-04-10 22:31:49 --> URI Class Initialized
INFO - 2018-04-10 22:31:49 --> Router Class Initialized
INFO - 2018-04-10 22:31:49 --> Output Class Initialized
INFO - 2018-04-10 22:31:49 --> Security Class Initialized
DEBUG - 2018-04-10 22:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 22:31:49 --> CSRF cookie sent
INFO - 2018-04-10 22:31:50 --> Input Class Initialized
INFO - 2018-04-10 22:31:50 --> Language Class Initialized
INFO - 2018-04-10 22:31:50 --> Loader Class Initialized
INFO - 2018-04-10 22:31:50 --> Helper loaded: url_helper
INFO - 2018-04-10 22:31:50 --> Helper loaded: form_helper
INFO - 2018-04-10 22:31:50 --> Helper loaded: language_helper
DEBUG - 2018-04-10 22:31:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 22:31:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 22:31:50 --> User Agent Class Initialized
INFO - 2018-04-10 22:31:50 --> Controller Class Initialized
INFO - 2018-04-10 22:31:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 22:31:50 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 22:31:50 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 22:31:50 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 22:31:50 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 22:31:50 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-10 22:31:50 --> Could not find the language line "req_email"
INFO - 2018-04-10 22:31:50 --> File loaded: E:\www\yacopoo\application\views\myaccount/forgot_password.php
INFO - 2018-04-10 22:31:50 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 22:31:50 --> Final output sent to browser
DEBUG - 2018-04-10 22:31:50 --> Total execution time: 0.8873
INFO - 2018-04-10 22:31:51 --> Config Class Initialized
INFO - 2018-04-10 22:31:52 --> Hooks Class Initialized
DEBUG - 2018-04-10 22:31:52 --> UTF-8 Support Enabled
INFO - 2018-04-10 22:31:52 --> Utf8 Class Initialized
INFO - 2018-04-10 22:31:52 --> URI Class Initialized
INFO - 2018-04-10 22:31:52 --> Router Class Initialized
INFO - 2018-04-10 22:31:52 --> Output Class Initialized
INFO - 2018-04-10 22:31:52 --> Security Class Initialized
DEBUG - 2018-04-10 22:31:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 22:31:52 --> CSRF cookie sent
INFO - 2018-04-10 22:31:52 --> Input Class Initialized
INFO - 2018-04-10 22:31:52 --> Language Class Initialized
ERROR - 2018-04-10 22:31:52 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 22:32:19 --> Config Class Initialized
INFO - 2018-04-10 22:32:19 --> Hooks Class Initialized
DEBUG - 2018-04-10 22:32:19 --> UTF-8 Support Enabled
INFO - 2018-04-10 22:32:19 --> Utf8 Class Initialized
INFO - 2018-04-10 22:32:19 --> URI Class Initialized
INFO - 2018-04-10 22:32:19 --> Router Class Initialized
INFO - 2018-04-10 22:32:19 --> Output Class Initialized
INFO - 2018-04-10 22:32:19 --> Security Class Initialized
DEBUG - 2018-04-10 22:32:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 22:32:19 --> CSRF cookie sent
INFO - 2018-04-10 22:32:19 --> Input Class Initialized
INFO - 2018-04-10 22:32:19 --> Language Class Initialized
INFO - 2018-04-10 22:32:19 --> Loader Class Initialized
INFO - 2018-04-10 22:32:19 --> Helper loaded: url_helper
INFO - 2018-04-10 22:32:19 --> Helper loaded: form_helper
INFO - 2018-04-10 22:32:19 --> Helper loaded: language_helper
DEBUG - 2018-04-10 22:32:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 22:32:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 22:32:19 --> User Agent Class Initialized
INFO - 2018-04-10 22:32:19 --> Controller Class Initialized
INFO - 2018-04-10 22:32:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 22:32:19 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 22:32:20 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 22:32:20 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 22:32:20 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 22:32:20 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-10 22:32:20 --> Could not find the language line "req_email"
INFO - 2018-04-10 22:32:20 --> File loaded: E:\www\yacopoo\application\views\myaccount/forgot_password.php
INFO - 2018-04-10 22:32:20 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 22:32:20 --> Final output sent to browser
DEBUG - 2018-04-10 22:32:20 --> Total execution time: 0.6073
INFO - 2018-04-10 22:32:20 --> Config Class Initialized
INFO - 2018-04-10 22:32:20 --> Hooks Class Initialized
DEBUG - 2018-04-10 22:32:20 --> UTF-8 Support Enabled
INFO - 2018-04-10 22:32:20 --> Utf8 Class Initialized
INFO - 2018-04-10 22:32:20 --> URI Class Initialized
INFO - 2018-04-10 22:32:20 --> Router Class Initialized
INFO - 2018-04-10 22:32:20 --> Output Class Initialized
INFO - 2018-04-10 22:32:20 --> Security Class Initialized
DEBUG - 2018-04-10 22:32:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 22:32:20 --> CSRF cookie sent
INFO - 2018-04-10 22:32:20 --> Input Class Initialized
INFO - 2018-04-10 22:32:20 --> Language Class Initialized
ERROR - 2018-04-10 22:32:20 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 22:34:35 --> Config Class Initialized
INFO - 2018-04-10 22:34:35 --> Hooks Class Initialized
DEBUG - 2018-04-10 22:34:35 --> UTF-8 Support Enabled
INFO - 2018-04-10 22:34:35 --> Utf8 Class Initialized
INFO - 2018-04-10 22:34:35 --> URI Class Initialized
INFO - 2018-04-10 22:34:35 --> Router Class Initialized
INFO - 2018-04-10 22:34:35 --> Output Class Initialized
INFO - 2018-04-10 22:34:35 --> Security Class Initialized
DEBUG - 2018-04-10 22:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 22:34:35 --> CSRF cookie sent
INFO - 2018-04-10 22:34:35 --> Input Class Initialized
INFO - 2018-04-10 22:34:36 --> Language Class Initialized
INFO - 2018-04-10 22:34:36 --> Loader Class Initialized
INFO - 2018-04-10 22:34:36 --> Helper loaded: url_helper
INFO - 2018-04-10 22:34:36 --> Helper loaded: form_helper
INFO - 2018-04-10 22:34:36 --> Helper loaded: language_helper
DEBUG - 2018-04-10 22:34:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 22:34:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 22:34:36 --> User Agent Class Initialized
INFO - 2018-04-10 22:34:36 --> Controller Class Initialized
INFO - 2018-04-10 22:34:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 22:34:36 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 22:34:36 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 22:34:36 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 22:34:37 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 22:34:37 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-10 22:34:37 --> Could not find the language line "req_email"
INFO - 2018-04-10 22:34:37 --> File loaded: E:\www\yacopoo\application\views\myaccount/forgot_password.php
INFO - 2018-04-10 22:34:37 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 22:34:37 --> Final output sent to browser
DEBUG - 2018-04-10 22:34:37 --> Total execution time: 2.5359
INFO - 2018-04-10 22:35:07 --> Config Class Initialized
INFO - 2018-04-10 22:35:07 --> Hooks Class Initialized
DEBUG - 2018-04-10 22:35:07 --> UTF-8 Support Enabled
INFO - 2018-04-10 22:35:07 --> Utf8 Class Initialized
INFO - 2018-04-10 22:35:07 --> URI Class Initialized
INFO - 2018-04-10 22:35:08 --> Router Class Initialized
INFO - 2018-04-10 22:35:08 --> Output Class Initialized
INFO - 2018-04-10 22:35:08 --> Security Class Initialized
DEBUG - 2018-04-10 22:35:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 22:35:08 --> CSRF cookie sent
INFO - 2018-04-10 22:35:08 --> Input Class Initialized
INFO - 2018-04-10 22:35:08 --> Language Class Initialized
INFO - 2018-04-10 22:35:08 --> Loader Class Initialized
INFO - 2018-04-10 22:35:08 --> Helper loaded: url_helper
INFO - 2018-04-10 22:35:08 --> Helper loaded: form_helper
INFO - 2018-04-10 22:35:08 --> Helper loaded: language_helper
DEBUG - 2018-04-10 22:35:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 22:35:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 22:35:08 --> User Agent Class Initialized
INFO - 2018-04-10 22:35:08 --> Controller Class Initialized
INFO - 2018-04-10 22:35:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 22:35:08 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 22:35:08 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 22:35:09 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 22:35:09 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 22:35:09 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-10 22:35:09 --> Could not find the language line "req_email"
INFO - 2018-04-10 22:35:09 --> File loaded: E:\www\yacopoo\application\views\myaccount/forgot_password.php
INFO - 2018-04-10 22:35:09 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 22:35:09 --> Final output sent to browser
DEBUG - 2018-04-10 22:35:09 --> Total execution time: 1.8838
INFO - 2018-04-10 22:35:37 --> Config Class Initialized
INFO - 2018-04-10 22:35:38 --> Hooks Class Initialized
DEBUG - 2018-04-10 22:35:38 --> UTF-8 Support Enabled
INFO - 2018-04-10 22:35:38 --> Utf8 Class Initialized
INFO - 2018-04-10 22:35:38 --> URI Class Initialized
INFO - 2018-04-10 22:35:38 --> Router Class Initialized
INFO - 2018-04-10 22:35:38 --> Output Class Initialized
INFO - 2018-04-10 22:35:38 --> Security Class Initialized
DEBUG - 2018-04-10 22:35:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 22:35:38 --> CSRF cookie sent
INFO - 2018-04-10 22:35:38 --> Input Class Initialized
INFO - 2018-04-10 22:35:38 --> Language Class Initialized
INFO - 2018-04-10 22:35:38 --> Loader Class Initialized
INFO - 2018-04-10 22:35:38 --> Helper loaded: url_helper
INFO - 2018-04-10 22:35:38 --> Helper loaded: form_helper
INFO - 2018-04-10 22:35:38 --> Helper loaded: language_helper
DEBUG - 2018-04-10 22:35:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 22:35:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 22:35:38 --> User Agent Class Initialized
INFO - 2018-04-10 22:35:38 --> Controller Class Initialized
INFO - 2018-04-10 22:35:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 22:35:38 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 22:35:38 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 22:35:38 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 22:35:38 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 22:35:38 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-10 22:35:38 --> Could not find the language line "req_email"
INFO - 2018-04-10 22:35:38 --> File loaded: E:\www\yacopoo\application\views\myaccount/forgot_password.php
INFO - 2018-04-10 22:35:38 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 22:35:38 --> Final output sent to browser
DEBUG - 2018-04-10 22:35:38 --> Total execution time: 0.5038
INFO - 2018-04-10 22:39:36 --> Config Class Initialized
INFO - 2018-04-10 22:39:36 --> Hooks Class Initialized
DEBUG - 2018-04-10 22:39:36 --> UTF-8 Support Enabled
INFO - 2018-04-10 22:39:36 --> Utf8 Class Initialized
INFO - 2018-04-10 22:39:36 --> URI Class Initialized
INFO - 2018-04-10 22:39:36 --> Router Class Initialized
INFO - 2018-04-10 22:39:36 --> Output Class Initialized
INFO - 2018-04-10 22:39:36 --> Security Class Initialized
DEBUG - 2018-04-10 22:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 22:39:36 --> CSRF cookie sent
INFO - 2018-04-10 22:39:36 --> CSRF token verified
INFO - 2018-04-10 22:39:36 --> Input Class Initialized
INFO - 2018-04-10 22:39:36 --> Language Class Initialized
INFO - 2018-04-10 22:39:36 --> Loader Class Initialized
INFO - 2018-04-10 22:39:36 --> Helper loaded: url_helper
INFO - 2018-04-10 22:39:36 --> Helper loaded: form_helper
INFO - 2018-04-10 22:39:36 --> Helper loaded: language_helper
DEBUG - 2018-04-10 22:39:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 22:39:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 22:39:36 --> User Agent Class Initialized
INFO - 2018-04-10 22:39:36 --> Controller Class Initialized
INFO - 2018-04-10 22:39:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 22:39:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-10 22:39:36 --> Form Validation Class Initialized
INFO - 2018-04-10 22:39:36 --> Language file loaded: language/en/notifications_lang.php
INFO - 2018-04-10 22:39:36 --> Pixel_Model class loaded
INFO - 2018-04-10 22:39:36 --> Database Driver Class Initialized
INFO - 2018-04-10 22:39:39 --> Model "AuthenticationModel" initialized
INFO - 2018-04-10 22:39:39 --> Helper loaded: string_helper
INFO - 2018-04-10 22:39:40 --> File loaded: E:\www\yacopoo\application\views\emails/header.php
INFO - 2018-04-10 22:39:40 --> File loaded: E:\www\yacopoo\application\views\emails/footer.php
INFO - 2018-04-10 22:39:40 --> File loaded: E:\www\yacopoo\application\views\emails/generic.php
ERROR - 2018-04-10 22:39:40 --> Severity: Error --> Call to undefined method AuthenticationController::getCompanyId() E:\www\yacopoo\application\libraries\EmailsHelper.php 102
INFO - 2018-04-10 22:40:10 --> Config Class Initialized
INFO - 2018-04-10 22:40:10 --> Hooks Class Initialized
DEBUG - 2018-04-10 22:40:10 --> UTF-8 Support Enabled
INFO - 2018-04-10 22:40:10 --> Utf8 Class Initialized
INFO - 2018-04-10 22:40:10 --> URI Class Initialized
INFO - 2018-04-10 22:40:10 --> Router Class Initialized
INFO - 2018-04-10 22:40:10 --> Output Class Initialized
INFO - 2018-04-10 22:40:10 --> Security Class Initialized
DEBUG - 2018-04-10 22:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 22:40:10 --> CSRF cookie sent
INFO - 2018-04-10 22:40:10 --> CSRF token verified
INFO - 2018-04-10 22:40:10 --> Input Class Initialized
INFO - 2018-04-10 22:40:10 --> Language Class Initialized
INFO - 2018-04-10 22:40:10 --> Loader Class Initialized
INFO - 2018-04-10 22:40:10 --> Helper loaded: url_helper
INFO - 2018-04-10 22:40:11 --> Helper loaded: form_helper
INFO - 2018-04-10 22:40:11 --> Helper loaded: language_helper
DEBUG - 2018-04-10 22:40:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 22:40:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 22:40:11 --> User Agent Class Initialized
INFO - 2018-04-10 22:40:11 --> Controller Class Initialized
INFO - 2018-04-10 22:40:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 22:40:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-10 22:40:11 --> Form Validation Class Initialized
INFO - 2018-04-10 22:40:11 --> Language file loaded: language/en/notifications_lang.php
INFO - 2018-04-10 22:40:11 --> Pixel_Model class loaded
INFO - 2018-04-10 22:40:11 --> Database Driver Class Initialized
INFO - 2018-04-10 22:40:14 --> Model "AuthenticationModel" initialized
INFO - 2018-04-10 22:40:14 --> Config Class Initialized
INFO - 2018-04-10 22:40:14 --> Hooks Class Initialized
DEBUG - 2018-04-10 22:40:14 --> UTF-8 Support Enabled
INFO - 2018-04-10 22:40:14 --> Utf8 Class Initialized
INFO - 2018-04-10 22:40:14 --> URI Class Initialized
INFO - 2018-04-10 22:40:14 --> Router Class Initialized
INFO - 2018-04-10 22:40:14 --> Output Class Initialized
INFO - 2018-04-10 22:40:14 --> Security Class Initialized
DEBUG - 2018-04-10 22:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 22:40:14 --> CSRF cookie sent
INFO - 2018-04-10 22:40:14 --> Input Class Initialized
INFO - 2018-04-10 22:40:14 --> Language Class Initialized
INFO - 2018-04-10 22:40:14 --> Loader Class Initialized
INFO - 2018-04-10 22:40:14 --> Helper loaded: url_helper
INFO - 2018-04-10 22:40:14 --> Helper loaded: form_helper
INFO - 2018-04-10 22:40:14 --> Helper loaded: language_helper
DEBUG - 2018-04-10 22:40:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 22:40:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 22:40:14 --> User Agent Class Initialized
INFO - 2018-04-10 22:40:14 --> Controller Class Initialized
INFO - 2018-04-10 22:40:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 22:40:14 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 22:40:14 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 22:40:14 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 22:40:14 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 22:40:14 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-10 22:40:14 --> File loaded: E:\www\yacopoo\application\views\shared/_soft_error.php
ERROR - 2018-04-10 22:40:14 --> Could not find the language line "req_email"
INFO - 2018-04-10 22:40:14 --> File loaded: E:\www\yacopoo\application\views\myaccount/forgot_password.php
INFO - 2018-04-10 22:40:14 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 22:40:14 --> Final output sent to browser
DEBUG - 2018-04-10 22:40:14 --> Total execution time: 0.4936
INFO - 2018-04-10 22:40:15 --> Config Class Initialized
INFO - 2018-04-10 22:40:15 --> Config Class Initialized
INFO - 2018-04-10 22:40:15 --> Hooks Class Initialized
INFO - 2018-04-10 22:40:15 --> Hooks Class Initialized
DEBUG - 2018-04-10 22:40:15 --> UTF-8 Support Enabled
INFO - 2018-04-10 22:40:15 --> Config Class Initialized
INFO - 2018-04-10 22:40:15 --> Utf8 Class Initialized
DEBUG - 2018-04-10 22:40:15 --> UTF-8 Support Enabled
INFO - 2018-04-10 22:40:15 --> Utf8 Class Initialized
INFO - 2018-04-10 22:40:15 --> Hooks Class Initialized
INFO - 2018-04-10 22:40:15 --> URI Class Initialized
INFO - 2018-04-10 22:40:15 --> URI Class Initialized
INFO - 2018-04-10 22:40:15 --> Router Class Initialized
DEBUG - 2018-04-10 22:40:15 --> UTF-8 Support Enabled
INFO - 2018-04-10 22:40:15 --> Utf8 Class Initialized
INFO - 2018-04-10 22:40:15 --> Output Class Initialized
INFO - 2018-04-10 22:40:15 --> Router Class Initialized
INFO - 2018-04-10 22:40:15 --> URI Class Initialized
INFO - 2018-04-10 22:40:15 --> Security Class Initialized
INFO - 2018-04-10 22:40:15 --> Output Class Initialized
INFO - 2018-04-10 22:40:15 --> Security Class Initialized
DEBUG - 2018-04-10 22:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 22:40:15 --> Router Class Initialized
INFO - 2018-04-10 22:40:15 --> CSRF cookie sent
INFO - 2018-04-10 22:40:15 --> Output Class Initialized
DEBUG - 2018-04-10 22:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 22:40:15 --> CSRF cookie sent
INFO - 2018-04-10 22:40:15 --> Input Class Initialized
INFO - 2018-04-10 22:40:15 --> Security Class Initialized
INFO - 2018-04-10 22:40:15 --> Input Class Initialized
INFO - 2018-04-10 22:40:15 --> Language Class Initialized
DEBUG - 2018-04-10 22:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 22:40:15 --> CSRF cookie sent
INFO - 2018-04-10 22:40:15 --> Language Class Initialized
ERROR - 2018-04-10 22:40:15 --> 404 Page Not Found: Forgot-password/assets
INFO - 2018-04-10 22:40:15 --> Input Class Initialized
ERROR - 2018-04-10 22:40:15 --> 404 Page Not Found: Forgot-password/assets
INFO - 2018-04-10 22:40:15 --> Language Class Initialized
ERROR - 2018-04-10 22:40:15 --> 404 Page Not Found: Forgot-password/assets
INFO - 2018-04-10 23:05:15 --> Config Class Initialized
INFO - 2018-04-10 23:05:15 --> Hooks Class Initialized
DEBUG - 2018-04-10 23:05:15 --> UTF-8 Support Enabled
INFO - 2018-04-10 23:05:15 --> Utf8 Class Initialized
INFO - 2018-04-10 23:05:15 --> URI Class Initialized
INFO - 2018-04-10 23:05:15 --> Router Class Initialized
INFO - 2018-04-10 23:05:15 --> Output Class Initialized
INFO - 2018-04-10 23:05:15 --> Security Class Initialized
DEBUG - 2018-04-10 23:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 23:05:15 --> CSRF cookie sent
INFO - 2018-04-10 23:05:15 --> CSRF token verified
INFO - 2018-04-10 23:05:15 --> Input Class Initialized
INFO - 2018-04-10 23:05:16 --> Language Class Initialized
INFO - 2018-04-10 23:05:16 --> Loader Class Initialized
INFO - 2018-04-10 23:05:16 --> Helper loaded: url_helper
INFO - 2018-04-10 23:05:16 --> Helper loaded: form_helper
INFO - 2018-04-10 23:05:16 --> Helper loaded: language_helper
DEBUG - 2018-04-10 23:05:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 23:05:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 23:05:16 --> User Agent Class Initialized
INFO - 2018-04-10 23:05:16 --> Controller Class Initialized
INFO - 2018-04-10 23:05:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 23:05:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-10 23:05:16 --> Form Validation Class Initialized
INFO - 2018-04-10 23:05:16 --> Language file loaded: language/en/notifications_lang.php
INFO - 2018-04-10 23:05:16 --> Pixel_Model class loaded
INFO - 2018-04-10 23:05:16 --> Database Driver Class Initialized
INFO - 2018-04-10 23:05:19 --> Model "AuthenticationModel" initialized
INFO - 2018-04-10 23:05:56 --> Config Class Initialized
INFO - 2018-04-10 23:05:56 --> Hooks Class Initialized
DEBUG - 2018-04-10 23:05:56 --> UTF-8 Support Enabled
INFO - 2018-04-10 23:05:56 --> Utf8 Class Initialized
INFO - 2018-04-10 23:05:56 --> URI Class Initialized
INFO - 2018-04-10 23:05:56 --> Router Class Initialized
INFO - 2018-04-10 23:05:56 --> Output Class Initialized
INFO - 2018-04-10 23:05:56 --> Security Class Initialized
DEBUG - 2018-04-10 23:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 23:05:56 --> CSRF cookie sent
INFO - 2018-04-10 23:05:56 --> CSRF token verified
INFO - 2018-04-10 23:05:56 --> Input Class Initialized
INFO - 2018-04-10 23:05:56 --> Language Class Initialized
INFO - 2018-04-10 23:05:56 --> Loader Class Initialized
INFO - 2018-04-10 23:05:56 --> Helper loaded: url_helper
INFO - 2018-04-10 23:05:56 --> Helper loaded: form_helper
INFO - 2018-04-10 23:05:56 --> Helper loaded: language_helper
DEBUG - 2018-04-10 23:05:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 23:05:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 23:05:56 --> User Agent Class Initialized
INFO - 2018-04-10 23:05:56 --> Controller Class Initialized
INFO - 2018-04-10 23:05:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 23:05:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-10 23:05:57 --> Form Validation Class Initialized
INFO - 2018-04-10 23:05:57 --> Language file loaded: language/en/notifications_lang.php
INFO - 2018-04-10 23:05:57 --> Pixel_Model class loaded
INFO - 2018-04-10 23:05:57 --> Database Driver Class Initialized
INFO - 2018-04-10 23:06:00 --> Model "AuthenticationModel" initialized
INFO - 2018-04-10 23:06:00 --> Helper loaded: string_helper
INFO - 2018-04-10 23:06:00 --> File loaded: E:\www\yacopoo\application\views\emails/header.php
INFO - 2018-04-10 23:06:00 --> File loaded: E:\www\yacopoo\application\views\emails/footer.php
INFO - 2018-04-10 23:06:00 --> File loaded: E:\www\yacopoo\application\views\emails/generic.php
ERROR - 2018-04-10 23:06:00 --> Query error: Table 'yacopo.email_queue' doesn't exist - Invalid query: INSERT INTO `email_queue` (`to_email`, `subject`, `hash`, `message`, `attempts`, `success`, `date_published`, `type`, `language`) VALUES ('saqib@7thpixel.ca', 'Forgot your password?', '1b440d8e74ec2f13a980', '�\0\0\0\0\0�Xmo�6������--[����b�\r���V�톡Z:[D$Q��n���#�bɯqZ\Zv(�/w��=w�0Tq�8J��\n�J]۞���yGdS�{uue/��;j�Y���Z�?d�D5�fj�st�:f����G��y*2e�/�	���@��\0️m�p<ኳ�-}��q,����쫸��{G�\nK1� eR�E�����EOn!�p�+,I�	�\";S!���ˎ/bۗ���<Z��H1��#K�{�8g}��p2�F�R-#�!�:�Lqt�p���S�d��J\n�,_`�,o�|�x<�{�OC岙��}�W1��H�%H?CL�%<��\"����N�x~��F9����[\'ca[���j��O�\'�1{�c�<K�!��[����lʓv��\\��VŻ�2ˑ�d(S�H~�����u�_�L\"������ڻ������k��L��k����0��\"��z�n�?����\'}�\"�#S��dja�\'�}���_��MB,\\=���������o�ؘ�8�`���� >�r�wȳ��;�O~L���zj���&���n{��,����4�TW��ԑ���˫�tQ�%�R�\0�;��ڑ�떻+��H��j��H.�J��~*[��!Pjes\Z3Z��u/���)�5g�����c���� ��t�(\'�c�LGjW	�jI�rF$(5u^�0��:>��������Y��qĒ�Gh՜_��Ӷ�����GL�ӝ�����0GT��E%m�)Jcƣv$���&�R�GJ2����<�Ɏ�D�w�-�3��}����Xz��A�y���t�qzv�Qtf�1��Gz���ЅAJ9��iM$\\�� ��Ӯ�Jl�C��٩9�N}�����`j�r�zo�\")�ܤ\'1{����j�\n��Z�a2WC/;(aM���x-�\0��!4rۚ�ynm�B�P^E����J^����ٰ�դ�5��0[�����h��^l�K��������m�j$����PJ���x��A�H�����1Άc2}�>P�/f�U!�RQ$�tPaL��ˈ%@�It;�]�}1KT��sH�4�E\"k��2L��Ș�\"q!	6�:P\0\"5 �Ha��ȅ>�}�rs�_��Z����*�:w��ɟ�{��翨>%ѽR�C���2��t�a�j�3Hs3Q4�2��WD�Mw����R���M���Xc�F�ݻ鿬�??��[�u\'4�F(d�O!%~��q��M�ܙ�N��Ze \n�G%��Y���^��J��MZ͇�̿�f ���w7��-�rF\Z��Mku\"��j�NY�Ræ\r����iĖ�J���h8��d\Z��h�����x	_g(u��a����Κ���(������j���C�<m�b�SA��]�utU�|�|�!��o֒��f��W��}v��y�N\'j����\"gy\r=�;8��^�4֐�N<��GC�\'�B.!F)�F�9��p�*��K��qZ��(}b�2X�,\\�YqX-�O�\\�[%��X�qY�[���\04�f��y���Kx�\0\0', 1, 1, '2018-04-10 23:06:00', 0, 'en')
ERROR - 2018-04-10 23:06:00 --> Language file contains no data: language/en/db_lang.php
ERROR - 2018-04-10 23:06:00 --> Could not find the language line "db_error_heading"
INFO - 2018-04-10 23:07:27 --> Config Class Initialized
INFO - 2018-04-10 23:07:27 --> Hooks Class Initialized
DEBUG - 2018-04-10 23:07:27 --> UTF-8 Support Enabled
INFO - 2018-04-10 23:07:27 --> Utf8 Class Initialized
INFO - 2018-04-10 23:07:27 --> URI Class Initialized
INFO - 2018-04-10 23:07:27 --> Router Class Initialized
INFO - 2018-04-10 23:07:27 --> Output Class Initialized
INFO - 2018-04-10 23:07:27 --> Security Class Initialized
DEBUG - 2018-04-10 23:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 23:07:27 --> CSRF cookie sent
INFO - 2018-04-10 23:07:27 --> CSRF token verified
INFO - 2018-04-10 23:07:27 --> Input Class Initialized
INFO - 2018-04-10 23:07:27 --> Language Class Initialized
INFO - 2018-04-10 23:07:27 --> Loader Class Initialized
INFO - 2018-04-10 23:07:27 --> Helper loaded: url_helper
INFO - 2018-04-10 23:07:27 --> Helper loaded: form_helper
INFO - 2018-04-10 23:07:27 --> Helper loaded: language_helper
DEBUG - 2018-04-10 23:07:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 23:07:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 23:07:27 --> User Agent Class Initialized
INFO - 2018-04-10 23:07:27 --> Controller Class Initialized
INFO - 2018-04-10 23:07:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 23:07:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-10 23:07:27 --> Form Validation Class Initialized
INFO - 2018-04-10 23:07:27 --> Language file loaded: language/en/notifications_lang.php
INFO - 2018-04-10 23:07:28 --> Pixel_Model class loaded
INFO - 2018-04-10 23:07:28 --> Database Driver Class Initialized
INFO - 2018-04-10 23:07:28 --> Model "AuthenticationModel" initialized
INFO - 2018-04-10 23:07:28 --> Helper loaded: string_helper
INFO - 2018-04-10 23:07:28 --> File loaded: E:\www\yacopoo\application\views\emails/header.php
INFO - 2018-04-10 23:07:28 --> File loaded: E:\www\yacopoo\application\views\emails/footer.php
INFO - 2018-04-10 23:07:28 --> File loaded: E:\www\yacopoo\application\views\emails/generic.php
INFO - 2018-04-10 23:07:28 --> Email Class Initialized
INFO - 2018-04-10 23:07:28 --> Config Class Initialized
INFO - 2018-04-10 23:07:28 --> Hooks Class Initialized
DEBUG - 2018-04-10 23:07:28 --> UTF-8 Support Enabled
INFO - 2018-04-10 23:07:28 --> Utf8 Class Initialized
INFO - 2018-04-10 23:07:28 --> URI Class Initialized
INFO - 2018-04-10 23:07:28 --> Router Class Initialized
INFO - 2018-04-10 23:07:28 --> Output Class Initialized
INFO - 2018-04-10 23:07:28 --> Security Class Initialized
DEBUG - 2018-04-10 23:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 23:07:28 --> CSRF cookie sent
INFO - 2018-04-10 23:07:28 --> Input Class Initialized
INFO - 2018-04-10 23:07:28 --> Language Class Initialized
ERROR - 2018-04-10 23:07:28 --> 404 Page Not Found: Assets/images
INFO - 2018-04-10 23:07:50 --> Config Class Initialized
INFO - 2018-04-10 23:07:50 --> Hooks Class Initialized
DEBUG - 2018-04-10 23:07:50 --> UTF-8 Support Enabled
INFO - 2018-04-10 23:07:50 --> Utf8 Class Initialized
INFO - 2018-04-10 23:07:50 --> URI Class Initialized
DEBUG - 2018-04-10 23:07:50 --> No URI present. Default controller set.
INFO - 2018-04-10 23:07:50 --> Router Class Initialized
INFO - 2018-04-10 23:07:50 --> Output Class Initialized
INFO - 2018-04-10 23:07:50 --> Security Class Initialized
DEBUG - 2018-04-10 23:07:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 23:07:50 --> CSRF cookie sent
INFO - 2018-04-10 23:07:50 --> Input Class Initialized
INFO - 2018-04-10 23:07:50 --> Language Class Initialized
INFO - 2018-04-10 23:07:50 --> Loader Class Initialized
INFO - 2018-04-10 23:07:50 --> Helper loaded: url_helper
INFO - 2018-04-10 23:07:50 --> Helper loaded: form_helper
INFO - 2018-04-10 23:07:50 --> Helper loaded: language_helper
DEBUG - 2018-04-10 23:07:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 23:07:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 23:07:50 --> User Agent Class Initialized
INFO - 2018-04-10 23:07:50 --> Controller Class Initialized
INFO - 2018-04-10 23:07:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 23:07:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-10 23:07:50 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 23:07:50 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-10 23:07:50 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 23:07:50 --> Final output sent to browser
DEBUG - 2018-04-10 23:07:50 --> Total execution time: 0.4710
INFO - 2018-04-10 23:07:52 --> Config Class Initialized
INFO - 2018-04-10 23:07:52 --> Hooks Class Initialized
DEBUG - 2018-04-10 23:07:52 --> UTF-8 Support Enabled
INFO - 2018-04-10 23:07:52 --> Utf8 Class Initialized
INFO - 2018-04-10 23:07:52 --> URI Class Initialized
INFO - 2018-04-10 23:07:52 --> Router Class Initialized
INFO - 2018-04-10 23:07:52 --> Output Class Initialized
INFO - 2018-04-10 23:07:52 --> Security Class Initialized
DEBUG - 2018-04-10 23:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 23:07:52 --> CSRF cookie sent
INFO - 2018-04-10 23:07:52 --> Input Class Initialized
INFO - 2018-04-10 23:07:52 --> Language Class Initialized
ERROR - 2018-04-10 23:07:52 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-10 23:09:33 --> Config Class Initialized
INFO - 2018-04-10 23:09:33 --> Hooks Class Initialized
DEBUG - 2018-04-10 23:09:33 --> UTF-8 Support Enabled
INFO - 2018-04-10 23:09:33 --> Utf8 Class Initialized
INFO - 2018-04-10 23:09:33 --> URI Class Initialized
INFO - 2018-04-10 23:09:33 --> Router Class Initialized
INFO - 2018-04-10 23:09:33 --> Output Class Initialized
INFO - 2018-04-10 23:09:33 --> Security Class Initialized
DEBUG - 2018-04-10 23:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 23:09:33 --> CSRF cookie sent
INFO - 2018-04-10 23:09:33 --> Input Class Initialized
INFO - 2018-04-10 23:09:33 --> Language Class Initialized
INFO - 2018-04-10 23:09:33 --> Loader Class Initialized
INFO - 2018-04-10 23:09:33 --> Helper loaded: url_helper
INFO - 2018-04-10 23:09:33 --> Helper loaded: form_helper
INFO - 2018-04-10 23:09:33 --> Helper loaded: language_helper
DEBUG - 2018-04-10 23:09:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 23:09:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 23:09:34 --> User Agent Class Initialized
INFO - 2018-04-10 23:09:34 --> Controller Class Initialized
INFO - 2018-04-10 23:09:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 23:09:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-10 23:09:34 --> Pixel_Model class loaded
INFO - 2018-04-10 23:09:34 --> Database Driver Class Initialized
INFO - 2018-04-10 23:09:37 --> Model "RegistrationModel" initialized
DEBUG - 2018-04-10 23:09:37 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 23:09:37 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 23:09:37 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 23:09:37 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-10 23:09:37 --> Could not find the language line "req_email"
INFO - 2018-04-10 23:09:37 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-04-10 23:09:37 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 23:09:37 --> Final output sent to browser
DEBUG - 2018-04-10 23:09:37 --> Total execution time: 3.6552
INFO - 2018-04-10 23:09:40 --> Config Class Initialized
INFO - 2018-04-10 23:09:40 --> Hooks Class Initialized
DEBUG - 2018-04-10 23:09:40 --> UTF-8 Support Enabled
INFO - 2018-04-10 23:09:40 --> Utf8 Class Initialized
INFO - 2018-04-10 23:09:40 --> URI Class Initialized
INFO - 2018-04-10 23:09:40 --> Router Class Initialized
INFO - 2018-04-10 23:09:40 --> Output Class Initialized
INFO - 2018-04-10 23:09:40 --> Security Class Initialized
DEBUG - 2018-04-10 23:09:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 23:09:40 --> CSRF cookie sent
INFO - 2018-04-10 23:09:40 --> Input Class Initialized
INFO - 2018-04-10 23:09:40 --> Language Class Initialized
ERROR - 2018-04-10 23:09:40 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 23:10:37 --> Config Class Initialized
INFO - 2018-04-10 23:10:37 --> Hooks Class Initialized
DEBUG - 2018-04-10 23:10:37 --> UTF-8 Support Enabled
INFO - 2018-04-10 23:10:37 --> Utf8 Class Initialized
INFO - 2018-04-10 23:10:37 --> URI Class Initialized
INFO - 2018-04-10 23:10:37 --> Router Class Initialized
INFO - 2018-04-10 23:10:37 --> Output Class Initialized
INFO - 2018-04-10 23:10:37 --> Security Class Initialized
DEBUG - 2018-04-10 23:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 23:10:37 --> CSRF cookie sent
INFO - 2018-04-10 23:10:37 --> CSRF token verified
INFO - 2018-04-10 23:10:37 --> Input Class Initialized
INFO - 2018-04-10 23:10:37 --> Language Class Initialized
INFO - 2018-04-10 23:10:38 --> Loader Class Initialized
INFO - 2018-04-10 23:10:38 --> Helper loaded: url_helper
INFO - 2018-04-10 23:10:38 --> Helper loaded: form_helper
INFO - 2018-04-10 23:10:38 --> Helper loaded: language_helper
DEBUG - 2018-04-10 23:10:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 23:10:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 23:10:38 --> User Agent Class Initialized
INFO - 2018-04-10 23:10:38 --> Controller Class Initialized
INFO - 2018-04-10 23:10:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 23:10:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-10 23:10:38 --> Form Validation Class Initialized
INFO - 2018-04-10 23:10:38 --> Language file loaded: language/en/notifications_lang.php
INFO - 2018-04-10 23:10:38 --> Pixel_Model class loaded
INFO - 2018-04-10 23:10:38 --> Database Driver Class Initialized
INFO - 2018-04-10 23:10:41 --> Model "AuthenticationModel" initialized
INFO - 2018-04-10 23:10:41 --> Helper loaded: string_helper
INFO - 2018-04-10 23:10:41 --> File loaded: E:\www\yacopoo\application\views\emails/header.php
INFO - 2018-04-10 23:10:41 --> File loaded: E:\www\yacopoo\application\views\emails/footer.php
INFO - 2018-04-10 23:10:41 --> File loaded: E:\www\yacopoo\application\views\emails/generic.php
INFO - 2018-04-10 23:10:41 --> Email Class Initialized
INFO - 2018-04-10 23:10:41 --> Config Class Initialized
INFO - 2018-04-10 23:10:41 --> Hooks Class Initialized
DEBUG - 2018-04-10 23:10:41 --> UTF-8 Support Enabled
INFO - 2018-04-10 23:10:41 --> Utf8 Class Initialized
INFO - 2018-04-10 23:10:41 --> URI Class Initialized
INFO - 2018-04-10 23:10:41 --> Router Class Initialized
INFO - 2018-04-10 23:10:41 --> Output Class Initialized
INFO - 2018-04-10 23:10:41 --> Security Class Initialized
DEBUG - 2018-04-10 23:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 23:10:41 --> CSRF cookie sent
INFO - 2018-04-10 23:10:41 --> Input Class Initialized
INFO - 2018-04-10 23:10:41 --> Language Class Initialized
ERROR - 2018-04-10 23:10:41 --> 404 Page Not Found: Assets/images
INFO - 2018-04-10 23:11:11 --> Config Class Initialized
INFO - 2018-04-10 23:11:11 --> Hooks Class Initialized
DEBUG - 2018-04-10 23:11:11 --> UTF-8 Support Enabled
INFO - 2018-04-10 23:11:11 --> Utf8 Class Initialized
INFO - 2018-04-10 23:11:11 --> URI Class Initialized
INFO - 2018-04-10 23:11:11 --> Router Class Initialized
INFO - 2018-04-10 23:11:11 --> Output Class Initialized
INFO - 2018-04-10 23:11:11 --> Security Class Initialized
DEBUG - 2018-04-10 23:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 23:11:11 --> CSRF cookie sent
INFO - 2018-04-10 23:11:11 --> CSRF token verified
INFO - 2018-04-10 23:11:11 --> Input Class Initialized
INFO - 2018-04-10 23:11:11 --> Language Class Initialized
INFO - 2018-04-10 23:11:11 --> Loader Class Initialized
INFO - 2018-04-10 23:11:11 --> Helper loaded: url_helper
INFO - 2018-04-10 23:11:11 --> Helper loaded: form_helper
INFO - 2018-04-10 23:11:11 --> Helper loaded: language_helper
DEBUG - 2018-04-10 23:11:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 23:11:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 23:11:11 --> User Agent Class Initialized
INFO - 2018-04-10 23:11:11 --> Controller Class Initialized
INFO - 2018-04-10 23:11:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 23:11:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-10 23:11:11 --> Form Validation Class Initialized
INFO - 2018-04-10 23:11:11 --> Language file loaded: language/en/notifications_lang.php
INFO - 2018-04-10 23:11:11 --> Pixel_Model class loaded
INFO - 2018-04-10 23:11:11 --> Database Driver Class Initialized
INFO - 2018-04-10 23:11:11 --> Model "AuthenticationModel" initialized
INFO - 2018-04-10 23:11:11 --> Helper loaded: string_helper
INFO - 2018-04-10 23:11:11 --> File loaded: E:\www\yacopoo\application\views\emails/header.php
INFO - 2018-04-10 23:11:11 --> File loaded: E:\www\yacopoo\application\views\emails/footer.php
INFO - 2018-04-10 23:11:11 --> File loaded: E:\www\yacopoo\application\views\emails/generic.php
INFO - 2018-04-10 23:11:11 --> Email Class Initialized
INFO - 2018-04-10 23:11:11 --> Config Class Initialized
INFO - 2018-04-10 23:11:12 --> Hooks Class Initialized
DEBUG - 2018-04-10 23:11:12 --> UTF-8 Support Enabled
INFO - 2018-04-10 23:11:12 --> Utf8 Class Initialized
INFO - 2018-04-10 23:11:12 --> URI Class Initialized
INFO - 2018-04-10 23:11:12 --> Router Class Initialized
INFO - 2018-04-10 23:11:12 --> Output Class Initialized
INFO - 2018-04-10 23:11:12 --> Security Class Initialized
DEBUG - 2018-04-10 23:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 23:11:12 --> CSRF cookie sent
INFO - 2018-04-10 23:11:12 --> Input Class Initialized
INFO - 2018-04-10 23:11:12 --> Language Class Initialized
ERROR - 2018-04-10 23:11:12 --> 404 Page Not Found: Assets/images
INFO - 2018-04-10 23:11:48 --> Config Class Initialized
INFO - 2018-04-10 23:11:48 --> Hooks Class Initialized
DEBUG - 2018-04-10 23:11:48 --> UTF-8 Support Enabled
INFO - 2018-04-10 23:11:48 --> Utf8 Class Initialized
INFO - 2018-04-10 23:11:48 --> URI Class Initialized
INFO - 2018-04-10 23:11:48 --> Router Class Initialized
INFO - 2018-04-10 23:11:48 --> Output Class Initialized
INFO - 2018-04-10 23:11:48 --> Security Class Initialized
DEBUG - 2018-04-10 23:11:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 23:11:48 --> CSRF cookie sent
INFO - 2018-04-10 23:11:48 --> CSRF token verified
INFO - 2018-04-10 23:11:48 --> Input Class Initialized
INFO - 2018-04-10 23:11:48 --> Language Class Initialized
INFO - 2018-04-10 23:11:48 --> Loader Class Initialized
INFO - 2018-04-10 23:11:48 --> Helper loaded: url_helper
INFO - 2018-04-10 23:11:48 --> Helper loaded: form_helper
INFO - 2018-04-10 23:11:48 --> Helper loaded: language_helper
DEBUG - 2018-04-10 23:11:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 23:11:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 23:11:48 --> User Agent Class Initialized
INFO - 2018-04-10 23:11:48 --> Controller Class Initialized
INFO - 2018-04-10 23:11:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 23:11:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-10 23:11:48 --> Form Validation Class Initialized
INFO - 2018-04-10 23:11:49 --> Language file loaded: language/en/notifications_lang.php
INFO - 2018-04-10 23:11:49 --> Pixel_Model class loaded
INFO - 2018-04-10 23:11:49 --> Database Driver Class Initialized
INFO - 2018-04-10 23:11:52 --> Model "AuthenticationModel" initialized
INFO - 2018-04-10 23:11:52 --> Helper loaded: string_helper
INFO - 2018-04-10 23:11:52 --> File loaded: E:\www\yacopoo\application\views\emails/header.php
INFO - 2018-04-10 23:11:52 --> File loaded: E:\www\yacopoo\application\views\emails/footer.php
INFO - 2018-04-10 23:11:52 --> File loaded: E:\www\yacopoo\application\views\emails/generic.php
INFO - 2018-04-10 23:11:52 --> Email Class Initialized
INFO - 2018-04-10 23:11:52 --> Config Class Initialized
INFO - 2018-04-10 23:11:52 --> Hooks Class Initialized
DEBUG - 2018-04-10 23:11:52 --> UTF-8 Support Enabled
INFO - 2018-04-10 23:11:52 --> Utf8 Class Initialized
INFO - 2018-04-10 23:11:52 --> URI Class Initialized
INFO - 2018-04-10 23:11:52 --> Router Class Initialized
INFO - 2018-04-10 23:11:52 --> Output Class Initialized
INFO - 2018-04-10 23:11:52 --> Security Class Initialized
DEBUG - 2018-04-10 23:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 23:11:52 --> CSRF cookie sent
INFO - 2018-04-10 23:11:52 --> Input Class Initialized
INFO - 2018-04-10 23:11:52 --> Language Class Initialized
ERROR - 2018-04-10 23:11:52 --> 404 Page Not Found: Assets/images
INFO - 2018-04-10 23:12:42 --> Config Class Initialized
INFO - 2018-04-10 23:12:42 --> Hooks Class Initialized
DEBUG - 2018-04-10 23:12:42 --> UTF-8 Support Enabled
INFO - 2018-04-10 23:12:42 --> Utf8 Class Initialized
INFO - 2018-04-10 23:12:42 --> URI Class Initialized
INFO - 2018-04-10 23:12:42 --> Router Class Initialized
INFO - 2018-04-10 23:12:42 --> Output Class Initialized
INFO - 2018-04-10 23:12:42 --> Security Class Initialized
DEBUG - 2018-04-10 23:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 23:12:42 --> CSRF cookie sent
INFO - 2018-04-10 23:12:42 --> Input Class Initialized
INFO - 2018-04-10 23:12:42 --> Language Class Initialized
INFO - 2018-04-10 23:12:42 --> Loader Class Initialized
INFO - 2018-04-10 23:12:42 --> Helper loaded: url_helper
INFO - 2018-04-10 23:12:42 --> Helper loaded: form_helper
INFO - 2018-04-10 23:12:42 --> Helper loaded: language_helper
DEBUG - 2018-04-10 23:12:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 23:12:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 23:12:43 --> User Agent Class Initialized
INFO - 2018-04-10 23:12:43 --> Controller Class Initialized
INFO - 2018-04-10 23:12:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 23:12:43 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 23:12:43 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 23:12:43 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 23:12:43 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 23:12:43 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-10 23:12:43 --> Could not find the language line "req_email"
INFO - 2018-04-10 23:12:43 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-04-10 23:12:43 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 23:12:43 --> Final output sent to browser
DEBUG - 2018-04-10 23:12:43 --> Total execution time: 0.5334
INFO - 2018-04-10 23:12:43 --> Config Class Initialized
INFO - 2018-04-10 23:12:43 --> Hooks Class Initialized
DEBUG - 2018-04-10 23:12:43 --> UTF-8 Support Enabled
INFO - 2018-04-10 23:12:43 --> Utf8 Class Initialized
INFO - 2018-04-10 23:12:43 --> URI Class Initialized
INFO - 2018-04-10 23:12:43 --> Router Class Initialized
INFO - 2018-04-10 23:12:43 --> Output Class Initialized
INFO - 2018-04-10 23:12:43 --> Security Class Initialized
DEBUG - 2018-04-10 23:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 23:12:43 --> CSRF cookie sent
INFO - 2018-04-10 23:12:43 --> Input Class Initialized
INFO - 2018-04-10 23:12:43 --> Language Class Initialized
ERROR - 2018-04-10 23:12:43 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 23:12:56 --> Config Class Initialized
INFO - 2018-04-10 23:12:56 --> Hooks Class Initialized
DEBUG - 2018-04-10 23:12:56 --> UTF-8 Support Enabled
INFO - 2018-04-10 23:12:56 --> Utf8 Class Initialized
INFO - 2018-04-10 23:12:56 --> URI Class Initialized
INFO - 2018-04-10 23:12:56 --> Router Class Initialized
INFO - 2018-04-10 23:12:56 --> Output Class Initialized
INFO - 2018-04-10 23:12:56 --> Security Class Initialized
DEBUG - 2018-04-10 23:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 23:12:56 --> CSRF cookie sent
INFO - 2018-04-10 23:12:56 --> CSRF token verified
INFO - 2018-04-10 23:12:56 --> Input Class Initialized
INFO - 2018-04-10 23:12:56 --> Language Class Initialized
INFO - 2018-04-10 23:12:56 --> Loader Class Initialized
INFO - 2018-04-10 23:12:56 --> Helper loaded: url_helper
INFO - 2018-04-10 23:12:56 --> Helper loaded: form_helper
INFO - 2018-04-10 23:12:56 --> Helper loaded: language_helper
DEBUG - 2018-04-10 23:12:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 23:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 23:12:56 --> User Agent Class Initialized
INFO - 2018-04-10 23:12:56 --> Controller Class Initialized
INFO - 2018-04-10 23:12:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 23:12:56 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-10 23:12:56 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-10 23:12:57 --> Form Validation Class Initialized
INFO - 2018-04-10 23:12:57 --> Pixel_Model class loaded
INFO - 2018-04-10 23:12:57 --> Database Driver Class Initialized
INFO - 2018-04-10 23:12:57 --> Model "AuthenticationModel" initialized
INFO - 2018-04-10 23:12:57 --> Config Class Initialized
INFO - 2018-04-10 23:12:57 --> Hooks Class Initialized
DEBUG - 2018-04-10 23:12:57 --> UTF-8 Support Enabled
INFO - 2018-04-10 23:12:57 --> Utf8 Class Initialized
INFO - 2018-04-10 23:12:57 --> URI Class Initialized
DEBUG - 2018-04-10 23:12:57 --> No URI present. Default controller set.
INFO - 2018-04-10 23:12:57 --> Router Class Initialized
INFO - 2018-04-10 23:12:57 --> Output Class Initialized
INFO - 2018-04-10 23:12:57 --> Security Class Initialized
DEBUG - 2018-04-10 23:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 23:12:57 --> CSRF cookie sent
INFO - 2018-04-10 23:12:57 --> Input Class Initialized
INFO - 2018-04-10 23:12:57 --> Language Class Initialized
INFO - 2018-04-10 23:12:57 --> Loader Class Initialized
INFO - 2018-04-10 23:12:57 --> Helper loaded: url_helper
INFO - 2018-04-10 23:12:57 --> Helper loaded: form_helper
INFO - 2018-04-10 23:12:57 --> Helper loaded: language_helper
DEBUG - 2018-04-10 23:12:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 23:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 23:12:57 --> User Agent Class Initialized
INFO - 2018-04-10 23:12:57 --> Controller Class Initialized
INFO - 2018-04-10 23:12:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 23:12:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-10 23:12:57 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 23:12:57 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-10 23:12:57 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 23:12:57 --> Final output sent to browser
DEBUG - 2018-04-10 23:12:57 --> Total execution time: 0.4237
INFO - 2018-04-10 23:12:58 --> Config Class Initialized
INFO - 2018-04-10 23:12:58 --> Hooks Class Initialized
DEBUG - 2018-04-10 23:12:58 --> UTF-8 Support Enabled
INFO - 2018-04-10 23:12:58 --> Utf8 Class Initialized
INFO - 2018-04-10 23:12:58 --> URI Class Initialized
INFO - 2018-04-10 23:12:58 --> Router Class Initialized
INFO - 2018-04-10 23:12:58 --> Output Class Initialized
INFO - 2018-04-10 23:12:58 --> Security Class Initialized
DEBUG - 2018-04-10 23:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 23:12:58 --> CSRF cookie sent
INFO - 2018-04-10 23:12:58 --> Input Class Initialized
INFO - 2018-04-10 23:12:58 --> Language Class Initialized
ERROR - 2018-04-10 23:12:58 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 23:13:00 --> Config Class Initialized
INFO - 2018-04-10 23:13:00 --> Hooks Class Initialized
DEBUG - 2018-04-10 23:13:00 --> UTF-8 Support Enabled
INFO - 2018-04-10 23:13:00 --> Utf8 Class Initialized
INFO - 2018-04-10 23:13:00 --> URI Class Initialized
INFO - 2018-04-10 23:13:00 --> Router Class Initialized
INFO - 2018-04-10 23:13:00 --> Output Class Initialized
INFO - 2018-04-10 23:13:00 --> Security Class Initialized
DEBUG - 2018-04-10 23:13:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 23:13:00 --> CSRF cookie sent
INFO - 2018-04-10 23:13:00 --> Input Class Initialized
INFO - 2018-04-10 23:13:00 --> Language Class Initialized
ERROR - 2018-04-10 23:13:00 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-10 23:16:08 --> Config Class Initialized
INFO - 2018-04-10 23:16:08 --> Hooks Class Initialized
DEBUG - 2018-04-10 23:16:08 --> UTF-8 Support Enabled
INFO - 2018-04-10 23:16:08 --> Utf8 Class Initialized
INFO - 2018-04-10 23:16:08 --> URI Class Initialized
INFO - 2018-04-10 23:16:08 --> Router Class Initialized
INFO - 2018-04-10 23:16:08 --> Output Class Initialized
INFO - 2018-04-10 23:16:08 --> Security Class Initialized
DEBUG - 2018-04-10 23:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 23:16:08 --> CSRF cookie sent
INFO - 2018-04-10 23:16:08 --> Input Class Initialized
INFO - 2018-04-10 23:16:08 --> Language Class Initialized
INFO - 2018-04-10 23:16:08 --> Loader Class Initialized
INFO - 2018-04-10 23:16:08 --> Helper loaded: url_helper
INFO - 2018-04-10 23:16:08 --> Helper loaded: form_helper
INFO - 2018-04-10 23:16:08 --> Helper loaded: language_helper
DEBUG - 2018-04-10 23:16:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 23:16:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 23:16:08 --> User Agent Class Initialized
INFO - 2018-04-10 23:16:08 --> Controller Class Initialized
INFO - 2018-04-10 23:16:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 23:16:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-10 23:16:08 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 23:16:08 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 23:16:08 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-10 23:16:08 --> File loaded: E:\www\yacopoo\application\views\myaccount/change_password.php
INFO - 2018-04-10 23:16:08 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 23:16:08 --> Final output sent to browser
DEBUG - 2018-04-10 23:16:08 --> Total execution time: 0.4633
INFO - 2018-04-10 23:16:09 --> Config Class Initialized
INFO - 2018-04-10 23:16:09 --> Hooks Class Initialized
DEBUG - 2018-04-10 23:16:09 --> UTF-8 Support Enabled
INFO - 2018-04-10 23:16:09 --> Utf8 Class Initialized
INFO - 2018-04-10 23:16:09 --> URI Class Initialized
INFO - 2018-04-10 23:16:09 --> Router Class Initialized
INFO - 2018-04-10 23:16:09 --> Output Class Initialized
INFO - 2018-04-10 23:16:09 --> Security Class Initialized
DEBUG - 2018-04-10 23:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 23:16:09 --> CSRF cookie sent
INFO - 2018-04-10 23:16:09 --> Input Class Initialized
INFO - 2018-04-10 23:16:09 --> Language Class Initialized
ERROR - 2018-04-10 23:16:09 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 23:16:24 --> Config Class Initialized
INFO - 2018-04-10 23:16:24 --> Hooks Class Initialized
DEBUG - 2018-04-10 23:16:24 --> UTF-8 Support Enabled
INFO - 2018-04-10 23:16:24 --> Utf8 Class Initialized
INFO - 2018-04-10 23:16:24 --> URI Class Initialized
INFO - 2018-04-10 23:16:24 --> Router Class Initialized
INFO - 2018-04-10 23:16:24 --> Output Class Initialized
INFO - 2018-04-10 23:16:24 --> Security Class Initialized
DEBUG - 2018-04-10 23:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 23:16:24 --> CSRF cookie sent
INFO - 2018-04-10 23:16:24 --> CSRF token verified
INFO - 2018-04-10 23:16:24 --> Input Class Initialized
INFO - 2018-04-10 23:16:24 --> Language Class Initialized
INFO - 2018-04-10 23:16:24 --> Loader Class Initialized
INFO - 2018-04-10 23:16:24 --> Helper loaded: url_helper
INFO - 2018-04-10 23:16:24 --> Helper loaded: form_helper
INFO - 2018-04-10 23:16:24 --> Helper loaded: language_helper
DEBUG - 2018-04-10 23:16:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 23:16:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 23:16:24 --> User Agent Class Initialized
INFO - 2018-04-10 23:16:24 --> Controller Class Initialized
INFO - 2018-04-10 23:16:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 23:16:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-10 23:16:24 --> Form Validation Class Initialized
INFO - 2018-04-10 23:16:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-10 23:16:24 --> Pixel_Model class loaded
INFO - 2018-04-10 23:16:25 --> Database Driver Class Initialized
INFO - 2018-04-10 23:16:28 --> Model "AuthenticationModel" initialized
ERROR - 2018-04-10 23:16:28 --> Could not find the language line "incorrect_password"
INFO - 2018-04-10 23:16:28 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 23:16:28 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 23:16:28 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-10 23:16:28 --> File loaded: E:\www\yacopoo\application\views\myaccount/change_password.php
INFO - 2018-04-10 23:16:28 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 23:16:28 --> Final output sent to browser
DEBUG - 2018-04-10 23:16:28 --> Total execution time: 3.7901
INFO - 2018-04-10 23:16:28 --> Config Class Initialized
INFO - 2018-04-10 23:16:28 --> Hooks Class Initialized
DEBUG - 2018-04-10 23:16:28 --> UTF-8 Support Enabled
INFO - 2018-04-10 23:16:28 --> Utf8 Class Initialized
INFO - 2018-04-10 23:16:28 --> URI Class Initialized
INFO - 2018-04-10 23:16:28 --> Router Class Initialized
INFO - 2018-04-10 23:16:28 --> Output Class Initialized
INFO - 2018-04-10 23:16:28 --> Security Class Initialized
DEBUG - 2018-04-10 23:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 23:16:28 --> CSRF cookie sent
INFO - 2018-04-10 23:16:28 --> Input Class Initialized
INFO - 2018-04-10 23:16:28 --> Language Class Initialized
ERROR - 2018-04-10 23:16:28 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 23:19:03 --> Config Class Initialized
INFO - 2018-04-10 23:19:03 --> Hooks Class Initialized
DEBUG - 2018-04-10 23:19:03 --> UTF-8 Support Enabled
INFO - 2018-04-10 23:19:03 --> Utf8 Class Initialized
INFO - 2018-04-10 23:19:03 --> URI Class Initialized
INFO - 2018-04-10 23:19:03 --> Router Class Initialized
INFO - 2018-04-10 23:19:03 --> Output Class Initialized
INFO - 2018-04-10 23:19:03 --> Security Class Initialized
DEBUG - 2018-04-10 23:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 23:19:03 --> CSRF cookie sent
INFO - 2018-04-10 23:19:03 --> CSRF token verified
INFO - 2018-04-10 23:19:03 --> Input Class Initialized
INFO - 2018-04-10 23:19:03 --> Language Class Initialized
INFO - 2018-04-10 23:19:03 --> Loader Class Initialized
INFO - 2018-04-10 23:19:03 --> Helper loaded: url_helper
INFO - 2018-04-10 23:19:03 --> Helper loaded: form_helper
INFO - 2018-04-10 23:19:03 --> Helper loaded: language_helper
DEBUG - 2018-04-10 23:19:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 23:19:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 23:19:03 --> User Agent Class Initialized
INFO - 2018-04-10 23:19:03 --> Controller Class Initialized
INFO - 2018-04-10 23:19:03 --> Language file loaded: language/en/common_lang.php
ERROR - 2018-04-10 23:19:03 --> Severity: Error --> Cannot use object of type CI_Lang as array E:\www\yacopoo\application\language\en\form_validation_lang.php 20
INFO - 2018-04-10 23:19:56 --> Config Class Initialized
INFO - 2018-04-10 23:19:56 --> Hooks Class Initialized
DEBUG - 2018-04-10 23:19:56 --> UTF-8 Support Enabled
INFO - 2018-04-10 23:19:56 --> Utf8 Class Initialized
INFO - 2018-04-10 23:19:56 --> URI Class Initialized
INFO - 2018-04-10 23:19:56 --> Router Class Initialized
INFO - 2018-04-10 23:19:56 --> Output Class Initialized
INFO - 2018-04-10 23:19:56 --> Security Class Initialized
DEBUG - 2018-04-10 23:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 23:19:56 --> CSRF cookie sent
INFO - 2018-04-10 23:19:56 --> CSRF token verified
INFO - 2018-04-10 23:19:56 --> Input Class Initialized
INFO - 2018-04-10 23:19:56 --> Language Class Initialized
INFO - 2018-04-10 23:19:56 --> Loader Class Initialized
INFO - 2018-04-10 23:19:56 --> Helper loaded: url_helper
INFO - 2018-04-10 23:19:56 --> Helper loaded: form_helper
INFO - 2018-04-10 23:19:56 --> Helper loaded: language_helper
DEBUG - 2018-04-10 23:19:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 23:19:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 23:19:57 --> User Agent Class Initialized
INFO - 2018-04-10 23:19:57 --> Controller Class Initialized
INFO - 2018-04-10 23:19:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 23:19:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-10 23:19:57 --> Form Validation Class Initialized
INFO - 2018-04-10 23:19:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-10 23:19:57 --> Pixel_Model class loaded
INFO - 2018-04-10 23:19:57 --> Database Driver Class Initialized
INFO - 2018-04-10 23:20:00 --> Model "AuthenticationModel" initialized
INFO - 2018-04-10 23:20:00 --> Config Class Initialized
INFO - 2018-04-10 23:20:00 --> Hooks Class Initialized
DEBUG - 2018-04-10 23:20:00 --> UTF-8 Support Enabled
INFO - 2018-04-10 23:20:00 --> Utf8 Class Initialized
INFO - 2018-04-10 23:20:00 --> URI Class Initialized
INFO - 2018-04-10 23:20:00 --> Router Class Initialized
INFO - 2018-04-10 23:20:00 --> Output Class Initialized
INFO - 2018-04-10 23:20:00 --> Security Class Initialized
DEBUG - 2018-04-10 23:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 23:20:00 --> CSRF cookie sent
INFO - 2018-04-10 23:20:00 --> Input Class Initialized
INFO - 2018-04-10 23:20:00 --> Language Class Initialized
INFO - 2018-04-10 23:20:00 --> Loader Class Initialized
INFO - 2018-04-10 23:20:00 --> Helper loaded: url_helper
INFO - 2018-04-10 23:20:00 --> Helper loaded: form_helper
INFO - 2018-04-10 23:20:00 --> Helper loaded: language_helper
DEBUG - 2018-04-10 23:20:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 23:20:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 23:20:00 --> User Agent Class Initialized
INFO - 2018-04-10 23:20:00 --> Controller Class Initialized
INFO - 2018-04-10 23:20:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 23:20:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-10 23:20:00 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 23:20:00 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 23:20:01 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-10 23:20:01 --> File loaded: E:\www\yacopoo\application\views\shared/_soft_error.php
INFO - 2018-04-10 23:20:01 --> File loaded: E:\www\yacopoo\application\views\myaccount/change_password.php
INFO - 2018-04-10 23:20:01 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 23:20:01 --> Final output sent to browser
DEBUG - 2018-04-10 23:20:01 --> Total execution time: 0.4604
INFO - 2018-04-10 23:20:01 --> Config Class Initialized
INFO - 2018-04-10 23:20:01 --> Hooks Class Initialized
DEBUG - 2018-04-10 23:20:01 --> UTF-8 Support Enabled
INFO - 2018-04-10 23:20:01 --> Utf8 Class Initialized
INFO - 2018-04-10 23:20:01 --> URI Class Initialized
INFO - 2018-04-10 23:20:01 --> Router Class Initialized
INFO - 2018-04-10 23:20:01 --> Output Class Initialized
INFO - 2018-04-10 23:20:01 --> Security Class Initialized
DEBUG - 2018-04-10 23:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 23:20:01 --> CSRF cookie sent
INFO - 2018-04-10 23:20:01 --> Input Class Initialized
INFO - 2018-04-10 23:20:01 --> Config Class Initialized
INFO - 2018-04-10 23:20:01 --> Config Class Initialized
INFO - 2018-04-10 23:20:01 --> Hooks Class Initialized
INFO - 2018-04-10 23:20:01 --> Config Class Initialized
INFO - 2018-04-10 23:20:01 --> Language Class Initialized
INFO - 2018-04-10 23:20:01 --> Hooks Class Initialized
INFO - 2018-04-10 23:20:01 --> Hooks Class Initialized
DEBUG - 2018-04-10 23:20:01 --> UTF-8 Support Enabled
ERROR - 2018-04-10 23:20:01 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 23:20:01 --> Utf8 Class Initialized
DEBUG - 2018-04-10 23:20:01 --> UTF-8 Support Enabled
DEBUG - 2018-04-10 23:20:01 --> UTF-8 Support Enabled
INFO - 2018-04-10 23:20:01 --> Utf8 Class Initialized
INFO - 2018-04-10 23:20:01 --> Utf8 Class Initialized
INFO - 2018-04-10 23:20:01 --> URI Class Initialized
INFO - 2018-04-10 23:20:01 --> URI Class Initialized
INFO - 2018-04-10 23:20:01 --> URI Class Initialized
INFO - 2018-04-10 23:20:01 --> Router Class Initialized
INFO - 2018-04-10 23:20:01 --> Output Class Initialized
INFO - 2018-04-10 23:20:01 --> Router Class Initialized
INFO - 2018-04-10 23:20:01 --> Router Class Initialized
INFO - 2018-04-10 23:20:01 --> Security Class Initialized
INFO - 2018-04-10 23:20:01 --> Output Class Initialized
INFO - 2018-04-10 23:20:01 --> Output Class Initialized
INFO - 2018-04-10 23:20:01 --> Security Class Initialized
DEBUG - 2018-04-10 23:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 23:20:01 --> Security Class Initialized
INFO - 2018-04-10 23:20:01 --> CSRF cookie sent
DEBUG - 2018-04-10 23:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-10 23:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 23:20:01 --> Input Class Initialized
INFO - 2018-04-10 23:20:01 --> CSRF cookie sent
INFO - 2018-04-10 23:20:01 --> CSRF cookie sent
INFO - 2018-04-10 23:20:01 --> Input Class Initialized
INFO - 2018-04-10 23:20:01 --> Input Class Initialized
INFO - 2018-04-10 23:20:01 --> Language Class Initialized
INFO - 2018-04-10 23:20:01 --> Language Class Initialized
INFO - 2018-04-10 23:20:01 --> Language Class Initialized
ERROR - 2018-04-10 23:20:02 --> 404 Page Not Found: Change-password/assets
ERROR - 2018-04-10 23:20:02 --> 404 Page Not Found: Change-password/assets
ERROR - 2018-04-10 23:20:02 --> 404 Page Not Found: Change-password/assets
INFO - 2018-04-10 23:20:16 --> Config Class Initialized
INFO - 2018-04-10 23:20:16 --> Hooks Class Initialized
DEBUG - 2018-04-10 23:20:16 --> UTF-8 Support Enabled
INFO - 2018-04-10 23:20:16 --> Utf8 Class Initialized
INFO - 2018-04-10 23:20:16 --> URI Class Initialized
INFO - 2018-04-10 23:20:16 --> Router Class Initialized
INFO - 2018-04-10 23:20:16 --> Output Class Initialized
INFO - 2018-04-10 23:20:16 --> Security Class Initialized
DEBUG - 2018-04-10 23:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 23:20:16 --> CSRF cookie sent
INFO - 2018-04-10 23:20:16 --> CSRF token verified
INFO - 2018-04-10 23:20:16 --> Input Class Initialized
INFO - 2018-04-10 23:20:16 --> Language Class Initialized
INFO - 2018-04-10 23:20:16 --> Loader Class Initialized
INFO - 2018-04-10 23:20:16 --> Helper loaded: url_helper
INFO - 2018-04-10 23:20:16 --> Helper loaded: form_helper
INFO - 2018-04-10 23:20:17 --> Helper loaded: language_helper
DEBUG - 2018-04-10 23:20:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 23:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 23:20:17 --> User Agent Class Initialized
INFO - 2018-04-10 23:20:17 --> Controller Class Initialized
INFO - 2018-04-10 23:20:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 23:20:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-10 23:20:17 --> Form Validation Class Initialized
INFO - 2018-04-10 23:20:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-10 23:20:17 --> Pixel_Model class loaded
INFO - 2018-04-10 23:20:17 --> Database Driver Class Initialized
INFO - 2018-04-10 23:20:17 --> Model "AuthenticationModel" initialized
INFO - 2018-04-10 23:20:17 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 23:20:17 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 23:20:17 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-10 23:20:17 --> File loaded: E:\www\yacopoo\application\views\shared/_errors.php
INFO - 2018-04-10 23:20:17 --> File loaded: E:\www\yacopoo\application\views\myaccount/change_password.php
INFO - 2018-04-10 23:20:17 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 23:20:17 --> Final output sent to browser
DEBUG - 2018-04-10 23:20:17 --> Total execution time: 0.7619
INFO - 2018-04-10 23:20:17 --> Config Class Initialized
INFO - 2018-04-10 23:20:17 --> Hooks Class Initialized
DEBUG - 2018-04-10 23:20:17 --> UTF-8 Support Enabled
INFO - 2018-04-10 23:20:17 --> Utf8 Class Initialized
INFO - 2018-04-10 23:20:17 --> URI Class Initialized
INFO - 2018-04-10 23:20:17 --> Router Class Initialized
INFO - 2018-04-10 23:20:18 --> Output Class Initialized
INFO - 2018-04-10 23:20:18 --> Security Class Initialized
DEBUG - 2018-04-10 23:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 23:20:18 --> CSRF cookie sent
INFO - 2018-04-10 23:20:18 --> Input Class Initialized
INFO - 2018-04-10 23:20:18 --> Language Class Initialized
ERROR - 2018-04-10 23:20:18 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 23:20:29 --> Config Class Initialized
INFO - 2018-04-10 23:20:29 --> Hooks Class Initialized
DEBUG - 2018-04-10 23:20:29 --> UTF-8 Support Enabled
INFO - 2018-04-10 23:20:29 --> Utf8 Class Initialized
INFO - 2018-04-10 23:20:29 --> URI Class Initialized
INFO - 2018-04-10 23:20:29 --> Router Class Initialized
INFO - 2018-04-10 23:20:29 --> Output Class Initialized
INFO - 2018-04-10 23:20:29 --> Security Class Initialized
DEBUG - 2018-04-10 23:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 23:20:29 --> CSRF cookie sent
INFO - 2018-04-10 23:20:29 --> CSRF token verified
INFO - 2018-04-10 23:20:29 --> Input Class Initialized
INFO - 2018-04-10 23:20:29 --> Language Class Initialized
INFO - 2018-04-10 23:20:29 --> Loader Class Initialized
INFO - 2018-04-10 23:20:29 --> Helper loaded: url_helper
INFO - 2018-04-10 23:20:29 --> Helper loaded: form_helper
INFO - 2018-04-10 23:20:29 --> Helper loaded: language_helper
DEBUG - 2018-04-10 23:20:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 23:20:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 23:20:29 --> User Agent Class Initialized
INFO - 2018-04-10 23:20:29 --> Controller Class Initialized
INFO - 2018-04-10 23:20:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 23:20:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-10 23:20:29 --> Form Validation Class Initialized
INFO - 2018-04-10 23:20:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-10 23:20:29 --> Pixel_Model class loaded
INFO - 2018-04-10 23:20:29 --> Database Driver Class Initialized
INFO - 2018-04-10 23:20:29 --> Model "AuthenticationModel" initialized
INFO - 2018-04-10 23:20:30 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 23:20:30 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 23:20:30 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-10 23:20:30 --> File loaded: E:\www\yacopoo\application\views\shared/_errors.php
INFO - 2018-04-10 23:20:30 --> File loaded: E:\www\yacopoo\application\views\myaccount/change_password.php
INFO - 2018-04-10 23:20:30 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 23:20:30 --> Final output sent to browser
DEBUG - 2018-04-10 23:20:30 --> Total execution time: 0.7966
INFO - 2018-04-10 23:20:30 --> Config Class Initialized
INFO - 2018-04-10 23:20:30 --> Hooks Class Initialized
DEBUG - 2018-04-10 23:20:30 --> UTF-8 Support Enabled
INFO - 2018-04-10 23:20:30 --> Utf8 Class Initialized
INFO - 2018-04-10 23:20:30 --> URI Class Initialized
INFO - 2018-04-10 23:20:30 --> Router Class Initialized
INFO - 2018-04-10 23:20:30 --> Output Class Initialized
INFO - 2018-04-10 23:20:30 --> Security Class Initialized
DEBUG - 2018-04-10 23:20:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 23:20:30 --> CSRF cookie sent
INFO - 2018-04-10 23:20:30 --> Input Class Initialized
INFO - 2018-04-10 23:20:30 --> Language Class Initialized
ERROR - 2018-04-10 23:20:30 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 23:31:09 --> Config Class Initialized
INFO - 2018-04-10 23:31:09 --> Hooks Class Initialized
DEBUG - 2018-04-10 23:31:09 --> UTF-8 Support Enabled
INFO - 2018-04-10 23:31:09 --> Utf8 Class Initialized
INFO - 2018-04-10 23:31:09 --> URI Class Initialized
INFO - 2018-04-10 23:31:09 --> Router Class Initialized
INFO - 2018-04-10 23:31:09 --> Output Class Initialized
INFO - 2018-04-10 23:31:09 --> Security Class Initialized
DEBUG - 2018-04-10 23:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 23:31:09 --> CSRF cookie sent
INFO - 2018-04-10 23:31:09 --> CSRF token verified
INFO - 2018-04-10 23:31:09 --> Input Class Initialized
INFO - 2018-04-10 23:31:09 --> Language Class Initialized
INFO - 2018-04-10 23:31:09 --> Loader Class Initialized
INFO - 2018-04-10 23:31:09 --> Helper loaded: url_helper
INFO - 2018-04-10 23:31:09 --> Helper loaded: form_helper
INFO - 2018-04-10 23:31:09 --> Helper loaded: language_helper
DEBUG - 2018-04-10 23:31:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 23:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 23:31:09 --> User Agent Class Initialized
INFO - 2018-04-10 23:31:09 --> Controller Class Initialized
INFO - 2018-04-10 23:31:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 23:31:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-10 23:31:09 --> Form Validation Class Initialized
INFO - 2018-04-10 23:31:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-10 23:31:09 --> Pixel_Model class loaded
INFO - 2018-04-10 23:31:09 --> Database Driver Class Initialized
INFO - 2018-04-10 23:31:12 --> Model "AuthenticationModel" initialized
INFO - 2018-04-10 23:31:12 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 23:31:12 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 23:31:13 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-10 23:31:13 --> File loaded: E:\www\yacopoo\application\views\shared/_errors.php
INFO - 2018-04-10 23:31:13 --> File loaded: E:\www\yacopoo\application\views\myaccount/change_password.php
INFO - 2018-04-10 23:31:13 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 23:31:13 --> Final output sent to browser
DEBUG - 2018-04-10 23:31:13 --> Total execution time: 3.8567
INFO - 2018-04-10 23:31:13 --> Config Class Initialized
INFO - 2018-04-10 23:31:13 --> Hooks Class Initialized
DEBUG - 2018-04-10 23:31:13 --> UTF-8 Support Enabled
INFO - 2018-04-10 23:31:13 --> Utf8 Class Initialized
INFO - 2018-04-10 23:31:13 --> URI Class Initialized
INFO - 2018-04-10 23:31:13 --> Router Class Initialized
INFO - 2018-04-10 23:31:13 --> Output Class Initialized
INFO - 2018-04-10 23:31:13 --> Security Class Initialized
DEBUG - 2018-04-10 23:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 23:31:13 --> CSRF cookie sent
INFO - 2018-04-10 23:31:13 --> Input Class Initialized
INFO - 2018-04-10 23:31:13 --> Language Class Initialized
ERROR - 2018-04-10 23:31:13 --> 404 Page Not Found: Assets/css
INFO - 2018-04-10 23:31:42 --> Config Class Initialized
INFO - 2018-04-10 23:31:42 --> Hooks Class Initialized
DEBUG - 2018-04-10 23:31:42 --> UTF-8 Support Enabled
INFO - 2018-04-10 23:31:42 --> Utf8 Class Initialized
INFO - 2018-04-10 23:31:42 --> URI Class Initialized
INFO - 2018-04-10 23:31:42 --> Router Class Initialized
INFO - 2018-04-10 23:31:42 --> Output Class Initialized
INFO - 2018-04-10 23:31:42 --> Security Class Initialized
DEBUG - 2018-04-10 23:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 23:31:42 --> CSRF cookie sent
INFO - 2018-04-10 23:31:42 --> CSRF token verified
INFO - 2018-04-10 23:31:42 --> Input Class Initialized
INFO - 2018-04-10 23:31:42 --> Language Class Initialized
INFO - 2018-04-10 23:31:42 --> Loader Class Initialized
INFO - 2018-04-10 23:31:42 --> Helper loaded: url_helper
INFO - 2018-04-10 23:31:42 --> Helper loaded: form_helper
INFO - 2018-04-10 23:31:42 --> Helper loaded: language_helper
DEBUG - 2018-04-10 23:31:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 23:31:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 23:31:42 --> User Agent Class Initialized
INFO - 2018-04-10 23:31:43 --> Controller Class Initialized
INFO - 2018-04-10 23:31:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-10 23:31:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-10 23:31:43 --> Form Validation Class Initialized
INFO - 2018-04-10 23:31:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-10 23:31:43 --> Pixel_Model class loaded
INFO - 2018-04-10 23:31:43 --> Database Driver Class Initialized
INFO - 2018-04-10 23:31:46 --> Model "AuthenticationModel" initialized
INFO - 2018-04-10 23:31:46 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-10 23:31:46 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-10 23:31:46 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-10 23:31:46 --> File loaded: E:\www\yacopoo\application\views\shared/_errors.php
INFO - 2018-04-10 23:31:46 --> File loaded: E:\www\yacopoo\application\views\myaccount/change_password.php
INFO - 2018-04-10 23:31:46 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-10 23:31:46 --> Final output sent to browser
DEBUG - 2018-04-10 23:31:46 --> Total execution time: 3.8649
INFO - 2018-04-10 23:31:46 --> Config Class Initialized
INFO - 2018-04-10 23:31:46 --> Hooks Class Initialized
DEBUG - 2018-04-10 23:31:47 --> UTF-8 Support Enabled
INFO - 2018-04-10 23:31:47 --> Utf8 Class Initialized
INFO - 2018-04-10 23:31:47 --> URI Class Initialized
INFO - 2018-04-10 23:31:47 --> Router Class Initialized
INFO - 2018-04-10 23:31:47 --> Output Class Initialized
INFO - 2018-04-10 23:31:47 --> Security Class Initialized
DEBUG - 2018-04-10 23:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 23:31:47 --> CSRF cookie sent
INFO - 2018-04-10 23:31:47 --> Input Class Initialized
INFO - 2018-04-10 23:31:47 --> Language Class Initialized
ERROR - 2018-04-10 23:31:47 --> 404 Page Not Found: Assets/css

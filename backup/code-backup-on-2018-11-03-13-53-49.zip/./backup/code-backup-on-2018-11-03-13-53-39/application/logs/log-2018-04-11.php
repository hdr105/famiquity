<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-04-11 00:08:46 --> Config Class Initialized
INFO - 2018-04-11 00:08:46 --> Hooks Class Initialized
DEBUG - 2018-04-11 00:08:46 --> UTF-8 Support Enabled
INFO - 2018-04-11 00:08:46 --> Utf8 Class Initialized
INFO - 2018-04-11 00:08:46 --> URI Class Initialized
INFO - 2018-04-11 00:08:46 --> Router Class Initialized
INFO - 2018-04-11 00:08:47 --> Output Class Initialized
INFO - 2018-04-11 00:08:47 --> Security Class Initialized
DEBUG - 2018-04-11 00:08:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 00:08:47 --> CSRF cookie sent
INFO - 2018-04-11 00:08:47 --> Input Class Initialized
INFO - 2018-04-11 00:08:47 --> Language Class Initialized
INFO - 2018-04-11 00:08:47 --> Loader Class Initialized
INFO - 2018-04-11 00:08:47 --> Helper loaded: url_helper
INFO - 2018-04-11 00:08:47 --> Helper loaded: form_helper
INFO - 2018-04-11 00:08:47 --> Helper loaded: language_helper
DEBUG - 2018-04-11 00:08:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 00:08:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 00:08:47 --> User Agent Class Initialized
INFO - 2018-04-11 00:08:47 --> Controller Class Initialized
INFO - 2018-04-11 00:08:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 00:08:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 00:08:47 --> Pixel_Model class loaded
INFO - 2018-04-11 00:08:47 --> Database Driver Class Initialized
INFO - 2018-04-11 00:08:50 --> Model "RegistrationModel" initialized
ERROR - 2018-04-11 00:08:50 --> Could not find the language line "signup_head"
ERROR - 2018-04-11 00:08:50 --> Severity: Notice --> Undefined property: RegistrationController::$registration E:\www\yacopoo\application\controllers\RegistrationController.php 36
ERROR - 2018-04-11 00:08:50 --> Could not find the language line "signup_message"
INFO - 2018-04-11 00:08:50 --> File loaded: E:\www\yacopoo\application\views\emails/_buttons.php
INFO - 2018-04-11 00:08:50 --> File loaded: E:\www\yacopoo\application\views\emails/header.php
ERROR - 2018-04-11 00:08:50 --> Could not find the language line "dear"
ERROR - 2018-04-11 00:08:50 --> Could not find the language line "email_thanks"
ERROR - 2018-04-11 00:08:50 --> Could not find the language line "email_footer_txt1"
ERROR - 2018-04-11 00:08:50 --> Could not find the language line "email_footer_txt2"
INFO - 2018-04-11 00:08:50 --> File loaded: E:\www\yacopoo\application\views\emails/footer.php
INFO - 2018-04-11 00:08:50 --> File loaded: E:\www\yacopoo\application\views\emails/generic.php
INFO - 2018-04-11 00:08:50 --> Email Class Initialized
INFO - 2018-04-11 00:08:50 --> Config Class Initialized
INFO - 2018-04-11 00:08:50 --> Hooks Class Initialized
DEBUG - 2018-04-11 00:08:50 --> UTF-8 Support Enabled
INFO - 2018-04-11 00:08:50 --> Utf8 Class Initialized
INFO - 2018-04-11 00:08:50 --> URI Class Initialized
INFO - 2018-04-11 00:08:50 --> Router Class Initialized
INFO - 2018-04-11 00:08:50 --> Output Class Initialized
INFO - 2018-04-11 00:08:50 --> Security Class Initialized
DEBUG - 2018-04-11 00:08:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 00:08:50 --> CSRF cookie sent
INFO - 2018-04-11 00:08:50 --> Input Class Initialized
INFO - 2018-04-11 00:08:50 --> Language Class Initialized
ERROR - 2018-04-11 00:08:50 --> 404 Page Not Found: Assets/images
INFO - 2018-04-11 00:09:10 --> Config Class Initialized
INFO - 2018-04-11 00:09:10 --> Hooks Class Initialized
DEBUG - 2018-04-11 00:09:10 --> UTF-8 Support Enabled
INFO - 2018-04-11 00:09:10 --> Utf8 Class Initialized
INFO - 2018-04-11 00:09:10 --> URI Class Initialized
INFO - 2018-04-11 00:09:10 --> Router Class Initialized
INFO - 2018-04-11 00:09:10 --> Output Class Initialized
INFO - 2018-04-11 00:09:10 --> Security Class Initialized
DEBUG - 2018-04-11 00:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 00:09:10 --> CSRF cookie sent
INFO - 2018-04-11 00:09:10 --> Input Class Initialized
INFO - 2018-04-11 00:09:10 --> Language Class Initialized
INFO - 2018-04-11 00:09:11 --> Loader Class Initialized
INFO - 2018-04-11 00:09:11 --> Helper loaded: url_helper
INFO - 2018-04-11 00:09:11 --> Helper loaded: form_helper
INFO - 2018-04-11 00:09:11 --> Helper loaded: language_helper
DEBUG - 2018-04-11 00:09:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 00:09:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 00:09:11 --> User Agent Class Initialized
INFO - 2018-04-11 00:09:11 --> Controller Class Initialized
INFO - 2018-04-11 00:09:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 00:09:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 00:09:11 --> Pixel_Model class loaded
INFO - 2018-04-11 00:09:11 --> Database Driver Class Initialized
INFO - 2018-04-11 00:09:11 --> Model "RegistrationModel" initialized
ERROR - 2018-04-11 00:09:11 --> Could not find the language line "signup_head"
ERROR - 2018-04-11 00:09:11 --> Could not find the language line "signup_message"
INFO - 2018-04-11 00:09:11 --> File loaded: E:\www\yacopoo\application\views\emails/_buttons.php
INFO - 2018-04-11 00:09:11 --> File loaded: E:\www\yacopoo\application\views\emails/header.php
ERROR - 2018-04-11 00:09:11 --> Could not find the language line "dear"
ERROR - 2018-04-11 00:09:11 --> Could not find the language line "email_thanks"
ERROR - 2018-04-11 00:09:11 --> Could not find the language line "email_footer_txt1"
ERROR - 2018-04-11 00:09:11 --> Could not find the language line "email_footer_txt2"
INFO - 2018-04-11 00:09:11 --> File loaded: E:\www\yacopoo\application\views\emails/footer.php
INFO - 2018-04-11 00:09:11 --> File loaded: E:\www\yacopoo\application\views\emails/generic.php
INFO - 2018-04-11 00:09:11 --> Email Class Initialized
INFO - 2018-04-11 00:09:11 --> Config Class Initialized
INFO - 2018-04-11 00:09:11 --> Hooks Class Initialized
DEBUG - 2018-04-11 00:09:11 --> UTF-8 Support Enabled
INFO - 2018-04-11 00:09:11 --> Utf8 Class Initialized
INFO - 2018-04-11 00:09:11 --> URI Class Initialized
INFO - 2018-04-11 00:09:11 --> Router Class Initialized
INFO - 2018-04-11 00:09:11 --> Output Class Initialized
INFO - 2018-04-11 00:09:11 --> Security Class Initialized
DEBUG - 2018-04-11 00:09:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 00:09:11 --> CSRF cookie sent
INFO - 2018-04-11 00:09:11 --> Input Class Initialized
INFO - 2018-04-11 00:09:11 --> Language Class Initialized
ERROR - 2018-04-11 00:09:11 --> 404 Page Not Found: Assets/images
INFO - 2018-04-11 00:10:35 --> Config Class Initialized
INFO - 2018-04-11 00:10:36 --> Hooks Class Initialized
DEBUG - 2018-04-11 00:10:36 --> UTF-8 Support Enabled
INFO - 2018-04-11 00:10:36 --> Utf8 Class Initialized
INFO - 2018-04-11 00:10:36 --> URI Class Initialized
INFO - 2018-04-11 00:10:36 --> Router Class Initialized
INFO - 2018-04-11 00:10:36 --> Output Class Initialized
INFO - 2018-04-11 00:10:36 --> Security Class Initialized
DEBUG - 2018-04-11 00:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 00:10:36 --> CSRF cookie sent
INFO - 2018-04-11 00:10:36 --> Input Class Initialized
INFO - 2018-04-11 00:10:36 --> Language Class Initialized
INFO - 2018-04-11 00:10:36 --> Loader Class Initialized
INFO - 2018-04-11 00:10:36 --> Helper loaded: url_helper
INFO - 2018-04-11 00:10:36 --> Helper loaded: form_helper
INFO - 2018-04-11 00:10:36 --> Helper loaded: language_helper
DEBUG - 2018-04-11 00:10:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 00:10:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 00:10:36 --> User Agent Class Initialized
INFO - 2018-04-11 00:10:36 --> Controller Class Initialized
INFO - 2018-04-11 00:10:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 00:10:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 00:10:36 --> Pixel_Model class loaded
INFO - 2018-04-11 00:10:36 --> Database Driver Class Initialized
INFO - 2018-04-11 00:10:39 --> Model "RegistrationModel" initialized
INFO - 2018-04-11 00:10:39 --> Language file loaded: language/en/notifications_lang.php
INFO - 2018-04-11 00:10:39 --> File loaded: E:\www\yacopoo\application\views\emails/_buttons.php
INFO - 2018-04-11 00:10:39 --> File loaded: E:\www\yacopoo\application\views\emails/header.php
INFO - 2018-04-11 00:10:39 --> File loaded: E:\www\yacopoo\application\views\emails/footer.php
INFO - 2018-04-11 00:10:39 --> File loaded: E:\www\yacopoo\application\views\emails/generic.php
INFO - 2018-04-11 00:10:39 --> Email Class Initialized
INFO - 2018-04-11 00:10:39 --> Config Class Initialized
INFO - 2018-04-11 00:10:39 --> Hooks Class Initialized
DEBUG - 2018-04-11 00:10:39 --> UTF-8 Support Enabled
INFO - 2018-04-11 00:10:39 --> Utf8 Class Initialized
INFO - 2018-04-11 00:10:39 --> URI Class Initialized
INFO - 2018-04-11 00:10:39 --> Router Class Initialized
INFO - 2018-04-11 00:10:39 --> Output Class Initialized
INFO - 2018-04-11 00:10:39 --> Security Class Initialized
DEBUG - 2018-04-11 00:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 00:10:39 --> CSRF cookie sent
INFO - 2018-04-11 00:10:39 --> Input Class Initialized
INFO - 2018-04-11 00:10:39 --> Language Class Initialized
ERROR - 2018-04-11 00:10:39 --> 404 Page Not Found: Assets/images
INFO - 2018-04-11 00:12:50 --> Config Class Initialized
INFO - 2018-04-11 00:12:50 --> Hooks Class Initialized
DEBUG - 2018-04-11 00:12:50 --> UTF-8 Support Enabled
INFO - 2018-04-11 00:12:50 --> Utf8 Class Initialized
INFO - 2018-04-11 00:12:50 --> URI Class Initialized
INFO - 2018-04-11 00:12:50 --> Router Class Initialized
INFO - 2018-04-11 00:12:50 --> Output Class Initialized
INFO - 2018-04-11 00:12:50 --> Security Class Initialized
DEBUG - 2018-04-11 00:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 00:12:50 --> CSRF cookie sent
INFO - 2018-04-11 00:12:50 --> Input Class Initialized
INFO - 2018-04-11 00:12:50 --> Language Class Initialized
INFO - 2018-04-11 00:12:50 --> Loader Class Initialized
INFO - 2018-04-11 00:12:50 --> Helper loaded: url_helper
INFO - 2018-04-11 00:12:50 --> Helper loaded: form_helper
INFO - 2018-04-11 00:12:50 --> Helper loaded: language_helper
DEBUG - 2018-04-11 00:12:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 00:12:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 00:12:50 --> User Agent Class Initialized
INFO - 2018-04-11 00:12:50 --> Controller Class Initialized
INFO - 2018-04-11 00:12:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 00:12:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 00:12:50 --> Pixel_Model class loaded
INFO - 2018-04-11 00:12:50 --> Database Driver Class Initialized
INFO - 2018-04-11 00:12:53 --> Model "RegistrationModel" initialized
INFO - 2018-04-11 00:12:53 --> Language file loaded: language/en/notifications_lang.php
INFO - 2018-04-11 00:12:53 --> File loaded: E:\www\yacopoo\application\views\emails/_buttons.php
INFO - 2018-04-11 00:12:53 --> File loaded: E:\www\yacopoo\application\views\emails/header.php
INFO - 2018-04-11 00:12:53 --> File loaded: E:\www\yacopoo\application\views\emails/footer.php
INFO - 2018-04-11 00:12:53 --> File loaded: E:\www\yacopoo\application\views\emails/generic.php
INFO - 2018-04-11 00:12:53 --> Email Class Initialized
INFO - 2018-04-11 00:12:53 --> Config Class Initialized
INFO - 2018-04-11 00:12:53 --> Hooks Class Initialized
DEBUG - 2018-04-11 00:12:53 --> UTF-8 Support Enabled
INFO - 2018-04-11 00:12:53 --> Utf8 Class Initialized
INFO - 2018-04-11 00:12:53 --> URI Class Initialized
INFO - 2018-04-11 00:12:53 --> Router Class Initialized
INFO - 2018-04-11 00:12:53 --> Output Class Initialized
INFO - 2018-04-11 00:12:53 --> Security Class Initialized
DEBUG - 2018-04-11 00:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 00:12:53 --> CSRF cookie sent
INFO - 2018-04-11 00:12:53 --> Input Class Initialized
INFO - 2018-04-11 00:12:54 --> Language Class Initialized
ERROR - 2018-04-11 00:12:54 --> 404 Page Not Found: Assets/images
INFO - 2018-04-11 00:26:04 --> Config Class Initialized
INFO - 2018-04-11 00:26:04 --> Hooks Class Initialized
DEBUG - 2018-04-11 00:26:04 --> UTF-8 Support Enabled
INFO - 2018-04-11 00:26:04 --> Utf8 Class Initialized
INFO - 2018-04-11 00:26:04 --> URI Class Initialized
INFO - 2018-04-11 00:26:04 --> Router Class Initialized
INFO - 2018-04-11 00:26:04 --> Output Class Initialized
INFO - 2018-04-11 00:26:04 --> Security Class Initialized
DEBUG - 2018-04-11 00:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 00:26:04 --> CSRF cookie sent
INFO - 2018-04-11 00:26:04 --> Input Class Initialized
INFO - 2018-04-11 00:26:04 --> Language Class Initialized
INFO - 2018-04-11 00:26:04 --> Loader Class Initialized
INFO - 2018-04-11 00:26:04 --> Helper loaded: url_helper
INFO - 2018-04-11 00:26:04 --> Helper loaded: form_helper
INFO - 2018-04-11 00:26:04 --> Helper loaded: language_helper
DEBUG - 2018-04-11 00:26:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 00:26:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 00:26:04 --> User Agent Class Initialized
INFO - 2018-04-11 00:26:04 --> Controller Class Initialized
INFO - 2018-04-11 00:26:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 00:26:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 00:26:04 --> Pixel_Model class loaded
INFO - 2018-04-11 00:26:04 --> Database Driver Class Initialized
INFO - 2018-04-11 00:26:07 --> Model "RegistrationModel" initialized
INFO - 2018-04-11 00:26:07 --> Language file loaded: language/en/notifications_lang.php
INFO - 2018-04-11 00:26:07 --> File loaded: E:\www\yacopoo\application\views\emails/_buttons.php
INFO - 2018-04-11 00:26:07 --> File loaded: E:\www\yacopoo\application\views\emails/header.php
INFO - 2018-04-11 00:26:07 --> File loaded: E:\www\yacopoo\application\views\emails/footer.php
INFO - 2018-04-11 00:26:07 --> File loaded: E:\www\yacopoo\application\views\emails/generic.php
INFO - 2018-04-11 00:26:07 --> Email Class Initialized
INFO - 2018-04-11 00:26:07 --> Config Class Initialized
INFO - 2018-04-11 00:26:07 --> Hooks Class Initialized
DEBUG - 2018-04-11 00:26:07 --> UTF-8 Support Enabled
INFO - 2018-04-11 00:26:07 --> Utf8 Class Initialized
INFO - 2018-04-11 00:26:07 --> URI Class Initialized
INFO - 2018-04-11 00:26:07 --> Router Class Initialized
INFO - 2018-04-11 00:26:07 --> Output Class Initialized
INFO - 2018-04-11 00:26:07 --> Security Class Initialized
DEBUG - 2018-04-11 00:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 00:26:07 --> CSRF cookie sent
INFO - 2018-04-11 00:26:07 --> Input Class Initialized
INFO - 2018-04-11 00:26:07 --> Language Class Initialized
ERROR - 2018-04-11 00:26:07 --> 404 Page Not Found: Assets/images
INFO - 2018-04-11 00:27:54 --> Config Class Initialized
INFO - 2018-04-11 00:27:54 --> Hooks Class Initialized
DEBUG - 2018-04-11 00:27:54 --> UTF-8 Support Enabled
INFO - 2018-04-11 00:27:54 --> Utf8 Class Initialized
INFO - 2018-04-11 00:27:54 --> URI Class Initialized
INFO - 2018-04-11 00:27:54 --> Router Class Initialized
INFO - 2018-04-11 00:27:54 --> Output Class Initialized
INFO - 2018-04-11 00:27:54 --> Security Class Initialized
DEBUG - 2018-04-11 00:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 00:27:54 --> CSRF cookie sent
INFO - 2018-04-11 00:27:54 --> Input Class Initialized
INFO - 2018-04-11 00:27:54 --> Language Class Initialized
ERROR - 2018-04-11 00:27:54 --> 404 Page Not Found: En/activate-account
INFO - 2018-04-11 00:27:56 --> Config Class Initialized
INFO - 2018-04-11 00:27:56 --> Hooks Class Initialized
DEBUG - 2018-04-11 00:27:56 --> UTF-8 Support Enabled
INFO - 2018-04-11 00:27:56 --> Utf8 Class Initialized
INFO - 2018-04-11 00:27:56 --> URI Class Initialized
INFO - 2018-04-11 00:27:56 --> Router Class Initialized
INFO - 2018-04-11 00:27:56 --> Output Class Initialized
INFO - 2018-04-11 00:27:56 --> Security Class Initialized
DEBUG - 2018-04-11 00:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 00:27:56 --> CSRF cookie sent
INFO - 2018-04-11 00:27:56 --> Input Class Initialized
INFO - 2018-04-11 00:27:56 --> Language Class Initialized
INFO - 2018-04-11 00:27:56 --> Loader Class Initialized
INFO - 2018-04-11 00:27:56 --> Helper loaded: url_helper
INFO - 2018-04-11 00:27:56 --> Helper loaded: form_helper
INFO - 2018-04-11 00:27:56 --> Helper loaded: language_helper
DEBUG - 2018-04-11 00:27:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 00:27:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 00:27:56 --> User Agent Class Initialized
INFO - 2018-04-11 00:27:56 --> Controller Class Initialized
INFO - 2018-04-11 00:27:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 00:27:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 00:27:56 --> Pixel_Model class loaded
INFO - 2018-04-11 00:27:56 --> Database Driver Class Initialized
INFO - 2018-04-11 00:27:59 --> Model "RegistrationModel" initialized
INFO - 2018-04-11 00:27:59 --> Language file loaded: language/en/notifications_lang.php
INFO - 2018-04-11 00:27:59 --> File loaded: E:\www\yacopoo\application\views\emails/_buttons.php
INFO - 2018-04-11 00:27:59 --> File loaded: E:\www\yacopoo\application\views\emails/header.php
INFO - 2018-04-11 00:27:59 --> File loaded: E:\www\yacopoo\application\views\emails/footer.php
INFO - 2018-04-11 00:27:59 --> File loaded: E:\www\yacopoo\application\views\emails/generic.php
INFO - 2018-04-11 00:27:59 --> Email Class Initialized
INFO - 2018-04-11 00:27:59 --> Config Class Initialized
INFO - 2018-04-11 00:27:59 --> Hooks Class Initialized
DEBUG - 2018-04-11 00:27:59 --> UTF-8 Support Enabled
INFO - 2018-04-11 00:27:59 --> Utf8 Class Initialized
INFO - 2018-04-11 00:27:59 --> URI Class Initialized
INFO - 2018-04-11 00:27:59 --> Router Class Initialized
INFO - 2018-04-11 00:27:59 --> Output Class Initialized
INFO - 2018-04-11 00:27:59 --> Security Class Initialized
DEBUG - 2018-04-11 00:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 00:27:59 --> CSRF cookie sent
INFO - 2018-04-11 00:27:59 --> Input Class Initialized
INFO - 2018-04-11 00:28:00 --> Language Class Initialized
ERROR - 2018-04-11 00:28:00 --> 404 Page Not Found: Assets/images
INFO - 2018-04-11 00:28:04 --> Config Class Initialized
INFO - 2018-04-11 00:28:04 --> Hooks Class Initialized
DEBUG - 2018-04-11 00:28:04 --> UTF-8 Support Enabled
INFO - 2018-04-11 00:28:04 --> Utf8 Class Initialized
INFO - 2018-04-11 00:28:04 --> URI Class Initialized
INFO - 2018-04-11 00:28:04 --> Router Class Initialized
INFO - 2018-04-11 00:28:04 --> Output Class Initialized
INFO - 2018-04-11 00:28:04 --> Security Class Initialized
DEBUG - 2018-04-11 00:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 00:28:04 --> CSRF cookie sent
INFO - 2018-04-11 00:28:04 --> Input Class Initialized
INFO - 2018-04-11 00:28:04 --> Language Class Initialized
ERROR - 2018-04-11 00:28:04 --> 404 Page Not Found: En/activate-account
INFO - 2018-04-11 00:32:23 --> Config Class Initialized
INFO - 2018-04-11 00:32:24 --> Hooks Class Initialized
DEBUG - 2018-04-11 00:32:24 --> UTF-8 Support Enabled
INFO - 2018-04-11 00:32:24 --> Utf8 Class Initialized
INFO - 2018-04-11 00:32:24 --> URI Class Initialized
INFO - 2018-04-11 00:32:24 --> Router Class Initialized
INFO - 2018-04-11 00:32:24 --> Output Class Initialized
INFO - 2018-04-11 00:32:24 --> Security Class Initialized
DEBUG - 2018-04-11 00:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 00:32:24 --> CSRF cookie sent
INFO - 2018-04-11 00:32:24 --> Input Class Initialized
INFO - 2018-04-11 00:32:24 --> Language Class Initialized
INFO - 2018-04-11 00:32:24 --> Loader Class Initialized
INFO - 2018-04-11 00:32:24 --> Helper loaded: url_helper
INFO - 2018-04-11 00:32:24 --> Helper loaded: form_helper
INFO - 2018-04-11 00:32:24 --> Helper loaded: language_helper
DEBUG - 2018-04-11 00:32:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 00:32:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 00:32:24 --> User Agent Class Initialized
INFO - 2018-04-11 00:32:24 --> Controller Class Initialized
INFO - 2018-04-11 00:32:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 00:32:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 00:32:24 --> Pixel_Model class loaded
INFO - 2018-04-11 00:32:24 --> Database Driver Class Initialized
INFO - 2018-04-11 00:32:27 --> Model "RegistrationModel" initialized
INFO - 2018-04-11 00:32:27 --> Language file loaded: language/en/notifications_lang.php
INFO - 2018-04-11 00:32:27 --> File loaded: E:\www\yacopoo\application\views\emails/_buttons.php
INFO - 2018-04-11 00:32:27 --> File loaded: E:\www\yacopoo\application\views\emails/header.php
INFO - 2018-04-11 00:32:27 --> File loaded: E:\www\yacopoo\application\views\emails/footer.php
INFO - 2018-04-11 00:32:27 --> File loaded: E:\www\yacopoo\application\views\emails/generic.php
INFO - 2018-04-11 00:32:27 --> Email Class Initialized
INFO - 2018-04-11 00:32:27 --> Config Class Initialized
INFO - 2018-04-11 00:32:27 --> Hooks Class Initialized
DEBUG - 2018-04-11 00:32:27 --> UTF-8 Support Enabled
INFO - 2018-04-11 00:32:27 --> Utf8 Class Initialized
INFO - 2018-04-11 00:32:27 --> URI Class Initialized
INFO - 2018-04-11 00:32:27 --> Router Class Initialized
INFO - 2018-04-11 00:32:27 --> Output Class Initialized
INFO - 2018-04-11 00:32:27 --> Security Class Initialized
DEBUG - 2018-04-11 00:32:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 00:32:27 --> CSRF cookie sent
INFO - 2018-04-11 00:32:27 --> Input Class Initialized
INFO - 2018-04-11 00:32:27 --> Language Class Initialized
ERROR - 2018-04-11 00:32:27 --> 404 Page Not Found: Assets/images
INFO - 2018-04-11 00:32:30 --> Config Class Initialized
INFO - 2018-04-11 00:32:30 --> Hooks Class Initialized
DEBUG - 2018-04-11 00:32:30 --> UTF-8 Support Enabled
INFO - 2018-04-11 00:32:30 --> Utf8 Class Initialized
INFO - 2018-04-11 00:32:30 --> URI Class Initialized
INFO - 2018-04-11 00:32:30 --> Router Class Initialized
INFO - 2018-04-11 00:32:30 --> Output Class Initialized
INFO - 2018-04-11 00:32:30 --> Security Class Initialized
DEBUG - 2018-04-11 00:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 00:32:30 --> CSRF cookie sent
INFO - 2018-04-11 00:32:30 --> Input Class Initialized
INFO - 2018-04-11 00:32:30 --> Language Class Initialized
ERROR - 2018-04-11 00:32:30 --> 404 Page Not Found: En/activate-account
INFO - 2018-04-11 00:34:03 --> Config Class Initialized
INFO - 2018-04-11 00:34:03 --> Hooks Class Initialized
DEBUG - 2018-04-11 00:34:03 --> UTF-8 Support Enabled
INFO - 2018-04-11 00:34:03 --> Utf8 Class Initialized
INFO - 2018-04-11 00:34:03 --> URI Class Initialized
INFO - 2018-04-11 00:34:03 --> Router Class Initialized
INFO - 2018-04-11 00:34:03 --> Output Class Initialized
INFO - 2018-04-11 00:34:03 --> Security Class Initialized
DEBUG - 2018-04-11 00:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 00:34:03 --> CSRF cookie sent
INFO - 2018-04-11 00:34:03 --> Input Class Initialized
INFO - 2018-04-11 00:34:03 --> Language Class Initialized
INFO - 2018-04-11 00:34:03 --> Loader Class Initialized
INFO - 2018-04-11 00:34:03 --> Helper loaded: url_helper
INFO - 2018-04-11 00:34:03 --> Helper loaded: form_helper
INFO - 2018-04-11 00:34:03 --> Helper loaded: language_helper
DEBUG - 2018-04-11 00:34:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 00:34:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 00:34:03 --> User Agent Class Initialized
INFO - 2018-04-11 00:34:03 --> Controller Class Initialized
INFO - 2018-04-11 00:34:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 00:34:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 00:34:03 --> Pixel_Model class loaded
INFO - 2018-04-11 00:34:03 --> Database Driver Class Initialized
INFO - 2018-04-11 00:34:06 --> Model "RegistrationModel" initialized
INFO - 2018-04-11 00:34:06 --> Language file loaded: language/en/notifications_lang.php
INFO - 2018-04-11 00:34:06 --> File loaded: E:\www\yacopoo\application\views\emails/_buttons.php
INFO - 2018-04-11 00:34:06 --> File loaded: E:\www\yacopoo\application\views\emails/header.php
INFO - 2018-04-11 00:34:06 --> File loaded: E:\www\yacopoo\application\views\emails/footer.php
INFO - 2018-04-11 00:34:06 --> File loaded: E:\www\yacopoo\application\views\emails/generic.php
INFO - 2018-04-11 00:34:06 --> Email Class Initialized
INFO - 2018-04-11 00:34:07 --> Config Class Initialized
INFO - 2018-04-11 00:34:07 --> Hooks Class Initialized
DEBUG - 2018-04-11 00:34:07 --> UTF-8 Support Enabled
INFO - 2018-04-11 00:34:07 --> Utf8 Class Initialized
INFO - 2018-04-11 00:34:07 --> URI Class Initialized
INFO - 2018-04-11 00:34:07 --> Router Class Initialized
INFO - 2018-04-11 00:34:07 --> Output Class Initialized
INFO - 2018-04-11 00:34:07 --> Security Class Initialized
DEBUG - 2018-04-11 00:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 00:34:07 --> CSRF cookie sent
INFO - 2018-04-11 00:34:07 --> Input Class Initialized
INFO - 2018-04-11 00:34:07 --> Language Class Initialized
ERROR - 2018-04-11 00:34:07 --> 404 Page Not Found: Assets/images
INFO - 2018-04-11 00:34:09 --> Config Class Initialized
INFO - 2018-04-11 00:34:09 --> Hooks Class Initialized
DEBUG - 2018-04-11 00:34:09 --> UTF-8 Support Enabled
INFO - 2018-04-11 00:34:09 --> Utf8 Class Initialized
INFO - 2018-04-11 00:34:09 --> URI Class Initialized
INFO - 2018-04-11 00:34:09 --> Router Class Initialized
INFO - 2018-04-11 00:34:10 --> Output Class Initialized
INFO - 2018-04-11 00:34:10 --> Security Class Initialized
DEBUG - 2018-04-11 00:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 00:34:10 --> CSRF cookie sent
INFO - 2018-04-11 00:34:10 --> Input Class Initialized
INFO - 2018-04-11 00:34:10 --> Language Class Initialized
ERROR - 2018-04-11 00:34:10 --> 404 Page Not Found: En/activate-account
INFO - 2018-04-11 00:34:46 --> Config Class Initialized
INFO - 2018-04-11 00:34:46 --> Hooks Class Initialized
DEBUG - 2018-04-11 00:34:46 --> UTF-8 Support Enabled
INFO - 2018-04-11 00:34:46 --> Utf8 Class Initialized
INFO - 2018-04-11 00:34:46 --> URI Class Initialized
INFO - 2018-04-11 00:34:46 --> Router Class Initialized
INFO - 2018-04-11 00:34:46 --> Output Class Initialized
INFO - 2018-04-11 00:34:46 --> Security Class Initialized
DEBUG - 2018-04-11 00:34:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 00:34:46 --> CSRF cookie sent
INFO - 2018-04-11 00:34:46 --> Input Class Initialized
INFO - 2018-04-11 00:34:46 --> Language Class Initialized
INFO - 2018-04-11 00:34:46 --> Loader Class Initialized
INFO - 2018-04-11 00:34:46 --> Helper loaded: url_helper
INFO - 2018-04-11 00:34:46 --> Helper loaded: form_helper
INFO - 2018-04-11 00:34:46 --> Helper loaded: language_helper
DEBUG - 2018-04-11 00:34:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 00:34:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 00:34:46 --> User Agent Class Initialized
INFO - 2018-04-11 00:34:46 --> Controller Class Initialized
INFO - 2018-04-11 00:34:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 00:34:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 00:34:46 --> Pixel_Model class loaded
INFO - 2018-04-11 00:34:46 --> Database Driver Class Initialized
INFO - 2018-04-11 00:34:46 --> Model "RegistrationModel" initialized
INFO - 2018-04-11 00:34:46 --> Language file loaded: language/en/notifications_lang.php
INFO - 2018-04-11 00:34:46 --> File loaded: E:\www\yacopoo\application\views\emails/_buttons.php
INFO - 2018-04-11 00:34:46 --> File loaded: E:\www\yacopoo\application\views\emails/header.php
INFO - 2018-04-11 00:34:46 --> File loaded: E:\www\yacopoo\application\views\emails/footer.php
INFO - 2018-04-11 00:34:46 --> File loaded: E:\www\yacopoo\application\views\emails/generic.php
INFO - 2018-04-11 00:34:46 --> Email Class Initialized
INFO - 2018-04-11 00:34:46 --> Config Class Initialized
INFO - 2018-04-11 00:34:46 --> Hooks Class Initialized
DEBUG - 2018-04-11 00:34:46 --> UTF-8 Support Enabled
INFO - 2018-04-11 00:34:46 --> Utf8 Class Initialized
INFO - 2018-04-11 00:34:46 --> URI Class Initialized
INFO - 2018-04-11 00:34:46 --> Router Class Initialized
INFO - 2018-04-11 00:34:46 --> Output Class Initialized
INFO - 2018-04-11 00:34:46 --> Security Class Initialized
DEBUG - 2018-04-11 00:34:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 00:34:46 --> CSRF cookie sent
INFO - 2018-04-11 00:34:46 --> Input Class Initialized
INFO - 2018-04-11 00:34:46 --> Language Class Initialized
ERROR - 2018-04-11 00:34:46 --> 404 Page Not Found: Assets/images
INFO - 2018-04-11 00:34:49 --> Config Class Initialized
INFO - 2018-04-11 00:34:49 --> Hooks Class Initialized
DEBUG - 2018-04-11 00:34:49 --> UTF-8 Support Enabled
INFO - 2018-04-11 00:34:49 --> Utf8 Class Initialized
INFO - 2018-04-11 00:34:49 --> URI Class Initialized
INFO - 2018-04-11 00:34:49 --> Router Class Initialized
INFO - 2018-04-11 00:34:49 --> Output Class Initialized
INFO - 2018-04-11 00:34:49 --> Security Class Initialized
DEBUG - 2018-04-11 00:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 00:34:49 --> CSRF cookie sent
INFO - 2018-04-11 00:34:49 --> Input Class Initialized
INFO - 2018-04-11 00:34:49 --> Language Class Initialized
INFO - 2018-04-11 00:34:49 --> Loader Class Initialized
INFO - 2018-04-11 00:34:49 --> Helper loaded: url_helper
INFO - 2018-04-11 00:34:49 --> Helper loaded: form_helper
INFO - 2018-04-11 00:34:49 --> Helper loaded: language_helper
DEBUG - 2018-04-11 00:34:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 00:34:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 00:34:49 --> User Agent Class Initialized
INFO - 2018-04-11 00:34:49 --> Controller Class Initialized
INFO - 2018-04-11 00:34:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 00:34:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 00:34:49 --> Config Class Initialized
INFO - 2018-04-11 00:34:49 --> Hooks Class Initialized
DEBUG - 2018-04-11 00:34:49 --> UTF-8 Support Enabled
INFO - 2018-04-11 00:34:49 --> Utf8 Class Initialized
INFO - 2018-04-11 00:34:49 --> URI Class Initialized
DEBUG - 2018-04-11 00:34:49 --> No URI present. Default controller set.
INFO - 2018-04-11 00:34:49 --> Router Class Initialized
INFO - 2018-04-11 00:34:49 --> Output Class Initialized
INFO - 2018-04-11 00:34:49 --> Security Class Initialized
DEBUG - 2018-04-11 00:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 00:34:49 --> CSRF cookie sent
INFO - 2018-04-11 00:34:49 --> Input Class Initialized
INFO - 2018-04-11 00:34:49 --> Language Class Initialized
INFO - 2018-04-11 00:34:49 --> Loader Class Initialized
INFO - 2018-04-11 00:34:49 --> Helper loaded: url_helper
INFO - 2018-04-11 00:34:49 --> Helper loaded: form_helper
INFO - 2018-04-11 00:34:49 --> Helper loaded: language_helper
DEBUG - 2018-04-11 00:34:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 00:34:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 00:34:49 --> User Agent Class Initialized
INFO - 2018-04-11 00:34:49 --> Controller Class Initialized
INFO - 2018-04-11 00:34:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 00:34:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 00:34:49 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 00:34:49 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-11 00:34:49 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 00:34:49 --> Final output sent to browser
DEBUG - 2018-04-11 00:34:50 --> Total execution time: 0.2957
INFO - 2018-04-11 00:34:51 --> Config Class Initialized
INFO - 2018-04-11 00:34:51 --> Hooks Class Initialized
DEBUG - 2018-04-11 00:34:51 --> UTF-8 Support Enabled
INFO - 2018-04-11 00:34:51 --> Utf8 Class Initialized
INFO - 2018-04-11 00:34:51 --> URI Class Initialized
INFO - 2018-04-11 00:34:51 --> Router Class Initialized
INFO - 2018-04-11 00:34:51 --> Output Class Initialized
INFO - 2018-04-11 00:34:51 --> Security Class Initialized
DEBUG - 2018-04-11 00:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 00:34:51 --> CSRF cookie sent
INFO - 2018-04-11 00:34:51 --> Input Class Initialized
INFO - 2018-04-11 00:34:51 --> Language Class Initialized
ERROR - 2018-04-11 00:34:51 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-11 00:34:54 --> Config Class Initialized
INFO - 2018-04-11 00:34:54 --> Hooks Class Initialized
DEBUG - 2018-04-11 00:34:54 --> UTF-8 Support Enabled
INFO - 2018-04-11 00:34:54 --> Utf8 Class Initialized
INFO - 2018-04-11 00:34:54 --> URI Class Initialized
INFO - 2018-04-11 00:34:54 --> Router Class Initialized
INFO - 2018-04-11 00:34:54 --> Output Class Initialized
INFO - 2018-04-11 00:34:54 --> Security Class Initialized
DEBUG - 2018-04-11 00:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 00:34:54 --> CSRF cookie sent
INFO - 2018-04-11 00:34:54 --> Input Class Initialized
INFO - 2018-04-11 00:34:54 --> Language Class Initialized
INFO - 2018-04-11 00:34:54 --> Loader Class Initialized
INFO - 2018-04-11 00:34:54 --> Helper loaded: url_helper
INFO - 2018-04-11 00:34:54 --> Helper loaded: form_helper
INFO - 2018-04-11 00:34:54 --> Helper loaded: language_helper
DEBUG - 2018-04-11 00:34:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 00:34:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 00:34:54 --> User Agent Class Initialized
INFO - 2018-04-11 00:34:54 --> Controller Class Initialized
INFO - 2018-04-11 00:34:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 00:34:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 00:34:54 --> CSRF cookie sent
INFO - 2018-04-11 00:34:54 --> Config Class Initialized
INFO - 2018-04-11 00:34:54 --> Hooks Class Initialized
DEBUG - 2018-04-11 00:34:54 --> UTF-8 Support Enabled
INFO - 2018-04-11 00:34:54 --> Utf8 Class Initialized
INFO - 2018-04-11 00:34:54 --> URI Class Initialized
DEBUG - 2018-04-11 00:34:54 --> No URI present. Default controller set.
INFO - 2018-04-11 00:34:54 --> Router Class Initialized
INFO - 2018-04-11 00:34:54 --> Output Class Initialized
INFO - 2018-04-11 00:34:55 --> Security Class Initialized
DEBUG - 2018-04-11 00:34:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 00:34:55 --> CSRF cookie sent
INFO - 2018-04-11 00:34:55 --> Input Class Initialized
INFO - 2018-04-11 00:34:55 --> Language Class Initialized
INFO - 2018-04-11 00:34:55 --> Loader Class Initialized
INFO - 2018-04-11 00:34:55 --> Helper loaded: url_helper
INFO - 2018-04-11 00:34:55 --> Helper loaded: form_helper
INFO - 2018-04-11 00:34:55 --> Helper loaded: language_helper
DEBUG - 2018-04-11 00:34:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 00:34:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 00:34:55 --> User Agent Class Initialized
INFO - 2018-04-11 00:34:55 --> Controller Class Initialized
INFO - 2018-04-11 00:34:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 00:34:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 00:34:55 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 00:34:55 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-11 00:34:55 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 00:34:55 --> Final output sent to browser
DEBUG - 2018-04-11 00:34:55 --> Total execution time: 0.4712
INFO - 2018-04-11 00:35:06 --> Config Class Initialized
INFO - 2018-04-11 00:35:06 --> Hooks Class Initialized
DEBUG - 2018-04-11 00:35:06 --> UTF-8 Support Enabled
INFO - 2018-04-11 00:35:06 --> Utf8 Class Initialized
INFO - 2018-04-11 00:35:06 --> URI Class Initialized
INFO - 2018-04-11 00:35:06 --> Router Class Initialized
INFO - 2018-04-11 00:35:06 --> Output Class Initialized
INFO - 2018-04-11 00:35:06 --> Security Class Initialized
DEBUG - 2018-04-11 00:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 00:35:06 --> CSRF cookie sent
INFO - 2018-04-11 00:35:06 --> Input Class Initialized
INFO - 2018-04-11 00:35:06 --> Language Class Initialized
INFO - 2018-04-11 00:35:06 --> Loader Class Initialized
INFO - 2018-04-11 00:35:06 --> Helper loaded: url_helper
INFO - 2018-04-11 00:35:06 --> Helper loaded: form_helper
INFO - 2018-04-11 00:35:06 --> Helper loaded: language_helper
DEBUG - 2018-04-11 00:35:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 00:35:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 00:35:06 --> User Agent Class Initialized
INFO - 2018-04-11 00:35:06 --> Controller Class Initialized
INFO - 2018-04-11 00:35:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 00:35:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 00:35:06 --> Pixel_Model class loaded
ERROR - 2018-04-11 00:35:06 --> Severity: error --> Exception: Unable to locate the model you have specified: Registration_model E:\www\yacopoo\system\core\Loader.php 348
INFO - 2018-04-11 00:36:04 --> Config Class Initialized
INFO - 2018-04-11 00:36:04 --> Hooks Class Initialized
DEBUG - 2018-04-11 00:36:04 --> UTF-8 Support Enabled
INFO - 2018-04-11 00:36:04 --> Utf8 Class Initialized
INFO - 2018-04-11 00:36:04 --> URI Class Initialized
INFO - 2018-04-11 00:36:04 --> Router Class Initialized
INFO - 2018-04-11 00:36:04 --> Output Class Initialized
INFO - 2018-04-11 00:36:04 --> Security Class Initialized
DEBUG - 2018-04-11 00:36:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 00:36:04 --> CSRF cookie sent
INFO - 2018-04-11 00:36:05 --> Input Class Initialized
INFO - 2018-04-11 00:36:05 --> Language Class Initialized
ERROR - 2018-04-11 00:36:05 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-11 00:36:09 --> Config Class Initialized
INFO - 2018-04-11 00:36:09 --> Hooks Class Initialized
DEBUG - 2018-04-11 00:36:09 --> UTF-8 Support Enabled
INFO - 2018-04-11 00:36:09 --> Utf8 Class Initialized
INFO - 2018-04-11 00:36:09 --> URI Class Initialized
INFO - 2018-04-11 00:36:09 --> Router Class Initialized
INFO - 2018-04-11 00:36:09 --> Output Class Initialized
INFO - 2018-04-11 00:36:09 --> Security Class Initialized
DEBUG - 2018-04-11 00:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 00:36:09 --> CSRF cookie sent
INFO - 2018-04-11 00:36:09 --> Input Class Initialized
INFO - 2018-04-11 00:36:09 --> Language Class Initialized
INFO - 2018-04-11 00:36:09 --> Loader Class Initialized
INFO - 2018-04-11 00:36:09 --> Helper loaded: url_helper
INFO - 2018-04-11 00:36:09 --> Helper loaded: form_helper
INFO - 2018-04-11 00:36:09 --> Helper loaded: language_helper
DEBUG - 2018-04-11 00:36:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 00:36:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 00:36:09 --> User Agent Class Initialized
INFO - 2018-04-11 00:36:09 --> Controller Class Initialized
INFO - 2018-04-11 00:36:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 00:36:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 00:36:09 --> Pixel_Model class loaded
INFO - 2018-04-11 00:36:09 --> Database Driver Class Initialized
INFO - 2018-04-11 00:36:12 --> Model "RegistrationModel" initialized
INFO - 2018-04-11 00:36:12 --> Language file loaded: language/en/notifications_lang.php
INFO - 2018-04-11 00:36:12 --> File loaded: E:\www\yacopoo\application\views\emails/_buttons.php
INFO - 2018-04-11 00:36:12 --> File loaded: E:\www\yacopoo\application\views\emails/header.php
INFO - 2018-04-11 00:36:12 --> File loaded: E:\www\yacopoo\application\views\emails/footer.php
INFO - 2018-04-11 00:36:12 --> File loaded: E:\www\yacopoo\application\views\emails/generic.php
INFO - 2018-04-11 00:36:12 --> Email Class Initialized
INFO - 2018-04-11 00:36:12 --> Config Class Initialized
INFO - 2018-04-11 00:36:12 --> Hooks Class Initialized
DEBUG - 2018-04-11 00:36:12 --> UTF-8 Support Enabled
INFO - 2018-04-11 00:36:12 --> Utf8 Class Initialized
INFO - 2018-04-11 00:36:12 --> URI Class Initialized
INFO - 2018-04-11 00:36:12 --> Router Class Initialized
INFO - 2018-04-11 00:36:12 --> Output Class Initialized
INFO - 2018-04-11 00:36:12 --> Security Class Initialized
DEBUG - 2018-04-11 00:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 00:36:12 --> CSRF cookie sent
INFO - 2018-04-11 00:36:12 --> Input Class Initialized
INFO - 2018-04-11 00:36:12 --> Language Class Initialized
ERROR - 2018-04-11 00:36:12 --> 404 Page Not Found: Assets/images
INFO - 2018-04-11 00:37:41 --> Config Class Initialized
INFO - 2018-04-11 00:37:41 --> Hooks Class Initialized
DEBUG - 2018-04-11 00:37:41 --> UTF-8 Support Enabled
INFO - 2018-04-11 00:37:41 --> Utf8 Class Initialized
INFO - 2018-04-11 00:37:41 --> URI Class Initialized
INFO - 2018-04-11 00:37:41 --> Router Class Initialized
INFO - 2018-04-11 00:37:41 --> Output Class Initialized
INFO - 2018-04-11 00:37:41 --> Security Class Initialized
DEBUG - 2018-04-11 00:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 00:37:41 --> CSRF cookie sent
INFO - 2018-04-11 00:37:41 --> Input Class Initialized
INFO - 2018-04-11 00:37:41 --> Language Class Initialized
INFO - 2018-04-11 00:37:41 --> Loader Class Initialized
INFO - 2018-04-11 00:37:41 --> Helper loaded: url_helper
INFO - 2018-04-11 00:37:41 --> Helper loaded: form_helper
INFO - 2018-04-11 00:37:41 --> Helper loaded: language_helper
DEBUG - 2018-04-11 00:37:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 00:37:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 00:37:41 --> User Agent Class Initialized
INFO - 2018-04-11 00:37:41 --> Controller Class Initialized
INFO - 2018-04-11 00:37:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 00:37:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 00:37:58 --> Config Class Initialized
INFO - 2018-04-11 00:37:58 --> Hooks Class Initialized
DEBUG - 2018-04-11 00:37:58 --> UTF-8 Support Enabled
INFO - 2018-04-11 00:37:58 --> Utf8 Class Initialized
INFO - 2018-04-11 00:37:58 --> URI Class Initialized
INFO - 2018-04-11 00:37:58 --> Router Class Initialized
INFO - 2018-04-11 00:37:58 --> Output Class Initialized
INFO - 2018-04-11 00:37:58 --> Security Class Initialized
DEBUG - 2018-04-11 00:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 00:37:58 --> CSRF cookie sent
INFO - 2018-04-11 00:37:58 --> Input Class Initialized
INFO - 2018-04-11 00:37:58 --> Language Class Initialized
INFO - 2018-04-11 00:37:58 --> Loader Class Initialized
INFO - 2018-04-11 00:37:58 --> Helper loaded: url_helper
INFO - 2018-04-11 00:37:58 --> Helper loaded: form_helper
INFO - 2018-04-11 00:37:58 --> Helper loaded: language_helper
DEBUG - 2018-04-11 00:37:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 00:37:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 00:37:58 --> User Agent Class Initialized
INFO - 2018-04-11 00:37:58 --> Controller Class Initialized
INFO - 2018-04-11 00:37:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 00:37:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 00:37:58 --> Pixel_Model class loaded
INFO - 2018-04-11 00:37:58 --> Database Driver Class Initialized
INFO - 2018-04-11 00:38:01 --> Model "RegistrationModel" initialized
INFO - 2018-04-11 00:44:36 --> Config Class Initialized
INFO - 2018-04-11 00:44:36 --> Hooks Class Initialized
DEBUG - 2018-04-11 00:44:36 --> UTF-8 Support Enabled
INFO - 2018-04-11 00:44:36 --> Utf8 Class Initialized
INFO - 2018-04-11 00:44:36 --> URI Class Initialized
INFO - 2018-04-11 00:44:36 --> Router Class Initialized
INFO - 2018-04-11 00:44:36 --> Output Class Initialized
INFO - 2018-04-11 00:44:36 --> Security Class Initialized
DEBUG - 2018-04-11 00:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 00:44:36 --> CSRF cookie sent
INFO - 2018-04-11 00:44:36 --> Input Class Initialized
INFO - 2018-04-11 00:44:36 --> Language Class Initialized
INFO - 2018-04-11 00:44:36 --> Loader Class Initialized
INFO - 2018-04-11 00:44:36 --> Helper loaded: url_helper
INFO - 2018-04-11 00:44:36 --> Helper loaded: form_helper
INFO - 2018-04-11 00:44:36 --> Helper loaded: language_helper
DEBUG - 2018-04-11 00:44:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 00:44:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 00:44:36 --> User Agent Class Initialized
INFO - 2018-04-11 00:44:36 --> Controller Class Initialized
INFO - 2018-04-11 00:44:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 00:44:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 00:44:36 --> Pixel_Model class loaded
INFO - 2018-04-11 00:44:36 --> Database Driver Class Initialized
INFO - 2018-04-11 00:44:39 --> Model "RegistrationModel" initialized
INFO - 2018-04-11 00:44:39 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 00:44:39 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
ERROR - 2018-04-11 00:44:39 --> Severity: Notice --> Undefined variable: txt3 E:\www\yacopoo\application\views\shared\_page_header.php 6
INFO - 2018-04-11 00:44:39 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-11 00:44:39 --> File loaded: E:\www\yacopoo\application\views\register/activation_success.php
INFO - 2018-04-11 00:44:39 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 00:44:39 --> Final output sent to browser
DEBUG - 2018-04-11 00:44:39 --> Total execution time: 3.4156
INFO - 2018-04-11 00:44:40 --> Config Class Initialized
INFO - 2018-04-11 00:44:40 --> Config Class Initialized
INFO - 2018-04-11 00:44:40 --> Config Class Initialized
INFO - 2018-04-11 00:44:40 --> Hooks Class Initialized
INFO - 2018-04-11 00:44:40 --> Hooks Class Initialized
INFO - 2018-04-11 00:44:40 --> Hooks Class Initialized
DEBUG - 2018-04-11 00:44:40 --> UTF-8 Support Enabled
DEBUG - 2018-04-11 00:44:40 --> UTF-8 Support Enabled
DEBUG - 2018-04-11 00:44:40 --> UTF-8 Support Enabled
INFO - 2018-04-11 00:44:40 --> Utf8 Class Initialized
INFO - 2018-04-11 00:44:40 --> Utf8 Class Initialized
INFO - 2018-04-11 00:44:40 --> Utf8 Class Initialized
INFO - 2018-04-11 00:44:40 --> URI Class Initialized
INFO - 2018-04-11 00:44:40 --> URI Class Initialized
INFO - 2018-04-11 00:44:40 --> URI Class Initialized
INFO - 2018-04-11 00:44:40 --> Router Class Initialized
INFO - 2018-04-11 00:44:40 --> Router Class Initialized
INFO - 2018-04-11 00:44:40 --> Router Class Initialized
INFO - 2018-04-11 00:44:40 --> Output Class Initialized
INFO - 2018-04-11 00:44:40 --> Output Class Initialized
INFO - 2018-04-11 00:44:40 --> Output Class Initialized
INFO - 2018-04-11 00:44:40 --> Security Class Initialized
INFO - 2018-04-11 00:44:40 --> Security Class Initialized
INFO - 2018-04-11 00:44:40 --> Security Class Initialized
DEBUG - 2018-04-11 00:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-11 00:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-11 00:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 00:44:40 --> CSRF cookie sent
INFO - 2018-04-11 00:44:40 --> CSRF cookie sent
INFO - 2018-04-11 00:44:40 --> CSRF cookie sent
INFO - 2018-04-11 00:44:40 --> Input Class Initialized
INFO - 2018-04-11 00:44:40 --> Input Class Initialized
INFO - 2018-04-11 00:44:40 --> Input Class Initialized
INFO - 2018-04-11 00:44:40 --> Language Class Initialized
INFO - 2018-04-11 00:44:40 --> Language Class Initialized
INFO - 2018-04-11 00:44:40 --> Language Class Initialized
ERROR - 2018-04-11 00:44:40 --> 404 Page Not Found: Activate-account/assets
ERROR - 2018-04-11 00:44:40 --> 404 Page Not Found: Activate-account/assets
ERROR - 2018-04-11 00:44:40 --> 404 Page Not Found: Activate-account/assets
INFO - 2018-04-11 00:45:03 --> Config Class Initialized
INFO - 2018-04-11 00:45:03 --> Hooks Class Initialized
DEBUG - 2018-04-11 00:45:03 --> UTF-8 Support Enabled
INFO - 2018-04-11 00:45:03 --> Utf8 Class Initialized
INFO - 2018-04-11 00:45:03 --> URI Class Initialized
INFO - 2018-04-11 00:45:03 --> Router Class Initialized
INFO - 2018-04-11 00:45:03 --> Output Class Initialized
INFO - 2018-04-11 00:45:03 --> Security Class Initialized
DEBUG - 2018-04-11 00:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 00:45:03 --> CSRF cookie sent
INFO - 2018-04-11 00:45:03 --> Input Class Initialized
INFO - 2018-04-11 00:45:03 --> Language Class Initialized
INFO - 2018-04-11 00:45:03 --> Loader Class Initialized
INFO - 2018-04-11 00:45:03 --> Helper loaded: url_helper
INFO - 2018-04-11 00:45:03 --> Helper loaded: form_helper
INFO - 2018-04-11 00:45:03 --> Helper loaded: language_helper
DEBUG - 2018-04-11 00:45:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 00:45:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 00:45:03 --> User Agent Class Initialized
INFO - 2018-04-11 00:45:03 --> Controller Class Initialized
INFO - 2018-04-11 00:45:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 00:45:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 00:45:03 --> Pixel_Model class loaded
INFO - 2018-04-11 00:45:03 --> Database Driver Class Initialized
INFO - 2018-04-11 00:45:03 --> Model "RegistrationModel" initialized
INFO - 2018-04-11 00:45:03 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 00:45:03 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-11 00:45:03 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-11 00:45:03 --> File loaded: E:\www\yacopoo\application\views\register/activation_success.php
INFO - 2018-04-11 00:45:03 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 00:45:03 --> Final output sent to browser
DEBUG - 2018-04-11 00:45:03 --> Total execution time: 0.3811
INFO - 2018-04-11 00:45:04 --> Config Class Initialized
INFO - 2018-04-11 00:45:04 --> Config Class Initialized
INFO - 2018-04-11 00:45:04 --> Config Class Initialized
INFO - 2018-04-11 00:45:04 --> Hooks Class Initialized
INFO - 2018-04-11 00:45:04 --> Hooks Class Initialized
INFO - 2018-04-11 00:45:04 --> Hooks Class Initialized
DEBUG - 2018-04-11 00:45:04 --> UTF-8 Support Enabled
DEBUG - 2018-04-11 00:45:04 --> UTF-8 Support Enabled
INFO - 2018-04-11 00:45:04 --> Utf8 Class Initialized
INFO - 2018-04-11 00:45:04 --> Utf8 Class Initialized
DEBUG - 2018-04-11 00:45:04 --> UTF-8 Support Enabled
INFO - 2018-04-11 00:45:04 --> Utf8 Class Initialized
INFO - 2018-04-11 00:45:04 --> URI Class Initialized
INFO - 2018-04-11 00:45:04 --> URI Class Initialized
INFO - 2018-04-11 00:45:04 --> URI Class Initialized
INFO - 2018-04-11 00:45:04 --> Router Class Initialized
INFO - 2018-04-11 00:45:04 --> Router Class Initialized
INFO - 2018-04-11 00:45:04 --> Output Class Initialized
INFO - 2018-04-11 00:45:04 --> Output Class Initialized
INFO - 2018-04-11 00:45:04 --> Router Class Initialized
INFO - 2018-04-11 00:45:04 --> Output Class Initialized
INFO - 2018-04-11 00:45:04 --> Security Class Initialized
INFO - 2018-04-11 00:45:04 --> Security Class Initialized
DEBUG - 2018-04-11 00:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 00:45:04 --> Security Class Initialized
DEBUG - 2018-04-11 00:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 00:45:04 --> CSRF cookie sent
INFO - 2018-04-11 00:45:04 --> CSRF cookie sent
DEBUG - 2018-04-11 00:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 00:45:04 --> Input Class Initialized
INFO - 2018-04-11 00:45:04 --> Input Class Initialized
INFO - 2018-04-11 00:45:04 --> CSRF cookie sent
INFO - 2018-04-11 00:45:04 --> Input Class Initialized
INFO - 2018-04-11 00:45:04 --> Language Class Initialized
INFO - 2018-04-11 00:45:04 --> Language Class Initialized
INFO - 2018-04-11 00:45:04 --> Language Class Initialized
ERROR - 2018-04-11 00:45:04 --> 404 Page Not Found: Activate-account/assets
ERROR - 2018-04-11 00:45:04 --> 404 Page Not Found: Activate-account/assets
ERROR - 2018-04-11 00:45:04 --> 404 Page Not Found: Activate-account/assets
INFO - 2018-04-11 00:45:24 --> Config Class Initialized
INFO - 2018-04-11 00:45:24 --> Hooks Class Initialized
DEBUG - 2018-04-11 00:45:24 --> UTF-8 Support Enabled
INFO - 2018-04-11 00:45:24 --> Utf8 Class Initialized
INFO - 2018-04-11 00:45:24 --> URI Class Initialized
INFO - 2018-04-11 00:45:24 --> Router Class Initialized
INFO - 2018-04-11 00:45:24 --> Output Class Initialized
INFO - 2018-04-11 00:45:24 --> Security Class Initialized
DEBUG - 2018-04-11 00:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 00:45:24 --> CSRF cookie sent
INFO - 2018-04-11 00:45:24 --> Input Class Initialized
INFO - 2018-04-11 00:45:24 --> Language Class Initialized
INFO - 2018-04-11 00:45:24 --> Loader Class Initialized
INFO - 2018-04-11 00:45:24 --> Helper loaded: url_helper
INFO - 2018-04-11 00:45:24 --> Helper loaded: form_helper
INFO - 2018-04-11 00:45:24 --> Helper loaded: language_helper
DEBUG - 2018-04-11 00:45:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 00:45:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 00:45:24 --> User Agent Class Initialized
INFO - 2018-04-11 00:45:24 --> Controller Class Initialized
INFO - 2018-04-11 00:45:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 00:45:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 00:45:24 --> Pixel_Model class loaded
INFO - 2018-04-11 00:45:24 --> Database Driver Class Initialized
INFO - 2018-04-11 00:45:24 --> Model "RegistrationModel" initialized
INFO - 2018-04-11 00:45:24 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 00:45:24 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-11 00:45:24 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-11 00:45:24 --> File loaded: E:\www\yacopoo\application\views\register/activation_success.php
INFO - 2018-04-11 00:45:24 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 00:45:24 --> Final output sent to browser
DEBUG - 2018-04-11 00:45:24 --> Total execution time: 0.4269
INFO - 2018-04-11 00:45:25 --> Config Class Initialized
INFO - 2018-04-11 00:45:25 --> Config Class Initialized
INFO - 2018-04-11 00:45:25 --> Hooks Class Initialized
INFO - 2018-04-11 00:45:25 --> Hooks Class Initialized
INFO - 2018-04-11 00:45:25 --> Config Class Initialized
INFO - 2018-04-11 00:45:25 --> Hooks Class Initialized
DEBUG - 2018-04-11 00:45:25 --> UTF-8 Support Enabled
DEBUG - 2018-04-11 00:45:25 --> UTF-8 Support Enabled
INFO - 2018-04-11 00:45:25 --> Utf8 Class Initialized
INFO - 2018-04-11 00:45:25 --> Utf8 Class Initialized
DEBUG - 2018-04-11 00:45:25 --> UTF-8 Support Enabled
INFO - 2018-04-11 00:45:25 --> Utf8 Class Initialized
INFO - 2018-04-11 00:45:25 --> URI Class Initialized
INFO - 2018-04-11 00:45:25 --> URI Class Initialized
INFO - 2018-04-11 00:45:25 --> URI Class Initialized
INFO - 2018-04-11 00:45:25 --> Router Class Initialized
INFO - 2018-04-11 00:45:25 --> Router Class Initialized
INFO - 2018-04-11 00:45:25 --> Output Class Initialized
INFO - 2018-04-11 00:45:25 --> Output Class Initialized
INFO - 2018-04-11 00:45:25 --> Router Class Initialized
INFO - 2018-04-11 00:45:25 --> Output Class Initialized
INFO - 2018-04-11 00:45:25 --> Security Class Initialized
INFO - 2018-04-11 00:45:25 --> Security Class Initialized
DEBUG - 2018-04-11 00:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 00:45:25 --> Security Class Initialized
DEBUG - 2018-04-11 00:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 00:45:25 --> CSRF cookie sent
INFO - 2018-04-11 00:45:25 --> CSRF cookie sent
DEBUG - 2018-04-11 00:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 00:45:25 --> Input Class Initialized
INFO - 2018-04-11 00:45:25 --> Input Class Initialized
INFO - 2018-04-11 00:45:25 --> CSRF cookie sent
INFO - 2018-04-11 00:45:25 --> Input Class Initialized
INFO - 2018-04-11 00:45:25 --> Language Class Initialized
INFO - 2018-04-11 00:45:25 --> Language Class Initialized
INFO - 2018-04-11 00:45:25 --> Language Class Initialized
ERROR - 2018-04-11 00:45:25 --> 404 Page Not Found: Activate-account/assets
ERROR - 2018-04-11 00:45:25 --> 404 Page Not Found: Activate-account/assets
ERROR - 2018-04-11 00:45:25 --> 404 Page Not Found: Activate-account/assets
INFO - 2018-04-11 00:47:10 --> Config Class Initialized
INFO - 2018-04-11 00:47:10 --> Hooks Class Initialized
DEBUG - 2018-04-11 00:47:10 --> UTF-8 Support Enabled
INFO - 2018-04-11 00:47:10 --> Utf8 Class Initialized
INFO - 2018-04-11 00:47:10 --> URI Class Initialized
INFO - 2018-04-11 00:47:10 --> Router Class Initialized
INFO - 2018-04-11 00:47:10 --> Output Class Initialized
INFO - 2018-04-11 00:47:10 --> Security Class Initialized
DEBUG - 2018-04-11 00:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 00:47:11 --> CSRF cookie sent
INFO - 2018-04-11 00:47:11 --> Input Class Initialized
INFO - 2018-04-11 00:47:11 --> Language Class Initialized
INFO - 2018-04-11 00:47:11 --> Loader Class Initialized
INFO - 2018-04-11 00:47:11 --> Helper loaded: url_helper
INFO - 2018-04-11 00:47:11 --> Helper loaded: form_helper
INFO - 2018-04-11 00:47:11 --> Helper loaded: language_helper
DEBUG - 2018-04-11 00:47:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 00:47:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 00:47:11 --> User Agent Class Initialized
INFO - 2018-04-11 00:47:11 --> Controller Class Initialized
INFO - 2018-04-11 00:47:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 00:47:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 00:47:11 --> Pixel_Model class loaded
INFO - 2018-04-11 00:47:11 --> Database Driver Class Initialized
INFO - 2018-04-11 00:47:14 --> Model "RegistrationModel" initialized
DEBUG - 2018-04-11 00:47:14 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-11 00:47:14 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 00:47:14 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-11 00:47:14 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-11 00:47:14 --> Could not find the language line "req_email"
INFO - 2018-04-11 00:47:14 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-04-11 00:47:14 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 00:47:14 --> Final output sent to browser
DEBUG - 2018-04-11 00:47:14 --> Total execution time: 3.4045
INFO - 2018-04-11 00:51:16 --> Config Class Initialized
INFO - 2018-04-11 00:51:16 --> Hooks Class Initialized
DEBUG - 2018-04-11 00:51:16 --> UTF-8 Support Enabled
INFO - 2018-04-11 00:51:16 --> Utf8 Class Initialized
INFO - 2018-04-11 00:51:16 --> URI Class Initialized
INFO - 2018-04-11 00:51:16 --> Router Class Initialized
INFO - 2018-04-11 00:51:16 --> Output Class Initialized
INFO - 2018-04-11 00:51:16 --> Security Class Initialized
DEBUG - 2018-04-11 00:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 00:51:16 --> CSRF cookie sent
INFO - 2018-04-11 00:51:16 --> Input Class Initialized
INFO - 2018-04-11 00:51:16 --> Language Class Initialized
INFO - 2018-04-11 00:51:16 --> Loader Class Initialized
INFO - 2018-04-11 00:51:16 --> Helper loaded: url_helper
INFO - 2018-04-11 00:51:16 --> Helper loaded: form_helper
INFO - 2018-04-11 00:51:16 --> Helper loaded: language_helper
DEBUG - 2018-04-11 00:51:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 00:51:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 00:51:16 --> User Agent Class Initialized
INFO - 2018-04-11 00:51:16 --> Controller Class Initialized
INFO - 2018-04-11 00:51:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 00:51:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 00:51:16 --> Pixel_Model class loaded
INFO - 2018-04-11 00:51:16 --> Database Driver Class Initialized
INFO - 2018-04-11 00:51:19 --> Model "RegistrationModel" initialized
DEBUG - 2018-04-11 00:51:19 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-11 00:51:19 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 00:51:19 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-11 00:51:19 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-11 00:51:19 --> Could not find the language line "req_email"
INFO - 2018-04-11 00:51:19 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-04-11 00:51:19 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 00:51:19 --> Final output sent to browser
DEBUG - 2018-04-11 00:51:19 --> Total execution time: 3.4026
INFO - 2018-04-11 01:03:21 --> Config Class Initialized
INFO - 2018-04-11 01:03:21 --> Hooks Class Initialized
DEBUG - 2018-04-11 01:03:21 --> UTF-8 Support Enabled
INFO - 2018-04-11 01:03:21 --> Utf8 Class Initialized
INFO - 2018-04-11 01:03:21 --> URI Class Initialized
INFO - 2018-04-11 01:03:21 --> Router Class Initialized
INFO - 2018-04-11 01:03:21 --> Output Class Initialized
INFO - 2018-04-11 01:03:21 --> Security Class Initialized
DEBUG - 2018-04-11 01:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 01:03:21 --> CSRF cookie sent
INFO - 2018-04-11 01:03:21 --> Input Class Initialized
INFO - 2018-04-11 01:03:21 --> Language Class Initialized
INFO - 2018-04-11 01:03:21 --> Loader Class Initialized
INFO - 2018-04-11 01:03:21 --> Helper loaded: url_helper
INFO - 2018-04-11 01:03:21 --> Helper loaded: form_helper
INFO - 2018-04-11 01:03:21 --> Helper loaded: language_helper
DEBUG - 2018-04-11 01:03:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 01:03:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 01:03:21 --> User Agent Class Initialized
INFO - 2018-04-11 01:03:21 --> Controller Class Initialized
INFO - 2018-04-11 01:03:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 01:03:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 01:03:21 --> Pixel_Model class loaded
INFO - 2018-04-11 01:03:21 --> Database Driver Class Initialized
INFO - 2018-04-11 01:03:24 --> Model "RegistrationModel" initialized
DEBUG - 2018-04-11 01:03:24 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-11 01:03:24 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 01:03:24 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-11 01:03:24 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-11 01:03:24 --> Could not find the language line "req_email"
INFO - 2018-04-11 01:03:24 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-04-11 01:03:24 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 01:03:24 --> Final output sent to browser
DEBUG - 2018-04-11 01:03:24 --> Total execution time: 3.4205
INFO - 2018-04-11 14:56:38 --> Config Class Initialized
INFO - 2018-04-11 14:56:38 --> Hooks Class Initialized
DEBUG - 2018-04-11 14:56:39 --> UTF-8 Support Enabled
INFO - 2018-04-11 14:56:39 --> Utf8 Class Initialized
INFO - 2018-04-11 14:56:39 --> URI Class Initialized
INFO - 2018-04-11 14:56:40 --> Router Class Initialized
INFO - 2018-04-11 14:56:40 --> Output Class Initialized
INFO - 2018-04-11 14:56:41 --> Security Class Initialized
DEBUG - 2018-04-11 14:56:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 14:56:41 --> CSRF cookie sent
INFO - 2018-04-11 14:56:41 --> Input Class Initialized
INFO - 2018-04-11 14:56:41 --> Language Class Initialized
INFO - 2018-04-11 14:56:42 --> Loader Class Initialized
INFO - 2018-04-11 14:56:42 --> Helper loaded: url_helper
INFO - 2018-04-11 14:56:43 --> Helper loaded: form_helper
INFO - 2018-04-11 14:56:43 --> Helper loaded: language_helper
DEBUG - 2018-04-11 14:56:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 14:56:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 14:56:44 --> User Agent Class Initialized
INFO - 2018-04-11 14:56:45 --> Controller Class Initialized
INFO - 2018-04-11 14:56:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 14:56:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 14:56:46 --> Pixel_Model class loaded
INFO - 2018-04-11 14:56:47 --> Database Driver Class Initialized
INFO - 2018-04-11 14:56:50 --> Model "RegistrationModel" initialized
DEBUG - 2018-04-11 14:56:50 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-11 14:56:51 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 14:56:52 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-11 14:56:52 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-11 14:56:52 --> Could not find the language line "req_email"
INFO - 2018-04-11 14:56:52 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-04-11 14:56:52 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 14:56:52 --> Final output sent to browser
DEBUG - 2018-04-11 14:56:52 --> Total execution time: 15.1387
INFO - 2018-04-11 14:56:52 --> Config Class Initialized
INFO - 2018-04-11 14:56:52 --> Hooks Class Initialized
DEBUG - 2018-04-11 14:56:52 --> UTF-8 Support Enabled
INFO - 2018-04-11 14:56:52 --> Config Class Initialized
INFO - 2018-04-11 14:56:52 --> Hooks Class Initialized
INFO - 2018-04-11 14:56:52 --> Utf8 Class Initialized
INFO - 2018-04-11 14:56:53 --> URI Class Initialized
DEBUG - 2018-04-11 14:56:53 --> UTF-8 Support Enabled
INFO - 2018-04-11 14:56:53 --> Utf8 Class Initialized
INFO - 2018-04-11 14:56:53 --> Router Class Initialized
INFO - 2018-04-11 14:56:53 --> URI Class Initialized
INFO - 2018-04-11 14:56:53 --> Output Class Initialized
INFO - 2018-04-11 14:56:53 --> Router Class Initialized
INFO - 2018-04-11 14:56:53 --> Security Class Initialized
INFO - 2018-04-11 14:56:53 --> Output Class Initialized
INFO - 2018-04-11 14:56:53 --> Security Class Initialized
DEBUG - 2018-04-11 14:56:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 14:56:54 --> CSRF cookie sent
DEBUG - 2018-04-11 14:56:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 14:56:54 --> Input Class Initialized
INFO - 2018-04-11 14:56:54 --> CSRF cookie sent
INFO - 2018-04-11 14:56:54 --> Language Class Initialized
INFO - 2018-04-11 14:56:54 --> Input Class Initialized
INFO - 2018-04-11 14:56:54 --> Loader Class Initialized
INFO - 2018-04-11 14:56:54 --> Language Class Initialized
INFO - 2018-04-11 14:56:54 --> Helper loaded: url_helper
INFO - 2018-04-11 14:56:54 --> Helper loaded: form_helper
INFO - 2018-04-11 14:56:54 --> Loader Class Initialized
INFO - 2018-04-11 14:56:55 --> Helper loaded: url_helper
INFO - 2018-04-11 14:56:55 --> Helper loaded: language_helper
INFO - 2018-04-11 14:56:55 --> Helper loaded: form_helper
DEBUG - 2018-04-11 14:56:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 14:56:55 --> Helper loaded: language_helper
INFO - 2018-04-11 14:56:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 14:56:55 --> User Agent Class Initialized
DEBUG - 2018-04-11 14:56:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 14:56:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 14:56:56 --> Controller Class Initialized
INFO - 2018-04-11 14:56:56 --> User Agent Class Initialized
INFO - 2018-04-11 14:56:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 14:56:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 14:56:56 --> Controller Class Initialized
INFO - 2018-04-11 14:56:56 --> Pixel_Model class loaded
INFO - 2018-04-11 14:56:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 14:56:57 --> Database Driver Class Initialized
INFO - 2018-04-11 14:56:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 14:56:57 --> Pixel_Model class loaded
INFO - 2018-04-11 14:56:57 --> Database Driver Class Initialized
INFO - 2018-04-11 14:56:57 --> Model "RegistrationModel" initialized
DEBUG - 2018-04-11 14:56:57 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-11 14:56:58 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 14:56:58 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-11 14:56:58 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-11 14:56:58 --> Could not find the language line "req_email"
INFO - 2018-04-11 14:56:58 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-04-11 14:56:58 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 14:56:58 --> Final output sent to browser
DEBUG - 2018-04-11 14:56:58 --> Total execution time: 5.8969
INFO - 2018-04-11 14:57:00 --> Model "RegistrationModel" initialized
DEBUG - 2018-04-11 14:57:00 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-11 14:57:00 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 14:57:00 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-11 14:57:00 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-11 14:57:01 --> Could not find the language line "req_email"
INFO - 2018-04-11 14:57:01 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-04-11 14:57:01 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 14:57:01 --> Final output sent to browser
DEBUG - 2018-04-11 14:57:01 --> Total execution time: 8.7545
INFO - 2018-04-11 16:02:56 --> Config Class Initialized
INFO - 2018-04-11 16:02:56 --> Hooks Class Initialized
DEBUG - 2018-04-11 16:02:56 --> UTF-8 Support Enabled
INFO - 2018-04-11 16:02:56 --> Utf8 Class Initialized
INFO - 2018-04-11 16:02:56 --> URI Class Initialized
INFO - 2018-04-11 16:02:56 --> Router Class Initialized
INFO - 2018-04-11 16:02:56 --> Output Class Initialized
INFO - 2018-04-11 16:02:56 --> Security Class Initialized
DEBUG - 2018-04-11 16:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 16:02:56 --> CSRF cookie sent
INFO - 2018-04-11 16:02:56 --> Input Class Initialized
INFO - 2018-04-11 16:02:56 --> Language Class Initialized
INFO - 2018-04-11 16:02:56 --> Loader Class Initialized
INFO - 2018-04-11 16:02:56 --> Helper loaded: url_helper
INFO - 2018-04-11 16:02:56 --> Helper loaded: form_helper
INFO - 2018-04-11 16:02:56 --> Helper loaded: language_helper
DEBUG - 2018-04-11 16:02:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 16:02:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 16:02:56 --> User Agent Class Initialized
INFO - 2018-04-11 16:02:56 --> Controller Class Initialized
INFO - 2018-04-11 16:02:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 16:02:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 16:02:56 --> Pixel_Model class loaded
INFO - 2018-04-11 16:02:56 --> Database Driver Class Initialized
INFO - 2018-04-11 16:02:59 --> Model "RegistrationModel" initialized
DEBUG - 2018-04-11 16:02:59 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-11 16:02:59 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 16:02:59 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-11 16:02:59 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-11 16:02:59 --> Could not find the language line "req_email"
INFO - 2018-04-11 16:02:59 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-04-11 16:02:59 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 16:02:59 --> Final output sent to browser
DEBUG - 2018-04-11 16:02:59 --> Total execution time: 3.4621
INFO - 2018-04-11 16:06:39 --> Config Class Initialized
INFO - 2018-04-11 16:06:39 --> Hooks Class Initialized
DEBUG - 2018-04-11 16:06:39 --> UTF-8 Support Enabled
INFO - 2018-04-11 16:06:39 --> Utf8 Class Initialized
INFO - 2018-04-11 16:06:39 --> URI Class Initialized
INFO - 2018-04-11 16:06:39 --> Router Class Initialized
INFO - 2018-04-11 16:06:39 --> Output Class Initialized
INFO - 2018-04-11 16:06:39 --> Security Class Initialized
DEBUG - 2018-04-11 16:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 16:06:39 --> CSRF cookie sent
INFO - 2018-04-11 16:06:39 --> Input Class Initialized
INFO - 2018-04-11 16:06:39 --> Language Class Initialized
INFO - 2018-04-11 16:06:39 --> Loader Class Initialized
INFO - 2018-04-11 16:06:39 --> Helper loaded: url_helper
INFO - 2018-04-11 16:06:39 --> Helper loaded: form_helper
INFO - 2018-04-11 16:06:39 --> Helper loaded: language_helper
DEBUG - 2018-04-11 16:06:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 16:06:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 16:06:39 --> User Agent Class Initialized
INFO - 2018-04-11 16:06:39 --> Controller Class Initialized
INFO - 2018-04-11 16:06:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 16:06:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 16:06:39 --> Pixel_Model class loaded
INFO - 2018-04-11 16:06:39 --> Database Driver Class Initialized
INFO - 2018-04-11 16:06:42 --> Model "RegistrationModel" initialized
DEBUG - 2018-04-11 16:06:42 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-11 16:06:42 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 16:06:42 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-11 16:06:42 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-11 16:06:42 --> Could not find the language line "req_email"
INFO - 2018-04-11 16:06:42 --> File loaded: E:\www\yacopoo\application\views\register/signup_lawyer.php
INFO - 2018-04-11 16:06:42 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 16:06:42 --> Final output sent to browser
DEBUG - 2018-04-11 16:06:42 --> Total execution time: 3.5067
INFO - 2018-04-11 16:07:07 --> Config Class Initialized
INFO - 2018-04-11 16:07:07 --> Hooks Class Initialized
DEBUG - 2018-04-11 16:07:07 --> UTF-8 Support Enabled
INFO - 2018-04-11 16:07:07 --> Utf8 Class Initialized
INFO - 2018-04-11 16:07:07 --> URI Class Initialized
INFO - 2018-04-11 16:07:07 --> Router Class Initialized
INFO - 2018-04-11 16:07:07 --> Output Class Initialized
INFO - 2018-04-11 16:07:07 --> Security Class Initialized
DEBUG - 2018-04-11 16:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 16:07:07 --> CSRF cookie sent
INFO - 2018-04-11 16:07:07 --> Input Class Initialized
INFO - 2018-04-11 16:07:07 --> Language Class Initialized
INFO - 2018-04-11 16:07:08 --> Loader Class Initialized
INFO - 2018-04-11 16:07:08 --> Helper loaded: url_helper
INFO - 2018-04-11 16:07:08 --> Helper loaded: form_helper
INFO - 2018-04-11 16:07:08 --> Helper loaded: language_helper
DEBUG - 2018-04-11 16:07:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 16:07:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 16:07:08 --> User Agent Class Initialized
INFO - 2018-04-11 16:07:08 --> Controller Class Initialized
INFO - 2018-04-11 16:07:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 16:07:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 16:07:08 --> Pixel_Model class loaded
INFO - 2018-04-11 16:07:08 --> Database Driver Class Initialized
INFO - 2018-04-11 16:07:11 --> Model "RegistrationModel" initialized
DEBUG - 2018-04-11 16:07:11 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-11 16:07:11 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 16:07:11 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-11 16:07:11 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-11 16:07:11 --> Could not find the language line "req_email"
INFO - 2018-04-11 16:07:11 --> File loaded: E:\www\yacopoo\application\views\register/signup_lawyer.php
INFO - 2018-04-11 16:07:11 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 16:07:11 --> Final output sent to browser
DEBUG - 2018-04-11 16:07:11 --> Total execution time: 3.5016
INFO - 2018-04-11 16:07:31 --> Config Class Initialized
INFO - 2018-04-11 16:07:31 --> Hooks Class Initialized
DEBUG - 2018-04-11 16:07:31 --> UTF-8 Support Enabled
INFO - 2018-04-11 16:07:31 --> Utf8 Class Initialized
INFO - 2018-04-11 16:07:31 --> URI Class Initialized
INFO - 2018-04-11 16:07:31 --> Router Class Initialized
INFO - 2018-04-11 16:07:31 --> Output Class Initialized
INFO - 2018-04-11 16:07:31 --> Security Class Initialized
DEBUG - 2018-04-11 16:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 16:07:31 --> CSRF cookie sent
INFO - 2018-04-11 16:07:31 --> Input Class Initialized
INFO - 2018-04-11 16:07:31 --> Language Class Initialized
INFO - 2018-04-11 16:07:31 --> Loader Class Initialized
INFO - 2018-04-11 16:07:31 --> Helper loaded: url_helper
INFO - 2018-04-11 16:07:31 --> Helper loaded: form_helper
INFO - 2018-04-11 16:07:31 --> Helper loaded: language_helper
DEBUG - 2018-04-11 16:07:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 16:07:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 16:07:31 --> User Agent Class Initialized
INFO - 2018-04-11 16:07:31 --> Controller Class Initialized
INFO - 2018-04-11 16:07:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 16:07:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 16:07:31 --> Pixel_Model class loaded
INFO - 2018-04-11 16:07:31 --> Database Driver Class Initialized
INFO - 2018-04-11 16:07:31 --> Model "RegistrationModel" initialized
DEBUG - 2018-04-11 16:07:31 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-11 16:07:31 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 16:07:31 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-11 16:07:31 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-11 16:07:31 --> Could not find the language line "req_email"
INFO - 2018-04-11 16:07:31 --> File loaded: E:\www\yacopoo\application\views\register/signup_lawyer.php
INFO - 2018-04-11 16:07:31 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 16:07:31 --> Final output sent to browser
DEBUG - 2018-04-11 16:07:31 --> Total execution time: 0.4363
INFO - 2018-04-11 16:27:30 --> Config Class Initialized
INFO - 2018-04-11 16:27:30 --> Hooks Class Initialized
DEBUG - 2018-04-11 16:27:30 --> UTF-8 Support Enabled
INFO - 2018-04-11 16:27:30 --> Utf8 Class Initialized
INFO - 2018-04-11 16:27:30 --> URI Class Initialized
INFO - 2018-04-11 16:27:30 --> Router Class Initialized
INFO - 2018-04-11 16:27:30 --> Output Class Initialized
INFO - 2018-04-11 16:27:30 --> Security Class Initialized
DEBUG - 2018-04-11 16:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 16:27:30 --> CSRF cookie sent
INFO - 2018-04-11 16:27:30 --> Input Class Initialized
INFO - 2018-04-11 16:27:30 --> Language Class Initialized
INFO - 2018-04-11 16:27:30 --> Loader Class Initialized
INFO - 2018-04-11 16:27:30 --> Helper loaded: url_helper
INFO - 2018-04-11 16:27:30 --> Helper loaded: form_helper
INFO - 2018-04-11 16:27:30 --> Helper loaded: language_helper
DEBUG - 2018-04-11 16:27:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 16:27:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 16:27:30 --> User Agent Class Initialized
INFO - 2018-04-11 16:27:30 --> Controller Class Initialized
INFO - 2018-04-11 16:27:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 16:27:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 16:27:30 --> Pixel_Model class loaded
INFO - 2018-04-11 16:27:31 --> Database Driver Class Initialized
INFO - 2018-04-11 16:27:34 --> Model "RegistrationModel" initialized
DEBUG - 2018-04-11 16:27:34 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-11 16:27:34 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 16:27:34 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-11 16:27:34 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-11 16:27:34 --> Could not find the language line "req_email"
ERROR - 2018-04-11 16:27:34 --> Could not find the language line "practice_type"
INFO - 2018-04-11 16:27:34 --> File loaded: E:\www\yacopoo\application\views\register/signup_lawyer.php
INFO - 2018-04-11 16:27:34 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 16:27:34 --> Final output sent to browser
DEBUG - 2018-04-11 16:27:34 --> Total execution time: 3.4562
INFO - 2018-04-11 16:33:36 --> Config Class Initialized
INFO - 2018-04-11 16:33:36 --> Hooks Class Initialized
DEBUG - 2018-04-11 16:33:36 --> UTF-8 Support Enabled
INFO - 2018-04-11 16:33:36 --> Utf8 Class Initialized
INFO - 2018-04-11 16:33:36 --> URI Class Initialized
INFO - 2018-04-11 16:33:36 --> Router Class Initialized
INFO - 2018-04-11 16:33:36 --> Output Class Initialized
INFO - 2018-04-11 16:33:36 --> Security Class Initialized
DEBUG - 2018-04-11 16:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 16:33:36 --> CSRF cookie sent
INFO - 2018-04-11 16:33:36 --> Input Class Initialized
INFO - 2018-04-11 16:33:36 --> Language Class Initialized
INFO - 2018-04-11 16:33:36 --> Loader Class Initialized
INFO - 2018-04-11 16:33:36 --> Helper loaded: url_helper
INFO - 2018-04-11 16:33:36 --> Helper loaded: form_helper
INFO - 2018-04-11 16:33:36 --> Helper loaded: language_helper
DEBUG - 2018-04-11 16:33:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 16:33:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 16:33:36 --> User Agent Class Initialized
INFO - 2018-04-11 16:33:36 --> Controller Class Initialized
INFO - 2018-04-11 16:33:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 16:33:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 16:33:36 --> Pixel_Model class loaded
INFO - 2018-04-11 16:33:36 --> Database Driver Class Initialized
INFO - 2018-04-11 16:33:39 --> Model "RegistrationModel" initialized
DEBUG - 2018-04-11 16:33:39 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-11 16:33:39 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 16:33:39 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-11 16:33:39 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-11 16:33:39 --> Could not find the language line "req_email"
INFO - 2018-04-11 16:33:39 --> File loaded: E:\www\yacopoo\application\views\register/signup_lawyer.php
INFO - 2018-04-11 16:33:39 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 16:33:39 --> Final output sent to browser
DEBUG - 2018-04-11 16:33:39 --> Total execution time: 3.4400
INFO - 2018-04-11 19:06:08 --> Config Class Initialized
INFO - 2018-04-11 19:06:08 --> Hooks Class Initialized
DEBUG - 2018-04-11 19:06:08 --> UTF-8 Support Enabled
INFO - 2018-04-11 19:06:08 --> Utf8 Class Initialized
INFO - 2018-04-11 19:06:08 --> URI Class Initialized
INFO - 2018-04-11 19:06:08 --> Router Class Initialized
INFO - 2018-04-11 19:06:08 --> Output Class Initialized
INFO - 2018-04-11 19:06:08 --> Security Class Initialized
DEBUG - 2018-04-11 19:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 19:06:08 --> CSRF cookie sent
INFO - 2018-04-11 19:06:08 --> Input Class Initialized
INFO - 2018-04-11 19:06:08 --> Language Class Initialized
INFO - 2018-04-11 19:06:08 --> Loader Class Initialized
INFO - 2018-04-11 19:06:08 --> Helper loaded: url_helper
INFO - 2018-04-11 19:06:08 --> Helper loaded: form_helper
INFO - 2018-04-11 19:06:08 --> Helper loaded: language_helper
DEBUG - 2018-04-11 19:06:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 19:06:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 19:06:08 --> User Agent Class Initialized
INFO - 2018-04-11 19:06:08 --> Controller Class Initialized
INFO - 2018-04-11 19:06:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 19:06:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 19:06:08 --> Pixel_Model class loaded
INFO - 2018-04-11 19:06:08 --> Database Driver Class Initialized
INFO - 2018-04-11 19:06:11 --> Model "RegistrationModel" initialized
DEBUG - 2018-04-11 19:06:11 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-11 19:06:12 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 19:06:12 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-11 19:06:12 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-11 19:06:12 --> Could not find the language line "req_email"
INFO - 2018-04-11 19:06:12 --> File loaded: E:\www\yacopoo\application\views\register/signup_lawyer.php
INFO - 2018-04-11 19:06:12 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 19:06:12 --> Final output sent to browser
DEBUG - 2018-04-11 19:06:12 --> Total execution time: 3.4183
INFO - 2018-04-11 19:08:58 --> Config Class Initialized
INFO - 2018-04-11 19:08:58 --> Hooks Class Initialized
DEBUG - 2018-04-11 19:08:58 --> UTF-8 Support Enabled
INFO - 2018-04-11 19:08:58 --> Utf8 Class Initialized
INFO - 2018-04-11 19:08:58 --> URI Class Initialized
INFO - 2018-04-11 19:08:58 --> Router Class Initialized
INFO - 2018-04-11 19:08:58 --> Output Class Initialized
INFO - 2018-04-11 19:08:58 --> Security Class Initialized
DEBUG - 2018-04-11 19:08:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 19:08:58 --> CSRF cookie sent
INFO - 2018-04-11 19:08:58 --> CSRF token verified
INFO - 2018-04-11 19:08:58 --> Input Class Initialized
INFO - 2018-04-11 19:08:58 --> Language Class Initialized
INFO - 2018-04-11 19:08:58 --> Loader Class Initialized
INFO - 2018-04-11 19:08:58 --> Helper loaded: url_helper
INFO - 2018-04-11 19:08:58 --> Helper loaded: form_helper
INFO - 2018-04-11 19:08:58 --> Helper loaded: language_helper
DEBUG - 2018-04-11 19:08:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 19:08:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 19:08:58 --> User Agent Class Initialized
INFO - 2018-04-11 19:08:58 --> Controller Class Initialized
INFO - 2018-04-11 19:08:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 19:08:58 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-11 19:08:58 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-11 19:09:00 --> Form Validation Class Initialized
INFO - 2018-04-11 19:09:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-11 19:09:00 --> Pixel_Model class loaded
INFO - 2018-04-11 19:09:00 --> Database Driver Class Initialized
INFO - 2018-04-11 19:09:03 --> Model "RegistrationModel" initialized
INFO - 2018-04-11 19:09:03 --> Database Driver Class Initialized
INFO - 2018-04-11 19:09:03 --> Model "RegistrationModel" initialized
DEBUG - 2018-04-11 19:09:03 --> Recaptcha class already loaded. Second attempt ignored.
INFO - 2018-04-11 19:09:03 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 19:09:03 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-11 19:09:03 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-11 19:09:03 --> File loaded: E:\www\yacopoo\application\views\shared/_errors.php
ERROR - 2018-04-11 19:09:03 --> Could not find the language line "req_email"
INFO - 2018-04-11 19:09:03 --> File loaded: E:\www\yacopoo\application\views\register/signup_lawyer.php
INFO - 2018-04-11 19:09:03 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 19:09:03 --> Final output sent to browser
DEBUG - 2018-04-11 19:09:03 --> Total execution time: 5.2585
INFO - 2018-04-11 19:10:01 --> Config Class Initialized
INFO - 2018-04-11 19:10:01 --> Hooks Class Initialized
DEBUG - 2018-04-11 19:10:01 --> UTF-8 Support Enabled
INFO - 2018-04-11 19:10:01 --> Utf8 Class Initialized
INFO - 2018-04-11 19:10:01 --> URI Class Initialized
INFO - 2018-04-11 19:10:01 --> Router Class Initialized
INFO - 2018-04-11 19:10:01 --> Output Class Initialized
INFO - 2018-04-11 19:10:01 --> Security Class Initialized
DEBUG - 2018-04-11 19:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 19:10:01 --> CSRF cookie sent
INFO - 2018-04-11 19:10:01 --> CSRF token verified
INFO - 2018-04-11 19:10:01 --> Input Class Initialized
INFO - 2018-04-11 19:10:01 --> Language Class Initialized
INFO - 2018-04-11 19:10:01 --> Loader Class Initialized
INFO - 2018-04-11 19:10:01 --> Helper loaded: url_helper
INFO - 2018-04-11 19:10:01 --> Helper loaded: form_helper
INFO - 2018-04-11 19:10:01 --> Helper loaded: language_helper
DEBUG - 2018-04-11 19:10:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 19:10:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 19:10:01 --> User Agent Class Initialized
INFO - 2018-04-11 19:10:01 --> Controller Class Initialized
INFO - 2018-04-11 19:10:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 19:10:01 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-11 19:10:01 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-11 19:10:01 --> Form Validation Class Initialized
INFO - 2018-04-11 19:10:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-11 19:10:01 --> Pixel_Model class loaded
INFO - 2018-04-11 19:10:01 --> Database Driver Class Initialized
INFO - 2018-04-11 19:10:01 --> Model "RegistrationModel" initialized
INFO - 2018-04-11 19:10:01 --> Helper loaded: string_helper
INFO - 2018-04-11 19:10:01 --> Language file loaded: language/en/notifications_lang.php
INFO - 2018-04-11 19:10:02 --> File loaded: E:\www\yacopoo\application\views\emails/_buttons.php
INFO - 2018-04-11 19:10:02 --> File loaded: E:\www\yacopoo\application\views\emails/header.php
INFO - 2018-04-11 19:10:02 --> File loaded: E:\www\yacopoo\application\views\emails/footer.php
INFO - 2018-04-11 19:10:02 --> File loaded: E:\www\yacopoo\application\views\emails/generic.php
INFO - 2018-04-11 19:10:02 --> Email Class Initialized
ERROR - 2018-04-11 19:10:03 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() E:\www\yacopoo\system\libraries\Email.php 1888
INFO - 2018-04-11 19:10:03 --> Language file loaded: language/english/email_lang.php
INFO - 2018-04-11 19:10:03 --> Config Class Initialized
INFO - 2018-04-11 19:10:03 --> Hooks Class Initialized
DEBUG - 2018-04-11 19:10:03 --> UTF-8 Support Enabled
INFO - 2018-04-11 19:10:03 --> Utf8 Class Initialized
INFO - 2018-04-11 19:10:03 --> URI Class Initialized
DEBUG - 2018-04-11 19:10:03 --> No URI present. Default controller set.
INFO - 2018-04-11 19:10:03 --> Router Class Initialized
INFO - 2018-04-11 19:10:03 --> Output Class Initialized
INFO - 2018-04-11 19:10:03 --> Security Class Initialized
DEBUG - 2018-04-11 19:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 19:10:03 --> CSRF cookie sent
INFO - 2018-04-11 19:10:03 --> Input Class Initialized
INFO - 2018-04-11 19:10:03 --> Language Class Initialized
INFO - 2018-04-11 19:10:03 --> Loader Class Initialized
INFO - 2018-04-11 19:10:03 --> Helper loaded: url_helper
INFO - 2018-04-11 19:10:03 --> Helper loaded: form_helper
INFO - 2018-04-11 19:10:03 --> Helper loaded: language_helper
DEBUG - 2018-04-11 19:10:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 19:10:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 19:10:03 --> User Agent Class Initialized
INFO - 2018-04-11 19:10:03 --> Controller Class Initialized
INFO - 2018-04-11 19:10:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 19:10:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 19:10:03 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 19:10:03 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-11 19:10:03 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 19:10:03 --> Final output sent to browser
DEBUG - 2018-04-11 19:10:03 --> Total execution time: 0.3968
INFO - 2018-04-11 19:10:05 --> Config Class Initialized
INFO - 2018-04-11 19:10:05 --> Hooks Class Initialized
DEBUG - 2018-04-11 19:10:05 --> UTF-8 Support Enabled
INFO - 2018-04-11 19:10:05 --> Utf8 Class Initialized
INFO - 2018-04-11 19:10:05 --> URI Class Initialized
INFO - 2018-04-11 19:10:05 --> Router Class Initialized
INFO - 2018-04-11 19:10:05 --> Output Class Initialized
INFO - 2018-04-11 19:10:05 --> Security Class Initialized
DEBUG - 2018-04-11 19:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 19:10:05 --> CSRF cookie sent
INFO - 2018-04-11 19:10:05 --> Input Class Initialized
INFO - 2018-04-11 19:10:05 --> Language Class Initialized
ERROR - 2018-04-11 19:10:05 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-11 19:17:21 --> Config Class Initialized
INFO - 2018-04-11 19:17:21 --> Hooks Class Initialized
DEBUG - 2018-04-11 19:17:21 --> UTF-8 Support Enabled
INFO - 2018-04-11 19:17:21 --> Utf8 Class Initialized
INFO - 2018-04-11 19:17:21 --> URI Class Initialized
INFO - 2018-04-11 19:17:21 --> Router Class Initialized
INFO - 2018-04-11 19:17:21 --> Output Class Initialized
INFO - 2018-04-11 19:17:21 --> Security Class Initialized
DEBUG - 2018-04-11 19:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 19:17:21 --> CSRF cookie sent
INFO - 2018-04-11 19:17:21 --> Input Class Initialized
INFO - 2018-04-11 19:17:21 --> Language Class Initialized
INFO - 2018-04-11 19:17:21 --> Loader Class Initialized
INFO - 2018-04-11 19:17:21 --> Helper loaded: url_helper
INFO - 2018-04-11 19:17:21 --> Helper loaded: form_helper
INFO - 2018-04-11 19:17:21 --> Helper loaded: language_helper
DEBUG - 2018-04-11 19:17:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 19:17:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 19:17:21 --> User Agent Class Initialized
INFO - 2018-04-11 19:17:21 --> Controller Class Initialized
INFO - 2018-04-11 19:17:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 19:17:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 19:17:22 --> CSRF cookie sent
INFO - 2018-04-11 19:17:22 --> Config Class Initialized
INFO - 2018-04-11 19:17:22 --> Hooks Class Initialized
DEBUG - 2018-04-11 19:17:22 --> UTF-8 Support Enabled
INFO - 2018-04-11 19:17:22 --> Utf8 Class Initialized
INFO - 2018-04-11 19:17:22 --> URI Class Initialized
DEBUG - 2018-04-11 19:17:22 --> No URI present. Default controller set.
INFO - 2018-04-11 19:17:22 --> Router Class Initialized
INFO - 2018-04-11 19:17:22 --> Output Class Initialized
INFO - 2018-04-11 19:17:22 --> Security Class Initialized
DEBUG - 2018-04-11 19:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 19:17:22 --> CSRF cookie sent
INFO - 2018-04-11 19:17:22 --> Input Class Initialized
INFO - 2018-04-11 19:17:22 --> Language Class Initialized
INFO - 2018-04-11 19:17:22 --> Loader Class Initialized
INFO - 2018-04-11 19:17:22 --> Helper loaded: url_helper
INFO - 2018-04-11 19:17:22 --> Helper loaded: form_helper
INFO - 2018-04-11 19:17:22 --> Helper loaded: language_helper
DEBUG - 2018-04-11 19:17:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 19:17:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 19:17:22 --> User Agent Class Initialized
INFO - 2018-04-11 19:17:22 --> Controller Class Initialized
INFO - 2018-04-11 19:17:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 19:17:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 19:17:22 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 19:17:22 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-11 19:17:22 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 19:17:22 --> Final output sent to browser
DEBUG - 2018-04-11 19:17:22 --> Total execution time: 0.3113
INFO - 2018-04-11 19:17:23 --> Config Class Initialized
INFO - 2018-04-11 19:17:23 --> Hooks Class Initialized
DEBUG - 2018-04-11 19:17:23 --> UTF-8 Support Enabled
INFO - 2018-04-11 19:17:23 --> Utf8 Class Initialized
INFO - 2018-04-11 19:17:23 --> URI Class Initialized
INFO - 2018-04-11 19:17:23 --> Router Class Initialized
INFO - 2018-04-11 19:17:23 --> Output Class Initialized
INFO - 2018-04-11 19:17:23 --> Security Class Initialized
DEBUG - 2018-04-11 19:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 19:17:23 --> CSRF cookie sent
INFO - 2018-04-11 19:17:23 --> Input Class Initialized
INFO - 2018-04-11 19:17:23 --> Language Class Initialized
ERROR - 2018-04-11 19:17:23 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-11 19:17:24 --> Config Class Initialized
INFO - 2018-04-11 19:17:24 --> Hooks Class Initialized
DEBUG - 2018-04-11 19:17:24 --> UTF-8 Support Enabled
INFO - 2018-04-11 19:17:24 --> Utf8 Class Initialized
INFO - 2018-04-11 19:17:24 --> URI Class Initialized
INFO - 2018-04-11 19:17:24 --> Router Class Initialized
INFO - 2018-04-11 19:17:24 --> Output Class Initialized
INFO - 2018-04-11 19:17:24 --> Security Class Initialized
DEBUG - 2018-04-11 19:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 19:17:24 --> CSRF cookie sent
INFO - 2018-04-11 19:17:24 --> Input Class Initialized
INFO - 2018-04-11 19:17:24 --> Language Class Initialized
INFO - 2018-04-11 19:17:24 --> Loader Class Initialized
INFO - 2018-04-11 19:17:24 --> Helper loaded: url_helper
INFO - 2018-04-11 19:17:24 --> Helper loaded: form_helper
INFO - 2018-04-11 19:17:24 --> Helper loaded: language_helper
DEBUG - 2018-04-11 19:17:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 19:17:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 19:17:24 --> User Agent Class Initialized
INFO - 2018-04-11 19:17:24 --> Controller Class Initialized
INFO - 2018-04-11 19:17:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 19:17:24 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-11 19:17:24 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-11 19:17:24 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 19:17:24 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-11 19:17:24 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-11 19:17:24 --> Could not find the language line "req_email"
INFO - 2018-04-11 19:17:24 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-04-11 19:17:24 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 19:17:24 --> Final output sent to browser
DEBUG - 2018-04-11 19:17:24 --> Total execution time: 0.4951
INFO - 2018-04-11 19:18:08 --> Config Class Initialized
INFO - 2018-04-11 19:18:08 --> Hooks Class Initialized
DEBUG - 2018-04-11 19:18:08 --> UTF-8 Support Enabled
INFO - 2018-04-11 19:18:08 --> Utf8 Class Initialized
INFO - 2018-04-11 19:18:08 --> URI Class Initialized
INFO - 2018-04-11 19:18:08 --> Router Class Initialized
INFO - 2018-04-11 19:18:08 --> Output Class Initialized
INFO - 2018-04-11 19:18:08 --> Security Class Initialized
DEBUG - 2018-04-11 19:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 19:18:08 --> CSRF cookie sent
INFO - 2018-04-11 19:18:08 --> CSRF token verified
INFO - 2018-04-11 19:18:08 --> Input Class Initialized
INFO - 2018-04-11 19:18:08 --> Language Class Initialized
INFO - 2018-04-11 19:18:08 --> Loader Class Initialized
INFO - 2018-04-11 19:18:08 --> Helper loaded: url_helper
INFO - 2018-04-11 19:18:08 --> Helper loaded: form_helper
INFO - 2018-04-11 19:18:08 --> Helper loaded: language_helper
DEBUG - 2018-04-11 19:18:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 19:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 19:18:08 --> User Agent Class Initialized
INFO - 2018-04-11 19:18:08 --> Controller Class Initialized
INFO - 2018-04-11 19:18:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 19:18:08 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-11 19:18:08 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-11 19:18:09 --> Form Validation Class Initialized
INFO - 2018-04-11 19:18:09 --> Pixel_Model class loaded
INFO - 2018-04-11 19:18:09 --> Database Driver Class Initialized
INFO - 2018-04-11 19:18:12 --> Model "AuthenticationModel" initialized
INFO - 2018-04-11 19:18:12 --> Config Class Initialized
INFO - 2018-04-11 19:18:12 --> Hooks Class Initialized
DEBUG - 2018-04-11 19:18:12 --> UTF-8 Support Enabled
INFO - 2018-04-11 19:18:12 --> Utf8 Class Initialized
INFO - 2018-04-11 19:18:12 --> URI Class Initialized
INFO - 2018-04-11 19:18:12 --> Router Class Initialized
INFO - 2018-04-11 19:18:12 --> Output Class Initialized
INFO - 2018-04-11 19:18:12 --> Security Class Initialized
DEBUG - 2018-04-11 19:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 19:18:12 --> CSRF cookie sent
INFO - 2018-04-11 19:18:12 --> Input Class Initialized
INFO - 2018-04-11 19:18:12 --> Language Class Initialized
INFO - 2018-04-11 19:18:12 --> Loader Class Initialized
INFO - 2018-04-11 19:18:12 --> Helper loaded: url_helper
INFO - 2018-04-11 19:18:12 --> Helper loaded: form_helper
INFO - 2018-04-11 19:18:12 --> Helper loaded: language_helper
DEBUG - 2018-04-11 19:18:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 19:18:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 19:18:12 --> User Agent Class Initialized
INFO - 2018-04-11 19:18:12 --> Controller Class Initialized
INFO - 2018-04-11 19:18:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 19:18:12 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-11 19:18:12 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-11 19:18:12 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 19:18:12 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-11 19:18:12 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-11 19:18:12 --> File loaded: E:\www\yacopoo\application\views\shared/_soft_error.php
ERROR - 2018-04-11 19:18:12 --> Could not find the language line "req_email"
INFO - 2018-04-11 19:18:12 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-04-11 19:18:12 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 19:18:12 --> Final output sent to browser
DEBUG - 2018-04-11 19:18:12 --> Total execution time: 0.3664
INFO - 2018-04-11 19:18:40 --> Config Class Initialized
INFO - 2018-04-11 19:18:40 --> Hooks Class Initialized
DEBUG - 2018-04-11 19:18:40 --> UTF-8 Support Enabled
INFO - 2018-04-11 19:18:40 --> Utf8 Class Initialized
INFO - 2018-04-11 19:18:40 --> URI Class Initialized
INFO - 2018-04-11 19:18:40 --> Router Class Initialized
INFO - 2018-04-11 19:18:40 --> Output Class Initialized
INFO - 2018-04-11 19:18:40 --> Security Class Initialized
DEBUG - 2018-04-11 19:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 19:18:40 --> CSRF cookie sent
INFO - 2018-04-11 19:18:40 --> Input Class Initialized
INFO - 2018-04-11 19:18:40 --> Language Class Initialized
INFO - 2018-04-11 19:18:40 --> Loader Class Initialized
INFO - 2018-04-11 19:18:40 --> Helper loaded: url_helper
INFO - 2018-04-11 19:18:40 --> Helper loaded: form_helper
INFO - 2018-04-11 19:18:40 --> Helper loaded: language_helper
DEBUG - 2018-04-11 19:18:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 19:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 19:18:40 --> User Agent Class Initialized
INFO - 2018-04-11 19:18:40 --> Controller Class Initialized
INFO - 2018-04-11 19:18:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 19:18:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 19:18:40 --> Pixel_Model class loaded
INFO - 2018-04-11 19:18:40 --> Database Driver Class Initialized
INFO - 2018-04-11 19:18:40 --> Model "RegistrationModel" initialized
INFO - 2018-04-11 19:18:40 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 19:18:40 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-11 19:18:40 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-11 19:18:40 --> File loaded: E:\www\yacopoo\application\views\register/activation_success.php
INFO - 2018-04-11 19:18:40 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 19:18:40 --> Final output sent to browser
DEBUG - 2018-04-11 19:18:40 --> Total execution time: 0.5221
INFO - 2018-04-11 19:18:40 --> Config Class Initialized
INFO - 2018-04-11 19:18:40 --> Config Class Initialized
INFO - 2018-04-11 19:18:40 --> Config Class Initialized
INFO - 2018-04-11 19:18:40 --> Hooks Class Initialized
INFO - 2018-04-11 19:18:40 --> Hooks Class Initialized
INFO - 2018-04-11 19:18:40 --> Hooks Class Initialized
DEBUG - 2018-04-11 19:18:40 --> UTF-8 Support Enabled
DEBUG - 2018-04-11 19:18:40 --> UTF-8 Support Enabled
DEBUG - 2018-04-11 19:18:40 --> UTF-8 Support Enabled
INFO - 2018-04-11 19:18:40 --> Utf8 Class Initialized
INFO - 2018-04-11 19:18:40 --> Utf8 Class Initialized
INFO - 2018-04-11 19:18:40 --> Utf8 Class Initialized
INFO - 2018-04-11 19:18:40 --> URI Class Initialized
INFO - 2018-04-11 19:18:40 --> URI Class Initialized
INFO - 2018-04-11 19:18:40 --> URI Class Initialized
INFO - 2018-04-11 19:18:40 --> Router Class Initialized
INFO - 2018-04-11 19:18:40 --> Router Class Initialized
INFO - 2018-04-11 19:18:40 --> Router Class Initialized
INFO - 2018-04-11 19:18:40 --> Output Class Initialized
INFO - 2018-04-11 19:18:40 --> Output Class Initialized
INFO - 2018-04-11 19:18:40 --> Output Class Initialized
INFO - 2018-04-11 19:18:40 --> Security Class Initialized
INFO - 2018-04-11 19:18:40 --> Security Class Initialized
INFO - 2018-04-11 19:18:40 --> Security Class Initialized
DEBUG - 2018-04-11 19:18:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-11 19:18:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-11 19:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 19:18:40 --> CSRF cookie sent
INFO - 2018-04-11 19:18:40 --> CSRF cookie sent
INFO - 2018-04-11 19:18:40 --> CSRF cookie sent
INFO - 2018-04-11 19:18:40 --> Input Class Initialized
INFO - 2018-04-11 19:18:40 --> Input Class Initialized
INFO - 2018-04-11 19:18:40 --> Input Class Initialized
INFO - 2018-04-11 19:18:40 --> Language Class Initialized
INFO - 2018-04-11 19:18:40 --> Language Class Initialized
INFO - 2018-04-11 19:18:40 --> Language Class Initialized
ERROR - 2018-04-11 19:18:41 --> 404 Page Not Found: Activate-account/assets
ERROR - 2018-04-11 19:18:41 --> 404 Page Not Found: Activate-account/assets
ERROR - 2018-04-11 19:18:41 --> 404 Page Not Found: Activate-account/assets
INFO - 2018-04-11 19:18:43 --> Config Class Initialized
INFO - 2018-04-11 19:18:43 --> Hooks Class Initialized
DEBUG - 2018-04-11 19:18:43 --> UTF-8 Support Enabled
INFO - 2018-04-11 19:18:43 --> Utf8 Class Initialized
INFO - 2018-04-11 19:18:43 --> URI Class Initialized
INFO - 2018-04-11 19:18:43 --> Router Class Initialized
INFO - 2018-04-11 19:18:43 --> Output Class Initialized
INFO - 2018-04-11 19:18:43 --> Security Class Initialized
DEBUG - 2018-04-11 19:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 19:18:43 --> CSRF cookie sent
INFO - 2018-04-11 19:18:43 --> Input Class Initialized
INFO - 2018-04-11 19:18:43 --> Language Class Initialized
INFO - 2018-04-11 19:18:44 --> Loader Class Initialized
INFO - 2018-04-11 19:18:44 --> Helper loaded: url_helper
INFO - 2018-04-11 19:18:44 --> Helper loaded: form_helper
INFO - 2018-04-11 19:18:44 --> Helper loaded: language_helper
DEBUG - 2018-04-11 19:18:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 19:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 19:18:44 --> User Agent Class Initialized
INFO - 2018-04-11 19:18:44 --> Controller Class Initialized
INFO - 2018-04-11 19:18:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 19:18:44 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-11 19:18:44 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-11 19:18:44 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 19:18:44 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-11 19:18:44 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-11 19:18:44 --> Could not find the language line "req_email"
INFO - 2018-04-11 19:18:44 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-04-11 19:18:44 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 19:18:44 --> Final output sent to browser
DEBUG - 2018-04-11 19:18:44 --> Total execution time: 0.4652
INFO - 2018-04-11 19:18:55 --> Config Class Initialized
INFO - 2018-04-11 19:18:55 --> Hooks Class Initialized
DEBUG - 2018-04-11 19:18:55 --> UTF-8 Support Enabled
INFO - 2018-04-11 19:18:55 --> Utf8 Class Initialized
INFO - 2018-04-11 19:18:55 --> URI Class Initialized
INFO - 2018-04-11 19:18:55 --> Router Class Initialized
INFO - 2018-04-11 19:18:55 --> Output Class Initialized
INFO - 2018-04-11 19:18:55 --> Security Class Initialized
DEBUG - 2018-04-11 19:18:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 19:18:55 --> CSRF cookie sent
INFO - 2018-04-11 19:18:55 --> CSRF token verified
INFO - 2018-04-11 19:18:55 --> Input Class Initialized
INFO - 2018-04-11 19:18:55 --> Language Class Initialized
INFO - 2018-04-11 19:18:55 --> Loader Class Initialized
INFO - 2018-04-11 19:18:55 --> Helper loaded: url_helper
INFO - 2018-04-11 19:18:55 --> Helper loaded: form_helper
INFO - 2018-04-11 19:18:55 --> Helper loaded: language_helper
DEBUG - 2018-04-11 19:18:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 19:18:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 19:18:55 --> User Agent Class Initialized
INFO - 2018-04-11 19:18:55 --> Controller Class Initialized
INFO - 2018-04-11 19:18:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 19:18:56 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-11 19:18:56 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-11 19:18:56 --> Config Class Initialized
INFO - 2018-04-11 19:18:56 --> Hooks Class Initialized
DEBUG - 2018-04-11 19:18:56 --> UTF-8 Support Enabled
INFO - 2018-04-11 19:18:56 --> Utf8 Class Initialized
INFO - 2018-04-11 19:18:56 --> URI Class Initialized
INFO - 2018-04-11 19:18:56 --> Router Class Initialized
INFO - 2018-04-11 19:18:56 --> Output Class Initialized
INFO - 2018-04-11 19:18:56 --> Security Class Initialized
DEBUG - 2018-04-11 19:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 19:18:56 --> CSRF cookie sent
INFO - 2018-04-11 19:18:56 --> Input Class Initialized
INFO - 2018-04-11 19:18:56 --> Language Class Initialized
INFO - 2018-04-11 19:18:56 --> Loader Class Initialized
INFO - 2018-04-11 19:18:56 --> Helper loaded: url_helper
INFO - 2018-04-11 19:18:56 --> Helper loaded: form_helper
INFO - 2018-04-11 19:18:56 --> Helper loaded: language_helper
DEBUG - 2018-04-11 19:18:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 19:18:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 19:18:56 --> User Agent Class Initialized
INFO - 2018-04-11 19:18:56 --> Controller Class Initialized
INFO - 2018-04-11 19:18:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 19:18:56 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-11 19:18:56 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-11 19:18:56 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 19:18:56 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-11 19:18:56 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-11 19:18:56 --> File loaded: E:\www\yacopoo\application\views\shared/_soft_error.php
ERROR - 2018-04-11 19:18:56 --> Could not find the language line "req_email"
INFO - 2018-04-11 19:18:56 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-04-11 19:18:56 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 19:18:56 --> Final output sent to browser
DEBUG - 2018-04-11 19:18:56 --> Total execution time: 0.4083
INFO - 2018-04-11 19:19:13 --> Config Class Initialized
INFO - 2018-04-11 19:19:13 --> Hooks Class Initialized
DEBUG - 2018-04-11 19:19:13 --> UTF-8 Support Enabled
INFO - 2018-04-11 19:19:13 --> Utf8 Class Initialized
INFO - 2018-04-11 19:19:13 --> URI Class Initialized
INFO - 2018-04-11 19:19:13 --> Router Class Initialized
INFO - 2018-04-11 19:19:13 --> Output Class Initialized
INFO - 2018-04-11 19:19:13 --> Security Class Initialized
DEBUG - 2018-04-11 19:19:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 19:19:13 --> CSRF cookie sent
INFO - 2018-04-11 19:19:13 --> CSRF token verified
INFO - 2018-04-11 19:19:13 --> Input Class Initialized
INFO - 2018-04-11 19:19:13 --> Language Class Initialized
INFO - 2018-04-11 19:19:13 --> Loader Class Initialized
INFO - 2018-04-11 19:19:13 --> Helper loaded: url_helper
INFO - 2018-04-11 19:19:13 --> Helper loaded: form_helper
INFO - 2018-04-11 19:19:13 --> Helper loaded: language_helper
DEBUG - 2018-04-11 19:19:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 19:19:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 19:19:13 --> User Agent Class Initialized
INFO - 2018-04-11 19:19:13 --> Controller Class Initialized
INFO - 2018-04-11 19:19:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 19:19:13 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-11 19:19:13 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-11 19:19:13 --> Form Validation Class Initialized
INFO - 2018-04-11 19:19:13 --> Pixel_Model class loaded
INFO - 2018-04-11 19:19:13 --> Database Driver Class Initialized
INFO - 2018-04-11 19:19:16 --> Model "AuthenticationModel" initialized
INFO - 2018-04-11 19:19:17 --> Config Class Initialized
INFO - 2018-04-11 19:19:17 --> Hooks Class Initialized
DEBUG - 2018-04-11 19:19:17 --> UTF-8 Support Enabled
INFO - 2018-04-11 19:19:17 --> Utf8 Class Initialized
INFO - 2018-04-11 19:19:17 --> URI Class Initialized
DEBUG - 2018-04-11 19:19:17 --> No URI present. Default controller set.
INFO - 2018-04-11 19:19:17 --> Router Class Initialized
INFO - 2018-04-11 19:19:17 --> Output Class Initialized
INFO - 2018-04-11 19:19:17 --> Security Class Initialized
DEBUG - 2018-04-11 19:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 19:19:17 --> CSRF cookie sent
INFO - 2018-04-11 19:19:17 --> Input Class Initialized
INFO - 2018-04-11 19:19:17 --> Language Class Initialized
INFO - 2018-04-11 19:19:17 --> Loader Class Initialized
INFO - 2018-04-11 19:19:17 --> Helper loaded: url_helper
INFO - 2018-04-11 19:19:17 --> Helper loaded: form_helper
INFO - 2018-04-11 19:19:17 --> Helper loaded: language_helper
DEBUG - 2018-04-11 19:19:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 19:19:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 19:19:17 --> User Agent Class Initialized
INFO - 2018-04-11 19:19:17 --> Controller Class Initialized
INFO - 2018-04-11 19:19:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 19:19:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 19:19:17 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 19:19:17 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-11 19:19:17 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 19:19:17 --> Final output sent to browser
DEBUG - 2018-04-11 19:19:17 --> Total execution time: 0.3221
INFO - 2018-04-11 19:19:18 --> Config Class Initialized
INFO - 2018-04-11 19:19:18 --> Hooks Class Initialized
DEBUG - 2018-04-11 19:19:18 --> UTF-8 Support Enabled
INFO - 2018-04-11 19:19:18 --> Utf8 Class Initialized
INFO - 2018-04-11 19:19:18 --> URI Class Initialized
INFO - 2018-04-11 19:19:18 --> Router Class Initialized
INFO - 2018-04-11 19:19:19 --> Output Class Initialized
INFO - 2018-04-11 19:19:19 --> Security Class Initialized
DEBUG - 2018-04-11 19:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 19:19:19 --> CSRF cookie sent
INFO - 2018-04-11 19:19:19 --> Input Class Initialized
INFO - 2018-04-11 19:19:19 --> Language Class Initialized
ERROR - 2018-04-11 19:19:19 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-11 20:38:53 --> Config Class Initialized
INFO - 2018-04-11 20:38:53 --> Hooks Class Initialized
DEBUG - 2018-04-11 20:38:53 --> UTF-8 Support Enabled
INFO - 2018-04-11 20:38:53 --> Utf8 Class Initialized
INFO - 2018-04-11 20:38:53 --> URI Class Initialized
INFO - 2018-04-11 20:38:53 --> Router Class Initialized
INFO - 2018-04-11 20:38:53 --> Output Class Initialized
INFO - 2018-04-11 20:38:54 --> Security Class Initialized
DEBUG - 2018-04-11 20:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 20:38:54 --> CSRF cookie sent
INFO - 2018-04-11 20:38:54 --> Input Class Initialized
INFO - 2018-04-11 20:38:54 --> Language Class Initialized
INFO - 2018-04-11 20:38:54 --> Loader Class Initialized
INFO - 2018-04-11 20:38:54 --> Helper loaded: url_helper
INFO - 2018-04-11 20:38:54 --> Helper loaded: form_helper
INFO - 2018-04-11 20:38:54 --> Helper loaded: language_helper
DEBUG - 2018-04-11 20:38:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 20:38:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 20:38:54 --> User Agent Class Initialized
INFO - 2018-04-11 20:38:54 --> Controller Class Initialized
INFO - 2018-04-11 20:38:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 20:38:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 20:38:54 --> CSRF cookie sent
INFO - 2018-04-11 20:38:54 --> Config Class Initialized
INFO - 2018-04-11 20:38:54 --> Hooks Class Initialized
DEBUG - 2018-04-11 20:38:54 --> UTF-8 Support Enabled
INFO - 2018-04-11 20:38:54 --> Utf8 Class Initialized
INFO - 2018-04-11 20:38:54 --> URI Class Initialized
DEBUG - 2018-04-11 20:38:54 --> No URI present. Default controller set.
INFO - 2018-04-11 20:38:54 --> Router Class Initialized
INFO - 2018-04-11 20:38:54 --> Output Class Initialized
INFO - 2018-04-11 20:38:54 --> Security Class Initialized
DEBUG - 2018-04-11 20:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 20:38:54 --> CSRF cookie sent
INFO - 2018-04-11 20:38:54 --> Input Class Initialized
INFO - 2018-04-11 20:38:54 --> Language Class Initialized
INFO - 2018-04-11 20:38:54 --> Loader Class Initialized
INFO - 2018-04-11 20:38:54 --> Helper loaded: url_helper
INFO - 2018-04-11 20:38:54 --> Helper loaded: form_helper
INFO - 2018-04-11 20:38:54 --> Helper loaded: language_helper
DEBUG - 2018-04-11 20:38:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 20:38:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 20:38:54 --> User Agent Class Initialized
INFO - 2018-04-11 20:38:54 --> Controller Class Initialized
INFO - 2018-04-11 20:38:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 20:38:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 20:38:54 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 20:38:54 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-11 20:38:54 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 20:38:54 --> Final output sent to browser
DEBUG - 2018-04-11 20:38:54 --> Total execution time: 0.3237
INFO - 2018-04-11 20:38:56 --> Config Class Initialized
INFO - 2018-04-11 20:38:56 --> Hooks Class Initialized
DEBUG - 2018-04-11 20:38:56 --> UTF-8 Support Enabled
INFO - 2018-04-11 20:38:56 --> Utf8 Class Initialized
INFO - 2018-04-11 20:38:56 --> URI Class Initialized
INFO - 2018-04-11 20:38:56 --> Router Class Initialized
INFO - 2018-04-11 20:38:56 --> Output Class Initialized
INFO - 2018-04-11 20:38:56 --> Security Class Initialized
DEBUG - 2018-04-11 20:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 20:38:56 --> CSRF cookie sent
INFO - 2018-04-11 20:38:56 --> Input Class Initialized
INFO - 2018-04-11 20:38:56 --> Language Class Initialized
ERROR - 2018-04-11 20:38:56 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-11 20:38:59 --> Config Class Initialized
INFO - 2018-04-11 20:38:59 --> Hooks Class Initialized
DEBUG - 2018-04-11 20:38:59 --> UTF-8 Support Enabled
INFO - 2018-04-11 20:38:59 --> Utf8 Class Initialized
INFO - 2018-04-11 20:38:59 --> URI Class Initialized
INFO - 2018-04-11 20:38:59 --> Router Class Initialized
INFO - 2018-04-11 20:38:59 --> Output Class Initialized
INFO - 2018-04-11 20:38:59 --> Security Class Initialized
DEBUG - 2018-04-11 20:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 20:38:59 --> CSRF cookie sent
INFO - 2018-04-11 20:38:59 --> Input Class Initialized
INFO - 2018-04-11 20:38:59 --> Language Class Initialized
ERROR - 2018-04-11 20:38:59 --> 404 Page Not Found: Assets/css
INFO - 2018-04-11 20:39:55 --> Config Class Initialized
INFO - 2018-04-11 20:39:55 --> Hooks Class Initialized
DEBUG - 2018-04-11 20:39:55 --> UTF-8 Support Enabled
INFO - 2018-04-11 20:39:55 --> Utf8 Class Initialized
INFO - 2018-04-11 20:39:55 --> URI Class Initialized
DEBUG - 2018-04-11 20:39:55 --> No URI present. Default controller set.
INFO - 2018-04-11 20:39:55 --> Router Class Initialized
INFO - 2018-04-11 20:39:55 --> Output Class Initialized
INFO - 2018-04-11 20:39:55 --> Security Class Initialized
DEBUG - 2018-04-11 20:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 20:39:55 --> CSRF cookie sent
INFO - 2018-04-11 20:39:55 --> Input Class Initialized
INFO - 2018-04-11 20:39:55 --> Language Class Initialized
INFO - 2018-04-11 20:39:55 --> Loader Class Initialized
INFO - 2018-04-11 20:39:55 --> Helper loaded: url_helper
INFO - 2018-04-11 20:39:55 --> Helper loaded: form_helper
INFO - 2018-04-11 20:39:55 --> Helper loaded: language_helper
DEBUG - 2018-04-11 20:39:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 20:39:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 20:39:55 --> User Agent Class Initialized
INFO - 2018-04-11 20:39:55 --> Controller Class Initialized
INFO - 2018-04-11 20:39:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 20:39:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 20:39:56 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 20:39:56 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-11 20:39:56 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 20:39:56 --> Final output sent to browser
DEBUG - 2018-04-11 20:39:56 --> Total execution time: 0.3431
INFO - 2018-04-11 20:39:56 --> Config Class Initialized
INFO - 2018-04-11 20:39:56 --> Hooks Class Initialized
DEBUG - 2018-04-11 20:39:56 --> UTF-8 Support Enabled
INFO - 2018-04-11 20:39:56 --> Utf8 Class Initialized
INFO - 2018-04-11 20:39:56 --> URI Class Initialized
INFO - 2018-04-11 20:39:56 --> Router Class Initialized
INFO - 2018-04-11 20:39:56 --> Output Class Initialized
INFO - 2018-04-11 20:39:56 --> Security Class Initialized
DEBUG - 2018-04-11 20:39:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 20:39:56 --> CSRF cookie sent
INFO - 2018-04-11 20:39:56 --> Input Class Initialized
INFO - 2018-04-11 20:39:56 --> Language Class Initialized
ERROR - 2018-04-11 20:39:56 --> 404 Page Not Found: Assets/css
INFO - 2018-04-11 20:39:58 --> Config Class Initialized
INFO - 2018-04-11 20:39:58 --> Hooks Class Initialized
DEBUG - 2018-04-11 20:39:58 --> UTF-8 Support Enabled
INFO - 2018-04-11 20:39:58 --> Utf8 Class Initialized
INFO - 2018-04-11 20:39:58 --> URI Class Initialized
INFO - 2018-04-11 20:39:58 --> Router Class Initialized
INFO - 2018-04-11 20:39:58 --> Output Class Initialized
INFO - 2018-04-11 20:39:58 --> Security Class Initialized
DEBUG - 2018-04-11 20:39:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 20:39:58 --> CSRF cookie sent
INFO - 2018-04-11 20:39:58 --> Input Class Initialized
INFO - 2018-04-11 20:39:58 --> Language Class Initialized
ERROR - 2018-04-11 20:39:58 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-11 20:48:36 --> Config Class Initialized
INFO - 2018-04-11 20:48:36 --> Hooks Class Initialized
DEBUG - 2018-04-11 20:48:36 --> UTF-8 Support Enabled
INFO - 2018-04-11 20:48:36 --> Utf8 Class Initialized
INFO - 2018-04-11 20:48:36 --> URI Class Initialized
INFO - 2018-04-11 20:48:36 --> Router Class Initialized
INFO - 2018-04-11 20:48:36 --> Output Class Initialized
INFO - 2018-04-11 20:48:36 --> Security Class Initialized
DEBUG - 2018-04-11 20:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 20:48:36 --> CSRF cookie sent
INFO - 2018-04-11 20:48:36 --> Input Class Initialized
INFO - 2018-04-11 20:48:36 --> Language Class Initialized
INFO - 2018-04-11 20:48:36 --> Loader Class Initialized
INFO - 2018-04-11 20:48:36 --> Helper loaded: url_helper
INFO - 2018-04-11 20:48:36 --> Helper loaded: form_helper
INFO - 2018-04-11 20:48:36 --> Helper loaded: language_helper
DEBUG - 2018-04-11 20:48:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 20:48:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 20:48:36 --> User Agent Class Initialized
INFO - 2018-04-11 20:48:36 --> Controller Class Initialized
INFO - 2018-04-11 20:48:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 20:48:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 20:48:36 --> Pixel_Model class loaded
INFO - 2018-04-11 20:48:36 --> Database Driver Class Initialized
INFO - 2018-04-11 20:48:39 --> Model "RegistrationModel" initialized
DEBUG - 2018-04-11 20:48:39 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-11 20:48:39 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 20:48:39 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-11 20:48:39 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-11 20:48:39 --> Could not find the language line "req_email"
INFO - 2018-04-11 20:48:39 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-04-11 20:48:39 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 20:48:39 --> Final output sent to browser
DEBUG - 2018-04-11 20:48:39 --> Total execution time: 3.4520
INFO - 2018-04-11 20:48:39 --> Config Class Initialized
INFO - 2018-04-11 20:48:39 --> Hooks Class Initialized
DEBUG - 2018-04-11 20:48:40 --> UTF-8 Support Enabled
INFO - 2018-04-11 20:48:40 --> Utf8 Class Initialized
INFO - 2018-04-11 20:48:40 --> URI Class Initialized
INFO - 2018-04-11 20:48:40 --> Router Class Initialized
INFO - 2018-04-11 20:48:40 --> Output Class Initialized
INFO - 2018-04-11 20:48:40 --> Security Class Initialized
DEBUG - 2018-04-11 20:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 20:48:40 --> CSRF cookie sent
INFO - 2018-04-11 20:48:40 --> Input Class Initialized
INFO - 2018-04-11 20:48:40 --> Language Class Initialized
ERROR - 2018-04-11 20:48:40 --> 404 Page Not Found: Assets/css
INFO - 2018-04-11 20:48:46 --> Config Class Initialized
INFO - 2018-04-11 20:48:46 --> Hooks Class Initialized
DEBUG - 2018-04-11 20:48:46 --> UTF-8 Support Enabled
INFO - 2018-04-11 20:48:46 --> Utf8 Class Initialized
INFO - 2018-04-11 20:48:46 --> URI Class Initialized
INFO - 2018-04-11 20:48:46 --> Router Class Initialized
INFO - 2018-04-11 20:48:46 --> Output Class Initialized
INFO - 2018-04-11 20:48:46 --> Security Class Initialized
DEBUG - 2018-04-11 20:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 20:48:46 --> CSRF cookie sent
INFO - 2018-04-11 20:48:46 --> Input Class Initialized
INFO - 2018-04-11 20:48:46 --> Language Class Initialized
INFO - 2018-04-11 20:48:46 --> Loader Class Initialized
INFO - 2018-04-11 20:48:46 --> Helper loaded: url_helper
INFO - 2018-04-11 20:48:46 --> Helper loaded: form_helper
INFO - 2018-04-11 20:48:46 --> Helper loaded: language_helper
DEBUG - 2018-04-11 20:48:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 20:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 20:48:46 --> User Agent Class Initialized
INFO - 2018-04-11 20:48:46 --> Controller Class Initialized
INFO - 2018-04-11 20:48:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 20:48:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 20:48:46 --> Pixel_Model class loaded
INFO - 2018-04-11 20:48:46 --> Database Driver Class Initialized
INFO - 2018-04-11 20:48:46 --> Model "RegistrationModel" initialized
DEBUG - 2018-04-11 20:48:46 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-11 20:48:46 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 20:48:46 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-11 20:48:46 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-11 20:48:46 --> Could not find the language line "req_email"
INFO - 2018-04-11 20:48:46 --> File loaded: E:\www\yacopoo\application\views\register/signup_fa.php
INFO - 2018-04-11 20:48:46 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 20:48:46 --> Final output sent to browser
DEBUG - 2018-04-11 20:48:46 --> Total execution time: 0.4597
INFO - 2018-04-11 20:48:46 --> Config Class Initialized
INFO - 2018-04-11 20:48:46 --> Hooks Class Initialized
DEBUG - 2018-04-11 20:48:46 --> UTF-8 Support Enabled
INFO - 2018-04-11 20:48:47 --> Utf8 Class Initialized
INFO - 2018-04-11 20:48:47 --> URI Class Initialized
INFO - 2018-04-11 20:48:47 --> Router Class Initialized
INFO - 2018-04-11 20:48:47 --> Output Class Initialized
INFO - 2018-04-11 20:48:47 --> Security Class Initialized
DEBUG - 2018-04-11 20:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 20:48:47 --> CSRF cookie sent
INFO - 2018-04-11 20:48:47 --> Input Class Initialized
INFO - 2018-04-11 20:48:47 --> Language Class Initialized
ERROR - 2018-04-11 20:48:47 --> 404 Page Not Found: Assets/css
INFO - 2018-04-11 20:49:46 --> Config Class Initialized
INFO - 2018-04-11 20:49:46 --> Hooks Class Initialized
DEBUG - 2018-04-11 20:49:46 --> UTF-8 Support Enabled
INFO - 2018-04-11 20:49:46 --> Utf8 Class Initialized
INFO - 2018-04-11 20:49:46 --> URI Class Initialized
INFO - 2018-04-11 20:49:47 --> Router Class Initialized
INFO - 2018-04-11 20:49:47 --> Output Class Initialized
INFO - 2018-04-11 20:49:47 --> Security Class Initialized
DEBUG - 2018-04-11 20:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 20:49:47 --> CSRF cookie sent
INFO - 2018-04-11 20:49:47 --> CSRF token verified
INFO - 2018-04-11 20:49:47 --> Input Class Initialized
INFO - 2018-04-11 20:49:47 --> Language Class Initialized
INFO - 2018-04-11 20:49:47 --> Loader Class Initialized
INFO - 2018-04-11 20:49:47 --> Helper loaded: url_helper
INFO - 2018-04-11 20:49:47 --> Helper loaded: form_helper
INFO - 2018-04-11 20:49:47 --> Helper loaded: language_helper
DEBUG - 2018-04-11 20:49:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 20:49:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 20:49:47 --> User Agent Class Initialized
INFO - 2018-04-11 20:49:47 --> Controller Class Initialized
INFO - 2018-04-11 20:49:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 20:49:47 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-11 20:49:47 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-11 20:49:47 --> Form Validation Class Initialized
INFO - 2018-04-11 20:49:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-11 20:49:47 --> Pixel_Model class loaded
INFO - 2018-04-11 20:49:47 --> Database Driver Class Initialized
INFO - 2018-04-11 20:49:50 --> Model "RegistrationModel" initialized
INFO - 2018-04-11 20:49:50 --> Helper loaded: string_helper
INFO - 2018-04-11 20:49:50 --> Language file loaded: language/en/notifications_lang.php
INFO - 2018-04-11 20:49:50 --> File loaded: E:\www\yacopoo\application\views\emails/_buttons.php
INFO - 2018-04-11 20:49:50 --> File loaded: E:\www\yacopoo\application\views\emails/header.php
INFO - 2018-04-11 20:49:50 --> File loaded: E:\www\yacopoo\application\views\emails/footer.php
INFO - 2018-04-11 20:49:50 --> File loaded: E:\www\yacopoo\application\views\emails/generic.php
INFO - 2018-04-11 20:49:51 --> Email Class Initialized
ERROR - 2018-04-11 20:49:52 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() E:\www\yacopoo\system\libraries\Email.php 1888
INFO - 2018-04-11 20:49:52 --> Language file loaded: language/english/email_lang.php
INFO - 2018-04-11 20:49:52 --> Config Class Initialized
INFO - 2018-04-11 20:49:52 --> Hooks Class Initialized
DEBUG - 2018-04-11 20:49:52 --> UTF-8 Support Enabled
INFO - 2018-04-11 20:49:52 --> Utf8 Class Initialized
INFO - 2018-04-11 20:49:52 --> URI Class Initialized
DEBUG - 2018-04-11 20:49:52 --> No URI present. Default controller set.
INFO - 2018-04-11 20:49:52 --> Router Class Initialized
INFO - 2018-04-11 20:49:52 --> Output Class Initialized
INFO - 2018-04-11 20:49:52 --> Security Class Initialized
DEBUG - 2018-04-11 20:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 20:49:52 --> CSRF cookie sent
INFO - 2018-04-11 20:49:52 --> Input Class Initialized
INFO - 2018-04-11 20:49:52 --> Language Class Initialized
INFO - 2018-04-11 20:49:52 --> Loader Class Initialized
INFO - 2018-04-11 20:49:52 --> Helper loaded: url_helper
INFO - 2018-04-11 20:49:52 --> Helper loaded: form_helper
INFO - 2018-04-11 20:49:52 --> Helper loaded: language_helper
DEBUG - 2018-04-11 20:49:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 20:49:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 20:49:52 --> User Agent Class Initialized
INFO - 2018-04-11 20:49:52 --> Controller Class Initialized
INFO - 2018-04-11 20:49:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 20:49:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 20:49:52 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 20:49:52 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-11 20:49:52 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 20:49:52 --> Final output sent to browser
DEBUG - 2018-04-11 20:49:52 --> Total execution time: 0.3809
INFO - 2018-04-11 20:49:52 --> Config Class Initialized
INFO - 2018-04-11 20:49:52 --> Hooks Class Initialized
DEBUG - 2018-04-11 20:49:52 --> UTF-8 Support Enabled
INFO - 2018-04-11 20:49:52 --> Utf8 Class Initialized
INFO - 2018-04-11 20:49:52 --> URI Class Initialized
INFO - 2018-04-11 20:49:52 --> Router Class Initialized
INFO - 2018-04-11 20:49:53 --> Output Class Initialized
INFO - 2018-04-11 20:49:53 --> Security Class Initialized
DEBUG - 2018-04-11 20:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 20:49:53 --> CSRF cookie sent
INFO - 2018-04-11 20:49:53 --> Input Class Initialized
INFO - 2018-04-11 20:49:53 --> Language Class Initialized
ERROR - 2018-04-11 20:49:53 --> 404 Page Not Found: Assets/css
INFO - 2018-04-11 20:49:54 --> Config Class Initialized
INFO - 2018-04-11 20:49:54 --> Hooks Class Initialized
DEBUG - 2018-04-11 20:49:54 --> UTF-8 Support Enabled
INFO - 2018-04-11 20:49:54 --> Utf8 Class Initialized
INFO - 2018-04-11 20:49:54 --> URI Class Initialized
INFO - 2018-04-11 20:49:54 --> Router Class Initialized
INFO - 2018-04-11 20:49:54 --> Output Class Initialized
INFO - 2018-04-11 20:49:54 --> Security Class Initialized
DEBUG - 2018-04-11 20:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 20:49:54 --> CSRF cookie sent
INFO - 2018-04-11 20:49:54 --> Input Class Initialized
INFO - 2018-04-11 20:49:54 --> Language Class Initialized
ERROR - 2018-04-11 20:49:54 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-11 20:50:09 --> Config Class Initialized
INFO - 2018-04-11 20:50:09 --> Hooks Class Initialized
DEBUG - 2018-04-11 20:50:09 --> UTF-8 Support Enabled
INFO - 2018-04-11 20:50:09 --> Utf8 Class Initialized
INFO - 2018-04-11 20:50:09 --> URI Class Initialized
INFO - 2018-04-11 20:50:09 --> Router Class Initialized
INFO - 2018-04-11 20:50:09 --> Output Class Initialized
INFO - 2018-04-11 20:50:09 --> Security Class Initialized
DEBUG - 2018-04-11 20:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 20:50:09 --> CSRF cookie sent
INFO - 2018-04-11 20:50:09 --> Input Class Initialized
INFO - 2018-04-11 20:50:09 --> Language Class Initialized
INFO - 2018-04-11 20:50:09 --> Loader Class Initialized
INFO - 2018-04-11 20:50:09 --> Helper loaded: url_helper
INFO - 2018-04-11 20:50:09 --> Helper loaded: form_helper
INFO - 2018-04-11 20:50:09 --> Helper loaded: language_helper
DEBUG - 2018-04-11 20:50:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 20:50:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 20:50:09 --> User Agent Class Initialized
INFO - 2018-04-11 20:50:09 --> Controller Class Initialized
INFO - 2018-04-11 20:50:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 20:50:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 20:50:09 --> CSRF cookie sent
INFO - 2018-04-11 20:50:09 --> Config Class Initialized
INFO - 2018-04-11 20:50:09 --> Hooks Class Initialized
DEBUG - 2018-04-11 20:50:09 --> UTF-8 Support Enabled
INFO - 2018-04-11 20:50:09 --> Utf8 Class Initialized
INFO - 2018-04-11 20:50:09 --> URI Class Initialized
DEBUG - 2018-04-11 20:50:09 --> No URI present. Default controller set.
INFO - 2018-04-11 20:50:09 --> Router Class Initialized
INFO - 2018-04-11 20:50:09 --> Output Class Initialized
INFO - 2018-04-11 20:50:09 --> Security Class Initialized
DEBUG - 2018-04-11 20:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 20:50:09 --> CSRF cookie sent
INFO - 2018-04-11 20:50:09 --> Input Class Initialized
INFO - 2018-04-11 20:50:09 --> Language Class Initialized
INFO - 2018-04-11 20:50:09 --> Loader Class Initialized
INFO - 2018-04-11 20:50:09 --> Helper loaded: url_helper
INFO - 2018-04-11 20:50:09 --> Helper loaded: form_helper
INFO - 2018-04-11 20:50:09 --> Helper loaded: language_helper
DEBUG - 2018-04-11 20:50:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 20:50:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 20:50:09 --> User Agent Class Initialized
INFO - 2018-04-11 20:50:09 --> Controller Class Initialized
INFO - 2018-04-11 20:50:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 20:50:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 20:50:09 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 20:50:09 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-11 20:50:10 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 20:50:10 --> Final output sent to browser
DEBUG - 2018-04-11 20:50:10 --> Total execution time: 0.3330
INFO - 2018-04-11 20:50:10 --> Config Class Initialized
INFO - 2018-04-11 20:50:10 --> Hooks Class Initialized
DEBUG - 2018-04-11 20:50:10 --> UTF-8 Support Enabled
INFO - 2018-04-11 20:50:10 --> Utf8 Class Initialized
INFO - 2018-04-11 20:50:10 --> URI Class Initialized
INFO - 2018-04-11 20:50:10 --> Router Class Initialized
INFO - 2018-04-11 20:50:10 --> Output Class Initialized
INFO - 2018-04-11 20:50:10 --> Security Class Initialized
DEBUG - 2018-04-11 20:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 20:50:10 --> CSRF cookie sent
INFO - 2018-04-11 20:50:10 --> Input Class Initialized
INFO - 2018-04-11 20:50:10 --> Language Class Initialized
ERROR - 2018-04-11 20:50:10 --> 404 Page Not Found: Assets/css
INFO - 2018-04-11 20:50:12 --> Config Class Initialized
INFO - 2018-04-11 20:50:12 --> Hooks Class Initialized
DEBUG - 2018-04-11 20:50:12 --> UTF-8 Support Enabled
INFO - 2018-04-11 20:50:12 --> Utf8 Class Initialized
INFO - 2018-04-11 20:50:12 --> URI Class Initialized
INFO - 2018-04-11 20:50:12 --> Router Class Initialized
INFO - 2018-04-11 20:50:12 --> Output Class Initialized
INFO - 2018-04-11 20:50:12 --> Security Class Initialized
DEBUG - 2018-04-11 20:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 20:50:12 --> CSRF cookie sent
INFO - 2018-04-11 20:50:12 --> Input Class Initialized
INFO - 2018-04-11 20:50:12 --> Language Class Initialized
ERROR - 2018-04-11 20:50:12 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-11 20:58:27 --> Config Class Initialized
INFO - 2018-04-11 20:58:27 --> Hooks Class Initialized
DEBUG - 2018-04-11 20:58:27 --> UTF-8 Support Enabled
INFO - 2018-04-11 20:58:27 --> Utf8 Class Initialized
INFO - 2018-04-11 20:58:27 --> URI Class Initialized
INFO - 2018-04-11 20:58:27 --> Router Class Initialized
INFO - 2018-04-11 20:58:27 --> Output Class Initialized
INFO - 2018-04-11 20:58:27 --> Security Class Initialized
DEBUG - 2018-04-11 20:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 20:58:27 --> CSRF cookie sent
INFO - 2018-04-11 20:58:27 --> Input Class Initialized
INFO - 2018-04-11 20:58:27 --> Language Class Initialized
INFO - 2018-04-11 20:58:27 --> Loader Class Initialized
INFO - 2018-04-11 20:58:27 --> Helper loaded: url_helper
INFO - 2018-04-11 20:58:27 --> Helper loaded: form_helper
INFO - 2018-04-11 20:58:27 --> Helper loaded: language_helper
DEBUG - 2018-04-11 20:58:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 20:58:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 20:58:27 --> User Agent Class Initialized
INFO - 2018-04-11 20:58:27 --> Controller Class Initialized
INFO - 2018-04-11 20:58:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 20:58:27 --> Language file loaded: language/en/form_validation_lang.php
ERROR - 2018-04-11 20:58:27 --> Severity: Notice --> Undefined property: RegistrationController::$model E:\www\yacopoo\application\controllers\RegistrationController.php 26
ERROR - 2018-04-11 20:58:27 --> Severity: Error --> Call to a member function selectTypes() on null E:\www\yacopoo\application\controllers\RegistrationController.php 26
INFO - 2018-04-11 20:58:46 --> Config Class Initialized
INFO - 2018-04-11 20:58:46 --> Hooks Class Initialized
DEBUG - 2018-04-11 20:58:46 --> UTF-8 Support Enabled
INFO - 2018-04-11 20:58:46 --> Utf8 Class Initialized
INFO - 2018-04-11 20:58:46 --> URI Class Initialized
INFO - 2018-04-11 20:58:46 --> Router Class Initialized
INFO - 2018-04-11 20:58:46 --> Output Class Initialized
INFO - 2018-04-11 20:58:46 --> Security Class Initialized
DEBUG - 2018-04-11 20:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 20:58:46 --> CSRF cookie sent
INFO - 2018-04-11 20:58:46 --> Input Class Initialized
INFO - 2018-04-11 20:58:46 --> Language Class Initialized
INFO - 2018-04-11 20:58:46 --> Loader Class Initialized
INFO - 2018-04-11 20:58:46 --> Helper loaded: url_helper
INFO - 2018-04-11 20:58:46 --> Helper loaded: form_helper
INFO - 2018-04-11 20:58:46 --> Helper loaded: language_helper
DEBUG - 2018-04-11 20:58:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 20:58:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 20:58:46 --> User Agent Class Initialized
INFO - 2018-04-11 20:58:46 --> Controller Class Initialized
INFO - 2018-04-11 20:58:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 20:58:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 20:58:46 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 20:58:46 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-11 20:58:46 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-11 20:58:46 --> File loaded: E:\www\yacopoo\application\views\register/thanks.php
INFO - 2018-04-11 20:58:46 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 20:58:46 --> Final output sent to browser
DEBUG - 2018-04-11 20:58:46 --> Total execution time: 0.3774
INFO - 2018-04-11 20:58:47 --> Config Class Initialized
INFO - 2018-04-11 20:58:47 --> Hooks Class Initialized
DEBUG - 2018-04-11 20:58:47 --> UTF-8 Support Enabled
INFO - 2018-04-11 20:58:47 --> Utf8 Class Initialized
INFO - 2018-04-11 20:58:47 --> URI Class Initialized
INFO - 2018-04-11 20:58:47 --> Router Class Initialized
INFO - 2018-04-11 20:58:47 --> Output Class Initialized
INFO - 2018-04-11 20:58:47 --> Security Class Initialized
DEBUG - 2018-04-11 20:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 20:58:47 --> CSRF cookie sent
INFO - 2018-04-11 20:58:47 --> Input Class Initialized
INFO - 2018-04-11 20:58:47 --> Language Class Initialized
ERROR - 2018-04-11 20:58:47 --> 404 Page Not Found: Assets/css
INFO - 2018-04-11 21:02:12 --> Config Class Initialized
INFO - 2018-04-11 21:02:12 --> Hooks Class Initialized
DEBUG - 2018-04-11 21:02:12 --> UTF-8 Support Enabled
INFO - 2018-04-11 21:02:12 --> Utf8 Class Initialized
INFO - 2018-04-11 21:02:12 --> URI Class Initialized
INFO - 2018-04-11 21:02:12 --> Router Class Initialized
INFO - 2018-04-11 21:02:12 --> Output Class Initialized
INFO - 2018-04-11 21:02:12 --> Security Class Initialized
DEBUG - 2018-04-11 21:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 21:02:12 --> CSRF cookie sent
INFO - 2018-04-11 21:02:12 --> Input Class Initialized
INFO - 2018-04-11 21:02:12 --> Language Class Initialized
INFO - 2018-04-11 21:02:12 --> Loader Class Initialized
INFO - 2018-04-11 21:02:12 --> Helper loaded: url_helper
INFO - 2018-04-11 21:02:12 --> Helper loaded: form_helper
INFO - 2018-04-11 21:02:12 --> Helper loaded: language_helper
DEBUG - 2018-04-11 21:02:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 21:02:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 21:02:12 --> User Agent Class Initialized
INFO - 2018-04-11 21:02:12 --> Controller Class Initialized
INFO - 2018-04-11 21:02:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 21:02:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 21:02:12 --> Pixel_Model class loaded
INFO - 2018-04-11 21:02:12 --> Database Driver Class Initialized
INFO - 2018-04-11 21:02:16 --> Model "RegistrationModel" initialized
DEBUG - 2018-04-11 21:02:16 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-11 21:02:16 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 21:02:16 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-11 21:02:16 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-11 21:02:16 --> Could not find the language line "req_email"
INFO - 2018-04-11 21:02:16 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-04-11 21:02:16 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 21:02:16 --> Final output sent to browser
DEBUG - 2018-04-11 21:02:16 --> Total execution time: 3.4808
INFO - 2018-04-11 21:02:16 --> Config Class Initialized
INFO - 2018-04-11 21:02:16 --> Hooks Class Initialized
DEBUG - 2018-04-11 21:02:16 --> UTF-8 Support Enabled
INFO - 2018-04-11 21:02:16 --> Utf8 Class Initialized
INFO - 2018-04-11 21:02:16 --> URI Class Initialized
INFO - 2018-04-11 21:02:16 --> Router Class Initialized
INFO - 2018-04-11 21:02:16 --> Output Class Initialized
INFO - 2018-04-11 21:02:16 --> Security Class Initialized
DEBUG - 2018-04-11 21:02:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 21:02:16 --> CSRF cookie sent
INFO - 2018-04-11 21:02:16 --> Input Class Initialized
INFO - 2018-04-11 21:02:16 --> Language Class Initialized
ERROR - 2018-04-11 21:02:16 --> 404 Page Not Found: Assets/css
INFO - 2018-04-11 21:04:27 --> Config Class Initialized
INFO - 2018-04-11 21:04:27 --> Hooks Class Initialized
DEBUG - 2018-04-11 21:04:27 --> UTF-8 Support Enabled
INFO - 2018-04-11 21:04:27 --> Utf8 Class Initialized
INFO - 2018-04-11 21:04:27 --> URI Class Initialized
INFO - 2018-04-11 21:04:27 --> Router Class Initialized
INFO - 2018-04-11 21:04:27 --> Output Class Initialized
INFO - 2018-04-11 21:04:27 --> Security Class Initialized
DEBUG - 2018-04-11 21:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 21:04:27 --> CSRF cookie sent
INFO - 2018-04-11 21:04:27 --> Input Class Initialized
INFO - 2018-04-11 21:04:27 --> Language Class Initialized
INFO - 2018-04-11 21:04:27 --> Loader Class Initialized
INFO - 2018-04-11 21:04:27 --> Helper loaded: url_helper
INFO - 2018-04-11 21:04:27 --> Helper loaded: form_helper
INFO - 2018-04-11 21:04:27 --> Helper loaded: language_helper
DEBUG - 2018-04-11 21:04:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 21:04:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 21:04:27 --> User Agent Class Initialized
INFO - 2018-04-11 21:04:27 --> Controller Class Initialized
INFO - 2018-04-11 21:04:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 21:04:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 21:04:27 --> Pixel_Model class loaded
INFO - 2018-04-11 21:04:27 --> Database Driver Class Initialized
INFO - 2018-04-11 21:04:30 --> Model "RegistrationModel" initialized
DEBUG - 2018-04-11 21:04:30 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-11 21:04:30 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 21:04:30 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-11 21:04:30 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-11 21:04:30 --> Could not find the language line "req_email"
INFO - 2018-04-11 21:04:30 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-04-11 21:04:30 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 21:04:30 --> Final output sent to browser
DEBUG - 2018-04-11 21:04:30 --> Total execution time: 3.4377
INFO - 2018-04-11 21:04:31 --> Config Class Initialized
INFO - 2018-04-11 21:04:31 --> Hooks Class Initialized
DEBUG - 2018-04-11 21:04:31 --> UTF-8 Support Enabled
INFO - 2018-04-11 21:04:31 --> Utf8 Class Initialized
INFO - 2018-04-11 21:04:31 --> URI Class Initialized
INFO - 2018-04-11 21:04:31 --> Router Class Initialized
INFO - 2018-04-11 21:04:31 --> Output Class Initialized
INFO - 2018-04-11 21:04:31 --> Security Class Initialized
DEBUG - 2018-04-11 21:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 21:04:31 --> CSRF cookie sent
INFO - 2018-04-11 21:04:31 --> Input Class Initialized
INFO - 2018-04-11 21:04:31 --> Language Class Initialized
ERROR - 2018-04-11 21:04:31 --> 404 Page Not Found: Assets/css
INFO - 2018-04-11 21:04:41 --> Config Class Initialized
INFO - 2018-04-11 21:04:41 --> Hooks Class Initialized
DEBUG - 2018-04-11 21:04:41 --> UTF-8 Support Enabled
INFO - 2018-04-11 21:04:41 --> Utf8 Class Initialized
INFO - 2018-04-11 21:04:41 --> URI Class Initialized
INFO - 2018-04-11 21:04:41 --> Router Class Initialized
INFO - 2018-04-11 21:04:41 --> Output Class Initialized
INFO - 2018-04-11 21:04:41 --> Security Class Initialized
DEBUG - 2018-04-11 21:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 21:04:41 --> CSRF cookie sent
INFO - 2018-04-11 21:04:41 --> Input Class Initialized
INFO - 2018-04-11 21:04:41 --> Language Class Initialized
INFO - 2018-04-11 21:04:41 --> Loader Class Initialized
INFO - 2018-04-11 21:04:41 --> Helper loaded: url_helper
INFO - 2018-04-11 21:04:41 --> Helper loaded: form_helper
INFO - 2018-04-11 21:04:41 --> Helper loaded: language_helper
DEBUG - 2018-04-11 21:04:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 21:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 21:04:41 --> User Agent Class Initialized
INFO - 2018-04-11 21:04:41 --> Controller Class Initialized
INFO - 2018-04-11 21:04:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 21:04:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 21:04:42 --> Pixel_Model class loaded
INFO - 2018-04-11 21:04:42 --> Database Driver Class Initialized
INFO - 2018-04-11 21:04:42 --> Model "RegistrationModel" initialized
DEBUG - 2018-04-11 21:04:42 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-11 21:04:42 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 21:04:42 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-11 21:04:42 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-11 21:04:42 --> Could not find the language line "req_email"
INFO - 2018-04-11 21:04:42 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-04-11 21:04:42 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 21:04:42 --> Final output sent to browser
DEBUG - 2018-04-11 21:04:42 --> Total execution time: 0.5058
INFO - 2018-04-11 21:04:42 --> Config Class Initialized
INFO - 2018-04-11 21:04:42 --> Hooks Class Initialized
DEBUG - 2018-04-11 21:04:42 --> UTF-8 Support Enabled
INFO - 2018-04-11 21:04:42 --> Utf8 Class Initialized
INFO - 2018-04-11 21:04:42 --> URI Class Initialized
INFO - 2018-04-11 21:04:42 --> Router Class Initialized
INFO - 2018-04-11 21:04:42 --> Output Class Initialized
INFO - 2018-04-11 21:04:42 --> Security Class Initialized
DEBUG - 2018-04-11 21:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 21:04:42 --> CSRF cookie sent
INFO - 2018-04-11 21:04:42 --> Input Class Initialized
INFO - 2018-04-11 21:04:42 --> Language Class Initialized
ERROR - 2018-04-11 21:04:42 --> 404 Page Not Found: Assets/css
INFO - 2018-04-11 21:06:04 --> Config Class Initialized
INFO - 2018-04-11 21:06:04 --> Hooks Class Initialized
DEBUG - 2018-04-11 21:06:04 --> UTF-8 Support Enabled
INFO - 2018-04-11 21:06:04 --> Utf8 Class Initialized
INFO - 2018-04-11 21:06:04 --> URI Class Initialized
INFO - 2018-04-11 21:06:04 --> Router Class Initialized
INFO - 2018-04-11 21:06:04 --> Output Class Initialized
INFO - 2018-04-11 21:06:04 --> Security Class Initialized
DEBUG - 2018-04-11 21:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 21:06:04 --> CSRF cookie sent
INFO - 2018-04-11 21:06:04 --> Input Class Initialized
INFO - 2018-04-11 21:06:04 --> Language Class Initialized
INFO - 2018-04-11 21:06:05 --> Loader Class Initialized
INFO - 2018-04-11 21:06:05 --> Helper loaded: url_helper
INFO - 2018-04-11 21:06:05 --> Helper loaded: form_helper
INFO - 2018-04-11 21:06:05 --> Helper loaded: language_helper
DEBUG - 2018-04-11 21:06:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 21:06:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 21:06:05 --> User Agent Class Initialized
INFO - 2018-04-11 21:06:05 --> Controller Class Initialized
INFO - 2018-04-11 21:06:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 21:06:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 21:06:05 --> Pixel_Model class loaded
INFO - 2018-04-11 21:06:05 --> Database Driver Class Initialized
INFO - 2018-04-11 21:06:08 --> Model "RegistrationModel" initialized
DEBUG - 2018-04-11 21:06:08 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-11 21:06:08 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 21:06:08 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-11 21:06:08 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-11 21:06:08 --> Could not find the language line "req_email"
INFO - 2018-04-11 21:06:08 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-04-11 21:06:08 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 21:06:08 --> Final output sent to browser
DEBUG - 2018-04-11 21:06:08 --> Total execution time: 3.4614
INFO - 2018-04-11 21:06:08 --> Config Class Initialized
INFO - 2018-04-11 21:06:08 --> Hooks Class Initialized
DEBUG - 2018-04-11 21:06:08 --> UTF-8 Support Enabled
INFO - 2018-04-11 21:06:08 --> Utf8 Class Initialized
INFO - 2018-04-11 21:06:08 --> URI Class Initialized
INFO - 2018-04-11 21:06:08 --> Router Class Initialized
INFO - 2018-04-11 21:06:08 --> Output Class Initialized
INFO - 2018-04-11 21:06:08 --> Security Class Initialized
DEBUG - 2018-04-11 21:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 21:06:08 --> CSRF cookie sent
INFO - 2018-04-11 21:06:08 --> Input Class Initialized
INFO - 2018-04-11 21:06:08 --> Language Class Initialized
ERROR - 2018-04-11 21:06:08 --> 404 Page Not Found: Assets/css
INFO - 2018-04-11 21:08:04 --> Config Class Initialized
INFO - 2018-04-11 21:08:04 --> Hooks Class Initialized
DEBUG - 2018-04-11 21:08:04 --> UTF-8 Support Enabled
INFO - 2018-04-11 21:08:04 --> Utf8 Class Initialized
INFO - 2018-04-11 21:08:04 --> URI Class Initialized
INFO - 2018-04-11 21:08:04 --> Router Class Initialized
INFO - 2018-04-11 21:08:04 --> Output Class Initialized
INFO - 2018-04-11 21:08:04 --> Security Class Initialized
DEBUG - 2018-04-11 21:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 21:08:04 --> CSRF cookie sent
INFO - 2018-04-11 21:08:04 --> Input Class Initialized
INFO - 2018-04-11 21:08:04 --> Language Class Initialized
INFO - 2018-04-11 21:08:04 --> Loader Class Initialized
INFO - 2018-04-11 21:08:04 --> Helper loaded: url_helper
INFO - 2018-04-11 21:08:04 --> Helper loaded: form_helper
INFO - 2018-04-11 21:08:04 --> Helper loaded: language_helper
DEBUG - 2018-04-11 21:08:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 21:08:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 21:08:05 --> User Agent Class Initialized
INFO - 2018-04-11 21:08:05 --> Controller Class Initialized
INFO - 2018-04-11 21:08:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 21:08:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 21:08:05 --> Pixel_Model class loaded
INFO - 2018-04-11 21:08:05 --> Database Driver Class Initialized
INFO - 2018-04-11 21:08:08 --> Model "RegistrationModel" initialized
DEBUG - 2018-04-11 21:08:08 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-11 21:08:08 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 21:08:08 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-11 21:08:08 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-11 21:08:08 --> Could not find the language line "req_email"
INFO - 2018-04-11 21:08:08 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-04-11 21:08:08 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 21:08:08 --> Final output sent to browser
DEBUG - 2018-04-11 21:08:08 --> Total execution time: 3.4765
INFO - 2018-04-11 21:08:08 --> Config Class Initialized
INFO - 2018-04-11 21:08:08 --> Hooks Class Initialized
DEBUG - 2018-04-11 21:08:08 --> UTF-8 Support Enabled
INFO - 2018-04-11 21:08:08 --> Utf8 Class Initialized
INFO - 2018-04-11 21:08:08 --> URI Class Initialized
INFO - 2018-04-11 21:08:08 --> Router Class Initialized
INFO - 2018-04-11 21:08:08 --> Output Class Initialized
INFO - 2018-04-11 21:08:08 --> Security Class Initialized
DEBUG - 2018-04-11 21:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 21:08:08 --> CSRF cookie sent
INFO - 2018-04-11 21:08:08 --> Input Class Initialized
INFO - 2018-04-11 21:08:08 --> Language Class Initialized
ERROR - 2018-04-11 21:08:08 --> 404 Page Not Found: Assets/css
INFO - 2018-04-11 21:08:59 --> Config Class Initialized
INFO - 2018-04-11 21:08:59 --> Hooks Class Initialized
DEBUG - 2018-04-11 21:08:59 --> UTF-8 Support Enabled
INFO - 2018-04-11 21:08:59 --> Utf8 Class Initialized
INFO - 2018-04-11 21:08:59 --> URI Class Initialized
INFO - 2018-04-11 21:08:59 --> Router Class Initialized
INFO - 2018-04-11 21:08:59 --> Output Class Initialized
INFO - 2018-04-11 21:08:59 --> Security Class Initialized
DEBUG - 2018-04-11 21:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 21:08:59 --> CSRF cookie sent
INFO - 2018-04-11 21:08:59 --> Input Class Initialized
INFO - 2018-04-11 21:08:59 --> Language Class Initialized
INFO - 2018-04-11 21:08:59 --> Loader Class Initialized
INFO - 2018-04-11 21:08:59 --> Helper loaded: url_helper
INFO - 2018-04-11 21:08:59 --> Helper loaded: form_helper
INFO - 2018-04-11 21:08:59 --> Helper loaded: language_helper
DEBUG - 2018-04-11 21:08:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 21:08:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 21:08:59 --> User Agent Class Initialized
INFO - 2018-04-11 21:08:59 --> Controller Class Initialized
INFO - 2018-04-11 21:08:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 21:08:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 21:08:59 --> Pixel_Model class loaded
INFO - 2018-04-11 21:08:59 --> Database Driver Class Initialized
INFO - 2018-04-11 21:09:02 --> Model "RegistrationModel" initialized
DEBUG - 2018-04-11 21:09:02 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-11 21:09:02 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 21:09:02 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-11 21:09:02 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-11 21:09:02 --> Could not find the language line "req_email"
INFO - 2018-04-11 21:09:02 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-04-11 21:09:02 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 21:09:02 --> Final output sent to browser
DEBUG - 2018-04-11 21:09:02 --> Total execution time: 3.4967
INFO - 2018-04-11 21:09:02 --> Config Class Initialized
INFO - 2018-04-11 21:09:02 --> Hooks Class Initialized
DEBUG - 2018-04-11 21:09:02 --> UTF-8 Support Enabled
INFO - 2018-04-11 21:09:02 --> Utf8 Class Initialized
INFO - 2018-04-11 21:09:02 --> URI Class Initialized
INFO - 2018-04-11 21:09:03 --> Router Class Initialized
INFO - 2018-04-11 21:09:03 --> Output Class Initialized
INFO - 2018-04-11 21:09:03 --> Security Class Initialized
DEBUG - 2018-04-11 21:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 21:09:03 --> CSRF cookie sent
INFO - 2018-04-11 21:09:03 --> Input Class Initialized
INFO - 2018-04-11 21:09:03 --> Language Class Initialized
ERROR - 2018-04-11 21:09:03 --> 404 Page Not Found: Assets/css
INFO - 2018-04-11 21:10:05 --> Config Class Initialized
INFO - 2018-04-11 21:10:05 --> Hooks Class Initialized
DEBUG - 2018-04-11 21:10:05 --> UTF-8 Support Enabled
INFO - 2018-04-11 21:10:05 --> Utf8 Class Initialized
INFO - 2018-04-11 21:10:05 --> URI Class Initialized
INFO - 2018-04-11 21:10:05 --> Router Class Initialized
INFO - 2018-04-11 21:10:05 --> Output Class Initialized
INFO - 2018-04-11 21:10:05 --> Security Class Initialized
DEBUG - 2018-04-11 21:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 21:10:05 --> CSRF cookie sent
INFO - 2018-04-11 21:10:05 --> Input Class Initialized
INFO - 2018-04-11 21:10:05 --> Language Class Initialized
INFO - 2018-04-11 21:10:05 --> Loader Class Initialized
INFO - 2018-04-11 21:10:05 --> Helper loaded: url_helper
INFO - 2018-04-11 21:10:05 --> Helper loaded: form_helper
INFO - 2018-04-11 21:10:05 --> Helper loaded: language_helper
DEBUG - 2018-04-11 21:10:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 21:10:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 21:10:05 --> User Agent Class Initialized
INFO - 2018-04-11 21:10:05 --> Controller Class Initialized
INFO - 2018-04-11 21:10:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 21:10:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 21:10:05 --> Pixel_Model class loaded
INFO - 2018-04-11 21:10:05 --> Database Driver Class Initialized
INFO - 2018-04-11 21:10:05 --> Model "RegistrationModel" initialized
DEBUG - 2018-04-11 21:10:05 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-11 21:10:05 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 21:10:05 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-11 21:10:05 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-11 21:10:05 --> Could not find the language line "req_email"
INFO - 2018-04-11 21:10:05 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-04-11 21:10:05 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 21:10:05 --> Final output sent to browser
DEBUG - 2018-04-11 21:10:05 --> Total execution time: 0.4738
INFO - 2018-04-11 21:10:06 --> Config Class Initialized
INFO - 2018-04-11 21:10:06 --> Hooks Class Initialized
DEBUG - 2018-04-11 21:10:06 --> UTF-8 Support Enabled
INFO - 2018-04-11 21:10:06 --> Utf8 Class Initialized
INFO - 2018-04-11 21:10:06 --> URI Class Initialized
INFO - 2018-04-11 21:10:06 --> Router Class Initialized
INFO - 2018-04-11 21:10:06 --> Output Class Initialized
INFO - 2018-04-11 21:10:06 --> Security Class Initialized
DEBUG - 2018-04-11 21:10:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 21:10:06 --> CSRF cookie sent
INFO - 2018-04-11 21:10:06 --> Input Class Initialized
INFO - 2018-04-11 21:10:06 --> Language Class Initialized
ERROR - 2018-04-11 21:10:06 --> 404 Page Not Found: Assets/css
INFO - 2018-04-11 21:41:28 --> Config Class Initialized
INFO - 2018-04-11 21:41:28 --> Hooks Class Initialized
DEBUG - 2018-04-11 21:41:28 --> UTF-8 Support Enabled
INFO - 2018-04-11 21:41:28 --> Utf8 Class Initialized
INFO - 2018-04-11 21:41:28 --> URI Class Initialized
INFO - 2018-04-11 21:41:28 --> Router Class Initialized
INFO - 2018-04-11 21:41:28 --> Output Class Initialized
INFO - 2018-04-11 21:41:28 --> Security Class Initialized
DEBUG - 2018-04-11 21:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 21:41:28 --> CSRF cookie sent
INFO - 2018-04-11 21:41:28 --> Input Class Initialized
INFO - 2018-04-11 21:41:28 --> Language Class Initialized
INFO - 2018-04-11 21:41:28 --> Loader Class Initialized
INFO - 2018-04-11 21:41:28 --> Helper loaded: url_helper
INFO - 2018-04-11 21:41:28 --> Helper loaded: form_helper
INFO - 2018-04-11 21:41:28 --> Helper loaded: language_helper
DEBUG - 2018-04-11 21:41:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 21:41:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 21:41:28 --> User Agent Class Initialized
INFO - 2018-04-11 21:41:28 --> Controller Class Initialized
INFO - 2018-04-11 21:41:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 21:41:29 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-11 21:41:29 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-11 21:41:29 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 21:41:29 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-11 21:41:29 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-11 21:41:29 --> Could not find the language line "req_email"
INFO - 2018-04-11 21:41:29 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-04-11 21:41:29 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 21:41:29 --> Final output sent to browser
DEBUG - 2018-04-11 21:41:29 --> Total execution time: 0.4723
INFO - 2018-04-11 21:41:29 --> Config Class Initialized
INFO - 2018-04-11 21:41:29 --> Hooks Class Initialized
DEBUG - 2018-04-11 21:41:29 --> UTF-8 Support Enabled
INFO - 2018-04-11 21:41:29 --> Utf8 Class Initialized
INFO - 2018-04-11 21:41:29 --> URI Class Initialized
INFO - 2018-04-11 21:41:29 --> Router Class Initialized
INFO - 2018-04-11 21:41:29 --> Output Class Initialized
INFO - 2018-04-11 21:41:29 --> Security Class Initialized
DEBUG - 2018-04-11 21:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 21:41:29 --> CSRF cookie sent
INFO - 2018-04-11 21:41:29 --> Input Class Initialized
INFO - 2018-04-11 21:41:29 --> Language Class Initialized
ERROR - 2018-04-11 21:41:29 --> 404 Page Not Found: Assets/css
INFO - 2018-04-11 21:41:54 --> Config Class Initialized
INFO - 2018-04-11 21:41:54 --> Hooks Class Initialized
DEBUG - 2018-04-11 21:41:54 --> UTF-8 Support Enabled
INFO - 2018-04-11 21:41:54 --> Utf8 Class Initialized
INFO - 2018-04-11 21:41:54 --> URI Class Initialized
INFO - 2018-04-11 21:41:54 --> Router Class Initialized
INFO - 2018-04-11 21:41:54 --> Output Class Initialized
INFO - 2018-04-11 21:41:54 --> Security Class Initialized
DEBUG - 2018-04-11 21:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 21:41:54 --> CSRF cookie sent
INFO - 2018-04-11 21:41:54 --> CSRF token verified
INFO - 2018-04-11 21:41:54 --> Input Class Initialized
INFO - 2018-04-11 21:41:54 --> Language Class Initialized
INFO - 2018-04-11 21:41:54 --> Loader Class Initialized
INFO - 2018-04-11 21:41:54 --> Helper loaded: url_helper
INFO - 2018-04-11 21:41:54 --> Helper loaded: form_helper
INFO - 2018-04-11 21:41:54 --> Helper loaded: language_helper
DEBUG - 2018-04-11 21:41:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 21:41:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 21:41:54 --> User Agent Class Initialized
INFO - 2018-04-11 21:41:54 --> Controller Class Initialized
INFO - 2018-04-11 21:41:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 21:41:54 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-11 21:41:54 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-11 21:41:54 --> Form Validation Class Initialized
INFO - 2018-04-11 21:41:54 --> Pixel_Model class loaded
INFO - 2018-04-11 21:41:55 --> Database Driver Class Initialized
INFO - 2018-04-11 21:41:58 --> Model "AuthenticationModel" initialized
INFO - 2018-04-11 21:41:58 --> Config Class Initialized
INFO - 2018-04-11 21:41:58 --> Hooks Class Initialized
DEBUG - 2018-04-11 21:41:58 --> UTF-8 Support Enabled
INFO - 2018-04-11 21:41:58 --> Utf8 Class Initialized
INFO - 2018-04-11 21:41:58 --> URI Class Initialized
INFO - 2018-04-11 21:41:58 --> Router Class Initialized
INFO - 2018-04-11 21:41:58 --> Output Class Initialized
INFO - 2018-04-11 21:41:58 --> Security Class Initialized
DEBUG - 2018-04-11 21:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 21:41:58 --> CSRF cookie sent
INFO - 2018-04-11 21:41:58 --> Input Class Initialized
INFO - 2018-04-11 21:41:58 --> Language Class Initialized
INFO - 2018-04-11 21:41:58 --> Loader Class Initialized
INFO - 2018-04-11 21:41:58 --> Helper loaded: url_helper
INFO - 2018-04-11 21:41:58 --> Helper loaded: form_helper
INFO - 2018-04-11 21:41:58 --> Helper loaded: language_helper
DEBUG - 2018-04-11 21:41:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 21:41:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 21:41:58 --> User Agent Class Initialized
INFO - 2018-04-11 21:41:58 --> Controller Class Initialized
INFO - 2018-04-11 21:41:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 21:41:58 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-11 21:41:58 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-11 21:41:58 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 21:41:58 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-11 21:41:58 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-11 21:41:58 --> File loaded: E:\www\yacopoo\application\views\shared/_soft_error.php
ERROR - 2018-04-11 21:41:58 --> Could not find the language line "req_email"
INFO - 2018-04-11 21:41:58 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-04-11 21:41:58 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 21:41:58 --> Final output sent to browser
DEBUG - 2018-04-11 21:41:58 --> Total execution time: 0.4031
INFO - 2018-04-11 21:41:58 --> Config Class Initialized
INFO - 2018-04-11 21:41:58 --> Hooks Class Initialized
DEBUG - 2018-04-11 21:41:58 --> UTF-8 Support Enabled
INFO - 2018-04-11 21:41:58 --> Utf8 Class Initialized
INFO - 2018-04-11 21:41:58 --> URI Class Initialized
INFO - 2018-04-11 21:41:59 --> Router Class Initialized
INFO - 2018-04-11 21:41:59 --> Output Class Initialized
INFO - 2018-04-11 21:41:59 --> Security Class Initialized
DEBUG - 2018-04-11 21:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 21:41:59 --> CSRF cookie sent
INFO - 2018-04-11 21:41:59 --> Input Class Initialized
INFO - 2018-04-11 21:41:59 --> Language Class Initialized
ERROR - 2018-04-11 21:41:59 --> 404 Page Not Found: Assets/css
INFO - 2018-04-11 21:42:48 --> Config Class Initialized
INFO - 2018-04-11 21:42:48 --> Hooks Class Initialized
DEBUG - 2018-04-11 21:42:48 --> UTF-8 Support Enabled
INFO - 2018-04-11 21:42:48 --> Utf8 Class Initialized
INFO - 2018-04-11 21:42:48 --> URI Class Initialized
INFO - 2018-04-11 21:42:48 --> Router Class Initialized
INFO - 2018-04-11 21:42:48 --> Output Class Initialized
INFO - 2018-04-11 21:42:48 --> Security Class Initialized
DEBUG - 2018-04-11 21:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 21:42:48 --> CSRF cookie sent
INFO - 2018-04-11 21:42:48 --> CSRF token verified
INFO - 2018-04-11 21:42:48 --> Input Class Initialized
INFO - 2018-04-11 21:42:48 --> Language Class Initialized
INFO - 2018-04-11 21:42:48 --> Loader Class Initialized
INFO - 2018-04-11 21:42:48 --> Helper loaded: url_helper
INFO - 2018-04-11 21:42:48 --> Helper loaded: form_helper
INFO - 2018-04-11 21:42:48 --> Helper loaded: language_helper
DEBUG - 2018-04-11 21:42:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 21:42:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 21:42:48 --> User Agent Class Initialized
INFO - 2018-04-11 21:42:48 --> Controller Class Initialized
INFO - 2018-04-11 21:42:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 21:42:48 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-11 21:42:48 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-11 21:42:48 --> Form Validation Class Initialized
INFO - 2018-04-11 21:42:48 --> Pixel_Model class loaded
INFO - 2018-04-11 21:42:48 --> Database Driver Class Initialized
INFO - 2018-04-11 21:42:48 --> Model "AuthenticationModel" initialized
INFO - 2018-04-11 21:42:49 --> Config Class Initialized
INFO - 2018-04-11 21:42:49 --> Hooks Class Initialized
DEBUG - 2018-04-11 21:42:49 --> UTF-8 Support Enabled
INFO - 2018-04-11 21:42:49 --> Utf8 Class Initialized
INFO - 2018-04-11 21:42:49 --> URI Class Initialized
INFO - 2018-04-11 21:42:49 --> Router Class Initialized
INFO - 2018-04-11 21:42:49 --> Output Class Initialized
INFO - 2018-04-11 21:42:49 --> Security Class Initialized
DEBUG - 2018-04-11 21:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 21:42:49 --> CSRF cookie sent
INFO - 2018-04-11 21:42:49 --> Input Class Initialized
INFO - 2018-04-11 21:42:49 --> Language Class Initialized
INFO - 2018-04-11 21:42:49 --> Loader Class Initialized
INFO - 2018-04-11 21:42:49 --> Helper loaded: url_helper
INFO - 2018-04-11 21:42:49 --> Helper loaded: form_helper
INFO - 2018-04-11 21:42:49 --> Helper loaded: language_helper
DEBUG - 2018-04-11 21:42:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 21:42:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 21:42:49 --> User Agent Class Initialized
INFO - 2018-04-11 21:42:49 --> Controller Class Initialized
INFO - 2018-04-11 21:42:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 21:42:49 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-11 21:42:49 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-11 21:42:49 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 21:42:49 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-11 21:42:49 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-11 21:42:49 --> File loaded: E:\www\yacopoo\application\views\shared/_soft_error.php
ERROR - 2018-04-11 21:42:49 --> Could not find the language line "req_email"
INFO - 2018-04-11 21:42:49 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-04-11 21:42:49 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 21:42:49 --> Final output sent to browser
DEBUG - 2018-04-11 21:42:49 --> Total execution time: 0.4109
INFO - 2018-04-11 21:42:49 --> Config Class Initialized
INFO - 2018-04-11 21:42:49 --> Hooks Class Initialized
DEBUG - 2018-04-11 21:42:50 --> UTF-8 Support Enabled
INFO - 2018-04-11 21:42:50 --> Utf8 Class Initialized
INFO - 2018-04-11 21:42:50 --> URI Class Initialized
INFO - 2018-04-11 21:42:50 --> Router Class Initialized
INFO - 2018-04-11 21:42:50 --> Output Class Initialized
INFO - 2018-04-11 21:42:50 --> Security Class Initialized
DEBUG - 2018-04-11 21:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 21:42:50 --> CSRF cookie sent
INFO - 2018-04-11 21:42:50 --> Input Class Initialized
INFO - 2018-04-11 21:42:50 --> Language Class Initialized
ERROR - 2018-04-11 21:42:50 --> 404 Page Not Found: Assets/css
INFO - 2018-04-11 21:43:14 --> Config Class Initialized
INFO - 2018-04-11 21:43:14 --> Hooks Class Initialized
DEBUG - 2018-04-11 21:43:14 --> UTF-8 Support Enabled
INFO - 2018-04-11 21:43:14 --> Utf8 Class Initialized
INFO - 2018-04-11 21:43:14 --> URI Class Initialized
INFO - 2018-04-11 21:43:14 --> Router Class Initialized
INFO - 2018-04-11 21:43:14 --> Output Class Initialized
INFO - 2018-04-11 21:43:14 --> Security Class Initialized
DEBUG - 2018-04-11 21:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 21:43:14 --> CSRF cookie sent
INFO - 2018-04-11 21:43:14 --> CSRF token verified
INFO - 2018-04-11 21:43:14 --> Input Class Initialized
INFO - 2018-04-11 21:43:14 --> Language Class Initialized
INFO - 2018-04-11 21:43:14 --> Loader Class Initialized
INFO - 2018-04-11 21:43:14 --> Helper loaded: url_helper
INFO - 2018-04-11 21:43:14 --> Helper loaded: form_helper
INFO - 2018-04-11 21:43:14 --> Helper loaded: language_helper
DEBUG - 2018-04-11 21:43:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 21:43:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 21:43:14 --> User Agent Class Initialized
INFO - 2018-04-11 21:43:14 --> Controller Class Initialized
INFO - 2018-04-11 21:43:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 21:43:14 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-11 21:43:14 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-11 21:43:15 --> Form Validation Class Initialized
INFO - 2018-04-11 21:43:15 --> Pixel_Model class loaded
INFO - 2018-04-11 21:43:15 --> Database Driver Class Initialized
INFO - 2018-04-11 21:43:18 --> Model "AuthenticationModel" initialized
INFO - 2018-04-11 21:43:18 --> Config Class Initialized
INFO - 2018-04-11 21:43:18 --> Hooks Class Initialized
DEBUG - 2018-04-11 21:43:18 --> UTF-8 Support Enabled
INFO - 2018-04-11 21:43:18 --> Utf8 Class Initialized
INFO - 2018-04-11 21:43:18 --> URI Class Initialized
INFO - 2018-04-11 21:43:18 --> Router Class Initialized
INFO - 2018-04-11 21:43:18 --> Output Class Initialized
INFO - 2018-04-11 21:43:18 --> Security Class Initialized
DEBUG - 2018-04-11 21:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 21:43:18 --> CSRF cookie sent
INFO - 2018-04-11 21:43:18 --> Input Class Initialized
INFO - 2018-04-11 21:43:18 --> Language Class Initialized
INFO - 2018-04-11 21:43:18 --> Loader Class Initialized
INFO - 2018-04-11 21:43:18 --> Helper loaded: url_helper
INFO - 2018-04-11 21:43:18 --> Helper loaded: form_helper
INFO - 2018-04-11 21:43:18 --> Helper loaded: language_helper
DEBUG - 2018-04-11 21:43:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 21:43:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 21:43:18 --> User Agent Class Initialized
INFO - 2018-04-11 21:43:18 --> Controller Class Initialized
INFO - 2018-04-11 21:43:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 21:43:18 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-11 21:43:18 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-11 21:43:18 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 21:43:18 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-11 21:43:18 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-11 21:43:18 --> File loaded: E:\www\yacopoo\application\views\shared/_soft_error.php
ERROR - 2018-04-11 21:43:18 --> Could not find the language line "req_email"
INFO - 2018-04-11 21:43:18 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-04-11 21:43:18 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 21:43:18 --> Final output sent to browser
DEBUG - 2018-04-11 21:43:18 --> Total execution time: 0.4091
INFO - 2018-04-11 21:43:19 --> Config Class Initialized
INFO - 2018-04-11 21:43:19 --> Hooks Class Initialized
DEBUG - 2018-04-11 21:43:19 --> UTF-8 Support Enabled
INFO - 2018-04-11 21:43:19 --> Utf8 Class Initialized
INFO - 2018-04-11 21:43:19 --> URI Class Initialized
INFO - 2018-04-11 21:43:19 --> Router Class Initialized
INFO - 2018-04-11 21:43:19 --> Output Class Initialized
INFO - 2018-04-11 21:43:19 --> Security Class Initialized
DEBUG - 2018-04-11 21:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 21:43:19 --> CSRF cookie sent
INFO - 2018-04-11 21:43:19 --> Input Class Initialized
INFO - 2018-04-11 21:43:19 --> Language Class Initialized
ERROR - 2018-04-11 21:43:19 --> 404 Page Not Found: Assets/css
INFO - 2018-04-11 21:43:34 --> Config Class Initialized
INFO - 2018-04-11 21:43:35 --> Hooks Class Initialized
DEBUG - 2018-04-11 21:43:35 --> UTF-8 Support Enabled
INFO - 2018-04-11 21:43:35 --> Utf8 Class Initialized
INFO - 2018-04-11 21:43:35 --> URI Class Initialized
INFO - 2018-04-11 21:43:35 --> Router Class Initialized
INFO - 2018-04-11 21:43:35 --> Output Class Initialized
INFO - 2018-04-11 21:43:35 --> Security Class Initialized
DEBUG - 2018-04-11 21:43:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 21:43:35 --> CSRF cookie sent
INFO - 2018-04-11 21:43:35 --> CSRF token verified
INFO - 2018-04-11 21:43:35 --> Input Class Initialized
INFO - 2018-04-11 21:43:35 --> Language Class Initialized
INFO - 2018-04-11 21:43:35 --> Loader Class Initialized
INFO - 2018-04-11 21:43:35 --> Helper loaded: url_helper
INFO - 2018-04-11 21:43:35 --> Helper loaded: form_helper
INFO - 2018-04-11 21:43:35 --> Helper loaded: language_helper
DEBUG - 2018-04-11 21:43:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 21:43:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 21:43:35 --> User Agent Class Initialized
INFO - 2018-04-11 21:43:35 --> Controller Class Initialized
INFO - 2018-04-11 21:43:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 21:43:35 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-11 21:43:35 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-11 21:43:35 --> Form Validation Class Initialized
INFO - 2018-04-11 21:43:35 --> Pixel_Model class loaded
INFO - 2018-04-11 21:43:35 --> Database Driver Class Initialized
INFO - 2018-04-11 21:43:35 --> Model "AuthenticationModel" initialized
INFO - 2018-04-11 21:43:35 --> Config Class Initialized
INFO - 2018-04-11 21:43:35 --> Hooks Class Initialized
DEBUG - 2018-04-11 21:43:35 --> UTF-8 Support Enabled
INFO - 2018-04-11 21:43:35 --> Utf8 Class Initialized
INFO - 2018-04-11 21:43:35 --> URI Class Initialized
DEBUG - 2018-04-11 21:43:35 --> No URI present. Default controller set.
INFO - 2018-04-11 21:43:35 --> Router Class Initialized
INFO - 2018-04-11 21:43:35 --> Output Class Initialized
INFO - 2018-04-11 21:43:35 --> Security Class Initialized
DEBUG - 2018-04-11 21:43:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 21:43:35 --> CSRF cookie sent
INFO - 2018-04-11 21:43:36 --> Input Class Initialized
INFO - 2018-04-11 21:43:36 --> Language Class Initialized
INFO - 2018-04-11 21:43:36 --> Loader Class Initialized
INFO - 2018-04-11 21:43:36 --> Helper loaded: url_helper
INFO - 2018-04-11 21:43:36 --> Helper loaded: form_helper
INFO - 2018-04-11 21:43:36 --> Helper loaded: language_helper
DEBUG - 2018-04-11 21:43:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 21:43:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 21:43:36 --> User Agent Class Initialized
INFO - 2018-04-11 21:43:36 --> Controller Class Initialized
INFO - 2018-04-11 21:43:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 21:43:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 21:43:36 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 21:43:36 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-11 21:43:36 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 21:43:36 --> Final output sent to browser
DEBUG - 2018-04-11 21:43:36 --> Total execution time: 0.3805
INFO - 2018-04-11 21:43:36 --> Config Class Initialized
INFO - 2018-04-11 21:43:36 --> Hooks Class Initialized
DEBUG - 2018-04-11 21:43:36 --> UTF-8 Support Enabled
INFO - 2018-04-11 21:43:36 --> Utf8 Class Initialized
INFO - 2018-04-11 21:43:36 --> URI Class Initialized
INFO - 2018-04-11 21:43:36 --> Router Class Initialized
INFO - 2018-04-11 21:43:36 --> Output Class Initialized
INFO - 2018-04-11 21:43:36 --> Security Class Initialized
DEBUG - 2018-04-11 21:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 21:43:36 --> CSRF cookie sent
INFO - 2018-04-11 21:43:36 --> Input Class Initialized
INFO - 2018-04-11 21:43:36 --> Language Class Initialized
ERROR - 2018-04-11 21:43:36 --> 404 Page Not Found: Assets/css
INFO - 2018-04-11 21:43:38 --> Config Class Initialized
INFO - 2018-04-11 21:43:38 --> Hooks Class Initialized
DEBUG - 2018-04-11 21:43:38 --> UTF-8 Support Enabled
INFO - 2018-04-11 21:43:38 --> Utf8 Class Initialized
INFO - 2018-04-11 21:43:38 --> URI Class Initialized
INFO - 2018-04-11 21:43:38 --> Router Class Initialized
INFO - 2018-04-11 21:43:38 --> Output Class Initialized
INFO - 2018-04-11 21:43:38 --> Security Class Initialized
DEBUG - 2018-04-11 21:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 21:43:38 --> CSRF cookie sent
INFO - 2018-04-11 21:43:38 --> Input Class Initialized
INFO - 2018-04-11 21:43:38 --> Language Class Initialized
ERROR - 2018-04-11 21:43:38 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-11 21:43:39 --> Config Class Initialized
INFO - 2018-04-11 21:43:39 --> Hooks Class Initialized
DEBUG - 2018-04-11 21:43:39 --> UTF-8 Support Enabled
INFO - 2018-04-11 21:43:39 --> Utf8 Class Initialized
INFO - 2018-04-11 21:43:39 --> URI Class Initialized
INFO - 2018-04-11 21:43:39 --> Router Class Initialized
INFO - 2018-04-11 21:43:39 --> Output Class Initialized
INFO - 2018-04-11 21:43:39 --> Security Class Initialized
DEBUG - 2018-04-11 21:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 21:43:39 --> CSRF cookie sent
INFO - 2018-04-11 21:43:39 --> Input Class Initialized
INFO - 2018-04-11 21:43:39 --> Language Class Initialized
INFO - 2018-04-11 21:43:39 --> Loader Class Initialized
INFO - 2018-04-11 21:43:39 --> Helper loaded: url_helper
INFO - 2018-04-11 21:43:39 --> Helper loaded: form_helper
INFO - 2018-04-11 21:43:39 --> Helper loaded: language_helper
DEBUG - 2018-04-11 21:43:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 21:43:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 21:43:39 --> User Agent Class Initialized
INFO - 2018-04-11 21:43:39 --> Controller Class Initialized
INFO - 2018-04-11 21:43:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 21:43:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 21:43:40 --> CSRF cookie sent
INFO - 2018-04-11 21:43:40 --> Config Class Initialized
INFO - 2018-04-11 21:43:40 --> Hooks Class Initialized
DEBUG - 2018-04-11 21:43:40 --> UTF-8 Support Enabled
INFO - 2018-04-11 21:43:40 --> Utf8 Class Initialized
INFO - 2018-04-11 21:43:40 --> URI Class Initialized
DEBUG - 2018-04-11 21:43:40 --> No URI present. Default controller set.
INFO - 2018-04-11 21:43:40 --> Router Class Initialized
INFO - 2018-04-11 21:43:40 --> Output Class Initialized
INFO - 2018-04-11 21:43:40 --> Security Class Initialized
DEBUG - 2018-04-11 21:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 21:43:40 --> CSRF cookie sent
INFO - 2018-04-11 21:43:40 --> Input Class Initialized
INFO - 2018-04-11 21:43:40 --> Language Class Initialized
INFO - 2018-04-11 21:43:40 --> Loader Class Initialized
INFO - 2018-04-11 21:43:40 --> Helper loaded: url_helper
INFO - 2018-04-11 21:43:40 --> Helper loaded: form_helper
INFO - 2018-04-11 21:43:40 --> Helper loaded: language_helper
DEBUG - 2018-04-11 21:43:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 21:43:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 21:43:40 --> User Agent Class Initialized
INFO - 2018-04-11 21:43:40 --> Controller Class Initialized
INFO - 2018-04-11 21:43:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 21:43:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 21:43:40 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 21:43:40 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-11 21:43:40 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 21:43:40 --> Final output sent to browser
DEBUG - 2018-04-11 21:43:40 --> Total execution time: 0.4780
INFO - 2018-04-11 21:43:41 --> Config Class Initialized
INFO - 2018-04-11 21:43:41 --> Hooks Class Initialized
DEBUG - 2018-04-11 21:43:41 --> UTF-8 Support Enabled
INFO - 2018-04-11 21:43:41 --> Utf8 Class Initialized
INFO - 2018-04-11 21:43:41 --> URI Class Initialized
INFO - 2018-04-11 21:43:41 --> Router Class Initialized
INFO - 2018-04-11 21:43:41 --> Output Class Initialized
INFO - 2018-04-11 21:43:41 --> Security Class Initialized
DEBUG - 2018-04-11 21:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 21:43:41 --> CSRF cookie sent
INFO - 2018-04-11 21:43:41 --> Input Class Initialized
INFO - 2018-04-11 21:43:41 --> Language Class Initialized
ERROR - 2018-04-11 21:43:41 --> 404 Page Not Found: Assets/css
INFO - 2018-04-11 21:43:42 --> Config Class Initialized
INFO - 2018-04-11 21:43:42 --> Hooks Class Initialized
DEBUG - 2018-04-11 21:43:42 --> UTF-8 Support Enabled
INFO - 2018-04-11 21:43:42 --> Utf8 Class Initialized
INFO - 2018-04-11 21:43:42 --> URI Class Initialized
INFO - 2018-04-11 21:43:43 --> Router Class Initialized
INFO - 2018-04-11 21:43:43 --> Output Class Initialized
INFO - 2018-04-11 21:43:43 --> Security Class Initialized
DEBUG - 2018-04-11 21:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 21:43:43 --> CSRF cookie sent
INFO - 2018-04-11 21:43:43 --> Input Class Initialized
INFO - 2018-04-11 21:43:43 --> Language Class Initialized
ERROR - 2018-04-11 21:43:43 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-11 21:44:08 --> Config Class Initialized
INFO - 2018-04-11 21:44:08 --> Hooks Class Initialized
DEBUG - 2018-04-11 21:44:08 --> UTF-8 Support Enabled
INFO - 2018-04-11 21:44:08 --> Utf8 Class Initialized
INFO - 2018-04-11 21:44:08 --> URI Class Initialized
INFO - 2018-04-11 21:44:08 --> Router Class Initialized
INFO - 2018-04-11 21:44:08 --> Output Class Initialized
INFO - 2018-04-11 21:44:08 --> Security Class Initialized
DEBUG - 2018-04-11 21:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 21:44:08 --> CSRF cookie sent
INFO - 2018-04-11 21:44:08 --> Input Class Initialized
INFO - 2018-04-11 21:44:08 --> Language Class Initialized
INFO - 2018-04-11 21:44:08 --> Loader Class Initialized
INFO - 2018-04-11 21:44:08 --> Helper loaded: url_helper
INFO - 2018-04-11 21:44:08 --> Helper loaded: form_helper
INFO - 2018-04-11 21:44:08 --> Helper loaded: language_helper
DEBUG - 2018-04-11 21:44:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 21:44:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 21:44:08 --> User Agent Class Initialized
INFO - 2018-04-11 21:44:08 --> Controller Class Initialized
INFO - 2018-04-11 21:44:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 21:44:08 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-11 21:44:08 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-11 21:44:08 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 21:44:08 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-11 21:44:08 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-11 21:44:08 --> Could not find the language line "req_email"
INFO - 2018-04-11 21:44:08 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-04-11 21:44:08 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 21:44:08 --> Final output sent to browser
DEBUG - 2018-04-11 21:44:08 --> Total execution time: 0.4446
INFO - 2018-04-11 21:44:08 --> Config Class Initialized
INFO - 2018-04-11 21:44:08 --> Hooks Class Initialized
DEBUG - 2018-04-11 21:44:08 --> UTF-8 Support Enabled
INFO - 2018-04-11 21:44:08 --> Utf8 Class Initialized
INFO - 2018-04-11 21:44:08 --> URI Class Initialized
INFO - 2018-04-11 21:44:08 --> Router Class Initialized
INFO - 2018-04-11 21:44:08 --> Output Class Initialized
INFO - 2018-04-11 21:44:08 --> Security Class Initialized
DEBUG - 2018-04-11 21:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 21:44:08 --> CSRF cookie sent
INFO - 2018-04-11 21:44:09 --> Input Class Initialized
INFO - 2018-04-11 21:44:09 --> Language Class Initialized
ERROR - 2018-04-11 21:44:09 --> 404 Page Not Found: Assets/css
INFO - 2018-04-11 21:44:19 --> Config Class Initialized
INFO - 2018-04-11 21:44:19 --> Hooks Class Initialized
DEBUG - 2018-04-11 21:44:19 --> UTF-8 Support Enabled
INFO - 2018-04-11 21:44:19 --> Utf8 Class Initialized
INFO - 2018-04-11 21:44:19 --> URI Class Initialized
INFO - 2018-04-11 21:44:19 --> Router Class Initialized
INFO - 2018-04-11 21:44:19 --> Output Class Initialized
INFO - 2018-04-11 21:44:19 --> Security Class Initialized
DEBUG - 2018-04-11 21:44:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 21:44:19 --> CSRF cookie sent
INFO - 2018-04-11 21:44:19 --> CSRF token verified
INFO - 2018-04-11 21:44:19 --> Input Class Initialized
INFO - 2018-04-11 21:44:19 --> Language Class Initialized
INFO - 2018-04-11 21:44:19 --> Loader Class Initialized
INFO - 2018-04-11 21:44:19 --> Helper loaded: url_helper
INFO - 2018-04-11 21:44:19 --> Helper loaded: form_helper
INFO - 2018-04-11 21:44:19 --> Helper loaded: language_helper
DEBUG - 2018-04-11 21:44:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 21:44:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 21:44:19 --> User Agent Class Initialized
INFO - 2018-04-11 21:44:19 --> Controller Class Initialized
INFO - 2018-04-11 21:44:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 21:44:19 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-11 21:44:19 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-11 21:44:20 --> Form Validation Class Initialized
INFO - 2018-04-11 21:44:20 --> Pixel_Model class loaded
INFO - 2018-04-11 21:44:20 --> Database Driver Class Initialized
INFO - 2018-04-11 21:44:20 --> Model "AuthenticationModel" initialized
INFO - 2018-04-11 21:44:20 --> Config Class Initialized
INFO - 2018-04-11 21:44:20 --> Hooks Class Initialized
DEBUG - 2018-04-11 21:44:20 --> UTF-8 Support Enabled
INFO - 2018-04-11 21:44:20 --> Utf8 Class Initialized
INFO - 2018-04-11 21:44:20 --> URI Class Initialized
DEBUG - 2018-04-11 21:44:20 --> No URI present. Default controller set.
INFO - 2018-04-11 21:44:20 --> Router Class Initialized
INFO - 2018-04-11 21:44:20 --> Output Class Initialized
INFO - 2018-04-11 21:44:20 --> Security Class Initialized
DEBUG - 2018-04-11 21:44:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 21:44:20 --> CSRF cookie sent
INFO - 2018-04-11 21:44:20 --> Input Class Initialized
INFO - 2018-04-11 21:44:20 --> Language Class Initialized
INFO - 2018-04-11 21:44:20 --> Loader Class Initialized
INFO - 2018-04-11 21:44:20 --> Helper loaded: url_helper
INFO - 2018-04-11 21:44:20 --> Helper loaded: form_helper
INFO - 2018-04-11 21:44:20 --> Helper loaded: language_helper
DEBUG - 2018-04-11 21:44:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 21:44:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 21:44:20 --> User Agent Class Initialized
INFO - 2018-04-11 21:44:20 --> Controller Class Initialized
INFO - 2018-04-11 21:44:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 21:44:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 21:44:20 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 21:44:20 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-11 21:44:20 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 21:44:20 --> Final output sent to browser
DEBUG - 2018-04-11 21:44:20 --> Total execution time: 0.3678
INFO - 2018-04-11 21:44:21 --> Config Class Initialized
INFO - 2018-04-11 21:44:21 --> Hooks Class Initialized
DEBUG - 2018-04-11 21:44:21 --> UTF-8 Support Enabled
INFO - 2018-04-11 21:44:21 --> Utf8 Class Initialized
INFO - 2018-04-11 21:44:21 --> URI Class Initialized
INFO - 2018-04-11 21:44:21 --> Router Class Initialized
INFO - 2018-04-11 21:44:21 --> Output Class Initialized
INFO - 2018-04-11 21:44:21 --> Security Class Initialized
DEBUG - 2018-04-11 21:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 21:44:21 --> CSRF cookie sent
INFO - 2018-04-11 21:44:21 --> Input Class Initialized
INFO - 2018-04-11 21:44:21 --> Language Class Initialized
ERROR - 2018-04-11 21:44:21 --> 404 Page Not Found: Assets/css
INFO - 2018-04-11 21:44:22 --> Config Class Initialized
INFO - 2018-04-11 21:44:22 --> Hooks Class Initialized
DEBUG - 2018-04-11 21:44:22 --> UTF-8 Support Enabled
INFO - 2018-04-11 21:44:22 --> Utf8 Class Initialized
INFO - 2018-04-11 21:44:22 --> URI Class Initialized
INFO - 2018-04-11 21:44:22 --> Router Class Initialized
INFO - 2018-04-11 21:44:22 --> Output Class Initialized
INFO - 2018-04-11 21:44:22 --> Security Class Initialized
DEBUG - 2018-04-11 21:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 21:44:22 --> CSRF cookie sent
INFO - 2018-04-11 21:44:22 --> Input Class Initialized
INFO - 2018-04-11 21:44:22 --> Language Class Initialized
ERROR - 2018-04-11 21:44:22 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-11 21:44:30 --> Config Class Initialized
INFO - 2018-04-11 21:44:30 --> Hooks Class Initialized
DEBUG - 2018-04-11 21:44:30 --> UTF-8 Support Enabled
INFO - 2018-04-11 21:44:30 --> Utf8 Class Initialized
INFO - 2018-04-11 21:44:31 --> URI Class Initialized
INFO - 2018-04-11 21:44:31 --> Router Class Initialized
INFO - 2018-04-11 21:44:31 --> Output Class Initialized
INFO - 2018-04-11 21:44:31 --> Security Class Initialized
DEBUG - 2018-04-11 21:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 21:44:31 --> CSRF cookie sent
INFO - 2018-04-11 21:44:31 --> Input Class Initialized
INFO - 2018-04-11 21:44:31 --> Language Class Initialized
INFO - 2018-04-11 21:44:31 --> Loader Class Initialized
INFO - 2018-04-11 21:44:31 --> Helper loaded: url_helper
INFO - 2018-04-11 21:44:31 --> Helper loaded: form_helper
INFO - 2018-04-11 21:44:31 --> Helper loaded: language_helper
DEBUG - 2018-04-11 21:44:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 21:44:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 21:44:31 --> User Agent Class Initialized
INFO - 2018-04-11 21:44:31 --> Controller Class Initialized
INFO - 2018-04-11 21:44:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 21:44:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 21:44:31 --> Pixel_Model class loaded
INFO - 2018-04-11 21:44:31 --> Database Driver Class Initialized
INFO - 2018-04-11 21:44:31 --> Model "MyAccountModel" initialized
INFO - 2018-04-11 21:44:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-04-11 21:44:31 --> Pagination Class Initialized
INFO - 2018-04-11 21:44:31 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 21:44:31 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-11 21:44:31 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-11 21:44:31 --> Severity: Error --> Call to undefined method Constants::getStatusLabel() E:\www\yacopoo\application\views\myaccount\users_list.php 68
INFO - 2018-04-11 21:45:53 --> Config Class Initialized
INFO - 2018-04-11 21:45:53 --> Hooks Class Initialized
DEBUG - 2018-04-11 21:45:53 --> UTF-8 Support Enabled
INFO - 2018-04-11 21:45:53 --> Utf8 Class Initialized
INFO - 2018-04-11 21:45:53 --> URI Class Initialized
INFO - 2018-04-11 21:45:53 --> Router Class Initialized
INFO - 2018-04-11 21:45:53 --> Output Class Initialized
INFO - 2018-04-11 21:45:53 --> Security Class Initialized
DEBUG - 2018-04-11 21:45:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 21:45:53 --> CSRF cookie sent
INFO - 2018-04-11 21:45:53 --> Input Class Initialized
INFO - 2018-04-11 21:45:53 --> Language Class Initialized
INFO - 2018-04-11 21:45:53 --> Loader Class Initialized
INFO - 2018-04-11 21:45:53 --> Helper loaded: url_helper
INFO - 2018-04-11 21:45:53 --> Helper loaded: form_helper
INFO - 2018-04-11 21:45:53 --> Helper loaded: language_helper
DEBUG - 2018-04-11 21:45:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 21:45:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 21:45:54 --> User Agent Class Initialized
INFO - 2018-04-11 21:45:54 --> Controller Class Initialized
INFO - 2018-04-11 21:45:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 21:45:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 21:45:54 --> Pixel_Model class loaded
INFO - 2018-04-11 21:45:54 --> Database Driver Class Initialized
INFO - 2018-04-11 21:45:57 --> Model "MyAccountModel" initialized
INFO - 2018-04-11 21:45:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-04-11 21:45:57 --> Pagination Class Initialized
INFO - 2018-04-11 21:45:57 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 21:45:57 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-11 21:45:57 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-11 21:45:57 --> File loaded: E:\www\yacopoo\application\views\myaccount/users_list.php
INFO - 2018-04-11 21:45:57 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 21:45:57 --> Final output sent to browser
DEBUG - 2018-04-11 21:45:57 --> Total execution time: 3.5807
INFO - 2018-04-11 21:45:57 --> Config Class Initialized
INFO - 2018-04-11 21:45:57 --> Hooks Class Initialized
DEBUG - 2018-04-11 21:45:57 --> UTF-8 Support Enabled
INFO - 2018-04-11 21:45:57 --> Utf8 Class Initialized
INFO - 2018-04-11 21:45:57 --> URI Class Initialized
INFO - 2018-04-11 21:45:57 --> Router Class Initialized
INFO - 2018-04-11 21:45:57 --> Output Class Initialized
INFO - 2018-04-11 21:45:57 --> Security Class Initialized
DEBUG - 2018-04-11 21:45:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 21:45:57 --> CSRF cookie sent
INFO - 2018-04-11 21:45:57 --> Input Class Initialized
INFO - 2018-04-11 21:45:57 --> Language Class Initialized
ERROR - 2018-04-11 21:45:57 --> 404 Page Not Found: Assets/css
INFO - 2018-04-11 21:55:28 --> Config Class Initialized
INFO - 2018-04-11 21:55:28 --> Hooks Class Initialized
DEBUG - 2018-04-11 21:55:28 --> UTF-8 Support Enabled
INFO - 2018-04-11 21:55:28 --> Utf8 Class Initialized
INFO - 2018-04-11 21:55:28 --> URI Class Initialized
INFO - 2018-04-11 21:55:28 --> Router Class Initialized
INFO - 2018-04-11 21:55:28 --> Output Class Initialized
INFO - 2018-04-11 21:55:28 --> Security Class Initialized
DEBUG - 2018-04-11 21:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 21:55:28 --> CSRF cookie sent
INFO - 2018-04-11 21:55:28 --> Input Class Initialized
INFO - 2018-04-11 21:55:28 --> Language Class Initialized
INFO - 2018-04-11 21:55:28 --> Loader Class Initialized
INFO - 2018-04-11 21:55:28 --> Helper loaded: url_helper
INFO - 2018-04-11 21:55:28 --> Helper loaded: form_helper
INFO - 2018-04-11 21:55:28 --> Helper loaded: language_helper
DEBUG - 2018-04-11 21:55:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 21:55:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 21:55:28 --> User Agent Class Initialized
INFO - 2018-04-11 21:55:28 --> Controller Class Initialized
INFO - 2018-04-11 21:55:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 21:55:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 21:55:28 --> Pixel_Model class loaded
INFO - 2018-04-11 21:55:28 --> Database Driver Class Initialized
INFO - 2018-04-11 21:55:31 --> Model "MyAccountModel" initialized
INFO - 2018-04-11 21:55:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-04-11 21:55:31 --> Pagination Class Initialized
INFO - 2018-04-11 21:55:31 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 21:55:31 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-11 21:55:31 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-11 21:55:31 --> Severity: Error --> Call to undefined method Smart::getStatusLabel() E:\www\yacopoo\application\views\myaccount\users_list.php 68
INFO - 2018-04-11 21:56:11 --> Config Class Initialized
INFO - 2018-04-11 21:56:11 --> Hooks Class Initialized
DEBUG - 2018-04-11 21:56:11 --> UTF-8 Support Enabled
INFO - 2018-04-11 21:56:11 --> Utf8 Class Initialized
INFO - 2018-04-11 21:56:11 --> URI Class Initialized
INFO - 2018-04-11 21:56:11 --> Router Class Initialized
INFO - 2018-04-11 21:56:11 --> Output Class Initialized
INFO - 2018-04-11 21:56:11 --> Security Class Initialized
DEBUG - 2018-04-11 21:56:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 21:56:11 --> CSRF cookie sent
INFO - 2018-04-11 21:56:11 --> Input Class Initialized
INFO - 2018-04-11 21:56:11 --> Language Class Initialized
INFO - 2018-04-11 21:56:11 --> Loader Class Initialized
INFO - 2018-04-11 21:56:11 --> Helper loaded: url_helper
INFO - 2018-04-11 21:56:11 --> Helper loaded: form_helper
INFO - 2018-04-11 21:56:11 --> Helper loaded: language_helper
DEBUG - 2018-04-11 21:56:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 21:56:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 21:56:11 --> User Agent Class Initialized
INFO - 2018-04-11 21:56:11 --> Controller Class Initialized
INFO - 2018-04-11 21:56:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 21:56:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 21:56:11 --> Pixel_Model class loaded
INFO - 2018-04-11 21:56:11 --> Database Driver Class Initialized
INFO - 2018-04-11 21:56:11 --> Model "MyAccountModel" initialized
INFO - 2018-04-11 21:56:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-04-11 21:56:11 --> Pagination Class Initialized
INFO - 2018-04-11 21:56:11 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 21:56:11 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-11 21:56:11 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-11 21:56:11 --> File loaded: E:\www\yacopoo\application\views\myaccount/users_list.php
INFO - 2018-04-11 21:56:11 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 21:56:11 --> Final output sent to browser
DEBUG - 2018-04-11 21:56:11 --> Total execution time: 0.4835
INFO - 2018-04-11 21:56:11 --> Config Class Initialized
INFO - 2018-04-11 21:56:12 --> Hooks Class Initialized
DEBUG - 2018-04-11 21:56:12 --> UTF-8 Support Enabled
INFO - 2018-04-11 21:56:12 --> Utf8 Class Initialized
INFO - 2018-04-11 21:56:12 --> URI Class Initialized
INFO - 2018-04-11 21:56:12 --> Router Class Initialized
INFO - 2018-04-11 21:56:12 --> Output Class Initialized
INFO - 2018-04-11 21:56:12 --> Security Class Initialized
DEBUG - 2018-04-11 21:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 21:56:12 --> CSRF cookie sent
INFO - 2018-04-11 21:56:12 --> Input Class Initialized
INFO - 2018-04-11 21:56:12 --> Language Class Initialized
ERROR - 2018-04-11 21:56:12 --> 404 Page Not Found: Assets/css
INFO - 2018-04-11 21:56:22 --> Config Class Initialized
INFO - 2018-04-11 21:56:22 --> Hooks Class Initialized
DEBUG - 2018-04-11 21:56:22 --> UTF-8 Support Enabled
INFO - 2018-04-11 21:56:22 --> Utf8 Class Initialized
INFO - 2018-04-11 21:56:22 --> URI Class Initialized
INFO - 2018-04-11 21:56:22 --> Router Class Initialized
INFO - 2018-04-11 21:56:22 --> Output Class Initialized
INFO - 2018-04-11 21:56:22 --> Security Class Initialized
DEBUG - 2018-04-11 21:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 21:56:22 --> CSRF cookie sent
INFO - 2018-04-11 21:56:22 --> Input Class Initialized
INFO - 2018-04-11 21:56:22 --> Language Class Initialized
INFO - 2018-04-11 21:56:22 --> Loader Class Initialized
INFO - 2018-04-11 21:56:22 --> Helper loaded: url_helper
INFO - 2018-04-11 21:56:22 --> Helper loaded: form_helper
INFO - 2018-04-11 21:56:22 --> Helper loaded: language_helper
DEBUG - 2018-04-11 21:56:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 21:56:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 21:56:23 --> User Agent Class Initialized
INFO - 2018-04-11 21:56:23 --> Controller Class Initialized
INFO - 2018-04-11 21:56:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 21:56:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 21:56:23 --> Pixel_Model class loaded
INFO - 2018-04-11 21:56:23 --> Database Driver Class Initialized
INFO - 2018-04-11 21:56:23 --> Model "MyAccountModel" initialized
INFO - 2018-04-11 21:56:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-04-11 21:56:23 --> Pagination Class Initialized
INFO - 2018-04-11 21:56:23 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 21:56:23 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-11 21:56:23 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-11 21:56:23 --> File loaded: E:\www\yacopoo\application\views\myaccount/users_list.php
INFO - 2018-04-11 21:56:23 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 21:56:23 --> Final output sent to browser
DEBUG - 2018-04-11 21:56:23 --> Total execution time: 0.5612
INFO - 2018-04-11 21:56:23 --> Config Class Initialized
INFO - 2018-04-11 21:56:23 --> Hooks Class Initialized
DEBUG - 2018-04-11 21:56:23 --> UTF-8 Support Enabled
INFO - 2018-04-11 21:56:23 --> Utf8 Class Initialized
INFO - 2018-04-11 21:56:23 --> URI Class Initialized
INFO - 2018-04-11 21:56:23 --> Router Class Initialized
INFO - 2018-04-11 21:56:23 --> Output Class Initialized
INFO - 2018-04-11 21:56:23 --> Security Class Initialized
DEBUG - 2018-04-11 21:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 21:56:23 --> CSRF cookie sent
INFO - 2018-04-11 21:56:23 --> Input Class Initialized
INFO - 2018-04-11 21:56:23 --> Language Class Initialized
ERROR - 2018-04-11 21:56:23 --> 404 Page Not Found: Assets/css
INFO - 2018-04-11 21:56:27 --> Config Class Initialized
INFO - 2018-04-11 21:56:27 --> Hooks Class Initialized
DEBUG - 2018-04-11 21:56:27 --> UTF-8 Support Enabled
INFO - 2018-04-11 21:56:27 --> Utf8 Class Initialized
INFO - 2018-04-11 21:56:27 --> URI Class Initialized
INFO - 2018-04-11 21:56:27 --> Router Class Initialized
INFO - 2018-04-11 21:56:27 --> Output Class Initialized
INFO - 2018-04-11 21:56:27 --> Security Class Initialized
DEBUG - 2018-04-11 21:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 21:56:27 --> CSRF cookie sent
INFO - 2018-04-11 21:56:27 --> Input Class Initialized
INFO - 2018-04-11 21:56:27 --> Language Class Initialized
INFO - 2018-04-11 21:56:27 --> Loader Class Initialized
INFO - 2018-04-11 21:56:27 --> Helper loaded: url_helper
INFO - 2018-04-11 21:56:27 --> Helper loaded: form_helper
INFO - 2018-04-11 21:56:27 --> Helper loaded: language_helper
DEBUG - 2018-04-11 21:56:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 21:56:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 21:56:28 --> User Agent Class Initialized
INFO - 2018-04-11 21:56:28 --> Controller Class Initialized
INFO - 2018-04-11 21:56:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 21:56:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 21:56:28 --> Pixel_Model class loaded
INFO - 2018-04-11 21:56:28 --> Database Driver Class Initialized
INFO - 2018-04-11 21:56:28 --> Model "MyAccountModel" initialized
INFO - 2018-04-11 21:56:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-04-11 21:56:28 --> Pagination Class Initialized
INFO - 2018-04-11 21:56:28 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 21:56:28 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-11 21:56:28 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-11 21:56:28 --> File loaded: E:\www\yacopoo\application\views\myaccount/users_list.php
INFO - 2018-04-11 21:56:28 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 21:56:28 --> Final output sent to browser
DEBUG - 2018-04-11 21:56:28 --> Total execution time: 0.5809
INFO - 2018-04-11 21:56:28 --> Config Class Initialized
INFO - 2018-04-11 21:56:28 --> Hooks Class Initialized
DEBUG - 2018-04-11 21:56:28 --> UTF-8 Support Enabled
INFO - 2018-04-11 21:56:28 --> Utf8 Class Initialized
INFO - 2018-04-11 21:56:28 --> URI Class Initialized
INFO - 2018-04-11 21:56:28 --> Router Class Initialized
INFO - 2018-04-11 21:56:28 --> Output Class Initialized
INFO - 2018-04-11 21:56:28 --> Security Class Initialized
DEBUG - 2018-04-11 21:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 21:56:28 --> CSRF cookie sent
INFO - 2018-04-11 21:56:28 --> Input Class Initialized
INFO - 2018-04-11 21:56:28 --> Language Class Initialized
ERROR - 2018-04-11 21:56:28 --> 404 Page Not Found: Assets/css
INFO - 2018-04-11 21:56:29 --> Config Class Initialized
INFO - 2018-04-11 21:56:29 --> Hooks Class Initialized
DEBUG - 2018-04-11 21:56:29 --> UTF-8 Support Enabled
INFO - 2018-04-11 21:56:29 --> Utf8 Class Initialized
INFO - 2018-04-11 21:56:29 --> URI Class Initialized
DEBUG - 2018-04-11 21:56:29 --> No URI present. Default controller set.
INFO - 2018-04-11 21:56:29 --> Router Class Initialized
INFO - 2018-04-11 21:56:29 --> Output Class Initialized
INFO - 2018-04-11 21:56:29 --> Security Class Initialized
DEBUG - 2018-04-11 21:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 21:56:29 --> CSRF cookie sent
INFO - 2018-04-11 21:56:29 --> Input Class Initialized
INFO - 2018-04-11 21:56:29 --> Language Class Initialized
INFO - 2018-04-11 21:56:29 --> Loader Class Initialized
INFO - 2018-04-11 21:56:29 --> Helper loaded: url_helper
INFO - 2018-04-11 21:56:29 --> Helper loaded: form_helper
INFO - 2018-04-11 21:56:29 --> Helper loaded: language_helper
DEBUG - 2018-04-11 21:56:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 21:56:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 21:56:29 --> User Agent Class Initialized
INFO - 2018-04-11 21:56:29 --> Controller Class Initialized
INFO - 2018-04-11 21:56:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 21:56:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 21:56:29 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 21:56:29 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-11 21:56:29 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 21:56:29 --> Final output sent to browser
DEBUG - 2018-04-11 21:56:29 --> Total execution time: 0.5068
INFO - 2018-04-11 21:56:30 --> Config Class Initialized
INFO - 2018-04-11 21:56:30 --> Hooks Class Initialized
DEBUG - 2018-04-11 21:56:30 --> UTF-8 Support Enabled
INFO - 2018-04-11 21:56:30 --> Utf8 Class Initialized
INFO - 2018-04-11 21:56:30 --> URI Class Initialized
INFO - 2018-04-11 21:56:30 --> Router Class Initialized
INFO - 2018-04-11 21:56:30 --> Output Class Initialized
INFO - 2018-04-11 21:56:30 --> Security Class Initialized
DEBUG - 2018-04-11 21:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 21:56:30 --> CSRF cookie sent
INFO - 2018-04-11 21:56:30 --> Input Class Initialized
INFO - 2018-04-11 21:56:30 --> Language Class Initialized
ERROR - 2018-04-11 21:56:30 --> 404 Page Not Found: Assets/css
INFO - 2018-04-11 21:56:31 --> Config Class Initialized
INFO - 2018-04-11 21:56:31 --> Hooks Class Initialized
DEBUG - 2018-04-11 21:56:31 --> UTF-8 Support Enabled
INFO - 2018-04-11 21:56:31 --> Utf8 Class Initialized
INFO - 2018-04-11 21:56:31 --> URI Class Initialized
INFO - 2018-04-11 21:56:31 --> Router Class Initialized
INFO - 2018-04-11 21:56:31 --> Output Class Initialized
INFO - 2018-04-11 21:56:31 --> Security Class Initialized
DEBUG - 2018-04-11 21:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 21:56:31 --> CSRF cookie sent
INFO - 2018-04-11 21:56:31 --> Input Class Initialized
INFO - 2018-04-11 21:56:31 --> Language Class Initialized
ERROR - 2018-04-11 21:56:31 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-11 21:56:32 --> Config Class Initialized
INFO - 2018-04-11 21:56:32 --> Hooks Class Initialized
DEBUG - 2018-04-11 21:56:32 --> UTF-8 Support Enabled
INFO - 2018-04-11 21:56:32 --> Utf8 Class Initialized
INFO - 2018-04-11 21:56:32 --> URI Class Initialized
INFO - 2018-04-11 21:56:32 --> Router Class Initialized
INFO - 2018-04-11 21:56:32 --> Output Class Initialized
INFO - 2018-04-11 21:56:32 --> Security Class Initialized
DEBUG - 2018-04-11 21:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 21:56:32 --> CSRF cookie sent
INFO - 2018-04-11 21:56:32 --> Input Class Initialized
INFO - 2018-04-11 21:56:32 --> Language Class Initialized
INFO - 2018-04-11 21:56:32 --> Loader Class Initialized
INFO - 2018-04-11 21:56:32 --> Helper loaded: url_helper
INFO - 2018-04-11 21:56:32 --> Helper loaded: form_helper
INFO - 2018-04-11 21:56:32 --> Helper loaded: language_helper
DEBUG - 2018-04-11 21:56:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 21:56:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 21:56:32 --> User Agent Class Initialized
INFO - 2018-04-11 21:56:32 --> Controller Class Initialized
INFO - 2018-04-11 21:56:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 21:56:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 21:56:32 --> CSRF cookie sent
INFO - 2018-04-11 21:56:32 --> Config Class Initialized
INFO - 2018-04-11 21:56:32 --> Hooks Class Initialized
DEBUG - 2018-04-11 21:56:32 --> UTF-8 Support Enabled
INFO - 2018-04-11 21:56:33 --> Utf8 Class Initialized
INFO - 2018-04-11 21:56:33 --> URI Class Initialized
DEBUG - 2018-04-11 21:56:33 --> No URI present. Default controller set.
INFO - 2018-04-11 21:56:33 --> Router Class Initialized
INFO - 2018-04-11 21:56:33 --> Output Class Initialized
INFO - 2018-04-11 21:56:33 --> Security Class Initialized
DEBUG - 2018-04-11 21:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 21:56:33 --> CSRF cookie sent
INFO - 2018-04-11 21:56:33 --> Input Class Initialized
INFO - 2018-04-11 21:56:33 --> Language Class Initialized
INFO - 2018-04-11 21:56:33 --> Loader Class Initialized
INFO - 2018-04-11 21:56:33 --> Helper loaded: url_helper
INFO - 2018-04-11 21:56:33 --> Helper loaded: form_helper
INFO - 2018-04-11 21:56:33 --> Helper loaded: language_helper
DEBUG - 2018-04-11 21:56:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 21:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 21:56:33 --> User Agent Class Initialized
INFO - 2018-04-11 21:56:33 --> Controller Class Initialized
INFO - 2018-04-11 21:56:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 21:56:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 21:56:33 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 21:56:33 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-11 21:56:33 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 21:56:33 --> Final output sent to browser
DEBUG - 2018-04-11 21:56:33 --> Total execution time: 0.5765
INFO - 2018-04-11 21:56:34 --> Config Class Initialized
INFO - 2018-04-11 21:56:34 --> Hooks Class Initialized
DEBUG - 2018-04-11 21:56:34 --> UTF-8 Support Enabled
INFO - 2018-04-11 21:56:34 --> Utf8 Class Initialized
INFO - 2018-04-11 21:56:34 --> URI Class Initialized
INFO - 2018-04-11 21:56:34 --> Router Class Initialized
INFO - 2018-04-11 21:56:34 --> Output Class Initialized
INFO - 2018-04-11 21:56:34 --> Security Class Initialized
DEBUG - 2018-04-11 21:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 21:56:35 --> CSRF cookie sent
INFO - 2018-04-11 21:56:35 --> Input Class Initialized
INFO - 2018-04-11 21:56:35 --> Language Class Initialized
ERROR - 2018-04-11 21:56:35 --> 404 Page Not Found: Assets/css
INFO - 2018-04-11 21:56:35 --> Config Class Initialized
INFO - 2018-04-11 21:56:35 --> Hooks Class Initialized
DEBUG - 2018-04-11 21:56:35 --> UTF-8 Support Enabled
INFO - 2018-04-11 21:56:35 --> Utf8 Class Initialized
INFO - 2018-04-11 21:56:35 --> URI Class Initialized
INFO - 2018-04-11 21:56:35 --> Router Class Initialized
INFO - 2018-04-11 21:56:35 --> Output Class Initialized
INFO - 2018-04-11 21:56:35 --> Security Class Initialized
DEBUG - 2018-04-11 21:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 21:56:35 --> CSRF cookie sent
INFO - 2018-04-11 21:56:35 --> Input Class Initialized
INFO - 2018-04-11 21:56:35 --> Language Class Initialized
ERROR - 2018-04-11 21:56:35 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-11 21:56:39 --> Config Class Initialized
INFO - 2018-04-11 21:56:39 --> Hooks Class Initialized
DEBUG - 2018-04-11 21:56:39 --> UTF-8 Support Enabled
INFO - 2018-04-11 21:56:39 --> Utf8 Class Initialized
INFO - 2018-04-11 21:56:39 --> URI Class Initialized
INFO - 2018-04-11 21:56:39 --> Router Class Initialized
INFO - 2018-04-11 21:56:39 --> Output Class Initialized
INFO - 2018-04-11 21:56:39 --> Security Class Initialized
DEBUG - 2018-04-11 21:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 21:56:39 --> CSRF cookie sent
INFO - 2018-04-11 21:56:39 --> Input Class Initialized
INFO - 2018-04-11 21:56:39 --> Language Class Initialized
INFO - 2018-04-11 21:56:39 --> Loader Class Initialized
INFO - 2018-04-11 21:56:39 --> Helper loaded: url_helper
INFO - 2018-04-11 21:56:39 --> Helper loaded: form_helper
INFO - 2018-04-11 21:56:39 --> Helper loaded: language_helper
DEBUG - 2018-04-11 21:56:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 21:56:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 21:56:39 --> User Agent Class Initialized
INFO - 2018-04-11 21:56:39 --> Controller Class Initialized
INFO - 2018-04-11 21:56:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 21:56:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 21:56:39 --> Pixel_Model class loaded
INFO - 2018-04-11 21:56:39 --> Database Driver Class Initialized
INFO - 2018-04-11 21:56:39 --> Model "RegistrationModel" initialized
DEBUG - 2018-04-11 21:56:39 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-11 21:56:39 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 21:56:39 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-11 21:56:39 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-11 21:56:39 --> Could not find the language line "req_email"
INFO - 2018-04-11 21:56:39 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-04-11 21:56:39 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 21:56:39 --> Final output sent to browser
DEBUG - 2018-04-11 21:56:39 --> Total execution time: 0.5244
INFO - 2018-04-11 21:56:40 --> Config Class Initialized
INFO - 2018-04-11 21:56:40 --> Hooks Class Initialized
DEBUG - 2018-04-11 21:56:40 --> UTF-8 Support Enabled
INFO - 2018-04-11 21:56:40 --> Utf8 Class Initialized
INFO - 2018-04-11 21:56:40 --> URI Class Initialized
INFO - 2018-04-11 21:56:40 --> Router Class Initialized
INFO - 2018-04-11 21:56:40 --> Output Class Initialized
INFO - 2018-04-11 21:56:40 --> Security Class Initialized
DEBUG - 2018-04-11 21:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 21:56:40 --> CSRF cookie sent
INFO - 2018-04-11 21:56:40 --> Input Class Initialized
INFO - 2018-04-11 21:56:40 --> Language Class Initialized
ERROR - 2018-04-11 21:56:40 --> 404 Page Not Found: Assets/css
INFO - 2018-04-11 21:58:23 --> Config Class Initialized
INFO - 2018-04-11 21:58:23 --> Hooks Class Initialized
DEBUG - 2018-04-11 21:58:24 --> UTF-8 Support Enabled
INFO - 2018-04-11 21:58:24 --> Utf8 Class Initialized
INFO - 2018-04-11 21:58:24 --> URI Class Initialized
INFO - 2018-04-11 21:58:24 --> Router Class Initialized
INFO - 2018-04-11 21:58:24 --> Output Class Initialized
INFO - 2018-04-11 21:58:24 --> Security Class Initialized
DEBUG - 2018-04-11 21:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 21:58:24 --> CSRF cookie sent
INFO - 2018-04-11 21:58:24 --> Input Class Initialized
INFO - 2018-04-11 21:58:24 --> Language Class Initialized
INFO - 2018-04-11 21:58:24 --> Loader Class Initialized
INFO - 2018-04-11 21:58:24 --> Helper loaded: url_helper
INFO - 2018-04-11 21:58:24 --> Helper loaded: form_helper
INFO - 2018-04-11 21:58:24 --> Helper loaded: language_helper
DEBUG - 2018-04-11 21:58:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 21:58:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 21:58:24 --> User Agent Class Initialized
INFO - 2018-04-11 21:58:24 --> Controller Class Initialized
INFO - 2018-04-11 21:58:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 21:58:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 21:58:24 --> Pixel_Model class loaded
INFO - 2018-04-11 21:58:24 --> Database Driver Class Initialized
INFO - 2018-04-11 21:58:27 --> Model "RegistrationModel" initialized
DEBUG - 2018-04-11 21:58:27 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-11 21:58:27 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 21:58:27 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-11 21:58:27 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-11 21:58:27 --> Could not find the language line "req_email"
INFO - 2018-04-11 21:58:27 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-04-11 21:58:27 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 21:58:27 --> Final output sent to browser
DEBUG - 2018-04-11 21:58:27 --> Total execution time: 3.4962
INFO - 2018-04-11 21:58:27 --> Config Class Initialized
INFO - 2018-04-11 21:58:27 --> Hooks Class Initialized
DEBUG - 2018-04-11 21:58:27 --> UTF-8 Support Enabled
INFO - 2018-04-11 21:58:27 --> Utf8 Class Initialized
INFO - 2018-04-11 21:58:27 --> URI Class Initialized
INFO - 2018-04-11 21:58:27 --> Router Class Initialized
INFO - 2018-04-11 21:58:28 --> Output Class Initialized
INFO - 2018-04-11 21:58:28 --> Security Class Initialized
DEBUG - 2018-04-11 21:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 21:58:28 --> CSRF cookie sent
INFO - 2018-04-11 21:58:28 --> Input Class Initialized
INFO - 2018-04-11 21:58:28 --> Language Class Initialized
ERROR - 2018-04-11 21:58:28 --> 404 Page Not Found: Assets/css
INFO - 2018-04-11 21:58:58 --> Config Class Initialized
INFO - 2018-04-11 21:58:58 --> Hooks Class Initialized
DEBUG - 2018-04-11 21:58:58 --> UTF-8 Support Enabled
INFO - 2018-04-11 21:58:58 --> Utf8 Class Initialized
INFO - 2018-04-11 21:58:58 --> URI Class Initialized
INFO - 2018-04-11 21:58:58 --> Router Class Initialized
INFO - 2018-04-11 21:58:58 --> Output Class Initialized
INFO - 2018-04-11 21:58:58 --> Security Class Initialized
DEBUG - 2018-04-11 21:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 21:58:58 --> CSRF cookie sent
INFO - 2018-04-11 21:58:58 --> Input Class Initialized
INFO - 2018-04-11 21:58:58 --> Language Class Initialized
INFO - 2018-04-11 21:58:58 --> Loader Class Initialized
INFO - 2018-04-11 21:58:58 --> Helper loaded: url_helper
INFO - 2018-04-11 21:58:58 --> Helper loaded: form_helper
INFO - 2018-04-11 21:58:58 --> Helper loaded: language_helper
DEBUG - 2018-04-11 21:58:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 21:58:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 21:58:58 --> User Agent Class Initialized
INFO - 2018-04-11 21:58:58 --> Controller Class Initialized
INFO - 2018-04-11 21:58:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 21:58:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 21:58:58 --> Pixel_Model class loaded
INFO - 2018-04-11 21:58:58 --> Database Driver Class Initialized
INFO - 2018-04-11 21:59:01 --> Model "RegistrationModel" initialized
DEBUG - 2018-04-11 21:59:01 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-11 21:59:01 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 21:59:01 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-11 21:59:01 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-11 21:59:01 --> Could not find the language line "req_email"
INFO - 2018-04-11 21:59:01 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-04-11 21:59:01 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 21:59:01 --> Final output sent to browser
DEBUG - 2018-04-11 21:59:01 --> Total execution time: 3.5834
INFO - 2018-04-11 21:59:02 --> Config Class Initialized
INFO - 2018-04-11 21:59:02 --> Hooks Class Initialized
DEBUG - 2018-04-11 21:59:02 --> UTF-8 Support Enabled
INFO - 2018-04-11 21:59:02 --> Utf8 Class Initialized
INFO - 2018-04-11 21:59:02 --> URI Class Initialized
INFO - 2018-04-11 21:59:02 --> Router Class Initialized
INFO - 2018-04-11 21:59:02 --> Output Class Initialized
INFO - 2018-04-11 21:59:02 --> Security Class Initialized
DEBUG - 2018-04-11 21:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 21:59:02 --> CSRF cookie sent
INFO - 2018-04-11 21:59:02 --> Input Class Initialized
INFO - 2018-04-11 21:59:02 --> Language Class Initialized
ERROR - 2018-04-11 21:59:02 --> 404 Page Not Found: Assets/css
INFO - 2018-04-11 21:59:17 --> Config Class Initialized
INFO - 2018-04-11 21:59:17 --> Hooks Class Initialized
DEBUG - 2018-04-11 21:59:17 --> UTF-8 Support Enabled
INFO - 2018-04-11 21:59:18 --> Utf8 Class Initialized
INFO - 2018-04-11 21:59:18 --> URI Class Initialized
INFO - 2018-04-11 21:59:18 --> Router Class Initialized
INFO - 2018-04-11 21:59:18 --> Output Class Initialized
INFO - 2018-04-11 21:59:18 --> Security Class Initialized
DEBUG - 2018-04-11 21:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 21:59:18 --> CSRF cookie sent
INFO - 2018-04-11 21:59:18 --> Input Class Initialized
INFO - 2018-04-11 21:59:18 --> Language Class Initialized
INFO - 2018-04-11 21:59:18 --> Loader Class Initialized
INFO - 2018-04-11 21:59:18 --> Helper loaded: url_helper
INFO - 2018-04-11 21:59:18 --> Helper loaded: form_helper
INFO - 2018-04-11 21:59:18 --> Helper loaded: language_helper
DEBUG - 2018-04-11 21:59:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 21:59:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 21:59:18 --> User Agent Class Initialized
INFO - 2018-04-11 21:59:18 --> Controller Class Initialized
INFO - 2018-04-11 21:59:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 21:59:18 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-11 21:59:18 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-11 21:59:18 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 21:59:18 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-11 21:59:18 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-11 21:59:18 --> Could not find the language line "req_email"
INFO - 2018-04-11 21:59:18 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-04-11 21:59:18 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 21:59:18 --> Final output sent to browser
DEBUG - 2018-04-11 21:59:18 --> Total execution time: 0.4772
INFO - 2018-04-11 21:59:18 --> Config Class Initialized
INFO - 2018-04-11 21:59:18 --> Hooks Class Initialized
DEBUG - 2018-04-11 21:59:18 --> UTF-8 Support Enabled
INFO - 2018-04-11 21:59:18 --> Utf8 Class Initialized
INFO - 2018-04-11 21:59:18 --> URI Class Initialized
INFO - 2018-04-11 21:59:18 --> Router Class Initialized
INFO - 2018-04-11 21:59:18 --> Output Class Initialized
INFO - 2018-04-11 21:59:19 --> Security Class Initialized
DEBUG - 2018-04-11 21:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 21:59:19 --> CSRF cookie sent
INFO - 2018-04-11 21:59:19 --> Input Class Initialized
INFO - 2018-04-11 21:59:19 --> Language Class Initialized
ERROR - 2018-04-11 21:59:19 --> 404 Page Not Found: Assets/css
INFO - 2018-04-11 21:59:57 --> Config Class Initialized
INFO - 2018-04-11 21:59:57 --> Hooks Class Initialized
DEBUG - 2018-04-11 21:59:57 --> UTF-8 Support Enabled
INFO - 2018-04-11 21:59:57 --> Utf8 Class Initialized
INFO - 2018-04-11 21:59:57 --> URI Class Initialized
INFO - 2018-04-11 21:59:57 --> Router Class Initialized
INFO - 2018-04-11 21:59:57 --> Output Class Initialized
INFO - 2018-04-11 21:59:57 --> Security Class Initialized
DEBUG - 2018-04-11 21:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 21:59:57 --> CSRF cookie sent
INFO - 2018-04-11 21:59:57 --> Input Class Initialized
INFO - 2018-04-11 21:59:57 --> Language Class Initialized
INFO - 2018-04-11 21:59:57 --> Loader Class Initialized
INFO - 2018-04-11 21:59:57 --> Helper loaded: url_helper
INFO - 2018-04-11 21:59:57 --> Helper loaded: form_helper
INFO - 2018-04-11 21:59:57 --> Helper loaded: language_helper
DEBUG - 2018-04-11 21:59:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 21:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 21:59:57 --> User Agent Class Initialized
INFO - 2018-04-11 21:59:57 --> Controller Class Initialized
INFO - 2018-04-11 21:59:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 21:59:57 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-11 21:59:57 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-11 21:59:57 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 21:59:57 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-11 21:59:57 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-11 21:59:57 --> Could not find the language line "req_email"
INFO - 2018-04-11 21:59:57 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-04-11 21:59:57 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 21:59:57 --> Final output sent to browser
DEBUG - 2018-04-11 21:59:57 --> Total execution time: 0.4779
INFO - 2018-04-11 21:59:58 --> Config Class Initialized
INFO - 2018-04-11 21:59:58 --> Hooks Class Initialized
DEBUG - 2018-04-11 21:59:58 --> UTF-8 Support Enabled
INFO - 2018-04-11 21:59:58 --> Utf8 Class Initialized
INFO - 2018-04-11 21:59:58 --> URI Class Initialized
INFO - 2018-04-11 21:59:58 --> Router Class Initialized
INFO - 2018-04-11 21:59:58 --> Output Class Initialized
INFO - 2018-04-11 21:59:58 --> Security Class Initialized
DEBUG - 2018-04-11 21:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 21:59:58 --> CSRF cookie sent
INFO - 2018-04-11 21:59:58 --> Input Class Initialized
INFO - 2018-04-11 21:59:58 --> Language Class Initialized
ERROR - 2018-04-11 21:59:58 --> 404 Page Not Found: Assets/css
INFO - 2018-04-11 22:00:33 --> Config Class Initialized
INFO - 2018-04-11 22:00:33 --> Hooks Class Initialized
DEBUG - 2018-04-11 22:00:33 --> UTF-8 Support Enabled
INFO - 2018-04-11 22:00:33 --> Utf8 Class Initialized
INFO - 2018-04-11 22:00:33 --> URI Class Initialized
INFO - 2018-04-11 22:00:33 --> Router Class Initialized
INFO - 2018-04-11 22:00:33 --> Output Class Initialized
INFO - 2018-04-11 22:00:33 --> Security Class Initialized
DEBUG - 2018-04-11 22:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:00:33 --> CSRF cookie sent
INFO - 2018-04-11 22:00:33 --> CSRF token verified
INFO - 2018-04-11 22:00:33 --> Input Class Initialized
INFO - 2018-04-11 22:00:33 --> Language Class Initialized
INFO - 2018-04-11 22:00:33 --> Loader Class Initialized
INFO - 2018-04-11 22:00:33 --> Helper loaded: url_helper
INFO - 2018-04-11 22:00:33 --> Helper loaded: form_helper
INFO - 2018-04-11 22:00:33 --> Helper loaded: language_helper
DEBUG - 2018-04-11 22:00:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 22:00:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 22:00:33 --> User Agent Class Initialized
INFO - 2018-04-11 22:00:33 --> Controller Class Initialized
INFO - 2018-04-11 22:00:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 22:00:33 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-11 22:00:33 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-11 22:00:33 --> Config Class Initialized
INFO - 2018-04-11 22:00:33 --> Hooks Class Initialized
DEBUG - 2018-04-11 22:00:33 --> UTF-8 Support Enabled
INFO - 2018-04-11 22:00:33 --> Utf8 Class Initialized
INFO - 2018-04-11 22:00:33 --> URI Class Initialized
INFO - 2018-04-11 22:00:33 --> Router Class Initialized
INFO - 2018-04-11 22:00:33 --> Output Class Initialized
INFO - 2018-04-11 22:00:33 --> Security Class Initialized
DEBUG - 2018-04-11 22:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:00:33 --> CSRF cookie sent
INFO - 2018-04-11 22:00:33 --> Input Class Initialized
INFO - 2018-04-11 22:00:33 --> Language Class Initialized
INFO - 2018-04-11 22:00:33 --> Loader Class Initialized
INFO - 2018-04-11 22:00:33 --> Helper loaded: url_helper
INFO - 2018-04-11 22:00:33 --> Helper loaded: form_helper
INFO - 2018-04-11 22:00:33 --> Helper loaded: language_helper
DEBUG - 2018-04-11 22:00:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 22:00:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 22:00:33 --> User Agent Class Initialized
INFO - 2018-04-11 22:00:33 --> Controller Class Initialized
INFO - 2018-04-11 22:00:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 22:00:33 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-11 22:00:33 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-11 22:00:33 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 22:00:33 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-11 22:00:33 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-11 22:00:34 --> File loaded: E:\www\yacopoo\application\views\shared/_soft_error.php
ERROR - 2018-04-11 22:00:34 --> Could not find the language line "req_email"
INFO - 2018-04-11 22:00:34 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-04-11 22:00:34 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 22:00:34 --> Final output sent to browser
DEBUG - 2018-04-11 22:00:34 --> Total execution time: 0.4941
INFO - 2018-04-11 22:00:34 --> Config Class Initialized
INFO - 2018-04-11 22:00:34 --> Hooks Class Initialized
DEBUG - 2018-04-11 22:00:34 --> UTF-8 Support Enabled
INFO - 2018-04-11 22:00:34 --> Utf8 Class Initialized
INFO - 2018-04-11 22:00:34 --> URI Class Initialized
INFO - 2018-04-11 22:00:34 --> Router Class Initialized
INFO - 2018-04-11 22:00:34 --> Output Class Initialized
INFO - 2018-04-11 22:00:34 --> Security Class Initialized
DEBUG - 2018-04-11 22:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:00:34 --> CSRF cookie sent
INFO - 2018-04-11 22:00:34 --> Input Class Initialized
INFO - 2018-04-11 22:00:34 --> Language Class Initialized
ERROR - 2018-04-11 22:00:34 --> 404 Page Not Found: Assets/css
INFO - 2018-04-11 22:00:47 --> Config Class Initialized
INFO - 2018-04-11 22:00:47 --> Hooks Class Initialized
DEBUG - 2018-04-11 22:00:47 --> UTF-8 Support Enabled
INFO - 2018-04-11 22:00:47 --> Utf8 Class Initialized
INFO - 2018-04-11 22:00:47 --> URI Class Initialized
INFO - 2018-04-11 22:00:47 --> Router Class Initialized
INFO - 2018-04-11 22:00:47 --> Output Class Initialized
INFO - 2018-04-11 22:00:47 --> Security Class Initialized
DEBUG - 2018-04-11 22:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:00:47 --> CSRF cookie sent
INFO - 2018-04-11 22:00:47 --> CSRF token verified
INFO - 2018-04-11 22:00:47 --> Input Class Initialized
INFO - 2018-04-11 22:00:47 --> Language Class Initialized
INFO - 2018-04-11 22:00:47 --> Loader Class Initialized
INFO - 2018-04-11 22:00:47 --> Helper loaded: url_helper
INFO - 2018-04-11 22:00:47 --> Helper loaded: form_helper
INFO - 2018-04-11 22:00:47 --> Helper loaded: language_helper
DEBUG - 2018-04-11 22:00:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 22:00:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 22:00:47 --> User Agent Class Initialized
INFO - 2018-04-11 22:00:47 --> Controller Class Initialized
INFO - 2018-04-11 22:00:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 22:00:47 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-11 22:00:47 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-11 22:00:48 --> Form Validation Class Initialized
INFO - 2018-04-11 22:00:48 --> Pixel_Model class loaded
INFO - 2018-04-11 22:00:48 --> Database Driver Class Initialized
INFO - 2018-04-11 22:00:48 --> Model "AuthenticationModel" initialized
INFO - 2018-04-11 22:00:48 --> Config Class Initialized
INFO - 2018-04-11 22:00:48 --> Hooks Class Initialized
DEBUG - 2018-04-11 22:00:48 --> UTF-8 Support Enabled
INFO - 2018-04-11 22:00:48 --> Utf8 Class Initialized
INFO - 2018-04-11 22:00:48 --> URI Class Initialized
DEBUG - 2018-04-11 22:00:48 --> No URI present. Default controller set.
INFO - 2018-04-11 22:00:48 --> Router Class Initialized
INFO - 2018-04-11 22:00:48 --> Output Class Initialized
INFO - 2018-04-11 22:00:48 --> Security Class Initialized
DEBUG - 2018-04-11 22:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:00:48 --> CSRF cookie sent
INFO - 2018-04-11 22:00:48 --> Input Class Initialized
INFO - 2018-04-11 22:00:48 --> Language Class Initialized
INFO - 2018-04-11 22:00:48 --> Loader Class Initialized
INFO - 2018-04-11 22:00:48 --> Helper loaded: url_helper
INFO - 2018-04-11 22:00:48 --> Helper loaded: form_helper
INFO - 2018-04-11 22:00:48 --> Helper loaded: language_helper
DEBUG - 2018-04-11 22:00:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 22:00:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 22:00:48 --> User Agent Class Initialized
INFO - 2018-04-11 22:00:48 --> Controller Class Initialized
INFO - 2018-04-11 22:00:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 22:00:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 22:00:48 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 22:00:48 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-11 22:00:48 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 22:00:48 --> Final output sent to browser
DEBUG - 2018-04-11 22:00:48 --> Total execution time: 0.3817
INFO - 2018-04-11 22:00:49 --> Config Class Initialized
INFO - 2018-04-11 22:00:49 --> Hooks Class Initialized
DEBUG - 2018-04-11 22:00:49 --> UTF-8 Support Enabled
INFO - 2018-04-11 22:00:49 --> Utf8 Class Initialized
INFO - 2018-04-11 22:00:49 --> URI Class Initialized
INFO - 2018-04-11 22:00:49 --> Router Class Initialized
INFO - 2018-04-11 22:00:49 --> Output Class Initialized
INFO - 2018-04-11 22:00:49 --> Security Class Initialized
DEBUG - 2018-04-11 22:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:00:49 --> CSRF cookie sent
INFO - 2018-04-11 22:00:49 --> Input Class Initialized
INFO - 2018-04-11 22:00:49 --> Language Class Initialized
ERROR - 2018-04-11 22:00:49 --> 404 Page Not Found: Assets/css
INFO - 2018-04-11 22:00:51 --> Config Class Initialized
INFO - 2018-04-11 22:00:51 --> Hooks Class Initialized
DEBUG - 2018-04-11 22:00:51 --> UTF-8 Support Enabled
INFO - 2018-04-11 22:00:51 --> Utf8 Class Initialized
INFO - 2018-04-11 22:00:51 --> URI Class Initialized
INFO - 2018-04-11 22:00:51 --> Router Class Initialized
INFO - 2018-04-11 22:00:51 --> Output Class Initialized
INFO - 2018-04-11 22:00:51 --> Security Class Initialized
DEBUG - 2018-04-11 22:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:00:51 --> CSRF cookie sent
INFO - 2018-04-11 22:00:51 --> Input Class Initialized
INFO - 2018-04-11 22:00:51 --> Language Class Initialized
ERROR - 2018-04-11 22:00:51 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-11 22:12:36 --> Config Class Initialized
INFO - 2018-04-11 22:12:36 --> Hooks Class Initialized
DEBUG - 2018-04-11 22:12:36 --> UTF-8 Support Enabled
INFO - 2018-04-11 22:12:36 --> Utf8 Class Initialized
INFO - 2018-04-11 22:12:36 --> URI Class Initialized
INFO - 2018-04-11 22:12:36 --> Router Class Initialized
INFO - 2018-04-11 22:12:36 --> Output Class Initialized
INFO - 2018-04-11 22:12:36 --> Security Class Initialized
DEBUG - 2018-04-11 22:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:12:36 --> CSRF cookie sent
INFO - 2018-04-11 22:12:36 --> Input Class Initialized
INFO - 2018-04-11 22:12:36 --> Language Class Initialized
INFO - 2018-04-11 22:12:36 --> Loader Class Initialized
INFO - 2018-04-11 22:12:36 --> Helper loaded: url_helper
INFO - 2018-04-11 22:12:36 --> Helper loaded: form_helper
INFO - 2018-04-11 22:12:36 --> Helper loaded: language_helper
DEBUG - 2018-04-11 22:12:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 22:12:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 22:12:36 --> User Agent Class Initialized
INFO - 2018-04-11 22:12:36 --> Controller Class Initialized
INFO - 2018-04-11 22:12:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 22:12:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 22:12:36 --> Pixel_Model class loaded
INFO - 2018-04-11 22:12:36 --> Database Driver Class Initialized
INFO - 2018-04-11 22:12:39 --> Model "MyAccountModel" initialized
INFO - 2018-04-11 22:12:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-04-11 22:12:39 --> Pagination Class Initialized
INFO - 2018-04-11 22:12:39 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 22:12:39 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-11 22:12:39 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-11 22:12:39 --> File loaded: E:\www\yacopoo\application\views\myaccount/users_list.php
INFO - 2018-04-11 22:12:39 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 22:12:39 --> Final output sent to browser
DEBUG - 2018-04-11 22:12:39 --> Total execution time: 3.5775
INFO - 2018-04-11 22:12:40 --> Config Class Initialized
INFO - 2018-04-11 22:12:40 --> Hooks Class Initialized
DEBUG - 2018-04-11 22:12:40 --> UTF-8 Support Enabled
INFO - 2018-04-11 22:12:40 --> Utf8 Class Initialized
INFO - 2018-04-11 22:12:40 --> URI Class Initialized
INFO - 2018-04-11 22:12:40 --> Router Class Initialized
INFO - 2018-04-11 22:12:40 --> Output Class Initialized
INFO - 2018-04-11 22:12:40 --> Security Class Initialized
DEBUG - 2018-04-11 22:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:12:40 --> CSRF cookie sent
INFO - 2018-04-11 22:12:40 --> Input Class Initialized
INFO - 2018-04-11 22:12:40 --> Language Class Initialized
ERROR - 2018-04-11 22:12:40 --> 404 Page Not Found: Assets/css
INFO - 2018-04-11 22:12:42 --> Config Class Initialized
INFO - 2018-04-11 22:12:42 --> Hooks Class Initialized
DEBUG - 2018-04-11 22:12:42 --> UTF-8 Support Enabled
INFO - 2018-04-11 22:12:42 --> Utf8 Class Initialized
INFO - 2018-04-11 22:12:42 --> URI Class Initialized
INFO - 2018-04-11 22:12:42 --> Router Class Initialized
INFO - 2018-04-11 22:12:42 --> Output Class Initialized
INFO - 2018-04-11 22:12:42 --> Security Class Initialized
DEBUG - 2018-04-11 22:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:12:42 --> CSRF cookie sent
INFO - 2018-04-11 22:12:42 --> Input Class Initialized
INFO - 2018-04-11 22:12:42 --> Language Class Initialized
INFO - 2018-04-11 22:12:42 --> Loader Class Initialized
INFO - 2018-04-11 22:12:42 --> Helper loaded: url_helper
INFO - 2018-04-11 22:12:42 --> Helper loaded: form_helper
INFO - 2018-04-11 22:12:42 --> Helper loaded: language_helper
DEBUG - 2018-04-11 22:12:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 22:12:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 22:12:42 --> User Agent Class Initialized
INFO - 2018-04-11 22:12:42 --> Controller Class Initialized
INFO - 2018-04-11 22:12:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 22:12:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 22:12:42 --> Pixel_Model class loaded
INFO - 2018-04-11 22:12:42 --> Database Driver Class Initialized
INFO - 2018-04-11 22:12:42 --> Model "MyAccountModel" initialized
INFO - 2018-04-11 22:12:42 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 22:12:42 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-11 22:12:42 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-11 22:12:42 --> File loaded: E:\www\yacopoo\application\views\myaccount/edit_user.php
INFO - 2018-04-11 22:12:43 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 22:12:43 --> Final output sent to browser
DEBUG - 2018-04-11 22:12:43 --> Total execution time: 0.4936
INFO - 2018-04-11 22:12:43 --> Config Class Initialized
INFO - 2018-04-11 22:12:43 --> Hooks Class Initialized
DEBUG - 2018-04-11 22:12:43 --> UTF-8 Support Enabled
INFO - 2018-04-11 22:12:43 --> Utf8 Class Initialized
INFO - 2018-04-11 22:12:43 --> URI Class Initialized
INFO - 2018-04-11 22:12:43 --> Router Class Initialized
INFO - 2018-04-11 22:12:43 --> Output Class Initialized
INFO - 2018-04-11 22:12:43 --> Security Class Initialized
DEBUG - 2018-04-11 22:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:12:43 --> CSRF cookie sent
INFO - 2018-04-11 22:12:43 --> Input Class Initialized
INFO - 2018-04-11 22:12:43 --> Language Class Initialized
ERROR - 2018-04-11 22:12:43 --> 404 Page Not Found: Assets/css
INFO - 2018-04-11 22:12:43 --> Config Class Initialized
INFO - 2018-04-11 22:12:43 --> Config Class Initialized
INFO - 2018-04-11 22:12:43 --> Hooks Class Initialized
INFO - 2018-04-11 22:12:43 --> Config Class Initialized
INFO - 2018-04-11 22:12:43 --> Hooks Class Initialized
INFO - 2018-04-11 22:12:43 --> Hooks Class Initialized
DEBUG - 2018-04-11 22:12:43 --> UTF-8 Support Enabled
INFO - 2018-04-11 22:12:43 --> Utf8 Class Initialized
DEBUG - 2018-04-11 22:12:43 --> UTF-8 Support Enabled
DEBUG - 2018-04-11 22:12:43 --> UTF-8 Support Enabled
INFO - 2018-04-11 22:12:43 --> Utf8 Class Initialized
INFO - 2018-04-11 22:12:43 --> Utf8 Class Initialized
INFO - 2018-04-11 22:12:43 --> URI Class Initialized
INFO - 2018-04-11 22:12:44 --> URI Class Initialized
INFO - 2018-04-11 22:12:44 --> URI Class Initialized
INFO - 2018-04-11 22:12:44 --> Router Class Initialized
INFO - 2018-04-11 22:12:44 --> Output Class Initialized
INFO - 2018-04-11 22:12:44 --> Router Class Initialized
INFO - 2018-04-11 22:12:44 --> Router Class Initialized
INFO - 2018-04-11 22:12:44 --> Security Class Initialized
INFO - 2018-04-11 22:12:44 --> Output Class Initialized
INFO - 2018-04-11 22:12:44 --> Output Class Initialized
DEBUG - 2018-04-11 22:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:12:44 --> Security Class Initialized
INFO - 2018-04-11 22:12:44 --> Security Class Initialized
INFO - 2018-04-11 22:12:44 --> CSRF cookie sent
DEBUG - 2018-04-11 22:12:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-11 22:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:12:44 --> Input Class Initialized
INFO - 2018-04-11 22:12:44 --> CSRF cookie sent
INFO - 2018-04-11 22:12:44 --> CSRF cookie sent
INFO - 2018-04-11 22:12:44 --> Language Class Initialized
INFO - 2018-04-11 22:12:44 --> Input Class Initialized
INFO - 2018-04-11 22:12:44 --> Input Class Initialized
ERROR - 2018-04-11 22:12:44 --> 404 Page Not Found: Edit-user/assets
INFO - 2018-04-11 22:12:44 --> Language Class Initialized
INFO - 2018-04-11 22:12:44 --> Language Class Initialized
ERROR - 2018-04-11 22:12:44 --> 404 Page Not Found: Edit-user/assets
ERROR - 2018-04-11 22:12:44 --> 404 Page Not Found: Edit-user/assets
INFO - 2018-04-11 22:13:28 --> Config Class Initialized
INFO - 2018-04-11 22:13:28 --> Hooks Class Initialized
DEBUG - 2018-04-11 22:13:28 --> UTF-8 Support Enabled
INFO - 2018-04-11 22:13:28 --> Utf8 Class Initialized
INFO - 2018-04-11 22:13:28 --> URI Class Initialized
INFO - 2018-04-11 22:13:28 --> Router Class Initialized
INFO - 2018-04-11 22:13:28 --> Output Class Initialized
INFO - 2018-04-11 22:13:28 --> Security Class Initialized
DEBUG - 2018-04-11 22:13:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:13:28 --> CSRF cookie sent
INFO - 2018-04-11 22:13:28 --> Input Class Initialized
INFO - 2018-04-11 22:13:28 --> Language Class Initialized
INFO - 2018-04-11 22:13:28 --> Loader Class Initialized
INFO - 2018-04-11 22:13:28 --> Helper loaded: url_helper
INFO - 2018-04-11 22:13:28 --> Helper loaded: form_helper
INFO - 2018-04-11 22:13:28 --> Helper loaded: language_helper
DEBUG - 2018-04-11 22:13:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 22:13:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 22:13:28 --> User Agent Class Initialized
INFO - 2018-04-11 22:13:28 --> Controller Class Initialized
INFO - 2018-04-11 22:13:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 22:13:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 22:13:28 --> Pixel_Model class loaded
INFO - 2018-04-11 22:13:28 --> Database Driver Class Initialized
INFO - 2018-04-11 22:13:31 --> Model "MyAccountModel" initialized
INFO - 2018-04-11 22:13:31 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 22:13:31 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-11 22:13:31 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-11 22:13:31 --> File loaded: E:\www\yacopoo\application\views\myaccount/edit_user.php
INFO - 2018-04-11 22:13:31 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 22:13:32 --> Final output sent to browser
DEBUG - 2018-04-11 22:13:32 --> Total execution time: 3.5371
INFO - 2018-04-11 22:13:32 --> Config Class Initialized
INFO - 2018-04-11 22:13:32 --> Hooks Class Initialized
DEBUG - 2018-04-11 22:13:32 --> UTF-8 Support Enabled
INFO - 2018-04-11 22:13:32 --> Utf8 Class Initialized
INFO - 2018-04-11 22:13:32 --> URI Class Initialized
INFO - 2018-04-11 22:13:32 --> Router Class Initialized
INFO - 2018-04-11 22:13:32 --> Output Class Initialized
INFO - 2018-04-11 22:13:32 --> Security Class Initialized
DEBUG - 2018-04-11 22:13:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:13:32 --> CSRF cookie sent
INFO - 2018-04-11 22:13:32 --> Input Class Initialized
INFO - 2018-04-11 22:13:32 --> Language Class Initialized
INFO - 2018-04-11 22:13:32 --> Config Class Initialized
ERROR - 2018-04-11 22:13:32 --> 404 Page Not Found: Assets/css
INFO - 2018-04-11 22:13:32 --> Config Class Initialized
INFO - 2018-04-11 22:13:32 --> Config Class Initialized
INFO - 2018-04-11 22:13:32 --> Hooks Class Initialized
INFO - 2018-04-11 22:13:32 --> Hooks Class Initialized
INFO - 2018-04-11 22:13:32 --> Hooks Class Initialized
DEBUG - 2018-04-11 22:13:32 --> UTF-8 Support Enabled
DEBUG - 2018-04-11 22:13:32 --> UTF-8 Support Enabled
DEBUG - 2018-04-11 22:13:32 --> UTF-8 Support Enabled
INFO - 2018-04-11 22:13:32 --> Utf8 Class Initialized
INFO - 2018-04-11 22:13:32 --> Utf8 Class Initialized
INFO - 2018-04-11 22:13:32 --> Utf8 Class Initialized
INFO - 2018-04-11 22:13:32 --> URI Class Initialized
INFO - 2018-04-11 22:13:32 --> URI Class Initialized
INFO - 2018-04-11 22:13:32 --> URI Class Initialized
INFO - 2018-04-11 22:13:32 --> Router Class Initialized
INFO - 2018-04-11 22:13:32 --> Router Class Initialized
INFO - 2018-04-11 22:13:32 --> Router Class Initialized
INFO - 2018-04-11 22:13:32 --> Output Class Initialized
INFO - 2018-04-11 22:13:32 --> Output Class Initialized
INFO - 2018-04-11 22:13:32 --> Output Class Initialized
INFO - 2018-04-11 22:13:32 --> Security Class Initialized
INFO - 2018-04-11 22:13:32 --> Security Class Initialized
INFO - 2018-04-11 22:13:32 --> Security Class Initialized
DEBUG - 2018-04-11 22:13:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-11 22:13:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-11 22:13:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:13:32 --> CSRF cookie sent
INFO - 2018-04-11 22:13:32 --> CSRF cookie sent
INFO - 2018-04-11 22:13:32 --> CSRF cookie sent
INFO - 2018-04-11 22:13:32 --> Input Class Initialized
INFO - 2018-04-11 22:13:32 --> Input Class Initialized
INFO - 2018-04-11 22:13:32 --> Input Class Initialized
INFO - 2018-04-11 22:13:32 --> Language Class Initialized
INFO - 2018-04-11 22:13:32 --> Language Class Initialized
INFO - 2018-04-11 22:13:32 --> Language Class Initialized
ERROR - 2018-04-11 22:13:32 --> 404 Page Not Found: Edit-user/assets
ERROR - 2018-04-11 22:13:32 --> 404 Page Not Found: Edit-user/assets
ERROR - 2018-04-11 22:13:32 --> 404 Page Not Found: Edit-user/assets
INFO - 2018-04-11 22:14:01 --> Config Class Initialized
INFO - 2018-04-11 22:14:01 --> Hooks Class Initialized
DEBUG - 2018-04-11 22:14:01 --> UTF-8 Support Enabled
INFO - 2018-04-11 22:14:01 --> Utf8 Class Initialized
INFO - 2018-04-11 22:14:01 --> URI Class Initialized
INFO - 2018-04-11 22:14:01 --> Router Class Initialized
INFO - 2018-04-11 22:14:01 --> Output Class Initialized
INFO - 2018-04-11 22:14:01 --> Security Class Initialized
DEBUG - 2018-04-11 22:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:14:01 --> CSRF cookie sent
INFO - 2018-04-11 22:14:01 --> Input Class Initialized
INFO - 2018-04-11 22:14:01 --> Language Class Initialized
INFO - 2018-04-11 22:14:01 --> Loader Class Initialized
INFO - 2018-04-11 22:14:01 --> Helper loaded: url_helper
INFO - 2018-04-11 22:14:01 --> Helper loaded: form_helper
INFO - 2018-04-11 22:14:01 --> Helper loaded: language_helper
DEBUG - 2018-04-11 22:14:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 22:14:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 22:14:01 --> User Agent Class Initialized
INFO - 2018-04-11 22:14:01 --> Controller Class Initialized
INFO - 2018-04-11 22:14:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 22:14:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 22:14:01 --> Pixel_Model class loaded
INFO - 2018-04-11 22:14:01 --> Database Driver Class Initialized
INFO - 2018-04-11 22:14:01 --> Model "MyAccountModel" initialized
INFO - 2018-04-11 22:14:01 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 22:14:01 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-11 22:14:01 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-11 22:14:01 --> File loaded: E:\www\yacopoo\application\views\myaccount/edit_user.php
INFO - 2018-04-11 22:14:01 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 22:14:01 --> Final output sent to browser
DEBUG - 2018-04-11 22:14:01 --> Total execution time: 0.4962
INFO - 2018-04-11 22:14:02 --> Config Class Initialized
INFO - 2018-04-11 22:14:02 --> Hooks Class Initialized
DEBUG - 2018-04-11 22:14:02 --> UTF-8 Support Enabled
INFO - 2018-04-11 22:14:02 --> Utf8 Class Initialized
INFO - 2018-04-11 22:14:02 --> URI Class Initialized
INFO - 2018-04-11 22:14:02 --> Router Class Initialized
INFO - 2018-04-11 22:14:02 --> Output Class Initialized
INFO - 2018-04-11 22:14:02 --> Security Class Initialized
DEBUG - 2018-04-11 22:14:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:14:02 --> CSRF cookie sent
INFO - 2018-04-11 22:14:02 --> Input Class Initialized
INFO - 2018-04-11 22:14:02 --> Language Class Initialized
ERROR - 2018-04-11 22:14:02 --> 404 Page Not Found: Assets/css
INFO - 2018-04-11 22:14:02 --> Config Class Initialized
INFO - 2018-04-11 22:14:02 --> Config Class Initialized
INFO - 2018-04-11 22:14:02 --> Config Class Initialized
INFO - 2018-04-11 22:14:02 --> Hooks Class Initialized
INFO - 2018-04-11 22:14:02 --> Hooks Class Initialized
INFO - 2018-04-11 22:14:02 --> Hooks Class Initialized
DEBUG - 2018-04-11 22:14:02 --> UTF-8 Support Enabled
DEBUG - 2018-04-11 22:14:02 --> UTF-8 Support Enabled
DEBUG - 2018-04-11 22:14:02 --> UTF-8 Support Enabled
INFO - 2018-04-11 22:14:02 --> Utf8 Class Initialized
INFO - 2018-04-11 22:14:02 --> Utf8 Class Initialized
INFO - 2018-04-11 22:14:02 --> Utf8 Class Initialized
INFO - 2018-04-11 22:14:02 --> URI Class Initialized
INFO - 2018-04-11 22:14:02 --> URI Class Initialized
INFO - 2018-04-11 22:14:02 --> URI Class Initialized
INFO - 2018-04-11 22:14:02 --> Router Class Initialized
INFO - 2018-04-11 22:14:02 --> Router Class Initialized
INFO - 2018-04-11 22:14:02 --> Router Class Initialized
INFO - 2018-04-11 22:14:02 --> Output Class Initialized
INFO - 2018-04-11 22:14:02 --> Output Class Initialized
INFO - 2018-04-11 22:14:02 --> Output Class Initialized
INFO - 2018-04-11 22:14:02 --> Security Class Initialized
INFO - 2018-04-11 22:14:02 --> Security Class Initialized
INFO - 2018-04-11 22:14:02 --> Security Class Initialized
DEBUG - 2018-04-11 22:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-11 22:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-11 22:14:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:14:02 --> CSRF cookie sent
INFO - 2018-04-11 22:14:02 --> CSRF cookie sent
INFO - 2018-04-11 22:14:02 --> CSRF cookie sent
INFO - 2018-04-11 22:14:02 --> Input Class Initialized
INFO - 2018-04-11 22:14:02 --> Input Class Initialized
INFO - 2018-04-11 22:14:02 --> Input Class Initialized
INFO - 2018-04-11 22:14:02 --> Language Class Initialized
INFO - 2018-04-11 22:14:02 --> Language Class Initialized
INFO - 2018-04-11 22:14:02 --> Language Class Initialized
ERROR - 2018-04-11 22:14:02 --> 404 Page Not Found: Edit-user/assets
ERROR - 2018-04-11 22:14:02 --> 404 Page Not Found: Edit-user/assets
ERROR - 2018-04-11 22:14:02 --> 404 Page Not Found: Edit-user/assets
INFO - 2018-04-11 22:15:49 --> Config Class Initialized
INFO - 2018-04-11 22:15:49 --> Hooks Class Initialized
DEBUG - 2018-04-11 22:15:49 --> UTF-8 Support Enabled
INFO - 2018-04-11 22:15:49 --> Utf8 Class Initialized
INFO - 2018-04-11 22:15:49 --> URI Class Initialized
INFO - 2018-04-11 22:15:49 --> Router Class Initialized
INFO - 2018-04-11 22:15:49 --> Output Class Initialized
INFO - 2018-04-11 22:15:49 --> Security Class Initialized
DEBUG - 2018-04-11 22:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:15:49 --> CSRF cookie sent
INFO - 2018-04-11 22:15:49 --> Input Class Initialized
INFO - 2018-04-11 22:15:49 --> Language Class Initialized
INFO - 2018-04-11 22:15:49 --> Loader Class Initialized
INFO - 2018-04-11 22:15:49 --> Helper loaded: url_helper
INFO - 2018-04-11 22:15:49 --> Helper loaded: form_helper
INFO - 2018-04-11 22:15:49 --> Helper loaded: language_helper
DEBUG - 2018-04-11 22:15:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 22:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 22:15:49 --> User Agent Class Initialized
INFO - 2018-04-11 22:15:49 --> Controller Class Initialized
INFO - 2018-04-11 22:15:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 22:15:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 22:15:49 --> Pixel_Model class loaded
INFO - 2018-04-11 22:15:49 --> Database Driver Class Initialized
INFO - 2018-04-11 22:15:52 --> Model "MyAccountModel" initialized
INFO - 2018-04-11 22:15:52 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 22:15:52 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-11 22:15:52 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-11 22:15:52 --> Could not find the language line "req_email"
ERROR - 2018-04-11 22:15:52 --> Severity: Notice --> Undefined variable: provinces E:\www\yacopoo\application\views\myaccount\edit_user.php 78
INFO - 2018-04-11 22:15:52 --> File loaded: E:\www\yacopoo\application\views\myaccount/edit_user.php
INFO - 2018-04-11 22:15:52 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 22:15:52 --> Final output sent to browser
DEBUG - 2018-04-11 22:15:53 --> Total execution time: 3.5443
INFO - 2018-04-11 22:15:53 --> Config Class Initialized
INFO - 2018-04-11 22:15:53 --> Hooks Class Initialized
DEBUG - 2018-04-11 22:15:53 --> UTF-8 Support Enabled
INFO - 2018-04-11 22:15:53 --> Utf8 Class Initialized
INFO - 2018-04-11 22:15:53 --> URI Class Initialized
INFO - 2018-04-11 22:15:53 --> Router Class Initialized
INFO - 2018-04-11 22:15:53 --> Output Class Initialized
INFO - 2018-04-11 22:15:53 --> Security Class Initialized
DEBUG - 2018-04-11 22:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:15:53 --> CSRF cookie sent
INFO - 2018-04-11 22:15:53 --> Input Class Initialized
INFO - 2018-04-11 22:15:53 --> Language Class Initialized
ERROR - 2018-04-11 22:15:53 --> 404 Page Not Found: Assets/css
INFO - 2018-04-11 22:15:53 --> Config Class Initialized
INFO - 2018-04-11 22:15:53 --> Config Class Initialized
INFO - 2018-04-11 22:15:53 --> Config Class Initialized
INFO - 2018-04-11 22:15:53 --> Config Class Initialized
INFO - 2018-04-11 22:15:53 --> Hooks Class Initialized
INFO - 2018-04-11 22:15:53 --> Hooks Class Initialized
INFO - 2018-04-11 22:15:53 --> Hooks Class Initialized
INFO - 2018-04-11 22:15:53 --> Hooks Class Initialized
DEBUG - 2018-04-11 22:15:54 --> UTF-8 Support Enabled
DEBUG - 2018-04-11 22:15:54 --> UTF-8 Support Enabled
DEBUG - 2018-04-11 22:15:54 --> UTF-8 Support Enabled
DEBUG - 2018-04-11 22:15:54 --> UTF-8 Support Enabled
INFO - 2018-04-11 22:15:54 --> Utf8 Class Initialized
INFO - 2018-04-11 22:15:54 --> Utf8 Class Initialized
INFO - 2018-04-11 22:15:54 --> Utf8 Class Initialized
INFO - 2018-04-11 22:15:54 --> Utf8 Class Initialized
INFO - 2018-04-11 22:15:54 --> URI Class Initialized
INFO - 2018-04-11 22:15:54 --> URI Class Initialized
INFO - 2018-04-11 22:15:54 --> URI Class Initialized
INFO - 2018-04-11 22:15:54 --> URI Class Initialized
INFO - 2018-04-11 22:15:54 --> Router Class Initialized
INFO - 2018-04-11 22:15:54 --> Router Class Initialized
INFO - 2018-04-11 22:15:54 --> Router Class Initialized
INFO - 2018-04-11 22:15:54 --> Router Class Initialized
INFO - 2018-04-11 22:15:54 --> Output Class Initialized
INFO - 2018-04-11 22:15:54 --> Output Class Initialized
INFO - 2018-04-11 22:15:54 --> Output Class Initialized
INFO - 2018-04-11 22:15:54 --> Output Class Initialized
INFO - 2018-04-11 22:15:54 --> Security Class Initialized
INFO - 2018-04-11 22:15:54 --> Security Class Initialized
INFO - 2018-04-11 22:15:54 --> Security Class Initialized
INFO - 2018-04-11 22:15:54 --> Security Class Initialized
DEBUG - 2018-04-11 22:15:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-11 22:15:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-11 22:15:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-11 22:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:15:54 --> CSRF cookie sent
INFO - 2018-04-11 22:15:54 --> CSRF cookie sent
INFO - 2018-04-11 22:15:54 --> CSRF cookie sent
INFO - 2018-04-11 22:15:54 --> CSRF cookie sent
INFO - 2018-04-11 22:15:54 --> Input Class Initialized
INFO - 2018-04-11 22:15:54 --> Input Class Initialized
INFO - 2018-04-11 22:15:54 --> Input Class Initialized
INFO - 2018-04-11 22:15:54 --> Input Class Initialized
INFO - 2018-04-11 22:15:54 --> Language Class Initialized
INFO - 2018-04-11 22:15:54 --> Language Class Initialized
INFO - 2018-04-11 22:15:54 --> Language Class Initialized
INFO - 2018-04-11 22:15:54 --> Language Class Initialized
ERROR - 2018-04-11 22:15:54 --> 404 Page Not Found: Edit-user/assets
ERROR - 2018-04-11 22:15:54 --> 404 Page Not Found: Edit-user/assets
ERROR - 2018-04-11 22:15:54 --> 404 Page Not Found: Edit-user/assets
ERROR - 2018-04-11 22:15:54 --> 404 Page Not Found: Edit-user/assets
INFO - 2018-04-11 22:19:11 --> Config Class Initialized
INFO - 2018-04-11 22:19:11 --> Hooks Class Initialized
DEBUG - 2018-04-11 22:19:11 --> UTF-8 Support Enabled
INFO - 2018-04-11 22:19:11 --> Utf8 Class Initialized
INFO - 2018-04-11 22:19:11 --> URI Class Initialized
INFO - 2018-04-11 22:19:11 --> Router Class Initialized
INFO - 2018-04-11 22:19:11 --> Output Class Initialized
INFO - 2018-04-11 22:19:11 --> Security Class Initialized
DEBUG - 2018-04-11 22:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:19:11 --> CSRF cookie sent
INFO - 2018-04-11 22:19:11 --> Input Class Initialized
INFO - 2018-04-11 22:19:11 --> Language Class Initialized
INFO - 2018-04-11 22:19:11 --> Loader Class Initialized
INFO - 2018-04-11 22:19:11 --> Helper loaded: url_helper
INFO - 2018-04-11 22:19:11 --> Helper loaded: form_helper
INFO - 2018-04-11 22:19:11 --> Helper loaded: language_helper
DEBUG - 2018-04-11 22:19:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 22:19:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 22:19:11 --> User Agent Class Initialized
INFO - 2018-04-11 22:19:11 --> Controller Class Initialized
INFO - 2018-04-11 22:19:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 22:19:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 22:19:11 --> Pixel_Model class loaded
INFO - 2018-04-11 22:19:11 --> Database Driver Class Initialized
INFO - 2018-04-11 22:19:14 --> Model "MyAccountModel" initialized
INFO - 2018-04-11 22:19:14 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 22:19:14 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-11 22:19:14 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-11 22:19:14 --> Severity: Notice --> Undefined variable: provinces E:\www\yacopoo\application\views\myaccount\edit_user.php 57
INFO - 2018-04-11 22:19:14 --> File loaded: E:\www\yacopoo\application\views\myaccount/edit_user.php
INFO - 2018-04-11 22:19:14 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 22:19:14 --> Final output sent to browser
DEBUG - 2018-04-11 22:19:14 --> Total execution time: 3.5422
INFO - 2018-04-11 22:19:15 --> Config Class Initialized
INFO - 2018-04-11 22:19:15 --> Hooks Class Initialized
DEBUG - 2018-04-11 22:19:15 --> UTF-8 Support Enabled
INFO - 2018-04-11 22:19:15 --> Utf8 Class Initialized
INFO - 2018-04-11 22:19:15 --> URI Class Initialized
INFO - 2018-04-11 22:19:15 --> Router Class Initialized
INFO - 2018-04-11 22:19:15 --> Output Class Initialized
INFO - 2018-04-11 22:19:15 --> Security Class Initialized
DEBUG - 2018-04-11 22:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:19:15 --> CSRF cookie sent
INFO - 2018-04-11 22:19:15 --> Input Class Initialized
INFO - 2018-04-11 22:19:15 --> Config Class Initialized
INFO - 2018-04-11 22:19:15 --> Config Class Initialized
INFO - 2018-04-11 22:19:15 --> Config Class Initialized
INFO - 2018-04-11 22:19:15 --> Config Class Initialized
INFO - 2018-04-11 22:19:15 --> Hooks Class Initialized
INFO - 2018-04-11 22:19:15 --> Hooks Class Initialized
INFO - 2018-04-11 22:19:15 --> Hooks Class Initialized
INFO - 2018-04-11 22:19:15 --> Language Class Initialized
INFO - 2018-04-11 22:19:15 --> Hooks Class Initialized
DEBUG - 2018-04-11 22:19:15 --> UTF-8 Support Enabled
DEBUG - 2018-04-11 22:19:15 --> UTF-8 Support Enabled
DEBUG - 2018-04-11 22:19:15 --> UTF-8 Support Enabled
ERROR - 2018-04-11 22:19:15 --> 404 Page Not Found: Assets/css
DEBUG - 2018-04-11 22:19:15 --> UTF-8 Support Enabled
INFO - 2018-04-11 22:19:15 --> Utf8 Class Initialized
INFO - 2018-04-11 22:19:15 --> Utf8 Class Initialized
INFO - 2018-04-11 22:19:15 --> Utf8 Class Initialized
INFO - 2018-04-11 22:19:15 --> Utf8 Class Initialized
INFO - 2018-04-11 22:19:15 --> URI Class Initialized
INFO - 2018-04-11 22:19:15 --> URI Class Initialized
INFO - 2018-04-11 22:19:15 --> URI Class Initialized
INFO - 2018-04-11 22:19:15 --> Router Class Initialized
INFO - 2018-04-11 22:19:15 --> Router Class Initialized
INFO - 2018-04-11 22:19:15 --> URI Class Initialized
INFO - 2018-04-11 22:19:15 --> Router Class Initialized
INFO - 2018-04-11 22:19:15 --> Router Class Initialized
INFO - 2018-04-11 22:19:15 --> Output Class Initialized
INFO - 2018-04-11 22:19:15 --> Output Class Initialized
INFO - 2018-04-11 22:19:15 --> Output Class Initialized
INFO - 2018-04-11 22:19:15 --> Security Class Initialized
INFO - 2018-04-11 22:19:15 --> Security Class Initialized
INFO - 2018-04-11 22:19:15 --> Security Class Initialized
INFO - 2018-04-11 22:19:15 --> Output Class Initialized
DEBUG - 2018-04-11 22:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:19:15 --> Security Class Initialized
DEBUG - 2018-04-11 22:19:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-11 22:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:19:15 --> CSRF cookie sent
INFO - 2018-04-11 22:19:15 --> CSRF cookie sent
INFO - 2018-04-11 22:19:15 --> CSRF cookie sent
DEBUG - 2018-04-11 22:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:19:15 --> CSRF cookie sent
INFO - 2018-04-11 22:19:15 --> Input Class Initialized
INFO - 2018-04-11 22:19:15 --> Input Class Initialized
INFO - 2018-04-11 22:19:15 --> Input Class Initialized
INFO - 2018-04-11 22:19:15 --> Input Class Initialized
INFO - 2018-04-11 22:19:15 --> Language Class Initialized
INFO - 2018-04-11 22:19:15 --> Language Class Initialized
INFO - 2018-04-11 22:19:15 --> Language Class Initialized
INFO - 2018-04-11 22:19:15 --> Language Class Initialized
ERROR - 2018-04-11 22:19:15 --> 404 Page Not Found: Edit-user/assets
ERROR - 2018-04-11 22:19:15 --> 404 Page Not Found: Edit-user/assets
ERROR - 2018-04-11 22:19:15 --> 404 Page Not Found: Edit-user/assets
ERROR - 2018-04-11 22:19:15 --> 404 Page Not Found: Edit-user/assets
INFO - 2018-04-11 22:19:49 --> Config Class Initialized
INFO - 2018-04-11 22:19:49 --> Hooks Class Initialized
DEBUG - 2018-04-11 22:19:49 --> UTF-8 Support Enabled
INFO - 2018-04-11 22:19:49 --> Utf8 Class Initialized
INFO - 2018-04-11 22:19:49 --> URI Class Initialized
INFO - 2018-04-11 22:19:49 --> Router Class Initialized
INFO - 2018-04-11 22:19:49 --> Output Class Initialized
INFO - 2018-04-11 22:19:49 --> Security Class Initialized
DEBUG - 2018-04-11 22:19:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:19:49 --> CSRF cookie sent
INFO - 2018-04-11 22:19:49 --> Input Class Initialized
INFO - 2018-04-11 22:19:49 --> Language Class Initialized
INFO - 2018-04-11 22:19:49 --> Loader Class Initialized
INFO - 2018-04-11 22:19:49 --> Helper loaded: url_helper
INFO - 2018-04-11 22:19:49 --> Helper loaded: form_helper
INFO - 2018-04-11 22:19:49 --> Helper loaded: language_helper
DEBUG - 2018-04-11 22:19:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 22:19:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 22:19:49 --> User Agent Class Initialized
INFO - 2018-04-11 22:19:49 --> Controller Class Initialized
INFO - 2018-04-11 22:19:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 22:19:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 22:19:49 --> Pixel_Model class loaded
INFO - 2018-04-11 22:19:49 --> Database Driver Class Initialized
INFO - 2018-04-11 22:19:49 --> Model "MyAccountModel" initialized
INFO - 2018-04-11 22:19:49 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 22:19:49 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-11 22:19:49 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-11 22:19:49 --> File loaded: E:\www\yacopoo\application\views\myaccount/edit_user.php
INFO - 2018-04-11 22:19:49 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 22:19:49 --> Final output sent to browser
DEBUG - 2018-04-11 22:19:49 --> Total execution time: 0.5563
INFO - 2018-04-11 22:19:50 --> Config Class Initialized
INFO - 2018-04-11 22:19:50 --> Hooks Class Initialized
DEBUG - 2018-04-11 22:19:50 --> UTF-8 Support Enabled
INFO - 2018-04-11 22:19:50 --> Utf8 Class Initialized
INFO - 2018-04-11 22:19:50 --> URI Class Initialized
INFO - 2018-04-11 22:19:50 --> Router Class Initialized
INFO - 2018-04-11 22:19:50 --> Output Class Initialized
INFO - 2018-04-11 22:19:50 --> Security Class Initialized
DEBUG - 2018-04-11 22:19:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:19:50 --> CSRF cookie sent
INFO - 2018-04-11 22:19:50 --> Input Class Initialized
INFO - 2018-04-11 22:19:50 --> Language Class Initialized
INFO - 2018-04-11 22:19:50 --> Config Class Initialized
INFO - 2018-04-11 22:19:50 --> Hooks Class Initialized
ERROR - 2018-04-11 22:19:50 --> 404 Page Not Found: Assets/css
INFO - 2018-04-11 22:19:50 --> Config Class Initialized
INFO - 2018-04-11 22:19:50 --> Config Class Initialized
INFO - 2018-04-11 22:19:50 --> Config Class Initialized
INFO - 2018-04-11 22:19:50 --> Hooks Class Initialized
INFO - 2018-04-11 22:19:50 --> Hooks Class Initialized
INFO - 2018-04-11 22:19:50 --> Hooks Class Initialized
DEBUG - 2018-04-11 22:19:50 --> UTF-8 Support Enabled
INFO - 2018-04-11 22:19:50 --> Utf8 Class Initialized
DEBUG - 2018-04-11 22:19:50 --> UTF-8 Support Enabled
DEBUG - 2018-04-11 22:19:50 --> UTF-8 Support Enabled
INFO - 2018-04-11 22:19:50 --> URI Class Initialized
DEBUG - 2018-04-11 22:19:50 --> UTF-8 Support Enabled
INFO - 2018-04-11 22:19:50 --> Utf8 Class Initialized
INFO - 2018-04-11 22:19:50 --> Utf8 Class Initialized
INFO - 2018-04-11 22:19:50 --> Utf8 Class Initialized
INFO - 2018-04-11 22:19:50 --> Router Class Initialized
INFO - 2018-04-11 22:19:50 --> URI Class Initialized
INFO - 2018-04-11 22:19:50 --> Output Class Initialized
INFO - 2018-04-11 22:19:50 --> URI Class Initialized
INFO - 2018-04-11 22:19:50 --> URI Class Initialized
INFO - 2018-04-11 22:19:50 --> Security Class Initialized
INFO - 2018-04-11 22:19:50 --> Router Class Initialized
INFO - 2018-04-11 22:19:50 --> Router Class Initialized
INFO - 2018-04-11 22:19:50 --> Router Class Initialized
DEBUG - 2018-04-11 22:19:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:19:50 --> Output Class Initialized
INFO - 2018-04-11 22:19:50 --> Output Class Initialized
INFO - 2018-04-11 22:19:50 --> Output Class Initialized
INFO - 2018-04-11 22:19:50 --> CSRF cookie sent
INFO - 2018-04-11 22:19:50 --> Security Class Initialized
INFO - 2018-04-11 22:19:50 --> Security Class Initialized
INFO - 2018-04-11 22:19:50 --> Security Class Initialized
INFO - 2018-04-11 22:19:50 --> Input Class Initialized
DEBUG - 2018-04-11 22:19:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-11 22:19:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-11 22:19:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:19:50 --> CSRF cookie sent
INFO - 2018-04-11 22:19:50 --> CSRF cookie sent
INFO - 2018-04-11 22:19:50 --> CSRF cookie sent
INFO - 2018-04-11 22:19:50 --> Language Class Initialized
INFO - 2018-04-11 22:19:50 --> Input Class Initialized
INFO - 2018-04-11 22:19:50 --> Input Class Initialized
INFO - 2018-04-11 22:19:50 --> Input Class Initialized
ERROR - 2018-04-11 22:19:50 --> 404 Page Not Found: Edit-user/assets
INFO - 2018-04-11 22:19:50 --> Language Class Initialized
INFO - 2018-04-11 22:19:50 --> Language Class Initialized
INFO - 2018-04-11 22:19:50 --> Language Class Initialized
ERROR - 2018-04-11 22:19:50 --> 404 Page Not Found: Edit-user/assets
ERROR - 2018-04-11 22:19:50 --> 404 Page Not Found: Edit-user/assets
ERROR - 2018-04-11 22:19:50 --> 404 Page Not Found: Edit-user/assets
INFO - 2018-04-11 22:20:39 --> Config Class Initialized
INFO - 2018-04-11 22:20:39 --> Hooks Class Initialized
DEBUG - 2018-04-11 22:20:39 --> UTF-8 Support Enabled
INFO - 2018-04-11 22:20:39 --> Utf8 Class Initialized
INFO - 2018-04-11 22:20:39 --> URI Class Initialized
INFO - 2018-04-11 22:20:40 --> Router Class Initialized
INFO - 2018-04-11 22:20:40 --> Output Class Initialized
INFO - 2018-04-11 22:20:40 --> Security Class Initialized
DEBUG - 2018-04-11 22:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:20:40 --> CSRF cookie sent
INFO - 2018-04-11 22:20:40 --> Input Class Initialized
INFO - 2018-04-11 22:20:40 --> Language Class Initialized
INFO - 2018-04-11 22:20:40 --> Loader Class Initialized
INFO - 2018-04-11 22:20:40 --> Helper loaded: url_helper
INFO - 2018-04-11 22:20:40 --> Helper loaded: form_helper
INFO - 2018-04-11 22:20:40 --> Helper loaded: language_helper
DEBUG - 2018-04-11 22:20:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 22:20:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 22:20:40 --> User Agent Class Initialized
INFO - 2018-04-11 22:20:40 --> Controller Class Initialized
INFO - 2018-04-11 22:20:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 22:20:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 22:20:40 --> Pixel_Model class loaded
INFO - 2018-04-11 22:20:40 --> Database Driver Class Initialized
INFO - 2018-04-11 22:20:40 --> Model "MyAccountModel" initialized
INFO - 2018-04-11 22:20:40 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 22:20:40 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-11 22:20:40 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-11 22:20:40 --> File loaded: E:\www\yacopoo\application\views\myaccount/edit_user.php
INFO - 2018-04-11 22:20:40 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 22:20:40 --> Final output sent to browser
DEBUG - 2018-04-11 22:20:40 --> Total execution time: 0.4910
INFO - 2018-04-11 22:20:40 --> Config Class Initialized
INFO - 2018-04-11 22:20:40 --> Hooks Class Initialized
DEBUG - 2018-04-11 22:20:40 --> UTF-8 Support Enabled
INFO - 2018-04-11 22:20:40 --> Utf8 Class Initialized
INFO - 2018-04-11 22:20:40 --> URI Class Initialized
INFO - 2018-04-11 22:20:40 --> Router Class Initialized
INFO - 2018-04-11 22:20:40 --> Output Class Initialized
INFO - 2018-04-11 22:20:40 --> Security Class Initialized
DEBUG - 2018-04-11 22:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:20:40 --> CSRF cookie sent
INFO - 2018-04-11 22:20:40 --> Input Class Initialized
INFO - 2018-04-11 22:20:41 --> Language Class Initialized
ERROR - 2018-04-11 22:20:41 --> 404 Page Not Found: Assets/css
INFO - 2018-04-11 22:20:41 --> Config Class Initialized
INFO - 2018-04-11 22:20:41 --> Hooks Class Initialized
INFO - 2018-04-11 22:20:41 --> Config Class Initialized
INFO - 2018-04-11 22:20:41 --> Config Class Initialized
INFO - 2018-04-11 22:20:41 --> Config Class Initialized
INFO - 2018-04-11 22:20:41 --> Hooks Class Initialized
INFO - 2018-04-11 22:20:41 --> Hooks Class Initialized
DEBUG - 2018-04-11 22:20:41 --> UTF-8 Support Enabled
INFO - 2018-04-11 22:20:41 --> Hooks Class Initialized
INFO - 2018-04-11 22:20:41 --> Utf8 Class Initialized
DEBUG - 2018-04-11 22:20:41 --> UTF-8 Support Enabled
DEBUG - 2018-04-11 22:20:41 --> UTF-8 Support Enabled
DEBUG - 2018-04-11 22:20:41 --> UTF-8 Support Enabled
INFO - 2018-04-11 22:20:41 --> Utf8 Class Initialized
INFO - 2018-04-11 22:20:41 --> URI Class Initialized
INFO - 2018-04-11 22:20:41 --> Utf8 Class Initialized
INFO - 2018-04-11 22:20:41 --> Utf8 Class Initialized
INFO - 2018-04-11 22:20:41 --> Router Class Initialized
INFO - 2018-04-11 22:20:41 --> URI Class Initialized
INFO - 2018-04-11 22:20:41 --> URI Class Initialized
INFO - 2018-04-11 22:20:41 --> URI Class Initialized
INFO - 2018-04-11 22:20:41 --> Output Class Initialized
INFO - 2018-04-11 22:20:41 --> Router Class Initialized
INFO - 2018-04-11 22:20:41 --> Router Class Initialized
INFO - 2018-04-11 22:20:41 --> Router Class Initialized
INFO - 2018-04-11 22:20:41 --> Output Class Initialized
INFO - 2018-04-11 22:20:41 --> Output Class Initialized
INFO - 2018-04-11 22:20:41 --> Output Class Initialized
INFO - 2018-04-11 22:20:41 --> Security Class Initialized
INFO - 2018-04-11 22:20:41 --> Security Class Initialized
INFO - 2018-04-11 22:20:41 --> Security Class Initialized
DEBUG - 2018-04-11 22:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:20:41 --> Security Class Initialized
INFO - 2018-04-11 22:20:41 --> CSRF cookie sent
DEBUG - 2018-04-11 22:20:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-11 22:20:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-11 22:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:20:41 --> CSRF cookie sent
INFO - 2018-04-11 22:20:41 --> CSRF cookie sent
INFO - 2018-04-11 22:20:41 --> Input Class Initialized
INFO - 2018-04-11 22:20:41 --> CSRF cookie sent
INFO - 2018-04-11 22:20:41 --> Input Class Initialized
INFO - 2018-04-11 22:20:41 --> Input Class Initialized
INFO - 2018-04-11 22:20:41 --> Input Class Initialized
INFO - 2018-04-11 22:20:41 --> Language Class Initialized
INFO - 2018-04-11 22:20:41 --> Language Class Initialized
INFO - 2018-04-11 22:20:41 --> Language Class Initialized
INFO - 2018-04-11 22:20:41 --> Language Class Initialized
ERROR - 2018-04-11 22:20:41 --> 404 Page Not Found: Edit-user/assets
ERROR - 2018-04-11 22:20:41 --> 404 Page Not Found: Edit-user/assets
ERROR - 2018-04-11 22:20:41 --> 404 Page Not Found: Edit-user/assets
ERROR - 2018-04-11 22:20:41 --> 404 Page Not Found: Edit-user/assets
INFO - 2018-04-11 22:20:46 --> Config Class Initialized
INFO - 2018-04-11 22:20:46 --> Hooks Class Initialized
DEBUG - 2018-04-11 22:20:46 --> UTF-8 Support Enabled
INFO - 2018-04-11 22:20:46 --> Utf8 Class Initialized
INFO - 2018-04-11 22:20:46 --> URI Class Initialized
INFO - 2018-04-11 22:20:46 --> Router Class Initialized
INFO - 2018-04-11 22:20:46 --> Output Class Initialized
INFO - 2018-04-11 22:20:46 --> Security Class Initialized
DEBUG - 2018-04-11 22:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:20:46 --> CSRF cookie sent
INFO - 2018-04-11 22:20:46 --> Input Class Initialized
INFO - 2018-04-11 22:20:46 --> Language Class Initialized
INFO - 2018-04-11 22:20:46 --> Loader Class Initialized
INFO - 2018-04-11 22:20:46 --> Helper loaded: url_helper
INFO - 2018-04-11 22:20:46 --> Helper loaded: form_helper
INFO - 2018-04-11 22:20:46 --> Helper loaded: language_helper
DEBUG - 2018-04-11 22:20:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 22:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 22:20:46 --> User Agent Class Initialized
INFO - 2018-04-11 22:20:46 --> Controller Class Initialized
INFO - 2018-04-11 22:20:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 22:20:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 22:20:47 --> Pixel_Model class loaded
INFO - 2018-04-11 22:20:47 --> Database Driver Class Initialized
INFO - 2018-04-11 22:20:47 --> Model "MyAccountModel" initialized
INFO - 2018-04-11 22:20:47 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 22:20:47 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-11 22:20:47 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-11 22:20:47 --> File loaded: E:\www\yacopoo\application\views\myaccount/edit_user.php
INFO - 2018-04-11 22:20:47 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 22:20:47 --> Final output sent to browser
DEBUG - 2018-04-11 22:20:47 --> Total execution time: 0.5209
INFO - 2018-04-11 22:20:47 --> Config Class Initialized
INFO - 2018-04-11 22:20:47 --> Hooks Class Initialized
DEBUG - 2018-04-11 22:20:47 --> UTF-8 Support Enabled
INFO - 2018-04-11 22:20:47 --> Utf8 Class Initialized
INFO - 2018-04-11 22:20:47 --> URI Class Initialized
INFO - 2018-04-11 22:20:47 --> Router Class Initialized
INFO - 2018-04-11 22:20:47 --> Output Class Initialized
INFO - 2018-04-11 22:20:47 --> Security Class Initialized
DEBUG - 2018-04-11 22:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:20:47 --> CSRF cookie sent
INFO - 2018-04-11 22:20:47 --> Input Class Initialized
INFO - 2018-04-11 22:20:47 --> Language Class Initialized
ERROR - 2018-04-11 22:20:47 --> 404 Page Not Found: Assets/css
INFO - 2018-04-11 22:20:47 --> Config Class Initialized
INFO - 2018-04-11 22:20:47 --> Config Class Initialized
INFO - 2018-04-11 22:20:47 --> Config Class Initialized
INFO - 2018-04-11 22:20:47 --> Config Class Initialized
INFO - 2018-04-11 22:20:47 --> Hooks Class Initialized
INFO - 2018-04-11 22:20:47 --> Hooks Class Initialized
INFO - 2018-04-11 22:20:47 --> Hooks Class Initialized
INFO - 2018-04-11 22:20:47 --> Hooks Class Initialized
DEBUG - 2018-04-11 22:20:47 --> UTF-8 Support Enabled
DEBUG - 2018-04-11 22:20:47 --> UTF-8 Support Enabled
DEBUG - 2018-04-11 22:20:47 --> UTF-8 Support Enabled
DEBUG - 2018-04-11 22:20:47 --> UTF-8 Support Enabled
INFO - 2018-04-11 22:20:47 --> Utf8 Class Initialized
INFO - 2018-04-11 22:20:47 --> Utf8 Class Initialized
INFO - 2018-04-11 22:20:47 --> Utf8 Class Initialized
INFO - 2018-04-11 22:20:47 --> Utf8 Class Initialized
INFO - 2018-04-11 22:20:47 --> URI Class Initialized
INFO - 2018-04-11 22:20:47 --> URI Class Initialized
INFO - 2018-04-11 22:20:47 --> URI Class Initialized
INFO - 2018-04-11 22:20:47 --> URI Class Initialized
INFO - 2018-04-11 22:20:47 --> Router Class Initialized
INFO - 2018-04-11 22:20:47 --> Router Class Initialized
INFO - 2018-04-11 22:20:47 --> Router Class Initialized
INFO - 2018-04-11 22:20:47 --> Router Class Initialized
INFO - 2018-04-11 22:20:47 --> Output Class Initialized
INFO - 2018-04-11 22:20:47 --> Output Class Initialized
INFO - 2018-04-11 22:20:47 --> Output Class Initialized
INFO - 2018-04-11 22:20:47 --> Output Class Initialized
INFO - 2018-04-11 22:20:47 --> Security Class Initialized
INFO - 2018-04-11 22:20:47 --> Security Class Initialized
INFO - 2018-04-11 22:20:47 --> Security Class Initialized
INFO - 2018-04-11 22:20:47 --> Security Class Initialized
DEBUG - 2018-04-11 22:20:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-11 22:20:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-11 22:20:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-11 22:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:20:48 --> CSRF cookie sent
INFO - 2018-04-11 22:20:48 --> CSRF cookie sent
INFO - 2018-04-11 22:20:48 --> CSRF cookie sent
INFO - 2018-04-11 22:20:48 --> CSRF cookie sent
INFO - 2018-04-11 22:20:48 --> Input Class Initialized
INFO - 2018-04-11 22:20:48 --> Input Class Initialized
INFO - 2018-04-11 22:20:48 --> Input Class Initialized
INFO - 2018-04-11 22:20:48 --> Input Class Initialized
INFO - 2018-04-11 22:20:48 --> Language Class Initialized
INFO - 2018-04-11 22:20:48 --> Language Class Initialized
INFO - 2018-04-11 22:20:48 --> Language Class Initialized
INFO - 2018-04-11 22:20:48 --> Language Class Initialized
ERROR - 2018-04-11 22:20:48 --> 404 Page Not Found: Edit-user/3
ERROR - 2018-04-11 22:20:48 --> 404 Page Not Found: Edit-user/3
ERROR - 2018-04-11 22:20:48 --> 404 Page Not Found: Edit-user/3
ERROR - 2018-04-11 22:20:48 --> 404 Page Not Found: Edit-user/3
INFO - 2018-04-11 22:21:32 --> Config Class Initialized
INFO - 2018-04-11 22:21:32 --> Hooks Class Initialized
DEBUG - 2018-04-11 22:21:32 --> UTF-8 Support Enabled
INFO - 2018-04-11 22:21:32 --> Utf8 Class Initialized
INFO - 2018-04-11 22:21:32 --> URI Class Initialized
INFO - 2018-04-11 22:21:32 --> Router Class Initialized
INFO - 2018-04-11 22:21:32 --> Output Class Initialized
INFO - 2018-04-11 22:21:32 --> Security Class Initialized
DEBUG - 2018-04-11 22:21:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:21:32 --> CSRF cookie sent
INFO - 2018-04-11 22:21:32 --> Input Class Initialized
INFO - 2018-04-11 22:21:32 --> Language Class Initialized
INFO - 2018-04-11 22:21:32 --> Loader Class Initialized
INFO - 2018-04-11 22:21:32 --> Helper loaded: url_helper
INFO - 2018-04-11 22:21:32 --> Helper loaded: form_helper
INFO - 2018-04-11 22:21:32 --> Helper loaded: language_helper
DEBUG - 2018-04-11 22:21:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 22:21:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 22:21:32 --> User Agent Class Initialized
INFO - 2018-04-11 22:21:32 --> Controller Class Initialized
INFO - 2018-04-11 22:21:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 22:21:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 22:21:32 --> Pixel_Model class loaded
INFO - 2018-04-11 22:21:32 --> Database Driver Class Initialized
INFO - 2018-04-11 22:21:35 --> Model "MyAccountModel" initialized
INFO - 2018-04-11 22:21:35 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 22:21:35 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-11 22:21:35 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-11 22:21:35 --> File loaded: E:\www\yacopoo\application\views\myaccount/edit_user.php
INFO - 2018-04-11 22:21:35 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 22:21:35 --> Final output sent to browser
DEBUG - 2018-04-11 22:21:35 --> Total execution time: 3.4958
INFO - 2018-04-11 22:21:36 --> Config Class Initialized
INFO - 2018-04-11 22:21:36 --> Hooks Class Initialized
DEBUG - 2018-04-11 22:21:36 --> UTF-8 Support Enabled
INFO - 2018-04-11 22:21:36 --> Utf8 Class Initialized
INFO - 2018-04-11 22:21:36 --> URI Class Initialized
INFO - 2018-04-11 22:21:36 --> Router Class Initialized
INFO - 2018-04-11 22:21:36 --> Output Class Initialized
INFO - 2018-04-11 22:21:36 --> Security Class Initialized
DEBUG - 2018-04-11 22:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:21:36 --> CSRF cookie sent
INFO - 2018-04-11 22:21:36 --> Input Class Initialized
INFO - 2018-04-11 22:21:36 --> Language Class Initialized
ERROR - 2018-04-11 22:21:36 --> 404 Page Not Found: Assets/css
INFO - 2018-04-11 22:23:17 --> Config Class Initialized
INFO - 2018-04-11 22:23:17 --> Hooks Class Initialized
DEBUG - 2018-04-11 22:23:17 --> UTF-8 Support Enabled
INFO - 2018-04-11 22:23:17 --> Utf8 Class Initialized
INFO - 2018-04-11 22:23:17 --> URI Class Initialized
INFO - 2018-04-11 22:23:17 --> Router Class Initialized
INFO - 2018-04-11 22:23:17 --> Output Class Initialized
INFO - 2018-04-11 22:23:17 --> Security Class Initialized
DEBUG - 2018-04-11 22:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:23:17 --> CSRF cookie sent
INFO - 2018-04-11 22:23:17 --> Input Class Initialized
INFO - 2018-04-11 22:23:17 --> Language Class Initialized
INFO - 2018-04-11 22:23:17 --> Loader Class Initialized
INFO - 2018-04-11 22:23:17 --> Helper loaded: url_helper
INFO - 2018-04-11 22:23:17 --> Helper loaded: form_helper
INFO - 2018-04-11 22:23:17 --> Helper loaded: language_helper
DEBUG - 2018-04-11 22:23:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 22:23:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 22:23:17 --> User Agent Class Initialized
INFO - 2018-04-11 22:23:17 --> Controller Class Initialized
INFO - 2018-04-11 22:23:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 22:23:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 22:23:17 --> Pixel_Model class loaded
INFO - 2018-04-11 22:23:17 --> Database Driver Class Initialized
INFO - 2018-04-11 22:23:20 --> Model "MyAccountModel" initialized
INFO - 2018-04-11 22:23:20 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 22:23:20 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-11 22:23:20 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-11 22:23:20 --> File loaded: E:\www\yacopoo\application\views\myaccount/edit_user.php
INFO - 2018-04-11 22:23:20 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 22:23:20 --> Final output sent to browser
DEBUG - 2018-04-11 22:23:21 --> Total execution time: 3.5208
INFO - 2018-04-11 22:23:21 --> Config Class Initialized
INFO - 2018-04-11 22:23:21 --> Hooks Class Initialized
DEBUG - 2018-04-11 22:23:21 --> UTF-8 Support Enabled
INFO - 2018-04-11 22:23:21 --> Utf8 Class Initialized
INFO - 2018-04-11 22:23:21 --> URI Class Initialized
INFO - 2018-04-11 22:23:21 --> Router Class Initialized
INFO - 2018-04-11 22:23:21 --> Output Class Initialized
INFO - 2018-04-11 22:23:21 --> Security Class Initialized
DEBUG - 2018-04-11 22:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:23:21 --> CSRF cookie sent
INFO - 2018-04-11 22:23:21 --> Input Class Initialized
INFO - 2018-04-11 22:23:21 --> Config Class Initialized
INFO - 2018-04-11 22:23:21 --> Language Class Initialized
INFO - 2018-04-11 22:23:21 --> Config Class Initialized
INFO - 2018-04-11 22:23:21 --> Config Class Initialized
INFO - 2018-04-11 22:23:21 --> Config Class Initialized
INFO - 2018-04-11 22:23:21 --> Hooks Class Initialized
INFO - 2018-04-11 22:23:21 --> Hooks Class Initialized
INFO - 2018-04-11 22:23:21 --> Hooks Class Initialized
INFO - 2018-04-11 22:23:21 --> Hooks Class Initialized
ERROR - 2018-04-11 22:23:21 --> 404 Page Not Found: Assets/css
DEBUG - 2018-04-11 22:23:21 --> UTF-8 Support Enabled
DEBUG - 2018-04-11 22:23:21 --> UTF-8 Support Enabled
DEBUG - 2018-04-11 22:23:21 --> UTF-8 Support Enabled
DEBUG - 2018-04-11 22:23:21 --> UTF-8 Support Enabled
INFO - 2018-04-11 22:23:21 --> Utf8 Class Initialized
INFO - 2018-04-11 22:23:21 --> Utf8 Class Initialized
INFO - 2018-04-11 22:23:21 --> Utf8 Class Initialized
INFO - 2018-04-11 22:23:21 --> Utf8 Class Initialized
INFO - 2018-04-11 22:23:21 --> URI Class Initialized
INFO - 2018-04-11 22:23:21 --> URI Class Initialized
INFO - 2018-04-11 22:23:21 --> URI Class Initialized
INFO - 2018-04-11 22:23:21 --> URI Class Initialized
INFO - 2018-04-11 22:23:21 --> Router Class Initialized
INFO - 2018-04-11 22:23:21 --> Router Class Initialized
INFO - 2018-04-11 22:23:21 --> Router Class Initialized
INFO - 2018-04-11 22:23:21 --> Router Class Initialized
INFO - 2018-04-11 22:23:21 --> Output Class Initialized
INFO - 2018-04-11 22:23:21 --> Output Class Initialized
INFO - 2018-04-11 22:23:21 --> Output Class Initialized
INFO - 2018-04-11 22:23:21 --> Output Class Initialized
INFO - 2018-04-11 22:23:21 --> Security Class Initialized
INFO - 2018-04-11 22:23:21 --> Security Class Initialized
INFO - 2018-04-11 22:23:21 --> Security Class Initialized
INFO - 2018-04-11 22:23:21 --> Security Class Initialized
DEBUG - 2018-04-11 22:23:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-11 22:23:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-11 22:23:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-11 22:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:23:21 --> CSRF cookie sent
INFO - 2018-04-11 22:23:21 --> CSRF cookie sent
INFO - 2018-04-11 22:23:21 --> CSRF cookie sent
INFO - 2018-04-11 22:23:21 --> CSRF cookie sent
INFO - 2018-04-11 22:23:21 --> Input Class Initialized
INFO - 2018-04-11 22:23:21 --> Input Class Initialized
INFO - 2018-04-11 22:23:21 --> Input Class Initialized
INFO - 2018-04-11 22:23:21 --> Input Class Initialized
INFO - 2018-04-11 22:23:21 --> Language Class Initialized
INFO - 2018-04-11 22:23:21 --> Language Class Initialized
INFO - 2018-04-11 22:23:21 --> Language Class Initialized
INFO - 2018-04-11 22:23:21 --> Language Class Initialized
ERROR - 2018-04-11 22:23:21 --> 404 Page Not Found: Edit-user/3
ERROR - 2018-04-11 22:23:21 --> 404 Page Not Found: Edit-user/3
ERROR - 2018-04-11 22:23:21 --> 404 Page Not Found: Edit-user/3
ERROR - 2018-04-11 22:23:21 --> 404 Page Not Found: Edit-user/3
INFO - 2018-04-11 22:24:01 --> Config Class Initialized
INFO - 2018-04-11 22:24:01 --> Hooks Class Initialized
DEBUG - 2018-04-11 22:24:01 --> UTF-8 Support Enabled
INFO - 2018-04-11 22:24:01 --> Utf8 Class Initialized
INFO - 2018-04-11 22:24:01 --> URI Class Initialized
INFO - 2018-04-11 22:24:01 --> Router Class Initialized
INFO - 2018-04-11 22:24:01 --> Output Class Initialized
INFO - 2018-04-11 22:24:01 --> Security Class Initialized
DEBUG - 2018-04-11 22:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:24:01 --> CSRF cookie sent
INFO - 2018-04-11 22:24:01 --> Input Class Initialized
INFO - 2018-04-11 22:24:01 --> Language Class Initialized
INFO - 2018-04-11 22:24:01 --> Loader Class Initialized
INFO - 2018-04-11 22:24:01 --> Helper loaded: url_helper
INFO - 2018-04-11 22:24:02 --> Helper loaded: form_helper
INFO - 2018-04-11 22:24:02 --> Helper loaded: language_helper
DEBUG - 2018-04-11 22:24:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 22:24:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 22:24:02 --> User Agent Class Initialized
INFO - 2018-04-11 22:24:02 --> Controller Class Initialized
INFO - 2018-04-11 22:24:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 22:24:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 22:24:02 --> Pixel_Model class loaded
INFO - 2018-04-11 22:24:02 --> Database Driver Class Initialized
INFO - 2018-04-11 22:24:02 --> Model "MyAccountModel" initialized
INFO - 2018-04-11 22:24:02 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 22:24:02 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-11 22:24:02 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-11 22:24:02 --> File loaded: E:\www\yacopoo\application\views\myaccount/edit_user.php
INFO - 2018-04-11 22:24:02 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 22:24:02 --> Final output sent to browser
DEBUG - 2018-04-11 22:24:02 --> Total execution time: 0.5953
INFO - 2018-04-11 22:24:02 --> Config Class Initialized
INFO - 2018-04-11 22:24:02 --> Hooks Class Initialized
DEBUG - 2018-04-11 22:24:02 --> UTF-8 Support Enabled
INFO - 2018-04-11 22:24:02 --> Utf8 Class Initialized
INFO - 2018-04-11 22:24:02 --> URI Class Initialized
INFO - 2018-04-11 22:24:02 --> Router Class Initialized
INFO - 2018-04-11 22:24:02 --> Output Class Initialized
INFO - 2018-04-11 22:24:02 --> Security Class Initialized
DEBUG - 2018-04-11 22:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:24:02 --> CSRF cookie sent
INFO - 2018-04-11 22:24:02 --> Input Class Initialized
INFO - 2018-04-11 22:24:02 --> Language Class Initialized
ERROR - 2018-04-11 22:24:03 --> 404 Page Not Found: Assets/css
INFO - 2018-04-11 22:24:52 --> Config Class Initialized
INFO - 2018-04-11 22:24:52 --> Hooks Class Initialized
DEBUG - 2018-04-11 22:24:52 --> UTF-8 Support Enabled
INFO - 2018-04-11 22:24:52 --> Utf8 Class Initialized
INFO - 2018-04-11 22:24:52 --> URI Class Initialized
INFO - 2018-04-11 22:24:52 --> Router Class Initialized
INFO - 2018-04-11 22:24:52 --> Output Class Initialized
INFO - 2018-04-11 22:24:52 --> Security Class Initialized
DEBUG - 2018-04-11 22:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:24:52 --> CSRF cookie sent
INFO - 2018-04-11 22:24:52 --> Input Class Initialized
INFO - 2018-04-11 22:24:52 --> Language Class Initialized
INFO - 2018-04-11 22:24:52 --> Loader Class Initialized
INFO - 2018-04-11 22:24:52 --> Helper loaded: url_helper
INFO - 2018-04-11 22:24:52 --> Helper loaded: form_helper
INFO - 2018-04-11 22:24:52 --> Helper loaded: language_helper
DEBUG - 2018-04-11 22:24:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 22:24:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 22:24:52 --> User Agent Class Initialized
INFO - 2018-04-11 22:24:52 --> Controller Class Initialized
INFO - 2018-04-11 22:24:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 22:24:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 22:24:52 --> Pixel_Model class loaded
INFO - 2018-04-11 22:24:52 --> Database Driver Class Initialized
INFO - 2018-04-11 22:24:55 --> Model "MyAccountModel" initialized
INFO - 2018-04-11 22:24:55 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 22:24:55 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-11 22:24:55 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-11 22:24:55 --> File loaded: E:\www\yacopoo\application\views\myaccount/edit_user.php
INFO - 2018-04-11 22:24:55 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 22:24:56 --> Final output sent to browser
DEBUG - 2018-04-11 22:24:56 --> Total execution time: 3.5430
INFO - 2018-04-11 22:24:56 --> Config Class Initialized
INFO - 2018-04-11 22:24:56 --> Hooks Class Initialized
DEBUG - 2018-04-11 22:24:56 --> UTF-8 Support Enabled
INFO - 2018-04-11 22:24:56 --> Utf8 Class Initialized
INFO - 2018-04-11 22:24:56 --> URI Class Initialized
INFO - 2018-04-11 22:24:56 --> Router Class Initialized
INFO - 2018-04-11 22:24:56 --> Output Class Initialized
INFO - 2018-04-11 22:24:56 --> Security Class Initialized
DEBUG - 2018-04-11 22:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:24:56 --> CSRF cookie sent
INFO - 2018-04-11 22:24:56 --> Input Class Initialized
INFO - 2018-04-11 22:24:56 --> Language Class Initialized
ERROR - 2018-04-11 22:24:56 --> 404 Page Not Found: Assets/css
INFO - 2018-04-11 22:27:54 --> Config Class Initialized
INFO - 2018-04-11 22:27:54 --> Hooks Class Initialized
DEBUG - 2018-04-11 22:27:54 --> UTF-8 Support Enabled
INFO - 2018-04-11 22:27:54 --> Utf8 Class Initialized
INFO - 2018-04-11 22:27:54 --> URI Class Initialized
INFO - 2018-04-11 22:27:54 --> Router Class Initialized
INFO - 2018-04-11 22:27:54 --> Output Class Initialized
INFO - 2018-04-11 22:27:54 --> Security Class Initialized
DEBUG - 2018-04-11 22:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:27:55 --> CSRF cookie sent
INFO - 2018-04-11 22:27:55 --> Input Class Initialized
INFO - 2018-04-11 22:27:55 --> Language Class Initialized
INFO - 2018-04-11 22:27:55 --> Loader Class Initialized
INFO - 2018-04-11 22:27:55 --> Helper loaded: url_helper
INFO - 2018-04-11 22:27:55 --> Helper loaded: form_helper
INFO - 2018-04-11 22:27:55 --> Helper loaded: language_helper
DEBUG - 2018-04-11 22:27:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 22:27:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 22:27:55 --> User Agent Class Initialized
INFO - 2018-04-11 22:27:55 --> Controller Class Initialized
INFO - 2018-04-11 22:27:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 22:27:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 22:27:55 --> Pixel_Model class loaded
INFO - 2018-04-11 22:27:55 --> Database Driver Class Initialized
INFO - 2018-04-11 22:27:58 --> Model "MyAccountModel" initialized
INFO - 2018-04-11 22:27:58 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 22:27:58 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-11 22:27:58 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-11 22:27:58 --> File loaded: E:\www\yacopoo\application\views\myaccount/edit_user.php
INFO - 2018-04-11 22:27:58 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 22:27:58 --> Final output sent to browser
DEBUG - 2018-04-11 22:27:58 --> Total execution time: 3.5278
INFO - 2018-04-11 22:27:58 --> Config Class Initialized
INFO - 2018-04-11 22:27:58 --> Hooks Class Initialized
DEBUG - 2018-04-11 22:27:58 --> UTF-8 Support Enabled
INFO - 2018-04-11 22:27:58 --> Utf8 Class Initialized
INFO - 2018-04-11 22:27:58 --> URI Class Initialized
INFO - 2018-04-11 22:27:58 --> Router Class Initialized
INFO - 2018-04-11 22:27:58 --> Output Class Initialized
INFO - 2018-04-11 22:27:58 --> Security Class Initialized
DEBUG - 2018-04-11 22:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:27:58 --> CSRF cookie sent
INFO - 2018-04-11 22:27:58 --> Input Class Initialized
INFO - 2018-04-11 22:27:59 --> Language Class Initialized
ERROR - 2018-04-11 22:27:59 --> 404 Page Not Found: Assets/css
INFO - 2018-04-11 22:28:23 --> Config Class Initialized
INFO - 2018-04-11 22:28:23 --> Hooks Class Initialized
DEBUG - 2018-04-11 22:28:23 --> UTF-8 Support Enabled
INFO - 2018-04-11 22:28:23 --> Utf8 Class Initialized
INFO - 2018-04-11 22:28:23 --> URI Class Initialized
INFO - 2018-04-11 22:28:23 --> Router Class Initialized
INFO - 2018-04-11 22:28:23 --> Output Class Initialized
INFO - 2018-04-11 22:28:23 --> Security Class Initialized
DEBUG - 2018-04-11 22:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:28:23 --> CSRF cookie sent
INFO - 2018-04-11 22:28:23 --> Input Class Initialized
INFO - 2018-04-11 22:28:23 --> Language Class Initialized
INFO - 2018-04-11 22:28:23 --> Loader Class Initialized
INFO - 2018-04-11 22:28:23 --> Helper loaded: url_helper
INFO - 2018-04-11 22:28:23 --> Helper loaded: form_helper
INFO - 2018-04-11 22:28:24 --> Helper loaded: language_helper
DEBUG - 2018-04-11 22:28:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 22:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 22:28:24 --> User Agent Class Initialized
INFO - 2018-04-11 22:28:24 --> Controller Class Initialized
INFO - 2018-04-11 22:28:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 22:28:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 22:28:24 --> Pixel_Model class loaded
INFO - 2018-04-11 22:28:24 --> Database Driver Class Initialized
INFO - 2018-04-11 22:28:24 --> Model "MyAccountModel" initialized
INFO - 2018-04-11 22:28:24 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 22:28:24 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-11 22:28:24 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-11 22:28:24 --> File loaded: E:\www\yacopoo\application\views\myaccount/edit_user.php
INFO - 2018-04-11 22:28:24 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 22:28:24 --> Final output sent to browser
DEBUG - 2018-04-11 22:28:24 --> Total execution time: 0.5901
INFO - 2018-04-11 22:28:24 --> Config Class Initialized
INFO - 2018-04-11 22:28:24 --> Hooks Class Initialized
DEBUG - 2018-04-11 22:28:24 --> UTF-8 Support Enabled
INFO - 2018-04-11 22:28:24 --> Utf8 Class Initialized
INFO - 2018-04-11 22:28:24 --> URI Class Initialized
INFO - 2018-04-11 22:28:24 --> Router Class Initialized
INFO - 2018-04-11 22:28:24 --> Output Class Initialized
INFO - 2018-04-11 22:28:24 --> Security Class Initialized
DEBUG - 2018-04-11 22:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:28:24 --> CSRF cookie sent
INFO - 2018-04-11 22:28:24 --> Input Class Initialized
INFO - 2018-04-11 22:28:24 --> Language Class Initialized
ERROR - 2018-04-11 22:28:24 --> 404 Page Not Found: Assets/css
INFO - 2018-04-11 22:28:28 --> Config Class Initialized
INFO - 2018-04-11 22:28:28 --> Hooks Class Initialized
DEBUG - 2018-04-11 22:28:28 --> UTF-8 Support Enabled
INFO - 2018-04-11 22:28:28 --> Utf8 Class Initialized
INFO - 2018-04-11 22:28:28 --> URI Class Initialized
INFO - 2018-04-11 22:28:28 --> Router Class Initialized
INFO - 2018-04-11 22:28:28 --> Output Class Initialized
INFO - 2018-04-11 22:28:28 --> Security Class Initialized
DEBUG - 2018-04-11 22:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:28:28 --> CSRF cookie sent
INFO - 2018-04-11 22:28:28 --> CSRF token verified
INFO - 2018-04-11 22:28:28 --> Input Class Initialized
INFO - 2018-04-11 22:28:28 --> Language Class Initialized
INFO - 2018-04-11 22:28:28 --> Loader Class Initialized
INFO - 2018-04-11 22:28:28 --> Helper loaded: url_helper
INFO - 2018-04-11 22:28:28 --> Helper loaded: form_helper
INFO - 2018-04-11 22:28:28 --> Helper loaded: language_helper
DEBUG - 2018-04-11 22:28:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 22:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 22:28:28 --> User Agent Class Initialized
INFO - 2018-04-11 22:28:28 --> Controller Class Initialized
INFO - 2018-04-11 22:28:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 22:28:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 22:28:28 --> Form Validation Class Initialized
INFO - 2018-04-11 22:28:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-11 22:28:28 --> Pixel_Model class loaded
INFO - 2018-04-11 22:28:28 --> Database Driver Class Initialized
INFO - 2018-04-11 22:28:28 --> Model "MyAccountModel" initialized
INFO - 2018-04-11 22:28:28 --> Config Class Initialized
INFO - 2018-04-11 22:28:28 --> Hooks Class Initialized
DEBUG - 2018-04-11 22:28:28 --> UTF-8 Support Enabled
INFO - 2018-04-11 22:28:29 --> Utf8 Class Initialized
INFO - 2018-04-11 22:28:29 --> URI Class Initialized
INFO - 2018-04-11 22:28:29 --> Router Class Initialized
INFO - 2018-04-11 22:28:29 --> Output Class Initialized
INFO - 2018-04-11 22:28:29 --> Security Class Initialized
DEBUG - 2018-04-11 22:28:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:28:29 --> CSRF cookie sent
INFO - 2018-04-11 22:28:29 --> Input Class Initialized
INFO - 2018-04-11 22:28:29 --> Language Class Initialized
INFO - 2018-04-11 22:28:29 --> Loader Class Initialized
INFO - 2018-04-11 22:28:29 --> Helper loaded: url_helper
INFO - 2018-04-11 22:28:29 --> Helper loaded: form_helper
INFO - 2018-04-11 22:28:29 --> Helper loaded: language_helper
DEBUG - 2018-04-11 22:28:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 22:28:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 22:28:29 --> User Agent Class Initialized
INFO - 2018-04-11 22:28:29 --> Controller Class Initialized
INFO - 2018-04-11 22:28:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 22:28:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 22:28:29 --> Pixel_Model class loaded
INFO - 2018-04-11 22:28:29 --> Database Driver Class Initialized
INFO - 2018-04-11 22:28:29 --> Model "MyAccountModel" initialized
INFO - 2018-04-11 22:28:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-04-11 22:28:29 --> Pagination Class Initialized
INFO - 2018-04-11 22:28:29 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 22:28:29 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-11 22:28:29 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-11 22:28:29 --> File loaded: E:\www\yacopoo\application\views\myaccount/users_list.php
INFO - 2018-04-11 22:28:29 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 22:28:29 --> Final output sent to browser
DEBUG - 2018-04-11 22:28:29 --> Total execution time: 0.5164
INFO - 2018-04-11 22:28:29 --> Config Class Initialized
INFO - 2018-04-11 22:28:29 --> Hooks Class Initialized
DEBUG - 2018-04-11 22:28:29 --> UTF-8 Support Enabled
INFO - 2018-04-11 22:28:29 --> Utf8 Class Initialized
INFO - 2018-04-11 22:28:29 --> URI Class Initialized
INFO - 2018-04-11 22:28:29 --> Router Class Initialized
INFO - 2018-04-11 22:28:30 --> Output Class Initialized
INFO - 2018-04-11 22:28:30 --> Security Class Initialized
DEBUG - 2018-04-11 22:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:28:30 --> CSRF cookie sent
INFO - 2018-04-11 22:28:30 --> Input Class Initialized
INFO - 2018-04-11 22:28:30 --> Language Class Initialized
ERROR - 2018-04-11 22:28:30 --> 404 Page Not Found: Assets/css
INFO - 2018-04-11 22:28:32 --> Config Class Initialized
INFO - 2018-04-11 22:28:32 --> Hooks Class Initialized
DEBUG - 2018-04-11 22:28:32 --> UTF-8 Support Enabled
INFO - 2018-04-11 22:28:32 --> Utf8 Class Initialized
INFO - 2018-04-11 22:28:32 --> URI Class Initialized
INFO - 2018-04-11 22:28:32 --> Router Class Initialized
INFO - 2018-04-11 22:28:32 --> Output Class Initialized
INFO - 2018-04-11 22:28:32 --> Security Class Initialized
DEBUG - 2018-04-11 22:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:28:32 --> CSRF cookie sent
INFO - 2018-04-11 22:28:32 --> Input Class Initialized
INFO - 2018-04-11 22:28:32 --> Language Class Initialized
INFO - 2018-04-11 22:28:32 --> Loader Class Initialized
INFO - 2018-04-11 22:28:32 --> Helper loaded: url_helper
INFO - 2018-04-11 22:28:32 --> Helper loaded: form_helper
INFO - 2018-04-11 22:28:32 --> Helper loaded: language_helper
DEBUG - 2018-04-11 22:28:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 22:28:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 22:28:32 --> User Agent Class Initialized
INFO - 2018-04-11 22:28:32 --> Controller Class Initialized
INFO - 2018-04-11 22:28:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 22:28:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 22:28:32 --> Pixel_Model class loaded
INFO - 2018-04-11 22:28:32 --> Database Driver Class Initialized
INFO - 2018-04-11 22:28:32 --> Model "MyAccountModel" initialized
INFO - 2018-04-11 22:28:32 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 22:28:32 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-11 22:28:32 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-11 22:28:32 --> File loaded: E:\www\yacopoo\application\views\myaccount/edit_user.php
INFO - 2018-04-11 22:28:32 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 22:28:32 --> Final output sent to browser
DEBUG - 2018-04-11 22:28:32 --> Total execution time: 0.5124
INFO - 2018-04-11 22:28:34 --> Config Class Initialized
INFO - 2018-04-11 22:28:34 --> Hooks Class Initialized
DEBUG - 2018-04-11 22:28:34 --> UTF-8 Support Enabled
INFO - 2018-04-11 22:28:34 --> Utf8 Class Initialized
INFO - 2018-04-11 22:28:34 --> URI Class Initialized
INFO - 2018-04-11 22:28:34 --> Router Class Initialized
INFO - 2018-04-11 22:28:34 --> Output Class Initialized
INFO - 2018-04-11 22:28:34 --> Security Class Initialized
DEBUG - 2018-04-11 22:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:28:34 --> CSRF cookie sent
INFO - 2018-04-11 22:28:34 --> Input Class Initialized
INFO - 2018-04-11 22:28:34 --> Language Class Initialized
ERROR - 2018-04-11 22:28:34 --> 404 Page Not Found: Assets/css
INFO - 2018-04-11 22:28:37 --> Config Class Initialized
INFO - 2018-04-11 22:28:37 --> Hooks Class Initialized
DEBUG - 2018-04-11 22:28:37 --> UTF-8 Support Enabled
INFO - 2018-04-11 22:28:37 --> Utf8 Class Initialized
INFO - 2018-04-11 22:28:37 --> URI Class Initialized
INFO - 2018-04-11 22:28:37 --> Router Class Initialized
INFO - 2018-04-11 22:28:37 --> Output Class Initialized
INFO - 2018-04-11 22:28:37 --> Security Class Initialized
DEBUG - 2018-04-11 22:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:28:37 --> CSRF cookie sent
INFO - 2018-04-11 22:28:37 --> CSRF token verified
INFO - 2018-04-11 22:28:37 --> Input Class Initialized
INFO - 2018-04-11 22:28:37 --> Language Class Initialized
INFO - 2018-04-11 22:28:37 --> Loader Class Initialized
INFO - 2018-04-11 22:28:37 --> Helper loaded: url_helper
INFO - 2018-04-11 22:28:37 --> Helper loaded: form_helper
INFO - 2018-04-11 22:28:37 --> Helper loaded: language_helper
DEBUG - 2018-04-11 22:28:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 22:28:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 22:28:37 --> User Agent Class Initialized
INFO - 2018-04-11 22:28:37 --> Controller Class Initialized
INFO - 2018-04-11 22:28:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 22:28:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 22:28:37 --> Form Validation Class Initialized
INFO - 2018-04-11 22:28:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-11 22:28:37 --> Pixel_Model class loaded
INFO - 2018-04-11 22:28:37 --> Database Driver Class Initialized
INFO - 2018-04-11 22:28:37 --> Model "MyAccountModel" initialized
INFO - 2018-04-11 22:28:37 --> Config Class Initialized
INFO - 2018-04-11 22:28:37 --> Hooks Class Initialized
DEBUG - 2018-04-11 22:28:37 --> UTF-8 Support Enabled
INFO - 2018-04-11 22:28:37 --> Utf8 Class Initialized
INFO - 2018-04-11 22:28:37 --> URI Class Initialized
INFO - 2018-04-11 22:28:37 --> Router Class Initialized
INFO - 2018-04-11 22:28:37 --> Output Class Initialized
INFO - 2018-04-11 22:28:37 --> Security Class Initialized
DEBUG - 2018-04-11 22:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:28:38 --> CSRF cookie sent
INFO - 2018-04-11 22:28:38 --> Input Class Initialized
INFO - 2018-04-11 22:28:38 --> Language Class Initialized
INFO - 2018-04-11 22:28:38 --> Loader Class Initialized
INFO - 2018-04-11 22:28:38 --> Helper loaded: url_helper
INFO - 2018-04-11 22:28:38 --> Helper loaded: form_helper
INFO - 2018-04-11 22:28:38 --> Helper loaded: language_helper
DEBUG - 2018-04-11 22:28:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 22:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 22:28:38 --> User Agent Class Initialized
INFO - 2018-04-11 22:28:38 --> Controller Class Initialized
INFO - 2018-04-11 22:28:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 22:28:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 22:28:38 --> Pixel_Model class loaded
INFO - 2018-04-11 22:28:38 --> Database Driver Class Initialized
INFO - 2018-04-11 22:28:38 --> Model "MyAccountModel" initialized
INFO - 2018-04-11 22:28:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-04-11 22:28:38 --> Pagination Class Initialized
INFO - 2018-04-11 22:28:38 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 22:28:38 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-11 22:28:38 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-11 22:28:38 --> File loaded: E:\www\yacopoo\application\views\myaccount/users_list.php
INFO - 2018-04-11 22:28:38 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 22:28:38 --> Final output sent to browser
DEBUG - 2018-04-11 22:28:38 --> Total execution time: 0.5405
INFO - 2018-04-11 22:28:38 --> Config Class Initialized
INFO - 2018-04-11 22:28:38 --> Hooks Class Initialized
DEBUG - 2018-04-11 22:28:38 --> UTF-8 Support Enabled
INFO - 2018-04-11 22:28:38 --> Utf8 Class Initialized
INFO - 2018-04-11 22:28:38 --> URI Class Initialized
INFO - 2018-04-11 22:28:38 --> Router Class Initialized
INFO - 2018-04-11 22:28:38 --> Output Class Initialized
INFO - 2018-04-11 22:28:38 --> Security Class Initialized
DEBUG - 2018-04-11 22:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:28:39 --> CSRF cookie sent
INFO - 2018-04-11 22:28:39 --> Input Class Initialized
INFO - 2018-04-11 22:28:39 --> Language Class Initialized
ERROR - 2018-04-11 22:28:39 --> 404 Page Not Found: Assets/css
INFO - 2018-04-11 22:30:08 --> Config Class Initialized
INFO - 2018-04-11 22:30:08 --> Hooks Class Initialized
DEBUG - 2018-04-11 22:30:08 --> UTF-8 Support Enabled
INFO - 2018-04-11 22:30:08 --> Utf8 Class Initialized
INFO - 2018-04-11 22:30:08 --> URI Class Initialized
INFO - 2018-04-11 22:30:08 --> Router Class Initialized
INFO - 2018-04-11 22:30:08 --> Output Class Initialized
INFO - 2018-04-11 22:30:08 --> Security Class Initialized
DEBUG - 2018-04-11 22:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:30:08 --> CSRF cookie sent
INFO - 2018-04-11 22:30:08 --> Input Class Initialized
INFO - 2018-04-11 22:30:08 --> Language Class Initialized
INFO - 2018-04-11 22:30:08 --> Loader Class Initialized
INFO - 2018-04-11 22:30:08 --> Helper loaded: url_helper
INFO - 2018-04-11 22:30:08 --> Helper loaded: form_helper
INFO - 2018-04-11 22:30:08 --> Helper loaded: language_helper
DEBUG - 2018-04-11 22:30:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 22:30:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 22:30:08 --> User Agent Class Initialized
INFO - 2018-04-11 22:30:08 --> Controller Class Initialized
INFO - 2018-04-11 22:30:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 22:30:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 22:30:08 --> Pixel_Model class loaded
INFO - 2018-04-11 22:30:08 --> Database Driver Class Initialized
INFO - 2018-04-11 22:30:11 --> Model "MyAccountModel" initialized
INFO - 2018-04-11 22:30:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-04-11 22:30:11 --> Pagination Class Initialized
INFO - 2018-04-11 22:30:11 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 22:30:11 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-11 22:30:11 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-11 22:30:11 --> File loaded: E:\www\yacopoo\application\views\myaccount/users_list.php
INFO - 2018-04-11 22:30:11 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 22:30:11 --> Final output sent to browser
DEBUG - 2018-04-11 22:30:12 --> Total execution time: 3.5734
INFO - 2018-04-11 22:30:12 --> Config Class Initialized
INFO - 2018-04-11 22:30:12 --> Hooks Class Initialized
DEBUG - 2018-04-11 22:30:12 --> UTF-8 Support Enabled
INFO - 2018-04-11 22:30:12 --> Utf8 Class Initialized
INFO - 2018-04-11 22:30:12 --> URI Class Initialized
INFO - 2018-04-11 22:30:12 --> Router Class Initialized
INFO - 2018-04-11 22:30:12 --> Output Class Initialized
INFO - 2018-04-11 22:30:12 --> Security Class Initialized
DEBUG - 2018-04-11 22:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:30:12 --> CSRF cookie sent
INFO - 2018-04-11 22:30:12 --> Input Class Initialized
INFO - 2018-04-11 22:30:12 --> Language Class Initialized
ERROR - 2018-04-11 22:30:12 --> 404 Page Not Found: Assets/css
INFO - 2018-04-11 22:47:21 --> Config Class Initialized
INFO - 2018-04-11 22:47:21 --> Hooks Class Initialized
DEBUG - 2018-04-11 22:47:21 --> UTF-8 Support Enabled
INFO - 2018-04-11 22:47:21 --> Utf8 Class Initialized
INFO - 2018-04-11 22:47:21 --> URI Class Initialized
INFO - 2018-04-11 22:47:21 --> Router Class Initialized
INFO - 2018-04-11 22:47:21 --> Output Class Initialized
INFO - 2018-04-11 22:47:21 --> Security Class Initialized
DEBUG - 2018-04-11 22:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:47:21 --> CSRF cookie sent
INFO - 2018-04-11 22:47:21 --> Input Class Initialized
INFO - 2018-04-11 22:47:21 --> Language Class Initialized
INFO - 2018-04-11 22:47:21 --> Loader Class Initialized
INFO - 2018-04-11 22:47:21 --> Helper loaded: url_helper
INFO - 2018-04-11 22:47:21 --> Helper loaded: form_helper
INFO - 2018-04-11 22:47:21 --> Helper loaded: language_helper
DEBUG - 2018-04-11 22:47:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 22:47:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 22:47:21 --> User Agent Class Initialized
INFO - 2018-04-11 22:47:21 --> Controller Class Initialized
INFO - 2018-04-11 22:47:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 22:47:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 22:47:21 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 22:48:06 --> Config Class Initialized
INFO - 2018-04-11 22:48:06 --> Hooks Class Initialized
DEBUG - 2018-04-11 22:48:06 --> UTF-8 Support Enabled
INFO - 2018-04-11 22:48:06 --> Utf8 Class Initialized
INFO - 2018-04-11 22:48:06 --> URI Class Initialized
INFO - 2018-04-11 22:48:06 --> Router Class Initialized
INFO - 2018-04-11 22:48:06 --> Output Class Initialized
INFO - 2018-04-11 22:48:06 --> Security Class Initialized
DEBUG - 2018-04-11 22:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:48:06 --> CSRF cookie sent
INFO - 2018-04-11 22:48:06 --> Input Class Initialized
INFO - 2018-04-11 22:48:06 --> Language Class Initialized
INFO - 2018-04-11 22:48:06 --> Loader Class Initialized
INFO - 2018-04-11 22:48:06 --> Helper loaded: url_helper
INFO - 2018-04-11 22:48:06 --> Helper loaded: form_helper
INFO - 2018-04-11 22:48:06 --> Helper loaded: language_helper
DEBUG - 2018-04-11 22:48:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 22:48:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 22:48:06 --> User Agent Class Initialized
INFO - 2018-04-11 22:48:06 --> Controller Class Initialized
INFO - 2018-04-11 22:48:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 22:48:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 22:48:06 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 22:48:16 --> Config Class Initialized
INFO - 2018-04-11 22:48:16 --> Hooks Class Initialized
DEBUG - 2018-04-11 22:48:16 --> UTF-8 Support Enabled
INFO - 2018-04-11 22:48:16 --> Utf8 Class Initialized
INFO - 2018-04-11 22:48:16 --> URI Class Initialized
INFO - 2018-04-11 22:48:16 --> Router Class Initialized
INFO - 2018-04-11 22:48:16 --> Output Class Initialized
INFO - 2018-04-11 22:48:16 --> Security Class Initialized
DEBUG - 2018-04-11 22:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:48:16 --> CSRF cookie sent
INFO - 2018-04-11 22:48:16 --> Input Class Initialized
INFO - 2018-04-11 22:48:16 --> Language Class Initialized
INFO - 2018-04-11 22:48:16 --> Loader Class Initialized
INFO - 2018-04-11 22:48:16 --> Helper loaded: url_helper
INFO - 2018-04-11 22:48:16 --> Helper loaded: form_helper
INFO - 2018-04-11 22:48:16 --> Helper loaded: language_helper
DEBUG - 2018-04-11 22:48:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 22:48:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 22:48:16 --> User Agent Class Initialized
INFO - 2018-04-11 22:48:16 --> Controller Class Initialized
INFO - 2018-04-11 22:48:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 22:48:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 22:48:16 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 22:48:16 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-11 22:48:16 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-11 22:48:16 --> Severity: Notice --> Undefined variable: action E:\www\yacopoo\application\views\myaccount\add_institute.php 9
ERROR - 2018-04-11 22:48:16 --> Severity: Notice --> Undefined variable: obj E:\www\yacopoo\application\views\myaccount\add_institute.php 10
ERROR - 2018-04-11 22:48:16 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\myaccount\add_institute.php 10
ERROR - 2018-04-11 22:48:16 --> Severity: Notice --> Undefined variable: obj E:\www\yacopoo\application\views\myaccount\add_institute.php 23
ERROR - 2018-04-11 22:48:16 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\myaccount\add_institute.php 23
ERROR - 2018-04-11 22:48:16 --> Severity: Notice --> Undefined variable: obj E:\www\yacopoo\application\views\myaccount\add_institute.php 32
ERROR - 2018-04-11 22:48:16 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\myaccount\add_institute.php 32
ERROR - 2018-04-11 22:48:16 --> Severity: Notice --> Undefined variable: obj E:\www\yacopoo\application\views\myaccount\add_institute.php 39
ERROR - 2018-04-11 22:48:16 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\myaccount\add_institute.php 39
ERROR - 2018-04-11 22:48:16 --> Severity: Notice --> Undefined variable: obj E:\www\yacopoo\application\views\myaccount\add_institute.php 47
ERROR - 2018-04-11 22:48:16 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\myaccount\add_institute.php 47
ERROR - 2018-04-11 22:48:16 --> Severity: Notice --> Undefined variable: obj E:\www\yacopoo\application\views\myaccount\add_institute.php 55
ERROR - 2018-04-11 22:48:16 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\myaccount\add_institute.php 55
ERROR - 2018-04-11 22:48:16 --> Severity: Notice --> Undefined variable: obj E:\www\yacopoo\application\views\myaccount\add_institute.php 62
ERROR - 2018-04-11 22:48:16 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\views\myaccount\add_institute.php 62
ERROR - 2018-04-11 22:48:16 --> Severity: Notice --> Undefined variable: isEdit E:\www\yacopoo\application\views\myaccount\add_institute.php 67
INFO - 2018-04-11 22:48:16 --> File loaded: E:\www\yacopoo\application\views\myaccount/add_institute.php
INFO - 2018-04-11 22:48:16 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 22:48:16 --> Final output sent to browser
DEBUG - 2018-04-11 22:48:17 --> Total execution time: 0.7455
INFO - 2018-04-11 22:48:17 --> Config Class Initialized
INFO - 2018-04-11 22:48:17 --> Hooks Class Initialized
DEBUG - 2018-04-11 22:48:17 --> UTF-8 Support Enabled
INFO - 2018-04-11 22:48:17 --> Utf8 Class Initialized
INFO - 2018-04-11 22:48:17 --> URI Class Initialized
INFO - 2018-04-11 22:48:17 --> Router Class Initialized
INFO - 2018-04-11 22:48:17 --> Output Class Initialized
INFO - 2018-04-11 22:48:17 --> Security Class Initialized
DEBUG - 2018-04-11 22:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:48:17 --> CSRF cookie sent
INFO - 2018-04-11 22:48:17 --> Input Class Initialized
INFO - 2018-04-11 22:48:17 --> Language Class Initialized
ERROR - 2018-04-11 22:48:17 --> 404 Page Not Found: Assets/css
INFO - 2018-04-11 22:48:33 --> Config Class Initialized
INFO - 2018-04-11 22:48:33 --> Hooks Class Initialized
DEBUG - 2018-04-11 22:48:33 --> UTF-8 Support Enabled
INFO - 2018-04-11 22:48:33 --> Utf8 Class Initialized
INFO - 2018-04-11 22:48:33 --> URI Class Initialized
INFO - 2018-04-11 22:48:33 --> Router Class Initialized
INFO - 2018-04-11 22:48:33 --> Output Class Initialized
INFO - 2018-04-11 22:48:33 --> Security Class Initialized
DEBUG - 2018-04-11 22:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:48:33 --> CSRF cookie sent
INFO - 2018-04-11 22:48:33 --> Input Class Initialized
INFO - 2018-04-11 22:48:33 --> Language Class Initialized
INFO - 2018-04-11 22:48:33 --> Loader Class Initialized
INFO - 2018-04-11 22:48:33 --> Helper loaded: url_helper
INFO - 2018-04-11 22:48:33 --> Helper loaded: form_helper
INFO - 2018-04-11 22:48:33 --> Helper loaded: language_helper
DEBUG - 2018-04-11 22:48:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 22:48:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 22:48:33 --> User Agent Class Initialized
INFO - 2018-04-11 22:48:33 --> Controller Class Initialized
INFO - 2018-04-11 22:48:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 22:48:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 22:48:33 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 22:48:33 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-11 22:48:33 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-11 22:48:33 --> File loaded: E:\www\yacopoo\application\views\myaccount/add_institute.php
INFO - 2018-04-11 22:48:34 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 22:48:34 --> Final output sent to browser
DEBUG - 2018-04-11 22:48:34 --> Total execution time: 0.4606
INFO - 2018-04-11 22:48:34 --> Config Class Initialized
INFO - 2018-04-11 22:48:34 --> Hooks Class Initialized
DEBUG - 2018-04-11 22:48:34 --> UTF-8 Support Enabled
INFO - 2018-04-11 22:48:34 --> Utf8 Class Initialized
INFO - 2018-04-11 22:48:34 --> URI Class Initialized
INFO - 2018-04-11 22:48:34 --> Router Class Initialized
INFO - 2018-04-11 22:48:34 --> Output Class Initialized
INFO - 2018-04-11 22:48:34 --> Security Class Initialized
DEBUG - 2018-04-11 22:48:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:48:34 --> CSRF cookie sent
INFO - 2018-04-11 22:48:34 --> Input Class Initialized
INFO - 2018-04-11 22:48:34 --> Language Class Initialized
ERROR - 2018-04-11 22:48:34 --> 404 Page Not Found: Assets/css
INFO - 2018-04-11 22:58:29 --> Config Class Initialized
INFO - 2018-04-11 22:58:29 --> Hooks Class Initialized
DEBUG - 2018-04-11 22:58:29 --> UTF-8 Support Enabled
INFO - 2018-04-11 22:58:29 --> Utf8 Class Initialized
INFO - 2018-04-11 22:58:29 --> URI Class Initialized
INFO - 2018-04-11 22:58:29 --> Router Class Initialized
INFO - 2018-04-11 22:58:29 --> Output Class Initialized
INFO - 2018-04-11 22:58:29 --> Security Class Initialized
DEBUG - 2018-04-11 22:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:58:29 --> CSRF cookie sent
INFO - 2018-04-11 22:58:29 --> Input Class Initialized
INFO - 2018-04-11 22:58:29 --> Language Class Initialized
INFO - 2018-04-11 22:58:29 --> Loader Class Initialized
INFO - 2018-04-11 22:58:29 --> Helper loaded: url_helper
INFO - 2018-04-11 22:58:29 --> Helper loaded: form_helper
INFO - 2018-04-11 22:58:29 --> Helper loaded: language_helper
DEBUG - 2018-04-11 22:58:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 22:58:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 22:58:29 --> User Agent Class Initialized
INFO - 2018-04-11 22:58:29 --> Controller Class Initialized
INFO - 2018-04-11 22:58:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 22:58:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 22:58:29 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 22:58:29 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-11 22:58:29 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-11 22:58:29 --> File loaded: E:\www\yacopoo\application\views\myaccount/add_institute.php
INFO - 2018-04-11 22:58:29 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 22:58:29 --> Final output sent to browser
DEBUG - 2018-04-11 22:58:29 --> Total execution time: 0.4994
INFO - 2018-04-11 22:58:30 --> Config Class Initialized
INFO - 2018-04-11 22:58:30 --> Hooks Class Initialized
DEBUG - 2018-04-11 22:58:30 --> UTF-8 Support Enabled
INFO - 2018-04-11 22:58:30 --> Utf8 Class Initialized
INFO - 2018-04-11 22:58:30 --> URI Class Initialized
INFO - 2018-04-11 22:58:30 --> Router Class Initialized
INFO - 2018-04-11 22:58:30 --> Output Class Initialized
INFO - 2018-04-11 22:58:30 --> Security Class Initialized
DEBUG - 2018-04-11 22:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:58:30 --> CSRF cookie sent
INFO - 2018-04-11 22:58:30 --> Input Class Initialized
INFO - 2018-04-11 22:58:30 --> Language Class Initialized
ERROR - 2018-04-11 22:58:30 --> 404 Page Not Found: Assets/css
INFO - 2018-04-11 22:58:47 --> Config Class Initialized
INFO - 2018-04-11 22:58:47 --> Hooks Class Initialized
DEBUG - 2018-04-11 22:58:47 --> UTF-8 Support Enabled
INFO - 2018-04-11 22:58:47 --> Utf8 Class Initialized
INFO - 2018-04-11 22:58:47 --> URI Class Initialized
INFO - 2018-04-11 22:58:47 --> Router Class Initialized
INFO - 2018-04-11 22:58:47 --> Output Class Initialized
INFO - 2018-04-11 22:58:47 --> Security Class Initialized
DEBUG - 2018-04-11 22:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:58:47 --> CSRF cookie sent
INFO - 2018-04-11 22:58:47 --> CSRF token verified
INFO - 2018-04-11 22:58:47 --> Input Class Initialized
INFO - 2018-04-11 22:58:47 --> Language Class Initialized
INFO - 2018-04-11 22:58:47 --> Loader Class Initialized
INFO - 2018-04-11 22:58:47 --> Helper loaded: url_helper
INFO - 2018-04-11 22:58:47 --> Helper loaded: form_helper
INFO - 2018-04-11 22:58:47 --> Helper loaded: language_helper
DEBUG - 2018-04-11 22:58:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 22:58:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 22:58:47 --> User Agent Class Initialized
INFO - 2018-04-11 22:58:47 --> Controller Class Initialized
INFO - 2018-04-11 22:58:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 22:58:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 22:58:48 --> Form Validation Class Initialized
INFO - 2018-04-11 22:58:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-11 22:58:48 --> Pixel_Model class loaded
INFO - 2018-04-11 22:58:48 --> Database Driver Class Initialized
INFO - 2018-04-11 22:58:51 --> Model "MyAccountModel" initialized
ERROR - 2018-04-11 22:58:51 --> Query error: Unknown column 'aid' in 'field list' - Invalid query: INSERT INTO `institutions` (`aid`, `name`, `address`, `contact_person`, `email`, `phone`, `fax`) VALUES ('0', 'Td Bank', '97 Fallingdale Crescent', 'Saqib', 'saqib@cronomagic.com', '6474788263', '')
INFO - 2018-04-11 22:58:51 --> Language file loaded: language/english/db_lang.php
INFO - 2018-04-11 22:59:19 --> Config Class Initialized
INFO - 2018-04-11 22:59:19 --> Hooks Class Initialized
DEBUG - 2018-04-11 22:59:19 --> UTF-8 Support Enabled
INFO - 2018-04-11 22:59:19 --> Utf8 Class Initialized
INFO - 2018-04-11 22:59:19 --> URI Class Initialized
INFO - 2018-04-11 22:59:19 --> Router Class Initialized
INFO - 2018-04-11 22:59:19 --> Output Class Initialized
INFO - 2018-04-11 22:59:19 --> Security Class Initialized
DEBUG - 2018-04-11 22:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:59:19 --> CSRF cookie sent
INFO - 2018-04-11 22:59:19 --> CSRF token verified
INFO - 2018-04-11 22:59:19 --> Input Class Initialized
INFO - 2018-04-11 22:59:19 --> Language Class Initialized
INFO - 2018-04-11 22:59:19 --> Loader Class Initialized
INFO - 2018-04-11 22:59:19 --> Helper loaded: url_helper
INFO - 2018-04-11 22:59:19 --> Helper loaded: form_helper
INFO - 2018-04-11 22:59:19 --> Helper loaded: language_helper
DEBUG - 2018-04-11 22:59:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 22:59:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 22:59:19 --> User Agent Class Initialized
INFO - 2018-04-11 22:59:19 --> Controller Class Initialized
INFO - 2018-04-11 22:59:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 22:59:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 22:59:19 --> Form Validation Class Initialized
INFO - 2018-04-11 22:59:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-11 22:59:19 --> Pixel_Model class loaded
INFO - 2018-04-11 22:59:19 --> Database Driver Class Initialized
INFO - 2018-04-11 22:59:22 --> Model "MyAccountModel" initialized
INFO - 2018-04-11 22:59:22 --> Config Class Initialized
INFO - 2018-04-11 22:59:22 --> Hooks Class Initialized
DEBUG - 2018-04-11 22:59:22 --> UTF-8 Support Enabled
INFO - 2018-04-11 22:59:22 --> Utf8 Class Initialized
INFO - 2018-04-11 22:59:22 --> URI Class Initialized
INFO - 2018-04-11 22:59:22 --> Router Class Initialized
INFO - 2018-04-11 22:59:22 --> Output Class Initialized
INFO - 2018-04-11 22:59:22 --> Security Class Initialized
DEBUG - 2018-04-11 22:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:59:22 --> CSRF cookie sent
INFO - 2018-04-11 22:59:22 --> Input Class Initialized
INFO - 2018-04-11 22:59:22 --> Language Class Initialized
INFO - 2018-04-11 22:59:22 --> Loader Class Initialized
INFO - 2018-04-11 22:59:22 --> Helper loaded: url_helper
INFO - 2018-04-11 22:59:22 --> Helper loaded: form_helper
INFO - 2018-04-11 22:59:22 --> Helper loaded: language_helper
DEBUG - 2018-04-11 22:59:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 22:59:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 22:59:22 --> User Agent Class Initialized
INFO - 2018-04-11 22:59:22 --> Controller Class Initialized
INFO - 2018-04-11 22:59:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 22:59:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 22:59:23 --> Pixel_Model class loaded
INFO - 2018-04-11 22:59:23 --> Database Driver Class Initialized
INFO - 2018-04-11 22:59:23 --> Model "MyAccountModel" initialized
INFO - 2018-04-11 22:59:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-04-11 22:59:23 --> Pagination Class Initialized
INFO - 2018-04-11 22:59:23 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 22:59:23 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-11 22:59:23 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-11 22:59:23 --> Severity: Notice --> Undefined property: stdClass::$active E:\www\yacopoo\application\views\myaccount\institute_list.php 71
INFO - 2018-04-11 22:59:23 --> File loaded: E:\www\yacopoo\application\views\myaccount/institute_list.php
INFO - 2018-04-11 22:59:23 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 22:59:23 --> Final output sent to browser
DEBUG - 2018-04-11 22:59:23 --> Total execution time: 0.5421
INFO - 2018-04-11 22:59:24 --> Config Class Initialized
INFO - 2018-04-11 22:59:24 --> Hooks Class Initialized
DEBUG - 2018-04-11 22:59:24 --> UTF-8 Support Enabled
INFO - 2018-04-11 22:59:24 --> Utf8 Class Initialized
INFO - 2018-04-11 22:59:24 --> URI Class Initialized
INFO - 2018-04-11 22:59:24 --> Router Class Initialized
INFO - 2018-04-11 22:59:24 --> Output Class Initialized
INFO - 2018-04-11 22:59:24 --> Security Class Initialized
DEBUG - 2018-04-11 22:59:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:59:24 --> CSRF cookie sent
INFO - 2018-04-11 22:59:24 --> Input Class Initialized
INFO - 2018-04-11 22:59:24 --> Language Class Initialized
ERROR - 2018-04-11 22:59:24 --> 404 Page Not Found: Assets/css
INFO - 2018-04-11 22:59:43 --> Config Class Initialized
INFO - 2018-04-11 22:59:43 --> Hooks Class Initialized
DEBUG - 2018-04-11 22:59:43 --> UTF-8 Support Enabled
INFO - 2018-04-11 22:59:43 --> Utf8 Class Initialized
INFO - 2018-04-11 22:59:43 --> URI Class Initialized
INFO - 2018-04-11 22:59:43 --> Router Class Initialized
INFO - 2018-04-11 22:59:43 --> Output Class Initialized
INFO - 2018-04-11 22:59:43 --> Security Class Initialized
DEBUG - 2018-04-11 22:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:59:43 --> CSRF cookie sent
INFO - 2018-04-11 22:59:43 --> Input Class Initialized
INFO - 2018-04-11 22:59:43 --> Language Class Initialized
INFO - 2018-04-11 22:59:43 --> Loader Class Initialized
INFO - 2018-04-11 22:59:43 --> Helper loaded: url_helper
INFO - 2018-04-11 22:59:43 --> Helper loaded: form_helper
INFO - 2018-04-11 22:59:43 --> Helper loaded: language_helper
DEBUG - 2018-04-11 22:59:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 22:59:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 22:59:43 --> User Agent Class Initialized
INFO - 2018-04-11 22:59:43 --> Controller Class Initialized
INFO - 2018-04-11 22:59:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 22:59:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 22:59:43 --> Pixel_Model class loaded
INFO - 2018-04-11 22:59:43 --> Database Driver Class Initialized
INFO - 2018-04-11 22:59:43 --> Model "MyAccountModel" initialized
INFO - 2018-04-11 22:59:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-04-11 22:59:43 --> Pagination Class Initialized
INFO - 2018-04-11 22:59:43 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 22:59:43 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-11 22:59:43 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-11 22:59:43 --> File loaded: E:\www\yacopoo\application\views\myaccount/institute_list.php
INFO - 2018-04-11 22:59:43 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 22:59:43 --> Final output sent to browser
DEBUG - 2018-04-11 22:59:43 --> Total execution time: 0.5550
INFO - 2018-04-11 22:59:44 --> Config Class Initialized
INFO - 2018-04-11 22:59:44 --> Hooks Class Initialized
DEBUG - 2018-04-11 22:59:44 --> UTF-8 Support Enabled
INFO - 2018-04-11 22:59:44 --> Utf8 Class Initialized
INFO - 2018-04-11 22:59:44 --> URI Class Initialized
INFO - 2018-04-11 22:59:44 --> Router Class Initialized
INFO - 2018-04-11 22:59:44 --> Output Class Initialized
INFO - 2018-04-11 22:59:44 --> Security Class Initialized
DEBUG - 2018-04-11 22:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:59:44 --> CSRF cookie sent
INFO - 2018-04-11 22:59:44 --> Input Class Initialized
INFO - 2018-04-11 22:59:44 --> Language Class Initialized
ERROR - 2018-04-11 22:59:44 --> 404 Page Not Found: Assets/css
INFO - 2018-04-11 22:59:47 --> Config Class Initialized
INFO - 2018-04-11 22:59:47 --> Hooks Class Initialized
DEBUG - 2018-04-11 22:59:47 --> UTF-8 Support Enabled
INFO - 2018-04-11 22:59:47 --> Utf8 Class Initialized
INFO - 2018-04-11 22:59:47 --> URI Class Initialized
INFO - 2018-04-11 22:59:47 --> Router Class Initialized
INFO - 2018-04-11 22:59:47 --> Output Class Initialized
INFO - 2018-04-11 22:59:47 --> Security Class Initialized
DEBUG - 2018-04-11 22:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:59:47 --> CSRF cookie sent
INFO - 2018-04-11 22:59:47 --> Input Class Initialized
INFO - 2018-04-11 22:59:47 --> Language Class Initialized
INFO - 2018-04-11 22:59:47 --> Loader Class Initialized
INFO - 2018-04-11 22:59:47 --> Helper loaded: url_helper
INFO - 2018-04-11 22:59:47 --> Helper loaded: form_helper
INFO - 2018-04-11 22:59:47 --> Helper loaded: language_helper
DEBUG - 2018-04-11 22:59:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 22:59:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 22:59:47 --> User Agent Class Initialized
INFO - 2018-04-11 22:59:47 --> Controller Class Initialized
INFO - 2018-04-11 22:59:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 22:59:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 22:59:47 --> Pixel_Model class loaded
INFO - 2018-04-11 22:59:47 --> Database Driver Class Initialized
INFO - 2018-04-11 22:59:47 --> Model "MyAccountModel" initialized
INFO - 2018-04-11 22:59:47 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 22:59:47 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-11 22:59:47 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-11 22:59:47 --> File loaded: E:\www\yacopoo\application\views\myaccount/add_institute.php
INFO - 2018-04-11 22:59:47 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 22:59:47 --> Final output sent to browser
DEBUG - 2018-04-11 22:59:47 --> Total execution time: 0.5723
INFO - 2018-04-11 22:59:48 --> Config Class Initialized
INFO - 2018-04-11 22:59:48 --> Hooks Class Initialized
DEBUG - 2018-04-11 22:59:48 --> UTF-8 Support Enabled
INFO - 2018-04-11 22:59:48 --> Utf8 Class Initialized
INFO - 2018-04-11 22:59:48 --> URI Class Initialized
INFO - 2018-04-11 22:59:48 --> Router Class Initialized
INFO - 2018-04-11 22:59:48 --> Output Class Initialized
INFO - 2018-04-11 22:59:48 --> Security Class Initialized
DEBUG - 2018-04-11 22:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:59:48 --> CSRF cookie sent
INFO - 2018-04-11 22:59:48 --> Input Class Initialized
INFO - 2018-04-11 22:59:48 --> Language Class Initialized
ERROR - 2018-04-11 22:59:48 --> 404 Page Not Found: Assets/css
INFO - 2018-04-11 22:59:55 --> Config Class Initialized
INFO - 2018-04-11 22:59:55 --> Hooks Class Initialized
DEBUG - 2018-04-11 22:59:55 --> UTF-8 Support Enabled
INFO - 2018-04-11 22:59:55 --> Utf8 Class Initialized
INFO - 2018-04-11 22:59:55 --> URI Class Initialized
INFO - 2018-04-11 22:59:55 --> Router Class Initialized
INFO - 2018-04-11 22:59:55 --> Output Class Initialized
INFO - 2018-04-11 22:59:55 --> Security Class Initialized
DEBUG - 2018-04-11 22:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:59:55 --> CSRF cookie sent
INFO - 2018-04-11 22:59:55 --> CSRF token verified
INFO - 2018-04-11 22:59:55 --> Input Class Initialized
INFO - 2018-04-11 22:59:55 --> Language Class Initialized
INFO - 2018-04-11 22:59:55 --> Loader Class Initialized
INFO - 2018-04-11 22:59:55 --> Helper loaded: url_helper
INFO - 2018-04-11 22:59:55 --> Helper loaded: form_helper
INFO - 2018-04-11 22:59:55 --> Helper loaded: language_helper
DEBUG - 2018-04-11 22:59:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 22:59:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 22:59:55 --> User Agent Class Initialized
INFO - 2018-04-11 22:59:55 --> Controller Class Initialized
INFO - 2018-04-11 22:59:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 22:59:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 22:59:55 --> Form Validation Class Initialized
INFO - 2018-04-11 22:59:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-11 22:59:55 --> Pixel_Model class loaded
INFO - 2018-04-11 22:59:55 --> Database Driver Class Initialized
INFO - 2018-04-11 22:59:55 --> Model "MyAccountModel" initialized
INFO - 2018-04-11 22:59:55 --> Config Class Initialized
INFO - 2018-04-11 22:59:55 --> Hooks Class Initialized
DEBUG - 2018-04-11 22:59:55 --> UTF-8 Support Enabled
INFO - 2018-04-11 22:59:55 --> Utf8 Class Initialized
INFO - 2018-04-11 22:59:55 --> URI Class Initialized
INFO - 2018-04-11 22:59:55 --> Router Class Initialized
INFO - 2018-04-11 22:59:55 --> Output Class Initialized
INFO - 2018-04-11 22:59:55 --> Security Class Initialized
DEBUG - 2018-04-11 22:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:59:55 --> CSRF cookie sent
INFO - 2018-04-11 22:59:55 --> Input Class Initialized
INFO - 2018-04-11 22:59:55 --> Language Class Initialized
INFO - 2018-04-11 22:59:55 --> Loader Class Initialized
INFO - 2018-04-11 22:59:55 --> Helper loaded: url_helper
INFO - 2018-04-11 22:59:55 --> Helper loaded: form_helper
INFO - 2018-04-11 22:59:55 --> Helper loaded: language_helper
DEBUG - 2018-04-11 22:59:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 22:59:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 22:59:55 --> User Agent Class Initialized
INFO - 2018-04-11 22:59:55 --> Controller Class Initialized
INFO - 2018-04-11 22:59:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 22:59:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 22:59:55 --> Pixel_Model class loaded
INFO - 2018-04-11 22:59:55 --> Database Driver Class Initialized
INFO - 2018-04-11 22:59:55 --> Model "MyAccountModel" initialized
INFO - 2018-04-11 22:59:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-04-11 22:59:55 --> Pagination Class Initialized
INFO - 2018-04-11 22:59:56 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 22:59:56 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-11 22:59:56 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-11 22:59:56 --> File loaded: E:\www\yacopoo\application\views\myaccount/institute_list.php
INFO - 2018-04-11 22:59:56 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 22:59:56 --> Final output sent to browser
DEBUG - 2018-04-11 22:59:56 --> Total execution time: 0.5324
INFO - 2018-04-11 22:59:56 --> Config Class Initialized
INFO - 2018-04-11 22:59:56 --> Hooks Class Initialized
DEBUG - 2018-04-11 22:59:56 --> UTF-8 Support Enabled
INFO - 2018-04-11 22:59:56 --> Utf8 Class Initialized
INFO - 2018-04-11 22:59:56 --> URI Class Initialized
INFO - 2018-04-11 22:59:56 --> Router Class Initialized
INFO - 2018-04-11 22:59:56 --> Output Class Initialized
INFO - 2018-04-11 22:59:56 --> Security Class Initialized
DEBUG - 2018-04-11 22:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 22:59:56 --> CSRF cookie sent
INFO - 2018-04-11 22:59:56 --> Input Class Initialized
INFO - 2018-04-11 22:59:56 --> Language Class Initialized
ERROR - 2018-04-11 22:59:56 --> 404 Page Not Found: Assets/css
INFO - 2018-04-11 23:31:42 --> Config Class Initialized
INFO - 2018-04-11 23:31:42 --> Hooks Class Initialized
DEBUG - 2018-04-11 23:31:42 --> UTF-8 Support Enabled
INFO - 2018-04-11 23:31:42 --> Utf8 Class Initialized
INFO - 2018-04-11 23:31:42 --> URI Class Initialized
INFO - 2018-04-11 23:31:42 --> Router Class Initialized
INFO - 2018-04-11 23:31:42 --> Output Class Initialized
INFO - 2018-04-11 23:31:42 --> Security Class Initialized
DEBUG - 2018-04-11 23:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 23:31:42 --> CSRF cookie sent
INFO - 2018-04-11 23:31:42 --> Input Class Initialized
INFO - 2018-04-11 23:31:42 --> Language Class Initialized
INFO - 2018-04-11 23:31:42 --> Loader Class Initialized
INFO - 2018-04-11 23:31:42 --> Helper loaded: url_helper
INFO - 2018-04-11 23:31:42 --> Helper loaded: form_helper
INFO - 2018-04-11 23:31:42 --> Helper loaded: language_helper
DEBUG - 2018-04-11 23:31:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 23:31:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 23:31:42 --> User Agent Class Initialized
INFO - 2018-04-11 23:31:42 --> Controller Class Initialized
INFO - 2018-04-11 23:31:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 23:31:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 23:31:42 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 23:31:42 --> File loaded: E:\www\yacopoo\application\views\faPage1.php
INFO - 2018-04-11 23:31:42 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 23:31:42 --> Final output sent to browser
DEBUG - 2018-04-11 23:31:42 --> Total execution time: 0.4368
INFO - 2018-04-11 23:31:43 --> Config Class Initialized
INFO - 2018-04-11 23:31:43 --> Hooks Class Initialized
DEBUG - 2018-04-11 23:31:43 --> UTF-8 Support Enabled
INFO - 2018-04-11 23:31:43 --> Utf8 Class Initialized
INFO - 2018-04-11 23:31:43 --> URI Class Initialized
INFO - 2018-04-11 23:31:43 --> Router Class Initialized
INFO - 2018-04-11 23:31:43 --> Output Class Initialized
INFO - 2018-04-11 23:31:43 --> Security Class Initialized
DEBUG - 2018-04-11 23:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 23:31:43 --> CSRF cookie sent
INFO - 2018-04-11 23:31:43 --> Input Class Initialized
INFO - 2018-04-11 23:31:43 --> Language Class Initialized
ERROR - 2018-04-11 23:31:43 --> 404 Page Not Found: Assets/css
INFO - 2018-04-11 23:31:57 --> Config Class Initialized
INFO - 2018-04-11 23:31:57 --> Hooks Class Initialized
DEBUG - 2018-04-11 23:31:57 --> UTF-8 Support Enabled
INFO - 2018-04-11 23:31:57 --> Utf8 Class Initialized
INFO - 2018-04-11 23:31:57 --> URI Class Initialized
INFO - 2018-04-11 23:31:57 --> Router Class Initialized
INFO - 2018-04-11 23:31:57 --> Output Class Initialized
INFO - 2018-04-11 23:31:57 --> Security Class Initialized
DEBUG - 2018-04-11 23:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 23:31:57 --> CSRF cookie sent
INFO - 2018-04-11 23:31:57 --> Input Class Initialized
INFO - 2018-04-11 23:31:57 --> Language Class Initialized
INFO - 2018-04-11 23:31:57 --> Loader Class Initialized
INFO - 2018-04-11 23:31:57 --> Helper loaded: url_helper
INFO - 2018-04-11 23:31:57 --> Helper loaded: form_helper
INFO - 2018-04-11 23:31:57 --> Helper loaded: language_helper
DEBUG - 2018-04-11 23:31:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 23:31:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 23:31:57 --> User Agent Class Initialized
INFO - 2018-04-11 23:31:57 --> Controller Class Initialized
INFO - 2018-04-11 23:31:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 23:31:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 23:31:57 --> Pixel_Model class loaded
INFO - 2018-04-11 23:31:57 --> Database Driver Class Initialized
INFO - 2018-04-11 23:32:00 --> Model "MyAccountModel" initialized
INFO - 2018-04-11 23:32:00 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 23:32:00 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-11 23:32:00 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-11 23:32:00 --> File loaded: E:\www\yacopoo\application\views\register/import_fa.php
INFO - 2018-04-11 23:32:00 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 23:32:00 --> Final output sent to browser
DEBUG - 2018-04-11 23:32:00 --> Total execution time: 3.5266
INFO - 2018-04-11 23:32:01 --> Config Class Initialized
INFO - 2018-04-11 23:32:01 --> Hooks Class Initialized
DEBUG - 2018-04-11 23:32:01 --> UTF-8 Support Enabled
INFO - 2018-04-11 23:32:01 --> Utf8 Class Initialized
INFO - 2018-04-11 23:32:01 --> URI Class Initialized
INFO - 2018-04-11 23:32:01 --> Router Class Initialized
INFO - 2018-04-11 23:32:01 --> Output Class Initialized
INFO - 2018-04-11 23:32:01 --> Security Class Initialized
DEBUG - 2018-04-11 23:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 23:32:01 --> CSRF cookie sent
INFO - 2018-04-11 23:32:01 --> Input Class Initialized
INFO - 2018-04-11 23:32:01 --> Language Class Initialized
ERROR - 2018-04-11 23:32:01 --> 404 Page Not Found: Assets/css
INFO - 2018-04-11 23:36:10 --> Config Class Initialized
INFO - 2018-04-11 23:36:10 --> Hooks Class Initialized
DEBUG - 2018-04-11 23:36:10 --> UTF-8 Support Enabled
INFO - 2018-04-11 23:36:10 --> Utf8 Class Initialized
INFO - 2018-04-11 23:36:10 --> URI Class Initialized
INFO - 2018-04-11 23:36:10 --> Router Class Initialized
INFO - 2018-04-11 23:36:10 --> Output Class Initialized
INFO - 2018-04-11 23:36:10 --> Security Class Initialized
DEBUG - 2018-04-11 23:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 23:36:10 --> CSRF cookie sent
INFO - 2018-04-11 23:36:10 --> Input Class Initialized
INFO - 2018-04-11 23:36:10 --> Language Class Initialized
INFO - 2018-04-11 23:36:10 --> Loader Class Initialized
INFO - 2018-04-11 23:36:10 --> Helper loaded: url_helper
INFO - 2018-04-11 23:36:10 --> Helper loaded: form_helper
INFO - 2018-04-11 23:36:10 --> Helper loaded: language_helper
DEBUG - 2018-04-11 23:36:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 23:36:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 23:36:10 --> User Agent Class Initialized
INFO - 2018-04-11 23:36:10 --> Controller Class Initialized
INFO - 2018-04-11 23:36:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 23:36:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 23:36:10 --> Pixel_Model class loaded
INFO - 2018-04-11 23:36:10 --> Database Driver Class Initialized
INFO - 2018-04-11 23:36:13 --> Model "MyAccountModel" initialized
INFO - 2018-04-11 23:36:13 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 23:36:13 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-11 23:36:13 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-11 23:36:13 --> File loaded: E:\www\yacopoo\application\views\register/import_fa.php
INFO - 2018-04-11 23:36:13 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 23:36:13 --> Final output sent to browser
DEBUG - 2018-04-11 23:36:14 --> Total execution time: 3.5980
INFO - 2018-04-11 23:36:15 --> Config Class Initialized
INFO - 2018-04-11 23:36:15 --> Hooks Class Initialized
DEBUG - 2018-04-11 23:36:15 --> UTF-8 Support Enabled
INFO - 2018-04-11 23:36:15 --> Utf8 Class Initialized
INFO - 2018-04-11 23:36:15 --> URI Class Initialized
INFO - 2018-04-11 23:36:15 --> Router Class Initialized
INFO - 2018-04-11 23:36:15 --> Output Class Initialized
INFO - 2018-04-11 23:36:15 --> Security Class Initialized
DEBUG - 2018-04-11 23:36:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 23:36:15 --> CSRF cookie sent
INFO - 2018-04-11 23:36:15 --> Input Class Initialized
INFO - 2018-04-11 23:36:15 --> Language Class Initialized
ERROR - 2018-04-11 23:36:15 --> 404 Page Not Found: Assets/css
INFO - 2018-04-11 23:36:20 --> Config Class Initialized
INFO - 2018-04-11 23:36:20 --> Hooks Class Initialized
DEBUG - 2018-04-11 23:36:20 --> UTF-8 Support Enabled
INFO - 2018-04-11 23:36:20 --> Utf8 Class Initialized
INFO - 2018-04-11 23:36:20 --> URI Class Initialized
INFO - 2018-04-11 23:36:20 --> Router Class Initialized
INFO - 2018-04-11 23:36:20 --> Output Class Initialized
INFO - 2018-04-11 23:36:20 --> Security Class Initialized
DEBUG - 2018-04-11 23:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 23:36:20 --> CSRF cookie sent
INFO - 2018-04-11 23:36:20 --> CSRF token verified
INFO - 2018-04-11 23:36:20 --> Input Class Initialized
INFO - 2018-04-11 23:36:20 --> Language Class Initialized
INFO - 2018-04-11 23:36:20 --> Loader Class Initialized
INFO - 2018-04-11 23:36:20 --> Helper loaded: url_helper
INFO - 2018-04-11 23:36:20 --> Helper loaded: form_helper
INFO - 2018-04-11 23:36:20 --> Helper loaded: language_helper
DEBUG - 2018-04-11 23:36:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 23:36:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 23:36:20 --> User Agent Class Initialized
INFO - 2018-04-11 23:36:20 --> Controller Class Initialized
INFO - 2018-04-11 23:36:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 23:36:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 23:36:20 --> Upload Class Initialized
INFO - 2018-04-11 23:36:20 --> Final output sent to browser
DEBUG - 2018-04-11 23:36:20 --> Total execution time: 0.5941
INFO - 2018-04-11 23:48:21 --> Config Class Initialized
INFO - 2018-04-11 23:48:21 --> Hooks Class Initialized
DEBUG - 2018-04-11 23:48:21 --> UTF-8 Support Enabled
INFO - 2018-04-11 23:48:21 --> Utf8 Class Initialized
INFO - 2018-04-11 23:48:21 --> URI Class Initialized
INFO - 2018-04-11 23:48:21 --> Router Class Initialized
INFO - 2018-04-11 23:48:21 --> Output Class Initialized
INFO - 2018-04-11 23:48:21 --> Security Class Initialized
DEBUG - 2018-04-11 23:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 23:48:21 --> CSRF cookie sent
INFO - 2018-04-11 23:48:21 --> CSRF token verified
INFO - 2018-04-11 23:48:21 --> Input Class Initialized
INFO - 2018-04-11 23:48:21 --> Language Class Initialized
INFO - 2018-04-11 23:48:21 --> Loader Class Initialized
INFO - 2018-04-11 23:48:21 --> Helper loaded: url_helper
INFO - 2018-04-11 23:48:21 --> Helper loaded: form_helper
INFO - 2018-04-11 23:48:21 --> Helper loaded: language_helper
DEBUG - 2018-04-11 23:48:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 23:48:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 23:48:21 --> User Agent Class Initialized
INFO - 2018-04-11 23:48:21 --> Controller Class Initialized
INFO - 2018-04-11 23:48:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 23:48:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 23:48:21 --> Upload Class Initialized
INFO - 2018-04-11 23:48:21 --> Pixel_Model class loaded
INFO - 2018-04-11 23:48:21 --> Database Driver Class Initialized
INFO - 2018-04-11 23:48:24 --> Model "RegistrationModel" initialized
INFO - 2018-04-11 23:48:24 --> Database Driver Class Initialized
INFO - 2018-04-11 23:48:24 --> Model "RegistrationModel" initialized
INFO - 2018-04-11 23:48:24 --> Helper loaded: string_helper
INFO - 2018-04-11 23:48:24 --> Language file loaded: language/en/notifications_lang.php
INFO - 2018-04-11 23:48:25 --> File loaded: E:\www\yacopoo\application\views\emails/_buttons.php
INFO - 2018-04-11 23:48:25 --> File loaded: E:\www\yacopoo\application\views\emails/header.php
INFO - 2018-04-11 23:48:25 --> File loaded: E:\www\yacopoo\application\views\emails/footer.php
INFO - 2018-04-11 23:48:25 --> File loaded: E:\www\yacopoo\application\views\emails/generic.php
INFO - 2018-04-11 23:48:25 --> Email Class Initialized
ERROR - 2018-04-11 23:48:26 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() E:\www\yacopoo\system\libraries\Email.php 1888
INFO - 2018-04-11 23:48:26 --> Language file loaded: language/english/email_lang.php
DEBUG - 2018-04-11 23:48:26 --> EmailsHelper class already loaded. Second attempt ignored.
INFO - 2018-04-11 23:48:26 --> File loaded: E:\www\yacopoo\application\views\emails/_buttons.php
INFO - 2018-04-11 23:48:26 --> File loaded: E:\www\yacopoo\application\views\emails/header.php
INFO - 2018-04-11 23:48:26 --> File loaded: E:\www\yacopoo\application\views\emails/footer.php
INFO - 2018-04-11 23:48:26 --> File loaded: E:\www\yacopoo\application\views\emails/generic.php
DEBUG - 2018-04-11 23:48:26 --> Email class already loaded. Second attempt ignored.
ERROR - 2018-04-11 23:48:28 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() E:\www\yacopoo\system\libraries\Email.php 1888
DEBUG - 2018-04-11 23:48:28 --> EmailsHelper class already loaded. Second attempt ignored.
INFO - 2018-04-11 23:48:28 --> File loaded: E:\www\yacopoo\application\views\emails/_buttons.php
INFO - 2018-04-11 23:48:28 --> File loaded: E:\www\yacopoo\application\views\emails/header.php
INFO - 2018-04-11 23:48:28 --> File loaded: E:\www\yacopoo\application\views\emails/footer.php
INFO - 2018-04-11 23:48:28 --> File loaded: E:\www\yacopoo\application\views\emails/generic.php
DEBUG - 2018-04-11 23:48:28 --> Email class already loaded. Second attempt ignored.
ERROR - 2018-04-11 23:48:29 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() E:\www\yacopoo\system\libraries\Email.php 1888
INFO - 2018-04-11 23:48:29 --> Config Class Initialized
INFO - 2018-04-11 23:48:29 --> Hooks Class Initialized
DEBUG - 2018-04-11 23:48:29 --> UTF-8 Support Enabled
INFO - 2018-04-11 23:48:29 --> Utf8 Class Initialized
INFO - 2018-04-11 23:48:29 --> URI Class Initialized
INFO - 2018-04-11 23:48:29 --> Router Class Initialized
INFO - 2018-04-11 23:48:29 --> Output Class Initialized
INFO - 2018-04-11 23:48:29 --> Security Class Initialized
DEBUG - 2018-04-11 23:48:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 23:48:29 --> CSRF cookie sent
INFO - 2018-04-11 23:48:29 --> Input Class Initialized
INFO - 2018-04-11 23:48:29 --> Language Class Initialized
INFO - 2018-04-11 23:48:29 --> Loader Class Initialized
INFO - 2018-04-11 23:48:29 --> Helper loaded: url_helper
INFO - 2018-04-11 23:48:29 --> Helper loaded: form_helper
INFO - 2018-04-11 23:48:30 --> Helper loaded: language_helper
DEBUG - 2018-04-11 23:48:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 23:48:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 23:48:30 --> User Agent Class Initialized
INFO - 2018-04-11 23:48:30 --> Controller Class Initialized
INFO - 2018-04-11 23:48:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 23:48:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 23:48:30 --> Pixel_Model class loaded
INFO - 2018-04-11 23:48:30 --> Database Driver Class Initialized
INFO - 2018-04-11 23:48:30 --> Model "MyAccountModel" initialized
INFO - 2018-04-11 23:48:30 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 23:48:30 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-11 23:48:30 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-11 23:48:30 --> File loaded: E:\www\yacopoo\application\views\shared/_soft_error.php
INFO - 2018-04-11 23:48:30 --> File loaded: E:\www\yacopoo\application\views\register/import_fa.php
INFO - 2018-04-11 23:48:30 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 23:48:30 --> Final output sent to browser
DEBUG - 2018-04-11 23:48:30 --> Total execution time: 0.7473
INFO - 2018-04-11 23:48:30 --> Config Class Initialized
INFO - 2018-04-11 23:48:30 --> Hooks Class Initialized
DEBUG - 2018-04-11 23:48:30 --> UTF-8 Support Enabled
INFO - 2018-04-11 23:48:30 --> Utf8 Class Initialized
INFO - 2018-04-11 23:48:30 --> URI Class Initialized
INFO - 2018-04-11 23:48:30 --> Router Class Initialized
INFO - 2018-04-11 23:48:31 --> Output Class Initialized
INFO - 2018-04-11 23:48:31 --> Security Class Initialized
DEBUG - 2018-04-11 23:48:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 23:48:31 --> CSRF cookie sent
INFO - 2018-04-11 23:48:31 --> Input Class Initialized
INFO - 2018-04-11 23:48:31 --> Language Class Initialized
ERROR - 2018-04-11 23:48:31 --> 404 Page Not Found: Assets/css
INFO - 2018-04-11 23:51:39 --> Config Class Initialized
INFO - 2018-04-11 23:51:39 --> Hooks Class Initialized
DEBUG - 2018-04-11 23:51:39 --> UTF-8 Support Enabled
INFO - 2018-04-11 23:51:39 --> Utf8 Class Initialized
INFO - 2018-04-11 23:51:39 --> URI Class Initialized
INFO - 2018-04-11 23:51:39 --> Router Class Initialized
INFO - 2018-04-11 23:51:39 --> Output Class Initialized
INFO - 2018-04-11 23:51:39 --> Security Class Initialized
DEBUG - 2018-04-11 23:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 23:51:39 --> CSRF cookie sent
INFO - 2018-04-11 23:51:39 --> CSRF token verified
INFO - 2018-04-11 23:51:39 --> Input Class Initialized
INFO - 2018-04-11 23:51:39 --> Language Class Initialized
INFO - 2018-04-11 23:51:39 --> Loader Class Initialized
INFO - 2018-04-11 23:51:39 --> Helper loaded: url_helper
INFO - 2018-04-11 23:51:39 --> Helper loaded: form_helper
INFO - 2018-04-11 23:51:39 --> Helper loaded: language_helper
DEBUG - 2018-04-11 23:51:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 23:51:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 23:51:39 --> User Agent Class Initialized
INFO - 2018-04-11 23:51:39 --> Controller Class Initialized
INFO - 2018-04-11 23:51:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 23:51:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 23:51:39 --> Upload Class Initialized
INFO - 2018-04-11 23:51:39 --> Pixel_Model class loaded
INFO - 2018-04-11 23:51:39 --> Database Driver Class Initialized
INFO - 2018-04-11 23:51:42 --> Model "RegistrationModel" initialized
INFO - 2018-04-11 23:51:42 --> Config Class Initialized
INFO - 2018-04-11 23:51:42 --> Hooks Class Initialized
DEBUG - 2018-04-11 23:51:42 --> UTF-8 Support Enabled
INFO - 2018-04-11 23:51:42 --> Utf8 Class Initialized
INFO - 2018-04-11 23:51:42 --> URI Class Initialized
INFO - 2018-04-11 23:51:42 --> Router Class Initialized
INFO - 2018-04-11 23:51:42 --> Output Class Initialized
INFO - 2018-04-11 23:51:42 --> Security Class Initialized
DEBUG - 2018-04-11 23:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 23:51:42 --> CSRF cookie sent
INFO - 2018-04-11 23:51:42 --> Input Class Initialized
INFO - 2018-04-11 23:51:42 --> Language Class Initialized
INFO - 2018-04-11 23:51:42 --> Loader Class Initialized
INFO - 2018-04-11 23:51:42 --> Helper loaded: url_helper
INFO - 2018-04-11 23:51:42 --> Helper loaded: form_helper
INFO - 2018-04-11 23:51:42 --> Helper loaded: language_helper
DEBUG - 2018-04-11 23:51:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 23:51:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 23:51:42 --> User Agent Class Initialized
INFO - 2018-04-11 23:51:42 --> Controller Class Initialized
INFO - 2018-04-11 23:51:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 23:51:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 23:51:43 --> Pixel_Model class loaded
INFO - 2018-04-11 23:51:43 --> Database Driver Class Initialized
INFO - 2018-04-11 23:51:43 --> Model "MyAccountModel" initialized
INFO - 2018-04-11 23:51:43 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 23:51:43 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-11 23:51:43 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-11 23:51:43 --> File loaded: E:\www\yacopoo\application\views\shared/_soft_error.php
INFO - 2018-04-11 23:51:43 --> File loaded: E:\www\yacopoo\application\views\register/import_fa.php
INFO - 2018-04-11 23:51:43 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 23:51:43 --> Final output sent to browser
DEBUG - 2018-04-11 23:51:43 --> Total execution time: 0.5308
INFO - 2018-04-11 23:59:54 --> Config Class Initialized
INFO - 2018-04-11 23:59:54 --> Hooks Class Initialized
DEBUG - 2018-04-11 23:59:54 --> UTF-8 Support Enabled
INFO - 2018-04-11 23:59:54 --> Utf8 Class Initialized
INFO - 2018-04-11 23:59:54 --> URI Class Initialized
INFO - 2018-04-11 23:59:54 --> Router Class Initialized
INFO - 2018-04-11 23:59:54 --> Output Class Initialized
INFO - 2018-04-11 23:59:54 --> Security Class Initialized
DEBUG - 2018-04-11 23:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 23:59:54 --> CSRF cookie sent
INFO - 2018-04-11 23:59:54 --> Input Class Initialized
INFO - 2018-04-11 23:59:54 --> Language Class Initialized
INFO - 2018-04-11 23:59:54 --> Loader Class Initialized
INFO - 2018-04-11 23:59:54 --> Helper loaded: url_helper
INFO - 2018-04-11 23:59:54 --> Helper loaded: form_helper
INFO - 2018-04-11 23:59:54 --> Helper loaded: language_helper
DEBUG - 2018-04-11 23:59:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 23:59:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 23:59:54 --> User Agent Class Initialized
INFO - 2018-04-11 23:59:54 --> Controller Class Initialized
INFO - 2018-04-11 23:59:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-11 23:59:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-11 23:59:54 --> Pixel_Model class loaded
INFO - 2018-04-11 23:59:54 --> Database Driver Class Initialized
INFO - 2018-04-11 23:59:57 --> Model "MyAccountModel" initialized
INFO - 2018-04-11 23:59:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-04-11 23:59:57 --> Pagination Class Initialized
INFO - 2018-04-11 23:59:57 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-11 23:59:57 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-11 23:59:57 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-11 23:59:57 --> File loaded: E:\www\yacopoo\application\views\myaccount/users_list.php
INFO - 2018-04-11 23:59:58 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-11 23:59:58 --> Final output sent to browser
DEBUG - 2018-04-11 23:59:58 --> Total execution time: 3.6113

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-04-18 17:42:05 --> Config Class Initialized
INFO - 2018-04-18 17:42:05 --> Hooks Class Initialized
DEBUG - 2018-04-18 17:42:05 --> UTF-8 Support Enabled
INFO - 2018-04-18 17:42:05 --> Utf8 Class Initialized
INFO - 2018-04-18 17:42:05 --> URI Class Initialized
DEBUG - 2018-04-18 17:42:06 --> No URI present. Default controller set.
INFO - 2018-04-18 17:42:06 --> Router Class Initialized
INFO - 2018-04-18 17:42:06 --> Output Class Initialized
INFO - 2018-04-18 17:42:06 --> Security Class Initialized
DEBUG - 2018-04-18 17:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-18 17:42:06 --> CSRF cookie sent
INFO - 2018-04-18 17:42:06 --> Input Class Initialized
INFO - 2018-04-18 17:42:06 --> Language Class Initialized
INFO - 2018-04-18 17:42:07 --> Loader Class Initialized
INFO - 2018-04-18 17:42:07 --> Helper loaded: url_helper
INFO - 2018-04-18 17:42:07 --> Helper loaded: form_helper
INFO - 2018-04-18 17:42:07 --> Helper loaded: language_helper
DEBUG - 2018-04-18 17:42:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-18 17:42:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-18 17:42:08 --> User Agent Class Initialized
INFO - 2018-04-18 17:42:08 --> Controller Class Initialized
INFO - 2018-04-18 17:42:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-18 17:42:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-18 17:42:08 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-18 17:42:08 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-18 17:42:08 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-18 17:42:08 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-18 17:42:09 --> Final output sent to browser
DEBUG - 2018-04-18 17:42:09 --> Total execution time: 3.6085
INFO - 2018-04-18 17:42:12 --> Config Class Initialized
INFO - 2018-04-18 17:42:12 --> Hooks Class Initialized
DEBUG - 2018-04-18 17:42:12 --> UTF-8 Support Enabled
INFO - 2018-04-18 17:42:12 --> Utf8 Class Initialized
INFO - 2018-04-18 17:42:12 --> URI Class Initialized
INFO - 2018-04-18 17:42:12 --> Router Class Initialized
INFO - 2018-04-18 17:42:13 --> Output Class Initialized
INFO - 2018-04-18 17:42:13 --> Security Class Initialized
DEBUG - 2018-04-18 17:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-18 17:42:13 --> CSRF cookie sent
INFO - 2018-04-18 17:42:13 --> Input Class Initialized
INFO - 2018-04-18 17:42:13 --> Language Class Initialized
ERROR - 2018-04-18 17:42:13 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-18 17:42:14 --> Config Class Initialized
INFO - 2018-04-18 17:42:14 --> Hooks Class Initialized
DEBUG - 2018-04-18 17:42:14 --> UTF-8 Support Enabled
INFO - 2018-04-18 17:42:14 --> Utf8 Class Initialized
INFO - 2018-04-18 17:42:14 --> URI Class Initialized
INFO - 2018-04-18 17:42:14 --> Router Class Initialized
INFO - 2018-04-18 17:42:14 --> Output Class Initialized
INFO - 2018-04-18 17:42:14 --> Security Class Initialized
DEBUG - 2018-04-18 17:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-18 17:42:14 --> CSRF cookie sent
INFO - 2018-04-18 17:42:14 --> Input Class Initialized
INFO - 2018-04-18 17:42:14 --> Language Class Initialized
INFO - 2018-04-18 17:42:14 --> Loader Class Initialized
INFO - 2018-04-18 17:42:14 --> Helper loaded: url_helper
INFO - 2018-04-18 17:42:14 --> Helper loaded: form_helper
INFO - 2018-04-18 17:42:14 --> Helper loaded: language_helper
DEBUG - 2018-04-18 17:42:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-18 17:42:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-18 17:42:15 --> User Agent Class Initialized
INFO - 2018-04-18 17:42:15 --> Controller Class Initialized
INFO - 2018-04-18 17:42:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-18 17:42:15 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-18 17:42:15 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-18 17:42:15 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-18 17:42:15 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-18 17:42:15 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-18 17:42:15 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-18 17:42:15 --> Could not find the language line "req_email"
INFO - 2018-04-18 17:42:15 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-04-18 17:42:15 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-18 17:42:15 --> Final output sent to browser
DEBUG - 2018-04-18 17:42:15 --> Total execution time: 1.5152
INFO - 2018-04-18 17:42:29 --> Config Class Initialized
INFO - 2018-04-18 17:42:29 --> Hooks Class Initialized
DEBUG - 2018-04-18 17:42:29 --> UTF-8 Support Enabled
INFO - 2018-04-18 17:42:29 --> Utf8 Class Initialized
INFO - 2018-04-18 17:42:29 --> URI Class Initialized
INFO - 2018-04-18 17:42:29 --> Router Class Initialized
INFO - 2018-04-18 17:42:29 --> Output Class Initialized
INFO - 2018-04-18 17:42:29 --> Security Class Initialized
DEBUG - 2018-04-18 17:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-18 17:42:29 --> CSRF cookie sent
INFO - 2018-04-18 17:42:29 --> CSRF token verified
INFO - 2018-04-18 17:42:29 --> Input Class Initialized
INFO - 2018-04-18 17:42:29 --> Language Class Initialized
INFO - 2018-04-18 17:42:29 --> Loader Class Initialized
INFO - 2018-04-18 17:42:29 --> Helper loaded: url_helper
INFO - 2018-04-18 17:42:29 --> Helper loaded: form_helper
INFO - 2018-04-18 17:42:29 --> Helper loaded: language_helper
DEBUG - 2018-04-18 17:42:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-18 17:42:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-18 17:42:30 --> User Agent Class Initialized
INFO - 2018-04-18 17:42:30 --> Controller Class Initialized
INFO - 2018-04-18 17:42:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-18 17:42:30 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-18 17:42:30 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-18 17:42:30 --> Form Validation Class Initialized
INFO - 2018-04-18 17:42:30 --> Pixel_Model class loaded
INFO - 2018-04-18 17:42:31 --> Database Driver Class Initialized
INFO - 2018-04-18 17:42:34 --> Model "AuthenticationModel" initialized
INFO - 2018-04-18 17:42:34 --> Config Class Initialized
INFO - 2018-04-18 17:42:34 --> Hooks Class Initialized
DEBUG - 2018-04-18 17:42:34 --> UTF-8 Support Enabled
INFO - 2018-04-18 17:42:34 --> Utf8 Class Initialized
INFO - 2018-04-18 17:42:34 --> URI Class Initialized
DEBUG - 2018-04-18 17:42:34 --> No URI present. Default controller set.
INFO - 2018-04-18 17:42:34 --> Router Class Initialized
INFO - 2018-04-18 17:42:34 --> Output Class Initialized
INFO - 2018-04-18 17:42:34 --> Security Class Initialized
DEBUG - 2018-04-18 17:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-18 17:42:34 --> CSRF cookie sent
INFO - 2018-04-18 17:42:34 --> Input Class Initialized
INFO - 2018-04-18 17:42:34 --> Language Class Initialized
INFO - 2018-04-18 17:42:35 --> Loader Class Initialized
INFO - 2018-04-18 17:42:35 --> Helper loaded: url_helper
INFO - 2018-04-18 17:42:35 --> Helper loaded: form_helper
INFO - 2018-04-18 17:42:35 --> Helper loaded: language_helper
DEBUG - 2018-04-18 17:42:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-18 17:42:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-18 17:42:35 --> User Agent Class Initialized
INFO - 2018-04-18 17:42:35 --> Controller Class Initialized
INFO - 2018-04-18 17:42:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-18 17:42:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-18 17:42:35 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-18 17:42:35 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-18 17:42:35 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-18 17:42:35 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-18 17:42:35 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-18 17:42:35 --> Final output sent to browser
DEBUG - 2018-04-18 17:42:35 --> Total execution time: 1.0034
INFO - 2018-04-18 17:42:37 --> Config Class Initialized
INFO - 2018-04-18 17:42:37 --> Hooks Class Initialized
DEBUG - 2018-04-18 17:42:37 --> UTF-8 Support Enabled
INFO - 2018-04-18 17:42:37 --> Utf8 Class Initialized
INFO - 2018-04-18 17:42:37 --> URI Class Initialized
INFO - 2018-04-18 17:42:37 --> Router Class Initialized
INFO - 2018-04-18 17:42:37 --> Output Class Initialized
INFO - 2018-04-18 17:42:37 --> Security Class Initialized
DEBUG - 2018-04-18 17:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-18 17:42:37 --> CSRF cookie sent
INFO - 2018-04-18 17:42:37 --> Input Class Initialized
INFO - 2018-04-18 17:42:37 --> Language Class Initialized
ERROR - 2018-04-18 17:42:37 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-18 17:42:59 --> Config Class Initialized
INFO - 2018-04-18 17:42:59 --> Hooks Class Initialized
DEBUG - 2018-04-18 17:42:59 --> UTF-8 Support Enabled
INFO - 2018-04-18 17:42:59 --> Utf8 Class Initialized
INFO - 2018-04-18 17:42:59 --> URI Class Initialized
INFO - 2018-04-18 17:42:59 --> Router Class Initialized
INFO - 2018-04-18 17:42:59 --> Output Class Initialized
INFO - 2018-04-18 17:42:59 --> Security Class Initialized
DEBUG - 2018-04-18 17:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-18 17:42:59 --> CSRF cookie sent
INFO - 2018-04-18 17:42:59 --> Input Class Initialized
INFO - 2018-04-18 17:42:59 --> Language Class Initialized
INFO - 2018-04-18 17:42:59 --> Loader Class Initialized
INFO - 2018-04-18 17:42:59 --> Helper loaded: url_helper
INFO - 2018-04-18 17:42:59 --> Helper loaded: form_helper
INFO - 2018-04-18 17:42:59 --> Helper loaded: language_helper
DEBUG - 2018-04-18 17:42:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-18 17:42:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-18 17:42:59 --> User Agent Class Initialized
INFO - 2018-04-18 17:42:59 --> Controller Class Initialized
INFO - 2018-04-18 17:42:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-18 17:42:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-18 17:42:59 --> Pixel_Model class loaded
INFO - 2018-04-18 17:42:59 --> Database Driver Class Initialized
INFO - 2018-04-18 17:43:02 --> Model "QuestionsModel" initialized
INFO - 2018-04-18 17:43:02 --> Config Class Initialized
INFO - 2018-04-18 17:43:02 --> Hooks Class Initialized
DEBUG - 2018-04-18 17:43:02 --> UTF-8 Support Enabled
INFO - 2018-04-18 17:43:02 --> Utf8 Class Initialized
INFO - 2018-04-18 17:43:02 --> URI Class Initialized
INFO - 2018-04-18 17:43:02 --> Router Class Initialized
INFO - 2018-04-18 17:43:02 --> Output Class Initialized
INFO - 2018-04-18 17:43:02 --> Security Class Initialized
DEBUG - 2018-04-18 17:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-18 17:43:02 --> CSRF cookie sent
INFO - 2018-04-18 17:43:02 --> Input Class Initialized
INFO - 2018-04-18 17:43:02 --> Language Class Initialized
INFO - 2018-04-18 17:43:02 --> Loader Class Initialized
INFO - 2018-04-18 17:43:02 --> Helper loaded: url_helper
INFO - 2018-04-18 17:43:02 --> Helper loaded: form_helper
INFO - 2018-04-18 17:43:02 --> Helper loaded: language_helper
DEBUG - 2018-04-18 17:43:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-18 17:43:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-18 17:43:02 --> User Agent Class Initialized
INFO - 2018-04-18 17:43:02 --> Controller Class Initialized
INFO - 2018-04-18 17:43:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-18 17:43:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-18 17:43:02 --> Pixel_Model class loaded
INFO - 2018-04-18 17:43:02 --> Database Driver Class Initialized
INFO - 2018-04-18 17:43:02 --> Model "QuestionsModel" initialized
INFO - 2018-04-18 17:43:02 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-18 17:43:02 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-18 17:43:02 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-18 17:43:03 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-18 17:43:03 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-18 17:43:03 --> File loaded: E:\www\yacopoo\application\views\questions/start_questions.php
INFO - 2018-04-18 17:43:03 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-18 17:43:03 --> Final output sent to browser
DEBUG - 2018-04-18 17:43:03 --> Total execution time: 0.4219
INFO - 2018-04-18 17:43:31 --> Config Class Initialized
INFO - 2018-04-18 17:43:31 --> Hooks Class Initialized
DEBUG - 2018-04-18 17:43:31 --> UTF-8 Support Enabled
INFO - 2018-04-18 17:43:31 --> Utf8 Class Initialized
INFO - 2018-04-18 17:43:31 --> URI Class Initialized
INFO - 2018-04-18 17:43:31 --> Router Class Initialized
INFO - 2018-04-18 17:43:31 --> Output Class Initialized
INFO - 2018-04-18 17:43:31 --> Security Class Initialized
DEBUG - 2018-04-18 17:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-18 17:43:31 --> CSRF cookie sent
INFO - 2018-04-18 17:43:31 --> Input Class Initialized
INFO - 2018-04-18 17:43:31 --> Language Class Initialized
INFO - 2018-04-18 17:43:31 --> Loader Class Initialized
INFO - 2018-04-18 17:43:31 --> Helper loaded: url_helper
INFO - 2018-04-18 17:43:31 --> Helper loaded: form_helper
INFO - 2018-04-18 17:43:31 --> Helper loaded: language_helper
DEBUG - 2018-04-18 17:43:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-18 17:43:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-18 17:43:31 --> User Agent Class Initialized
INFO - 2018-04-18 17:43:31 --> Controller Class Initialized
INFO - 2018-04-18 17:43:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-18 17:43:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-18 17:43:31 --> Pixel_Model class loaded
INFO - 2018-04-18 17:43:31 --> Database Driver Class Initialized
INFO - 2018-04-18 17:43:31 --> Model "QuestionsModel" initialized
INFO - 2018-04-18 17:43:31 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-18 17:43:31 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-18 17:43:31 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-18 17:43:31 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-18 17:43:31 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-18 17:43:31 --> File loaded: E:\www\yacopoo\application\views\questions/start_questions.php
INFO - 2018-04-18 17:43:31 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-18 17:43:31 --> Final output sent to browser
DEBUG - 2018-04-18 17:43:31 --> Total execution time: 0.4794
INFO - 2018-04-18 17:43:52 --> Config Class Initialized
INFO - 2018-04-18 17:43:52 --> Hooks Class Initialized
DEBUG - 2018-04-18 17:43:52 --> UTF-8 Support Enabled
INFO - 2018-04-18 17:43:52 --> Utf8 Class Initialized
INFO - 2018-04-18 17:43:52 --> URI Class Initialized
INFO - 2018-04-18 17:43:52 --> Router Class Initialized
INFO - 2018-04-18 17:43:52 --> Output Class Initialized
INFO - 2018-04-18 17:43:52 --> Security Class Initialized
DEBUG - 2018-04-18 17:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-18 17:43:52 --> CSRF cookie sent
INFO - 2018-04-18 17:43:52 --> Input Class Initialized
INFO - 2018-04-18 17:43:52 --> Language Class Initialized
INFO - 2018-04-18 17:43:52 --> Loader Class Initialized
INFO - 2018-04-18 17:43:52 --> Helper loaded: url_helper
INFO - 2018-04-18 17:43:52 --> Helper loaded: form_helper
INFO - 2018-04-18 17:43:52 --> Helper loaded: language_helper
DEBUG - 2018-04-18 17:43:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-18 17:43:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-18 17:43:52 --> User Agent Class Initialized
INFO - 2018-04-18 17:43:52 --> Controller Class Initialized
INFO - 2018-04-18 17:43:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-18 17:43:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-18 17:43:52 --> Pixel_Model class loaded
INFO - 2018-04-18 17:43:52 --> Database Driver Class Initialized
INFO - 2018-04-18 17:43:52 --> Model "QuestionsModel" initialized
INFO - 2018-04-18 17:43:52 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-18 17:43:52 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-18 17:43:52 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-18 17:43:53 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-18 17:43:53 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-18 17:43:53 --> File loaded: E:\www\yacopoo\application\views\questions/marriage.php
INFO - 2018-04-18 17:43:53 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-18 17:43:53 --> Final output sent to browser
DEBUG - 2018-04-18 17:43:53 --> Total execution time: 0.5668
INFO - 2018-04-18 17:44:09 --> Config Class Initialized
INFO - 2018-04-18 17:44:09 --> Hooks Class Initialized
DEBUG - 2018-04-18 17:44:09 --> UTF-8 Support Enabled
INFO - 2018-04-18 17:44:09 --> Utf8 Class Initialized
INFO - 2018-04-18 17:44:09 --> URI Class Initialized
INFO - 2018-04-18 17:44:09 --> Router Class Initialized
INFO - 2018-04-18 17:44:09 --> Output Class Initialized
INFO - 2018-04-18 17:44:09 --> Security Class Initialized
DEBUG - 2018-04-18 17:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-18 17:44:09 --> CSRF cookie sent
INFO - 2018-04-18 17:44:09 --> Input Class Initialized
INFO - 2018-04-18 17:44:09 --> Language Class Initialized
INFO - 2018-04-18 17:44:09 --> Loader Class Initialized
INFO - 2018-04-18 17:44:09 --> Helper loaded: url_helper
INFO - 2018-04-18 17:44:09 --> Helper loaded: form_helper
INFO - 2018-04-18 17:44:09 --> Helper loaded: language_helper
DEBUG - 2018-04-18 17:44:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-18 17:44:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-18 17:44:09 --> User Agent Class Initialized
INFO - 2018-04-18 17:44:09 --> Controller Class Initialized
INFO - 2018-04-18 17:44:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-18 17:44:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-18 17:44:09 --> Pixel_Model class loaded
INFO - 2018-04-18 17:44:09 --> Database Driver Class Initialized
INFO - 2018-04-18 17:44:09 --> Model "QuestionsModel" initialized
INFO - 2018-04-18 17:44:09 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-18 17:44:09 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-18 17:44:09 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-18 17:44:09 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-18 17:44:09 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-18 17:44:09 --> File loaded: E:\www\yacopoo\application\views\questions/home_owner.php
INFO - 2018-04-18 17:44:09 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-18 17:44:09 --> Final output sent to browser
DEBUG - 2018-04-18 17:44:09 --> Total execution time: 0.5060
INFO - 2018-04-18 17:45:11 --> Config Class Initialized
INFO - 2018-04-18 17:45:11 --> Hooks Class Initialized
DEBUG - 2018-04-18 17:45:11 --> UTF-8 Support Enabled
INFO - 2018-04-18 17:45:11 --> Utf8 Class Initialized
INFO - 2018-04-18 17:45:11 --> URI Class Initialized
INFO - 2018-04-18 17:45:11 --> Router Class Initialized
INFO - 2018-04-18 17:45:11 --> Output Class Initialized
INFO - 2018-04-18 17:45:11 --> Security Class Initialized
DEBUG - 2018-04-18 17:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-18 17:45:11 --> CSRF cookie sent
INFO - 2018-04-18 17:45:11 --> Input Class Initialized
INFO - 2018-04-18 17:45:11 --> Language Class Initialized
ERROR - 2018-04-18 17:45:11 --> 404 Page Not Found: Assets/css
INFO - 2018-04-18 17:45:25 --> Config Class Initialized
INFO - 2018-04-18 17:45:25 --> Hooks Class Initialized
DEBUG - 2018-04-18 17:45:25 --> UTF-8 Support Enabled
INFO - 2018-04-18 17:45:25 --> Utf8 Class Initialized
INFO - 2018-04-18 17:45:25 --> URI Class Initialized
INFO - 2018-04-18 17:45:25 --> Router Class Initialized
INFO - 2018-04-18 17:45:25 --> Output Class Initialized
INFO - 2018-04-18 17:45:25 --> Security Class Initialized
DEBUG - 2018-04-18 17:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-18 17:45:25 --> CSRF cookie sent
INFO - 2018-04-18 17:45:25 --> CSRF token verified
INFO - 2018-04-18 17:45:25 --> Input Class Initialized
INFO - 2018-04-18 17:45:25 --> Language Class Initialized
INFO - 2018-04-18 17:45:25 --> Loader Class Initialized
INFO - 2018-04-18 17:45:25 --> Helper loaded: url_helper
INFO - 2018-04-18 17:45:25 --> Helper loaded: form_helper
INFO - 2018-04-18 17:45:25 --> Helper loaded: language_helper
DEBUG - 2018-04-18 17:45:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-18 17:45:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-18 17:45:25 --> User Agent Class Initialized
INFO - 2018-04-18 17:45:25 --> Controller Class Initialized
INFO - 2018-04-18 17:45:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-18 17:45:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-18 17:45:25 --> Pixel_Model class loaded
INFO - 2018-04-18 17:45:25 --> Database Driver Class Initialized
INFO - 2018-04-18 17:45:28 --> Model "QuestionsModel" initialized
INFO - 2018-04-18 17:45:28 --> Form Validation Class Initialized
INFO - 2018-04-18 17:45:28 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-04-18 17:45:28 --> Query error: Table 'yacopo.applicationss' doesn't exist - Invalid query: UPDATE `applicationss` SET `has_own_home` = '28', `current_seo_uri` = 'home-title-info'
WHERE `id` = 1
INFO - 2018-04-18 17:45:28 --> Language file loaded: language/english/db_lang.php
INFO - 2018-04-18 17:47:59 --> Config Class Initialized
INFO - 2018-04-18 17:47:59 --> Hooks Class Initialized
DEBUG - 2018-04-18 17:47:59 --> UTF-8 Support Enabled
INFO - 2018-04-18 17:47:59 --> Utf8 Class Initialized
INFO - 2018-04-18 17:47:59 --> URI Class Initialized
INFO - 2018-04-18 17:47:59 --> Router Class Initialized
INFO - 2018-04-18 17:47:59 --> Output Class Initialized
INFO - 2018-04-18 17:47:59 --> Security Class Initialized
DEBUG - 2018-04-18 17:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-18 17:47:59 --> CSRF cookie sent
INFO - 2018-04-18 17:47:59 --> CSRF token verified
INFO - 2018-04-18 17:47:59 --> Input Class Initialized
INFO - 2018-04-18 17:47:59 --> Language Class Initialized
INFO - 2018-04-18 17:47:59 --> Loader Class Initialized
INFO - 2018-04-18 17:47:59 --> Helper loaded: url_helper
INFO - 2018-04-18 17:47:59 --> Helper loaded: form_helper
INFO - 2018-04-18 17:47:59 --> Helper loaded: language_helper
DEBUG - 2018-04-18 17:47:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-18 17:47:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-18 17:47:59 --> User Agent Class Initialized
INFO - 2018-04-18 17:47:59 --> Controller Class Initialized
INFO - 2018-04-18 17:48:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-18 17:48:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-18 17:48:00 --> Pixel_Model class loaded
INFO - 2018-04-18 17:48:00 --> Database Driver Class Initialized
INFO - 2018-04-18 17:48:03 --> Model "QuestionsModel" initialized
INFO - 2018-04-18 17:48:03 --> Form Validation Class Initialized
INFO - 2018-04-18 17:48:03 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-04-18 17:48:03 --> Query error: Table 'yacopo.applicationss' doesn't exist - Invalid query: UPDATE `applicationss` SET `has_own_home` = '28', `current_seo_uri` = 'home-title-info', `bilal` = 'ghumman'
WHERE `id` = 1
INFO - 2018-04-18 17:48:03 --> Language file loaded: language/english/db_lang.php
INFO - 2018-04-18 17:48:37 --> Config Class Initialized
INFO - 2018-04-18 17:48:37 --> Hooks Class Initialized
DEBUG - 2018-04-18 17:48:37 --> UTF-8 Support Enabled
INFO - 2018-04-18 17:48:37 --> Utf8 Class Initialized
INFO - 2018-04-18 17:48:37 --> URI Class Initialized
INFO - 2018-04-18 17:48:37 --> Router Class Initialized
INFO - 2018-04-18 17:48:37 --> Output Class Initialized
INFO - 2018-04-18 17:48:37 --> Security Class Initialized
DEBUG - 2018-04-18 17:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-18 17:48:37 --> CSRF cookie sent
INFO - 2018-04-18 17:48:37 --> CSRF token verified
INFO - 2018-04-18 17:48:37 --> Input Class Initialized
INFO - 2018-04-18 17:48:37 --> Language Class Initialized
INFO - 2018-04-18 17:48:37 --> Loader Class Initialized
INFO - 2018-04-18 17:48:37 --> Helper loaded: url_helper
INFO - 2018-04-18 17:48:37 --> Helper loaded: form_helper
INFO - 2018-04-18 17:48:37 --> Helper loaded: language_helper
DEBUG - 2018-04-18 17:48:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-18 17:48:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-18 17:48:38 --> User Agent Class Initialized
INFO - 2018-04-18 17:48:38 --> Controller Class Initialized
INFO - 2018-04-18 17:48:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-18 17:48:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-18 17:48:38 --> Pixel_Model class loaded
INFO - 2018-04-18 17:48:38 --> Database Driver Class Initialized
INFO - 2018-04-18 17:48:38 --> Model "QuestionsModel" initialized
INFO - 2018-04-18 17:48:38 --> Form Validation Class Initialized
INFO - 2018-04-18 17:48:38 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-04-18 17:48:38 --> Query error: Table 'yacopo.applicationss' doesn't exist - Invalid query: UPDATE `applicationss` SET `has_own_home` = '28', `current_seo_uri` = 'home-title-info', `bilal` = 'ghumman'
WHERE `id` = 1
INFO - 2018-04-18 17:48:38 --> Language file loaded: language/english/db_lang.php
INFO - 2018-04-18 17:49:26 --> Config Class Initialized
INFO - 2018-04-18 17:49:26 --> Hooks Class Initialized
DEBUG - 2018-04-18 17:49:26 --> UTF-8 Support Enabled
INFO - 2018-04-18 17:49:26 --> Utf8 Class Initialized
INFO - 2018-04-18 17:49:26 --> URI Class Initialized
INFO - 2018-04-18 17:49:26 --> Router Class Initialized
INFO - 2018-04-18 17:49:26 --> Output Class Initialized
INFO - 2018-04-18 17:49:26 --> Security Class Initialized
DEBUG - 2018-04-18 17:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-18 17:49:26 --> CSRF cookie sent
INFO - 2018-04-18 17:49:26 --> CSRF token verified
INFO - 2018-04-18 17:49:26 --> Input Class Initialized
INFO - 2018-04-18 17:49:26 --> Language Class Initialized
INFO - 2018-04-18 17:49:26 --> Loader Class Initialized
INFO - 2018-04-18 17:49:26 --> Helper loaded: url_helper
INFO - 2018-04-18 17:49:26 --> Helper loaded: form_helper
INFO - 2018-04-18 17:49:26 --> Helper loaded: language_helper
DEBUG - 2018-04-18 17:49:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-18 17:49:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-18 17:49:26 --> User Agent Class Initialized
INFO - 2018-04-18 17:49:26 --> Controller Class Initialized
INFO - 2018-04-18 17:49:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-18 17:49:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-18 17:49:26 --> Pixel_Model class loaded
INFO - 2018-04-18 17:49:26 --> Database Driver Class Initialized
INFO - 2018-04-18 17:49:29 --> Model "QuestionsModel" initialized
INFO - 2018-04-18 17:49:29 --> Form Validation Class Initialized
INFO - 2018-04-18 17:49:29 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-04-18 17:49:29 --> Query error: Unknown column 'bilal' in 'field list' - Invalid query: UPDATE `applications` SET `has_own_home` = '28', `current_seo_uri` = 'home-title-info', `bilal` = 'ghumman'
WHERE `id` = 1
INFO - 2018-04-18 17:49:29 --> Language file loaded: language/english/db_lang.php
INFO - 2018-04-18 17:52:11 --> Config Class Initialized
INFO - 2018-04-18 17:52:12 --> Hooks Class Initialized
DEBUG - 2018-04-18 17:52:12 --> UTF-8 Support Enabled
INFO - 2018-04-18 17:52:12 --> Utf8 Class Initialized
INFO - 2018-04-18 17:52:12 --> URI Class Initialized
INFO - 2018-04-18 17:52:12 --> Router Class Initialized
INFO - 2018-04-18 17:52:12 --> Output Class Initialized
INFO - 2018-04-18 17:52:12 --> Security Class Initialized
DEBUG - 2018-04-18 17:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-18 17:52:12 --> CSRF cookie sent
INFO - 2018-04-18 17:52:12 --> CSRF token verified
INFO - 2018-04-18 17:52:12 --> Input Class Initialized
INFO - 2018-04-18 17:52:12 --> Language Class Initialized
INFO - 2018-04-18 17:52:12 --> Loader Class Initialized
INFO - 2018-04-18 17:52:12 --> Helper loaded: url_helper
INFO - 2018-04-18 17:52:12 --> Helper loaded: form_helper
INFO - 2018-04-18 17:52:12 --> Helper loaded: language_helper
DEBUG - 2018-04-18 17:52:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-18 17:52:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-18 17:52:12 --> User Agent Class Initialized
INFO - 2018-04-18 17:52:12 --> Controller Class Initialized
INFO - 2018-04-18 17:52:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-18 17:52:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-18 17:52:12 --> Pixel_Model class loaded
INFO - 2018-04-18 17:52:12 --> Database Driver Class Initialized
INFO - 2018-04-18 17:52:15 --> Model "QuestionsModel" initialized
INFO - 2018-04-18 17:52:15 --> Form Validation Class Initialized
INFO - 2018-04-18 17:52:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-18 17:52:15 --> Config Class Initialized
INFO - 2018-04-18 17:52:15 --> Hooks Class Initialized
DEBUG - 2018-04-18 17:52:15 --> UTF-8 Support Enabled
INFO - 2018-04-18 17:52:15 --> Utf8 Class Initialized
INFO - 2018-04-18 17:52:15 --> URI Class Initialized
INFO - 2018-04-18 17:52:15 --> Router Class Initialized
INFO - 2018-04-18 17:52:15 --> Output Class Initialized
INFO - 2018-04-18 17:52:15 --> Security Class Initialized
DEBUG - 2018-04-18 17:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-18 17:52:15 --> CSRF cookie sent
INFO - 2018-04-18 17:52:15 --> Input Class Initialized
INFO - 2018-04-18 17:52:15 --> Language Class Initialized
ERROR - 2018-04-18 17:52:15 --> 404 Page Not Found: Home-title-info/index
INFO - 2018-04-18 17:52:25 --> Config Class Initialized
INFO - 2018-04-18 17:52:25 --> Hooks Class Initialized
DEBUG - 2018-04-18 17:52:25 --> UTF-8 Support Enabled
INFO - 2018-04-18 17:52:25 --> Utf8 Class Initialized
INFO - 2018-04-18 17:52:25 --> URI Class Initialized
INFO - 2018-04-18 17:52:25 --> Router Class Initialized
INFO - 2018-04-18 17:52:25 --> Output Class Initialized
INFO - 2018-04-18 17:52:25 --> Security Class Initialized
DEBUG - 2018-04-18 17:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-18 17:52:25 --> CSRF cookie sent
INFO - 2018-04-18 17:52:25 --> CSRF token verified
INFO - 2018-04-18 17:52:25 --> Input Class Initialized
INFO - 2018-04-18 17:52:25 --> Language Class Initialized
INFO - 2018-04-18 17:52:25 --> Loader Class Initialized
INFO - 2018-04-18 17:52:25 --> Helper loaded: url_helper
INFO - 2018-04-18 17:52:25 --> Helper loaded: form_helper
INFO - 2018-04-18 17:52:25 --> Helper loaded: language_helper
DEBUG - 2018-04-18 17:52:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-18 17:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-18 17:52:25 --> User Agent Class Initialized
INFO - 2018-04-18 17:52:25 --> Controller Class Initialized
INFO - 2018-04-18 17:52:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-18 17:52:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-18 17:52:25 --> Pixel_Model class loaded
INFO - 2018-04-18 17:52:25 --> Database Driver Class Initialized
INFO - 2018-04-18 17:52:25 --> Model "QuestionsModel" initialized
INFO - 2018-04-18 17:52:25 --> Form Validation Class Initialized
INFO - 2018-04-18 17:52:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-18 17:52:25 --> Config Class Initialized
INFO - 2018-04-18 17:52:25 --> Hooks Class Initialized
DEBUG - 2018-04-18 17:52:25 --> UTF-8 Support Enabled
INFO - 2018-04-18 17:52:25 --> Utf8 Class Initialized
INFO - 2018-04-18 17:52:25 --> URI Class Initialized
INFO - 2018-04-18 17:52:25 --> Router Class Initialized
INFO - 2018-04-18 17:52:25 --> Output Class Initialized
INFO - 2018-04-18 17:52:25 --> Security Class Initialized
DEBUG - 2018-04-18 17:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-18 17:52:26 --> CSRF cookie sent
INFO - 2018-04-18 17:52:26 --> Input Class Initialized
INFO - 2018-04-18 17:52:26 --> Language Class Initialized
ERROR - 2018-04-18 17:52:26 --> 404 Page Not Found: Home-title-info/index
INFO - 2018-04-18 17:52:32 --> Config Class Initialized
INFO - 2018-04-18 17:52:32 --> Hooks Class Initialized
DEBUG - 2018-04-18 17:52:32 --> UTF-8 Support Enabled
INFO - 2018-04-18 17:52:32 --> Utf8 Class Initialized
INFO - 2018-04-18 17:52:32 --> URI Class Initialized
INFO - 2018-04-18 17:52:32 --> Router Class Initialized
INFO - 2018-04-18 17:52:32 --> Output Class Initialized
INFO - 2018-04-18 17:52:32 --> Security Class Initialized
DEBUG - 2018-04-18 17:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-18 17:52:32 --> CSRF cookie sent
INFO - 2018-04-18 17:52:32 --> CSRF token verified
INFO - 2018-04-18 17:52:32 --> Input Class Initialized
INFO - 2018-04-18 17:52:32 --> Language Class Initialized
INFO - 2018-04-18 17:52:32 --> Loader Class Initialized
INFO - 2018-04-18 17:52:32 --> Helper loaded: url_helper
INFO - 2018-04-18 17:52:32 --> Helper loaded: form_helper
INFO - 2018-04-18 17:52:32 --> Helper loaded: language_helper
DEBUG - 2018-04-18 17:52:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-18 17:52:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-18 17:52:32 --> User Agent Class Initialized
INFO - 2018-04-18 17:52:32 --> Controller Class Initialized
INFO - 2018-04-18 17:52:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-18 17:52:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-18 17:52:32 --> Pixel_Model class loaded
INFO - 2018-04-18 17:52:32 --> Database Driver Class Initialized
INFO - 2018-04-18 17:52:32 --> Model "QuestionsModel" initialized
INFO - 2018-04-18 17:52:32 --> Form Validation Class Initialized
INFO - 2018-04-18 17:52:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-18 17:52:32 --> Config Class Initialized
INFO - 2018-04-18 17:52:32 --> Hooks Class Initialized
DEBUG - 2018-04-18 17:52:32 --> UTF-8 Support Enabled
INFO - 2018-04-18 17:52:32 --> Utf8 Class Initialized
INFO - 2018-04-18 17:52:32 --> URI Class Initialized
INFO - 2018-04-18 17:52:32 --> Router Class Initialized
INFO - 2018-04-18 17:52:32 --> Output Class Initialized
INFO - 2018-04-18 17:52:32 --> Security Class Initialized
DEBUG - 2018-04-18 17:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-18 17:52:32 --> CSRF cookie sent
INFO - 2018-04-18 17:52:32 --> Input Class Initialized
INFO - 2018-04-18 17:52:32 --> Language Class Initialized
ERROR - 2018-04-18 17:52:32 --> 404 Page Not Found: Home-title-info/index
INFO - 2018-04-18 17:52:34 --> Config Class Initialized
INFO - 2018-04-18 17:52:34 --> Hooks Class Initialized
DEBUG - 2018-04-18 17:52:34 --> UTF-8 Support Enabled
INFO - 2018-04-18 17:52:34 --> Utf8 Class Initialized
INFO - 2018-04-18 17:52:34 --> URI Class Initialized
INFO - 2018-04-18 17:52:34 --> Router Class Initialized
INFO - 2018-04-18 17:52:34 --> Output Class Initialized
INFO - 2018-04-18 17:52:34 --> Security Class Initialized
DEBUG - 2018-04-18 17:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-18 17:52:34 --> CSRF cookie sent
INFO - 2018-04-18 17:52:34 --> CSRF token verified
INFO - 2018-04-18 17:52:34 --> Input Class Initialized
INFO - 2018-04-18 17:52:34 --> Language Class Initialized
INFO - 2018-04-18 17:52:34 --> Loader Class Initialized
INFO - 2018-04-18 17:52:34 --> Helper loaded: url_helper
INFO - 2018-04-18 17:52:35 --> Helper loaded: form_helper
INFO - 2018-04-18 17:52:35 --> Helper loaded: language_helper
DEBUG - 2018-04-18 17:52:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-18 17:52:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-18 17:52:35 --> User Agent Class Initialized
INFO - 2018-04-18 17:52:35 --> Controller Class Initialized
INFO - 2018-04-18 17:52:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-18 17:52:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-18 17:52:35 --> Pixel_Model class loaded
INFO - 2018-04-18 17:52:35 --> Database Driver Class Initialized
INFO - 2018-04-18 17:52:35 --> Model "QuestionsModel" initialized
INFO - 2018-04-18 17:52:35 --> Form Validation Class Initialized
INFO - 2018-04-18 17:52:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-18 17:52:35 --> Config Class Initialized
INFO - 2018-04-18 17:52:35 --> Hooks Class Initialized
DEBUG - 2018-04-18 17:52:35 --> UTF-8 Support Enabled
INFO - 2018-04-18 17:52:35 --> Utf8 Class Initialized
INFO - 2018-04-18 17:52:35 --> URI Class Initialized
INFO - 2018-04-18 17:52:35 --> Router Class Initialized
INFO - 2018-04-18 17:52:35 --> Output Class Initialized
INFO - 2018-04-18 17:52:35 --> Security Class Initialized
DEBUG - 2018-04-18 17:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-18 17:52:35 --> CSRF cookie sent
INFO - 2018-04-18 17:52:35 --> Input Class Initialized
INFO - 2018-04-18 17:52:35 --> Language Class Initialized
ERROR - 2018-04-18 17:52:35 --> 404 Page Not Found: Home-title-info/index
INFO - 2018-04-18 17:52:37 --> Config Class Initialized
INFO - 2018-04-18 17:52:37 --> Hooks Class Initialized
DEBUG - 2018-04-18 17:52:37 --> UTF-8 Support Enabled
INFO - 2018-04-18 17:52:37 --> Utf8 Class Initialized
INFO - 2018-04-18 17:52:37 --> URI Class Initialized
INFO - 2018-04-18 17:52:37 --> Router Class Initialized
INFO - 2018-04-18 17:52:37 --> Output Class Initialized
INFO - 2018-04-18 17:52:38 --> Security Class Initialized
DEBUG - 2018-04-18 17:52:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-18 17:52:38 --> CSRF cookie sent
INFO - 2018-04-18 17:52:38 --> Input Class Initialized
INFO - 2018-04-18 17:52:38 --> Language Class Initialized
INFO - 2018-04-18 17:52:38 --> Loader Class Initialized
INFO - 2018-04-18 17:52:38 --> Helper loaded: url_helper
INFO - 2018-04-18 17:52:38 --> Helper loaded: form_helper
INFO - 2018-04-18 17:52:38 --> Helper loaded: language_helper
DEBUG - 2018-04-18 17:52:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-18 17:52:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-18 17:52:38 --> User Agent Class Initialized
INFO - 2018-04-18 17:52:38 --> Controller Class Initialized
INFO - 2018-04-18 17:52:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-18 17:52:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-18 17:52:38 --> Pixel_Model class loaded
INFO - 2018-04-18 17:52:38 --> Database Driver Class Initialized
INFO - 2018-04-18 17:52:38 --> Model "QuestionsModel" initialized
INFO - 2018-04-18 17:52:38 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-18 17:52:38 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-18 17:52:38 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-18 17:52:38 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-18 17:52:38 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-18 17:52:38 --> File loaded: E:\www\yacopoo\application\views\questions/home_owner.php
INFO - 2018-04-18 17:52:38 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-18 17:52:38 --> Final output sent to browser
DEBUG - 2018-04-18 17:52:38 --> Total execution time: 0.4203
INFO - 2018-04-18 17:52:38 --> Config Class Initialized
INFO - 2018-04-18 17:52:38 --> Hooks Class Initialized
DEBUG - 2018-04-18 17:52:38 --> UTF-8 Support Enabled
INFO - 2018-04-18 17:52:38 --> Utf8 Class Initialized
INFO - 2018-04-18 17:52:38 --> URI Class Initialized
INFO - 2018-04-18 17:52:39 --> Router Class Initialized
INFO - 2018-04-18 17:52:39 --> Output Class Initialized
INFO - 2018-04-18 17:52:39 --> Security Class Initialized
DEBUG - 2018-04-18 17:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-18 17:52:39 --> CSRF cookie sent
INFO - 2018-04-18 17:52:39 --> Input Class Initialized
INFO - 2018-04-18 17:52:39 --> Language Class Initialized
ERROR - 2018-04-18 17:52:39 --> 404 Page Not Found: Assets/css
INFO - 2018-04-18 17:52:40 --> Config Class Initialized
INFO - 2018-04-18 17:52:40 --> Hooks Class Initialized
DEBUG - 2018-04-18 17:52:40 --> UTF-8 Support Enabled
INFO - 2018-04-18 17:52:40 --> Utf8 Class Initialized
INFO - 2018-04-18 17:52:40 --> URI Class Initialized
INFO - 2018-04-18 17:52:40 --> Router Class Initialized
INFO - 2018-04-18 17:52:40 --> Output Class Initialized
INFO - 2018-04-18 17:52:40 --> Security Class Initialized
DEBUG - 2018-04-18 17:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-18 17:52:40 --> CSRF cookie sent
INFO - 2018-04-18 17:52:40 --> Input Class Initialized
INFO - 2018-04-18 17:52:40 --> Language Class Initialized
INFO - 2018-04-18 17:52:40 --> Loader Class Initialized
INFO - 2018-04-18 17:52:40 --> Helper loaded: url_helper
INFO - 2018-04-18 17:52:40 --> Helper loaded: form_helper
INFO - 2018-04-18 17:52:40 --> Helper loaded: language_helper
DEBUG - 2018-04-18 17:52:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-18 17:52:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-18 17:52:40 --> User Agent Class Initialized
INFO - 2018-04-18 17:52:41 --> Controller Class Initialized
INFO - 2018-04-18 17:52:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-18 17:52:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-18 17:52:41 --> Pixel_Model class loaded
INFO - 2018-04-18 17:52:41 --> Database Driver Class Initialized
INFO - 2018-04-18 17:52:41 --> Model "QuestionsModel" initialized
INFO - 2018-04-18 17:52:41 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-18 17:52:41 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-18 17:52:41 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-18 17:52:41 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-18 17:52:41 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-18 17:52:41 --> File loaded: E:\www\yacopoo\application\views\questions/home_owner.php
INFO - 2018-04-18 17:52:41 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-18 17:52:41 --> Final output sent to browser
DEBUG - 2018-04-18 17:52:41 --> Total execution time: 0.4599
INFO - 2018-04-18 17:52:41 --> Config Class Initialized
INFO - 2018-04-18 17:52:41 --> Config Class Initialized
INFO - 2018-04-18 17:52:41 --> Hooks Class Initialized
INFO - 2018-04-18 17:52:41 --> Hooks Class Initialized
DEBUG - 2018-04-18 17:52:41 --> UTF-8 Support Enabled
DEBUG - 2018-04-18 17:52:41 --> UTF-8 Support Enabled
INFO - 2018-04-18 17:52:41 --> Utf8 Class Initialized
INFO - 2018-04-18 17:52:41 --> Utf8 Class Initialized
INFO - 2018-04-18 17:52:41 --> URI Class Initialized
INFO - 2018-04-18 17:52:41 --> URI Class Initialized
INFO - 2018-04-18 17:52:41 --> Router Class Initialized
INFO - 2018-04-18 17:52:41 --> Router Class Initialized
INFO - 2018-04-18 17:52:41 --> Output Class Initialized
INFO - 2018-04-18 17:52:41 --> Output Class Initialized
INFO - 2018-04-18 17:52:41 --> Security Class Initialized
INFO - 2018-04-18 17:52:41 --> Security Class Initialized
DEBUG - 2018-04-18 17:52:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-18 17:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-18 17:52:41 --> CSRF cookie sent
INFO - 2018-04-18 17:52:41 --> CSRF cookie sent
INFO - 2018-04-18 17:52:41 --> Input Class Initialized
INFO - 2018-04-18 17:52:41 --> Input Class Initialized
INFO - 2018-04-18 17:52:41 --> Language Class Initialized
INFO - 2018-04-18 17:52:41 --> Language Class Initialized
INFO - 2018-04-18 17:52:41 --> Loader Class Initialized
INFO - 2018-04-18 17:52:41 --> Loader Class Initialized
INFO - 2018-04-18 17:52:41 --> Helper loaded: url_helper
INFO - 2018-04-18 17:52:41 --> Helper loaded: url_helper
INFO - 2018-04-18 17:52:41 --> Helper loaded: form_helper
INFO - 2018-04-18 17:52:41 --> Helper loaded: form_helper
INFO - 2018-04-18 17:52:41 --> Helper loaded: language_helper
INFO - 2018-04-18 17:52:41 --> Helper loaded: language_helper
DEBUG - 2018-04-18 17:52:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-04-18 17:52:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-18 17:52:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-18 17:52:41 --> User Agent Class Initialized
INFO - 2018-04-18 17:52:41 --> Controller Class Initialized
INFO - 2018-04-18 17:52:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-18 17:52:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-18 17:52:41 --> Pixel_Model class loaded
INFO - 2018-04-18 17:52:41 --> Database Driver Class Initialized
INFO - 2018-04-18 17:52:41 --> Model "QuestionsModel" initialized
INFO - 2018-04-18 17:52:41 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-18 17:52:41 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-18 17:52:41 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-18 17:52:41 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-18 17:52:41 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-18 17:52:41 --> File loaded: E:\www\yacopoo\application\views\questions/home_owner.php
INFO - 2018-04-18 17:52:41 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-18 17:52:41 --> Final output sent to browser
DEBUG - 2018-04-18 17:52:41 --> Total execution time: 0.4236
INFO - 2018-04-18 17:52:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-18 17:52:41 --> User Agent Class Initialized
INFO - 2018-04-18 17:52:41 --> Controller Class Initialized
INFO - 2018-04-18 17:52:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-18 17:52:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-18 17:52:41 --> Pixel_Model class loaded
INFO - 2018-04-18 17:52:42 --> Database Driver Class Initialized
INFO - 2018-04-18 17:52:42 --> Model "QuestionsModel" initialized
INFO - 2018-04-18 17:52:42 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-18 17:52:42 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-18 17:52:42 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-18 17:52:42 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-18 17:52:42 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-18 17:52:42 --> File loaded: E:\www\yacopoo\application\views\questions/home_owner.php
INFO - 2018-04-18 17:52:42 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-18 17:52:42 --> Final output sent to browser
DEBUG - 2018-04-18 17:52:42 --> Total execution time: 0.7839
INFO - 2018-04-18 17:52:42 --> Config Class Initialized
INFO - 2018-04-18 17:52:42 --> Hooks Class Initialized
DEBUG - 2018-04-18 17:52:42 --> UTF-8 Support Enabled
INFO - 2018-04-18 17:52:42 --> Utf8 Class Initialized
INFO - 2018-04-18 17:52:42 --> URI Class Initialized
INFO - 2018-04-18 17:52:42 --> Router Class Initialized
INFO - 2018-04-18 17:52:42 --> Output Class Initialized
INFO - 2018-04-18 17:52:42 --> Security Class Initialized
DEBUG - 2018-04-18 17:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-18 17:52:42 --> CSRF cookie sent
INFO - 2018-04-18 17:52:42 --> Input Class Initialized
INFO - 2018-04-18 17:52:42 --> Language Class Initialized
ERROR - 2018-04-18 17:52:42 --> 404 Page Not Found: Assets/css
INFO - 2018-04-18 17:53:46 --> Config Class Initialized
INFO - 2018-04-18 17:53:46 --> Hooks Class Initialized
DEBUG - 2018-04-18 17:53:46 --> UTF-8 Support Enabled
INFO - 2018-04-18 17:53:46 --> Utf8 Class Initialized
INFO - 2018-04-18 17:53:46 --> URI Class Initialized
INFO - 2018-04-18 17:53:46 --> Router Class Initialized
INFO - 2018-04-18 17:53:46 --> Output Class Initialized
INFO - 2018-04-18 17:53:46 --> Security Class Initialized
DEBUG - 2018-04-18 17:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-18 17:53:46 --> CSRF cookie sent
INFO - 2018-04-18 17:53:46 --> Input Class Initialized
INFO - 2018-04-18 17:53:46 --> Language Class Initialized
INFO - 2018-04-18 17:53:46 --> Loader Class Initialized
INFO - 2018-04-18 17:53:46 --> Helper loaded: url_helper
INFO - 2018-04-18 17:53:46 --> Helper loaded: form_helper
INFO - 2018-04-18 17:53:46 --> Helper loaded: language_helper
DEBUG - 2018-04-18 17:53:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-18 17:53:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-18 17:53:46 --> User Agent Class Initialized
INFO - 2018-04-18 17:53:46 --> Controller Class Initialized
INFO - 2018-04-18 17:53:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-18 17:53:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-18 17:53:46 --> Pixel_Model class loaded
INFO - 2018-04-18 17:53:46 --> Database Driver Class Initialized
INFO - 2018-04-18 17:53:49 --> Model "QuestionsModel" initialized
INFO - 2018-04-18 17:53:49 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-18 17:53:49 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-18 17:53:49 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-18 17:53:49 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-18 17:53:49 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-18 17:53:49 --> File loaded: E:\www\yacopoo\application\views\questions/home_owner.php
INFO - 2018-04-18 17:53:49 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-18 17:53:49 --> Final output sent to browser
DEBUG - 2018-04-18 17:53:49 --> Total execution time: 3.4411
INFO - 2018-04-18 17:53:50 --> Config Class Initialized
INFO - 2018-04-18 17:53:50 --> Hooks Class Initialized
DEBUG - 2018-04-18 17:53:50 --> UTF-8 Support Enabled
INFO - 2018-04-18 17:53:50 --> Utf8 Class Initialized
INFO - 2018-04-18 17:53:50 --> URI Class Initialized
INFO - 2018-04-18 17:53:50 --> Router Class Initialized
INFO - 2018-04-18 17:53:50 --> Output Class Initialized
INFO - 2018-04-18 17:53:50 --> Security Class Initialized
DEBUG - 2018-04-18 17:53:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-18 17:53:50 --> CSRF cookie sent
INFO - 2018-04-18 17:53:50 --> Input Class Initialized
INFO - 2018-04-18 17:53:50 --> Language Class Initialized
ERROR - 2018-04-18 17:53:50 --> 404 Page Not Found: Assets/css
INFO - 2018-04-18 18:00:36 --> Config Class Initialized
INFO - 2018-04-18 18:00:36 --> Hooks Class Initialized
DEBUG - 2018-04-18 18:00:36 --> UTF-8 Support Enabled
INFO - 2018-04-18 18:00:36 --> Utf8 Class Initialized
INFO - 2018-04-18 18:00:36 --> URI Class Initialized
INFO - 2018-04-18 18:00:36 --> Router Class Initialized
INFO - 2018-04-18 18:00:36 --> Output Class Initialized
INFO - 2018-04-18 18:00:36 --> Security Class Initialized
DEBUG - 2018-04-18 18:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-18 18:00:36 --> CSRF cookie sent
INFO - 2018-04-18 18:00:36 --> CSRF token verified
INFO - 2018-04-18 18:00:36 --> Input Class Initialized
INFO - 2018-04-18 18:00:36 --> Language Class Initialized
INFO - 2018-04-18 18:00:36 --> Loader Class Initialized
INFO - 2018-04-18 18:00:36 --> Helper loaded: url_helper
INFO - 2018-04-18 18:00:36 --> Helper loaded: form_helper
INFO - 2018-04-18 18:00:36 --> Helper loaded: language_helper
DEBUG - 2018-04-18 18:00:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-18 18:00:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-18 18:00:36 --> User Agent Class Initialized
INFO - 2018-04-18 18:00:36 --> Controller Class Initialized
INFO - 2018-04-18 18:00:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-18 18:00:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-18 18:00:36 --> Pixel_Model class loaded
INFO - 2018-04-18 18:00:36 --> Database Driver Class Initialized
INFO - 2018-04-18 18:00:39 --> Model "QuestionsModel" initialized
INFO - 2018-04-18 18:00:39 --> Form Validation Class Initialized
INFO - 2018-04-18 18:00:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-18 18:01:17 --> Config Class Initialized
INFO - 2018-04-18 18:01:17 --> Hooks Class Initialized
DEBUG - 2018-04-18 18:01:17 --> UTF-8 Support Enabled
INFO - 2018-04-18 18:01:17 --> Utf8 Class Initialized
INFO - 2018-04-18 18:01:17 --> URI Class Initialized
INFO - 2018-04-18 18:01:17 --> Router Class Initialized
INFO - 2018-04-18 18:01:17 --> Output Class Initialized
INFO - 2018-04-18 18:01:17 --> Security Class Initialized
DEBUG - 2018-04-18 18:01:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-18 18:01:17 --> CSRF cookie sent
INFO - 2018-04-18 18:01:17 --> CSRF token verified
INFO - 2018-04-18 18:01:17 --> Input Class Initialized
INFO - 2018-04-18 18:01:17 --> Language Class Initialized
INFO - 2018-04-18 18:01:17 --> Loader Class Initialized
INFO - 2018-04-18 18:01:17 --> Helper loaded: url_helper
INFO - 2018-04-18 18:01:17 --> Helper loaded: form_helper
INFO - 2018-04-18 18:01:17 --> Helper loaded: language_helper
DEBUG - 2018-04-18 18:01:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-18 18:01:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-18 18:01:17 --> User Agent Class Initialized
INFO - 2018-04-18 18:01:17 --> Controller Class Initialized
INFO - 2018-04-18 18:01:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-18 18:01:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-18 18:01:17 --> Pixel_Model class loaded
INFO - 2018-04-18 18:01:17 --> Database Driver Class Initialized
INFO - 2018-04-18 18:01:20 --> Model "QuestionsModel" initialized
INFO - 2018-04-18 18:01:20 --> Form Validation Class Initialized
INFO - 2018-04-18 18:01:20 --> Language file loaded: language/english/form_validation_lang.php

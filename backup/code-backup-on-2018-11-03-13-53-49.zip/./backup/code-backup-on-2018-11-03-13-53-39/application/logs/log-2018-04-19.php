<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-04-19 15:50:33 --> Config Class Initialized
INFO - 2018-04-19 15:50:33 --> Hooks Class Initialized
DEBUG - 2018-04-19 15:50:34 --> UTF-8 Support Enabled
INFO - 2018-04-19 15:50:34 --> Utf8 Class Initialized
INFO - 2018-04-19 15:50:34 --> URI Class Initialized
INFO - 2018-04-19 15:50:34 --> Router Class Initialized
INFO - 2018-04-19 15:50:34 --> Output Class Initialized
INFO - 2018-04-19 15:50:34 --> Security Class Initialized
DEBUG - 2018-04-19 15:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 15:50:34 --> CSRF cookie sent
INFO - 2018-04-19 15:50:34 --> Input Class Initialized
INFO - 2018-04-19 15:50:34 --> Language Class Initialized
INFO - 2018-04-19 15:50:34 --> Loader Class Initialized
INFO - 2018-04-19 15:50:34 --> Helper loaded: url_helper
INFO - 2018-04-19 15:50:34 --> Helper loaded: form_helper
INFO - 2018-04-19 15:50:34 --> Helper loaded: language_helper
DEBUG - 2018-04-19 15:50:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 15:50:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 15:50:35 --> User Agent Class Initialized
INFO - 2018-04-19 15:50:35 --> Controller Class Initialized
INFO - 2018-04-19 15:50:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 15:50:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 15:50:35 --> Config Class Initialized
INFO - 2018-04-19 15:50:35 --> Hooks Class Initialized
DEBUG - 2018-04-19 15:50:35 --> UTF-8 Support Enabled
INFO - 2018-04-19 15:50:35 --> Utf8 Class Initialized
INFO - 2018-04-19 15:50:35 --> URI Class Initialized
DEBUG - 2018-04-19 15:50:35 --> No URI present. Default controller set.
INFO - 2018-04-19 15:50:35 --> Router Class Initialized
INFO - 2018-04-19 15:50:35 --> Output Class Initialized
INFO - 2018-04-19 15:50:35 --> Security Class Initialized
DEBUG - 2018-04-19 15:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 15:50:35 --> CSRF cookie sent
INFO - 2018-04-19 15:50:35 --> Input Class Initialized
INFO - 2018-04-19 15:50:35 --> Language Class Initialized
INFO - 2018-04-19 15:50:35 --> Loader Class Initialized
INFO - 2018-04-19 15:50:35 --> Helper loaded: url_helper
INFO - 2018-04-19 15:50:35 --> Helper loaded: form_helper
INFO - 2018-04-19 15:50:35 --> Helper loaded: language_helper
DEBUG - 2018-04-19 15:50:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 15:50:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 15:50:36 --> User Agent Class Initialized
INFO - 2018-04-19 15:50:36 --> Controller Class Initialized
INFO - 2018-04-19 15:50:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 15:50:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 15:50:36 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 15:50:36 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 15:50:36 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-19 15:50:36 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 15:50:36 --> Final output sent to browser
DEBUG - 2018-04-19 15:50:36 --> Total execution time: 0.9349
INFO - 2018-04-19 15:50:49 --> Config Class Initialized
INFO - 2018-04-19 15:50:49 --> Hooks Class Initialized
DEBUG - 2018-04-19 15:50:49 --> UTF-8 Support Enabled
INFO - 2018-04-19 15:50:49 --> Utf8 Class Initialized
INFO - 2018-04-19 15:50:49 --> URI Class Initialized
INFO - 2018-04-19 15:50:49 --> Router Class Initialized
INFO - 2018-04-19 15:50:49 --> Output Class Initialized
INFO - 2018-04-19 15:50:49 --> Security Class Initialized
DEBUG - 2018-04-19 15:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 15:50:49 --> CSRF cookie sent
INFO - 2018-04-19 15:50:49 --> Input Class Initialized
INFO - 2018-04-19 15:50:49 --> Language Class Initialized
ERROR - 2018-04-19 15:50:49 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-19 16:12:03 --> Config Class Initialized
INFO - 2018-04-19 16:12:03 --> Hooks Class Initialized
DEBUG - 2018-04-19 16:12:03 --> UTF-8 Support Enabled
INFO - 2018-04-19 16:12:03 --> Utf8 Class Initialized
INFO - 2018-04-19 16:12:03 --> URI Class Initialized
DEBUG - 2018-04-19 16:12:03 --> No URI present. Default controller set.
INFO - 2018-04-19 16:12:03 --> Router Class Initialized
INFO - 2018-04-19 16:12:03 --> Output Class Initialized
INFO - 2018-04-19 16:12:03 --> Security Class Initialized
DEBUG - 2018-04-19 16:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 16:12:03 --> CSRF cookie sent
INFO - 2018-04-19 16:12:03 --> Input Class Initialized
INFO - 2018-04-19 16:12:03 --> Language Class Initialized
INFO - 2018-04-19 16:12:03 --> Loader Class Initialized
INFO - 2018-04-19 16:12:03 --> Helper loaded: url_helper
INFO - 2018-04-19 16:12:03 --> Helper loaded: form_helper
INFO - 2018-04-19 16:12:03 --> Helper loaded: language_helper
DEBUG - 2018-04-19 16:12:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 16:12:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 16:12:03 --> User Agent Class Initialized
INFO - 2018-04-19 16:12:03 --> Controller Class Initialized
INFO - 2018-04-19 16:12:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 16:12:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 16:12:03 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 16:12:03 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 16:12:03 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-19 16:12:03 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 16:12:03 --> Final output sent to browser
DEBUG - 2018-04-19 16:12:03 --> Total execution time: 0.2478
INFO - 2018-04-19 16:12:05 --> Config Class Initialized
INFO - 2018-04-19 16:12:05 --> Hooks Class Initialized
DEBUG - 2018-04-19 16:12:05 --> UTF-8 Support Enabled
INFO - 2018-04-19 16:12:05 --> Utf8 Class Initialized
INFO - 2018-04-19 16:12:05 --> URI Class Initialized
INFO - 2018-04-19 16:12:05 --> Router Class Initialized
INFO - 2018-04-19 16:12:05 --> Output Class Initialized
INFO - 2018-04-19 16:12:05 --> Security Class Initialized
DEBUG - 2018-04-19 16:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 16:12:05 --> CSRF cookie sent
INFO - 2018-04-19 16:12:05 --> Input Class Initialized
INFO - 2018-04-19 16:12:05 --> Language Class Initialized
ERROR - 2018-04-19 16:12:05 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-19 16:12:08 --> Config Class Initialized
INFO - 2018-04-19 16:12:08 --> Hooks Class Initialized
DEBUG - 2018-04-19 16:12:08 --> UTF-8 Support Enabled
INFO - 2018-04-19 16:12:08 --> Utf8 Class Initialized
INFO - 2018-04-19 16:12:08 --> URI Class Initialized
INFO - 2018-04-19 16:12:08 --> Router Class Initialized
INFO - 2018-04-19 16:12:08 --> Output Class Initialized
INFO - 2018-04-19 16:12:08 --> Security Class Initialized
DEBUG - 2018-04-19 16:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 16:12:08 --> CSRF cookie sent
INFO - 2018-04-19 16:12:08 --> Input Class Initialized
INFO - 2018-04-19 16:12:08 --> Language Class Initialized
INFO - 2018-04-19 16:12:08 --> Loader Class Initialized
INFO - 2018-04-19 16:12:08 --> Helper loaded: url_helper
INFO - 2018-04-19 16:12:08 --> Helper loaded: form_helper
INFO - 2018-04-19 16:12:08 --> Helper loaded: language_helper
DEBUG - 2018-04-19 16:12:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 16:12:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 16:12:08 --> User Agent Class Initialized
INFO - 2018-04-19 16:12:08 --> Controller Class Initialized
INFO - 2018-04-19 16:12:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 16:12:08 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-19 16:12:08 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-19 16:12:08 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 16:12:08 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 16:12:08 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-19 16:12:08 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-19 16:12:08 --> Could not find the language line "req_email"
INFO - 2018-04-19 16:12:08 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-04-19 16:12:08 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 16:12:08 --> Final output sent to browser
DEBUG - 2018-04-19 16:12:08 --> Total execution time: 0.3912
INFO - 2018-04-19 16:12:09 --> Config Class Initialized
INFO - 2018-04-19 16:12:09 --> Hooks Class Initialized
DEBUG - 2018-04-19 16:12:09 --> UTF-8 Support Enabled
INFO - 2018-04-19 16:12:09 --> Utf8 Class Initialized
INFO - 2018-04-19 16:12:09 --> URI Class Initialized
INFO - 2018-04-19 16:12:09 --> Router Class Initialized
INFO - 2018-04-19 16:12:09 --> Output Class Initialized
INFO - 2018-04-19 16:12:09 --> Security Class Initialized
DEBUG - 2018-04-19 16:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 16:12:09 --> CSRF cookie sent
INFO - 2018-04-19 16:12:09 --> Input Class Initialized
INFO - 2018-04-19 16:12:09 --> Language Class Initialized
ERROR - 2018-04-19 16:12:09 --> 404 Page Not Found: Assets/images
INFO - 2018-04-19 16:13:04 --> Config Class Initialized
INFO - 2018-04-19 16:13:04 --> Hooks Class Initialized
DEBUG - 2018-04-19 16:13:04 --> UTF-8 Support Enabled
INFO - 2018-04-19 16:13:04 --> Utf8 Class Initialized
INFO - 2018-04-19 16:13:04 --> URI Class Initialized
INFO - 2018-04-19 16:13:04 --> Router Class Initialized
INFO - 2018-04-19 16:13:04 --> Output Class Initialized
INFO - 2018-04-19 16:13:04 --> Security Class Initialized
DEBUG - 2018-04-19 16:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 16:13:04 --> CSRF cookie sent
INFO - 2018-04-19 16:13:04 --> CSRF token verified
INFO - 2018-04-19 16:13:04 --> Input Class Initialized
INFO - 2018-04-19 16:13:04 --> Language Class Initialized
INFO - 2018-04-19 16:13:04 --> Loader Class Initialized
INFO - 2018-04-19 16:13:04 --> Helper loaded: url_helper
INFO - 2018-04-19 16:13:04 --> Helper loaded: form_helper
INFO - 2018-04-19 16:13:04 --> Helper loaded: language_helper
DEBUG - 2018-04-19 16:13:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 16:13:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 16:13:04 --> User Agent Class Initialized
INFO - 2018-04-19 16:13:04 --> Controller Class Initialized
INFO - 2018-04-19 16:13:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 16:13:04 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-19 16:13:04 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-19 16:13:04 --> Form Validation Class Initialized
INFO - 2018-04-19 16:13:05 --> Pixel_Model class loaded
INFO - 2018-04-19 16:13:05 --> Database Driver Class Initialized
INFO - 2018-04-19 16:13:05 --> Model "AuthenticationModel" initialized
INFO - 2018-04-19 16:13:05 --> Config Class Initialized
INFO - 2018-04-19 16:13:05 --> Hooks Class Initialized
DEBUG - 2018-04-19 16:13:05 --> UTF-8 Support Enabled
INFO - 2018-04-19 16:13:05 --> Utf8 Class Initialized
INFO - 2018-04-19 16:13:05 --> URI Class Initialized
DEBUG - 2018-04-19 16:13:05 --> No URI present. Default controller set.
INFO - 2018-04-19 16:13:05 --> Router Class Initialized
INFO - 2018-04-19 16:13:05 --> Output Class Initialized
INFO - 2018-04-19 16:13:05 --> Security Class Initialized
DEBUG - 2018-04-19 16:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 16:13:05 --> CSRF cookie sent
INFO - 2018-04-19 16:13:05 --> Input Class Initialized
INFO - 2018-04-19 16:13:05 --> Language Class Initialized
INFO - 2018-04-19 16:13:05 --> Loader Class Initialized
INFO - 2018-04-19 16:13:05 --> Helper loaded: url_helper
INFO - 2018-04-19 16:13:05 --> Helper loaded: form_helper
INFO - 2018-04-19 16:13:05 --> Helper loaded: language_helper
DEBUG - 2018-04-19 16:13:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 16:13:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 16:13:05 --> User Agent Class Initialized
INFO - 2018-04-19 16:13:05 --> Controller Class Initialized
INFO - 2018-04-19 16:13:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 16:13:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 16:13:05 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 16:13:05 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-19 16:13:05 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 16:13:05 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-19 16:13:05 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 16:13:05 --> Final output sent to browser
DEBUG - 2018-04-19 16:13:05 --> Total execution time: 0.2481
INFO - 2018-04-19 16:13:07 --> Config Class Initialized
INFO - 2018-04-19 16:13:07 --> Hooks Class Initialized
DEBUG - 2018-04-19 16:13:07 --> UTF-8 Support Enabled
INFO - 2018-04-19 16:13:07 --> Utf8 Class Initialized
INFO - 2018-04-19 16:13:07 --> URI Class Initialized
INFO - 2018-04-19 16:13:07 --> Router Class Initialized
INFO - 2018-04-19 16:13:07 --> Output Class Initialized
INFO - 2018-04-19 16:13:07 --> Security Class Initialized
DEBUG - 2018-04-19 16:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 16:13:07 --> CSRF cookie sent
INFO - 2018-04-19 16:13:07 --> Input Class Initialized
INFO - 2018-04-19 16:13:07 --> Language Class Initialized
ERROR - 2018-04-19 16:13:07 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-19 16:15:09 --> Config Class Initialized
INFO - 2018-04-19 16:15:09 --> Hooks Class Initialized
DEBUG - 2018-04-19 16:15:09 --> UTF-8 Support Enabled
INFO - 2018-04-19 16:15:09 --> Utf8 Class Initialized
INFO - 2018-04-19 16:15:09 --> URI Class Initialized
INFO - 2018-04-19 16:15:09 --> Router Class Initialized
INFO - 2018-04-19 16:15:09 --> Output Class Initialized
INFO - 2018-04-19 16:15:09 --> Security Class Initialized
DEBUG - 2018-04-19 16:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 16:15:09 --> CSRF cookie sent
INFO - 2018-04-19 16:15:09 --> Input Class Initialized
INFO - 2018-04-19 16:15:09 --> Language Class Initialized
ERROR - 2018-04-19 16:15:09 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 16:15:15 --> Config Class Initialized
INFO - 2018-04-19 16:15:15 --> Hooks Class Initialized
DEBUG - 2018-04-19 16:15:15 --> UTF-8 Support Enabled
INFO - 2018-04-19 16:15:15 --> Utf8 Class Initialized
INFO - 2018-04-19 16:15:15 --> URI Class Initialized
DEBUG - 2018-04-19 16:15:15 --> No URI present. Default controller set.
INFO - 2018-04-19 16:15:15 --> Router Class Initialized
INFO - 2018-04-19 16:15:15 --> Output Class Initialized
INFO - 2018-04-19 16:15:15 --> Security Class Initialized
DEBUG - 2018-04-19 16:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 16:15:15 --> CSRF cookie sent
INFO - 2018-04-19 16:15:15 --> Input Class Initialized
INFO - 2018-04-19 16:15:15 --> Language Class Initialized
INFO - 2018-04-19 16:15:15 --> Loader Class Initialized
INFO - 2018-04-19 16:15:15 --> Helper loaded: url_helper
INFO - 2018-04-19 16:15:15 --> Helper loaded: form_helper
INFO - 2018-04-19 16:15:15 --> Helper loaded: language_helper
DEBUG - 2018-04-19 16:15:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 16:15:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 16:15:15 --> User Agent Class Initialized
INFO - 2018-04-19 16:15:15 --> Controller Class Initialized
INFO - 2018-04-19 16:15:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 16:15:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 16:15:16 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 16:15:16 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-19 16:15:16 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 16:15:16 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-19 16:15:16 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 16:15:16 --> Final output sent to browser
DEBUG - 2018-04-19 16:15:16 --> Total execution time: 0.2888
INFO - 2018-04-19 16:15:16 --> Config Class Initialized
INFO - 2018-04-19 16:15:16 --> Hooks Class Initialized
DEBUG - 2018-04-19 16:15:16 --> UTF-8 Support Enabled
INFO - 2018-04-19 16:15:16 --> Utf8 Class Initialized
INFO - 2018-04-19 16:15:16 --> URI Class Initialized
INFO - 2018-04-19 16:15:16 --> Router Class Initialized
INFO - 2018-04-19 16:15:16 --> Output Class Initialized
INFO - 2018-04-19 16:15:16 --> Security Class Initialized
DEBUG - 2018-04-19 16:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 16:15:16 --> CSRF cookie sent
INFO - 2018-04-19 16:15:16 --> Input Class Initialized
INFO - 2018-04-19 16:15:16 --> Language Class Initialized
ERROR - 2018-04-19 16:15:16 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 16:15:18 --> Config Class Initialized
INFO - 2018-04-19 16:15:18 --> Hooks Class Initialized
DEBUG - 2018-04-19 16:15:18 --> UTF-8 Support Enabled
INFO - 2018-04-19 16:15:18 --> Utf8 Class Initialized
INFO - 2018-04-19 16:15:18 --> URI Class Initialized
INFO - 2018-04-19 16:15:18 --> Router Class Initialized
INFO - 2018-04-19 16:15:18 --> Output Class Initialized
INFO - 2018-04-19 16:15:18 --> Security Class Initialized
DEBUG - 2018-04-19 16:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 16:15:18 --> CSRF cookie sent
INFO - 2018-04-19 16:15:18 --> Input Class Initialized
INFO - 2018-04-19 16:15:18 --> Language Class Initialized
ERROR - 2018-04-19 16:15:18 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-19 16:16:22 --> Config Class Initialized
INFO - 2018-04-19 16:16:22 --> Hooks Class Initialized
DEBUG - 2018-04-19 16:16:22 --> UTF-8 Support Enabled
INFO - 2018-04-19 16:16:22 --> Utf8 Class Initialized
INFO - 2018-04-19 16:16:22 --> URI Class Initialized
DEBUG - 2018-04-19 16:16:22 --> No URI present. Default controller set.
INFO - 2018-04-19 16:16:22 --> Router Class Initialized
INFO - 2018-04-19 16:16:22 --> Output Class Initialized
INFO - 2018-04-19 16:16:22 --> Security Class Initialized
DEBUG - 2018-04-19 16:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 16:16:22 --> CSRF cookie sent
INFO - 2018-04-19 16:16:22 --> Input Class Initialized
INFO - 2018-04-19 16:16:22 --> Language Class Initialized
INFO - 2018-04-19 16:16:22 --> Loader Class Initialized
INFO - 2018-04-19 16:16:22 --> Helper loaded: url_helper
INFO - 2018-04-19 16:16:22 --> Helper loaded: form_helper
INFO - 2018-04-19 16:16:22 --> Helper loaded: language_helper
DEBUG - 2018-04-19 16:16:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 16:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 16:16:22 --> User Agent Class Initialized
INFO - 2018-04-19 16:16:22 --> Controller Class Initialized
INFO - 2018-04-19 16:16:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 16:16:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 16:16:22 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 16:16:22 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-19 16:16:22 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 16:16:22 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-19 16:16:22 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 16:16:22 --> Final output sent to browser
DEBUG - 2018-04-19 16:16:22 --> Total execution time: 0.2960
INFO - 2018-04-19 16:16:22 --> Config Class Initialized
INFO - 2018-04-19 16:16:22 --> Hooks Class Initialized
DEBUG - 2018-04-19 16:16:22 --> UTF-8 Support Enabled
INFO - 2018-04-19 16:16:22 --> Utf8 Class Initialized
INFO - 2018-04-19 16:16:22 --> URI Class Initialized
INFO - 2018-04-19 16:16:22 --> Router Class Initialized
INFO - 2018-04-19 16:16:23 --> Output Class Initialized
INFO - 2018-04-19 16:16:23 --> Security Class Initialized
DEBUG - 2018-04-19 16:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 16:16:23 --> CSRF cookie sent
INFO - 2018-04-19 16:16:23 --> Input Class Initialized
INFO - 2018-04-19 16:16:23 --> Language Class Initialized
ERROR - 2018-04-19 16:16:23 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 16:16:24 --> Config Class Initialized
INFO - 2018-04-19 16:16:24 --> Hooks Class Initialized
DEBUG - 2018-04-19 16:16:24 --> UTF-8 Support Enabled
INFO - 2018-04-19 16:16:24 --> Utf8 Class Initialized
INFO - 2018-04-19 16:16:24 --> URI Class Initialized
INFO - 2018-04-19 16:16:24 --> Router Class Initialized
INFO - 2018-04-19 16:16:24 --> Output Class Initialized
INFO - 2018-04-19 16:16:24 --> Security Class Initialized
DEBUG - 2018-04-19 16:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 16:16:24 --> CSRF cookie sent
INFO - 2018-04-19 16:16:24 --> Input Class Initialized
INFO - 2018-04-19 16:16:24 --> Language Class Initialized
ERROR - 2018-04-19 16:16:24 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-19 16:17:13 --> Config Class Initialized
INFO - 2018-04-19 16:17:13 --> Hooks Class Initialized
DEBUG - 2018-04-19 16:17:13 --> UTF-8 Support Enabled
INFO - 2018-04-19 16:17:13 --> Utf8 Class Initialized
INFO - 2018-04-19 16:17:13 --> URI Class Initialized
DEBUG - 2018-04-19 16:17:13 --> No URI present. Default controller set.
INFO - 2018-04-19 16:17:13 --> Router Class Initialized
INFO - 2018-04-19 16:17:13 --> Output Class Initialized
INFO - 2018-04-19 16:17:13 --> Security Class Initialized
DEBUG - 2018-04-19 16:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 16:17:13 --> CSRF cookie sent
INFO - 2018-04-19 16:17:13 --> Input Class Initialized
INFO - 2018-04-19 16:17:13 --> Language Class Initialized
INFO - 2018-04-19 16:17:13 --> Loader Class Initialized
INFO - 2018-04-19 16:17:13 --> Helper loaded: url_helper
INFO - 2018-04-19 16:17:13 --> Helper loaded: form_helper
INFO - 2018-04-19 16:17:13 --> Helper loaded: language_helper
DEBUG - 2018-04-19 16:17:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 16:17:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 16:17:13 --> User Agent Class Initialized
INFO - 2018-04-19 16:17:13 --> Controller Class Initialized
INFO - 2018-04-19 16:17:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 16:17:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 16:17:13 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 16:17:13 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-19 16:17:13 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 16:17:14 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-19 16:17:14 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 16:17:14 --> Final output sent to browser
DEBUG - 2018-04-19 16:17:14 --> Total execution time: 0.3052
INFO - 2018-04-19 16:17:14 --> Config Class Initialized
INFO - 2018-04-19 16:17:14 --> Hooks Class Initialized
DEBUG - 2018-04-19 16:17:14 --> UTF-8 Support Enabled
INFO - 2018-04-19 16:17:14 --> Utf8 Class Initialized
INFO - 2018-04-19 16:17:14 --> URI Class Initialized
INFO - 2018-04-19 16:17:14 --> Router Class Initialized
INFO - 2018-04-19 16:17:14 --> Output Class Initialized
INFO - 2018-04-19 16:17:14 --> Security Class Initialized
DEBUG - 2018-04-19 16:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 16:17:14 --> CSRF cookie sent
INFO - 2018-04-19 16:17:14 --> Input Class Initialized
INFO - 2018-04-19 16:17:14 --> Language Class Initialized
ERROR - 2018-04-19 16:17:14 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 16:17:15 --> Config Class Initialized
INFO - 2018-04-19 16:17:15 --> Hooks Class Initialized
DEBUG - 2018-04-19 16:17:15 --> UTF-8 Support Enabled
INFO - 2018-04-19 16:17:15 --> Utf8 Class Initialized
INFO - 2018-04-19 16:17:15 --> URI Class Initialized
INFO - 2018-04-19 16:17:15 --> Router Class Initialized
INFO - 2018-04-19 16:17:15 --> Output Class Initialized
INFO - 2018-04-19 16:17:15 --> Security Class Initialized
DEBUG - 2018-04-19 16:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 16:17:16 --> CSRF cookie sent
INFO - 2018-04-19 16:17:16 --> Input Class Initialized
INFO - 2018-04-19 16:17:16 --> Language Class Initialized
ERROR - 2018-04-19 16:17:16 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-19 16:17:21 --> Config Class Initialized
INFO - 2018-04-19 16:17:21 --> Hooks Class Initialized
DEBUG - 2018-04-19 16:17:21 --> UTF-8 Support Enabled
INFO - 2018-04-19 16:17:21 --> Utf8 Class Initialized
INFO - 2018-04-19 16:17:21 --> URI Class Initialized
DEBUG - 2018-04-19 16:17:21 --> No URI present. Default controller set.
INFO - 2018-04-19 16:17:21 --> Router Class Initialized
INFO - 2018-04-19 16:17:21 --> Output Class Initialized
INFO - 2018-04-19 16:17:21 --> Security Class Initialized
DEBUG - 2018-04-19 16:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 16:17:21 --> CSRF cookie sent
INFO - 2018-04-19 16:17:21 --> Input Class Initialized
INFO - 2018-04-19 16:17:21 --> Language Class Initialized
INFO - 2018-04-19 16:17:21 --> Loader Class Initialized
INFO - 2018-04-19 16:17:21 --> Helper loaded: url_helper
INFO - 2018-04-19 16:17:21 --> Helper loaded: form_helper
INFO - 2018-04-19 16:17:21 --> Helper loaded: language_helper
DEBUG - 2018-04-19 16:17:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 16:17:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 16:17:21 --> User Agent Class Initialized
INFO - 2018-04-19 16:17:21 --> Controller Class Initialized
INFO - 2018-04-19 16:17:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 16:17:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 16:17:21 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 16:17:21 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-19 16:17:21 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 16:17:21 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-19 16:17:21 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 16:17:21 --> Final output sent to browser
DEBUG - 2018-04-19 16:17:21 --> Total execution time: 0.2937
INFO - 2018-04-19 16:17:23 --> Config Class Initialized
INFO - 2018-04-19 16:17:23 --> Hooks Class Initialized
DEBUG - 2018-04-19 16:17:23 --> UTF-8 Support Enabled
INFO - 2018-04-19 16:17:23 --> Utf8 Class Initialized
INFO - 2018-04-19 16:17:23 --> URI Class Initialized
INFO - 2018-04-19 16:17:23 --> Router Class Initialized
INFO - 2018-04-19 16:17:23 --> Output Class Initialized
INFO - 2018-04-19 16:17:23 --> Security Class Initialized
DEBUG - 2018-04-19 16:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 16:17:23 --> CSRF cookie sent
INFO - 2018-04-19 16:17:23 --> Input Class Initialized
INFO - 2018-04-19 16:17:23 --> Language Class Initialized
ERROR - 2018-04-19 16:17:23 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-19 16:18:51 --> Config Class Initialized
INFO - 2018-04-19 16:18:51 --> Hooks Class Initialized
DEBUG - 2018-04-19 16:18:51 --> UTF-8 Support Enabled
INFO - 2018-04-19 16:18:51 --> Utf8 Class Initialized
INFO - 2018-04-19 16:18:51 --> URI Class Initialized
DEBUG - 2018-04-19 16:18:51 --> No URI present. Default controller set.
INFO - 2018-04-19 16:18:51 --> Router Class Initialized
INFO - 2018-04-19 16:18:51 --> Output Class Initialized
INFO - 2018-04-19 16:18:51 --> Security Class Initialized
DEBUG - 2018-04-19 16:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 16:18:51 --> CSRF cookie sent
INFO - 2018-04-19 16:18:51 --> Input Class Initialized
INFO - 2018-04-19 16:18:51 --> Language Class Initialized
INFO - 2018-04-19 16:18:51 --> Loader Class Initialized
INFO - 2018-04-19 16:18:51 --> Helper loaded: url_helper
INFO - 2018-04-19 16:18:51 --> Helper loaded: form_helper
INFO - 2018-04-19 16:18:51 --> Helper loaded: language_helper
DEBUG - 2018-04-19 16:18:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 16:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 16:18:51 --> User Agent Class Initialized
INFO - 2018-04-19 16:18:51 --> Controller Class Initialized
INFO - 2018-04-19 16:18:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 16:18:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 16:18:51 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 16:18:51 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-19 16:18:51 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 16:18:51 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-19 16:18:51 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 16:18:51 --> Final output sent to browser
DEBUG - 2018-04-19 16:18:51 --> Total execution time: 0.2845
INFO - 2018-04-19 16:18:53 --> Config Class Initialized
INFO - 2018-04-19 16:18:53 --> Hooks Class Initialized
DEBUG - 2018-04-19 16:18:53 --> UTF-8 Support Enabled
INFO - 2018-04-19 16:18:53 --> Utf8 Class Initialized
INFO - 2018-04-19 16:18:53 --> URI Class Initialized
INFO - 2018-04-19 16:18:53 --> Router Class Initialized
INFO - 2018-04-19 16:18:53 --> Output Class Initialized
INFO - 2018-04-19 16:18:53 --> Security Class Initialized
DEBUG - 2018-04-19 16:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 16:18:53 --> CSRF cookie sent
INFO - 2018-04-19 16:18:53 --> Input Class Initialized
INFO - 2018-04-19 16:18:53 --> Language Class Initialized
ERROR - 2018-04-19 16:18:53 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-19 16:18:55 --> Config Class Initialized
INFO - 2018-04-19 16:18:55 --> Hooks Class Initialized
DEBUG - 2018-04-19 16:18:55 --> UTF-8 Support Enabled
INFO - 2018-04-19 16:18:55 --> Utf8 Class Initialized
INFO - 2018-04-19 16:18:55 --> URI Class Initialized
DEBUG - 2018-04-19 16:18:55 --> No URI present. Default controller set.
INFO - 2018-04-19 16:18:55 --> Router Class Initialized
INFO - 2018-04-19 16:18:55 --> Output Class Initialized
INFO - 2018-04-19 16:18:55 --> Security Class Initialized
DEBUG - 2018-04-19 16:18:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 16:18:55 --> CSRF cookie sent
INFO - 2018-04-19 16:18:55 --> Input Class Initialized
INFO - 2018-04-19 16:18:55 --> Language Class Initialized
INFO - 2018-04-19 16:18:55 --> Loader Class Initialized
INFO - 2018-04-19 16:18:55 --> Helper loaded: url_helper
INFO - 2018-04-19 16:18:55 --> Helper loaded: form_helper
INFO - 2018-04-19 16:18:55 --> Helper loaded: language_helper
DEBUG - 2018-04-19 16:18:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 16:18:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 16:18:55 --> User Agent Class Initialized
INFO - 2018-04-19 16:18:55 --> Controller Class Initialized
INFO - 2018-04-19 16:18:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 16:18:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 16:18:55 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 16:18:55 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-19 16:18:55 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 16:18:55 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-19 16:18:55 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 16:18:55 --> Final output sent to browser
DEBUG - 2018-04-19 16:18:55 --> Total execution time: 0.3133
INFO - 2018-04-19 16:18:56 --> Config Class Initialized
INFO - 2018-04-19 16:18:56 --> Hooks Class Initialized
DEBUG - 2018-04-19 16:18:56 --> UTF-8 Support Enabled
INFO - 2018-04-19 16:18:56 --> Utf8 Class Initialized
INFO - 2018-04-19 16:18:56 --> URI Class Initialized
INFO - 2018-04-19 16:18:56 --> Router Class Initialized
INFO - 2018-04-19 16:18:56 --> Output Class Initialized
INFO - 2018-04-19 16:18:56 --> Security Class Initialized
DEBUG - 2018-04-19 16:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 16:18:56 --> CSRF cookie sent
INFO - 2018-04-19 16:18:56 --> Input Class Initialized
INFO - 2018-04-19 16:18:56 --> Language Class Initialized
ERROR - 2018-04-19 16:18:56 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-19 16:19:51 --> Config Class Initialized
INFO - 2018-04-19 16:19:51 --> Hooks Class Initialized
DEBUG - 2018-04-19 16:19:51 --> UTF-8 Support Enabled
INFO - 2018-04-19 16:19:51 --> Utf8 Class Initialized
INFO - 2018-04-19 16:19:51 --> URI Class Initialized
DEBUG - 2018-04-19 16:19:51 --> No URI present. Default controller set.
INFO - 2018-04-19 16:19:51 --> Router Class Initialized
INFO - 2018-04-19 16:19:51 --> Output Class Initialized
INFO - 2018-04-19 16:19:51 --> Security Class Initialized
DEBUG - 2018-04-19 16:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 16:19:51 --> CSRF cookie sent
INFO - 2018-04-19 16:19:51 --> Input Class Initialized
INFO - 2018-04-19 16:19:51 --> Language Class Initialized
INFO - 2018-04-19 16:19:51 --> Loader Class Initialized
INFO - 2018-04-19 16:19:51 --> Helper loaded: url_helper
INFO - 2018-04-19 16:19:51 --> Helper loaded: form_helper
INFO - 2018-04-19 16:19:51 --> Helper loaded: language_helper
DEBUG - 2018-04-19 16:19:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 16:19:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 16:19:52 --> User Agent Class Initialized
INFO - 2018-04-19 16:19:52 --> Controller Class Initialized
INFO - 2018-04-19 16:19:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 16:19:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 16:19:52 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 16:19:52 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-19 16:19:52 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 16:19:52 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-19 16:19:52 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 16:19:52 --> Final output sent to browser
DEBUG - 2018-04-19 16:19:52 --> Total execution time: 0.2898
INFO - 2018-04-19 16:20:54 --> Config Class Initialized
INFO - 2018-04-19 16:20:54 --> Hooks Class Initialized
DEBUG - 2018-04-19 16:20:54 --> UTF-8 Support Enabled
INFO - 2018-04-19 16:20:54 --> Utf8 Class Initialized
INFO - 2018-04-19 16:20:54 --> URI Class Initialized
DEBUG - 2018-04-19 16:20:54 --> No URI present. Default controller set.
INFO - 2018-04-19 16:20:54 --> Router Class Initialized
INFO - 2018-04-19 16:20:54 --> Output Class Initialized
INFO - 2018-04-19 16:20:54 --> Security Class Initialized
DEBUG - 2018-04-19 16:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 16:20:54 --> CSRF cookie sent
INFO - 2018-04-19 16:20:54 --> Input Class Initialized
INFO - 2018-04-19 16:20:54 --> Language Class Initialized
INFO - 2018-04-19 16:20:54 --> Loader Class Initialized
INFO - 2018-04-19 16:20:54 --> Helper loaded: url_helper
INFO - 2018-04-19 16:20:54 --> Helper loaded: form_helper
INFO - 2018-04-19 16:20:54 --> Helper loaded: language_helper
DEBUG - 2018-04-19 16:20:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 16:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 16:20:54 --> User Agent Class Initialized
INFO - 2018-04-19 16:20:54 --> Controller Class Initialized
INFO - 2018-04-19 16:20:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 16:20:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 16:20:54 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 16:20:54 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-19 16:20:54 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 16:20:54 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-19 16:20:54 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 16:20:54 --> Final output sent to browser
DEBUG - 2018-04-19 16:20:54 --> Total execution time: 0.2928
INFO - 2018-04-19 16:20:55 --> Config Class Initialized
INFO - 2018-04-19 16:20:55 --> Hooks Class Initialized
DEBUG - 2018-04-19 16:20:55 --> UTF-8 Support Enabled
INFO - 2018-04-19 16:20:55 --> Utf8 Class Initialized
INFO - 2018-04-19 16:20:55 --> URI Class Initialized
INFO - 2018-04-19 16:20:55 --> Router Class Initialized
INFO - 2018-04-19 16:20:55 --> Output Class Initialized
INFO - 2018-04-19 16:20:55 --> Security Class Initialized
DEBUG - 2018-04-19 16:20:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 16:20:56 --> CSRF cookie sent
INFO - 2018-04-19 16:20:56 --> Input Class Initialized
INFO - 2018-04-19 16:20:56 --> Language Class Initialized
ERROR - 2018-04-19 16:20:56 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-19 16:21:04 --> Config Class Initialized
INFO - 2018-04-19 16:21:04 --> Hooks Class Initialized
DEBUG - 2018-04-19 16:21:04 --> UTF-8 Support Enabled
INFO - 2018-04-19 16:21:04 --> Utf8 Class Initialized
INFO - 2018-04-19 16:21:04 --> URI Class Initialized
INFO - 2018-04-19 16:21:04 --> Router Class Initialized
INFO - 2018-04-19 16:21:04 --> Output Class Initialized
INFO - 2018-04-19 16:21:04 --> Security Class Initialized
DEBUG - 2018-04-19 16:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 16:21:04 --> CSRF cookie sent
INFO - 2018-04-19 16:21:04 --> Input Class Initialized
INFO - 2018-04-19 16:21:04 --> Language Class Initialized
ERROR - 2018-04-19 16:21:04 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 16:21:17 --> Config Class Initialized
INFO - 2018-04-19 16:21:17 --> Hooks Class Initialized
DEBUG - 2018-04-19 16:21:17 --> UTF-8 Support Enabled
INFO - 2018-04-19 16:21:17 --> Utf8 Class Initialized
INFO - 2018-04-19 16:21:17 --> URI Class Initialized
DEBUG - 2018-04-19 16:21:17 --> No URI present. Default controller set.
INFO - 2018-04-19 16:21:17 --> Router Class Initialized
INFO - 2018-04-19 16:21:17 --> Output Class Initialized
INFO - 2018-04-19 16:21:17 --> Security Class Initialized
DEBUG - 2018-04-19 16:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 16:21:17 --> CSRF cookie sent
INFO - 2018-04-19 16:21:17 --> Input Class Initialized
INFO - 2018-04-19 16:21:17 --> Language Class Initialized
INFO - 2018-04-19 16:21:17 --> Loader Class Initialized
INFO - 2018-04-19 16:21:17 --> Helper loaded: url_helper
INFO - 2018-04-19 16:21:17 --> Helper loaded: form_helper
INFO - 2018-04-19 16:21:17 --> Helper loaded: language_helper
DEBUG - 2018-04-19 16:21:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 16:21:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 16:21:17 --> User Agent Class Initialized
INFO - 2018-04-19 16:21:17 --> Controller Class Initialized
INFO - 2018-04-19 16:21:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 16:21:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 16:21:17 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 16:21:17 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-19 16:21:17 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 16:21:17 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-19 16:21:17 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 16:21:17 --> Final output sent to browser
DEBUG - 2018-04-19 16:21:17 --> Total execution time: 0.2911
INFO - 2018-04-19 16:21:17 --> Config Class Initialized
INFO - 2018-04-19 16:21:17 --> Hooks Class Initialized
DEBUG - 2018-04-19 16:21:17 --> UTF-8 Support Enabled
INFO - 2018-04-19 16:21:17 --> Utf8 Class Initialized
INFO - 2018-04-19 16:21:17 --> URI Class Initialized
INFO - 2018-04-19 16:21:17 --> Router Class Initialized
INFO - 2018-04-19 16:21:17 --> Output Class Initialized
INFO - 2018-04-19 16:21:17 --> Security Class Initialized
DEBUG - 2018-04-19 16:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 16:21:17 --> CSRF cookie sent
INFO - 2018-04-19 16:21:17 --> Input Class Initialized
INFO - 2018-04-19 16:21:17 --> Language Class Initialized
ERROR - 2018-04-19 16:21:17 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 16:21:19 --> Config Class Initialized
INFO - 2018-04-19 16:21:19 --> Hooks Class Initialized
DEBUG - 2018-04-19 16:21:19 --> UTF-8 Support Enabled
INFO - 2018-04-19 16:21:19 --> Utf8 Class Initialized
INFO - 2018-04-19 16:21:19 --> URI Class Initialized
INFO - 2018-04-19 16:21:19 --> Router Class Initialized
INFO - 2018-04-19 16:21:19 --> Output Class Initialized
INFO - 2018-04-19 16:21:19 --> Security Class Initialized
DEBUG - 2018-04-19 16:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 16:21:19 --> CSRF cookie sent
INFO - 2018-04-19 16:21:19 --> Input Class Initialized
INFO - 2018-04-19 16:21:19 --> Language Class Initialized
ERROR - 2018-04-19 16:21:19 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-19 16:21:27 --> Config Class Initialized
INFO - 2018-04-19 16:21:27 --> Hooks Class Initialized
DEBUG - 2018-04-19 16:21:27 --> UTF-8 Support Enabled
INFO - 2018-04-19 16:21:27 --> Utf8 Class Initialized
INFO - 2018-04-19 16:21:27 --> URI Class Initialized
DEBUG - 2018-04-19 16:21:27 --> No URI present. Default controller set.
INFO - 2018-04-19 16:21:27 --> Router Class Initialized
INFO - 2018-04-19 16:21:27 --> Output Class Initialized
INFO - 2018-04-19 16:21:27 --> Security Class Initialized
DEBUG - 2018-04-19 16:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 16:21:27 --> CSRF cookie sent
INFO - 2018-04-19 16:21:27 --> Input Class Initialized
INFO - 2018-04-19 16:21:27 --> Language Class Initialized
INFO - 2018-04-19 16:21:27 --> Loader Class Initialized
INFO - 2018-04-19 16:21:27 --> Helper loaded: url_helper
INFO - 2018-04-19 16:21:27 --> Helper loaded: form_helper
INFO - 2018-04-19 16:21:27 --> Helper loaded: language_helper
DEBUG - 2018-04-19 16:21:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 16:21:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 16:21:27 --> User Agent Class Initialized
INFO - 2018-04-19 16:21:27 --> Controller Class Initialized
INFO - 2018-04-19 16:21:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 16:21:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 16:21:27 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 16:21:27 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-19 16:21:27 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 16:21:27 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-19 16:21:27 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 16:21:27 --> Final output sent to browser
DEBUG - 2018-04-19 16:21:27 --> Total execution time: 0.2902
INFO - 2018-04-19 16:21:29 --> Config Class Initialized
INFO - 2018-04-19 16:21:29 --> Hooks Class Initialized
DEBUG - 2018-04-19 16:21:29 --> UTF-8 Support Enabled
INFO - 2018-04-19 16:21:29 --> Utf8 Class Initialized
INFO - 2018-04-19 16:21:29 --> URI Class Initialized
INFO - 2018-04-19 16:21:29 --> Router Class Initialized
INFO - 2018-04-19 16:21:29 --> Output Class Initialized
INFO - 2018-04-19 16:21:29 --> Security Class Initialized
DEBUG - 2018-04-19 16:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 16:21:29 --> CSRF cookie sent
INFO - 2018-04-19 16:21:29 --> Input Class Initialized
INFO - 2018-04-19 16:21:29 --> Language Class Initialized
ERROR - 2018-04-19 16:21:29 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-19 16:21:36 --> Config Class Initialized
INFO - 2018-04-19 16:21:36 --> Hooks Class Initialized
DEBUG - 2018-04-19 16:21:36 --> UTF-8 Support Enabled
INFO - 2018-04-19 16:21:36 --> Utf8 Class Initialized
INFO - 2018-04-19 16:21:36 --> URI Class Initialized
INFO - 2018-04-19 16:21:36 --> Router Class Initialized
INFO - 2018-04-19 16:21:36 --> Output Class Initialized
INFO - 2018-04-19 16:21:36 --> Security Class Initialized
DEBUG - 2018-04-19 16:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 16:21:36 --> CSRF cookie sent
INFO - 2018-04-19 16:21:36 --> Input Class Initialized
INFO - 2018-04-19 16:21:36 --> Language Class Initialized
ERROR - 2018-04-19 16:21:36 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 17:08:36 --> Config Class Initialized
INFO - 2018-04-19 17:08:36 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:08:36 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:08:36 --> Utf8 Class Initialized
INFO - 2018-04-19 17:08:36 --> URI Class Initialized
DEBUG - 2018-04-19 17:08:36 --> No URI present. Default controller set.
INFO - 2018-04-19 17:08:37 --> Router Class Initialized
INFO - 2018-04-19 17:08:37 --> Output Class Initialized
INFO - 2018-04-19 17:08:37 --> Security Class Initialized
DEBUG - 2018-04-19 17:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:08:37 --> CSRF cookie sent
INFO - 2018-04-19 17:08:37 --> Input Class Initialized
INFO - 2018-04-19 17:08:37 --> Language Class Initialized
INFO - 2018-04-19 17:08:37 --> Loader Class Initialized
INFO - 2018-04-19 17:08:37 --> Helper loaded: url_helper
INFO - 2018-04-19 17:08:37 --> Helper loaded: form_helper
INFO - 2018-04-19 17:08:37 --> Helper loaded: language_helper
DEBUG - 2018-04-19 17:08:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 17:08:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 17:08:37 --> User Agent Class Initialized
INFO - 2018-04-19 17:08:37 --> Controller Class Initialized
INFO - 2018-04-19 17:08:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 17:08:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 17:08:37 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 17:08:37 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-19 17:08:37 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 17:08:37 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-19 17:08:37 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 17:08:37 --> Final output sent to browser
DEBUG - 2018-04-19 17:08:37 --> Total execution time: 0.2777
INFO - 2018-04-19 17:08:37 --> Config Class Initialized
INFO - 2018-04-19 17:08:37 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:08:37 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:08:37 --> Utf8 Class Initialized
INFO - 2018-04-19 17:08:37 --> URI Class Initialized
INFO - 2018-04-19 17:08:37 --> Router Class Initialized
INFO - 2018-04-19 17:08:37 --> Output Class Initialized
INFO - 2018-04-19 17:08:37 --> Security Class Initialized
DEBUG - 2018-04-19 17:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:08:37 --> CSRF cookie sent
INFO - 2018-04-19 17:08:37 --> Input Class Initialized
INFO - 2018-04-19 17:08:37 --> Language Class Initialized
ERROR - 2018-04-19 17:08:37 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 17:08:39 --> Config Class Initialized
INFO - 2018-04-19 17:08:39 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:08:39 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:08:39 --> Utf8 Class Initialized
INFO - 2018-04-19 17:08:39 --> URI Class Initialized
INFO - 2018-04-19 17:08:39 --> Router Class Initialized
INFO - 2018-04-19 17:08:39 --> Output Class Initialized
INFO - 2018-04-19 17:08:39 --> Security Class Initialized
DEBUG - 2018-04-19 17:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:08:39 --> CSRF cookie sent
INFO - 2018-04-19 17:08:39 --> Input Class Initialized
INFO - 2018-04-19 17:08:39 --> Language Class Initialized
ERROR - 2018-04-19 17:08:39 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-19 17:08:39 --> Config Class Initialized
INFO - 2018-04-19 17:08:39 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:08:39 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:08:39 --> Utf8 Class Initialized
INFO - 2018-04-19 17:08:39 --> URI Class Initialized
INFO - 2018-04-19 17:08:39 --> Router Class Initialized
INFO - 2018-04-19 17:08:39 --> Output Class Initialized
INFO - 2018-04-19 17:08:39 --> Security Class Initialized
DEBUG - 2018-04-19 17:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:08:39 --> CSRF cookie sent
INFO - 2018-04-19 17:08:39 --> Input Class Initialized
INFO - 2018-04-19 17:08:39 --> Language Class Initialized
INFO - 2018-04-19 17:08:39 --> Loader Class Initialized
INFO - 2018-04-19 17:08:39 --> Helper loaded: url_helper
INFO - 2018-04-19 17:08:39 --> Helper loaded: form_helper
INFO - 2018-04-19 17:08:39 --> Helper loaded: language_helper
DEBUG - 2018-04-19 17:08:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 17:08:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 17:08:39 --> User Agent Class Initialized
INFO - 2018-04-19 17:08:40 --> Controller Class Initialized
INFO - 2018-04-19 17:08:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 17:08:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 17:08:40 --> Config Class Initialized
INFO - 2018-04-19 17:08:40 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:08:40 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:08:40 --> Utf8 Class Initialized
INFO - 2018-04-19 17:08:40 --> URI Class Initialized
DEBUG - 2018-04-19 17:08:40 --> No URI present. Default controller set.
INFO - 2018-04-19 17:08:40 --> Router Class Initialized
INFO - 2018-04-19 17:08:40 --> Output Class Initialized
INFO - 2018-04-19 17:08:40 --> Security Class Initialized
DEBUG - 2018-04-19 17:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:08:40 --> CSRF cookie sent
INFO - 2018-04-19 17:08:40 --> Input Class Initialized
INFO - 2018-04-19 17:08:40 --> Language Class Initialized
INFO - 2018-04-19 17:08:40 --> Loader Class Initialized
INFO - 2018-04-19 17:08:40 --> Helper loaded: url_helper
INFO - 2018-04-19 17:08:40 --> Helper loaded: form_helper
INFO - 2018-04-19 17:08:40 --> Helper loaded: language_helper
DEBUG - 2018-04-19 17:08:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 17:08:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 17:08:40 --> User Agent Class Initialized
INFO - 2018-04-19 17:08:40 --> Controller Class Initialized
INFO - 2018-04-19 17:08:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 17:08:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 17:08:40 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 17:08:40 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-19 17:08:40 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 17:08:40 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-19 17:08:40 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 17:08:40 --> Final output sent to browser
DEBUG - 2018-04-19 17:08:40 --> Total execution time: 0.3959
INFO - 2018-04-19 17:08:40 --> Config Class Initialized
INFO - 2018-04-19 17:08:40 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:08:40 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:08:40 --> Utf8 Class Initialized
INFO - 2018-04-19 17:08:41 --> URI Class Initialized
INFO - 2018-04-19 17:08:41 --> Router Class Initialized
INFO - 2018-04-19 17:08:41 --> Output Class Initialized
INFO - 2018-04-19 17:08:41 --> Security Class Initialized
DEBUG - 2018-04-19 17:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:08:41 --> CSRF cookie sent
INFO - 2018-04-19 17:08:41 --> Input Class Initialized
INFO - 2018-04-19 17:08:41 --> Language Class Initialized
ERROR - 2018-04-19 17:08:41 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 17:08:42 --> Config Class Initialized
INFO - 2018-04-19 17:08:42 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:08:42 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:08:42 --> Utf8 Class Initialized
INFO - 2018-04-19 17:08:42 --> URI Class Initialized
INFO - 2018-04-19 17:08:42 --> Router Class Initialized
INFO - 2018-04-19 17:08:42 --> Output Class Initialized
INFO - 2018-04-19 17:08:42 --> Security Class Initialized
DEBUG - 2018-04-19 17:08:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:08:42 --> CSRF cookie sent
INFO - 2018-04-19 17:08:42 --> Input Class Initialized
INFO - 2018-04-19 17:08:42 --> Language Class Initialized
ERROR - 2018-04-19 17:08:42 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-19 17:08:45 --> Config Class Initialized
INFO - 2018-04-19 17:08:45 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:08:45 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:08:45 --> Utf8 Class Initialized
INFO - 2018-04-19 17:08:45 --> URI Class Initialized
INFO - 2018-04-19 17:08:45 --> Router Class Initialized
INFO - 2018-04-19 17:08:45 --> Output Class Initialized
INFO - 2018-04-19 17:08:45 --> Security Class Initialized
DEBUG - 2018-04-19 17:08:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:08:45 --> CSRF cookie sent
INFO - 2018-04-19 17:08:45 --> Input Class Initialized
INFO - 2018-04-19 17:08:45 --> Language Class Initialized
INFO - 2018-04-19 17:08:45 --> Loader Class Initialized
INFO - 2018-04-19 17:08:45 --> Helper loaded: url_helper
INFO - 2018-04-19 17:08:45 --> Helper loaded: form_helper
INFO - 2018-04-19 17:08:45 --> Helper loaded: language_helper
DEBUG - 2018-04-19 17:08:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 17:08:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 17:08:45 --> User Agent Class Initialized
INFO - 2018-04-19 17:08:45 --> Controller Class Initialized
INFO - 2018-04-19 17:08:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 17:08:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 17:08:45 --> Config Class Initialized
INFO - 2018-04-19 17:08:45 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:08:45 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:08:45 --> Utf8 Class Initialized
INFO - 2018-04-19 17:08:45 --> URI Class Initialized
DEBUG - 2018-04-19 17:08:45 --> No URI present. Default controller set.
INFO - 2018-04-19 17:08:45 --> Router Class Initialized
INFO - 2018-04-19 17:08:45 --> Output Class Initialized
INFO - 2018-04-19 17:08:45 --> Security Class Initialized
DEBUG - 2018-04-19 17:08:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:08:45 --> CSRF cookie sent
INFO - 2018-04-19 17:08:45 --> Input Class Initialized
INFO - 2018-04-19 17:08:45 --> Language Class Initialized
INFO - 2018-04-19 17:08:46 --> Loader Class Initialized
INFO - 2018-04-19 17:08:46 --> Helper loaded: url_helper
INFO - 2018-04-19 17:08:46 --> Helper loaded: form_helper
INFO - 2018-04-19 17:08:46 --> Helper loaded: language_helper
DEBUG - 2018-04-19 17:08:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 17:08:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 17:08:46 --> User Agent Class Initialized
INFO - 2018-04-19 17:08:46 --> Controller Class Initialized
INFO - 2018-04-19 17:08:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 17:08:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 17:08:46 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 17:08:46 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-19 17:08:46 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 17:08:46 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-19 17:08:46 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 17:08:46 --> Final output sent to browser
DEBUG - 2018-04-19 17:08:46 --> Total execution time: 0.3112
INFO - 2018-04-19 17:08:46 --> Config Class Initialized
INFO - 2018-04-19 17:08:46 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:08:46 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:08:46 --> Utf8 Class Initialized
INFO - 2018-04-19 17:08:46 --> URI Class Initialized
INFO - 2018-04-19 17:08:46 --> Router Class Initialized
INFO - 2018-04-19 17:08:46 --> Output Class Initialized
INFO - 2018-04-19 17:08:46 --> Security Class Initialized
DEBUG - 2018-04-19 17:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:08:46 --> CSRF cookie sent
INFO - 2018-04-19 17:08:46 --> Input Class Initialized
INFO - 2018-04-19 17:08:46 --> Language Class Initialized
ERROR - 2018-04-19 17:08:46 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 17:08:48 --> Config Class Initialized
INFO - 2018-04-19 17:08:48 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:08:48 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:08:48 --> Utf8 Class Initialized
INFO - 2018-04-19 17:08:48 --> URI Class Initialized
INFO - 2018-04-19 17:08:48 --> Router Class Initialized
INFO - 2018-04-19 17:08:48 --> Output Class Initialized
INFO - 2018-04-19 17:08:48 --> Security Class Initialized
DEBUG - 2018-04-19 17:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:08:48 --> CSRF cookie sent
INFO - 2018-04-19 17:08:48 --> Input Class Initialized
INFO - 2018-04-19 17:08:48 --> Language Class Initialized
ERROR - 2018-04-19 17:08:48 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-19 17:09:16 --> Config Class Initialized
INFO - 2018-04-19 17:09:16 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:09:16 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:09:16 --> Utf8 Class Initialized
INFO - 2018-04-19 17:09:16 --> URI Class Initialized
DEBUG - 2018-04-19 17:09:16 --> No URI present. Default controller set.
INFO - 2018-04-19 17:09:16 --> Router Class Initialized
INFO - 2018-04-19 17:09:16 --> Output Class Initialized
INFO - 2018-04-19 17:09:16 --> Security Class Initialized
DEBUG - 2018-04-19 17:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:09:16 --> CSRF cookie sent
INFO - 2018-04-19 17:09:16 --> Input Class Initialized
INFO - 2018-04-19 17:09:16 --> Language Class Initialized
INFO - 2018-04-19 17:09:16 --> Loader Class Initialized
INFO - 2018-04-19 17:09:16 --> Helper loaded: url_helper
INFO - 2018-04-19 17:09:16 --> Helper loaded: form_helper
INFO - 2018-04-19 17:09:16 --> Helper loaded: language_helper
DEBUG - 2018-04-19 17:09:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 17:09:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 17:09:16 --> User Agent Class Initialized
INFO - 2018-04-19 17:09:16 --> Controller Class Initialized
INFO - 2018-04-19 17:09:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 17:09:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 17:09:16 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 17:09:16 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-19 17:09:16 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 17:09:16 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-19 17:09:16 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 17:09:16 --> Final output sent to browser
DEBUG - 2018-04-19 17:09:16 --> Total execution time: 0.2982
INFO - 2018-04-19 17:09:16 --> Config Class Initialized
INFO - 2018-04-19 17:09:16 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:09:16 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:09:16 --> Utf8 Class Initialized
INFO - 2018-04-19 17:09:16 --> URI Class Initialized
INFO - 2018-04-19 17:09:16 --> Router Class Initialized
INFO - 2018-04-19 17:09:16 --> Output Class Initialized
INFO - 2018-04-19 17:09:16 --> Security Class Initialized
DEBUG - 2018-04-19 17:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:09:16 --> CSRF cookie sent
INFO - 2018-04-19 17:09:16 --> Input Class Initialized
INFO - 2018-04-19 17:09:16 --> Language Class Initialized
ERROR - 2018-04-19 17:09:16 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 17:09:18 --> Config Class Initialized
INFO - 2018-04-19 17:09:18 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:09:18 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:09:18 --> Utf8 Class Initialized
INFO - 2018-04-19 17:09:18 --> URI Class Initialized
INFO - 2018-04-19 17:09:18 --> Router Class Initialized
INFO - 2018-04-19 17:09:18 --> Output Class Initialized
INFO - 2018-04-19 17:09:18 --> Security Class Initialized
DEBUG - 2018-04-19 17:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:09:18 --> CSRF cookie sent
INFO - 2018-04-19 17:09:18 --> Input Class Initialized
INFO - 2018-04-19 17:09:18 --> Language Class Initialized
ERROR - 2018-04-19 17:09:18 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-19 17:09:18 --> Config Class Initialized
INFO - 2018-04-19 17:09:18 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:09:18 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:09:18 --> Utf8 Class Initialized
INFO - 2018-04-19 17:09:18 --> URI Class Initialized
INFO - 2018-04-19 17:09:18 --> Router Class Initialized
INFO - 2018-04-19 17:09:18 --> Output Class Initialized
INFO - 2018-04-19 17:09:18 --> Security Class Initialized
DEBUG - 2018-04-19 17:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:09:18 --> CSRF cookie sent
INFO - 2018-04-19 17:09:18 --> Input Class Initialized
INFO - 2018-04-19 17:09:19 --> Language Class Initialized
INFO - 2018-04-19 17:09:19 --> Loader Class Initialized
INFO - 2018-04-19 17:09:19 --> Helper loaded: url_helper
INFO - 2018-04-19 17:09:19 --> Helper loaded: form_helper
INFO - 2018-04-19 17:09:19 --> Helper loaded: language_helper
DEBUG - 2018-04-19 17:09:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 17:09:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 17:09:19 --> User Agent Class Initialized
INFO - 2018-04-19 17:09:19 --> Controller Class Initialized
INFO - 2018-04-19 17:09:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 17:09:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 17:09:19 --> Pixel_Model class loaded
INFO - 2018-04-19 17:09:19 --> Database Driver Class Initialized
INFO - 2018-04-19 17:09:19 --> Model "MyAccountModel" initialized
INFO - 2018-04-19 17:09:19 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 17:09:19 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-19 17:09:19 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 17:09:19 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-19 17:09:19 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-19 17:09:19 --> File loaded: E:\www\yacopoo\application\views\register/import_enduser.php
INFO - 2018-04-19 17:09:19 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 17:09:19 --> Final output sent to browser
DEBUG - 2018-04-19 17:09:19 --> Total execution time: 0.5270
INFO - 2018-04-19 17:09:19 --> Config Class Initialized
INFO - 2018-04-19 17:09:19 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:09:19 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:09:19 --> Utf8 Class Initialized
INFO - 2018-04-19 17:09:19 --> URI Class Initialized
INFO - 2018-04-19 17:09:19 --> Router Class Initialized
INFO - 2018-04-19 17:09:19 --> Output Class Initialized
INFO - 2018-04-19 17:09:19 --> Config Class Initialized
INFO - 2018-04-19 17:09:19 --> Hooks Class Initialized
INFO - 2018-04-19 17:09:19 --> Security Class Initialized
DEBUG - 2018-04-19 17:09:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-19 17:09:19 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:09:19 --> CSRF cookie sent
INFO - 2018-04-19 17:09:19 --> Utf8 Class Initialized
INFO - 2018-04-19 17:09:19 --> Input Class Initialized
INFO - 2018-04-19 17:09:19 --> URI Class Initialized
INFO - 2018-04-19 17:09:19 --> Language Class Initialized
INFO - 2018-04-19 17:09:19 --> Router Class Initialized
ERROR - 2018-04-19 17:09:19 --> 404 Page Not Found: Assets/images
INFO - 2018-04-19 17:09:19 --> Output Class Initialized
INFO - 2018-04-19 17:09:19 --> Security Class Initialized
DEBUG - 2018-04-19 17:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:09:19 --> CSRF cookie sent
INFO - 2018-04-19 17:09:19 --> Input Class Initialized
INFO - 2018-04-19 17:09:19 --> Language Class Initialized
ERROR - 2018-04-19 17:09:19 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 17:09:47 --> Config Class Initialized
INFO - 2018-04-19 17:09:47 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:09:47 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:09:47 --> Utf8 Class Initialized
INFO - 2018-04-19 17:09:47 --> URI Class Initialized
INFO - 2018-04-19 17:09:47 --> Router Class Initialized
INFO - 2018-04-19 17:09:47 --> Output Class Initialized
INFO - 2018-04-19 17:09:47 --> Security Class Initialized
DEBUG - 2018-04-19 17:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:09:47 --> CSRF cookie sent
INFO - 2018-04-19 17:09:47 --> Input Class Initialized
INFO - 2018-04-19 17:09:47 --> Language Class Initialized
INFO - 2018-04-19 17:09:47 --> Loader Class Initialized
INFO - 2018-04-19 17:09:47 --> Helper loaded: url_helper
INFO - 2018-04-19 17:09:47 --> Helper loaded: form_helper
INFO - 2018-04-19 17:09:47 --> Helper loaded: language_helper
DEBUG - 2018-04-19 17:09:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 17:09:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 17:09:47 --> User Agent Class Initialized
INFO - 2018-04-19 17:09:47 --> Controller Class Initialized
INFO - 2018-04-19 17:09:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 17:09:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 17:09:47 --> Pixel_Model class loaded
INFO - 2018-04-19 17:09:47 --> Database Driver Class Initialized
INFO - 2018-04-19 17:09:47 --> Model "MyAccountModel" initialized
INFO - 2018-04-19 17:09:47 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 17:09:47 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-19 17:09:47 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 17:09:47 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-19 17:09:47 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-19 17:09:47 --> File loaded: E:\www\yacopoo\application\views\register/import_enduser.php
INFO - 2018-04-19 17:09:47 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 17:09:47 --> Final output sent to browser
DEBUG - 2018-04-19 17:09:47 --> Total execution time: 0.3404
INFO - 2018-04-19 17:09:47 --> Config Class Initialized
INFO - 2018-04-19 17:09:47 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:09:47 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:09:47 --> Utf8 Class Initialized
INFO - 2018-04-19 17:09:48 --> URI Class Initialized
INFO - 2018-04-19 17:09:48 --> Router Class Initialized
INFO - 2018-04-19 17:09:48 --> Output Class Initialized
INFO - 2018-04-19 17:09:48 --> Config Class Initialized
INFO - 2018-04-19 17:09:48 --> Hooks Class Initialized
INFO - 2018-04-19 17:09:48 --> Security Class Initialized
DEBUG - 2018-04-19 17:09:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-19 17:09:48 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:09:48 --> Utf8 Class Initialized
INFO - 2018-04-19 17:09:48 --> CSRF cookie sent
INFO - 2018-04-19 17:09:48 --> Input Class Initialized
INFO - 2018-04-19 17:09:48 --> URI Class Initialized
INFO - 2018-04-19 17:09:48 --> Language Class Initialized
INFO - 2018-04-19 17:09:48 --> Router Class Initialized
ERROR - 2018-04-19 17:09:48 --> 404 Page Not Found: Assets/images
INFO - 2018-04-19 17:09:48 --> Output Class Initialized
INFO - 2018-04-19 17:09:48 --> Security Class Initialized
DEBUG - 2018-04-19 17:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:09:48 --> CSRF cookie sent
INFO - 2018-04-19 17:09:48 --> Input Class Initialized
INFO - 2018-04-19 17:09:48 --> Language Class Initialized
ERROR - 2018-04-19 17:09:48 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 17:09:48 --> Config Class Initialized
INFO - 2018-04-19 17:09:48 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:09:48 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:09:48 --> Utf8 Class Initialized
INFO - 2018-04-19 17:09:48 --> URI Class Initialized
INFO - 2018-04-19 17:09:48 --> Router Class Initialized
INFO - 2018-04-19 17:09:48 --> Output Class Initialized
INFO - 2018-04-19 17:09:48 --> Security Class Initialized
DEBUG - 2018-04-19 17:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:09:48 --> CSRF cookie sent
INFO - 2018-04-19 17:09:48 --> Input Class Initialized
INFO - 2018-04-19 17:09:48 --> Language Class Initialized
ERROR - 2018-04-19 17:09:48 --> 404 Page Not Found: Assets/images
INFO - 2018-04-19 17:10:16 --> Config Class Initialized
INFO - 2018-04-19 17:10:16 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:10:16 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:10:16 --> Utf8 Class Initialized
INFO - 2018-04-19 17:10:16 --> URI Class Initialized
INFO - 2018-04-19 17:10:16 --> Router Class Initialized
INFO - 2018-04-19 17:10:16 --> Output Class Initialized
INFO - 2018-04-19 17:10:16 --> Security Class Initialized
DEBUG - 2018-04-19 17:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:10:16 --> CSRF cookie sent
INFO - 2018-04-19 17:10:16 --> Input Class Initialized
INFO - 2018-04-19 17:10:16 --> Language Class Initialized
INFO - 2018-04-19 17:10:16 --> Loader Class Initialized
INFO - 2018-04-19 17:10:16 --> Helper loaded: url_helper
INFO - 2018-04-19 17:10:16 --> Helper loaded: form_helper
INFO - 2018-04-19 17:10:16 --> Helper loaded: language_helper
DEBUG - 2018-04-19 17:10:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 17:10:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 17:10:16 --> User Agent Class Initialized
INFO - 2018-04-19 17:10:16 --> Controller Class Initialized
INFO - 2018-04-19 17:10:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 17:10:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 17:10:16 --> Pixel_Model class loaded
INFO - 2018-04-19 17:10:16 --> Database Driver Class Initialized
INFO - 2018-04-19 17:10:16 --> Model "MyAccountModel" initialized
INFO - 2018-04-19 17:10:16 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 17:10:16 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-19 17:10:16 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 17:10:16 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-19 17:10:16 --> File loaded: E:\www\yacopoo\application\views\register/import_enduser.php
INFO - 2018-04-19 17:10:16 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 17:10:16 --> Final output sent to browser
DEBUG - 2018-04-19 17:10:16 --> Total execution time: 0.3272
INFO - 2018-04-19 17:10:17 --> Config Class Initialized
INFO - 2018-04-19 17:10:17 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:10:17 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:10:17 --> Utf8 Class Initialized
INFO - 2018-04-19 17:10:17 --> URI Class Initialized
INFO - 2018-04-19 17:10:17 --> Router Class Initialized
INFO - 2018-04-19 17:10:17 --> Output Class Initialized
INFO - 2018-04-19 17:10:17 --> Security Class Initialized
DEBUG - 2018-04-19 17:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:10:17 --> CSRF cookie sent
INFO - 2018-04-19 17:10:17 --> Input Class Initialized
INFO - 2018-04-19 17:10:17 --> Language Class Initialized
ERROR - 2018-04-19 17:10:17 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 17:10:58 --> Config Class Initialized
INFO - 2018-04-19 17:10:58 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:10:58 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:10:58 --> Utf8 Class Initialized
INFO - 2018-04-19 17:10:58 --> URI Class Initialized
INFO - 2018-04-19 17:10:58 --> Router Class Initialized
INFO - 2018-04-19 17:10:58 --> Output Class Initialized
INFO - 2018-04-19 17:10:58 --> Security Class Initialized
DEBUG - 2018-04-19 17:10:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:10:58 --> CSRF cookie sent
INFO - 2018-04-19 17:10:58 --> Input Class Initialized
INFO - 2018-04-19 17:10:58 --> Language Class Initialized
INFO - 2018-04-19 17:10:58 --> Loader Class Initialized
INFO - 2018-04-19 17:10:58 --> Helper loaded: url_helper
INFO - 2018-04-19 17:10:58 --> Helper loaded: form_helper
INFO - 2018-04-19 17:10:58 --> Helper loaded: language_helper
DEBUG - 2018-04-19 17:10:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 17:10:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 17:10:58 --> User Agent Class Initialized
INFO - 2018-04-19 17:10:58 --> Controller Class Initialized
INFO - 2018-04-19 17:10:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 17:10:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 17:10:58 --> Pixel_Model class loaded
INFO - 2018-04-19 17:10:58 --> Database Driver Class Initialized
INFO - 2018-04-19 17:10:58 --> Model "MyAccountModel" initialized
INFO - 2018-04-19 17:10:58 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 17:10:58 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-19 17:10:58 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 17:10:58 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-19 17:10:58 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-19 17:10:58 --> File loaded: E:\www\yacopoo\application\views\register/import_enduser.php
INFO - 2018-04-19 17:10:58 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 17:10:58 --> Final output sent to browser
DEBUG - 2018-04-19 17:10:58 --> Total execution time: 0.3512
INFO - 2018-04-19 17:10:59 --> Config Class Initialized
INFO - 2018-04-19 17:10:59 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:10:59 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:10:59 --> Utf8 Class Initialized
INFO - 2018-04-19 17:10:59 --> URI Class Initialized
INFO - 2018-04-19 17:10:59 --> Router Class Initialized
INFO - 2018-04-19 17:10:59 --> Output Class Initialized
INFO - 2018-04-19 17:10:59 --> Security Class Initialized
DEBUG - 2018-04-19 17:10:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:10:59 --> CSRF cookie sent
INFO - 2018-04-19 17:10:59 --> Input Class Initialized
INFO - 2018-04-19 17:10:59 --> Language Class Initialized
ERROR - 2018-04-19 17:10:59 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 17:11:37 --> Config Class Initialized
INFO - 2018-04-19 17:11:37 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:11:37 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:11:37 --> Utf8 Class Initialized
INFO - 2018-04-19 17:11:37 --> URI Class Initialized
INFO - 2018-04-19 17:11:37 --> Router Class Initialized
INFO - 2018-04-19 17:11:37 --> Output Class Initialized
INFO - 2018-04-19 17:11:37 --> Security Class Initialized
DEBUG - 2018-04-19 17:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:11:37 --> CSRF cookie sent
INFO - 2018-04-19 17:11:37 --> Input Class Initialized
INFO - 2018-04-19 17:11:37 --> Language Class Initialized
INFO - 2018-04-19 17:11:37 --> Loader Class Initialized
INFO - 2018-04-19 17:11:37 --> Helper loaded: url_helper
INFO - 2018-04-19 17:11:37 --> Helper loaded: form_helper
INFO - 2018-04-19 17:11:37 --> Helper loaded: language_helper
DEBUG - 2018-04-19 17:11:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 17:11:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 17:11:37 --> User Agent Class Initialized
INFO - 2018-04-19 17:11:37 --> Controller Class Initialized
INFO - 2018-04-19 17:11:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 17:11:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 17:11:37 --> Pixel_Model class loaded
INFO - 2018-04-19 17:11:37 --> Database Driver Class Initialized
INFO - 2018-04-19 17:11:37 --> Model "MyAccountModel" initialized
INFO - 2018-04-19 17:11:37 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 17:11:37 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-19 17:11:37 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 17:11:37 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-19 17:11:37 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-19 17:11:37 --> File loaded: E:\www\yacopoo\application\views\register/import_enduser.php
INFO - 2018-04-19 17:11:38 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 17:11:38 --> Final output sent to browser
DEBUG - 2018-04-19 17:11:38 --> Total execution time: 0.3574
INFO - 2018-04-19 17:11:38 --> Config Class Initialized
INFO - 2018-04-19 17:11:38 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:11:38 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:11:38 --> Utf8 Class Initialized
INFO - 2018-04-19 17:11:38 --> URI Class Initialized
INFO - 2018-04-19 17:11:38 --> Router Class Initialized
INFO - 2018-04-19 17:11:38 --> Output Class Initialized
INFO - 2018-04-19 17:11:38 --> Security Class Initialized
DEBUG - 2018-04-19 17:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:11:38 --> CSRF cookie sent
INFO - 2018-04-19 17:11:38 --> Input Class Initialized
INFO - 2018-04-19 17:11:38 --> Language Class Initialized
ERROR - 2018-04-19 17:11:38 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 17:11:56 --> Config Class Initialized
INFO - 2018-04-19 17:11:56 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:11:56 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:11:56 --> Utf8 Class Initialized
INFO - 2018-04-19 17:11:56 --> URI Class Initialized
INFO - 2018-04-19 17:11:56 --> Router Class Initialized
INFO - 2018-04-19 17:11:56 --> Output Class Initialized
INFO - 2018-04-19 17:11:56 --> Security Class Initialized
DEBUG - 2018-04-19 17:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:11:56 --> CSRF cookie sent
INFO - 2018-04-19 17:11:56 --> Input Class Initialized
INFO - 2018-04-19 17:11:56 --> Language Class Initialized
INFO - 2018-04-19 17:11:56 --> Loader Class Initialized
INFO - 2018-04-19 17:11:56 --> Helper loaded: url_helper
INFO - 2018-04-19 17:11:56 --> Helper loaded: form_helper
INFO - 2018-04-19 17:11:56 --> Helper loaded: language_helper
DEBUG - 2018-04-19 17:11:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 17:11:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 17:11:56 --> User Agent Class Initialized
INFO - 2018-04-19 17:11:56 --> Controller Class Initialized
INFO - 2018-04-19 17:11:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 17:11:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 17:11:56 --> Pixel_Model class loaded
INFO - 2018-04-19 17:11:56 --> Database Driver Class Initialized
INFO - 2018-04-19 17:11:56 --> Model "MyAccountModel" initialized
INFO - 2018-04-19 17:11:56 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 17:11:56 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-19 17:11:57 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 17:11:57 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-19 17:11:57 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-19 17:11:57 --> File loaded: E:\www\yacopoo\application\views\register/import_enduser.php
INFO - 2018-04-19 17:11:57 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 17:11:57 --> Final output sent to browser
DEBUG - 2018-04-19 17:11:57 --> Total execution time: 0.3480
INFO - 2018-04-19 17:11:57 --> Config Class Initialized
INFO - 2018-04-19 17:11:57 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:11:57 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:11:57 --> Utf8 Class Initialized
INFO - 2018-04-19 17:11:57 --> URI Class Initialized
INFO - 2018-04-19 17:11:57 --> Router Class Initialized
INFO - 2018-04-19 17:11:57 --> Output Class Initialized
INFO - 2018-04-19 17:11:57 --> Security Class Initialized
DEBUG - 2018-04-19 17:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:11:57 --> CSRF cookie sent
INFO - 2018-04-19 17:11:57 --> Input Class Initialized
INFO - 2018-04-19 17:11:57 --> Language Class Initialized
ERROR - 2018-04-19 17:11:57 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 17:13:31 --> Config Class Initialized
INFO - 2018-04-19 17:13:31 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:13:31 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:13:31 --> Utf8 Class Initialized
INFO - 2018-04-19 17:13:31 --> URI Class Initialized
INFO - 2018-04-19 17:13:31 --> Router Class Initialized
INFO - 2018-04-19 17:13:31 --> Output Class Initialized
INFO - 2018-04-19 17:13:31 --> Security Class Initialized
DEBUG - 2018-04-19 17:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:13:31 --> CSRF cookie sent
INFO - 2018-04-19 17:13:31 --> Input Class Initialized
INFO - 2018-04-19 17:13:31 --> Language Class Initialized
INFO - 2018-04-19 17:13:31 --> Loader Class Initialized
INFO - 2018-04-19 17:13:31 --> Helper loaded: url_helper
INFO - 2018-04-19 17:13:31 --> Helper loaded: form_helper
INFO - 2018-04-19 17:13:31 --> Helper loaded: language_helper
DEBUG - 2018-04-19 17:13:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 17:13:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 17:13:31 --> User Agent Class Initialized
INFO - 2018-04-19 17:13:31 --> Controller Class Initialized
INFO - 2018-04-19 17:13:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 17:13:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 17:13:31 --> Pixel_Model class loaded
INFO - 2018-04-19 17:13:31 --> Database Driver Class Initialized
INFO - 2018-04-19 17:13:31 --> Model "MyAccountModel" initialized
INFO - 2018-04-19 17:13:31 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 17:13:31 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-19 17:13:31 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 17:13:31 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-19 17:13:31 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-19 17:13:31 --> File loaded: E:\www\yacopoo\application\views\register/import_enduser.php
INFO - 2018-04-19 17:13:31 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 17:13:31 --> Final output sent to browser
DEBUG - 2018-04-19 17:13:31 --> Total execution time: 0.3363
INFO - 2018-04-19 17:13:32 --> Config Class Initialized
INFO - 2018-04-19 17:13:32 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:13:32 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:13:32 --> Utf8 Class Initialized
INFO - 2018-04-19 17:13:32 --> URI Class Initialized
INFO - 2018-04-19 17:13:32 --> Router Class Initialized
INFO - 2018-04-19 17:13:32 --> Output Class Initialized
INFO - 2018-04-19 17:13:32 --> Security Class Initialized
DEBUG - 2018-04-19 17:13:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:13:32 --> CSRF cookie sent
INFO - 2018-04-19 17:13:32 --> Input Class Initialized
INFO - 2018-04-19 17:13:32 --> Language Class Initialized
ERROR - 2018-04-19 17:13:32 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 17:13:34 --> Config Class Initialized
INFO - 2018-04-19 17:13:34 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:13:34 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:13:34 --> Utf8 Class Initialized
INFO - 2018-04-19 17:13:34 --> URI Class Initialized
INFO - 2018-04-19 17:13:34 --> Router Class Initialized
INFO - 2018-04-19 17:13:34 --> Output Class Initialized
INFO - 2018-04-19 17:13:34 --> Security Class Initialized
DEBUG - 2018-04-19 17:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:13:34 --> CSRF cookie sent
INFO - 2018-04-19 17:13:34 --> Input Class Initialized
INFO - 2018-04-19 17:13:34 --> Language Class Initialized
INFO - 2018-04-19 17:13:34 --> Loader Class Initialized
INFO - 2018-04-19 17:13:34 --> Helper loaded: url_helper
INFO - 2018-04-19 17:13:34 --> Helper loaded: form_helper
INFO - 2018-04-19 17:13:34 --> Helper loaded: language_helper
DEBUG - 2018-04-19 17:13:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 17:13:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 17:13:34 --> User Agent Class Initialized
INFO - 2018-04-19 17:13:34 --> Controller Class Initialized
INFO - 2018-04-19 17:13:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 17:13:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 17:13:34 --> Pixel_Model class loaded
INFO - 2018-04-19 17:13:34 --> Database Driver Class Initialized
INFO - 2018-04-19 17:13:34 --> Model "MyAccountModel" initialized
INFO - 2018-04-19 17:13:34 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 17:13:34 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-19 17:13:34 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 17:13:34 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-19 17:13:34 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-19 17:13:34 --> File loaded: E:\www\yacopoo\application\views\register/import_enduser.php
INFO - 2018-04-19 17:13:34 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 17:13:34 --> Final output sent to browser
DEBUG - 2018-04-19 17:13:34 --> Total execution time: 0.3419
INFO - 2018-04-19 17:13:35 --> Config Class Initialized
INFO - 2018-04-19 17:13:35 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:13:35 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:13:35 --> Utf8 Class Initialized
INFO - 2018-04-19 17:13:35 --> URI Class Initialized
INFO - 2018-04-19 17:13:35 --> Router Class Initialized
INFO - 2018-04-19 17:13:35 --> Output Class Initialized
INFO - 2018-04-19 17:13:35 --> Security Class Initialized
DEBUG - 2018-04-19 17:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:13:35 --> CSRF cookie sent
INFO - 2018-04-19 17:13:35 --> Input Class Initialized
INFO - 2018-04-19 17:13:35 --> Language Class Initialized
ERROR - 2018-04-19 17:13:35 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 17:14:42 --> Config Class Initialized
INFO - 2018-04-19 17:14:42 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:14:42 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:14:42 --> Utf8 Class Initialized
INFO - 2018-04-19 17:14:42 --> URI Class Initialized
INFO - 2018-04-19 17:14:42 --> Router Class Initialized
INFO - 2018-04-19 17:14:42 --> Output Class Initialized
INFO - 2018-04-19 17:14:42 --> Security Class Initialized
DEBUG - 2018-04-19 17:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:14:42 --> CSRF cookie sent
INFO - 2018-04-19 17:14:42 --> Input Class Initialized
INFO - 2018-04-19 17:14:42 --> Language Class Initialized
INFO - 2018-04-19 17:14:42 --> Loader Class Initialized
INFO - 2018-04-19 17:14:42 --> Helper loaded: url_helper
INFO - 2018-04-19 17:14:42 --> Helper loaded: form_helper
INFO - 2018-04-19 17:14:42 --> Helper loaded: language_helper
DEBUG - 2018-04-19 17:14:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 17:14:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 17:14:42 --> User Agent Class Initialized
INFO - 2018-04-19 17:14:42 --> Controller Class Initialized
INFO - 2018-04-19 17:14:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 17:14:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 17:14:42 --> Pixel_Model class loaded
INFO - 2018-04-19 17:14:42 --> Database Driver Class Initialized
INFO - 2018-04-19 17:14:42 --> Model "MyAccountModel" initialized
INFO - 2018-04-19 17:14:42 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 17:14:42 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-19 17:14:42 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 17:14:42 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-19 17:14:42 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-19 17:14:42 --> File loaded: E:\www\yacopoo\application\views\register/import_enduser.php
INFO - 2018-04-19 17:14:42 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 17:14:42 --> Final output sent to browser
DEBUG - 2018-04-19 17:14:42 --> Total execution time: 0.3427
INFO - 2018-04-19 17:14:43 --> Config Class Initialized
INFO - 2018-04-19 17:14:43 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:14:43 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:14:43 --> Utf8 Class Initialized
INFO - 2018-04-19 17:14:43 --> URI Class Initialized
INFO - 2018-04-19 17:14:43 --> Router Class Initialized
INFO - 2018-04-19 17:14:43 --> Output Class Initialized
INFO - 2018-04-19 17:14:43 --> Security Class Initialized
DEBUG - 2018-04-19 17:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:14:43 --> CSRF cookie sent
INFO - 2018-04-19 17:14:43 --> Input Class Initialized
INFO - 2018-04-19 17:14:43 --> Language Class Initialized
ERROR - 2018-04-19 17:14:43 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 17:18:09 --> Config Class Initialized
INFO - 2018-04-19 17:18:09 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:18:09 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:18:09 --> Utf8 Class Initialized
INFO - 2018-04-19 17:18:09 --> URI Class Initialized
INFO - 2018-04-19 17:18:09 --> Router Class Initialized
INFO - 2018-04-19 17:18:09 --> Output Class Initialized
INFO - 2018-04-19 17:18:09 --> Security Class Initialized
DEBUG - 2018-04-19 17:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:18:09 --> CSRF cookie sent
INFO - 2018-04-19 17:18:09 --> Input Class Initialized
INFO - 2018-04-19 17:18:09 --> Language Class Initialized
INFO - 2018-04-19 17:18:09 --> Loader Class Initialized
INFO - 2018-04-19 17:18:09 --> Helper loaded: url_helper
INFO - 2018-04-19 17:18:09 --> Helper loaded: form_helper
INFO - 2018-04-19 17:18:09 --> Helper loaded: language_helper
DEBUG - 2018-04-19 17:18:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 17:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 17:18:09 --> User Agent Class Initialized
INFO - 2018-04-19 17:18:09 --> Controller Class Initialized
INFO - 2018-04-19 17:18:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 17:18:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 17:18:09 --> Pixel_Model class loaded
INFO - 2018-04-19 17:18:09 --> Database Driver Class Initialized
INFO - 2018-04-19 17:18:09 --> Model "MyAccountModel" initialized
INFO - 2018-04-19 17:18:09 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 17:18:09 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-19 17:18:09 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 17:18:09 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-19 17:18:09 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-19 17:18:09 --> File loaded: E:\www\yacopoo\application\views\register/import_enduser.php
INFO - 2018-04-19 17:18:09 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 17:18:09 --> Final output sent to browser
DEBUG - 2018-04-19 17:18:09 --> Total execution time: 0.3528
INFO - 2018-04-19 17:18:09 --> Config Class Initialized
INFO - 2018-04-19 17:18:09 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:18:09 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:18:09 --> Utf8 Class Initialized
INFO - 2018-04-19 17:18:09 --> URI Class Initialized
INFO - 2018-04-19 17:18:09 --> Router Class Initialized
INFO - 2018-04-19 17:18:09 --> Output Class Initialized
INFO - 2018-04-19 17:18:10 --> Security Class Initialized
DEBUG - 2018-04-19 17:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:18:10 --> CSRF cookie sent
INFO - 2018-04-19 17:18:10 --> Input Class Initialized
INFO - 2018-04-19 17:18:10 --> Language Class Initialized
ERROR - 2018-04-19 17:18:10 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 17:18:22 --> Config Class Initialized
INFO - 2018-04-19 17:18:22 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:18:22 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:18:22 --> Utf8 Class Initialized
INFO - 2018-04-19 17:18:22 --> URI Class Initialized
INFO - 2018-04-19 17:18:22 --> Router Class Initialized
INFO - 2018-04-19 17:18:22 --> Output Class Initialized
INFO - 2018-04-19 17:18:22 --> Security Class Initialized
DEBUG - 2018-04-19 17:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:18:23 --> CSRF cookie sent
INFO - 2018-04-19 17:18:23 --> Input Class Initialized
INFO - 2018-04-19 17:18:23 --> Language Class Initialized
INFO - 2018-04-19 17:18:23 --> Loader Class Initialized
INFO - 2018-04-19 17:18:23 --> Helper loaded: url_helper
INFO - 2018-04-19 17:18:23 --> Helper loaded: form_helper
INFO - 2018-04-19 17:18:23 --> Helper loaded: language_helper
DEBUG - 2018-04-19 17:18:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 17:18:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 17:18:23 --> User Agent Class Initialized
INFO - 2018-04-19 17:18:23 --> Controller Class Initialized
INFO - 2018-04-19 17:18:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 17:18:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 17:18:23 --> Pixel_Model class loaded
INFO - 2018-04-19 17:18:23 --> Database Driver Class Initialized
INFO - 2018-04-19 17:18:23 --> Model "MyAccountModel" initialized
INFO - 2018-04-19 17:18:23 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 17:18:23 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-19 17:18:23 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 17:18:23 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-19 17:18:23 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-19 17:18:23 --> File loaded: E:\www\yacopoo\application\views\register/import_enduser.php
INFO - 2018-04-19 17:18:23 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 17:18:23 --> Final output sent to browser
DEBUG - 2018-04-19 17:18:23 --> Total execution time: 0.3593
INFO - 2018-04-19 17:18:23 --> Config Class Initialized
INFO - 2018-04-19 17:18:23 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:18:23 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:18:23 --> Utf8 Class Initialized
INFO - 2018-04-19 17:18:23 --> URI Class Initialized
INFO - 2018-04-19 17:18:23 --> Router Class Initialized
INFO - 2018-04-19 17:18:23 --> Output Class Initialized
INFO - 2018-04-19 17:18:23 --> Security Class Initialized
DEBUG - 2018-04-19 17:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:18:23 --> CSRF cookie sent
INFO - 2018-04-19 17:18:23 --> Input Class Initialized
INFO - 2018-04-19 17:18:23 --> Language Class Initialized
ERROR - 2018-04-19 17:18:23 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 17:19:35 --> Config Class Initialized
INFO - 2018-04-19 17:19:35 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:19:35 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:19:35 --> Utf8 Class Initialized
INFO - 2018-04-19 17:19:35 --> URI Class Initialized
INFO - 2018-04-19 17:19:35 --> Router Class Initialized
INFO - 2018-04-19 17:19:35 --> Output Class Initialized
INFO - 2018-04-19 17:19:35 --> Security Class Initialized
DEBUG - 2018-04-19 17:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:19:35 --> CSRF cookie sent
INFO - 2018-04-19 17:19:35 --> Input Class Initialized
INFO - 2018-04-19 17:19:35 --> Language Class Initialized
INFO - 2018-04-19 17:19:35 --> Loader Class Initialized
INFO - 2018-04-19 17:19:35 --> Helper loaded: url_helper
INFO - 2018-04-19 17:19:36 --> Helper loaded: form_helper
INFO - 2018-04-19 17:19:36 --> Helper loaded: language_helper
DEBUG - 2018-04-19 17:19:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 17:19:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 17:19:36 --> User Agent Class Initialized
INFO - 2018-04-19 17:19:36 --> Controller Class Initialized
INFO - 2018-04-19 17:19:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 17:19:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 17:19:36 --> Pixel_Model class loaded
INFO - 2018-04-19 17:19:36 --> Database Driver Class Initialized
INFO - 2018-04-19 17:19:36 --> Model "MyAccountModel" initialized
INFO - 2018-04-19 17:19:36 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 17:19:36 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-19 17:19:36 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 17:19:36 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-19 17:19:36 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-19 17:19:36 --> File loaded: E:\www\yacopoo\application\views\register/import_enduser.php
INFO - 2018-04-19 17:19:36 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 17:19:36 --> Final output sent to browser
DEBUG - 2018-04-19 17:19:36 --> Total execution time: 0.3508
INFO - 2018-04-19 17:19:59 --> Config Class Initialized
INFO - 2018-04-19 17:19:59 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:19:59 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:19:59 --> Utf8 Class Initialized
INFO - 2018-04-19 17:19:59 --> URI Class Initialized
INFO - 2018-04-19 17:19:59 --> Router Class Initialized
INFO - 2018-04-19 17:19:59 --> Output Class Initialized
INFO - 2018-04-19 17:19:59 --> Security Class Initialized
DEBUG - 2018-04-19 17:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:19:59 --> CSRF cookie sent
INFO - 2018-04-19 17:19:59 --> Input Class Initialized
INFO - 2018-04-19 17:19:59 --> Language Class Initialized
INFO - 2018-04-19 17:19:59 --> Loader Class Initialized
INFO - 2018-04-19 17:19:59 --> Helper loaded: url_helper
INFO - 2018-04-19 17:19:59 --> Helper loaded: form_helper
INFO - 2018-04-19 17:19:59 --> Helper loaded: language_helper
DEBUG - 2018-04-19 17:19:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 17:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 17:19:59 --> User Agent Class Initialized
INFO - 2018-04-19 17:19:59 --> Controller Class Initialized
INFO - 2018-04-19 17:19:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 17:19:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 17:19:59 --> Pixel_Model class loaded
INFO - 2018-04-19 17:19:59 --> Database Driver Class Initialized
INFO - 2018-04-19 17:19:59 --> Model "MyAccountModel" initialized
INFO - 2018-04-19 17:19:59 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 17:19:59 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-19 17:19:59 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 17:19:59 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-19 17:19:59 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-19 17:19:59 --> File loaded: E:\www\yacopoo\application\views\register/import_enduser.php
INFO - 2018-04-19 17:19:59 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 17:19:59 --> Final output sent to browser
DEBUG - 2018-04-19 17:19:59 --> Total execution time: 0.3520
INFO - 2018-04-19 17:20:18 --> Config Class Initialized
INFO - 2018-04-19 17:20:18 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:20:18 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:20:18 --> Utf8 Class Initialized
INFO - 2018-04-19 17:20:18 --> URI Class Initialized
INFO - 2018-04-19 17:20:18 --> Router Class Initialized
INFO - 2018-04-19 17:20:18 --> Output Class Initialized
INFO - 2018-04-19 17:20:18 --> Security Class Initialized
DEBUG - 2018-04-19 17:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:20:18 --> CSRF cookie sent
INFO - 2018-04-19 17:20:18 --> Input Class Initialized
INFO - 2018-04-19 17:20:18 --> Language Class Initialized
INFO - 2018-04-19 17:20:18 --> Loader Class Initialized
INFO - 2018-04-19 17:20:18 --> Helper loaded: url_helper
INFO - 2018-04-19 17:20:18 --> Helper loaded: form_helper
INFO - 2018-04-19 17:20:18 --> Helper loaded: language_helper
DEBUG - 2018-04-19 17:20:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 17:20:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 17:20:18 --> User Agent Class Initialized
INFO - 2018-04-19 17:20:18 --> Controller Class Initialized
INFO - 2018-04-19 17:20:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 17:20:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 17:20:18 --> Pixel_Model class loaded
INFO - 2018-04-19 17:20:18 --> Database Driver Class Initialized
INFO - 2018-04-19 17:20:18 --> Model "MyAccountModel" initialized
INFO - 2018-04-19 17:20:18 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 17:20:18 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-19 17:20:18 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 17:20:18 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-19 17:20:18 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-19 17:20:18 --> File loaded: E:\www\yacopoo\application\views\register/import_enduser.php
INFO - 2018-04-19 17:20:18 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 17:20:18 --> Final output sent to browser
DEBUG - 2018-04-19 17:20:18 --> Total execution time: 0.3354
INFO - 2018-04-19 17:20:49 --> Config Class Initialized
INFO - 2018-04-19 17:20:49 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:20:49 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:20:49 --> Utf8 Class Initialized
INFO - 2018-04-19 17:20:49 --> URI Class Initialized
INFO - 2018-04-19 17:20:49 --> Router Class Initialized
INFO - 2018-04-19 17:20:49 --> Output Class Initialized
INFO - 2018-04-19 17:20:49 --> Security Class Initialized
DEBUG - 2018-04-19 17:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:20:49 --> CSRF cookie sent
INFO - 2018-04-19 17:20:49 --> Input Class Initialized
INFO - 2018-04-19 17:20:49 --> Language Class Initialized
INFO - 2018-04-19 17:20:49 --> Loader Class Initialized
INFO - 2018-04-19 17:20:49 --> Helper loaded: url_helper
INFO - 2018-04-19 17:20:49 --> Helper loaded: form_helper
INFO - 2018-04-19 17:20:49 --> Helper loaded: language_helper
DEBUG - 2018-04-19 17:20:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 17:20:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 17:20:49 --> User Agent Class Initialized
INFO - 2018-04-19 17:20:49 --> Controller Class Initialized
INFO - 2018-04-19 17:20:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 17:20:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 17:20:49 --> Pixel_Model class loaded
INFO - 2018-04-19 17:20:49 --> Database Driver Class Initialized
INFO - 2018-04-19 17:20:49 --> Model "MyAccountModel" initialized
INFO - 2018-04-19 17:20:49 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 17:20:49 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-19 17:20:49 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 17:20:49 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-19 17:20:49 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-19 17:20:49 --> File loaded: E:\www\yacopoo\application\views\register/import_enduser.php
INFO - 2018-04-19 17:20:49 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 17:20:49 --> Final output sent to browser
DEBUG - 2018-04-19 17:20:49 --> Total execution time: 0.3410
INFO - 2018-04-19 17:21:00 --> Config Class Initialized
INFO - 2018-04-19 17:21:00 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:21:00 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:21:00 --> Utf8 Class Initialized
INFO - 2018-04-19 17:21:00 --> URI Class Initialized
INFO - 2018-04-19 17:21:00 --> Router Class Initialized
INFO - 2018-04-19 17:21:00 --> Output Class Initialized
INFO - 2018-04-19 17:21:00 --> Security Class Initialized
DEBUG - 2018-04-19 17:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:21:00 --> CSRF cookie sent
INFO - 2018-04-19 17:21:00 --> Input Class Initialized
INFO - 2018-04-19 17:21:00 --> Language Class Initialized
INFO - 2018-04-19 17:21:00 --> Loader Class Initialized
INFO - 2018-04-19 17:21:00 --> Helper loaded: url_helper
INFO - 2018-04-19 17:21:00 --> Helper loaded: form_helper
INFO - 2018-04-19 17:21:00 --> Helper loaded: language_helper
DEBUG - 2018-04-19 17:21:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 17:21:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 17:21:00 --> User Agent Class Initialized
INFO - 2018-04-19 17:21:00 --> Controller Class Initialized
INFO - 2018-04-19 17:21:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 17:21:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 17:21:00 --> Pixel_Model class loaded
INFO - 2018-04-19 17:21:00 --> Database Driver Class Initialized
INFO - 2018-04-19 17:21:00 --> Model "MyAccountModel" initialized
INFO - 2018-04-19 17:21:00 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 17:21:00 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-19 17:21:00 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 17:21:00 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-19 17:21:00 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-19 17:21:00 --> File loaded: E:\www\yacopoo\application\views\register/import_enduser.php
INFO - 2018-04-19 17:21:00 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 17:21:00 --> Final output sent to browser
DEBUG - 2018-04-19 17:21:00 --> Total execution time: 0.3395
INFO - 2018-04-19 17:22:10 --> Config Class Initialized
INFO - 2018-04-19 17:22:10 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:22:10 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:22:10 --> Utf8 Class Initialized
INFO - 2018-04-19 17:22:10 --> URI Class Initialized
INFO - 2018-04-19 17:22:10 --> Router Class Initialized
INFO - 2018-04-19 17:22:10 --> Output Class Initialized
INFO - 2018-04-19 17:22:10 --> Security Class Initialized
DEBUG - 2018-04-19 17:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:22:10 --> CSRF cookie sent
INFO - 2018-04-19 17:22:10 --> Input Class Initialized
INFO - 2018-04-19 17:22:10 --> Language Class Initialized
INFO - 2018-04-19 17:22:10 --> Loader Class Initialized
INFO - 2018-04-19 17:22:10 --> Helper loaded: url_helper
INFO - 2018-04-19 17:22:10 --> Helper loaded: form_helper
INFO - 2018-04-19 17:22:10 --> Helper loaded: language_helper
DEBUG - 2018-04-19 17:22:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 17:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 17:22:10 --> User Agent Class Initialized
INFO - 2018-04-19 17:22:10 --> Controller Class Initialized
INFO - 2018-04-19 17:22:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 17:22:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 17:22:10 --> Pixel_Model class loaded
INFO - 2018-04-19 17:22:10 --> Database Driver Class Initialized
INFO - 2018-04-19 17:22:10 --> Model "MyAccountModel" initialized
INFO - 2018-04-19 17:22:10 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 17:22:10 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-19 17:22:10 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 17:22:10 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-19 17:22:10 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-19 17:22:10 --> File loaded: E:\www\yacopoo\application\views\register/import_enduser.php
INFO - 2018-04-19 17:22:10 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 17:22:10 --> Final output sent to browser
DEBUG - 2018-04-19 17:22:10 --> Total execution time: 0.3396
INFO - 2018-04-19 17:22:23 --> Config Class Initialized
INFO - 2018-04-19 17:22:23 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:22:23 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:22:23 --> Utf8 Class Initialized
INFO - 2018-04-19 17:22:23 --> URI Class Initialized
INFO - 2018-04-19 17:22:23 --> Router Class Initialized
INFO - 2018-04-19 17:22:23 --> Output Class Initialized
INFO - 2018-04-19 17:22:23 --> Security Class Initialized
DEBUG - 2018-04-19 17:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:22:23 --> CSRF cookie sent
INFO - 2018-04-19 17:22:23 --> Input Class Initialized
INFO - 2018-04-19 17:22:23 --> Language Class Initialized
ERROR - 2018-04-19 17:22:23 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 17:23:28 --> Config Class Initialized
INFO - 2018-04-19 17:23:28 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:23:28 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:23:28 --> Utf8 Class Initialized
INFO - 2018-04-19 17:23:28 --> URI Class Initialized
INFO - 2018-04-19 17:23:28 --> Router Class Initialized
INFO - 2018-04-19 17:23:28 --> Output Class Initialized
INFO - 2018-04-19 17:23:28 --> Security Class Initialized
DEBUG - 2018-04-19 17:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:23:28 --> CSRF cookie sent
INFO - 2018-04-19 17:23:28 --> Input Class Initialized
INFO - 2018-04-19 17:23:28 --> Language Class Initialized
INFO - 2018-04-19 17:23:28 --> Loader Class Initialized
INFO - 2018-04-19 17:23:28 --> Helper loaded: url_helper
INFO - 2018-04-19 17:23:28 --> Helper loaded: form_helper
INFO - 2018-04-19 17:23:28 --> Helper loaded: language_helper
DEBUG - 2018-04-19 17:23:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 17:23:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 17:23:28 --> User Agent Class Initialized
INFO - 2018-04-19 17:23:28 --> Controller Class Initialized
INFO - 2018-04-19 17:23:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 17:23:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 17:23:28 --> Pixel_Model class loaded
INFO - 2018-04-19 17:23:28 --> Database Driver Class Initialized
INFO - 2018-04-19 17:23:28 --> Model "MyAccountModel" initialized
INFO - 2018-04-19 17:23:28 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 17:23:28 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-19 17:23:28 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 17:23:28 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-19 17:23:28 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-19 17:23:28 --> File loaded: E:\www\yacopoo\application\views\register/import_enduser.php
INFO - 2018-04-19 17:23:28 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 17:23:28 --> Final output sent to browser
DEBUG - 2018-04-19 17:23:28 --> Total execution time: 0.3439
INFO - 2018-04-19 17:23:29 --> Config Class Initialized
INFO - 2018-04-19 17:23:29 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:23:29 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:23:29 --> Utf8 Class Initialized
INFO - 2018-04-19 17:23:29 --> URI Class Initialized
INFO - 2018-04-19 17:23:29 --> Router Class Initialized
INFO - 2018-04-19 17:23:29 --> Output Class Initialized
INFO - 2018-04-19 17:23:29 --> Security Class Initialized
DEBUG - 2018-04-19 17:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:23:29 --> CSRF cookie sent
INFO - 2018-04-19 17:23:29 --> Input Class Initialized
INFO - 2018-04-19 17:23:29 --> Language Class Initialized
ERROR - 2018-04-19 17:23:29 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 17:23:59 --> Config Class Initialized
INFO - 2018-04-19 17:23:59 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:23:59 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:23:59 --> Utf8 Class Initialized
INFO - 2018-04-19 17:23:59 --> URI Class Initialized
INFO - 2018-04-19 17:23:59 --> Router Class Initialized
INFO - 2018-04-19 17:23:59 --> Output Class Initialized
INFO - 2018-04-19 17:23:59 --> Security Class Initialized
DEBUG - 2018-04-19 17:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:23:59 --> CSRF cookie sent
INFO - 2018-04-19 17:23:59 --> Input Class Initialized
INFO - 2018-04-19 17:23:59 --> Language Class Initialized
INFO - 2018-04-19 17:23:59 --> Loader Class Initialized
INFO - 2018-04-19 17:23:59 --> Helper loaded: url_helper
INFO - 2018-04-19 17:23:59 --> Helper loaded: form_helper
INFO - 2018-04-19 17:23:59 --> Helper loaded: language_helper
DEBUG - 2018-04-19 17:23:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 17:23:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 17:23:59 --> User Agent Class Initialized
INFO - 2018-04-19 17:23:59 --> Controller Class Initialized
INFO - 2018-04-19 17:23:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 17:24:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 17:24:00 --> Pixel_Model class loaded
INFO - 2018-04-19 17:24:00 --> Database Driver Class Initialized
INFO - 2018-04-19 17:24:00 --> Model "MyAccountModel" initialized
INFO - 2018-04-19 17:24:00 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 17:24:00 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-19 17:24:00 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 17:24:00 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-19 17:24:00 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-19 17:24:00 --> File loaded: E:\www\yacopoo\application\views\register/import_enduser.php
INFO - 2018-04-19 17:24:00 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 17:24:00 --> Final output sent to browser
DEBUG - 2018-04-19 17:24:00 --> Total execution time: 0.3627
INFO - 2018-04-19 17:24:00 --> Config Class Initialized
INFO - 2018-04-19 17:24:00 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:24:00 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:24:00 --> Utf8 Class Initialized
INFO - 2018-04-19 17:24:00 --> URI Class Initialized
INFO - 2018-04-19 17:24:00 --> Router Class Initialized
INFO - 2018-04-19 17:24:00 --> Output Class Initialized
INFO - 2018-04-19 17:24:00 --> Security Class Initialized
DEBUG - 2018-04-19 17:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:24:00 --> CSRF cookie sent
INFO - 2018-04-19 17:24:00 --> Input Class Initialized
INFO - 2018-04-19 17:24:00 --> Language Class Initialized
ERROR - 2018-04-19 17:24:00 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 17:24:29 --> Config Class Initialized
INFO - 2018-04-19 17:24:29 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:24:29 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:24:29 --> Utf8 Class Initialized
INFO - 2018-04-19 17:24:29 --> URI Class Initialized
INFO - 2018-04-19 17:24:29 --> Router Class Initialized
INFO - 2018-04-19 17:24:29 --> Output Class Initialized
INFO - 2018-04-19 17:24:29 --> Security Class Initialized
DEBUG - 2018-04-19 17:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:24:29 --> CSRF cookie sent
INFO - 2018-04-19 17:24:29 --> Input Class Initialized
INFO - 2018-04-19 17:24:29 --> Language Class Initialized
INFO - 2018-04-19 17:24:29 --> Loader Class Initialized
INFO - 2018-04-19 17:24:29 --> Helper loaded: url_helper
INFO - 2018-04-19 17:24:29 --> Helper loaded: form_helper
INFO - 2018-04-19 17:24:29 --> Helper loaded: language_helper
DEBUG - 2018-04-19 17:24:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 17:24:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 17:24:29 --> User Agent Class Initialized
INFO - 2018-04-19 17:24:29 --> Controller Class Initialized
INFO - 2018-04-19 17:24:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 17:24:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 17:24:29 --> Pixel_Model class loaded
INFO - 2018-04-19 17:24:29 --> Database Driver Class Initialized
INFO - 2018-04-19 17:24:29 --> Model "MyAccountModel" initialized
INFO - 2018-04-19 17:24:29 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 17:24:29 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-19 17:24:29 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 17:24:29 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-19 17:24:29 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-19 17:24:29 --> File loaded: E:\www\yacopoo\application\views\register/import_enduser.php
INFO - 2018-04-19 17:24:29 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 17:24:29 --> Final output sent to browser
DEBUG - 2018-04-19 17:24:29 --> Total execution time: 0.3636
INFO - 2018-04-19 17:24:29 --> Config Class Initialized
INFO - 2018-04-19 17:24:29 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:24:29 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:24:29 --> Utf8 Class Initialized
INFO - 2018-04-19 17:24:30 --> URI Class Initialized
INFO - 2018-04-19 17:24:30 --> Router Class Initialized
INFO - 2018-04-19 17:24:30 --> Output Class Initialized
INFO - 2018-04-19 17:24:30 --> Security Class Initialized
DEBUG - 2018-04-19 17:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:24:30 --> CSRF cookie sent
INFO - 2018-04-19 17:24:30 --> Input Class Initialized
INFO - 2018-04-19 17:24:30 --> Language Class Initialized
ERROR - 2018-04-19 17:24:30 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 17:25:05 --> Config Class Initialized
INFO - 2018-04-19 17:25:05 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:25:05 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:25:05 --> Utf8 Class Initialized
INFO - 2018-04-19 17:25:05 --> URI Class Initialized
INFO - 2018-04-19 17:25:05 --> Router Class Initialized
INFO - 2018-04-19 17:25:05 --> Output Class Initialized
INFO - 2018-04-19 17:25:05 --> Security Class Initialized
DEBUG - 2018-04-19 17:25:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:25:05 --> CSRF cookie sent
INFO - 2018-04-19 17:25:05 --> Input Class Initialized
INFO - 2018-04-19 17:25:05 --> Language Class Initialized
INFO - 2018-04-19 17:25:05 --> Loader Class Initialized
INFO - 2018-04-19 17:25:05 --> Helper loaded: url_helper
INFO - 2018-04-19 17:25:05 --> Helper loaded: form_helper
INFO - 2018-04-19 17:25:05 --> Helper loaded: language_helper
DEBUG - 2018-04-19 17:25:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 17:25:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 17:25:05 --> User Agent Class Initialized
INFO - 2018-04-19 17:25:05 --> Controller Class Initialized
INFO - 2018-04-19 17:25:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 17:25:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 17:25:05 --> Pixel_Model class loaded
INFO - 2018-04-19 17:25:05 --> Database Driver Class Initialized
INFO - 2018-04-19 17:25:05 --> Model "MyAccountModel" initialized
INFO - 2018-04-19 17:25:05 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 17:25:05 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-19 17:25:05 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 17:25:05 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-19 17:25:05 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-19 17:25:05 --> File loaded: E:\www\yacopoo\application\views\register/import_enduser.php
INFO - 2018-04-19 17:25:05 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 17:25:05 --> Final output sent to browser
DEBUG - 2018-04-19 17:25:05 --> Total execution time: 0.3583
INFO - 2018-04-19 17:25:05 --> Config Class Initialized
INFO - 2018-04-19 17:25:05 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:25:05 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:25:05 --> Utf8 Class Initialized
INFO - 2018-04-19 17:25:05 --> URI Class Initialized
INFO - 2018-04-19 17:25:05 --> Router Class Initialized
INFO - 2018-04-19 17:25:05 --> Output Class Initialized
INFO - 2018-04-19 17:25:05 --> Security Class Initialized
DEBUG - 2018-04-19 17:25:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:25:05 --> CSRF cookie sent
INFO - 2018-04-19 17:25:05 --> Input Class Initialized
INFO - 2018-04-19 17:25:05 --> Language Class Initialized
ERROR - 2018-04-19 17:25:05 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 17:25:23 --> Config Class Initialized
INFO - 2018-04-19 17:25:23 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:25:23 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:25:23 --> Utf8 Class Initialized
INFO - 2018-04-19 17:25:23 --> URI Class Initialized
INFO - 2018-04-19 17:25:23 --> Router Class Initialized
INFO - 2018-04-19 17:25:23 --> Output Class Initialized
INFO - 2018-04-19 17:25:23 --> Security Class Initialized
DEBUG - 2018-04-19 17:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:25:23 --> CSRF cookie sent
INFO - 2018-04-19 17:25:23 --> Input Class Initialized
INFO - 2018-04-19 17:25:23 --> Language Class Initialized
INFO - 2018-04-19 17:25:23 --> Loader Class Initialized
INFO - 2018-04-19 17:25:23 --> Helper loaded: url_helper
INFO - 2018-04-19 17:25:23 --> Helper loaded: form_helper
INFO - 2018-04-19 17:25:23 --> Helper loaded: language_helper
DEBUG - 2018-04-19 17:25:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 17:25:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 17:25:23 --> User Agent Class Initialized
INFO - 2018-04-19 17:25:23 --> Controller Class Initialized
INFO - 2018-04-19 17:25:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 17:25:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 17:25:23 --> Pixel_Model class loaded
INFO - 2018-04-19 17:25:23 --> Database Driver Class Initialized
INFO - 2018-04-19 17:25:23 --> Model "MyAccountModel" initialized
INFO - 2018-04-19 17:25:23 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 17:25:23 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-19 17:25:23 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 17:25:23 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-19 17:25:23 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-19 17:25:23 --> File loaded: E:\www\yacopoo\application\views\register/import_enduser.php
INFO - 2018-04-19 17:25:23 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 17:25:23 --> Final output sent to browser
DEBUG - 2018-04-19 17:25:23 --> Total execution time: 0.3664
INFO - 2018-04-19 17:25:24 --> Config Class Initialized
INFO - 2018-04-19 17:25:24 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:25:24 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:25:24 --> Utf8 Class Initialized
INFO - 2018-04-19 17:25:24 --> URI Class Initialized
INFO - 2018-04-19 17:25:24 --> Router Class Initialized
INFO - 2018-04-19 17:25:24 --> Output Class Initialized
INFO - 2018-04-19 17:25:24 --> Security Class Initialized
DEBUG - 2018-04-19 17:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:25:24 --> CSRF cookie sent
INFO - 2018-04-19 17:25:24 --> Input Class Initialized
INFO - 2018-04-19 17:25:24 --> Language Class Initialized
ERROR - 2018-04-19 17:25:24 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 17:27:26 --> Config Class Initialized
INFO - 2018-04-19 17:27:26 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:27:26 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:27:26 --> Utf8 Class Initialized
INFO - 2018-04-19 17:27:26 --> URI Class Initialized
INFO - 2018-04-19 17:27:26 --> Router Class Initialized
INFO - 2018-04-19 17:27:26 --> Output Class Initialized
INFO - 2018-04-19 17:27:26 --> Security Class Initialized
DEBUG - 2018-04-19 17:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:27:26 --> CSRF cookie sent
INFO - 2018-04-19 17:27:26 --> Input Class Initialized
INFO - 2018-04-19 17:27:26 --> Language Class Initialized
INFO - 2018-04-19 17:27:26 --> Loader Class Initialized
INFO - 2018-04-19 17:27:26 --> Helper loaded: url_helper
INFO - 2018-04-19 17:27:26 --> Helper loaded: form_helper
INFO - 2018-04-19 17:27:26 --> Helper loaded: language_helper
DEBUG - 2018-04-19 17:27:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 17:27:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 17:27:26 --> User Agent Class Initialized
INFO - 2018-04-19 17:27:26 --> Controller Class Initialized
INFO - 2018-04-19 17:27:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 17:27:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 17:27:26 --> Pixel_Model class loaded
INFO - 2018-04-19 17:27:26 --> Database Driver Class Initialized
INFO - 2018-04-19 17:27:26 --> Model "MyAccountModel" initialized
INFO - 2018-04-19 17:27:26 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 17:27:26 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-19 17:27:26 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 17:27:26 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-19 17:27:26 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-19 17:27:26 --> File loaded: E:\www\yacopoo\application\views\register/import_enduser.php
INFO - 2018-04-19 17:27:27 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 17:27:27 --> Final output sent to browser
DEBUG - 2018-04-19 17:27:27 --> Total execution time: 0.3646
INFO - 2018-04-19 17:27:27 --> Config Class Initialized
INFO - 2018-04-19 17:27:27 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:27:27 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:27:27 --> Utf8 Class Initialized
INFO - 2018-04-19 17:27:27 --> URI Class Initialized
INFO - 2018-04-19 17:27:27 --> Router Class Initialized
INFO - 2018-04-19 17:27:27 --> Output Class Initialized
INFO - 2018-04-19 17:27:27 --> Security Class Initialized
DEBUG - 2018-04-19 17:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:27:27 --> CSRF cookie sent
INFO - 2018-04-19 17:27:27 --> Input Class Initialized
INFO - 2018-04-19 17:27:27 --> Language Class Initialized
ERROR - 2018-04-19 17:27:27 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 17:27:54 --> Config Class Initialized
INFO - 2018-04-19 17:27:54 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:27:54 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:27:54 --> Utf8 Class Initialized
INFO - 2018-04-19 17:27:54 --> URI Class Initialized
INFO - 2018-04-19 17:27:54 --> Router Class Initialized
INFO - 2018-04-19 17:27:54 --> Output Class Initialized
INFO - 2018-04-19 17:27:54 --> Security Class Initialized
DEBUG - 2018-04-19 17:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:27:54 --> CSRF cookie sent
INFO - 2018-04-19 17:27:54 --> Input Class Initialized
INFO - 2018-04-19 17:27:54 --> Language Class Initialized
INFO - 2018-04-19 17:27:54 --> Loader Class Initialized
INFO - 2018-04-19 17:27:54 --> Helper loaded: url_helper
INFO - 2018-04-19 17:27:54 --> Helper loaded: form_helper
INFO - 2018-04-19 17:27:54 --> Helper loaded: language_helper
DEBUG - 2018-04-19 17:27:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 17:27:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 17:27:54 --> User Agent Class Initialized
INFO - 2018-04-19 17:27:54 --> Controller Class Initialized
INFO - 2018-04-19 17:27:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 17:27:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 17:27:55 --> Pixel_Model class loaded
INFO - 2018-04-19 17:27:55 --> Database Driver Class Initialized
INFO - 2018-04-19 17:27:55 --> Model "MyAccountModel" initialized
INFO - 2018-04-19 17:27:55 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 17:27:55 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-19 17:27:55 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 17:27:55 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-19 17:27:55 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-19 17:27:55 --> File loaded: E:\www\yacopoo\application\views\register/import_enduser.php
INFO - 2018-04-19 17:27:55 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 17:27:55 --> Final output sent to browser
DEBUG - 2018-04-19 17:27:55 --> Total execution time: 0.3697
INFO - 2018-04-19 17:27:55 --> Config Class Initialized
INFO - 2018-04-19 17:27:55 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:27:55 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:27:55 --> Utf8 Class Initialized
INFO - 2018-04-19 17:27:55 --> URI Class Initialized
INFO - 2018-04-19 17:27:55 --> Router Class Initialized
INFO - 2018-04-19 17:27:55 --> Output Class Initialized
INFO - 2018-04-19 17:27:55 --> Security Class Initialized
DEBUG - 2018-04-19 17:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:27:55 --> CSRF cookie sent
INFO - 2018-04-19 17:27:55 --> Input Class Initialized
INFO - 2018-04-19 17:27:55 --> Language Class Initialized
ERROR - 2018-04-19 17:27:55 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 17:30:56 --> Config Class Initialized
INFO - 2018-04-19 17:30:56 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:30:56 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:30:56 --> Utf8 Class Initialized
INFO - 2018-04-19 17:30:56 --> URI Class Initialized
INFO - 2018-04-19 17:30:56 --> Router Class Initialized
INFO - 2018-04-19 17:30:56 --> Output Class Initialized
INFO - 2018-04-19 17:30:56 --> Security Class Initialized
DEBUG - 2018-04-19 17:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:30:56 --> CSRF cookie sent
INFO - 2018-04-19 17:30:56 --> Input Class Initialized
INFO - 2018-04-19 17:30:56 --> Language Class Initialized
INFO - 2018-04-19 17:30:56 --> Loader Class Initialized
INFO - 2018-04-19 17:30:56 --> Helper loaded: url_helper
INFO - 2018-04-19 17:30:56 --> Helper loaded: form_helper
INFO - 2018-04-19 17:30:56 --> Helper loaded: language_helper
DEBUG - 2018-04-19 17:30:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 17:30:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 17:30:56 --> User Agent Class Initialized
INFO - 2018-04-19 17:30:56 --> Controller Class Initialized
INFO - 2018-04-19 17:30:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 17:30:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 17:30:57 --> Pixel_Model class loaded
INFO - 2018-04-19 17:30:57 --> Database Driver Class Initialized
INFO - 2018-04-19 17:30:57 --> Model "MyAccountModel" initialized
INFO - 2018-04-19 17:30:57 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 17:30:57 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-19 17:30:57 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 17:30:57 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-19 17:30:57 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-19 17:30:57 --> File loaded: E:\www\yacopoo\application\views\register/import_enduser.php
INFO - 2018-04-19 17:30:57 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 17:30:57 --> Final output sent to browser
DEBUG - 2018-04-19 17:30:57 --> Total execution time: 0.3915
INFO - 2018-04-19 17:30:57 --> Config Class Initialized
INFO - 2018-04-19 17:30:57 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:30:57 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:30:57 --> Utf8 Class Initialized
INFO - 2018-04-19 17:30:57 --> URI Class Initialized
INFO - 2018-04-19 17:30:57 --> Router Class Initialized
INFO - 2018-04-19 17:30:57 --> Output Class Initialized
INFO - 2018-04-19 17:30:57 --> Security Class Initialized
DEBUG - 2018-04-19 17:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:30:57 --> CSRF cookie sent
INFO - 2018-04-19 17:30:57 --> Input Class Initialized
INFO - 2018-04-19 17:30:57 --> Language Class Initialized
ERROR - 2018-04-19 17:30:57 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 17:31:30 --> Config Class Initialized
INFO - 2018-04-19 17:31:30 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:31:30 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:31:30 --> Utf8 Class Initialized
INFO - 2018-04-19 17:31:30 --> URI Class Initialized
INFO - 2018-04-19 17:31:30 --> Router Class Initialized
INFO - 2018-04-19 17:31:30 --> Output Class Initialized
INFO - 2018-04-19 17:31:30 --> Security Class Initialized
DEBUG - 2018-04-19 17:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:31:30 --> CSRF cookie sent
INFO - 2018-04-19 17:31:30 --> Input Class Initialized
INFO - 2018-04-19 17:31:30 --> Language Class Initialized
INFO - 2018-04-19 17:31:30 --> Loader Class Initialized
INFO - 2018-04-19 17:31:30 --> Helper loaded: url_helper
INFO - 2018-04-19 17:31:30 --> Helper loaded: form_helper
INFO - 2018-04-19 17:31:30 --> Helper loaded: language_helper
DEBUG - 2018-04-19 17:31:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 17:31:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 17:31:30 --> User Agent Class Initialized
INFO - 2018-04-19 17:31:30 --> Controller Class Initialized
INFO - 2018-04-19 17:31:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 17:31:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 17:31:30 --> Pixel_Model class loaded
INFO - 2018-04-19 17:31:30 --> Database Driver Class Initialized
INFO - 2018-04-19 17:31:30 --> Model "MyAccountModel" initialized
INFO - 2018-04-19 17:31:30 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 17:31:30 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-19 17:31:30 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 17:31:30 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-19 17:31:30 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-19 17:31:30 --> File loaded: E:\www\yacopoo\application\views\register/import_enduser.php
INFO - 2018-04-19 17:31:30 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 17:31:30 --> Final output sent to browser
DEBUG - 2018-04-19 17:31:30 --> Total execution time: 0.3741
INFO - 2018-04-19 17:31:30 --> Config Class Initialized
INFO - 2018-04-19 17:31:30 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:31:30 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:31:30 --> Utf8 Class Initialized
INFO - 2018-04-19 17:31:30 --> URI Class Initialized
INFO - 2018-04-19 17:31:30 --> Router Class Initialized
INFO - 2018-04-19 17:31:30 --> Output Class Initialized
INFO - 2018-04-19 17:31:30 --> Security Class Initialized
DEBUG - 2018-04-19 17:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:31:31 --> CSRF cookie sent
INFO - 2018-04-19 17:31:31 --> Input Class Initialized
INFO - 2018-04-19 17:31:31 --> Language Class Initialized
ERROR - 2018-04-19 17:31:31 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 17:31:45 --> Config Class Initialized
INFO - 2018-04-19 17:31:45 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:31:45 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:31:45 --> Utf8 Class Initialized
INFO - 2018-04-19 17:31:45 --> URI Class Initialized
INFO - 2018-04-19 17:31:45 --> Router Class Initialized
INFO - 2018-04-19 17:31:45 --> Output Class Initialized
INFO - 2018-04-19 17:31:45 --> Security Class Initialized
DEBUG - 2018-04-19 17:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:31:45 --> CSRF cookie sent
INFO - 2018-04-19 17:31:45 --> Input Class Initialized
INFO - 2018-04-19 17:31:45 --> Language Class Initialized
INFO - 2018-04-19 17:31:45 --> Loader Class Initialized
INFO - 2018-04-19 17:31:45 --> Helper loaded: url_helper
INFO - 2018-04-19 17:31:45 --> Helper loaded: form_helper
INFO - 2018-04-19 17:31:45 --> Helper loaded: language_helper
DEBUG - 2018-04-19 17:31:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 17:31:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 17:31:45 --> User Agent Class Initialized
INFO - 2018-04-19 17:31:45 --> Controller Class Initialized
INFO - 2018-04-19 17:31:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 17:31:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 17:31:45 --> Pixel_Model class loaded
INFO - 2018-04-19 17:31:45 --> Database Driver Class Initialized
INFO - 2018-04-19 17:31:45 --> Model "MyAccountModel" initialized
INFO - 2018-04-19 17:31:45 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 17:31:45 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-19 17:31:45 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 17:31:45 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-19 17:31:45 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-19 17:31:45 --> File loaded: E:\www\yacopoo\application\views\register/import_enduser.php
INFO - 2018-04-19 17:31:45 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 17:31:45 --> Final output sent to browser
DEBUG - 2018-04-19 17:31:45 --> Total execution time: 0.3908
INFO - 2018-04-19 17:31:45 --> Config Class Initialized
INFO - 2018-04-19 17:31:45 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:31:45 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:31:45 --> Utf8 Class Initialized
INFO - 2018-04-19 17:31:45 --> URI Class Initialized
INFO - 2018-04-19 17:31:45 --> Router Class Initialized
INFO - 2018-04-19 17:31:46 --> Output Class Initialized
INFO - 2018-04-19 17:31:46 --> Security Class Initialized
DEBUG - 2018-04-19 17:31:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:31:46 --> CSRF cookie sent
INFO - 2018-04-19 17:31:46 --> Input Class Initialized
INFO - 2018-04-19 17:31:46 --> Language Class Initialized
ERROR - 2018-04-19 17:31:46 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 17:32:15 --> Config Class Initialized
INFO - 2018-04-19 17:32:15 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:32:15 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:32:15 --> Utf8 Class Initialized
INFO - 2018-04-19 17:32:15 --> URI Class Initialized
INFO - 2018-04-19 17:32:15 --> Router Class Initialized
INFO - 2018-04-19 17:32:15 --> Output Class Initialized
INFO - 2018-04-19 17:32:15 --> Security Class Initialized
DEBUG - 2018-04-19 17:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:32:15 --> CSRF cookie sent
INFO - 2018-04-19 17:32:15 --> Input Class Initialized
INFO - 2018-04-19 17:32:15 --> Language Class Initialized
INFO - 2018-04-19 17:32:15 --> Loader Class Initialized
INFO - 2018-04-19 17:32:15 --> Helper loaded: url_helper
INFO - 2018-04-19 17:32:15 --> Helper loaded: form_helper
INFO - 2018-04-19 17:32:15 --> Helper loaded: language_helper
DEBUG - 2018-04-19 17:32:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 17:32:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 17:32:15 --> User Agent Class Initialized
INFO - 2018-04-19 17:32:15 --> Controller Class Initialized
INFO - 2018-04-19 17:32:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 17:32:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 17:32:15 --> Pixel_Model class loaded
INFO - 2018-04-19 17:32:15 --> Database Driver Class Initialized
INFO - 2018-04-19 17:32:15 --> Model "MyAccountModel" initialized
INFO - 2018-04-19 17:32:15 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 17:32:15 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-19 17:32:15 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 17:32:15 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-19 17:32:15 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-19 17:32:15 --> File loaded: E:\www\yacopoo\application\views\register/import_enduser.php
INFO - 2018-04-19 17:32:15 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 17:32:15 --> Final output sent to browser
DEBUG - 2018-04-19 17:32:15 --> Total execution time: 0.3768
INFO - 2018-04-19 17:32:16 --> Config Class Initialized
INFO - 2018-04-19 17:32:16 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:32:16 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:32:16 --> Utf8 Class Initialized
INFO - 2018-04-19 17:32:16 --> URI Class Initialized
INFO - 2018-04-19 17:32:16 --> Router Class Initialized
INFO - 2018-04-19 17:32:16 --> Output Class Initialized
INFO - 2018-04-19 17:32:16 --> Security Class Initialized
DEBUG - 2018-04-19 17:32:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:32:16 --> CSRF cookie sent
INFO - 2018-04-19 17:32:16 --> Input Class Initialized
INFO - 2018-04-19 17:32:16 --> Language Class Initialized
ERROR - 2018-04-19 17:32:16 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 17:32:50 --> Config Class Initialized
INFO - 2018-04-19 17:32:50 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:32:50 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:32:50 --> Utf8 Class Initialized
INFO - 2018-04-19 17:32:50 --> URI Class Initialized
INFO - 2018-04-19 17:32:50 --> Router Class Initialized
INFO - 2018-04-19 17:32:50 --> Output Class Initialized
INFO - 2018-04-19 17:32:50 --> Security Class Initialized
DEBUG - 2018-04-19 17:32:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:32:50 --> CSRF cookie sent
INFO - 2018-04-19 17:32:50 --> Input Class Initialized
INFO - 2018-04-19 17:32:50 --> Language Class Initialized
INFO - 2018-04-19 17:32:50 --> Loader Class Initialized
INFO - 2018-04-19 17:32:50 --> Helper loaded: url_helper
INFO - 2018-04-19 17:32:50 --> Helper loaded: form_helper
INFO - 2018-04-19 17:32:50 --> Helper loaded: language_helper
DEBUG - 2018-04-19 17:32:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 17:32:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 17:32:50 --> User Agent Class Initialized
INFO - 2018-04-19 17:32:50 --> Controller Class Initialized
INFO - 2018-04-19 17:32:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 17:32:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 17:32:50 --> Pixel_Model class loaded
INFO - 2018-04-19 17:32:50 --> Database Driver Class Initialized
INFO - 2018-04-19 17:32:50 --> Model "MyAccountModel" initialized
INFO - 2018-04-19 17:32:50 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 17:32:50 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-19 17:32:50 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 17:32:50 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-19 17:32:50 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-19 17:32:50 --> File loaded: E:\www\yacopoo\application\views\register/import_enduser.php
INFO - 2018-04-19 17:32:50 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 17:32:50 --> Final output sent to browser
DEBUG - 2018-04-19 17:32:50 --> Total execution time: 0.3723
INFO - 2018-04-19 17:32:51 --> Config Class Initialized
INFO - 2018-04-19 17:32:51 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:32:51 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:32:51 --> Utf8 Class Initialized
INFO - 2018-04-19 17:32:51 --> URI Class Initialized
INFO - 2018-04-19 17:32:51 --> Router Class Initialized
INFO - 2018-04-19 17:32:51 --> Output Class Initialized
INFO - 2018-04-19 17:32:51 --> Security Class Initialized
DEBUG - 2018-04-19 17:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:32:51 --> CSRF cookie sent
INFO - 2018-04-19 17:32:51 --> Input Class Initialized
INFO - 2018-04-19 17:32:51 --> Language Class Initialized
ERROR - 2018-04-19 17:32:51 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 17:33:08 --> Config Class Initialized
INFO - 2018-04-19 17:33:08 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:33:08 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:33:08 --> Utf8 Class Initialized
INFO - 2018-04-19 17:33:08 --> URI Class Initialized
INFO - 2018-04-19 17:33:08 --> Router Class Initialized
INFO - 2018-04-19 17:33:08 --> Output Class Initialized
INFO - 2018-04-19 17:33:08 --> Security Class Initialized
DEBUG - 2018-04-19 17:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:33:08 --> CSRF cookie sent
INFO - 2018-04-19 17:33:08 --> Input Class Initialized
INFO - 2018-04-19 17:33:08 --> Language Class Initialized
INFO - 2018-04-19 17:33:08 --> Loader Class Initialized
INFO - 2018-04-19 17:33:08 --> Helper loaded: url_helper
INFO - 2018-04-19 17:33:08 --> Helper loaded: form_helper
INFO - 2018-04-19 17:33:08 --> Helper loaded: language_helper
DEBUG - 2018-04-19 17:33:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 17:33:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 17:33:09 --> User Agent Class Initialized
INFO - 2018-04-19 17:33:09 --> Controller Class Initialized
INFO - 2018-04-19 17:33:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 17:33:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 17:33:09 --> Pixel_Model class loaded
INFO - 2018-04-19 17:33:09 --> Database Driver Class Initialized
INFO - 2018-04-19 17:33:09 --> Model "MyAccountModel" initialized
INFO - 2018-04-19 17:33:09 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 17:33:09 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-19 17:33:09 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 17:33:09 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-19 17:33:09 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-19 17:33:09 --> File loaded: E:\www\yacopoo\application\views\register/import_enduser.php
INFO - 2018-04-19 17:33:09 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 17:33:09 --> Final output sent to browser
DEBUG - 2018-04-19 17:33:09 --> Total execution time: 0.4048
INFO - 2018-04-19 17:33:09 --> Config Class Initialized
INFO - 2018-04-19 17:33:09 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:33:09 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:33:09 --> Utf8 Class Initialized
INFO - 2018-04-19 17:33:09 --> URI Class Initialized
INFO - 2018-04-19 17:33:09 --> Router Class Initialized
INFO - 2018-04-19 17:33:09 --> Output Class Initialized
INFO - 2018-04-19 17:33:09 --> Security Class Initialized
DEBUG - 2018-04-19 17:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:33:09 --> CSRF cookie sent
INFO - 2018-04-19 17:33:09 --> Input Class Initialized
INFO - 2018-04-19 17:33:09 --> Language Class Initialized
ERROR - 2018-04-19 17:33:09 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 17:33:34 --> Config Class Initialized
INFO - 2018-04-19 17:33:34 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:33:34 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:33:34 --> Utf8 Class Initialized
INFO - 2018-04-19 17:33:34 --> URI Class Initialized
INFO - 2018-04-19 17:33:34 --> Router Class Initialized
INFO - 2018-04-19 17:33:34 --> Output Class Initialized
INFO - 2018-04-19 17:33:34 --> Security Class Initialized
DEBUG - 2018-04-19 17:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:33:34 --> CSRF cookie sent
INFO - 2018-04-19 17:33:34 --> Input Class Initialized
INFO - 2018-04-19 17:33:34 --> Language Class Initialized
INFO - 2018-04-19 17:33:34 --> Loader Class Initialized
INFO - 2018-04-19 17:33:34 --> Helper loaded: url_helper
INFO - 2018-04-19 17:33:34 --> Helper loaded: form_helper
INFO - 2018-04-19 17:33:34 --> Helper loaded: language_helper
DEBUG - 2018-04-19 17:33:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 17:33:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 17:33:34 --> User Agent Class Initialized
INFO - 2018-04-19 17:33:34 --> Controller Class Initialized
INFO - 2018-04-19 17:33:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 17:33:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 17:33:34 --> Pixel_Model class loaded
INFO - 2018-04-19 17:33:34 --> Database Driver Class Initialized
INFO - 2018-04-19 17:33:34 --> Model "MyAccountModel" initialized
INFO - 2018-04-19 17:33:34 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 17:33:34 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-19 17:33:34 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 17:33:34 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-19 17:33:34 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-19 17:33:34 --> File loaded: E:\www\yacopoo\application\views\register/import_enduser.php
INFO - 2018-04-19 17:33:34 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 17:33:34 --> Final output sent to browser
DEBUG - 2018-04-19 17:33:34 --> Total execution time: 0.3740
INFO - 2018-04-19 17:33:34 --> Config Class Initialized
INFO - 2018-04-19 17:33:34 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:33:34 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:33:34 --> Utf8 Class Initialized
INFO - 2018-04-19 17:33:34 --> URI Class Initialized
INFO - 2018-04-19 17:33:34 --> Router Class Initialized
INFO - 2018-04-19 17:33:34 --> Output Class Initialized
INFO - 2018-04-19 17:33:34 --> Security Class Initialized
DEBUG - 2018-04-19 17:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:33:35 --> CSRF cookie sent
INFO - 2018-04-19 17:33:35 --> Input Class Initialized
INFO - 2018-04-19 17:33:35 --> Language Class Initialized
ERROR - 2018-04-19 17:33:35 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 17:33:41 --> Config Class Initialized
INFO - 2018-04-19 17:33:41 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:33:41 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:33:41 --> Utf8 Class Initialized
INFO - 2018-04-19 17:33:41 --> URI Class Initialized
INFO - 2018-04-19 17:33:41 --> Router Class Initialized
INFO - 2018-04-19 17:33:41 --> Output Class Initialized
INFO - 2018-04-19 17:33:41 --> Security Class Initialized
DEBUG - 2018-04-19 17:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:33:41 --> CSRF cookie sent
INFO - 2018-04-19 17:33:41 --> Input Class Initialized
INFO - 2018-04-19 17:33:41 --> Language Class Initialized
INFO - 2018-04-19 17:33:41 --> Loader Class Initialized
INFO - 2018-04-19 17:33:41 --> Helper loaded: url_helper
INFO - 2018-04-19 17:33:41 --> Helper loaded: form_helper
INFO - 2018-04-19 17:33:41 --> Helper loaded: language_helper
DEBUG - 2018-04-19 17:33:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 17:33:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 17:33:42 --> User Agent Class Initialized
INFO - 2018-04-19 17:33:42 --> Controller Class Initialized
INFO - 2018-04-19 17:33:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 17:33:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 17:33:42 --> Pixel_Model class loaded
INFO - 2018-04-19 17:33:42 --> Database Driver Class Initialized
INFO - 2018-04-19 17:33:42 --> Model "MyAccountModel" initialized
INFO - 2018-04-19 17:33:42 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 17:33:42 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-19 17:33:42 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 17:33:42 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-19 17:33:42 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-19 17:33:42 --> File loaded: E:\www\yacopoo\application\views\register/import_enduser.php
INFO - 2018-04-19 17:33:42 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 17:33:42 --> Final output sent to browser
DEBUG - 2018-04-19 17:33:42 --> Total execution time: 0.3780
INFO - 2018-04-19 17:33:42 --> Config Class Initialized
INFO - 2018-04-19 17:33:42 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:33:42 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:33:42 --> Utf8 Class Initialized
INFO - 2018-04-19 17:33:42 --> URI Class Initialized
INFO - 2018-04-19 17:33:42 --> Router Class Initialized
INFO - 2018-04-19 17:33:42 --> Output Class Initialized
INFO - 2018-04-19 17:33:42 --> Security Class Initialized
DEBUG - 2018-04-19 17:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:33:42 --> CSRF cookie sent
INFO - 2018-04-19 17:33:42 --> Input Class Initialized
INFO - 2018-04-19 17:33:42 --> Language Class Initialized
ERROR - 2018-04-19 17:33:42 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 17:33:48 --> Config Class Initialized
INFO - 2018-04-19 17:33:48 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:33:48 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:33:48 --> Utf8 Class Initialized
INFO - 2018-04-19 17:33:48 --> URI Class Initialized
INFO - 2018-04-19 17:33:48 --> Router Class Initialized
INFO - 2018-04-19 17:33:48 --> Output Class Initialized
INFO - 2018-04-19 17:33:48 --> Security Class Initialized
DEBUG - 2018-04-19 17:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:33:48 --> CSRF cookie sent
INFO - 2018-04-19 17:33:48 --> Input Class Initialized
INFO - 2018-04-19 17:33:48 --> Language Class Initialized
INFO - 2018-04-19 17:33:48 --> Loader Class Initialized
INFO - 2018-04-19 17:33:48 --> Helper loaded: url_helper
INFO - 2018-04-19 17:33:48 --> Helper loaded: form_helper
INFO - 2018-04-19 17:33:48 --> Helper loaded: language_helper
DEBUG - 2018-04-19 17:33:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 17:33:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 17:33:49 --> User Agent Class Initialized
INFO - 2018-04-19 17:33:49 --> Controller Class Initialized
INFO - 2018-04-19 17:33:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 17:33:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 17:33:49 --> Pixel_Model class loaded
INFO - 2018-04-19 17:33:49 --> Database Driver Class Initialized
INFO - 2018-04-19 17:33:49 --> Model "MyAccountModel" initialized
INFO - 2018-04-19 17:33:49 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 17:33:49 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-19 17:33:49 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 17:33:49 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-19 17:33:49 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-19 17:33:49 --> File loaded: E:\www\yacopoo\application\views\register/import_enduser.php
INFO - 2018-04-19 17:33:49 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 17:33:49 --> Final output sent to browser
DEBUG - 2018-04-19 17:33:49 --> Total execution time: 0.3832
INFO - 2018-04-19 17:33:49 --> Config Class Initialized
INFO - 2018-04-19 17:33:49 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:33:49 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:33:49 --> Utf8 Class Initialized
INFO - 2018-04-19 17:33:49 --> URI Class Initialized
INFO - 2018-04-19 17:33:49 --> Router Class Initialized
INFO - 2018-04-19 17:33:49 --> Output Class Initialized
INFO - 2018-04-19 17:33:49 --> Security Class Initialized
DEBUG - 2018-04-19 17:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:33:49 --> CSRF cookie sent
INFO - 2018-04-19 17:33:49 --> Input Class Initialized
INFO - 2018-04-19 17:33:49 --> Language Class Initialized
ERROR - 2018-04-19 17:33:49 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 17:34:50 --> Config Class Initialized
INFO - 2018-04-19 17:34:51 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:34:51 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:34:51 --> Utf8 Class Initialized
INFO - 2018-04-19 17:34:51 --> URI Class Initialized
INFO - 2018-04-19 17:34:51 --> Router Class Initialized
INFO - 2018-04-19 17:34:51 --> Output Class Initialized
INFO - 2018-04-19 17:34:51 --> Security Class Initialized
DEBUG - 2018-04-19 17:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:34:51 --> CSRF cookie sent
INFO - 2018-04-19 17:34:51 --> Input Class Initialized
INFO - 2018-04-19 17:34:51 --> Language Class Initialized
INFO - 2018-04-19 17:34:51 --> Loader Class Initialized
INFO - 2018-04-19 17:34:51 --> Helper loaded: url_helper
INFO - 2018-04-19 17:34:51 --> Helper loaded: form_helper
INFO - 2018-04-19 17:34:51 --> Helper loaded: language_helper
DEBUG - 2018-04-19 17:34:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 17:34:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 17:34:51 --> User Agent Class Initialized
INFO - 2018-04-19 17:34:51 --> Controller Class Initialized
INFO - 2018-04-19 17:34:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 17:34:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 17:34:51 --> Pixel_Model class loaded
INFO - 2018-04-19 17:34:51 --> Database Driver Class Initialized
INFO - 2018-04-19 17:34:51 --> Model "MyAccountModel" initialized
INFO - 2018-04-19 17:34:51 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 17:34:51 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-19 17:34:51 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 17:34:51 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-19 17:34:51 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-19 17:34:51 --> File loaded: E:\www\yacopoo\application\views\register/import_enduser.php
INFO - 2018-04-19 17:34:51 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 17:34:51 --> Final output sent to browser
DEBUG - 2018-04-19 17:34:51 --> Total execution time: 0.3718
INFO - 2018-04-19 17:34:51 --> Config Class Initialized
INFO - 2018-04-19 17:34:51 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:34:51 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:34:51 --> Utf8 Class Initialized
INFO - 2018-04-19 17:34:51 --> URI Class Initialized
INFO - 2018-04-19 17:34:51 --> Router Class Initialized
INFO - 2018-04-19 17:34:51 --> Output Class Initialized
INFO - 2018-04-19 17:34:51 --> Security Class Initialized
DEBUG - 2018-04-19 17:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:34:51 --> CSRF cookie sent
INFO - 2018-04-19 17:34:51 --> Input Class Initialized
INFO - 2018-04-19 17:34:51 --> Language Class Initialized
ERROR - 2018-04-19 17:34:51 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 17:38:05 --> Config Class Initialized
INFO - 2018-04-19 17:38:05 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:38:05 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:38:05 --> Utf8 Class Initialized
INFO - 2018-04-19 17:38:05 --> URI Class Initialized
INFO - 2018-04-19 17:38:05 --> Router Class Initialized
INFO - 2018-04-19 17:38:05 --> Output Class Initialized
INFO - 2018-04-19 17:38:05 --> Security Class Initialized
DEBUG - 2018-04-19 17:38:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:38:05 --> CSRF cookie sent
INFO - 2018-04-19 17:38:05 --> Input Class Initialized
INFO - 2018-04-19 17:38:05 --> Language Class Initialized
INFO - 2018-04-19 17:38:05 --> Loader Class Initialized
INFO - 2018-04-19 17:38:05 --> Helper loaded: url_helper
INFO - 2018-04-19 17:38:05 --> Helper loaded: form_helper
INFO - 2018-04-19 17:38:05 --> Helper loaded: language_helper
DEBUG - 2018-04-19 17:38:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 17:38:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 17:38:05 --> User Agent Class Initialized
INFO - 2018-04-19 17:38:05 --> Controller Class Initialized
INFO - 2018-04-19 17:38:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 17:38:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 17:38:05 --> Pixel_Model class loaded
INFO - 2018-04-19 17:38:05 --> Database Driver Class Initialized
INFO - 2018-04-19 17:38:05 --> Model "MyAccountModel" initialized
INFO - 2018-04-19 17:38:05 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 17:38:05 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-19 17:38:05 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 17:38:05 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-19 17:38:05 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-19 17:38:05 --> File loaded: E:\www\yacopoo\application\views\register/import_enduser.php
INFO - 2018-04-19 17:38:05 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 17:38:05 --> Final output sent to browser
DEBUG - 2018-04-19 17:38:05 --> Total execution time: 0.3826
INFO - 2018-04-19 17:38:06 --> Config Class Initialized
INFO - 2018-04-19 17:38:06 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:38:06 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:38:06 --> Utf8 Class Initialized
INFO - 2018-04-19 17:38:06 --> URI Class Initialized
INFO - 2018-04-19 17:38:06 --> Router Class Initialized
INFO - 2018-04-19 17:38:06 --> Output Class Initialized
INFO - 2018-04-19 17:38:06 --> Security Class Initialized
DEBUG - 2018-04-19 17:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:38:06 --> CSRF cookie sent
INFO - 2018-04-19 17:38:06 --> Input Class Initialized
INFO - 2018-04-19 17:38:06 --> Language Class Initialized
ERROR - 2018-04-19 17:38:06 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 17:38:45 --> Config Class Initialized
INFO - 2018-04-19 17:38:45 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:38:45 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:38:45 --> Utf8 Class Initialized
INFO - 2018-04-19 17:38:45 --> URI Class Initialized
INFO - 2018-04-19 17:38:45 --> Router Class Initialized
INFO - 2018-04-19 17:38:45 --> Output Class Initialized
INFO - 2018-04-19 17:38:45 --> Security Class Initialized
DEBUG - 2018-04-19 17:38:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:38:45 --> CSRF cookie sent
INFO - 2018-04-19 17:38:45 --> Input Class Initialized
INFO - 2018-04-19 17:38:45 --> Language Class Initialized
INFO - 2018-04-19 17:38:45 --> Loader Class Initialized
INFO - 2018-04-19 17:38:45 --> Helper loaded: url_helper
INFO - 2018-04-19 17:38:45 --> Helper loaded: form_helper
INFO - 2018-04-19 17:38:45 --> Helper loaded: language_helper
DEBUG - 2018-04-19 17:38:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 17:38:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 17:38:45 --> User Agent Class Initialized
INFO - 2018-04-19 17:38:45 --> Controller Class Initialized
INFO - 2018-04-19 17:38:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 17:38:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 17:38:45 --> Pixel_Model class loaded
INFO - 2018-04-19 17:38:45 --> Database Driver Class Initialized
INFO - 2018-04-19 17:38:45 --> Model "MyAccountModel" initialized
INFO - 2018-04-19 17:38:45 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 17:38:45 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-19 17:38:45 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 17:38:45 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-19 17:38:45 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-19 17:38:45 --> File loaded: E:\www\yacopoo\application\views\register/import_enduser.php
INFO - 2018-04-19 17:38:45 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 17:38:45 --> Final output sent to browser
DEBUG - 2018-04-19 17:38:45 --> Total execution time: 0.3888
INFO - 2018-04-19 17:38:45 --> Config Class Initialized
INFO - 2018-04-19 17:38:45 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:38:45 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:38:45 --> Utf8 Class Initialized
INFO - 2018-04-19 17:38:45 --> URI Class Initialized
INFO - 2018-04-19 17:38:45 --> Router Class Initialized
INFO - 2018-04-19 17:38:45 --> Output Class Initialized
INFO - 2018-04-19 17:38:45 --> Security Class Initialized
DEBUG - 2018-04-19 17:38:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:38:45 --> CSRF cookie sent
INFO - 2018-04-19 17:38:45 --> Input Class Initialized
INFO - 2018-04-19 17:38:45 --> Language Class Initialized
ERROR - 2018-04-19 17:38:46 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 17:38:54 --> Config Class Initialized
INFO - 2018-04-19 17:38:54 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:38:54 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:38:54 --> Utf8 Class Initialized
INFO - 2018-04-19 17:38:54 --> URI Class Initialized
INFO - 2018-04-19 17:38:54 --> Router Class Initialized
INFO - 2018-04-19 17:38:54 --> Output Class Initialized
INFO - 2018-04-19 17:38:54 --> Security Class Initialized
DEBUG - 2018-04-19 17:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:38:54 --> CSRF cookie sent
INFO - 2018-04-19 17:38:54 --> Input Class Initialized
INFO - 2018-04-19 17:38:54 --> Language Class Initialized
INFO - 2018-04-19 17:38:54 --> Loader Class Initialized
INFO - 2018-04-19 17:38:54 --> Helper loaded: url_helper
INFO - 2018-04-19 17:38:54 --> Helper loaded: form_helper
INFO - 2018-04-19 17:38:54 --> Helper loaded: language_helper
DEBUG - 2018-04-19 17:38:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 17:38:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 17:38:54 --> User Agent Class Initialized
INFO - 2018-04-19 17:38:54 --> Controller Class Initialized
INFO - 2018-04-19 17:38:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 17:38:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 17:38:54 --> Pixel_Model class loaded
INFO - 2018-04-19 17:38:55 --> Database Driver Class Initialized
INFO - 2018-04-19 17:38:55 --> Model "MyAccountModel" initialized
INFO - 2018-04-19 17:38:55 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 17:38:55 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-19 17:38:55 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 17:38:55 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-19 17:38:55 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-19 17:38:55 --> File loaded: E:\www\yacopoo\application\views\register/import_enduser.php
INFO - 2018-04-19 17:38:55 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 17:38:55 --> Final output sent to browser
DEBUG - 2018-04-19 17:38:55 --> Total execution time: 0.4092
INFO - 2018-04-19 17:38:55 --> Config Class Initialized
INFO - 2018-04-19 17:38:55 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:38:55 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:38:55 --> Utf8 Class Initialized
INFO - 2018-04-19 17:38:55 --> URI Class Initialized
INFO - 2018-04-19 17:38:55 --> Router Class Initialized
INFO - 2018-04-19 17:38:55 --> Output Class Initialized
INFO - 2018-04-19 17:38:55 --> Security Class Initialized
DEBUG - 2018-04-19 17:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:38:55 --> CSRF cookie sent
INFO - 2018-04-19 17:38:55 --> Input Class Initialized
INFO - 2018-04-19 17:38:55 --> Language Class Initialized
ERROR - 2018-04-19 17:38:55 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 17:39:05 --> Config Class Initialized
INFO - 2018-04-19 17:39:05 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:39:05 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:39:05 --> Utf8 Class Initialized
INFO - 2018-04-19 17:39:05 --> URI Class Initialized
INFO - 2018-04-19 17:39:05 --> Router Class Initialized
INFO - 2018-04-19 17:39:05 --> Output Class Initialized
INFO - 2018-04-19 17:39:05 --> Security Class Initialized
DEBUG - 2018-04-19 17:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:39:05 --> CSRF cookie sent
INFO - 2018-04-19 17:39:05 --> Input Class Initialized
INFO - 2018-04-19 17:39:05 --> Language Class Initialized
INFO - 2018-04-19 17:39:05 --> Loader Class Initialized
INFO - 2018-04-19 17:39:05 --> Helper loaded: url_helper
INFO - 2018-04-19 17:39:05 --> Helper loaded: form_helper
INFO - 2018-04-19 17:39:05 --> Helper loaded: language_helper
DEBUG - 2018-04-19 17:39:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 17:39:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 17:39:05 --> User Agent Class Initialized
INFO - 2018-04-19 17:39:05 --> Controller Class Initialized
INFO - 2018-04-19 17:39:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 17:39:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 17:39:05 --> Pixel_Model class loaded
INFO - 2018-04-19 17:39:05 --> Database Driver Class Initialized
INFO - 2018-04-19 17:39:05 --> Model "MyAccountModel" initialized
INFO - 2018-04-19 17:39:05 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 17:39:05 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-19 17:39:05 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 17:39:05 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-19 17:39:05 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-19 17:39:05 --> File loaded: E:\www\yacopoo\application\views\register/import_enduser.php
INFO - 2018-04-19 17:39:06 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 17:39:06 --> Final output sent to browser
DEBUG - 2018-04-19 17:39:06 --> Total execution time: 0.4096
INFO - 2018-04-19 17:39:06 --> Config Class Initialized
INFO - 2018-04-19 17:39:06 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:39:06 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:39:06 --> Utf8 Class Initialized
INFO - 2018-04-19 17:39:06 --> URI Class Initialized
INFO - 2018-04-19 17:39:06 --> Router Class Initialized
INFO - 2018-04-19 17:39:06 --> Output Class Initialized
INFO - 2018-04-19 17:39:06 --> Security Class Initialized
DEBUG - 2018-04-19 17:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:39:06 --> CSRF cookie sent
INFO - 2018-04-19 17:39:06 --> Input Class Initialized
INFO - 2018-04-19 17:39:06 --> Language Class Initialized
ERROR - 2018-04-19 17:39:06 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 17:39:16 --> Config Class Initialized
INFO - 2018-04-19 17:39:16 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:39:16 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:39:16 --> Utf8 Class Initialized
INFO - 2018-04-19 17:39:16 --> URI Class Initialized
INFO - 2018-04-19 17:39:16 --> Router Class Initialized
INFO - 2018-04-19 17:39:16 --> Output Class Initialized
INFO - 2018-04-19 17:39:16 --> Security Class Initialized
DEBUG - 2018-04-19 17:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:39:16 --> CSRF cookie sent
INFO - 2018-04-19 17:39:16 --> Input Class Initialized
INFO - 2018-04-19 17:39:16 --> Language Class Initialized
INFO - 2018-04-19 17:39:16 --> Loader Class Initialized
INFO - 2018-04-19 17:39:16 --> Helper loaded: url_helper
INFO - 2018-04-19 17:39:16 --> Helper loaded: form_helper
INFO - 2018-04-19 17:39:17 --> Helper loaded: language_helper
DEBUG - 2018-04-19 17:39:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 17:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 17:39:17 --> User Agent Class Initialized
INFO - 2018-04-19 17:39:17 --> Controller Class Initialized
INFO - 2018-04-19 17:39:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 17:39:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 17:39:17 --> Pixel_Model class loaded
INFO - 2018-04-19 17:39:17 --> Database Driver Class Initialized
INFO - 2018-04-19 17:39:17 --> Model "MyAccountModel" initialized
INFO - 2018-04-19 17:39:17 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 17:39:17 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-19 17:39:17 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 17:39:17 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-19 17:39:17 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-19 17:39:17 --> File loaded: E:\www\yacopoo\application\views\register/import_enduser.php
INFO - 2018-04-19 17:39:17 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 17:39:17 --> Final output sent to browser
DEBUG - 2018-04-19 17:39:17 --> Total execution time: 0.4100
INFO - 2018-04-19 17:39:17 --> Config Class Initialized
INFO - 2018-04-19 17:39:17 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:39:17 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:39:17 --> Utf8 Class Initialized
INFO - 2018-04-19 17:39:17 --> URI Class Initialized
INFO - 2018-04-19 17:39:17 --> Router Class Initialized
INFO - 2018-04-19 17:39:17 --> Output Class Initialized
INFO - 2018-04-19 17:39:17 --> Security Class Initialized
DEBUG - 2018-04-19 17:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:39:17 --> CSRF cookie sent
INFO - 2018-04-19 17:39:17 --> Input Class Initialized
INFO - 2018-04-19 17:39:17 --> Language Class Initialized
ERROR - 2018-04-19 17:39:17 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 17:39:46 --> Config Class Initialized
INFO - 2018-04-19 17:39:46 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:39:46 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:39:46 --> Utf8 Class Initialized
INFO - 2018-04-19 17:39:46 --> URI Class Initialized
INFO - 2018-04-19 17:39:46 --> Router Class Initialized
INFO - 2018-04-19 17:39:46 --> Output Class Initialized
INFO - 2018-04-19 17:39:46 --> Security Class Initialized
DEBUG - 2018-04-19 17:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:39:47 --> CSRF cookie sent
INFO - 2018-04-19 17:39:47 --> Input Class Initialized
INFO - 2018-04-19 17:39:47 --> Language Class Initialized
INFO - 2018-04-19 17:39:47 --> Loader Class Initialized
INFO - 2018-04-19 17:39:47 --> Helper loaded: url_helper
INFO - 2018-04-19 17:39:47 --> Helper loaded: form_helper
INFO - 2018-04-19 17:39:47 --> Helper loaded: language_helper
DEBUG - 2018-04-19 17:39:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 17:39:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 17:39:47 --> User Agent Class Initialized
INFO - 2018-04-19 17:39:47 --> Controller Class Initialized
INFO - 2018-04-19 17:39:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 17:39:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 17:39:47 --> Pixel_Model class loaded
INFO - 2018-04-19 17:39:47 --> Database Driver Class Initialized
INFO - 2018-04-19 17:39:47 --> Model "MyAccountModel" initialized
INFO - 2018-04-19 17:39:47 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 17:39:47 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-19 17:39:47 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 17:39:47 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-19 17:39:47 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-19 17:39:47 --> File loaded: E:\www\yacopoo\application\views\register/import_enduser.php
INFO - 2018-04-19 17:39:47 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 17:39:47 --> Final output sent to browser
DEBUG - 2018-04-19 17:39:47 --> Total execution time: 0.4034
INFO - 2018-04-19 17:39:47 --> Config Class Initialized
INFO - 2018-04-19 17:39:47 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:39:47 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:39:47 --> Utf8 Class Initialized
INFO - 2018-04-19 17:39:47 --> URI Class Initialized
INFO - 2018-04-19 17:39:47 --> Router Class Initialized
INFO - 2018-04-19 17:39:47 --> Output Class Initialized
INFO - 2018-04-19 17:39:47 --> Security Class Initialized
DEBUG - 2018-04-19 17:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:39:47 --> CSRF cookie sent
INFO - 2018-04-19 17:39:47 --> Input Class Initialized
INFO - 2018-04-19 17:39:47 --> Language Class Initialized
ERROR - 2018-04-19 17:39:47 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 17:40:02 --> Config Class Initialized
INFO - 2018-04-19 17:40:02 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:40:02 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:40:02 --> Utf8 Class Initialized
INFO - 2018-04-19 17:40:02 --> URI Class Initialized
INFO - 2018-04-19 17:40:02 --> Router Class Initialized
INFO - 2018-04-19 17:40:02 --> Output Class Initialized
INFO - 2018-04-19 17:40:02 --> Security Class Initialized
DEBUG - 2018-04-19 17:40:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:40:02 --> CSRF cookie sent
INFO - 2018-04-19 17:40:02 --> Input Class Initialized
INFO - 2018-04-19 17:40:02 --> Language Class Initialized
INFO - 2018-04-19 17:40:02 --> Loader Class Initialized
INFO - 2018-04-19 17:40:02 --> Helper loaded: url_helper
INFO - 2018-04-19 17:40:02 --> Helper loaded: form_helper
INFO - 2018-04-19 17:40:02 --> Helper loaded: language_helper
DEBUG - 2018-04-19 17:40:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 17:40:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 17:40:02 --> User Agent Class Initialized
INFO - 2018-04-19 17:40:02 --> Controller Class Initialized
INFO - 2018-04-19 17:40:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 17:40:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 17:40:02 --> Pixel_Model class loaded
INFO - 2018-04-19 17:40:02 --> Database Driver Class Initialized
INFO - 2018-04-19 17:40:02 --> Model "MyAccountModel" initialized
INFO - 2018-04-19 17:40:02 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 17:40:02 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-19 17:40:02 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 17:40:02 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-19 17:40:02 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-19 17:40:02 --> File loaded: E:\www\yacopoo\application\views\register/import_enduser.php
INFO - 2018-04-19 17:40:02 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 17:40:02 --> Final output sent to browser
DEBUG - 2018-04-19 17:40:02 --> Total execution time: 0.4048
INFO - 2018-04-19 17:40:02 --> Config Class Initialized
INFO - 2018-04-19 17:40:02 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:40:02 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:40:03 --> Utf8 Class Initialized
INFO - 2018-04-19 17:40:03 --> URI Class Initialized
INFO - 2018-04-19 17:40:03 --> Router Class Initialized
INFO - 2018-04-19 17:40:03 --> Output Class Initialized
INFO - 2018-04-19 17:40:03 --> Security Class Initialized
DEBUG - 2018-04-19 17:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:40:03 --> CSRF cookie sent
INFO - 2018-04-19 17:40:03 --> Input Class Initialized
INFO - 2018-04-19 17:40:03 --> Language Class Initialized
ERROR - 2018-04-19 17:40:03 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 17:40:29 --> Config Class Initialized
INFO - 2018-04-19 17:40:29 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:40:29 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:40:29 --> Utf8 Class Initialized
INFO - 2018-04-19 17:40:29 --> URI Class Initialized
INFO - 2018-04-19 17:40:29 --> Router Class Initialized
INFO - 2018-04-19 17:40:29 --> Output Class Initialized
INFO - 2018-04-19 17:40:29 --> Security Class Initialized
DEBUG - 2018-04-19 17:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:40:29 --> CSRF cookie sent
INFO - 2018-04-19 17:40:29 --> Input Class Initialized
INFO - 2018-04-19 17:40:29 --> Language Class Initialized
INFO - 2018-04-19 17:40:29 --> Loader Class Initialized
INFO - 2018-04-19 17:40:29 --> Helper loaded: url_helper
INFO - 2018-04-19 17:40:29 --> Helper loaded: form_helper
INFO - 2018-04-19 17:40:29 --> Helper loaded: language_helper
DEBUG - 2018-04-19 17:40:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 17:40:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 17:40:29 --> User Agent Class Initialized
INFO - 2018-04-19 17:40:29 --> Controller Class Initialized
INFO - 2018-04-19 17:40:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 17:40:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 17:40:29 --> Pixel_Model class loaded
INFO - 2018-04-19 17:40:29 --> Database Driver Class Initialized
INFO - 2018-04-19 17:40:29 --> Model "MyAccountModel" initialized
INFO - 2018-04-19 17:40:29 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 17:40:29 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-19 17:40:29 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 17:40:29 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-19 17:40:29 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-19 17:40:29 --> File loaded: E:\www\yacopoo\application\views\register/import_enduser.php
INFO - 2018-04-19 17:40:29 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 17:40:29 --> Final output sent to browser
DEBUG - 2018-04-19 17:40:29 --> Total execution time: 0.4052
INFO - 2018-04-19 17:40:30 --> Config Class Initialized
INFO - 2018-04-19 17:40:30 --> Hooks Class Initialized
DEBUG - 2018-04-19 17:40:30 --> UTF-8 Support Enabled
INFO - 2018-04-19 17:40:30 --> Utf8 Class Initialized
INFO - 2018-04-19 17:40:30 --> URI Class Initialized
INFO - 2018-04-19 17:40:30 --> Router Class Initialized
INFO - 2018-04-19 17:40:30 --> Output Class Initialized
INFO - 2018-04-19 17:40:30 --> Security Class Initialized
DEBUG - 2018-04-19 17:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 17:40:30 --> CSRF cookie sent
INFO - 2018-04-19 17:40:30 --> Input Class Initialized
INFO - 2018-04-19 17:40:30 --> Language Class Initialized
ERROR - 2018-04-19 17:40:30 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 19:23:49 --> Config Class Initialized
INFO - 2018-04-19 19:23:49 --> Hooks Class Initialized
DEBUG - 2018-04-19 19:23:49 --> UTF-8 Support Enabled
INFO - 2018-04-19 19:23:49 --> Utf8 Class Initialized
INFO - 2018-04-19 19:23:49 --> URI Class Initialized
INFO - 2018-04-19 19:23:49 --> Router Class Initialized
INFO - 2018-04-19 19:23:49 --> Output Class Initialized
INFO - 2018-04-19 19:23:49 --> Security Class Initialized
DEBUG - 2018-04-19 19:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 19:23:49 --> CSRF cookie sent
INFO - 2018-04-19 19:23:49 --> Input Class Initialized
INFO - 2018-04-19 19:23:49 --> Language Class Initialized
INFO - 2018-04-19 19:23:49 --> Loader Class Initialized
INFO - 2018-04-19 19:23:49 --> Helper loaded: url_helper
INFO - 2018-04-19 19:23:50 --> Helper loaded: form_helper
INFO - 2018-04-19 19:23:50 --> Helper loaded: language_helper
DEBUG - 2018-04-19 19:23:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 19:23:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 19:23:50 --> User Agent Class Initialized
INFO - 2018-04-19 19:23:50 --> Controller Class Initialized
INFO - 2018-04-19 19:23:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 19:23:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 19:23:50 --> Pixel_Model class loaded
INFO - 2018-04-19 19:23:50 --> Database Driver Class Initialized
INFO - 2018-04-19 19:23:50 --> Model "MyAccountModel" initialized
INFO - 2018-04-19 19:23:50 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 19:23:50 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-19 19:23:50 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 19:23:50 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-19 19:23:50 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-19 19:23:50 --> File loaded: E:\www\yacopoo\application\views\register/import_enduser.php
INFO - 2018-04-19 19:23:50 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 19:23:50 --> Final output sent to browser
DEBUG - 2018-04-19 19:23:50 --> Total execution time: 0.4011
INFO - 2018-04-19 19:23:50 --> Config Class Initialized
INFO - 2018-04-19 19:23:50 --> Hooks Class Initialized
DEBUG - 2018-04-19 19:23:50 --> UTF-8 Support Enabled
INFO - 2018-04-19 19:23:50 --> Utf8 Class Initialized
INFO - 2018-04-19 19:23:50 --> URI Class Initialized
INFO - 2018-04-19 19:23:50 --> Router Class Initialized
INFO - 2018-04-19 19:23:50 --> Output Class Initialized
INFO - 2018-04-19 19:23:50 --> Security Class Initialized
DEBUG - 2018-04-19 19:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 19:23:50 --> CSRF cookie sent
INFO - 2018-04-19 19:23:50 --> Input Class Initialized
INFO - 2018-04-19 19:23:50 --> Language Class Initialized
ERROR - 2018-04-19 19:23:50 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 19:23:59 --> Config Class Initialized
INFO - 2018-04-19 19:23:59 --> Hooks Class Initialized
DEBUG - 2018-04-19 19:23:59 --> UTF-8 Support Enabled
INFO - 2018-04-19 19:23:59 --> Utf8 Class Initialized
INFO - 2018-04-19 19:23:59 --> URI Class Initialized
INFO - 2018-04-19 19:23:59 --> Router Class Initialized
INFO - 2018-04-19 19:23:59 --> Output Class Initialized
INFO - 2018-04-19 19:23:59 --> Security Class Initialized
DEBUG - 2018-04-19 19:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 19:23:59 --> CSRF cookie sent
INFO - 2018-04-19 19:23:59 --> Input Class Initialized
INFO - 2018-04-19 19:23:59 --> Language Class Initialized
INFO - 2018-04-19 19:23:59 --> Loader Class Initialized
INFO - 2018-04-19 19:23:59 --> Helper loaded: url_helper
INFO - 2018-04-19 19:23:59 --> Helper loaded: form_helper
INFO - 2018-04-19 19:23:59 --> Helper loaded: language_helper
DEBUG - 2018-04-19 19:23:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 19:23:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 19:23:59 --> User Agent Class Initialized
INFO - 2018-04-19 19:23:59 --> Controller Class Initialized
INFO - 2018-04-19 19:23:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 19:23:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 19:23:59 --> Pixel_Model class loaded
INFO - 2018-04-19 19:23:59 --> Database Driver Class Initialized
INFO - 2018-04-19 19:23:59 --> Model "MyAccountModel" initialized
INFO - 2018-04-19 19:23:59 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 19:23:59 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-19 19:23:59 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 19:23:59 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-19 19:23:59 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-19 19:23:59 --> Could not find the language line "req_email"
INFO - 2018-04-19 19:23:59 --> File loaded: E:\www\yacopoo\application\views\register/add_client.php
INFO - 2018-04-19 19:23:59 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 19:23:59 --> Final output sent to browser
DEBUG - 2018-04-19 19:23:59 --> Total execution time: 0.4049
INFO - 2018-04-19 19:24:00 --> Config Class Initialized
INFO - 2018-04-19 19:24:00 --> Hooks Class Initialized
DEBUG - 2018-04-19 19:24:00 --> UTF-8 Support Enabled
INFO - 2018-04-19 19:24:00 --> Utf8 Class Initialized
INFO - 2018-04-19 19:24:00 --> URI Class Initialized
INFO - 2018-04-19 19:24:00 --> Router Class Initialized
INFO - 2018-04-19 19:24:00 --> Output Class Initialized
INFO - 2018-04-19 19:24:00 --> Security Class Initialized
DEBUG - 2018-04-19 19:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 19:24:00 --> CSRF cookie sent
INFO - 2018-04-19 19:24:00 --> Input Class Initialized
INFO - 2018-04-19 19:24:00 --> Language Class Initialized
ERROR - 2018-04-19 19:24:00 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 19:24:02 --> Config Class Initialized
INFO - 2018-04-19 19:24:02 --> Hooks Class Initialized
DEBUG - 2018-04-19 19:24:02 --> UTF-8 Support Enabled
INFO - 2018-04-19 19:24:02 --> Utf8 Class Initialized
INFO - 2018-04-19 19:24:02 --> URI Class Initialized
INFO - 2018-04-19 19:24:02 --> Router Class Initialized
INFO - 2018-04-19 19:24:02 --> Output Class Initialized
INFO - 2018-04-19 19:24:02 --> Security Class Initialized
DEBUG - 2018-04-19 19:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 19:24:02 --> CSRF cookie sent
INFO - 2018-04-19 19:24:02 --> Input Class Initialized
INFO - 2018-04-19 19:24:02 --> Language Class Initialized
INFO - 2018-04-19 19:24:02 --> Loader Class Initialized
INFO - 2018-04-19 19:24:02 --> Helper loaded: url_helper
INFO - 2018-04-19 19:24:02 --> Helper loaded: form_helper
INFO - 2018-04-19 19:24:02 --> Helper loaded: language_helper
DEBUG - 2018-04-19 19:24:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 19:24:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 19:24:02 --> User Agent Class Initialized
INFO - 2018-04-19 19:24:02 --> Controller Class Initialized
INFO - 2018-04-19 19:24:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 19:24:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 19:24:02 --> Pixel_Model class loaded
INFO - 2018-04-19 19:24:02 --> Database Driver Class Initialized
INFO - 2018-04-19 19:24:02 --> Model "MyAccountModel" initialized
INFO - 2018-04-19 19:24:02 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 19:24:03 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-19 19:24:03 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 19:24:03 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-19 19:24:03 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-19 19:24:03 --> File loaded: E:\www\yacopoo\application\views\register/import_enduser.php
INFO - 2018-04-19 19:24:03 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 19:24:03 --> Final output sent to browser
DEBUG - 2018-04-19 19:24:03 --> Total execution time: 0.3888
INFO - 2018-04-19 19:24:03 --> Config Class Initialized
INFO - 2018-04-19 19:24:03 --> Hooks Class Initialized
DEBUG - 2018-04-19 19:24:03 --> UTF-8 Support Enabled
INFO - 2018-04-19 19:24:03 --> Utf8 Class Initialized
INFO - 2018-04-19 19:24:03 --> URI Class Initialized
INFO - 2018-04-19 19:24:03 --> Router Class Initialized
INFO - 2018-04-19 19:24:03 --> Output Class Initialized
INFO - 2018-04-19 19:24:03 --> Security Class Initialized
DEBUG - 2018-04-19 19:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 19:24:03 --> CSRF cookie sent
INFO - 2018-04-19 19:24:03 --> Input Class Initialized
INFO - 2018-04-19 19:24:03 --> Language Class Initialized
ERROR - 2018-04-19 19:24:03 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 19:24:16 --> Config Class Initialized
INFO - 2018-04-19 19:24:16 --> Hooks Class Initialized
DEBUG - 2018-04-19 19:24:16 --> UTF-8 Support Enabled
INFO - 2018-04-19 19:24:16 --> Utf8 Class Initialized
INFO - 2018-04-19 19:24:16 --> URI Class Initialized
INFO - 2018-04-19 19:24:16 --> Router Class Initialized
INFO - 2018-04-19 19:24:16 --> Output Class Initialized
INFO - 2018-04-19 19:24:16 --> Security Class Initialized
DEBUG - 2018-04-19 19:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 19:24:16 --> CSRF cookie sent
INFO - 2018-04-19 19:24:16 --> CSRF token verified
INFO - 2018-04-19 19:24:16 --> Input Class Initialized
INFO - 2018-04-19 19:24:16 --> Language Class Initialized
INFO - 2018-04-19 19:24:16 --> Loader Class Initialized
INFO - 2018-04-19 19:24:16 --> Helper loaded: url_helper
INFO - 2018-04-19 19:24:16 --> Helper loaded: form_helper
INFO - 2018-04-19 19:24:16 --> Helper loaded: language_helper
DEBUG - 2018-04-19 19:24:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 19:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 19:24:16 --> User Agent Class Initialized
INFO - 2018-04-19 19:24:16 --> Controller Class Initialized
INFO - 2018-04-19 19:24:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 19:24:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 19:24:16 --> Upload Class Initialized
INFO - 2018-04-19 19:24:16 --> Pixel_Model class loaded
INFO - 2018-04-19 19:24:16 --> Database Driver Class Initialized
INFO - 2018-04-19 19:24:16 --> Model "RegistrationModel" initialized
INFO - 2018-04-19 19:24:16 --> Database Driver Class Initialized
INFO - 2018-04-19 19:24:16 --> Model "RegistrationModel" initialized
INFO - 2018-04-19 19:24:16 --> Helper loaded: string_helper
INFO - 2018-04-19 19:24:16 --> Language file loaded: language/en/notifications_lang.php
ERROR - 2018-04-19 19:24:17 --> Severity: Error --> Call to undefined method EmailsHelper::welcomeMessageEndUserSuccess() E:\www\yacopoo\application\libraries\EmailsHelper.php 44
INFO - 2018-04-19 19:26:51 --> Config Class Initialized
INFO - 2018-04-19 19:26:51 --> Hooks Class Initialized
DEBUG - 2018-04-19 19:26:51 --> UTF-8 Support Enabled
INFO - 2018-04-19 19:26:51 --> Utf8 Class Initialized
INFO - 2018-04-19 19:26:51 --> URI Class Initialized
INFO - 2018-04-19 19:26:51 --> Router Class Initialized
INFO - 2018-04-19 19:26:51 --> Output Class Initialized
INFO - 2018-04-19 19:26:51 --> Security Class Initialized
DEBUG - 2018-04-19 19:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 19:26:51 --> CSRF cookie sent
INFO - 2018-04-19 19:26:51 --> CSRF token verified
INFO - 2018-04-19 19:26:51 --> Input Class Initialized
INFO - 2018-04-19 19:26:51 --> Language Class Initialized
INFO - 2018-04-19 19:26:51 --> Loader Class Initialized
INFO - 2018-04-19 19:26:51 --> Helper loaded: url_helper
INFO - 2018-04-19 19:26:51 --> Helper loaded: form_helper
INFO - 2018-04-19 19:26:51 --> Helper loaded: language_helper
DEBUG - 2018-04-19 19:26:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 19:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 19:26:51 --> User Agent Class Initialized
INFO - 2018-04-19 19:26:51 --> Controller Class Initialized
INFO - 2018-04-19 19:26:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 19:26:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 19:26:51 --> Upload Class Initialized
INFO - 2018-04-19 19:26:51 --> Pixel_Model class loaded
INFO - 2018-04-19 19:26:51 --> Database Driver Class Initialized
INFO - 2018-04-19 19:26:51 --> Model "RegistrationModel" initialized
INFO - 2018-04-19 19:26:51 --> Database Driver Class Initialized
INFO - 2018-04-19 19:26:51 --> Model "RegistrationModel" initialized
INFO - 2018-04-19 19:26:51 --> Helper loaded: string_helper
INFO - 2018-04-19 19:26:51 --> Language file loaded: language/en/notifications_lang.php
INFO - 2018-04-19 19:26:52 --> File loaded: E:\www\yacopoo\application\views\emails/_buttons.php
INFO - 2018-04-19 19:26:52 --> File loaded: E:\www\yacopoo\application\views\emails/header.php
INFO - 2018-04-19 19:26:52 --> File loaded: E:\www\yacopoo\application\views\emails/footer.php
INFO - 2018-04-19 19:26:52 --> File loaded: E:\www\yacopoo\application\views\emails/generic.php
INFO - 2018-04-19 19:26:52 --> Email Class Initialized
DEBUG - 2018-04-19 19:26:52 --> EmailsHelper class already loaded. Second attempt ignored.
INFO - 2018-04-19 19:26:52 --> File loaded: E:\www\yacopoo\application\views\emails/_buttons.php
INFO - 2018-04-19 19:26:52 --> File loaded: E:\www\yacopoo\application\views\emails/header.php
INFO - 2018-04-19 19:26:52 --> File loaded: E:\www\yacopoo\application\views\emails/footer.php
INFO - 2018-04-19 19:26:52 --> File loaded: E:\www\yacopoo\application\views\emails/generic.php
DEBUG - 2018-04-19 19:26:52 --> Email class already loaded. Second attempt ignored.
INFO - 2018-04-19 19:26:52 --> Final output sent to browser
INFO - 2018-04-19 19:26:52 --> Config Class Initialized
DEBUG - 2018-04-19 19:26:52 --> Total execution time: 1.2697
INFO - 2018-04-19 19:26:52 --> Hooks Class Initialized
DEBUG - 2018-04-19 19:26:52 --> UTF-8 Support Enabled
INFO - 2018-04-19 19:26:52 --> Utf8 Class Initialized
INFO - 2018-04-19 19:26:52 --> URI Class Initialized
INFO - 2018-04-19 19:26:52 --> Router Class Initialized
INFO - 2018-04-19 19:26:52 --> Output Class Initialized
INFO - 2018-04-19 19:26:52 --> Security Class Initialized
DEBUG - 2018-04-19 19:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 19:26:52 --> CSRF cookie sent
INFO - 2018-04-19 19:26:52 --> Input Class Initialized
INFO - 2018-04-19 19:26:52 --> Language Class Initialized
ERROR - 2018-04-19 19:26:52 --> 404 Page Not Found: Assets/images
INFO - 2018-04-19 19:27:05 --> Config Class Initialized
INFO - 2018-04-19 19:27:05 --> Hooks Class Initialized
DEBUG - 2018-04-19 19:27:05 --> UTF-8 Support Enabled
INFO - 2018-04-19 19:27:05 --> Utf8 Class Initialized
INFO - 2018-04-19 19:27:05 --> URI Class Initialized
INFO - 2018-04-19 19:27:05 --> Router Class Initialized
INFO - 2018-04-19 19:27:05 --> Output Class Initialized
INFO - 2018-04-19 19:27:05 --> Security Class Initialized
DEBUG - 2018-04-19 19:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 19:27:05 --> CSRF cookie sent
INFO - 2018-04-19 19:27:05 --> Input Class Initialized
INFO - 2018-04-19 19:27:05 --> Language Class Initialized
ERROR - 2018-04-19 19:27:05 --> 404 Page Not Found: Complete-registration/2b8a27dbbb6d8943c6c9b2a29ff4ec90
INFO - 2018-04-19 19:40:19 --> Config Class Initialized
INFO - 2018-04-19 19:40:19 --> Hooks Class Initialized
DEBUG - 2018-04-19 19:40:19 --> UTF-8 Support Enabled
INFO - 2018-04-19 19:40:19 --> Utf8 Class Initialized
INFO - 2018-04-19 19:40:19 --> URI Class Initialized
INFO - 2018-04-19 19:40:19 --> Router Class Initialized
INFO - 2018-04-19 19:40:19 --> Output Class Initialized
INFO - 2018-04-19 19:40:19 --> Security Class Initialized
DEBUG - 2018-04-19 19:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 19:40:19 --> CSRF cookie sent
INFO - 2018-04-19 19:40:19 --> Input Class Initialized
INFO - 2018-04-19 19:40:19 --> Language Class Initialized
INFO - 2018-04-19 19:40:19 --> Loader Class Initialized
INFO - 2018-04-19 19:40:19 --> Helper loaded: url_helper
INFO - 2018-04-19 19:40:19 --> Helper loaded: form_helper
INFO - 2018-04-19 19:40:19 --> Helper loaded: language_helper
DEBUG - 2018-04-19 19:40:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 19:40:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 19:40:19 --> User Agent Class Initialized
INFO - 2018-04-19 19:40:19 --> Controller Class Initialized
INFO - 2018-04-19 19:40:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 19:40:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 19:40:19 --> Config Class Initialized
INFO - 2018-04-19 19:40:19 --> Hooks Class Initialized
DEBUG - 2018-04-19 19:40:19 --> UTF-8 Support Enabled
INFO - 2018-04-19 19:40:19 --> Utf8 Class Initialized
INFO - 2018-04-19 19:40:19 --> URI Class Initialized
DEBUG - 2018-04-19 19:40:19 --> No URI present. Default controller set.
INFO - 2018-04-19 19:40:19 --> Router Class Initialized
INFO - 2018-04-19 19:40:19 --> Output Class Initialized
INFO - 2018-04-19 19:40:19 --> Security Class Initialized
DEBUG - 2018-04-19 19:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 19:40:19 --> CSRF cookie sent
INFO - 2018-04-19 19:40:19 --> Input Class Initialized
INFO - 2018-04-19 19:40:19 --> Language Class Initialized
INFO - 2018-04-19 19:40:19 --> Loader Class Initialized
INFO - 2018-04-19 19:40:19 --> Helper loaded: url_helper
INFO - 2018-04-19 19:40:19 --> Helper loaded: form_helper
INFO - 2018-04-19 19:40:19 --> Helper loaded: language_helper
DEBUG - 2018-04-19 19:40:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 19:40:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 19:40:19 --> User Agent Class Initialized
INFO - 2018-04-19 19:40:19 --> Controller Class Initialized
INFO - 2018-04-19 19:40:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 19:40:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 19:40:19 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 19:40:19 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-19 19:40:19 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 19:40:19 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-19 19:40:19 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 19:40:19 --> Final output sent to browser
DEBUG - 2018-04-19 19:40:19 --> Total execution time: 0.3309
INFO - 2018-04-19 19:40:20 --> Config Class Initialized
INFO - 2018-04-19 19:40:20 --> Hooks Class Initialized
DEBUG - 2018-04-19 19:40:20 --> UTF-8 Support Enabled
INFO - 2018-04-19 19:40:20 --> Utf8 Class Initialized
INFO - 2018-04-19 19:40:20 --> URI Class Initialized
INFO - 2018-04-19 19:40:20 --> Router Class Initialized
INFO - 2018-04-19 19:40:20 --> Output Class Initialized
INFO - 2018-04-19 19:40:20 --> Security Class Initialized
DEBUG - 2018-04-19 19:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 19:40:20 --> CSRF cookie sent
INFO - 2018-04-19 19:40:20 --> Input Class Initialized
INFO - 2018-04-19 19:40:20 --> Language Class Initialized
ERROR - 2018-04-19 19:40:20 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 19:40:21 --> Config Class Initialized
INFO - 2018-04-19 19:40:21 --> Hooks Class Initialized
DEBUG - 2018-04-19 19:40:21 --> UTF-8 Support Enabled
INFO - 2018-04-19 19:40:21 --> Utf8 Class Initialized
INFO - 2018-04-19 19:40:21 --> URI Class Initialized
INFO - 2018-04-19 19:40:21 --> Router Class Initialized
INFO - 2018-04-19 19:40:21 --> Output Class Initialized
INFO - 2018-04-19 19:40:21 --> Security Class Initialized
DEBUG - 2018-04-19 19:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 19:40:21 --> CSRF cookie sent
INFO - 2018-04-19 19:40:21 --> Input Class Initialized
INFO - 2018-04-19 19:40:21 --> Language Class Initialized
ERROR - 2018-04-19 19:40:21 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-19 19:40:24 --> Config Class Initialized
INFO - 2018-04-19 19:40:24 --> Hooks Class Initialized
DEBUG - 2018-04-19 19:40:24 --> UTF-8 Support Enabled
INFO - 2018-04-19 19:40:24 --> Utf8 Class Initialized
INFO - 2018-04-19 19:40:24 --> URI Class Initialized
INFO - 2018-04-19 19:40:25 --> Router Class Initialized
INFO - 2018-04-19 19:40:25 --> Output Class Initialized
INFO - 2018-04-19 19:40:25 --> Security Class Initialized
DEBUG - 2018-04-19 19:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 19:40:25 --> CSRF cookie sent
INFO - 2018-04-19 19:40:25 --> CSRF token verified
INFO - 2018-04-19 19:40:25 --> Input Class Initialized
INFO - 2018-04-19 19:40:25 --> Language Class Initialized
INFO - 2018-04-19 19:40:25 --> Loader Class Initialized
INFO - 2018-04-19 19:40:25 --> Helper loaded: url_helper
INFO - 2018-04-19 19:40:25 --> Helper loaded: form_helper
INFO - 2018-04-19 19:40:25 --> Helper loaded: language_helper
DEBUG - 2018-04-19 19:40:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 19:40:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 19:40:25 --> User Agent Class Initialized
INFO - 2018-04-19 19:40:25 --> Controller Class Initialized
INFO - 2018-04-19 19:40:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 19:40:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 19:40:25 --> Upload Class Initialized
INFO - 2018-04-19 19:40:25 --> Pixel_Model class loaded
INFO - 2018-04-19 19:40:25 --> Database Driver Class Initialized
INFO - 2018-04-19 19:40:25 --> Model "RegistrationModel" initialized
INFO - 2018-04-19 19:40:25 --> Final output sent to browser
DEBUG - 2018-04-19 19:40:25 --> Total execution time: 0.3961
INFO - 2018-04-19 19:48:55 --> Config Class Initialized
INFO - 2018-04-19 19:48:55 --> Hooks Class Initialized
DEBUG - 2018-04-19 19:48:55 --> UTF-8 Support Enabled
INFO - 2018-04-19 19:48:55 --> Utf8 Class Initialized
INFO - 2018-04-19 19:48:55 --> URI Class Initialized
INFO - 2018-04-19 19:48:55 --> Router Class Initialized
INFO - 2018-04-19 19:48:55 --> Output Class Initialized
INFO - 2018-04-19 19:48:55 --> Security Class Initialized
DEBUG - 2018-04-19 19:48:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 19:48:55 --> CSRF cookie sent
INFO - 2018-04-19 19:48:55 --> CSRF token verified
INFO - 2018-04-19 19:48:55 --> Input Class Initialized
INFO - 2018-04-19 19:48:55 --> Language Class Initialized
INFO - 2018-04-19 19:48:55 --> Loader Class Initialized
INFO - 2018-04-19 19:48:55 --> Helper loaded: url_helper
INFO - 2018-04-19 19:48:55 --> Helper loaded: form_helper
INFO - 2018-04-19 19:48:55 --> Helper loaded: language_helper
DEBUG - 2018-04-19 19:48:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 19:48:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 19:48:55 --> User Agent Class Initialized
INFO - 2018-04-19 19:48:55 --> Controller Class Initialized
INFO - 2018-04-19 19:48:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 19:48:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 19:48:55 --> Upload Class Initialized
INFO - 2018-04-19 19:48:55 --> Pixel_Model class loaded
INFO - 2018-04-19 19:48:55 --> Database Driver Class Initialized
INFO - 2018-04-19 19:48:55 --> Model "RegistrationModel" initialized
INFO - 2018-04-19 19:48:55 --> Database Driver Class Initialized
INFO - 2018-04-19 19:48:55 --> Model "RegistrationModel" initialized
INFO - 2018-04-19 19:48:55 --> Helper loaded: string_helper
INFO - 2018-04-19 19:48:55 --> Language file loaded: language/en/notifications_lang.php
INFO - 2018-04-19 19:48:55 --> File loaded: E:\www\yacopoo\application\views\emails/_buttons.php
INFO - 2018-04-19 19:48:55 --> File loaded: E:\www\yacopoo\application\views\emails/header.php
INFO - 2018-04-19 19:48:55 --> File loaded: E:\www\yacopoo\application\views\emails/footer.php
INFO - 2018-04-19 19:48:55 --> File loaded: E:\www\yacopoo\application\views\emails/generic.php
INFO - 2018-04-19 19:48:55 --> Email Class Initialized
DEBUG - 2018-04-19 19:48:56 --> EmailsHelper class already loaded. Second attempt ignored.
INFO - 2018-04-19 19:48:56 --> File loaded: E:\www\yacopoo\application\views\emails/_buttons.php
INFO - 2018-04-19 19:48:56 --> File loaded: E:\www\yacopoo\application\views\emails/header.php
INFO - 2018-04-19 19:48:56 --> File loaded: E:\www\yacopoo\application\views\emails/footer.php
INFO - 2018-04-19 19:48:56 --> File loaded: E:\www\yacopoo\application\views\emails/generic.php
DEBUG - 2018-04-19 19:48:56 --> Email class already loaded. Second attempt ignored.
INFO - 2018-04-19 19:48:56 --> Config Class Initialized
INFO - 2018-04-19 19:48:56 --> Hooks Class Initialized
DEBUG - 2018-04-19 19:48:56 --> UTF-8 Support Enabled
INFO - 2018-04-19 19:48:56 --> Utf8 Class Initialized
INFO - 2018-04-19 19:48:56 --> URI Class Initialized
INFO - 2018-04-19 19:48:56 --> Router Class Initialized
INFO - 2018-04-19 19:48:56 --> Output Class Initialized
INFO - 2018-04-19 19:48:56 --> Security Class Initialized
DEBUG - 2018-04-19 19:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 19:48:56 --> CSRF cookie sent
INFO - 2018-04-19 19:48:56 --> Input Class Initialized
INFO - 2018-04-19 19:48:56 --> Language Class Initialized
DEBUG - 2018-04-19 19:48:56 --> EmailsHelper class already loaded. Second attempt ignored.
INFO - 2018-04-19 19:48:56 --> File loaded: E:\www\yacopoo\application\views\emails/_buttons.php
ERROR - 2018-04-19 19:48:56 --> 404 Page Not Found: Assets/images
INFO - 2018-04-19 19:48:56 --> File loaded: E:\www\yacopoo\application\views\emails/header.php
INFO - 2018-04-19 19:48:56 --> File loaded: E:\www\yacopoo\application\views\emails/footer.php
INFO - 2018-04-19 19:48:56 --> File loaded: E:\www\yacopoo\application\views\emails/generic.php
DEBUG - 2018-04-19 19:48:56 --> Email class already loaded. Second attempt ignored.
INFO - 2018-04-19 19:48:56 --> Final output sent to browser
DEBUG - 2018-04-19 19:48:56 --> Total execution time: 1.3192
INFO - 2018-04-19 19:48:56 --> Config Class Initialized
INFO - 2018-04-19 19:48:56 --> Hooks Class Initialized
DEBUG - 2018-04-19 19:48:56 --> UTF-8 Support Enabled
INFO - 2018-04-19 19:48:56 --> Utf8 Class Initialized
INFO - 2018-04-19 19:48:56 --> URI Class Initialized
INFO - 2018-04-19 19:48:56 --> Router Class Initialized
INFO - 2018-04-19 19:48:56 --> Output Class Initialized
INFO - 2018-04-19 19:48:56 --> Security Class Initialized
DEBUG - 2018-04-19 19:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 19:48:56 --> CSRF cookie sent
INFO - 2018-04-19 19:48:56 --> Input Class Initialized
INFO - 2018-04-19 19:48:56 --> Language Class Initialized
ERROR - 2018-04-19 19:48:56 --> 404 Page Not Found: Assets/images
INFO - 2018-04-19 19:53:37 --> Config Class Initialized
INFO - 2018-04-19 19:53:38 --> Hooks Class Initialized
DEBUG - 2018-04-19 19:53:38 --> UTF-8 Support Enabled
INFO - 2018-04-19 19:53:38 --> Utf8 Class Initialized
INFO - 2018-04-19 19:53:38 --> URI Class Initialized
DEBUG - 2018-04-19 19:53:38 --> No URI present. Default controller set.
INFO - 2018-04-19 19:53:38 --> Router Class Initialized
INFO - 2018-04-19 19:53:38 --> Output Class Initialized
INFO - 2018-04-19 19:53:38 --> Security Class Initialized
DEBUG - 2018-04-19 19:53:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 19:53:38 --> CSRF cookie sent
INFO - 2018-04-19 19:53:38 --> Input Class Initialized
INFO - 2018-04-19 19:53:38 --> Language Class Initialized
INFO - 2018-04-19 19:53:38 --> Loader Class Initialized
INFO - 2018-04-19 19:53:38 --> Helper loaded: url_helper
INFO - 2018-04-19 19:53:38 --> Helper loaded: form_helper
INFO - 2018-04-19 19:53:38 --> Helper loaded: language_helper
DEBUG - 2018-04-19 19:53:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 19:53:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 19:53:38 --> User Agent Class Initialized
INFO - 2018-04-19 19:53:38 --> Controller Class Initialized
INFO - 2018-04-19 19:53:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 19:53:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 19:53:38 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 19:53:38 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-19 19:53:38 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 19:53:38 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-19 19:53:38 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 19:53:38 --> Final output sent to browser
DEBUG - 2018-04-19 19:53:38 --> Total execution time: 0.3601
INFO - 2018-04-19 19:53:40 --> Config Class Initialized
INFO - 2018-04-19 19:53:40 --> Hooks Class Initialized
DEBUG - 2018-04-19 19:53:40 --> UTF-8 Support Enabled
INFO - 2018-04-19 19:53:40 --> Utf8 Class Initialized
INFO - 2018-04-19 19:53:40 --> URI Class Initialized
INFO - 2018-04-19 19:53:40 --> Router Class Initialized
INFO - 2018-04-19 19:53:40 --> Output Class Initialized
INFO - 2018-04-19 19:53:40 --> Security Class Initialized
DEBUG - 2018-04-19 19:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 19:53:40 --> CSRF cookie sent
INFO - 2018-04-19 19:53:40 --> Input Class Initialized
INFO - 2018-04-19 19:53:40 --> Language Class Initialized
ERROR - 2018-04-19 19:53:40 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-19 19:53:42 --> Config Class Initialized
INFO - 2018-04-19 19:53:42 --> Hooks Class Initialized
DEBUG - 2018-04-19 19:53:42 --> UTF-8 Support Enabled
INFO - 2018-04-19 19:53:42 --> Utf8 Class Initialized
INFO - 2018-04-19 19:53:42 --> URI Class Initialized
INFO - 2018-04-19 19:53:42 --> Router Class Initialized
INFO - 2018-04-19 19:53:42 --> Output Class Initialized
INFO - 2018-04-19 19:53:42 --> Security Class Initialized
DEBUG - 2018-04-19 19:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 19:53:42 --> CSRF cookie sent
INFO - 2018-04-19 19:53:42 --> Input Class Initialized
INFO - 2018-04-19 19:53:42 --> Language Class Initialized
INFO - 2018-04-19 19:53:42 --> Loader Class Initialized
INFO - 2018-04-19 19:53:42 --> Helper loaded: url_helper
INFO - 2018-04-19 19:53:42 --> Helper loaded: form_helper
INFO - 2018-04-19 19:53:42 --> Helper loaded: language_helper
DEBUG - 2018-04-19 19:53:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 19:53:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 19:53:42 --> User Agent Class Initialized
INFO - 2018-04-19 19:53:42 --> Controller Class Initialized
INFO - 2018-04-19 19:53:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 19:53:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 19:53:42 --> CSRF cookie sent
INFO - 2018-04-19 19:53:42 --> Config Class Initialized
INFO - 2018-04-19 19:53:42 --> Hooks Class Initialized
DEBUG - 2018-04-19 19:53:42 --> UTF-8 Support Enabled
INFO - 2018-04-19 19:53:42 --> Utf8 Class Initialized
INFO - 2018-04-19 19:53:42 --> URI Class Initialized
DEBUG - 2018-04-19 19:53:42 --> No URI present. Default controller set.
INFO - 2018-04-19 19:53:42 --> Router Class Initialized
INFO - 2018-04-19 19:53:42 --> Output Class Initialized
INFO - 2018-04-19 19:53:42 --> Security Class Initialized
DEBUG - 2018-04-19 19:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 19:53:42 --> CSRF cookie sent
INFO - 2018-04-19 19:53:42 --> Input Class Initialized
INFO - 2018-04-19 19:53:43 --> Language Class Initialized
INFO - 2018-04-19 19:53:43 --> Loader Class Initialized
INFO - 2018-04-19 19:53:43 --> Helper loaded: url_helper
INFO - 2018-04-19 19:53:43 --> Helper loaded: form_helper
INFO - 2018-04-19 19:53:43 --> Helper loaded: language_helper
DEBUG - 2018-04-19 19:53:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 19:53:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 19:53:43 --> User Agent Class Initialized
INFO - 2018-04-19 19:53:43 --> Controller Class Initialized
INFO - 2018-04-19 19:53:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 19:53:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 19:53:43 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 19:53:43 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 19:53:43 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-19 19:53:43 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 19:53:43 --> Final output sent to browser
DEBUG - 2018-04-19 19:53:43 --> Total execution time: 0.3688
INFO - 2018-04-19 19:53:44 --> Config Class Initialized
INFO - 2018-04-19 19:53:44 --> Hooks Class Initialized
DEBUG - 2018-04-19 19:53:44 --> UTF-8 Support Enabled
INFO - 2018-04-19 19:53:44 --> Utf8 Class Initialized
INFO - 2018-04-19 19:53:44 --> URI Class Initialized
INFO - 2018-04-19 19:53:44 --> Router Class Initialized
INFO - 2018-04-19 19:53:44 --> Output Class Initialized
INFO - 2018-04-19 19:53:44 --> Security Class Initialized
DEBUG - 2018-04-19 19:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 19:53:44 --> CSRF cookie sent
INFO - 2018-04-19 19:53:44 --> Input Class Initialized
INFO - 2018-04-19 19:53:44 --> Language Class Initialized
ERROR - 2018-04-19 19:53:44 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-19 19:53:46 --> Config Class Initialized
INFO - 2018-04-19 19:53:46 --> Hooks Class Initialized
DEBUG - 2018-04-19 19:53:46 --> UTF-8 Support Enabled
INFO - 2018-04-19 19:53:46 --> Utf8 Class Initialized
INFO - 2018-04-19 19:53:46 --> URI Class Initialized
INFO - 2018-04-19 19:53:46 --> Router Class Initialized
INFO - 2018-04-19 19:53:46 --> Output Class Initialized
INFO - 2018-04-19 19:53:46 --> Security Class Initialized
DEBUG - 2018-04-19 19:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 19:53:46 --> CSRF cookie sent
INFO - 2018-04-19 19:53:46 --> Input Class Initialized
INFO - 2018-04-19 19:53:46 --> Language Class Initialized
INFO - 2018-04-19 19:53:46 --> Loader Class Initialized
INFO - 2018-04-19 19:53:46 --> Helper loaded: url_helper
INFO - 2018-04-19 19:53:46 --> Helper loaded: form_helper
INFO - 2018-04-19 19:53:46 --> Helper loaded: language_helper
DEBUG - 2018-04-19 19:53:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 19:53:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 19:53:46 --> User Agent Class Initialized
INFO - 2018-04-19 19:53:46 --> Controller Class Initialized
INFO - 2018-04-19 19:53:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 19:53:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 19:53:46 --> Pixel_Model class loaded
INFO - 2018-04-19 19:53:46 --> Database Driver Class Initialized
INFO - 2018-04-19 19:53:46 --> Model "RegistrationModel" initialized
INFO - 2018-04-19 19:53:46 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 19:53:46 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 19:53:46 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-19 19:53:46 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-19 19:53:46 --> Severity: Notice --> Undefined variable: provinces E:\www\yacopoo\application\views\register\complete_registration.php 57
INFO - 2018-04-19 19:53:46 --> File loaded: E:\www\yacopoo\application\views\register/complete_registration.php
INFO - 2018-04-19 19:53:46 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 19:53:46 --> Final output sent to browser
DEBUG - 2018-04-19 19:53:46 --> Total execution time: 0.5367
INFO - 2018-04-19 19:54:35 --> Config Class Initialized
INFO - 2018-04-19 19:54:35 --> Hooks Class Initialized
DEBUG - 2018-04-19 19:54:35 --> UTF-8 Support Enabled
INFO - 2018-04-19 19:54:35 --> Utf8 Class Initialized
INFO - 2018-04-19 19:54:35 --> URI Class Initialized
INFO - 2018-04-19 19:54:35 --> Router Class Initialized
INFO - 2018-04-19 19:54:35 --> Output Class Initialized
INFO - 2018-04-19 19:54:35 --> Security Class Initialized
DEBUG - 2018-04-19 19:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 19:54:35 --> CSRF cookie sent
INFO - 2018-04-19 19:54:35 --> Input Class Initialized
INFO - 2018-04-19 19:54:35 --> Language Class Initialized
INFO - 2018-04-19 19:54:35 --> Loader Class Initialized
INFO - 2018-04-19 19:54:35 --> Helper loaded: url_helper
INFO - 2018-04-19 19:54:35 --> Helper loaded: form_helper
INFO - 2018-04-19 19:54:35 --> Helper loaded: language_helper
DEBUG - 2018-04-19 19:54:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 19:54:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 19:54:35 --> User Agent Class Initialized
INFO - 2018-04-19 19:54:35 --> Controller Class Initialized
INFO - 2018-04-19 19:54:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 19:54:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 19:54:35 --> Pixel_Model class loaded
INFO - 2018-04-19 19:54:35 --> Database Driver Class Initialized
INFO - 2018-04-19 19:54:35 --> Model "RegistrationModel" initialized
INFO - 2018-04-19 19:54:35 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 19:54:35 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 19:54:35 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-19 19:54:35 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-19 19:54:35 --> File loaded: E:\www\yacopoo\application\views\register/complete_registration.php
INFO - 2018-04-19 19:54:35 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 19:54:35 --> Final output sent to browser
DEBUG - 2018-04-19 19:54:35 --> Total execution time: 0.4541
INFO - 2018-04-19 20:06:59 --> Config Class Initialized
INFO - 2018-04-19 20:06:59 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:06:59 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:06:59 --> Utf8 Class Initialized
INFO - 2018-04-19 20:06:59 --> URI Class Initialized
INFO - 2018-04-19 20:06:59 --> Router Class Initialized
INFO - 2018-04-19 20:06:59 --> Output Class Initialized
INFO - 2018-04-19 20:06:59 --> Security Class Initialized
DEBUG - 2018-04-19 20:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:06:59 --> CSRF cookie sent
INFO - 2018-04-19 20:06:59 --> CSRF token verified
INFO - 2018-04-19 20:06:59 --> Input Class Initialized
INFO - 2018-04-19 20:06:59 --> Language Class Initialized
INFO - 2018-04-19 20:06:59 --> Loader Class Initialized
INFO - 2018-04-19 20:06:59 --> Helper loaded: url_helper
INFO - 2018-04-19 20:06:59 --> Helper loaded: form_helper
INFO - 2018-04-19 20:06:59 --> Helper loaded: language_helper
DEBUG - 2018-04-19 20:06:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 20:06:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 20:06:59 --> User Agent Class Initialized
INFO - 2018-04-19 20:06:59 --> Controller Class Initialized
INFO - 2018-04-19 20:06:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 20:06:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 20:06:59 --> Pixel_Model class loaded
INFO - 2018-04-19 20:06:59 --> Database Driver Class Initialized
INFO - 2018-04-19 20:06:59 --> Model "RegistrationModel" initialized
ERROR - 2018-04-19 20:06:59 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\controllers\RegistrationController.php 517
INFO - 2018-04-19 20:06:59 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 20:06:59 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 20:06:59 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-19 20:06:59 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-19 20:06:59 --> File loaded: E:\www\yacopoo\application\views\register/activation_success.php
INFO - 2018-04-19 20:06:59 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 20:06:59 --> Final output sent to browser
DEBUG - 2018-04-19 20:06:59 --> Total execution time: 0.4378
INFO - 2018-04-19 20:07:14 --> Config Class Initialized
INFO - 2018-04-19 20:07:14 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:07:15 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:07:15 --> Utf8 Class Initialized
INFO - 2018-04-19 20:07:15 --> URI Class Initialized
INFO - 2018-04-19 20:07:15 --> Router Class Initialized
INFO - 2018-04-19 20:07:15 --> Output Class Initialized
INFO - 2018-04-19 20:07:15 --> Security Class Initialized
DEBUG - 2018-04-19 20:07:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:07:15 --> CSRF cookie sent
INFO - 2018-04-19 20:07:15 --> Input Class Initialized
INFO - 2018-04-19 20:07:15 --> Language Class Initialized
INFO - 2018-04-19 20:07:15 --> Loader Class Initialized
INFO - 2018-04-19 20:07:15 --> Helper loaded: url_helper
INFO - 2018-04-19 20:07:15 --> Helper loaded: form_helper
INFO - 2018-04-19 20:07:15 --> Helper loaded: language_helper
DEBUG - 2018-04-19 20:07:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 20:07:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 20:07:15 --> User Agent Class Initialized
INFO - 2018-04-19 20:07:15 --> Controller Class Initialized
INFO - 2018-04-19 20:07:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 20:07:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 20:07:15 --> Pixel_Model class loaded
INFO - 2018-04-19 20:07:15 --> Database Driver Class Initialized
INFO - 2018-04-19 20:07:15 --> Model "RegistrationModel" initialized
INFO - 2018-04-19 20:07:15 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 20:07:15 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 20:07:15 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-19 20:07:15 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-19 20:07:15 --> File loaded: E:\www\yacopoo\application\views\register/complete_registration.php
INFO - 2018-04-19 20:07:15 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 20:07:15 --> Final output sent to browser
DEBUG - 2018-04-19 20:07:15 --> Total execution time: 0.4481
INFO - 2018-04-19 20:07:16 --> Config Class Initialized
INFO - 2018-04-19 20:07:16 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:07:16 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:07:16 --> Utf8 Class Initialized
INFO - 2018-04-19 20:07:16 --> URI Class Initialized
INFO - 2018-04-19 20:07:16 --> Router Class Initialized
INFO - 2018-04-19 20:07:16 --> Output Class Initialized
INFO - 2018-04-19 20:07:16 --> Security Class Initialized
DEBUG - 2018-04-19 20:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:07:16 --> CSRF cookie sent
INFO - 2018-04-19 20:07:16 --> Input Class Initialized
INFO - 2018-04-19 20:07:16 --> Language Class Initialized
INFO - 2018-04-19 20:07:17 --> Loader Class Initialized
INFO - 2018-04-19 20:07:17 --> Helper loaded: url_helper
INFO - 2018-04-19 20:07:17 --> Helper loaded: form_helper
INFO - 2018-04-19 20:07:17 --> Helper loaded: language_helper
DEBUG - 2018-04-19 20:07:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 20:07:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 20:07:17 --> User Agent Class Initialized
INFO - 2018-04-19 20:07:17 --> Controller Class Initialized
INFO - 2018-04-19 20:07:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 20:07:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 20:07:17 --> Pixel_Model class loaded
INFO - 2018-04-19 20:07:17 --> Database Driver Class Initialized
INFO - 2018-04-19 20:07:17 --> Model "RegistrationModel" initialized
INFO - 2018-04-19 20:07:17 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 20:07:17 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 20:07:17 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-19 20:07:17 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-19 20:07:17 --> File loaded: E:\www\yacopoo\application\views\register/complete_registration.php
INFO - 2018-04-19 20:07:17 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 20:07:17 --> Final output sent to browser
DEBUG - 2018-04-19 20:07:17 --> Total execution time: 0.4301
INFO - 2018-04-19 20:07:25 --> Config Class Initialized
INFO - 2018-04-19 20:07:25 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:07:25 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:07:25 --> Utf8 Class Initialized
INFO - 2018-04-19 20:07:25 --> URI Class Initialized
INFO - 2018-04-19 20:07:25 --> Router Class Initialized
INFO - 2018-04-19 20:07:25 --> Output Class Initialized
INFO - 2018-04-19 20:07:26 --> Security Class Initialized
DEBUG - 2018-04-19 20:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:07:26 --> CSRF cookie sent
INFO - 2018-04-19 20:07:26 --> Input Class Initialized
INFO - 2018-04-19 20:07:26 --> Language Class Initialized
INFO - 2018-04-19 20:07:26 --> Loader Class Initialized
INFO - 2018-04-19 20:07:26 --> Helper loaded: url_helper
INFO - 2018-04-19 20:07:26 --> Helper loaded: form_helper
INFO - 2018-04-19 20:07:26 --> Helper loaded: language_helper
DEBUG - 2018-04-19 20:07:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 20:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 20:07:26 --> User Agent Class Initialized
INFO - 2018-04-19 20:07:26 --> Controller Class Initialized
INFO - 2018-04-19 20:07:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 20:07:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 20:07:26 --> Pixel_Model class loaded
INFO - 2018-04-19 20:07:26 --> Database Driver Class Initialized
INFO - 2018-04-19 20:07:26 --> Model "RegistrationModel" initialized
INFO - 2018-04-19 20:07:26 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 20:07:26 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 20:07:26 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-19 20:07:26 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-19 20:07:26 --> File loaded: E:\www\yacopoo\application\views\register/complete_registration.php
INFO - 2018-04-19 20:07:26 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 20:07:26 --> Final output sent to browser
DEBUG - 2018-04-19 20:07:26 --> Total execution time: 0.4990
INFO - 2018-04-19 20:07:55 --> Config Class Initialized
INFO - 2018-04-19 20:07:55 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:07:55 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:07:55 --> Utf8 Class Initialized
INFO - 2018-04-19 20:07:55 --> URI Class Initialized
INFO - 2018-04-19 20:07:55 --> Router Class Initialized
INFO - 2018-04-19 20:07:55 --> Output Class Initialized
INFO - 2018-04-19 20:07:55 --> Security Class Initialized
DEBUG - 2018-04-19 20:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:07:55 --> CSRF cookie sent
INFO - 2018-04-19 20:07:55 --> Input Class Initialized
INFO - 2018-04-19 20:07:55 --> Language Class Initialized
ERROR - 2018-04-19 20:07:55 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 20:07:59 --> Config Class Initialized
INFO - 2018-04-19 20:07:59 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:07:59 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:07:59 --> Utf8 Class Initialized
INFO - 2018-04-19 20:07:59 --> URI Class Initialized
INFO - 2018-04-19 20:07:59 --> Router Class Initialized
INFO - 2018-04-19 20:07:59 --> Output Class Initialized
INFO - 2018-04-19 20:07:59 --> Security Class Initialized
DEBUG - 2018-04-19 20:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:07:59 --> CSRF cookie sent
INFO - 2018-04-19 20:07:59 --> Input Class Initialized
INFO - 2018-04-19 20:07:59 --> Language Class Initialized
INFO - 2018-04-19 20:07:59 --> Loader Class Initialized
INFO - 2018-04-19 20:07:59 --> Helper loaded: url_helper
INFO - 2018-04-19 20:07:59 --> Helper loaded: form_helper
INFO - 2018-04-19 20:07:59 --> Helper loaded: language_helper
DEBUG - 2018-04-19 20:07:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 20:07:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 20:07:59 --> User Agent Class Initialized
INFO - 2018-04-19 20:07:59 --> Controller Class Initialized
INFO - 2018-04-19 20:07:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 20:07:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 20:07:59 --> Pixel_Model class loaded
INFO - 2018-04-19 20:07:59 --> Database Driver Class Initialized
INFO - 2018-04-19 20:07:59 --> Model "RegistrationModel" initialized
INFO - 2018-04-19 20:07:59 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 20:07:59 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 20:07:59 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-19 20:07:59 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-19 20:07:59 --> File loaded: E:\www\yacopoo\application\views\register/complete_registration.php
INFO - 2018-04-19 20:07:59 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 20:07:59 --> Final output sent to browser
DEBUG - 2018-04-19 20:07:59 --> Total execution time: 0.5031
INFO - 2018-04-19 20:07:59 --> Config Class Initialized
INFO - 2018-04-19 20:08:00 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:08:00 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:08:00 --> Utf8 Class Initialized
INFO - 2018-04-19 20:08:00 --> URI Class Initialized
INFO - 2018-04-19 20:08:00 --> Router Class Initialized
INFO - 2018-04-19 20:08:00 --> Output Class Initialized
INFO - 2018-04-19 20:08:00 --> Security Class Initialized
DEBUG - 2018-04-19 20:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:08:00 --> CSRF cookie sent
INFO - 2018-04-19 20:08:00 --> Input Class Initialized
INFO - 2018-04-19 20:08:00 --> Language Class Initialized
ERROR - 2018-04-19 20:08:00 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 20:09:12 --> Config Class Initialized
INFO - 2018-04-19 20:09:12 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:09:12 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:09:12 --> Utf8 Class Initialized
INFO - 2018-04-19 20:09:12 --> URI Class Initialized
INFO - 2018-04-19 20:09:12 --> Router Class Initialized
INFO - 2018-04-19 20:09:12 --> Output Class Initialized
INFO - 2018-04-19 20:09:12 --> Security Class Initialized
DEBUG - 2018-04-19 20:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:09:13 --> CSRF cookie sent
INFO - 2018-04-19 20:09:13 --> Input Class Initialized
INFO - 2018-04-19 20:09:13 --> Language Class Initialized
INFO - 2018-04-19 20:09:13 --> Loader Class Initialized
INFO - 2018-04-19 20:09:13 --> Helper loaded: url_helper
INFO - 2018-04-19 20:09:13 --> Helper loaded: form_helper
INFO - 2018-04-19 20:09:13 --> Helper loaded: language_helper
DEBUG - 2018-04-19 20:09:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 20:09:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 20:09:13 --> User Agent Class Initialized
INFO - 2018-04-19 20:09:13 --> Controller Class Initialized
INFO - 2018-04-19 20:09:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 20:09:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 20:09:13 --> Pixel_Model class loaded
INFO - 2018-04-19 20:09:13 --> Database Driver Class Initialized
INFO - 2018-04-19 20:09:13 --> Model "RegistrationModel" initialized
DEBUG - 2018-04-19 20:09:13 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-19 20:09:13 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 20:09:13 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 20:09:13 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-19 20:09:13 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-19 20:09:13 --> Could not find the language line "req_email"
INFO - 2018-04-19 20:09:13 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-04-19 20:09:13 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 20:09:13 --> Final output sent to browser
DEBUG - 2018-04-19 20:09:13 --> Total execution time: 0.4942
INFO - 2018-04-19 20:09:46 --> Config Class Initialized
INFO - 2018-04-19 20:09:46 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:09:46 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:09:46 --> Utf8 Class Initialized
INFO - 2018-04-19 20:09:46 --> URI Class Initialized
INFO - 2018-04-19 20:09:46 --> Router Class Initialized
INFO - 2018-04-19 20:09:46 --> Output Class Initialized
INFO - 2018-04-19 20:09:46 --> Security Class Initialized
DEBUG - 2018-04-19 20:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:09:46 --> CSRF cookie sent
INFO - 2018-04-19 20:09:46 --> Input Class Initialized
INFO - 2018-04-19 20:09:46 --> Language Class Initialized
ERROR - 2018-04-19 20:09:46 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 20:13:30 --> Config Class Initialized
INFO - 2018-04-19 20:13:30 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:13:30 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:13:30 --> Utf8 Class Initialized
INFO - 2018-04-19 20:13:30 --> URI Class Initialized
INFO - 2018-04-19 20:13:30 --> Router Class Initialized
INFO - 2018-04-19 20:13:31 --> Output Class Initialized
INFO - 2018-04-19 20:13:31 --> Security Class Initialized
DEBUG - 2018-04-19 20:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:13:31 --> CSRF cookie sent
INFO - 2018-04-19 20:13:31 --> Input Class Initialized
INFO - 2018-04-19 20:13:31 --> Language Class Initialized
INFO - 2018-04-19 20:13:31 --> Loader Class Initialized
INFO - 2018-04-19 20:13:31 --> Helper loaded: url_helper
INFO - 2018-04-19 20:13:31 --> Helper loaded: form_helper
INFO - 2018-04-19 20:13:31 --> Helper loaded: language_helper
DEBUG - 2018-04-19 20:13:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 20:13:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 20:13:31 --> User Agent Class Initialized
INFO - 2018-04-19 20:13:31 --> Controller Class Initialized
INFO - 2018-04-19 20:13:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 20:13:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 20:13:31 --> Pixel_Model class loaded
INFO - 2018-04-19 20:13:31 --> Database Driver Class Initialized
INFO - 2018-04-19 20:13:31 --> Model "RegistrationModel" initialized
DEBUG - 2018-04-19 20:13:31 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-19 20:13:31 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 20:13:31 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 20:13:31 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-19 20:13:31 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-19 20:13:31 --> Could not find the language line "req_email"
INFO - 2018-04-19 20:13:31 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-04-19 20:13:31 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 20:13:31 --> Final output sent to browser
DEBUG - 2018-04-19 20:13:31 --> Total execution time: 0.5227
INFO - 2018-04-19 20:13:31 --> Config Class Initialized
INFO - 2018-04-19 20:13:31 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:13:31 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:13:31 --> Utf8 Class Initialized
INFO - 2018-04-19 20:13:31 --> URI Class Initialized
INFO - 2018-04-19 20:13:31 --> Router Class Initialized
INFO - 2018-04-19 20:13:31 --> Output Class Initialized
INFO - 2018-04-19 20:13:32 --> Security Class Initialized
DEBUG - 2018-04-19 20:13:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:13:32 --> CSRF cookie sent
INFO - 2018-04-19 20:13:32 --> Input Class Initialized
INFO - 2018-04-19 20:13:32 --> Language Class Initialized
ERROR - 2018-04-19 20:13:32 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 20:13:42 --> Config Class Initialized
INFO - 2018-04-19 20:13:42 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:13:42 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:13:43 --> Utf8 Class Initialized
INFO - 2018-04-19 20:13:43 --> URI Class Initialized
INFO - 2018-04-19 20:13:43 --> Router Class Initialized
INFO - 2018-04-19 20:13:43 --> Output Class Initialized
INFO - 2018-04-19 20:13:43 --> Security Class Initialized
DEBUG - 2018-04-19 20:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:13:43 --> CSRF cookie sent
INFO - 2018-04-19 20:13:43 --> Input Class Initialized
INFO - 2018-04-19 20:13:43 --> Language Class Initialized
INFO - 2018-04-19 20:13:43 --> Loader Class Initialized
INFO - 2018-04-19 20:13:43 --> Helper loaded: url_helper
INFO - 2018-04-19 20:13:43 --> Helper loaded: form_helper
INFO - 2018-04-19 20:13:43 --> Helper loaded: language_helper
DEBUG - 2018-04-19 20:13:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 20:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 20:13:43 --> User Agent Class Initialized
INFO - 2018-04-19 20:13:43 --> Controller Class Initialized
INFO - 2018-04-19 20:13:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 20:13:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 20:13:43 --> Pixel_Model class loaded
INFO - 2018-04-19 20:13:43 --> Database Driver Class Initialized
INFO - 2018-04-19 20:13:43 --> Model "RegistrationModel" initialized
DEBUG - 2018-04-19 20:13:43 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-19 20:13:43 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 20:13:43 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 20:13:43 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-19 20:13:43 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-19 20:13:43 --> Could not find the language line "req_email"
INFO - 2018-04-19 20:13:43 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-04-19 20:13:43 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 20:13:43 --> Final output sent to browser
DEBUG - 2018-04-19 20:13:43 --> Total execution time: 0.4874
INFO - 2018-04-19 20:13:43 --> Config Class Initialized
INFO - 2018-04-19 20:13:43 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:13:43 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:13:43 --> Utf8 Class Initialized
INFO - 2018-04-19 20:13:43 --> URI Class Initialized
INFO - 2018-04-19 20:13:43 --> Router Class Initialized
INFO - 2018-04-19 20:13:43 --> Output Class Initialized
INFO - 2018-04-19 20:13:44 --> Security Class Initialized
DEBUG - 2018-04-19 20:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:13:44 --> CSRF cookie sent
INFO - 2018-04-19 20:13:44 --> Input Class Initialized
INFO - 2018-04-19 20:13:44 --> Language Class Initialized
ERROR - 2018-04-19 20:13:44 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 20:14:08 --> Config Class Initialized
INFO - 2018-04-19 20:14:08 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:14:08 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:14:08 --> Utf8 Class Initialized
INFO - 2018-04-19 20:14:08 --> URI Class Initialized
INFO - 2018-04-19 20:14:08 --> Router Class Initialized
INFO - 2018-04-19 20:14:08 --> Output Class Initialized
INFO - 2018-04-19 20:14:08 --> Security Class Initialized
DEBUG - 2018-04-19 20:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:14:08 --> CSRF cookie sent
INFO - 2018-04-19 20:14:08 --> Input Class Initialized
INFO - 2018-04-19 20:14:08 --> Language Class Initialized
INFO - 2018-04-19 20:14:08 --> Loader Class Initialized
INFO - 2018-04-19 20:14:08 --> Helper loaded: url_helper
INFO - 2018-04-19 20:14:08 --> Helper loaded: form_helper
INFO - 2018-04-19 20:14:08 --> Helper loaded: language_helper
DEBUG - 2018-04-19 20:14:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 20:14:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 20:14:08 --> User Agent Class Initialized
INFO - 2018-04-19 20:14:08 --> Controller Class Initialized
INFO - 2018-04-19 20:14:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 20:14:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 20:14:08 --> Pixel_Model class loaded
INFO - 2018-04-19 20:14:08 --> Database Driver Class Initialized
INFO - 2018-04-19 20:14:08 --> Model "RegistrationModel" initialized
INFO - 2018-04-19 20:14:08 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 20:14:08 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 20:14:08 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-19 20:14:08 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-19 20:14:08 --> File loaded: E:\www\yacopoo\application\views\register/complete_registration.php
INFO - 2018-04-19 20:14:08 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 20:14:09 --> Final output sent to browser
DEBUG - 2018-04-19 20:14:09 --> Total execution time: 0.4705
INFO - 2018-04-19 20:14:09 --> Config Class Initialized
INFO - 2018-04-19 20:14:09 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:14:09 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:14:09 --> Utf8 Class Initialized
INFO - 2018-04-19 20:14:09 --> URI Class Initialized
INFO - 2018-04-19 20:14:09 --> Router Class Initialized
INFO - 2018-04-19 20:14:09 --> Output Class Initialized
INFO - 2018-04-19 20:14:09 --> Security Class Initialized
DEBUG - 2018-04-19 20:14:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:14:09 --> CSRF cookie sent
INFO - 2018-04-19 20:14:09 --> Input Class Initialized
INFO - 2018-04-19 20:14:09 --> Language Class Initialized
ERROR - 2018-04-19 20:14:09 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 20:14:25 --> Config Class Initialized
INFO - 2018-04-19 20:14:25 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:14:25 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:14:25 --> Utf8 Class Initialized
INFO - 2018-04-19 20:14:25 --> URI Class Initialized
INFO - 2018-04-19 20:14:25 --> Router Class Initialized
INFO - 2018-04-19 20:14:25 --> Output Class Initialized
INFO - 2018-04-19 20:14:25 --> Security Class Initialized
DEBUG - 2018-04-19 20:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:14:25 --> CSRF cookie sent
INFO - 2018-04-19 20:14:25 --> CSRF token verified
INFO - 2018-04-19 20:14:25 --> Input Class Initialized
INFO - 2018-04-19 20:14:25 --> Language Class Initialized
INFO - 2018-04-19 20:14:25 --> Loader Class Initialized
INFO - 2018-04-19 20:14:25 --> Helper loaded: url_helper
INFO - 2018-04-19 20:14:25 --> Helper loaded: form_helper
INFO - 2018-04-19 20:14:25 --> Helper loaded: language_helper
DEBUG - 2018-04-19 20:14:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 20:14:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 20:14:25 --> User Agent Class Initialized
INFO - 2018-04-19 20:14:25 --> Controller Class Initialized
INFO - 2018-04-19 20:14:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 20:14:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 20:14:25 --> Pixel_Model class loaded
INFO - 2018-04-19 20:14:25 --> Database Driver Class Initialized
INFO - 2018-04-19 20:14:25 --> Model "RegistrationModel" initialized
ERROR - 2018-04-19 20:14:25 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\controllers\RegistrationController.php 517
INFO - 2018-04-19 20:14:25 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 20:14:25 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 20:14:25 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-19 20:14:25 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-19 20:14:25 --> File loaded: E:\www\yacopoo\application\views\register/activation_success.php
INFO - 2018-04-19 20:14:25 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 20:14:25 --> Final output sent to browser
DEBUG - 2018-04-19 20:14:25 --> Total execution time: 0.4493
INFO - 2018-04-19 20:14:26 --> Config Class Initialized
INFO - 2018-04-19 20:14:26 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:14:26 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:14:26 --> Utf8 Class Initialized
INFO - 2018-04-19 20:14:26 --> URI Class Initialized
INFO - 2018-04-19 20:14:26 --> Router Class Initialized
INFO - 2018-04-19 20:14:26 --> Output Class Initialized
INFO - 2018-04-19 20:14:26 --> Security Class Initialized
DEBUG - 2018-04-19 20:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:14:26 --> CSRF cookie sent
INFO - 2018-04-19 20:14:26 --> Input Class Initialized
INFO - 2018-04-19 20:14:26 --> Language Class Initialized
ERROR - 2018-04-19 20:14:26 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 20:15:01 --> Config Class Initialized
INFO - 2018-04-19 20:15:01 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:15:01 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:15:01 --> Utf8 Class Initialized
INFO - 2018-04-19 20:15:01 --> URI Class Initialized
INFO - 2018-04-19 20:15:01 --> Router Class Initialized
INFO - 2018-04-19 20:15:01 --> Output Class Initialized
INFO - 2018-04-19 20:15:01 --> Security Class Initialized
DEBUG - 2018-04-19 20:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:15:01 --> CSRF cookie sent
INFO - 2018-04-19 20:15:01 --> CSRF token verified
INFO - 2018-04-19 20:15:01 --> Input Class Initialized
INFO - 2018-04-19 20:15:01 --> Language Class Initialized
INFO - 2018-04-19 20:15:01 --> Loader Class Initialized
INFO - 2018-04-19 20:15:01 --> Helper loaded: url_helper
INFO - 2018-04-19 20:15:01 --> Helper loaded: form_helper
INFO - 2018-04-19 20:15:01 --> Helper loaded: language_helper
DEBUG - 2018-04-19 20:15:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 20:15:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 20:15:01 --> User Agent Class Initialized
INFO - 2018-04-19 20:15:01 --> Controller Class Initialized
INFO - 2018-04-19 20:15:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 20:15:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 20:15:01 --> Pixel_Model class loaded
INFO - 2018-04-19 20:15:01 --> Database Driver Class Initialized
INFO - 2018-04-19 20:15:01 --> Model "RegistrationModel" initialized
INFO - 2018-04-19 20:15:01 --> Form Validation Class Initialized
INFO - 2018-04-19 20:15:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-19 20:15:02 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 20:15:02 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 20:15:02 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-19 20:15:02 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-19 20:15:02 --> File loaded: E:\www\yacopoo\application\views\shared/_errors.php
INFO - 2018-04-19 20:15:02 --> File loaded: E:\www\yacopoo\application\views\register/complete_registration.php
INFO - 2018-04-19 20:15:02 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 20:15:02 --> Final output sent to browser
DEBUG - 2018-04-19 20:15:02 --> Total execution time: 0.6344
INFO - 2018-04-19 20:15:02 --> Config Class Initialized
INFO - 2018-04-19 20:15:02 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:15:02 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:15:02 --> Utf8 Class Initialized
INFO - 2018-04-19 20:15:02 --> URI Class Initialized
INFO - 2018-04-19 20:15:02 --> Router Class Initialized
INFO - 2018-04-19 20:15:02 --> Output Class Initialized
INFO - 2018-04-19 20:15:02 --> Security Class Initialized
DEBUG - 2018-04-19 20:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:15:02 --> CSRF cookie sent
INFO - 2018-04-19 20:15:02 --> Input Class Initialized
INFO - 2018-04-19 20:15:02 --> Language Class Initialized
ERROR - 2018-04-19 20:15:02 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 20:15:15 --> Config Class Initialized
INFO - 2018-04-19 20:15:15 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:15:15 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:15:15 --> Utf8 Class Initialized
INFO - 2018-04-19 20:15:15 --> URI Class Initialized
INFO - 2018-04-19 20:15:15 --> Router Class Initialized
INFO - 2018-04-19 20:15:15 --> Output Class Initialized
INFO - 2018-04-19 20:15:15 --> Security Class Initialized
DEBUG - 2018-04-19 20:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:15:15 --> CSRF cookie sent
INFO - 2018-04-19 20:15:15 --> CSRF token verified
INFO - 2018-04-19 20:15:15 --> Input Class Initialized
INFO - 2018-04-19 20:15:15 --> Language Class Initialized
INFO - 2018-04-19 20:15:15 --> Loader Class Initialized
INFO - 2018-04-19 20:15:15 --> Helper loaded: url_helper
INFO - 2018-04-19 20:15:15 --> Helper loaded: form_helper
INFO - 2018-04-19 20:15:15 --> Helper loaded: language_helper
DEBUG - 2018-04-19 20:15:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 20:15:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 20:15:15 --> User Agent Class Initialized
INFO - 2018-04-19 20:15:15 --> Controller Class Initialized
INFO - 2018-04-19 20:15:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 20:15:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 20:15:15 --> Pixel_Model class loaded
INFO - 2018-04-19 20:15:15 --> Database Driver Class Initialized
INFO - 2018-04-19 20:15:15 --> Model "RegistrationModel" initialized
INFO - 2018-04-19 20:15:15 --> Form Validation Class Initialized
INFO - 2018-04-19 20:15:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-19 20:15:15 --> Config Class Initialized
INFO - 2018-04-19 20:15:15 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:15:15 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:15:15 --> Utf8 Class Initialized
INFO - 2018-04-19 20:15:15 --> URI Class Initialized
DEBUG - 2018-04-19 20:15:15 --> No URI present. Default controller set.
INFO - 2018-04-19 20:15:15 --> Router Class Initialized
INFO - 2018-04-19 20:15:16 --> Output Class Initialized
INFO - 2018-04-19 20:15:16 --> Security Class Initialized
DEBUG - 2018-04-19 20:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:15:16 --> CSRF cookie sent
INFO - 2018-04-19 20:15:16 --> Input Class Initialized
INFO - 2018-04-19 20:15:16 --> Language Class Initialized
INFO - 2018-04-19 20:15:16 --> Loader Class Initialized
INFO - 2018-04-19 20:15:16 --> Helper loaded: url_helper
INFO - 2018-04-19 20:15:16 --> Helper loaded: form_helper
INFO - 2018-04-19 20:15:16 --> Helper loaded: language_helper
DEBUG - 2018-04-19 20:15:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 20:15:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 20:15:16 --> User Agent Class Initialized
INFO - 2018-04-19 20:15:16 --> Controller Class Initialized
INFO - 2018-04-19 20:15:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 20:15:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 20:15:16 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 20:15:16 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-19 20:15:16 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 20:15:16 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-19 20:15:16 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 20:15:16 --> Final output sent to browser
DEBUG - 2018-04-19 20:15:16 --> Total execution time: 0.3788
INFO - 2018-04-19 20:15:16 --> Config Class Initialized
INFO - 2018-04-19 20:15:16 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:15:16 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:15:16 --> Utf8 Class Initialized
INFO - 2018-04-19 20:15:16 --> URI Class Initialized
INFO - 2018-04-19 20:15:16 --> Router Class Initialized
INFO - 2018-04-19 20:15:16 --> Output Class Initialized
INFO - 2018-04-19 20:15:16 --> Security Class Initialized
DEBUG - 2018-04-19 20:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:15:16 --> CSRF cookie sent
INFO - 2018-04-19 20:15:16 --> Input Class Initialized
INFO - 2018-04-19 20:15:16 --> Language Class Initialized
ERROR - 2018-04-19 20:15:16 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 20:15:18 --> Config Class Initialized
INFO - 2018-04-19 20:15:18 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:15:18 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:15:18 --> Utf8 Class Initialized
INFO - 2018-04-19 20:15:18 --> URI Class Initialized
INFO - 2018-04-19 20:15:18 --> Router Class Initialized
INFO - 2018-04-19 20:15:18 --> Output Class Initialized
INFO - 2018-04-19 20:15:18 --> Security Class Initialized
DEBUG - 2018-04-19 20:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:15:18 --> CSRF cookie sent
INFO - 2018-04-19 20:15:18 --> Input Class Initialized
INFO - 2018-04-19 20:15:18 --> Language Class Initialized
ERROR - 2018-04-19 20:15:18 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-19 20:15:26 --> Config Class Initialized
INFO - 2018-04-19 20:15:26 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:15:26 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:15:26 --> Utf8 Class Initialized
INFO - 2018-04-19 20:15:26 --> URI Class Initialized
INFO - 2018-04-19 20:15:26 --> Router Class Initialized
INFO - 2018-04-19 20:15:26 --> Output Class Initialized
INFO - 2018-04-19 20:15:26 --> Security Class Initialized
DEBUG - 2018-04-19 20:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:15:26 --> CSRF cookie sent
INFO - 2018-04-19 20:15:26 --> Input Class Initialized
INFO - 2018-04-19 20:15:26 --> Language Class Initialized
INFO - 2018-04-19 20:15:26 --> Loader Class Initialized
INFO - 2018-04-19 20:15:26 --> Helper loaded: url_helper
INFO - 2018-04-19 20:15:26 --> Helper loaded: form_helper
INFO - 2018-04-19 20:15:26 --> Helper loaded: language_helper
DEBUG - 2018-04-19 20:15:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 20:15:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 20:15:26 --> User Agent Class Initialized
INFO - 2018-04-19 20:15:26 --> Controller Class Initialized
INFO - 2018-04-19 20:15:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 20:15:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 20:15:26 --> CSRF cookie sent
INFO - 2018-04-19 20:15:26 --> Config Class Initialized
INFO - 2018-04-19 20:15:26 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:15:26 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:15:26 --> Utf8 Class Initialized
INFO - 2018-04-19 20:15:26 --> URI Class Initialized
DEBUG - 2018-04-19 20:15:27 --> No URI present. Default controller set.
INFO - 2018-04-19 20:15:27 --> Router Class Initialized
INFO - 2018-04-19 20:15:27 --> Output Class Initialized
INFO - 2018-04-19 20:15:27 --> Security Class Initialized
DEBUG - 2018-04-19 20:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:15:27 --> CSRF cookie sent
INFO - 2018-04-19 20:15:27 --> Input Class Initialized
INFO - 2018-04-19 20:15:27 --> Language Class Initialized
INFO - 2018-04-19 20:15:27 --> Loader Class Initialized
INFO - 2018-04-19 20:15:27 --> Helper loaded: url_helper
INFO - 2018-04-19 20:15:27 --> Helper loaded: form_helper
INFO - 2018-04-19 20:15:27 --> Helper loaded: language_helper
DEBUG - 2018-04-19 20:15:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 20:15:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 20:15:27 --> User Agent Class Initialized
INFO - 2018-04-19 20:15:27 --> Controller Class Initialized
INFO - 2018-04-19 20:15:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 20:15:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 20:15:27 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 20:15:27 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 20:15:27 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-19 20:15:27 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 20:15:27 --> Final output sent to browser
DEBUG - 2018-04-19 20:15:27 --> Total execution time: 0.3714
INFO - 2018-04-19 20:15:27 --> Config Class Initialized
INFO - 2018-04-19 20:15:27 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:15:27 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:15:27 --> Utf8 Class Initialized
INFO - 2018-04-19 20:15:27 --> URI Class Initialized
INFO - 2018-04-19 20:15:27 --> Router Class Initialized
INFO - 2018-04-19 20:15:27 --> Output Class Initialized
INFO - 2018-04-19 20:15:27 --> Security Class Initialized
DEBUG - 2018-04-19 20:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:15:27 --> CSRF cookie sent
INFO - 2018-04-19 20:15:27 --> Input Class Initialized
INFO - 2018-04-19 20:15:27 --> Language Class Initialized
ERROR - 2018-04-19 20:15:27 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 20:15:29 --> Config Class Initialized
INFO - 2018-04-19 20:15:29 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:15:29 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:15:29 --> Utf8 Class Initialized
INFO - 2018-04-19 20:15:29 --> URI Class Initialized
INFO - 2018-04-19 20:15:29 --> Router Class Initialized
INFO - 2018-04-19 20:15:29 --> Output Class Initialized
INFO - 2018-04-19 20:15:29 --> Security Class Initialized
DEBUG - 2018-04-19 20:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:15:29 --> CSRF cookie sent
INFO - 2018-04-19 20:15:29 --> Input Class Initialized
INFO - 2018-04-19 20:15:29 --> Language Class Initialized
ERROR - 2018-04-19 20:15:29 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-19 20:15:45 --> Config Class Initialized
INFO - 2018-04-19 20:15:45 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:15:45 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:15:45 --> Utf8 Class Initialized
INFO - 2018-04-19 20:15:45 --> URI Class Initialized
INFO - 2018-04-19 20:15:45 --> Router Class Initialized
INFO - 2018-04-19 20:15:45 --> Output Class Initialized
INFO - 2018-04-19 20:15:45 --> Security Class Initialized
DEBUG - 2018-04-19 20:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:15:45 --> CSRF cookie sent
INFO - 2018-04-19 20:15:45 --> Input Class Initialized
INFO - 2018-04-19 20:15:45 --> Language Class Initialized
INFO - 2018-04-19 20:15:46 --> Loader Class Initialized
INFO - 2018-04-19 20:15:46 --> Helper loaded: url_helper
INFO - 2018-04-19 20:15:46 --> Helper loaded: form_helper
INFO - 2018-04-19 20:15:46 --> Helper loaded: language_helper
DEBUG - 2018-04-19 20:15:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 20:15:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 20:15:46 --> User Agent Class Initialized
INFO - 2018-04-19 20:15:46 --> Controller Class Initialized
INFO - 2018-04-19 20:15:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 20:15:46 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-19 20:15:46 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-19 20:15:46 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 20:15:46 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 20:15:46 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-19 20:15:46 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-19 20:15:46 --> Could not find the language line "req_email"
INFO - 2018-04-19 20:15:46 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-04-19 20:15:46 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 20:15:46 --> Final output sent to browser
DEBUG - 2018-04-19 20:15:46 --> Total execution time: 0.4123
INFO - 2018-04-19 20:15:46 --> Config Class Initialized
INFO - 2018-04-19 20:15:46 --> Hooks Class Initialized
INFO - 2018-04-19 20:15:46 --> Config Class Initialized
INFO - 2018-04-19 20:15:46 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:15:46 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:15:46 --> Utf8 Class Initialized
DEBUG - 2018-04-19 20:15:46 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:15:46 --> Utf8 Class Initialized
INFO - 2018-04-19 20:15:46 --> URI Class Initialized
INFO - 2018-04-19 20:15:46 --> URI Class Initialized
INFO - 2018-04-19 20:15:46 --> Router Class Initialized
INFO - 2018-04-19 20:15:46 --> Router Class Initialized
INFO - 2018-04-19 20:15:46 --> Output Class Initialized
INFO - 2018-04-19 20:15:46 --> Output Class Initialized
INFO - 2018-04-19 20:15:46 --> Security Class Initialized
INFO - 2018-04-19 20:15:46 --> Security Class Initialized
DEBUG - 2018-04-19 20:15:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-19 20:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:15:46 --> CSRF cookie sent
INFO - 2018-04-19 20:15:46 --> CSRF cookie sent
INFO - 2018-04-19 20:15:46 --> Input Class Initialized
INFO - 2018-04-19 20:15:46 --> Input Class Initialized
INFO - 2018-04-19 20:15:46 --> Language Class Initialized
INFO - 2018-04-19 20:15:46 --> Language Class Initialized
ERROR - 2018-04-19 20:15:46 --> 404 Page Not Found: Assets/css
ERROR - 2018-04-19 20:15:46 --> 404 Page Not Found: Assets/images
INFO - 2018-04-19 20:15:51 --> Config Class Initialized
INFO - 2018-04-19 20:15:51 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:15:51 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:15:51 --> Utf8 Class Initialized
INFO - 2018-04-19 20:15:51 --> URI Class Initialized
INFO - 2018-04-19 20:15:51 --> Router Class Initialized
INFO - 2018-04-19 20:15:51 --> Output Class Initialized
INFO - 2018-04-19 20:15:51 --> Security Class Initialized
DEBUG - 2018-04-19 20:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:15:51 --> CSRF cookie sent
INFO - 2018-04-19 20:15:52 --> CSRF token verified
INFO - 2018-04-19 20:15:52 --> Input Class Initialized
INFO - 2018-04-19 20:15:52 --> Language Class Initialized
INFO - 2018-04-19 20:15:52 --> Loader Class Initialized
INFO - 2018-04-19 20:15:52 --> Helper loaded: url_helper
INFO - 2018-04-19 20:15:52 --> Helper loaded: form_helper
INFO - 2018-04-19 20:15:52 --> Helper loaded: language_helper
DEBUG - 2018-04-19 20:15:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 20:15:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 20:15:52 --> User Agent Class Initialized
INFO - 2018-04-19 20:15:52 --> Controller Class Initialized
INFO - 2018-04-19 20:15:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 20:15:52 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-19 20:15:52 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-19 20:15:52 --> Form Validation Class Initialized
INFO - 2018-04-19 20:15:52 --> Pixel_Model class loaded
INFO - 2018-04-19 20:15:52 --> Database Driver Class Initialized
INFO - 2018-04-19 20:15:52 --> Model "AuthenticationModel" initialized
INFO - 2018-04-19 20:15:52 --> Config Class Initialized
INFO - 2018-04-19 20:15:52 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:15:52 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:15:52 --> Utf8 Class Initialized
INFO - 2018-04-19 20:15:52 --> URI Class Initialized
DEBUG - 2018-04-19 20:15:52 --> No URI present. Default controller set.
INFO - 2018-04-19 20:15:52 --> Router Class Initialized
INFO - 2018-04-19 20:15:52 --> Output Class Initialized
INFO - 2018-04-19 20:15:52 --> Security Class Initialized
DEBUG - 2018-04-19 20:15:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:15:52 --> CSRF cookie sent
INFO - 2018-04-19 20:15:52 --> Input Class Initialized
INFO - 2018-04-19 20:15:52 --> Language Class Initialized
INFO - 2018-04-19 20:15:53 --> Loader Class Initialized
INFO - 2018-04-19 20:15:53 --> Helper loaded: url_helper
INFO - 2018-04-19 20:15:53 --> Helper loaded: form_helper
INFO - 2018-04-19 20:15:53 --> Helper loaded: language_helper
DEBUG - 2018-04-19 20:15:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 20:15:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 20:15:53 --> User Agent Class Initialized
INFO - 2018-04-19 20:15:53 --> Controller Class Initialized
INFO - 2018-04-19 20:15:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 20:15:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 20:15:53 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 20:15:53 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-19 20:15:53 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 20:15:53 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-19 20:15:53 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 20:15:53 --> Final output sent to browser
DEBUG - 2018-04-19 20:15:53 --> Total execution time: 0.3658
INFO - 2018-04-19 20:15:53 --> Config Class Initialized
INFO - 2018-04-19 20:15:53 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:15:53 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:15:53 --> Utf8 Class Initialized
INFO - 2018-04-19 20:15:53 --> URI Class Initialized
INFO - 2018-04-19 20:15:53 --> Router Class Initialized
INFO - 2018-04-19 20:15:53 --> Output Class Initialized
INFO - 2018-04-19 20:15:53 --> Security Class Initialized
DEBUG - 2018-04-19 20:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:15:53 --> CSRF cookie sent
INFO - 2018-04-19 20:15:53 --> Input Class Initialized
INFO - 2018-04-19 20:15:53 --> Language Class Initialized
ERROR - 2018-04-19 20:15:53 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 20:15:55 --> Config Class Initialized
INFO - 2018-04-19 20:15:55 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:15:55 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:15:55 --> Utf8 Class Initialized
INFO - 2018-04-19 20:15:55 --> URI Class Initialized
INFO - 2018-04-19 20:15:55 --> Router Class Initialized
INFO - 2018-04-19 20:15:55 --> Output Class Initialized
INFO - 2018-04-19 20:15:55 --> Security Class Initialized
DEBUG - 2018-04-19 20:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:15:55 --> CSRF cookie sent
INFO - 2018-04-19 20:15:56 --> Input Class Initialized
INFO - 2018-04-19 20:15:56 --> Language Class Initialized
ERROR - 2018-04-19 20:15:56 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-19 20:15:57 --> Config Class Initialized
INFO - 2018-04-19 20:15:57 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:15:57 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:15:57 --> Utf8 Class Initialized
INFO - 2018-04-19 20:15:57 --> URI Class Initialized
INFO - 2018-04-19 20:15:57 --> Router Class Initialized
INFO - 2018-04-19 20:15:57 --> Output Class Initialized
INFO - 2018-04-19 20:15:57 --> Security Class Initialized
DEBUG - 2018-04-19 20:15:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:15:57 --> CSRF cookie sent
INFO - 2018-04-19 20:15:57 --> Input Class Initialized
INFO - 2018-04-19 20:15:57 --> Language Class Initialized
INFO - 2018-04-19 20:15:57 --> Loader Class Initialized
INFO - 2018-04-19 20:15:58 --> Helper loaded: url_helper
INFO - 2018-04-19 20:15:58 --> Helper loaded: form_helper
INFO - 2018-04-19 20:15:58 --> Helper loaded: language_helper
DEBUG - 2018-04-19 20:15:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 20:15:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 20:15:58 --> User Agent Class Initialized
INFO - 2018-04-19 20:15:58 --> Controller Class Initialized
INFO - 2018-04-19 20:15:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 20:15:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 20:15:58 --> Pixel_Model class loaded
INFO - 2018-04-19 20:15:58 --> Database Driver Class Initialized
INFO - 2018-04-19 20:15:58 --> Model "MyAccountModel" initialized
INFO - 2018-04-19 20:15:58 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 20:15:58 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-19 20:15:58 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 20:15:58 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-19 20:15:58 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-19 20:15:58 --> File loaded: E:\www\yacopoo\application\views\register/import_fa.php
INFO - 2018-04-19 20:15:58 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 20:15:58 --> Final output sent to browser
DEBUG - 2018-04-19 20:15:58 --> Total execution time: 0.5198
INFO - 2018-04-19 20:15:58 --> Config Class Initialized
INFO - 2018-04-19 20:15:58 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:15:58 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:15:58 --> Utf8 Class Initialized
INFO - 2018-04-19 20:15:58 --> URI Class Initialized
INFO - 2018-04-19 20:15:58 --> Router Class Initialized
INFO - 2018-04-19 20:15:58 --> Output Class Initialized
INFO - 2018-04-19 20:15:58 --> Security Class Initialized
DEBUG - 2018-04-19 20:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:15:58 --> CSRF cookie sent
INFO - 2018-04-19 20:15:58 --> Input Class Initialized
INFO - 2018-04-19 20:15:58 --> Language Class Initialized
ERROR - 2018-04-19 20:15:58 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 20:16:56 --> Config Class Initialized
INFO - 2018-04-19 20:16:56 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:16:56 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:16:56 --> Utf8 Class Initialized
INFO - 2018-04-19 20:16:56 --> URI Class Initialized
INFO - 2018-04-19 20:16:56 --> Router Class Initialized
INFO - 2018-04-19 20:16:56 --> Output Class Initialized
INFO - 2018-04-19 20:16:56 --> Security Class Initialized
DEBUG - 2018-04-19 20:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:16:56 --> CSRF cookie sent
INFO - 2018-04-19 20:16:56 --> Input Class Initialized
INFO - 2018-04-19 20:16:56 --> Language Class Initialized
INFO - 2018-04-19 20:16:56 --> Loader Class Initialized
INFO - 2018-04-19 20:16:56 --> Helper loaded: url_helper
INFO - 2018-04-19 20:16:56 --> Helper loaded: form_helper
INFO - 2018-04-19 20:16:56 --> Helper loaded: language_helper
DEBUG - 2018-04-19 20:16:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 20:16:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 20:16:56 --> User Agent Class Initialized
INFO - 2018-04-19 20:16:56 --> Controller Class Initialized
INFO - 2018-04-19 20:16:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 20:16:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 20:16:57 --> Pixel_Model class loaded
INFO - 2018-04-19 20:16:57 --> Database Driver Class Initialized
INFO - 2018-04-19 20:16:57 --> Model "MyAccountModel" initialized
INFO - 2018-04-19 20:16:57 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 20:16:57 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-19 20:16:57 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 20:16:57 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-19 20:16:57 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-19 20:16:57 --> File loaded: E:\www\yacopoo\application\views\register/import_fa.php
INFO - 2018-04-19 20:16:57 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 20:16:57 --> Final output sent to browser
DEBUG - 2018-04-19 20:16:57 --> Total execution time: 0.4621
INFO - 2018-04-19 20:16:57 --> Config Class Initialized
INFO - 2018-04-19 20:16:57 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:16:57 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:16:57 --> Utf8 Class Initialized
INFO - 2018-04-19 20:16:57 --> URI Class Initialized
INFO - 2018-04-19 20:16:57 --> Router Class Initialized
INFO - 2018-04-19 20:16:57 --> Output Class Initialized
INFO - 2018-04-19 20:16:57 --> Security Class Initialized
DEBUG - 2018-04-19 20:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:16:57 --> CSRF cookie sent
INFO - 2018-04-19 20:16:57 --> Input Class Initialized
INFO - 2018-04-19 20:16:57 --> Language Class Initialized
ERROR - 2018-04-19 20:16:57 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 20:18:03 --> Config Class Initialized
INFO - 2018-04-19 20:18:03 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:18:03 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:18:03 --> Utf8 Class Initialized
INFO - 2018-04-19 20:18:03 --> URI Class Initialized
INFO - 2018-04-19 20:18:03 --> Router Class Initialized
INFO - 2018-04-19 20:18:03 --> Output Class Initialized
INFO - 2018-04-19 20:18:03 --> Security Class Initialized
DEBUG - 2018-04-19 20:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:18:03 --> CSRF cookie sent
INFO - 2018-04-19 20:18:03 --> Input Class Initialized
INFO - 2018-04-19 20:18:03 --> Language Class Initialized
INFO - 2018-04-19 20:18:03 --> Loader Class Initialized
INFO - 2018-04-19 20:18:03 --> Helper loaded: url_helper
INFO - 2018-04-19 20:18:03 --> Helper loaded: form_helper
INFO - 2018-04-19 20:18:03 --> Helper loaded: language_helper
DEBUG - 2018-04-19 20:18:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 20:18:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 20:18:03 --> User Agent Class Initialized
INFO - 2018-04-19 20:18:03 --> Controller Class Initialized
INFO - 2018-04-19 20:18:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 20:18:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 20:18:03 --> Pixel_Model class loaded
INFO - 2018-04-19 20:18:03 --> Database Driver Class Initialized
INFO - 2018-04-19 20:18:03 --> Model "MyAccountModel" initialized
INFO - 2018-04-19 20:18:03 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 20:18:03 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-19 20:18:03 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 20:18:03 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-19 20:18:03 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-19 20:18:03 --> File loaded: E:\www\yacopoo\application\views\register/import_fa.php
INFO - 2018-04-19 20:18:03 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 20:18:03 --> Final output sent to browser
DEBUG - 2018-04-19 20:18:03 --> Total execution time: 0.4813
INFO - 2018-04-19 20:18:04 --> Config Class Initialized
INFO - 2018-04-19 20:18:04 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:18:04 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:18:04 --> Utf8 Class Initialized
INFO - 2018-04-19 20:18:04 --> URI Class Initialized
INFO - 2018-04-19 20:18:04 --> Router Class Initialized
INFO - 2018-04-19 20:18:04 --> Output Class Initialized
INFO - 2018-04-19 20:18:04 --> Security Class Initialized
DEBUG - 2018-04-19 20:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:18:04 --> CSRF cookie sent
INFO - 2018-04-19 20:18:04 --> Input Class Initialized
INFO - 2018-04-19 20:18:04 --> Language Class Initialized
ERROR - 2018-04-19 20:18:04 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 20:18:49 --> Config Class Initialized
INFO - 2018-04-19 20:18:49 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:18:49 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:18:49 --> Utf8 Class Initialized
INFO - 2018-04-19 20:18:49 --> URI Class Initialized
INFO - 2018-04-19 20:18:49 --> Router Class Initialized
INFO - 2018-04-19 20:18:49 --> Output Class Initialized
INFO - 2018-04-19 20:18:49 --> Security Class Initialized
DEBUG - 2018-04-19 20:18:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:18:49 --> CSRF cookie sent
INFO - 2018-04-19 20:18:49 --> Input Class Initialized
INFO - 2018-04-19 20:18:49 --> Language Class Initialized
INFO - 2018-04-19 20:18:49 --> Loader Class Initialized
INFO - 2018-04-19 20:18:49 --> Helper loaded: url_helper
INFO - 2018-04-19 20:18:49 --> Helper loaded: form_helper
INFO - 2018-04-19 20:18:49 --> Helper loaded: language_helper
DEBUG - 2018-04-19 20:18:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 20:18:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 20:18:49 --> User Agent Class Initialized
INFO - 2018-04-19 20:18:49 --> Controller Class Initialized
INFO - 2018-04-19 20:18:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 20:18:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 20:18:49 --> Pixel_Model class loaded
INFO - 2018-04-19 20:18:49 --> Database Driver Class Initialized
INFO - 2018-04-19 20:18:49 --> Model "MyAccountModel" initialized
INFO - 2018-04-19 20:18:49 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 20:18:49 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-19 20:18:49 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 20:18:49 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-19 20:18:49 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-19 20:18:49 --> File loaded: E:\www\yacopoo\application\views\register/import_fa.php
INFO - 2018-04-19 20:18:49 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 20:18:49 --> Final output sent to browser
DEBUG - 2018-04-19 20:18:49 --> Total execution time: 0.4691
INFO - 2018-04-19 20:18:50 --> Config Class Initialized
INFO - 2018-04-19 20:18:50 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:18:50 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:18:50 --> Utf8 Class Initialized
INFO - 2018-04-19 20:18:50 --> URI Class Initialized
INFO - 2018-04-19 20:18:50 --> Router Class Initialized
INFO - 2018-04-19 20:18:50 --> Output Class Initialized
INFO - 2018-04-19 20:18:50 --> Security Class Initialized
DEBUG - 2018-04-19 20:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:18:50 --> CSRF cookie sent
INFO - 2018-04-19 20:18:50 --> Input Class Initialized
INFO - 2018-04-19 20:18:50 --> Language Class Initialized
ERROR - 2018-04-19 20:18:50 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 20:20:52 --> Config Class Initialized
INFO - 2018-04-19 20:20:52 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:20:52 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:20:52 --> Utf8 Class Initialized
INFO - 2018-04-19 20:20:52 --> URI Class Initialized
INFO - 2018-04-19 20:20:52 --> Router Class Initialized
INFO - 2018-04-19 20:20:52 --> Output Class Initialized
INFO - 2018-04-19 20:20:53 --> Security Class Initialized
DEBUG - 2018-04-19 20:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:20:53 --> CSRF cookie sent
INFO - 2018-04-19 20:20:53 --> Input Class Initialized
INFO - 2018-04-19 20:20:53 --> Language Class Initialized
INFO - 2018-04-19 20:20:53 --> Loader Class Initialized
INFO - 2018-04-19 20:20:53 --> Helper loaded: url_helper
INFO - 2018-04-19 20:20:53 --> Helper loaded: form_helper
INFO - 2018-04-19 20:20:53 --> Helper loaded: language_helper
DEBUG - 2018-04-19 20:20:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 20:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 20:20:53 --> User Agent Class Initialized
INFO - 2018-04-19 20:20:53 --> Controller Class Initialized
INFO - 2018-04-19 20:20:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 20:20:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 20:20:53 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 20:20:53 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-19 20:20:53 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 20:20:53 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-19 20:20:53 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-19 20:20:53 --> File loaded: E:\www\yacopoo\application\views\register/import_fa.php
INFO - 2018-04-19 20:20:53 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 20:20:53 --> Final output sent to browser
DEBUG - 2018-04-19 20:20:53 --> Total execution time: 0.4203
INFO - 2018-04-19 20:20:53 --> Config Class Initialized
INFO - 2018-04-19 20:20:53 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:20:53 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:20:53 --> Utf8 Class Initialized
INFO - 2018-04-19 20:20:53 --> URI Class Initialized
INFO - 2018-04-19 20:20:53 --> Router Class Initialized
INFO - 2018-04-19 20:20:53 --> Output Class Initialized
INFO - 2018-04-19 20:20:53 --> Security Class Initialized
DEBUG - 2018-04-19 20:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:20:53 --> CSRF cookie sent
INFO - 2018-04-19 20:20:53 --> Input Class Initialized
INFO - 2018-04-19 20:20:53 --> Language Class Initialized
ERROR - 2018-04-19 20:20:53 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 20:20:59 --> Config Class Initialized
INFO - 2018-04-19 20:20:59 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:20:59 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:20:59 --> Utf8 Class Initialized
INFO - 2018-04-19 20:20:59 --> URI Class Initialized
INFO - 2018-04-19 20:20:59 --> Router Class Initialized
INFO - 2018-04-19 20:20:59 --> Output Class Initialized
INFO - 2018-04-19 20:20:59 --> Security Class Initialized
DEBUG - 2018-04-19 20:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:20:59 --> CSRF cookie sent
INFO - 2018-04-19 20:20:59 --> CSRF token verified
INFO - 2018-04-19 20:20:59 --> Input Class Initialized
INFO - 2018-04-19 20:20:59 --> Language Class Initialized
INFO - 2018-04-19 20:20:59 --> Loader Class Initialized
INFO - 2018-04-19 20:20:59 --> Helper loaded: url_helper
INFO - 2018-04-19 20:20:59 --> Helper loaded: form_helper
INFO - 2018-04-19 20:20:59 --> Helper loaded: language_helper
DEBUG - 2018-04-19 20:20:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 20:20:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 20:20:59 --> User Agent Class Initialized
INFO - 2018-04-19 20:20:59 --> Controller Class Initialized
INFO - 2018-04-19 20:20:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 20:20:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 20:20:59 --> Upload Class Initialized
INFO - 2018-04-19 20:20:59 --> Pixel_Model class loaded
INFO - 2018-04-19 20:20:59 --> Database Driver Class Initialized
INFO - 2018-04-19 20:20:59 --> Model "RegistrationModel" initialized
INFO - 2018-04-19 20:20:59 --> Database Driver Class Initialized
INFO - 2018-04-19 20:20:59 --> Model "RegistrationModel" initialized
INFO - 2018-04-19 20:20:59 --> Helper loaded: string_helper
INFO - 2018-04-19 20:20:59 --> Language file loaded: language/en/notifications_lang.php
INFO - 2018-04-19 20:21:00 --> File loaded: E:\www\yacopoo\application\views\emails/_buttons.php
INFO - 2018-04-19 20:21:00 --> File loaded: E:\www\yacopoo\application\views\emails/header.php
INFO - 2018-04-19 20:21:00 --> File loaded: E:\www\yacopoo\application\views\emails/footer.php
INFO - 2018-04-19 20:21:00 --> File loaded: E:\www\yacopoo\application\views\emails/generic.php
INFO - 2018-04-19 20:21:00 --> Email Class Initialized
DEBUG - 2018-04-19 20:21:00 --> EmailsHelper class already loaded. Second attempt ignored.
INFO - 2018-04-19 20:21:00 --> File loaded: E:\www\yacopoo\application\views\emails/_buttons.php
INFO - 2018-04-19 20:21:00 --> File loaded: E:\www\yacopoo\application\views\emails/header.php
INFO - 2018-04-19 20:21:00 --> File loaded: E:\www\yacopoo\application\views\emails/footer.php
INFO - 2018-04-19 20:21:00 --> File loaded: E:\www\yacopoo\application\views\emails/generic.php
DEBUG - 2018-04-19 20:21:00 --> Email class already loaded. Second attempt ignored.
INFO - 2018-04-19 20:21:00 --> Config Class Initialized
INFO - 2018-04-19 20:21:00 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:21:00 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:21:00 --> Utf8 Class Initialized
INFO - 2018-04-19 20:21:00 --> URI Class Initialized
INFO - 2018-04-19 20:21:00 --> Router Class Initialized
INFO - 2018-04-19 20:21:00 --> Output Class Initialized
INFO - 2018-04-19 20:21:00 --> Security Class Initialized
DEBUG - 2018-04-19 20:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:21:00 --> CSRF cookie sent
INFO - 2018-04-19 20:21:00 --> Input Class Initialized
INFO - 2018-04-19 20:21:00 --> Language Class Initialized
DEBUG - 2018-04-19 20:21:00 --> EmailsHelper class already loaded. Second attempt ignored.
INFO - 2018-04-19 20:21:00 --> File loaded: E:\www\yacopoo\application\views\emails/_buttons.php
ERROR - 2018-04-19 20:21:00 --> 404 Page Not Found: Assets/images
INFO - 2018-04-19 20:21:00 --> File loaded: E:\www\yacopoo\application\views\emails/header.php
INFO - 2018-04-19 20:21:00 --> File loaded: E:\www\yacopoo\application\views\emails/footer.php
INFO - 2018-04-19 20:21:00 --> File loaded: E:\www\yacopoo\application\views\emails/generic.php
DEBUG - 2018-04-19 20:21:00 --> Email class already loaded. Second attempt ignored.
ERROR - 2018-04-19 20:21:00 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at E:\www\yacopoo\application\controllers\RegistrationController.php:836) E:\www\yacopoo\system\helpers\url_helper.php 564
INFO - 2018-04-19 20:21:00 --> Config Class Initialized
INFO - 2018-04-19 20:21:00 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:21:00 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:21:00 --> Utf8 Class Initialized
INFO - 2018-04-19 20:21:00 --> URI Class Initialized
INFO - 2018-04-19 20:21:00 --> Router Class Initialized
INFO - 2018-04-19 20:21:00 --> Output Class Initialized
INFO - 2018-04-19 20:21:01 --> Security Class Initialized
DEBUG - 2018-04-19 20:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:21:01 --> CSRF cookie sent
INFO - 2018-04-19 20:21:01 --> Input Class Initialized
INFO - 2018-04-19 20:21:01 --> Language Class Initialized
ERROR - 2018-04-19 20:21:01 --> 404 Page Not Found: Assets/images
INFO - 2018-04-19 20:21:05 --> Config Class Initialized
INFO - 2018-04-19 20:21:05 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:21:05 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:21:05 --> Utf8 Class Initialized
INFO - 2018-04-19 20:21:05 --> URI Class Initialized
INFO - 2018-04-19 20:21:05 --> Router Class Initialized
INFO - 2018-04-19 20:21:05 --> Output Class Initialized
INFO - 2018-04-19 20:21:05 --> Security Class Initialized
DEBUG - 2018-04-19 20:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:21:05 --> CSRF cookie sent
INFO - 2018-04-19 20:21:05 --> Input Class Initialized
INFO - 2018-04-19 20:21:05 --> Language Class Initialized
INFO - 2018-04-19 20:21:06 --> Loader Class Initialized
INFO - 2018-04-19 20:21:06 --> Helper loaded: url_helper
INFO - 2018-04-19 20:21:06 --> Helper loaded: form_helper
INFO - 2018-04-19 20:21:06 --> Helper loaded: language_helper
DEBUG - 2018-04-19 20:21:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 20:21:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 20:21:06 --> User Agent Class Initialized
INFO - 2018-04-19 20:21:06 --> Controller Class Initialized
INFO - 2018-04-19 20:21:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 20:21:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 20:21:06 --> Config Class Initialized
INFO - 2018-04-19 20:21:06 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:21:06 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:21:06 --> Utf8 Class Initialized
INFO - 2018-04-19 20:21:06 --> URI Class Initialized
DEBUG - 2018-04-19 20:21:06 --> No URI present. Default controller set.
INFO - 2018-04-19 20:21:06 --> Router Class Initialized
INFO - 2018-04-19 20:21:06 --> Output Class Initialized
INFO - 2018-04-19 20:21:06 --> Security Class Initialized
DEBUG - 2018-04-19 20:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:21:06 --> CSRF cookie sent
INFO - 2018-04-19 20:21:06 --> Input Class Initialized
INFO - 2018-04-19 20:21:06 --> Language Class Initialized
INFO - 2018-04-19 20:21:06 --> Loader Class Initialized
INFO - 2018-04-19 20:21:06 --> Helper loaded: url_helper
INFO - 2018-04-19 20:21:06 --> Helper loaded: form_helper
INFO - 2018-04-19 20:21:06 --> Helper loaded: language_helper
DEBUG - 2018-04-19 20:21:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 20:21:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 20:21:06 --> User Agent Class Initialized
INFO - 2018-04-19 20:21:06 --> Controller Class Initialized
INFO - 2018-04-19 20:21:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 20:21:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 20:21:06 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 20:21:06 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-19 20:21:06 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 20:21:06 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-19 20:21:06 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 20:21:06 --> Final output sent to browser
DEBUG - 2018-04-19 20:21:06 --> Total execution time: 0.3925
INFO - 2018-04-19 20:21:06 --> Config Class Initialized
INFO - 2018-04-19 20:21:06 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:21:06 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:21:06 --> Utf8 Class Initialized
INFO - 2018-04-19 20:21:07 --> URI Class Initialized
INFO - 2018-04-19 20:21:07 --> Router Class Initialized
INFO - 2018-04-19 20:21:07 --> Output Class Initialized
INFO - 2018-04-19 20:21:07 --> Security Class Initialized
DEBUG - 2018-04-19 20:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:21:07 --> CSRF cookie sent
INFO - 2018-04-19 20:21:07 --> Input Class Initialized
INFO - 2018-04-19 20:21:07 --> Language Class Initialized
ERROR - 2018-04-19 20:21:07 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 20:21:08 --> Config Class Initialized
INFO - 2018-04-19 20:21:08 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:21:08 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:21:08 --> Utf8 Class Initialized
INFO - 2018-04-19 20:21:08 --> URI Class Initialized
INFO - 2018-04-19 20:21:08 --> Router Class Initialized
INFO - 2018-04-19 20:21:08 --> Output Class Initialized
INFO - 2018-04-19 20:21:08 --> Security Class Initialized
DEBUG - 2018-04-19 20:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:21:08 --> CSRF cookie sent
INFO - 2018-04-19 20:21:09 --> Input Class Initialized
INFO - 2018-04-19 20:21:09 --> Language Class Initialized
ERROR - 2018-04-19 20:21:09 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-19 20:21:12 --> Config Class Initialized
INFO - 2018-04-19 20:21:12 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:21:12 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:21:12 --> Utf8 Class Initialized
INFO - 2018-04-19 20:21:12 --> URI Class Initialized
INFO - 2018-04-19 20:21:12 --> Router Class Initialized
INFO - 2018-04-19 20:21:12 --> Output Class Initialized
INFO - 2018-04-19 20:21:12 --> Security Class Initialized
DEBUG - 2018-04-19 20:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:21:12 --> CSRF cookie sent
INFO - 2018-04-19 20:21:12 --> Input Class Initialized
INFO - 2018-04-19 20:21:12 --> Language Class Initialized
INFO - 2018-04-19 20:21:12 --> Loader Class Initialized
INFO - 2018-04-19 20:21:12 --> Helper loaded: url_helper
INFO - 2018-04-19 20:21:12 --> Helper loaded: form_helper
INFO - 2018-04-19 20:21:12 --> Helper loaded: language_helper
DEBUG - 2018-04-19 20:21:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 20:21:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 20:21:12 --> User Agent Class Initialized
INFO - 2018-04-19 20:21:12 --> Controller Class Initialized
INFO - 2018-04-19 20:21:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 20:21:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 20:21:12 --> CSRF cookie sent
INFO - 2018-04-19 20:21:12 --> Config Class Initialized
INFO - 2018-04-19 20:21:12 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:21:12 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:21:12 --> Utf8 Class Initialized
INFO - 2018-04-19 20:21:12 --> URI Class Initialized
DEBUG - 2018-04-19 20:21:12 --> No URI present. Default controller set.
INFO - 2018-04-19 20:21:12 --> Router Class Initialized
INFO - 2018-04-19 20:21:12 --> Output Class Initialized
INFO - 2018-04-19 20:21:12 --> Security Class Initialized
DEBUG - 2018-04-19 20:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:21:12 --> CSRF cookie sent
INFO - 2018-04-19 20:21:12 --> Input Class Initialized
INFO - 2018-04-19 20:21:12 --> Language Class Initialized
INFO - 2018-04-19 20:21:12 --> Loader Class Initialized
INFO - 2018-04-19 20:21:12 --> Helper loaded: url_helper
INFO - 2018-04-19 20:21:12 --> Helper loaded: form_helper
INFO - 2018-04-19 20:21:12 --> Helper loaded: language_helper
DEBUG - 2018-04-19 20:21:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 20:21:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 20:21:12 --> User Agent Class Initialized
INFO - 2018-04-19 20:21:12 --> Controller Class Initialized
INFO - 2018-04-19 20:21:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 20:21:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 20:21:12 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 20:21:12 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 20:21:12 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-19 20:21:12 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 20:21:12 --> Final output sent to browser
DEBUG - 2018-04-19 20:21:13 --> Total execution time: 0.3913
INFO - 2018-04-19 20:21:13 --> Config Class Initialized
INFO - 2018-04-19 20:21:13 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:21:13 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:21:13 --> Utf8 Class Initialized
INFO - 2018-04-19 20:21:13 --> URI Class Initialized
INFO - 2018-04-19 20:21:13 --> Router Class Initialized
INFO - 2018-04-19 20:21:13 --> Output Class Initialized
INFO - 2018-04-19 20:21:13 --> Security Class Initialized
DEBUG - 2018-04-19 20:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:21:13 --> CSRF cookie sent
INFO - 2018-04-19 20:21:13 --> Input Class Initialized
INFO - 2018-04-19 20:21:13 --> Language Class Initialized
ERROR - 2018-04-19 20:21:13 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 20:21:14 --> Config Class Initialized
INFO - 2018-04-19 20:21:14 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:21:14 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:21:14 --> Utf8 Class Initialized
INFO - 2018-04-19 20:21:14 --> URI Class Initialized
INFO - 2018-04-19 20:21:14 --> Router Class Initialized
INFO - 2018-04-19 20:21:14 --> Output Class Initialized
INFO - 2018-04-19 20:21:14 --> Security Class Initialized
DEBUG - 2018-04-19 20:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:21:14 --> CSRF cookie sent
INFO - 2018-04-19 20:21:15 --> Input Class Initialized
INFO - 2018-04-19 20:21:15 --> Language Class Initialized
ERROR - 2018-04-19 20:21:15 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-19 20:21:23 --> Config Class Initialized
INFO - 2018-04-19 20:21:23 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:21:23 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:21:23 --> Utf8 Class Initialized
INFO - 2018-04-19 20:21:23 --> URI Class Initialized
INFO - 2018-04-19 20:21:23 --> Router Class Initialized
INFO - 2018-04-19 20:21:23 --> Output Class Initialized
INFO - 2018-04-19 20:21:23 --> Security Class Initialized
DEBUG - 2018-04-19 20:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:21:23 --> CSRF cookie sent
INFO - 2018-04-19 20:21:23 --> Input Class Initialized
INFO - 2018-04-19 20:21:23 --> Language Class Initialized
INFO - 2018-04-19 20:21:23 --> Loader Class Initialized
INFO - 2018-04-19 20:21:23 --> Helper loaded: url_helper
INFO - 2018-04-19 20:21:24 --> Helper loaded: form_helper
INFO - 2018-04-19 20:21:24 --> Helper loaded: language_helper
DEBUG - 2018-04-19 20:21:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 20:21:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 20:21:24 --> User Agent Class Initialized
INFO - 2018-04-19 20:21:24 --> Controller Class Initialized
INFO - 2018-04-19 20:21:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 20:21:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 20:21:24 --> Pixel_Model class loaded
INFO - 2018-04-19 20:21:24 --> Database Driver Class Initialized
INFO - 2018-04-19 20:21:24 --> Model "RegistrationModel" initialized
INFO - 2018-04-19 20:21:24 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 20:21:24 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 20:21:24 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-19 20:21:24 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-19 20:21:24 --> File loaded: E:\www\yacopoo\application\views\register/complete_registration.php
INFO - 2018-04-19 20:21:24 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 20:21:24 --> Final output sent to browser
DEBUG - 2018-04-19 20:21:24 --> Total execution time: 0.5270
INFO - 2018-04-19 20:21:24 --> Config Class Initialized
INFO - 2018-04-19 20:21:24 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:21:24 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:21:24 --> Utf8 Class Initialized
INFO - 2018-04-19 20:21:24 --> URI Class Initialized
INFO - 2018-04-19 20:21:24 --> Router Class Initialized
INFO - 2018-04-19 20:21:24 --> Output Class Initialized
INFO - 2018-04-19 20:21:24 --> Security Class Initialized
DEBUG - 2018-04-19 20:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:21:24 --> CSRF cookie sent
INFO - 2018-04-19 20:21:24 --> Input Class Initialized
INFO - 2018-04-19 20:21:24 --> Language Class Initialized
ERROR - 2018-04-19 20:21:24 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 20:21:40 --> Config Class Initialized
INFO - 2018-04-19 20:21:40 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:21:40 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:21:40 --> Utf8 Class Initialized
INFO - 2018-04-19 20:21:40 --> URI Class Initialized
INFO - 2018-04-19 20:21:40 --> Router Class Initialized
INFO - 2018-04-19 20:21:40 --> Output Class Initialized
INFO - 2018-04-19 20:21:40 --> Security Class Initialized
DEBUG - 2018-04-19 20:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:21:40 --> CSRF cookie sent
INFO - 2018-04-19 20:21:40 --> CSRF token verified
INFO - 2018-04-19 20:21:40 --> Input Class Initialized
INFO - 2018-04-19 20:21:40 --> Language Class Initialized
INFO - 2018-04-19 20:21:40 --> Loader Class Initialized
INFO - 2018-04-19 20:21:40 --> Helper loaded: url_helper
INFO - 2018-04-19 20:21:40 --> Helper loaded: form_helper
INFO - 2018-04-19 20:21:40 --> Helper loaded: language_helper
DEBUG - 2018-04-19 20:21:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 20:21:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 20:21:40 --> User Agent Class Initialized
INFO - 2018-04-19 20:21:40 --> Controller Class Initialized
INFO - 2018-04-19 20:21:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 20:21:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 20:21:40 --> Pixel_Model class loaded
INFO - 2018-04-19 20:21:40 --> Database Driver Class Initialized
INFO - 2018-04-19 20:21:40 --> Model "RegistrationModel" initialized
INFO - 2018-04-19 20:21:40 --> Form Validation Class Initialized
INFO - 2018-04-19 20:21:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-19 20:21:41 --> Config Class Initialized
INFO - 2018-04-19 20:21:41 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:21:41 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:21:41 --> Utf8 Class Initialized
INFO - 2018-04-19 20:21:41 --> URI Class Initialized
DEBUG - 2018-04-19 20:21:41 --> No URI present. Default controller set.
INFO - 2018-04-19 20:21:41 --> Router Class Initialized
INFO - 2018-04-19 20:21:41 --> Output Class Initialized
INFO - 2018-04-19 20:21:41 --> Security Class Initialized
DEBUG - 2018-04-19 20:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:21:41 --> CSRF cookie sent
INFO - 2018-04-19 20:21:41 --> Input Class Initialized
INFO - 2018-04-19 20:21:41 --> Language Class Initialized
INFO - 2018-04-19 20:21:41 --> Loader Class Initialized
INFO - 2018-04-19 20:21:41 --> Helper loaded: url_helper
INFO - 2018-04-19 20:21:41 --> Helper loaded: form_helper
INFO - 2018-04-19 20:21:41 --> Helper loaded: language_helper
DEBUG - 2018-04-19 20:21:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 20:21:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 20:21:41 --> User Agent Class Initialized
INFO - 2018-04-19 20:21:41 --> Controller Class Initialized
INFO - 2018-04-19 20:21:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 20:21:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 20:21:41 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 20:21:41 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-19 20:21:41 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 20:21:41 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-19 20:21:41 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 20:21:41 --> Final output sent to browser
DEBUG - 2018-04-19 20:21:41 --> Total execution time: 0.3811
INFO - 2018-04-19 20:21:41 --> Config Class Initialized
INFO - 2018-04-19 20:21:41 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:21:41 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:21:41 --> Utf8 Class Initialized
INFO - 2018-04-19 20:21:41 --> URI Class Initialized
INFO - 2018-04-19 20:21:41 --> Router Class Initialized
INFO - 2018-04-19 20:21:41 --> Output Class Initialized
INFO - 2018-04-19 20:21:41 --> Security Class Initialized
DEBUG - 2018-04-19 20:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:21:41 --> CSRF cookie sent
INFO - 2018-04-19 20:21:42 --> Input Class Initialized
INFO - 2018-04-19 20:21:42 --> Language Class Initialized
ERROR - 2018-04-19 20:21:42 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 20:21:43 --> Config Class Initialized
INFO - 2018-04-19 20:21:43 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:21:43 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:21:43 --> Utf8 Class Initialized
INFO - 2018-04-19 20:21:43 --> URI Class Initialized
INFO - 2018-04-19 20:21:43 --> Router Class Initialized
INFO - 2018-04-19 20:21:43 --> Output Class Initialized
INFO - 2018-04-19 20:21:43 --> Security Class Initialized
DEBUG - 2018-04-19 20:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:21:43 --> CSRF cookie sent
INFO - 2018-04-19 20:21:43 --> Input Class Initialized
INFO - 2018-04-19 20:21:43 --> Language Class Initialized
ERROR - 2018-04-19 20:21:43 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-19 20:22:04 --> Config Class Initialized
INFO - 2018-04-19 20:22:04 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:22:04 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:22:04 --> Utf8 Class Initialized
INFO - 2018-04-19 20:22:04 --> URI Class Initialized
INFO - 2018-04-19 20:22:04 --> Router Class Initialized
INFO - 2018-04-19 20:22:04 --> Output Class Initialized
INFO - 2018-04-19 20:22:04 --> Security Class Initialized
DEBUG - 2018-04-19 20:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:22:04 --> CSRF cookie sent
INFO - 2018-04-19 20:22:04 --> Input Class Initialized
INFO - 2018-04-19 20:22:04 --> Language Class Initialized
INFO - 2018-04-19 20:22:04 --> Loader Class Initialized
INFO - 2018-04-19 20:22:04 --> Helper loaded: url_helper
INFO - 2018-04-19 20:22:04 --> Helper loaded: form_helper
INFO - 2018-04-19 20:22:04 --> Helper loaded: language_helper
DEBUG - 2018-04-19 20:22:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 20:22:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 20:22:04 --> User Agent Class Initialized
INFO - 2018-04-19 20:22:04 --> Controller Class Initialized
INFO - 2018-04-19 20:22:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 20:22:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 20:22:04 --> CSRF cookie sent
INFO - 2018-04-19 20:22:04 --> Config Class Initialized
INFO - 2018-04-19 20:22:04 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:22:04 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:22:04 --> Utf8 Class Initialized
INFO - 2018-04-19 20:22:04 --> URI Class Initialized
DEBUG - 2018-04-19 20:22:04 --> No URI present. Default controller set.
INFO - 2018-04-19 20:22:04 --> Router Class Initialized
INFO - 2018-04-19 20:22:04 --> Output Class Initialized
INFO - 2018-04-19 20:22:04 --> Security Class Initialized
DEBUG - 2018-04-19 20:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:22:04 --> CSRF cookie sent
INFO - 2018-04-19 20:22:04 --> Input Class Initialized
INFO - 2018-04-19 20:22:04 --> Language Class Initialized
INFO - 2018-04-19 20:22:04 --> Loader Class Initialized
INFO - 2018-04-19 20:22:04 --> Helper loaded: url_helper
INFO - 2018-04-19 20:22:04 --> Helper loaded: form_helper
INFO - 2018-04-19 20:22:04 --> Helper loaded: language_helper
DEBUG - 2018-04-19 20:22:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 20:22:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 20:22:04 --> User Agent Class Initialized
INFO - 2018-04-19 20:22:04 --> Controller Class Initialized
INFO - 2018-04-19 20:22:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 20:22:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 20:22:04 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 20:22:04 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 20:22:04 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-19 20:22:04 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 20:22:04 --> Final output sent to browser
DEBUG - 2018-04-19 20:22:04 --> Total execution time: 0.3934
INFO - 2018-04-19 20:22:05 --> Config Class Initialized
INFO - 2018-04-19 20:22:05 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:22:05 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:22:05 --> Utf8 Class Initialized
INFO - 2018-04-19 20:22:05 --> URI Class Initialized
INFO - 2018-04-19 20:22:05 --> Router Class Initialized
INFO - 2018-04-19 20:22:05 --> Output Class Initialized
INFO - 2018-04-19 20:22:05 --> Security Class Initialized
DEBUG - 2018-04-19 20:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:22:05 --> CSRF cookie sent
INFO - 2018-04-19 20:22:05 --> Input Class Initialized
INFO - 2018-04-19 20:22:05 --> Language Class Initialized
ERROR - 2018-04-19 20:22:05 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 20:22:06 --> Config Class Initialized
INFO - 2018-04-19 20:22:06 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:22:06 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:22:07 --> Utf8 Class Initialized
INFO - 2018-04-19 20:22:07 --> URI Class Initialized
INFO - 2018-04-19 20:22:07 --> Router Class Initialized
INFO - 2018-04-19 20:22:07 --> Output Class Initialized
INFO - 2018-04-19 20:22:07 --> Security Class Initialized
DEBUG - 2018-04-19 20:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:22:07 --> CSRF cookie sent
INFO - 2018-04-19 20:22:07 --> Input Class Initialized
INFO - 2018-04-19 20:22:07 --> Config Class Initialized
INFO - 2018-04-19 20:22:07 --> Hooks Class Initialized
INFO - 2018-04-19 20:22:07 --> Language Class Initialized
ERROR - 2018-04-19 20:22:07 --> 404 Page Not Found: Revolution/assets
DEBUG - 2018-04-19 20:22:07 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:22:07 --> Utf8 Class Initialized
INFO - 2018-04-19 20:22:07 --> URI Class Initialized
INFO - 2018-04-19 20:22:07 --> Router Class Initialized
INFO - 2018-04-19 20:22:07 --> Output Class Initialized
INFO - 2018-04-19 20:22:07 --> Security Class Initialized
DEBUG - 2018-04-19 20:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:22:07 --> CSRF cookie sent
INFO - 2018-04-19 20:22:07 --> Input Class Initialized
INFO - 2018-04-19 20:22:07 --> Language Class Initialized
INFO - 2018-04-19 20:22:07 --> Loader Class Initialized
INFO - 2018-04-19 20:22:07 --> Helper loaded: url_helper
INFO - 2018-04-19 20:22:07 --> Helper loaded: form_helper
INFO - 2018-04-19 20:22:07 --> Helper loaded: language_helper
DEBUG - 2018-04-19 20:22:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 20:22:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 20:22:07 --> User Agent Class Initialized
INFO - 2018-04-19 20:22:07 --> Controller Class Initialized
INFO - 2018-04-19 20:22:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 20:22:07 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-19 20:22:07 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-19 20:22:07 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 20:22:07 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 20:22:07 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-19 20:22:07 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-19 20:22:07 --> Could not find the language line "req_email"
INFO - 2018-04-19 20:22:07 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-04-19 20:22:07 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 20:22:07 --> Final output sent to browser
DEBUG - 2018-04-19 20:22:07 --> Total execution time: 0.5893
INFO - 2018-04-19 20:22:08 --> Config Class Initialized
INFO - 2018-04-19 20:22:08 --> Config Class Initialized
INFO - 2018-04-19 20:22:08 --> Hooks Class Initialized
INFO - 2018-04-19 20:22:08 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:22:08 --> UTF-8 Support Enabled
DEBUG - 2018-04-19 20:22:08 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:22:08 --> Utf8 Class Initialized
INFO - 2018-04-19 20:22:08 --> Utf8 Class Initialized
INFO - 2018-04-19 20:22:08 --> URI Class Initialized
INFO - 2018-04-19 20:22:08 --> URI Class Initialized
INFO - 2018-04-19 20:22:08 --> Router Class Initialized
INFO - 2018-04-19 20:22:08 --> Output Class Initialized
INFO - 2018-04-19 20:22:08 --> Router Class Initialized
INFO - 2018-04-19 20:22:08 --> Output Class Initialized
INFO - 2018-04-19 20:22:08 --> Security Class Initialized
DEBUG - 2018-04-19 20:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:22:08 --> Security Class Initialized
INFO - 2018-04-19 20:22:08 --> CSRF cookie sent
DEBUG - 2018-04-19 20:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:22:08 --> Input Class Initialized
INFO - 2018-04-19 20:22:08 --> CSRF cookie sent
INFO - 2018-04-19 20:22:08 --> Input Class Initialized
INFO - 2018-04-19 20:22:08 --> Language Class Initialized
INFO - 2018-04-19 20:22:08 --> Language Class Initialized
ERROR - 2018-04-19 20:22:08 --> 404 Page Not Found: Assets/images
ERROR - 2018-04-19 20:22:08 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 20:22:26 --> Config Class Initialized
INFO - 2018-04-19 20:22:26 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:22:26 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:22:26 --> Utf8 Class Initialized
INFO - 2018-04-19 20:22:26 --> URI Class Initialized
INFO - 2018-04-19 20:22:26 --> Router Class Initialized
INFO - 2018-04-19 20:22:26 --> Output Class Initialized
INFO - 2018-04-19 20:22:26 --> Security Class Initialized
DEBUG - 2018-04-19 20:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:22:26 --> CSRF cookie sent
INFO - 2018-04-19 20:22:26 --> CSRF token verified
INFO - 2018-04-19 20:22:26 --> Input Class Initialized
INFO - 2018-04-19 20:22:26 --> Language Class Initialized
INFO - 2018-04-19 20:22:26 --> Loader Class Initialized
INFO - 2018-04-19 20:22:26 --> Helper loaded: url_helper
INFO - 2018-04-19 20:22:26 --> Helper loaded: form_helper
INFO - 2018-04-19 20:22:26 --> Helper loaded: language_helper
DEBUG - 2018-04-19 20:22:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 20:22:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 20:22:26 --> User Agent Class Initialized
INFO - 2018-04-19 20:22:26 --> Controller Class Initialized
INFO - 2018-04-19 20:22:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 20:22:26 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-19 20:22:26 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-19 20:22:26 --> Form Validation Class Initialized
INFO - 2018-04-19 20:22:26 --> Pixel_Model class loaded
INFO - 2018-04-19 20:22:26 --> Database Driver Class Initialized
INFO - 2018-04-19 20:22:26 --> Model "AuthenticationModel" initialized
INFO - 2018-04-19 20:22:27 --> Config Class Initialized
INFO - 2018-04-19 20:22:27 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:22:27 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:22:27 --> Utf8 Class Initialized
INFO - 2018-04-19 20:22:27 --> URI Class Initialized
INFO - 2018-04-19 20:22:27 --> Router Class Initialized
INFO - 2018-04-19 20:22:27 --> Output Class Initialized
INFO - 2018-04-19 20:22:27 --> Security Class Initialized
DEBUG - 2018-04-19 20:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:22:27 --> CSRF cookie sent
INFO - 2018-04-19 20:22:27 --> Input Class Initialized
INFO - 2018-04-19 20:22:27 --> Language Class Initialized
INFO - 2018-04-19 20:22:27 --> Loader Class Initialized
INFO - 2018-04-19 20:22:27 --> Helper loaded: url_helper
INFO - 2018-04-19 20:22:27 --> Helper loaded: form_helper
INFO - 2018-04-19 20:22:27 --> Helper loaded: language_helper
DEBUG - 2018-04-19 20:22:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 20:22:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 20:22:27 --> User Agent Class Initialized
INFO - 2018-04-19 20:22:27 --> Controller Class Initialized
INFO - 2018-04-19 20:22:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 20:22:27 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-19 20:22:27 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-19 20:22:27 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 20:22:27 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 20:22:27 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-19 20:22:27 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-19 20:22:27 --> File loaded: E:\www\yacopoo\application\views\shared/_soft_error.php
ERROR - 2018-04-19 20:22:27 --> Could not find the language line "req_email"
INFO - 2018-04-19 20:22:27 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-04-19 20:22:27 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 20:22:27 --> Final output sent to browser
DEBUG - 2018-04-19 20:22:27 --> Total execution time: 0.4528
INFO - 2018-04-19 20:22:27 --> Config Class Initialized
INFO - 2018-04-19 20:22:27 --> Config Class Initialized
INFO - 2018-04-19 20:22:27 --> Hooks Class Initialized
INFO - 2018-04-19 20:22:27 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:22:27 --> UTF-8 Support Enabled
DEBUG - 2018-04-19 20:22:27 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:22:27 --> Utf8 Class Initialized
INFO - 2018-04-19 20:22:27 --> Utf8 Class Initialized
INFO - 2018-04-19 20:22:27 --> URI Class Initialized
INFO - 2018-04-19 20:22:28 --> URI Class Initialized
INFO - 2018-04-19 20:22:28 --> Router Class Initialized
INFO - 2018-04-19 20:22:28 --> Output Class Initialized
INFO - 2018-04-19 20:22:28 --> Router Class Initialized
INFO - 2018-04-19 20:22:28 --> Security Class Initialized
INFO - 2018-04-19 20:22:28 --> Output Class Initialized
INFO - 2018-04-19 20:22:28 --> Security Class Initialized
DEBUG - 2018-04-19 20:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:22:28 --> CSRF cookie sent
DEBUG - 2018-04-19 20:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:22:28 --> Input Class Initialized
INFO - 2018-04-19 20:22:28 --> CSRF cookie sent
INFO - 2018-04-19 20:22:28 --> Input Class Initialized
INFO - 2018-04-19 20:22:28 --> Language Class Initialized
INFO - 2018-04-19 20:22:28 --> Language Class Initialized
ERROR - 2018-04-19 20:22:28 --> 404 Page Not Found: Assets/images
ERROR - 2018-04-19 20:22:28 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 20:23:01 --> Config Class Initialized
INFO - 2018-04-19 20:23:01 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:23:01 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:23:01 --> Utf8 Class Initialized
INFO - 2018-04-19 20:23:01 --> URI Class Initialized
INFO - 2018-04-19 20:23:01 --> Router Class Initialized
INFO - 2018-04-19 20:23:01 --> Output Class Initialized
INFO - 2018-04-19 20:23:01 --> Security Class Initialized
DEBUG - 2018-04-19 20:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:23:01 --> CSRF cookie sent
INFO - 2018-04-19 20:23:01 --> CSRF token verified
INFO - 2018-04-19 20:23:01 --> Input Class Initialized
INFO - 2018-04-19 20:23:01 --> Language Class Initialized
INFO - 2018-04-19 20:23:01 --> Loader Class Initialized
INFO - 2018-04-19 20:23:01 --> Helper loaded: url_helper
INFO - 2018-04-19 20:23:01 --> Helper loaded: form_helper
INFO - 2018-04-19 20:23:01 --> Helper loaded: language_helper
DEBUG - 2018-04-19 20:23:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 20:23:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 20:23:01 --> User Agent Class Initialized
INFO - 2018-04-19 20:23:01 --> Controller Class Initialized
INFO - 2018-04-19 20:23:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 20:23:01 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-19 20:23:01 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-19 20:23:01 --> Form Validation Class Initialized
INFO - 2018-04-19 20:23:01 --> Pixel_Model class loaded
INFO - 2018-04-19 20:23:01 --> Database Driver Class Initialized
INFO - 2018-04-19 20:23:01 --> Model "AuthenticationModel" initialized
INFO - 2018-04-19 20:23:01 --> Config Class Initialized
INFO - 2018-04-19 20:23:01 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:23:01 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:23:01 --> Utf8 Class Initialized
INFO - 2018-04-19 20:23:01 --> URI Class Initialized
INFO - 2018-04-19 20:23:01 --> Router Class Initialized
INFO - 2018-04-19 20:23:01 --> Output Class Initialized
INFO - 2018-04-19 20:23:01 --> Security Class Initialized
DEBUG - 2018-04-19 20:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:23:01 --> CSRF cookie sent
INFO - 2018-04-19 20:23:01 --> Input Class Initialized
INFO - 2018-04-19 20:23:01 --> Language Class Initialized
INFO - 2018-04-19 20:23:01 --> Loader Class Initialized
INFO - 2018-04-19 20:23:01 --> Helper loaded: url_helper
INFO - 2018-04-19 20:23:01 --> Helper loaded: form_helper
INFO - 2018-04-19 20:23:02 --> Helper loaded: language_helper
DEBUG - 2018-04-19 20:23:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 20:23:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 20:23:02 --> User Agent Class Initialized
INFO - 2018-04-19 20:23:02 --> Controller Class Initialized
INFO - 2018-04-19 20:23:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 20:23:02 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-19 20:23:02 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-19 20:23:02 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 20:23:02 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 20:23:02 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-19 20:23:02 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-19 20:23:02 --> File loaded: E:\www\yacopoo\application\views\shared/_soft_error.php
ERROR - 2018-04-19 20:23:02 --> Could not find the language line "req_email"
INFO - 2018-04-19 20:23:02 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-04-19 20:23:02 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 20:23:02 --> Final output sent to browser
DEBUG - 2018-04-19 20:23:02 --> Total execution time: 0.4543
INFO - 2018-04-19 20:23:02 --> Config Class Initialized
INFO - 2018-04-19 20:23:02 --> Config Class Initialized
INFO - 2018-04-19 20:23:02 --> Hooks Class Initialized
INFO - 2018-04-19 20:23:02 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:23:02 --> UTF-8 Support Enabled
DEBUG - 2018-04-19 20:23:02 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:23:02 --> Utf8 Class Initialized
INFO - 2018-04-19 20:23:02 --> Utf8 Class Initialized
INFO - 2018-04-19 20:23:02 --> URI Class Initialized
INFO - 2018-04-19 20:23:02 --> URI Class Initialized
INFO - 2018-04-19 20:23:02 --> Router Class Initialized
INFO - 2018-04-19 20:23:02 --> Router Class Initialized
INFO - 2018-04-19 20:23:02 --> Output Class Initialized
INFO - 2018-04-19 20:23:02 --> Output Class Initialized
INFO - 2018-04-19 20:23:02 --> Security Class Initialized
INFO - 2018-04-19 20:23:02 --> Security Class Initialized
DEBUG - 2018-04-19 20:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-19 20:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:23:02 --> CSRF cookie sent
INFO - 2018-04-19 20:23:02 --> CSRF cookie sent
INFO - 2018-04-19 20:23:02 --> Input Class Initialized
INFO - 2018-04-19 20:23:02 --> Input Class Initialized
INFO - 2018-04-19 20:23:02 --> Language Class Initialized
INFO - 2018-04-19 20:23:02 --> Language Class Initialized
ERROR - 2018-04-19 20:23:02 --> 404 Page Not Found: Assets/images
ERROR - 2018-04-19 20:23:02 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 20:23:12 --> Config Class Initialized
INFO - 2018-04-19 20:23:12 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:23:12 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:23:12 --> Utf8 Class Initialized
INFO - 2018-04-19 20:23:12 --> URI Class Initialized
INFO - 2018-04-19 20:23:12 --> Router Class Initialized
INFO - 2018-04-19 20:23:12 --> Output Class Initialized
INFO - 2018-04-19 20:23:12 --> Security Class Initialized
DEBUG - 2018-04-19 20:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:23:12 --> CSRF cookie sent
INFO - 2018-04-19 20:23:12 --> Input Class Initialized
INFO - 2018-04-19 20:23:12 --> Language Class Initialized
INFO - 2018-04-19 20:23:12 --> Loader Class Initialized
INFO - 2018-04-19 20:23:12 --> Helper loaded: url_helper
INFO - 2018-04-19 20:23:12 --> Helper loaded: form_helper
INFO - 2018-04-19 20:23:12 --> Helper loaded: language_helper
DEBUG - 2018-04-19 20:23:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 20:23:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 20:23:12 --> User Agent Class Initialized
INFO - 2018-04-19 20:23:12 --> Controller Class Initialized
INFO - 2018-04-19 20:23:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 20:23:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 20:23:12 --> Pixel_Model class loaded
INFO - 2018-04-19 20:23:12 --> Database Driver Class Initialized
INFO - 2018-04-19 20:23:12 --> Model "RegistrationModel" initialized
INFO - 2018-04-19 20:23:12 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 20:23:12 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 20:23:12 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-19 20:23:12 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-19 20:23:12 --> File loaded: E:\www\yacopoo\application\views\register/complete_registration.php
INFO - 2018-04-19 20:23:12 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 20:23:12 --> Final output sent to browser
DEBUG - 2018-04-19 20:23:12 --> Total execution time: 0.4882
INFO - 2018-04-19 20:23:13 --> Config Class Initialized
INFO - 2018-04-19 20:23:13 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:23:13 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:23:13 --> Utf8 Class Initialized
INFO - 2018-04-19 20:23:13 --> URI Class Initialized
INFO - 2018-04-19 20:23:13 --> Router Class Initialized
INFO - 2018-04-19 20:23:13 --> Output Class Initialized
INFO - 2018-04-19 20:23:13 --> Security Class Initialized
DEBUG - 2018-04-19 20:23:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:23:13 --> CSRF cookie sent
INFO - 2018-04-19 20:23:13 --> Input Class Initialized
INFO - 2018-04-19 20:23:13 --> Language Class Initialized
ERROR - 2018-04-19 20:23:13 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 20:23:25 --> Config Class Initialized
INFO - 2018-04-19 20:23:25 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:23:25 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:23:25 --> Utf8 Class Initialized
INFO - 2018-04-19 20:23:25 --> URI Class Initialized
INFO - 2018-04-19 20:23:25 --> Router Class Initialized
INFO - 2018-04-19 20:23:25 --> Output Class Initialized
INFO - 2018-04-19 20:23:25 --> Security Class Initialized
DEBUG - 2018-04-19 20:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:23:25 --> CSRF cookie sent
INFO - 2018-04-19 20:23:25 --> CSRF token verified
INFO - 2018-04-19 20:23:25 --> Input Class Initialized
INFO - 2018-04-19 20:23:25 --> Language Class Initialized
INFO - 2018-04-19 20:23:25 --> Loader Class Initialized
INFO - 2018-04-19 20:23:25 --> Helper loaded: url_helper
INFO - 2018-04-19 20:23:25 --> Helper loaded: form_helper
INFO - 2018-04-19 20:23:25 --> Helper loaded: language_helper
DEBUG - 2018-04-19 20:23:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 20:23:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 20:23:25 --> User Agent Class Initialized
INFO - 2018-04-19 20:23:25 --> Controller Class Initialized
INFO - 2018-04-19 20:23:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 20:23:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 20:23:25 --> Pixel_Model class loaded
INFO - 2018-04-19 20:23:25 --> Database Driver Class Initialized
INFO - 2018-04-19 20:23:25 --> Model "RegistrationModel" initialized
INFO - 2018-04-19 20:23:25 --> Form Validation Class Initialized
INFO - 2018-04-19 20:23:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-19 20:23:26 --> Config Class Initialized
INFO - 2018-04-19 20:23:26 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:23:26 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:23:26 --> Utf8 Class Initialized
INFO - 2018-04-19 20:23:26 --> URI Class Initialized
DEBUG - 2018-04-19 20:23:26 --> No URI present. Default controller set.
INFO - 2018-04-19 20:23:26 --> Router Class Initialized
INFO - 2018-04-19 20:23:26 --> Output Class Initialized
INFO - 2018-04-19 20:23:26 --> Security Class Initialized
DEBUG - 2018-04-19 20:23:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:23:26 --> CSRF cookie sent
INFO - 2018-04-19 20:23:26 --> Input Class Initialized
INFO - 2018-04-19 20:23:26 --> Language Class Initialized
INFO - 2018-04-19 20:23:26 --> Loader Class Initialized
INFO - 2018-04-19 20:23:26 --> Helper loaded: url_helper
INFO - 2018-04-19 20:23:26 --> Helper loaded: form_helper
INFO - 2018-04-19 20:23:26 --> Helper loaded: language_helper
DEBUG - 2018-04-19 20:23:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 20:23:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 20:23:26 --> User Agent Class Initialized
INFO - 2018-04-19 20:23:26 --> Controller Class Initialized
INFO - 2018-04-19 20:23:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 20:23:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 20:23:26 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 20:23:26 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-19 20:23:26 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 20:23:26 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-19 20:23:26 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 20:23:26 --> Final output sent to browser
DEBUG - 2018-04-19 20:23:26 --> Total execution time: 0.3919
INFO - 2018-04-19 20:23:26 --> Config Class Initialized
INFO - 2018-04-19 20:23:26 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:23:26 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:23:26 --> Utf8 Class Initialized
INFO - 2018-04-19 20:23:26 --> URI Class Initialized
INFO - 2018-04-19 20:23:26 --> Router Class Initialized
INFO - 2018-04-19 20:23:26 --> Output Class Initialized
INFO - 2018-04-19 20:23:26 --> Security Class Initialized
DEBUG - 2018-04-19 20:23:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:23:26 --> CSRF cookie sent
INFO - 2018-04-19 20:23:26 --> Input Class Initialized
INFO - 2018-04-19 20:23:26 --> Language Class Initialized
ERROR - 2018-04-19 20:23:27 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 20:23:28 --> Config Class Initialized
INFO - 2018-04-19 20:23:28 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:23:28 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:23:28 --> Utf8 Class Initialized
INFO - 2018-04-19 20:23:28 --> URI Class Initialized
INFO - 2018-04-19 20:23:28 --> Router Class Initialized
INFO - 2018-04-19 20:23:28 --> Output Class Initialized
INFO - 2018-04-19 20:23:28 --> Security Class Initialized
DEBUG - 2018-04-19 20:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:23:28 --> CSRF cookie sent
INFO - 2018-04-19 20:23:28 --> Input Class Initialized
INFO - 2018-04-19 20:23:28 --> Language Class Initialized
ERROR - 2018-04-19 20:23:28 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-19 20:23:33 --> Config Class Initialized
INFO - 2018-04-19 20:23:33 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:23:33 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:23:33 --> Utf8 Class Initialized
INFO - 2018-04-19 20:23:33 --> URI Class Initialized
INFO - 2018-04-19 20:23:33 --> Router Class Initialized
INFO - 2018-04-19 20:23:33 --> Output Class Initialized
INFO - 2018-04-19 20:23:33 --> Security Class Initialized
DEBUG - 2018-04-19 20:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:23:33 --> CSRF cookie sent
INFO - 2018-04-19 20:23:33 --> Input Class Initialized
INFO - 2018-04-19 20:23:33 --> Language Class Initialized
INFO - 2018-04-19 20:23:33 --> Loader Class Initialized
INFO - 2018-04-19 20:23:33 --> Helper loaded: url_helper
INFO - 2018-04-19 20:23:33 --> Helper loaded: form_helper
INFO - 2018-04-19 20:23:33 --> Helper loaded: language_helper
DEBUG - 2018-04-19 20:23:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 20:23:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 20:23:33 --> User Agent Class Initialized
INFO - 2018-04-19 20:23:33 --> Controller Class Initialized
INFO - 2018-04-19 20:23:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 20:23:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 20:23:33 --> CSRF cookie sent
INFO - 2018-04-19 20:23:33 --> Config Class Initialized
INFO - 2018-04-19 20:23:33 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:23:33 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:23:33 --> Utf8 Class Initialized
INFO - 2018-04-19 20:23:33 --> URI Class Initialized
DEBUG - 2018-04-19 20:23:33 --> No URI present. Default controller set.
INFO - 2018-04-19 20:23:33 --> Router Class Initialized
INFO - 2018-04-19 20:23:33 --> Output Class Initialized
INFO - 2018-04-19 20:23:33 --> Security Class Initialized
DEBUG - 2018-04-19 20:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:23:33 --> CSRF cookie sent
INFO - 2018-04-19 20:23:33 --> Input Class Initialized
INFO - 2018-04-19 20:23:33 --> Language Class Initialized
INFO - 2018-04-19 20:23:33 --> Loader Class Initialized
INFO - 2018-04-19 20:23:33 --> Helper loaded: url_helper
INFO - 2018-04-19 20:23:33 --> Helper loaded: form_helper
INFO - 2018-04-19 20:23:33 --> Helper loaded: language_helper
DEBUG - 2018-04-19 20:23:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 20:23:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 20:23:33 --> User Agent Class Initialized
INFO - 2018-04-19 20:23:33 --> Controller Class Initialized
INFO - 2018-04-19 20:23:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 20:23:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 20:23:33 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 20:23:33 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 20:23:34 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-19 20:23:34 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 20:23:34 --> Final output sent to browser
DEBUG - 2018-04-19 20:23:34 --> Total execution time: 0.4217
INFO - 2018-04-19 20:23:34 --> Config Class Initialized
INFO - 2018-04-19 20:23:34 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:23:34 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:23:34 --> Utf8 Class Initialized
INFO - 2018-04-19 20:23:34 --> URI Class Initialized
INFO - 2018-04-19 20:23:34 --> Router Class Initialized
INFO - 2018-04-19 20:23:34 --> Output Class Initialized
INFO - 2018-04-19 20:23:34 --> Security Class Initialized
DEBUG - 2018-04-19 20:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:23:34 --> CSRF cookie sent
INFO - 2018-04-19 20:23:34 --> Input Class Initialized
INFO - 2018-04-19 20:23:34 --> Language Class Initialized
ERROR - 2018-04-19 20:23:34 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 20:23:36 --> Config Class Initialized
INFO - 2018-04-19 20:23:36 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:23:36 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:23:36 --> Utf8 Class Initialized
INFO - 2018-04-19 20:23:36 --> URI Class Initialized
INFO - 2018-04-19 20:23:36 --> Router Class Initialized
INFO - 2018-04-19 20:23:36 --> Output Class Initialized
INFO - 2018-04-19 20:23:36 --> Config Class Initialized
INFO - 2018-04-19 20:23:36 --> Hooks Class Initialized
INFO - 2018-04-19 20:23:36 --> Security Class Initialized
DEBUG - 2018-04-19 20:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-19 20:23:36 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:23:36 --> CSRF cookie sent
INFO - 2018-04-19 20:23:36 --> Utf8 Class Initialized
INFO - 2018-04-19 20:23:36 --> Input Class Initialized
INFO - 2018-04-19 20:23:36 --> URI Class Initialized
INFO - 2018-04-19 20:23:36 --> Language Class Initialized
INFO - 2018-04-19 20:23:36 --> Router Class Initialized
INFO - 2018-04-19 20:23:36 --> Output Class Initialized
INFO - 2018-04-19 20:23:36 --> Loader Class Initialized
INFO - 2018-04-19 20:23:36 --> Helper loaded: url_helper
INFO - 2018-04-19 20:23:36 --> Security Class Initialized
INFO - 2018-04-19 20:23:36 --> Helper loaded: form_helper
DEBUG - 2018-04-19 20:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:23:36 --> CSRF cookie sent
INFO - 2018-04-19 20:23:36 --> Helper loaded: language_helper
INFO - 2018-04-19 20:23:36 --> Input Class Initialized
DEBUG - 2018-04-19 20:23:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 20:23:36 --> Language Class Initialized
INFO - 2018-04-19 20:23:36 --> Session: Class initialized using 'files' driver.
ERROR - 2018-04-19 20:23:36 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-19 20:23:36 --> User Agent Class Initialized
INFO - 2018-04-19 20:23:36 --> Controller Class Initialized
INFO - 2018-04-19 20:23:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 20:23:36 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-19 20:23:36 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-19 20:23:36 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 20:23:36 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 20:23:36 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-19 20:23:36 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-19 20:23:36 --> Could not find the language line "req_email"
INFO - 2018-04-19 20:23:36 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-04-19 20:23:36 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 20:23:36 --> Final output sent to browser
DEBUG - 2018-04-19 20:23:36 --> Total execution time: 0.5889
INFO - 2018-04-19 20:23:37 --> Config Class Initialized
INFO - 2018-04-19 20:23:37 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:23:37 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:23:37 --> Utf8 Class Initialized
INFO - 2018-04-19 20:23:37 --> Config Class Initialized
INFO - 2018-04-19 20:23:37 --> Hooks Class Initialized
INFO - 2018-04-19 20:23:37 --> URI Class Initialized
DEBUG - 2018-04-19 20:23:37 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:23:37 --> Router Class Initialized
INFO - 2018-04-19 20:23:37 --> Utf8 Class Initialized
INFO - 2018-04-19 20:23:37 --> Output Class Initialized
INFO - 2018-04-19 20:23:37 --> URI Class Initialized
INFO - 2018-04-19 20:23:37 --> Security Class Initialized
DEBUG - 2018-04-19 20:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:23:37 --> Router Class Initialized
INFO - 2018-04-19 20:23:37 --> CSRF cookie sent
INFO - 2018-04-19 20:23:37 --> Input Class Initialized
INFO - 2018-04-19 20:23:37 --> Language Class Initialized
ERROR - 2018-04-19 20:23:37 --> 404 Page Not Found: Assets/images
INFO - 2018-04-19 20:23:37 --> Output Class Initialized
INFO - 2018-04-19 20:23:37 --> Security Class Initialized
DEBUG - 2018-04-19 20:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:23:37 --> CSRF cookie sent
INFO - 2018-04-19 20:23:37 --> Input Class Initialized
INFO - 2018-04-19 20:23:37 --> Language Class Initialized
ERROR - 2018-04-19 20:23:37 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 20:23:59 --> Config Class Initialized
INFO - 2018-04-19 20:23:59 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:23:59 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:23:59 --> Utf8 Class Initialized
INFO - 2018-04-19 20:23:59 --> URI Class Initialized
INFO - 2018-04-19 20:23:59 --> Router Class Initialized
INFO - 2018-04-19 20:23:59 --> Output Class Initialized
INFO - 2018-04-19 20:23:59 --> Security Class Initialized
DEBUG - 2018-04-19 20:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:23:59 --> CSRF cookie sent
INFO - 2018-04-19 20:23:59 --> CSRF token verified
INFO - 2018-04-19 20:23:59 --> Input Class Initialized
INFO - 2018-04-19 20:23:59 --> Language Class Initialized
INFO - 2018-04-19 20:23:59 --> Loader Class Initialized
INFO - 2018-04-19 20:23:59 --> Helper loaded: url_helper
INFO - 2018-04-19 20:23:59 --> Helper loaded: form_helper
INFO - 2018-04-19 20:23:59 --> Helper loaded: language_helper
DEBUG - 2018-04-19 20:23:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 20:23:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 20:23:59 --> User Agent Class Initialized
INFO - 2018-04-19 20:23:59 --> Controller Class Initialized
INFO - 2018-04-19 20:23:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 20:23:59 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-19 20:23:59 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-19 20:23:59 --> Form Validation Class Initialized
INFO - 2018-04-19 20:23:59 --> Pixel_Model class loaded
INFO - 2018-04-19 20:23:59 --> Database Driver Class Initialized
INFO - 2018-04-19 20:23:59 --> Model "AuthenticationModel" initialized
INFO - 2018-04-19 20:23:59 --> Config Class Initialized
INFO - 2018-04-19 20:23:59 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:23:59 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:23:59 --> Utf8 Class Initialized
INFO - 2018-04-19 20:23:59 --> URI Class Initialized
INFO - 2018-04-19 20:23:59 --> Router Class Initialized
INFO - 2018-04-19 20:23:59 --> Output Class Initialized
INFO - 2018-04-19 20:23:59 --> Security Class Initialized
DEBUG - 2018-04-19 20:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:24:00 --> CSRF cookie sent
INFO - 2018-04-19 20:24:00 --> Input Class Initialized
INFO - 2018-04-19 20:24:00 --> Language Class Initialized
INFO - 2018-04-19 20:24:00 --> Loader Class Initialized
INFO - 2018-04-19 20:24:00 --> Helper loaded: url_helper
INFO - 2018-04-19 20:24:00 --> Helper loaded: form_helper
INFO - 2018-04-19 20:24:00 --> Helper loaded: language_helper
DEBUG - 2018-04-19 20:24:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 20:24:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 20:24:00 --> User Agent Class Initialized
INFO - 2018-04-19 20:24:00 --> Controller Class Initialized
INFO - 2018-04-19 20:24:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 20:24:00 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-19 20:24:00 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-19 20:24:00 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 20:24:00 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 20:24:00 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-19 20:24:00 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-19 20:24:00 --> File loaded: E:\www\yacopoo\application\views\shared/_soft_error.php
ERROR - 2018-04-19 20:24:00 --> Could not find the language line "req_email"
INFO - 2018-04-19 20:24:00 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-04-19 20:24:00 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 20:24:00 --> Final output sent to browser
DEBUG - 2018-04-19 20:24:00 --> Total execution time: 0.4749
INFO - 2018-04-19 20:24:00 --> Config Class Initialized
INFO - 2018-04-19 20:24:00 --> Config Class Initialized
INFO - 2018-04-19 20:24:00 --> Hooks Class Initialized
INFO - 2018-04-19 20:24:00 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:24:00 --> UTF-8 Support Enabled
DEBUG - 2018-04-19 20:24:00 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:24:00 --> Utf8 Class Initialized
INFO - 2018-04-19 20:24:00 --> Utf8 Class Initialized
INFO - 2018-04-19 20:24:00 --> URI Class Initialized
INFO - 2018-04-19 20:24:00 --> URI Class Initialized
INFO - 2018-04-19 20:24:00 --> Router Class Initialized
INFO - 2018-04-19 20:24:00 --> Router Class Initialized
INFO - 2018-04-19 20:24:00 --> Output Class Initialized
INFO - 2018-04-19 20:24:00 --> Output Class Initialized
INFO - 2018-04-19 20:24:00 --> Security Class Initialized
INFO - 2018-04-19 20:24:00 --> Security Class Initialized
DEBUG - 2018-04-19 20:24:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-19 20:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:24:00 --> CSRF cookie sent
INFO - 2018-04-19 20:24:00 --> CSRF cookie sent
INFO - 2018-04-19 20:24:00 --> Input Class Initialized
INFO - 2018-04-19 20:24:00 --> Input Class Initialized
INFO - 2018-04-19 20:24:00 --> Language Class Initialized
INFO - 2018-04-19 20:24:00 --> Language Class Initialized
ERROR - 2018-04-19 20:24:00 --> 404 Page Not Found: Assets/css
ERROR - 2018-04-19 20:24:00 --> 404 Page Not Found: Assets/images
INFO - 2018-04-19 20:25:16 --> Config Class Initialized
INFO - 2018-04-19 20:25:16 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:25:16 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:25:16 --> Utf8 Class Initialized
INFO - 2018-04-19 20:25:16 --> URI Class Initialized
INFO - 2018-04-19 20:25:16 --> Router Class Initialized
INFO - 2018-04-19 20:25:16 --> Output Class Initialized
INFO - 2018-04-19 20:25:16 --> Security Class Initialized
DEBUG - 2018-04-19 20:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:25:16 --> CSRF cookie sent
INFO - 2018-04-19 20:25:16 --> CSRF token verified
INFO - 2018-04-19 20:25:16 --> Input Class Initialized
INFO - 2018-04-19 20:25:16 --> Language Class Initialized
INFO - 2018-04-19 20:25:16 --> Loader Class Initialized
INFO - 2018-04-19 20:25:16 --> Helper loaded: url_helper
INFO - 2018-04-19 20:25:16 --> Helper loaded: form_helper
INFO - 2018-04-19 20:25:16 --> Helper loaded: language_helper
DEBUG - 2018-04-19 20:25:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 20:25:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 20:25:17 --> User Agent Class Initialized
INFO - 2018-04-19 20:25:17 --> Controller Class Initialized
INFO - 2018-04-19 20:25:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 20:25:17 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-19 20:25:17 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-19 20:25:17 --> Form Validation Class Initialized
INFO - 2018-04-19 20:25:17 --> Pixel_Model class loaded
INFO - 2018-04-19 20:25:17 --> Database Driver Class Initialized
INFO - 2018-04-19 20:25:17 --> Model "AuthenticationModel" initialized
INFO - 2018-04-19 20:29:01 --> Config Class Initialized
INFO - 2018-04-19 20:29:01 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:29:01 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:29:01 --> Utf8 Class Initialized
INFO - 2018-04-19 20:29:01 --> URI Class Initialized
INFO - 2018-04-19 20:29:01 --> Router Class Initialized
INFO - 2018-04-19 20:29:01 --> Output Class Initialized
INFO - 2018-04-19 20:29:01 --> Security Class Initialized
DEBUG - 2018-04-19 20:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:29:01 --> CSRF cookie sent
INFO - 2018-04-19 20:29:01 --> Input Class Initialized
INFO - 2018-04-19 20:29:01 --> Language Class Initialized
INFO - 2018-04-19 20:29:01 --> Loader Class Initialized
INFO - 2018-04-19 20:29:01 --> Helper loaded: url_helper
INFO - 2018-04-19 20:29:01 --> Helper loaded: form_helper
INFO - 2018-04-19 20:29:01 --> Helper loaded: language_helper
DEBUG - 2018-04-19 20:29:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 20:29:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 20:29:01 --> User Agent Class Initialized
INFO - 2018-04-19 20:29:01 --> Controller Class Initialized
INFO - 2018-04-19 20:29:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 20:29:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 20:29:01 --> Pixel_Model class loaded
INFO - 2018-04-19 20:29:01 --> Database Driver Class Initialized
INFO - 2018-04-19 20:29:01 --> Model "RegistrationModel" initialized
INFO - 2018-04-19 20:29:01 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 20:29:01 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 20:29:01 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-19 20:29:01 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-19 20:29:01 --> File loaded: E:\www\yacopoo\application\views\register/activation_success.php
INFO - 2018-04-19 20:29:01 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 20:29:01 --> Final output sent to browser
DEBUG - 2018-04-19 20:29:01 --> Total execution time: 0.5052
INFO - 2018-04-19 20:29:02 --> Config Class Initialized
INFO - 2018-04-19 20:29:02 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:29:02 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:29:02 --> Utf8 Class Initialized
INFO - 2018-04-19 20:29:02 --> URI Class Initialized
INFO - 2018-04-19 20:29:02 --> Router Class Initialized
INFO - 2018-04-19 20:29:02 --> Output Class Initialized
INFO - 2018-04-19 20:29:02 --> Security Class Initialized
DEBUG - 2018-04-19 20:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:29:02 --> CSRF cookie sent
INFO - 2018-04-19 20:29:02 --> Input Class Initialized
INFO - 2018-04-19 20:29:02 --> Language Class Initialized
ERROR - 2018-04-19 20:29:02 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 20:29:09 --> Config Class Initialized
INFO - 2018-04-19 20:29:09 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:29:09 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:29:09 --> Utf8 Class Initialized
INFO - 2018-04-19 20:29:09 --> URI Class Initialized
INFO - 2018-04-19 20:29:09 --> Router Class Initialized
INFO - 2018-04-19 20:29:09 --> Output Class Initialized
INFO - 2018-04-19 20:29:09 --> Security Class Initialized
DEBUG - 2018-04-19 20:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:29:09 --> CSRF cookie sent
INFO - 2018-04-19 20:29:09 --> Input Class Initialized
INFO - 2018-04-19 20:29:09 --> Language Class Initialized
INFO - 2018-04-19 20:29:09 --> Loader Class Initialized
INFO - 2018-04-19 20:29:09 --> Helper loaded: url_helper
INFO - 2018-04-19 20:29:09 --> Helper loaded: form_helper
INFO - 2018-04-19 20:29:09 --> Helper loaded: language_helper
DEBUG - 2018-04-19 20:29:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 20:29:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 20:29:09 --> User Agent Class Initialized
INFO - 2018-04-19 20:29:09 --> Controller Class Initialized
INFO - 2018-04-19 20:29:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 20:29:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 20:29:09 --> Pixel_Model class loaded
INFO - 2018-04-19 20:29:09 --> Database Driver Class Initialized
INFO - 2018-04-19 20:29:09 --> Model "RegistrationModel" initialized
INFO - 2018-04-19 20:29:09 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 20:29:09 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 20:29:09 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-19 20:29:09 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-19 20:29:09 --> File loaded: E:\www\yacopoo\application\views\register/complete_registration.php
INFO - 2018-04-19 20:29:09 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 20:29:09 --> Final output sent to browser
DEBUG - 2018-04-19 20:29:09 --> Total execution time: 0.5193
INFO - 2018-04-19 20:29:09 --> Config Class Initialized
INFO - 2018-04-19 20:29:09 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:29:09 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:29:09 --> Utf8 Class Initialized
INFO - 2018-04-19 20:29:09 --> URI Class Initialized
INFO - 2018-04-19 20:29:10 --> Router Class Initialized
INFO - 2018-04-19 20:29:10 --> Output Class Initialized
INFO - 2018-04-19 20:29:10 --> Security Class Initialized
DEBUG - 2018-04-19 20:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:29:10 --> CSRF cookie sent
INFO - 2018-04-19 20:29:10 --> Input Class Initialized
INFO - 2018-04-19 20:29:10 --> Language Class Initialized
ERROR - 2018-04-19 20:29:10 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 20:29:36 --> Config Class Initialized
INFO - 2018-04-19 20:29:36 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:29:36 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:29:36 --> Utf8 Class Initialized
INFO - 2018-04-19 20:29:36 --> URI Class Initialized
INFO - 2018-04-19 20:29:36 --> Router Class Initialized
INFO - 2018-04-19 20:29:36 --> Output Class Initialized
INFO - 2018-04-19 20:29:36 --> Security Class Initialized
DEBUG - 2018-04-19 20:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:29:36 --> CSRF cookie sent
INFO - 2018-04-19 20:29:36 --> CSRF token verified
INFO - 2018-04-19 20:29:36 --> Input Class Initialized
INFO - 2018-04-19 20:29:36 --> Language Class Initialized
INFO - 2018-04-19 20:29:36 --> Loader Class Initialized
INFO - 2018-04-19 20:29:36 --> Helper loaded: url_helper
INFO - 2018-04-19 20:29:36 --> Helper loaded: form_helper
INFO - 2018-04-19 20:29:36 --> Helper loaded: language_helper
DEBUG - 2018-04-19 20:29:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 20:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 20:29:36 --> User Agent Class Initialized
INFO - 2018-04-19 20:29:36 --> Controller Class Initialized
INFO - 2018-04-19 20:29:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 20:29:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 20:29:36 --> Pixel_Model class loaded
INFO - 2018-04-19 20:29:36 --> Database Driver Class Initialized
INFO - 2018-04-19 20:29:36 --> Model "RegistrationModel" initialized
INFO - 2018-04-19 20:29:36 --> Form Validation Class Initialized
INFO - 2018-04-19 20:29:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-19 20:29:37 --> Config Class Initialized
INFO - 2018-04-19 20:29:37 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:29:37 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:29:37 --> Utf8 Class Initialized
INFO - 2018-04-19 20:29:37 --> URI Class Initialized
DEBUG - 2018-04-19 20:29:37 --> No URI present. Default controller set.
INFO - 2018-04-19 20:29:37 --> Router Class Initialized
INFO - 2018-04-19 20:29:37 --> Output Class Initialized
INFO - 2018-04-19 20:29:37 --> Security Class Initialized
DEBUG - 2018-04-19 20:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:29:37 --> CSRF cookie sent
INFO - 2018-04-19 20:29:37 --> Input Class Initialized
INFO - 2018-04-19 20:29:37 --> Language Class Initialized
INFO - 2018-04-19 20:29:37 --> Loader Class Initialized
INFO - 2018-04-19 20:29:37 --> Helper loaded: url_helper
INFO - 2018-04-19 20:29:37 --> Helper loaded: form_helper
INFO - 2018-04-19 20:29:37 --> Helper loaded: language_helper
DEBUG - 2018-04-19 20:29:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 20:29:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 20:29:37 --> User Agent Class Initialized
INFO - 2018-04-19 20:29:37 --> Controller Class Initialized
INFO - 2018-04-19 20:29:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 20:29:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 20:29:37 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 20:29:37 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-19 20:29:37 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 20:29:37 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-19 20:29:37 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 20:29:37 --> Final output sent to browser
DEBUG - 2018-04-19 20:29:37 --> Total execution time: 0.4033
INFO - 2018-04-19 20:29:37 --> Config Class Initialized
INFO - 2018-04-19 20:29:37 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:29:37 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:29:37 --> Utf8 Class Initialized
INFO - 2018-04-19 20:29:37 --> URI Class Initialized
INFO - 2018-04-19 20:29:38 --> Router Class Initialized
INFO - 2018-04-19 20:29:38 --> Output Class Initialized
INFO - 2018-04-19 20:29:38 --> Security Class Initialized
DEBUG - 2018-04-19 20:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:29:38 --> CSRF cookie sent
INFO - 2018-04-19 20:29:38 --> Input Class Initialized
INFO - 2018-04-19 20:29:38 --> Language Class Initialized
ERROR - 2018-04-19 20:29:38 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 20:29:39 --> Config Class Initialized
INFO - 2018-04-19 20:29:39 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:29:39 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:29:39 --> Utf8 Class Initialized
INFO - 2018-04-19 20:29:39 --> URI Class Initialized
INFO - 2018-04-19 20:29:39 --> Router Class Initialized
INFO - 2018-04-19 20:29:39 --> Output Class Initialized
INFO - 2018-04-19 20:29:39 --> Security Class Initialized
DEBUG - 2018-04-19 20:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:29:39 --> CSRF cookie sent
INFO - 2018-04-19 20:29:39 --> Input Class Initialized
INFO - 2018-04-19 20:29:39 --> Language Class Initialized
ERROR - 2018-04-19 20:29:39 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-19 20:29:40 --> Config Class Initialized
INFO - 2018-04-19 20:29:40 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:29:40 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:29:40 --> Utf8 Class Initialized
INFO - 2018-04-19 20:29:40 --> URI Class Initialized
INFO - 2018-04-19 20:29:40 --> Router Class Initialized
INFO - 2018-04-19 20:29:40 --> Output Class Initialized
INFO - 2018-04-19 20:29:40 --> Security Class Initialized
DEBUG - 2018-04-19 20:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:29:40 --> CSRF cookie sent
INFO - 2018-04-19 20:29:40 --> Input Class Initialized
INFO - 2018-04-19 20:29:40 --> Language Class Initialized
INFO - 2018-04-19 20:29:40 --> Loader Class Initialized
INFO - 2018-04-19 20:29:40 --> Helper loaded: url_helper
INFO - 2018-04-19 20:29:40 --> Helper loaded: form_helper
INFO - 2018-04-19 20:29:40 --> Helper loaded: language_helper
DEBUG - 2018-04-19 20:29:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 20:29:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 20:29:40 --> User Agent Class Initialized
INFO - 2018-04-19 20:29:40 --> Controller Class Initialized
INFO - 2018-04-19 20:29:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 20:29:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 20:29:41 --> CSRF cookie sent
INFO - 2018-04-19 20:29:41 --> Config Class Initialized
INFO - 2018-04-19 20:29:41 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:29:41 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:29:41 --> Utf8 Class Initialized
INFO - 2018-04-19 20:29:41 --> URI Class Initialized
DEBUG - 2018-04-19 20:29:41 --> No URI present. Default controller set.
INFO - 2018-04-19 20:29:41 --> Router Class Initialized
INFO - 2018-04-19 20:29:41 --> Output Class Initialized
INFO - 2018-04-19 20:29:41 --> Security Class Initialized
DEBUG - 2018-04-19 20:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:29:41 --> CSRF cookie sent
INFO - 2018-04-19 20:29:41 --> Input Class Initialized
INFO - 2018-04-19 20:29:41 --> Language Class Initialized
INFO - 2018-04-19 20:29:41 --> Loader Class Initialized
INFO - 2018-04-19 20:29:41 --> Helper loaded: url_helper
INFO - 2018-04-19 20:29:41 --> Helper loaded: form_helper
INFO - 2018-04-19 20:29:41 --> Helper loaded: language_helper
DEBUG - 2018-04-19 20:29:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 20:29:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 20:29:41 --> User Agent Class Initialized
INFO - 2018-04-19 20:29:41 --> Controller Class Initialized
INFO - 2018-04-19 20:29:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 20:29:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 20:29:41 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 20:29:41 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 20:29:41 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-19 20:29:41 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 20:29:41 --> Final output sent to browser
DEBUG - 2018-04-19 20:29:41 --> Total execution time: 0.4575
INFO - 2018-04-19 20:29:41 --> Config Class Initialized
INFO - 2018-04-19 20:29:41 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:29:41 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:29:41 --> Utf8 Class Initialized
INFO - 2018-04-19 20:29:41 --> URI Class Initialized
INFO - 2018-04-19 20:29:42 --> Router Class Initialized
INFO - 2018-04-19 20:29:42 --> Output Class Initialized
INFO - 2018-04-19 20:29:42 --> Security Class Initialized
DEBUG - 2018-04-19 20:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:29:42 --> CSRF cookie sent
INFO - 2018-04-19 20:29:42 --> Input Class Initialized
INFO - 2018-04-19 20:29:42 --> Language Class Initialized
ERROR - 2018-04-19 20:29:42 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 20:29:43 --> Config Class Initialized
INFO - 2018-04-19 20:29:43 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:29:43 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:29:43 --> Utf8 Class Initialized
INFO - 2018-04-19 20:29:43 --> URI Class Initialized
INFO - 2018-04-19 20:29:43 --> Router Class Initialized
INFO - 2018-04-19 20:29:43 --> Config Class Initialized
INFO - 2018-04-19 20:29:43 --> Hooks Class Initialized
INFO - 2018-04-19 20:29:43 --> Output Class Initialized
INFO - 2018-04-19 20:29:43 --> Security Class Initialized
DEBUG - 2018-04-19 20:29:43 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:29:43 --> Utf8 Class Initialized
DEBUG - 2018-04-19 20:29:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:29:43 --> CSRF cookie sent
INFO - 2018-04-19 20:29:43 --> URI Class Initialized
INFO - 2018-04-19 20:29:43 --> Input Class Initialized
INFO - 2018-04-19 20:29:43 --> Router Class Initialized
INFO - 2018-04-19 20:29:43 --> Language Class Initialized
INFO - 2018-04-19 20:29:43 --> Output Class Initialized
ERROR - 2018-04-19 20:29:43 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-19 20:29:43 --> Security Class Initialized
DEBUG - 2018-04-19 20:29:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:29:43 --> CSRF cookie sent
INFO - 2018-04-19 20:29:43 --> Input Class Initialized
INFO - 2018-04-19 20:29:43 --> Language Class Initialized
INFO - 2018-04-19 20:29:43 --> Loader Class Initialized
INFO - 2018-04-19 20:29:43 --> Helper loaded: url_helper
INFO - 2018-04-19 20:29:43 --> Helper loaded: form_helper
INFO - 2018-04-19 20:29:43 --> Helper loaded: language_helper
DEBUG - 2018-04-19 20:29:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 20:29:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 20:29:44 --> User Agent Class Initialized
INFO - 2018-04-19 20:29:44 --> Controller Class Initialized
INFO - 2018-04-19 20:29:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 20:29:44 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-19 20:29:44 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-19 20:29:44 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 20:29:44 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 20:29:44 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-19 20:29:44 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-19 20:29:44 --> Could not find the language line "req_email"
INFO - 2018-04-19 20:29:44 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-04-19 20:29:44 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 20:29:44 --> Final output sent to browser
DEBUG - 2018-04-19 20:29:44 --> Total execution time: 0.6008
INFO - 2018-04-19 20:29:44 --> Config Class Initialized
INFO - 2018-04-19 20:29:44 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:29:44 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:29:44 --> Utf8 Class Initialized
INFO - 2018-04-19 20:29:44 --> Config Class Initialized
INFO - 2018-04-19 20:29:44 --> Hooks Class Initialized
INFO - 2018-04-19 20:29:44 --> URI Class Initialized
DEBUG - 2018-04-19 20:29:44 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:29:44 --> Router Class Initialized
INFO - 2018-04-19 20:29:44 --> Utf8 Class Initialized
INFO - 2018-04-19 20:29:44 --> Output Class Initialized
INFO - 2018-04-19 20:29:44 --> URI Class Initialized
INFO - 2018-04-19 20:29:44 --> Security Class Initialized
DEBUG - 2018-04-19 20:29:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:29:44 --> Router Class Initialized
INFO - 2018-04-19 20:29:44 --> CSRF cookie sent
INFO - 2018-04-19 20:29:44 --> Output Class Initialized
INFO - 2018-04-19 20:29:44 --> Input Class Initialized
INFO - 2018-04-19 20:29:44 --> Security Class Initialized
INFO - 2018-04-19 20:29:44 --> Language Class Initialized
DEBUG - 2018-04-19 20:29:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:29:44 --> CSRF cookie sent
ERROR - 2018-04-19 20:29:44 --> 404 Page Not Found: Assets/images
INFO - 2018-04-19 20:29:44 --> Input Class Initialized
INFO - 2018-04-19 20:29:44 --> Language Class Initialized
ERROR - 2018-04-19 20:29:44 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 20:30:04 --> Config Class Initialized
INFO - 2018-04-19 20:30:04 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:30:04 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:30:04 --> Utf8 Class Initialized
INFO - 2018-04-19 20:30:04 --> URI Class Initialized
INFO - 2018-04-19 20:30:04 --> Router Class Initialized
INFO - 2018-04-19 20:30:04 --> Output Class Initialized
INFO - 2018-04-19 20:30:04 --> Security Class Initialized
DEBUG - 2018-04-19 20:30:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:30:04 --> CSRF cookie sent
INFO - 2018-04-19 20:30:04 --> CSRF token verified
INFO - 2018-04-19 20:30:04 --> Input Class Initialized
INFO - 2018-04-19 20:30:04 --> Language Class Initialized
INFO - 2018-04-19 20:30:04 --> Loader Class Initialized
INFO - 2018-04-19 20:30:04 --> Helper loaded: url_helper
INFO - 2018-04-19 20:30:04 --> Helper loaded: form_helper
INFO - 2018-04-19 20:30:04 --> Helper loaded: language_helper
DEBUG - 2018-04-19 20:30:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 20:30:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 20:30:04 --> User Agent Class Initialized
INFO - 2018-04-19 20:30:04 --> Controller Class Initialized
INFO - 2018-04-19 20:30:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 20:30:04 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-19 20:30:04 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-19 20:30:04 --> Form Validation Class Initialized
INFO - 2018-04-19 20:30:04 --> Pixel_Model class loaded
INFO - 2018-04-19 20:30:04 --> Database Driver Class Initialized
INFO - 2018-04-19 20:30:04 --> Model "AuthenticationModel" initialized
INFO - 2018-04-19 20:30:05 --> Config Class Initialized
INFO - 2018-04-19 20:30:05 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:30:05 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:30:05 --> Utf8 Class Initialized
INFO - 2018-04-19 20:30:05 --> URI Class Initialized
DEBUG - 2018-04-19 20:30:05 --> No URI present. Default controller set.
INFO - 2018-04-19 20:30:05 --> Router Class Initialized
INFO - 2018-04-19 20:30:05 --> Output Class Initialized
INFO - 2018-04-19 20:30:05 --> Security Class Initialized
DEBUG - 2018-04-19 20:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:30:05 --> CSRF cookie sent
INFO - 2018-04-19 20:30:05 --> Input Class Initialized
INFO - 2018-04-19 20:30:05 --> Language Class Initialized
INFO - 2018-04-19 20:30:05 --> Loader Class Initialized
INFO - 2018-04-19 20:30:05 --> Helper loaded: url_helper
INFO - 2018-04-19 20:30:05 --> Helper loaded: form_helper
INFO - 2018-04-19 20:30:05 --> Helper loaded: language_helper
DEBUG - 2018-04-19 20:30:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 20:30:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 20:30:05 --> User Agent Class Initialized
INFO - 2018-04-19 20:30:05 --> Controller Class Initialized
INFO - 2018-04-19 20:30:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 20:30:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 20:30:05 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 20:30:05 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-19 20:30:05 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 20:30:05 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-19 20:30:05 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 20:30:05 --> Final output sent to browser
DEBUG - 2018-04-19 20:30:05 --> Total execution time: 0.4110
INFO - 2018-04-19 20:30:05 --> Config Class Initialized
INFO - 2018-04-19 20:30:05 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:30:06 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:30:06 --> Utf8 Class Initialized
INFO - 2018-04-19 20:30:06 --> URI Class Initialized
INFO - 2018-04-19 20:30:06 --> Router Class Initialized
INFO - 2018-04-19 20:30:06 --> Output Class Initialized
INFO - 2018-04-19 20:30:06 --> Security Class Initialized
DEBUG - 2018-04-19 20:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:30:06 --> CSRF cookie sent
INFO - 2018-04-19 20:30:06 --> Input Class Initialized
INFO - 2018-04-19 20:30:06 --> Language Class Initialized
ERROR - 2018-04-19 20:30:06 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 20:30:07 --> Config Class Initialized
INFO - 2018-04-19 20:30:07 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:30:07 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:30:07 --> Utf8 Class Initialized
INFO - 2018-04-19 20:30:07 --> URI Class Initialized
INFO - 2018-04-19 20:30:07 --> Router Class Initialized
INFO - 2018-04-19 20:30:07 --> Output Class Initialized
INFO - 2018-04-19 20:30:07 --> Security Class Initialized
DEBUG - 2018-04-19 20:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:30:07 --> CSRF cookie sent
INFO - 2018-04-19 20:30:08 --> Input Class Initialized
INFO - 2018-04-19 20:30:08 --> Language Class Initialized
ERROR - 2018-04-19 20:30:08 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-19 20:30:51 --> Config Class Initialized
INFO - 2018-04-19 20:30:51 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:30:51 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:30:51 --> Utf8 Class Initialized
INFO - 2018-04-19 20:30:51 --> URI Class Initialized
INFO - 2018-04-19 20:30:52 --> Router Class Initialized
INFO - 2018-04-19 20:30:52 --> Output Class Initialized
INFO - 2018-04-19 20:30:52 --> Security Class Initialized
DEBUG - 2018-04-19 20:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:30:52 --> CSRF cookie sent
INFO - 2018-04-19 20:30:52 --> Input Class Initialized
INFO - 2018-04-19 20:30:52 --> Language Class Initialized
INFO - 2018-04-19 20:30:52 --> Loader Class Initialized
INFO - 2018-04-19 20:30:52 --> Helper loaded: url_helper
INFO - 2018-04-19 20:30:52 --> Helper loaded: form_helper
INFO - 2018-04-19 20:30:52 --> Helper loaded: language_helper
DEBUG - 2018-04-19 20:30:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 20:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 20:30:52 --> User Agent Class Initialized
INFO - 2018-04-19 20:30:52 --> Controller Class Initialized
INFO - 2018-04-19 20:30:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 20:30:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 20:30:52 --> Pixel_Model class loaded
INFO - 2018-04-19 20:30:52 --> Database Driver Class Initialized
INFO - 2018-04-19 20:30:52 --> Model "MyAccountModel" initialized
INFO - 2018-04-19 20:30:52 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 20:30:52 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-19 20:30:52 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 20:30:52 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-19 20:30:52 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-19 20:30:52 --> File loaded: E:\www\yacopoo\application\views\register/import_enduser.php
INFO - 2018-04-19 20:30:52 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 20:30:52 --> Final output sent to browser
DEBUG - 2018-04-19 20:30:52 --> Total execution time: 0.5123
INFO - 2018-04-19 20:30:52 --> Config Class Initialized
INFO - 2018-04-19 20:30:52 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:30:52 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:30:52 --> Utf8 Class Initialized
INFO - 2018-04-19 20:30:52 --> URI Class Initialized
INFO - 2018-04-19 20:30:52 --> Router Class Initialized
INFO - 2018-04-19 20:30:53 --> Output Class Initialized
INFO - 2018-04-19 20:30:53 --> Security Class Initialized
DEBUG - 2018-04-19 20:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:30:53 --> CSRF cookie sent
INFO - 2018-04-19 20:30:53 --> Input Class Initialized
INFO - 2018-04-19 20:30:53 --> Language Class Initialized
ERROR - 2018-04-19 20:30:53 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 20:56:27 --> Config Class Initialized
INFO - 2018-04-19 20:56:27 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:56:27 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:56:27 --> Utf8 Class Initialized
INFO - 2018-04-19 20:56:27 --> URI Class Initialized
INFO - 2018-04-19 20:56:27 --> Router Class Initialized
INFO - 2018-04-19 20:56:27 --> Output Class Initialized
INFO - 2018-04-19 20:56:27 --> Security Class Initialized
DEBUG - 2018-04-19 20:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:56:27 --> CSRF cookie sent
INFO - 2018-04-19 20:56:27 --> Input Class Initialized
INFO - 2018-04-19 20:56:27 --> Language Class Initialized
INFO - 2018-04-19 20:56:27 --> Loader Class Initialized
INFO - 2018-04-19 20:56:27 --> Helper loaded: url_helper
INFO - 2018-04-19 20:56:27 --> Helper loaded: form_helper
INFO - 2018-04-19 20:56:27 --> Helper loaded: language_helper
DEBUG - 2018-04-19 20:56:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 20:56:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 20:56:27 --> User Agent Class Initialized
INFO - 2018-04-19 20:56:27 --> Controller Class Initialized
INFO - 2018-04-19 20:56:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 20:56:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 20:56:27 --> Pixel_Model class loaded
INFO - 2018-04-19 20:56:27 --> Database Driver Class Initialized
INFO - 2018-04-19 20:56:27 --> Model "MyAccountModel" initialized
INFO - 2018-04-19 20:56:27 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 20:56:27 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-19 20:56:27 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 20:56:27 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-19 20:56:27 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-19 20:56:27 --> Could not find the language line "req_email"
INFO - 2018-04-19 20:56:27 --> File loaded: E:\www\yacopoo\application\views\register/add_client.php
INFO - 2018-04-19 20:56:27 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 20:56:27 --> Final output sent to browser
DEBUG - 2018-04-19 20:56:27 --> Total execution time: 0.5094
INFO - 2018-04-19 20:56:28 --> Config Class Initialized
INFO - 2018-04-19 20:56:28 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:56:28 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:56:28 --> Utf8 Class Initialized
INFO - 2018-04-19 20:56:28 --> URI Class Initialized
INFO - 2018-04-19 20:56:28 --> Router Class Initialized
INFO - 2018-04-19 20:56:28 --> Output Class Initialized
INFO - 2018-04-19 20:56:28 --> Security Class Initialized
DEBUG - 2018-04-19 20:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:56:28 --> CSRF cookie sent
INFO - 2018-04-19 20:56:28 --> Input Class Initialized
INFO - 2018-04-19 20:56:28 --> Language Class Initialized
ERROR - 2018-04-19 20:56:28 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 20:59:44 --> Config Class Initialized
INFO - 2018-04-19 20:59:44 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:59:44 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:59:44 --> Utf8 Class Initialized
INFO - 2018-04-19 20:59:44 --> URI Class Initialized
INFO - 2018-04-19 20:59:44 --> Router Class Initialized
INFO - 2018-04-19 20:59:44 --> Output Class Initialized
INFO - 2018-04-19 20:59:44 --> Security Class Initialized
DEBUG - 2018-04-19 20:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:59:44 --> CSRF cookie sent
INFO - 2018-04-19 20:59:44 --> Input Class Initialized
INFO - 2018-04-19 20:59:44 --> Language Class Initialized
INFO - 2018-04-19 20:59:44 --> Loader Class Initialized
INFO - 2018-04-19 20:59:44 --> Helper loaded: url_helper
INFO - 2018-04-19 20:59:44 --> Helper loaded: form_helper
INFO - 2018-04-19 20:59:44 --> Helper loaded: language_helper
DEBUG - 2018-04-19 20:59:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 20:59:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 20:59:44 --> User Agent Class Initialized
INFO - 2018-04-19 20:59:44 --> Controller Class Initialized
INFO - 2018-04-19 20:59:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 20:59:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 20:59:44 --> Pixel_Model class loaded
INFO - 2018-04-19 20:59:44 --> Database Driver Class Initialized
INFO - 2018-04-19 20:59:44 --> Model "MyAccountModel" initialized
INFO - 2018-04-19 20:59:44 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 20:59:44 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-19 20:59:44 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 20:59:44 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-19 20:59:45 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-19 20:59:45 --> Could not find the language line "req_email"
INFO - 2018-04-19 20:59:45 --> File loaded: E:\www\yacopoo\application\views\register/add_client.php
INFO - 2018-04-19 20:59:45 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 20:59:45 --> Final output sent to browser
DEBUG - 2018-04-19 20:59:45 --> Total execution time: 0.5028
INFO - 2018-04-19 20:59:45 --> Config Class Initialized
INFO - 2018-04-19 20:59:45 --> Hooks Class Initialized
DEBUG - 2018-04-19 20:59:45 --> UTF-8 Support Enabled
INFO - 2018-04-19 20:59:45 --> Utf8 Class Initialized
INFO - 2018-04-19 20:59:45 --> URI Class Initialized
INFO - 2018-04-19 20:59:45 --> Router Class Initialized
INFO - 2018-04-19 20:59:45 --> Output Class Initialized
INFO - 2018-04-19 20:59:45 --> Security Class Initialized
DEBUG - 2018-04-19 20:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 20:59:45 --> CSRF cookie sent
INFO - 2018-04-19 20:59:45 --> Input Class Initialized
INFO - 2018-04-19 20:59:45 --> Language Class Initialized
ERROR - 2018-04-19 20:59:45 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 21:00:06 --> Config Class Initialized
INFO - 2018-04-19 21:00:06 --> Hooks Class Initialized
DEBUG - 2018-04-19 21:00:06 --> UTF-8 Support Enabled
INFO - 2018-04-19 21:00:06 --> Utf8 Class Initialized
INFO - 2018-04-19 21:00:06 --> URI Class Initialized
INFO - 2018-04-19 21:00:06 --> Router Class Initialized
INFO - 2018-04-19 21:00:06 --> Output Class Initialized
INFO - 2018-04-19 21:00:06 --> Security Class Initialized
DEBUG - 2018-04-19 21:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 21:00:07 --> CSRF cookie sent
INFO - 2018-04-19 21:00:07 --> CSRF token verified
INFO - 2018-04-19 21:00:07 --> Input Class Initialized
INFO - 2018-04-19 21:00:07 --> Language Class Initialized
INFO - 2018-04-19 21:00:07 --> Loader Class Initialized
INFO - 2018-04-19 21:00:07 --> Helper loaded: url_helper
INFO - 2018-04-19 21:00:07 --> Helper loaded: form_helper
INFO - 2018-04-19 21:00:07 --> Helper loaded: language_helper
DEBUG - 2018-04-19 21:00:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 21:00:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 21:00:07 --> User Agent Class Initialized
INFO - 2018-04-19 21:00:07 --> Controller Class Initialized
INFO - 2018-04-19 21:00:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 21:00:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 21:00:07 --> Form Validation Class Initialized
INFO - 2018-04-19 21:00:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-19 21:00:07 --> Pixel_Model class loaded
INFO - 2018-04-19 21:00:07 --> Database Driver Class Initialized
INFO - 2018-04-19 21:00:07 --> Model "RegistrationModel" initialized
INFO - 2018-04-19 21:00:07 --> Helper loaded: string_helper
INFO - 2018-04-19 21:00:07 --> Language file loaded: language/en/notifications_lang.php
INFO - 2018-04-19 21:00:07 --> File loaded: E:\www\yacopoo\application\views\emails/_buttons.php
INFO - 2018-04-19 21:00:07 --> File loaded: E:\www\yacopoo\application\views\emails/header.php
INFO - 2018-04-19 21:00:07 --> File loaded: E:\www\yacopoo\application\views\emails/footer.php
INFO - 2018-04-19 21:00:07 --> File loaded: E:\www\yacopoo\application\views\emails/generic.php
INFO - 2018-04-19 21:00:07 --> Email Class Initialized
INFO - 2018-04-19 21:00:07 --> Final output sent to browser
DEBUG - 2018-04-19 21:00:07 --> Total execution time: 0.7805
INFO - 2018-04-19 21:00:07 --> Config Class Initialized
INFO - 2018-04-19 21:00:07 --> Hooks Class Initialized
DEBUG - 2018-04-19 21:00:07 --> UTF-8 Support Enabled
INFO - 2018-04-19 21:00:07 --> Utf8 Class Initialized
INFO - 2018-04-19 21:00:07 --> URI Class Initialized
INFO - 2018-04-19 21:00:07 --> Router Class Initialized
INFO - 2018-04-19 21:00:07 --> Output Class Initialized
INFO - 2018-04-19 21:00:07 --> Security Class Initialized
DEBUG - 2018-04-19 21:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 21:00:07 --> CSRF cookie sent
INFO - 2018-04-19 21:00:07 --> Input Class Initialized
INFO - 2018-04-19 21:00:07 --> Language Class Initialized
ERROR - 2018-04-19 21:00:07 --> 404 Page Not Found: Assets/images
INFO - 2018-04-19 21:00:32 --> Config Class Initialized
INFO - 2018-04-19 21:00:32 --> Hooks Class Initialized
DEBUG - 2018-04-19 21:00:32 --> UTF-8 Support Enabled
INFO - 2018-04-19 21:00:32 --> Utf8 Class Initialized
INFO - 2018-04-19 21:00:32 --> URI Class Initialized
DEBUG - 2018-04-19 21:00:32 --> No URI present. Default controller set.
INFO - 2018-04-19 21:00:32 --> Router Class Initialized
INFO - 2018-04-19 21:00:32 --> Output Class Initialized
INFO - 2018-04-19 21:00:33 --> Security Class Initialized
DEBUG - 2018-04-19 21:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 21:00:33 --> CSRF cookie sent
INFO - 2018-04-19 21:00:33 --> Input Class Initialized
INFO - 2018-04-19 21:00:33 --> Language Class Initialized
INFO - 2018-04-19 21:00:33 --> Loader Class Initialized
INFO - 2018-04-19 21:00:33 --> Helper loaded: url_helper
INFO - 2018-04-19 21:00:33 --> Helper loaded: form_helper
INFO - 2018-04-19 21:00:33 --> Helper loaded: language_helper
DEBUG - 2018-04-19 21:00:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 21:00:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 21:00:33 --> User Agent Class Initialized
INFO - 2018-04-19 21:00:33 --> Controller Class Initialized
INFO - 2018-04-19 21:00:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 21:00:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 21:00:33 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 21:00:33 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-19 21:00:33 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 21:00:33 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-19 21:00:33 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 21:00:33 --> Final output sent to browser
DEBUG - 2018-04-19 21:00:33 --> Total execution time: 0.4355
INFO - 2018-04-19 21:00:33 --> Config Class Initialized
INFO - 2018-04-19 21:00:33 --> Hooks Class Initialized
DEBUG - 2018-04-19 21:00:33 --> UTF-8 Support Enabled
INFO - 2018-04-19 21:00:33 --> Utf8 Class Initialized
INFO - 2018-04-19 21:00:33 --> URI Class Initialized
INFO - 2018-04-19 21:00:33 --> Router Class Initialized
INFO - 2018-04-19 21:00:33 --> Output Class Initialized
INFO - 2018-04-19 21:00:33 --> Security Class Initialized
DEBUG - 2018-04-19 21:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 21:00:33 --> CSRF cookie sent
INFO - 2018-04-19 21:00:33 --> Input Class Initialized
INFO - 2018-04-19 21:00:33 --> Language Class Initialized
ERROR - 2018-04-19 21:00:33 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 21:00:35 --> Config Class Initialized
INFO - 2018-04-19 21:00:35 --> Hooks Class Initialized
DEBUG - 2018-04-19 21:00:35 --> UTF-8 Support Enabled
INFO - 2018-04-19 21:00:35 --> Utf8 Class Initialized
INFO - 2018-04-19 21:00:35 --> URI Class Initialized
INFO - 2018-04-19 21:00:35 --> Router Class Initialized
INFO - 2018-04-19 21:00:35 --> Output Class Initialized
INFO - 2018-04-19 21:00:35 --> Security Class Initialized
DEBUG - 2018-04-19 21:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 21:00:35 --> CSRF cookie sent
INFO - 2018-04-19 21:00:35 --> Input Class Initialized
INFO - 2018-04-19 21:00:35 --> Language Class Initialized
ERROR - 2018-04-19 21:00:35 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-19 21:00:36 --> Config Class Initialized
INFO - 2018-04-19 21:00:36 --> Hooks Class Initialized
DEBUG - 2018-04-19 21:00:36 --> UTF-8 Support Enabled
INFO - 2018-04-19 21:00:36 --> Utf8 Class Initialized
INFO - 2018-04-19 21:00:36 --> URI Class Initialized
INFO - 2018-04-19 21:00:36 --> Router Class Initialized
INFO - 2018-04-19 21:00:36 --> Output Class Initialized
INFO - 2018-04-19 21:00:36 --> Security Class Initialized
DEBUG - 2018-04-19 21:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 21:00:36 --> CSRF cookie sent
INFO - 2018-04-19 21:00:36 --> Input Class Initialized
INFO - 2018-04-19 21:00:36 --> Language Class Initialized
INFO - 2018-04-19 21:00:36 --> Loader Class Initialized
INFO - 2018-04-19 21:00:36 --> Helper loaded: url_helper
INFO - 2018-04-19 21:00:36 --> Helper loaded: form_helper
INFO - 2018-04-19 21:00:36 --> Helper loaded: language_helper
DEBUG - 2018-04-19 21:00:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 21:00:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 21:00:36 --> User Agent Class Initialized
INFO - 2018-04-19 21:00:36 --> Controller Class Initialized
INFO - 2018-04-19 21:00:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 21:00:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 21:00:36 --> CSRF cookie sent
INFO - 2018-04-19 21:00:36 --> Config Class Initialized
INFO - 2018-04-19 21:00:36 --> Hooks Class Initialized
DEBUG - 2018-04-19 21:00:37 --> UTF-8 Support Enabled
INFO - 2018-04-19 21:00:37 --> Utf8 Class Initialized
INFO - 2018-04-19 21:00:37 --> URI Class Initialized
DEBUG - 2018-04-19 21:00:37 --> No URI present. Default controller set.
INFO - 2018-04-19 21:00:37 --> Router Class Initialized
INFO - 2018-04-19 21:00:37 --> Output Class Initialized
INFO - 2018-04-19 21:00:37 --> Security Class Initialized
DEBUG - 2018-04-19 21:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 21:00:37 --> CSRF cookie sent
INFO - 2018-04-19 21:00:37 --> Input Class Initialized
INFO - 2018-04-19 21:00:37 --> Language Class Initialized
INFO - 2018-04-19 21:00:37 --> Loader Class Initialized
INFO - 2018-04-19 21:00:37 --> Helper loaded: url_helper
INFO - 2018-04-19 21:00:37 --> Helper loaded: form_helper
INFO - 2018-04-19 21:00:37 --> Helper loaded: language_helper
DEBUG - 2018-04-19 21:00:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 21:00:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 21:00:37 --> User Agent Class Initialized
INFO - 2018-04-19 21:00:37 --> Controller Class Initialized
INFO - 2018-04-19 21:00:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 21:00:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 21:00:37 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 21:00:37 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 21:00:37 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-19 21:00:37 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 21:00:37 --> Final output sent to browser
DEBUG - 2018-04-19 21:00:37 --> Total execution time: 0.4719
INFO - 2018-04-19 21:00:37 --> Config Class Initialized
INFO - 2018-04-19 21:00:37 --> Hooks Class Initialized
DEBUG - 2018-04-19 21:00:37 --> UTF-8 Support Enabled
INFO - 2018-04-19 21:00:37 --> Utf8 Class Initialized
INFO - 2018-04-19 21:00:37 --> URI Class Initialized
INFO - 2018-04-19 21:00:38 --> Router Class Initialized
INFO - 2018-04-19 21:00:38 --> Output Class Initialized
INFO - 2018-04-19 21:00:38 --> Security Class Initialized
DEBUG - 2018-04-19 21:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 21:00:38 --> CSRF cookie sent
INFO - 2018-04-19 21:00:38 --> Input Class Initialized
INFO - 2018-04-19 21:00:38 --> Language Class Initialized
ERROR - 2018-04-19 21:00:38 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 21:00:39 --> Config Class Initialized
INFO - 2018-04-19 21:00:39 --> Hooks Class Initialized
DEBUG - 2018-04-19 21:00:39 --> UTF-8 Support Enabled
INFO - 2018-04-19 21:00:39 --> Utf8 Class Initialized
INFO - 2018-04-19 21:00:39 --> URI Class Initialized
INFO - 2018-04-19 21:00:39 --> Router Class Initialized
INFO - 2018-04-19 21:00:39 --> Output Class Initialized
INFO - 2018-04-19 21:00:39 --> Security Class Initialized
DEBUG - 2018-04-19 21:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 21:00:39 --> CSRF cookie sent
INFO - 2018-04-19 21:00:39 --> Input Class Initialized
INFO - 2018-04-19 21:00:39 --> Language Class Initialized
ERROR - 2018-04-19 21:00:39 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-19 21:00:39 --> Config Class Initialized
INFO - 2018-04-19 21:00:39 --> Hooks Class Initialized
DEBUG - 2018-04-19 21:00:39 --> UTF-8 Support Enabled
INFO - 2018-04-19 21:00:40 --> Utf8 Class Initialized
INFO - 2018-04-19 21:00:40 --> URI Class Initialized
INFO - 2018-04-19 21:00:40 --> Router Class Initialized
INFO - 2018-04-19 21:00:40 --> Output Class Initialized
INFO - 2018-04-19 21:00:40 --> Security Class Initialized
DEBUG - 2018-04-19 21:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 21:00:40 --> CSRF cookie sent
INFO - 2018-04-19 21:00:40 --> Input Class Initialized
INFO - 2018-04-19 21:00:40 --> Language Class Initialized
INFO - 2018-04-19 21:00:40 --> Loader Class Initialized
INFO - 2018-04-19 21:00:40 --> Helper loaded: url_helper
INFO - 2018-04-19 21:00:40 --> Helper loaded: form_helper
INFO - 2018-04-19 21:00:40 --> Helper loaded: language_helper
DEBUG - 2018-04-19 21:00:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 21:00:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 21:00:42 --> User Agent Class Initialized
INFO - 2018-04-19 21:00:42 --> Controller Class Initialized
INFO - 2018-04-19 21:00:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 21:00:42 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-19 21:00:42 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-19 21:00:42 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 21:00:42 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 21:00:42 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-19 21:00:42 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-19 21:00:42 --> Could not find the language line "req_email"
INFO - 2018-04-19 21:00:42 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-04-19 21:00:42 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 21:00:42 --> Final output sent to browser
DEBUG - 2018-04-19 21:00:42 --> Total execution time: 2.9209
INFO - 2018-04-19 21:00:43 --> Config Class Initialized
INFO - 2018-04-19 21:00:43 --> Hooks Class Initialized
DEBUG - 2018-04-19 21:00:43 --> UTF-8 Support Enabled
INFO - 2018-04-19 21:00:43 --> Utf8 Class Initialized
INFO - 2018-04-19 21:00:43 --> Config Class Initialized
INFO - 2018-04-19 21:00:43 --> Hooks Class Initialized
INFO - 2018-04-19 21:00:43 --> URI Class Initialized
DEBUG - 2018-04-19 21:00:43 --> UTF-8 Support Enabled
INFO - 2018-04-19 21:00:43 --> Router Class Initialized
INFO - 2018-04-19 21:00:43 --> Utf8 Class Initialized
INFO - 2018-04-19 21:00:43 --> Output Class Initialized
INFO - 2018-04-19 21:00:43 --> URI Class Initialized
INFO - 2018-04-19 21:00:43 --> Security Class Initialized
INFO - 2018-04-19 21:00:43 --> Router Class Initialized
DEBUG - 2018-04-19 21:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 21:00:43 --> CSRF cookie sent
INFO - 2018-04-19 21:00:43 --> Output Class Initialized
INFO - 2018-04-19 21:00:43 --> Input Class Initialized
INFO - 2018-04-19 21:00:43 --> Security Class Initialized
INFO - 2018-04-19 21:00:43 --> Language Class Initialized
DEBUG - 2018-04-19 21:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 21:00:43 --> CSRF cookie sent
ERROR - 2018-04-19 21:00:43 --> 404 Page Not Found: Assets/images
INFO - 2018-04-19 21:00:43 --> Input Class Initialized
INFO - 2018-04-19 21:00:43 --> Language Class Initialized
ERROR - 2018-04-19 21:00:43 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 21:00:45 --> Config Class Initialized
INFO - 2018-04-19 21:00:45 --> Hooks Class Initialized
DEBUG - 2018-04-19 21:00:45 --> UTF-8 Support Enabled
INFO - 2018-04-19 21:00:45 --> Utf8 Class Initialized
INFO - 2018-04-19 21:00:45 --> URI Class Initialized
INFO - 2018-04-19 21:00:45 --> Router Class Initialized
INFO - 2018-04-19 21:00:45 --> Output Class Initialized
INFO - 2018-04-19 21:00:45 --> Security Class Initialized
DEBUG - 2018-04-19 21:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 21:00:45 --> CSRF cookie sent
INFO - 2018-04-19 21:00:45 --> Input Class Initialized
INFO - 2018-04-19 21:00:45 --> Language Class Initialized
INFO - 2018-04-19 21:00:45 --> Loader Class Initialized
INFO - 2018-04-19 21:00:45 --> Helper loaded: url_helper
INFO - 2018-04-19 21:00:45 --> Helper loaded: form_helper
INFO - 2018-04-19 21:00:45 --> Helper loaded: language_helper
DEBUG - 2018-04-19 21:00:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 21:00:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 21:00:45 --> User Agent Class Initialized
INFO - 2018-04-19 21:00:45 --> Controller Class Initialized
INFO - 2018-04-19 21:00:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 21:00:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 21:00:45 --> Pixel_Model class loaded
INFO - 2018-04-19 21:00:45 --> Database Driver Class Initialized
INFO - 2018-04-19 21:00:45 --> Model "RegistrationModel" initialized
INFO - 2018-04-19 21:00:45 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 21:00:45 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 21:00:45 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-19 21:00:45 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-19 21:00:45 --> File loaded: E:\www\yacopoo\application\views\register/complete_registration.php
INFO - 2018-04-19 21:00:45 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 21:00:45 --> Final output sent to browser
DEBUG - 2018-04-19 21:00:45 --> Total execution time: 0.5589
INFO - 2018-04-19 21:00:46 --> Config Class Initialized
INFO - 2018-04-19 21:00:46 --> Hooks Class Initialized
DEBUG - 2018-04-19 21:00:46 --> UTF-8 Support Enabled
INFO - 2018-04-19 21:00:46 --> Utf8 Class Initialized
INFO - 2018-04-19 21:00:46 --> URI Class Initialized
INFO - 2018-04-19 21:00:46 --> Router Class Initialized
INFO - 2018-04-19 21:00:46 --> Output Class Initialized
INFO - 2018-04-19 21:00:46 --> Security Class Initialized
DEBUG - 2018-04-19 21:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 21:00:46 --> CSRF cookie sent
INFO - 2018-04-19 21:00:46 --> Input Class Initialized
INFO - 2018-04-19 21:00:46 --> Language Class Initialized
ERROR - 2018-04-19 21:00:46 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 21:00:54 --> Config Class Initialized
INFO - 2018-04-19 21:00:55 --> Hooks Class Initialized
DEBUG - 2018-04-19 21:00:55 --> UTF-8 Support Enabled
INFO - 2018-04-19 21:00:55 --> Utf8 Class Initialized
INFO - 2018-04-19 21:00:55 --> URI Class Initialized
INFO - 2018-04-19 21:00:55 --> Router Class Initialized
INFO - 2018-04-19 21:00:55 --> Output Class Initialized
INFO - 2018-04-19 21:00:55 --> Security Class Initialized
DEBUG - 2018-04-19 21:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 21:00:55 --> CSRF cookie sent
INFO - 2018-04-19 21:00:55 --> CSRF token verified
INFO - 2018-04-19 21:00:55 --> Input Class Initialized
INFO - 2018-04-19 21:00:55 --> Language Class Initialized
INFO - 2018-04-19 21:00:55 --> Loader Class Initialized
INFO - 2018-04-19 21:00:55 --> Helper loaded: url_helper
INFO - 2018-04-19 21:00:55 --> Helper loaded: form_helper
INFO - 2018-04-19 21:00:55 --> Helper loaded: language_helper
DEBUG - 2018-04-19 21:00:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 21:00:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 21:00:55 --> User Agent Class Initialized
INFO - 2018-04-19 21:00:55 --> Controller Class Initialized
INFO - 2018-04-19 21:00:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 21:00:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 21:00:55 --> Pixel_Model class loaded
INFO - 2018-04-19 21:00:55 --> Database Driver Class Initialized
INFO - 2018-04-19 21:00:55 --> Model "RegistrationModel" initialized
INFO - 2018-04-19 21:00:55 --> Form Validation Class Initialized
INFO - 2018-04-19 21:00:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-19 21:00:55 --> Config Class Initialized
INFO - 2018-04-19 21:00:55 --> Hooks Class Initialized
DEBUG - 2018-04-19 21:00:55 --> UTF-8 Support Enabled
INFO - 2018-04-19 21:00:55 --> Utf8 Class Initialized
INFO - 2018-04-19 21:00:55 --> URI Class Initialized
DEBUG - 2018-04-19 21:00:55 --> No URI present. Default controller set.
INFO - 2018-04-19 21:00:55 --> Router Class Initialized
INFO - 2018-04-19 21:00:55 --> Output Class Initialized
INFO - 2018-04-19 21:00:55 --> Security Class Initialized
DEBUG - 2018-04-19 21:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 21:00:55 --> CSRF cookie sent
INFO - 2018-04-19 21:00:55 --> Input Class Initialized
INFO - 2018-04-19 21:00:55 --> Language Class Initialized
INFO - 2018-04-19 21:00:55 --> Loader Class Initialized
INFO - 2018-04-19 21:00:55 --> Helper loaded: url_helper
INFO - 2018-04-19 21:00:55 --> Helper loaded: form_helper
INFO - 2018-04-19 21:00:55 --> Helper loaded: language_helper
DEBUG - 2018-04-19 21:00:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 21:00:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 21:00:55 --> User Agent Class Initialized
INFO - 2018-04-19 21:00:55 --> Controller Class Initialized
INFO - 2018-04-19 21:00:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 21:00:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 21:00:55 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 21:00:56 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-19 21:00:56 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 21:00:56 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-19 21:00:56 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 21:00:56 --> Final output sent to browser
DEBUG - 2018-04-19 21:00:56 --> Total execution time: 0.4268
INFO - 2018-04-19 21:00:56 --> Config Class Initialized
INFO - 2018-04-19 21:00:56 --> Hooks Class Initialized
DEBUG - 2018-04-19 21:00:56 --> UTF-8 Support Enabled
INFO - 2018-04-19 21:00:56 --> Utf8 Class Initialized
INFO - 2018-04-19 21:00:56 --> URI Class Initialized
INFO - 2018-04-19 21:00:56 --> Router Class Initialized
INFO - 2018-04-19 21:00:56 --> Output Class Initialized
INFO - 2018-04-19 21:00:56 --> Security Class Initialized
DEBUG - 2018-04-19 21:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 21:00:56 --> CSRF cookie sent
INFO - 2018-04-19 21:00:56 --> Input Class Initialized
INFO - 2018-04-19 21:00:56 --> Language Class Initialized
ERROR - 2018-04-19 21:00:56 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 21:00:58 --> Config Class Initialized
INFO - 2018-04-19 21:00:58 --> Hooks Class Initialized
DEBUG - 2018-04-19 21:00:58 --> UTF-8 Support Enabled
INFO - 2018-04-19 21:00:59 --> Utf8 Class Initialized
INFO - 2018-04-19 21:00:59 --> URI Class Initialized
INFO - 2018-04-19 21:00:59 --> Router Class Initialized
INFO - 2018-04-19 21:00:59 --> Output Class Initialized
INFO - 2018-04-19 21:00:59 --> Security Class Initialized
DEBUG - 2018-04-19 21:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 21:00:59 --> CSRF cookie sent
INFO - 2018-04-19 21:00:59 --> Input Class Initialized
INFO - 2018-04-19 21:00:59 --> Language Class Initialized
ERROR - 2018-04-19 21:00:59 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-19 21:00:59 --> Config Class Initialized
INFO - 2018-04-19 21:00:59 --> Hooks Class Initialized
DEBUG - 2018-04-19 21:00:59 --> UTF-8 Support Enabled
INFO - 2018-04-19 21:00:59 --> Utf8 Class Initialized
INFO - 2018-04-19 21:00:59 --> URI Class Initialized
INFO - 2018-04-19 21:00:59 --> Router Class Initialized
INFO - 2018-04-19 21:00:59 --> Output Class Initialized
INFO - 2018-04-19 21:00:59 --> Security Class Initialized
DEBUG - 2018-04-19 21:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 21:00:59 --> CSRF cookie sent
INFO - 2018-04-19 21:00:59 --> Input Class Initialized
INFO - 2018-04-19 21:00:59 --> Language Class Initialized
INFO - 2018-04-19 21:00:59 --> Loader Class Initialized
INFO - 2018-04-19 21:00:59 --> Helper loaded: url_helper
INFO - 2018-04-19 21:00:59 --> Helper loaded: form_helper
INFO - 2018-04-19 21:00:59 --> Helper loaded: language_helper
DEBUG - 2018-04-19 21:00:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 21:00:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 21:01:00 --> User Agent Class Initialized
INFO - 2018-04-19 21:01:00 --> Controller Class Initialized
INFO - 2018-04-19 21:01:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 21:01:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 21:01:00 --> CSRF cookie sent
INFO - 2018-04-19 21:01:00 --> Config Class Initialized
INFO - 2018-04-19 21:01:00 --> Hooks Class Initialized
DEBUG - 2018-04-19 21:01:00 --> UTF-8 Support Enabled
INFO - 2018-04-19 21:01:00 --> Utf8 Class Initialized
INFO - 2018-04-19 21:01:00 --> URI Class Initialized
DEBUG - 2018-04-19 21:01:00 --> No URI present. Default controller set.
INFO - 2018-04-19 21:01:00 --> Router Class Initialized
INFO - 2018-04-19 21:01:00 --> Output Class Initialized
INFO - 2018-04-19 21:01:00 --> Security Class Initialized
DEBUG - 2018-04-19 21:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 21:01:00 --> CSRF cookie sent
INFO - 2018-04-19 21:01:00 --> Input Class Initialized
INFO - 2018-04-19 21:01:00 --> Language Class Initialized
INFO - 2018-04-19 21:01:00 --> Loader Class Initialized
INFO - 2018-04-19 21:01:00 --> Helper loaded: url_helper
INFO - 2018-04-19 21:01:00 --> Helper loaded: form_helper
INFO - 2018-04-19 21:01:00 --> Helper loaded: language_helper
DEBUG - 2018-04-19 21:01:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 21:01:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 21:01:00 --> User Agent Class Initialized
INFO - 2018-04-19 21:01:00 --> Controller Class Initialized
INFO - 2018-04-19 21:01:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 21:01:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 21:01:00 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 21:01:00 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 21:01:00 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-19 21:01:00 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 21:01:00 --> Final output sent to browser
DEBUG - 2018-04-19 21:01:00 --> Total execution time: 0.4953
INFO - 2018-04-19 21:01:01 --> Config Class Initialized
INFO - 2018-04-19 21:01:01 --> Hooks Class Initialized
DEBUG - 2018-04-19 21:01:01 --> UTF-8 Support Enabled
INFO - 2018-04-19 21:01:01 --> Utf8 Class Initialized
INFO - 2018-04-19 21:01:01 --> URI Class Initialized
INFO - 2018-04-19 21:01:01 --> Router Class Initialized
INFO - 2018-04-19 21:01:01 --> Output Class Initialized
INFO - 2018-04-19 21:01:01 --> Security Class Initialized
DEBUG - 2018-04-19 21:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 21:01:01 --> CSRF cookie sent
INFO - 2018-04-19 21:01:01 --> Input Class Initialized
INFO - 2018-04-19 21:01:01 --> Language Class Initialized
ERROR - 2018-04-19 21:01:01 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 21:01:02 --> Config Class Initialized
INFO - 2018-04-19 21:01:02 --> Hooks Class Initialized
DEBUG - 2018-04-19 21:01:02 --> UTF-8 Support Enabled
INFO - 2018-04-19 21:01:02 --> Utf8 Class Initialized
INFO - 2018-04-19 21:01:02 --> URI Class Initialized
INFO - 2018-04-19 21:01:02 --> Router Class Initialized
INFO - 2018-04-19 21:01:02 --> Output Class Initialized
INFO - 2018-04-19 21:01:02 --> Security Class Initialized
DEBUG - 2018-04-19 21:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 21:01:02 --> CSRF cookie sent
INFO - 2018-04-19 21:01:02 --> Input Class Initialized
INFO - 2018-04-19 21:01:02 --> Language Class Initialized
ERROR - 2018-04-19 21:01:02 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-19 21:01:02 --> Config Class Initialized
INFO - 2018-04-19 21:01:02 --> Hooks Class Initialized
DEBUG - 2018-04-19 21:01:02 --> UTF-8 Support Enabled
INFO - 2018-04-19 21:01:02 --> Utf8 Class Initialized
INFO - 2018-04-19 21:01:02 --> URI Class Initialized
INFO - 2018-04-19 21:01:02 --> Router Class Initialized
INFO - 2018-04-19 21:01:02 --> Output Class Initialized
INFO - 2018-04-19 21:01:02 --> Security Class Initialized
DEBUG - 2018-04-19 21:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 21:01:02 --> CSRF cookie sent
INFO - 2018-04-19 21:01:03 --> Input Class Initialized
INFO - 2018-04-19 21:01:03 --> Language Class Initialized
INFO - 2018-04-19 21:01:03 --> Loader Class Initialized
INFO - 2018-04-19 21:01:03 --> Helper loaded: url_helper
INFO - 2018-04-19 21:01:03 --> Helper loaded: form_helper
INFO - 2018-04-19 21:01:03 --> Helper loaded: language_helper
DEBUG - 2018-04-19 21:01:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 21:01:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 21:01:03 --> User Agent Class Initialized
INFO - 2018-04-19 21:01:03 --> Controller Class Initialized
INFO - 2018-04-19 21:01:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 21:01:03 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-19 21:01:03 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-19 21:01:03 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 21:01:03 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 21:01:03 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-19 21:01:03 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-19 21:01:03 --> Could not find the language line "req_email"
INFO - 2018-04-19 21:01:03 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-04-19 21:01:03 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 21:01:03 --> Final output sent to browser
DEBUG - 2018-04-19 21:01:03 --> Total execution time: 0.6379
INFO - 2018-04-19 21:01:03 --> Config Class Initialized
INFO - 2018-04-19 21:01:03 --> Hooks Class Initialized
INFO - 2018-04-19 21:01:03 --> Config Class Initialized
INFO - 2018-04-19 21:01:03 --> Hooks Class Initialized
DEBUG - 2018-04-19 21:01:03 --> UTF-8 Support Enabled
INFO - 2018-04-19 21:01:03 --> Utf8 Class Initialized
DEBUG - 2018-04-19 21:01:03 --> UTF-8 Support Enabled
INFO - 2018-04-19 21:01:03 --> Utf8 Class Initialized
INFO - 2018-04-19 21:01:03 --> URI Class Initialized
INFO - 2018-04-19 21:01:03 --> URI Class Initialized
INFO - 2018-04-19 21:01:03 --> Router Class Initialized
INFO - 2018-04-19 21:01:03 --> Output Class Initialized
INFO - 2018-04-19 21:01:03 --> Router Class Initialized
INFO - 2018-04-19 21:01:04 --> Output Class Initialized
INFO - 2018-04-19 21:01:04 --> Security Class Initialized
INFO - 2018-04-19 21:01:04 --> Security Class Initialized
DEBUG - 2018-04-19 21:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 21:01:04 --> CSRF cookie sent
DEBUG - 2018-04-19 21:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 21:01:04 --> CSRF cookie sent
INFO - 2018-04-19 21:01:04 --> Input Class Initialized
INFO - 2018-04-19 21:01:04 --> Input Class Initialized
INFO - 2018-04-19 21:01:04 --> Language Class Initialized
INFO - 2018-04-19 21:01:04 --> Language Class Initialized
ERROR - 2018-04-19 21:01:04 --> 404 Page Not Found: Assets/css
ERROR - 2018-04-19 21:01:04 --> 404 Page Not Found: Assets/images
INFO - 2018-04-19 21:01:34 --> Config Class Initialized
INFO - 2018-04-19 21:01:34 --> Hooks Class Initialized
DEBUG - 2018-04-19 21:01:34 --> UTF-8 Support Enabled
INFO - 2018-04-19 21:01:34 --> Utf8 Class Initialized
INFO - 2018-04-19 21:01:34 --> URI Class Initialized
INFO - 2018-04-19 21:01:34 --> Router Class Initialized
INFO - 2018-04-19 21:01:34 --> Output Class Initialized
INFO - 2018-04-19 21:01:34 --> Security Class Initialized
DEBUG - 2018-04-19 21:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 21:01:34 --> CSRF cookie sent
INFO - 2018-04-19 21:01:34 --> CSRF token verified
INFO - 2018-04-19 21:01:34 --> Input Class Initialized
INFO - 2018-04-19 21:01:34 --> Language Class Initialized
INFO - 2018-04-19 21:01:34 --> Loader Class Initialized
INFO - 2018-04-19 21:01:34 --> Helper loaded: url_helper
INFO - 2018-04-19 21:01:34 --> Helper loaded: form_helper
INFO - 2018-04-19 21:01:34 --> Helper loaded: language_helper
DEBUG - 2018-04-19 21:01:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 21:01:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 21:01:34 --> User Agent Class Initialized
INFO - 2018-04-19 21:01:34 --> Controller Class Initialized
INFO - 2018-04-19 21:01:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 21:01:34 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-19 21:01:34 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-19 21:01:35 --> Form Validation Class Initialized
INFO - 2018-04-19 21:01:35 --> Pixel_Model class loaded
INFO - 2018-04-19 21:01:35 --> Database Driver Class Initialized
INFO - 2018-04-19 21:01:35 --> Model "AuthenticationModel" initialized
INFO - 2018-04-19 21:01:36 --> Config Class Initialized
INFO - 2018-04-19 21:01:36 --> Hooks Class Initialized
DEBUG - 2018-04-19 21:01:36 --> UTF-8 Support Enabled
INFO - 2018-04-19 21:01:36 --> Utf8 Class Initialized
INFO - 2018-04-19 21:01:36 --> URI Class Initialized
DEBUG - 2018-04-19 21:01:36 --> No URI present. Default controller set.
INFO - 2018-04-19 21:01:36 --> Router Class Initialized
INFO - 2018-04-19 21:01:36 --> Output Class Initialized
INFO - 2018-04-19 21:01:36 --> Security Class Initialized
DEBUG - 2018-04-19 21:01:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 21:01:36 --> CSRF cookie sent
INFO - 2018-04-19 21:01:36 --> Input Class Initialized
INFO - 2018-04-19 21:01:36 --> Language Class Initialized
INFO - 2018-04-19 21:01:36 --> Loader Class Initialized
INFO - 2018-04-19 21:01:36 --> Helper loaded: url_helper
INFO - 2018-04-19 21:01:36 --> Helper loaded: form_helper
INFO - 2018-04-19 21:01:36 --> Helper loaded: language_helper
DEBUG - 2018-04-19 21:01:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 21:01:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 21:01:36 --> User Agent Class Initialized
INFO - 2018-04-19 21:01:36 --> Controller Class Initialized
INFO - 2018-04-19 21:01:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 21:01:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 21:01:36 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 21:01:36 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-19 21:01:36 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 21:01:36 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-19 21:01:36 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 21:01:36 --> Final output sent to browser
DEBUG - 2018-04-19 21:01:36 --> Total execution time: 0.4374
INFO - 2018-04-19 21:01:36 --> Config Class Initialized
INFO - 2018-04-19 21:01:36 --> Hooks Class Initialized
DEBUG - 2018-04-19 21:01:36 --> UTF-8 Support Enabled
INFO - 2018-04-19 21:01:36 --> Utf8 Class Initialized
INFO - 2018-04-19 21:01:36 --> URI Class Initialized
INFO - 2018-04-19 21:01:37 --> Router Class Initialized
INFO - 2018-04-19 21:01:37 --> Output Class Initialized
INFO - 2018-04-19 21:01:37 --> Security Class Initialized
DEBUG - 2018-04-19 21:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 21:01:37 --> CSRF cookie sent
INFO - 2018-04-19 21:01:37 --> Input Class Initialized
INFO - 2018-04-19 21:01:37 --> Language Class Initialized
ERROR - 2018-04-19 21:01:37 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 21:01:38 --> Config Class Initialized
INFO - 2018-04-19 21:01:38 --> Hooks Class Initialized
DEBUG - 2018-04-19 21:01:38 --> UTF-8 Support Enabled
INFO - 2018-04-19 21:01:38 --> Utf8 Class Initialized
INFO - 2018-04-19 21:01:38 --> URI Class Initialized
INFO - 2018-04-19 21:01:38 --> Router Class Initialized
INFO - 2018-04-19 21:01:38 --> Output Class Initialized
INFO - 2018-04-19 21:01:38 --> Security Class Initialized
DEBUG - 2018-04-19 21:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 21:01:38 --> CSRF cookie sent
INFO - 2018-04-19 21:01:38 --> Input Class Initialized
INFO - 2018-04-19 21:01:38 --> Language Class Initialized
ERROR - 2018-04-19 21:01:38 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-19 21:01:42 --> Config Class Initialized
INFO - 2018-04-19 21:01:42 --> Hooks Class Initialized
DEBUG - 2018-04-19 21:01:42 --> UTF-8 Support Enabled
INFO - 2018-04-19 21:01:42 --> Utf8 Class Initialized
INFO - 2018-04-19 21:01:42 --> URI Class Initialized
INFO - 2018-04-19 21:01:42 --> Router Class Initialized
INFO - 2018-04-19 21:01:42 --> Output Class Initialized
INFO - 2018-04-19 21:01:42 --> Security Class Initialized
DEBUG - 2018-04-19 21:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 21:01:42 --> CSRF cookie sent
INFO - 2018-04-19 21:01:42 --> Input Class Initialized
INFO - 2018-04-19 21:01:42 --> Language Class Initialized
INFO - 2018-04-19 21:01:42 --> Loader Class Initialized
INFO - 2018-04-19 21:01:42 --> Helper loaded: url_helper
INFO - 2018-04-19 21:01:42 --> Helper loaded: form_helper
INFO - 2018-04-19 21:01:42 --> Helper loaded: language_helper
DEBUG - 2018-04-19 21:01:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 21:01:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 21:01:42 --> User Agent Class Initialized
INFO - 2018-04-19 21:01:42 --> Controller Class Initialized
INFO - 2018-04-19 21:01:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 21:01:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 21:01:42 --> CSRF cookie sent
INFO - 2018-04-19 21:01:42 --> Config Class Initialized
INFO - 2018-04-19 21:01:42 --> Hooks Class Initialized
DEBUG - 2018-04-19 21:01:42 --> UTF-8 Support Enabled
INFO - 2018-04-19 21:01:42 --> Utf8 Class Initialized
INFO - 2018-04-19 21:01:42 --> URI Class Initialized
DEBUG - 2018-04-19 21:01:42 --> No URI present. Default controller set.
INFO - 2018-04-19 21:01:42 --> Router Class Initialized
INFO - 2018-04-19 21:01:42 --> Output Class Initialized
INFO - 2018-04-19 21:01:42 --> Security Class Initialized
DEBUG - 2018-04-19 21:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 21:01:42 --> CSRF cookie sent
INFO - 2018-04-19 21:01:42 --> Input Class Initialized
INFO - 2018-04-19 21:01:42 --> Language Class Initialized
INFO - 2018-04-19 21:01:42 --> Loader Class Initialized
INFO - 2018-04-19 21:01:42 --> Helper loaded: url_helper
INFO - 2018-04-19 21:01:42 --> Helper loaded: form_helper
INFO - 2018-04-19 21:01:42 --> Helper loaded: language_helper
DEBUG - 2018-04-19 21:01:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 21:01:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 21:01:42 --> User Agent Class Initialized
INFO - 2018-04-19 21:01:42 --> Controller Class Initialized
INFO - 2018-04-19 21:01:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 21:01:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 21:01:42 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 21:01:42 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 21:01:42 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-19 21:01:42 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 21:01:42 --> Final output sent to browser
DEBUG - 2018-04-19 21:01:42 --> Total execution time: 0.4709
INFO - 2018-04-19 21:01:43 --> Config Class Initialized
INFO - 2018-04-19 21:01:43 --> Hooks Class Initialized
DEBUG - 2018-04-19 21:01:43 --> UTF-8 Support Enabled
INFO - 2018-04-19 21:01:43 --> Utf8 Class Initialized
INFO - 2018-04-19 21:01:43 --> URI Class Initialized
INFO - 2018-04-19 21:01:43 --> Router Class Initialized
INFO - 2018-04-19 21:01:43 --> Output Class Initialized
INFO - 2018-04-19 21:01:43 --> Security Class Initialized
DEBUG - 2018-04-19 21:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 21:01:43 --> CSRF cookie sent
INFO - 2018-04-19 21:01:43 --> Input Class Initialized
INFO - 2018-04-19 21:01:43 --> Language Class Initialized
ERROR - 2018-04-19 21:01:43 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 21:01:45 --> Config Class Initialized
INFO - 2018-04-19 21:01:45 --> Hooks Class Initialized
DEBUG - 2018-04-19 21:01:45 --> UTF-8 Support Enabled
INFO - 2018-04-19 21:01:45 --> Utf8 Class Initialized
INFO - 2018-04-19 21:01:45 --> URI Class Initialized
INFO - 2018-04-19 21:01:45 --> Router Class Initialized
INFO - 2018-04-19 21:01:45 --> Output Class Initialized
INFO - 2018-04-19 21:01:45 --> Security Class Initialized
DEBUG - 2018-04-19 21:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 21:01:45 --> CSRF cookie sent
INFO - 2018-04-19 21:01:45 --> Input Class Initialized
INFO - 2018-04-19 21:01:45 --> Language Class Initialized
ERROR - 2018-04-19 21:01:45 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-19 21:01:45 --> Config Class Initialized
INFO - 2018-04-19 21:01:45 --> Hooks Class Initialized
DEBUG - 2018-04-19 21:01:45 --> UTF-8 Support Enabled
INFO - 2018-04-19 21:01:45 --> Utf8 Class Initialized
INFO - 2018-04-19 21:01:45 --> URI Class Initialized
INFO - 2018-04-19 21:01:45 --> Router Class Initialized
INFO - 2018-04-19 21:01:45 --> Output Class Initialized
INFO - 2018-04-19 21:01:45 --> Security Class Initialized
DEBUG - 2018-04-19 21:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 21:01:45 --> CSRF cookie sent
INFO - 2018-04-19 21:01:45 --> Input Class Initialized
INFO - 2018-04-19 21:01:45 --> Language Class Initialized
INFO - 2018-04-19 21:01:45 --> Loader Class Initialized
INFO - 2018-04-19 21:01:46 --> Helper loaded: url_helper
INFO - 2018-04-19 21:01:46 --> Helper loaded: form_helper
INFO - 2018-04-19 21:01:46 --> Helper loaded: language_helper
DEBUG - 2018-04-19 21:01:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 21:01:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 21:01:46 --> User Agent Class Initialized
INFO - 2018-04-19 21:01:46 --> Controller Class Initialized
INFO - 2018-04-19 21:01:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 21:01:46 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-19 21:01:46 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-19 21:01:46 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 21:01:46 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 21:01:46 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-19 21:01:46 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-19 21:01:46 --> Could not find the language line "req_email"
INFO - 2018-04-19 21:01:46 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-04-19 21:01:46 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 21:01:46 --> Final output sent to browser
DEBUG - 2018-04-19 21:01:46 --> Total execution time: 0.5910
INFO - 2018-04-19 21:01:46 --> Config Class Initialized
INFO - 2018-04-19 21:01:46 --> Hooks Class Initialized
DEBUG - 2018-04-19 21:01:46 --> UTF-8 Support Enabled
INFO - 2018-04-19 21:01:46 --> Utf8 Class Initialized
INFO - 2018-04-19 21:01:46 --> Config Class Initialized
INFO - 2018-04-19 21:01:46 --> Hooks Class Initialized
INFO - 2018-04-19 21:01:46 --> URI Class Initialized
DEBUG - 2018-04-19 21:01:46 --> UTF-8 Support Enabled
INFO - 2018-04-19 21:01:46 --> Router Class Initialized
INFO - 2018-04-19 21:01:46 --> Utf8 Class Initialized
INFO - 2018-04-19 21:01:46 --> Output Class Initialized
INFO - 2018-04-19 21:01:46 --> URI Class Initialized
INFO - 2018-04-19 21:01:46 --> Security Class Initialized
INFO - 2018-04-19 21:01:46 --> Router Class Initialized
DEBUG - 2018-04-19 21:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 21:01:46 --> Output Class Initialized
INFO - 2018-04-19 21:01:46 --> CSRF cookie sent
INFO - 2018-04-19 21:01:46 --> Security Class Initialized
INFO - 2018-04-19 21:01:46 --> Input Class Initialized
DEBUG - 2018-04-19 21:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 21:01:47 --> CSRF cookie sent
INFO - 2018-04-19 21:01:47 --> Language Class Initialized
INFO - 2018-04-19 21:01:47 --> Input Class Initialized
ERROR - 2018-04-19 21:01:47 --> 404 Page Not Found: Assets/images
INFO - 2018-04-19 21:01:47 --> Language Class Initialized
ERROR - 2018-04-19 21:01:47 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 21:01:48 --> Config Class Initialized
INFO - 2018-04-19 21:01:48 --> Hooks Class Initialized
DEBUG - 2018-04-19 21:01:48 --> UTF-8 Support Enabled
INFO - 2018-04-19 21:01:48 --> Utf8 Class Initialized
INFO - 2018-04-19 21:01:48 --> URI Class Initialized
INFO - 2018-04-19 21:01:48 --> Router Class Initialized
INFO - 2018-04-19 21:01:48 --> Output Class Initialized
INFO - 2018-04-19 21:01:48 --> Security Class Initialized
DEBUG - 2018-04-19 21:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 21:01:48 --> CSRF cookie sent
INFO - 2018-04-19 21:01:48 --> CSRF token verified
INFO - 2018-04-19 21:01:48 --> Input Class Initialized
INFO - 2018-04-19 21:01:48 --> Language Class Initialized
INFO - 2018-04-19 21:01:48 --> Loader Class Initialized
INFO - 2018-04-19 21:01:48 --> Helper loaded: url_helper
INFO - 2018-04-19 21:01:48 --> Helper loaded: form_helper
INFO - 2018-04-19 21:01:48 --> Helper loaded: language_helper
DEBUG - 2018-04-19 21:01:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 21:01:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 21:01:48 --> User Agent Class Initialized
INFO - 2018-04-19 21:01:48 --> Controller Class Initialized
INFO - 2018-04-19 21:01:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 21:01:48 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-19 21:01:48 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-19 21:01:48 --> Config Class Initialized
INFO - 2018-04-19 21:01:48 --> Hooks Class Initialized
DEBUG - 2018-04-19 21:01:48 --> UTF-8 Support Enabled
INFO - 2018-04-19 21:01:48 --> Utf8 Class Initialized
INFO - 2018-04-19 21:01:48 --> URI Class Initialized
INFO - 2018-04-19 21:01:48 --> Router Class Initialized
INFO - 2018-04-19 21:01:48 --> Output Class Initialized
INFO - 2018-04-19 21:01:48 --> Security Class Initialized
DEBUG - 2018-04-19 21:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 21:01:48 --> CSRF cookie sent
INFO - 2018-04-19 21:01:48 --> Input Class Initialized
INFO - 2018-04-19 21:01:48 --> Language Class Initialized
INFO - 2018-04-19 21:01:48 --> Loader Class Initialized
INFO - 2018-04-19 21:01:48 --> Helper loaded: url_helper
INFO - 2018-04-19 21:01:48 --> Helper loaded: form_helper
INFO - 2018-04-19 21:01:48 --> Helper loaded: language_helper
DEBUG - 2018-04-19 21:01:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 21:01:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 21:01:48 --> User Agent Class Initialized
INFO - 2018-04-19 21:01:49 --> Controller Class Initialized
INFO - 2018-04-19 21:01:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 21:01:49 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-19 21:01:49 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-19 21:01:49 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 21:01:49 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 21:01:49 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-19 21:01:49 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-19 21:01:49 --> File loaded: E:\www\yacopoo\application\views\shared/_soft_error.php
ERROR - 2018-04-19 21:01:49 --> Could not find the language line "req_email"
INFO - 2018-04-19 21:01:49 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-04-19 21:01:49 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 21:01:49 --> Final output sent to browser
DEBUG - 2018-04-19 21:01:49 --> Total execution time: 0.5209
INFO - 2018-04-19 21:01:49 --> Config Class Initialized
INFO - 2018-04-19 21:01:49 --> Config Class Initialized
INFO - 2018-04-19 21:01:49 --> Hooks Class Initialized
INFO - 2018-04-19 21:01:49 --> Hooks Class Initialized
DEBUG - 2018-04-19 21:01:49 --> UTF-8 Support Enabled
INFO - 2018-04-19 21:01:49 --> Utf8 Class Initialized
INFO - 2018-04-19 21:01:49 --> URI Class Initialized
DEBUG - 2018-04-19 21:01:49 --> UTF-8 Support Enabled
INFO - 2018-04-19 21:01:49 --> Utf8 Class Initialized
INFO - 2018-04-19 21:01:49 --> Router Class Initialized
INFO - 2018-04-19 21:01:49 --> URI Class Initialized
INFO - 2018-04-19 21:01:49 --> Output Class Initialized
INFO - 2018-04-19 21:01:49 --> Security Class Initialized
INFO - 2018-04-19 21:01:49 --> Router Class Initialized
DEBUG - 2018-04-19 21:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 21:01:49 --> Output Class Initialized
INFO - 2018-04-19 21:01:49 --> CSRF cookie sent
INFO - 2018-04-19 21:01:49 --> Security Class Initialized
INFO - 2018-04-19 21:01:49 --> Input Class Initialized
DEBUG - 2018-04-19 21:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 21:01:49 --> CSRF cookie sent
INFO - 2018-04-19 21:01:49 --> Input Class Initialized
INFO - 2018-04-19 21:01:49 --> Language Class Initialized
INFO - 2018-04-19 21:01:49 --> Language Class Initialized
ERROR - 2018-04-19 21:01:49 --> 404 Page Not Found: Assets/css
ERROR - 2018-04-19 21:01:49 --> 404 Page Not Found: Assets/images
INFO - 2018-04-19 21:01:54 --> Config Class Initialized
INFO - 2018-04-19 21:01:54 --> Hooks Class Initialized
DEBUG - 2018-04-19 21:01:54 --> UTF-8 Support Enabled
INFO - 2018-04-19 21:01:54 --> Utf8 Class Initialized
INFO - 2018-04-19 21:01:54 --> URI Class Initialized
INFO - 2018-04-19 21:01:54 --> Router Class Initialized
INFO - 2018-04-19 21:01:54 --> Output Class Initialized
INFO - 2018-04-19 21:01:54 --> Security Class Initialized
DEBUG - 2018-04-19 21:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 21:01:54 --> CSRF cookie sent
INFO - 2018-04-19 21:01:54 --> CSRF token verified
INFO - 2018-04-19 21:01:54 --> Input Class Initialized
INFO - 2018-04-19 21:01:54 --> Language Class Initialized
INFO - 2018-04-19 21:01:54 --> Loader Class Initialized
INFO - 2018-04-19 21:01:54 --> Helper loaded: url_helper
INFO - 2018-04-19 21:01:54 --> Helper loaded: form_helper
INFO - 2018-04-19 21:01:54 --> Helper loaded: language_helper
DEBUG - 2018-04-19 21:01:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 21:01:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 21:01:54 --> User Agent Class Initialized
INFO - 2018-04-19 21:01:54 --> Controller Class Initialized
INFO - 2018-04-19 21:01:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 21:01:54 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-19 21:01:54 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-19 21:01:55 --> Form Validation Class Initialized
INFO - 2018-04-19 21:01:55 --> Pixel_Model class loaded
INFO - 2018-04-19 21:01:55 --> Database Driver Class Initialized
INFO - 2018-04-19 21:01:55 --> Model "AuthenticationModel" initialized
INFO - 2018-04-19 21:01:55 --> Config Class Initialized
INFO - 2018-04-19 21:01:55 --> Hooks Class Initialized
DEBUG - 2018-04-19 21:01:55 --> UTF-8 Support Enabled
INFO - 2018-04-19 21:01:56 --> Utf8 Class Initialized
INFO - 2018-04-19 21:01:56 --> URI Class Initialized
DEBUG - 2018-04-19 21:01:56 --> No URI present. Default controller set.
INFO - 2018-04-19 21:01:56 --> Router Class Initialized
INFO - 2018-04-19 21:01:56 --> Output Class Initialized
INFO - 2018-04-19 21:01:56 --> Security Class Initialized
DEBUG - 2018-04-19 21:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 21:01:56 --> CSRF cookie sent
INFO - 2018-04-19 21:01:56 --> Input Class Initialized
INFO - 2018-04-19 21:01:56 --> Language Class Initialized
INFO - 2018-04-19 21:01:56 --> Loader Class Initialized
INFO - 2018-04-19 21:01:56 --> Helper loaded: url_helper
INFO - 2018-04-19 21:01:56 --> Helper loaded: form_helper
INFO - 2018-04-19 21:01:56 --> Helper loaded: language_helper
DEBUG - 2018-04-19 21:01:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 21:01:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 21:01:56 --> User Agent Class Initialized
INFO - 2018-04-19 21:01:56 --> Controller Class Initialized
INFO - 2018-04-19 21:01:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 21:01:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 21:01:56 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 21:01:56 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-19 21:01:56 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 21:01:56 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-19 21:01:56 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 21:01:56 --> Final output sent to browser
DEBUG - 2018-04-19 21:01:56 --> Total execution time: 0.4398
INFO - 2018-04-19 21:01:56 --> Config Class Initialized
INFO - 2018-04-19 21:01:56 --> Hooks Class Initialized
DEBUG - 2018-04-19 21:01:56 --> UTF-8 Support Enabled
INFO - 2018-04-19 21:01:56 --> Utf8 Class Initialized
INFO - 2018-04-19 21:01:56 --> URI Class Initialized
INFO - 2018-04-19 21:01:56 --> Router Class Initialized
INFO - 2018-04-19 21:01:56 --> Output Class Initialized
INFO - 2018-04-19 21:01:56 --> Security Class Initialized
DEBUG - 2018-04-19 21:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 21:01:57 --> CSRF cookie sent
INFO - 2018-04-19 21:01:57 --> Input Class Initialized
INFO - 2018-04-19 21:01:57 --> Language Class Initialized
ERROR - 2018-04-19 21:01:57 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 21:01:58 --> Config Class Initialized
INFO - 2018-04-19 21:01:58 --> Hooks Class Initialized
DEBUG - 2018-04-19 21:01:58 --> UTF-8 Support Enabled
INFO - 2018-04-19 21:01:58 --> Utf8 Class Initialized
INFO - 2018-04-19 21:01:58 --> URI Class Initialized
INFO - 2018-04-19 21:01:58 --> Router Class Initialized
INFO - 2018-04-19 21:01:58 --> Output Class Initialized
INFO - 2018-04-19 21:01:58 --> Security Class Initialized
DEBUG - 2018-04-19 21:01:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 21:01:58 --> CSRF cookie sent
INFO - 2018-04-19 21:01:58 --> Input Class Initialized
INFO - 2018-04-19 21:01:58 --> Language Class Initialized
ERROR - 2018-04-19 21:01:58 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-19 21:01:59 --> Config Class Initialized
INFO - 2018-04-19 21:01:59 --> Hooks Class Initialized
DEBUG - 2018-04-19 21:01:59 --> UTF-8 Support Enabled
INFO - 2018-04-19 21:01:59 --> Utf8 Class Initialized
INFO - 2018-04-19 21:01:59 --> URI Class Initialized
INFO - 2018-04-19 21:01:59 --> Router Class Initialized
INFO - 2018-04-19 21:01:59 --> Output Class Initialized
INFO - 2018-04-19 21:01:59 --> Security Class Initialized
DEBUG - 2018-04-19 21:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 21:01:59 --> CSRF cookie sent
INFO - 2018-04-19 21:01:59 --> Input Class Initialized
INFO - 2018-04-19 21:01:59 --> Language Class Initialized
INFO - 2018-04-19 21:01:59 --> Loader Class Initialized
INFO - 2018-04-19 21:01:59 --> Helper loaded: url_helper
INFO - 2018-04-19 21:01:59 --> Helper loaded: form_helper
INFO - 2018-04-19 21:01:59 --> Helper loaded: language_helper
DEBUG - 2018-04-19 21:01:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 21:01:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 21:01:59 --> User Agent Class Initialized
INFO - 2018-04-19 21:01:59 --> Controller Class Initialized
INFO - 2018-04-19 21:01:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 21:01:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 21:01:59 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 21:01:59 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-19 21:01:59 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 21:01:59 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-19 21:01:59 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-19 21:01:59 --> File loaded: E:\www\yacopoo\application\views\register/import_fa.php
INFO - 2018-04-19 21:01:59 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 21:01:59 --> Final output sent to browser
DEBUG - 2018-04-19 21:01:59 --> Total execution time: 0.6138
INFO - 2018-04-19 21:02:00 --> Config Class Initialized
INFO - 2018-04-19 21:02:00 --> Hooks Class Initialized
DEBUG - 2018-04-19 21:02:00 --> UTF-8 Support Enabled
INFO - 2018-04-19 21:02:00 --> Utf8 Class Initialized
INFO - 2018-04-19 21:02:00 --> URI Class Initialized
INFO - 2018-04-19 21:02:00 --> Router Class Initialized
INFO - 2018-04-19 21:02:00 --> Output Class Initialized
INFO - 2018-04-19 21:02:00 --> Security Class Initialized
DEBUG - 2018-04-19 21:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 21:02:00 --> CSRF cookie sent
INFO - 2018-04-19 21:02:00 --> Input Class Initialized
INFO - 2018-04-19 21:02:00 --> Language Class Initialized
ERROR - 2018-04-19 21:02:00 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 21:02:02 --> Config Class Initialized
INFO - 2018-04-19 21:02:02 --> Hooks Class Initialized
DEBUG - 2018-04-19 21:02:02 --> UTF-8 Support Enabled
INFO - 2018-04-19 21:02:02 --> Utf8 Class Initialized
INFO - 2018-04-19 21:02:02 --> URI Class Initialized
INFO - 2018-04-19 21:02:02 --> Router Class Initialized
INFO - 2018-04-19 21:02:02 --> Output Class Initialized
INFO - 2018-04-19 21:02:02 --> Security Class Initialized
DEBUG - 2018-04-19 21:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 21:02:02 --> CSRF cookie sent
INFO - 2018-04-19 21:02:02 --> Input Class Initialized
INFO - 2018-04-19 21:02:02 --> Language Class Initialized
INFO - 2018-04-19 21:02:02 --> Loader Class Initialized
INFO - 2018-04-19 21:02:02 --> Helper loaded: url_helper
INFO - 2018-04-19 21:02:02 --> Helper loaded: form_helper
INFO - 2018-04-19 21:02:02 --> Helper loaded: language_helper
DEBUG - 2018-04-19 21:02:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 21:02:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 21:02:02 --> User Agent Class Initialized
INFO - 2018-04-19 21:02:02 --> Controller Class Initialized
INFO - 2018-04-19 21:02:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 21:02:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 21:02:02 --> Pixel_Model class loaded
INFO - 2018-04-19 21:02:02 --> Database Driver Class Initialized
INFO - 2018-04-19 21:02:02 --> Model "MyAccountModel" initialized
INFO - 2018-04-19 21:02:02 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 21:02:02 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-19 21:02:02 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 21:02:02 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-19 21:02:02 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-19 21:02:02 --> Could not find the language line "req_email"
INFO - 2018-04-19 21:02:02 --> File loaded: E:\www\yacopoo\application\views\register/add_advisor.php
INFO - 2018-04-19 21:02:02 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 21:02:02 --> Final output sent to browser
DEBUG - 2018-04-19 21:02:02 --> Total execution time: 0.5781
INFO - 2018-04-19 21:02:03 --> Config Class Initialized
INFO - 2018-04-19 21:02:03 --> Hooks Class Initialized
DEBUG - 2018-04-19 21:02:03 --> UTF-8 Support Enabled
INFO - 2018-04-19 21:02:03 --> Utf8 Class Initialized
INFO - 2018-04-19 21:02:03 --> URI Class Initialized
INFO - 2018-04-19 21:02:03 --> Router Class Initialized
INFO - 2018-04-19 21:02:03 --> Output Class Initialized
INFO - 2018-04-19 21:02:03 --> Security Class Initialized
DEBUG - 2018-04-19 21:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 21:02:03 --> CSRF cookie sent
INFO - 2018-04-19 21:02:03 --> Input Class Initialized
INFO - 2018-04-19 21:02:03 --> Language Class Initialized
ERROR - 2018-04-19 21:02:03 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 21:03:12 --> Config Class Initialized
INFO - 2018-04-19 21:03:12 --> Hooks Class Initialized
DEBUG - 2018-04-19 21:03:12 --> UTF-8 Support Enabled
INFO - 2018-04-19 21:03:12 --> Utf8 Class Initialized
INFO - 2018-04-19 21:03:12 --> URI Class Initialized
INFO - 2018-04-19 21:03:12 --> Router Class Initialized
INFO - 2018-04-19 21:03:12 --> Output Class Initialized
INFO - 2018-04-19 21:03:12 --> Security Class Initialized
DEBUG - 2018-04-19 21:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 21:03:12 --> CSRF cookie sent
INFO - 2018-04-19 21:03:12 --> Input Class Initialized
INFO - 2018-04-19 21:03:12 --> Language Class Initialized
INFO - 2018-04-19 21:03:12 --> Loader Class Initialized
INFO - 2018-04-19 21:03:12 --> Helper loaded: url_helper
INFO - 2018-04-19 21:03:12 --> Helper loaded: form_helper
INFO - 2018-04-19 21:03:12 --> Helper loaded: language_helper
DEBUG - 2018-04-19 21:03:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 21:03:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 21:03:12 --> User Agent Class Initialized
INFO - 2018-04-19 21:03:12 --> Controller Class Initialized
INFO - 2018-04-19 21:03:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 21:03:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 21:03:12 --> Pixel_Model class loaded
INFO - 2018-04-19 21:03:12 --> Database Driver Class Initialized
INFO - 2018-04-19 21:03:12 --> Model "MyAccountModel" initialized
INFO - 2018-04-19 21:03:12 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 21:03:12 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-19 21:03:12 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 21:03:12 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-19 21:03:12 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-19 21:03:12 --> Could not find the language line "req_email"
INFO - 2018-04-19 21:03:12 --> File loaded: E:\www\yacopoo\application\views\register/add_advisor.php
INFO - 2018-04-19 21:03:12 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 21:03:12 --> Final output sent to browser
DEBUG - 2018-04-19 21:03:12 --> Total execution time: 0.5546
INFO - 2018-04-19 21:03:13 --> Config Class Initialized
INFO - 2018-04-19 21:03:13 --> Hooks Class Initialized
DEBUG - 2018-04-19 21:03:13 --> UTF-8 Support Enabled
INFO - 2018-04-19 21:03:13 --> Utf8 Class Initialized
INFO - 2018-04-19 21:03:13 --> URI Class Initialized
INFO - 2018-04-19 21:03:13 --> Router Class Initialized
INFO - 2018-04-19 21:03:13 --> Output Class Initialized
INFO - 2018-04-19 21:03:13 --> Security Class Initialized
DEBUG - 2018-04-19 21:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 21:03:13 --> CSRF cookie sent
INFO - 2018-04-19 21:03:13 --> Input Class Initialized
INFO - 2018-04-19 21:03:13 --> Language Class Initialized
ERROR - 2018-04-19 21:03:13 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 21:04:17 --> Config Class Initialized
INFO - 2018-04-19 21:04:18 --> Hooks Class Initialized
DEBUG - 2018-04-19 21:04:18 --> UTF-8 Support Enabled
INFO - 2018-04-19 21:04:18 --> Utf8 Class Initialized
INFO - 2018-04-19 21:04:18 --> URI Class Initialized
INFO - 2018-04-19 21:04:18 --> Router Class Initialized
INFO - 2018-04-19 21:04:18 --> Output Class Initialized
INFO - 2018-04-19 21:04:18 --> Security Class Initialized
DEBUG - 2018-04-19 21:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 21:04:18 --> CSRF cookie sent
INFO - 2018-04-19 21:04:18 --> Input Class Initialized
INFO - 2018-04-19 21:04:18 --> Language Class Initialized
INFO - 2018-04-19 21:04:18 --> Loader Class Initialized
INFO - 2018-04-19 21:04:18 --> Helper loaded: url_helper
INFO - 2018-04-19 21:04:18 --> Helper loaded: form_helper
INFO - 2018-04-19 21:04:18 --> Helper loaded: language_helper
DEBUG - 2018-04-19 21:04:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 21:04:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 21:04:18 --> User Agent Class Initialized
INFO - 2018-04-19 21:04:18 --> Controller Class Initialized
INFO - 2018-04-19 21:04:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 21:04:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 21:04:18 --> Pixel_Model class loaded
INFO - 2018-04-19 21:04:18 --> Database Driver Class Initialized
INFO - 2018-04-19 21:04:18 --> Model "MyAccountModel" initialized
INFO - 2018-04-19 21:04:18 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 21:04:18 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-19 21:04:18 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 21:04:18 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-19 21:04:18 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-19 21:04:18 --> Could not find the language line "req_email"
INFO - 2018-04-19 21:04:18 --> File loaded: E:\www\yacopoo\application\views\register/add_advisor.php
INFO - 2018-04-19 21:04:18 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 21:04:18 --> Final output sent to browser
DEBUG - 2018-04-19 21:04:18 --> Total execution time: 0.5611
INFO - 2018-04-19 21:04:18 --> Config Class Initialized
INFO - 2018-04-19 21:04:18 --> Hooks Class Initialized
DEBUG - 2018-04-19 21:04:18 --> UTF-8 Support Enabled
INFO - 2018-04-19 21:04:18 --> Utf8 Class Initialized
INFO - 2018-04-19 21:04:19 --> URI Class Initialized
INFO - 2018-04-19 21:04:19 --> Router Class Initialized
INFO - 2018-04-19 21:04:19 --> Output Class Initialized
INFO - 2018-04-19 21:04:19 --> Security Class Initialized
DEBUG - 2018-04-19 21:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 21:04:19 --> CSRF cookie sent
INFO - 2018-04-19 21:04:19 --> Input Class Initialized
INFO - 2018-04-19 21:04:19 --> Language Class Initialized
ERROR - 2018-04-19 21:04:19 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 21:05:26 --> Config Class Initialized
INFO - 2018-04-19 21:05:26 --> Hooks Class Initialized
DEBUG - 2018-04-19 21:05:26 --> UTF-8 Support Enabled
INFO - 2018-04-19 21:05:26 --> Utf8 Class Initialized
INFO - 2018-04-19 21:05:26 --> URI Class Initialized
INFO - 2018-04-19 21:05:26 --> Router Class Initialized
INFO - 2018-04-19 21:05:26 --> Output Class Initialized
INFO - 2018-04-19 21:05:26 --> Security Class Initialized
DEBUG - 2018-04-19 21:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 21:05:26 --> CSRF cookie sent
INFO - 2018-04-19 21:05:26 --> CSRF token verified
INFO - 2018-04-19 21:05:26 --> Input Class Initialized
INFO - 2018-04-19 21:05:26 --> Language Class Initialized
INFO - 2018-04-19 21:05:26 --> Loader Class Initialized
INFO - 2018-04-19 21:05:26 --> Helper loaded: url_helper
INFO - 2018-04-19 21:05:26 --> Helper loaded: form_helper
INFO - 2018-04-19 21:05:26 --> Helper loaded: language_helper
DEBUG - 2018-04-19 21:05:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 21:05:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 21:05:26 --> User Agent Class Initialized
INFO - 2018-04-19 21:05:26 --> Controller Class Initialized
INFO - 2018-04-19 21:05:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 21:05:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 21:05:26 --> Form Validation Class Initialized
INFO - 2018-04-19 21:05:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-19 21:05:26 --> Pixel_Model class loaded
INFO - 2018-04-19 21:05:26 --> Database Driver Class Initialized
INFO - 2018-04-19 21:05:26 --> Model "RegistrationModel" initialized
INFO - 2018-04-19 21:05:26 --> Helper loaded: string_helper
INFO - 2018-04-19 21:05:26 --> Language file loaded: language/en/notifications_lang.php
INFO - 2018-04-19 21:05:27 --> File loaded: E:\www\yacopoo\application\views\emails/_buttons.php
INFO - 2018-04-19 21:05:27 --> File loaded: E:\www\yacopoo\application\views\emails/header.php
INFO - 2018-04-19 21:05:27 --> File loaded: E:\www\yacopoo\application\views\emails/footer.php
INFO - 2018-04-19 21:05:27 --> File loaded: E:\www\yacopoo\application\views\emails/generic.php
INFO - 2018-04-19 21:05:27 --> Email Class Initialized
INFO - 2018-04-19 21:05:27 --> Final output sent to browser
DEBUG - 2018-04-19 21:05:27 --> Total execution time: 0.8879
INFO - 2018-04-19 21:05:27 --> Config Class Initialized
INFO - 2018-04-19 21:05:27 --> Hooks Class Initialized
DEBUG - 2018-04-19 21:05:27 --> UTF-8 Support Enabled
INFO - 2018-04-19 21:05:27 --> Utf8 Class Initialized
INFO - 2018-04-19 21:05:27 --> URI Class Initialized
INFO - 2018-04-19 21:05:27 --> Router Class Initialized
INFO - 2018-04-19 21:05:27 --> Output Class Initialized
INFO - 2018-04-19 21:05:27 --> Security Class Initialized
DEBUG - 2018-04-19 21:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 21:05:27 --> CSRF cookie sent
INFO - 2018-04-19 21:05:27 --> Input Class Initialized
INFO - 2018-04-19 21:05:27 --> Language Class Initialized
ERROR - 2018-04-19 21:05:27 --> 404 Page Not Found: Assets/images
INFO - 2018-04-19 21:05:35 --> Config Class Initialized
INFO - 2018-04-19 21:05:35 --> Hooks Class Initialized
DEBUG - 2018-04-19 21:05:35 --> UTF-8 Support Enabled
INFO - 2018-04-19 21:05:35 --> Utf8 Class Initialized
INFO - 2018-04-19 21:05:35 --> URI Class Initialized
DEBUG - 2018-04-19 21:05:35 --> No URI present. Default controller set.
INFO - 2018-04-19 21:05:35 --> Router Class Initialized
INFO - 2018-04-19 21:05:35 --> Output Class Initialized
INFO - 2018-04-19 21:05:35 --> Security Class Initialized
DEBUG - 2018-04-19 21:05:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 21:05:35 --> CSRF cookie sent
INFO - 2018-04-19 21:05:35 --> Input Class Initialized
INFO - 2018-04-19 21:05:35 --> Language Class Initialized
INFO - 2018-04-19 21:05:35 --> Loader Class Initialized
INFO - 2018-04-19 21:05:35 --> Helper loaded: url_helper
INFO - 2018-04-19 21:05:35 --> Helper loaded: form_helper
INFO - 2018-04-19 21:05:35 --> Helper loaded: language_helper
DEBUG - 2018-04-19 21:05:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 21:05:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 21:05:35 --> User Agent Class Initialized
INFO - 2018-04-19 21:05:35 --> Controller Class Initialized
INFO - 2018-04-19 21:05:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 21:05:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 21:05:35 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 21:05:35 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-19 21:05:35 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 21:05:35 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-19 21:05:35 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 21:05:35 --> Final output sent to browser
DEBUG - 2018-04-19 21:05:35 --> Total execution time: 0.4604
INFO - 2018-04-19 21:05:36 --> Config Class Initialized
INFO - 2018-04-19 21:05:36 --> Hooks Class Initialized
DEBUG - 2018-04-19 21:05:36 --> UTF-8 Support Enabled
INFO - 2018-04-19 21:05:36 --> Utf8 Class Initialized
INFO - 2018-04-19 21:05:36 --> URI Class Initialized
INFO - 2018-04-19 21:05:36 --> Router Class Initialized
INFO - 2018-04-19 21:05:36 --> Output Class Initialized
INFO - 2018-04-19 21:05:36 --> Security Class Initialized
DEBUG - 2018-04-19 21:05:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 21:05:36 --> CSRF cookie sent
INFO - 2018-04-19 21:05:36 --> Input Class Initialized
INFO - 2018-04-19 21:05:36 --> Language Class Initialized
ERROR - 2018-04-19 21:05:36 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 21:05:37 --> Config Class Initialized
INFO - 2018-04-19 21:05:37 --> Hooks Class Initialized
DEBUG - 2018-04-19 21:05:38 --> UTF-8 Support Enabled
INFO - 2018-04-19 21:05:38 --> Utf8 Class Initialized
INFO - 2018-04-19 21:05:38 --> URI Class Initialized
INFO - 2018-04-19 21:05:38 --> Router Class Initialized
INFO - 2018-04-19 21:05:38 --> Output Class Initialized
INFO - 2018-04-19 21:05:38 --> Security Class Initialized
DEBUG - 2018-04-19 21:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 21:05:38 --> CSRF cookie sent
INFO - 2018-04-19 21:05:38 --> Input Class Initialized
INFO - 2018-04-19 21:05:38 --> Language Class Initialized
ERROR - 2018-04-19 21:05:38 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-19 21:05:38 --> Config Class Initialized
INFO - 2018-04-19 21:05:38 --> Hooks Class Initialized
DEBUG - 2018-04-19 21:05:38 --> UTF-8 Support Enabled
INFO - 2018-04-19 21:05:38 --> Utf8 Class Initialized
INFO - 2018-04-19 21:05:38 --> URI Class Initialized
INFO - 2018-04-19 21:05:38 --> Router Class Initialized
INFO - 2018-04-19 21:05:38 --> Output Class Initialized
INFO - 2018-04-19 21:05:38 --> Security Class Initialized
DEBUG - 2018-04-19 21:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 21:05:38 --> CSRF cookie sent
INFO - 2018-04-19 21:05:38 --> Input Class Initialized
INFO - 2018-04-19 21:05:38 --> Language Class Initialized
INFO - 2018-04-19 21:05:38 --> Loader Class Initialized
INFO - 2018-04-19 21:05:38 --> Helper loaded: url_helper
INFO - 2018-04-19 21:05:38 --> Helper loaded: form_helper
INFO - 2018-04-19 21:05:38 --> Helper loaded: language_helper
DEBUG - 2018-04-19 21:05:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 21:05:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 21:05:39 --> User Agent Class Initialized
INFO - 2018-04-19 21:05:39 --> Controller Class Initialized
INFO - 2018-04-19 21:05:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 21:05:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 21:05:39 --> CSRF cookie sent
INFO - 2018-04-19 21:05:39 --> Config Class Initialized
INFO - 2018-04-19 21:05:39 --> Hooks Class Initialized
DEBUG - 2018-04-19 21:05:39 --> UTF-8 Support Enabled
INFO - 2018-04-19 21:05:39 --> Utf8 Class Initialized
INFO - 2018-04-19 21:05:39 --> URI Class Initialized
DEBUG - 2018-04-19 21:05:39 --> No URI present. Default controller set.
INFO - 2018-04-19 21:05:39 --> Router Class Initialized
INFO - 2018-04-19 21:05:39 --> Output Class Initialized
INFO - 2018-04-19 21:05:39 --> Security Class Initialized
DEBUG - 2018-04-19 21:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 21:05:39 --> CSRF cookie sent
INFO - 2018-04-19 21:05:39 --> Input Class Initialized
INFO - 2018-04-19 21:05:39 --> Language Class Initialized
INFO - 2018-04-19 21:05:39 --> Loader Class Initialized
INFO - 2018-04-19 21:05:39 --> Helper loaded: url_helper
INFO - 2018-04-19 21:05:39 --> Helper loaded: form_helper
INFO - 2018-04-19 21:05:39 --> Helper loaded: language_helper
DEBUG - 2018-04-19 21:05:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 21:05:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 21:05:39 --> User Agent Class Initialized
INFO - 2018-04-19 21:05:39 --> Controller Class Initialized
INFO - 2018-04-19 21:05:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 21:05:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 21:05:39 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 21:05:39 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 21:05:39 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-19 21:05:39 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 21:05:39 --> Final output sent to browser
DEBUG - 2018-04-19 21:05:39 --> Total execution time: 0.5004
INFO - 2018-04-19 21:05:40 --> Config Class Initialized
INFO - 2018-04-19 21:05:40 --> Hooks Class Initialized
DEBUG - 2018-04-19 21:05:40 --> UTF-8 Support Enabled
INFO - 2018-04-19 21:05:40 --> Utf8 Class Initialized
INFO - 2018-04-19 21:05:40 --> URI Class Initialized
INFO - 2018-04-19 21:05:40 --> Router Class Initialized
INFO - 2018-04-19 21:05:40 --> Output Class Initialized
INFO - 2018-04-19 21:05:40 --> Security Class Initialized
DEBUG - 2018-04-19 21:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 21:05:40 --> CSRF cookie sent
INFO - 2018-04-19 21:05:40 --> Input Class Initialized
INFO - 2018-04-19 21:05:40 --> Language Class Initialized
ERROR - 2018-04-19 21:05:40 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 21:05:42 --> Config Class Initialized
INFO - 2018-04-19 21:05:42 --> Hooks Class Initialized
DEBUG - 2018-04-19 21:05:42 --> UTF-8 Support Enabled
INFO - 2018-04-19 21:05:42 --> Utf8 Class Initialized
INFO - 2018-04-19 21:05:42 --> URI Class Initialized
INFO - 2018-04-19 21:05:42 --> Router Class Initialized
INFO - 2018-04-19 21:05:42 --> Output Class Initialized
INFO - 2018-04-19 21:05:42 --> Security Class Initialized
DEBUG - 2018-04-19 21:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 21:05:42 --> CSRF cookie sent
INFO - 2018-04-19 21:05:42 --> Input Class Initialized
INFO - 2018-04-19 21:05:42 --> Language Class Initialized
INFO - 2018-04-19 21:05:42 --> Loader Class Initialized
INFO - 2018-04-19 21:05:42 --> Helper loaded: url_helper
INFO - 2018-04-19 21:05:42 --> Helper loaded: form_helper
INFO - 2018-04-19 21:05:42 --> Helper loaded: language_helper
DEBUG - 2018-04-19 21:05:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 21:05:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 21:05:42 --> User Agent Class Initialized
INFO - 2018-04-19 21:05:42 --> Controller Class Initialized
INFO - 2018-04-19 21:05:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 21:05:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 21:05:42 --> Pixel_Model class loaded
INFO - 2018-04-19 21:05:42 --> Database Driver Class Initialized
INFO - 2018-04-19 21:05:42 --> Model "RegistrationModel" initialized
INFO - 2018-04-19 21:05:42 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 21:05:42 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 21:05:42 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-19 21:05:42 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-19 21:05:42 --> File loaded: E:\www\yacopoo\application\views\register/complete_registration.php
INFO - 2018-04-19 21:05:43 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 21:05:43 --> Final output sent to browser
DEBUG - 2018-04-19 21:05:43 --> Total execution time: 0.5706
INFO - 2018-04-19 21:05:43 --> Config Class Initialized
INFO - 2018-04-19 21:05:43 --> Hooks Class Initialized
DEBUG - 2018-04-19 21:05:43 --> UTF-8 Support Enabled
INFO - 2018-04-19 21:05:43 --> Utf8 Class Initialized
INFO - 2018-04-19 21:05:43 --> URI Class Initialized
INFO - 2018-04-19 21:05:43 --> Router Class Initialized
INFO - 2018-04-19 21:05:43 --> Output Class Initialized
INFO - 2018-04-19 21:05:43 --> Security Class Initialized
DEBUG - 2018-04-19 21:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 21:05:43 --> CSRF cookie sent
INFO - 2018-04-19 21:05:43 --> Input Class Initialized
INFO - 2018-04-19 21:05:43 --> Language Class Initialized
ERROR - 2018-04-19 21:05:43 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 21:05:55 --> Config Class Initialized
INFO - 2018-04-19 21:05:55 --> Hooks Class Initialized
DEBUG - 2018-04-19 21:05:55 --> UTF-8 Support Enabled
INFO - 2018-04-19 21:05:55 --> Utf8 Class Initialized
INFO - 2018-04-19 21:05:55 --> URI Class Initialized
INFO - 2018-04-19 21:05:55 --> Router Class Initialized
INFO - 2018-04-19 21:05:55 --> Output Class Initialized
INFO - 2018-04-19 21:05:55 --> Security Class Initialized
DEBUG - 2018-04-19 21:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 21:05:55 --> CSRF cookie sent
INFO - 2018-04-19 21:05:55 --> CSRF token verified
INFO - 2018-04-19 21:05:55 --> Input Class Initialized
INFO - 2018-04-19 21:05:55 --> Language Class Initialized
INFO - 2018-04-19 21:05:56 --> Loader Class Initialized
INFO - 2018-04-19 21:05:56 --> Helper loaded: url_helper
INFO - 2018-04-19 21:05:56 --> Helper loaded: form_helper
INFO - 2018-04-19 21:05:56 --> Helper loaded: language_helper
DEBUG - 2018-04-19 21:05:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 21:05:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 21:05:56 --> User Agent Class Initialized
INFO - 2018-04-19 21:05:56 --> Controller Class Initialized
INFO - 2018-04-19 21:05:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 21:05:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 21:05:56 --> Pixel_Model class loaded
INFO - 2018-04-19 21:05:56 --> Database Driver Class Initialized
INFO - 2018-04-19 21:05:56 --> Model "RegistrationModel" initialized
INFO - 2018-04-19 21:05:56 --> Form Validation Class Initialized
INFO - 2018-04-19 21:05:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-19 21:05:56 --> Config Class Initialized
INFO - 2018-04-19 21:05:56 --> Hooks Class Initialized
DEBUG - 2018-04-19 21:05:56 --> UTF-8 Support Enabled
INFO - 2018-04-19 21:05:56 --> Utf8 Class Initialized
INFO - 2018-04-19 21:05:56 --> URI Class Initialized
DEBUG - 2018-04-19 21:05:56 --> No URI present. Default controller set.
INFO - 2018-04-19 21:05:56 --> Router Class Initialized
INFO - 2018-04-19 21:05:56 --> Output Class Initialized
INFO - 2018-04-19 21:05:56 --> Security Class Initialized
DEBUG - 2018-04-19 21:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 21:05:56 --> CSRF cookie sent
INFO - 2018-04-19 21:05:56 --> Input Class Initialized
INFO - 2018-04-19 21:05:56 --> Language Class Initialized
INFO - 2018-04-19 21:05:56 --> Loader Class Initialized
INFO - 2018-04-19 21:05:56 --> Helper loaded: url_helper
INFO - 2018-04-19 21:05:56 --> Helper loaded: form_helper
INFO - 2018-04-19 21:05:56 --> Helper loaded: language_helper
DEBUG - 2018-04-19 21:05:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 21:05:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 21:05:56 --> User Agent Class Initialized
INFO - 2018-04-19 21:05:56 --> Controller Class Initialized
INFO - 2018-04-19 21:05:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 21:05:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 21:05:56 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 21:05:56 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-19 21:05:56 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 21:05:56 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-19 21:05:56 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 21:05:56 --> Final output sent to browser
DEBUG - 2018-04-19 21:05:57 --> Total execution time: 0.4547
INFO - 2018-04-19 21:05:57 --> Config Class Initialized
INFO - 2018-04-19 21:05:57 --> Hooks Class Initialized
DEBUG - 2018-04-19 21:05:57 --> UTF-8 Support Enabled
INFO - 2018-04-19 21:05:57 --> Utf8 Class Initialized
INFO - 2018-04-19 21:05:57 --> URI Class Initialized
INFO - 2018-04-19 21:05:57 --> Router Class Initialized
INFO - 2018-04-19 21:05:57 --> Output Class Initialized
INFO - 2018-04-19 21:05:57 --> Security Class Initialized
DEBUG - 2018-04-19 21:05:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 21:05:57 --> CSRF cookie sent
INFO - 2018-04-19 21:05:57 --> Input Class Initialized
INFO - 2018-04-19 21:05:57 --> Language Class Initialized
ERROR - 2018-04-19 21:05:57 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 21:05:59 --> Config Class Initialized
INFO - 2018-04-19 21:05:59 --> Hooks Class Initialized
DEBUG - 2018-04-19 21:05:59 --> UTF-8 Support Enabled
INFO - 2018-04-19 21:05:59 --> Utf8 Class Initialized
INFO - 2018-04-19 21:05:59 --> URI Class Initialized
INFO - 2018-04-19 21:05:59 --> Router Class Initialized
INFO - 2018-04-19 21:05:59 --> Output Class Initialized
INFO - 2018-04-19 21:05:59 --> Security Class Initialized
DEBUG - 2018-04-19 21:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 21:05:59 --> CSRF cookie sent
INFO - 2018-04-19 21:05:59 --> Input Class Initialized
INFO - 2018-04-19 21:05:59 --> Language Class Initialized
ERROR - 2018-04-19 21:05:59 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-19 21:06:03 --> Config Class Initialized
INFO - 2018-04-19 21:06:03 --> Hooks Class Initialized
DEBUG - 2018-04-19 21:06:03 --> UTF-8 Support Enabled
INFO - 2018-04-19 21:06:03 --> Utf8 Class Initialized
INFO - 2018-04-19 21:06:03 --> URI Class Initialized
INFO - 2018-04-19 21:06:03 --> Router Class Initialized
INFO - 2018-04-19 21:06:03 --> Output Class Initialized
INFO - 2018-04-19 21:06:03 --> Security Class Initialized
DEBUG - 2018-04-19 21:06:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 21:06:03 --> CSRF cookie sent
INFO - 2018-04-19 21:06:03 --> Input Class Initialized
INFO - 2018-04-19 21:06:03 --> Language Class Initialized
INFO - 2018-04-19 21:06:03 --> Loader Class Initialized
INFO - 2018-04-19 21:06:03 --> Helper loaded: url_helper
INFO - 2018-04-19 21:06:03 --> Helper loaded: form_helper
INFO - 2018-04-19 21:06:03 --> Helper loaded: language_helper
DEBUG - 2018-04-19 21:06:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 21:06:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 21:06:03 --> User Agent Class Initialized
INFO - 2018-04-19 21:06:03 --> Controller Class Initialized
INFO - 2018-04-19 21:06:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 21:06:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 21:06:03 --> CSRF cookie sent
INFO - 2018-04-19 21:06:03 --> Config Class Initialized
INFO - 2018-04-19 21:06:03 --> Hooks Class Initialized
DEBUG - 2018-04-19 21:06:03 --> UTF-8 Support Enabled
INFO - 2018-04-19 21:06:03 --> Utf8 Class Initialized
INFO - 2018-04-19 21:06:03 --> URI Class Initialized
DEBUG - 2018-04-19 21:06:03 --> No URI present. Default controller set.
INFO - 2018-04-19 21:06:03 --> Router Class Initialized
INFO - 2018-04-19 21:06:04 --> Output Class Initialized
INFO - 2018-04-19 21:06:04 --> Security Class Initialized
DEBUG - 2018-04-19 21:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 21:06:04 --> CSRF cookie sent
INFO - 2018-04-19 21:06:04 --> Input Class Initialized
INFO - 2018-04-19 21:06:04 --> Language Class Initialized
INFO - 2018-04-19 21:06:04 --> Loader Class Initialized
INFO - 2018-04-19 21:06:04 --> Helper loaded: url_helper
INFO - 2018-04-19 21:06:04 --> Helper loaded: form_helper
INFO - 2018-04-19 21:06:04 --> Helper loaded: language_helper
DEBUG - 2018-04-19 21:06:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 21:06:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 21:06:04 --> User Agent Class Initialized
INFO - 2018-04-19 21:06:04 --> Controller Class Initialized
INFO - 2018-04-19 21:06:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 21:06:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 21:06:04 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 21:06:04 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 21:06:04 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-19 21:06:04 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 21:06:04 --> Final output sent to browser
DEBUG - 2018-04-19 21:06:04 --> Total execution time: 0.5013
INFO - 2018-04-19 21:06:04 --> Config Class Initialized
INFO - 2018-04-19 21:06:04 --> Hooks Class Initialized
DEBUG - 2018-04-19 21:06:04 --> UTF-8 Support Enabled
INFO - 2018-04-19 21:06:04 --> Utf8 Class Initialized
INFO - 2018-04-19 21:06:04 --> URI Class Initialized
INFO - 2018-04-19 21:06:04 --> Router Class Initialized
INFO - 2018-04-19 21:06:04 --> Output Class Initialized
INFO - 2018-04-19 21:06:04 --> Security Class Initialized
DEBUG - 2018-04-19 21:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 21:06:04 --> CSRF cookie sent
INFO - 2018-04-19 21:06:04 --> Input Class Initialized
INFO - 2018-04-19 21:06:04 --> Language Class Initialized
ERROR - 2018-04-19 21:06:04 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 21:06:07 --> Config Class Initialized
INFO - 2018-04-19 21:06:07 --> Hooks Class Initialized
DEBUG - 2018-04-19 21:06:07 --> UTF-8 Support Enabled
INFO - 2018-04-19 21:06:07 --> Utf8 Class Initialized
INFO - 2018-04-19 21:06:07 --> URI Class Initialized
INFO - 2018-04-19 21:06:07 --> Router Class Initialized
INFO - 2018-04-19 21:06:07 --> Output Class Initialized
INFO - 2018-04-19 21:06:07 --> Security Class Initialized
DEBUG - 2018-04-19 21:06:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 21:06:07 --> CSRF cookie sent
INFO - 2018-04-19 21:06:07 --> Input Class Initialized
INFO - 2018-04-19 21:06:07 --> Language Class Initialized
ERROR - 2018-04-19 21:06:07 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-19 21:06:07 --> Config Class Initialized
INFO - 2018-04-19 21:06:07 --> Hooks Class Initialized
DEBUG - 2018-04-19 21:06:07 --> UTF-8 Support Enabled
INFO - 2018-04-19 21:06:07 --> Utf8 Class Initialized
INFO - 2018-04-19 21:06:07 --> URI Class Initialized
INFO - 2018-04-19 21:06:08 --> Router Class Initialized
INFO - 2018-04-19 21:06:08 --> Output Class Initialized
INFO - 2018-04-19 21:06:08 --> Security Class Initialized
DEBUG - 2018-04-19 21:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 21:06:08 --> CSRF cookie sent
INFO - 2018-04-19 21:06:08 --> Input Class Initialized
INFO - 2018-04-19 21:06:08 --> Language Class Initialized
INFO - 2018-04-19 21:06:08 --> Loader Class Initialized
INFO - 2018-04-19 21:06:08 --> Helper loaded: url_helper
INFO - 2018-04-19 21:06:08 --> Helper loaded: form_helper
INFO - 2018-04-19 21:06:08 --> Helper loaded: language_helper
DEBUG - 2018-04-19 21:06:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 21:06:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 21:06:08 --> User Agent Class Initialized
INFO - 2018-04-19 21:06:08 --> Controller Class Initialized
INFO - 2018-04-19 21:06:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 21:06:08 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-19 21:06:08 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-19 21:06:08 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 21:06:08 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 21:06:08 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-19 21:06:08 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-19 21:06:08 --> Could not find the language line "req_email"
INFO - 2018-04-19 21:06:08 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-04-19 21:06:08 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 21:06:08 --> Final output sent to browser
DEBUG - 2018-04-19 21:06:08 --> Total execution time: 0.6904
INFO - 2018-04-19 21:06:08 --> Config Class Initialized
INFO - 2018-04-19 21:06:08 --> Config Class Initialized
INFO - 2018-04-19 21:06:09 --> Hooks Class Initialized
INFO - 2018-04-19 21:06:09 --> Hooks Class Initialized
DEBUG - 2018-04-19 21:06:09 --> UTF-8 Support Enabled
DEBUG - 2018-04-19 21:06:09 --> UTF-8 Support Enabled
INFO - 2018-04-19 21:06:09 --> Utf8 Class Initialized
INFO - 2018-04-19 21:06:09 --> Utf8 Class Initialized
INFO - 2018-04-19 21:06:09 --> URI Class Initialized
INFO - 2018-04-19 21:06:09 --> URI Class Initialized
INFO - 2018-04-19 21:06:09 --> Router Class Initialized
INFO - 2018-04-19 21:06:09 --> Router Class Initialized
INFO - 2018-04-19 21:06:09 --> Output Class Initialized
INFO - 2018-04-19 21:06:09 --> Output Class Initialized
INFO - 2018-04-19 21:06:09 --> Security Class Initialized
INFO - 2018-04-19 21:06:09 --> Security Class Initialized
DEBUG - 2018-04-19 21:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-19 21:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 21:06:09 --> CSRF cookie sent
INFO - 2018-04-19 21:06:09 --> CSRF cookie sent
INFO - 2018-04-19 21:06:09 --> Input Class Initialized
INFO - 2018-04-19 21:06:09 --> Input Class Initialized
INFO - 2018-04-19 21:06:09 --> Language Class Initialized
INFO - 2018-04-19 21:06:09 --> Language Class Initialized
ERROR - 2018-04-19 21:06:09 --> 404 Page Not Found: Assets/css
ERROR - 2018-04-19 21:06:09 --> 404 Page Not Found: Assets/images
INFO - 2018-04-19 21:06:19 --> Config Class Initialized
INFO - 2018-04-19 21:06:19 --> Hooks Class Initialized
DEBUG - 2018-04-19 21:06:19 --> UTF-8 Support Enabled
INFO - 2018-04-19 21:06:19 --> Utf8 Class Initialized
INFO - 2018-04-19 21:06:19 --> URI Class Initialized
INFO - 2018-04-19 21:06:19 --> Router Class Initialized
INFO - 2018-04-19 21:06:19 --> Output Class Initialized
INFO - 2018-04-19 21:06:19 --> Security Class Initialized
DEBUG - 2018-04-19 21:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 21:06:19 --> CSRF cookie sent
INFO - 2018-04-19 21:06:19 --> CSRF token verified
INFO - 2018-04-19 21:06:19 --> Input Class Initialized
INFO - 2018-04-19 21:06:19 --> Language Class Initialized
INFO - 2018-04-19 21:06:19 --> Loader Class Initialized
INFO - 2018-04-19 21:06:19 --> Helper loaded: url_helper
INFO - 2018-04-19 21:06:19 --> Helper loaded: form_helper
INFO - 2018-04-19 21:06:19 --> Helper loaded: language_helper
DEBUG - 2018-04-19 21:06:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 21:06:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 21:06:19 --> User Agent Class Initialized
INFO - 2018-04-19 21:06:19 --> Controller Class Initialized
INFO - 2018-04-19 21:06:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 21:06:19 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-19 21:06:19 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-19 21:06:19 --> Form Validation Class Initialized
INFO - 2018-04-19 21:06:19 --> Pixel_Model class loaded
INFO - 2018-04-19 21:06:19 --> Database Driver Class Initialized
INFO - 2018-04-19 21:06:19 --> Model "AuthenticationModel" initialized
INFO - 2018-04-19 21:06:20 --> Config Class Initialized
INFO - 2018-04-19 21:06:20 --> Hooks Class Initialized
DEBUG - 2018-04-19 21:06:20 --> UTF-8 Support Enabled
INFO - 2018-04-19 21:06:20 --> Utf8 Class Initialized
INFO - 2018-04-19 21:06:20 --> URI Class Initialized
DEBUG - 2018-04-19 21:06:20 --> No URI present. Default controller set.
INFO - 2018-04-19 21:06:20 --> Router Class Initialized
INFO - 2018-04-19 21:06:20 --> Output Class Initialized
INFO - 2018-04-19 21:06:20 --> Security Class Initialized
DEBUG - 2018-04-19 21:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 21:06:20 --> CSRF cookie sent
INFO - 2018-04-19 21:06:20 --> Input Class Initialized
INFO - 2018-04-19 21:06:20 --> Language Class Initialized
INFO - 2018-04-19 21:06:20 --> Loader Class Initialized
INFO - 2018-04-19 21:06:20 --> Helper loaded: url_helper
INFO - 2018-04-19 21:06:20 --> Helper loaded: form_helper
INFO - 2018-04-19 21:06:20 --> Helper loaded: language_helper
DEBUG - 2018-04-19 21:06:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 21:06:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 21:06:20 --> User Agent Class Initialized
INFO - 2018-04-19 21:06:20 --> Controller Class Initialized
INFO - 2018-04-19 21:06:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 21:06:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 21:06:20 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 21:06:20 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-04-19 21:06:20 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 21:06:20 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-19 21:06:20 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 21:06:20 --> Final output sent to browser
DEBUG - 2018-04-19 21:06:20 --> Total execution time: 0.4631
INFO - 2018-04-19 21:06:20 --> Config Class Initialized
INFO - 2018-04-19 21:06:21 --> Hooks Class Initialized
DEBUG - 2018-04-19 21:06:21 --> UTF-8 Support Enabled
INFO - 2018-04-19 21:06:21 --> Utf8 Class Initialized
INFO - 2018-04-19 21:06:21 --> URI Class Initialized
INFO - 2018-04-19 21:06:21 --> Router Class Initialized
INFO - 2018-04-19 21:06:21 --> Output Class Initialized
INFO - 2018-04-19 21:06:21 --> Security Class Initialized
DEBUG - 2018-04-19 21:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 21:06:21 --> CSRF cookie sent
INFO - 2018-04-19 21:06:21 --> Input Class Initialized
INFO - 2018-04-19 21:06:21 --> Language Class Initialized
ERROR - 2018-04-19 21:06:21 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 21:06:22 --> Config Class Initialized
INFO - 2018-04-19 21:06:22 --> Hooks Class Initialized
DEBUG - 2018-04-19 21:06:22 --> UTF-8 Support Enabled
INFO - 2018-04-19 21:06:22 --> Utf8 Class Initialized
INFO - 2018-04-19 21:06:22 --> URI Class Initialized
INFO - 2018-04-19 21:06:22 --> Router Class Initialized
INFO - 2018-04-19 21:06:22 --> Output Class Initialized
INFO - 2018-04-19 21:06:22 --> Security Class Initialized
DEBUG - 2018-04-19 21:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 21:06:22 --> CSRF cookie sent
INFO - 2018-04-19 21:06:22 --> Input Class Initialized
INFO - 2018-04-19 21:06:22 --> Language Class Initialized
ERROR - 2018-04-19 21:06:23 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-19 22:51:55 --> Config Class Initialized
INFO - 2018-04-19 22:51:55 --> Hooks Class Initialized
DEBUG - 2018-04-19 22:51:56 --> UTF-8 Support Enabled
INFO - 2018-04-19 22:51:56 --> Utf8 Class Initialized
INFO - 2018-04-19 22:51:56 --> URI Class Initialized
INFO - 2018-04-19 22:51:56 --> Router Class Initialized
INFO - 2018-04-19 22:51:56 --> Output Class Initialized
INFO - 2018-04-19 22:51:56 --> Security Class Initialized
DEBUG - 2018-04-19 22:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 22:51:56 --> CSRF cookie sent
INFO - 2018-04-19 22:51:56 --> Input Class Initialized
INFO - 2018-04-19 22:51:56 --> Language Class Initialized
INFO - 2018-04-19 22:51:56 --> Loader Class Initialized
INFO - 2018-04-19 22:51:56 --> Helper loaded: url_helper
INFO - 2018-04-19 22:51:56 --> Helper loaded: form_helper
INFO - 2018-04-19 22:51:56 --> Helper loaded: language_helper
DEBUG - 2018-04-19 22:51:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 22:51:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 22:51:56 --> User Agent Class Initialized
INFO - 2018-04-19 22:51:56 --> Controller Class Initialized
INFO - 2018-04-19 22:51:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 22:51:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 22:51:57 --> CSRF cookie sent
INFO - 2018-04-19 22:51:57 --> Config Class Initialized
INFO - 2018-04-19 22:51:57 --> Hooks Class Initialized
DEBUG - 2018-04-19 22:51:57 --> UTF-8 Support Enabled
INFO - 2018-04-19 22:51:57 --> Utf8 Class Initialized
INFO - 2018-04-19 22:51:57 --> URI Class Initialized
DEBUG - 2018-04-19 22:51:57 --> No URI present. Default controller set.
INFO - 2018-04-19 22:51:57 --> Router Class Initialized
INFO - 2018-04-19 22:51:57 --> Output Class Initialized
INFO - 2018-04-19 22:51:57 --> Security Class Initialized
DEBUG - 2018-04-19 22:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 22:51:57 --> CSRF cookie sent
INFO - 2018-04-19 22:51:57 --> Input Class Initialized
INFO - 2018-04-19 22:51:57 --> Language Class Initialized
INFO - 2018-04-19 22:51:57 --> Loader Class Initialized
INFO - 2018-04-19 22:51:57 --> Helper loaded: url_helper
INFO - 2018-04-19 22:51:57 --> Helper loaded: form_helper
INFO - 2018-04-19 22:51:57 --> Helper loaded: language_helper
DEBUG - 2018-04-19 22:51:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 22:51:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 22:51:57 --> User Agent Class Initialized
INFO - 2018-04-19 22:51:57 --> Controller Class Initialized
INFO - 2018-04-19 22:51:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 22:51:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 22:51:57 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 22:51:57 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 22:51:57 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-19 22:51:57 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 22:51:57 --> Final output sent to browser
DEBUG - 2018-04-19 22:51:57 --> Total execution time: 0.6401
INFO - 2018-04-19 22:51:58 --> Config Class Initialized
INFO - 2018-04-19 22:51:58 --> Hooks Class Initialized
DEBUG - 2018-04-19 22:51:58 --> UTF-8 Support Enabled
INFO - 2018-04-19 22:51:58 --> Utf8 Class Initialized
INFO - 2018-04-19 22:51:58 --> URI Class Initialized
INFO - 2018-04-19 22:51:58 --> Router Class Initialized
INFO - 2018-04-19 22:51:58 --> Output Class Initialized
INFO - 2018-04-19 22:51:58 --> Security Class Initialized
DEBUG - 2018-04-19 22:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 22:51:58 --> CSRF cookie sent
INFO - 2018-04-19 22:51:58 --> Input Class Initialized
INFO - 2018-04-19 22:51:58 --> Language Class Initialized
ERROR - 2018-04-19 22:51:58 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 22:52:00 --> Config Class Initialized
INFO - 2018-04-19 22:52:00 --> Hooks Class Initialized
DEBUG - 2018-04-19 22:52:00 --> UTF-8 Support Enabled
INFO - 2018-04-19 22:52:00 --> Utf8 Class Initialized
INFO - 2018-04-19 22:52:00 --> URI Class Initialized
INFO - 2018-04-19 22:52:00 --> Router Class Initialized
INFO - 2018-04-19 22:52:00 --> Output Class Initialized
INFO - 2018-04-19 22:52:00 --> Security Class Initialized
DEBUG - 2018-04-19 22:52:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 22:52:00 --> CSRF cookie sent
INFO - 2018-04-19 22:52:00 --> Input Class Initialized
INFO - 2018-04-19 22:52:00 --> Language Class Initialized
ERROR - 2018-04-19 22:52:00 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-19 22:59:32 --> Config Class Initialized
INFO - 2018-04-19 22:59:32 --> Hooks Class Initialized
DEBUG - 2018-04-19 22:59:32 --> UTF-8 Support Enabled
INFO - 2018-04-19 22:59:32 --> Utf8 Class Initialized
INFO - 2018-04-19 22:59:32 --> URI Class Initialized
DEBUG - 2018-04-19 22:59:32 --> No URI present. Default controller set.
INFO - 2018-04-19 22:59:32 --> Router Class Initialized
INFO - 2018-04-19 22:59:32 --> Output Class Initialized
INFO - 2018-04-19 22:59:32 --> Security Class Initialized
DEBUG - 2018-04-19 22:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 22:59:32 --> CSRF cookie sent
INFO - 2018-04-19 22:59:32 --> Input Class Initialized
INFO - 2018-04-19 22:59:32 --> Language Class Initialized
INFO - 2018-04-19 22:59:32 --> Loader Class Initialized
INFO - 2018-04-19 22:59:32 --> Helper loaded: url_helper
INFO - 2018-04-19 22:59:32 --> Helper loaded: form_helper
INFO - 2018-04-19 22:59:32 --> Helper loaded: language_helper
DEBUG - 2018-04-19 22:59:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 22:59:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 22:59:32 --> User Agent Class Initialized
INFO - 2018-04-19 22:59:32 --> Controller Class Initialized
INFO - 2018-04-19 22:59:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 22:59:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 22:59:33 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 22:59:33 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 22:59:33 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-19 22:59:33 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 22:59:33 --> Final output sent to browser
DEBUG - 2018-04-19 22:59:33 --> Total execution time: 0.5452
INFO - 2018-04-19 22:59:33 --> Config Class Initialized
INFO - 2018-04-19 22:59:33 --> Hooks Class Initialized
DEBUG - 2018-04-19 22:59:33 --> UTF-8 Support Enabled
INFO - 2018-04-19 22:59:33 --> Utf8 Class Initialized
INFO - 2018-04-19 22:59:33 --> URI Class Initialized
INFO - 2018-04-19 22:59:33 --> Router Class Initialized
INFO - 2018-04-19 22:59:33 --> Output Class Initialized
INFO - 2018-04-19 22:59:33 --> Security Class Initialized
DEBUG - 2018-04-19 22:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 22:59:33 --> CSRF cookie sent
INFO - 2018-04-19 22:59:33 --> Input Class Initialized
INFO - 2018-04-19 22:59:33 --> Language Class Initialized
ERROR - 2018-04-19 22:59:33 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 22:59:35 --> Config Class Initialized
INFO - 2018-04-19 22:59:35 --> Hooks Class Initialized
DEBUG - 2018-04-19 22:59:35 --> UTF-8 Support Enabled
INFO - 2018-04-19 22:59:35 --> Utf8 Class Initialized
INFO - 2018-04-19 22:59:35 --> URI Class Initialized
INFO - 2018-04-19 22:59:35 --> Router Class Initialized
INFO - 2018-04-19 22:59:35 --> Output Class Initialized
INFO - 2018-04-19 22:59:35 --> Security Class Initialized
DEBUG - 2018-04-19 22:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 22:59:35 --> CSRF cookie sent
INFO - 2018-04-19 22:59:35 --> Input Class Initialized
INFO - 2018-04-19 22:59:35 --> Language Class Initialized
ERROR - 2018-04-19 22:59:35 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-19 23:00:20 --> Config Class Initialized
INFO - 2018-04-19 23:00:20 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:00:20 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:00:20 --> Utf8 Class Initialized
INFO - 2018-04-19 23:00:20 --> URI Class Initialized
DEBUG - 2018-04-19 23:00:20 --> No URI present. Default controller set.
INFO - 2018-04-19 23:00:20 --> Router Class Initialized
INFO - 2018-04-19 23:00:20 --> Output Class Initialized
INFO - 2018-04-19 23:00:20 --> Security Class Initialized
DEBUG - 2018-04-19 23:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:00:20 --> CSRF cookie sent
INFO - 2018-04-19 23:00:20 --> Input Class Initialized
INFO - 2018-04-19 23:00:20 --> Language Class Initialized
INFO - 2018-04-19 23:00:20 --> Loader Class Initialized
INFO - 2018-04-19 23:00:20 --> Helper loaded: url_helper
INFO - 2018-04-19 23:00:20 --> Helper loaded: form_helper
INFO - 2018-04-19 23:00:21 --> Helper loaded: language_helper
DEBUG - 2018-04-19 23:00:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 23:00:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 23:00:21 --> User Agent Class Initialized
INFO - 2018-04-19 23:00:21 --> Controller Class Initialized
INFO - 2018-04-19 23:00:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 23:00:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 23:00:21 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 23:00:21 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 23:00:21 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-19 23:00:21 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 23:00:21 --> Final output sent to browser
DEBUG - 2018-04-19 23:00:21 --> Total execution time: 0.5393
INFO - 2018-04-19 23:00:21 --> Config Class Initialized
INFO - 2018-04-19 23:00:21 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:00:21 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:00:21 --> Utf8 Class Initialized
INFO - 2018-04-19 23:00:21 --> URI Class Initialized
INFO - 2018-04-19 23:00:21 --> Router Class Initialized
INFO - 2018-04-19 23:00:21 --> Output Class Initialized
INFO - 2018-04-19 23:00:21 --> Security Class Initialized
DEBUG - 2018-04-19 23:00:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:00:21 --> CSRF cookie sent
INFO - 2018-04-19 23:00:21 --> Input Class Initialized
INFO - 2018-04-19 23:00:21 --> Language Class Initialized
ERROR - 2018-04-19 23:00:21 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 23:00:23 --> Config Class Initialized
INFO - 2018-04-19 23:00:23 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:00:23 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:00:23 --> Utf8 Class Initialized
INFO - 2018-04-19 23:00:23 --> URI Class Initialized
INFO - 2018-04-19 23:00:23 --> Router Class Initialized
INFO - 2018-04-19 23:00:23 --> Output Class Initialized
INFO - 2018-04-19 23:00:23 --> Security Class Initialized
DEBUG - 2018-04-19 23:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:00:23 --> CSRF cookie sent
INFO - 2018-04-19 23:00:23 --> Input Class Initialized
INFO - 2018-04-19 23:00:23 --> Language Class Initialized
ERROR - 2018-04-19 23:00:23 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-19 23:00:25 --> Config Class Initialized
INFO - 2018-04-19 23:00:25 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:00:25 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:00:25 --> Utf8 Class Initialized
INFO - 2018-04-19 23:00:25 --> URI Class Initialized
INFO - 2018-04-19 23:00:25 --> Router Class Initialized
INFO - 2018-04-19 23:00:25 --> Output Class Initialized
INFO - 2018-04-19 23:00:25 --> Security Class Initialized
DEBUG - 2018-04-19 23:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:00:25 --> CSRF cookie sent
INFO - 2018-04-19 23:00:25 --> Input Class Initialized
INFO - 2018-04-19 23:00:25 --> Language Class Initialized
INFO - 2018-04-19 23:00:25 --> Loader Class Initialized
INFO - 2018-04-19 23:00:25 --> Helper loaded: url_helper
INFO - 2018-04-19 23:00:25 --> Helper loaded: form_helper
INFO - 2018-04-19 23:00:25 --> Helper loaded: language_helper
DEBUG - 2018-04-19 23:00:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 23:00:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 23:00:25 --> User Agent Class Initialized
INFO - 2018-04-19 23:00:25 --> Controller Class Initialized
INFO - 2018-04-19 23:00:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 23:00:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 23:00:25 --> Pixel_Model class loaded
INFO - 2018-04-19 23:00:25 --> Database Driver Class Initialized
INFO - 2018-04-19 23:00:25 --> Model "RegistrationModel" initialized
DEBUG - 2018-04-19 23:00:25 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-19 23:00:25 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 23:00:26 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 23:00:26 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-19 23:00:26 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-19 23:00:26 --> Could not find the language line "req_email"
INFO - 2018-04-19 23:00:26 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-04-19 23:00:26 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 23:00:26 --> Final output sent to browser
DEBUG - 2018-04-19 23:00:26 --> Total execution time: 1.0888
INFO - 2018-04-19 23:00:26 --> Config Class Initialized
INFO - 2018-04-19 23:00:26 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:00:26 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:00:26 --> Utf8 Class Initialized
INFO - 2018-04-19 23:00:26 --> URI Class Initialized
INFO - 2018-04-19 23:00:26 --> Router Class Initialized
INFO - 2018-04-19 23:00:26 --> Output Class Initialized
INFO - 2018-04-19 23:00:26 --> Security Class Initialized
DEBUG - 2018-04-19 23:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:00:26 --> CSRF cookie sent
INFO - 2018-04-19 23:00:26 --> Input Class Initialized
INFO - 2018-04-19 23:00:26 --> Language Class Initialized
ERROR - 2018-04-19 23:00:27 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 23:00:28 --> Config Class Initialized
INFO - 2018-04-19 23:00:28 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:00:28 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:00:29 --> Utf8 Class Initialized
INFO - 2018-04-19 23:00:29 --> URI Class Initialized
DEBUG - 2018-04-19 23:00:29 --> No URI present. Default controller set.
INFO - 2018-04-19 23:00:29 --> Router Class Initialized
INFO - 2018-04-19 23:00:29 --> Output Class Initialized
INFO - 2018-04-19 23:00:29 --> Security Class Initialized
DEBUG - 2018-04-19 23:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:00:29 --> CSRF cookie sent
INFO - 2018-04-19 23:00:29 --> Input Class Initialized
INFO - 2018-04-19 23:00:29 --> Language Class Initialized
INFO - 2018-04-19 23:00:29 --> Loader Class Initialized
INFO - 2018-04-19 23:00:29 --> Helper loaded: url_helper
INFO - 2018-04-19 23:00:29 --> Helper loaded: form_helper
INFO - 2018-04-19 23:00:29 --> Helper loaded: language_helper
DEBUG - 2018-04-19 23:00:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 23:00:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 23:00:29 --> User Agent Class Initialized
INFO - 2018-04-19 23:00:29 --> Controller Class Initialized
INFO - 2018-04-19 23:00:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 23:00:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 23:00:29 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 23:00:29 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 23:00:29 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-19 23:00:29 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 23:00:29 --> Final output sent to browser
DEBUG - 2018-04-19 23:00:29 --> Total execution time: 0.5131
INFO - 2018-04-19 23:00:29 --> Config Class Initialized
INFO - 2018-04-19 23:00:29 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:00:29 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:00:29 --> Utf8 Class Initialized
INFO - 2018-04-19 23:00:30 --> URI Class Initialized
INFO - 2018-04-19 23:00:30 --> Router Class Initialized
INFO - 2018-04-19 23:00:30 --> Output Class Initialized
INFO - 2018-04-19 23:00:30 --> Security Class Initialized
DEBUG - 2018-04-19 23:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:00:30 --> CSRF cookie sent
INFO - 2018-04-19 23:00:30 --> Input Class Initialized
INFO - 2018-04-19 23:00:30 --> Language Class Initialized
ERROR - 2018-04-19 23:00:30 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 23:00:31 --> Config Class Initialized
INFO - 2018-04-19 23:00:31 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:00:31 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:00:31 --> Utf8 Class Initialized
INFO - 2018-04-19 23:00:31 --> URI Class Initialized
INFO - 2018-04-19 23:00:31 --> Router Class Initialized
INFO - 2018-04-19 23:00:31 --> Output Class Initialized
INFO - 2018-04-19 23:00:32 --> Security Class Initialized
DEBUG - 2018-04-19 23:00:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:00:32 --> CSRF cookie sent
INFO - 2018-04-19 23:00:32 --> Input Class Initialized
INFO - 2018-04-19 23:00:32 --> Language Class Initialized
ERROR - 2018-04-19 23:00:32 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-19 23:00:32 --> Config Class Initialized
INFO - 2018-04-19 23:00:32 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:00:32 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:00:32 --> Utf8 Class Initialized
INFO - 2018-04-19 23:00:32 --> URI Class Initialized
INFO - 2018-04-19 23:00:32 --> Router Class Initialized
INFO - 2018-04-19 23:00:32 --> Output Class Initialized
INFO - 2018-04-19 23:00:32 --> Security Class Initialized
DEBUG - 2018-04-19 23:00:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:00:32 --> CSRF cookie sent
INFO - 2018-04-19 23:00:32 --> Input Class Initialized
INFO - 2018-04-19 23:00:32 --> Language Class Initialized
INFO - 2018-04-19 23:00:33 --> Loader Class Initialized
INFO - 2018-04-19 23:00:33 --> Helper loaded: url_helper
INFO - 2018-04-19 23:00:33 --> Helper loaded: form_helper
INFO - 2018-04-19 23:00:33 --> Helper loaded: language_helper
DEBUG - 2018-04-19 23:00:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 23:00:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 23:00:33 --> User Agent Class Initialized
INFO - 2018-04-19 23:00:33 --> Controller Class Initialized
INFO - 2018-04-19 23:00:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 23:00:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 23:00:33 --> Pixel_Model class loaded
INFO - 2018-04-19 23:00:33 --> Database Driver Class Initialized
INFO - 2018-04-19 23:00:33 --> Model "RegistrationModel" initialized
DEBUG - 2018-04-19 23:00:33 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-19 23:00:33 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 23:00:33 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 23:00:33 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-19 23:00:33 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-19 23:00:33 --> Could not find the language line "req_email"
INFO - 2018-04-19 23:00:33 --> File loaded: E:\www\yacopoo\application\views\register/signup_lawyer.php
INFO - 2018-04-19 23:00:33 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 23:00:33 --> Final output sent to browser
DEBUG - 2018-04-19 23:00:33 --> Total execution time: 0.7379
INFO - 2018-04-19 23:00:33 --> Config Class Initialized
INFO - 2018-04-19 23:00:33 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:00:34 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:00:34 --> Utf8 Class Initialized
INFO - 2018-04-19 23:00:34 --> URI Class Initialized
INFO - 2018-04-19 23:00:34 --> Router Class Initialized
INFO - 2018-04-19 23:00:34 --> Output Class Initialized
INFO - 2018-04-19 23:00:34 --> Security Class Initialized
DEBUG - 2018-04-19 23:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:00:34 --> CSRF cookie sent
INFO - 2018-04-19 23:00:34 --> Input Class Initialized
INFO - 2018-04-19 23:00:34 --> Language Class Initialized
ERROR - 2018-04-19 23:00:34 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 23:00:37 --> Config Class Initialized
INFO - 2018-04-19 23:00:37 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:00:37 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:00:37 --> Utf8 Class Initialized
INFO - 2018-04-19 23:00:37 --> URI Class Initialized
DEBUG - 2018-04-19 23:00:37 --> No URI present. Default controller set.
INFO - 2018-04-19 23:00:37 --> Router Class Initialized
INFO - 2018-04-19 23:00:37 --> Output Class Initialized
INFO - 2018-04-19 23:00:37 --> Security Class Initialized
DEBUG - 2018-04-19 23:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:00:37 --> CSRF cookie sent
INFO - 2018-04-19 23:00:37 --> Input Class Initialized
INFO - 2018-04-19 23:00:37 --> Language Class Initialized
INFO - 2018-04-19 23:00:37 --> Loader Class Initialized
INFO - 2018-04-19 23:00:37 --> Helper loaded: url_helper
INFO - 2018-04-19 23:00:37 --> Helper loaded: form_helper
INFO - 2018-04-19 23:00:37 --> Helper loaded: language_helper
DEBUG - 2018-04-19 23:00:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 23:00:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 23:00:37 --> User Agent Class Initialized
INFO - 2018-04-19 23:00:37 --> Controller Class Initialized
INFO - 2018-04-19 23:00:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 23:00:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 23:00:37 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 23:00:37 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 23:00:37 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-19 23:00:37 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 23:00:37 --> Final output sent to browser
DEBUG - 2018-04-19 23:00:37 --> Total execution time: 0.4673
INFO - 2018-04-19 23:00:37 --> Config Class Initialized
INFO - 2018-04-19 23:00:37 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:00:37 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:00:37 --> Utf8 Class Initialized
INFO - 2018-04-19 23:00:37 --> URI Class Initialized
INFO - 2018-04-19 23:00:38 --> Router Class Initialized
INFO - 2018-04-19 23:00:38 --> Output Class Initialized
INFO - 2018-04-19 23:00:38 --> Security Class Initialized
DEBUG - 2018-04-19 23:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:00:38 --> CSRF cookie sent
INFO - 2018-04-19 23:00:38 --> Input Class Initialized
INFO - 2018-04-19 23:00:38 --> Language Class Initialized
ERROR - 2018-04-19 23:00:38 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 23:00:40 --> Config Class Initialized
INFO - 2018-04-19 23:00:40 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:00:40 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:00:40 --> Utf8 Class Initialized
INFO - 2018-04-19 23:00:40 --> URI Class Initialized
INFO - 2018-04-19 23:00:40 --> Router Class Initialized
INFO - 2018-04-19 23:00:40 --> Output Class Initialized
INFO - 2018-04-19 23:00:40 --> Security Class Initialized
DEBUG - 2018-04-19 23:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:00:40 --> CSRF cookie sent
INFO - 2018-04-19 23:00:40 --> Input Class Initialized
INFO - 2018-04-19 23:00:40 --> Language Class Initialized
ERROR - 2018-04-19 23:00:40 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-19 23:00:41 --> Config Class Initialized
INFO - 2018-04-19 23:00:41 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:00:41 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:00:41 --> Utf8 Class Initialized
INFO - 2018-04-19 23:00:41 --> URI Class Initialized
INFO - 2018-04-19 23:00:41 --> Router Class Initialized
INFO - 2018-04-19 23:00:41 --> Output Class Initialized
INFO - 2018-04-19 23:00:41 --> Security Class Initialized
DEBUG - 2018-04-19 23:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:00:41 --> CSRF cookie sent
INFO - 2018-04-19 23:00:41 --> Input Class Initialized
INFO - 2018-04-19 23:00:41 --> Language Class Initialized
INFO - 2018-04-19 23:00:41 --> Loader Class Initialized
INFO - 2018-04-19 23:00:41 --> Helper loaded: url_helper
INFO - 2018-04-19 23:00:41 --> Helper loaded: form_helper
INFO - 2018-04-19 23:00:41 --> Helper loaded: language_helper
DEBUG - 2018-04-19 23:00:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 23:00:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 23:00:41 --> User Agent Class Initialized
INFO - 2018-04-19 23:00:41 --> Controller Class Initialized
INFO - 2018-04-19 23:00:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 23:00:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 23:00:41 --> Pixel_Model class loaded
INFO - 2018-04-19 23:00:41 --> Database Driver Class Initialized
INFO - 2018-04-19 23:00:41 --> Model "RegistrationModel" initialized
DEBUG - 2018-04-19 23:00:41 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-19 23:00:41 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 23:00:41 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 23:00:41 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-19 23:00:41 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-19 23:00:41 --> Could not find the language line "req_email"
INFO - 2018-04-19 23:00:41 --> File loaded: E:\www\yacopoo\application\views\register/signup_fa.php
INFO - 2018-04-19 23:00:41 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 23:00:41 --> Final output sent to browser
DEBUG - 2018-04-19 23:00:41 --> Total execution time: 0.7239
INFO - 2018-04-19 23:00:42 --> Config Class Initialized
INFO - 2018-04-19 23:00:42 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:00:42 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:00:42 --> Utf8 Class Initialized
INFO - 2018-04-19 23:00:42 --> URI Class Initialized
INFO - 2018-04-19 23:00:42 --> Router Class Initialized
INFO - 2018-04-19 23:00:42 --> Output Class Initialized
INFO - 2018-04-19 23:00:42 --> Security Class Initialized
DEBUG - 2018-04-19 23:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:00:42 --> CSRF cookie sent
INFO - 2018-04-19 23:00:42 --> Input Class Initialized
INFO - 2018-04-19 23:00:42 --> Language Class Initialized
ERROR - 2018-04-19 23:00:42 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 23:01:28 --> Config Class Initialized
INFO - 2018-04-19 23:01:28 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:01:28 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:01:28 --> Utf8 Class Initialized
INFO - 2018-04-19 23:01:28 --> URI Class Initialized
DEBUG - 2018-04-19 23:01:28 --> No URI present. Default controller set.
INFO - 2018-04-19 23:01:28 --> Router Class Initialized
INFO - 2018-04-19 23:01:28 --> Output Class Initialized
INFO - 2018-04-19 23:01:28 --> Security Class Initialized
DEBUG - 2018-04-19 23:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:01:28 --> CSRF cookie sent
INFO - 2018-04-19 23:01:28 --> Input Class Initialized
INFO - 2018-04-19 23:01:28 --> Language Class Initialized
INFO - 2018-04-19 23:01:28 --> Loader Class Initialized
INFO - 2018-04-19 23:01:28 --> Helper loaded: url_helper
INFO - 2018-04-19 23:01:28 --> Helper loaded: form_helper
INFO - 2018-04-19 23:01:28 --> Helper loaded: language_helper
DEBUG - 2018-04-19 23:01:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 23:01:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 23:01:28 --> User Agent Class Initialized
INFO - 2018-04-19 23:01:28 --> Controller Class Initialized
INFO - 2018-04-19 23:01:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 23:01:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 23:01:28 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 23:01:28 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 23:01:28 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-19 23:01:28 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 23:01:28 --> Final output sent to browser
DEBUG - 2018-04-19 23:01:28 --> Total execution time: 0.4582
INFO - 2018-04-19 23:01:29 --> Config Class Initialized
INFO - 2018-04-19 23:01:29 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:01:29 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:01:29 --> Utf8 Class Initialized
INFO - 2018-04-19 23:01:29 --> URI Class Initialized
INFO - 2018-04-19 23:01:29 --> Router Class Initialized
INFO - 2018-04-19 23:01:29 --> Output Class Initialized
INFO - 2018-04-19 23:01:29 --> Security Class Initialized
DEBUG - 2018-04-19 23:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:01:29 --> CSRF cookie sent
INFO - 2018-04-19 23:01:29 --> Input Class Initialized
INFO - 2018-04-19 23:01:29 --> Language Class Initialized
ERROR - 2018-04-19 23:01:29 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 23:01:30 --> Config Class Initialized
INFO - 2018-04-19 23:01:30 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:01:30 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:01:30 --> Utf8 Class Initialized
INFO - 2018-04-19 23:01:30 --> URI Class Initialized
INFO - 2018-04-19 23:01:30 --> Router Class Initialized
INFO - 2018-04-19 23:01:30 --> Output Class Initialized
INFO - 2018-04-19 23:01:30 --> Security Class Initialized
DEBUG - 2018-04-19 23:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:01:30 --> CSRF cookie sent
INFO - 2018-04-19 23:01:30 --> Input Class Initialized
INFO - 2018-04-19 23:01:30 --> Language Class Initialized
ERROR - 2018-04-19 23:01:31 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-19 23:01:57 --> Config Class Initialized
INFO - 2018-04-19 23:01:57 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:01:57 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:01:57 --> Utf8 Class Initialized
INFO - 2018-04-19 23:01:57 --> URI Class Initialized
INFO - 2018-04-19 23:01:57 --> Router Class Initialized
INFO - 2018-04-19 23:01:57 --> Output Class Initialized
INFO - 2018-04-19 23:01:57 --> Security Class Initialized
DEBUG - 2018-04-19 23:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:01:57 --> CSRF cookie sent
INFO - 2018-04-19 23:01:57 --> Input Class Initialized
INFO - 2018-04-19 23:01:57 --> Language Class Initialized
INFO - 2018-04-19 23:01:57 --> Loader Class Initialized
INFO - 2018-04-19 23:01:57 --> Helper loaded: url_helper
INFO - 2018-04-19 23:01:57 --> Helper loaded: form_helper
INFO - 2018-04-19 23:01:57 --> Helper loaded: language_helper
DEBUG - 2018-04-19 23:01:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 23:01:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 23:01:57 --> User Agent Class Initialized
INFO - 2018-04-19 23:01:57 --> Controller Class Initialized
INFO - 2018-04-19 23:01:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 23:01:57 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-19 23:01:57 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-19 23:01:57 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 23:01:57 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 23:01:57 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-19 23:01:57 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-19 23:01:57 --> Could not find the language line "req_email"
INFO - 2018-04-19 23:01:57 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-04-19 23:01:57 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 23:01:57 --> Final output sent to browser
DEBUG - 2018-04-19 23:01:57 --> Total execution time: 0.5771
INFO - 2018-04-19 23:01:58 --> Config Class Initialized
INFO - 2018-04-19 23:01:58 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:01:58 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:01:58 --> Utf8 Class Initialized
INFO - 2018-04-19 23:01:58 --> URI Class Initialized
INFO - 2018-04-19 23:01:58 --> Router Class Initialized
INFO - 2018-04-19 23:01:58 --> Output Class Initialized
INFO - 2018-04-19 23:01:58 --> Security Class Initialized
DEBUG - 2018-04-19 23:01:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:01:58 --> CSRF cookie sent
INFO - 2018-04-19 23:01:58 --> Input Class Initialized
INFO - 2018-04-19 23:01:58 --> Language Class Initialized
ERROR - 2018-04-19 23:01:58 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 23:01:58 --> Config Class Initialized
INFO - 2018-04-19 23:01:58 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:01:58 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:01:58 --> Utf8 Class Initialized
INFO - 2018-04-19 23:01:58 --> URI Class Initialized
INFO - 2018-04-19 23:01:58 --> Router Class Initialized
INFO - 2018-04-19 23:01:58 --> Output Class Initialized
INFO - 2018-04-19 23:01:58 --> Security Class Initialized
DEBUG - 2018-04-19 23:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:01:59 --> CSRF cookie sent
INFO - 2018-04-19 23:01:59 --> Input Class Initialized
INFO - 2018-04-19 23:01:59 --> Language Class Initialized
ERROR - 2018-04-19 23:01:59 --> 404 Page Not Found: Assets/images
INFO - 2018-04-19 23:02:03 --> Config Class Initialized
INFO - 2018-04-19 23:02:03 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:02:03 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:02:03 --> Utf8 Class Initialized
INFO - 2018-04-19 23:02:03 --> URI Class Initialized
INFO - 2018-04-19 23:02:03 --> Router Class Initialized
INFO - 2018-04-19 23:02:03 --> Output Class Initialized
INFO - 2018-04-19 23:02:04 --> Security Class Initialized
DEBUG - 2018-04-19 23:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:02:04 --> CSRF cookie sent
INFO - 2018-04-19 23:02:04 --> CSRF token verified
INFO - 2018-04-19 23:02:04 --> Input Class Initialized
INFO - 2018-04-19 23:02:04 --> Language Class Initialized
INFO - 2018-04-19 23:02:04 --> Loader Class Initialized
INFO - 2018-04-19 23:02:04 --> Helper loaded: url_helper
INFO - 2018-04-19 23:02:04 --> Helper loaded: form_helper
INFO - 2018-04-19 23:02:04 --> Helper loaded: language_helper
DEBUG - 2018-04-19 23:02:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 23:02:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 23:02:04 --> User Agent Class Initialized
INFO - 2018-04-19 23:02:04 --> Controller Class Initialized
INFO - 2018-04-19 23:02:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 23:02:04 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-19 23:02:04 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-19 23:02:04 --> Form Validation Class Initialized
INFO - 2018-04-19 23:02:04 --> Pixel_Model class loaded
INFO - 2018-04-19 23:02:04 --> Database Driver Class Initialized
INFO - 2018-04-19 23:02:04 --> Model "AuthenticationModel" initialized
INFO - 2018-04-19 23:02:04 --> Config Class Initialized
INFO - 2018-04-19 23:02:04 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:02:05 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:02:05 --> Utf8 Class Initialized
INFO - 2018-04-19 23:02:05 --> URI Class Initialized
DEBUG - 2018-04-19 23:02:05 --> No URI present. Default controller set.
INFO - 2018-04-19 23:02:05 --> Router Class Initialized
INFO - 2018-04-19 23:02:05 --> Output Class Initialized
INFO - 2018-04-19 23:02:05 --> Security Class Initialized
DEBUG - 2018-04-19 23:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:02:05 --> CSRF cookie sent
INFO - 2018-04-19 23:02:05 --> Input Class Initialized
INFO - 2018-04-19 23:02:05 --> Language Class Initialized
INFO - 2018-04-19 23:02:05 --> Loader Class Initialized
INFO - 2018-04-19 23:02:05 --> Helper loaded: url_helper
INFO - 2018-04-19 23:02:05 --> Helper loaded: form_helper
INFO - 2018-04-19 23:02:05 --> Helper loaded: language_helper
DEBUG - 2018-04-19 23:02:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 23:02:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 23:02:05 --> User Agent Class Initialized
INFO - 2018-04-19 23:02:05 --> Controller Class Initialized
INFO - 2018-04-19 23:02:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 23:02:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 23:02:05 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 23:02:05 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-19 23:02:05 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 23:02:05 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-19 23:02:05 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 23:02:05 --> Final output sent to browser
DEBUG - 2018-04-19 23:02:05 --> Total execution time: 0.4763
INFO - 2018-04-19 23:02:05 --> Config Class Initialized
INFO - 2018-04-19 23:02:05 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:02:05 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:02:05 --> Utf8 Class Initialized
INFO - 2018-04-19 23:02:05 --> URI Class Initialized
INFO - 2018-04-19 23:02:06 --> Router Class Initialized
INFO - 2018-04-19 23:02:06 --> Output Class Initialized
INFO - 2018-04-19 23:02:06 --> Security Class Initialized
DEBUG - 2018-04-19 23:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:02:06 --> CSRF cookie sent
INFO - 2018-04-19 23:02:06 --> Input Class Initialized
INFO - 2018-04-19 23:02:06 --> Language Class Initialized
ERROR - 2018-04-19 23:02:06 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 23:02:07 --> Config Class Initialized
INFO - 2018-04-19 23:02:07 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:02:07 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:02:07 --> Utf8 Class Initialized
INFO - 2018-04-19 23:02:07 --> URI Class Initialized
INFO - 2018-04-19 23:02:07 --> Router Class Initialized
INFO - 2018-04-19 23:02:07 --> Output Class Initialized
INFO - 2018-04-19 23:02:07 --> Security Class Initialized
DEBUG - 2018-04-19 23:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:02:07 --> CSRF cookie sent
INFO - 2018-04-19 23:02:07 --> Input Class Initialized
INFO - 2018-04-19 23:02:07 --> Language Class Initialized
ERROR - 2018-04-19 23:02:07 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-19 23:02:13 --> Config Class Initialized
INFO - 2018-04-19 23:02:13 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:02:13 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:02:13 --> Utf8 Class Initialized
INFO - 2018-04-19 23:02:13 --> URI Class Initialized
INFO - 2018-04-19 23:02:13 --> Router Class Initialized
INFO - 2018-04-19 23:02:13 --> Output Class Initialized
INFO - 2018-04-19 23:02:13 --> Security Class Initialized
DEBUG - 2018-04-19 23:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:02:13 --> CSRF cookie sent
INFO - 2018-04-19 23:02:13 --> Input Class Initialized
INFO - 2018-04-19 23:02:13 --> Language Class Initialized
INFO - 2018-04-19 23:02:13 --> Loader Class Initialized
INFO - 2018-04-19 23:02:13 --> Helper loaded: url_helper
INFO - 2018-04-19 23:02:13 --> Helper loaded: form_helper
INFO - 2018-04-19 23:02:13 --> Helper loaded: language_helper
DEBUG - 2018-04-19 23:02:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 23:02:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 23:02:13 --> User Agent Class Initialized
INFO - 2018-04-19 23:02:13 --> Controller Class Initialized
INFO - 2018-04-19 23:02:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 23:02:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 23:02:13 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 23:02:13 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-19 23:02:13 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 23:02:13 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-19 23:02:13 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-19 23:02:13 --> File loaded: E:\www\yacopoo\application\views\myaccount/change_password.php
INFO - 2018-04-19 23:02:13 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 23:02:13 --> Final output sent to browser
DEBUG - 2018-04-19 23:02:13 --> Total execution time: 0.5720
INFO - 2018-04-19 23:02:14 --> Config Class Initialized
INFO - 2018-04-19 23:02:14 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:02:14 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:02:14 --> Utf8 Class Initialized
INFO - 2018-04-19 23:02:14 --> URI Class Initialized
INFO - 2018-04-19 23:02:14 --> Router Class Initialized
INFO - 2018-04-19 23:02:14 --> Output Class Initialized
INFO - 2018-04-19 23:02:14 --> Security Class Initialized
DEBUG - 2018-04-19 23:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:02:14 --> CSRF cookie sent
INFO - 2018-04-19 23:02:14 --> Input Class Initialized
INFO - 2018-04-19 23:02:14 --> Language Class Initialized
ERROR - 2018-04-19 23:02:14 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 23:03:15 --> Config Class Initialized
INFO - 2018-04-19 23:03:15 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:03:15 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:03:15 --> Utf8 Class Initialized
INFO - 2018-04-19 23:03:15 --> URI Class Initialized
INFO - 2018-04-19 23:03:15 --> Router Class Initialized
INFO - 2018-04-19 23:03:15 --> Output Class Initialized
INFO - 2018-04-19 23:03:15 --> Security Class Initialized
DEBUG - 2018-04-19 23:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:03:15 --> CSRF cookie sent
INFO - 2018-04-19 23:03:15 --> Input Class Initialized
INFO - 2018-04-19 23:03:15 --> Language Class Initialized
INFO - 2018-04-19 23:03:15 --> Loader Class Initialized
INFO - 2018-04-19 23:03:15 --> Helper loaded: url_helper
INFO - 2018-04-19 23:03:15 --> Helper loaded: form_helper
INFO - 2018-04-19 23:03:15 --> Helper loaded: language_helper
DEBUG - 2018-04-19 23:03:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 23:03:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 23:03:15 --> User Agent Class Initialized
INFO - 2018-04-19 23:03:15 --> Controller Class Initialized
INFO - 2018-04-19 23:03:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 23:03:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 23:03:15 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 23:03:15 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-19 23:03:15 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 23:03:15 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-19 23:03:15 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-19 23:03:15 --> File loaded: E:\www\yacopoo\application\views\myaccount/change_password.php
INFO - 2018-04-19 23:03:15 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 23:03:15 --> Final output sent to browser
DEBUG - 2018-04-19 23:03:15 --> Total execution time: 0.5112
INFO - 2018-04-19 23:03:16 --> Config Class Initialized
INFO - 2018-04-19 23:03:16 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:03:16 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:03:16 --> Utf8 Class Initialized
INFO - 2018-04-19 23:03:16 --> URI Class Initialized
INFO - 2018-04-19 23:03:16 --> Router Class Initialized
INFO - 2018-04-19 23:03:16 --> Output Class Initialized
INFO - 2018-04-19 23:03:16 --> Security Class Initialized
DEBUG - 2018-04-19 23:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:03:16 --> CSRF cookie sent
INFO - 2018-04-19 23:03:16 --> Input Class Initialized
INFO - 2018-04-19 23:03:16 --> Language Class Initialized
ERROR - 2018-04-19 23:03:16 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 23:03:45 --> Config Class Initialized
INFO - 2018-04-19 23:03:45 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:03:45 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:03:45 --> Utf8 Class Initialized
INFO - 2018-04-19 23:03:45 --> URI Class Initialized
INFO - 2018-04-19 23:03:45 --> Router Class Initialized
INFO - 2018-04-19 23:03:45 --> Output Class Initialized
INFO - 2018-04-19 23:03:45 --> Security Class Initialized
DEBUG - 2018-04-19 23:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:03:46 --> CSRF cookie sent
INFO - 2018-04-19 23:03:46 --> Input Class Initialized
INFO - 2018-04-19 23:03:46 --> Language Class Initialized
INFO - 2018-04-19 23:03:46 --> Loader Class Initialized
INFO - 2018-04-19 23:03:46 --> Helper loaded: url_helper
INFO - 2018-04-19 23:03:46 --> Helper loaded: form_helper
INFO - 2018-04-19 23:03:46 --> Helper loaded: language_helper
DEBUG - 2018-04-19 23:03:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 23:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 23:03:46 --> User Agent Class Initialized
INFO - 2018-04-19 23:03:46 --> Controller Class Initialized
INFO - 2018-04-19 23:03:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 23:03:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 23:03:46 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 23:03:46 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-19 23:03:46 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 23:03:46 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-19 23:03:46 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-19 23:03:46 --> File loaded: E:\www\yacopoo\application\views\myaccount/change_password.php
INFO - 2018-04-19 23:03:46 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 23:03:46 --> Final output sent to browser
DEBUG - 2018-04-19 23:03:46 --> Total execution time: 0.5151
INFO - 2018-04-19 23:03:46 --> Config Class Initialized
INFO - 2018-04-19 23:03:46 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:03:46 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:03:46 --> Utf8 Class Initialized
INFO - 2018-04-19 23:03:46 --> URI Class Initialized
INFO - 2018-04-19 23:03:46 --> Router Class Initialized
INFO - 2018-04-19 23:03:46 --> Output Class Initialized
INFO - 2018-04-19 23:03:46 --> Security Class Initialized
DEBUG - 2018-04-19 23:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:03:46 --> CSRF cookie sent
INFO - 2018-04-19 23:03:46 --> Input Class Initialized
INFO - 2018-04-19 23:03:46 --> Language Class Initialized
ERROR - 2018-04-19 23:03:47 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 23:03:54 --> Config Class Initialized
INFO - 2018-04-19 23:03:54 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:03:54 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:03:54 --> Utf8 Class Initialized
INFO - 2018-04-19 23:03:54 --> URI Class Initialized
INFO - 2018-04-19 23:03:54 --> Router Class Initialized
INFO - 2018-04-19 23:03:54 --> Output Class Initialized
INFO - 2018-04-19 23:03:54 --> Security Class Initialized
DEBUG - 2018-04-19 23:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:03:54 --> CSRF cookie sent
INFO - 2018-04-19 23:03:54 --> Input Class Initialized
INFO - 2018-04-19 23:03:54 --> Language Class Initialized
INFO - 2018-04-19 23:03:54 --> Loader Class Initialized
INFO - 2018-04-19 23:03:54 --> Helper loaded: url_helper
INFO - 2018-04-19 23:03:54 --> Helper loaded: form_helper
INFO - 2018-04-19 23:03:54 --> Helper loaded: language_helper
DEBUG - 2018-04-19 23:03:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 23:03:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 23:03:54 --> User Agent Class Initialized
INFO - 2018-04-19 23:03:54 --> Controller Class Initialized
INFO - 2018-04-19 23:03:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 23:03:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 23:03:54 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 23:03:54 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-19 23:03:54 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 23:03:54 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-19 23:03:55 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-19 23:03:55 --> File loaded: E:\www\yacopoo\application\views\register/import_fa.php
INFO - 2018-04-19 23:03:55 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 23:03:55 --> Final output sent to browser
DEBUG - 2018-04-19 23:03:55 --> Total execution time: 0.5278
INFO - 2018-04-19 23:03:55 --> Config Class Initialized
INFO - 2018-04-19 23:03:55 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:03:55 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:03:55 --> Utf8 Class Initialized
INFO - 2018-04-19 23:03:55 --> URI Class Initialized
INFO - 2018-04-19 23:03:55 --> Router Class Initialized
INFO - 2018-04-19 23:03:55 --> Output Class Initialized
INFO - 2018-04-19 23:03:55 --> Security Class Initialized
DEBUG - 2018-04-19 23:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:03:55 --> CSRF cookie sent
INFO - 2018-04-19 23:03:55 --> Input Class Initialized
INFO - 2018-04-19 23:03:55 --> Language Class Initialized
ERROR - 2018-04-19 23:03:55 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 23:04:09 --> Config Class Initialized
INFO - 2018-04-19 23:04:09 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:04:09 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:04:09 --> Utf8 Class Initialized
INFO - 2018-04-19 23:04:09 --> URI Class Initialized
DEBUG - 2018-04-19 23:04:09 --> No URI present. Default controller set.
INFO - 2018-04-19 23:04:09 --> Router Class Initialized
INFO - 2018-04-19 23:04:09 --> Output Class Initialized
INFO - 2018-04-19 23:04:09 --> Security Class Initialized
DEBUG - 2018-04-19 23:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:04:09 --> CSRF cookie sent
INFO - 2018-04-19 23:04:09 --> Input Class Initialized
INFO - 2018-04-19 23:04:09 --> Language Class Initialized
INFO - 2018-04-19 23:04:09 --> Loader Class Initialized
INFO - 2018-04-19 23:04:09 --> Helper loaded: url_helper
INFO - 2018-04-19 23:04:09 --> Helper loaded: form_helper
INFO - 2018-04-19 23:04:09 --> Helper loaded: language_helper
DEBUG - 2018-04-19 23:04:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 23:04:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 23:04:09 --> User Agent Class Initialized
INFO - 2018-04-19 23:04:09 --> Controller Class Initialized
INFO - 2018-04-19 23:04:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 23:04:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 23:04:09 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 23:04:09 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-19 23:04:09 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 23:04:09 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-19 23:04:09 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 23:04:09 --> Final output sent to browser
DEBUG - 2018-04-19 23:04:09 --> Total execution time: 0.4821
INFO - 2018-04-19 23:04:10 --> Config Class Initialized
INFO - 2018-04-19 23:04:10 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:04:10 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:04:10 --> Utf8 Class Initialized
INFO - 2018-04-19 23:04:10 --> URI Class Initialized
INFO - 2018-04-19 23:04:10 --> Router Class Initialized
INFO - 2018-04-19 23:04:10 --> Output Class Initialized
INFO - 2018-04-19 23:04:10 --> Security Class Initialized
DEBUG - 2018-04-19 23:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:04:10 --> CSRF cookie sent
INFO - 2018-04-19 23:04:10 --> Input Class Initialized
INFO - 2018-04-19 23:04:10 --> Language Class Initialized
ERROR - 2018-04-19 23:04:10 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 23:04:12 --> Config Class Initialized
INFO - 2018-04-19 23:04:12 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:04:12 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:04:12 --> Utf8 Class Initialized
INFO - 2018-04-19 23:04:12 --> URI Class Initialized
INFO - 2018-04-19 23:04:12 --> Router Class Initialized
INFO - 2018-04-19 23:04:12 --> Output Class Initialized
INFO - 2018-04-19 23:04:12 --> Security Class Initialized
DEBUG - 2018-04-19 23:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:04:12 --> CSRF cookie sent
INFO - 2018-04-19 23:04:12 --> Input Class Initialized
INFO - 2018-04-19 23:04:12 --> Language Class Initialized
ERROR - 2018-04-19 23:04:12 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-19 23:06:43 --> Config Class Initialized
INFO - 2018-04-19 23:06:43 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:06:43 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:06:43 --> Utf8 Class Initialized
INFO - 2018-04-19 23:06:43 --> URI Class Initialized
DEBUG - 2018-04-19 23:06:43 --> No URI present. Default controller set.
INFO - 2018-04-19 23:06:43 --> Router Class Initialized
INFO - 2018-04-19 23:06:43 --> Output Class Initialized
INFO - 2018-04-19 23:06:43 --> Security Class Initialized
DEBUG - 2018-04-19 23:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:06:43 --> CSRF cookie sent
INFO - 2018-04-19 23:06:43 --> Input Class Initialized
INFO - 2018-04-19 23:06:43 --> Language Class Initialized
INFO - 2018-04-19 23:06:43 --> Loader Class Initialized
INFO - 2018-04-19 23:06:44 --> Helper loaded: url_helper
INFO - 2018-04-19 23:06:44 --> Helper loaded: form_helper
INFO - 2018-04-19 23:06:44 --> Helper loaded: language_helper
DEBUG - 2018-04-19 23:06:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 23:06:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 23:06:44 --> User Agent Class Initialized
INFO - 2018-04-19 23:06:44 --> Controller Class Initialized
INFO - 2018-04-19 23:06:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 23:06:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 23:06:44 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 23:06:44 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-19 23:06:44 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 23:06:44 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-19 23:06:44 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 23:06:44 --> Final output sent to browser
DEBUG - 2018-04-19 23:06:44 --> Total execution time: 0.5238
INFO - 2018-04-19 23:06:44 --> Config Class Initialized
INFO - 2018-04-19 23:06:44 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:06:44 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:06:44 --> Utf8 Class Initialized
INFO - 2018-04-19 23:06:44 --> URI Class Initialized
INFO - 2018-04-19 23:06:44 --> Router Class Initialized
INFO - 2018-04-19 23:06:44 --> Output Class Initialized
INFO - 2018-04-19 23:06:44 --> Security Class Initialized
DEBUG - 2018-04-19 23:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:06:44 --> CSRF cookie sent
INFO - 2018-04-19 23:06:44 --> Input Class Initialized
INFO - 2018-04-19 23:06:44 --> Language Class Initialized
ERROR - 2018-04-19 23:06:44 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 23:06:46 --> Config Class Initialized
INFO - 2018-04-19 23:06:46 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:06:46 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:06:46 --> Utf8 Class Initialized
INFO - 2018-04-19 23:06:46 --> URI Class Initialized
INFO - 2018-04-19 23:06:46 --> Router Class Initialized
INFO - 2018-04-19 23:06:46 --> Output Class Initialized
INFO - 2018-04-19 23:06:46 --> Security Class Initialized
DEBUG - 2018-04-19 23:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:06:46 --> CSRF cookie sent
INFO - 2018-04-19 23:06:46 --> Input Class Initialized
INFO - 2018-04-19 23:06:46 --> Language Class Initialized
ERROR - 2018-04-19 23:06:46 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-19 23:07:25 --> Config Class Initialized
INFO - 2018-04-19 23:07:25 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:07:25 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:07:25 --> Utf8 Class Initialized
INFO - 2018-04-19 23:07:25 --> URI Class Initialized
DEBUG - 2018-04-19 23:07:25 --> No URI present. Default controller set.
INFO - 2018-04-19 23:07:25 --> Router Class Initialized
INFO - 2018-04-19 23:07:25 --> Output Class Initialized
INFO - 2018-04-19 23:07:25 --> Security Class Initialized
DEBUG - 2018-04-19 23:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:07:25 --> CSRF cookie sent
INFO - 2018-04-19 23:07:25 --> Input Class Initialized
INFO - 2018-04-19 23:07:25 --> Language Class Initialized
INFO - 2018-04-19 23:07:25 --> Loader Class Initialized
INFO - 2018-04-19 23:07:25 --> Helper loaded: url_helper
INFO - 2018-04-19 23:07:25 --> Helper loaded: form_helper
INFO - 2018-04-19 23:07:25 --> Helper loaded: language_helper
DEBUG - 2018-04-19 23:07:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 23:07:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 23:07:25 --> User Agent Class Initialized
INFO - 2018-04-19 23:07:25 --> Controller Class Initialized
INFO - 2018-04-19 23:07:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 23:07:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 23:07:25 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 23:07:25 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-19 23:07:25 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 23:07:25 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-19 23:07:25 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 23:07:25 --> Final output sent to browser
DEBUG - 2018-04-19 23:07:25 --> Total execution time: 0.5793
INFO - 2018-04-19 23:07:26 --> Config Class Initialized
INFO - 2018-04-19 23:07:26 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:07:26 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:07:26 --> Utf8 Class Initialized
INFO - 2018-04-19 23:07:26 --> URI Class Initialized
INFO - 2018-04-19 23:07:26 --> Router Class Initialized
INFO - 2018-04-19 23:07:26 --> Output Class Initialized
INFO - 2018-04-19 23:07:26 --> Security Class Initialized
DEBUG - 2018-04-19 23:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:07:26 --> CSRF cookie sent
INFO - 2018-04-19 23:07:26 --> Input Class Initialized
INFO - 2018-04-19 23:07:26 --> Language Class Initialized
ERROR - 2018-04-19 23:07:26 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 23:07:28 --> Config Class Initialized
INFO - 2018-04-19 23:07:28 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:07:28 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:07:28 --> Utf8 Class Initialized
INFO - 2018-04-19 23:07:28 --> URI Class Initialized
INFO - 2018-04-19 23:07:28 --> Router Class Initialized
INFO - 2018-04-19 23:07:28 --> Output Class Initialized
INFO - 2018-04-19 23:07:28 --> Security Class Initialized
DEBUG - 2018-04-19 23:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:07:28 --> CSRF cookie sent
INFO - 2018-04-19 23:07:28 --> Input Class Initialized
INFO - 2018-04-19 23:07:28 --> Language Class Initialized
ERROR - 2018-04-19 23:07:28 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-19 23:08:10 --> Config Class Initialized
INFO - 2018-04-19 23:08:10 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:08:10 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:08:10 --> Utf8 Class Initialized
INFO - 2018-04-19 23:08:11 --> URI Class Initialized
DEBUG - 2018-04-19 23:08:11 --> No URI present. Default controller set.
INFO - 2018-04-19 23:08:11 --> Router Class Initialized
INFO - 2018-04-19 23:08:11 --> Output Class Initialized
INFO - 2018-04-19 23:08:11 --> Security Class Initialized
DEBUG - 2018-04-19 23:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:08:11 --> CSRF cookie sent
INFO - 2018-04-19 23:08:11 --> Input Class Initialized
INFO - 2018-04-19 23:08:11 --> Language Class Initialized
INFO - 2018-04-19 23:08:11 --> Loader Class Initialized
INFO - 2018-04-19 23:08:11 --> Helper loaded: url_helper
INFO - 2018-04-19 23:08:11 --> Helper loaded: form_helper
INFO - 2018-04-19 23:08:11 --> Helper loaded: language_helper
DEBUG - 2018-04-19 23:08:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 23:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 23:08:11 --> User Agent Class Initialized
INFO - 2018-04-19 23:08:11 --> Controller Class Initialized
INFO - 2018-04-19 23:08:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 23:08:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 23:08:11 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 23:08:11 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-19 23:08:11 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 23:08:11 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-19 23:08:11 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 23:08:11 --> Final output sent to browser
DEBUG - 2018-04-19 23:08:11 --> Total execution time: 0.5749
INFO - 2018-04-19 23:08:11 --> Config Class Initialized
INFO - 2018-04-19 23:08:11 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:08:11 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:08:12 --> Utf8 Class Initialized
INFO - 2018-04-19 23:08:12 --> URI Class Initialized
INFO - 2018-04-19 23:08:12 --> Router Class Initialized
INFO - 2018-04-19 23:08:12 --> Output Class Initialized
INFO - 2018-04-19 23:08:12 --> Security Class Initialized
DEBUG - 2018-04-19 23:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:08:12 --> CSRF cookie sent
INFO - 2018-04-19 23:08:12 --> Input Class Initialized
INFO - 2018-04-19 23:08:12 --> Language Class Initialized
ERROR - 2018-04-19 23:08:12 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 23:08:13 --> Config Class Initialized
INFO - 2018-04-19 23:08:13 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:08:13 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:08:13 --> Utf8 Class Initialized
INFO - 2018-04-19 23:08:13 --> URI Class Initialized
INFO - 2018-04-19 23:08:13 --> Router Class Initialized
INFO - 2018-04-19 23:08:13 --> Output Class Initialized
INFO - 2018-04-19 23:08:14 --> Security Class Initialized
DEBUG - 2018-04-19 23:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:08:14 --> CSRF cookie sent
INFO - 2018-04-19 23:08:14 --> Input Class Initialized
INFO - 2018-04-19 23:08:14 --> Language Class Initialized
ERROR - 2018-04-19 23:08:14 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-19 23:08:29 --> Config Class Initialized
INFO - 2018-04-19 23:08:30 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:08:30 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:08:30 --> Utf8 Class Initialized
INFO - 2018-04-19 23:08:30 --> URI Class Initialized
DEBUG - 2018-04-19 23:08:30 --> No URI present. Default controller set.
INFO - 2018-04-19 23:08:30 --> Router Class Initialized
INFO - 2018-04-19 23:08:30 --> Output Class Initialized
INFO - 2018-04-19 23:08:30 --> Security Class Initialized
DEBUG - 2018-04-19 23:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:08:30 --> CSRF cookie sent
INFO - 2018-04-19 23:08:30 --> Input Class Initialized
INFO - 2018-04-19 23:08:30 --> Language Class Initialized
INFO - 2018-04-19 23:08:30 --> Loader Class Initialized
INFO - 2018-04-19 23:08:30 --> Helper loaded: url_helper
INFO - 2018-04-19 23:08:30 --> Helper loaded: form_helper
INFO - 2018-04-19 23:08:30 --> Helper loaded: language_helper
DEBUG - 2018-04-19 23:08:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 23:08:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 23:08:30 --> User Agent Class Initialized
INFO - 2018-04-19 23:08:30 --> Controller Class Initialized
INFO - 2018-04-19 23:08:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 23:08:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 23:08:30 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 23:08:30 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-19 23:08:30 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 23:08:30 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-19 23:08:30 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 23:08:30 --> Final output sent to browser
DEBUG - 2018-04-19 23:08:30 --> Total execution time: 0.5799
INFO - 2018-04-19 23:08:30 --> Config Class Initialized
INFO - 2018-04-19 23:08:30 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:08:30 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:08:30 --> Utf8 Class Initialized
INFO - 2018-04-19 23:08:31 --> URI Class Initialized
INFO - 2018-04-19 23:08:31 --> Router Class Initialized
INFO - 2018-04-19 23:08:31 --> Output Class Initialized
INFO - 2018-04-19 23:08:31 --> Security Class Initialized
DEBUG - 2018-04-19 23:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:08:31 --> CSRF cookie sent
INFO - 2018-04-19 23:08:31 --> Input Class Initialized
INFO - 2018-04-19 23:08:31 --> Language Class Initialized
ERROR - 2018-04-19 23:08:31 --> 404 Page Not Found: Assets/css
INFO - 2018-04-19 23:08:33 --> Config Class Initialized
INFO - 2018-04-19 23:08:33 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:08:33 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:08:33 --> Utf8 Class Initialized
INFO - 2018-04-19 23:08:33 --> URI Class Initialized
INFO - 2018-04-19 23:08:33 --> Router Class Initialized
INFO - 2018-04-19 23:08:33 --> Output Class Initialized
INFO - 2018-04-19 23:08:33 --> Security Class Initialized
DEBUG - 2018-04-19 23:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:08:33 --> CSRF cookie sent
INFO - 2018-04-19 23:08:33 --> Input Class Initialized
INFO - 2018-04-19 23:08:33 --> Language Class Initialized
ERROR - 2018-04-19 23:08:33 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-19 23:08:42 --> Config Class Initialized
INFO - 2018-04-19 23:08:42 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:08:42 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:08:42 --> Utf8 Class Initialized
INFO - 2018-04-19 23:08:42 --> URI Class Initialized
DEBUG - 2018-04-19 23:08:42 --> No URI present. Default controller set.
INFO - 2018-04-19 23:08:42 --> Router Class Initialized
INFO - 2018-04-19 23:08:42 --> Output Class Initialized
INFO - 2018-04-19 23:08:42 --> Security Class Initialized
DEBUG - 2018-04-19 23:08:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:08:42 --> CSRF cookie sent
INFO - 2018-04-19 23:08:42 --> Input Class Initialized
INFO - 2018-04-19 23:08:42 --> Language Class Initialized
INFO - 2018-04-19 23:08:42 --> Loader Class Initialized
INFO - 2018-04-19 23:08:42 --> Helper loaded: url_helper
INFO - 2018-04-19 23:08:42 --> Helper loaded: form_helper
INFO - 2018-04-19 23:08:42 --> Helper loaded: language_helper
DEBUG - 2018-04-19 23:08:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 23:08:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 23:08:42 --> User Agent Class Initialized
INFO - 2018-04-19 23:08:42 --> Controller Class Initialized
INFO - 2018-04-19 23:08:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 23:08:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 23:08:42 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 23:08:42 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-19 23:08:42 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 23:08:42 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-19 23:08:42 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 23:08:42 --> Final output sent to browser
DEBUG - 2018-04-19 23:08:42 --> Total execution time: 0.5141
INFO - 2018-04-19 23:08:44 --> Config Class Initialized
INFO - 2018-04-19 23:08:44 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:08:44 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:08:44 --> Utf8 Class Initialized
INFO - 2018-04-19 23:08:44 --> URI Class Initialized
INFO - 2018-04-19 23:08:44 --> Router Class Initialized
INFO - 2018-04-19 23:08:44 --> Output Class Initialized
INFO - 2018-04-19 23:08:44 --> Security Class Initialized
DEBUG - 2018-04-19 23:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:08:44 --> CSRF cookie sent
INFO - 2018-04-19 23:08:44 --> Input Class Initialized
INFO - 2018-04-19 23:08:44 --> Language Class Initialized
ERROR - 2018-04-19 23:08:44 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-19 23:09:04 --> Config Class Initialized
INFO - 2018-04-19 23:09:04 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:09:04 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:09:04 --> Utf8 Class Initialized
INFO - 2018-04-19 23:09:04 --> URI Class Initialized
DEBUG - 2018-04-19 23:09:04 --> No URI present. Default controller set.
INFO - 2018-04-19 23:09:04 --> Router Class Initialized
INFO - 2018-04-19 23:09:04 --> Output Class Initialized
INFO - 2018-04-19 23:09:04 --> Security Class Initialized
DEBUG - 2018-04-19 23:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:09:04 --> CSRF cookie sent
INFO - 2018-04-19 23:09:04 --> Input Class Initialized
INFO - 2018-04-19 23:09:04 --> Language Class Initialized
INFO - 2018-04-19 23:09:04 --> Loader Class Initialized
INFO - 2018-04-19 23:09:04 --> Helper loaded: url_helper
INFO - 2018-04-19 23:09:04 --> Helper loaded: form_helper
INFO - 2018-04-19 23:09:04 --> Helper loaded: language_helper
DEBUG - 2018-04-19 23:09:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 23:09:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 23:09:04 --> User Agent Class Initialized
INFO - 2018-04-19 23:09:04 --> Controller Class Initialized
INFO - 2018-04-19 23:09:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 23:09:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 23:09:04 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 23:09:04 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-19 23:09:04 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 23:09:04 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-19 23:09:04 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 23:09:04 --> Final output sent to browser
DEBUG - 2018-04-19 23:09:04 --> Total execution time: 0.5342
INFO - 2018-04-19 23:09:06 --> Config Class Initialized
INFO - 2018-04-19 23:09:06 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:09:06 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:09:06 --> Utf8 Class Initialized
INFO - 2018-04-19 23:09:06 --> URI Class Initialized
INFO - 2018-04-19 23:09:06 --> Router Class Initialized
INFO - 2018-04-19 23:09:06 --> Output Class Initialized
INFO - 2018-04-19 23:09:06 --> Security Class Initialized
DEBUG - 2018-04-19 23:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:09:06 --> CSRF cookie sent
INFO - 2018-04-19 23:09:06 --> Input Class Initialized
INFO - 2018-04-19 23:09:06 --> Language Class Initialized
ERROR - 2018-04-19 23:09:06 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-19 23:09:23 --> Config Class Initialized
INFO - 2018-04-19 23:09:23 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:09:23 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:09:23 --> Utf8 Class Initialized
INFO - 2018-04-19 23:09:23 --> URI Class Initialized
DEBUG - 2018-04-19 23:09:23 --> No URI present. Default controller set.
INFO - 2018-04-19 23:09:23 --> Router Class Initialized
INFO - 2018-04-19 23:09:23 --> Output Class Initialized
INFO - 2018-04-19 23:09:23 --> Security Class Initialized
DEBUG - 2018-04-19 23:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:09:23 --> CSRF cookie sent
INFO - 2018-04-19 23:09:23 --> Input Class Initialized
INFO - 2018-04-19 23:09:23 --> Language Class Initialized
INFO - 2018-04-19 23:09:23 --> Loader Class Initialized
INFO - 2018-04-19 23:09:23 --> Helper loaded: url_helper
INFO - 2018-04-19 23:09:23 --> Helper loaded: form_helper
INFO - 2018-04-19 23:09:23 --> Helper loaded: language_helper
DEBUG - 2018-04-19 23:09:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 23:09:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 23:09:23 --> User Agent Class Initialized
INFO - 2018-04-19 23:09:23 --> Controller Class Initialized
INFO - 2018-04-19 23:09:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 23:09:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 23:09:23 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 23:09:23 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-19 23:09:23 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 23:09:24 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-19 23:09:24 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 23:09:24 --> Final output sent to browser
DEBUG - 2018-04-19 23:09:24 --> Total execution time: 0.5149
INFO - 2018-04-19 23:09:25 --> Config Class Initialized
INFO - 2018-04-19 23:09:25 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:09:25 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:09:25 --> Utf8 Class Initialized
INFO - 2018-04-19 23:09:25 --> URI Class Initialized
INFO - 2018-04-19 23:09:25 --> Router Class Initialized
INFO - 2018-04-19 23:09:25 --> Output Class Initialized
INFO - 2018-04-19 23:09:25 --> Security Class Initialized
DEBUG - 2018-04-19 23:09:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:09:25 --> CSRF cookie sent
INFO - 2018-04-19 23:09:25 --> Input Class Initialized
INFO - 2018-04-19 23:09:25 --> Language Class Initialized
ERROR - 2018-04-19 23:09:25 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-19 23:13:49 --> Config Class Initialized
INFO - 2018-04-19 23:13:49 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:13:49 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:13:49 --> Utf8 Class Initialized
INFO - 2018-04-19 23:13:49 --> URI Class Initialized
INFO - 2018-04-19 23:13:49 --> Router Class Initialized
INFO - 2018-04-19 23:13:49 --> Output Class Initialized
INFO - 2018-04-19 23:13:49 --> Security Class Initialized
DEBUG - 2018-04-19 23:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:13:50 --> CSRF cookie sent
INFO - 2018-04-19 23:13:50 --> Input Class Initialized
INFO - 2018-04-19 23:13:50 --> Language Class Initialized
INFO - 2018-04-19 23:13:50 --> Loader Class Initialized
INFO - 2018-04-19 23:13:50 --> Helper loaded: url_helper
INFO - 2018-04-19 23:13:50 --> Helper loaded: form_helper
INFO - 2018-04-19 23:13:50 --> Helper loaded: language_helper
DEBUG - 2018-04-19 23:13:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 23:13:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 23:13:50 --> User Agent Class Initialized
INFO - 2018-04-19 23:13:50 --> Controller Class Initialized
INFO - 2018-04-19 23:13:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 23:13:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 23:13:50 --> CSRF cookie sent
INFO - 2018-04-19 23:13:50 --> Config Class Initialized
INFO - 2018-04-19 23:13:50 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:13:50 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:13:50 --> Utf8 Class Initialized
INFO - 2018-04-19 23:13:50 --> URI Class Initialized
DEBUG - 2018-04-19 23:13:50 --> No URI present. Default controller set.
INFO - 2018-04-19 23:13:50 --> Router Class Initialized
INFO - 2018-04-19 23:13:50 --> Output Class Initialized
INFO - 2018-04-19 23:13:50 --> Security Class Initialized
DEBUG - 2018-04-19 23:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:13:50 --> CSRF cookie sent
INFO - 2018-04-19 23:13:50 --> Input Class Initialized
INFO - 2018-04-19 23:13:50 --> Language Class Initialized
INFO - 2018-04-19 23:13:50 --> Loader Class Initialized
INFO - 2018-04-19 23:13:50 --> Helper loaded: url_helper
INFO - 2018-04-19 23:13:50 --> Helper loaded: form_helper
INFO - 2018-04-19 23:13:50 --> Helper loaded: language_helper
DEBUG - 2018-04-19 23:13:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 23:13:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 23:13:50 --> User Agent Class Initialized
INFO - 2018-04-19 23:13:50 --> Controller Class Initialized
INFO - 2018-04-19 23:13:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 23:13:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 23:13:50 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 23:13:50 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 23:13:50 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-19 23:13:50 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 23:13:50 --> Final output sent to browser
DEBUG - 2018-04-19 23:13:50 --> Total execution time: 0.4954
INFO - 2018-04-19 23:13:52 --> Config Class Initialized
INFO - 2018-04-19 23:13:52 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:13:52 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:13:52 --> Utf8 Class Initialized
INFO - 2018-04-19 23:13:52 --> URI Class Initialized
INFO - 2018-04-19 23:13:52 --> Router Class Initialized
INFO - 2018-04-19 23:13:52 --> Output Class Initialized
INFO - 2018-04-19 23:13:52 --> Security Class Initialized
DEBUG - 2018-04-19 23:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:13:52 --> CSRF cookie sent
INFO - 2018-04-19 23:13:52 --> Input Class Initialized
INFO - 2018-04-19 23:13:52 --> Language Class Initialized
ERROR - 2018-04-19 23:13:52 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-19 23:28:23 --> Config Class Initialized
INFO - 2018-04-19 23:28:23 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:28:23 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:28:23 --> Utf8 Class Initialized
INFO - 2018-04-19 23:28:23 --> URI Class Initialized
INFO - 2018-04-19 23:28:23 --> Router Class Initialized
INFO - 2018-04-19 23:28:23 --> Output Class Initialized
INFO - 2018-04-19 23:28:23 --> Security Class Initialized
DEBUG - 2018-04-19 23:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:28:23 --> CSRF cookie sent
INFO - 2018-04-19 23:28:23 --> Input Class Initialized
INFO - 2018-04-19 23:28:23 --> Language Class Initialized
INFO - 2018-04-19 23:28:23 --> Loader Class Initialized
INFO - 2018-04-19 23:28:23 --> Helper loaded: url_helper
INFO - 2018-04-19 23:28:23 --> Helper loaded: form_helper
INFO - 2018-04-19 23:28:23 --> Helper loaded: language_helper
DEBUG - 2018-04-19 23:28:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 23:28:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 23:28:23 --> User Agent Class Initialized
INFO - 2018-04-19 23:28:23 --> Controller Class Initialized
INFO - 2018-04-19 23:28:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 23:28:24 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-19 23:28:24 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-19 23:28:24 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 23:28:24 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 23:28:24 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-19 23:28:24 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-19 23:28:24 --> Could not find the language line "req_email"
INFO - 2018-04-19 23:28:24 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-04-19 23:28:24 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 23:28:24 --> Final output sent to browser
DEBUG - 2018-04-19 23:28:24 --> Total execution time: 0.5405
INFO - 2018-04-19 23:28:24 --> Config Class Initialized
INFO - 2018-04-19 23:28:24 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:28:24 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:28:24 --> Utf8 Class Initialized
INFO - 2018-04-19 23:28:24 --> URI Class Initialized
INFO - 2018-04-19 23:28:24 --> Router Class Initialized
INFO - 2018-04-19 23:28:24 --> Output Class Initialized
INFO - 2018-04-19 23:28:24 --> Security Class Initialized
DEBUG - 2018-04-19 23:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:28:24 --> CSRF cookie sent
INFO - 2018-04-19 23:28:24 --> Input Class Initialized
INFO - 2018-04-19 23:28:24 --> Language Class Initialized
ERROR - 2018-04-19 23:28:24 --> 404 Page Not Found: Assets/images
INFO - 2018-04-19 23:28:35 --> Config Class Initialized
INFO - 2018-04-19 23:28:35 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:28:35 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:28:35 --> Utf8 Class Initialized
INFO - 2018-04-19 23:28:35 --> URI Class Initialized
INFO - 2018-04-19 23:28:35 --> Router Class Initialized
INFO - 2018-04-19 23:28:35 --> Output Class Initialized
INFO - 2018-04-19 23:28:35 --> Security Class Initialized
DEBUG - 2018-04-19 23:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:28:35 --> CSRF cookie sent
INFO - 2018-04-19 23:28:35 --> CSRF token verified
INFO - 2018-04-19 23:28:35 --> Input Class Initialized
INFO - 2018-04-19 23:28:35 --> Language Class Initialized
INFO - 2018-04-19 23:28:35 --> Loader Class Initialized
INFO - 2018-04-19 23:28:35 --> Helper loaded: url_helper
INFO - 2018-04-19 23:28:35 --> Helper loaded: form_helper
INFO - 2018-04-19 23:28:35 --> Helper loaded: language_helper
DEBUG - 2018-04-19 23:28:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 23:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 23:28:35 --> User Agent Class Initialized
INFO - 2018-04-19 23:28:35 --> Controller Class Initialized
INFO - 2018-04-19 23:28:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 23:28:35 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-19 23:28:35 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-19 23:28:35 --> Form Validation Class Initialized
INFO - 2018-04-19 23:28:35 --> Pixel_Model class loaded
INFO - 2018-04-19 23:28:35 --> Database Driver Class Initialized
INFO - 2018-04-19 23:28:35 --> Model "AuthenticationModel" initialized
INFO - 2018-04-19 23:28:36 --> Config Class Initialized
INFO - 2018-04-19 23:28:36 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:28:36 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:28:36 --> Utf8 Class Initialized
INFO - 2018-04-19 23:28:36 --> URI Class Initialized
DEBUG - 2018-04-19 23:28:36 --> No URI present. Default controller set.
INFO - 2018-04-19 23:28:36 --> Router Class Initialized
INFO - 2018-04-19 23:28:36 --> Output Class Initialized
INFO - 2018-04-19 23:28:36 --> Security Class Initialized
DEBUG - 2018-04-19 23:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:28:36 --> CSRF cookie sent
INFO - 2018-04-19 23:28:36 --> Input Class Initialized
INFO - 2018-04-19 23:28:36 --> Language Class Initialized
INFO - 2018-04-19 23:28:36 --> Loader Class Initialized
INFO - 2018-04-19 23:28:36 --> Helper loaded: url_helper
INFO - 2018-04-19 23:28:36 --> Helper loaded: form_helper
INFO - 2018-04-19 23:28:36 --> Helper loaded: language_helper
DEBUG - 2018-04-19 23:28:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 23:28:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 23:28:36 --> User Agent Class Initialized
INFO - 2018-04-19 23:28:36 --> Controller Class Initialized
INFO - 2018-04-19 23:28:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 23:28:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 23:28:36 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 23:28:36 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-19 23:28:36 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 23:28:36 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-19 23:28:36 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 23:28:36 --> Final output sent to browser
DEBUG - 2018-04-19 23:28:36 --> Total execution time: 0.7402
INFO - 2018-04-19 23:28:38 --> Config Class Initialized
INFO - 2018-04-19 23:28:38 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:28:38 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:28:38 --> Utf8 Class Initialized
INFO - 2018-04-19 23:28:38 --> URI Class Initialized
INFO - 2018-04-19 23:28:38 --> Router Class Initialized
INFO - 2018-04-19 23:28:38 --> Output Class Initialized
INFO - 2018-04-19 23:28:38 --> Security Class Initialized
DEBUG - 2018-04-19 23:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:28:38 --> CSRF cookie sent
INFO - 2018-04-19 23:28:38 --> Input Class Initialized
INFO - 2018-04-19 23:28:38 --> Language Class Initialized
ERROR - 2018-04-19 23:28:38 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-19 23:28:41 --> Config Class Initialized
INFO - 2018-04-19 23:28:41 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:28:41 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:28:41 --> Utf8 Class Initialized
INFO - 2018-04-19 23:28:41 --> URI Class Initialized
INFO - 2018-04-19 23:28:41 --> Router Class Initialized
INFO - 2018-04-19 23:28:41 --> Output Class Initialized
INFO - 2018-04-19 23:28:41 --> Security Class Initialized
DEBUG - 2018-04-19 23:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:28:41 --> CSRF cookie sent
INFO - 2018-04-19 23:28:41 --> Input Class Initialized
INFO - 2018-04-19 23:28:41 --> Language Class Initialized
INFO - 2018-04-19 23:28:41 --> Loader Class Initialized
INFO - 2018-04-19 23:28:41 --> Helper loaded: url_helper
INFO - 2018-04-19 23:28:41 --> Helper loaded: form_helper
INFO - 2018-04-19 23:28:41 --> Helper loaded: language_helper
DEBUG - 2018-04-19 23:28:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 23:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 23:28:41 --> User Agent Class Initialized
INFO - 2018-04-19 23:28:41 --> Controller Class Initialized
INFO - 2018-04-19 23:28:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 23:28:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 23:28:41 --> Pixel_Model class loaded
INFO - 2018-04-19 23:28:41 --> Database Driver Class Initialized
INFO - 2018-04-19 23:28:41 --> Model "MyAccountModel" initialized
INFO - 2018-04-19 23:28:41 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 23:28:41 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-19 23:28:41 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 23:28:41 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-19 23:28:41 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-19 23:28:41 --> Severity: Notice --> Undefined variable: links E:\www\yacopoo\application\views\myaccount\application_list.php 57
INFO - 2018-04-19 23:28:41 --> File loaded: E:\www\yacopoo\application\views\myaccount/application_list.php
INFO - 2018-04-19 23:28:41 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 23:28:41 --> Final output sent to browser
DEBUG - 2018-04-19 23:28:41 --> Total execution time: 0.6495
INFO - 2018-04-19 23:30:00 --> Config Class Initialized
INFO - 2018-04-19 23:30:00 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:30:00 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:30:00 --> Utf8 Class Initialized
INFO - 2018-04-19 23:30:00 --> URI Class Initialized
INFO - 2018-04-19 23:30:00 --> Router Class Initialized
INFO - 2018-04-19 23:30:00 --> Output Class Initialized
INFO - 2018-04-19 23:30:00 --> Security Class Initialized
DEBUG - 2018-04-19 23:30:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:30:00 --> CSRF cookie sent
INFO - 2018-04-19 23:30:00 --> Input Class Initialized
INFO - 2018-04-19 23:30:00 --> Language Class Initialized
INFO - 2018-04-19 23:30:00 --> Loader Class Initialized
INFO - 2018-04-19 23:30:00 --> Helper loaded: url_helper
INFO - 2018-04-19 23:30:00 --> Helper loaded: form_helper
INFO - 2018-04-19 23:30:00 --> Helper loaded: language_helper
DEBUG - 2018-04-19 23:30:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 23:30:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 23:30:00 --> User Agent Class Initialized
INFO - 2018-04-19 23:30:00 --> Controller Class Initialized
INFO - 2018-04-19 23:30:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 23:30:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 23:30:00 --> Pixel_Model class loaded
INFO - 2018-04-19 23:30:00 --> Database Driver Class Initialized
INFO - 2018-04-19 23:30:00 --> Model "MyAccountModel" initialized
INFO - 2018-04-19 23:30:01 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 23:30:01 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-19 23:30:01 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 23:30:01 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-19 23:30:01 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-19 23:30:01 --> Severity: Notice --> Undefined variable: links E:\www\yacopoo\application\views\myaccount\application_list.php 57
INFO - 2018-04-19 23:30:01 --> File loaded: E:\www\yacopoo\application\views\myaccount/application_list.php
INFO - 2018-04-19 23:30:01 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 23:30:01 --> Final output sent to browser
DEBUG - 2018-04-19 23:30:01 --> Total execution time: 0.5987
INFO - 2018-04-19 23:31:04 --> Config Class Initialized
INFO - 2018-04-19 23:31:04 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:31:04 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:31:04 --> Utf8 Class Initialized
INFO - 2018-04-19 23:31:04 --> URI Class Initialized
INFO - 2018-04-19 23:31:05 --> Router Class Initialized
INFO - 2018-04-19 23:31:05 --> Output Class Initialized
INFO - 2018-04-19 23:31:05 --> Security Class Initialized
DEBUG - 2018-04-19 23:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:31:05 --> CSRF cookie sent
INFO - 2018-04-19 23:31:05 --> Input Class Initialized
INFO - 2018-04-19 23:31:05 --> Language Class Initialized
INFO - 2018-04-19 23:31:05 --> Loader Class Initialized
INFO - 2018-04-19 23:31:05 --> Helper loaded: url_helper
INFO - 2018-04-19 23:31:05 --> Helper loaded: form_helper
INFO - 2018-04-19 23:31:05 --> Helper loaded: language_helper
DEBUG - 2018-04-19 23:31:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 23:31:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 23:31:05 --> User Agent Class Initialized
INFO - 2018-04-19 23:31:05 --> Controller Class Initialized
INFO - 2018-04-19 23:31:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 23:31:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 23:31:05 --> Pixel_Model class loaded
INFO - 2018-04-19 23:31:05 --> Database Driver Class Initialized
INFO - 2018-04-19 23:31:05 --> Model "MyAccountModel" initialized
INFO - 2018-04-19 23:31:05 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 23:31:05 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-19 23:31:05 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 23:31:05 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-19 23:31:05 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-19 23:31:05 --> File loaded: E:\www\yacopoo\application\views\myaccount/application_list.php
INFO - 2018-04-19 23:31:05 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 23:31:05 --> Final output sent to browser
DEBUG - 2018-04-19 23:31:05 --> Total execution time: 0.5812
INFO - 2018-04-19 23:36:16 --> Config Class Initialized
INFO - 2018-04-19 23:36:16 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:36:16 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:36:16 --> Utf8 Class Initialized
INFO - 2018-04-19 23:36:16 --> URI Class Initialized
DEBUG - 2018-04-19 23:36:16 --> No URI present. Default controller set.
INFO - 2018-04-19 23:36:16 --> Router Class Initialized
INFO - 2018-04-19 23:36:16 --> Output Class Initialized
INFO - 2018-04-19 23:36:16 --> Security Class Initialized
DEBUG - 2018-04-19 23:36:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:36:16 --> CSRF cookie sent
INFO - 2018-04-19 23:36:16 --> Input Class Initialized
INFO - 2018-04-19 23:36:16 --> Language Class Initialized
INFO - 2018-04-19 23:36:16 --> Loader Class Initialized
INFO - 2018-04-19 23:36:16 --> Helper loaded: url_helper
INFO - 2018-04-19 23:36:16 --> Helper loaded: form_helper
INFO - 2018-04-19 23:36:16 --> Helper loaded: language_helper
DEBUG - 2018-04-19 23:36:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 23:36:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 23:36:16 --> User Agent Class Initialized
INFO - 2018-04-19 23:36:16 --> Controller Class Initialized
INFO - 2018-04-19 23:36:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 23:36:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 23:36:16 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 23:36:16 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-19 23:36:16 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 23:36:16 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-19 23:36:16 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 23:36:16 --> Final output sent to browser
DEBUG - 2018-04-19 23:36:16 --> Total execution time: 0.5281
INFO - 2018-04-19 23:36:18 --> Config Class Initialized
INFO - 2018-04-19 23:36:18 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:36:18 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:36:18 --> Utf8 Class Initialized
INFO - 2018-04-19 23:36:18 --> URI Class Initialized
INFO - 2018-04-19 23:36:18 --> Router Class Initialized
INFO - 2018-04-19 23:36:18 --> Output Class Initialized
INFO - 2018-04-19 23:36:18 --> Security Class Initialized
DEBUG - 2018-04-19 23:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:36:18 --> CSRF cookie sent
INFO - 2018-04-19 23:36:18 --> Input Class Initialized
INFO - 2018-04-19 23:36:18 --> Language Class Initialized
ERROR - 2018-04-19 23:36:18 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-19 23:45:50 --> Config Class Initialized
INFO - 2018-04-19 23:45:50 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:45:50 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:45:50 --> Utf8 Class Initialized
INFO - 2018-04-19 23:45:50 --> URI Class Initialized
INFO - 2018-04-19 23:45:50 --> Router Class Initialized
INFO - 2018-04-19 23:45:50 --> Output Class Initialized
INFO - 2018-04-19 23:45:50 --> Security Class Initialized
DEBUG - 2018-04-19 23:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:45:50 --> CSRF cookie sent
INFO - 2018-04-19 23:45:50 --> Input Class Initialized
INFO - 2018-04-19 23:45:50 --> Language Class Initialized
ERROR - 2018-04-19 23:45:50 --> 404 Page Not Found: PayerReciepientController/restartApplication
INFO - 2018-04-19 23:46:10 --> Config Class Initialized
INFO - 2018-04-19 23:46:10 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:46:10 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:46:10 --> Utf8 Class Initialized
INFO - 2018-04-19 23:46:10 --> URI Class Initialized
INFO - 2018-04-19 23:46:10 --> Router Class Initialized
INFO - 2018-04-19 23:46:10 --> Output Class Initialized
INFO - 2018-04-19 23:46:10 --> Security Class Initialized
DEBUG - 2018-04-19 23:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:46:10 --> CSRF cookie sent
INFO - 2018-04-19 23:46:10 --> Input Class Initialized
INFO - 2018-04-19 23:46:10 --> Language Class Initialized
ERROR - 2018-04-19 23:46:10 --> 404 Page Not Found: PayerReciepientController/restartApplication
INFO - 2018-04-19 23:46:25 --> Config Class Initialized
INFO - 2018-04-19 23:46:25 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:46:25 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:46:25 --> Utf8 Class Initialized
INFO - 2018-04-19 23:46:25 --> URI Class Initialized
INFO - 2018-04-19 23:46:25 --> Router Class Initialized
INFO - 2018-04-19 23:46:25 --> Output Class Initialized
INFO - 2018-04-19 23:46:25 --> Security Class Initialized
DEBUG - 2018-04-19 23:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:46:25 --> CSRF cookie sent
INFO - 2018-04-19 23:46:25 --> Input Class Initialized
INFO - 2018-04-19 23:46:25 --> Language Class Initialized
ERROR - 2018-04-19 23:46:25 --> 404 Page Not Found: PayerReciepientController/restartApplication
INFO - 2018-04-19 23:46:34 --> Config Class Initialized
INFO - 2018-04-19 23:46:34 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:46:34 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:46:34 --> Utf8 Class Initialized
INFO - 2018-04-19 23:46:34 --> URI Class Initialized
INFO - 2018-04-19 23:46:34 --> Router Class Initialized
INFO - 2018-04-19 23:46:34 --> Output Class Initialized
INFO - 2018-04-19 23:46:34 --> Security Class Initialized
DEBUG - 2018-04-19 23:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:46:34 --> CSRF cookie sent
INFO - 2018-04-19 23:46:34 --> Input Class Initialized
INFO - 2018-04-19 23:46:34 --> Language Class Initialized
INFO - 2018-04-19 23:46:34 --> Loader Class Initialized
INFO - 2018-04-19 23:46:34 --> Helper loaded: url_helper
INFO - 2018-04-19 23:46:34 --> Helper loaded: form_helper
INFO - 2018-04-19 23:46:34 --> Helper loaded: language_helper
DEBUG - 2018-04-19 23:46:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 23:46:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 23:46:35 --> User Agent Class Initialized
INFO - 2018-04-19 23:46:35 --> Controller Class Initialized
INFO - 2018-04-19 23:46:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 23:46:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 23:46:35 --> Final output sent to browser
DEBUG - 2018-04-19 23:46:35 --> Total execution time: 0.4147
INFO - 2018-04-19 23:48:53 --> Config Class Initialized
INFO - 2018-04-19 23:48:53 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:48:53 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:48:53 --> Utf8 Class Initialized
INFO - 2018-04-19 23:48:53 --> URI Class Initialized
INFO - 2018-04-19 23:48:53 --> Router Class Initialized
INFO - 2018-04-19 23:48:53 --> Output Class Initialized
INFO - 2018-04-19 23:48:53 --> Security Class Initialized
DEBUG - 2018-04-19 23:48:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:48:53 --> CSRF cookie sent
INFO - 2018-04-19 23:48:53 --> Input Class Initialized
INFO - 2018-04-19 23:48:53 --> Language Class Initialized
INFO - 2018-04-19 23:48:53 --> Loader Class Initialized
INFO - 2018-04-19 23:48:54 --> Helper loaded: url_helper
INFO - 2018-04-19 23:48:54 --> Helper loaded: form_helper
INFO - 2018-04-19 23:48:54 --> Helper loaded: language_helper
DEBUG - 2018-04-19 23:48:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 23:48:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 23:48:54 --> User Agent Class Initialized
INFO - 2018-04-19 23:48:54 --> Controller Class Initialized
INFO - 2018-04-19 23:48:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 23:48:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 23:48:54 --> Pixel_Model class loaded
INFO - 2018-04-19 23:48:54 --> Database Driver Class Initialized
INFO - 2018-04-19 23:48:54 --> Model "MyAccountModel" initialized
INFO - 2018-04-19 23:48:54 --> Config Class Initialized
INFO - 2018-04-19 23:48:54 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:48:54 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:48:54 --> Utf8 Class Initialized
INFO - 2018-04-19 23:48:54 --> URI Class Initialized
INFO - 2018-04-19 23:48:54 --> Router Class Initialized
INFO - 2018-04-19 23:48:54 --> Output Class Initialized
INFO - 2018-04-19 23:48:54 --> Security Class Initialized
DEBUG - 2018-04-19 23:48:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:48:54 --> CSRF cookie sent
INFO - 2018-04-19 23:48:54 --> Input Class Initialized
INFO - 2018-04-19 23:48:54 --> Language Class Initialized
ERROR - 2018-04-19 23:48:54 --> 404 Page Not Found: Current_seo_uri/index
INFO - 2018-04-19 23:49:08 --> Config Class Initialized
INFO - 2018-04-19 23:49:08 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:49:08 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:49:08 --> Utf8 Class Initialized
INFO - 2018-04-19 23:49:08 --> URI Class Initialized
INFO - 2018-04-19 23:49:08 --> Router Class Initialized
INFO - 2018-04-19 23:49:08 --> Output Class Initialized
INFO - 2018-04-19 23:49:08 --> Security Class Initialized
DEBUG - 2018-04-19 23:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:49:08 --> CSRF cookie sent
INFO - 2018-04-19 23:49:08 --> Input Class Initialized
INFO - 2018-04-19 23:49:08 --> Language Class Initialized
INFO - 2018-04-19 23:49:08 --> Loader Class Initialized
INFO - 2018-04-19 23:49:08 --> Helper loaded: url_helper
INFO - 2018-04-19 23:49:08 --> Helper loaded: form_helper
INFO - 2018-04-19 23:49:08 --> Helper loaded: language_helper
DEBUG - 2018-04-19 23:49:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 23:49:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 23:49:08 --> User Agent Class Initialized
INFO - 2018-04-19 23:49:08 --> Controller Class Initialized
INFO - 2018-04-19 23:49:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 23:49:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 23:49:08 --> Pixel_Model class loaded
INFO - 2018-04-19 23:49:08 --> Database Driver Class Initialized
INFO - 2018-04-19 23:49:08 --> Model "MyAccountModel" initialized
INFO - 2018-04-19 23:49:08 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 23:49:08 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-19 23:49:08 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 23:49:08 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-19 23:49:08 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-19 23:49:08 --> File loaded: E:\www\yacopoo\application\views\myaccount/application_list.php
INFO - 2018-04-19 23:49:08 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 23:49:08 --> Final output sent to browser
DEBUG - 2018-04-19 23:49:08 --> Total execution time: 0.5898
INFO - 2018-04-19 23:49:11 --> Config Class Initialized
INFO - 2018-04-19 23:49:11 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:49:11 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:49:11 --> Utf8 Class Initialized
INFO - 2018-04-19 23:49:11 --> URI Class Initialized
INFO - 2018-04-19 23:49:11 --> Router Class Initialized
INFO - 2018-04-19 23:49:11 --> Output Class Initialized
INFO - 2018-04-19 23:49:11 --> Security Class Initialized
DEBUG - 2018-04-19 23:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:49:11 --> CSRF cookie sent
INFO - 2018-04-19 23:49:11 --> Input Class Initialized
INFO - 2018-04-19 23:49:11 --> Language Class Initialized
INFO - 2018-04-19 23:49:11 --> Loader Class Initialized
INFO - 2018-04-19 23:49:11 --> Helper loaded: url_helper
INFO - 2018-04-19 23:49:11 --> Helper loaded: form_helper
INFO - 2018-04-19 23:49:11 --> Helper loaded: language_helper
DEBUG - 2018-04-19 23:49:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 23:49:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 23:49:11 --> User Agent Class Initialized
INFO - 2018-04-19 23:49:11 --> Controller Class Initialized
INFO - 2018-04-19 23:49:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 23:49:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 23:49:11 --> Pixel_Model class loaded
INFO - 2018-04-19 23:49:11 --> Database Driver Class Initialized
INFO - 2018-04-19 23:49:11 --> Model "MyAccountModel" initialized
ERROR - 2018-04-19 23:49:11 --> Severity: Notice --> Undefined variable: obj E:\www\yacopoo\application\controllers\EndUserAccountController.php 46
ERROR - 2018-04-19 23:49:11 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\controllers\EndUserAccountController.php 46
INFO - 2018-04-19 23:49:11 --> Config Class Initialized
INFO - 2018-04-19 23:49:11 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:49:11 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:49:11 --> Utf8 Class Initialized
INFO - 2018-04-19 23:49:11 --> URI Class Initialized
DEBUG - 2018-04-19 23:49:11 --> No URI present. Default controller set.
INFO - 2018-04-19 23:49:11 --> Router Class Initialized
INFO - 2018-04-19 23:49:11 --> Output Class Initialized
INFO - 2018-04-19 23:49:11 --> Security Class Initialized
DEBUG - 2018-04-19 23:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:49:11 --> CSRF cookie sent
INFO - 2018-04-19 23:49:11 --> Input Class Initialized
INFO - 2018-04-19 23:49:11 --> Language Class Initialized
INFO - 2018-04-19 23:49:11 --> Loader Class Initialized
INFO - 2018-04-19 23:49:11 --> Helper loaded: url_helper
INFO - 2018-04-19 23:49:11 --> Helper loaded: form_helper
INFO - 2018-04-19 23:49:11 --> Helper loaded: language_helper
DEBUG - 2018-04-19 23:49:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 23:49:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 23:49:11 --> User Agent Class Initialized
INFO - 2018-04-19 23:49:11 --> Controller Class Initialized
INFO - 2018-04-19 23:49:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 23:49:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 23:49:11 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 23:49:12 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-19 23:49:12 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 23:49:12 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-19 23:49:12 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 23:49:12 --> Final output sent to browser
DEBUG - 2018-04-19 23:49:12 --> Total execution time: 0.5032
INFO - 2018-04-19 23:49:13 --> Config Class Initialized
INFO - 2018-04-19 23:49:13 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:49:13 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:49:13 --> Utf8 Class Initialized
INFO - 2018-04-19 23:49:13 --> URI Class Initialized
INFO - 2018-04-19 23:49:13 --> Router Class Initialized
INFO - 2018-04-19 23:49:13 --> Output Class Initialized
INFO - 2018-04-19 23:49:13 --> Security Class Initialized
DEBUG - 2018-04-19 23:49:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:49:13 --> CSRF cookie sent
INFO - 2018-04-19 23:49:13 --> Input Class Initialized
INFO - 2018-04-19 23:49:13 --> Language Class Initialized
ERROR - 2018-04-19 23:49:13 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-19 23:49:22 --> Config Class Initialized
INFO - 2018-04-19 23:49:22 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:49:22 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:49:22 --> Utf8 Class Initialized
INFO - 2018-04-19 23:49:22 --> URI Class Initialized
INFO - 2018-04-19 23:49:22 --> Router Class Initialized
INFO - 2018-04-19 23:49:22 --> Output Class Initialized
INFO - 2018-04-19 23:49:22 --> Security Class Initialized
DEBUG - 2018-04-19 23:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:49:22 --> CSRF cookie sent
INFO - 2018-04-19 23:49:22 --> Input Class Initialized
INFO - 2018-04-19 23:49:22 --> Language Class Initialized
INFO - 2018-04-19 23:49:22 --> Loader Class Initialized
INFO - 2018-04-19 23:49:22 --> Helper loaded: url_helper
INFO - 2018-04-19 23:49:22 --> Helper loaded: form_helper
INFO - 2018-04-19 23:49:22 --> Helper loaded: language_helper
DEBUG - 2018-04-19 23:49:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 23:49:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 23:49:22 --> User Agent Class Initialized
INFO - 2018-04-19 23:49:22 --> Controller Class Initialized
INFO - 2018-04-19 23:49:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 23:49:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 23:49:22 --> Pixel_Model class loaded
INFO - 2018-04-19 23:49:23 --> Database Driver Class Initialized
INFO - 2018-04-19 23:49:23 --> Model "MyAccountModel" initialized
INFO - 2018-04-19 23:49:23 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 23:49:23 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-19 23:49:23 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 23:49:23 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-19 23:49:23 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-19 23:49:23 --> File loaded: E:\www\yacopoo\application\views\myaccount/application_list.php
INFO - 2018-04-19 23:49:23 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 23:49:23 --> Final output sent to browser
DEBUG - 2018-04-19 23:49:23 --> Total execution time: 0.6345
INFO - 2018-04-19 23:49:27 --> Config Class Initialized
INFO - 2018-04-19 23:49:27 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:49:27 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:49:27 --> Utf8 Class Initialized
INFO - 2018-04-19 23:49:27 --> URI Class Initialized
INFO - 2018-04-19 23:49:27 --> Router Class Initialized
INFO - 2018-04-19 23:49:27 --> Output Class Initialized
INFO - 2018-04-19 23:49:27 --> Security Class Initialized
DEBUG - 2018-04-19 23:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:49:27 --> CSRF cookie sent
INFO - 2018-04-19 23:49:27 --> Input Class Initialized
INFO - 2018-04-19 23:49:27 --> Language Class Initialized
INFO - 2018-04-19 23:49:27 --> Loader Class Initialized
INFO - 2018-04-19 23:49:27 --> Helper loaded: url_helper
INFO - 2018-04-19 23:49:27 --> Helper loaded: form_helper
INFO - 2018-04-19 23:49:27 --> Helper loaded: language_helper
DEBUG - 2018-04-19 23:49:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 23:49:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 23:49:27 --> User Agent Class Initialized
INFO - 2018-04-19 23:49:27 --> Controller Class Initialized
INFO - 2018-04-19 23:49:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 23:49:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 23:49:27 --> Pixel_Model class loaded
INFO - 2018-04-19 23:49:27 --> Database Driver Class Initialized
INFO - 2018-04-19 23:49:27 --> Model "MyAccountModel" initialized
ERROR - 2018-04-19 23:49:27 --> Severity: Notice --> Undefined variable: obj E:\www\yacopoo\application\controllers\EndUserAccountController.php 46
ERROR - 2018-04-19 23:49:27 --> Severity: Notice --> Trying to get property of non-object E:\www\yacopoo\application\controllers\EndUserAccountController.php 46
INFO - 2018-04-19 23:49:27 --> Config Class Initialized
INFO - 2018-04-19 23:49:27 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:49:27 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:49:27 --> Utf8 Class Initialized
INFO - 2018-04-19 23:49:27 --> URI Class Initialized
DEBUG - 2018-04-19 23:49:27 --> No URI present. Default controller set.
INFO - 2018-04-19 23:49:27 --> Router Class Initialized
INFO - 2018-04-19 23:49:27 --> Output Class Initialized
INFO - 2018-04-19 23:49:27 --> Security Class Initialized
DEBUG - 2018-04-19 23:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:49:27 --> CSRF cookie sent
INFO - 2018-04-19 23:49:27 --> Input Class Initialized
INFO - 2018-04-19 23:49:27 --> Language Class Initialized
INFO - 2018-04-19 23:49:27 --> Loader Class Initialized
INFO - 2018-04-19 23:49:28 --> Helper loaded: url_helper
INFO - 2018-04-19 23:49:28 --> Helper loaded: form_helper
INFO - 2018-04-19 23:49:28 --> Helper loaded: language_helper
DEBUG - 2018-04-19 23:49:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 23:49:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 23:49:28 --> User Agent Class Initialized
INFO - 2018-04-19 23:49:28 --> Controller Class Initialized
INFO - 2018-04-19 23:49:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 23:49:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 23:49:28 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 23:49:28 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-19 23:49:28 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 23:49:28 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-19 23:49:28 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 23:49:28 --> Final output sent to browser
DEBUG - 2018-04-19 23:49:28 --> Total execution time: 0.5058
INFO - 2018-04-19 23:49:29 --> Config Class Initialized
INFO - 2018-04-19 23:49:29 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:49:29 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:49:29 --> Utf8 Class Initialized
INFO - 2018-04-19 23:49:29 --> URI Class Initialized
INFO - 2018-04-19 23:49:29 --> Router Class Initialized
INFO - 2018-04-19 23:49:29 --> Output Class Initialized
INFO - 2018-04-19 23:49:29 --> Security Class Initialized
DEBUG - 2018-04-19 23:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:49:29 --> CSRF cookie sent
INFO - 2018-04-19 23:49:29 --> Input Class Initialized
INFO - 2018-04-19 23:49:29 --> Language Class Initialized
ERROR - 2018-04-19 23:49:29 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-19 23:49:38 --> Config Class Initialized
INFO - 2018-04-19 23:49:38 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:49:38 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:49:38 --> Utf8 Class Initialized
INFO - 2018-04-19 23:49:38 --> URI Class Initialized
INFO - 2018-04-19 23:49:38 --> Router Class Initialized
INFO - 2018-04-19 23:49:38 --> Output Class Initialized
INFO - 2018-04-19 23:49:38 --> Security Class Initialized
DEBUG - 2018-04-19 23:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:49:38 --> CSRF cookie sent
INFO - 2018-04-19 23:49:38 --> Input Class Initialized
INFO - 2018-04-19 23:49:38 --> Language Class Initialized
INFO - 2018-04-19 23:49:38 --> Loader Class Initialized
INFO - 2018-04-19 23:49:38 --> Helper loaded: url_helper
INFO - 2018-04-19 23:49:38 --> Helper loaded: form_helper
INFO - 2018-04-19 23:49:38 --> Helper loaded: language_helper
DEBUG - 2018-04-19 23:49:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 23:49:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 23:49:38 --> User Agent Class Initialized
INFO - 2018-04-19 23:49:38 --> Controller Class Initialized
INFO - 2018-04-19 23:49:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 23:49:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 23:49:38 --> Pixel_Model class loaded
INFO - 2018-04-19 23:49:38 --> Database Driver Class Initialized
INFO - 2018-04-19 23:49:38 --> Model "MyAccountModel" initialized
INFO - 2018-04-19 23:49:38 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 23:49:39 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-19 23:49:39 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 23:49:39 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-19 23:49:39 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-19 23:49:39 --> File loaded: E:\www\yacopoo\application\views\myaccount/application_list.php
INFO - 2018-04-19 23:49:39 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 23:49:39 --> Final output sent to browser
DEBUG - 2018-04-19 23:49:39 --> Total execution time: 0.6488
INFO - 2018-04-19 23:49:40 --> Config Class Initialized
INFO - 2018-04-19 23:49:40 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:49:40 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:49:40 --> Utf8 Class Initialized
INFO - 2018-04-19 23:49:40 --> URI Class Initialized
INFO - 2018-04-19 23:49:40 --> Router Class Initialized
INFO - 2018-04-19 23:49:40 --> Output Class Initialized
INFO - 2018-04-19 23:49:40 --> Security Class Initialized
DEBUG - 2018-04-19 23:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:49:40 --> CSRF cookie sent
INFO - 2018-04-19 23:49:40 --> Input Class Initialized
INFO - 2018-04-19 23:49:40 --> Language Class Initialized
INFO - 2018-04-19 23:49:40 --> Loader Class Initialized
INFO - 2018-04-19 23:49:40 --> Helper loaded: url_helper
INFO - 2018-04-19 23:49:40 --> Helper loaded: form_helper
INFO - 2018-04-19 23:49:41 --> Helper loaded: language_helper
DEBUG - 2018-04-19 23:49:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 23:49:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 23:49:41 --> User Agent Class Initialized
INFO - 2018-04-19 23:49:41 --> Controller Class Initialized
INFO - 2018-04-19 23:49:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 23:49:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 23:49:41 --> Pixel_Model class loaded
INFO - 2018-04-19 23:49:41 --> Database Driver Class Initialized
INFO - 2018-04-19 23:49:41 --> Model "MyAccountModel" initialized
INFO - 2018-04-19 23:49:41 --> Config Class Initialized
INFO - 2018-04-19 23:49:41 --> Hooks Class Initialized
DEBUG - 2018-04-19 23:49:41 --> UTF-8 Support Enabled
INFO - 2018-04-19 23:49:41 --> Utf8 Class Initialized
INFO - 2018-04-19 23:49:41 --> URI Class Initialized
INFO - 2018-04-19 23:49:41 --> Router Class Initialized
INFO - 2018-04-19 23:49:41 --> Output Class Initialized
INFO - 2018-04-19 23:49:41 --> Security Class Initialized
DEBUG - 2018-04-19 23:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-19 23:49:41 --> CSRF cookie sent
INFO - 2018-04-19 23:49:41 --> Input Class Initialized
INFO - 2018-04-19 23:49:41 --> Language Class Initialized
INFO - 2018-04-19 23:49:41 --> Loader Class Initialized
INFO - 2018-04-19 23:49:41 --> Helper loaded: url_helper
INFO - 2018-04-19 23:49:41 --> Helper loaded: form_helper
INFO - 2018-04-19 23:49:41 --> Helper loaded: language_helper
DEBUG - 2018-04-19 23:49:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-19 23:49:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-19 23:49:41 --> User Agent Class Initialized
INFO - 2018-04-19 23:49:41 --> Controller Class Initialized
INFO - 2018-04-19 23:49:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-19 23:49:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-19 23:49:41 --> Pixel_Model class loaded
INFO - 2018-04-19 23:49:41 --> Database Driver Class Initialized
INFO - 2018-04-19 23:49:41 --> Model "QuestionsModel" initialized
INFO - 2018-04-19 23:49:41 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-19 23:49:41 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-19 23:49:41 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-19 23:49:41 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-19 23:49:41 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-19 23:49:41 --> File loaded: E:\www\yacopoo\application\views\questions/have_hit_s.php
INFO - 2018-04-19 23:49:41 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-19 23:49:41 --> Final output sent to browser
DEBUG - 2018-04-19 23:49:41 --> Total execution time: 0.6464

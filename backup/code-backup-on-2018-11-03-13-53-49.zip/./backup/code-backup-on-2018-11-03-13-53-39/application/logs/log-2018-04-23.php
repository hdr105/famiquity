<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-04-23 14:58:25 --> Config Class Initialized
INFO - 2018-04-23 14:58:25 --> Hooks Class Initialized
DEBUG - 2018-04-23 14:58:25 --> UTF-8 Support Enabled
INFO - 2018-04-23 14:58:25 --> Utf8 Class Initialized
INFO - 2018-04-23 14:58:25 --> URI Class Initialized
INFO - 2018-04-23 14:58:25 --> Router Class Initialized
INFO - 2018-04-23 14:58:25 --> Output Class Initialized
INFO - 2018-04-23 14:58:25 --> Security Class Initialized
DEBUG - 2018-04-23 14:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 14:58:25 --> CSRF cookie sent
INFO - 2018-04-23 14:58:25 --> Input Class Initialized
INFO - 2018-04-23 14:58:25 --> Language Class Initialized
INFO - 2018-04-23 14:58:25 --> Loader Class Initialized
INFO - 2018-04-23 14:58:25 --> Helper loaded: url_helper
INFO - 2018-04-23 14:58:25 --> Helper loaded: form_helper
INFO - 2018-04-23 14:58:25 --> Helper loaded: language_helper
DEBUG - 2018-04-23 14:58:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-23 14:58:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 14:58:25 --> User Agent Class Initialized
INFO - 2018-04-23 14:58:25 --> Controller Class Initialized
INFO - 2018-04-23 14:58:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-23 14:58:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-23 14:58:26 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-23 14:58:26 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-23 14:58:26 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-23 14:58:26 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-23 14:58:26 --> File loaded: E:\www\yacopoo\application\views\register/success_message.php
INFO - 2018-04-23 14:58:26 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-23 14:58:26 --> Final output sent to browser
DEBUG - 2018-04-23 14:58:26 --> Total execution time: 1.0809
INFO - 2018-04-23 20:27:57 --> Config Class Initialized
INFO - 2018-04-23 20:27:57 --> Hooks Class Initialized
DEBUG - 2018-04-23 20:27:57 --> UTF-8 Support Enabled
INFO - 2018-04-23 20:27:57 --> Utf8 Class Initialized
INFO - 2018-04-23 20:27:57 --> URI Class Initialized
DEBUG - 2018-04-23 20:27:57 --> No URI present. Default controller set.
INFO - 2018-04-23 20:27:57 --> Router Class Initialized
INFO - 2018-04-23 20:27:57 --> Output Class Initialized
INFO - 2018-04-23 20:27:57 --> Security Class Initialized
DEBUG - 2018-04-23 20:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 20:27:57 --> CSRF cookie sent
INFO - 2018-04-23 20:27:57 --> Input Class Initialized
INFO - 2018-04-23 20:27:57 --> Language Class Initialized
INFO - 2018-04-23 20:27:58 --> Loader Class Initialized
INFO - 2018-04-23 20:27:58 --> Helper loaded: url_helper
INFO - 2018-04-23 20:27:58 --> Helper loaded: form_helper
INFO - 2018-04-23 20:27:58 --> Helper loaded: language_helper
DEBUG - 2018-04-23 20:27:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-23 20:27:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 20:27:58 --> User Agent Class Initialized
INFO - 2018-04-23 20:27:58 --> Controller Class Initialized
INFO - 2018-04-23 20:27:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-23 20:27:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-23 20:27:58 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-23 20:27:58 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-23 20:27:58 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-23 20:27:58 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-23 20:27:58 --> Final output sent to browser
DEBUG - 2018-04-23 20:27:58 --> Total execution time: 0.9186
INFO - 2018-04-23 20:28:00 --> Config Class Initialized
INFO - 2018-04-23 20:28:00 --> Hooks Class Initialized
DEBUG - 2018-04-23 20:28:00 --> UTF-8 Support Enabled
INFO - 2018-04-23 20:28:00 --> Utf8 Class Initialized
INFO - 2018-04-23 20:28:00 --> URI Class Initialized
INFO - 2018-04-23 20:28:00 --> Router Class Initialized
INFO - 2018-04-23 20:28:00 --> Output Class Initialized
INFO - 2018-04-23 20:28:00 --> Security Class Initialized
DEBUG - 2018-04-23 20:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 20:28:00 --> CSRF cookie sent
INFO - 2018-04-23 20:28:00 --> Input Class Initialized
INFO - 2018-04-23 20:28:00 --> Language Class Initialized
ERROR - 2018-04-23 20:28:00 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-23 20:28:01 --> Config Class Initialized
INFO - 2018-04-23 20:28:01 --> Hooks Class Initialized
DEBUG - 2018-04-23 20:28:01 --> UTF-8 Support Enabled
INFO - 2018-04-23 20:28:01 --> Utf8 Class Initialized
INFO - 2018-04-23 20:28:01 --> URI Class Initialized
INFO - 2018-04-23 20:28:01 --> Router Class Initialized
INFO - 2018-04-23 20:28:01 --> Output Class Initialized
INFO - 2018-04-23 20:28:01 --> Security Class Initialized
DEBUG - 2018-04-23 20:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 20:28:01 --> CSRF cookie sent
INFO - 2018-04-23 20:28:01 --> Input Class Initialized
INFO - 2018-04-23 20:28:01 --> Language Class Initialized
INFO - 2018-04-23 20:28:01 --> Loader Class Initialized
INFO - 2018-04-23 20:28:01 --> Helper loaded: url_helper
INFO - 2018-04-23 20:28:01 --> Helper loaded: form_helper
INFO - 2018-04-23 20:28:01 --> Helper loaded: language_helper
DEBUG - 2018-04-23 20:28:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-23 20:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 20:28:01 --> User Agent Class Initialized
INFO - 2018-04-23 20:28:01 --> Controller Class Initialized
INFO - 2018-04-23 20:28:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-23 20:28:01 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-23 20:28:01 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-23 20:28:02 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-23 20:28:02 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-23 20:28:02 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-23 20:28:02 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-23 20:28:02 --> Could not find the language line "req_email"
INFO - 2018-04-23 20:28:02 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-04-23 20:28:02 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-23 20:28:02 --> Final output sent to browser
DEBUG - 2018-04-23 20:28:02 --> Total execution time: 0.4643
INFO - 2018-04-23 20:28:07 --> Config Class Initialized
INFO - 2018-04-23 20:28:07 --> Hooks Class Initialized
DEBUG - 2018-04-23 20:28:07 --> UTF-8 Support Enabled
INFO - 2018-04-23 20:28:07 --> Utf8 Class Initialized
INFO - 2018-04-23 20:28:07 --> URI Class Initialized
INFO - 2018-04-23 20:28:07 --> Router Class Initialized
INFO - 2018-04-23 20:28:07 --> Output Class Initialized
INFO - 2018-04-23 20:28:07 --> Security Class Initialized
DEBUG - 2018-04-23 20:28:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 20:28:07 --> CSRF cookie sent
INFO - 2018-04-23 20:28:07 --> CSRF token verified
INFO - 2018-04-23 20:28:07 --> Input Class Initialized
INFO - 2018-04-23 20:28:07 --> Language Class Initialized
INFO - 2018-04-23 20:28:07 --> Loader Class Initialized
INFO - 2018-04-23 20:28:07 --> Helper loaded: url_helper
INFO - 2018-04-23 20:28:07 --> Helper loaded: form_helper
INFO - 2018-04-23 20:28:07 --> Helper loaded: language_helper
DEBUG - 2018-04-23 20:28:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-23 20:28:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 20:28:07 --> User Agent Class Initialized
INFO - 2018-04-23 20:28:07 --> Controller Class Initialized
INFO - 2018-04-23 20:28:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-23 20:28:07 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-23 20:28:07 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-23 20:28:08 --> Form Validation Class Initialized
INFO - 2018-04-23 20:28:08 --> Pixel_Model class loaded
INFO - 2018-04-23 20:28:08 --> Database Driver Class Initialized
INFO - 2018-04-23 20:28:08 --> Model "AuthenticationModel" initialized
INFO - 2018-04-23 20:28:09 --> Config Class Initialized
INFO - 2018-04-23 20:28:09 --> Hooks Class Initialized
DEBUG - 2018-04-23 20:28:09 --> UTF-8 Support Enabled
INFO - 2018-04-23 20:28:09 --> Utf8 Class Initialized
INFO - 2018-04-23 20:28:09 --> URI Class Initialized
DEBUG - 2018-04-23 20:28:09 --> No URI present. Default controller set.
INFO - 2018-04-23 20:28:09 --> Router Class Initialized
INFO - 2018-04-23 20:28:09 --> Output Class Initialized
INFO - 2018-04-23 20:28:09 --> Security Class Initialized
DEBUG - 2018-04-23 20:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 20:28:09 --> CSRF cookie sent
INFO - 2018-04-23 20:28:09 --> Input Class Initialized
INFO - 2018-04-23 20:28:09 --> Language Class Initialized
INFO - 2018-04-23 20:28:09 --> Loader Class Initialized
INFO - 2018-04-23 20:28:09 --> Helper loaded: url_helper
INFO - 2018-04-23 20:28:09 --> Helper loaded: form_helper
INFO - 2018-04-23 20:28:09 --> Helper loaded: language_helper
DEBUG - 2018-04-23 20:28:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-23 20:28:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 20:28:09 --> User Agent Class Initialized
INFO - 2018-04-23 20:28:09 --> Controller Class Initialized
INFO - 2018-04-23 20:28:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-23 20:28:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-23 20:28:09 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-23 20:28:09 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-23 20:28:09 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-23 20:28:09 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-23 20:28:09 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-23 20:28:09 --> Final output sent to browser
DEBUG - 2018-04-23 20:28:09 --> Total execution time: 0.2599
INFO - 2018-04-23 20:28:10 --> Config Class Initialized
INFO - 2018-04-23 20:28:10 --> Hooks Class Initialized
DEBUG - 2018-04-23 20:28:10 --> UTF-8 Support Enabled
INFO - 2018-04-23 20:28:10 --> Utf8 Class Initialized
INFO - 2018-04-23 20:28:10 --> URI Class Initialized
INFO - 2018-04-23 20:28:10 --> Router Class Initialized
INFO - 2018-04-23 20:28:10 --> Output Class Initialized
INFO - 2018-04-23 20:28:10 --> Security Class Initialized
DEBUG - 2018-04-23 20:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 20:28:11 --> CSRF cookie sent
INFO - 2018-04-23 20:28:11 --> Input Class Initialized
INFO - 2018-04-23 20:28:11 --> Language Class Initialized
ERROR - 2018-04-23 20:28:11 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-23 20:28:13 --> Config Class Initialized
INFO - 2018-04-23 20:28:13 --> Hooks Class Initialized
DEBUG - 2018-04-23 20:28:13 --> UTF-8 Support Enabled
INFO - 2018-04-23 20:28:13 --> Utf8 Class Initialized
INFO - 2018-04-23 20:28:13 --> URI Class Initialized
INFO - 2018-04-23 20:28:13 --> Router Class Initialized
INFO - 2018-04-23 20:28:13 --> Output Class Initialized
INFO - 2018-04-23 20:28:14 --> Security Class Initialized
DEBUG - 2018-04-23 20:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 20:28:14 --> CSRF cookie sent
INFO - 2018-04-23 20:28:14 --> Input Class Initialized
INFO - 2018-04-23 20:28:14 --> Language Class Initialized
INFO - 2018-04-23 20:28:14 --> Loader Class Initialized
INFO - 2018-04-23 20:28:14 --> Helper loaded: url_helper
INFO - 2018-04-23 20:28:14 --> Helper loaded: form_helper
INFO - 2018-04-23 20:28:14 --> Helper loaded: language_helper
DEBUG - 2018-04-23 20:28:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-23 20:28:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 20:28:14 --> User Agent Class Initialized
INFO - 2018-04-23 20:28:14 --> Controller Class Initialized
INFO - 2018-04-23 20:28:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-23 20:28:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-23 20:28:14 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-23 20:28:14 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-23 20:28:14 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-23 20:28:14 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-23 20:28:14 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-23 20:28:14 --> File loaded: E:\www\yacopoo\application\views\register/import_fa.php
INFO - 2018-04-23 20:28:14 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-23 20:28:14 --> Final output sent to browser
DEBUG - 2018-04-23 20:28:14 --> Total execution time: 0.3062
INFO - 2018-04-23 20:28:21 --> Config Class Initialized
INFO - 2018-04-23 20:28:21 --> Hooks Class Initialized
DEBUG - 2018-04-23 20:28:21 --> UTF-8 Support Enabled
INFO - 2018-04-23 20:28:21 --> Utf8 Class Initialized
INFO - 2018-04-23 20:28:21 --> URI Class Initialized
INFO - 2018-04-23 20:28:21 --> Router Class Initialized
INFO - 2018-04-23 20:28:21 --> Output Class Initialized
INFO - 2018-04-23 20:28:21 --> Security Class Initialized
DEBUG - 2018-04-23 20:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 20:28:21 --> CSRF cookie sent
INFO - 2018-04-23 20:28:21 --> Input Class Initialized
INFO - 2018-04-23 20:28:21 --> Language Class Initialized
INFO - 2018-04-23 20:28:21 --> Loader Class Initialized
INFO - 2018-04-23 20:28:21 --> Helper loaded: url_helper
INFO - 2018-04-23 20:28:21 --> Helper loaded: form_helper
INFO - 2018-04-23 20:28:21 --> Helper loaded: language_helper
DEBUG - 2018-04-23 20:28:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-23 20:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 20:28:21 --> User Agent Class Initialized
INFO - 2018-04-23 20:28:21 --> Controller Class Initialized
INFO - 2018-04-23 20:28:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-23 20:28:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-23 20:28:21 --> Pixel_Model class loaded
INFO - 2018-04-23 20:28:21 --> Database Driver Class Initialized
INFO - 2018-04-23 20:28:21 --> Model "MyAccountModel" initialized
INFO - 2018-04-23 20:28:21 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-23 20:28:21 --> File loaded: E:\www\yacopoo\application\views\shared/_admin_nav.php
INFO - 2018-04-23 20:28:21 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-23 20:28:21 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-23 20:28:21 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-23 20:28:21 --> Could not find the language line "req_email"
INFO - 2018-04-23 20:28:21 --> File loaded: E:\www\yacopoo\application\views\register/add_advisor.php
INFO - 2018-04-23 20:28:21 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-23 20:28:21 --> Final output sent to browser
DEBUG - 2018-04-23 20:28:21 --> Total execution time: 0.3764

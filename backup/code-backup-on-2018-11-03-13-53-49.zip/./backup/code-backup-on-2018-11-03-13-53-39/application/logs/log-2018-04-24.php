<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-04-24 15:19:53 --> Config Class Initialized
INFO - 2018-04-24 15:19:53 --> Hooks Class Initialized
DEBUG - 2018-04-24 15:19:53 --> UTF-8 Support Enabled
INFO - 2018-04-24 15:19:53 --> Utf8 Class Initialized
INFO - 2018-04-24 15:19:53 --> URI Class Initialized
INFO - 2018-04-24 15:19:53 --> Router Class Initialized
INFO - 2018-04-24 15:19:53 --> Output Class Initialized
INFO - 2018-04-24 15:19:53 --> Security Class Initialized
DEBUG - 2018-04-24 15:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-24 15:19:53 --> CSRF cookie sent
INFO - 2018-04-24 15:19:53 --> Input Class Initialized
INFO - 2018-04-24 15:19:53 --> Language Class Initialized
INFO - 2018-04-24 15:19:53 --> Loader Class Initialized
INFO - 2018-04-24 15:19:53 --> Helper loaded: url_helper
INFO - 2018-04-24 15:19:54 --> Helper loaded: form_helper
INFO - 2018-04-24 15:19:54 --> Helper loaded: language_helper
DEBUG - 2018-04-24 15:19:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-24 15:19:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-24 15:19:54 --> User Agent Class Initialized
INFO - 2018-04-24 15:19:54 --> Controller Class Initialized
INFO - 2018-04-24 15:19:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-24 15:19:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-24 15:19:54 --> Config Class Initialized
INFO - 2018-04-24 15:19:55 --> Hooks Class Initialized
DEBUG - 2018-04-24 15:19:55 --> UTF-8 Support Enabled
INFO - 2018-04-24 15:19:55 --> Utf8 Class Initialized
INFO - 2018-04-24 15:19:55 --> URI Class Initialized
DEBUG - 2018-04-24 15:19:55 --> No URI present. Default controller set.
INFO - 2018-04-24 15:19:55 --> Router Class Initialized
INFO - 2018-04-24 15:19:55 --> Output Class Initialized
INFO - 2018-04-24 15:19:55 --> Security Class Initialized
DEBUG - 2018-04-24 15:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-24 15:19:55 --> CSRF cookie sent
INFO - 2018-04-24 15:19:55 --> Input Class Initialized
INFO - 2018-04-24 15:19:55 --> Language Class Initialized
INFO - 2018-04-24 15:19:55 --> Loader Class Initialized
INFO - 2018-04-24 15:19:55 --> Helper loaded: url_helper
INFO - 2018-04-24 15:19:55 --> Helper loaded: form_helper
INFO - 2018-04-24 15:19:55 --> Helper loaded: language_helper
DEBUG - 2018-04-24 15:19:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-24 15:19:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-24 15:19:55 --> User Agent Class Initialized
INFO - 2018-04-24 15:19:55 --> Controller Class Initialized
INFO - 2018-04-24 15:19:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-24 15:19:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-24 15:19:55 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-24 15:19:55 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-24 15:19:55 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-24 15:19:55 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-24 15:19:55 --> Final output sent to browser
DEBUG - 2018-04-24 15:19:55 --> Total execution time: 0.8285
INFO - 2018-04-24 15:24:35 --> Config Class Initialized
INFO - 2018-04-24 15:24:35 --> Hooks Class Initialized
DEBUG - 2018-04-24 15:24:35 --> UTF-8 Support Enabled
INFO - 2018-04-24 15:24:35 --> Utf8 Class Initialized
INFO - 2018-04-24 15:24:35 --> URI Class Initialized
INFO - 2018-04-24 15:24:35 --> Router Class Initialized
INFO - 2018-04-24 15:24:35 --> Output Class Initialized
INFO - 2018-04-24 15:24:35 --> Security Class Initialized
DEBUG - 2018-04-24 15:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-24 15:24:35 --> CSRF cookie sent
INFO - 2018-04-24 15:24:35 --> Input Class Initialized
INFO - 2018-04-24 15:24:35 --> Language Class Initialized
ERROR - 2018-04-24 15:24:36 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-24 23:24:13 --> Config Class Initialized
INFO - 2018-04-24 23:24:13 --> Hooks Class Initialized
DEBUG - 2018-04-24 23:24:13 --> UTF-8 Support Enabled
INFO - 2018-04-24 23:24:13 --> Utf8 Class Initialized
INFO - 2018-04-24 23:24:13 --> URI Class Initialized
DEBUG - 2018-04-24 23:24:13 --> No URI present. Default controller set.
INFO - 2018-04-24 23:24:13 --> Router Class Initialized
INFO - 2018-04-24 23:24:13 --> Output Class Initialized
INFO - 2018-04-24 23:24:13 --> Security Class Initialized
DEBUG - 2018-04-24 23:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-24 23:24:14 --> CSRF cookie sent
INFO - 2018-04-24 23:24:14 --> Input Class Initialized
INFO - 2018-04-24 23:24:14 --> Language Class Initialized
INFO - 2018-04-24 23:24:14 --> Loader Class Initialized
INFO - 2018-04-24 23:24:14 --> Helper loaded: url_helper
INFO - 2018-04-24 23:24:14 --> Helper loaded: form_helper
INFO - 2018-04-24 23:24:14 --> Helper loaded: language_helper
DEBUG - 2018-04-24 23:24:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-24 23:24:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-24 23:24:14 --> User Agent Class Initialized
INFO - 2018-04-24 23:24:14 --> Controller Class Initialized
INFO - 2018-04-24 23:24:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-24 23:24:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-24 23:24:14 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-24 23:24:14 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-24 23:24:14 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-24 23:24:14 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-24 23:24:14 --> Final output sent to browser
DEBUG - 2018-04-24 23:24:14 --> Total execution time: 1.5166
INFO - 2018-04-24 23:24:17 --> Config Class Initialized
INFO - 2018-04-24 23:24:17 --> Hooks Class Initialized
DEBUG - 2018-04-24 23:24:17 --> UTF-8 Support Enabled
INFO - 2018-04-24 23:24:17 --> Utf8 Class Initialized
INFO - 2018-04-24 23:24:17 --> URI Class Initialized
INFO - 2018-04-24 23:24:17 --> Router Class Initialized
INFO - 2018-04-24 23:24:17 --> Output Class Initialized
INFO - 2018-04-24 23:24:17 --> Security Class Initialized
DEBUG - 2018-04-24 23:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-24 23:24:17 --> CSRF cookie sent
INFO - 2018-04-24 23:24:17 --> Input Class Initialized
INFO - 2018-04-24 23:24:17 --> Language Class Initialized
ERROR - 2018-04-24 23:24:17 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-24 23:26:26 --> Config Class Initialized
INFO - 2018-04-24 23:26:26 --> Hooks Class Initialized
DEBUG - 2018-04-24 23:26:26 --> UTF-8 Support Enabled
INFO - 2018-04-24 23:26:26 --> Utf8 Class Initialized
INFO - 2018-04-24 23:26:26 --> URI Class Initialized
DEBUG - 2018-04-24 23:26:26 --> No URI present. Default controller set.
INFO - 2018-04-24 23:26:26 --> Router Class Initialized
INFO - 2018-04-24 23:26:26 --> Output Class Initialized
INFO - 2018-04-24 23:26:26 --> Security Class Initialized
DEBUG - 2018-04-24 23:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-24 23:26:26 --> CSRF cookie sent
INFO - 2018-04-24 23:26:26 --> Input Class Initialized
INFO - 2018-04-24 23:26:26 --> Language Class Initialized
INFO - 2018-04-24 23:26:26 --> Loader Class Initialized
INFO - 2018-04-24 23:26:26 --> Helper loaded: url_helper
INFO - 2018-04-24 23:26:26 --> Helper loaded: form_helper
INFO - 2018-04-24 23:26:26 --> Helper loaded: language_helper
DEBUG - 2018-04-24 23:26:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-24 23:26:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-24 23:26:26 --> User Agent Class Initialized
INFO - 2018-04-24 23:26:26 --> Controller Class Initialized
INFO - 2018-04-24 23:26:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-24 23:26:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-24 23:26:26 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-24 23:26:26 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-24 23:26:26 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-24 23:26:26 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-24 23:26:26 --> Final output sent to browser
DEBUG - 2018-04-24 23:26:26 --> Total execution time: 0.2713
INFO - 2018-04-24 23:26:28 --> Config Class Initialized
INFO - 2018-04-24 23:26:28 --> Hooks Class Initialized
DEBUG - 2018-04-24 23:26:28 --> UTF-8 Support Enabled
INFO - 2018-04-24 23:26:28 --> Utf8 Class Initialized
INFO - 2018-04-24 23:26:28 --> URI Class Initialized
INFO - 2018-04-24 23:26:28 --> Router Class Initialized
INFO - 2018-04-24 23:26:28 --> Output Class Initialized
INFO - 2018-04-24 23:26:28 --> Security Class Initialized
DEBUG - 2018-04-24 23:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-24 23:26:28 --> CSRF cookie sent
INFO - 2018-04-24 23:26:28 --> Input Class Initialized
INFO - 2018-04-24 23:26:28 --> Language Class Initialized
ERROR - 2018-04-24 23:26:28 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-24 23:26:37 --> Config Class Initialized
INFO - 2018-04-24 23:26:37 --> Hooks Class Initialized
DEBUG - 2018-04-24 23:26:37 --> UTF-8 Support Enabled
INFO - 2018-04-24 23:26:37 --> Utf8 Class Initialized
INFO - 2018-04-24 23:26:37 --> URI Class Initialized
DEBUG - 2018-04-24 23:26:37 --> No URI present. Default controller set.
INFO - 2018-04-24 23:26:37 --> Router Class Initialized
INFO - 2018-04-24 23:26:37 --> Output Class Initialized
INFO - 2018-04-24 23:26:37 --> Security Class Initialized
DEBUG - 2018-04-24 23:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-24 23:26:37 --> CSRF cookie sent
INFO - 2018-04-24 23:26:37 --> Input Class Initialized
INFO - 2018-04-24 23:26:37 --> Language Class Initialized
INFO - 2018-04-24 23:26:37 --> Loader Class Initialized
INFO - 2018-04-24 23:26:37 --> Helper loaded: url_helper
INFO - 2018-04-24 23:26:38 --> Helper loaded: form_helper
INFO - 2018-04-24 23:26:38 --> Helper loaded: language_helper
DEBUG - 2018-04-24 23:26:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-24 23:26:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-24 23:26:38 --> User Agent Class Initialized
INFO - 2018-04-24 23:26:38 --> Controller Class Initialized
INFO - 2018-04-24 23:26:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-24 23:26:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-24 23:26:38 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-24 23:26:38 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-24 23:26:38 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-24 23:26:38 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-24 23:26:38 --> Final output sent to browser
DEBUG - 2018-04-24 23:26:38 --> Total execution time: 0.3104
INFO - 2018-04-24 23:26:39 --> Config Class Initialized
INFO - 2018-04-24 23:26:39 --> Hooks Class Initialized
DEBUG - 2018-04-24 23:26:39 --> UTF-8 Support Enabled
INFO - 2018-04-24 23:26:39 --> Utf8 Class Initialized
INFO - 2018-04-24 23:26:39 --> URI Class Initialized
INFO - 2018-04-24 23:26:39 --> Router Class Initialized
INFO - 2018-04-24 23:26:39 --> Output Class Initialized
INFO - 2018-04-24 23:26:39 --> Security Class Initialized
DEBUG - 2018-04-24 23:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-24 23:26:39 --> CSRF cookie sent
INFO - 2018-04-24 23:26:39 --> Input Class Initialized
INFO - 2018-04-24 23:26:39 --> Language Class Initialized
ERROR - 2018-04-24 23:26:39 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-24 23:27:53 --> Config Class Initialized
INFO - 2018-04-24 23:27:53 --> Hooks Class Initialized
DEBUG - 2018-04-24 23:27:53 --> UTF-8 Support Enabled
INFO - 2018-04-24 23:27:53 --> Utf8 Class Initialized
INFO - 2018-04-24 23:27:53 --> URI Class Initialized
DEBUG - 2018-04-24 23:27:53 --> No URI present. Default controller set.
INFO - 2018-04-24 23:27:53 --> Router Class Initialized
INFO - 2018-04-24 23:27:53 --> Output Class Initialized
INFO - 2018-04-24 23:27:53 --> Security Class Initialized
DEBUG - 2018-04-24 23:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-24 23:27:53 --> CSRF cookie sent
INFO - 2018-04-24 23:27:53 --> Input Class Initialized
INFO - 2018-04-24 23:27:53 --> Language Class Initialized
INFO - 2018-04-24 23:27:53 --> Loader Class Initialized
INFO - 2018-04-24 23:27:53 --> Helper loaded: url_helper
INFO - 2018-04-24 23:27:53 --> Helper loaded: form_helper
INFO - 2018-04-24 23:27:53 --> Helper loaded: language_helper
DEBUG - 2018-04-24 23:27:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-24 23:27:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-24 23:27:54 --> User Agent Class Initialized
INFO - 2018-04-24 23:27:54 --> Controller Class Initialized
INFO - 2018-04-24 23:27:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-24 23:27:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-24 23:27:54 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-24 23:27:54 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-24 23:27:54 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-24 23:27:54 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-24 23:27:54 --> Final output sent to browser
DEBUG - 2018-04-24 23:27:54 --> Total execution time: 0.3424
INFO - 2018-04-24 23:27:55 --> Config Class Initialized
INFO - 2018-04-24 23:27:55 --> Hooks Class Initialized
DEBUG - 2018-04-24 23:27:55 --> UTF-8 Support Enabled
INFO - 2018-04-24 23:27:55 --> Utf8 Class Initialized
INFO - 2018-04-24 23:27:55 --> URI Class Initialized
INFO - 2018-04-24 23:27:55 --> Router Class Initialized
INFO - 2018-04-24 23:27:55 --> Output Class Initialized
INFO - 2018-04-24 23:27:55 --> Security Class Initialized
DEBUG - 2018-04-24 23:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-24 23:27:55 --> CSRF cookie sent
INFO - 2018-04-24 23:27:55 --> Input Class Initialized
INFO - 2018-04-24 23:27:55 --> Language Class Initialized
ERROR - 2018-04-24 23:27:55 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-24 23:28:01 --> Config Class Initialized
INFO - 2018-04-24 23:28:01 --> Hooks Class Initialized
DEBUG - 2018-04-24 23:28:01 --> UTF-8 Support Enabled
INFO - 2018-04-24 23:28:01 --> Utf8 Class Initialized
INFO - 2018-04-24 23:28:01 --> URI Class Initialized
DEBUG - 2018-04-24 23:28:01 --> No URI present. Default controller set.
INFO - 2018-04-24 23:28:01 --> Router Class Initialized
INFO - 2018-04-24 23:28:01 --> Output Class Initialized
INFO - 2018-04-24 23:28:01 --> Security Class Initialized
DEBUG - 2018-04-24 23:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-24 23:28:01 --> CSRF cookie sent
INFO - 2018-04-24 23:28:01 --> Input Class Initialized
INFO - 2018-04-24 23:28:01 --> Language Class Initialized
INFO - 2018-04-24 23:28:01 --> Loader Class Initialized
INFO - 2018-04-24 23:28:01 --> Helper loaded: url_helper
INFO - 2018-04-24 23:28:01 --> Helper loaded: form_helper
INFO - 2018-04-24 23:28:01 --> Helper loaded: language_helper
DEBUG - 2018-04-24 23:28:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-24 23:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-24 23:28:01 --> User Agent Class Initialized
INFO - 2018-04-24 23:28:01 --> Controller Class Initialized
INFO - 2018-04-24 23:28:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-24 23:28:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-24 23:28:01 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-24 23:28:01 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-24 23:28:01 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-24 23:28:01 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-24 23:28:01 --> Final output sent to browser
DEBUG - 2018-04-24 23:28:01 --> Total execution time: 0.2824
INFO - 2018-04-24 23:28:03 --> Config Class Initialized
INFO - 2018-04-24 23:28:03 --> Hooks Class Initialized
DEBUG - 2018-04-24 23:28:03 --> UTF-8 Support Enabled
INFO - 2018-04-24 23:28:03 --> Utf8 Class Initialized
INFO - 2018-04-24 23:28:03 --> URI Class Initialized
INFO - 2018-04-24 23:28:03 --> Router Class Initialized
INFO - 2018-04-24 23:28:03 --> Output Class Initialized
INFO - 2018-04-24 23:28:03 --> Security Class Initialized
DEBUG - 2018-04-24 23:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-24 23:28:03 --> CSRF cookie sent
INFO - 2018-04-24 23:28:03 --> Input Class Initialized
INFO - 2018-04-24 23:28:03 --> Language Class Initialized
ERROR - 2018-04-24 23:28:03 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-24 23:28:20 --> Config Class Initialized
INFO - 2018-04-24 23:28:20 --> Hooks Class Initialized
DEBUG - 2018-04-24 23:28:20 --> UTF-8 Support Enabled
INFO - 2018-04-24 23:28:20 --> Utf8 Class Initialized
INFO - 2018-04-24 23:28:20 --> URI Class Initialized
DEBUG - 2018-04-24 23:28:20 --> No URI present. Default controller set.
INFO - 2018-04-24 23:28:20 --> Router Class Initialized
INFO - 2018-04-24 23:28:20 --> Output Class Initialized
INFO - 2018-04-24 23:28:20 --> Security Class Initialized
DEBUG - 2018-04-24 23:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-24 23:28:20 --> CSRF cookie sent
INFO - 2018-04-24 23:28:20 --> Input Class Initialized
INFO - 2018-04-24 23:28:20 --> Language Class Initialized
INFO - 2018-04-24 23:28:20 --> Loader Class Initialized
INFO - 2018-04-24 23:28:20 --> Helper loaded: url_helper
INFO - 2018-04-24 23:28:20 --> Helper loaded: form_helper
INFO - 2018-04-24 23:28:20 --> Helper loaded: language_helper
DEBUG - 2018-04-24 23:28:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-24 23:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-24 23:28:21 --> User Agent Class Initialized
INFO - 2018-04-24 23:28:21 --> Controller Class Initialized
INFO - 2018-04-24 23:28:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-24 23:28:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-24 23:28:21 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-24 23:28:21 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-24 23:28:21 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-24 23:28:21 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-24 23:28:21 --> Final output sent to browser
DEBUG - 2018-04-24 23:28:21 --> Total execution time: 0.3073
INFO - 2018-04-24 23:28:22 --> Config Class Initialized
INFO - 2018-04-24 23:28:22 --> Hooks Class Initialized
DEBUG - 2018-04-24 23:28:22 --> UTF-8 Support Enabled
INFO - 2018-04-24 23:28:22 --> Utf8 Class Initialized
INFO - 2018-04-24 23:28:22 --> URI Class Initialized
INFO - 2018-04-24 23:28:22 --> Router Class Initialized
INFO - 2018-04-24 23:28:22 --> Output Class Initialized
INFO - 2018-04-24 23:28:23 --> Security Class Initialized
DEBUG - 2018-04-24 23:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-24 23:28:23 --> CSRF cookie sent
INFO - 2018-04-24 23:28:23 --> Input Class Initialized
INFO - 2018-04-24 23:28:23 --> Language Class Initialized
ERROR - 2018-04-24 23:28:23 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-24 23:28:41 --> Config Class Initialized
INFO - 2018-04-24 23:28:41 --> Hooks Class Initialized
DEBUG - 2018-04-24 23:28:41 --> UTF-8 Support Enabled
INFO - 2018-04-24 23:28:41 --> Utf8 Class Initialized
INFO - 2018-04-24 23:28:41 --> URI Class Initialized
DEBUG - 2018-04-24 23:28:41 --> No URI present. Default controller set.
INFO - 2018-04-24 23:28:41 --> Router Class Initialized
INFO - 2018-04-24 23:28:41 --> Output Class Initialized
INFO - 2018-04-24 23:28:41 --> Security Class Initialized
DEBUG - 2018-04-24 23:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-24 23:28:41 --> CSRF cookie sent
INFO - 2018-04-24 23:28:41 --> Input Class Initialized
INFO - 2018-04-24 23:28:41 --> Language Class Initialized
INFO - 2018-04-24 23:28:41 --> Loader Class Initialized
INFO - 2018-04-24 23:28:41 --> Helper loaded: url_helper
INFO - 2018-04-24 23:28:41 --> Helper loaded: form_helper
INFO - 2018-04-24 23:28:41 --> Helper loaded: language_helper
DEBUG - 2018-04-24 23:28:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-24 23:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-24 23:28:41 --> User Agent Class Initialized
INFO - 2018-04-24 23:28:41 --> Controller Class Initialized
INFO - 2018-04-24 23:28:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-24 23:28:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-24 23:28:41 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-24 23:28:41 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-24 23:28:41 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-24 23:28:41 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-24 23:28:41 --> Final output sent to browser
DEBUG - 2018-04-24 23:28:41 --> Total execution time: 0.3164
INFO - 2018-04-24 23:28:43 --> Config Class Initialized
INFO - 2018-04-24 23:28:43 --> Hooks Class Initialized
DEBUG - 2018-04-24 23:28:43 --> UTF-8 Support Enabled
INFO - 2018-04-24 23:28:43 --> Utf8 Class Initialized
INFO - 2018-04-24 23:28:43 --> URI Class Initialized
INFO - 2018-04-24 23:28:43 --> Router Class Initialized
INFO - 2018-04-24 23:28:43 --> Output Class Initialized
INFO - 2018-04-24 23:28:43 --> Security Class Initialized
DEBUG - 2018-04-24 23:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-24 23:28:43 --> CSRF cookie sent
INFO - 2018-04-24 23:28:43 --> Input Class Initialized
INFO - 2018-04-24 23:28:43 --> Language Class Initialized
ERROR - 2018-04-24 23:28:43 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-24 23:43:44 --> Config Class Initialized
INFO - 2018-04-24 23:43:44 --> Hooks Class Initialized
DEBUG - 2018-04-24 23:43:44 --> UTF-8 Support Enabled
INFO - 2018-04-24 23:43:44 --> Utf8 Class Initialized
INFO - 2018-04-24 23:43:44 --> URI Class Initialized
DEBUG - 2018-04-24 23:43:44 --> No URI present. Default controller set.
INFO - 2018-04-24 23:43:44 --> Router Class Initialized
INFO - 2018-04-24 23:43:44 --> Output Class Initialized
INFO - 2018-04-24 23:43:44 --> Security Class Initialized
DEBUG - 2018-04-24 23:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-24 23:43:44 --> CSRF cookie sent
INFO - 2018-04-24 23:43:44 --> Input Class Initialized
INFO - 2018-04-24 23:43:44 --> Language Class Initialized
INFO - 2018-04-24 23:43:44 --> Loader Class Initialized
INFO - 2018-04-24 23:43:44 --> Helper loaded: url_helper
INFO - 2018-04-24 23:43:44 --> Helper loaded: form_helper
INFO - 2018-04-24 23:43:44 --> Helper loaded: language_helper
DEBUG - 2018-04-24 23:43:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-24 23:43:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-24 23:43:44 --> User Agent Class Initialized
INFO - 2018-04-24 23:43:44 --> Controller Class Initialized
INFO - 2018-04-24 23:43:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-24 23:43:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-24 23:43:44 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-24 23:43:44 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-24 23:43:44 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-24 23:43:44 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-24 23:43:44 --> Final output sent to browser
DEBUG - 2018-04-24 23:43:44 --> Total execution time: 0.2699
INFO - 2018-04-24 23:43:46 --> Config Class Initialized
INFO - 2018-04-24 23:43:46 --> Hooks Class Initialized
DEBUG - 2018-04-24 23:43:46 --> UTF-8 Support Enabled
INFO - 2018-04-24 23:43:46 --> Utf8 Class Initialized
INFO - 2018-04-24 23:43:46 --> URI Class Initialized
INFO - 2018-04-24 23:43:46 --> Router Class Initialized
INFO - 2018-04-24 23:43:46 --> Output Class Initialized
INFO - 2018-04-24 23:43:46 --> Security Class Initialized
DEBUG - 2018-04-24 23:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-24 23:43:46 --> CSRF cookie sent
INFO - 2018-04-24 23:43:46 --> Input Class Initialized
INFO - 2018-04-24 23:43:46 --> Language Class Initialized
ERROR - 2018-04-24 23:43:46 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-24 23:44:17 --> Config Class Initialized
INFO - 2018-04-24 23:44:17 --> Hooks Class Initialized
DEBUG - 2018-04-24 23:44:17 --> UTF-8 Support Enabled
INFO - 2018-04-24 23:44:17 --> Utf8 Class Initialized
INFO - 2018-04-24 23:44:17 --> URI Class Initialized
DEBUG - 2018-04-24 23:44:17 --> No URI present. Default controller set.
INFO - 2018-04-24 23:44:17 --> Router Class Initialized
INFO - 2018-04-24 23:44:17 --> Output Class Initialized
INFO - 2018-04-24 23:44:17 --> Security Class Initialized
DEBUG - 2018-04-24 23:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-24 23:44:17 --> CSRF cookie sent
INFO - 2018-04-24 23:44:17 --> Input Class Initialized
INFO - 2018-04-24 23:44:17 --> Language Class Initialized
INFO - 2018-04-24 23:44:17 --> Loader Class Initialized
INFO - 2018-04-24 23:44:17 --> Helper loaded: url_helper
INFO - 2018-04-24 23:44:17 --> Helper loaded: form_helper
INFO - 2018-04-24 23:44:17 --> Helper loaded: language_helper
DEBUG - 2018-04-24 23:44:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-24 23:44:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-24 23:44:17 --> User Agent Class Initialized
INFO - 2018-04-24 23:44:17 --> Controller Class Initialized
INFO - 2018-04-24 23:44:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-24 23:44:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-24 23:44:17 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-24 23:44:17 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-24 23:44:17 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-24 23:44:17 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-24 23:44:17 --> Final output sent to browser
DEBUG - 2018-04-24 23:44:17 --> Total execution time: 0.2992
INFO - 2018-04-24 23:44:18 --> Config Class Initialized
INFO - 2018-04-24 23:44:18 --> Hooks Class Initialized
DEBUG - 2018-04-24 23:44:18 --> UTF-8 Support Enabled
INFO - 2018-04-24 23:44:18 --> Utf8 Class Initialized
INFO - 2018-04-24 23:44:18 --> URI Class Initialized
INFO - 2018-04-24 23:44:18 --> Router Class Initialized
INFO - 2018-04-24 23:44:18 --> Output Class Initialized
INFO - 2018-04-24 23:44:18 --> Security Class Initialized
DEBUG - 2018-04-24 23:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-24 23:44:18 --> CSRF cookie sent
INFO - 2018-04-24 23:44:18 --> Input Class Initialized
INFO - 2018-04-24 23:44:18 --> Language Class Initialized
ERROR - 2018-04-24 23:44:18 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-24 23:44:30 --> Config Class Initialized
INFO - 2018-04-24 23:44:30 --> Hooks Class Initialized
DEBUG - 2018-04-24 23:44:30 --> UTF-8 Support Enabled
INFO - 2018-04-24 23:44:30 --> Utf8 Class Initialized
INFO - 2018-04-24 23:44:30 --> URI Class Initialized
DEBUG - 2018-04-24 23:44:30 --> No URI present. Default controller set.
INFO - 2018-04-24 23:44:30 --> Router Class Initialized
INFO - 2018-04-24 23:44:31 --> Output Class Initialized
INFO - 2018-04-24 23:44:31 --> Security Class Initialized
DEBUG - 2018-04-24 23:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-24 23:44:31 --> CSRF cookie sent
INFO - 2018-04-24 23:44:31 --> Input Class Initialized
INFO - 2018-04-24 23:44:31 --> Language Class Initialized
INFO - 2018-04-24 23:44:31 --> Loader Class Initialized
INFO - 2018-04-24 23:44:31 --> Helper loaded: url_helper
INFO - 2018-04-24 23:44:31 --> Helper loaded: form_helper
INFO - 2018-04-24 23:44:31 --> Helper loaded: language_helper
DEBUG - 2018-04-24 23:44:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-24 23:44:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-24 23:44:31 --> User Agent Class Initialized
INFO - 2018-04-24 23:44:31 --> Controller Class Initialized
INFO - 2018-04-24 23:44:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-24 23:44:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-24 23:44:31 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-24 23:44:31 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-24 23:44:31 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-24 23:44:31 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-24 23:44:31 --> Final output sent to browser
DEBUG - 2018-04-24 23:44:31 --> Total execution time: 0.3139
INFO - 2018-04-24 23:44:32 --> Config Class Initialized
INFO - 2018-04-24 23:44:32 --> Hooks Class Initialized
DEBUG - 2018-04-24 23:44:32 --> UTF-8 Support Enabled
INFO - 2018-04-24 23:44:32 --> Utf8 Class Initialized
INFO - 2018-04-24 23:44:32 --> URI Class Initialized
INFO - 2018-04-24 23:44:32 --> Router Class Initialized
INFO - 2018-04-24 23:44:32 --> Output Class Initialized
INFO - 2018-04-24 23:44:32 --> Security Class Initialized
DEBUG - 2018-04-24 23:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-24 23:44:32 --> CSRF cookie sent
INFO - 2018-04-24 23:44:32 --> Input Class Initialized
INFO - 2018-04-24 23:44:32 --> Language Class Initialized
ERROR - 2018-04-24 23:44:32 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-24 23:44:59 --> Config Class Initialized
INFO - 2018-04-24 23:44:59 --> Hooks Class Initialized
DEBUG - 2018-04-24 23:44:59 --> UTF-8 Support Enabled
INFO - 2018-04-24 23:44:59 --> Utf8 Class Initialized
INFO - 2018-04-24 23:44:59 --> URI Class Initialized
DEBUG - 2018-04-24 23:44:59 --> No URI present. Default controller set.
INFO - 2018-04-24 23:44:59 --> Router Class Initialized
INFO - 2018-04-24 23:44:59 --> Output Class Initialized
INFO - 2018-04-24 23:44:59 --> Security Class Initialized
DEBUG - 2018-04-24 23:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-24 23:44:59 --> CSRF cookie sent
INFO - 2018-04-24 23:44:59 --> Input Class Initialized
INFO - 2018-04-24 23:44:59 --> Language Class Initialized
INFO - 2018-04-24 23:44:59 --> Loader Class Initialized
INFO - 2018-04-24 23:44:59 --> Helper loaded: url_helper
INFO - 2018-04-24 23:44:59 --> Helper loaded: form_helper
INFO - 2018-04-24 23:44:59 --> Helper loaded: language_helper
DEBUG - 2018-04-24 23:44:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-24 23:44:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-24 23:44:59 --> User Agent Class Initialized
INFO - 2018-04-24 23:44:59 --> Controller Class Initialized
INFO - 2018-04-24 23:44:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-24 23:44:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-24 23:44:59 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-24 23:44:59 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-24 23:44:59 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-24 23:44:59 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-24 23:44:59 --> Final output sent to browser
DEBUG - 2018-04-24 23:44:59 --> Total execution time: 0.3267
INFO - 2018-04-24 23:45:00 --> Config Class Initialized
INFO - 2018-04-24 23:45:00 --> Hooks Class Initialized
DEBUG - 2018-04-24 23:45:00 --> UTF-8 Support Enabled
INFO - 2018-04-24 23:45:00 --> Utf8 Class Initialized
INFO - 2018-04-24 23:45:00 --> URI Class Initialized
INFO - 2018-04-24 23:45:00 --> Router Class Initialized
INFO - 2018-04-24 23:45:00 --> Output Class Initialized
INFO - 2018-04-24 23:45:00 --> Security Class Initialized
DEBUG - 2018-04-24 23:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-24 23:45:00 --> CSRF cookie sent
INFO - 2018-04-24 23:45:01 --> Input Class Initialized
INFO - 2018-04-24 23:45:01 --> Language Class Initialized
ERROR - 2018-04-24 23:45:01 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-24 23:45:38 --> Config Class Initialized
INFO - 2018-04-24 23:45:38 --> Hooks Class Initialized
DEBUG - 2018-04-24 23:45:38 --> UTF-8 Support Enabled
INFO - 2018-04-24 23:45:38 --> Utf8 Class Initialized
INFO - 2018-04-24 23:45:38 --> URI Class Initialized
DEBUG - 2018-04-24 23:45:38 --> No URI present. Default controller set.
INFO - 2018-04-24 23:45:38 --> Router Class Initialized
INFO - 2018-04-24 23:45:38 --> Output Class Initialized
INFO - 2018-04-24 23:45:38 --> Security Class Initialized
DEBUG - 2018-04-24 23:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-24 23:45:38 --> CSRF cookie sent
INFO - 2018-04-24 23:45:38 --> Input Class Initialized
INFO - 2018-04-24 23:45:38 --> Language Class Initialized
INFO - 2018-04-24 23:45:38 --> Loader Class Initialized
INFO - 2018-04-24 23:45:38 --> Helper loaded: url_helper
INFO - 2018-04-24 23:45:38 --> Helper loaded: form_helper
INFO - 2018-04-24 23:45:38 --> Helper loaded: language_helper
DEBUG - 2018-04-24 23:45:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-24 23:45:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-24 23:45:38 --> User Agent Class Initialized
INFO - 2018-04-24 23:45:38 --> Controller Class Initialized
INFO - 2018-04-24 23:45:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-24 23:45:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-24 23:45:38 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-24 23:45:38 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-24 23:45:38 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-24 23:45:38 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-24 23:45:38 --> Final output sent to browser
DEBUG - 2018-04-24 23:45:38 --> Total execution time: 0.3207
INFO - 2018-04-24 23:45:39 --> Config Class Initialized
INFO - 2018-04-24 23:45:39 --> Hooks Class Initialized
DEBUG - 2018-04-24 23:45:39 --> UTF-8 Support Enabled
INFO - 2018-04-24 23:45:39 --> Utf8 Class Initialized
INFO - 2018-04-24 23:45:39 --> URI Class Initialized
INFO - 2018-04-24 23:45:39 --> Router Class Initialized
INFO - 2018-04-24 23:45:39 --> Output Class Initialized
INFO - 2018-04-24 23:45:39 --> Security Class Initialized
DEBUG - 2018-04-24 23:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-24 23:45:40 --> CSRF cookie sent
INFO - 2018-04-24 23:45:40 --> Input Class Initialized
INFO - 2018-04-24 23:45:40 --> Language Class Initialized
ERROR - 2018-04-24 23:45:40 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-24 23:46:11 --> Config Class Initialized
INFO - 2018-04-24 23:46:11 --> Hooks Class Initialized
DEBUG - 2018-04-24 23:46:11 --> UTF-8 Support Enabled
INFO - 2018-04-24 23:46:11 --> Utf8 Class Initialized
INFO - 2018-04-24 23:46:11 --> URI Class Initialized
DEBUG - 2018-04-24 23:46:11 --> No URI present. Default controller set.
INFO - 2018-04-24 23:46:11 --> Router Class Initialized
INFO - 2018-04-24 23:46:11 --> Output Class Initialized
INFO - 2018-04-24 23:46:11 --> Security Class Initialized
DEBUG - 2018-04-24 23:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-24 23:46:11 --> CSRF cookie sent
INFO - 2018-04-24 23:46:11 --> Input Class Initialized
INFO - 2018-04-24 23:46:11 --> Language Class Initialized
INFO - 2018-04-24 23:46:11 --> Loader Class Initialized
INFO - 2018-04-24 23:46:11 --> Helper loaded: url_helper
INFO - 2018-04-24 23:46:11 --> Helper loaded: form_helper
INFO - 2018-04-24 23:46:11 --> Helper loaded: language_helper
DEBUG - 2018-04-24 23:46:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-24 23:46:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-24 23:46:11 --> User Agent Class Initialized
INFO - 2018-04-24 23:46:11 --> Controller Class Initialized
INFO - 2018-04-24 23:46:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-24 23:46:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-24 23:46:11 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-24 23:46:11 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-24 23:46:11 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-24 23:46:11 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-24 23:46:11 --> Final output sent to browser
DEBUG - 2018-04-24 23:46:11 --> Total execution time: 0.3150
INFO - 2018-04-24 23:46:13 --> Config Class Initialized
INFO - 2018-04-24 23:46:13 --> Hooks Class Initialized
DEBUG - 2018-04-24 23:46:13 --> UTF-8 Support Enabled
INFO - 2018-04-24 23:46:13 --> Utf8 Class Initialized
INFO - 2018-04-24 23:46:13 --> URI Class Initialized
INFO - 2018-04-24 23:46:13 --> Router Class Initialized
INFO - 2018-04-24 23:46:13 --> Output Class Initialized
INFO - 2018-04-24 23:46:13 --> Security Class Initialized
DEBUG - 2018-04-24 23:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-24 23:46:13 --> CSRF cookie sent
INFO - 2018-04-24 23:46:13 --> Input Class Initialized
INFO - 2018-04-24 23:46:13 --> Language Class Initialized
ERROR - 2018-04-24 23:46:13 --> 404 Page Not Found: Revolution/assets

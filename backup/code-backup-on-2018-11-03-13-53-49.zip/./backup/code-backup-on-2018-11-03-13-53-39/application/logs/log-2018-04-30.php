<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-04-30 21:59:42 --> Config Class Initialized
INFO - 2018-04-30 21:59:42 --> Hooks Class Initialized
DEBUG - 2018-04-30 21:59:42 --> UTF-8 Support Enabled
INFO - 2018-04-30 21:59:42 --> Utf8 Class Initialized
INFO - 2018-04-30 21:59:42 --> URI Class Initialized
DEBUG - 2018-04-30 21:59:42 --> No URI present. Default controller set.
INFO - 2018-04-30 21:59:42 --> Router Class Initialized
INFO - 2018-04-30 21:59:42 --> Output Class Initialized
INFO - 2018-04-30 21:59:42 --> Security Class Initialized
DEBUG - 2018-04-30 21:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-30 21:59:43 --> CSRF cookie sent
INFO - 2018-04-30 21:59:43 --> Input Class Initialized
INFO - 2018-04-30 21:59:43 --> Language Class Initialized
INFO - 2018-04-30 21:59:43 --> Loader Class Initialized
INFO - 2018-04-30 21:59:43 --> Helper loaded: url_helper
INFO - 2018-04-30 21:59:43 --> Helper loaded: form_helper
INFO - 2018-04-30 21:59:43 --> Helper loaded: language_helper
DEBUG - 2018-04-30 21:59:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-30 21:59:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-30 21:59:43 --> User Agent Class Initialized
INFO - 2018-04-30 21:59:43 --> Controller Class Initialized
INFO - 2018-04-30 21:59:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-30 21:59:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-30 21:59:43 --> Pixel_Model class loaded
INFO - 2018-04-30 21:59:43 --> Database Driver Class Initialized
INFO - 2018-04-30 21:59:43 --> Model "QuestionsModel" initialized
INFO - 2018-04-30 21:59:43 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-30 21:59:43 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-30 21:59:44 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-30 21:59:44 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-30 21:59:44 --> Final output sent to browser
DEBUG - 2018-04-30 21:59:44 --> Total execution time: 1.4570
INFO - 2018-04-30 21:59:46 --> Config Class Initialized
INFO - 2018-04-30 21:59:46 --> Hooks Class Initialized
DEBUG - 2018-04-30 21:59:46 --> UTF-8 Support Enabled
INFO - 2018-04-30 21:59:46 --> Utf8 Class Initialized
INFO - 2018-04-30 21:59:46 --> URI Class Initialized
INFO - 2018-04-30 21:59:46 --> Router Class Initialized
INFO - 2018-04-30 21:59:46 --> Output Class Initialized
INFO - 2018-04-30 21:59:46 --> Security Class Initialized
DEBUG - 2018-04-30 21:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-30 21:59:46 --> CSRF cookie sent
INFO - 2018-04-30 21:59:46 --> Input Class Initialized
INFO - 2018-04-30 21:59:46 --> Language Class Initialized
ERROR - 2018-04-30 21:59:46 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-30 21:59:48 --> Config Class Initialized
INFO - 2018-04-30 21:59:48 --> Hooks Class Initialized
DEBUG - 2018-04-30 21:59:48 --> UTF-8 Support Enabled
INFO - 2018-04-30 21:59:48 --> Utf8 Class Initialized
INFO - 2018-04-30 21:59:48 --> URI Class Initialized
INFO - 2018-04-30 21:59:48 --> Router Class Initialized
INFO - 2018-04-30 21:59:48 --> Output Class Initialized
INFO - 2018-04-30 21:59:48 --> Security Class Initialized
DEBUG - 2018-04-30 21:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-30 21:59:48 --> CSRF cookie sent
INFO - 2018-04-30 21:59:48 --> Input Class Initialized
INFO - 2018-04-30 21:59:48 --> Language Class Initialized
INFO - 2018-04-30 21:59:48 --> Loader Class Initialized
INFO - 2018-04-30 21:59:48 --> Helper loaded: url_helper
INFO - 2018-04-30 21:59:48 --> Helper loaded: form_helper
INFO - 2018-04-30 21:59:48 --> Helper loaded: language_helper
DEBUG - 2018-04-30 21:59:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-30 21:59:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-30 21:59:48 --> User Agent Class Initialized
INFO - 2018-04-30 21:59:48 --> Controller Class Initialized
INFO - 2018-04-30 21:59:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-30 21:59:48 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-30 21:59:48 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-30 21:59:48 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-30 21:59:48 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-30 21:59:48 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-30 21:59:48 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-30 21:59:48 --> Could not find the language line "req_email"
INFO - 2018-04-30 21:59:48 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-04-30 21:59:48 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-30 21:59:48 --> Final output sent to browser
DEBUG - 2018-04-30 21:59:48 --> Total execution time: 0.5061
INFO - 2018-04-30 21:59:59 --> Config Class Initialized
INFO - 2018-04-30 21:59:59 --> Hooks Class Initialized
DEBUG - 2018-04-30 21:59:59 --> UTF-8 Support Enabled
INFO - 2018-04-30 21:59:59 --> Utf8 Class Initialized
INFO - 2018-04-30 21:59:59 --> URI Class Initialized
INFO - 2018-04-30 21:59:59 --> Router Class Initialized
INFO - 2018-04-30 21:59:59 --> Output Class Initialized
INFO - 2018-04-30 21:59:59 --> Security Class Initialized
DEBUG - 2018-04-30 21:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-30 21:59:59 --> CSRF cookie sent
INFO - 2018-04-30 21:59:59 --> CSRF token verified
INFO - 2018-04-30 21:59:59 --> Input Class Initialized
INFO - 2018-04-30 21:59:59 --> Language Class Initialized
INFO - 2018-04-30 22:00:00 --> Loader Class Initialized
INFO - 2018-04-30 22:00:00 --> Helper loaded: url_helper
INFO - 2018-04-30 22:00:00 --> Helper loaded: form_helper
INFO - 2018-04-30 22:00:00 --> Helper loaded: language_helper
DEBUG - 2018-04-30 22:00:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-30 22:00:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-30 22:00:00 --> User Agent Class Initialized
INFO - 2018-04-30 22:00:00 --> Controller Class Initialized
INFO - 2018-04-30 22:00:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-30 22:00:00 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-04-30 22:00:00 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-30 22:00:00 --> Form Validation Class Initialized
INFO - 2018-04-30 22:00:00 --> Pixel_Model class loaded
INFO - 2018-04-30 22:00:00 --> Database Driver Class Initialized
INFO - 2018-04-30 22:00:00 --> Model "AuthenticationModel" initialized
INFO - 2018-04-30 22:00:01 --> Config Class Initialized
INFO - 2018-04-30 22:00:01 --> Hooks Class Initialized
DEBUG - 2018-04-30 22:00:01 --> UTF-8 Support Enabled
INFO - 2018-04-30 22:00:01 --> Utf8 Class Initialized
INFO - 2018-04-30 22:00:01 --> URI Class Initialized
DEBUG - 2018-04-30 22:00:01 --> No URI present. Default controller set.
INFO - 2018-04-30 22:00:01 --> Router Class Initialized
INFO - 2018-04-30 22:00:01 --> Output Class Initialized
INFO - 2018-04-30 22:00:01 --> Security Class Initialized
DEBUG - 2018-04-30 22:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-30 22:00:01 --> CSRF cookie sent
INFO - 2018-04-30 22:00:01 --> Input Class Initialized
INFO - 2018-04-30 22:00:01 --> Language Class Initialized
INFO - 2018-04-30 22:00:01 --> Loader Class Initialized
INFO - 2018-04-30 22:00:01 --> Helper loaded: url_helper
INFO - 2018-04-30 22:00:01 --> Helper loaded: form_helper
INFO - 2018-04-30 22:00:01 --> Helper loaded: language_helper
DEBUG - 2018-04-30 22:00:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-30 22:00:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-30 22:00:01 --> User Agent Class Initialized
INFO - 2018-04-30 22:00:01 --> Controller Class Initialized
INFO - 2018-04-30 22:00:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-30 22:00:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-30 22:00:01 --> Pixel_Model class loaded
INFO - 2018-04-30 22:00:01 --> Database Driver Class Initialized
INFO - 2018-04-30 22:00:01 --> Model "QuestionsModel" initialized
INFO - 2018-04-30 22:00:01 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-30 22:00:01 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-30 22:00:01 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-30 22:00:01 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-30 22:00:01 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-30 22:00:01 --> Final output sent to browser
DEBUG - 2018-04-30 22:00:01 --> Total execution time: 0.3011
INFO - 2018-04-30 22:00:02 --> Config Class Initialized
INFO - 2018-04-30 22:00:02 --> Hooks Class Initialized
DEBUG - 2018-04-30 22:00:02 --> UTF-8 Support Enabled
INFO - 2018-04-30 22:00:02 --> Utf8 Class Initialized
INFO - 2018-04-30 22:00:02 --> URI Class Initialized
INFO - 2018-04-30 22:00:02 --> Router Class Initialized
INFO - 2018-04-30 22:00:02 --> Output Class Initialized
INFO - 2018-04-30 22:00:02 --> Security Class Initialized
DEBUG - 2018-04-30 22:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-30 22:00:02 --> CSRF cookie sent
INFO - 2018-04-30 22:00:02 --> Input Class Initialized
INFO - 2018-04-30 22:00:02 --> Language Class Initialized
ERROR - 2018-04-30 22:00:02 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-30 22:00:07 --> Config Class Initialized
INFO - 2018-04-30 22:00:07 --> Hooks Class Initialized
DEBUG - 2018-04-30 22:00:07 --> UTF-8 Support Enabled
INFO - 2018-04-30 22:00:07 --> Utf8 Class Initialized
INFO - 2018-04-30 22:00:07 --> URI Class Initialized
INFO - 2018-04-30 22:00:07 --> Router Class Initialized
INFO - 2018-04-30 22:00:07 --> Output Class Initialized
INFO - 2018-04-30 22:00:07 --> Security Class Initialized
DEBUG - 2018-04-30 22:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-30 22:00:07 --> CSRF cookie sent
INFO - 2018-04-30 22:00:07 --> Input Class Initialized
INFO - 2018-04-30 22:00:07 --> Language Class Initialized
INFO - 2018-04-30 22:00:07 --> Loader Class Initialized
INFO - 2018-04-30 22:00:07 --> Helper loaded: url_helper
INFO - 2018-04-30 22:00:07 --> Helper loaded: form_helper
INFO - 2018-04-30 22:00:07 --> Helper loaded: language_helper
DEBUG - 2018-04-30 22:00:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-30 22:00:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-30 22:00:07 --> User Agent Class Initialized
INFO - 2018-04-30 22:00:07 --> Controller Class Initialized
INFO - 2018-04-30 22:00:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-30 22:00:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-30 22:00:08 --> Pixel_Model class loaded
INFO - 2018-04-30 22:00:08 --> Database Driver Class Initialized
INFO - 2018-04-30 22:00:08 --> Model "MyAccountModel" initialized
INFO - 2018-04-30 22:00:08 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-30 22:00:08 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-30 22:00:08 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-30 22:00:08 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-30 22:00:08 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-30 22:00:08 --> File loaded: E:\www\yacopoo\application\views\myaccount/application_list.php
INFO - 2018-04-30 22:00:08 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-30 22:00:08 --> Final output sent to browser
DEBUG - 2018-04-30 22:00:08 --> Total execution time: 0.4013
INFO - 2018-04-30 22:00:14 --> Config Class Initialized
INFO - 2018-04-30 22:00:14 --> Hooks Class Initialized
DEBUG - 2018-04-30 22:00:14 --> UTF-8 Support Enabled
INFO - 2018-04-30 22:00:14 --> Utf8 Class Initialized
INFO - 2018-04-30 22:00:14 --> URI Class Initialized
INFO - 2018-04-30 22:00:14 --> Router Class Initialized
INFO - 2018-04-30 22:00:14 --> Output Class Initialized
INFO - 2018-04-30 22:00:14 --> Security Class Initialized
DEBUG - 2018-04-30 22:00:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-30 22:00:14 --> CSRF cookie sent
INFO - 2018-04-30 22:00:14 --> Input Class Initialized
INFO - 2018-04-30 22:00:14 --> Language Class Initialized
INFO - 2018-04-30 22:00:14 --> Loader Class Initialized
INFO - 2018-04-30 22:00:14 --> Helper loaded: url_helper
INFO - 2018-04-30 22:00:14 --> Helper loaded: form_helper
INFO - 2018-04-30 22:00:14 --> Helper loaded: language_helper
DEBUG - 2018-04-30 22:00:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-30 22:00:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-30 22:00:14 --> User Agent Class Initialized
INFO - 2018-04-30 22:00:14 --> Controller Class Initialized
INFO - 2018-04-30 22:00:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-30 22:00:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-30 22:00:14 --> Pixel_Model class loaded
INFO - 2018-04-30 22:00:14 --> Database Driver Class Initialized
INFO - 2018-04-30 22:00:14 --> Model "MyAccountModel" initialized
INFO - 2018-04-30 22:00:14 --> Config Class Initialized
INFO - 2018-04-30 22:00:14 --> Hooks Class Initialized
DEBUG - 2018-04-30 22:00:14 --> UTF-8 Support Enabled
INFO - 2018-04-30 22:00:14 --> Utf8 Class Initialized
INFO - 2018-04-30 22:00:14 --> URI Class Initialized
INFO - 2018-04-30 22:00:14 --> Router Class Initialized
INFO - 2018-04-30 22:00:14 --> Output Class Initialized
INFO - 2018-04-30 22:00:14 --> Security Class Initialized
DEBUG - 2018-04-30 22:00:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-30 22:00:14 --> CSRF cookie sent
INFO - 2018-04-30 22:00:14 --> Input Class Initialized
INFO - 2018-04-30 22:00:14 --> Language Class Initialized
INFO - 2018-04-30 22:00:14 --> Loader Class Initialized
INFO - 2018-04-30 22:00:14 --> Helper loaded: url_helper
INFO - 2018-04-30 22:00:14 --> Helper loaded: form_helper
INFO - 2018-04-30 22:00:14 --> Helper loaded: language_helper
DEBUG - 2018-04-30 22:00:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-30 22:00:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-30 22:00:14 --> User Agent Class Initialized
INFO - 2018-04-30 22:00:14 --> Controller Class Initialized
INFO - 2018-04-30 22:00:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-30 22:00:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-30 22:00:14 --> Pixel_Model class loaded
INFO - 2018-04-30 22:00:14 --> Database Driver Class Initialized
INFO - 2018-04-30 22:00:14 --> Model "QuestionsModel" initialized
INFO - 2018-04-30 22:00:14 --> Database Driver Class Initialized
INFO - 2018-04-30 22:00:14 --> Model "QuestionsModel" initialized
INFO - 2018-04-30 22:00:14 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-30 22:00:14 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-30 22:00:14 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-30 22:00:14 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-30 22:00:15 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-30 22:00:15 --> File loaded: E:\www\yacopoo\application\views\shared/_bar.php
INFO - 2018-04-30 22:00:15 --> File loaded: E:\www\yacopoo\application\views\shared/_buttons.php
INFO - 2018-04-30 22:00:15 --> File loaded: E:\www\yacopoo\application\views\questions/influencer_info.php
INFO - 2018-04-30 22:00:15 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-30 22:00:15 --> Final output sent to browser
DEBUG - 2018-04-30 22:00:15 --> Total execution time: 0.4025
INFO - 2018-04-30 22:00:36 --> Config Class Initialized
INFO - 2018-04-30 22:00:36 --> Hooks Class Initialized
DEBUG - 2018-04-30 22:00:36 --> UTF-8 Support Enabled
INFO - 2018-04-30 22:00:36 --> Utf8 Class Initialized
INFO - 2018-04-30 22:00:36 --> URI Class Initialized
INFO - 2018-04-30 22:00:36 --> Router Class Initialized
INFO - 2018-04-30 22:00:36 --> Output Class Initialized
INFO - 2018-04-30 22:00:36 --> Security Class Initialized
DEBUG - 2018-04-30 22:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-30 22:00:36 --> CSRF cookie sent
INFO - 2018-04-30 22:00:36 --> CSRF token verified
INFO - 2018-04-30 22:00:36 --> Input Class Initialized
INFO - 2018-04-30 22:00:36 --> Language Class Initialized
INFO - 2018-04-30 22:00:36 --> Loader Class Initialized
INFO - 2018-04-30 22:00:36 --> Helper loaded: url_helper
INFO - 2018-04-30 22:00:36 --> Helper loaded: form_helper
INFO - 2018-04-30 22:00:36 --> Helper loaded: language_helper
DEBUG - 2018-04-30 22:00:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-30 22:00:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-30 22:00:36 --> User Agent Class Initialized
INFO - 2018-04-30 22:00:36 --> Controller Class Initialized
INFO - 2018-04-30 22:00:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-30 22:00:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-30 22:00:36 --> Pixel_Model class loaded
INFO - 2018-04-30 22:00:36 --> Database Driver Class Initialized
INFO - 2018-04-30 22:00:36 --> Model "QuestionsModel" initialized
INFO - 2018-04-30 22:00:36 --> Form Validation Class Initialized
INFO - 2018-04-30 22:00:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-30 22:00:36 --> Config Class Initialized
INFO - 2018-04-30 22:00:36 --> Hooks Class Initialized
DEBUG - 2018-04-30 22:00:36 --> UTF-8 Support Enabled
INFO - 2018-04-30 22:00:36 --> Utf8 Class Initialized
INFO - 2018-04-30 22:00:36 --> URI Class Initialized
INFO - 2018-04-30 22:00:36 --> Router Class Initialized
INFO - 2018-04-30 22:00:36 --> Output Class Initialized
INFO - 2018-04-30 22:00:36 --> Security Class Initialized
DEBUG - 2018-04-30 22:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-30 22:00:36 --> CSRF cookie sent
INFO - 2018-04-30 22:00:36 --> Input Class Initialized
INFO - 2018-04-30 22:00:36 --> Language Class Initialized
INFO - 2018-04-30 22:00:37 --> Loader Class Initialized
INFO - 2018-04-30 22:00:37 --> Helper loaded: url_helper
INFO - 2018-04-30 22:00:37 --> Helper loaded: form_helper
INFO - 2018-04-30 22:00:37 --> Helper loaded: language_helper
DEBUG - 2018-04-30 22:00:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-30 22:00:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-30 22:00:37 --> User Agent Class Initialized
INFO - 2018-04-30 22:00:37 --> Controller Class Initialized
INFO - 2018-04-30 22:00:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-30 22:00:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-30 22:00:37 --> Pixel_Model class loaded
INFO - 2018-04-30 22:00:37 --> Database Driver Class Initialized
INFO - 2018-04-30 22:00:37 --> Model "QuestionsModel" initialized
INFO - 2018-04-30 22:00:37 --> Database Driver Class Initialized
INFO - 2018-04-30 22:00:37 --> Model "QuestionsModel" initialized
INFO - 2018-04-30 22:00:37 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-30 22:00:37 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-30 22:00:37 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-30 22:00:37 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-30 22:00:37 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-30 22:00:37 --> File loaded: E:\www\yacopoo\application\views\shared/_bar.php
INFO - 2018-04-30 22:00:37 --> File loaded: E:\www\yacopoo\application\views\shared/_buttons.php
INFO - 2018-04-30 22:00:37 --> File loaded: E:\www\yacopoo\application\views\questions/influencer_info.php
INFO - 2018-04-30 22:00:37 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-30 22:00:37 --> Final output sent to browser
DEBUG - 2018-04-30 22:00:37 --> Total execution time: 0.3095
INFO - 2018-04-30 22:00:40 --> Config Class Initialized
INFO - 2018-04-30 22:00:40 --> Hooks Class Initialized
DEBUG - 2018-04-30 22:00:40 --> UTF-8 Support Enabled
INFO - 2018-04-30 22:00:40 --> Utf8 Class Initialized
INFO - 2018-04-30 22:00:40 --> URI Class Initialized
INFO - 2018-04-30 22:00:40 --> Router Class Initialized
INFO - 2018-04-30 22:00:40 --> Output Class Initialized
INFO - 2018-04-30 22:00:40 --> Security Class Initialized
DEBUG - 2018-04-30 22:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-30 22:00:40 --> CSRF cookie sent
INFO - 2018-04-30 22:00:40 --> CSRF token verified
INFO - 2018-04-30 22:00:40 --> Input Class Initialized
INFO - 2018-04-30 22:00:40 --> Language Class Initialized
INFO - 2018-04-30 22:00:40 --> Loader Class Initialized
INFO - 2018-04-30 22:00:40 --> Helper loaded: url_helper
INFO - 2018-04-30 22:00:40 --> Helper loaded: form_helper
INFO - 2018-04-30 22:00:40 --> Helper loaded: language_helper
DEBUG - 2018-04-30 22:00:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-30 22:00:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-30 22:00:40 --> User Agent Class Initialized
INFO - 2018-04-30 22:00:40 --> Controller Class Initialized
INFO - 2018-04-30 22:00:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-30 22:00:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-30 22:00:40 --> Pixel_Model class loaded
INFO - 2018-04-30 22:00:40 --> Database Driver Class Initialized
INFO - 2018-04-30 22:00:40 --> Model "QuestionsModel" initialized
INFO - 2018-04-30 22:00:40 --> Form Validation Class Initialized
INFO - 2018-04-30 22:00:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-30 22:00:40 --> Config Class Initialized
INFO - 2018-04-30 22:00:40 --> Hooks Class Initialized
DEBUG - 2018-04-30 22:00:40 --> UTF-8 Support Enabled
INFO - 2018-04-30 22:00:40 --> Utf8 Class Initialized
INFO - 2018-04-30 22:00:40 --> URI Class Initialized
INFO - 2018-04-30 22:00:40 --> Router Class Initialized
INFO - 2018-04-30 22:00:40 --> Output Class Initialized
INFO - 2018-04-30 22:00:40 --> Security Class Initialized
DEBUG - 2018-04-30 22:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-30 22:00:40 --> CSRF cookie sent
INFO - 2018-04-30 22:00:40 --> Input Class Initialized
INFO - 2018-04-30 22:00:40 --> Language Class Initialized
INFO - 2018-04-30 22:00:40 --> Loader Class Initialized
INFO - 2018-04-30 22:00:40 --> Helper loaded: url_helper
INFO - 2018-04-30 22:00:40 --> Helper loaded: form_helper
INFO - 2018-04-30 22:00:40 --> Helper loaded: language_helper
DEBUG - 2018-04-30 22:00:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-30 22:00:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-30 22:00:40 --> User Agent Class Initialized
INFO - 2018-04-30 22:00:41 --> Controller Class Initialized
INFO - 2018-04-30 22:00:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-30 22:00:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-30 22:00:41 --> Pixel_Model class loaded
INFO - 2018-04-30 22:00:41 --> Database Driver Class Initialized
INFO - 2018-04-30 22:00:41 --> Model "QuestionsModel" initialized
INFO - 2018-04-30 22:00:41 --> Database Driver Class Initialized
INFO - 2018-04-30 22:00:41 --> Model "QuestionsModel" initialized
INFO - 2018-04-30 22:00:41 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-30 22:00:41 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-30 22:00:41 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-30 22:00:41 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-30 22:00:41 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-30 22:00:41 --> File loaded: E:\www\yacopoo\application\views\shared/_bar.php
INFO - 2018-04-30 22:00:41 --> File loaded: E:\www\yacopoo\application\views\shared/_buttons.php
INFO - 2018-04-30 22:00:41 --> File loaded: E:\www\yacopoo\application\views\questions/influencer_info.php
INFO - 2018-04-30 22:00:41 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-30 22:00:41 --> Final output sent to browser
DEBUG - 2018-04-30 22:00:41 --> Total execution time: 0.3329
INFO - 2018-04-30 22:01:18 --> Config Class Initialized
INFO - 2018-04-30 22:01:18 --> Hooks Class Initialized
DEBUG - 2018-04-30 22:01:18 --> UTF-8 Support Enabled
INFO - 2018-04-30 22:01:18 --> Utf8 Class Initialized
INFO - 2018-04-30 22:01:18 --> URI Class Initialized
INFO - 2018-04-30 22:01:18 --> Router Class Initialized
INFO - 2018-04-30 22:01:18 --> Output Class Initialized
INFO - 2018-04-30 22:01:18 --> Security Class Initialized
DEBUG - 2018-04-30 22:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-30 22:01:18 --> CSRF cookie sent
INFO - 2018-04-30 22:01:18 --> CSRF token verified
INFO - 2018-04-30 22:01:18 --> Input Class Initialized
INFO - 2018-04-30 22:01:18 --> Language Class Initialized
INFO - 2018-04-30 22:01:18 --> Loader Class Initialized
INFO - 2018-04-30 22:01:18 --> Helper loaded: url_helper
INFO - 2018-04-30 22:01:18 --> Helper loaded: form_helper
INFO - 2018-04-30 22:01:18 --> Helper loaded: language_helper
DEBUG - 2018-04-30 22:01:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-30 22:01:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-30 22:01:18 --> User Agent Class Initialized
INFO - 2018-04-30 22:01:18 --> Controller Class Initialized
INFO - 2018-04-30 22:01:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-30 22:01:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-30 22:01:18 --> Pixel_Model class loaded
INFO - 2018-04-30 22:01:18 --> Database Driver Class Initialized
INFO - 2018-04-30 22:01:18 --> Model "QuestionsModel" initialized
INFO - 2018-04-30 22:01:18 --> Form Validation Class Initialized
INFO - 2018-04-30 22:01:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-30 22:01:18 --> Config Class Initialized
INFO - 2018-04-30 22:01:18 --> Hooks Class Initialized
DEBUG - 2018-04-30 22:01:18 --> UTF-8 Support Enabled
INFO - 2018-04-30 22:01:18 --> Utf8 Class Initialized
INFO - 2018-04-30 22:01:18 --> URI Class Initialized
INFO - 2018-04-30 22:01:18 --> Router Class Initialized
INFO - 2018-04-30 22:01:18 --> Output Class Initialized
INFO - 2018-04-30 22:01:18 --> Security Class Initialized
DEBUG - 2018-04-30 22:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-30 22:01:18 --> CSRF cookie sent
INFO - 2018-04-30 22:01:18 --> Input Class Initialized
INFO - 2018-04-30 22:01:18 --> Language Class Initialized
INFO - 2018-04-30 22:01:18 --> Loader Class Initialized
INFO - 2018-04-30 22:01:18 --> Helper loaded: url_helper
INFO - 2018-04-30 22:01:18 --> Helper loaded: form_helper
INFO - 2018-04-30 22:01:18 --> Helper loaded: language_helper
DEBUG - 2018-04-30 22:01:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-30 22:01:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-30 22:01:18 --> User Agent Class Initialized
INFO - 2018-04-30 22:01:18 --> Controller Class Initialized
INFO - 2018-04-30 22:01:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-30 22:01:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-30 22:01:18 --> Pixel_Model class loaded
INFO - 2018-04-30 22:01:18 --> Database Driver Class Initialized
INFO - 2018-04-30 22:01:18 --> Model "QuestionsModel" initialized
INFO - 2018-04-30 22:01:18 --> Database Driver Class Initialized
INFO - 2018-04-30 22:01:18 --> Model "QuestionsModel" initialized
INFO - 2018-04-30 22:01:18 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-30 22:01:18 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-30 22:01:18 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-30 22:01:18 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-30 22:01:18 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-30 22:01:18 --> File loaded: E:\www\yacopoo\application\views\shared/_bar.php
INFO - 2018-04-30 22:01:18 --> File loaded: E:\www\yacopoo\application\views\shared/_buttons.php
INFO - 2018-04-30 22:01:18 --> File loaded: E:\www\yacopoo\application\views\questions/influencer_info.php
INFO - 2018-04-30 22:01:18 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-30 22:01:19 --> Final output sent to browser
DEBUG - 2018-04-30 22:01:19 --> Total execution time: 0.3283
INFO - 2018-04-30 22:01:49 --> Config Class Initialized
INFO - 2018-04-30 22:01:49 --> Hooks Class Initialized
DEBUG - 2018-04-30 22:01:49 --> UTF-8 Support Enabled
INFO - 2018-04-30 22:01:49 --> Utf8 Class Initialized
INFO - 2018-04-30 22:01:49 --> URI Class Initialized
INFO - 2018-04-30 22:01:49 --> Router Class Initialized
INFO - 2018-04-30 22:01:49 --> Output Class Initialized
INFO - 2018-04-30 22:01:49 --> Security Class Initialized
DEBUG - 2018-04-30 22:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-30 22:01:49 --> CSRF cookie sent
INFO - 2018-04-30 22:01:49 --> Input Class Initialized
INFO - 2018-04-30 22:01:49 --> Language Class Initialized
ERROR - 2018-04-30 22:01:49 --> 404 Page Not Found: Assets/css
INFO - 2018-04-30 22:02:11 --> Config Class Initialized
INFO - 2018-04-30 22:02:11 --> Hooks Class Initialized
DEBUG - 2018-04-30 22:02:11 --> UTF-8 Support Enabled
INFO - 2018-04-30 22:02:11 --> Utf8 Class Initialized
INFO - 2018-04-30 22:02:11 --> URI Class Initialized
INFO - 2018-04-30 22:02:11 --> Router Class Initialized
INFO - 2018-04-30 22:02:12 --> Output Class Initialized
INFO - 2018-04-30 22:02:12 --> Security Class Initialized
DEBUG - 2018-04-30 22:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-30 22:02:12 --> CSRF cookie sent
INFO - 2018-04-30 22:02:12 --> CSRF token verified
INFO - 2018-04-30 22:02:12 --> Input Class Initialized
INFO - 2018-04-30 22:02:12 --> Language Class Initialized
INFO - 2018-04-30 22:02:12 --> Loader Class Initialized
INFO - 2018-04-30 22:02:12 --> Helper loaded: url_helper
INFO - 2018-04-30 22:02:12 --> Helper loaded: form_helper
INFO - 2018-04-30 22:02:12 --> Helper loaded: language_helper
DEBUG - 2018-04-30 22:02:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-30 22:02:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-30 22:02:12 --> User Agent Class Initialized
INFO - 2018-04-30 22:02:12 --> Controller Class Initialized
INFO - 2018-04-30 22:02:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-30 22:02:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-30 22:02:12 --> Pixel_Model class loaded
INFO - 2018-04-30 22:02:12 --> Database Driver Class Initialized
INFO - 2018-04-30 22:02:12 --> Model "QuestionsModel" initialized
INFO - 2018-04-30 22:02:12 --> Form Validation Class Initialized
INFO - 2018-04-30 22:02:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-30 22:02:31 --> Config Class Initialized
INFO - 2018-04-30 22:02:31 --> Hooks Class Initialized
DEBUG - 2018-04-30 22:02:31 --> UTF-8 Support Enabled
INFO - 2018-04-30 22:02:31 --> Utf8 Class Initialized
INFO - 2018-04-30 22:02:31 --> URI Class Initialized
INFO - 2018-04-30 22:02:31 --> Router Class Initialized
INFO - 2018-04-30 22:02:31 --> Output Class Initialized
INFO - 2018-04-30 22:02:31 --> Security Class Initialized
DEBUG - 2018-04-30 22:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-30 22:02:31 --> CSRF cookie sent
INFO - 2018-04-30 22:02:31 --> CSRF token verified
INFO - 2018-04-30 22:02:31 --> Input Class Initialized
INFO - 2018-04-30 22:02:31 --> Language Class Initialized
INFO - 2018-04-30 22:02:31 --> Loader Class Initialized
INFO - 2018-04-30 22:02:32 --> Helper loaded: url_helper
INFO - 2018-04-30 22:02:32 --> Helper loaded: form_helper
INFO - 2018-04-30 22:02:32 --> Helper loaded: language_helper
DEBUG - 2018-04-30 22:02:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-30 22:02:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-30 22:02:32 --> User Agent Class Initialized
INFO - 2018-04-30 22:02:32 --> Controller Class Initialized
INFO - 2018-04-30 22:02:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-30 22:02:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-30 22:02:32 --> Pixel_Model class loaded
INFO - 2018-04-30 22:02:32 --> Database Driver Class Initialized
INFO - 2018-04-30 22:02:32 --> Model "QuestionsModel" initialized
INFO - 2018-04-30 22:02:32 --> Form Validation Class Initialized
INFO - 2018-04-30 22:02:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-30 22:02:32 --> Config Class Initialized
INFO - 2018-04-30 22:02:32 --> Hooks Class Initialized
DEBUG - 2018-04-30 22:02:32 --> UTF-8 Support Enabled
INFO - 2018-04-30 22:02:32 --> Utf8 Class Initialized
INFO - 2018-04-30 22:02:32 --> URI Class Initialized
INFO - 2018-04-30 22:02:32 --> Router Class Initialized
INFO - 2018-04-30 22:02:32 --> Output Class Initialized
INFO - 2018-04-30 22:02:32 --> Security Class Initialized
DEBUG - 2018-04-30 22:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-30 22:02:32 --> CSRF cookie sent
INFO - 2018-04-30 22:02:32 --> Input Class Initialized
INFO - 2018-04-30 22:02:32 --> Language Class Initialized
INFO - 2018-04-30 22:02:32 --> Loader Class Initialized
INFO - 2018-04-30 22:02:32 --> Helper loaded: url_helper
INFO - 2018-04-30 22:02:32 --> Helper loaded: form_helper
INFO - 2018-04-30 22:02:32 --> Helper loaded: language_helper
DEBUG - 2018-04-30 22:02:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-30 22:02:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-30 22:02:32 --> User Agent Class Initialized
INFO - 2018-04-30 22:02:32 --> Controller Class Initialized
INFO - 2018-04-30 22:02:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-30 22:02:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-30 22:02:32 --> Pixel_Model class loaded
INFO - 2018-04-30 22:02:32 --> Database Driver Class Initialized
INFO - 2018-04-30 22:02:32 --> Model "QuestionsModel" initialized
INFO - 2018-04-30 22:02:32 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-30 22:02:32 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-30 22:02:32 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-30 22:02:32 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-30 22:02:32 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-30 22:02:32 --> File loaded: E:\www\yacopoo\application\views\questions/finish.php
INFO - 2018-04-30 22:02:32 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-30 22:02:32 --> Final output sent to browser
DEBUG - 2018-04-30 22:02:32 --> Total execution time: 0.2941
INFO - 2018-04-30 22:02:33 --> Config Class Initialized
INFO - 2018-04-30 22:02:33 --> Hooks Class Initialized
DEBUG - 2018-04-30 22:02:33 --> UTF-8 Support Enabled
INFO - 2018-04-30 22:02:33 --> Utf8 Class Initialized
INFO - 2018-04-30 22:02:33 --> URI Class Initialized
INFO - 2018-04-30 22:02:33 --> Router Class Initialized
INFO - 2018-04-30 22:02:33 --> Output Class Initialized
INFO - 2018-04-30 22:02:33 --> Security Class Initialized
DEBUG - 2018-04-30 22:02:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-30 22:02:33 --> CSRF cookie sent
INFO - 2018-04-30 22:02:33 --> Input Class Initialized
INFO - 2018-04-30 22:02:33 --> Language Class Initialized
ERROR - 2018-04-30 22:02:33 --> 404 Page Not Found: Assets/css
INFO - 2018-04-30 22:02:57 --> Config Class Initialized
INFO - 2018-04-30 22:02:57 --> Hooks Class Initialized
DEBUG - 2018-04-30 22:02:57 --> UTF-8 Support Enabled
INFO - 2018-04-30 22:02:57 --> Utf8 Class Initialized
INFO - 2018-04-30 22:02:57 --> URI Class Initialized
INFO - 2018-04-30 22:02:57 --> Router Class Initialized
INFO - 2018-04-30 22:02:57 --> Output Class Initialized
INFO - 2018-04-30 22:02:57 --> Security Class Initialized
DEBUG - 2018-04-30 22:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-30 22:02:57 --> CSRF cookie sent
INFO - 2018-04-30 22:02:57 --> CSRF token verified
INFO - 2018-04-30 22:02:57 --> Input Class Initialized
INFO - 2018-04-30 22:02:57 --> Language Class Initialized
INFO - 2018-04-30 22:02:57 --> Loader Class Initialized
INFO - 2018-04-30 22:02:57 --> Helper loaded: url_helper
INFO - 2018-04-30 22:02:57 --> Helper loaded: form_helper
INFO - 2018-04-30 22:02:57 --> Helper loaded: language_helper
DEBUG - 2018-04-30 22:02:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-30 22:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-30 22:02:57 --> User Agent Class Initialized
INFO - 2018-04-30 22:02:57 --> Controller Class Initialized
INFO - 2018-04-30 22:02:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-30 22:02:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-30 22:02:58 --> Pixel_Model class loaded
INFO - 2018-04-30 22:02:58 --> Database Driver Class Initialized
INFO - 2018-04-30 22:02:58 --> Model "QuestionsModel" initialized
INFO - 2018-04-30 22:02:58 --> Form Validation Class Initialized
INFO - 2018-04-30 22:02:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-30 22:02:58 --> Config Class Initialized
INFO - 2018-04-30 22:02:58 --> Hooks Class Initialized
DEBUG - 2018-04-30 22:02:58 --> UTF-8 Support Enabled
INFO - 2018-04-30 22:02:58 --> Utf8 Class Initialized
INFO - 2018-04-30 22:02:58 --> URI Class Initialized
INFO - 2018-04-30 22:02:58 --> Router Class Initialized
INFO - 2018-04-30 22:02:58 --> Output Class Initialized
INFO - 2018-04-30 22:02:58 --> Security Class Initialized
DEBUG - 2018-04-30 22:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-30 22:02:58 --> CSRF cookie sent
INFO - 2018-04-30 22:02:58 --> Input Class Initialized
INFO - 2018-04-30 22:02:58 --> Language Class Initialized
INFO - 2018-04-30 22:02:58 --> Loader Class Initialized
INFO - 2018-04-30 22:02:58 --> Helper loaded: url_helper
INFO - 2018-04-30 22:02:58 --> Helper loaded: form_helper
INFO - 2018-04-30 22:02:58 --> Helper loaded: language_helper
DEBUG - 2018-04-30 22:02:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-30 22:02:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-30 22:02:58 --> User Agent Class Initialized
INFO - 2018-04-30 22:02:58 --> Controller Class Initialized
INFO - 2018-04-30 22:02:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-30 22:02:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-30 22:02:58 --> Pixel_Model class loaded
INFO - 2018-04-30 22:02:58 --> Database Driver Class Initialized
INFO - 2018-04-30 22:02:58 --> Model "QuestionsModel" initialized
INFO - 2018-04-30 22:02:58 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-30 22:02:58 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-30 22:02:58 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-30 22:02:58 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-30 22:02:58 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-30 22:02:58 --> File loaded: E:\www\yacopoo\application\views\questions/finish.php
INFO - 2018-04-30 22:02:58 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-30 22:02:58 --> Final output sent to browser
DEBUG - 2018-04-30 22:02:58 --> Total execution time: 0.2973
INFO - 2018-04-30 22:02:58 --> Config Class Initialized
INFO - 2018-04-30 22:02:58 --> Hooks Class Initialized
DEBUG - 2018-04-30 22:02:58 --> UTF-8 Support Enabled
INFO - 2018-04-30 22:02:58 --> Utf8 Class Initialized
INFO - 2018-04-30 22:02:58 --> URI Class Initialized
INFO - 2018-04-30 22:02:58 --> Router Class Initialized
INFO - 2018-04-30 22:02:58 --> Output Class Initialized
INFO - 2018-04-30 22:02:58 --> Security Class Initialized
DEBUG - 2018-04-30 22:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-30 22:02:59 --> CSRF cookie sent
INFO - 2018-04-30 22:02:59 --> Input Class Initialized
INFO - 2018-04-30 22:02:59 --> Language Class Initialized
ERROR - 2018-04-30 22:02:59 --> 404 Page Not Found: Assets/css
INFO - 2018-04-30 22:02:59 --> Config Class Initialized
INFO - 2018-04-30 22:02:59 --> Hooks Class Initialized
DEBUG - 2018-04-30 22:02:59 --> UTF-8 Support Enabled
INFO - 2018-04-30 22:02:59 --> Utf8 Class Initialized
INFO - 2018-04-30 22:02:59 --> URI Class Initialized
INFO - 2018-04-30 22:02:59 --> Router Class Initialized
INFO - 2018-04-30 22:02:59 --> Output Class Initialized
INFO - 2018-04-30 22:02:59 --> Security Class Initialized
DEBUG - 2018-04-30 22:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-30 22:02:59 --> CSRF cookie sent
INFO - 2018-04-30 22:02:59 --> Input Class Initialized
INFO - 2018-04-30 22:02:59 --> Language Class Initialized
INFO - 2018-04-30 22:02:59 --> Loader Class Initialized
INFO - 2018-04-30 22:02:59 --> Helper loaded: url_helper
INFO - 2018-04-30 22:02:59 --> Helper loaded: form_helper
INFO - 2018-04-30 22:02:59 --> Helper loaded: language_helper
DEBUG - 2018-04-30 22:02:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-30 22:02:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-30 22:02:59 --> User Agent Class Initialized
INFO - 2018-04-30 22:02:59 --> Controller Class Initialized
INFO - 2018-04-30 22:02:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-30 22:02:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-30 22:02:59 --> Pixel_Model class loaded
INFO - 2018-04-30 22:02:59 --> Database Driver Class Initialized
INFO - 2018-04-30 22:03:00 --> Model "QuestionsModel" initialized
INFO - 2018-04-30 22:03:00 --> Database Driver Class Initialized
INFO - 2018-04-30 22:03:00 --> Model "QuestionsModel" initialized
INFO - 2018-04-30 22:03:00 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-30 22:03:00 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-30 22:03:00 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-30 22:03:00 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-30 22:03:00 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-30 22:03:00 --> File loaded: E:\www\yacopoo\application\views\shared/_bar.php
INFO - 2018-04-30 22:03:00 --> File loaded: E:\www\yacopoo\application\views\shared/_buttons.php
INFO - 2018-04-30 22:03:00 --> File loaded: E:\www\yacopoo\application\views\questions/influencer_info.php
INFO - 2018-04-30 22:03:00 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-30 22:03:00 --> Final output sent to browser
DEBUG - 2018-04-30 22:03:00 --> Total execution time: 0.3577
INFO - 2018-04-30 22:03:00 --> Config Class Initialized
INFO - 2018-04-30 22:03:00 --> Hooks Class Initialized
DEBUG - 2018-04-30 22:03:00 --> UTF-8 Support Enabled
INFO - 2018-04-30 22:03:00 --> Utf8 Class Initialized
INFO - 2018-04-30 22:03:00 --> URI Class Initialized
INFO - 2018-04-30 22:03:00 --> Router Class Initialized
INFO - 2018-04-30 22:03:00 --> Output Class Initialized
INFO - 2018-04-30 22:03:00 --> Security Class Initialized
DEBUG - 2018-04-30 22:03:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-30 22:03:00 --> CSRF cookie sent
INFO - 2018-04-30 22:03:00 --> Input Class Initialized
INFO - 2018-04-30 22:03:00 --> Language Class Initialized
ERROR - 2018-04-30 22:03:00 --> 404 Page Not Found: Assets/css
INFO - 2018-04-30 22:03:02 --> Config Class Initialized
INFO - 2018-04-30 22:03:02 --> Hooks Class Initialized
DEBUG - 2018-04-30 22:03:02 --> UTF-8 Support Enabled
INFO - 2018-04-30 22:03:02 --> Utf8 Class Initialized
INFO - 2018-04-30 22:03:02 --> URI Class Initialized
INFO - 2018-04-30 22:03:02 --> Router Class Initialized
INFO - 2018-04-30 22:03:02 --> Output Class Initialized
INFO - 2018-04-30 22:03:02 --> Security Class Initialized
DEBUG - 2018-04-30 22:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-30 22:03:02 --> CSRF cookie sent
INFO - 2018-04-30 22:03:02 --> CSRF token verified
INFO - 2018-04-30 22:03:02 --> Input Class Initialized
INFO - 2018-04-30 22:03:02 --> Language Class Initialized
INFO - 2018-04-30 22:03:02 --> Loader Class Initialized
INFO - 2018-04-30 22:03:02 --> Helper loaded: url_helper
INFO - 2018-04-30 22:03:02 --> Helper loaded: form_helper
INFO - 2018-04-30 22:03:02 --> Helper loaded: language_helper
DEBUG - 2018-04-30 22:03:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-30 22:03:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-30 22:03:02 --> User Agent Class Initialized
INFO - 2018-04-30 22:03:02 --> Controller Class Initialized
INFO - 2018-04-30 22:03:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-30 22:03:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-30 22:03:02 --> Pixel_Model class loaded
INFO - 2018-04-30 22:03:02 --> Database Driver Class Initialized
INFO - 2018-04-30 22:03:02 --> Model "QuestionsModel" initialized
INFO - 2018-04-30 22:03:02 --> Form Validation Class Initialized
INFO - 2018-04-30 22:03:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-30 22:03:02 --> Config Class Initialized
INFO - 2018-04-30 22:03:02 --> Hooks Class Initialized
DEBUG - 2018-04-30 22:03:02 --> UTF-8 Support Enabled
INFO - 2018-04-30 22:03:02 --> Utf8 Class Initialized
INFO - 2018-04-30 22:03:02 --> URI Class Initialized
INFO - 2018-04-30 22:03:02 --> Router Class Initialized
INFO - 2018-04-30 22:03:02 --> Output Class Initialized
INFO - 2018-04-30 22:03:02 --> Security Class Initialized
DEBUG - 2018-04-30 22:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-30 22:03:02 --> CSRF cookie sent
INFO - 2018-04-30 22:03:02 --> Input Class Initialized
INFO - 2018-04-30 22:03:02 --> Language Class Initialized
INFO - 2018-04-30 22:03:02 --> Loader Class Initialized
INFO - 2018-04-30 22:03:02 --> Helper loaded: url_helper
INFO - 2018-04-30 22:03:02 --> Helper loaded: form_helper
INFO - 2018-04-30 22:03:02 --> Helper loaded: language_helper
DEBUG - 2018-04-30 22:03:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-30 22:03:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-30 22:03:02 --> User Agent Class Initialized
INFO - 2018-04-30 22:03:02 --> Controller Class Initialized
INFO - 2018-04-30 22:03:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-30 22:03:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-30 22:03:02 --> Pixel_Model class loaded
INFO - 2018-04-30 22:03:02 --> Database Driver Class Initialized
INFO - 2018-04-30 22:03:02 --> Model "QuestionsModel" initialized
INFO - 2018-04-30 22:03:02 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-30 22:03:02 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-30 22:03:02 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-30 22:03:02 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-30 22:03:02 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-30 22:03:02 --> File loaded: E:\www\yacopoo\application\views\questions/finish.php
INFO - 2018-04-30 22:03:02 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-30 22:03:02 --> Final output sent to browser
DEBUG - 2018-04-30 22:03:02 --> Total execution time: 0.2990
INFO - 2018-04-30 22:03:03 --> Config Class Initialized
INFO - 2018-04-30 22:03:03 --> Hooks Class Initialized
DEBUG - 2018-04-30 22:03:03 --> UTF-8 Support Enabled
INFO - 2018-04-30 22:03:03 --> Utf8 Class Initialized
INFO - 2018-04-30 22:03:03 --> URI Class Initialized
INFO - 2018-04-30 22:03:03 --> Router Class Initialized
INFO - 2018-04-30 22:03:03 --> Output Class Initialized
INFO - 2018-04-30 22:03:03 --> Security Class Initialized
DEBUG - 2018-04-30 22:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-30 22:03:03 --> CSRF cookie sent
INFO - 2018-04-30 22:03:03 --> Input Class Initialized
INFO - 2018-04-30 22:03:03 --> Language Class Initialized
ERROR - 2018-04-30 22:03:03 --> 404 Page Not Found: Assets/css
INFO - 2018-04-30 22:03:09 --> Config Class Initialized
INFO - 2018-04-30 22:03:09 --> Hooks Class Initialized
DEBUG - 2018-04-30 22:03:09 --> UTF-8 Support Enabled
INFO - 2018-04-30 22:03:09 --> Utf8 Class Initialized
INFO - 2018-04-30 22:03:09 --> URI Class Initialized
INFO - 2018-04-30 22:03:09 --> Router Class Initialized
INFO - 2018-04-30 22:03:09 --> Output Class Initialized
INFO - 2018-04-30 22:03:09 --> Security Class Initialized
DEBUG - 2018-04-30 22:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-30 22:03:09 --> CSRF cookie sent
INFO - 2018-04-30 22:03:09 --> Input Class Initialized
INFO - 2018-04-30 22:03:09 --> Language Class Initialized
INFO - 2018-04-30 22:03:09 --> Loader Class Initialized
INFO - 2018-04-30 22:03:09 --> Helper loaded: url_helper
INFO - 2018-04-30 22:03:09 --> Helper loaded: form_helper
INFO - 2018-04-30 22:03:09 --> Helper loaded: language_helper
DEBUG - 2018-04-30 22:03:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-30 22:03:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-30 22:03:09 --> User Agent Class Initialized
INFO - 2018-04-30 22:03:09 --> Controller Class Initialized
INFO - 2018-04-30 22:03:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-30 22:03:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-30 22:03:09 --> Pixel_Model class loaded
INFO - 2018-04-30 22:03:09 --> Database Driver Class Initialized
INFO - 2018-04-30 22:03:09 --> Model "MyAccountModel" initialized
INFO - 2018-04-30 22:03:09 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-30 22:03:09 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-30 22:03:09 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-30 22:03:09 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-30 22:03:09 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-30 22:03:09 --> File loaded: E:\www\yacopoo\application\views\myaccount/application_list.php
INFO - 2018-04-30 22:03:09 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-30 22:03:09 --> Final output sent to browser
DEBUG - 2018-04-30 22:03:09 --> Total execution time: 0.2972
INFO - 2018-04-30 22:03:10 --> Config Class Initialized
INFO - 2018-04-30 22:03:10 --> Hooks Class Initialized
DEBUG - 2018-04-30 22:03:10 --> UTF-8 Support Enabled
INFO - 2018-04-30 22:03:10 --> Utf8 Class Initialized
INFO - 2018-04-30 22:03:10 --> URI Class Initialized
INFO - 2018-04-30 22:03:10 --> Router Class Initialized
INFO - 2018-04-30 22:03:10 --> Output Class Initialized
INFO - 2018-04-30 22:03:10 --> Security Class Initialized
DEBUG - 2018-04-30 22:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-30 22:03:10 --> CSRF cookie sent
INFO - 2018-04-30 22:03:10 --> Input Class Initialized
INFO - 2018-04-30 22:03:10 --> Language Class Initialized
ERROR - 2018-04-30 22:03:10 --> 404 Page Not Found: Assets/css
INFO - 2018-04-30 22:04:25 --> Config Class Initialized
INFO - 2018-04-30 22:04:25 --> Hooks Class Initialized
DEBUG - 2018-04-30 22:04:25 --> UTF-8 Support Enabled
INFO - 2018-04-30 22:04:25 --> Utf8 Class Initialized
INFO - 2018-04-30 22:04:25 --> URI Class Initialized
INFO - 2018-04-30 22:04:25 --> Router Class Initialized
INFO - 2018-04-30 22:04:25 --> Output Class Initialized
INFO - 2018-04-30 22:04:25 --> Security Class Initialized
DEBUG - 2018-04-30 22:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-30 22:04:25 --> CSRF cookie sent
INFO - 2018-04-30 22:04:25 --> Input Class Initialized
INFO - 2018-04-30 22:04:25 --> Language Class Initialized
INFO - 2018-04-30 22:04:25 --> Loader Class Initialized
INFO - 2018-04-30 22:04:25 --> Helper loaded: url_helper
INFO - 2018-04-30 22:04:25 --> Helper loaded: form_helper
INFO - 2018-04-30 22:04:25 --> Helper loaded: language_helper
DEBUG - 2018-04-30 22:04:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-30 22:04:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-30 22:04:25 --> User Agent Class Initialized
INFO - 2018-04-30 22:04:25 --> Controller Class Initialized
INFO - 2018-04-30 22:04:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-30 22:04:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-30 22:04:25 --> Pixel_Model class loaded
INFO - 2018-04-30 22:04:25 --> Database Driver Class Initialized
INFO - 2018-04-30 22:04:25 --> Model "QuestionsModel" initialized
INFO - 2018-04-30 22:04:25 --> Database Driver Class Initialized
INFO - 2018-04-30 22:04:25 --> Model "QuestionsModel" initialized
INFO - 2018-04-30 22:04:25 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-30 22:04:25 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-30 22:04:25 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-30 22:04:25 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-30 22:04:25 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-30 22:04:25 --> File loaded: E:\www\yacopoo\application\views\shared/_bar.php
INFO - 2018-04-30 22:04:25 --> File loaded: E:\www\yacopoo\application\views\shared/_buttons.php
INFO - 2018-04-30 22:04:25 --> File loaded: E:\www\yacopoo\application\views\questions/influencer_info.php
INFO - 2018-04-30 22:04:25 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-30 22:04:25 --> Final output sent to browser
DEBUG - 2018-04-30 22:04:25 --> Total execution time: 0.3499
INFO - 2018-04-30 22:04:26 --> Config Class Initialized
INFO - 2018-04-30 22:04:26 --> Hooks Class Initialized
DEBUG - 2018-04-30 22:04:26 --> UTF-8 Support Enabled
INFO - 2018-04-30 22:04:26 --> Utf8 Class Initialized
INFO - 2018-04-30 22:04:26 --> URI Class Initialized
INFO - 2018-04-30 22:04:26 --> Router Class Initialized
INFO - 2018-04-30 22:04:26 --> Output Class Initialized
INFO - 2018-04-30 22:04:26 --> Security Class Initialized
DEBUG - 2018-04-30 22:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-30 22:04:26 --> CSRF cookie sent
INFO - 2018-04-30 22:04:26 --> Input Class Initialized
INFO - 2018-04-30 22:04:26 --> Language Class Initialized
ERROR - 2018-04-30 22:04:26 --> 404 Page Not Found: Assets/css
INFO - 2018-04-30 22:04:29 --> Config Class Initialized
INFO - 2018-04-30 22:04:29 --> Hooks Class Initialized
DEBUG - 2018-04-30 22:04:29 --> UTF-8 Support Enabled
INFO - 2018-04-30 22:04:29 --> Utf8 Class Initialized
INFO - 2018-04-30 22:04:29 --> URI Class Initialized
INFO - 2018-04-30 22:04:29 --> Router Class Initialized
INFO - 2018-04-30 22:04:29 --> Output Class Initialized
INFO - 2018-04-30 22:04:29 --> Security Class Initialized
DEBUG - 2018-04-30 22:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-30 22:04:29 --> CSRF cookie sent
INFO - 2018-04-30 22:04:29 --> CSRF token verified
INFO - 2018-04-30 22:04:29 --> Input Class Initialized
INFO - 2018-04-30 22:04:29 --> Language Class Initialized
INFO - 2018-04-30 22:04:29 --> Loader Class Initialized
INFO - 2018-04-30 22:04:29 --> Helper loaded: url_helper
INFO - 2018-04-30 22:04:29 --> Helper loaded: form_helper
INFO - 2018-04-30 22:04:29 --> Helper loaded: language_helper
DEBUG - 2018-04-30 22:04:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-30 22:04:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-30 22:04:29 --> User Agent Class Initialized
INFO - 2018-04-30 22:04:29 --> Controller Class Initialized
INFO - 2018-04-30 22:04:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-30 22:04:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-30 22:04:29 --> Pixel_Model class loaded
INFO - 2018-04-30 22:04:29 --> Database Driver Class Initialized
INFO - 2018-04-30 22:04:29 --> Model "QuestionsModel" initialized
INFO - 2018-04-30 22:04:29 --> Form Validation Class Initialized
INFO - 2018-04-30 22:04:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-30 22:04:29 --> Config Class Initialized
INFO - 2018-04-30 22:04:29 --> Hooks Class Initialized
DEBUG - 2018-04-30 22:04:29 --> UTF-8 Support Enabled
INFO - 2018-04-30 22:04:29 --> Utf8 Class Initialized
INFO - 2018-04-30 22:04:29 --> URI Class Initialized
INFO - 2018-04-30 22:04:29 --> Router Class Initialized
INFO - 2018-04-30 22:04:29 --> Output Class Initialized
INFO - 2018-04-30 22:04:29 --> Security Class Initialized
DEBUG - 2018-04-30 22:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-30 22:04:29 --> CSRF cookie sent
INFO - 2018-04-30 22:04:29 --> Input Class Initialized
INFO - 2018-04-30 22:04:29 --> Language Class Initialized
INFO - 2018-04-30 22:04:29 --> Loader Class Initialized
INFO - 2018-04-30 22:04:29 --> Helper loaded: url_helper
INFO - 2018-04-30 22:04:29 --> Helper loaded: form_helper
INFO - 2018-04-30 22:04:29 --> Helper loaded: language_helper
DEBUG - 2018-04-30 22:04:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-30 22:04:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-30 22:04:29 --> User Agent Class Initialized
INFO - 2018-04-30 22:04:29 --> Controller Class Initialized
INFO - 2018-04-30 22:04:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-30 22:04:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-30 22:04:29 --> Pixel_Model class loaded
INFO - 2018-04-30 22:04:29 --> Database Driver Class Initialized
INFO - 2018-04-30 22:04:29 --> Model "QuestionsModel" initialized
INFO - 2018-04-30 22:04:29 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-30 22:04:29 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-30 22:04:29 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-30 22:04:29 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-30 22:04:29 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-30 22:04:29 --> File loaded: E:\www\yacopoo\application\views\questions/finish.php
INFO - 2018-04-30 22:04:29 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-30 22:04:29 --> Final output sent to browser
DEBUG - 2018-04-30 22:04:29 --> Total execution time: 0.2955
INFO - 2018-04-30 22:04:30 --> Config Class Initialized
INFO - 2018-04-30 22:04:30 --> Hooks Class Initialized
DEBUG - 2018-04-30 22:04:30 --> UTF-8 Support Enabled
INFO - 2018-04-30 22:04:30 --> Utf8 Class Initialized
INFO - 2018-04-30 22:04:30 --> URI Class Initialized
INFO - 2018-04-30 22:04:30 --> Router Class Initialized
INFO - 2018-04-30 22:04:30 --> Output Class Initialized
INFO - 2018-04-30 22:04:30 --> Security Class Initialized
DEBUG - 2018-04-30 22:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-30 22:04:30 --> CSRF cookie sent
INFO - 2018-04-30 22:04:30 --> Input Class Initialized
INFO - 2018-04-30 22:04:30 --> Language Class Initialized
ERROR - 2018-04-30 22:04:30 --> 404 Page Not Found: Assets/css
INFO - 2018-04-30 22:04:36 --> Config Class Initialized
INFO - 2018-04-30 22:04:36 --> Hooks Class Initialized
DEBUG - 2018-04-30 22:04:36 --> UTF-8 Support Enabled
INFO - 2018-04-30 22:04:36 --> Utf8 Class Initialized
INFO - 2018-04-30 22:04:36 --> URI Class Initialized
INFO - 2018-04-30 22:04:36 --> Router Class Initialized
INFO - 2018-04-30 22:04:36 --> Output Class Initialized
INFO - 2018-04-30 22:04:36 --> Security Class Initialized
DEBUG - 2018-04-30 22:04:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-30 22:04:36 --> CSRF cookie sent
INFO - 2018-04-30 22:04:36 --> Input Class Initialized
INFO - 2018-04-30 22:04:36 --> Language Class Initialized
INFO - 2018-04-30 22:04:36 --> Loader Class Initialized
INFO - 2018-04-30 22:04:36 --> Helper loaded: url_helper
INFO - 2018-04-30 22:04:36 --> Helper loaded: form_helper
INFO - 2018-04-30 22:04:36 --> Helper loaded: language_helper
DEBUG - 2018-04-30 22:04:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-30 22:04:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-30 22:04:36 --> User Agent Class Initialized
INFO - 2018-04-30 22:04:36 --> Controller Class Initialized
INFO - 2018-04-30 22:04:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-30 22:04:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-30 22:04:36 --> Pixel_Model class loaded
INFO - 2018-04-30 22:04:36 --> Database Driver Class Initialized
INFO - 2018-04-30 22:04:36 --> Model "MyAccountModel" initialized
INFO - 2018-04-30 22:04:36 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-30 22:04:36 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-30 22:04:36 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-30 22:04:36 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-30 22:04:36 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-30 22:04:36 --> File loaded: E:\www\yacopoo\application\views\myaccount/application_list.php
INFO - 2018-04-30 22:04:36 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-30 22:04:36 --> Final output sent to browser
DEBUG - 2018-04-30 22:04:36 --> Total execution time: 0.3056
INFO - 2018-04-30 22:04:37 --> Config Class Initialized
INFO - 2018-04-30 22:04:37 --> Hooks Class Initialized
DEBUG - 2018-04-30 22:04:37 --> UTF-8 Support Enabled
INFO - 2018-04-30 22:04:37 --> Utf8 Class Initialized
INFO - 2018-04-30 22:04:37 --> URI Class Initialized
INFO - 2018-04-30 22:04:37 --> Router Class Initialized
INFO - 2018-04-30 22:04:37 --> Output Class Initialized
INFO - 2018-04-30 22:04:37 --> Security Class Initialized
DEBUG - 2018-04-30 22:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-30 22:04:37 --> CSRF cookie sent
INFO - 2018-04-30 22:04:37 --> Input Class Initialized
INFO - 2018-04-30 22:04:37 --> Language Class Initialized
ERROR - 2018-04-30 22:04:37 --> 404 Page Not Found: Assets/css
INFO - 2018-04-30 22:06:01 --> Config Class Initialized
INFO - 2018-04-30 22:06:01 --> Hooks Class Initialized
DEBUG - 2018-04-30 22:06:01 --> UTF-8 Support Enabled
INFO - 2018-04-30 22:06:01 --> Utf8 Class Initialized
INFO - 2018-04-30 22:06:01 --> URI Class Initialized
INFO - 2018-04-30 22:06:01 --> Router Class Initialized
INFO - 2018-04-30 22:06:01 --> Output Class Initialized
INFO - 2018-04-30 22:06:01 --> Security Class Initialized
DEBUG - 2018-04-30 22:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-30 22:06:01 --> CSRF cookie sent
INFO - 2018-04-30 22:06:01 --> Input Class Initialized
INFO - 2018-04-30 22:06:01 --> Language Class Initialized
INFO - 2018-04-30 22:06:01 --> Loader Class Initialized
INFO - 2018-04-30 22:06:01 --> Helper loaded: url_helper
INFO - 2018-04-30 22:06:01 --> Helper loaded: form_helper
INFO - 2018-04-30 22:06:01 --> Helper loaded: language_helper
DEBUG - 2018-04-30 22:06:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-30 22:06:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-30 22:06:01 --> User Agent Class Initialized
INFO - 2018-04-30 22:06:01 --> Controller Class Initialized
INFO - 2018-04-30 22:06:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-30 22:06:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-30 22:06:01 --> Pixel_Model class loaded
INFO - 2018-04-30 22:06:01 --> Database Driver Class Initialized
INFO - 2018-04-30 22:06:01 --> Model "MyAccountModel" initialized
INFO - 2018-04-30 22:06:01 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-30 22:06:01 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-30 22:06:01 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-30 22:06:01 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-30 22:06:01 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-30 22:06:01 --> File loaded: E:\www\yacopoo\application\views\myaccount/application_list.php
INFO - 2018-04-30 22:06:01 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-30 22:06:01 --> Final output sent to browser
DEBUG - 2018-04-30 22:06:01 --> Total execution time: 0.3307
INFO - 2018-04-30 22:06:02 --> Config Class Initialized
INFO - 2018-04-30 22:06:02 --> Hooks Class Initialized
DEBUG - 2018-04-30 22:06:02 --> UTF-8 Support Enabled
INFO - 2018-04-30 22:06:02 --> Utf8 Class Initialized
INFO - 2018-04-30 22:06:02 --> URI Class Initialized
INFO - 2018-04-30 22:06:02 --> Router Class Initialized
INFO - 2018-04-30 22:06:02 --> Output Class Initialized
INFO - 2018-04-30 22:06:02 --> Security Class Initialized
DEBUG - 2018-04-30 22:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-30 22:06:02 --> CSRF cookie sent
INFO - 2018-04-30 22:06:02 --> Input Class Initialized
INFO - 2018-04-30 22:06:02 --> Language Class Initialized
ERROR - 2018-04-30 22:06:02 --> 404 Page Not Found: Assets/css
INFO - 2018-04-30 22:06:09 --> Config Class Initialized
INFO - 2018-04-30 22:06:09 --> Hooks Class Initialized
DEBUG - 2018-04-30 22:06:09 --> UTF-8 Support Enabled
INFO - 2018-04-30 22:06:09 --> Utf8 Class Initialized
INFO - 2018-04-30 22:06:09 --> URI Class Initialized
INFO - 2018-04-30 22:06:09 --> Router Class Initialized
INFO - 2018-04-30 22:06:09 --> Output Class Initialized
INFO - 2018-04-30 22:06:09 --> Security Class Initialized
DEBUG - 2018-04-30 22:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-30 22:06:09 --> CSRF cookie sent
INFO - 2018-04-30 22:06:09 --> Input Class Initialized
INFO - 2018-04-30 22:06:09 --> Language Class Initialized
INFO - 2018-04-30 22:06:09 --> Loader Class Initialized
INFO - 2018-04-30 22:06:09 --> Helper loaded: url_helper
INFO - 2018-04-30 22:06:09 --> Helper loaded: form_helper
INFO - 2018-04-30 22:06:09 --> Helper loaded: language_helper
DEBUG - 2018-04-30 22:06:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-30 22:06:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-30 22:06:09 --> User Agent Class Initialized
INFO - 2018-04-30 22:06:09 --> Controller Class Initialized
INFO - 2018-04-30 22:06:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-30 22:06:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-30 22:06:09 --> Pixel_Model class loaded
INFO - 2018-04-30 22:06:09 --> Database Driver Class Initialized
INFO - 2018-04-30 22:06:09 --> Model "MyAccountModel" initialized
INFO - 2018-04-30 22:06:09 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-30 22:06:09 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-30 22:06:09 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-30 22:06:09 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-30 22:06:09 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-30 22:06:09 --> File loaded: E:\www\yacopoo\application\views\myaccount/application_list.php
INFO - 2018-04-30 22:06:09 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-30 22:06:09 --> Final output sent to browser
DEBUG - 2018-04-30 22:06:09 --> Total execution time: 0.3464
INFO - 2018-04-30 22:06:10 --> Config Class Initialized
INFO - 2018-04-30 22:06:10 --> Hooks Class Initialized
DEBUG - 2018-04-30 22:06:10 --> UTF-8 Support Enabled
INFO - 2018-04-30 22:06:10 --> Utf8 Class Initialized
INFO - 2018-04-30 22:06:10 --> URI Class Initialized
INFO - 2018-04-30 22:06:10 --> Router Class Initialized
INFO - 2018-04-30 22:06:10 --> Output Class Initialized
INFO - 2018-04-30 22:06:10 --> Security Class Initialized
DEBUG - 2018-04-30 22:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-30 22:06:10 --> CSRF cookie sent
INFO - 2018-04-30 22:06:10 --> Input Class Initialized
INFO - 2018-04-30 22:06:10 --> Language Class Initialized
ERROR - 2018-04-30 22:06:10 --> 404 Page Not Found: Assets/css
INFO - 2018-04-30 22:06:31 --> Config Class Initialized
INFO - 2018-04-30 22:06:31 --> Hooks Class Initialized
DEBUG - 2018-04-30 22:06:31 --> UTF-8 Support Enabled
INFO - 2018-04-30 22:06:31 --> Utf8 Class Initialized
INFO - 2018-04-30 22:06:31 --> URI Class Initialized
INFO - 2018-04-30 22:06:31 --> Router Class Initialized
INFO - 2018-04-30 22:06:31 --> Output Class Initialized
INFO - 2018-04-30 22:06:31 --> Security Class Initialized
DEBUG - 2018-04-30 22:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-30 22:06:31 --> CSRF cookie sent
INFO - 2018-04-30 22:06:31 --> Input Class Initialized
INFO - 2018-04-30 22:06:31 --> Language Class Initialized
INFO - 2018-04-30 22:06:31 --> Loader Class Initialized
INFO - 2018-04-30 22:06:31 --> Helper loaded: url_helper
INFO - 2018-04-30 22:06:31 --> Helper loaded: form_helper
INFO - 2018-04-30 22:06:31 --> Helper loaded: language_helper
DEBUG - 2018-04-30 22:06:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-30 22:06:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-30 22:06:31 --> User Agent Class Initialized
INFO - 2018-04-30 22:06:31 --> Controller Class Initialized
INFO - 2018-04-30 22:06:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-30 22:06:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-30 22:06:31 --> Pixel_Model class loaded
INFO - 2018-04-30 22:06:31 --> Database Driver Class Initialized
INFO - 2018-04-30 22:06:31 --> Model "MyAccountModel" initialized
INFO - 2018-04-30 22:06:31 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-30 22:06:31 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-30 22:06:31 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-30 22:06:31 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-30 22:06:31 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-30 22:06:31 --> File loaded: E:\www\yacopoo\application\views\myaccount/application_list.php
INFO - 2018-04-30 22:06:31 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-30 22:06:31 --> Final output sent to browser
DEBUG - 2018-04-30 22:06:31 --> Total execution time: 0.3208
INFO - 2018-04-30 22:06:32 --> Config Class Initialized
INFO - 2018-04-30 22:06:32 --> Hooks Class Initialized
DEBUG - 2018-04-30 22:06:32 --> UTF-8 Support Enabled
INFO - 2018-04-30 22:06:32 --> Utf8 Class Initialized
INFO - 2018-04-30 22:06:32 --> URI Class Initialized
INFO - 2018-04-30 22:06:32 --> Router Class Initialized
INFO - 2018-04-30 22:06:32 --> Output Class Initialized
INFO - 2018-04-30 22:06:32 --> Security Class Initialized
DEBUG - 2018-04-30 22:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-30 22:06:32 --> CSRF cookie sent
INFO - 2018-04-30 22:06:32 --> Input Class Initialized
INFO - 2018-04-30 22:06:32 --> Language Class Initialized
ERROR - 2018-04-30 22:06:32 --> 404 Page Not Found: Assets/css
INFO - 2018-04-30 22:07:22 --> Config Class Initialized
INFO - 2018-04-30 22:07:22 --> Hooks Class Initialized
DEBUG - 2018-04-30 22:07:22 --> UTF-8 Support Enabled
INFO - 2018-04-30 22:07:22 --> Utf8 Class Initialized
INFO - 2018-04-30 22:07:22 --> URI Class Initialized
INFO - 2018-04-30 22:07:22 --> Router Class Initialized
INFO - 2018-04-30 22:07:22 --> Output Class Initialized
INFO - 2018-04-30 22:07:22 --> Security Class Initialized
DEBUG - 2018-04-30 22:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-30 22:07:22 --> CSRF cookie sent
INFO - 2018-04-30 22:07:22 --> Input Class Initialized
INFO - 2018-04-30 22:07:22 --> Language Class Initialized
INFO - 2018-04-30 22:07:22 --> Loader Class Initialized
INFO - 2018-04-30 22:07:22 --> Helper loaded: url_helper
INFO - 2018-04-30 22:07:22 --> Helper loaded: form_helper
INFO - 2018-04-30 22:07:22 --> Helper loaded: language_helper
DEBUG - 2018-04-30 22:07:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-30 22:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-30 22:07:23 --> User Agent Class Initialized
INFO - 2018-04-30 22:07:23 --> Controller Class Initialized
INFO - 2018-04-30 22:07:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-30 22:07:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-30 22:07:23 --> Pixel_Model class loaded
INFO - 2018-04-30 22:07:23 --> Database Driver Class Initialized
INFO - 2018-04-30 22:07:23 --> Model "QuestionsModel" initialized
INFO - 2018-04-30 22:07:23 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-30 22:07:23 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-30 22:07:23 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-30 22:07:23 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-30 22:07:23 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-30 22:07:23 --> File loaded: E:\www\yacopoo\application\views\shared/_bar.php
INFO - 2018-04-30 22:07:23 --> File loaded: E:\www\yacopoo\application\views\shared/_buttons.php
INFO - 2018-04-30 22:07:23 --> File loaded: E:\www\yacopoo\application\views\questions/income.php
INFO - 2018-04-30 22:07:23 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-30 22:07:23 --> Final output sent to browser
DEBUG - 2018-04-30 22:07:23 --> Total execution time: 0.4057
INFO - 2018-04-30 22:07:23 --> Config Class Initialized
INFO - 2018-04-30 22:07:23 --> Hooks Class Initialized
DEBUG - 2018-04-30 22:07:23 --> UTF-8 Support Enabled
INFO - 2018-04-30 22:07:23 --> Utf8 Class Initialized
INFO - 2018-04-30 22:07:23 --> URI Class Initialized
INFO - 2018-04-30 22:07:23 --> Router Class Initialized
INFO - 2018-04-30 22:07:23 --> Output Class Initialized
INFO - 2018-04-30 22:07:23 --> Security Class Initialized
DEBUG - 2018-04-30 22:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-30 22:07:23 --> CSRF cookie sent
INFO - 2018-04-30 22:07:23 --> Input Class Initialized
INFO - 2018-04-30 22:07:23 --> Language Class Initialized
ERROR - 2018-04-30 22:07:23 --> 404 Page Not Found: Assets/css
INFO - 2018-04-30 22:07:27 --> Config Class Initialized
INFO - 2018-04-30 22:07:27 --> Hooks Class Initialized
DEBUG - 2018-04-30 22:07:27 --> UTF-8 Support Enabled
INFO - 2018-04-30 22:07:27 --> Utf8 Class Initialized
INFO - 2018-04-30 22:07:27 --> URI Class Initialized
INFO - 2018-04-30 22:07:27 --> Router Class Initialized
INFO - 2018-04-30 22:07:27 --> Output Class Initialized
INFO - 2018-04-30 22:07:27 --> Security Class Initialized
DEBUG - 2018-04-30 22:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-30 22:07:27 --> CSRF cookie sent
INFO - 2018-04-30 22:07:27 --> Input Class Initialized
INFO - 2018-04-30 22:07:27 --> Language Class Initialized
INFO - 2018-04-30 22:07:27 --> Loader Class Initialized
INFO - 2018-04-30 22:07:27 --> Helper loaded: url_helper
INFO - 2018-04-30 22:07:27 --> Helper loaded: form_helper
INFO - 2018-04-30 22:07:27 --> Helper loaded: language_helper
DEBUG - 2018-04-30 22:07:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-30 22:07:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-30 22:07:27 --> User Agent Class Initialized
INFO - 2018-04-30 22:07:27 --> Controller Class Initialized
INFO - 2018-04-30 22:07:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-30 22:07:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-30 22:07:27 --> Pixel_Model class loaded
INFO - 2018-04-30 22:07:27 --> Database Driver Class Initialized
INFO - 2018-04-30 22:07:27 --> Model "MyAccountModel" initialized
INFO - 2018-04-30 22:07:27 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-30 22:07:27 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-30 22:07:27 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-30 22:07:27 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-30 22:07:27 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-30 22:07:27 --> File loaded: E:\www\yacopoo\application\views\myaccount/application_list.php
INFO - 2018-04-30 22:07:27 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-30 22:07:27 --> Final output sent to browser
DEBUG - 2018-04-30 22:07:27 --> Total execution time: 0.3254
INFO - 2018-04-30 22:07:27 --> Config Class Initialized
INFO - 2018-04-30 22:07:27 --> Hooks Class Initialized
DEBUG - 2018-04-30 22:07:27 --> UTF-8 Support Enabled
INFO - 2018-04-30 22:07:27 --> Utf8 Class Initialized
INFO - 2018-04-30 22:07:27 --> URI Class Initialized
INFO - 2018-04-30 22:07:27 --> Router Class Initialized
INFO - 2018-04-30 22:07:27 --> Output Class Initialized
INFO - 2018-04-30 22:07:27 --> Security Class Initialized
DEBUG - 2018-04-30 22:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-30 22:07:27 --> CSRF cookie sent
INFO - 2018-04-30 22:07:27 --> Input Class Initialized
INFO - 2018-04-30 22:07:27 --> Language Class Initialized
ERROR - 2018-04-30 22:07:27 --> 404 Page Not Found: Assets/css
INFO - 2018-04-30 22:08:25 --> Config Class Initialized
INFO - 2018-04-30 22:08:25 --> Hooks Class Initialized
DEBUG - 2018-04-30 22:08:25 --> UTF-8 Support Enabled
INFO - 2018-04-30 22:08:25 --> Utf8 Class Initialized
INFO - 2018-04-30 22:08:25 --> URI Class Initialized
INFO - 2018-04-30 22:08:25 --> Router Class Initialized
INFO - 2018-04-30 22:08:25 --> Output Class Initialized
INFO - 2018-04-30 22:08:25 --> Security Class Initialized
DEBUG - 2018-04-30 22:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-30 22:08:25 --> CSRF cookie sent
INFO - 2018-04-30 22:08:25 --> Input Class Initialized
INFO - 2018-04-30 22:08:25 --> Language Class Initialized
INFO - 2018-04-30 22:08:25 --> Loader Class Initialized
INFO - 2018-04-30 22:08:25 --> Helper loaded: url_helper
INFO - 2018-04-30 22:08:25 --> Helper loaded: form_helper
INFO - 2018-04-30 22:08:25 --> Helper loaded: language_helper
DEBUG - 2018-04-30 22:08:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-30 22:08:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-30 22:08:25 --> User Agent Class Initialized
INFO - 2018-04-30 22:08:25 --> Controller Class Initialized
INFO - 2018-04-30 22:08:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-30 22:08:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-30 22:08:25 --> Pixel_Model class loaded
INFO - 2018-04-30 22:08:25 --> Database Driver Class Initialized
INFO - 2018-04-30 22:08:25 --> Model "MyAccountModel" initialized
INFO - 2018-04-30 22:08:25 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-30 22:08:25 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-30 22:08:25 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-30 22:08:25 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-30 22:08:25 --> File loaded: E:\www\yacopoo\application\views\myaccount/application_list.php
INFO - 2018-04-30 22:08:25 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-30 22:08:25 --> Final output sent to browser
DEBUG - 2018-04-30 22:08:25 --> Total execution time: 0.3434
INFO - 2018-04-30 22:08:26 --> Config Class Initialized
INFO - 2018-04-30 22:08:26 --> Hooks Class Initialized
DEBUG - 2018-04-30 22:08:26 --> UTF-8 Support Enabled
INFO - 2018-04-30 22:08:26 --> Utf8 Class Initialized
INFO - 2018-04-30 22:08:26 --> URI Class Initialized
INFO - 2018-04-30 22:08:26 --> Router Class Initialized
INFO - 2018-04-30 22:08:26 --> Output Class Initialized
INFO - 2018-04-30 22:08:26 --> Security Class Initialized
DEBUG - 2018-04-30 22:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-30 22:08:26 --> CSRF cookie sent
INFO - 2018-04-30 22:08:26 --> Input Class Initialized
INFO - 2018-04-30 22:08:26 --> Language Class Initialized
ERROR - 2018-04-30 22:08:26 --> 404 Page Not Found: Assets/css
INFO - 2018-04-30 22:08:43 --> Config Class Initialized
INFO - 2018-04-30 22:08:43 --> Hooks Class Initialized
DEBUG - 2018-04-30 22:08:43 --> UTF-8 Support Enabled
INFO - 2018-04-30 22:08:43 --> Utf8 Class Initialized
INFO - 2018-04-30 22:08:43 --> URI Class Initialized
INFO - 2018-04-30 22:08:43 --> Router Class Initialized
INFO - 2018-04-30 22:08:43 --> Output Class Initialized
INFO - 2018-04-30 22:08:43 --> Security Class Initialized
DEBUG - 2018-04-30 22:08:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-30 22:08:43 --> CSRF cookie sent
INFO - 2018-04-30 22:08:43 --> Input Class Initialized
INFO - 2018-04-30 22:08:43 --> Language Class Initialized
INFO - 2018-04-30 22:08:43 --> Loader Class Initialized
INFO - 2018-04-30 22:08:43 --> Helper loaded: url_helper
INFO - 2018-04-30 22:08:43 --> Helper loaded: form_helper
INFO - 2018-04-30 22:08:43 --> Helper loaded: language_helper
DEBUG - 2018-04-30 22:08:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-30 22:08:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-30 22:08:43 --> User Agent Class Initialized
INFO - 2018-04-30 22:08:43 --> Controller Class Initialized
INFO - 2018-04-30 22:08:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-30 22:08:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-30 22:08:43 --> Pixel_Model class loaded
INFO - 2018-04-30 22:08:43 --> Database Driver Class Initialized
INFO - 2018-04-30 22:08:43 --> Model "MyAccountModel" initialized
INFO - 2018-04-30 22:08:43 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-30 22:08:43 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-30 22:08:43 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-30 22:08:43 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-30 22:08:43 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-30 22:08:43 --> File loaded: E:\www\yacopoo\application\views\myaccount/application_list.php
INFO - 2018-04-30 22:08:43 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-30 22:08:43 --> Final output sent to browser
DEBUG - 2018-04-30 22:08:43 --> Total execution time: 0.3245
INFO - 2018-04-30 22:08:44 --> Config Class Initialized
INFO - 2018-04-30 22:08:44 --> Hooks Class Initialized
DEBUG - 2018-04-30 22:08:44 --> UTF-8 Support Enabled
INFO - 2018-04-30 22:08:44 --> Utf8 Class Initialized
INFO - 2018-04-30 22:08:44 --> URI Class Initialized
INFO - 2018-04-30 22:08:44 --> Router Class Initialized
INFO - 2018-04-30 22:08:44 --> Output Class Initialized
INFO - 2018-04-30 22:08:44 --> Security Class Initialized
DEBUG - 2018-04-30 22:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-30 22:08:44 --> CSRF cookie sent
INFO - 2018-04-30 22:08:44 --> Input Class Initialized
INFO - 2018-04-30 22:08:44 --> Language Class Initialized
ERROR - 2018-04-30 22:08:44 --> 404 Page Not Found: Assets/css
INFO - 2018-04-30 22:10:09 --> Config Class Initialized
INFO - 2018-04-30 22:10:09 --> Hooks Class Initialized
DEBUG - 2018-04-30 22:10:09 --> UTF-8 Support Enabled
INFO - 2018-04-30 22:10:09 --> Utf8 Class Initialized
INFO - 2018-04-30 22:10:09 --> URI Class Initialized
INFO - 2018-04-30 22:10:09 --> Router Class Initialized
INFO - 2018-04-30 22:10:09 --> Output Class Initialized
INFO - 2018-04-30 22:10:09 --> Security Class Initialized
DEBUG - 2018-04-30 22:10:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-30 22:10:09 --> CSRF cookie sent
INFO - 2018-04-30 22:10:09 --> Input Class Initialized
INFO - 2018-04-30 22:10:09 --> Language Class Initialized
INFO - 2018-04-30 22:10:09 --> Loader Class Initialized
INFO - 2018-04-30 22:10:09 --> Helper loaded: url_helper
INFO - 2018-04-30 22:10:09 --> Helper loaded: form_helper
INFO - 2018-04-30 22:10:09 --> Helper loaded: language_helper
DEBUG - 2018-04-30 22:10:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-30 22:10:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-30 22:10:09 --> User Agent Class Initialized
INFO - 2018-04-30 22:10:09 --> Controller Class Initialized
INFO - 2018-04-30 22:10:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-30 22:10:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-30 22:10:09 --> Pixel_Model class loaded
INFO - 2018-04-30 22:10:09 --> Database Driver Class Initialized
INFO - 2018-04-30 22:10:09 --> Model "MyAccountModel" initialized
INFO - 2018-04-30 22:10:10 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-30 22:10:10 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-30 22:10:10 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-30 22:10:10 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-30 22:10:10 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-30 22:10:10 --> File loaded: E:\www\yacopoo\application\views\myaccount/application_list.php
INFO - 2018-04-30 22:10:10 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-30 22:10:10 --> Final output sent to browser
DEBUG - 2018-04-30 22:10:10 --> Total execution time: 0.3418
INFO - 2018-04-30 22:10:13 --> Config Class Initialized
INFO - 2018-04-30 22:10:13 --> Hooks Class Initialized
DEBUG - 2018-04-30 22:10:13 --> UTF-8 Support Enabled
INFO - 2018-04-30 22:10:13 --> Utf8 Class Initialized
INFO - 2018-04-30 22:10:13 --> URI Class Initialized
INFO - 2018-04-30 22:10:13 --> Router Class Initialized
INFO - 2018-04-30 22:10:13 --> Output Class Initialized
INFO - 2018-04-30 22:10:13 --> Security Class Initialized
DEBUG - 2018-04-30 22:10:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-30 22:10:13 --> CSRF cookie sent
INFO - 2018-04-30 22:10:13 --> Input Class Initialized
INFO - 2018-04-30 22:10:13 --> Language Class Initialized
ERROR - 2018-04-30 22:10:13 --> 404 Page Not Found: Assets/css
INFO - 2018-04-30 22:10:32 --> Config Class Initialized
INFO - 2018-04-30 22:10:32 --> Hooks Class Initialized
DEBUG - 2018-04-30 22:10:32 --> UTF-8 Support Enabled
INFO - 2018-04-30 22:10:32 --> Utf8 Class Initialized
INFO - 2018-04-30 22:10:32 --> URI Class Initialized
DEBUG - 2018-04-30 22:10:32 --> No URI present. Default controller set.
INFO - 2018-04-30 22:10:32 --> Router Class Initialized
INFO - 2018-04-30 22:10:32 --> Output Class Initialized
INFO - 2018-04-30 22:10:32 --> Security Class Initialized
DEBUG - 2018-04-30 22:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-30 22:10:32 --> CSRF cookie sent
INFO - 2018-04-30 22:10:32 --> Input Class Initialized
INFO - 2018-04-30 22:10:32 --> Language Class Initialized
INFO - 2018-04-30 22:10:32 --> Loader Class Initialized
INFO - 2018-04-30 22:10:32 --> Helper loaded: url_helper
INFO - 2018-04-30 22:10:32 --> Helper loaded: form_helper
INFO - 2018-04-30 22:10:32 --> Helper loaded: language_helper
DEBUG - 2018-04-30 22:10:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-30 22:10:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-30 22:10:32 --> User Agent Class Initialized
INFO - 2018-04-30 22:10:32 --> Controller Class Initialized
INFO - 2018-04-30 22:10:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-30 22:10:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-30 22:10:32 --> Pixel_Model class loaded
INFO - 2018-04-30 22:10:32 --> Database Driver Class Initialized
INFO - 2018-04-30 22:10:32 --> Model "QuestionsModel" initialized
INFO - 2018-04-30 22:10:32 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-30 22:10:32 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-30 22:10:32 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-30 22:10:32 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-30 22:10:33 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-30 22:10:33 --> Final output sent to browser
DEBUG - 2018-04-30 22:10:33 --> Total execution time: 0.3030
INFO - 2018-04-30 22:10:33 --> Config Class Initialized
INFO - 2018-04-30 22:10:33 --> Hooks Class Initialized
DEBUG - 2018-04-30 22:10:33 --> UTF-8 Support Enabled
INFO - 2018-04-30 22:10:33 --> Utf8 Class Initialized
INFO - 2018-04-30 22:10:33 --> URI Class Initialized
INFO - 2018-04-30 22:10:33 --> Router Class Initialized
INFO - 2018-04-30 22:10:33 --> Output Class Initialized
INFO - 2018-04-30 22:10:33 --> Security Class Initialized
DEBUG - 2018-04-30 22:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-30 22:10:33 --> CSRF cookie sent
INFO - 2018-04-30 22:10:33 --> Input Class Initialized
INFO - 2018-04-30 22:10:33 --> Language Class Initialized
ERROR - 2018-04-30 22:10:33 --> 404 Page Not Found: Assets/css
INFO - 2018-04-30 22:10:34 --> Config Class Initialized
INFO - 2018-04-30 22:10:34 --> Hooks Class Initialized
DEBUG - 2018-04-30 22:10:34 --> UTF-8 Support Enabled
INFO - 2018-04-30 22:10:34 --> Utf8 Class Initialized
INFO - 2018-04-30 22:10:34 --> URI Class Initialized
INFO - 2018-04-30 22:10:34 --> Router Class Initialized
INFO - 2018-04-30 22:10:34 --> Output Class Initialized
INFO - 2018-04-30 22:10:34 --> Security Class Initialized
DEBUG - 2018-04-30 22:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-30 22:10:34 --> CSRF cookie sent
INFO - 2018-04-30 22:10:34 --> Input Class Initialized
INFO - 2018-04-30 22:10:34 --> Language Class Initialized
ERROR - 2018-04-30 22:10:34 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-30 23:53:32 --> Config Class Initialized
INFO - 2018-04-30 23:53:32 --> Hooks Class Initialized
DEBUG - 2018-04-30 23:53:32 --> UTF-8 Support Enabled
INFO - 2018-04-30 23:53:32 --> Utf8 Class Initialized
INFO - 2018-04-30 23:53:32 --> URI Class Initialized
DEBUG - 2018-04-30 23:53:32 --> No URI present. Default controller set.
INFO - 2018-04-30 23:53:32 --> Router Class Initialized
INFO - 2018-04-30 23:53:32 --> Output Class Initialized
INFO - 2018-04-30 23:53:32 --> Security Class Initialized
DEBUG - 2018-04-30 23:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-30 23:53:32 --> CSRF cookie sent
INFO - 2018-04-30 23:53:32 --> Input Class Initialized
INFO - 2018-04-30 23:53:32 --> Language Class Initialized
INFO - 2018-04-30 23:53:32 --> Loader Class Initialized
INFO - 2018-04-30 23:53:32 --> Helper loaded: url_helper
INFO - 2018-04-30 23:53:32 --> Helper loaded: form_helper
INFO - 2018-04-30 23:53:32 --> Helper loaded: language_helper
DEBUG - 2018-04-30 23:53:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-30 23:53:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-30 23:53:32 --> User Agent Class Initialized
INFO - 2018-04-30 23:53:32 --> Controller Class Initialized
INFO - 2018-04-30 23:53:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-30 23:53:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-30 23:53:32 --> Pixel_Model class loaded
INFO - 2018-04-30 23:53:32 --> Database Driver Class Initialized
INFO - 2018-04-30 23:53:32 --> Model "QuestionsModel" initialized
INFO - 2018-04-30 23:53:32 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-30 23:53:32 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-30 23:53:32 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-30 23:53:32 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-30 23:53:32 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-30 23:53:32 --> Final output sent to browser
DEBUG - 2018-04-30 23:53:32 --> Total execution time: 0.3272
INFO - 2018-04-30 23:53:34 --> Config Class Initialized
INFO - 2018-04-30 23:53:34 --> Hooks Class Initialized
DEBUG - 2018-04-30 23:53:34 --> UTF-8 Support Enabled
INFO - 2018-04-30 23:53:34 --> Utf8 Class Initialized
INFO - 2018-04-30 23:53:34 --> URI Class Initialized
INFO - 2018-04-30 23:53:34 --> Router Class Initialized
INFO - 2018-04-30 23:53:34 --> Output Class Initialized
INFO - 2018-04-30 23:53:34 --> Security Class Initialized
DEBUG - 2018-04-30 23:53:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-30 23:53:34 --> CSRF cookie sent
INFO - 2018-04-30 23:53:34 --> Input Class Initialized
INFO - 2018-04-30 23:53:34 --> Language Class Initialized
ERROR - 2018-04-30 23:53:34 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-30 23:55:46 --> Config Class Initialized
INFO - 2018-04-30 23:55:46 --> Hooks Class Initialized
DEBUG - 2018-04-30 23:55:46 --> UTF-8 Support Enabled
INFO - 2018-04-30 23:55:46 --> Utf8 Class Initialized
INFO - 2018-04-30 23:55:46 --> URI Class Initialized
DEBUG - 2018-04-30 23:55:46 --> No URI present. Default controller set.
INFO - 2018-04-30 23:55:46 --> Router Class Initialized
INFO - 2018-04-30 23:55:46 --> Output Class Initialized
INFO - 2018-04-30 23:55:46 --> Security Class Initialized
DEBUG - 2018-04-30 23:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-30 23:55:46 --> CSRF cookie sent
INFO - 2018-04-30 23:55:46 --> Input Class Initialized
INFO - 2018-04-30 23:55:46 --> Language Class Initialized
INFO - 2018-04-30 23:55:46 --> Loader Class Initialized
INFO - 2018-04-30 23:55:46 --> Helper loaded: url_helper
INFO - 2018-04-30 23:55:46 --> Helper loaded: form_helper
INFO - 2018-04-30 23:55:46 --> Helper loaded: language_helper
DEBUG - 2018-04-30 23:55:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-30 23:55:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-30 23:55:46 --> User Agent Class Initialized
INFO - 2018-04-30 23:55:46 --> Controller Class Initialized
INFO - 2018-04-30 23:55:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-30 23:55:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-30 23:55:46 --> Pixel_Model class loaded
INFO - 2018-04-30 23:55:46 --> Database Driver Class Initialized
INFO - 2018-04-30 23:55:46 --> Model "QuestionsModel" initialized
INFO - 2018-04-30 23:55:46 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-30 23:55:46 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-30 23:55:46 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-30 23:55:46 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-30 23:55:46 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-30 23:55:46 --> Final output sent to browser
DEBUG - 2018-04-30 23:55:46 --> Total execution time: 0.3186
INFO - 2018-04-30 23:55:48 --> Config Class Initialized
INFO - 2018-04-30 23:55:48 --> Hooks Class Initialized
DEBUG - 2018-04-30 23:55:48 --> UTF-8 Support Enabled
INFO - 2018-04-30 23:55:48 --> Utf8 Class Initialized
INFO - 2018-04-30 23:55:48 --> URI Class Initialized
INFO - 2018-04-30 23:55:48 --> Router Class Initialized
INFO - 2018-04-30 23:55:48 --> Output Class Initialized
INFO - 2018-04-30 23:55:48 --> Security Class Initialized
DEBUG - 2018-04-30 23:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-30 23:55:48 --> CSRF cookie sent
INFO - 2018-04-30 23:55:48 --> Input Class Initialized
INFO - 2018-04-30 23:55:48 --> Language Class Initialized
ERROR - 2018-04-30 23:55:48 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-30 23:55:51 --> Config Class Initialized
INFO - 2018-04-30 23:55:51 --> Hooks Class Initialized
DEBUG - 2018-04-30 23:55:51 --> UTF-8 Support Enabled
INFO - 2018-04-30 23:55:51 --> Utf8 Class Initialized
INFO - 2018-04-30 23:55:51 --> URI Class Initialized
INFO - 2018-04-30 23:55:51 --> Router Class Initialized
INFO - 2018-04-30 23:55:51 --> Output Class Initialized
INFO - 2018-04-30 23:55:51 --> Security Class Initialized
DEBUG - 2018-04-30 23:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-30 23:55:51 --> CSRF cookie sent
INFO - 2018-04-30 23:55:51 --> CSRF token verified
INFO - 2018-04-30 23:55:51 --> Input Class Initialized
INFO - 2018-04-30 23:55:51 --> Language Class Initialized
INFO - 2018-04-30 23:55:51 --> Loader Class Initialized
INFO - 2018-04-30 23:55:51 --> Helper loaded: url_helper
INFO - 2018-04-30 23:55:51 --> Helper loaded: form_helper
INFO - 2018-04-30 23:55:51 --> Helper loaded: language_helper
DEBUG - 2018-04-30 23:55:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-30 23:55:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-30 23:55:52 --> User Agent Class Initialized
INFO - 2018-04-30 23:55:52 --> Controller Class Initialized
INFO - 2018-04-30 23:55:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-30 23:55:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-30 23:55:52 --> Pixel_Model class loaded
INFO - 2018-04-30 23:55:52 --> Database Driver Class Initialized
INFO - 2018-04-30 23:55:52 --> Model "QuestionsModel" initialized
INFO - 2018-04-30 23:55:52 --> Form Validation Class Initialized
INFO - 2018-04-30 23:55:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-30 23:55:52 --> Config Class Initialized
INFO - 2018-04-30 23:55:52 --> Hooks Class Initialized
DEBUG - 2018-04-30 23:55:52 --> UTF-8 Support Enabled
INFO - 2018-04-30 23:55:52 --> Utf8 Class Initialized
INFO - 2018-04-30 23:55:52 --> URI Class Initialized
INFO - 2018-04-30 23:55:52 --> Router Class Initialized
INFO - 2018-04-30 23:55:52 --> Output Class Initialized
INFO - 2018-04-30 23:55:52 --> Security Class Initialized
DEBUG - 2018-04-30 23:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-30 23:55:52 --> CSRF cookie sent
INFO - 2018-04-30 23:55:52 --> Input Class Initialized
INFO - 2018-04-30 23:55:52 --> Language Class Initialized
INFO - 2018-04-30 23:55:52 --> Loader Class Initialized
INFO - 2018-04-30 23:55:52 --> Helper loaded: url_helper
INFO - 2018-04-30 23:55:52 --> Helper loaded: form_helper
INFO - 2018-04-30 23:55:52 --> Helper loaded: language_helper
DEBUG - 2018-04-30 23:55:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-30 23:55:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-30 23:55:52 --> User Agent Class Initialized
INFO - 2018-04-30 23:55:52 --> Controller Class Initialized
INFO - 2018-04-30 23:55:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-30 23:55:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-30 23:55:52 --> Pixel_Model class loaded
INFO - 2018-04-30 23:55:52 --> Database Driver Class Initialized
INFO - 2018-04-30 23:55:52 --> Model "QuestionsModel" initialized
INFO - 2018-04-30 23:55:52 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-30 23:55:52 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-30 23:55:52 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-30 23:55:52 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-04-30 23:55:52 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-30 23:55:52 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-30 23:55:52 --> File loaded: E:\www\yacopoo\application\views\shared/_bar.php
INFO - 2018-04-30 23:55:52 --> File loaded: E:\www\yacopoo\application\views\shared/_buttons.php
INFO - 2018-04-30 23:55:52 --> File loaded: E:\www\yacopoo\application\views\questions/relation_ship_status.php
INFO - 2018-04-30 23:55:52 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-30 23:55:52 --> Final output sent to browser
DEBUG - 2018-04-30 23:55:52 --> Total execution time: 0.3956
INFO - 2018-04-30 23:56:00 --> Config Class Initialized
INFO - 2018-04-30 23:56:00 --> Hooks Class Initialized
DEBUG - 2018-04-30 23:56:00 --> UTF-8 Support Enabled
INFO - 2018-04-30 23:56:00 --> Utf8 Class Initialized
INFO - 2018-04-30 23:56:00 --> URI Class Initialized
INFO - 2018-04-30 23:56:00 --> Router Class Initialized
INFO - 2018-04-30 23:56:00 --> Output Class Initialized
INFO - 2018-04-30 23:56:00 --> Security Class Initialized
DEBUG - 2018-04-30 23:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-30 23:56:00 --> CSRF cookie sent
INFO - 2018-04-30 23:56:00 --> Input Class Initialized
INFO - 2018-04-30 23:56:00 --> Language Class Initialized
INFO - 2018-04-30 23:56:00 --> Loader Class Initialized
INFO - 2018-04-30 23:56:00 --> Helper loaded: url_helper
INFO - 2018-04-30 23:56:00 --> Helper loaded: form_helper
INFO - 2018-04-30 23:56:00 --> Helper loaded: language_helper
DEBUG - 2018-04-30 23:56:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-30 23:56:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-30 23:56:00 --> User Agent Class Initialized
INFO - 2018-04-30 23:56:00 --> Controller Class Initialized
INFO - 2018-04-30 23:56:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-30 23:56:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-30 23:56:00 --> Pixel_Model class loaded
INFO - 2018-04-30 23:56:00 --> Database Driver Class Initialized
INFO - 2018-04-30 23:56:00 --> Model "QuestionsModel" initialized
INFO - 2018-04-30 23:56:00 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-30 23:56:00 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-04-30 23:56:00 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-30 23:56:00 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-30 23:56:00 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-04-30 23:56:00 --> File loaded: E:\www\yacopoo\application\views\shared/_bar.php
INFO - 2018-04-30 23:56:00 --> File loaded: E:\www\yacopoo\application\views\shared/_buttons.php
INFO - 2018-04-30 23:56:00 --> File loaded: E:\www\yacopoo\application\views\questions/start_questions.php
INFO - 2018-04-30 23:56:00 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-30 23:56:00 --> Final output sent to browser
DEBUG - 2018-04-30 23:56:00 --> Total execution time: 0.3590
INFO - 2018-04-30 23:56:10 --> Config Class Initialized
INFO - 2018-04-30 23:56:10 --> Hooks Class Initialized
DEBUG - 2018-04-30 23:56:10 --> UTF-8 Support Enabled
INFO - 2018-04-30 23:56:10 --> Utf8 Class Initialized
INFO - 2018-04-30 23:56:10 --> URI Class Initialized
INFO - 2018-04-30 23:56:10 --> Router Class Initialized
INFO - 2018-04-30 23:56:10 --> Output Class Initialized
INFO - 2018-04-30 23:56:10 --> Security Class Initialized
DEBUG - 2018-04-30 23:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-30 23:56:10 --> CSRF cookie sent
INFO - 2018-04-30 23:56:10 --> Input Class Initialized
INFO - 2018-04-30 23:56:10 --> Language Class Initialized
INFO - 2018-04-30 23:56:10 --> Loader Class Initialized
INFO - 2018-04-30 23:56:10 --> Helper loaded: url_helper
INFO - 2018-04-30 23:56:10 --> Helper loaded: form_helper
INFO - 2018-04-30 23:56:10 --> Helper loaded: language_helper
DEBUG - 2018-04-30 23:56:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-30 23:56:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-30 23:56:10 --> User Agent Class Initialized
INFO - 2018-04-30 23:56:10 --> Controller Class Initialized
INFO - 2018-04-30 23:56:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-30 23:56:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-30 23:56:10 --> CSRF cookie sent
INFO - 2018-04-30 23:56:10 --> Config Class Initialized
INFO - 2018-04-30 23:56:10 --> Hooks Class Initialized
DEBUG - 2018-04-30 23:56:10 --> UTF-8 Support Enabled
INFO - 2018-04-30 23:56:10 --> Utf8 Class Initialized
INFO - 2018-04-30 23:56:10 --> URI Class Initialized
DEBUG - 2018-04-30 23:56:10 --> No URI present. Default controller set.
INFO - 2018-04-30 23:56:10 --> Router Class Initialized
INFO - 2018-04-30 23:56:10 --> Output Class Initialized
INFO - 2018-04-30 23:56:10 --> Security Class Initialized
DEBUG - 2018-04-30 23:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-30 23:56:10 --> CSRF cookie sent
INFO - 2018-04-30 23:56:10 --> Input Class Initialized
INFO - 2018-04-30 23:56:10 --> Language Class Initialized
INFO - 2018-04-30 23:56:10 --> Loader Class Initialized
INFO - 2018-04-30 23:56:10 --> Helper loaded: url_helper
INFO - 2018-04-30 23:56:10 --> Helper loaded: form_helper
INFO - 2018-04-30 23:56:10 --> Helper loaded: language_helper
DEBUG - 2018-04-30 23:56:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-30 23:56:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-30 23:56:10 --> User Agent Class Initialized
INFO - 2018-04-30 23:56:10 --> Controller Class Initialized
INFO - 2018-04-30 23:56:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-30 23:56:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-30 23:56:10 --> Pixel_Model class loaded
INFO - 2018-04-30 23:56:10 --> Database Driver Class Initialized
INFO - 2018-04-30 23:56:10 --> Model "QuestionsModel" initialized
INFO - 2018-04-30 23:56:10 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-30 23:56:10 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-30 23:56:10 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-04-30 23:56:10 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-30 23:56:10 --> Final output sent to browser
DEBUG - 2018-04-30 23:56:10 --> Total execution time: 0.3008
INFO - 2018-04-30 23:56:12 --> Config Class Initialized
INFO - 2018-04-30 23:56:12 --> Hooks Class Initialized
DEBUG - 2018-04-30 23:56:12 --> UTF-8 Support Enabled
INFO - 2018-04-30 23:56:12 --> Utf8 Class Initialized
INFO - 2018-04-30 23:56:12 --> URI Class Initialized
INFO - 2018-04-30 23:56:12 --> Router Class Initialized
INFO - 2018-04-30 23:56:12 --> Output Class Initialized
INFO - 2018-04-30 23:56:12 --> Security Class Initialized
DEBUG - 2018-04-30 23:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-30 23:56:12 --> CSRF cookie sent
INFO - 2018-04-30 23:56:12 --> Input Class Initialized
INFO - 2018-04-30 23:56:12 --> Language Class Initialized
ERROR - 2018-04-30 23:56:12 --> 404 Page Not Found: Revolution/assets
INFO - 2018-04-30 23:56:24 --> Config Class Initialized
INFO - 2018-04-30 23:56:24 --> Hooks Class Initialized
DEBUG - 2018-04-30 23:56:24 --> UTF-8 Support Enabled
INFO - 2018-04-30 23:56:24 --> Utf8 Class Initialized
INFO - 2018-04-30 23:56:24 --> URI Class Initialized
INFO - 2018-04-30 23:56:24 --> Router Class Initialized
INFO - 2018-04-30 23:56:24 --> Output Class Initialized
INFO - 2018-04-30 23:56:24 --> Security Class Initialized
DEBUG - 2018-04-30 23:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-30 23:56:24 --> CSRF cookie sent
INFO - 2018-04-30 23:56:24 --> CSRF token verified
INFO - 2018-04-30 23:56:24 --> Input Class Initialized
INFO - 2018-04-30 23:56:24 --> Language Class Initialized
INFO - 2018-04-30 23:56:24 --> Loader Class Initialized
INFO - 2018-04-30 23:56:24 --> Helper loaded: url_helper
INFO - 2018-04-30 23:56:24 --> Helper loaded: form_helper
INFO - 2018-04-30 23:56:24 --> Helper loaded: language_helper
DEBUG - 2018-04-30 23:56:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-30 23:56:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-30 23:56:24 --> User Agent Class Initialized
INFO - 2018-04-30 23:56:24 --> Controller Class Initialized
INFO - 2018-04-30 23:56:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-30 23:56:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-30 23:56:24 --> Pixel_Model class loaded
INFO - 2018-04-30 23:56:24 --> Database Driver Class Initialized
INFO - 2018-04-30 23:56:24 --> Model "QuestionsModel" initialized
INFO - 2018-04-30 23:56:24 --> Config Class Initialized
INFO - 2018-04-30 23:56:24 --> Hooks Class Initialized
DEBUG - 2018-04-30 23:56:24 --> UTF-8 Support Enabled
INFO - 2018-04-30 23:56:24 --> Utf8 Class Initialized
INFO - 2018-04-30 23:56:24 --> URI Class Initialized
INFO - 2018-04-30 23:56:24 --> Router Class Initialized
INFO - 2018-04-30 23:56:24 --> Output Class Initialized
INFO - 2018-04-30 23:56:24 --> Security Class Initialized
DEBUG - 2018-04-30 23:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-30 23:56:24 --> CSRF cookie sent
INFO - 2018-04-30 23:56:24 --> Input Class Initialized
INFO - 2018-04-30 23:56:24 --> Language Class Initialized
INFO - 2018-04-30 23:56:24 --> Loader Class Initialized
INFO - 2018-04-30 23:56:24 --> Helper loaded: url_helper
INFO - 2018-04-30 23:56:25 --> Helper loaded: form_helper
INFO - 2018-04-30 23:56:25 --> Helper loaded: language_helper
DEBUG - 2018-04-30 23:56:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-30 23:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-30 23:56:25 --> User Agent Class Initialized
INFO - 2018-04-30 23:56:25 --> Controller Class Initialized
INFO - 2018-04-30 23:56:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-04-30 23:56:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-04-30 23:56:25 --> Pixel_Model class loaded
INFO - 2018-04-30 23:56:25 --> Database Driver Class Initialized
INFO - 2018-04-30 23:56:25 --> Model "RegistrationModel" initialized
DEBUG - 2018-04-30 23:56:25 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-04-30 23:56:25 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-04-30 23:56:25 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-04-30 23:56:25 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-04-30 23:56:25 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-04-30 23:56:25 --> Could not find the language line "req_email"
INFO - 2018-04-30 23:56:25 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-04-30 23:56:25 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-04-30 23:56:25 --> Final output sent to browser
DEBUG - 2018-04-30 23:56:25 --> Total execution time: 0.4712

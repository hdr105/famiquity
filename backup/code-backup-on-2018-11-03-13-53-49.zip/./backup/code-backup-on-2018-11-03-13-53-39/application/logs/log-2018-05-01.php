<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-05-01 00:01:09 --> Config Class Initialized
INFO - 2018-05-01 00:01:09 --> Hooks Class Initialized
DEBUG - 2018-05-01 00:01:09 --> UTF-8 Support Enabled
INFO - 2018-05-01 00:01:09 --> Utf8 Class Initialized
INFO - 2018-05-01 00:01:09 --> URI Class Initialized
DEBUG - 2018-05-01 00:01:09 --> No URI present. Default controller set.
INFO - 2018-05-01 00:01:09 --> Router Class Initialized
INFO - 2018-05-01 00:01:09 --> Output Class Initialized
INFO - 2018-05-01 00:01:09 --> Security Class Initialized
DEBUG - 2018-05-01 00:01:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 00:01:09 --> CSRF cookie sent
INFO - 2018-05-01 00:01:09 --> Input Class Initialized
INFO - 2018-05-01 00:01:09 --> Language Class Initialized
INFO - 2018-05-01 00:01:09 --> Loader Class Initialized
INFO - 2018-05-01 00:01:09 --> Helper loaded: url_helper
INFO - 2018-05-01 00:01:09 --> Helper loaded: form_helper
INFO - 2018-05-01 00:01:09 --> Helper loaded: language_helper
DEBUG - 2018-05-01 00:01:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-01 00:01:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 00:01:09 --> User Agent Class Initialized
INFO - 2018-05-01 00:01:09 --> Controller Class Initialized
INFO - 2018-05-01 00:01:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-05-01 00:01:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-05-01 00:01:09 --> Pixel_Model class loaded
INFO - 2018-05-01 00:01:09 --> Database Driver Class Initialized
INFO - 2018-05-01 00:01:09 --> Model "QuestionsModel" initialized
INFO - 2018-05-01 00:01:09 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-05-01 00:01:09 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-05-01 00:01:09 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-05-01 00:01:09 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-05-01 00:01:09 --> Final output sent to browser
DEBUG - 2018-05-01 00:01:09 --> Total execution time: 0.2977
INFO - 2018-05-01 00:01:11 --> Config Class Initialized
INFO - 2018-05-01 00:01:11 --> Hooks Class Initialized
DEBUG - 2018-05-01 00:01:11 --> UTF-8 Support Enabled
INFO - 2018-05-01 00:01:11 --> Utf8 Class Initialized
INFO - 2018-05-01 00:01:11 --> URI Class Initialized
INFO - 2018-05-01 00:01:11 --> Router Class Initialized
INFO - 2018-05-01 00:01:11 --> Output Class Initialized
INFO - 2018-05-01 00:01:11 --> Security Class Initialized
DEBUG - 2018-05-01 00:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 00:01:11 --> CSRF cookie sent
INFO - 2018-05-01 00:01:11 --> Input Class Initialized
INFO - 2018-05-01 00:01:11 --> Language Class Initialized
ERROR - 2018-05-01 00:01:11 --> 404 Page Not Found: Revolution/assets
INFO - 2018-05-01 00:01:12 --> Config Class Initialized
INFO - 2018-05-01 00:01:13 --> Hooks Class Initialized
DEBUG - 2018-05-01 00:01:13 --> UTF-8 Support Enabled
INFO - 2018-05-01 00:01:13 --> Utf8 Class Initialized
INFO - 2018-05-01 00:01:13 --> URI Class Initialized
INFO - 2018-05-01 00:01:13 --> Router Class Initialized
INFO - 2018-05-01 00:01:13 --> Output Class Initialized
INFO - 2018-05-01 00:01:13 --> Security Class Initialized
DEBUG - 2018-05-01 00:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 00:01:13 --> CSRF cookie sent
INFO - 2018-05-01 00:01:13 --> CSRF token verified
INFO - 2018-05-01 00:01:13 --> Input Class Initialized
INFO - 2018-05-01 00:01:13 --> Language Class Initialized
INFO - 2018-05-01 00:01:13 --> Loader Class Initialized
INFO - 2018-05-01 00:01:13 --> Helper loaded: url_helper
INFO - 2018-05-01 00:01:13 --> Helper loaded: form_helper
INFO - 2018-05-01 00:01:13 --> Helper loaded: language_helper
DEBUG - 2018-05-01 00:01:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-01 00:01:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 00:01:13 --> User Agent Class Initialized
INFO - 2018-05-01 00:01:13 --> Controller Class Initialized
INFO - 2018-05-01 00:01:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-05-01 00:01:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-05-01 00:01:13 --> Pixel_Model class loaded
INFO - 2018-05-01 00:01:13 --> Database Driver Class Initialized
INFO - 2018-05-01 00:01:13 --> Model "QuestionsModel" initialized
INFO - 2018-05-01 00:08:52 --> Config Class Initialized
INFO - 2018-05-01 00:08:52 --> Hooks Class Initialized
DEBUG - 2018-05-01 00:08:52 --> UTF-8 Support Enabled
INFO - 2018-05-01 00:08:52 --> Utf8 Class Initialized
INFO - 2018-05-01 00:08:52 --> URI Class Initialized
INFO - 2018-05-01 00:08:52 --> Router Class Initialized
INFO - 2018-05-01 00:08:52 --> Output Class Initialized
INFO - 2018-05-01 00:08:52 --> Security Class Initialized
DEBUG - 2018-05-01 00:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 00:08:52 --> CSRF cookie sent
INFO - 2018-05-01 00:08:52 --> CSRF token verified
INFO - 2018-05-01 00:08:52 --> Input Class Initialized
INFO - 2018-05-01 00:08:52 --> Language Class Initialized
INFO - 2018-05-01 00:08:52 --> Loader Class Initialized
INFO - 2018-05-01 00:08:52 --> Helper loaded: url_helper
INFO - 2018-05-01 00:08:52 --> Helper loaded: form_helper
INFO - 2018-05-01 00:08:52 --> Helper loaded: language_helper
DEBUG - 2018-05-01 00:08:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-01 00:08:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 00:08:52 --> User Agent Class Initialized
INFO - 2018-05-01 00:08:52 --> Controller Class Initialized
INFO - 2018-05-01 00:08:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-05-01 00:08:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-05-01 00:08:52 --> Pixel_Model class loaded
INFO - 2018-05-01 00:08:52 --> Database Driver Class Initialized
INFO - 2018-05-01 00:08:52 --> Model "QuestionsModel" initialized
ERROR - 2018-05-01 00:08:52 --> Severity: Notice --> Undefined variable: appDate E:\www\yacopoo\application\controllers\QuestionnaireController.php 29
INFO - 2018-05-01 00:08:52 --> Config Class Initialized
INFO - 2018-05-01 00:08:52 --> Hooks Class Initialized
DEBUG - 2018-05-01 00:08:52 --> UTF-8 Support Enabled
INFO - 2018-05-01 00:08:52 --> Utf8 Class Initialized
INFO - 2018-05-01 00:08:52 --> URI Class Initialized
INFO - 2018-05-01 00:08:52 --> Router Class Initialized
INFO - 2018-05-01 00:08:52 --> Output Class Initialized
INFO - 2018-05-01 00:08:52 --> Security Class Initialized
DEBUG - 2018-05-01 00:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 00:08:52 --> CSRF cookie sent
INFO - 2018-05-01 00:08:52 --> Input Class Initialized
INFO - 2018-05-01 00:08:52 --> Language Class Initialized
INFO - 2018-05-01 00:08:52 --> Loader Class Initialized
INFO - 2018-05-01 00:08:52 --> Helper loaded: url_helper
INFO - 2018-05-01 00:08:52 --> Helper loaded: form_helper
INFO - 2018-05-01 00:08:52 --> Helper loaded: language_helper
DEBUG - 2018-05-01 00:08:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-01 00:08:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 00:08:52 --> User Agent Class Initialized
INFO - 2018-05-01 00:08:52 --> Controller Class Initialized
INFO - 2018-05-01 00:08:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-05-01 00:08:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-05-01 00:08:52 --> Pixel_Model class loaded
INFO - 2018-05-01 00:08:52 --> Database Driver Class Initialized
INFO - 2018-05-01 00:08:52 --> Model "RegistrationModel" initialized
DEBUG - 2018-05-01 00:08:52 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-05-01 00:08:52 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-05-01 00:08:52 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-05-01 00:08:52 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-05-01 00:08:52 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-05-01 00:08:52 --> Could not find the language line "req_email"
INFO - 2018-05-01 00:08:52 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-05-01 00:08:52 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-05-01 00:08:52 --> Final output sent to browser
DEBUG - 2018-05-01 00:08:52 --> Total execution time: 0.2736
INFO - 2018-05-01 00:09:21 --> Config Class Initialized
INFO - 2018-05-01 00:09:21 --> Hooks Class Initialized
DEBUG - 2018-05-01 00:09:21 --> UTF-8 Support Enabled
INFO - 2018-05-01 00:09:21 --> Utf8 Class Initialized
INFO - 2018-05-01 00:09:21 --> URI Class Initialized
INFO - 2018-05-01 00:09:21 --> Router Class Initialized
INFO - 2018-05-01 00:09:21 --> Output Class Initialized
INFO - 2018-05-01 00:09:21 --> Security Class Initialized
DEBUG - 2018-05-01 00:09:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 00:09:21 --> CSRF cookie sent
INFO - 2018-05-01 00:09:21 --> CSRF token verified
INFO - 2018-05-01 00:09:21 --> Input Class Initialized
INFO - 2018-05-01 00:09:21 --> Language Class Initialized
INFO - 2018-05-01 00:09:21 --> Loader Class Initialized
INFO - 2018-05-01 00:09:21 --> Helper loaded: url_helper
INFO - 2018-05-01 00:09:21 --> Helper loaded: form_helper
INFO - 2018-05-01 00:09:21 --> Helper loaded: language_helper
DEBUG - 2018-05-01 00:09:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-01 00:09:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 00:09:21 --> User Agent Class Initialized
INFO - 2018-05-01 00:09:21 --> Controller Class Initialized
INFO - 2018-05-01 00:09:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-05-01 00:09:21 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-05-01 00:09:21 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-05-01 00:09:21 --> Form Validation Class Initialized
INFO - 2018-05-01 00:09:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-05-01 00:09:21 --> Pixel_Model class loaded
INFO - 2018-05-01 00:09:21 --> Database Driver Class Initialized
INFO - 2018-05-01 00:09:21 --> Model "RegistrationModel" initialized
INFO - 2018-05-01 00:09:21 --> Helper loaded: string_helper
INFO - 2018-05-01 00:09:21 --> Language file loaded: language/en/notifications_lang.php
INFO - 2018-05-01 00:09:22 --> File loaded: E:\www\yacopoo\application\views\emails/_buttons.php
INFO - 2018-05-01 00:09:22 --> File loaded: E:\www\yacopoo\application\views\emails/header.php
INFO - 2018-05-01 00:09:22 --> File loaded: E:\www\yacopoo\application\views\emails/footer.php
INFO - 2018-05-01 00:09:22 --> File loaded: E:\www\yacopoo\application\views\emails/generic.php
INFO - 2018-05-01 00:09:22 --> Email Class Initialized
ERROR - 2018-05-01 00:09:23 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() E:\www\yacopoo\system\libraries\Email.php 1894
INFO - 2018-05-01 00:09:23 --> Language file loaded: language/english/email_lang.php
INFO - 2018-05-01 00:09:23 --> Config Class Initialized
INFO - 2018-05-01 00:09:23 --> Hooks Class Initialized
DEBUG - 2018-05-01 00:09:23 --> UTF-8 Support Enabled
INFO - 2018-05-01 00:09:23 --> Utf8 Class Initialized
INFO - 2018-05-01 00:09:23 --> URI Class Initialized
INFO - 2018-05-01 00:09:23 --> Router Class Initialized
INFO - 2018-05-01 00:09:23 --> Output Class Initialized
INFO - 2018-05-01 00:09:23 --> Security Class Initialized
DEBUG - 2018-05-01 00:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 00:09:23 --> CSRF cookie sent
INFO - 2018-05-01 00:09:23 --> Input Class Initialized
INFO - 2018-05-01 00:09:23 --> Language Class Initialized
INFO - 2018-05-01 00:09:23 --> Loader Class Initialized
INFO - 2018-05-01 00:09:23 --> Helper loaded: url_helper
INFO - 2018-05-01 00:09:23 --> Helper loaded: form_helper
INFO - 2018-05-01 00:09:23 --> Helper loaded: language_helper
DEBUG - 2018-05-01 00:09:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-01 00:09:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 00:09:23 --> User Agent Class Initialized
INFO - 2018-05-01 00:09:23 --> Controller Class Initialized
INFO - 2018-05-01 00:09:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-05-01 00:09:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-05-01 00:09:23 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-05-01 00:09:23 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-05-01 00:09:23 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-05-01 00:09:23 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-05-01 00:09:23 --> File loaded: E:\www\yacopoo\application\views\register/thanks.php
INFO - 2018-05-01 00:09:23 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-05-01 00:09:23 --> Final output sent to browser
DEBUG - 2018-05-01 00:09:23 --> Total execution time: 0.2665
INFO - 2018-05-01 00:10:37 --> Config Class Initialized
INFO - 2018-05-01 00:10:37 --> Hooks Class Initialized
DEBUG - 2018-05-01 00:10:37 --> UTF-8 Support Enabled
INFO - 2018-05-01 00:10:37 --> Utf8 Class Initialized
INFO - 2018-05-01 00:10:37 --> URI Class Initialized
DEBUG - 2018-05-01 00:10:37 --> No URI present. Default controller set.
INFO - 2018-05-01 00:10:37 --> Router Class Initialized
INFO - 2018-05-01 00:10:37 --> Output Class Initialized
INFO - 2018-05-01 00:10:37 --> Security Class Initialized
DEBUG - 2018-05-01 00:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 00:10:37 --> CSRF cookie sent
INFO - 2018-05-01 00:10:37 --> Input Class Initialized
INFO - 2018-05-01 00:10:37 --> Language Class Initialized
INFO - 2018-05-01 00:10:37 --> Loader Class Initialized
INFO - 2018-05-01 00:10:37 --> Helper loaded: url_helper
INFO - 2018-05-01 00:10:37 --> Helper loaded: form_helper
INFO - 2018-05-01 00:10:37 --> Helper loaded: language_helper
DEBUG - 2018-05-01 00:10:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-01 00:10:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 00:10:37 --> User Agent Class Initialized
INFO - 2018-05-01 00:10:37 --> Controller Class Initialized
INFO - 2018-05-01 00:10:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-05-01 00:10:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-05-01 00:10:37 --> Pixel_Model class loaded
INFO - 2018-05-01 00:10:37 --> Database Driver Class Initialized
INFO - 2018-05-01 00:10:37 --> Model "QuestionsModel" initialized
INFO - 2018-05-01 00:10:37 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-05-01 00:10:37 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-05-01 00:10:37 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-05-01 00:10:37 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-05-01 00:10:37 --> Final output sent to browser
DEBUG - 2018-05-01 00:10:37 --> Total execution time: 0.2694
INFO - 2018-05-01 00:10:39 --> Config Class Initialized
INFO - 2018-05-01 00:10:39 --> Hooks Class Initialized
DEBUG - 2018-05-01 00:10:39 --> UTF-8 Support Enabled
INFO - 2018-05-01 00:10:39 --> Utf8 Class Initialized
INFO - 2018-05-01 00:10:39 --> URI Class Initialized
INFO - 2018-05-01 00:10:39 --> Router Class Initialized
INFO - 2018-05-01 00:10:39 --> Output Class Initialized
INFO - 2018-05-01 00:10:39 --> Security Class Initialized
DEBUG - 2018-05-01 00:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 00:10:39 --> CSRF cookie sent
INFO - 2018-05-01 00:10:39 --> Input Class Initialized
INFO - 2018-05-01 00:10:39 --> Language Class Initialized
ERROR - 2018-05-01 00:10:39 --> 404 Page Not Found: Revolution/assets
INFO - 2018-05-01 00:10:48 --> Config Class Initialized
INFO - 2018-05-01 00:10:48 --> Hooks Class Initialized
DEBUG - 2018-05-01 00:10:48 --> UTF-8 Support Enabled
INFO - 2018-05-01 00:10:48 --> Utf8 Class Initialized
INFO - 2018-05-01 00:10:48 --> URI Class Initialized
INFO - 2018-05-01 00:10:48 --> Router Class Initialized
INFO - 2018-05-01 00:10:48 --> Output Class Initialized
INFO - 2018-05-01 00:10:48 --> Security Class Initialized
DEBUG - 2018-05-01 00:10:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 00:10:48 --> CSRF cookie sent
INFO - 2018-05-01 00:10:48 --> CSRF token verified
INFO - 2018-05-01 00:10:48 --> Input Class Initialized
INFO - 2018-05-01 00:10:48 --> Language Class Initialized
INFO - 2018-05-01 00:10:48 --> Loader Class Initialized
INFO - 2018-05-01 00:10:48 --> Helper loaded: url_helper
INFO - 2018-05-01 00:10:48 --> Helper loaded: form_helper
INFO - 2018-05-01 00:10:48 --> Helper loaded: language_helper
DEBUG - 2018-05-01 00:10:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-01 00:10:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 00:10:48 --> User Agent Class Initialized
INFO - 2018-05-01 00:10:48 --> Controller Class Initialized
INFO - 2018-05-01 00:10:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-05-01 00:10:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-05-01 00:10:48 --> Pixel_Model class loaded
INFO - 2018-05-01 00:10:48 --> Database Driver Class Initialized
INFO - 2018-05-01 00:10:48 --> Model "QuestionsModel" initialized
ERROR - 2018-05-01 00:10:48 --> Severity: Notice --> Undefined variable: appDate E:\www\yacopoo\application\controllers\QuestionnaireController.php 29
INFO - 2018-05-01 00:10:48 --> Config Class Initialized
INFO - 2018-05-01 00:10:48 --> Hooks Class Initialized
DEBUG - 2018-05-01 00:10:48 --> UTF-8 Support Enabled
INFO - 2018-05-01 00:10:48 --> Utf8 Class Initialized
INFO - 2018-05-01 00:10:48 --> URI Class Initialized
INFO - 2018-05-01 00:10:48 --> Router Class Initialized
INFO - 2018-05-01 00:10:48 --> Output Class Initialized
INFO - 2018-05-01 00:10:48 --> Security Class Initialized
DEBUG - 2018-05-01 00:10:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 00:10:48 --> CSRF cookie sent
INFO - 2018-05-01 00:10:48 --> Input Class Initialized
INFO - 2018-05-01 00:10:48 --> Language Class Initialized
INFO - 2018-05-01 00:10:48 --> Loader Class Initialized
INFO - 2018-05-01 00:10:48 --> Helper loaded: url_helper
INFO - 2018-05-01 00:10:48 --> Helper loaded: form_helper
INFO - 2018-05-01 00:10:48 --> Helper loaded: language_helper
DEBUG - 2018-05-01 00:10:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-01 00:10:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 00:10:48 --> User Agent Class Initialized
INFO - 2018-05-01 00:10:48 --> Controller Class Initialized
INFO - 2018-05-01 00:10:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-05-01 00:10:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-05-01 00:10:48 --> Pixel_Model class loaded
INFO - 2018-05-01 00:10:48 --> Database Driver Class Initialized
INFO - 2018-05-01 00:10:48 --> Model "RegistrationModel" initialized
DEBUG - 2018-05-01 00:10:48 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-05-01 00:10:48 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-05-01 00:10:48 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-05-01 00:10:48 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-05-01 00:10:48 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-05-01 00:10:48 --> Could not find the language line "req_email"
INFO - 2018-05-01 00:10:48 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-05-01 00:10:48 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-05-01 00:10:48 --> Final output sent to browser
DEBUG - 2018-05-01 00:10:48 --> Total execution time: 0.3062
INFO - 2018-05-01 00:11:06 --> Config Class Initialized
INFO - 2018-05-01 00:11:06 --> Hooks Class Initialized
DEBUG - 2018-05-01 00:11:06 --> UTF-8 Support Enabled
INFO - 2018-05-01 00:11:06 --> Utf8 Class Initialized
INFO - 2018-05-01 00:11:06 --> URI Class Initialized
INFO - 2018-05-01 00:11:06 --> Router Class Initialized
INFO - 2018-05-01 00:11:06 --> Output Class Initialized
INFO - 2018-05-01 00:11:06 --> Security Class Initialized
DEBUG - 2018-05-01 00:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 00:11:06 --> CSRF cookie sent
INFO - 2018-05-01 00:11:06 --> CSRF token verified
INFO - 2018-05-01 00:11:06 --> Input Class Initialized
INFO - 2018-05-01 00:11:06 --> Language Class Initialized
INFO - 2018-05-01 00:11:06 --> Loader Class Initialized
INFO - 2018-05-01 00:11:06 --> Helper loaded: url_helper
INFO - 2018-05-01 00:11:06 --> Helper loaded: form_helper
INFO - 2018-05-01 00:11:06 --> Helper loaded: language_helper
DEBUG - 2018-05-01 00:11:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-01 00:11:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 00:11:06 --> User Agent Class Initialized
INFO - 2018-05-01 00:11:06 --> Controller Class Initialized
INFO - 2018-05-01 00:11:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-05-01 00:11:06 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-05-01 00:11:06 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-05-01 00:11:06 --> Form Validation Class Initialized
INFO - 2018-05-01 00:11:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-05-01 00:11:06 --> Pixel_Model class loaded
INFO - 2018-05-01 00:11:06 --> Database Driver Class Initialized
INFO - 2018-05-01 00:11:06 --> Model "RegistrationModel" initialized
INFO - 2018-05-01 00:11:06 --> Helper loaded: string_helper
INFO - 2018-05-01 00:11:06 --> Language file loaded: language/en/notifications_lang.php
INFO - 2018-05-01 00:11:06 --> File loaded: E:\www\yacopoo\application\views\emails/_buttons.php
INFO - 2018-05-01 00:11:06 --> File loaded: E:\www\yacopoo\application\views\emails/header.php
INFO - 2018-05-01 00:11:06 --> File loaded: E:\www\yacopoo\application\views\emails/footer.php
INFO - 2018-05-01 00:11:06 --> File loaded: E:\www\yacopoo\application\views\emails/generic.php
INFO - 2018-05-01 00:11:06 --> Email Class Initialized
ERROR - 2018-05-01 00:11:07 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() E:\www\yacopoo\system\libraries\Email.php 1894
INFO - 2018-05-01 00:11:08 --> Language file loaded: language/english/email_lang.php
INFO - 2018-05-01 00:11:08 --> Database Driver Class Initialized
INFO - 2018-05-01 00:11:08 --> Model "QuestionsModel" initialized
INFO - 2018-05-01 00:11:08 --> Config Class Initialized
INFO - 2018-05-01 00:11:08 --> Hooks Class Initialized
DEBUG - 2018-05-01 00:11:08 --> UTF-8 Support Enabled
INFO - 2018-05-01 00:11:08 --> Utf8 Class Initialized
INFO - 2018-05-01 00:11:08 --> URI Class Initialized
INFO - 2018-05-01 00:11:08 --> Router Class Initialized
INFO - 2018-05-01 00:11:08 --> Output Class Initialized
INFO - 2018-05-01 00:11:08 --> Security Class Initialized
DEBUG - 2018-05-01 00:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 00:11:08 --> CSRF cookie sent
INFO - 2018-05-01 00:11:08 --> Input Class Initialized
INFO - 2018-05-01 00:11:08 --> Language Class Initialized
INFO - 2018-05-01 00:11:08 --> Loader Class Initialized
INFO - 2018-05-01 00:11:08 --> Helper loaded: url_helper
INFO - 2018-05-01 00:11:08 --> Helper loaded: form_helper
INFO - 2018-05-01 00:11:08 --> Helper loaded: language_helper
DEBUG - 2018-05-01 00:11:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-01 00:11:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 00:11:08 --> User Agent Class Initialized
INFO - 2018-05-01 00:11:08 --> Controller Class Initialized
INFO - 2018-05-01 00:11:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-05-01 00:11:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-05-01 00:11:08 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-05-01 00:11:08 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-05-01 00:11:08 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-05-01 00:11:08 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-05-01 00:11:08 --> File loaded: E:\www\yacopoo\application\views\register/thanks.php
INFO - 2018-05-01 00:11:08 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-05-01 00:11:08 --> Final output sent to browser
DEBUG - 2018-05-01 00:11:08 --> Total execution time: 0.2391
INFO - 2018-05-01 00:12:12 --> Config Class Initialized
INFO - 2018-05-01 00:12:12 --> Hooks Class Initialized
DEBUG - 2018-05-01 00:12:12 --> UTF-8 Support Enabled
INFO - 2018-05-01 00:12:12 --> Utf8 Class Initialized
INFO - 2018-05-01 00:12:12 --> URI Class Initialized
DEBUG - 2018-05-01 00:12:12 --> No URI present. Default controller set.
INFO - 2018-05-01 00:12:12 --> Router Class Initialized
INFO - 2018-05-01 00:12:12 --> Output Class Initialized
INFO - 2018-05-01 00:12:12 --> Security Class Initialized
DEBUG - 2018-05-01 00:12:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 00:12:12 --> CSRF cookie sent
INFO - 2018-05-01 00:12:12 --> Input Class Initialized
INFO - 2018-05-01 00:12:12 --> Language Class Initialized
INFO - 2018-05-01 00:12:12 --> Loader Class Initialized
INFO - 2018-05-01 00:12:12 --> Helper loaded: url_helper
INFO - 2018-05-01 00:12:12 --> Helper loaded: form_helper
INFO - 2018-05-01 00:12:12 --> Helper loaded: language_helper
DEBUG - 2018-05-01 00:12:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-01 00:12:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 00:12:12 --> User Agent Class Initialized
INFO - 2018-05-01 00:12:12 --> Controller Class Initialized
INFO - 2018-05-01 00:12:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-05-01 00:12:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-05-01 00:12:12 --> Pixel_Model class loaded
INFO - 2018-05-01 00:12:12 --> Database Driver Class Initialized
INFO - 2018-05-01 00:12:12 --> Model "QuestionsModel" initialized
INFO - 2018-05-01 00:12:12 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-05-01 00:12:12 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-05-01 00:12:12 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-05-01 00:12:12 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-05-01 00:12:12 --> Final output sent to browser
DEBUG - 2018-05-01 00:12:12 --> Total execution time: 0.3020
INFO - 2018-05-01 00:12:14 --> Config Class Initialized
INFO - 2018-05-01 00:12:14 --> Hooks Class Initialized
DEBUG - 2018-05-01 00:12:14 --> UTF-8 Support Enabled
INFO - 2018-05-01 00:12:14 --> Utf8 Class Initialized
INFO - 2018-05-01 00:12:14 --> URI Class Initialized
INFO - 2018-05-01 00:12:14 --> Router Class Initialized
INFO - 2018-05-01 00:12:14 --> Output Class Initialized
INFO - 2018-05-01 00:12:14 --> Security Class Initialized
DEBUG - 2018-05-01 00:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 00:12:14 --> CSRF cookie sent
INFO - 2018-05-01 00:12:14 --> Input Class Initialized
INFO - 2018-05-01 00:12:14 --> Language Class Initialized
ERROR - 2018-05-01 00:12:14 --> 404 Page Not Found: Revolution/assets
INFO - 2018-05-01 00:12:19 --> Config Class Initialized
INFO - 2018-05-01 00:12:19 --> Hooks Class Initialized
DEBUG - 2018-05-01 00:12:19 --> UTF-8 Support Enabled
INFO - 2018-05-01 00:12:19 --> Utf8 Class Initialized
INFO - 2018-05-01 00:12:19 --> URI Class Initialized
INFO - 2018-05-01 00:12:19 --> Router Class Initialized
INFO - 2018-05-01 00:12:19 --> Output Class Initialized
INFO - 2018-05-01 00:12:19 --> Security Class Initialized
DEBUG - 2018-05-01 00:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 00:12:19 --> CSRF cookie sent
INFO - 2018-05-01 00:12:19 --> CSRF token verified
INFO - 2018-05-01 00:12:19 --> Input Class Initialized
INFO - 2018-05-01 00:12:19 --> Language Class Initialized
INFO - 2018-05-01 00:12:19 --> Loader Class Initialized
INFO - 2018-05-01 00:12:19 --> Helper loaded: url_helper
INFO - 2018-05-01 00:12:19 --> Helper loaded: form_helper
INFO - 2018-05-01 00:12:19 --> Helper loaded: language_helper
DEBUG - 2018-05-01 00:12:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-01 00:12:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 00:12:19 --> User Agent Class Initialized
INFO - 2018-05-01 00:12:19 --> Controller Class Initialized
INFO - 2018-05-01 00:12:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-05-01 00:12:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-05-01 00:12:19 --> Pixel_Model class loaded
INFO - 2018-05-01 00:12:19 --> Database Driver Class Initialized
INFO - 2018-05-01 00:12:19 --> Model "QuestionsModel" initialized
ERROR - 2018-05-01 00:12:19 --> Severity: Notice --> Undefined variable: appDate E:\www\yacopoo\application\controllers\QuestionnaireController.php 29
INFO - 2018-05-01 00:12:19 --> Config Class Initialized
INFO - 2018-05-01 00:12:19 --> Hooks Class Initialized
DEBUG - 2018-05-01 00:12:19 --> UTF-8 Support Enabled
INFO - 2018-05-01 00:12:19 --> Utf8 Class Initialized
INFO - 2018-05-01 00:12:19 --> URI Class Initialized
INFO - 2018-05-01 00:12:19 --> Router Class Initialized
INFO - 2018-05-01 00:12:19 --> Output Class Initialized
INFO - 2018-05-01 00:12:19 --> Security Class Initialized
DEBUG - 2018-05-01 00:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 00:12:19 --> CSRF cookie sent
INFO - 2018-05-01 00:12:19 --> Input Class Initialized
INFO - 2018-05-01 00:12:19 --> Language Class Initialized
INFO - 2018-05-01 00:12:19 --> Loader Class Initialized
INFO - 2018-05-01 00:12:19 --> Helper loaded: url_helper
INFO - 2018-05-01 00:12:19 --> Helper loaded: form_helper
INFO - 2018-05-01 00:12:19 --> Helper loaded: language_helper
DEBUG - 2018-05-01 00:12:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-01 00:12:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 00:12:19 --> User Agent Class Initialized
INFO - 2018-05-01 00:12:19 --> Controller Class Initialized
INFO - 2018-05-01 00:12:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-05-01 00:12:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-05-01 00:12:19 --> Pixel_Model class loaded
INFO - 2018-05-01 00:12:19 --> Database Driver Class Initialized
INFO - 2018-05-01 00:12:19 --> Model "RegistrationModel" initialized
DEBUG - 2018-05-01 00:12:19 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-05-01 00:12:19 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-05-01 00:12:19 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-05-01 00:12:19 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-05-01 00:12:19 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-05-01 00:12:19 --> Could not find the language line "req_email"
INFO - 2018-05-01 00:12:19 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-05-01 00:12:19 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-05-01 00:12:19 --> Final output sent to browser
DEBUG - 2018-05-01 00:12:19 --> Total execution time: 0.3148
INFO - 2018-05-01 00:12:36 --> Config Class Initialized
INFO - 2018-05-01 00:12:36 --> Hooks Class Initialized
DEBUG - 2018-05-01 00:12:36 --> UTF-8 Support Enabled
INFO - 2018-05-01 00:12:36 --> Utf8 Class Initialized
INFO - 2018-05-01 00:12:36 --> URI Class Initialized
INFO - 2018-05-01 00:12:36 --> Router Class Initialized
INFO - 2018-05-01 00:12:36 --> Output Class Initialized
INFO - 2018-05-01 00:12:36 --> Security Class Initialized
DEBUG - 2018-05-01 00:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 00:12:36 --> CSRF cookie sent
INFO - 2018-05-01 00:12:36 --> CSRF token verified
INFO - 2018-05-01 00:12:36 --> Input Class Initialized
INFO - 2018-05-01 00:12:36 --> Language Class Initialized
INFO - 2018-05-01 00:12:36 --> Loader Class Initialized
INFO - 2018-05-01 00:12:36 --> Helper loaded: url_helper
INFO - 2018-05-01 00:12:36 --> Helper loaded: form_helper
INFO - 2018-05-01 00:12:36 --> Helper loaded: language_helper
DEBUG - 2018-05-01 00:12:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-01 00:12:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 00:12:36 --> User Agent Class Initialized
INFO - 2018-05-01 00:12:36 --> Controller Class Initialized
INFO - 2018-05-01 00:12:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-05-01 00:12:36 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-05-01 00:12:36 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-05-01 00:12:36 --> Form Validation Class Initialized
INFO - 2018-05-01 00:12:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-05-01 00:12:36 --> Pixel_Model class loaded
INFO - 2018-05-01 00:12:36 --> Database Driver Class Initialized
INFO - 2018-05-01 00:12:36 --> Model "RegistrationModel" initialized
INFO - 2018-05-01 00:12:36 --> Helper loaded: string_helper
INFO - 2018-05-01 00:12:36 --> Language file loaded: language/en/notifications_lang.php
INFO - 2018-05-01 00:12:36 --> File loaded: E:\www\yacopoo\application\views\emails/_buttons.php
INFO - 2018-05-01 00:12:36 --> File loaded: E:\www\yacopoo\application\views\emails/header.php
INFO - 2018-05-01 00:12:36 --> File loaded: E:\www\yacopoo\application\views\emails/footer.php
INFO - 2018-05-01 00:12:36 --> File loaded: E:\www\yacopoo\application\views\emails/generic.php
INFO - 2018-05-01 00:12:36 --> Email Class Initialized
ERROR - 2018-05-01 00:12:37 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() E:\www\yacopoo\system\libraries\Email.php 1894
INFO - 2018-05-01 00:12:37 --> Language file loaded: language/english/email_lang.php
INFO - 2018-05-01 00:12:37 --> Database Driver Class Initialized
INFO - 2018-05-01 00:12:37 --> Model "QuestionsModel" initialized
INFO - 2018-05-01 00:13:09 --> Config Class Initialized
INFO - 2018-05-01 00:13:09 --> Hooks Class Initialized
DEBUG - 2018-05-01 00:13:09 --> UTF-8 Support Enabled
INFO - 2018-05-01 00:13:09 --> Utf8 Class Initialized
INFO - 2018-05-01 00:13:09 --> URI Class Initialized
INFO - 2018-05-01 00:13:09 --> Router Class Initialized
INFO - 2018-05-01 00:13:09 --> Output Class Initialized
INFO - 2018-05-01 00:13:09 --> Security Class Initialized
DEBUG - 2018-05-01 00:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 00:13:09 --> CSRF cookie sent
INFO - 2018-05-01 00:13:09 --> CSRF token verified
INFO - 2018-05-01 00:13:09 --> Input Class Initialized
INFO - 2018-05-01 00:13:09 --> Language Class Initialized
INFO - 2018-05-01 00:13:09 --> Loader Class Initialized
INFO - 2018-05-01 00:13:09 --> Helper loaded: url_helper
INFO - 2018-05-01 00:13:09 --> Helper loaded: form_helper
INFO - 2018-05-01 00:13:09 --> Helper loaded: language_helper
DEBUG - 2018-05-01 00:13:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-01 00:13:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 00:13:09 --> User Agent Class Initialized
INFO - 2018-05-01 00:13:09 --> Controller Class Initialized
INFO - 2018-05-01 00:13:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-05-01 00:13:09 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-05-01 00:13:09 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-05-01 00:13:09 --> Config Class Initialized
INFO - 2018-05-01 00:13:09 --> Hooks Class Initialized
DEBUG - 2018-05-01 00:13:09 --> UTF-8 Support Enabled
INFO - 2018-05-01 00:13:09 --> Utf8 Class Initialized
INFO - 2018-05-01 00:13:09 --> URI Class Initialized
INFO - 2018-05-01 00:13:09 --> Router Class Initialized
INFO - 2018-05-01 00:13:09 --> Output Class Initialized
INFO - 2018-05-01 00:13:09 --> Security Class Initialized
DEBUG - 2018-05-01 00:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 00:13:09 --> CSRF cookie sent
INFO - 2018-05-01 00:13:09 --> Input Class Initialized
INFO - 2018-05-01 00:13:09 --> Language Class Initialized
INFO - 2018-05-01 00:13:09 --> Loader Class Initialized
INFO - 2018-05-01 00:13:09 --> Helper loaded: url_helper
INFO - 2018-05-01 00:13:09 --> Helper loaded: form_helper
INFO - 2018-05-01 00:13:09 --> Helper loaded: language_helper
DEBUG - 2018-05-01 00:13:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-01 00:13:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 00:13:09 --> User Agent Class Initialized
INFO - 2018-05-01 00:13:09 --> Controller Class Initialized
INFO - 2018-05-01 00:13:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-05-01 00:13:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-05-01 00:13:09 --> Pixel_Model class loaded
INFO - 2018-05-01 00:13:09 --> Database Driver Class Initialized
INFO - 2018-05-01 00:13:09 --> Model "RegistrationModel" initialized
DEBUG - 2018-05-01 00:13:09 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-05-01 00:13:09 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-05-01 00:13:09 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-05-01 00:13:09 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-05-01 00:13:09 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-05-01 00:13:09 --> File loaded: E:\www\yacopoo\application\views\shared/_soft_error.php
ERROR - 2018-05-01 00:13:09 --> Could not find the language line "req_email"
INFO - 2018-05-01 00:13:09 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-05-01 00:13:09 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-05-01 00:13:09 --> Final output sent to browser
DEBUG - 2018-05-01 00:13:09 --> Total execution time: 0.3189
INFO - 2018-05-01 00:13:43 --> Config Class Initialized
INFO - 2018-05-01 00:13:43 --> Hooks Class Initialized
DEBUG - 2018-05-01 00:13:43 --> UTF-8 Support Enabled
INFO - 2018-05-01 00:13:43 --> Utf8 Class Initialized
INFO - 2018-05-01 00:13:43 --> URI Class Initialized
INFO - 2018-05-01 00:13:43 --> Router Class Initialized
INFO - 2018-05-01 00:13:43 --> Output Class Initialized
INFO - 2018-05-01 00:13:43 --> Security Class Initialized
DEBUG - 2018-05-01 00:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 00:13:43 --> CSRF cookie sent
INFO - 2018-05-01 00:13:43 --> CSRF token verified
INFO - 2018-05-01 00:13:43 --> Input Class Initialized
INFO - 2018-05-01 00:13:43 --> Language Class Initialized
INFO - 2018-05-01 00:13:43 --> Loader Class Initialized
INFO - 2018-05-01 00:13:43 --> Helper loaded: url_helper
INFO - 2018-05-01 00:13:43 --> Helper loaded: form_helper
INFO - 2018-05-01 00:13:43 --> Helper loaded: language_helper
DEBUG - 2018-05-01 00:13:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-01 00:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 00:13:43 --> User Agent Class Initialized
INFO - 2018-05-01 00:13:43 --> Controller Class Initialized
INFO - 2018-05-01 00:13:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-05-01 00:13:43 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-05-01 00:13:43 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-05-01 00:13:43 --> Form Validation Class Initialized
INFO - 2018-05-01 00:13:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-05-01 00:13:43 --> Pixel_Model class loaded
INFO - 2018-05-01 00:13:43 --> Database Driver Class Initialized
INFO - 2018-05-01 00:13:43 --> Model "RegistrationModel" initialized
INFO - 2018-05-01 00:13:43 --> Helper loaded: string_helper
INFO - 2018-05-01 00:13:43 --> Language file loaded: language/en/notifications_lang.php
INFO - 2018-05-01 00:13:44 --> Database Driver Class Initialized
INFO - 2018-05-01 00:13:44 --> Model "QuestionsModel" initialized
INFO - 2018-05-01 00:16:09 --> Config Class Initialized
INFO - 2018-05-01 00:16:09 --> Hooks Class Initialized
DEBUG - 2018-05-01 00:16:09 --> UTF-8 Support Enabled
INFO - 2018-05-01 00:16:09 --> Utf8 Class Initialized
INFO - 2018-05-01 00:16:09 --> URI Class Initialized
INFO - 2018-05-01 00:16:09 --> Router Class Initialized
INFO - 2018-05-01 00:16:09 --> Output Class Initialized
INFO - 2018-05-01 00:16:09 --> Security Class Initialized
DEBUG - 2018-05-01 00:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 00:16:09 --> CSRF cookie sent
INFO - 2018-05-01 00:16:09 --> Input Class Initialized
INFO - 2018-05-01 00:16:09 --> Language Class Initialized
INFO - 2018-05-01 00:16:09 --> Loader Class Initialized
INFO - 2018-05-01 00:16:09 --> Helper loaded: url_helper
INFO - 2018-05-01 00:16:09 --> Helper loaded: form_helper
INFO - 2018-05-01 00:16:09 --> Helper loaded: language_helper
DEBUG - 2018-05-01 00:16:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-01 00:16:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 00:16:09 --> User Agent Class Initialized
INFO - 2018-05-01 00:16:09 --> Controller Class Initialized
INFO - 2018-05-01 00:16:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-05-01 00:16:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-05-01 00:16:09 --> Pixel_Model class loaded
INFO - 2018-05-01 00:16:09 --> Database Driver Class Initialized
INFO - 2018-05-01 00:16:09 --> Model "RegistrationModel" initialized
DEBUG - 2018-05-01 00:16:09 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-05-01 00:16:09 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-05-01 00:16:09 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-05-01 00:16:09 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-05-01 00:16:09 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-05-01 00:16:09 --> Could not find the language line "req_email"
INFO - 2018-05-01 00:16:09 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-05-01 00:16:09 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-05-01 00:16:09 --> Final output sent to browser
DEBUG - 2018-05-01 00:16:09 --> Total execution time: 0.3138
INFO - 2018-05-01 00:16:12 --> Config Class Initialized
INFO - 2018-05-01 00:16:12 --> Hooks Class Initialized
DEBUG - 2018-05-01 00:16:12 --> UTF-8 Support Enabled
INFO - 2018-05-01 00:16:12 --> Utf8 Class Initialized
INFO - 2018-05-01 00:16:12 --> URI Class Initialized
INFO - 2018-05-01 00:16:12 --> Router Class Initialized
INFO - 2018-05-01 00:16:12 --> Output Class Initialized
INFO - 2018-05-01 00:16:12 --> Security Class Initialized
DEBUG - 2018-05-01 00:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 00:16:12 --> CSRF cookie sent
INFO - 2018-05-01 00:16:12 --> Input Class Initialized
INFO - 2018-05-01 00:16:12 --> Language Class Initialized
INFO - 2018-05-01 00:16:12 --> Loader Class Initialized
INFO - 2018-05-01 00:16:12 --> Helper loaded: url_helper
INFO - 2018-05-01 00:16:12 --> Helper loaded: form_helper
INFO - 2018-05-01 00:16:12 --> Helper loaded: language_helper
DEBUG - 2018-05-01 00:16:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-01 00:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 00:16:12 --> User Agent Class Initialized
INFO - 2018-05-01 00:16:12 --> Controller Class Initialized
INFO - 2018-05-01 00:16:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-05-01 00:16:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-05-01 00:16:12 --> Pixel_Model class loaded
INFO - 2018-05-01 00:16:12 --> Database Driver Class Initialized
INFO - 2018-05-01 00:16:12 --> Model "RegistrationModel" initialized
DEBUG - 2018-05-01 00:16:12 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-05-01 00:16:12 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-05-01 00:16:12 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-05-01 00:16:12 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-05-01 00:16:12 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-05-01 00:16:12 --> Could not find the language line "req_email"
INFO - 2018-05-01 00:16:12 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-05-01 00:16:12 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-05-01 00:16:12 --> Final output sent to browser
DEBUG - 2018-05-01 00:16:12 --> Total execution time: 0.3114
INFO - 2018-05-01 00:16:32 --> Config Class Initialized
INFO - 2018-05-01 00:16:32 --> Hooks Class Initialized
DEBUG - 2018-05-01 00:16:32 --> UTF-8 Support Enabled
INFO - 2018-05-01 00:16:32 --> Utf8 Class Initialized
INFO - 2018-05-01 00:16:32 --> URI Class Initialized
INFO - 2018-05-01 00:16:32 --> Router Class Initialized
INFO - 2018-05-01 00:16:32 --> Output Class Initialized
INFO - 2018-05-01 00:16:32 --> Security Class Initialized
DEBUG - 2018-05-01 00:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 00:16:32 --> CSRF cookie sent
INFO - 2018-05-01 00:16:32 --> CSRF token verified
INFO - 2018-05-01 00:16:32 --> Input Class Initialized
INFO - 2018-05-01 00:16:32 --> Language Class Initialized
INFO - 2018-05-01 00:16:32 --> Loader Class Initialized
INFO - 2018-05-01 00:16:33 --> Helper loaded: url_helper
INFO - 2018-05-01 00:16:33 --> Helper loaded: form_helper
INFO - 2018-05-01 00:16:33 --> Helper loaded: language_helper
DEBUG - 2018-05-01 00:16:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-01 00:16:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 00:16:33 --> User Agent Class Initialized
INFO - 2018-05-01 00:16:33 --> Controller Class Initialized
INFO - 2018-05-01 00:16:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-05-01 00:16:33 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-05-01 00:16:33 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-05-01 00:16:33 --> Form Validation Class Initialized
INFO - 2018-05-01 00:16:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-05-01 00:16:33 --> Pixel_Model class loaded
INFO - 2018-05-01 00:16:33 --> Database Driver Class Initialized
INFO - 2018-05-01 00:16:33 --> Model "RegistrationModel" initialized
INFO - 2018-05-01 00:16:33 --> Helper loaded: string_helper
INFO - 2018-05-01 00:16:33 --> Language file loaded: language/en/notifications_lang.php
INFO - 2018-05-01 00:16:33 --> Database Driver Class Initialized
INFO - 2018-05-01 00:16:33 --> Model "QuestionsModel" initialized
ERROR - 2018-05-01 00:16:33 --> Query error: Unknown column 'session_ids' in 'where clause' - Invalid query: UPDATE `applications` SET `user_id` = '51'
WHERE `session_ids` = 'qb4kibd7ta3ntag0eno7785j08uilpp3'
AND `user_id` =0
INFO - 2018-05-01 00:16:33 --> Language file loaded: language/english/db_lang.php
INFO - 2018-05-01 00:17:40 --> Config Class Initialized
INFO - 2018-05-01 00:17:40 --> Hooks Class Initialized
DEBUG - 2018-05-01 00:17:40 --> UTF-8 Support Enabled
INFO - 2018-05-01 00:17:40 --> Utf8 Class Initialized
INFO - 2018-05-01 00:17:40 --> URI Class Initialized
DEBUG - 2018-05-01 00:17:40 --> No URI present. Default controller set.
INFO - 2018-05-01 00:17:40 --> Router Class Initialized
INFO - 2018-05-01 00:17:40 --> Output Class Initialized
INFO - 2018-05-01 00:17:40 --> Security Class Initialized
DEBUG - 2018-05-01 00:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 00:17:40 --> CSRF cookie sent
INFO - 2018-05-01 00:17:40 --> Input Class Initialized
INFO - 2018-05-01 00:17:40 --> Language Class Initialized
INFO - 2018-05-01 00:17:40 --> Loader Class Initialized
INFO - 2018-05-01 00:17:40 --> Helper loaded: url_helper
INFO - 2018-05-01 00:17:40 --> Helper loaded: form_helper
INFO - 2018-05-01 00:17:40 --> Helper loaded: language_helper
DEBUG - 2018-05-01 00:17:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-01 00:17:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 00:17:40 --> User Agent Class Initialized
INFO - 2018-05-01 00:17:40 --> Controller Class Initialized
INFO - 2018-05-01 00:17:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-05-01 00:17:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-05-01 00:17:40 --> Pixel_Model class loaded
INFO - 2018-05-01 00:17:40 --> Database Driver Class Initialized
INFO - 2018-05-01 00:17:40 --> Model "QuestionsModel" initialized
INFO - 2018-05-01 00:17:40 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-05-01 00:17:40 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-05-01 00:17:40 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-05-01 00:17:41 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-05-01 00:17:41 --> Final output sent to browser
DEBUG - 2018-05-01 00:17:41 --> Total execution time: 0.2956
INFO - 2018-05-01 00:17:42 --> Config Class Initialized
INFO - 2018-05-01 00:17:42 --> Hooks Class Initialized
DEBUG - 2018-05-01 00:17:42 --> UTF-8 Support Enabled
INFO - 2018-05-01 00:17:42 --> Utf8 Class Initialized
INFO - 2018-05-01 00:17:42 --> URI Class Initialized
INFO - 2018-05-01 00:17:42 --> Router Class Initialized
INFO - 2018-05-01 00:17:42 --> Output Class Initialized
INFO - 2018-05-01 00:17:42 --> Security Class Initialized
DEBUG - 2018-05-01 00:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 00:17:42 --> CSRF cookie sent
INFO - 2018-05-01 00:17:42 --> Input Class Initialized
INFO - 2018-05-01 00:17:42 --> Language Class Initialized
ERROR - 2018-05-01 00:17:42 --> 404 Page Not Found: Revolution/assets
INFO - 2018-05-01 00:17:48 --> Config Class Initialized
INFO - 2018-05-01 00:17:48 --> Hooks Class Initialized
DEBUG - 2018-05-01 00:17:48 --> UTF-8 Support Enabled
INFO - 2018-05-01 00:17:48 --> Utf8 Class Initialized
INFO - 2018-05-01 00:17:48 --> URI Class Initialized
INFO - 2018-05-01 00:17:48 --> Router Class Initialized
INFO - 2018-05-01 00:17:48 --> Output Class Initialized
INFO - 2018-05-01 00:17:48 --> Security Class Initialized
DEBUG - 2018-05-01 00:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 00:17:48 --> CSRF cookie sent
INFO - 2018-05-01 00:17:48 --> CSRF token verified
INFO - 2018-05-01 00:17:48 --> Input Class Initialized
INFO - 2018-05-01 00:17:48 --> Language Class Initialized
INFO - 2018-05-01 00:17:48 --> Loader Class Initialized
INFO - 2018-05-01 00:17:48 --> Helper loaded: url_helper
INFO - 2018-05-01 00:17:48 --> Helper loaded: form_helper
INFO - 2018-05-01 00:17:48 --> Helper loaded: language_helper
DEBUG - 2018-05-01 00:17:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-01 00:17:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 00:17:48 --> User Agent Class Initialized
INFO - 2018-05-01 00:17:48 --> Controller Class Initialized
INFO - 2018-05-01 00:17:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-05-01 00:17:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-05-01 00:17:48 --> Pixel_Model class loaded
INFO - 2018-05-01 00:17:48 --> Database Driver Class Initialized
INFO - 2018-05-01 00:17:48 --> Model "QuestionsModel" initialized
ERROR - 2018-05-01 00:17:48 --> Severity: Notice --> Undefined variable: appDate E:\www\yacopoo\application\controllers\QuestionnaireController.php 29
INFO - 2018-05-01 00:17:48 --> Config Class Initialized
INFO - 2018-05-01 00:17:48 --> Hooks Class Initialized
DEBUG - 2018-05-01 00:17:48 --> UTF-8 Support Enabled
INFO - 2018-05-01 00:17:48 --> Utf8 Class Initialized
INFO - 2018-05-01 00:17:48 --> URI Class Initialized
INFO - 2018-05-01 00:17:48 --> Router Class Initialized
INFO - 2018-05-01 00:17:48 --> Output Class Initialized
INFO - 2018-05-01 00:17:48 --> Security Class Initialized
DEBUG - 2018-05-01 00:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 00:17:49 --> CSRF cookie sent
INFO - 2018-05-01 00:17:49 --> Input Class Initialized
INFO - 2018-05-01 00:17:49 --> Language Class Initialized
INFO - 2018-05-01 00:17:49 --> Loader Class Initialized
INFO - 2018-05-01 00:17:49 --> Helper loaded: url_helper
INFO - 2018-05-01 00:17:49 --> Helper loaded: form_helper
INFO - 2018-05-01 00:17:49 --> Helper loaded: language_helper
DEBUG - 2018-05-01 00:17:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-01 00:17:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 00:17:49 --> User Agent Class Initialized
INFO - 2018-05-01 00:17:49 --> Controller Class Initialized
INFO - 2018-05-01 00:17:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-05-01 00:17:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-05-01 00:17:49 --> Pixel_Model class loaded
INFO - 2018-05-01 00:17:49 --> Database Driver Class Initialized
INFO - 2018-05-01 00:17:49 --> Model "RegistrationModel" initialized
DEBUG - 2018-05-01 00:17:49 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-05-01 00:17:49 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-05-01 00:17:49 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-05-01 00:17:49 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-05-01 00:17:49 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-05-01 00:17:49 --> Could not find the language line "req_email"
INFO - 2018-05-01 00:17:49 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-05-01 00:17:49 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-05-01 00:17:49 --> Final output sent to browser
DEBUG - 2018-05-01 00:17:49 --> Total execution time: 0.3295
INFO - 2018-05-01 00:18:24 --> Config Class Initialized
INFO - 2018-05-01 00:18:24 --> Hooks Class Initialized
DEBUG - 2018-05-01 00:18:24 --> UTF-8 Support Enabled
INFO - 2018-05-01 00:18:24 --> Utf8 Class Initialized
INFO - 2018-05-01 00:18:24 --> URI Class Initialized
INFO - 2018-05-01 00:18:24 --> Router Class Initialized
INFO - 2018-05-01 00:18:24 --> Output Class Initialized
INFO - 2018-05-01 00:18:24 --> Security Class Initialized
DEBUG - 2018-05-01 00:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 00:18:24 --> CSRF cookie sent
INFO - 2018-05-01 00:18:24 --> CSRF token verified
INFO - 2018-05-01 00:18:24 --> Input Class Initialized
INFO - 2018-05-01 00:18:24 --> Language Class Initialized
INFO - 2018-05-01 00:18:24 --> Loader Class Initialized
INFO - 2018-05-01 00:18:24 --> Helper loaded: url_helper
INFO - 2018-05-01 00:18:24 --> Helper loaded: form_helper
INFO - 2018-05-01 00:18:24 --> Helper loaded: language_helper
DEBUG - 2018-05-01 00:18:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-01 00:18:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 00:18:24 --> User Agent Class Initialized
INFO - 2018-05-01 00:18:24 --> Controller Class Initialized
INFO - 2018-05-01 00:18:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-05-01 00:18:24 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-05-01 00:18:24 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-05-01 00:18:25 --> Form Validation Class Initialized
INFO - 2018-05-01 00:18:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-05-01 00:18:25 --> Pixel_Model class loaded
INFO - 2018-05-01 00:18:25 --> Database Driver Class Initialized
INFO - 2018-05-01 00:18:25 --> Model "RegistrationModel" initialized
INFO - 2018-05-01 00:18:25 --> Helper loaded: string_helper
INFO - 2018-05-01 00:18:25 --> Language file loaded: language/en/notifications_lang.php
INFO - 2018-05-01 00:18:25 --> Database Driver Class Initialized
INFO - 2018-05-01 00:18:25 --> Model "QuestionsModel" initialized
INFO - 2018-05-01 00:23:35 --> Config Class Initialized
INFO - 2018-05-01 00:23:35 --> Hooks Class Initialized
DEBUG - 2018-05-01 00:23:35 --> UTF-8 Support Enabled
INFO - 2018-05-01 00:23:35 --> Utf8 Class Initialized
INFO - 2018-05-01 00:23:35 --> URI Class Initialized
DEBUG - 2018-05-01 00:23:35 --> No URI present. Default controller set.
INFO - 2018-05-01 00:23:35 --> Router Class Initialized
INFO - 2018-05-01 00:23:35 --> Output Class Initialized
INFO - 2018-05-01 00:23:35 --> Security Class Initialized
DEBUG - 2018-05-01 00:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 00:23:35 --> CSRF cookie sent
INFO - 2018-05-01 00:23:35 --> Input Class Initialized
INFO - 2018-05-01 00:23:35 --> Language Class Initialized
INFO - 2018-05-01 00:23:35 --> Loader Class Initialized
INFO - 2018-05-01 00:23:35 --> Helper loaded: url_helper
INFO - 2018-05-01 00:23:35 --> Helper loaded: form_helper
INFO - 2018-05-01 00:23:35 --> Helper loaded: language_helper
DEBUG - 2018-05-01 00:23:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-01 00:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 00:23:35 --> User Agent Class Initialized
INFO - 2018-05-01 00:23:35 --> Controller Class Initialized
INFO - 2018-05-01 00:23:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-05-01 00:23:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-05-01 00:23:35 --> Pixel_Model class loaded
INFO - 2018-05-01 00:23:35 --> Database Driver Class Initialized
INFO - 2018-05-01 00:23:35 --> Model "QuestionsModel" initialized
INFO - 2018-05-01 00:23:35 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-05-01 00:23:35 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-05-01 00:23:35 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-05-01 00:23:35 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-05-01 00:23:35 --> Final output sent to browser
DEBUG - 2018-05-01 00:23:35 --> Total execution time: 0.3159
INFO - 2018-05-01 00:23:36 --> Config Class Initialized
INFO - 2018-05-01 00:23:36 --> Hooks Class Initialized
DEBUG - 2018-05-01 00:23:36 --> UTF-8 Support Enabled
INFO - 2018-05-01 00:23:36 --> Utf8 Class Initialized
INFO - 2018-05-01 00:23:36 --> URI Class Initialized
INFO - 2018-05-01 00:23:36 --> Router Class Initialized
INFO - 2018-05-01 00:23:36 --> Output Class Initialized
INFO - 2018-05-01 00:23:36 --> Security Class Initialized
DEBUG - 2018-05-01 00:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 00:23:36 --> CSRF cookie sent
INFO - 2018-05-01 00:23:36 --> Input Class Initialized
INFO - 2018-05-01 00:23:36 --> Language Class Initialized
ERROR - 2018-05-01 00:23:36 --> 404 Page Not Found: Revolution/assets
INFO - 2018-05-01 00:23:38 --> Config Class Initialized
INFO - 2018-05-01 00:23:38 --> Hooks Class Initialized
DEBUG - 2018-05-01 00:23:38 --> UTF-8 Support Enabled
INFO - 2018-05-01 00:23:38 --> Utf8 Class Initialized
INFO - 2018-05-01 00:23:38 --> URI Class Initialized
INFO - 2018-05-01 00:23:38 --> Router Class Initialized
INFO - 2018-05-01 00:23:38 --> Output Class Initialized
INFO - 2018-05-01 00:23:38 --> Security Class Initialized
DEBUG - 2018-05-01 00:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 00:23:38 --> CSRF cookie sent
INFO - 2018-05-01 00:23:38 --> Input Class Initialized
INFO - 2018-05-01 00:23:38 --> Language Class Initialized
INFO - 2018-05-01 00:23:38 --> Loader Class Initialized
INFO - 2018-05-01 00:23:38 --> Helper loaded: url_helper
INFO - 2018-05-01 00:23:38 --> Helper loaded: form_helper
INFO - 2018-05-01 00:23:38 --> Helper loaded: language_helper
DEBUG - 2018-05-01 00:23:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-01 00:23:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 00:23:38 --> User Agent Class Initialized
INFO - 2018-05-01 00:23:38 --> Controller Class Initialized
INFO - 2018-05-01 00:23:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-05-01 00:23:38 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-05-01 00:23:38 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-05-01 00:23:38 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-05-01 00:23:38 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-05-01 00:23:38 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-05-01 00:23:38 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-05-01 00:23:38 --> Could not find the language line "req_email"
INFO - 2018-05-01 00:23:38 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-05-01 00:23:38 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-05-01 00:23:38 --> Final output sent to browser
DEBUG - 2018-05-01 00:23:38 --> Total execution time: 0.3189
INFO - 2018-05-01 00:23:48 --> Config Class Initialized
INFO - 2018-05-01 00:23:48 --> Hooks Class Initialized
DEBUG - 2018-05-01 00:23:48 --> UTF-8 Support Enabled
INFO - 2018-05-01 00:23:48 --> Utf8 Class Initialized
INFO - 2018-05-01 00:23:48 --> URI Class Initialized
INFO - 2018-05-01 00:23:48 --> Router Class Initialized
INFO - 2018-05-01 00:23:48 --> Output Class Initialized
INFO - 2018-05-01 00:23:48 --> Security Class Initialized
DEBUG - 2018-05-01 00:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 00:23:48 --> CSRF cookie sent
INFO - 2018-05-01 00:23:48 --> CSRF token verified
INFO - 2018-05-01 00:23:48 --> Input Class Initialized
INFO - 2018-05-01 00:23:48 --> Language Class Initialized
INFO - 2018-05-01 00:23:48 --> Loader Class Initialized
INFO - 2018-05-01 00:23:48 --> Helper loaded: url_helper
INFO - 2018-05-01 00:23:48 --> Helper loaded: form_helper
INFO - 2018-05-01 00:23:48 --> Helper loaded: language_helper
DEBUG - 2018-05-01 00:23:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-01 00:23:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 00:23:48 --> User Agent Class Initialized
INFO - 2018-05-01 00:23:48 --> Controller Class Initialized
INFO - 2018-05-01 00:23:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-05-01 00:23:48 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-05-01 00:23:48 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-05-01 00:23:48 --> Form Validation Class Initialized
INFO - 2018-05-01 00:23:49 --> Pixel_Model class loaded
INFO - 2018-05-01 00:23:49 --> Database Driver Class Initialized
INFO - 2018-05-01 00:23:49 --> Model "AuthenticationModel" initialized
INFO - 2018-05-01 00:23:49 --> Config Class Initialized
INFO - 2018-05-01 00:23:49 --> Hooks Class Initialized
DEBUG - 2018-05-01 00:23:49 --> UTF-8 Support Enabled
INFO - 2018-05-01 00:23:49 --> Utf8 Class Initialized
INFO - 2018-05-01 00:23:49 --> URI Class Initialized
DEBUG - 2018-05-01 00:23:49 --> No URI present. Default controller set.
INFO - 2018-05-01 00:23:49 --> Router Class Initialized
INFO - 2018-05-01 00:23:49 --> Output Class Initialized
INFO - 2018-05-01 00:23:49 --> Security Class Initialized
DEBUG - 2018-05-01 00:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 00:23:49 --> CSRF cookie sent
INFO - 2018-05-01 00:23:49 --> Input Class Initialized
INFO - 2018-05-01 00:23:49 --> Language Class Initialized
INFO - 2018-05-01 00:23:49 --> Loader Class Initialized
INFO - 2018-05-01 00:23:49 --> Helper loaded: url_helper
INFO - 2018-05-01 00:23:49 --> Helper loaded: form_helper
INFO - 2018-05-01 00:23:49 --> Helper loaded: language_helper
DEBUG - 2018-05-01 00:23:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-01 00:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 00:23:49 --> User Agent Class Initialized
INFO - 2018-05-01 00:23:49 --> Controller Class Initialized
INFO - 2018-05-01 00:23:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-05-01 00:23:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-05-01 00:23:49 --> Pixel_Model class loaded
INFO - 2018-05-01 00:23:49 --> Database Driver Class Initialized
INFO - 2018-05-01 00:23:49 --> Model "QuestionsModel" initialized
INFO - 2018-05-01 00:23:49 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-05-01 00:23:49 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-05-01 00:23:49 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-05-01 00:23:49 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-05-01 00:23:49 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-05-01 00:23:49 --> Final output sent to browser
DEBUG - 2018-05-01 00:23:49 --> Total execution time: 0.3111
INFO - 2018-05-01 00:23:51 --> Config Class Initialized
INFO - 2018-05-01 00:23:51 --> Hooks Class Initialized
DEBUG - 2018-05-01 00:23:51 --> UTF-8 Support Enabled
INFO - 2018-05-01 00:23:51 --> Utf8 Class Initialized
INFO - 2018-05-01 00:23:51 --> URI Class Initialized
INFO - 2018-05-01 00:23:51 --> Router Class Initialized
INFO - 2018-05-01 00:23:51 --> Output Class Initialized
INFO - 2018-05-01 00:23:51 --> Security Class Initialized
DEBUG - 2018-05-01 00:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 00:23:51 --> CSRF cookie sent
INFO - 2018-05-01 00:23:51 --> Input Class Initialized
INFO - 2018-05-01 00:23:51 --> Language Class Initialized
ERROR - 2018-05-01 00:23:51 --> 404 Page Not Found: Revolution/assets
INFO - 2018-05-01 00:23:52 --> Config Class Initialized
INFO - 2018-05-01 00:23:52 --> Hooks Class Initialized
DEBUG - 2018-05-01 00:23:52 --> UTF-8 Support Enabled
INFO - 2018-05-01 00:23:52 --> Utf8 Class Initialized
INFO - 2018-05-01 00:23:52 --> URI Class Initialized
INFO - 2018-05-01 00:23:52 --> Router Class Initialized
INFO - 2018-05-01 00:23:52 --> Output Class Initialized
INFO - 2018-05-01 00:23:52 --> Security Class Initialized
DEBUG - 2018-05-01 00:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 00:23:53 --> CSRF cookie sent
INFO - 2018-05-01 00:23:53 --> Input Class Initialized
INFO - 2018-05-01 00:23:53 --> Language Class Initialized
INFO - 2018-05-01 00:23:53 --> Loader Class Initialized
INFO - 2018-05-01 00:23:53 --> Helper loaded: url_helper
INFO - 2018-05-01 00:23:53 --> Helper loaded: form_helper
INFO - 2018-05-01 00:23:53 --> Helper loaded: language_helper
DEBUG - 2018-05-01 00:23:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-01 00:23:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 00:23:53 --> User Agent Class Initialized
INFO - 2018-05-01 00:23:53 --> Controller Class Initialized
INFO - 2018-05-01 00:23:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-05-01 00:23:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-05-01 00:23:53 --> CSRF cookie sent
INFO - 2018-05-01 00:23:53 --> Config Class Initialized
INFO - 2018-05-01 00:23:53 --> Hooks Class Initialized
DEBUG - 2018-05-01 00:23:53 --> UTF-8 Support Enabled
INFO - 2018-05-01 00:23:53 --> Utf8 Class Initialized
INFO - 2018-05-01 00:23:53 --> URI Class Initialized
DEBUG - 2018-05-01 00:23:53 --> No URI present. Default controller set.
INFO - 2018-05-01 00:23:53 --> Router Class Initialized
INFO - 2018-05-01 00:23:53 --> Output Class Initialized
INFO - 2018-05-01 00:23:53 --> Security Class Initialized
DEBUG - 2018-05-01 00:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 00:23:53 --> CSRF cookie sent
INFO - 2018-05-01 00:23:53 --> Input Class Initialized
INFO - 2018-05-01 00:23:53 --> Language Class Initialized
INFO - 2018-05-01 00:23:53 --> Loader Class Initialized
INFO - 2018-05-01 00:23:53 --> Helper loaded: url_helper
INFO - 2018-05-01 00:23:53 --> Helper loaded: form_helper
INFO - 2018-05-01 00:23:53 --> Helper loaded: language_helper
DEBUG - 2018-05-01 00:23:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-01 00:23:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 00:23:53 --> User Agent Class Initialized
INFO - 2018-05-01 00:23:53 --> Controller Class Initialized
INFO - 2018-05-01 00:23:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-05-01 00:23:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-05-01 00:23:53 --> Pixel_Model class loaded
INFO - 2018-05-01 00:23:53 --> Database Driver Class Initialized
INFO - 2018-05-01 00:23:53 --> Model "QuestionsModel" initialized
INFO - 2018-05-01 00:23:53 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-05-01 00:23:53 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-05-01 00:23:53 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-05-01 00:23:53 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-05-01 00:23:53 --> Final output sent to browser
DEBUG - 2018-05-01 00:23:53 --> Total execution time: 0.3543
INFO - 2018-05-01 00:23:54 --> Config Class Initialized
INFO - 2018-05-01 00:23:54 --> Hooks Class Initialized
DEBUG - 2018-05-01 00:23:54 --> UTF-8 Support Enabled
INFO - 2018-05-01 00:23:54 --> Utf8 Class Initialized
INFO - 2018-05-01 00:23:54 --> URI Class Initialized
INFO - 2018-05-01 00:23:54 --> Router Class Initialized
INFO - 2018-05-01 00:23:54 --> Output Class Initialized
INFO - 2018-05-01 00:23:54 --> Security Class Initialized
DEBUG - 2018-05-01 00:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 00:23:54 --> CSRF cookie sent
INFO - 2018-05-01 00:23:54 --> Input Class Initialized
INFO - 2018-05-01 00:23:54 --> Language Class Initialized
ERROR - 2018-05-01 00:23:54 --> 404 Page Not Found: Revolution/assets
INFO - 2018-05-01 00:23:59 --> Config Class Initialized
INFO - 2018-05-01 00:23:59 --> Hooks Class Initialized
DEBUG - 2018-05-01 00:23:59 --> UTF-8 Support Enabled
INFO - 2018-05-01 00:23:59 --> Utf8 Class Initialized
INFO - 2018-05-01 00:23:59 --> URI Class Initialized
INFO - 2018-05-01 00:23:59 --> Router Class Initialized
INFO - 2018-05-01 00:23:59 --> Output Class Initialized
INFO - 2018-05-01 00:23:59 --> Security Class Initialized
DEBUG - 2018-05-01 00:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 00:23:59 --> CSRF cookie sent
INFO - 2018-05-01 00:23:59 --> CSRF token verified
INFO - 2018-05-01 00:23:59 --> Input Class Initialized
INFO - 2018-05-01 00:23:59 --> Language Class Initialized
INFO - 2018-05-01 00:23:59 --> Loader Class Initialized
INFO - 2018-05-01 00:23:59 --> Helper loaded: url_helper
INFO - 2018-05-01 00:23:59 --> Helper loaded: form_helper
INFO - 2018-05-01 00:23:59 --> Helper loaded: language_helper
DEBUG - 2018-05-01 00:23:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-01 00:23:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 00:23:59 --> User Agent Class Initialized
INFO - 2018-05-01 00:23:59 --> Controller Class Initialized
INFO - 2018-05-01 00:23:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-05-01 00:23:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-05-01 00:23:59 --> Pixel_Model class loaded
INFO - 2018-05-01 00:23:59 --> Database Driver Class Initialized
INFO - 2018-05-01 00:23:59 --> Model "QuestionsModel" initialized
INFO - 2018-05-01 00:23:59 --> Config Class Initialized
INFO - 2018-05-01 00:23:59 --> Hooks Class Initialized
DEBUG - 2018-05-01 00:23:59 --> UTF-8 Support Enabled
INFO - 2018-05-01 00:23:59 --> Utf8 Class Initialized
INFO - 2018-05-01 00:23:59 --> URI Class Initialized
INFO - 2018-05-01 00:23:59 --> Router Class Initialized
INFO - 2018-05-01 00:23:59 --> Output Class Initialized
INFO - 2018-05-01 00:23:59 --> Security Class Initialized
DEBUG - 2018-05-01 00:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 00:23:59 --> CSRF cookie sent
INFO - 2018-05-01 00:23:59 --> Input Class Initialized
INFO - 2018-05-01 00:23:59 --> Language Class Initialized
INFO - 2018-05-01 00:23:59 --> Loader Class Initialized
INFO - 2018-05-01 00:23:59 --> Helper loaded: url_helper
INFO - 2018-05-01 00:23:59 --> Helper loaded: form_helper
INFO - 2018-05-01 00:23:59 --> Helper loaded: language_helper
DEBUG - 2018-05-01 00:23:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-01 00:23:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 00:23:59 --> User Agent Class Initialized
INFO - 2018-05-01 00:23:59 --> Controller Class Initialized
INFO - 2018-05-01 00:23:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-05-01 00:23:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-05-01 00:23:59 --> Pixel_Model class loaded
INFO - 2018-05-01 00:23:59 --> Database Driver Class Initialized
INFO - 2018-05-01 00:23:59 --> Model "RegistrationModel" initialized
DEBUG - 2018-05-01 00:23:59 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-05-01 00:24:00 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-05-01 00:24:00 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-05-01 00:24:00 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-05-01 00:24:00 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-05-01 00:24:00 --> Could not find the language line "req_email"
INFO - 2018-05-01 00:24:00 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-05-01 00:24:00 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-05-01 00:24:00 --> Final output sent to browser
DEBUG - 2018-05-01 00:24:00 --> Total execution time: 0.3711
INFO - 2018-05-01 00:24:26 --> Config Class Initialized
INFO - 2018-05-01 00:24:26 --> Hooks Class Initialized
DEBUG - 2018-05-01 00:24:26 --> UTF-8 Support Enabled
INFO - 2018-05-01 00:24:26 --> Utf8 Class Initialized
INFO - 2018-05-01 00:24:26 --> URI Class Initialized
INFO - 2018-05-01 00:24:26 --> Router Class Initialized
INFO - 2018-05-01 00:24:26 --> Output Class Initialized
INFO - 2018-05-01 00:24:26 --> Security Class Initialized
DEBUG - 2018-05-01 00:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 00:24:26 --> CSRF cookie sent
INFO - 2018-05-01 00:24:26 --> CSRF token verified
INFO - 2018-05-01 00:24:26 --> Input Class Initialized
INFO - 2018-05-01 00:24:26 --> Language Class Initialized
INFO - 2018-05-01 00:24:26 --> Loader Class Initialized
INFO - 2018-05-01 00:24:26 --> Helper loaded: url_helper
INFO - 2018-05-01 00:24:26 --> Helper loaded: form_helper
INFO - 2018-05-01 00:24:26 --> Helper loaded: language_helper
DEBUG - 2018-05-01 00:24:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-01 00:24:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 00:24:26 --> User Agent Class Initialized
INFO - 2018-05-01 00:24:26 --> Controller Class Initialized
INFO - 2018-05-01 00:24:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-05-01 00:24:26 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-05-01 00:24:26 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-05-01 00:24:27 --> Form Validation Class Initialized
INFO - 2018-05-01 00:24:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-05-01 00:24:27 --> Pixel_Model class loaded
INFO - 2018-05-01 00:24:27 --> Database Driver Class Initialized
INFO - 2018-05-01 00:24:27 --> Model "RegistrationModel" initialized
INFO - 2018-05-01 00:24:27 --> Helper loaded: string_helper
INFO - 2018-05-01 00:24:27 --> Language file loaded: language/en/notifications_lang.php
INFO - 2018-05-01 00:24:27 --> Database Driver Class Initialized
INFO - 2018-05-01 00:24:27 --> Model "QuestionsModel" initialized
INFO - 2018-05-01 00:24:27 --> File loaded: E:\www\yacopoo\application\views\emails/_buttons.php
INFO - 2018-05-01 00:24:27 --> File loaded: E:\www\yacopoo\application\views\emails/header.php
INFO - 2018-05-01 00:24:27 --> File loaded: E:\www\yacopoo\application\views\emails/footer.php
INFO - 2018-05-01 00:24:27 --> File loaded: E:\www\yacopoo\application\views\emails/generic.php
INFO - 2018-05-01 00:24:27 --> Email Class Initialized
ERROR - 2018-05-01 00:24:28 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() E:\www\yacopoo\system\libraries\Email.php 1894
INFO - 2018-05-01 00:24:28 --> Language file loaded: language/english/email_lang.php
INFO - 2018-05-01 00:24:28 --> Config Class Initialized
INFO - 2018-05-01 00:24:28 --> Hooks Class Initialized
DEBUG - 2018-05-01 00:24:28 --> UTF-8 Support Enabled
INFO - 2018-05-01 00:24:28 --> Utf8 Class Initialized
INFO - 2018-05-01 00:24:28 --> URI Class Initialized
INFO - 2018-05-01 00:24:28 --> Router Class Initialized
INFO - 2018-05-01 00:24:28 --> Output Class Initialized
INFO - 2018-05-01 00:24:28 --> Security Class Initialized
DEBUG - 2018-05-01 00:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 00:24:28 --> CSRF cookie sent
INFO - 2018-05-01 00:24:28 --> Input Class Initialized
INFO - 2018-05-01 00:24:28 --> Language Class Initialized
INFO - 2018-05-01 00:24:28 --> Loader Class Initialized
INFO - 2018-05-01 00:24:28 --> Helper loaded: url_helper
INFO - 2018-05-01 00:24:28 --> Helper loaded: form_helper
INFO - 2018-05-01 00:24:28 --> Helper loaded: language_helper
DEBUG - 2018-05-01 00:24:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-01 00:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 00:24:28 --> User Agent Class Initialized
INFO - 2018-05-01 00:24:28 --> Controller Class Initialized
INFO - 2018-05-01 00:24:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-05-01 00:24:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-05-01 00:24:28 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-05-01 00:24:28 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-05-01 00:24:28 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-05-01 00:24:28 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-05-01 00:24:28 --> File loaded: E:\www\yacopoo\application\views\register/thanks.php
INFO - 2018-05-01 00:24:28 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-05-01 00:24:28 --> Final output sent to browser
DEBUG - 2018-05-01 00:24:28 --> Total execution time: 0.2723
INFO - 2018-05-01 00:25:57 --> Config Class Initialized
INFO - 2018-05-01 00:25:57 --> Hooks Class Initialized
DEBUG - 2018-05-01 00:25:58 --> UTF-8 Support Enabled
INFO - 2018-05-01 00:25:58 --> Utf8 Class Initialized
INFO - 2018-05-01 00:25:58 --> URI Class Initialized
INFO - 2018-05-01 00:25:58 --> Router Class Initialized
INFO - 2018-05-01 00:25:58 --> Output Class Initialized
INFO - 2018-05-01 00:25:58 --> Security Class Initialized
DEBUG - 2018-05-01 00:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 00:25:58 --> CSRF cookie sent
INFO - 2018-05-01 00:25:58 --> Input Class Initialized
INFO - 2018-05-01 00:25:58 --> Language Class Initialized
INFO - 2018-05-01 00:25:58 --> Loader Class Initialized
INFO - 2018-05-01 00:25:58 --> Helper loaded: url_helper
INFO - 2018-05-01 00:25:58 --> Helper loaded: form_helper
INFO - 2018-05-01 00:25:58 --> Helper loaded: language_helper
DEBUG - 2018-05-01 00:25:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-01 00:25:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 00:25:58 --> User Agent Class Initialized
INFO - 2018-05-01 00:25:58 --> Controller Class Initialized
INFO - 2018-05-01 00:25:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-05-01 00:25:58 --> Language file loaded: language/en/form_validation_lang.php
ERROR - 2018-05-01 00:25:58 --> Severity: Notice --> Undefined index: HTTP_REFERER E:\www\yacopoo\application\core\Pixel_Controller.php 87
INFO - 2018-05-01 00:25:58 --> Config Class Initialized
INFO - 2018-05-01 00:25:58 --> Hooks Class Initialized
DEBUG - 2018-05-01 00:25:58 --> UTF-8 Support Enabled
INFO - 2018-05-01 00:25:58 --> Utf8 Class Initialized
INFO - 2018-05-01 00:25:58 --> URI Class Initialized
DEBUG - 2018-05-01 00:25:58 --> No URI present. Default controller set.
INFO - 2018-05-01 00:25:58 --> Router Class Initialized
INFO - 2018-05-01 00:25:58 --> Output Class Initialized
INFO - 2018-05-01 00:25:58 --> Security Class Initialized
DEBUG - 2018-05-01 00:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 00:25:58 --> CSRF cookie sent
INFO - 2018-05-01 00:25:58 --> Input Class Initialized
INFO - 2018-05-01 00:25:58 --> Language Class Initialized
INFO - 2018-05-01 00:25:58 --> Loader Class Initialized
INFO - 2018-05-01 00:25:58 --> Helper loaded: url_helper
INFO - 2018-05-01 00:25:58 --> Helper loaded: form_helper
INFO - 2018-05-01 00:25:58 --> Helper loaded: language_helper
DEBUG - 2018-05-01 00:25:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-01 00:25:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 00:25:58 --> User Agent Class Initialized
INFO - 2018-05-01 00:25:58 --> Controller Class Initialized
INFO - 2018-05-01 00:25:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-05-01 00:25:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-05-01 00:25:58 --> Pixel_Model class loaded
INFO - 2018-05-01 00:25:58 --> Database Driver Class Initialized
INFO - 2018-05-01 00:25:58 --> Model "QuestionsModel" initialized
INFO - 2018-05-01 00:25:58 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-05-01 00:25:58 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-05-01 00:25:58 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-05-01 00:25:58 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-05-01 00:25:58 --> Final output sent to browser
DEBUG - 2018-05-01 00:25:58 --> Total execution time: 0.3002
INFO - 2018-05-01 00:25:59 --> Config Class Initialized
INFO - 2018-05-01 00:25:59 --> Hooks Class Initialized
DEBUG - 2018-05-01 00:25:59 --> UTF-8 Support Enabled
INFO - 2018-05-01 00:25:59 --> Utf8 Class Initialized
INFO - 2018-05-01 00:25:59 --> URI Class Initialized
INFO - 2018-05-01 00:26:00 --> Router Class Initialized
INFO - 2018-05-01 00:26:00 --> Output Class Initialized
INFO - 2018-05-01 00:26:00 --> Security Class Initialized
DEBUG - 2018-05-01 00:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 00:26:00 --> CSRF cookie sent
INFO - 2018-05-01 00:26:00 --> Input Class Initialized
INFO - 2018-05-01 00:26:00 --> Language Class Initialized
ERROR - 2018-05-01 00:26:00 --> 404 Page Not Found: Revolution/assets
INFO - 2018-05-01 00:26:11 --> Config Class Initialized
INFO - 2018-05-01 00:26:11 --> Hooks Class Initialized
DEBUG - 2018-05-01 00:26:11 --> UTF-8 Support Enabled
INFO - 2018-05-01 00:26:11 --> Utf8 Class Initialized
INFO - 2018-05-01 00:26:11 --> URI Class Initialized
INFO - 2018-05-01 00:26:11 --> Router Class Initialized
INFO - 2018-05-01 00:26:11 --> Output Class Initialized
INFO - 2018-05-01 00:26:11 --> Security Class Initialized
DEBUG - 2018-05-01 00:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 00:26:11 --> CSRF cookie sent
INFO - 2018-05-01 00:26:11 --> Input Class Initialized
INFO - 2018-05-01 00:26:11 --> Language Class Initialized
INFO - 2018-05-01 00:26:11 --> Loader Class Initialized
INFO - 2018-05-01 00:26:11 --> Helper loaded: url_helper
INFO - 2018-05-01 00:26:11 --> Helper loaded: form_helper
INFO - 2018-05-01 00:26:12 --> Helper loaded: language_helper
DEBUG - 2018-05-01 00:26:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-01 00:26:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 00:26:12 --> User Agent Class Initialized
INFO - 2018-05-01 00:26:12 --> Controller Class Initialized
INFO - 2018-05-01 00:26:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-05-01 00:26:12 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-05-01 00:26:12 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-05-01 00:26:12 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-05-01 00:26:12 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-05-01 00:26:12 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-05-01 00:26:12 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-05-01 00:26:12 --> Could not find the language line "req_email"
INFO - 2018-05-01 00:26:12 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-05-01 00:26:12 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-05-01 00:26:12 --> Final output sent to browser
DEBUG - 2018-05-01 00:26:12 --> Total execution time: 0.3240
INFO - 2018-05-01 00:26:21 --> Config Class Initialized
INFO - 2018-05-01 00:26:21 --> Hooks Class Initialized
DEBUG - 2018-05-01 00:26:21 --> UTF-8 Support Enabled
INFO - 2018-05-01 00:26:21 --> Utf8 Class Initialized
INFO - 2018-05-01 00:26:21 --> URI Class Initialized
INFO - 2018-05-01 00:26:21 --> Router Class Initialized
INFO - 2018-05-01 00:26:21 --> Output Class Initialized
INFO - 2018-05-01 00:26:21 --> Security Class Initialized
DEBUG - 2018-05-01 00:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 00:26:21 --> CSRF cookie sent
INFO - 2018-05-01 00:26:21 --> CSRF token verified
INFO - 2018-05-01 00:26:21 --> Input Class Initialized
INFO - 2018-05-01 00:26:21 --> Language Class Initialized
INFO - 2018-05-01 00:26:21 --> Loader Class Initialized
INFO - 2018-05-01 00:26:21 --> Helper loaded: url_helper
INFO - 2018-05-01 00:26:21 --> Helper loaded: form_helper
INFO - 2018-05-01 00:26:21 --> Helper loaded: language_helper
DEBUG - 2018-05-01 00:26:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-01 00:26:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 00:26:21 --> User Agent Class Initialized
INFO - 2018-05-01 00:26:21 --> Controller Class Initialized
INFO - 2018-05-01 00:26:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-05-01 00:26:21 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-05-01 00:26:21 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-05-01 00:26:21 --> Form Validation Class Initialized
INFO - 2018-05-01 00:26:22 --> Pixel_Model class loaded
INFO - 2018-05-01 00:26:22 --> Database Driver Class Initialized
INFO - 2018-05-01 00:26:22 --> Model "AuthenticationModel" initialized
INFO - 2018-05-01 00:26:22 --> Config Class Initialized
INFO - 2018-05-01 00:26:22 --> Hooks Class Initialized
DEBUG - 2018-05-01 00:26:22 --> UTF-8 Support Enabled
INFO - 2018-05-01 00:26:22 --> Utf8 Class Initialized
INFO - 2018-05-01 00:26:22 --> URI Class Initialized
INFO - 2018-05-01 00:26:22 --> Router Class Initialized
INFO - 2018-05-01 00:26:22 --> Output Class Initialized
INFO - 2018-05-01 00:26:22 --> Security Class Initialized
DEBUG - 2018-05-01 00:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 00:26:22 --> CSRF cookie sent
INFO - 2018-05-01 00:26:22 --> Input Class Initialized
INFO - 2018-05-01 00:26:22 --> Language Class Initialized
INFO - 2018-05-01 00:26:22 --> Loader Class Initialized
INFO - 2018-05-01 00:26:22 --> Helper loaded: url_helper
INFO - 2018-05-01 00:26:22 --> Helper loaded: form_helper
INFO - 2018-05-01 00:26:22 --> Helper loaded: language_helper
DEBUG - 2018-05-01 00:26:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-01 00:26:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 00:26:22 --> User Agent Class Initialized
INFO - 2018-05-01 00:26:22 --> Controller Class Initialized
INFO - 2018-05-01 00:26:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-05-01 00:26:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-05-01 00:26:22 --> Pixel_Model class loaded
INFO - 2018-05-01 00:26:22 --> Database Driver Class Initialized
INFO - 2018-05-01 00:26:22 --> Model "MyAccountModel" initialized
INFO - 2018-05-01 00:26:22 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-05-01 00:26:22 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-05-01 00:26:22 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-05-01 00:26:22 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-05-01 00:26:22 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-05-01 00:26:22 --> File loaded: E:\www\yacopoo\application\views\myaccount/application_list.php
INFO - 2018-05-01 00:26:22 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-05-01 00:26:22 --> Final output sent to browser
DEBUG - 2018-05-01 00:26:22 --> Total execution time: 0.3397
INFO - 2018-05-01 00:28:22 --> Config Class Initialized
INFO - 2018-05-01 00:28:22 --> Hooks Class Initialized
DEBUG - 2018-05-01 00:28:22 --> UTF-8 Support Enabled
INFO - 2018-05-01 00:28:22 --> Utf8 Class Initialized
INFO - 2018-05-01 00:28:22 --> URI Class Initialized
INFO - 2018-05-01 00:28:22 --> Router Class Initialized
INFO - 2018-05-01 00:28:22 --> Output Class Initialized
INFO - 2018-05-01 00:28:22 --> Security Class Initialized
DEBUG - 2018-05-01 00:28:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 00:28:22 --> CSRF cookie sent
INFO - 2018-05-01 00:28:22 --> Input Class Initialized
INFO - 2018-05-01 00:28:22 --> Language Class Initialized
INFO - 2018-05-01 00:28:22 --> Loader Class Initialized
INFO - 2018-05-01 00:28:22 --> Helper loaded: url_helper
INFO - 2018-05-01 00:28:22 --> Helper loaded: form_helper
INFO - 2018-05-01 00:28:22 --> Helper loaded: language_helper
DEBUG - 2018-05-01 00:28:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-01 00:28:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 00:28:22 --> User Agent Class Initialized
INFO - 2018-05-01 00:28:22 --> Controller Class Initialized
INFO - 2018-05-01 00:28:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-05-01 00:28:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-05-01 00:28:22 --> Pixel_Model class loaded
INFO - 2018-05-01 00:28:22 --> Database Driver Class Initialized
INFO - 2018-05-01 00:28:22 --> Model "MyAccountModel" initialized
INFO - 2018-05-01 00:28:22 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-05-01 00:28:22 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-05-01 00:28:22 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-05-01 00:28:22 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-05-01 00:28:22 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-05-01 00:28:22 --> File loaded: E:\www\yacopoo\application\views\myaccount/application_list.php
INFO - 2018-05-01 00:28:22 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-05-01 00:28:22 --> Final output sent to browser
DEBUG - 2018-05-01 00:28:22 --> Total execution time: 0.3527
INFO - 2018-05-01 00:28:24 --> Config Class Initialized
INFO - 2018-05-01 00:28:24 --> Hooks Class Initialized
DEBUG - 2018-05-01 00:28:24 --> UTF-8 Support Enabled
INFO - 2018-05-01 00:28:24 --> Utf8 Class Initialized
INFO - 2018-05-01 00:28:24 --> URI Class Initialized
INFO - 2018-05-01 00:28:24 --> Router Class Initialized
INFO - 2018-05-01 00:28:24 --> Output Class Initialized
INFO - 2018-05-01 00:28:24 --> Security Class Initialized
DEBUG - 2018-05-01 00:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 00:28:25 --> CSRF cookie sent
INFO - 2018-05-01 00:28:25 --> Input Class Initialized
INFO - 2018-05-01 00:28:25 --> Language Class Initialized
INFO - 2018-05-01 00:28:25 --> Loader Class Initialized
INFO - 2018-05-01 00:28:25 --> Helper loaded: url_helper
INFO - 2018-05-01 00:28:25 --> Helper loaded: form_helper
INFO - 2018-05-01 00:28:25 --> Helper loaded: language_helper
DEBUG - 2018-05-01 00:28:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-01 00:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 00:28:25 --> User Agent Class Initialized
INFO - 2018-05-01 00:28:25 --> Controller Class Initialized
INFO - 2018-05-01 00:28:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-05-01 00:28:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-05-01 00:28:25 --> Pixel_Model class loaded
INFO - 2018-05-01 00:28:25 --> Database Driver Class Initialized
INFO - 2018-05-01 00:28:25 --> Model "QuestionsModel" initialized
INFO - 2018-05-01 00:28:25 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-05-01 00:28:25 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-05-01 00:28:25 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-05-01 00:28:25 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-05-01 00:28:25 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-05-01 00:28:25 --> File loaded: E:\www\yacopoo\application\views\shared/_bar.php
INFO - 2018-05-01 00:28:25 --> File loaded: E:\www\yacopoo\application\views\shared/_buttons.php
INFO - 2018-05-01 00:28:25 --> File loaded: E:\www\yacopoo\application\views\questions/start_questions.php
INFO - 2018-05-01 00:28:25 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-05-01 00:28:25 --> Final output sent to browser
DEBUG - 2018-05-01 00:28:25 --> Total execution time: 0.3692
INFO - 2018-05-01 00:28:36 --> Config Class Initialized
INFO - 2018-05-01 00:28:36 --> Hooks Class Initialized
DEBUG - 2018-05-01 00:28:36 --> UTF-8 Support Enabled
INFO - 2018-05-01 00:28:36 --> Utf8 Class Initialized
INFO - 2018-05-01 00:28:36 --> URI Class Initialized
INFO - 2018-05-01 00:28:36 --> Router Class Initialized
INFO - 2018-05-01 00:28:36 --> Output Class Initialized
INFO - 2018-05-01 00:28:36 --> Security Class Initialized
DEBUG - 2018-05-01 00:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 00:28:36 --> CSRF cookie sent
INFO - 2018-05-01 00:28:36 --> Input Class Initialized
INFO - 2018-05-01 00:28:36 --> Language Class Initialized
INFO - 2018-05-01 00:28:36 --> Loader Class Initialized
INFO - 2018-05-01 00:28:36 --> Helper loaded: url_helper
INFO - 2018-05-01 00:28:36 --> Helper loaded: form_helper
INFO - 2018-05-01 00:28:36 --> Helper loaded: language_helper
DEBUG - 2018-05-01 00:28:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-01 00:28:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 00:28:36 --> User Agent Class Initialized
INFO - 2018-05-01 00:28:36 --> Controller Class Initialized
INFO - 2018-05-01 00:28:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-05-01 00:28:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-05-01 00:28:36 --> Pixel_Model class loaded
INFO - 2018-05-01 00:28:36 --> Database Driver Class Initialized
INFO - 2018-05-01 00:28:36 --> Model "MyAccountModel" initialized
INFO - 2018-05-01 00:28:36 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-05-01 00:28:36 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-05-01 00:28:36 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-05-01 00:28:36 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-05-01 00:28:36 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-05-01 00:28:37 --> File loaded: E:\www\yacopoo\application\views\myaccount/application_list.php
INFO - 2018-05-01 00:28:37 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-05-01 00:28:37 --> Final output sent to browser
DEBUG - 2018-05-01 00:28:37 --> Total execution time: 0.3429
INFO - 2018-05-01 00:29:15 --> Config Class Initialized
INFO - 2018-05-01 00:29:15 --> Hooks Class Initialized
DEBUG - 2018-05-01 00:29:15 --> UTF-8 Support Enabled
INFO - 2018-05-01 00:29:15 --> Utf8 Class Initialized
INFO - 2018-05-01 00:29:15 --> URI Class Initialized
INFO - 2018-05-01 00:29:15 --> Router Class Initialized
INFO - 2018-05-01 00:29:15 --> Output Class Initialized
INFO - 2018-05-01 00:29:15 --> Security Class Initialized
DEBUG - 2018-05-01 00:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 00:29:15 --> CSRF cookie sent
INFO - 2018-05-01 00:29:15 --> Input Class Initialized
INFO - 2018-05-01 00:29:15 --> Language Class Initialized
INFO - 2018-05-01 00:29:15 --> Loader Class Initialized
INFO - 2018-05-01 00:29:15 --> Helper loaded: url_helper
INFO - 2018-05-01 00:29:15 --> Helper loaded: form_helper
INFO - 2018-05-01 00:29:15 --> Helper loaded: language_helper
DEBUG - 2018-05-01 00:29:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-01 00:29:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 00:29:15 --> User Agent Class Initialized
INFO - 2018-05-01 00:29:15 --> Controller Class Initialized
INFO - 2018-05-01 00:29:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-05-01 00:29:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-05-01 00:29:15 --> Pixel_Model class loaded
INFO - 2018-05-01 00:29:15 --> Database Driver Class Initialized
INFO - 2018-05-01 00:29:15 --> Model "MyAccountModel" initialized
INFO - 2018-05-01 00:29:15 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-05-01 00:29:15 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-05-01 00:29:15 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-05-01 00:29:15 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-05-01 00:29:16 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-05-01 00:29:16 --> File loaded: E:\www\yacopoo\application\views\myaccount/application_list.php
INFO - 2018-05-01 00:29:16 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-05-01 00:29:16 --> Final output sent to browser
DEBUG - 2018-05-01 00:29:16 --> Total execution time: 0.3437
INFO - 2018-05-01 00:29:58 --> Config Class Initialized
INFO - 2018-05-01 00:29:58 --> Hooks Class Initialized
DEBUG - 2018-05-01 00:29:58 --> UTF-8 Support Enabled
INFO - 2018-05-01 00:29:58 --> Utf8 Class Initialized
INFO - 2018-05-01 00:29:58 --> URI Class Initialized
INFO - 2018-05-01 00:29:58 --> Router Class Initialized
INFO - 2018-05-01 00:29:58 --> Output Class Initialized
INFO - 2018-05-01 00:29:58 --> Security Class Initialized
DEBUG - 2018-05-01 00:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 00:29:58 --> CSRF cookie sent
INFO - 2018-05-01 00:29:58 --> Input Class Initialized
INFO - 2018-05-01 00:29:58 --> Language Class Initialized
INFO - 2018-05-01 00:29:58 --> Loader Class Initialized
INFO - 2018-05-01 00:29:58 --> Helper loaded: url_helper
INFO - 2018-05-01 00:29:58 --> Helper loaded: form_helper
INFO - 2018-05-01 00:29:58 --> Helper loaded: language_helper
DEBUG - 2018-05-01 00:29:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-01 00:29:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 00:29:58 --> User Agent Class Initialized
INFO - 2018-05-01 00:29:58 --> Controller Class Initialized
INFO - 2018-05-01 00:29:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-05-01 00:29:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-05-01 00:29:58 --> Pixel_Model class loaded
INFO - 2018-05-01 00:29:58 --> Database Driver Class Initialized
INFO - 2018-05-01 00:29:58 --> Model "MyAccountModel" initialized
INFO - 2018-05-01 00:29:58 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-05-01 00:29:58 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-05-01 00:29:58 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-05-01 00:29:58 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-05-01 00:29:58 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-05-01 00:29:58 --> File loaded: E:\www\yacopoo\application\views\myaccount/application_list.php
INFO - 2018-05-01 00:29:58 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-05-01 00:29:58 --> Final output sent to browser
DEBUG - 2018-05-01 00:29:58 --> Total execution time: 0.3546
INFO - 2018-05-01 00:30:01 --> Config Class Initialized
INFO - 2018-05-01 00:30:01 --> Hooks Class Initialized
DEBUG - 2018-05-01 00:30:01 --> UTF-8 Support Enabled
INFO - 2018-05-01 00:30:01 --> Utf8 Class Initialized
INFO - 2018-05-01 00:30:01 --> URI Class Initialized
INFO - 2018-05-01 00:30:01 --> Router Class Initialized
INFO - 2018-05-01 00:30:01 --> Output Class Initialized
INFO - 2018-05-01 00:30:01 --> Security Class Initialized
DEBUG - 2018-05-01 00:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 00:30:01 --> CSRF cookie sent
INFO - 2018-05-01 00:30:01 --> Input Class Initialized
INFO - 2018-05-01 00:30:01 --> Language Class Initialized
INFO - 2018-05-01 00:30:01 --> Loader Class Initialized
INFO - 2018-05-01 00:30:01 --> Helper loaded: url_helper
INFO - 2018-05-01 00:30:01 --> Helper loaded: form_helper
INFO - 2018-05-01 00:30:01 --> Helper loaded: language_helper
DEBUG - 2018-05-01 00:30:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-01 00:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 00:30:01 --> User Agent Class Initialized
INFO - 2018-05-01 00:30:01 --> Controller Class Initialized
INFO - 2018-05-01 00:30:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-05-01 00:30:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-05-01 00:30:01 --> Pixel_Model class loaded
INFO - 2018-05-01 00:30:01 --> Database Driver Class Initialized
INFO - 2018-05-01 00:30:01 --> Model "MyAccountModel" initialized
INFO - 2018-05-01 00:30:01 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-05-01 00:30:01 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-05-01 00:30:01 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-05-01 00:30:01 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-05-01 00:30:01 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-05-01 00:30:01 --> File loaded: E:\www\yacopoo\application\views\myaccount/application_list.php
INFO - 2018-05-01 00:30:01 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-05-01 00:30:01 --> Final output sent to browser
DEBUG - 2018-05-01 00:30:01 --> Total execution time: 0.3443
INFO - 2018-05-01 00:30:08 --> Config Class Initialized
INFO - 2018-05-01 00:30:08 --> Hooks Class Initialized
DEBUG - 2018-05-01 00:30:08 --> UTF-8 Support Enabled
INFO - 2018-05-01 00:30:09 --> Utf8 Class Initialized
INFO - 2018-05-01 00:30:09 --> URI Class Initialized
DEBUG - 2018-05-01 00:30:09 --> No URI present. Default controller set.
INFO - 2018-05-01 00:30:09 --> Router Class Initialized
INFO - 2018-05-01 00:30:09 --> Output Class Initialized
INFO - 2018-05-01 00:30:09 --> Security Class Initialized
DEBUG - 2018-05-01 00:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 00:30:09 --> CSRF cookie sent
INFO - 2018-05-01 00:30:09 --> Input Class Initialized
INFO - 2018-05-01 00:30:09 --> Language Class Initialized
INFO - 2018-05-01 00:30:09 --> Loader Class Initialized
INFO - 2018-05-01 00:30:09 --> Helper loaded: url_helper
INFO - 2018-05-01 00:30:09 --> Helper loaded: form_helper
INFO - 2018-05-01 00:30:09 --> Helper loaded: language_helper
DEBUG - 2018-05-01 00:30:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-01 00:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 00:30:09 --> User Agent Class Initialized
INFO - 2018-05-01 00:30:09 --> Controller Class Initialized
INFO - 2018-05-01 00:30:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-05-01 00:30:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-05-01 00:30:09 --> Pixel_Model class loaded
INFO - 2018-05-01 00:30:09 --> Database Driver Class Initialized
INFO - 2018-05-01 00:30:09 --> Model "QuestionsModel" initialized
INFO - 2018-05-01 00:30:09 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-05-01 00:30:09 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-05-01 00:30:09 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-05-01 00:30:09 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-05-01 00:30:09 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-05-01 00:30:09 --> Final output sent to browser
DEBUG - 2018-05-01 00:30:09 --> Total execution time: 0.3341
INFO - 2018-05-01 00:30:10 --> Config Class Initialized
INFO - 2018-05-01 00:30:10 --> Hooks Class Initialized
DEBUG - 2018-05-01 00:30:10 --> UTF-8 Support Enabled
INFO - 2018-05-01 00:30:10 --> Utf8 Class Initialized
INFO - 2018-05-01 00:30:10 --> URI Class Initialized
INFO - 2018-05-01 00:30:10 --> Router Class Initialized
INFO - 2018-05-01 00:30:10 --> Output Class Initialized
INFO - 2018-05-01 00:30:10 --> Security Class Initialized
DEBUG - 2018-05-01 00:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 00:30:10 --> CSRF cookie sent
INFO - 2018-05-01 00:30:10 --> Input Class Initialized
INFO - 2018-05-01 00:30:10 --> Language Class Initialized
ERROR - 2018-05-01 00:30:10 --> 404 Page Not Found: Revolution/assets
INFO - 2018-05-01 00:30:15 --> Config Class Initialized
INFO - 2018-05-01 00:30:15 --> Hooks Class Initialized
DEBUG - 2018-05-01 00:30:15 --> UTF-8 Support Enabled
INFO - 2018-05-01 00:30:15 --> Utf8 Class Initialized
INFO - 2018-05-01 00:30:15 --> URI Class Initialized
INFO - 2018-05-01 00:30:15 --> Router Class Initialized
INFO - 2018-05-01 00:30:15 --> Output Class Initialized
INFO - 2018-05-01 00:30:15 --> Security Class Initialized
DEBUG - 2018-05-01 00:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 00:30:15 --> CSRF cookie sent
INFO - 2018-05-01 00:30:15 --> CSRF token verified
INFO - 2018-05-01 00:30:15 --> Input Class Initialized
INFO - 2018-05-01 00:30:15 --> Language Class Initialized
INFO - 2018-05-01 00:30:15 --> Loader Class Initialized
INFO - 2018-05-01 00:30:15 --> Helper loaded: url_helper
INFO - 2018-05-01 00:30:15 --> Helper loaded: form_helper
INFO - 2018-05-01 00:30:15 --> Helper loaded: language_helper
DEBUG - 2018-05-01 00:30:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-01 00:30:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 00:30:15 --> User Agent Class Initialized
INFO - 2018-05-01 00:30:15 --> Controller Class Initialized
INFO - 2018-05-01 00:30:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-05-01 00:30:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-05-01 00:30:15 --> Pixel_Model class loaded
INFO - 2018-05-01 00:30:15 --> Database Driver Class Initialized
INFO - 2018-05-01 00:30:15 --> Model "QuestionsModel" initialized
INFO - 2018-05-01 00:30:15 --> Form Validation Class Initialized
INFO - 2018-05-01 00:30:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-05-01 00:30:16 --> Config Class Initialized
INFO - 2018-05-01 00:30:16 --> Hooks Class Initialized
DEBUG - 2018-05-01 00:30:16 --> UTF-8 Support Enabled
INFO - 2018-05-01 00:30:16 --> Utf8 Class Initialized
INFO - 2018-05-01 00:30:16 --> URI Class Initialized
INFO - 2018-05-01 00:30:16 --> Router Class Initialized
INFO - 2018-05-01 00:30:16 --> Output Class Initialized
INFO - 2018-05-01 00:30:16 --> Security Class Initialized
DEBUG - 2018-05-01 00:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 00:30:16 --> CSRF cookie sent
INFO - 2018-05-01 00:30:16 --> Input Class Initialized
INFO - 2018-05-01 00:30:16 --> Language Class Initialized
INFO - 2018-05-01 00:30:16 --> Loader Class Initialized
INFO - 2018-05-01 00:30:16 --> Helper loaded: url_helper
INFO - 2018-05-01 00:30:16 --> Helper loaded: form_helper
INFO - 2018-05-01 00:30:16 --> Helper loaded: language_helper
DEBUG - 2018-05-01 00:30:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-01 00:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 00:30:16 --> User Agent Class Initialized
INFO - 2018-05-01 00:30:16 --> Controller Class Initialized
INFO - 2018-05-01 00:30:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-05-01 00:30:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-05-01 00:30:16 --> Pixel_Model class loaded
INFO - 2018-05-01 00:30:16 --> Database Driver Class Initialized
INFO - 2018-05-01 00:30:16 --> Model "QuestionsModel" initialized
INFO - 2018-05-01 00:30:16 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-05-01 00:30:16 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-05-01 00:30:16 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-05-01 00:30:16 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-05-01 00:30:16 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-05-01 00:30:16 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-05-01 00:30:16 --> File loaded: E:\www\yacopoo\application\views\shared/_bar.php
INFO - 2018-05-01 00:30:16 --> File loaded: E:\www\yacopoo\application\views\shared/_buttons.php
INFO - 2018-05-01 00:30:16 --> File loaded: E:\www\yacopoo\application\views\questions/relation_ship_status.php
INFO - 2018-05-01 00:30:16 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-05-01 00:30:16 --> Final output sent to browser
DEBUG - 2018-05-01 00:30:16 --> Total execution time: 0.3926
INFO - 2018-05-01 00:30:19 --> Config Class Initialized
INFO - 2018-05-01 00:30:19 --> Hooks Class Initialized
DEBUG - 2018-05-01 00:30:19 --> UTF-8 Support Enabled
INFO - 2018-05-01 00:30:19 --> Utf8 Class Initialized
INFO - 2018-05-01 00:30:19 --> URI Class Initialized
INFO - 2018-05-01 00:30:19 --> Router Class Initialized
INFO - 2018-05-01 00:30:19 --> Output Class Initialized
INFO - 2018-05-01 00:30:19 --> Security Class Initialized
DEBUG - 2018-05-01 00:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 00:30:19 --> CSRF cookie sent
INFO - 2018-05-01 00:30:19 --> Input Class Initialized
INFO - 2018-05-01 00:30:19 --> Language Class Initialized
INFO - 2018-05-01 00:30:19 --> Loader Class Initialized
INFO - 2018-05-01 00:30:19 --> Helper loaded: url_helper
INFO - 2018-05-01 00:30:19 --> Helper loaded: form_helper
INFO - 2018-05-01 00:30:19 --> Helper loaded: language_helper
DEBUG - 2018-05-01 00:30:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-01 00:30:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 00:30:19 --> User Agent Class Initialized
INFO - 2018-05-01 00:30:19 --> Controller Class Initialized
INFO - 2018-05-01 00:30:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-05-01 00:30:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-05-01 00:30:19 --> Pixel_Model class loaded
INFO - 2018-05-01 00:30:19 --> Database Driver Class Initialized
INFO - 2018-05-01 00:30:19 --> Model "MyAccountModel" initialized
INFO - 2018-05-01 00:30:19 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-05-01 00:30:19 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-05-01 00:30:19 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-05-01 00:30:19 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-05-01 00:30:19 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-05-01 00:30:19 --> File loaded: E:\www\yacopoo\application\views\myaccount/application_list.php
INFO - 2018-05-01 00:30:19 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-05-01 00:30:19 --> Final output sent to browser
DEBUG - 2018-05-01 00:30:19 --> Total execution time: 0.3483
INFO - 2018-05-01 00:30:22 --> Config Class Initialized
INFO - 2018-05-01 00:30:23 --> Hooks Class Initialized
DEBUG - 2018-05-01 00:30:23 --> UTF-8 Support Enabled
INFO - 2018-05-01 00:30:23 --> Utf8 Class Initialized
INFO - 2018-05-01 00:30:23 --> URI Class Initialized
INFO - 2018-05-01 00:30:23 --> Router Class Initialized
INFO - 2018-05-01 00:30:23 --> Output Class Initialized
INFO - 2018-05-01 00:30:23 --> Security Class Initialized
DEBUG - 2018-05-01 00:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 00:30:23 --> CSRF cookie sent
INFO - 2018-05-01 00:30:23 --> Input Class Initialized
INFO - 2018-05-01 00:30:23 --> Language Class Initialized
INFO - 2018-05-01 00:30:23 --> Loader Class Initialized
INFO - 2018-05-01 00:30:23 --> Helper loaded: url_helper
INFO - 2018-05-01 00:30:23 --> Helper loaded: form_helper
INFO - 2018-05-01 00:30:23 --> Helper loaded: language_helper
DEBUG - 2018-05-01 00:30:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-01 00:30:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 00:30:23 --> User Agent Class Initialized
INFO - 2018-05-01 00:30:23 --> Controller Class Initialized
INFO - 2018-05-01 00:30:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-05-01 00:30:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-05-01 00:30:23 --> Pixel_Model class loaded
INFO - 2018-05-01 00:30:23 --> Database Driver Class Initialized
INFO - 2018-05-01 00:30:23 --> Model "MyAccountModel" initialized
INFO - 2018-05-01 00:30:23 --> Config Class Initialized
INFO - 2018-05-01 00:30:23 --> Hooks Class Initialized
DEBUG - 2018-05-01 00:30:23 --> UTF-8 Support Enabled
INFO - 2018-05-01 00:30:23 --> Utf8 Class Initialized
INFO - 2018-05-01 00:30:23 --> URI Class Initialized
INFO - 2018-05-01 00:30:23 --> Router Class Initialized
INFO - 2018-05-01 00:30:23 --> Output Class Initialized
INFO - 2018-05-01 00:30:23 --> Security Class Initialized
DEBUG - 2018-05-01 00:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 00:30:23 --> CSRF cookie sent
INFO - 2018-05-01 00:30:23 --> Input Class Initialized
INFO - 2018-05-01 00:30:23 --> Language Class Initialized
INFO - 2018-05-01 00:30:23 --> Loader Class Initialized
INFO - 2018-05-01 00:30:23 --> Helper loaded: url_helper
INFO - 2018-05-01 00:30:23 --> Helper loaded: form_helper
INFO - 2018-05-01 00:30:23 --> Helper loaded: language_helper
DEBUG - 2018-05-01 00:30:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-01 00:30:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 00:30:23 --> User Agent Class Initialized
INFO - 2018-05-01 00:30:23 --> Controller Class Initialized
INFO - 2018-05-01 00:30:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-05-01 00:30:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-05-01 00:30:23 --> Pixel_Model class loaded
INFO - 2018-05-01 00:30:23 --> Database Driver Class Initialized
INFO - 2018-05-01 00:30:23 --> Model "QuestionsModel" initialized
INFO - 2018-05-01 00:30:23 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-05-01 00:30:23 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-05-01 00:30:23 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-05-01 00:30:23 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-05-01 00:30:23 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-05-01 00:30:23 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-05-01 00:30:23 --> File loaded: E:\www\yacopoo\application\views\shared/_bar.php
INFO - 2018-05-01 00:30:23 --> File loaded: E:\www\yacopoo\application\views\shared/_buttons.php
INFO - 2018-05-01 00:30:23 --> File loaded: E:\www\yacopoo\application\views\questions/relation_ship_status.php
INFO - 2018-05-01 00:30:23 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-05-01 00:30:23 --> Final output sent to browser
DEBUG - 2018-05-01 00:30:23 --> Total execution time: 0.3724
INFO - 2018-05-01 21:37:14 --> Config Class Initialized
INFO - 2018-05-01 21:37:14 --> Hooks Class Initialized
DEBUG - 2018-05-01 21:37:14 --> UTF-8 Support Enabled
INFO - 2018-05-01 21:37:14 --> Utf8 Class Initialized
INFO - 2018-05-01 21:37:14 --> URI Class Initialized
DEBUG - 2018-05-01 21:37:14 --> No URI present. Default controller set.
INFO - 2018-05-01 21:37:14 --> Router Class Initialized
INFO - 2018-05-01 21:37:14 --> Output Class Initialized
INFO - 2018-05-01 21:37:14 --> Security Class Initialized
DEBUG - 2018-05-01 21:37:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 21:37:14 --> CSRF cookie sent
INFO - 2018-05-01 21:37:14 --> Input Class Initialized
INFO - 2018-05-01 21:37:14 --> Language Class Initialized
INFO - 2018-05-01 21:37:14 --> Loader Class Initialized
INFO - 2018-05-01 21:37:14 --> Helper loaded: url_helper
INFO - 2018-05-01 21:37:14 --> Helper loaded: form_helper
INFO - 2018-05-01 21:37:14 --> Helper loaded: language_helper
DEBUG - 2018-05-01 21:37:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-01 21:37:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 21:37:15 --> User Agent Class Initialized
INFO - 2018-05-01 21:37:15 --> Controller Class Initialized
INFO - 2018-05-01 21:37:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-05-01 21:37:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-05-01 21:37:15 --> Pixel_Model class loaded
INFO - 2018-05-01 21:37:15 --> Database Driver Class Initialized
INFO - 2018-05-01 21:37:15 --> Model "QuestionsModel" initialized
INFO - 2018-05-01 21:37:15 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-05-01 21:37:15 --> File loaded: E:\www\yacopoo\application\views\shared/_fa_nav.php
INFO - 2018-05-01 21:37:15 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-05-01 21:37:15 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-05-01 21:37:15 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-05-01 21:37:16 --> Final output sent to browser
DEBUG - 2018-05-01 21:37:16 --> Total execution time: 1.8273
INFO - 2018-05-01 21:37:17 --> Config Class Initialized
INFO - 2018-05-01 21:37:17 --> Hooks Class Initialized
DEBUG - 2018-05-01 21:37:17 --> UTF-8 Support Enabled
INFO - 2018-05-01 21:37:17 --> Utf8 Class Initialized
INFO - 2018-05-01 21:37:17 --> URI Class Initialized
INFO - 2018-05-01 21:37:17 --> Router Class Initialized
INFO - 2018-05-01 21:37:17 --> Output Class Initialized
INFO - 2018-05-01 21:37:17 --> Security Class Initialized
DEBUG - 2018-05-01 21:37:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 21:37:17 --> CSRF cookie sent
INFO - 2018-05-01 21:37:17 --> Input Class Initialized
INFO - 2018-05-01 21:37:17 --> Language Class Initialized
ERROR - 2018-05-01 21:37:17 --> 404 Page Not Found: Assets/css
INFO - 2018-05-01 21:37:18 --> Config Class Initialized
INFO - 2018-05-01 21:37:18 --> Hooks Class Initialized
DEBUG - 2018-05-01 21:37:18 --> UTF-8 Support Enabled
INFO - 2018-05-01 21:37:18 --> Utf8 Class Initialized
INFO - 2018-05-01 21:37:18 --> URI Class Initialized
INFO - 2018-05-01 21:37:18 --> Router Class Initialized
INFO - 2018-05-01 21:37:18 --> Output Class Initialized
INFO - 2018-05-01 21:37:18 --> Security Class Initialized
DEBUG - 2018-05-01 21:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 21:37:18 --> CSRF cookie sent
INFO - 2018-05-01 21:37:18 --> Input Class Initialized
INFO - 2018-05-01 21:37:18 --> Language Class Initialized
ERROR - 2018-05-01 21:37:18 --> 404 Page Not Found: Revolution/assets

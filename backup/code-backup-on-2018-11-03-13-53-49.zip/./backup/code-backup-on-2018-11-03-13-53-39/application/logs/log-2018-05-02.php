<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-05-02 15:06:16 --> Config Class Initialized
INFO - 2018-05-02 15:06:16 --> Hooks Class Initialized
DEBUG - 2018-05-02 15:06:16 --> UTF-8 Support Enabled
INFO - 2018-05-02 15:06:16 --> Utf8 Class Initialized
INFO - 2018-05-02 15:06:16 --> URI Class Initialized
DEBUG - 2018-05-02 15:06:16 --> No URI present. Default controller set.
INFO - 2018-05-02 15:06:16 --> Router Class Initialized
INFO - 2018-05-02 15:06:16 --> Output Class Initialized
INFO - 2018-05-02 15:06:16 --> Security Class Initialized
DEBUG - 2018-05-02 15:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 15:06:17 --> CSRF cookie sent
INFO - 2018-05-02 15:06:17 --> Input Class Initialized
INFO - 2018-05-02 15:06:17 --> Language Class Initialized
INFO - 2018-05-02 15:06:17 --> Loader Class Initialized
INFO - 2018-05-02 15:06:17 --> Helper loaded: url_helper
INFO - 2018-05-02 15:06:17 --> Helper loaded: form_helper
INFO - 2018-05-02 15:06:17 --> Helper loaded: language_helper
DEBUG - 2018-05-02 15:06:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-02 15:06:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 15:06:17 --> User Agent Class Initialized
INFO - 2018-05-02 15:06:17 --> Controller Class Initialized
INFO - 2018-05-02 15:06:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-05-02 15:06:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-05-02 15:06:17 --> Pixel_Model class loaded
INFO - 2018-05-02 15:06:18 --> Database Driver Class Initialized
INFO - 2018-05-02 15:06:18 --> Model "QuestionsModel" initialized
INFO - 2018-05-02 15:06:18 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-05-02 15:06:18 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-05-02 15:06:19 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-05-02 15:06:20 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-05-02 15:06:20 --> Final output sent to browser
DEBUG - 2018-05-02 15:06:20 --> Total execution time: 3.7741
INFO - 2018-05-02 17:20:26 --> Config Class Initialized
INFO - 2018-05-02 17:20:26 --> Hooks Class Initialized
DEBUG - 2018-05-02 17:20:26 --> UTF-8 Support Enabled
INFO - 2018-05-02 17:20:26 --> Utf8 Class Initialized
INFO - 2018-05-02 17:20:26 --> URI Class Initialized
INFO - 2018-05-02 17:20:26 --> Router Class Initialized
INFO - 2018-05-02 17:20:26 --> Output Class Initialized
INFO - 2018-05-02 17:20:26 --> Security Class Initialized
DEBUG - 2018-05-02 17:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 17:20:26 --> CSRF cookie sent
INFO - 2018-05-02 17:20:26 --> Input Class Initialized
INFO - 2018-05-02 17:20:26 --> Language Class Initialized
ERROR - 2018-05-02 17:20:26 --> 404 Page Not Found: Revolution/assets

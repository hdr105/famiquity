<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-06-11 18:18:52 --> Config Class Initialized
INFO - 2018-06-11 18:18:52 --> Hooks Class Initialized
DEBUG - 2018-06-11 18:18:52 --> UTF-8 Support Enabled
INFO - 2018-06-11 18:18:52 --> Utf8 Class Initialized
INFO - 2018-06-11 18:18:52 --> URI Class Initialized
DEBUG - 2018-06-11 18:18:52 --> No URI present. Default controller set.
INFO - 2018-06-11 18:18:52 --> Router Class Initialized
INFO - 2018-06-11 18:18:52 --> Output Class Initialized
INFO - 2018-06-11 18:18:52 --> Security Class Initialized
DEBUG - 2018-06-11 18:18:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 18:18:52 --> CSRF cookie sent
INFO - 2018-06-11 18:18:52 --> Input Class Initialized
INFO - 2018-06-11 18:18:52 --> Language Class Initialized
INFO - 2018-06-11 18:18:52 --> Loader Class Initialized
INFO - 2018-06-11 18:18:52 --> Helper loaded: url_helper
INFO - 2018-06-11 18:18:52 --> Helper loaded: form_helper
INFO - 2018-06-11 18:18:53 --> Helper loaded: language_helper
DEBUG - 2018-06-11 18:18:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 18:18:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 18:18:53 --> User Agent Class Initialized
INFO - 2018-06-11 18:18:53 --> Controller Class Initialized
INFO - 2018-06-11 18:18:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 18:18:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 18:18:53 --> Pixel_Model class loaded
INFO - 2018-06-11 18:18:53 --> Database Driver Class Initialized
INFO - 2018-06-11 18:18:53 --> Model "QuestionsModel" initialized
INFO - 2018-06-11 18:18:54 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 18:18:54 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 18:18:54 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-06-11 18:18:54 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 18:18:54 --> Final output sent to browser
DEBUG - 2018-06-11 18:18:54 --> Total execution time: 2.2166
INFO - 2018-06-11 18:18:56 --> Config Class Initialized
INFO - 2018-06-11 18:18:56 --> Hooks Class Initialized
DEBUG - 2018-06-11 18:18:56 --> UTF-8 Support Enabled
INFO - 2018-06-11 18:18:56 --> Utf8 Class Initialized
INFO - 2018-06-11 18:18:56 --> URI Class Initialized
INFO - 2018-06-11 18:18:56 --> Router Class Initialized
INFO - 2018-06-11 18:18:56 --> Output Class Initialized
INFO - 2018-06-11 18:18:56 --> Security Class Initialized
DEBUG - 2018-06-11 18:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 18:18:56 --> CSRF cookie sent
INFO - 2018-06-11 18:18:56 --> Input Class Initialized
INFO - 2018-06-11 18:18:56 --> Language Class Initialized
ERROR - 2018-06-11 18:18:56 --> 404 Page Not Found: Revolution/assets
INFO - 2018-06-11 18:26:42 --> Config Class Initialized
INFO - 2018-06-11 18:26:42 --> Hooks Class Initialized
DEBUG - 2018-06-11 18:26:42 --> UTF-8 Support Enabled
INFO - 2018-06-11 18:26:42 --> Utf8 Class Initialized
INFO - 2018-06-11 18:26:42 --> URI Class Initialized
DEBUG - 2018-06-11 18:26:42 --> No URI present. Default controller set.
INFO - 2018-06-11 18:26:42 --> Router Class Initialized
INFO - 2018-06-11 18:26:42 --> Output Class Initialized
INFO - 2018-06-11 18:26:42 --> Security Class Initialized
DEBUG - 2018-06-11 18:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 18:26:42 --> CSRF cookie sent
INFO - 2018-06-11 18:26:42 --> Input Class Initialized
INFO - 2018-06-11 18:26:42 --> Language Class Initialized
INFO - 2018-06-11 18:26:42 --> Loader Class Initialized
INFO - 2018-06-11 18:26:42 --> Helper loaded: url_helper
INFO - 2018-06-11 18:26:42 --> Helper loaded: form_helper
INFO - 2018-06-11 18:26:42 --> Helper loaded: language_helper
DEBUG - 2018-06-11 18:26:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 18:26:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 18:26:42 --> User Agent Class Initialized
INFO - 2018-06-11 18:26:42 --> Controller Class Initialized
INFO - 2018-06-11 18:26:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 18:26:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 18:26:43 --> Pixel_Model class loaded
INFO - 2018-06-11 18:26:43 --> Database Driver Class Initialized
INFO - 2018-06-11 18:26:43 --> Model "QuestionsModel" initialized
INFO - 2018-06-11 18:26:43 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 18:26:43 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 18:26:43 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-06-11 18:26:43 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 18:26:43 --> Final output sent to browser
DEBUG - 2018-06-11 18:26:43 --> Total execution time: 0.2641
INFO - 2018-06-11 18:26:44 --> Config Class Initialized
INFO - 2018-06-11 18:26:44 --> Hooks Class Initialized
DEBUG - 2018-06-11 18:26:44 --> UTF-8 Support Enabled
INFO - 2018-06-11 18:26:44 --> Utf8 Class Initialized
INFO - 2018-06-11 18:26:44 --> URI Class Initialized
INFO - 2018-06-11 18:26:44 --> Router Class Initialized
INFO - 2018-06-11 18:26:44 --> Output Class Initialized
INFO - 2018-06-11 18:26:44 --> Security Class Initialized
DEBUG - 2018-06-11 18:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 18:26:44 --> CSRF cookie sent
INFO - 2018-06-11 18:26:44 --> Input Class Initialized
INFO - 2018-06-11 18:26:44 --> Language Class Initialized
ERROR - 2018-06-11 18:26:44 --> 404 Page Not Found: Revolution/assets
INFO - 2018-06-11 18:26:47 --> Config Class Initialized
INFO - 2018-06-11 18:26:47 --> Hooks Class Initialized
DEBUG - 2018-06-11 18:26:47 --> UTF-8 Support Enabled
INFO - 2018-06-11 18:26:47 --> Utf8 Class Initialized
INFO - 2018-06-11 18:26:47 --> URI Class Initialized
DEBUG - 2018-06-11 18:26:47 --> No URI present. Default controller set.
INFO - 2018-06-11 18:26:47 --> Router Class Initialized
INFO - 2018-06-11 18:26:47 --> Output Class Initialized
INFO - 2018-06-11 18:26:47 --> Security Class Initialized
DEBUG - 2018-06-11 18:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 18:26:47 --> CSRF cookie sent
INFO - 2018-06-11 18:26:47 --> Input Class Initialized
INFO - 2018-06-11 18:26:47 --> Language Class Initialized
INFO - 2018-06-11 18:26:47 --> Loader Class Initialized
INFO - 2018-06-11 18:26:47 --> Helper loaded: url_helper
INFO - 2018-06-11 18:26:47 --> Helper loaded: form_helper
INFO - 2018-06-11 18:26:47 --> Helper loaded: language_helper
DEBUG - 2018-06-11 18:26:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 18:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 18:26:47 --> User Agent Class Initialized
INFO - 2018-06-11 18:26:47 --> Controller Class Initialized
INFO - 2018-06-11 18:26:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 18:26:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 18:26:47 --> Pixel_Model class loaded
INFO - 2018-06-11 18:26:47 --> Database Driver Class Initialized
INFO - 2018-06-11 18:26:47 --> Model "QuestionsModel" initialized
INFO - 2018-06-11 18:26:47 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 18:26:47 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 18:26:47 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-06-11 18:26:47 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 18:26:47 --> Final output sent to browser
DEBUG - 2018-06-11 18:26:47 --> Total execution time: 0.2906
INFO - 2018-06-11 18:26:54 --> Config Class Initialized
INFO - 2018-06-11 18:26:54 --> Hooks Class Initialized
DEBUG - 2018-06-11 18:26:54 --> UTF-8 Support Enabled
INFO - 2018-06-11 18:26:54 --> Utf8 Class Initialized
INFO - 2018-06-11 18:26:54 --> URI Class Initialized
INFO - 2018-06-11 18:26:54 --> Router Class Initialized
INFO - 2018-06-11 18:26:54 --> Output Class Initialized
INFO - 2018-06-11 18:26:54 --> Security Class Initialized
DEBUG - 2018-06-11 18:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 18:26:54 --> CSRF cookie sent
INFO - 2018-06-11 18:26:54 --> Input Class Initialized
INFO - 2018-06-11 18:26:54 --> Language Class Initialized
ERROR - 2018-06-11 18:26:54 --> 404 Page Not Found: Assets/css
INFO - 2018-06-11 18:27:00 --> Config Class Initialized
INFO - 2018-06-11 18:27:00 --> Hooks Class Initialized
DEBUG - 2018-06-11 18:27:00 --> UTF-8 Support Enabled
INFO - 2018-06-11 18:27:00 --> Utf8 Class Initialized
INFO - 2018-06-11 18:27:00 --> URI Class Initialized
DEBUG - 2018-06-11 18:27:00 --> No URI present. Default controller set.
INFO - 2018-06-11 18:27:00 --> Router Class Initialized
INFO - 2018-06-11 18:27:00 --> Output Class Initialized
INFO - 2018-06-11 18:27:00 --> Security Class Initialized
DEBUG - 2018-06-11 18:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 18:27:00 --> CSRF cookie sent
INFO - 2018-06-11 18:27:00 --> Input Class Initialized
INFO - 2018-06-11 18:27:00 --> Language Class Initialized
INFO - 2018-06-11 18:27:00 --> Loader Class Initialized
INFO - 2018-06-11 18:27:00 --> Helper loaded: url_helper
INFO - 2018-06-11 18:27:00 --> Helper loaded: form_helper
INFO - 2018-06-11 18:27:00 --> Helper loaded: language_helper
DEBUG - 2018-06-11 18:27:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 18:27:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 18:27:00 --> User Agent Class Initialized
INFO - 2018-06-11 18:27:00 --> Controller Class Initialized
INFO - 2018-06-11 18:27:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 18:27:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 18:27:00 --> Pixel_Model class loaded
INFO - 2018-06-11 18:27:00 --> Database Driver Class Initialized
INFO - 2018-06-11 18:27:00 --> Model "QuestionsModel" initialized
INFO - 2018-06-11 18:27:00 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 18:27:00 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 18:27:00 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-06-11 18:27:00 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 18:27:00 --> Final output sent to browser
DEBUG - 2018-06-11 18:27:00 --> Total execution time: 0.3124
INFO - 2018-06-11 18:27:01 --> Config Class Initialized
INFO - 2018-06-11 18:27:01 --> Hooks Class Initialized
DEBUG - 2018-06-11 18:27:01 --> UTF-8 Support Enabled
INFO - 2018-06-11 18:27:01 --> Utf8 Class Initialized
INFO - 2018-06-11 18:27:01 --> URI Class Initialized
INFO - 2018-06-11 18:27:01 --> Router Class Initialized
INFO - 2018-06-11 18:27:01 --> Output Class Initialized
INFO - 2018-06-11 18:27:01 --> Security Class Initialized
DEBUG - 2018-06-11 18:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 18:27:01 --> CSRF cookie sent
INFO - 2018-06-11 18:27:01 --> Input Class Initialized
INFO - 2018-06-11 18:27:01 --> Language Class Initialized
ERROR - 2018-06-11 18:27:01 --> 404 Page Not Found: Assets/css
INFO - 2018-06-11 18:27:06 --> Config Class Initialized
INFO - 2018-06-11 18:27:06 --> Hooks Class Initialized
DEBUG - 2018-06-11 18:27:06 --> UTF-8 Support Enabled
INFO - 2018-06-11 18:27:06 --> Utf8 Class Initialized
INFO - 2018-06-11 18:27:06 --> URI Class Initialized
DEBUG - 2018-06-11 18:27:06 --> No URI present. Default controller set.
INFO - 2018-06-11 18:27:06 --> Router Class Initialized
INFO - 2018-06-11 18:27:06 --> Output Class Initialized
INFO - 2018-06-11 18:27:06 --> Security Class Initialized
DEBUG - 2018-06-11 18:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 18:27:06 --> CSRF cookie sent
INFO - 2018-06-11 18:27:06 --> Input Class Initialized
INFO - 2018-06-11 18:27:06 --> Language Class Initialized
INFO - 2018-06-11 18:27:06 --> Loader Class Initialized
INFO - 2018-06-11 18:27:06 --> Helper loaded: url_helper
INFO - 2018-06-11 18:27:06 --> Helper loaded: form_helper
INFO - 2018-06-11 18:27:06 --> Helper loaded: language_helper
DEBUG - 2018-06-11 18:27:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 18:27:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 18:27:06 --> User Agent Class Initialized
INFO - 2018-06-11 18:27:06 --> Controller Class Initialized
INFO - 2018-06-11 18:27:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 18:27:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 18:27:06 --> Pixel_Model class loaded
INFO - 2018-06-11 18:27:06 --> Database Driver Class Initialized
INFO - 2018-06-11 18:27:06 --> Model "QuestionsModel" initialized
INFO - 2018-06-11 18:27:06 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 18:27:06 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 18:27:06 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-06-11 18:27:06 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 18:27:06 --> Final output sent to browser
DEBUG - 2018-06-11 18:27:06 --> Total execution time: 0.3136
INFO - 2018-06-11 18:27:07 --> Config Class Initialized
INFO - 2018-06-11 18:27:07 --> Hooks Class Initialized
DEBUG - 2018-06-11 18:27:07 --> UTF-8 Support Enabled
INFO - 2018-06-11 18:27:07 --> Utf8 Class Initialized
INFO - 2018-06-11 18:27:07 --> URI Class Initialized
INFO - 2018-06-11 18:27:07 --> Router Class Initialized
INFO - 2018-06-11 18:27:07 --> Output Class Initialized
INFO - 2018-06-11 18:27:07 --> Security Class Initialized
DEBUG - 2018-06-11 18:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 18:27:07 --> CSRF cookie sent
INFO - 2018-06-11 18:27:07 --> Input Class Initialized
INFO - 2018-06-11 18:27:07 --> Language Class Initialized
ERROR - 2018-06-11 18:27:07 --> 404 Page Not Found: Assets/css
INFO - 2018-06-11 18:27:15 --> Config Class Initialized
INFO - 2018-06-11 18:27:15 --> Hooks Class Initialized
DEBUG - 2018-06-11 18:27:15 --> UTF-8 Support Enabled
INFO - 2018-06-11 18:27:15 --> Utf8 Class Initialized
INFO - 2018-06-11 18:27:15 --> URI Class Initialized
DEBUG - 2018-06-11 18:27:15 --> No URI present. Default controller set.
INFO - 2018-06-11 18:27:15 --> Router Class Initialized
INFO - 2018-06-11 18:27:15 --> Output Class Initialized
INFO - 2018-06-11 18:27:15 --> Security Class Initialized
DEBUG - 2018-06-11 18:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 18:27:15 --> CSRF cookie sent
INFO - 2018-06-11 18:27:15 --> Input Class Initialized
INFO - 2018-06-11 18:27:15 --> Language Class Initialized
INFO - 2018-06-11 18:27:15 --> Loader Class Initialized
INFO - 2018-06-11 18:27:15 --> Helper loaded: url_helper
INFO - 2018-06-11 18:27:15 --> Helper loaded: form_helper
INFO - 2018-06-11 18:27:15 --> Helper loaded: language_helper
DEBUG - 2018-06-11 18:27:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 18:27:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 18:27:15 --> User Agent Class Initialized
INFO - 2018-06-11 18:27:15 --> Controller Class Initialized
INFO - 2018-06-11 18:27:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 18:27:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 18:27:15 --> Pixel_Model class loaded
INFO - 2018-06-11 18:27:15 --> Database Driver Class Initialized
INFO - 2018-06-11 18:27:15 --> Model "QuestionsModel" initialized
INFO - 2018-06-11 18:27:15 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 18:27:15 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 18:27:15 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-06-11 18:27:15 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 18:27:15 --> Final output sent to browser
DEBUG - 2018-06-11 18:27:15 --> Total execution time: 0.2898
INFO - 2018-06-11 18:27:16 --> Config Class Initialized
INFO - 2018-06-11 18:27:16 --> Hooks Class Initialized
DEBUG - 2018-06-11 18:27:16 --> UTF-8 Support Enabled
INFO - 2018-06-11 18:27:16 --> Utf8 Class Initialized
INFO - 2018-06-11 18:27:16 --> URI Class Initialized
INFO - 2018-06-11 18:27:16 --> Router Class Initialized
INFO - 2018-06-11 18:27:16 --> Output Class Initialized
INFO - 2018-06-11 18:27:16 --> Security Class Initialized
DEBUG - 2018-06-11 18:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 18:27:16 --> CSRF cookie sent
INFO - 2018-06-11 18:27:16 --> Input Class Initialized
INFO - 2018-06-11 18:27:16 --> Language Class Initialized
ERROR - 2018-06-11 18:27:16 --> 404 Page Not Found: Assets/css
INFO - 2018-06-11 18:28:00 --> Config Class Initialized
INFO - 2018-06-11 18:28:00 --> Hooks Class Initialized
DEBUG - 2018-06-11 18:28:00 --> UTF-8 Support Enabled
INFO - 2018-06-11 18:28:00 --> Utf8 Class Initialized
INFO - 2018-06-11 18:28:00 --> URI Class Initialized
DEBUG - 2018-06-11 18:28:00 --> No URI present. Default controller set.
INFO - 2018-06-11 18:28:00 --> Router Class Initialized
INFO - 2018-06-11 18:28:00 --> Output Class Initialized
INFO - 2018-06-11 18:28:00 --> Security Class Initialized
DEBUG - 2018-06-11 18:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 18:28:00 --> CSRF cookie sent
INFO - 2018-06-11 18:28:00 --> Input Class Initialized
INFO - 2018-06-11 18:28:00 --> Language Class Initialized
INFO - 2018-06-11 18:28:00 --> Loader Class Initialized
INFO - 2018-06-11 18:28:00 --> Helper loaded: url_helper
INFO - 2018-06-11 18:28:00 --> Helper loaded: form_helper
INFO - 2018-06-11 18:28:00 --> Helper loaded: language_helper
DEBUG - 2018-06-11 18:28:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 18:28:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 18:28:00 --> User Agent Class Initialized
INFO - 2018-06-11 18:28:00 --> Controller Class Initialized
INFO - 2018-06-11 18:28:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 18:28:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 18:28:00 --> Pixel_Model class loaded
INFO - 2018-06-11 18:28:00 --> Database Driver Class Initialized
INFO - 2018-06-11 18:28:00 --> Model "QuestionsModel" initialized
INFO - 2018-06-11 18:28:00 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 18:28:00 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 18:28:00 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-06-11 18:28:00 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 18:28:00 --> Final output sent to browser
DEBUG - 2018-06-11 18:28:00 --> Total execution time: 0.3367
INFO - 2018-06-11 18:28:02 --> Config Class Initialized
INFO - 2018-06-11 18:28:02 --> Hooks Class Initialized
DEBUG - 2018-06-11 18:28:02 --> UTF-8 Support Enabled
INFO - 2018-06-11 18:28:02 --> Utf8 Class Initialized
INFO - 2018-06-11 18:28:02 --> URI Class Initialized
INFO - 2018-06-11 18:28:02 --> Router Class Initialized
INFO - 2018-06-11 18:28:02 --> Output Class Initialized
INFO - 2018-06-11 18:28:02 --> Security Class Initialized
DEBUG - 2018-06-11 18:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 18:28:02 --> CSRF cookie sent
INFO - 2018-06-11 18:28:02 --> Input Class Initialized
INFO - 2018-06-11 18:28:02 --> Language Class Initialized
ERROR - 2018-06-11 18:28:02 --> 404 Page Not Found: Assets/css
INFO - 2018-06-11 18:39:26 --> Config Class Initialized
INFO - 2018-06-11 18:39:26 --> Hooks Class Initialized
DEBUG - 2018-06-11 18:39:26 --> UTF-8 Support Enabled
INFO - 2018-06-11 18:39:26 --> Utf8 Class Initialized
INFO - 2018-06-11 18:39:26 --> URI Class Initialized
DEBUG - 2018-06-11 18:39:26 --> No URI present. Default controller set.
INFO - 2018-06-11 18:39:26 --> Router Class Initialized
INFO - 2018-06-11 18:39:26 --> Output Class Initialized
INFO - 2018-06-11 18:39:26 --> Security Class Initialized
DEBUG - 2018-06-11 18:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 18:39:26 --> CSRF cookie sent
INFO - 2018-06-11 18:39:26 --> Input Class Initialized
INFO - 2018-06-11 18:39:26 --> Language Class Initialized
INFO - 2018-06-11 18:39:27 --> Loader Class Initialized
INFO - 2018-06-11 18:39:27 --> Helper loaded: url_helper
INFO - 2018-06-11 18:39:27 --> Helper loaded: form_helper
INFO - 2018-06-11 18:39:27 --> Helper loaded: language_helper
DEBUG - 2018-06-11 18:39:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 18:39:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 18:39:27 --> User Agent Class Initialized
INFO - 2018-06-11 18:39:27 --> Controller Class Initialized
INFO - 2018-06-11 18:39:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 18:39:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 18:39:27 --> Pixel_Model class loaded
INFO - 2018-06-11 18:39:27 --> Database Driver Class Initialized
INFO - 2018-06-11 18:39:27 --> Model "QuestionsModel" initialized
INFO - 2018-06-11 18:39:27 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 18:39:27 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 18:39:27 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-06-11 18:39:27 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 18:39:27 --> Final output sent to browser
DEBUG - 2018-06-11 18:39:27 --> Total execution time: 0.2980
INFO - 2018-06-11 18:39:27 --> Config Class Initialized
INFO - 2018-06-11 18:39:27 --> Hooks Class Initialized
DEBUG - 2018-06-11 18:39:27 --> UTF-8 Support Enabled
INFO - 2018-06-11 18:39:27 --> Utf8 Class Initialized
INFO - 2018-06-11 18:39:27 --> URI Class Initialized
INFO - 2018-06-11 18:39:27 --> Router Class Initialized
INFO - 2018-06-11 18:39:27 --> Output Class Initialized
INFO - 2018-06-11 18:39:27 --> Security Class Initialized
DEBUG - 2018-06-11 18:39:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 18:39:27 --> CSRF cookie sent
INFO - 2018-06-11 18:39:27 --> Input Class Initialized
INFO - 2018-06-11 18:39:27 --> Language Class Initialized
ERROR - 2018-06-11 18:39:27 --> 404 Page Not Found: Assets/css
INFO - 2018-06-11 18:39:34 --> Config Class Initialized
INFO - 2018-06-11 18:39:34 --> Hooks Class Initialized
DEBUG - 2018-06-11 18:39:34 --> UTF-8 Support Enabled
INFO - 2018-06-11 18:39:34 --> Utf8 Class Initialized
INFO - 2018-06-11 18:39:34 --> URI Class Initialized
DEBUG - 2018-06-11 18:39:34 --> No URI present. Default controller set.
INFO - 2018-06-11 18:39:34 --> Router Class Initialized
INFO - 2018-06-11 18:39:34 --> Output Class Initialized
INFO - 2018-06-11 18:39:34 --> Security Class Initialized
DEBUG - 2018-06-11 18:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 18:39:34 --> CSRF cookie sent
INFO - 2018-06-11 18:39:34 --> Input Class Initialized
INFO - 2018-06-11 18:39:34 --> Language Class Initialized
INFO - 2018-06-11 18:39:34 --> Loader Class Initialized
INFO - 2018-06-11 18:39:34 --> Helper loaded: url_helper
INFO - 2018-06-11 18:39:34 --> Helper loaded: form_helper
INFO - 2018-06-11 18:39:34 --> Helper loaded: language_helper
DEBUG - 2018-06-11 18:39:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 18:39:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 18:39:34 --> User Agent Class Initialized
INFO - 2018-06-11 18:39:34 --> Controller Class Initialized
INFO - 2018-06-11 18:39:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 18:39:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 18:39:34 --> Pixel_Model class loaded
INFO - 2018-06-11 18:39:34 --> Database Driver Class Initialized
INFO - 2018-06-11 18:39:34 --> Model "QuestionsModel" initialized
INFO - 2018-06-11 18:39:34 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 18:39:34 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 18:39:34 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-06-11 18:39:34 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 18:39:34 --> Final output sent to browser
DEBUG - 2018-06-11 18:39:34 --> Total execution time: 0.2998
INFO - 2018-06-11 18:39:34 --> Config Class Initialized
INFO - 2018-06-11 18:39:34 --> Hooks Class Initialized
DEBUG - 2018-06-11 18:39:34 --> UTF-8 Support Enabled
INFO - 2018-06-11 18:39:34 --> Utf8 Class Initialized
INFO - 2018-06-11 18:39:34 --> URI Class Initialized
INFO - 2018-06-11 18:39:34 --> Router Class Initialized
INFO - 2018-06-11 18:39:34 --> Output Class Initialized
INFO - 2018-06-11 18:39:34 --> Security Class Initialized
DEBUG - 2018-06-11 18:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 18:39:34 --> CSRF cookie sent
INFO - 2018-06-11 18:39:34 --> Input Class Initialized
INFO - 2018-06-11 18:39:34 --> Language Class Initialized
ERROR - 2018-06-11 18:39:34 --> 404 Page Not Found: Assets/css
INFO - 2018-06-11 18:40:08 --> Config Class Initialized
INFO - 2018-06-11 18:40:08 --> Hooks Class Initialized
DEBUG - 2018-06-11 18:40:08 --> UTF-8 Support Enabled
INFO - 2018-06-11 18:40:09 --> Utf8 Class Initialized
INFO - 2018-06-11 18:40:09 --> URI Class Initialized
DEBUG - 2018-06-11 18:40:09 --> No URI present. Default controller set.
INFO - 2018-06-11 18:40:09 --> Router Class Initialized
INFO - 2018-06-11 18:40:09 --> Output Class Initialized
INFO - 2018-06-11 18:40:09 --> Security Class Initialized
DEBUG - 2018-06-11 18:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 18:40:09 --> CSRF cookie sent
INFO - 2018-06-11 18:40:09 --> Input Class Initialized
INFO - 2018-06-11 18:40:09 --> Language Class Initialized
INFO - 2018-06-11 18:40:09 --> Loader Class Initialized
INFO - 2018-06-11 18:40:09 --> Helper loaded: url_helper
INFO - 2018-06-11 18:40:09 --> Helper loaded: form_helper
INFO - 2018-06-11 18:40:09 --> Helper loaded: language_helper
DEBUG - 2018-06-11 18:40:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 18:40:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 18:40:09 --> User Agent Class Initialized
INFO - 2018-06-11 18:40:09 --> Controller Class Initialized
INFO - 2018-06-11 18:40:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 18:40:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 18:40:09 --> Pixel_Model class loaded
INFO - 2018-06-11 18:40:09 --> Database Driver Class Initialized
INFO - 2018-06-11 18:40:09 --> Model "QuestionsModel" initialized
INFO - 2018-06-11 18:40:09 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 18:40:09 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 18:40:09 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-06-11 18:40:09 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 18:40:09 --> Final output sent to browser
DEBUG - 2018-06-11 18:40:09 --> Total execution time: 0.3075
INFO - 2018-06-11 18:40:09 --> Config Class Initialized
INFO - 2018-06-11 18:40:09 --> Hooks Class Initialized
DEBUG - 2018-06-11 18:40:09 --> UTF-8 Support Enabled
INFO - 2018-06-11 18:40:09 --> Utf8 Class Initialized
INFO - 2018-06-11 18:40:09 --> URI Class Initialized
INFO - 2018-06-11 18:40:09 --> Router Class Initialized
INFO - 2018-06-11 18:40:09 --> Output Class Initialized
INFO - 2018-06-11 18:40:09 --> Security Class Initialized
DEBUG - 2018-06-11 18:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 18:40:09 --> CSRF cookie sent
INFO - 2018-06-11 18:40:09 --> Input Class Initialized
INFO - 2018-06-11 18:40:09 --> Language Class Initialized
ERROR - 2018-06-11 18:40:09 --> 404 Page Not Found: Assets/css
INFO - 2018-06-11 18:40:27 --> Config Class Initialized
INFO - 2018-06-11 18:40:27 --> Hooks Class Initialized
DEBUG - 2018-06-11 18:40:27 --> UTF-8 Support Enabled
INFO - 2018-06-11 18:40:27 --> Utf8 Class Initialized
INFO - 2018-06-11 18:40:27 --> URI Class Initialized
DEBUG - 2018-06-11 18:40:27 --> No URI present. Default controller set.
INFO - 2018-06-11 18:40:27 --> Router Class Initialized
INFO - 2018-06-11 18:40:27 --> Output Class Initialized
INFO - 2018-06-11 18:40:27 --> Security Class Initialized
DEBUG - 2018-06-11 18:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 18:40:27 --> CSRF cookie sent
INFO - 2018-06-11 18:40:27 --> Input Class Initialized
INFO - 2018-06-11 18:40:27 --> Language Class Initialized
INFO - 2018-06-11 18:40:27 --> Loader Class Initialized
INFO - 2018-06-11 18:40:27 --> Helper loaded: url_helper
INFO - 2018-06-11 18:40:27 --> Helper loaded: form_helper
INFO - 2018-06-11 18:40:27 --> Helper loaded: language_helper
DEBUG - 2018-06-11 18:40:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 18:40:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 18:40:27 --> User Agent Class Initialized
INFO - 2018-06-11 18:40:27 --> Controller Class Initialized
INFO - 2018-06-11 18:40:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 18:40:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 18:40:27 --> Pixel_Model class loaded
INFO - 2018-06-11 18:40:27 --> Database Driver Class Initialized
INFO - 2018-06-11 18:40:27 --> Model "QuestionsModel" initialized
INFO - 2018-06-11 18:40:27 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 18:40:27 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 18:40:27 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-06-11 18:40:27 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 18:40:27 --> Final output sent to browser
DEBUG - 2018-06-11 18:40:27 --> Total execution time: 0.3186
INFO - 2018-06-11 18:40:28 --> Config Class Initialized
INFO - 2018-06-11 18:40:28 --> Hooks Class Initialized
DEBUG - 2018-06-11 18:40:28 --> UTF-8 Support Enabled
INFO - 2018-06-11 18:40:28 --> Utf8 Class Initialized
INFO - 2018-06-11 18:40:28 --> URI Class Initialized
INFO - 2018-06-11 18:40:28 --> Router Class Initialized
INFO - 2018-06-11 18:40:28 --> Output Class Initialized
INFO - 2018-06-11 18:40:28 --> Security Class Initialized
DEBUG - 2018-06-11 18:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 18:40:28 --> CSRF cookie sent
INFO - 2018-06-11 18:40:28 --> Input Class Initialized
INFO - 2018-06-11 18:40:28 --> Language Class Initialized
ERROR - 2018-06-11 18:40:28 --> 404 Page Not Found: Assets/css
INFO - 2018-06-11 18:40:32 --> Config Class Initialized
INFO - 2018-06-11 18:40:32 --> Hooks Class Initialized
DEBUG - 2018-06-11 18:40:32 --> UTF-8 Support Enabled
INFO - 2018-06-11 18:40:32 --> Utf8 Class Initialized
INFO - 2018-06-11 18:40:32 --> URI Class Initialized
DEBUG - 2018-06-11 18:40:32 --> No URI present. Default controller set.
INFO - 2018-06-11 18:40:32 --> Router Class Initialized
INFO - 2018-06-11 18:40:32 --> Output Class Initialized
INFO - 2018-06-11 18:40:32 --> Security Class Initialized
DEBUG - 2018-06-11 18:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 18:40:32 --> CSRF cookie sent
INFO - 2018-06-11 18:40:32 --> Input Class Initialized
INFO - 2018-06-11 18:40:32 --> Language Class Initialized
INFO - 2018-06-11 18:40:32 --> Loader Class Initialized
INFO - 2018-06-11 18:40:32 --> Helper loaded: url_helper
INFO - 2018-06-11 18:40:32 --> Helper loaded: form_helper
INFO - 2018-06-11 18:40:32 --> Helper loaded: language_helper
DEBUG - 2018-06-11 18:40:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 18:40:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 18:40:32 --> User Agent Class Initialized
INFO - 2018-06-11 18:40:32 --> Controller Class Initialized
INFO - 2018-06-11 18:40:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 18:40:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 18:40:32 --> Pixel_Model class loaded
INFO - 2018-06-11 18:40:32 --> Database Driver Class Initialized
INFO - 2018-06-11 18:40:32 --> Model "QuestionsModel" initialized
INFO - 2018-06-11 18:40:32 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 18:40:32 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 18:40:32 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-06-11 18:40:32 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 18:40:32 --> Final output sent to browser
DEBUG - 2018-06-11 18:40:32 --> Total execution time: 0.3503
INFO - 2018-06-11 18:40:33 --> Config Class Initialized
INFO - 2018-06-11 18:40:33 --> Hooks Class Initialized
DEBUG - 2018-06-11 18:40:33 --> UTF-8 Support Enabled
INFO - 2018-06-11 18:40:33 --> Utf8 Class Initialized
INFO - 2018-06-11 18:40:33 --> URI Class Initialized
INFO - 2018-06-11 18:40:33 --> Router Class Initialized
INFO - 2018-06-11 18:40:33 --> Output Class Initialized
INFO - 2018-06-11 18:40:33 --> Security Class Initialized
DEBUG - 2018-06-11 18:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 18:40:33 --> CSRF cookie sent
INFO - 2018-06-11 18:40:33 --> Input Class Initialized
INFO - 2018-06-11 18:40:33 --> Language Class Initialized
ERROR - 2018-06-11 18:40:33 --> 404 Page Not Found: Assets/css
INFO - 2018-06-11 18:41:03 --> Config Class Initialized
INFO - 2018-06-11 18:41:03 --> Hooks Class Initialized
DEBUG - 2018-06-11 18:41:03 --> UTF-8 Support Enabled
INFO - 2018-06-11 18:41:03 --> Utf8 Class Initialized
INFO - 2018-06-11 18:41:03 --> URI Class Initialized
DEBUG - 2018-06-11 18:41:03 --> No URI present. Default controller set.
INFO - 2018-06-11 18:41:03 --> Router Class Initialized
INFO - 2018-06-11 18:41:03 --> Output Class Initialized
INFO - 2018-06-11 18:41:03 --> Security Class Initialized
DEBUG - 2018-06-11 18:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 18:41:03 --> CSRF cookie sent
INFO - 2018-06-11 18:41:03 --> Input Class Initialized
INFO - 2018-06-11 18:41:03 --> Language Class Initialized
INFO - 2018-06-11 18:41:03 --> Loader Class Initialized
INFO - 2018-06-11 18:41:03 --> Helper loaded: url_helper
INFO - 2018-06-11 18:41:03 --> Helper loaded: form_helper
INFO - 2018-06-11 18:41:03 --> Helper loaded: language_helper
DEBUG - 2018-06-11 18:41:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 18:41:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 18:41:03 --> User Agent Class Initialized
INFO - 2018-06-11 18:41:03 --> Controller Class Initialized
INFO - 2018-06-11 18:41:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 18:41:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 18:41:03 --> Pixel_Model class loaded
INFO - 2018-06-11 18:41:03 --> Database Driver Class Initialized
INFO - 2018-06-11 18:41:03 --> Model "QuestionsModel" initialized
INFO - 2018-06-11 18:41:03 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 18:41:03 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 18:41:03 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-06-11 18:41:03 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 18:41:03 --> Final output sent to browser
DEBUG - 2018-06-11 18:41:03 --> Total execution time: 0.3063
INFO - 2018-06-11 18:43:11 --> Config Class Initialized
INFO - 2018-06-11 18:43:11 --> Hooks Class Initialized
DEBUG - 2018-06-11 18:43:11 --> UTF-8 Support Enabled
INFO - 2018-06-11 18:43:11 --> Utf8 Class Initialized
INFO - 2018-06-11 18:43:11 --> URI Class Initialized
DEBUG - 2018-06-11 18:43:11 --> No URI present. Default controller set.
INFO - 2018-06-11 18:43:11 --> Router Class Initialized
INFO - 2018-06-11 18:43:11 --> Output Class Initialized
INFO - 2018-06-11 18:43:11 --> Security Class Initialized
DEBUG - 2018-06-11 18:43:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 18:43:11 --> CSRF cookie sent
INFO - 2018-06-11 18:43:11 --> Input Class Initialized
INFO - 2018-06-11 18:43:11 --> Language Class Initialized
INFO - 2018-06-11 18:43:12 --> Loader Class Initialized
INFO - 2018-06-11 18:43:12 --> Helper loaded: url_helper
INFO - 2018-06-11 18:43:12 --> Helper loaded: form_helper
INFO - 2018-06-11 18:43:12 --> Helper loaded: language_helper
DEBUG - 2018-06-11 18:43:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 18:43:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 18:43:12 --> User Agent Class Initialized
INFO - 2018-06-11 18:43:12 --> Controller Class Initialized
INFO - 2018-06-11 18:43:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 18:43:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 18:43:12 --> Pixel_Model class loaded
INFO - 2018-06-11 18:43:12 --> Database Driver Class Initialized
INFO - 2018-06-11 18:43:12 --> Model "QuestionsModel" initialized
INFO - 2018-06-11 18:43:12 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 18:43:12 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 18:43:12 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-06-11 18:43:12 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 18:43:12 --> Final output sent to browser
DEBUG - 2018-06-11 18:43:12 --> Total execution time: 0.8570
INFO - 2018-06-11 18:43:17 --> Config Class Initialized
INFO - 2018-06-11 18:43:17 --> Hooks Class Initialized
DEBUG - 2018-06-11 18:43:17 --> UTF-8 Support Enabled
INFO - 2018-06-11 18:43:17 --> Utf8 Class Initialized
INFO - 2018-06-11 18:43:17 --> URI Class Initialized
DEBUG - 2018-06-11 18:43:17 --> No URI present. Default controller set.
INFO - 2018-06-11 18:43:17 --> Router Class Initialized
INFO - 2018-06-11 18:43:17 --> Output Class Initialized
INFO - 2018-06-11 18:43:17 --> Security Class Initialized
DEBUG - 2018-06-11 18:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 18:43:17 --> CSRF cookie sent
INFO - 2018-06-11 18:43:17 --> Input Class Initialized
INFO - 2018-06-11 18:43:17 --> Language Class Initialized
INFO - 2018-06-11 18:43:18 --> Loader Class Initialized
INFO - 2018-06-11 18:43:18 --> Helper loaded: url_helper
INFO - 2018-06-11 18:43:18 --> Helper loaded: form_helper
INFO - 2018-06-11 18:43:18 --> Helper loaded: language_helper
DEBUG - 2018-06-11 18:43:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 18:43:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 18:43:18 --> User Agent Class Initialized
INFO - 2018-06-11 18:43:18 --> Controller Class Initialized
INFO - 2018-06-11 18:43:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 18:43:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 18:43:18 --> Pixel_Model class loaded
INFO - 2018-06-11 18:43:18 --> Database Driver Class Initialized
INFO - 2018-06-11 18:43:18 --> Model "QuestionsModel" initialized
INFO - 2018-06-11 18:43:18 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 18:43:18 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 18:43:18 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-06-11 18:43:18 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 18:43:18 --> Final output sent to browser
DEBUG - 2018-06-11 18:43:18 --> Total execution time: 0.3012
INFO - 2018-06-11 18:46:14 --> Config Class Initialized
INFO - 2018-06-11 18:46:14 --> Hooks Class Initialized
DEBUG - 2018-06-11 18:46:14 --> UTF-8 Support Enabled
INFO - 2018-06-11 18:46:14 --> Utf8 Class Initialized
INFO - 2018-06-11 18:46:14 --> URI Class Initialized
INFO - 2018-06-11 18:46:14 --> Router Class Initialized
INFO - 2018-06-11 18:46:14 --> Output Class Initialized
INFO - 2018-06-11 18:46:14 --> Security Class Initialized
DEBUG - 2018-06-11 18:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 18:46:14 --> CSRF cookie sent
INFO - 2018-06-11 18:46:14 --> Input Class Initialized
INFO - 2018-06-11 18:46:14 --> Language Class Initialized
ERROR - 2018-06-11 18:46:14 --> 404 Page Not Found: Assets/css
INFO - 2018-06-11 18:49:44 --> Config Class Initialized
INFO - 2018-06-11 18:49:44 --> Hooks Class Initialized
DEBUG - 2018-06-11 18:49:44 --> UTF-8 Support Enabled
INFO - 2018-06-11 18:49:44 --> Utf8 Class Initialized
INFO - 2018-06-11 18:49:44 --> URI Class Initialized
DEBUG - 2018-06-11 18:49:44 --> No URI present. Default controller set.
INFO - 2018-06-11 18:49:44 --> Router Class Initialized
INFO - 2018-06-11 18:49:44 --> Output Class Initialized
INFO - 2018-06-11 18:49:44 --> Security Class Initialized
DEBUG - 2018-06-11 18:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 18:49:44 --> CSRF cookie sent
INFO - 2018-06-11 18:49:44 --> Input Class Initialized
INFO - 2018-06-11 18:49:44 --> Language Class Initialized
INFO - 2018-06-11 18:49:44 --> Loader Class Initialized
INFO - 2018-06-11 18:49:44 --> Helper loaded: url_helper
INFO - 2018-06-11 18:49:44 --> Helper loaded: form_helper
INFO - 2018-06-11 18:49:44 --> Helper loaded: language_helper
DEBUG - 2018-06-11 18:49:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 18:49:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 18:49:44 --> User Agent Class Initialized
INFO - 2018-06-11 18:49:44 --> Controller Class Initialized
INFO - 2018-06-11 18:49:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 18:49:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 18:49:44 --> Pixel_Model class loaded
INFO - 2018-06-11 18:49:45 --> Database Driver Class Initialized
INFO - 2018-06-11 18:49:45 --> Model "QuestionsModel" initialized
INFO - 2018-06-11 18:49:45 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 18:49:45 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 18:49:45 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-06-11 18:49:45 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 18:49:45 --> Final output sent to browser
DEBUG - 2018-06-11 18:49:45 --> Total execution time: 0.2868
INFO - 2018-06-11 18:49:46 --> Config Class Initialized
INFO - 2018-06-11 18:49:46 --> Hooks Class Initialized
DEBUG - 2018-06-11 18:49:46 --> UTF-8 Support Enabled
INFO - 2018-06-11 18:49:46 --> Utf8 Class Initialized
INFO - 2018-06-11 18:49:46 --> URI Class Initialized
DEBUG - 2018-06-11 18:49:46 --> No URI present. Default controller set.
INFO - 2018-06-11 18:49:46 --> Router Class Initialized
INFO - 2018-06-11 18:49:46 --> Output Class Initialized
INFO - 2018-06-11 18:49:46 --> Security Class Initialized
DEBUG - 2018-06-11 18:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 18:49:46 --> CSRF cookie sent
INFO - 2018-06-11 18:49:46 --> Input Class Initialized
INFO - 2018-06-11 18:49:46 --> Language Class Initialized
INFO - 2018-06-11 18:49:46 --> Loader Class Initialized
INFO - 2018-06-11 18:49:46 --> Helper loaded: url_helper
INFO - 2018-06-11 18:49:46 --> Helper loaded: form_helper
INFO - 2018-06-11 18:49:46 --> Helper loaded: language_helper
DEBUG - 2018-06-11 18:49:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 18:49:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 18:49:46 --> User Agent Class Initialized
INFO - 2018-06-11 18:49:46 --> Controller Class Initialized
INFO - 2018-06-11 18:49:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 18:49:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 18:49:47 --> Pixel_Model class loaded
INFO - 2018-06-11 18:49:47 --> Database Driver Class Initialized
INFO - 2018-06-11 18:49:47 --> Model "QuestionsModel" initialized
INFO - 2018-06-11 18:49:47 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 18:49:47 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 18:49:47 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-06-11 18:49:47 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 18:49:47 --> Final output sent to browser
DEBUG - 2018-06-11 18:49:47 --> Total execution time: 0.3200
INFO - 2018-06-11 18:50:17 --> Config Class Initialized
INFO - 2018-06-11 18:50:17 --> Hooks Class Initialized
DEBUG - 2018-06-11 18:50:17 --> UTF-8 Support Enabled
INFO - 2018-06-11 18:50:17 --> Utf8 Class Initialized
INFO - 2018-06-11 18:50:17 --> URI Class Initialized
DEBUG - 2018-06-11 18:50:17 --> No URI present. Default controller set.
INFO - 2018-06-11 18:50:17 --> Router Class Initialized
INFO - 2018-06-11 18:50:17 --> Output Class Initialized
INFO - 2018-06-11 18:50:17 --> Security Class Initialized
DEBUG - 2018-06-11 18:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 18:50:17 --> CSRF cookie sent
INFO - 2018-06-11 18:50:17 --> Input Class Initialized
INFO - 2018-06-11 18:50:17 --> Language Class Initialized
INFO - 2018-06-11 18:50:17 --> Loader Class Initialized
INFO - 2018-06-11 18:50:17 --> Helper loaded: url_helper
INFO - 2018-06-11 18:50:17 --> Helper loaded: form_helper
INFO - 2018-06-11 18:50:17 --> Helper loaded: language_helper
DEBUG - 2018-06-11 18:50:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 18:50:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 18:50:17 --> User Agent Class Initialized
INFO - 2018-06-11 18:50:17 --> Controller Class Initialized
INFO - 2018-06-11 18:50:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 18:50:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 18:50:17 --> Pixel_Model class loaded
INFO - 2018-06-11 18:50:17 --> Database Driver Class Initialized
INFO - 2018-06-11 18:50:17 --> Model "QuestionsModel" initialized
INFO - 2018-06-11 18:50:17 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 18:50:17 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 18:50:17 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-06-11 18:50:17 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 18:50:17 --> Final output sent to browser
DEBUG - 2018-06-11 18:50:17 --> Total execution time: 0.3399
INFO - 2018-06-11 18:50:35 --> Config Class Initialized
INFO - 2018-06-11 18:50:35 --> Hooks Class Initialized
DEBUG - 2018-06-11 18:50:35 --> UTF-8 Support Enabled
INFO - 2018-06-11 18:50:35 --> Utf8 Class Initialized
INFO - 2018-06-11 18:50:35 --> URI Class Initialized
DEBUG - 2018-06-11 18:50:35 --> No URI present. Default controller set.
INFO - 2018-06-11 18:50:35 --> Router Class Initialized
INFO - 2018-06-11 18:50:35 --> Output Class Initialized
INFO - 2018-06-11 18:50:35 --> Security Class Initialized
DEBUG - 2018-06-11 18:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 18:50:35 --> CSRF cookie sent
INFO - 2018-06-11 18:50:35 --> Input Class Initialized
INFO - 2018-06-11 18:50:35 --> Language Class Initialized
INFO - 2018-06-11 18:50:35 --> Loader Class Initialized
INFO - 2018-06-11 18:50:35 --> Helper loaded: url_helper
INFO - 2018-06-11 18:50:35 --> Helper loaded: form_helper
INFO - 2018-06-11 18:50:35 --> Helper loaded: language_helper
DEBUG - 2018-06-11 18:50:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 18:50:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 18:50:35 --> User Agent Class Initialized
INFO - 2018-06-11 18:50:35 --> Controller Class Initialized
INFO - 2018-06-11 18:50:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 18:50:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 18:50:35 --> Pixel_Model class loaded
INFO - 2018-06-11 18:50:35 --> Database Driver Class Initialized
INFO - 2018-06-11 18:50:35 --> Model "QuestionsModel" initialized
INFO - 2018-06-11 18:50:35 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 18:50:35 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 18:50:35 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-06-11 18:50:35 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 18:50:35 --> Final output sent to browser
DEBUG - 2018-06-11 18:50:35 --> Total execution time: 0.3490
INFO - 2018-06-11 18:50:39 --> Config Class Initialized
INFO - 2018-06-11 18:50:39 --> Hooks Class Initialized
DEBUG - 2018-06-11 18:50:39 --> UTF-8 Support Enabled
INFO - 2018-06-11 18:50:39 --> Utf8 Class Initialized
INFO - 2018-06-11 18:50:39 --> URI Class Initialized
INFO - 2018-06-11 18:50:39 --> Router Class Initialized
INFO - 2018-06-11 18:50:39 --> Output Class Initialized
INFO - 2018-06-11 18:50:39 --> Security Class Initialized
DEBUG - 2018-06-11 18:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 18:50:39 --> CSRF cookie sent
INFO - 2018-06-11 18:50:39 --> Input Class Initialized
INFO - 2018-06-11 18:50:39 --> Language Class Initialized
ERROR - 2018-06-11 18:50:39 --> 404 Page Not Found: Assets/css
INFO - 2018-06-11 18:57:35 --> Config Class Initialized
INFO - 2018-06-11 18:57:35 --> Hooks Class Initialized
DEBUG - 2018-06-11 18:57:35 --> UTF-8 Support Enabled
INFO - 2018-06-11 18:57:35 --> Utf8 Class Initialized
INFO - 2018-06-11 18:57:35 --> URI Class Initialized
DEBUG - 2018-06-11 18:57:35 --> No URI present. Default controller set.
INFO - 2018-06-11 18:57:35 --> Router Class Initialized
INFO - 2018-06-11 18:57:35 --> Output Class Initialized
INFO - 2018-06-11 18:57:35 --> Security Class Initialized
DEBUG - 2018-06-11 18:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 18:57:35 --> CSRF cookie sent
INFO - 2018-06-11 18:57:35 --> Input Class Initialized
INFO - 2018-06-11 18:57:35 --> Language Class Initialized
INFO - 2018-06-11 18:57:35 --> Loader Class Initialized
INFO - 2018-06-11 18:57:35 --> Helper loaded: url_helper
INFO - 2018-06-11 18:57:35 --> Helper loaded: form_helper
INFO - 2018-06-11 18:57:35 --> Helper loaded: language_helper
DEBUG - 2018-06-11 18:57:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 18:57:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 18:57:35 --> User Agent Class Initialized
INFO - 2018-06-11 18:57:35 --> Controller Class Initialized
INFO - 2018-06-11 18:57:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 18:57:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 18:57:35 --> Pixel_Model class loaded
INFO - 2018-06-11 18:57:35 --> Database Driver Class Initialized
INFO - 2018-06-11 18:57:35 --> Model "QuestionsModel" initialized
INFO - 2018-06-11 18:57:35 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 18:57:35 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 18:57:35 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-06-11 18:57:36 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 18:57:36 --> Final output sent to browser
DEBUG - 2018-06-11 18:57:36 --> Total execution time: 0.3402
INFO - 2018-06-11 18:57:40 --> Config Class Initialized
INFO - 2018-06-11 18:57:40 --> Hooks Class Initialized
DEBUG - 2018-06-11 18:57:40 --> UTF-8 Support Enabled
INFO - 2018-06-11 18:57:40 --> Utf8 Class Initialized
INFO - 2018-06-11 18:57:40 --> URI Class Initialized
INFO - 2018-06-11 18:57:40 --> Router Class Initialized
INFO - 2018-06-11 18:57:40 --> Output Class Initialized
INFO - 2018-06-11 18:57:40 --> Security Class Initialized
DEBUG - 2018-06-11 18:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 18:57:40 --> CSRF cookie sent
INFO - 2018-06-11 18:57:40 --> Input Class Initialized
INFO - 2018-06-11 18:57:40 --> Language Class Initialized
INFO - 2018-06-11 18:57:40 --> Loader Class Initialized
INFO - 2018-06-11 18:57:40 --> Helper loaded: url_helper
INFO - 2018-06-11 18:57:40 --> Helper loaded: form_helper
INFO - 2018-06-11 18:57:40 --> Helper loaded: language_helper
DEBUG - 2018-06-11 18:57:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 18:57:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 18:57:40 --> User Agent Class Initialized
INFO - 2018-06-11 18:57:40 --> Controller Class Initialized
INFO - 2018-06-11 18:57:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 18:57:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 18:57:40 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 18:57:40 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 18:57:52 --> Config Class Initialized
INFO - 2018-06-11 18:57:52 --> Hooks Class Initialized
DEBUG - 2018-06-11 18:57:52 --> UTF-8 Support Enabled
INFO - 2018-06-11 18:57:52 --> Utf8 Class Initialized
INFO - 2018-06-11 18:57:52 --> URI Class Initialized
INFO - 2018-06-11 18:57:52 --> Router Class Initialized
INFO - 2018-06-11 18:57:52 --> Output Class Initialized
INFO - 2018-06-11 18:57:52 --> Security Class Initialized
DEBUG - 2018-06-11 18:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 18:57:52 --> CSRF cookie sent
INFO - 2018-06-11 18:57:52 --> Input Class Initialized
INFO - 2018-06-11 18:57:52 --> Language Class Initialized
INFO - 2018-06-11 18:57:52 --> Loader Class Initialized
INFO - 2018-06-11 18:57:52 --> Helper loaded: url_helper
INFO - 2018-06-11 18:57:52 --> Helper loaded: form_helper
INFO - 2018-06-11 18:57:52 --> Helper loaded: language_helper
DEBUG - 2018-06-11 18:57:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 18:57:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 18:57:52 --> User Agent Class Initialized
INFO - 2018-06-11 18:57:52 --> Controller Class Initialized
INFO - 2018-06-11 18:57:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 18:57:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 18:57:52 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 18:57:52 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 18:57:52 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
ERROR - 2018-06-11 18:57:52 --> Severity: Notice --> Undefined variable: decision_list E:\www\yacopoo\application\views\advisors.php 30
ERROR - 2018-06-11 18:57:52 --> Severity: Notice --> Undefined variable: profession_list E:\www\yacopoo\application\views\advisors.php 41
INFO - 2018-06-11 18:57:52 --> File loaded: E:\www\yacopoo\application\views\advisors.php
INFO - 2018-06-11 18:57:52 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 18:57:52 --> Final output sent to browser
DEBUG - 2018-06-11 18:57:52 --> Total execution time: 0.3237
INFO - 2018-06-11 18:58:30 --> Config Class Initialized
INFO - 2018-06-11 18:58:30 --> Hooks Class Initialized
DEBUG - 2018-06-11 18:58:30 --> UTF-8 Support Enabled
INFO - 2018-06-11 18:58:30 --> Utf8 Class Initialized
INFO - 2018-06-11 18:58:30 --> URI Class Initialized
INFO - 2018-06-11 18:58:30 --> Router Class Initialized
INFO - 2018-06-11 18:58:30 --> Output Class Initialized
INFO - 2018-06-11 18:58:30 --> Security Class Initialized
DEBUG - 2018-06-11 18:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 18:58:30 --> CSRF cookie sent
INFO - 2018-06-11 18:58:30 --> Input Class Initialized
INFO - 2018-06-11 18:58:30 --> Language Class Initialized
INFO - 2018-06-11 18:58:30 --> Loader Class Initialized
INFO - 2018-06-11 18:58:30 --> Helper loaded: url_helper
INFO - 2018-06-11 18:58:30 --> Helper loaded: form_helper
INFO - 2018-06-11 18:58:30 --> Helper loaded: language_helper
DEBUG - 2018-06-11 18:58:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 18:58:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 18:58:30 --> User Agent Class Initialized
INFO - 2018-06-11 18:58:30 --> Controller Class Initialized
INFO - 2018-06-11 18:58:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 18:58:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 18:58:30 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 18:58:30 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 18:58:30 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
ERROR - 2018-06-11 18:58:30 --> Severity: Notice --> Undefined variable: decision_list E:\www\yacopoo\application\views\advisors.php 31
ERROR - 2018-06-11 18:58:30 --> Severity: Notice --> Undefined variable: profession_list E:\www\yacopoo\application\views\advisors.php 42
INFO - 2018-06-11 18:58:30 --> File loaded: E:\www\yacopoo\application\views\advisors.php
INFO - 2018-06-11 18:58:30 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 18:58:30 --> Final output sent to browser
DEBUG - 2018-06-11 18:58:30 --> Total execution time: 0.2778
INFO - 2018-06-11 18:59:31 --> Config Class Initialized
INFO - 2018-06-11 18:59:31 --> Hooks Class Initialized
DEBUG - 2018-06-11 18:59:31 --> UTF-8 Support Enabled
INFO - 2018-06-11 18:59:31 --> Utf8 Class Initialized
INFO - 2018-06-11 18:59:31 --> URI Class Initialized
INFO - 2018-06-11 18:59:31 --> Router Class Initialized
INFO - 2018-06-11 18:59:31 --> Output Class Initialized
INFO - 2018-06-11 18:59:31 --> Security Class Initialized
DEBUG - 2018-06-11 18:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 18:59:31 --> CSRF cookie sent
INFO - 2018-06-11 18:59:31 --> Input Class Initialized
INFO - 2018-06-11 18:59:31 --> Language Class Initialized
INFO - 2018-06-11 18:59:31 --> Loader Class Initialized
INFO - 2018-06-11 18:59:31 --> Helper loaded: url_helper
INFO - 2018-06-11 18:59:31 --> Helper loaded: form_helper
INFO - 2018-06-11 18:59:31 --> Helper loaded: language_helper
DEBUG - 2018-06-11 18:59:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 18:59:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 18:59:31 --> User Agent Class Initialized
INFO - 2018-06-11 18:59:31 --> Controller Class Initialized
INFO - 2018-06-11 18:59:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 18:59:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 18:59:31 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 18:59:31 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 18:59:31 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 18:59:31 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-06-11 18:59:31 --> Severity: Notice --> Undefined variable: decision_list E:\www\yacopoo\application\views\advisors.php 32
ERROR - 2018-06-11 18:59:31 --> Severity: Notice --> Undefined variable: profession_list E:\www\yacopoo\application\views\advisors.php 43
INFO - 2018-06-11 18:59:31 --> File loaded: E:\www\yacopoo\application\views\advisors.php
INFO - 2018-06-11 18:59:31 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 18:59:31 --> Final output sent to browser
DEBUG - 2018-06-11 18:59:31 --> Total execution time: 0.2905
INFO - 2018-06-11 18:59:53 --> Config Class Initialized
INFO - 2018-06-11 18:59:53 --> Hooks Class Initialized
DEBUG - 2018-06-11 18:59:53 --> UTF-8 Support Enabled
INFO - 2018-06-11 18:59:53 --> Utf8 Class Initialized
INFO - 2018-06-11 18:59:53 --> URI Class Initialized
INFO - 2018-06-11 18:59:53 --> Router Class Initialized
INFO - 2018-06-11 18:59:53 --> Output Class Initialized
INFO - 2018-06-11 18:59:53 --> Security Class Initialized
DEBUG - 2018-06-11 18:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 18:59:53 --> CSRF cookie sent
INFO - 2018-06-11 18:59:53 --> Input Class Initialized
INFO - 2018-06-11 18:59:53 --> Language Class Initialized
INFO - 2018-06-11 18:59:53 --> Loader Class Initialized
INFO - 2018-06-11 18:59:53 --> Helper loaded: url_helper
INFO - 2018-06-11 18:59:53 --> Helper loaded: form_helper
INFO - 2018-06-11 18:59:53 --> Helper loaded: language_helper
DEBUG - 2018-06-11 18:59:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 18:59:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 18:59:53 --> User Agent Class Initialized
INFO - 2018-06-11 18:59:53 --> Controller Class Initialized
INFO - 2018-06-11 18:59:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 18:59:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 18:59:53 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 18:59:53 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 18:59:53 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 18:59:53 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 18:59:53 --> File loaded: E:\www\yacopoo\application\views\advisors.php
INFO - 2018-06-11 18:59:53 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 18:59:53 --> Final output sent to browser
DEBUG - 2018-06-11 18:59:53 --> Total execution time: 0.2715
INFO - 2018-06-11 19:10:45 --> Config Class Initialized
INFO - 2018-06-11 19:10:45 --> Hooks Class Initialized
DEBUG - 2018-06-11 19:10:45 --> UTF-8 Support Enabled
INFO - 2018-06-11 19:10:45 --> Utf8 Class Initialized
INFO - 2018-06-11 19:10:45 --> URI Class Initialized
INFO - 2018-06-11 19:10:45 --> Router Class Initialized
INFO - 2018-06-11 19:10:45 --> Output Class Initialized
INFO - 2018-06-11 19:10:45 --> Security Class Initialized
DEBUG - 2018-06-11 19:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 19:10:45 --> CSRF cookie sent
INFO - 2018-06-11 19:10:45 --> Input Class Initialized
INFO - 2018-06-11 19:10:45 --> Language Class Initialized
INFO - 2018-06-11 19:10:45 --> Loader Class Initialized
INFO - 2018-06-11 19:10:45 --> Helper loaded: url_helper
INFO - 2018-06-11 19:10:45 --> Helper loaded: form_helper
INFO - 2018-06-11 19:10:45 --> Helper loaded: language_helper
DEBUG - 2018-06-11 19:10:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 19:10:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 19:10:45 --> User Agent Class Initialized
INFO - 2018-06-11 19:10:45 --> Controller Class Initialized
INFO - 2018-06-11 19:10:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 19:10:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 19:10:45 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 19:10:45 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 19:10:45 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 19:10:45 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 19:10:45 --> File loaded: E:\www\yacopoo\application\views\advisors.php
INFO - 2018-06-11 19:10:45 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 19:10:45 --> Final output sent to browser
DEBUG - 2018-06-11 19:10:45 --> Total execution time: 0.2800
INFO - 2018-06-11 19:11:05 --> Config Class Initialized
INFO - 2018-06-11 19:11:05 --> Hooks Class Initialized
DEBUG - 2018-06-11 19:11:05 --> UTF-8 Support Enabled
INFO - 2018-06-11 19:11:05 --> Utf8 Class Initialized
INFO - 2018-06-11 19:11:05 --> URI Class Initialized
INFO - 2018-06-11 19:11:05 --> Router Class Initialized
INFO - 2018-06-11 19:11:05 --> Output Class Initialized
INFO - 2018-06-11 19:11:05 --> Security Class Initialized
DEBUG - 2018-06-11 19:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 19:11:05 --> CSRF cookie sent
INFO - 2018-06-11 19:11:05 --> Input Class Initialized
INFO - 2018-06-11 19:11:05 --> Language Class Initialized
INFO - 2018-06-11 19:11:05 --> Loader Class Initialized
INFO - 2018-06-11 19:11:05 --> Helper loaded: url_helper
INFO - 2018-06-11 19:11:05 --> Helper loaded: form_helper
INFO - 2018-06-11 19:11:05 --> Helper loaded: language_helper
DEBUG - 2018-06-11 19:11:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 19:11:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 19:11:05 --> User Agent Class Initialized
INFO - 2018-06-11 19:11:05 --> Controller Class Initialized
INFO - 2018-06-11 19:11:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 19:11:05 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-11 19:11:06 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-06-11 19:11:06 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 19:11:06 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 19:11:06 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 19:11:06 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-06-11 19:11:06 --> Could not find the language line "req_email"
INFO - 2018-06-11 19:11:06 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-06-11 19:11:06 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 19:11:06 --> Final output sent to browser
DEBUG - 2018-06-11 19:11:06 --> Total execution time: 0.8172
INFO - 2018-06-11 19:11:17 --> Config Class Initialized
INFO - 2018-06-11 19:11:17 --> Hooks Class Initialized
DEBUG - 2018-06-11 19:11:17 --> UTF-8 Support Enabled
INFO - 2018-06-11 19:11:17 --> Utf8 Class Initialized
INFO - 2018-06-11 19:11:17 --> URI Class Initialized
INFO - 2018-06-11 19:11:17 --> Router Class Initialized
INFO - 2018-06-11 19:11:17 --> Output Class Initialized
INFO - 2018-06-11 19:11:17 --> Security Class Initialized
DEBUG - 2018-06-11 19:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 19:11:17 --> CSRF cookie sent
INFO - 2018-06-11 19:11:17 --> Input Class Initialized
INFO - 2018-06-11 19:11:17 --> Language Class Initialized
INFO - 2018-06-11 19:11:17 --> Loader Class Initialized
INFO - 2018-06-11 19:11:17 --> Helper loaded: url_helper
INFO - 2018-06-11 19:11:17 --> Helper loaded: form_helper
INFO - 2018-06-11 19:11:17 --> Helper loaded: language_helper
DEBUG - 2018-06-11 19:11:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 19:11:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 19:11:17 --> User Agent Class Initialized
INFO - 2018-06-11 19:11:17 --> Controller Class Initialized
INFO - 2018-06-11 19:11:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 19:11:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 19:11:17 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 19:11:17 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 19:11:17 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 19:11:17 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 19:11:17 --> File loaded: E:\www\yacopoo\application\views\advisors.php
INFO - 2018-06-11 19:11:17 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 19:11:17 --> Final output sent to browser
DEBUG - 2018-06-11 19:11:17 --> Total execution time: 0.2957
INFO - 2018-06-11 19:11:40 --> Config Class Initialized
INFO - 2018-06-11 19:11:40 --> Hooks Class Initialized
DEBUG - 2018-06-11 19:11:40 --> UTF-8 Support Enabled
INFO - 2018-06-11 19:11:40 --> Utf8 Class Initialized
INFO - 2018-06-11 19:11:40 --> URI Class Initialized
INFO - 2018-06-11 19:11:40 --> Router Class Initialized
INFO - 2018-06-11 19:11:40 --> Output Class Initialized
INFO - 2018-06-11 19:11:40 --> Security Class Initialized
DEBUG - 2018-06-11 19:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 19:11:40 --> CSRF cookie sent
INFO - 2018-06-11 19:11:40 --> Input Class Initialized
INFO - 2018-06-11 19:11:40 --> Language Class Initialized
INFO - 2018-06-11 19:11:40 --> Loader Class Initialized
INFO - 2018-06-11 19:11:40 --> Helper loaded: url_helper
INFO - 2018-06-11 19:11:40 --> Helper loaded: form_helper
INFO - 2018-06-11 19:11:40 --> Helper loaded: language_helper
DEBUG - 2018-06-11 19:11:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 19:11:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 19:11:40 --> User Agent Class Initialized
INFO - 2018-06-11 19:11:40 --> Controller Class Initialized
INFO - 2018-06-11 19:11:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 19:11:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 19:11:40 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 19:11:40 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 19:11:40 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 19:11:40 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 19:11:40 --> File loaded: E:\www\yacopoo\application\views\advisors.php
INFO - 2018-06-11 19:11:40 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 19:11:40 --> Final output sent to browser
DEBUG - 2018-06-11 19:11:40 --> Total execution time: 0.2911
INFO - 2018-06-11 19:11:47 --> Config Class Initialized
INFO - 2018-06-11 19:11:47 --> Hooks Class Initialized
DEBUG - 2018-06-11 19:11:47 --> UTF-8 Support Enabled
INFO - 2018-06-11 19:11:47 --> Utf8 Class Initialized
INFO - 2018-06-11 19:11:47 --> URI Class Initialized
INFO - 2018-06-11 19:11:47 --> Router Class Initialized
INFO - 2018-06-11 19:11:47 --> Output Class Initialized
INFO - 2018-06-11 19:11:47 --> Security Class Initialized
DEBUG - 2018-06-11 19:11:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 19:11:47 --> CSRF cookie sent
INFO - 2018-06-11 19:11:47 --> Input Class Initialized
INFO - 2018-06-11 19:11:47 --> Language Class Initialized
INFO - 2018-06-11 19:11:47 --> Loader Class Initialized
INFO - 2018-06-11 19:11:47 --> Helper loaded: url_helper
INFO - 2018-06-11 19:11:47 --> Helper loaded: form_helper
INFO - 2018-06-11 19:11:47 --> Helper loaded: language_helper
DEBUG - 2018-06-11 19:11:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 19:11:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 19:11:47 --> User Agent Class Initialized
INFO - 2018-06-11 19:11:47 --> Controller Class Initialized
INFO - 2018-06-11 19:11:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 19:11:47 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-11 19:11:47 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-06-11 19:11:47 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 19:11:47 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 19:11:47 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 19:11:47 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-06-11 19:11:47 --> Could not find the language line "req_email"
INFO - 2018-06-11 19:11:47 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-06-11 19:11:47 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 19:11:47 --> Final output sent to browser
DEBUG - 2018-06-11 19:11:47 --> Total execution time: 0.3415
INFO - 2018-06-11 19:11:52 --> Config Class Initialized
INFO - 2018-06-11 19:11:52 --> Hooks Class Initialized
DEBUG - 2018-06-11 19:11:52 --> UTF-8 Support Enabled
INFO - 2018-06-11 19:11:52 --> Utf8 Class Initialized
INFO - 2018-06-11 19:11:52 --> URI Class Initialized
INFO - 2018-06-11 19:11:52 --> Router Class Initialized
INFO - 2018-06-11 19:11:52 --> Output Class Initialized
INFO - 2018-06-11 19:11:52 --> Security Class Initialized
DEBUG - 2018-06-11 19:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 19:11:52 --> CSRF cookie sent
INFO - 2018-06-11 19:11:52 --> Input Class Initialized
INFO - 2018-06-11 19:11:52 --> Language Class Initialized
INFO - 2018-06-11 19:11:52 --> Loader Class Initialized
INFO - 2018-06-11 19:11:52 --> Helper loaded: url_helper
INFO - 2018-06-11 19:11:52 --> Helper loaded: form_helper
INFO - 2018-06-11 19:11:52 --> Helper loaded: language_helper
DEBUG - 2018-06-11 19:11:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 19:11:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 19:11:52 --> User Agent Class Initialized
INFO - 2018-06-11 19:11:52 --> Controller Class Initialized
INFO - 2018-06-11 19:11:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 19:11:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 19:11:52 --> Pixel_Model class loaded
INFO - 2018-06-11 19:11:52 --> Database Driver Class Initialized
INFO - 2018-06-11 19:11:52 --> Model "RegistrationModel" initialized
DEBUG - 2018-06-11 19:11:52 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-06-11 19:11:52 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 19:11:52 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 19:11:52 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 19:11:52 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-06-11 19:11:52 --> Could not find the language line "req_email"
INFO - 2018-06-11 19:11:52 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-06-11 19:11:52 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 19:11:52 --> Final output sent to browser
DEBUG - 2018-06-11 19:11:52 --> Total execution time: 0.4135
INFO - 2018-06-11 19:15:16 --> Config Class Initialized
INFO - 2018-06-11 19:15:16 --> Hooks Class Initialized
DEBUG - 2018-06-11 19:15:16 --> UTF-8 Support Enabled
INFO - 2018-06-11 19:15:16 --> Utf8 Class Initialized
INFO - 2018-06-11 19:15:16 --> URI Class Initialized
DEBUG - 2018-06-11 19:15:16 --> No URI present. Default controller set.
INFO - 2018-06-11 19:15:16 --> Router Class Initialized
INFO - 2018-06-11 19:15:16 --> Output Class Initialized
INFO - 2018-06-11 19:15:16 --> Security Class Initialized
DEBUG - 2018-06-11 19:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 19:15:16 --> CSRF cookie sent
INFO - 2018-06-11 19:15:16 --> Input Class Initialized
INFO - 2018-06-11 19:15:16 --> Language Class Initialized
INFO - 2018-06-11 19:15:16 --> Loader Class Initialized
INFO - 2018-06-11 19:15:16 --> Helper loaded: url_helper
INFO - 2018-06-11 19:15:16 --> Helper loaded: form_helper
INFO - 2018-06-11 19:15:16 --> Helper loaded: language_helper
DEBUG - 2018-06-11 19:15:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 19:15:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 19:15:16 --> User Agent Class Initialized
INFO - 2018-06-11 19:15:16 --> Controller Class Initialized
INFO - 2018-06-11 19:15:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 19:15:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 19:15:16 --> Pixel_Model class loaded
INFO - 2018-06-11 19:15:16 --> Database Driver Class Initialized
INFO - 2018-06-11 19:15:16 --> Model "QuestionsModel" initialized
INFO - 2018-06-11 19:15:16 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 19:15:16 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 19:15:16 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-06-11 19:15:16 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 19:15:16 --> Final output sent to browser
DEBUG - 2018-06-11 19:15:16 --> Total execution time: 0.3331
INFO - 2018-06-11 19:15:40 --> Config Class Initialized
INFO - 2018-06-11 19:15:40 --> Hooks Class Initialized
DEBUG - 2018-06-11 19:15:40 --> UTF-8 Support Enabled
INFO - 2018-06-11 19:15:40 --> Utf8 Class Initialized
INFO - 2018-06-11 19:15:41 --> URI Class Initialized
INFO - 2018-06-11 19:15:41 --> Router Class Initialized
INFO - 2018-06-11 19:15:41 --> Output Class Initialized
INFO - 2018-06-11 19:15:41 --> Security Class Initialized
DEBUG - 2018-06-11 19:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 19:15:41 --> CSRF cookie sent
INFO - 2018-06-11 19:15:41 --> Input Class Initialized
INFO - 2018-06-11 19:15:41 --> Language Class Initialized
INFO - 2018-06-11 19:15:41 --> Loader Class Initialized
INFO - 2018-06-11 19:15:41 --> Helper loaded: url_helper
INFO - 2018-06-11 19:15:41 --> Helper loaded: form_helper
INFO - 2018-06-11 19:15:41 --> Helper loaded: language_helper
DEBUG - 2018-06-11 19:15:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 19:15:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 19:15:41 --> User Agent Class Initialized
INFO - 2018-06-11 19:15:41 --> Controller Class Initialized
INFO - 2018-06-11 19:15:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 19:15:41 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-11 19:15:41 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-06-11 19:15:41 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 19:15:41 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 19:15:41 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 19:15:41 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-06-11 19:15:41 --> Could not find the language line "req_email"
INFO - 2018-06-11 19:15:41 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-06-11 19:15:41 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 19:15:41 --> Final output sent to browser
DEBUG - 2018-06-11 19:15:41 --> Total execution time: 0.3316
INFO - 2018-06-11 19:15:48 --> Config Class Initialized
INFO - 2018-06-11 19:15:48 --> Hooks Class Initialized
DEBUG - 2018-06-11 19:15:48 --> UTF-8 Support Enabled
INFO - 2018-06-11 19:15:48 --> Utf8 Class Initialized
INFO - 2018-06-11 19:15:48 --> URI Class Initialized
INFO - 2018-06-11 19:15:48 --> Router Class Initialized
INFO - 2018-06-11 19:15:48 --> Output Class Initialized
INFO - 2018-06-11 19:15:48 --> Security Class Initialized
DEBUG - 2018-06-11 19:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 19:15:48 --> CSRF cookie sent
INFO - 2018-06-11 19:15:48 --> Input Class Initialized
INFO - 2018-06-11 19:15:48 --> Language Class Initialized
ERROR - 2018-06-11 19:15:48 --> 404 Page Not Found: Assets/css
INFO - 2018-06-11 19:19:38 --> Config Class Initialized
INFO - 2018-06-11 19:19:38 --> Hooks Class Initialized
DEBUG - 2018-06-11 19:19:38 --> UTF-8 Support Enabled
INFO - 2018-06-11 19:19:38 --> Utf8 Class Initialized
INFO - 2018-06-11 19:19:38 --> URI Class Initialized
INFO - 2018-06-11 19:19:38 --> Router Class Initialized
INFO - 2018-06-11 19:19:38 --> Output Class Initialized
INFO - 2018-06-11 19:19:38 --> Security Class Initialized
DEBUG - 2018-06-11 19:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 19:19:38 --> CSRF cookie sent
INFO - 2018-06-11 19:19:38 --> Input Class Initialized
INFO - 2018-06-11 19:19:38 --> Language Class Initialized
INFO - 2018-06-11 19:19:38 --> Loader Class Initialized
INFO - 2018-06-11 19:19:38 --> Helper loaded: url_helper
INFO - 2018-06-11 19:19:38 --> Helper loaded: form_helper
INFO - 2018-06-11 19:19:38 --> Helper loaded: language_helper
DEBUG - 2018-06-11 19:19:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 19:19:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 19:19:38 --> User Agent Class Initialized
INFO - 2018-06-11 19:19:38 --> Controller Class Initialized
INFO - 2018-06-11 19:19:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 19:19:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 19:19:38 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 19:19:38 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 19:19:38 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 19:19:38 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-06-11 19:19:38 --> Severity: Notice --> Undefined variable: next_page E:\www\yacopoo\application\views\advisors.php 15
INFO - 2018-06-11 19:19:38 --> File loaded: E:\www\yacopoo\application\views\advisors.php
INFO - 2018-06-11 19:19:38 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 19:19:38 --> Final output sent to browser
DEBUG - 2018-06-11 19:19:38 --> Total execution time: 0.3014
INFO - 2018-06-11 19:19:39 --> Config Class Initialized
INFO - 2018-06-11 19:19:39 --> Hooks Class Initialized
DEBUG - 2018-06-11 19:19:39 --> UTF-8 Support Enabled
INFO - 2018-06-11 19:19:39 --> Utf8 Class Initialized
INFO - 2018-06-11 19:19:39 --> URI Class Initialized
INFO - 2018-06-11 19:19:39 --> Router Class Initialized
INFO - 2018-06-11 19:19:39 --> Output Class Initialized
INFO - 2018-06-11 19:19:39 --> Security Class Initialized
DEBUG - 2018-06-11 19:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 19:19:39 --> CSRF cookie sent
INFO - 2018-06-11 19:19:39 --> Input Class Initialized
INFO - 2018-06-11 19:19:39 --> Language Class Initialized
ERROR - 2018-06-11 19:19:39 --> 404 Page Not Found: Assets/css
INFO - 2018-06-11 19:20:11 --> Config Class Initialized
INFO - 2018-06-11 19:20:11 --> Hooks Class Initialized
DEBUG - 2018-06-11 19:20:11 --> UTF-8 Support Enabled
INFO - 2018-06-11 19:20:11 --> Utf8 Class Initialized
INFO - 2018-06-11 19:20:11 --> URI Class Initialized
INFO - 2018-06-11 19:20:11 --> Router Class Initialized
INFO - 2018-06-11 19:20:11 --> Output Class Initialized
INFO - 2018-06-11 19:20:11 --> Security Class Initialized
DEBUG - 2018-06-11 19:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 19:20:11 --> CSRF cookie sent
INFO - 2018-06-11 19:20:11 --> Input Class Initialized
INFO - 2018-06-11 19:20:11 --> Language Class Initialized
INFO - 2018-06-11 19:20:11 --> Loader Class Initialized
INFO - 2018-06-11 19:20:11 --> Helper loaded: url_helper
INFO - 2018-06-11 19:20:11 --> Helper loaded: form_helper
INFO - 2018-06-11 19:20:11 --> Helper loaded: language_helper
DEBUG - 2018-06-11 19:20:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 19:20:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 19:20:11 --> User Agent Class Initialized
INFO - 2018-06-11 19:20:11 --> Controller Class Initialized
INFO - 2018-06-11 19:20:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 19:20:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 19:20:11 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 19:20:11 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 19:20:11 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 19:20:11 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 19:20:11 --> File loaded: E:\www\yacopoo\application\views\advisors.php
INFO - 2018-06-11 19:20:11 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 19:20:11 --> Final output sent to browser
DEBUG - 2018-06-11 19:20:11 --> Total execution time: 0.3544
INFO - 2018-06-11 19:20:11 --> Config Class Initialized
INFO - 2018-06-11 19:20:11 --> Hooks Class Initialized
DEBUG - 2018-06-11 19:20:11 --> UTF-8 Support Enabled
INFO - 2018-06-11 19:20:11 --> Utf8 Class Initialized
INFO - 2018-06-11 19:20:12 --> URI Class Initialized
INFO - 2018-06-11 19:20:12 --> Router Class Initialized
INFO - 2018-06-11 19:20:12 --> Output Class Initialized
INFO - 2018-06-11 19:20:12 --> Security Class Initialized
DEBUG - 2018-06-11 19:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 19:20:12 --> CSRF cookie sent
INFO - 2018-06-11 19:20:12 --> Input Class Initialized
INFO - 2018-06-11 19:20:12 --> Language Class Initialized
ERROR - 2018-06-11 19:20:12 --> 404 Page Not Found: Assets/css
INFO - 2018-06-11 19:20:22 --> Config Class Initialized
INFO - 2018-06-11 19:20:22 --> Hooks Class Initialized
DEBUG - 2018-06-11 19:20:22 --> UTF-8 Support Enabled
INFO - 2018-06-11 19:20:22 --> Utf8 Class Initialized
INFO - 2018-06-11 19:20:22 --> URI Class Initialized
INFO - 2018-06-11 19:20:22 --> Router Class Initialized
INFO - 2018-06-11 19:20:22 --> Output Class Initialized
INFO - 2018-06-11 19:20:22 --> Security Class Initialized
DEBUG - 2018-06-11 19:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 19:20:22 --> CSRF cookie sent
INFO - 2018-06-11 19:20:22 --> Input Class Initialized
INFO - 2018-06-11 19:20:22 --> Language Class Initialized
INFO - 2018-06-11 19:20:22 --> Loader Class Initialized
INFO - 2018-06-11 19:20:22 --> Helper loaded: url_helper
INFO - 2018-06-11 19:20:22 --> Helper loaded: form_helper
INFO - 2018-06-11 19:20:22 --> Helper loaded: language_helper
DEBUG - 2018-06-11 19:20:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 19:20:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 19:20:22 --> User Agent Class Initialized
INFO - 2018-06-11 19:20:22 --> Controller Class Initialized
INFO - 2018-06-11 19:20:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 19:20:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 19:20:23 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 19:20:23 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 19:20:23 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 19:20:23 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 19:20:23 --> File loaded: E:\www\yacopoo\application\views\advisors.php
INFO - 2018-06-11 19:20:23 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 19:20:23 --> Final output sent to browser
DEBUG - 2018-06-11 19:20:23 --> Total execution time: 0.3283
INFO - 2018-06-11 19:20:23 --> Config Class Initialized
INFO - 2018-06-11 19:20:23 --> Hooks Class Initialized
DEBUG - 2018-06-11 19:20:23 --> UTF-8 Support Enabled
INFO - 2018-06-11 19:20:23 --> Utf8 Class Initialized
INFO - 2018-06-11 19:20:23 --> URI Class Initialized
INFO - 2018-06-11 19:20:23 --> Router Class Initialized
INFO - 2018-06-11 19:20:23 --> Output Class Initialized
INFO - 2018-06-11 19:20:23 --> Security Class Initialized
DEBUG - 2018-06-11 19:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 19:20:23 --> CSRF cookie sent
INFO - 2018-06-11 19:20:23 --> Input Class Initialized
INFO - 2018-06-11 19:20:23 --> Language Class Initialized
ERROR - 2018-06-11 19:20:23 --> 404 Page Not Found: Assets/css
INFO - 2018-06-11 19:21:18 --> Config Class Initialized
INFO - 2018-06-11 19:21:18 --> Hooks Class Initialized
DEBUG - 2018-06-11 19:21:18 --> UTF-8 Support Enabled
INFO - 2018-06-11 19:21:18 --> Utf8 Class Initialized
INFO - 2018-06-11 19:21:18 --> URI Class Initialized
INFO - 2018-06-11 19:21:18 --> Router Class Initialized
INFO - 2018-06-11 19:21:18 --> Output Class Initialized
INFO - 2018-06-11 19:21:18 --> Security Class Initialized
DEBUG - 2018-06-11 19:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 19:21:18 --> CSRF cookie sent
INFO - 2018-06-11 19:21:18 --> Input Class Initialized
INFO - 2018-06-11 19:21:18 --> Language Class Initialized
INFO - 2018-06-11 19:21:18 --> Loader Class Initialized
INFO - 2018-06-11 19:21:18 --> Helper loaded: url_helper
INFO - 2018-06-11 19:21:18 --> Helper loaded: form_helper
INFO - 2018-06-11 19:21:18 --> Helper loaded: language_helper
DEBUG - 2018-06-11 19:21:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 19:21:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 19:21:18 --> User Agent Class Initialized
INFO - 2018-06-11 19:21:18 --> Controller Class Initialized
INFO - 2018-06-11 19:21:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 19:21:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 19:21:18 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 19:21:18 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 19:21:18 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 19:21:18 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 19:21:18 --> File loaded: E:\www\yacopoo\application\views\advisors.php
INFO - 2018-06-11 19:21:18 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 19:21:18 --> Final output sent to browser
DEBUG - 2018-06-11 19:21:18 --> Total execution time: 0.3015
INFO - 2018-06-11 19:21:19 --> Config Class Initialized
INFO - 2018-06-11 19:21:19 --> Hooks Class Initialized
DEBUG - 2018-06-11 19:21:19 --> UTF-8 Support Enabled
INFO - 2018-06-11 19:21:19 --> Utf8 Class Initialized
INFO - 2018-06-11 19:21:19 --> URI Class Initialized
INFO - 2018-06-11 19:21:19 --> Router Class Initialized
INFO - 2018-06-11 19:21:19 --> Output Class Initialized
INFO - 2018-06-11 19:21:19 --> Security Class Initialized
DEBUG - 2018-06-11 19:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 19:21:19 --> CSRF cookie sent
INFO - 2018-06-11 19:21:19 --> Input Class Initialized
INFO - 2018-06-11 19:21:19 --> Language Class Initialized
ERROR - 2018-06-11 19:21:19 --> 404 Page Not Found: Assets/css
INFO - 2018-06-11 19:21:50 --> Config Class Initialized
INFO - 2018-06-11 19:21:50 --> Hooks Class Initialized
DEBUG - 2018-06-11 19:21:50 --> UTF-8 Support Enabled
INFO - 2018-06-11 19:21:50 --> Utf8 Class Initialized
INFO - 2018-06-11 19:21:50 --> URI Class Initialized
INFO - 2018-06-11 19:21:50 --> Router Class Initialized
INFO - 2018-06-11 19:21:50 --> Output Class Initialized
INFO - 2018-06-11 19:21:50 --> Security Class Initialized
DEBUG - 2018-06-11 19:21:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 19:21:50 --> CSRF cookie sent
INFO - 2018-06-11 19:21:50 --> Input Class Initialized
INFO - 2018-06-11 19:21:50 --> Language Class Initialized
INFO - 2018-06-11 19:21:50 --> Loader Class Initialized
INFO - 2018-06-11 19:21:50 --> Helper loaded: url_helper
INFO - 2018-06-11 19:21:50 --> Helper loaded: form_helper
INFO - 2018-06-11 19:21:50 --> Helper loaded: language_helper
DEBUG - 2018-06-11 19:21:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 19:21:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 19:21:50 --> User Agent Class Initialized
INFO - 2018-06-11 19:21:50 --> Controller Class Initialized
INFO - 2018-06-11 19:21:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 19:21:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 19:21:50 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 19:21:50 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 19:21:50 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 19:21:50 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 19:21:51 --> File loaded: E:\www\yacopoo\application\views\advisors.php
INFO - 2018-06-11 19:21:51 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 19:21:51 --> Final output sent to browser
DEBUG - 2018-06-11 19:21:51 --> Total execution time: 0.3156
INFO - 2018-06-11 19:21:51 --> Config Class Initialized
INFO - 2018-06-11 19:21:51 --> Hooks Class Initialized
DEBUG - 2018-06-11 19:21:51 --> UTF-8 Support Enabled
INFO - 2018-06-11 19:21:51 --> Utf8 Class Initialized
INFO - 2018-06-11 19:21:51 --> URI Class Initialized
INFO - 2018-06-11 19:21:51 --> Router Class Initialized
INFO - 2018-06-11 19:21:51 --> Output Class Initialized
INFO - 2018-06-11 19:21:51 --> Security Class Initialized
DEBUG - 2018-06-11 19:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 19:21:51 --> CSRF cookie sent
INFO - 2018-06-11 19:21:51 --> Input Class Initialized
INFO - 2018-06-11 19:21:51 --> Language Class Initialized
ERROR - 2018-06-11 19:21:51 --> 404 Page Not Found: Assets/css
INFO - 2018-06-11 19:22:33 --> Config Class Initialized
INFO - 2018-06-11 19:22:33 --> Hooks Class Initialized
DEBUG - 2018-06-11 19:22:33 --> UTF-8 Support Enabled
INFO - 2018-06-11 19:22:33 --> Utf8 Class Initialized
INFO - 2018-06-11 19:22:33 --> URI Class Initialized
INFO - 2018-06-11 19:22:33 --> Router Class Initialized
INFO - 2018-06-11 19:22:34 --> Output Class Initialized
INFO - 2018-06-11 19:22:34 --> Security Class Initialized
DEBUG - 2018-06-11 19:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 19:22:34 --> CSRF cookie sent
INFO - 2018-06-11 19:22:34 --> Input Class Initialized
INFO - 2018-06-11 19:22:34 --> Language Class Initialized
INFO - 2018-06-11 19:22:34 --> Loader Class Initialized
INFO - 2018-06-11 19:22:34 --> Helper loaded: url_helper
INFO - 2018-06-11 19:22:34 --> Helper loaded: form_helper
INFO - 2018-06-11 19:22:34 --> Helper loaded: language_helper
DEBUG - 2018-06-11 19:22:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 19:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 19:22:34 --> User Agent Class Initialized
INFO - 2018-06-11 19:22:34 --> Controller Class Initialized
INFO - 2018-06-11 19:22:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 19:22:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 19:22:34 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 19:22:34 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 19:22:34 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 19:22:34 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 19:22:34 --> File loaded: E:\www\yacopoo\application\views\advisors.php
INFO - 2018-06-11 19:22:34 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 19:22:34 --> Final output sent to browser
DEBUG - 2018-06-11 19:22:34 --> Total execution time: 0.3237
INFO - 2018-06-11 19:22:34 --> Config Class Initialized
INFO - 2018-06-11 19:22:34 --> Hooks Class Initialized
DEBUG - 2018-06-11 19:22:34 --> UTF-8 Support Enabled
INFO - 2018-06-11 19:22:34 --> Utf8 Class Initialized
INFO - 2018-06-11 19:22:34 --> URI Class Initialized
INFO - 2018-06-11 19:22:34 --> Router Class Initialized
INFO - 2018-06-11 19:22:34 --> Output Class Initialized
INFO - 2018-06-11 19:22:34 --> Security Class Initialized
DEBUG - 2018-06-11 19:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 19:22:34 --> CSRF cookie sent
INFO - 2018-06-11 19:22:34 --> Input Class Initialized
INFO - 2018-06-11 19:22:34 --> Language Class Initialized
ERROR - 2018-06-11 19:22:34 --> 404 Page Not Found: Assets/css
INFO - 2018-06-11 19:24:07 --> Config Class Initialized
INFO - 2018-06-11 19:24:07 --> Hooks Class Initialized
DEBUG - 2018-06-11 19:24:07 --> UTF-8 Support Enabled
INFO - 2018-06-11 19:24:07 --> Utf8 Class Initialized
INFO - 2018-06-11 19:24:07 --> URI Class Initialized
INFO - 2018-06-11 19:24:07 --> Router Class Initialized
INFO - 2018-06-11 19:24:07 --> Output Class Initialized
INFO - 2018-06-11 19:24:07 --> Security Class Initialized
DEBUG - 2018-06-11 19:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 19:24:07 --> CSRF cookie sent
INFO - 2018-06-11 19:24:07 --> Input Class Initialized
INFO - 2018-06-11 19:24:07 --> Language Class Initialized
INFO - 2018-06-11 19:24:07 --> Loader Class Initialized
INFO - 2018-06-11 19:24:07 --> Helper loaded: url_helper
INFO - 2018-06-11 19:24:07 --> Helper loaded: form_helper
INFO - 2018-06-11 19:24:07 --> Helper loaded: language_helper
DEBUG - 2018-06-11 19:24:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 19:24:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 19:24:07 --> User Agent Class Initialized
INFO - 2018-06-11 19:24:07 --> Controller Class Initialized
INFO - 2018-06-11 19:24:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 19:24:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 19:24:07 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 19:24:07 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 19:24:07 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 19:24:07 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 19:24:07 --> File loaded: E:\www\yacopoo\application\views\advisors.php
INFO - 2018-06-11 19:24:07 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 19:24:07 --> Final output sent to browser
DEBUG - 2018-06-11 19:24:07 --> Total execution time: 0.3228
INFO - 2018-06-11 19:24:07 --> Config Class Initialized
INFO - 2018-06-11 19:24:07 --> Hooks Class Initialized
DEBUG - 2018-06-11 19:24:07 --> UTF-8 Support Enabled
INFO - 2018-06-11 19:24:07 --> Utf8 Class Initialized
INFO - 2018-06-11 19:24:07 --> URI Class Initialized
INFO - 2018-06-11 19:24:07 --> Router Class Initialized
INFO - 2018-06-11 19:24:07 --> Output Class Initialized
INFO - 2018-06-11 19:24:07 --> Security Class Initialized
DEBUG - 2018-06-11 19:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 19:24:07 --> CSRF cookie sent
INFO - 2018-06-11 19:24:07 --> Input Class Initialized
INFO - 2018-06-11 19:24:07 --> Language Class Initialized
ERROR - 2018-06-11 19:24:07 --> 404 Page Not Found: Assets/css
INFO - 2018-06-11 20:01:38 --> Config Class Initialized
INFO - 2018-06-11 20:01:38 --> Hooks Class Initialized
DEBUG - 2018-06-11 20:01:38 --> UTF-8 Support Enabled
INFO - 2018-06-11 20:01:38 --> Utf8 Class Initialized
INFO - 2018-06-11 20:01:38 --> URI Class Initialized
INFO - 2018-06-11 20:01:38 --> Router Class Initialized
INFO - 2018-06-11 20:01:38 --> Output Class Initialized
INFO - 2018-06-11 20:01:38 --> Security Class Initialized
DEBUG - 2018-06-11 20:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 20:01:38 --> CSRF cookie sent
INFO - 2018-06-11 20:01:38 --> Input Class Initialized
INFO - 2018-06-11 20:01:38 --> Language Class Initialized
INFO - 2018-06-11 20:01:38 --> Loader Class Initialized
INFO - 2018-06-11 20:01:38 --> Helper loaded: url_helper
INFO - 2018-06-11 20:01:38 --> Helper loaded: form_helper
INFO - 2018-06-11 20:01:38 --> Helper loaded: language_helper
DEBUG - 2018-06-11 20:01:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 20:01:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 20:01:38 --> User Agent Class Initialized
INFO - 2018-06-11 20:01:38 --> Controller Class Initialized
INFO - 2018-06-11 20:01:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 20:01:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 20:01:38 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 20:01:38 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 20:01:38 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 20:01:38 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 20:01:38 --> File loaded: E:\www\yacopoo\application\views\advisors.php
INFO - 2018-06-11 20:01:38 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 20:01:38 --> Final output sent to browser
DEBUG - 2018-06-11 20:01:38 --> Total execution time: 0.3155
INFO - 2018-06-11 20:01:38 --> Config Class Initialized
INFO - 2018-06-11 20:01:38 --> Hooks Class Initialized
DEBUG - 2018-06-11 20:01:38 --> UTF-8 Support Enabled
INFO - 2018-06-11 20:01:38 --> Utf8 Class Initialized
INFO - 2018-06-11 20:01:39 --> URI Class Initialized
INFO - 2018-06-11 20:01:39 --> Router Class Initialized
INFO - 2018-06-11 20:01:39 --> Output Class Initialized
INFO - 2018-06-11 20:01:39 --> Security Class Initialized
DEBUG - 2018-06-11 20:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 20:01:39 --> CSRF cookie sent
INFO - 2018-06-11 20:01:39 --> Input Class Initialized
INFO - 2018-06-11 20:01:39 --> Language Class Initialized
ERROR - 2018-06-11 20:01:39 --> 404 Page Not Found: Assets/css
INFO - 2018-06-11 20:02:42 --> Config Class Initialized
INFO - 2018-06-11 20:02:42 --> Hooks Class Initialized
DEBUG - 2018-06-11 20:02:42 --> UTF-8 Support Enabled
INFO - 2018-06-11 20:02:42 --> Utf8 Class Initialized
INFO - 2018-06-11 20:02:42 --> URI Class Initialized
INFO - 2018-06-11 20:02:42 --> Router Class Initialized
INFO - 2018-06-11 20:02:42 --> Output Class Initialized
INFO - 2018-06-11 20:02:42 --> Security Class Initialized
DEBUG - 2018-06-11 20:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 20:02:42 --> CSRF cookie sent
INFO - 2018-06-11 20:02:42 --> Input Class Initialized
INFO - 2018-06-11 20:02:42 --> Language Class Initialized
INFO - 2018-06-11 20:02:42 --> Loader Class Initialized
INFO - 2018-06-11 20:02:42 --> Helper loaded: url_helper
INFO - 2018-06-11 20:02:42 --> Helper loaded: form_helper
INFO - 2018-06-11 20:02:42 --> Helper loaded: language_helper
DEBUG - 2018-06-11 20:02:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 20:02:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 20:02:42 --> User Agent Class Initialized
INFO - 2018-06-11 20:02:42 --> Controller Class Initialized
INFO - 2018-06-11 20:02:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 20:02:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 20:02:42 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 20:02:42 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 20:02:42 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 20:02:42 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 20:02:42 --> File loaded: E:\www\yacopoo\application\views\advisors.php
INFO - 2018-06-11 20:02:42 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 20:02:42 --> Final output sent to browser
DEBUG - 2018-06-11 20:02:42 --> Total execution time: 0.3080
INFO - 2018-06-11 20:02:43 --> Config Class Initialized
INFO - 2018-06-11 20:02:43 --> Hooks Class Initialized
DEBUG - 2018-06-11 20:02:43 --> UTF-8 Support Enabled
INFO - 2018-06-11 20:02:43 --> Utf8 Class Initialized
INFO - 2018-06-11 20:02:43 --> URI Class Initialized
INFO - 2018-06-11 20:02:43 --> Router Class Initialized
INFO - 2018-06-11 20:02:43 --> Output Class Initialized
INFO - 2018-06-11 20:02:43 --> Security Class Initialized
DEBUG - 2018-06-11 20:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 20:02:43 --> CSRF cookie sent
INFO - 2018-06-11 20:02:43 --> Input Class Initialized
INFO - 2018-06-11 20:02:43 --> Language Class Initialized
ERROR - 2018-06-11 20:02:43 --> 404 Page Not Found: Assets/css
INFO - 2018-06-11 20:03:15 --> Config Class Initialized
INFO - 2018-06-11 20:03:15 --> Hooks Class Initialized
DEBUG - 2018-06-11 20:03:15 --> UTF-8 Support Enabled
INFO - 2018-06-11 20:03:15 --> Utf8 Class Initialized
INFO - 2018-06-11 20:03:15 --> URI Class Initialized
INFO - 2018-06-11 20:03:15 --> Router Class Initialized
INFO - 2018-06-11 20:03:15 --> Output Class Initialized
INFO - 2018-06-11 20:03:15 --> Security Class Initialized
DEBUG - 2018-06-11 20:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 20:03:15 --> CSRF cookie sent
INFO - 2018-06-11 20:03:15 --> Input Class Initialized
INFO - 2018-06-11 20:03:15 --> Language Class Initialized
INFO - 2018-06-11 20:03:15 --> Loader Class Initialized
INFO - 2018-06-11 20:03:15 --> Helper loaded: url_helper
INFO - 2018-06-11 20:03:15 --> Helper loaded: form_helper
INFO - 2018-06-11 20:03:15 --> Helper loaded: language_helper
DEBUG - 2018-06-11 20:03:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 20:03:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 20:03:15 --> User Agent Class Initialized
INFO - 2018-06-11 20:03:15 --> Controller Class Initialized
INFO - 2018-06-11 20:03:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 20:03:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 20:03:15 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 20:03:15 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 20:03:15 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 20:03:15 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 20:03:15 --> File loaded: E:\www\yacopoo\application\views\advisors.php
INFO - 2018-06-11 20:03:15 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 20:03:15 --> Final output sent to browser
DEBUG - 2018-06-11 20:03:15 --> Total execution time: 0.3215
INFO - 2018-06-11 20:03:16 --> Config Class Initialized
INFO - 2018-06-11 20:03:16 --> Hooks Class Initialized
DEBUG - 2018-06-11 20:03:16 --> UTF-8 Support Enabled
INFO - 2018-06-11 20:03:16 --> Utf8 Class Initialized
INFO - 2018-06-11 20:03:16 --> URI Class Initialized
INFO - 2018-06-11 20:03:16 --> Router Class Initialized
INFO - 2018-06-11 20:03:16 --> Output Class Initialized
INFO - 2018-06-11 20:03:16 --> Security Class Initialized
DEBUG - 2018-06-11 20:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 20:03:16 --> CSRF cookie sent
INFO - 2018-06-11 20:03:16 --> Input Class Initialized
INFO - 2018-06-11 20:03:16 --> Language Class Initialized
ERROR - 2018-06-11 20:03:16 --> 404 Page Not Found: Assets/css
INFO - 2018-06-11 20:03:22 --> Config Class Initialized
INFO - 2018-06-11 20:03:22 --> Hooks Class Initialized
DEBUG - 2018-06-11 20:03:22 --> UTF-8 Support Enabled
INFO - 2018-06-11 20:03:22 --> Utf8 Class Initialized
INFO - 2018-06-11 20:03:22 --> URI Class Initialized
INFO - 2018-06-11 20:03:22 --> Router Class Initialized
INFO - 2018-06-11 20:03:22 --> Output Class Initialized
INFO - 2018-06-11 20:03:22 --> Security Class Initialized
DEBUG - 2018-06-11 20:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 20:03:22 --> CSRF cookie sent
INFO - 2018-06-11 20:03:22 --> Input Class Initialized
INFO - 2018-06-11 20:03:22 --> Language Class Initialized
INFO - 2018-06-11 20:03:22 --> Loader Class Initialized
INFO - 2018-06-11 20:03:22 --> Helper loaded: url_helper
INFO - 2018-06-11 20:03:23 --> Helper loaded: form_helper
INFO - 2018-06-11 20:03:23 --> Helper loaded: language_helper
DEBUG - 2018-06-11 20:03:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 20:03:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 20:03:23 --> User Agent Class Initialized
INFO - 2018-06-11 20:03:23 --> Controller Class Initialized
INFO - 2018-06-11 20:03:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 20:03:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 20:03:23 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 20:03:23 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 20:03:23 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 20:03:23 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 20:03:23 --> File loaded: E:\www\yacopoo\application\views\advisors.php
INFO - 2018-06-11 20:03:23 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 20:03:23 --> Final output sent to browser
DEBUG - 2018-06-11 20:03:23 --> Total execution time: 0.3240
INFO - 2018-06-11 20:03:23 --> Config Class Initialized
INFO - 2018-06-11 20:03:23 --> Hooks Class Initialized
DEBUG - 2018-06-11 20:03:23 --> UTF-8 Support Enabled
INFO - 2018-06-11 20:03:23 --> Utf8 Class Initialized
INFO - 2018-06-11 20:03:23 --> URI Class Initialized
INFO - 2018-06-11 20:03:23 --> Router Class Initialized
INFO - 2018-06-11 20:03:23 --> Output Class Initialized
INFO - 2018-06-11 20:03:23 --> Security Class Initialized
DEBUG - 2018-06-11 20:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 20:03:23 --> CSRF cookie sent
INFO - 2018-06-11 20:03:23 --> Input Class Initialized
INFO - 2018-06-11 20:03:23 --> Language Class Initialized
ERROR - 2018-06-11 20:03:23 --> 404 Page Not Found: Assets/css
INFO - 2018-06-11 20:03:35 --> Config Class Initialized
INFO - 2018-06-11 20:03:35 --> Hooks Class Initialized
DEBUG - 2018-06-11 20:03:35 --> UTF-8 Support Enabled
INFO - 2018-06-11 20:03:35 --> Utf8 Class Initialized
INFO - 2018-06-11 20:03:35 --> URI Class Initialized
INFO - 2018-06-11 20:03:35 --> Router Class Initialized
INFO - 2018-06-11 20:03:35 --> Output Class Initialized
INFO - 2018-06-11 20:03:35 --> Security Class Initialized
DEBUG - 2018-06-11 20:03:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 20:03:35 --> CSRF cookie sent
INFO - 2018-06-11 20:03:35 --> Input Class Initialized
INFO - 2018-06-11 20:03:35 --> Language Class Initialized
INFO - 2018-06-11 20:03:35 --> Loader Class Initialized
INFO - 2018-06-11 20:03:35 --> Helper loaded: url_helper
INFO - 2018-06-11 20:03:35 --> Helper loaded: form_helper
INFO - 2018-06-11 20:03:35 --> Helper loaded: language_helper
DEBUG - 2018-06-11 20:03:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 20:03:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 20:03:35 --> User Agent Class Initialized
INFO - 2018-06-11 20:03:35 --> Controller Class Initialized
INFO - 2018-06-11 20:03:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 20:03:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 20:03:35 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 20:03:35 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 20:03:35 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 20:03:35 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 20:03:35 --> File loaded: E:\www\yacopoo\application\views\advisors.php
INFO - 2018-06-11 20:03:35 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 20:03:35 --> Final output sent to browser
DEBUG - 2018-06-11 20:03:35 --> Total execution time: 0.3091
INFO - 2018-06-11 20:03:36 --> Config Class Initialized
INFO - 2018-06-11 20:03:36 --> Hooks Class Initialized
DEBUG - 2018-06-11 20:03:36 --> UTF-8 Support Enabled
INFO - 2018-06-11 20:03:36 --> Utf8 Class Initialized
INFO - 2018-06-11 20:03:36 --> URI Class Initialized
INFO - 2018-06-11 20:03:36 --> Router Class Initialized
INFO - 2018-06-11 20:03:36 --> Output Class Initialized
INFO - 2018-06-11 20:03:36 --> Security Class Initialized
DEBUG - 2018-06-11 20:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 20:03:36 --> CSRF cookie sent
INFO - 2018-06-11 20:03:36 --> Input Class Initialized
INFO - 2018-06-11 20:03:36 --> Language Class Initialized
ERROR - 2018-06-11 20:03:36 --> 404 Page Not Found: Assets/css
INFO - 2018-06-11 20:03:41 --> Config Class Initialized
INFO - 2018-06-11 20:03:41 --> Hooks Class Initialized
DEBUG - 2018-06-11 20:03:41 --> UTF-8 Support Enabled
INFO - 2018-06-11 20:03:41 --> Utf8 Class Initialized
INFO - 2018-06-11 20:03:41 --> URI Class Initialized
INFO - 2018-06-11 20:03:41 --> Router Class Initialized
INFO - 2018-06-11 20:03:41 --> Output Class Initialized
INFO - 2018-06-11 20:03:41 --> Security Class Initialized
DEBUG - 2018-06-11 20:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 20:03:41 --> CSRF cookie sent
INFO - 2018-06-11 20:03:41 --> Input Class Initialized
INFO - 2018-06-11 20:03:41 --> Language Class Initialized
INFO - 2018-06-11 20:03:41 --> Loader Class Initialized
INFO - 2018-06-11 20:03:41 --> Helper loaded: url_helper
INFO - 2018-06-11 20:03:41 --> Helper loaded: form_helper
INFO - 2018-06-11 20:03:41 --> Helper loaded: language_helper
DEBUG - 2018-06-11 20:03:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 20:03:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 20:03:41 --> User Agent Class Initialized
INFO - 2018-06-11 20:03:41 --> Controller Class Initialized
INFO - 2018-06-11 20:03:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 20:03:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 20:03:41 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 20:03:41 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 20:03:41 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 20:03:41 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 20:03:41 --> File loaded: E:\www\yacopoo\application\views\advisors.php
INFO - 2018-06-11 20:03:41 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 20:03:41 --> Final output sent to browser
DEBUG - 2018-06-11 20:03:41 --> Total execution time: 0.3438
INFO - 2018-06-11 20:03:57 --> Config Class Initialized
INFO - 2018-06-11 20:03:57 --> Hooks Class Initialized
DEBUG - 2018-06-11 20:03:57 --> UTF-8 Support Enabled
INFO - 2018-06-11 20:03:57 --> Utf8 Class Initialized
INFO - 2018-06-11 20:03:57 --> URI Class Initialized
INFO - 2018-06-11 20:03:57 --> Router Class Initialized
INFO - 2018-06-11 20:03:57 --> Output Class Initialized
INFO - 2018-06-11 20:03:57 --> Security Class Initialized
DEBUG - 2018-06-11 20:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 20:03:57 --> CSRF cookie sent
INFO - 2018-06-11 20:03:57 --> Input Class Initialized
INFO - 2018-06-11 20:03:57 --> Language Class Initialized
INFO - 2018-06-11 20:03:57 --> Loader Class Initialized
INFO - 2018-06-11 20:03:57 --> Helper loaded: url_helper
INFO - 2018-06-11 20:03:57 --> Helper loaded: form_helper
INFO - 2018-06-11 20:03:57 --> Helper loaded: language_helper
DEBUG - 2018-06-11 20:03:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 20:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 20:03:57 --> User Agent Class Initialized
INFO - 2018-06-11 20:03:57 --> Controller Class Initialized
INFO - 2018-06-11 20:03:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 20:03:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 20:03:57 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 20:03:57 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 20:03:57 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 20:03:57 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 20:03:57 --> File loaded: E:\www\yacopoo\application\views\advisors.php
INFO - 2018-06-11 20:03:57 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 20:03:57 --> Final output sent to browser
DEBUG - 2018-06-11 20:03:57 --> Total execution time: 0.3187
INFO - 2018-06-11 20:04:43 --> Config Class Initialized
INFO - 2018-06-11 20:04:43 --> Hooks Class Initialized
DEBUG - 2018-06-11 20:04:43 --> UTF-8 Support Enabled
INFO - 2018-06-11 20:04:43 --> Utf8 Class Initialized
INFO - 2018-06-11 20:04:43 --> URI Class Initialized
INFO - 2018-06-11 20:04:43 --> Router Class Initialized
INFO - 2018-06-11 20:04:43 --> Output Class Initialized
INFO - 2018-06-11 20:04:43 --> Security Class Initialized
DEBUG - 2018-06-11 20:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 20:04:43 --> CSRF cookie sent
INFO - 2018-06-11 20:04:43 --> Input Class Initialized
INFO - 2018-06-11 20:04:43 --> Language Class Initialized
INFO - 2018-06-11 20:04:43 --> Loader Class Initialized
INFO - 2018-06-11 20:04:43 --> Helper loaded: url_helper
INFO - 2018-06-11 20:04:44 --> Helper loaded: form_helper
INFO - 2018-06-11 20:04:44 --> Helper loaded: language_helper
DEBUG - 2018-06-11 20:04:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 20:04:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 20:04:44 --> User Agent Class Initialized
INFO - 2018-06-11 20:04:44 --> Controller Class Initialized
INFO - 2018-06-11 20:04:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 20:04:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 20:04:44 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 20:04:44 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 20:04:44 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 20:04:44 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 20:04:44 --> File loaded: E:\www\yacopoo\application\views\advisors.php
INFO - 2018-06-11 20:04:44 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 20:04:44 --> Final output sent to browser
DEBUG - 2018-06-11 20:04:44 --> Total execution time: 0.3315
INFO - 2018-06-11 20:14:22 --> Config Class Initialized
INFO - 2018-06-11 20:14:22 --> Hooks Class Initialized
DEBUG - 2018-06-11 20:14:22 --> UTF-8 Support Enabled
INFO - 2018-06-11 20:14:22 --> Utf8 Class Initialized
INFO - 2018-06-11 20:14:22 --> URI Class Initialized
INFO - 2018-06-11 20:14:22 --> Router Class Initialized
INFO - 2018-06-11 20:14:22 --> Output Class Initialized
INFO - 2018-06-11 20:14:22 --> Security Class Initialized
DEBUG - 2018-06-11 20:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 20:14:22 --> CSRF cookie sent
INFO - 2018-06-11 20:14:22 --> Input Class Initialized
INFO - 2018-06-11 20:14:22 --> Language Class Initialized
INFO - 2018-06-11 20:14:22 --> Loader Class Initialized
INFO - 2018-06-11 20:14:22 --> Helper loaded: url_helper
INFO - 2018-06-11 20:14:22 --> Helper loaded: form_helper
INFO - 2018-06-11 20:14:22 --> Helper loaded: language_helper
DEBUG - 2018-06-11 20:14:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 20:14:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 20:14:22 --> User Agent Class Initialized
INFO - 2018-06-11 20:14:22 --> Controller Class Initialized
INFO - 2018-06-11 20:14:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 20:14:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 20:14:22 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 20:14:22 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 20:14:22 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 20:14:22 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 20:14:22 --> File loaded: E:\www\yacopoo\application\views\advisors.php
INFO - 2018-06-11 20:14:22 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 20:14:22 --> Final output sent to browser
DEBUG - 2018-06-11 20:14:22 --> Total execution time: 0.3166
INFO - 2018-06-11 20:14:38 --> Config Class Initialized
INFO - 2018-06-11 20:14:39 --> Hooks Class Initialized
DEBUG - 2018-06-11 20:14:39 --> UTF-8 Support Enabled
INFO - 2018-06-11 20:14:39 --> Utf8 Class Initialized
INFO - 2018-06-11 20:14:39 --> URI Class Initialized
INFO - 2018-06-11 20:14:39 --> Router Class Initialized
INFO - 2018-06-11 20:14:39 --> Output Class Initialized
INFO - 2018-06-11 20:14:39 --> Security Class Initialized
DEBUG - 2018-06-11 20:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 20:14:39 --> CSRF cookie sent
INFO - 2018-06-11 20:14:39 --> Input Class Initialized
INFO - 2018-06-11 20:14:39 --> Language Class Initialized
ERROR - 2018-06-11 20:14:39 --> 404 Page Not Found: Assets/css
INFO - 2018-06-11 21:18:11 --> Config Class Initialized
INFO - 2018-06-11 21:18:11 --> Hooks Class Initialized
DEBUG - 2018-06-11 21:18:11 --> UTF-8 Support Enabled
INFO - 2018-06-11 21:18:11 --> Utf8 Class Initialized
INFO - 2018-06-11 21:18:11 --> URI Class Initialized
INFO - 2018-06-11 21:18:11 --> Router Class Initialized
INFO - 2018-06-11 21:18:11 --> Output Class Initialized
INFO - 2018-06-11 21:18:11 --> Security Class Initialized
DEBUG - 2018-06-11 21:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 21:18:11 --> CSRF cookie sent
INFO - 2018-06-11 21:18:11 --> Input Class Initialized
INFO - 2018-06-11 21:18:11 --> Language Class Initialized
INFO - 2018-06-11 21:18:11 --> Loader Class Initialized
INFO - 2018-06-11 21:18:11 --> Helper loaded: url_helper
INFO - 2018-06-11 21:18:11 --> Helper loaded: form_helper
INFO - 2018-06-11 21:18:11 --> Helper loaded: language_helper
DEBUG - 2018-06-11 21:18:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 21:18:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 21:18:11 --> User Agent Class Initialized
INFO - 2018-06-11 21:18:11 --> Controller Class Initialized
INFO - 2018-06-11 21:18:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 21:18:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 21:18:11 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 21:18:11 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 21:18:11 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 21:18:11 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 21:18:11 --> File loaded: E:\www\yacopoo\application\views\faqs.php
INFO - 2018-06-11 21:18:11 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 21:18:11 --> Final output sent to browser
DEBUG - 2018-06-11 21:18:11 --> Total execution time: 0.3431
INFO - 2018-06-11 21:18:12 --> Config Class Initialized
INFO - 2018-06-11 21:18:12 --> Hooks Class Initialized
DEBUG - 2018-06-11 21:18:12 --> UTF-8 Support Enabled
INFO - 2018-06-11 21:18:12 --> Utf8 Class Initialized
INFO - 2018-06-11 21:18:12 --> URI Class Initialized
INFO - 2018-06-11 21:18:12 --> Router Class Initialized
INFO - 2018-06-11 21:18:12 --> Output Class Initialized
INFO - 2018-06-11 21:18:12 --> Security Class Initialized
DEBUG - 2018-06-11 21:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 21:18:12 --> CSRF cookie sent
INFO - 2018-06-11 21:18:12 --> Input Class Initialized
INFO - 2018-06-11 21:18:12 --> Language Class Initialized
ERROR - 2018-06-11 21:18:12 --> 404 Page Not Found: Assets/css
INFO - 2018-06-11 21:20:03 --> Config Class Initialized
INFO - 2018-06-11 21:20:03 --> Hooks Class Initialized
DEBUG - 2018-06-11 21:20:03 --> UTF-8 Support Enabled
INFO - 2018-06-11 21:20:03 --> Utf8 Class Initialized
INFO - 2018-06-11 21:20:03 --> URI Class Initialized
INFO - 2018-06-11 21:20:03 --> Router Class Initialized
INFO - 2018-06-11 21:20:03 --> Output Class Initialized
INFO - 2018-06-11 21:20:03 --> Security Class Initialized
DEBUG - 2018-06-11 21:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 21:20:03 --> CSRF cookie sent
INFO - 2018-06-11 21:20:03 --> Input Class Initialized
INFO - 2018-06-11 21:20:03 --> Language Class Initialized
INFO - 2018-06-11 21:20:03 --> Loader Class Initialized
INFO - 2018-06-11 21:20:03 --> Helper loaded: url_helper
INFO - 2018-06-11 21:20:03 --> Helper loaded: form_helper
INFO - 2018-06-11 21:20:03 --> Helper loaded: language_helper
DEBUG - 2018-06-11 21:20:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 21:20:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 21:20:03 --> User Agent Class Initialized
INFO - 2018-06-11 21:20:03 --> Controller Class Initialized
INFO - 2018-06-11 21:20:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 21:20:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 21:20:03 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 21:20:03 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 21:20:03 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 21:20:03 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 21:20:03 --> File loaded: E:\www\yacopoo\application\views\faqs.php
INFO - 2018-06-11 21:20:03 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 21:20:03 --> Final output sent to browser
DEBUG - 2018-06-11 21:20:03 --> Total execution time: 0.3385
INFO - 2018-06-11 21:20:04 --> Config Class Initialized
INFO - 2018-06-11 21:20:04 --> Hooks Class Initialized
DEBUG - 2018-06-11 21:20:04 --> UTF-8 Support Enabled
INFO - 2018-06-11 21:20:04 --> Utf8 Class Initialized
INFO - 2018-06-11 21:20:04 --> URI Class Initialized
INFO - 2018-06-11 21:20:04 --> Router Class Initialized
INFO - 2018-06-11 21:20:04 --> Output Class Initialized
INFO - 2018-06-11 21:20:04 --> Security Class Initialized
DEBUG - 2018-06-11 21:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 21:20:04 --> CSRF cookie sent
INFO - 2018-06-11 21:20:04 --> Input Class Initialized
INFO - 2018-06-11 21:20:04 --> Language Class Initialized
ERROR - 2018-06-11 21:20:04 --> 404 Page Not Found: Assets/css
INFO - 2018-06-11 21:29:06 --> Config Class Initialized
INFO - 2018-06-11 21:29:06 --> Hooks Class Initialized
DEBUG - 2018-06-11 21:29:06 --> UTF-8 Support Enabled
INFO - 2018-06-11 21:29:06 --> Utf8 Class Initialized
INFO - 2018-06-11 21:29:06 --> URI Class Initialized
INFO - 2018-06-11 21:29:06 --> Router Class Initialized
INFO - 2018-06-11 21:29:06 --> Output Class Initialized
INFO - 2018-06-11 21:29:06 --> Security Class Initialized
DEBUG - 2018-06-11 21:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 21:29:06 --> CSRF cookie sent
INFO - 2018-06-11 21:29:06 --> Input Class Initialized
INFO - 2018-06-11 21:29:06 --> Language Class Initialized
INFO - 2018-06-11 21:29:06 --> Loader Class Initialized
INFO - 2018-06-11 21:29:06 --> Helper loaded: url_helper
INFO - 2018-06-11 21:29:06 --> Helper loaded: form_helper
INFO - 2018-06-11 21:29:06 --> Helper loaded: language_helper
DEBUG - 2018-06-11 21:29:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 21:29:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 21:29:06 --> User Agent Class Initialized
INFO - 2018-06-11 21:29:06 --> Controller Class Initialized
INFO - 2018-06-11 21:29:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 21:29:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 21:29:06 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 21:29:06 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 21:29:06 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 21:29:06 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 21:29:06 --> File loaded: E:\www\yacopoo\application\views\advisors.php
INFO - 2018-06-11 21:29:06 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 21:29:06 --> Final output sent to browser
DEBUG - 2018-06-11 21:29:06 --> Total execution time: 0.3371
INFO - 2018-06-11 21:29:08 --> Config Class Initialized
INFO - 2018-06-11 21:29:08 --> Hooks Class Initialized
DEBUG - 2018-06-11 21:29:08 --> UTF-8 Support Enabled
INFO - 2018-06-11 21:29:08 --> Utf8 Class Initialized
INFO - 2018-06-11 21:29:08 --> URI Class Initialized
INFO - 2018-06-11 21:29:08 --> Router Class Initialized
INFO - 2018-06-11 21:29:09 --> Output Class Initialized
INFO - 2018-06-11 21:29:09 --> Security Class Initialized
DEBUG - 2018-06-11 21:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 21:29:09 --> CSRF cookie sent
INFO - 2018-06-11 21:29:09 --> Input Class Initialized
INFO - 2018-06-11 21:29:09 --> Language Class Initialized
INFO - 2018-06-11 21:29:09 --> Loader Class Initialized
INFO - 2018-06-11 21:29:09 --> Helper loaded: url_helper
INFO - 2018-06-11 21:29:09 --> Helper loaded: form_helper
INFO - 2018-06-11 21:29:09 --> Helper loaded: language_helper
DEBUG - 2018-06-11 21:29:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 21:29:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 21:29:09 --> User Agent Class Initialized
INFO - 2018-06-11 21:29:09 --> Controller Class Initialized
INFO - 2018-06-11 21:29:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 21:29:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 21:29:09 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 21:29:09 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 21:29:09 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 21:29:09 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 21:29:09 --> File loaded: E:\www\yacopoo\application\views\advisors.php
INFO - 2018-06-11 21:29:09 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 21:29:09 --> Final output sent to browser
DEBUG - 2018-06-11 21:29:09 --> Total execution time: 0.3810
INFO - 2018-06-11 21:29:11 --> Config Class Initialized
INFO - 2018-06-11 21:29:11 --> Hooks Class Initialized
DEBUG - 2018-06-11 21:29:11 --> UTF-8 Support Enabled
INFO - 2018-06-11 21:29:11 --> Utf8 Class Initialized
INFO - 2018-06-11 21:29:11 --> URI Class Initialized
INFO - 2018-06-11 21:29:11 --> Router Class Initialized
INFO - 2018-06-11 21:29:11 --> Output Class Initialized
INFO - 2018-06-11 21:29:11 --> Security Class Initialized
DEBUG - 2018-06-11 21:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 21:29:11 --> CSRF cookie sent
INFO - 2018-06-11 21:29:11 --> Input Class Initialized
INFO - 2018-06-11 21:29:11 --> Language Class Initialized
INFO - 2018-06-11 21:29:11 --> Loader Class Initialized
INFO - 2018-06-11 21:29:11 --> Helper loaded: url_helper
INFO - 2018-06-11 21:29:11 --> Helper loaded: form_helper
INFO - 2018-06-11 21:29:11 --> Helper loaded: language_helper
DEBUG - 2018-06-11 21:29:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 21:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 21:29:11 --> User Agent Class Initialized
INFO - 2018-06-11 21:29:11 --> Controller Class Initialized
INFO - 2018-06-11 21:29:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 21:29:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 21:29:11 --> Config Class Initialized
INFO - 2018-06-11 21:29:11 --> Hooks Class Initialized
DEBUG - 2018-06-11 21:29:11 --> UTF-8 Support Enabled
INFO - 2018-06-11 21:29:11 --> Utf8 Class Initialized
INFO - 2018-06-11 21:29:11 --> URI Class Initialized
DEBUG - 2018-06-11 21:29:11 --> No URI present. Default controller set.
INFO - 2018-06-11 21:29:11 --> Router Class Initialized
INFO - 2018-06-11 21:29:11 --> Output Class Initialized
INFO - 2018-06-11 21:29:11 --> Security Class Initialized
DEBUG - 2018-06-11 21:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 21:29:11 --> CSRF cookie sent
INFO - 2018-06-11 21:29:11 --> Input Class Initialized
INFO - 2018-06-11 21:29:11 --> Language Class Initialized
INFO - 2018-06-11 21:29:11 --> Loader Class Initialized
INFO - 2018-06-11 21:29:11 --> Helper loaded: url_helper
INFO - 2018-06-11 21:29:11 --> Helper loaded: form_helper
INFO - 2018-06-11 21:29:12 --> Helper loaded: language_helper
DEBUG - 2018-06-11 21:29:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 21:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 21:29:12 --> User Agent Class Initialized
INFO - 2018-06-11 21:29:12 --> Controller Class Initialized
INFO - 2018-06-11 21:29:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 21:29:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 21:29:12 --> Pixel_Model class loaded
INFO - 2018-06-11 21:29:12 --> Database Driver Class Initialized
INFO - 2018-06-11 21:29:12 --> Model "QuestionsModel" initialized
INFO - 2018-06-11 21:29:12 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 21:29:12 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 21:29:12 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-06-11 21:29:12 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 21:29:12 --> Final output sent to browser
DEBUG - 2018-06-11 21:29:12 --> Total execution time: 0.3893
INFO - 2018-06-11 21:29:15 --> Config Class Initialized
INFO - 2018-06-11 21:29:15 --> Hooks Class Initialized
DEBUG - 2018-06-11 21:29:15 --> UTF-8 Support Enabled
INFO - 2018-06-11 21:29:15 --> Utf8 Class Initialized
INFO - 2018-06-11 21:29:15 --> URI Class Initialized
INFO - 2018-06-11 21:29:15 --> Router Class Initialized
INFO - 2018-06-11 21:29:15 --> Output Class Initialized
INFO - 2018-06-11 21:29:15 --> Security Class Initialized
DEBUG - 2018-06-11 21:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 21:29:15 --> CSRF cookie sent
INFO - 2018-06-11 21:29:15 --> Input Class Initialized
INFO - 2018-06-11 21:29:15 --> Language Class Initialized
INFO - 2018-06-11 21:29:15 --> Loader Class Initialized
INFO - 2018-06-11 21:29:15 --> Helper loaded: url_helper
INFO - 2018-06-11 21:29:15 --> Helper loaded: form_helper
INFO - 2018-06-11 21:29:15 --> Helper loaded: language_helper
DEBUG - 2018-06-11 21:29:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 21:29:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 21:29:16 --> User Agent Class Initialized
INFO - 2018-06-11 21:29:16 --> Controller Class Initialized
INFO - 2018-06-11 21:29:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 21:29:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 21:29:16 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 21:29:16 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 21:29:16 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 21:29:16 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 21:29:16 --> File loaded: E:\www\yacopoo\application\views\advisors.php
INFO - 2018-06-11 21:29:16 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 21:29:16 --> Final output sent to browser
DEBUG - 2018-06-11 21:29:16 --> Total execution time: 0.3625
INFO - 2018-06-11 21:30:21 --> Config Class Initialized
INFO - 2018-06-11 21:30:21 --> Hooks Class Initialized
DEBUG - 2018-06-11 21:30:21 --> UTF-8 Support Enabled
INFO - 2018-06-11 21:30:21 --> Utf8 Class Initialized
INFO - 2018-06-11 21:30:21 --> URI Class Initialized
INFO - 2018-06-11 21:30:21 --> Router Class Initialized
INFO - 2018-06-11 21:30:21 --> Output Class Initialized
INFO - 2018-06-11 21:30:21 --> Security Class Initialized
DEBUG - 2018-06-11 21:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 21:30:21 --> CSRF cookie sent
INFO - 2018-06-11 21:30:21 --> Input Class Initialized
INFO - 2018-06-11 21:30:21 --> Language Class Initialized
INFO - 2018-06-11 21:30:21 --> Loader Class Initialized
INFO - 2018-06-11 21:30:21 --> Helper loaded: url_helper
INFO - 2018-06-11 21:30:21 --> Helper loaded: form_helper
INFO - 2018-06-11 21:30:21 --> Helper loaded: language_helper
DEBUG - 2018-06-11 21:30:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 21:30:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 21:30:21 --> User Agent Class Initialized
INFO - 2018-06-11 21:30:21 --> Controller Class Initialized
INFO - 2018-06-11 21:30:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 21:30:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 21:30:21 --> Config Class Initialized
INFO - 2018-06-11 21:30:21 --> Hooks Class Initialized
DEBUG - 2018-06-11 21:30:21 --> UTF-8 Support Enabled
INFO - 2018-06-11 21:30:21 --> Utf8 Class Initialized
INFO - 2018-06-11 21:30:21 --> URI Class Initialized
INFO - 2018-06-11 21:30:21 --> Router Class Initialized
INFO - 2018-06-11 21:30:21 --> Output Class Initialized
INFO - 2018-06-11 21:30:21 --> Security Class Initialized
DEBUG - 2018-06-11 21:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 21:30:21 --> CSRF cookie sent
INFO - 2018-06-11 21:30:21 --> Input Class Initialized
INFO - 2018-06-11 21:30:21 --> Language Class Initialized
INFO - 2018-06-11 21:30:21 --> Loader Class Initialized
INFO - 2018-06-11 21:30:21 --> Helper loaded: url_helper
INFO - 2018-06-11 21:30:21 --> Helper loaded: form_helper
INFO - 2018-06-11 21:30:21 --> Helper loaded: language_helper
DEBUG - 2018-06-11 21:30:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 21:30:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 21:30:21 --> User Agent Class Initialized
INFO - 2018-06-11 21:30:21 --> Controller Class Initialized
INFO - 2018-06-11 21:30:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 21:30:21 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-11 21:30:21 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-06-11 21:30:21 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 21:30:21 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 21:30:21 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 21:30:21 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-06-11 21:30:21 --> Could not find the language line "req_email"
INFO - 2018-06-11 21:30:21 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-06-11 21:30:21 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 21:30:21 --> Final output sent to browser
DEBUG - 2018-06-11 21:30:21 --> Total execution time: 0.3495
INFO - 2018-06-11 21:32:43 --> Config Class Initialized
INFO - 2018-06-11 21:32:43 --> Hooks Class Initialized
DEBUG - 2018-06-11 21:32:43 --> UTF-8 Support Enabled
INFO - 2018-06-11 21:32:43 --> Utf8 Class Initialized
INFO - 2018-06-11 21:32:43 --> URI Class Initialized
INFO - 2018-06-11 21:32:43 --> Router Class Initialized
INFO - 2018-06-11 21:32:43 --> Output Class Initialized
INFO - 2018-06-11 21:32:43 --> Security Class Initialized
DEBUG - 2018-06-11 21:32:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 21:32:43 --> CSRF cookie sent
INFO - 2018-06-11 21:32:43 --> Input Class Initialized
INFO - 2018-06-11 21:32:43 --> Language Class Initialized
INFO - 2018-06-11 21:32:43 --> Loader Class Initialized
INFO - 2018-06-11 21:32:43 --> Helper loaded: url_helper
INFO - 2018-06-11 21:32:44 --> Helper loaded: form_helper
INFO - 2018-06-11 21:32:44 --> Helper loaded: language_helper
DEBUG - 2018-06-11 21:32:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 21:32:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 21:32:44 --> User Agent Class Initialized
INFO - 2018-06-11 21:32:44 --> Controller Class Initialized
INFO - 2018-06-11 21:32:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 21:32:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 21:32:44 --> Pixel_Model class loaded
INFO - 2018-06-11 21:32:44 --> Database Driver Class Initialized
INFO - 2018-06-11 21:32:44 --> Model "RegistrationModel" initialized
DEBUG - 2018-06-11 21:32:44 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-06-11 21:32:44 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 21:32:44 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 21:32:44 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 21:32:44 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-06-11 21:32:44 --> Could not find the language line "req_email"
INFO - 2018-06-11 21:32:44 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-06-11 21:32:44 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 21:32:44 --> Final output sent to browser
DEBUG - 2018-06-11 21:32:44 --> Total execution time: 0.4002
INFO - 2018-06-11 21:32:52 --> Config Class Initialized
INFO - 2018-06-11 21:32:52 --> Hooks Class Initialized
DEBUG - 2018-06-11 21:32:52 --> UTF-8 Support Enabled
INFO - 2018-06-11 21:32:52 --> Utf8 Class Initialized
INFO - 2018-06-11 21:32:52 --> URI Class Initialized
INFO - 2018-06-11 21:32:52 --> Router Class Initialized
INFO - 2018-06-11 21:32:52 --> Output Class Initialized
INFO - 2018-06-11 21:32:52 --> Security Class Initialized
DEBUG - 2018-06-11 21:32:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 21:32:52 --> CSRF cookie sent
INFO - 2018-06-11 21:32:52 --> Input Class Initialized
INFO - 2018-06-11 21:32:52 --> Language Class Initialized
INFO - 2018-06-11 21:32:52 --> Loader Class Initialized
INFO - 2018-06-11 21:32:52 --> Helper loaded: url_helper
INFO - 2018-06-11 21:32:52 --> Helper loaded: form_helper
INFO - 2018-06-11 21:32:52 --> Helper loaded: language_helper
DEBUG - 2018-06-11 21:32:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 21:32:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 21:32:52 --> User Agent Class Initialized
INFO - 2018-06-11 21:32:52 --> Controller Class Initialized
INFO - 2018-06-11 21:32:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 21:32:52 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-11 21:32:52 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-06-11 21:32:52 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 21:32:52 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 21:32:52 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 21:32:52 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-06-11 21:32:52 --> Could not find the language line "req_email"
INFO - 2018-06-11 21:32:52 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-06-11 21:32:52 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 21:32:52 --> Final output sent to browser
DEBUG - 2018-06-11 21:32:52 --> Total execution time: 0.3456
INFO - 2018-06-11 21:35:27 --> Config Class Initialized
INFO - 2018-06-11 21:35:27 --> Hooks Class Initialized
DEBUG - 2018-06-11 21:35:27 --> UTF-8 Support Enabled
INFO - 2018-06-11 21:35:27 --> Utf8 Class Initialized
INFO - 2018-06-11 21:35:27 --> URI Class Initialized
INFO - 2018-06-11 21:35:27 --> Router Class Initialized
INFO - 2018-06-11 21:35:27 --> Output Class Initialized
INFO - 2018-06-11 21:35:27 --> Security Class Initialized
DEBUG - 2018-06-11 21:35:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 21:35:27 --> CSRF cookie sent
INFO - 2018-06-11 21:35:27 --> Input Class Initialized
INFO - 2018-06-11 21:35:27 --> Language Class Initialized
INFO - 2018-06-11 21:35:27 --> Loader Class Initialized
INFO - 2018-06-11 21:35:27 --> Helper loaded: url_helper
INFO - 2018-06-11 21:35:27 --> Helper loaded: form_helper
INFO - 2018-06-11 21:35:27 --> Helper loaded: language_helper
DEBUG - 2018-06-11 21:35:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 21:35:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 21:35:27 --> User Agent Class Initialized
INFO - 2018-06-11 21:35:27 --> Controller Class Initialized
INFO - 2018-06-11 21:35:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 21:35:27 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-11 21:35:27 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-06-11 21:35:27 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 21:35:27 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 21:35:27 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 21:35:27 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-06-11 21:35:27 --> Could not find the language line "req_email"
INFO - 2018-06-11 21:35:27 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-06-11 21:35:27 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 21:35:27 --> Final output sent to browser
DEBUG - 2018-06-11 21:35:27 --> Total execution time: 0.3504
INFO - 2018-06-11 21:35:35 --> Config Class Initialized
INFO - 2018-06-11 21:35:35 --> Hooks Class Initialized
DEBUG - 2018-06-11 21:35:35 --> UTF-8 Support Enabled
INFO - 2018-06-11 21:35:35 --> Utf8 Class Initialized
INFO - 2018-06-11 21:35:35 --> URI Class Initialized
INFO - 2018-06-11 21:35:35 --> Router Class Initialized
INFO - 2018-06-11 21:35:35 --> Output Class Initialized
INFO - 2018-06-11 21:35:35 --> Security Class Initialized
DEBUG - 2018-06-11 21:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 21:35:35 --> CSRF cookie sent
INFO - 2018-06-11 21:35:35 --> Input Class Initialized
INFO - 2018-06-11 21:35:35 --> Language Class Initialized
INFO - 2018-06-11 21:35:35 --> Loader Class Initialized
INFO - 2018-06-11 21:35:35 --> Helper loaded: url_helper
INFO - 2018-06-11 21:35:35 --> Helper loaded: form_helper
INFO - 2018-06-11 21:35:35 --> Helper loaded: language_helper
DEBUG - 2018-06-11 21:35:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 21:35:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 21:35:35 --> User Agent Class Initialized
INFO - 2018-06-11 21:35:35 --> Controller Class Initialized
INFO - 2018-06-11 21:35:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 21:35:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 21:35:35 --> Pixel_Model class loaded
INFO - 2018-06-11 21:35:35 --> Database Driver Class Initialized
INFO - 2018-06-11 21:35:35 --> Model "RegistrationModel" initialized
DEBUG - 2018-06-11 21:35:35 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-06-11 21:35:35 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 21:35:35 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 21:35:35 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 21:35:35 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-06-11 21:35:35 --> Could not find the language line "req_email"
INFO - 2018-06-11 21:35:35 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-06-11 21:35:35 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 21:35:35 --> Final output sent to browser
DEBUG - 2018-06-11 21:35:35 --> Total execution time: 0.4083
INFO - 2018-06-11 21:35:53 --> Config Class Initialized
INFO - 2018-06-11 21:35:53 --> Hooks Class Initialized
DEBUG - 2018-06-11 21:35:53 --> UTF-8 Support Enabled
INFO - 2018-06-11 21:35:53 --> Utf8 Class Initialized
INFO - 2018-06-11 21:35:53 --> URI Class Initialized
INFO - 2018-06-11 21:35:54 --> Router Class Initialized
INFO - 2018-06-11 21:35:54 --> Output Class Initialized
INFO - 2018-06-11 21:35:54 --> Security Class Initialized
DEBUG - 2018-06-11 21:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 21:35:54 --> CSRF cookie sent
INFO - 2018-06-11 21:35:54 --> Input Class Initialized
INFO - 2018-06-11 21:35:54 --> Language Class Initialized
INFO - 2018-06-11 21:35:54 --> Loader Class Initialized
INFO - 2018-06-11 21:35:54 --> Helper loaded: url_helper
INFO - 2018-06-11 21:35:54 --> Helper loaded: form_helper
INFO - 2018-06-11 21:35:54 --> Helper loaded: language_helper
DEBUG - 2018-06-11 21:35:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 21:35:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 21:35:54 --> User Agent Class Initialized
INFO - 2018-06-11 21:35:54 --> Controller Class Initialized
INFO - 2018-06-11 21:35:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 21:35:54 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-11 21:35:54 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-06-11 21:35:54 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 21:35:54 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 21:35:54 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 21:35:54 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-06-11 21:35:54 --> Could not find the language line "req_email"
INFO - 2018-06-11 21:35:54 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-06-11 21:35:54 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 21:35:54 --> Final output sent to browser
DEBUG - 2018-06-11 21:35:54 --> Total execution time: 0.3536
INFO - 2018-06-11 21:37:37 --> Config Class Initialized
INFO - 2018-06-11 21:37:37 --> Hooks Class Initialized
DEBUG - 2018-06-11 21:37:37 --> UTF-8 Support Enabled
INFO - 2018-06-11 21:37:37 --> Utf8 Class Initialized
INFO - 2018-06-11 21:37:37 --> URI Class Initialized
INFO - 2018-06-11 21:37:37 --> Router Class Initialized
INFO - 2018-06-11 21:37:37 --> Output Class Initialized
INFO - 2018-06-11 21:37:37 --> Security Class Initialized
DEBUG - 2018-06-11 21:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 21:37:37 --> CSRF cookie sent
INFO - 2018-06-11 21:37:37 --> Input Class Initialized
INFO - 2018-06-11 21:37:37 --> Language Class Initialized
INFO - 2018-06-11 21:37:37 --> Loader Class Initialized
INFO - 2018-06-11 21:37:37 --> Helper loaded: url_helper
INFO - 2018-06-11 21:37:37 --> Helper loaded: form_helper
INFO - 2018-06-11 21:37:37 --> Helper loaded: language_helper
DEBUG - 2018-06-11 21:37:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 21:37:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 21:37:37 --> User Agent Class Initialized
INFO - 2018-06-11 21:37:37 --> Controller Class Initialized
INFO - 2018-06-11 21:37:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 21:37:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 21:37:37 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 21:37:37 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 21:37:37 --> File loaded: E:\www\yacopoo\application\views\credit1.php
INFO - 2018-06-11 21:37:37 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 21:37:37 --> Final output sent to browser
DEBUG - 2018-06-11 21:37:37 --> Total execution time: 0.3239
INFO - 2018-06-11 21:38:07 --> Config Class Initialized
INFO - 2018-06-11 21:38:07 --> Hooks Class Initialized
DEBUG - 2018-06-11 21:38:07 --> UTF-8 Support Enabled
INFO - 2018-06-11 21:38:07 --> Utf8 Class Initialized
INFO - 2018-06-11 21:38:07 --> URI Class Initialized
INFO - 2018-06-11 21:38:07 --> Router Class Initialized
INFO - 2018-06-11 21:38:07 --> Output Class Initialized
INFO - 2018-06-11 21:38:07 --> Security Class Initialized
DEBUG - 2018-06-11 21:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 21:38:07 --> CSRF cookie sent
INFO - 2018-06-11 21:38:07 --> Input Class Initialized
INFO - 2018-06-11 21:38:07 --> Language Class Initialized
INFO - 2018-06-11 21:38:07 --> Loader Class Initialized
INFO - 2018-06-11 21:38:07 --> Helper loaded: url_helper
INFO - 2018-06-11 21:38:07 --> Helper loaded: form_helper
INFO - 2018-06-11 21:38:07 --> Helper loaded: language_helper
DEBUG - 2018-06-11 21:38:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 21:38:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 21:38:07 --> User Agent Class Initialized
INFO - 2018-06-11 21:38:07 --> Controller Class Initialized
INFO - 2018-06-11 21:38:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 21:38:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 21:38:07 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 21:38:07 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 21:38:07 --> File loaded: E:\www\yacopoo\application\views\credit.php
INFO - 2018-06-11 21:38:07 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 21:38:07 --> Final output sent to browser
DEBUG - 2018-06-11 21:38:07 --> Total execution time: 0.3862
INFO - 2018-06-11 21:40:03 --> Config Class Initialized
INFO - 2018-06-11 21:40:03 --> Hooks Class Initialized
DEBUG - 2018-06-11 21:40:03 --> UTF-8 Support Enabled
INFO - 2018-06-11 21:40:03 --> Utf8 Class Initialized
INFO - 2018-06-11 21:40:03 --> URI Class Initialized
INFO - 2018-06-11 21:40:03 --> Router Class Initialized
INFO - 2018-06-11 21:40:03 --> Output Class Initialized
INFO - 2018-06-11 21:40:03 --> Security Class Initialized
DEBUG - 2018-06-11 21:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 21:40:03 --> CSRF cookie sent
INFO - 2018-06-11 21:40:03 --> Input Class Initialized
INFO - 2018-06-11 21:40:03 --> Language Class Initialized
INFO - 2018-06-11 21:40:03 --> Loader Class Initialized
INFO - 2018-06-11 21:40:03 --> Helper loaded: url_helper
INFO - 2018-06-11 21:40:03 --> Helper loaded: form_helper
INFO - 2018-06-11 21:40:03 --> Helper loaded: language_helper
DEBUG - 2018-06-11 21:40:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 21:40:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 21:40:03 --> User Agent Class Initialized
INFO - 2018-06-11 21:40:03 --> Controller Class Initialized
INFO - 2018-06-11 21:40:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 21:40:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 21:40:03 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 21:40:03 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 21:40:03 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 21:40:03 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 21:40:03 --> File loaded: E:\www\yacopoo\application\views\buy_gift.php
INFO - 2018-06-11 21:40:03 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 21:40:03 --> Final output sent to browser
DEBUG - 2018-06-11 21:40:03 --> Total execution time: 0.3615
INFO - 2018-06-11 21:40:22 --> Config Class Initialized
INFO - 2018-06-11 21:40:22 --> Hooks Class Initialized
DEBUG - 2018-06-11 21:40:22 --> UTF-8 Support Enabled
INFO - 2018-06-11 21:40:22 --> Utf8 Class Initialized
INFO - 2018-06-11 21:40:22 --> URI Class Initialized
INFO - 2018-06-11 21:40:22 --> Router Class Initialized
INFO - 2018-06-11 21:40:22 --> Output Class Initialized
INFO - 2018-06-11 21:40:22 --> Security Class Initialized
DEBUG - 2018-06-11 21:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 21:40:22 --> CSRF cookie sent
INFO - 2018-06-11 21:40:22 --> Input Class Initialized
INFO - 2018-06-11 21:40:22 --> Language Class Initialized
INFO - 2018-06-11 21:40:22 --> Loader Class Initialized
INFO - 2018-06-11 21:40:22 --> Helper loaded: url_helper
INFO - 2018-06-11 21:40:22 --> Helper loaded: form_helper
INFO - 2018-06-11 21:40:22 --> Helper loaded: language_helper
DEBUG - 2018-06-11 21:40:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 21:40:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 21:40:22 --> User Agent Class Initialized
INFO - 2018-06-11 21:40:22 --> Controller Class Initialized
INFO - 2018-06-11 21:40:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 21:40:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 21:40:22 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 21:40:22 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 21:40:22 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 21:40:22 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 21:40:22 --> File loaded: E:\www\yacopoo\application\views\buy_gift.php
INFO - 2018-06-11 21:40:22 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 21:40:22 --> Final output sent to browser
DEBUG - 2018-06-11 21:40:22 --> Total execution time: 0.3454
INFO - 2018-06-11 21:40:40 --> Config Class Initialized
INFO - 2018-06-11 21:40:40 --> Hooks Class Initialized
DEBUG - 2018-06-11 21:40:40 --> UTF-8 Support Enabled
INFO - 2018-06-11 21:40:40 --> Utf8 Class Initialized
INFO - 2018-06-11 21:40:40 --> URI Class Initialized
INFO - 2018-06-11 21:40:40 --> Router Class Initialized
INFO - 2018-06-11 21:40:40 --> Output Class Initialized
INFO - 2018-06-11 21:40:40 --> Security Class Initialized
DEBUG - 2018-06-11 21:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 21:40:40 --> CSRF cookie sent
INFO - 2018-06-11 21:40:40 --> Input Class Initialized
INFO - 2018-06-11 21:40:40 --> Language Class Initialized
INFO - 2018-06-11 21:40:40 --> Loader Class Initialized
INFO - 2018-06-11 21:40:40 --> Helper loaded: url_helper
INFO - 2018-06-11 21:40:40 --> Helper loaded: form_helper
INFO - 2018-06-11 21:40:40 --> Helper loaded: language_helper
DEBUG - 2018-06-11 21:40:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 21:40:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 21:40:40 --> User Agent Class Initialized
INFO - 2018-06-11 21:40:40 --> Controller Class Initialized
INFO - 2018-06-11 21:40:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 21:40:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 21:40:40 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 21:40:40 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 21:40:40 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 21:40:40 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 21:40:40 --> File loaded: E:\www\yacopoo\application\views\buy_gift.php
INFO - 2018-06-11 21:40:40 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 21:40:40 --> Final output sent to browser
DEBUG - 2018-06-11 21:40:40 --> Total execution time: 0.3493
INFO - 2018-06-11 21:41:14 --> Config Class Initialized
INFO - 2018-06-11 21:41:14 --> Hooks Class Initialized
DEBUG - 2018-06-11 21:41:14 --> UTF-8 Support Enabled
INFO - 2018-06-11 21:41:14 --> Utf8 Class Initialized
INFO - 2018-06-11 21:41:14 --> URI Class Initialized
INFO - 2018-06-11 21:41:14 --> Router Class Initialized
INFO - 2018-06-11 21:41:14 --> Output Class Initialized
INFO - 2018-06-11 21:41:14 --> Security Class Initialized
DEBUG - 2018-06-11 21:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 21:41:14 --> CSRF cookie sent
INFO - 2018-06-11 21:41:14 --> Input Class Initialized
INFO - 2018-06-11 21:41:14 --> Language Class Initialized
INFO - 2018-06-11 21:41:14 --> Loader Class Initialized
INFO - 2018-06-11 21:41:14 --> Helper loaded: url_helper
INFO - 2018-06-11 21:41:14 --> Helper loaded: form_helper
INFO - 2018-06-11 21:41:14 --> Helper loaded: language_helper
DEBUG - 2018-06-11 21:41:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 21:41:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 21:41:14 --> User Agent Class Initialized
INFO - 2018-06-11 21:41:14 --> Controller Class Initialized
INFO - 2018-06-11 21:41:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 21:41:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 21:41:14 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 21:41:14 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 21:41:14 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 21:41:14 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 21:41:14 --> File loaded: E:\www\yacopoo\application\views\buy_gift.php
INFO - 2018-06-11 21:41:14 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 21:41:14 --> Final output sent to browser
DEBUG - 2018-06-11 21:41:14 --> Total execution time: 0.3516
INFO - 2018-06-11 21:41:30 --> Config Class Initialized
INFO - 2018-06-11 21:41:30 --> Hooks Class Initialized
DEBUG - 2018-06-11 21:41:30 --> UTF-8 Support Enabled
INFO - 2018-06-11 21:41:30 --> Utf8 Class Initialized
INFO - 2018-06-11 21:41:30 --> URI Class Initialized
INFO - 2018-06-11 21:41:30 --> Router Class Initialized
INFO - 2018-06-11 21:41:30 --> Output Class Initialized
INFO - 2018-06-11 21:41:30 --> Security Class Initialized
DEBUG - 2018-06-11 21:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 21:41:30 --> CSRF cookie sent
INFO - 2018-06-11 21:41:30 --> Input Class Initialized
INFO - 2018-06-11 21:41:30 --> Language Class Initialized
INFO - 2018-06-11 21:41:30 --> Loader Class Initialized
INFO - 2018-06-11 21:41:30 --> Helper loaded: url_helper
INFO - 2018-06-11 21:41:30 --> Helper loaded: form_helper
INFO - 2018-06-11 21:41:30 --> Helper loaded: language_helper
DEBUG - 2018-06-11 21:41:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 21:41:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 21:41:30 --> User Agent Class Initialized
INFO - 2018-06-11 21:41:30 --> Controller Class Initialized
INFO - 2018-06-11 21:41:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 21:41:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 21:41:30 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 21:41:30 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 21:41:30 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 21:41:30 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 21:41:30 --> File loaded: E:\www\yacopoo\application\views\buy_gift.php
INFO - 2018-06-11 21:41:30 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 21:41:30 --> Final output sent to browser
DEBUG - 2018-06-11 21:41:30 --> Total execution time: 0.3649
INFO - 2018-06-11 21:41:54 --> Config Class Initialized
INFO - 2018-06-11 21:41:54 --> Hooks Class Initialized
DEBUG - 2018-06-11 21:41:54 --> UTF-8 Support Enabled
INFO - 2018-06-11 21:41:54 --> Utf8 Class Initialized
INFO - 2018-06-11 21:41:54 --> URI Class Initialized
INFO - 2018-06-11 21:41:54 --> Router Class Initialized
INFO - 2018-06-11 21:41:54 --> Output Class Initialized
INFO - 2018-06-11 21:41:54 --> Security Class Initialized
DEBUG - 2018-06-11 21:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 21:41:54 --> CSRF cookie sent
INFO - 2018-06-11 21:41:54 --> Input Class Initialized
INFO - 2018-06-11 21:41:54 --> Language Class Initialized
INFO - 2018-06-11 21:41:54 --> Loader Class Initialized
INFO - 2018-06-11 21:41:54 --> Helper loaded: url_helper
INFO - 2018-06-11 21:41:54 --> Helper loaded: form_helper
INFO - 2018-06-11 21:41:54 --> Helper loaded: language_helper
DEBUG - 2018-06-11 21:41:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 21:41:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 21:41:54 --> User Agent Class Initialized
INFO - 2018-06-11 21:41:54 --> Controller Class Initialized
INFO - 2018-06-11 21:41:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 21:41:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 21:41:55 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 21:41:55 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 21:41:55 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 21:41:55 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 21:41:55 --> File loaded: E:\www\yacopoo\application\views\buy_gift.php
INFO - 2018-06-11 21:41:55 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 21:41:55 --> Final output sent to browser
DEBUG - 2018-06-11 21:41:55 --> Total execution time: 0.3437
INFO - 2018-06-11 21:42:13 --> Config Class Initialized
INFO - 2018-06-11 21:42:13 --> Hooks Class Initialized
DEBUG - 2018-06-11 21:42:13 --> UTF-8 Support Enabled
INFO - 2018-06-11 21:42:13 --> Utf8 Class Initialized
INFO - 2018-06-11 21:42:13 --> URI Class Initialized
INFO - 2018-06-11 21:42:13 --> Router Class Initialized
INFO - 2018-06-11 21:42:13 --> Output Class Initialized
INFO - 2018-06-11 21:42:13 --> Security Class Initialized
DEBUG - 2018-06-11 21:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 21:42:13 --> CSRF cookie sent
INFO - 2018-06-11 21:42:13 --> Input Class Initialized
INFO - 2018-06-11 21:42:13 --> Language Class Initialized
INFO - 2018-06-11 21:42:13 --> Loader Class Initialized
INFO - 2018-06-11 21:42:13 --> Helper loaded: url_helper
INFO - 2018-06-11 21:42:13 --> Helper loaded: form_helper
INFO - 2018-06-11 21:42:13 --> Helper loaded: language_helper
DEBUG - 2018-06-11 21:42:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 21:42:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 21:42:13 --> User Agent Class Initialized
INFO - 2018-06-11 21:42:13 --> Controller Class Initialized
INFO - 2018-06-11 21:42:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 21:42:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 21:42:13 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 21:42:13 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 21:42:13 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 21:42:13 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 21:42:13 --> File loaded: E:\www\yacopoo\application\views\buy_gift.php
INFO - 2018-06-11 21:42:13 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 21:42:13 --> Final output sent to browser
DEBUG - 2018-06-11 21:42:13 --> Total execution time: 0.3507
INFO - 2018-06-11 21:43:48 --> Config Class Initialized
INFO - 2018-06-11 21:43:48 --> Hooks Class Initialized
DEBUG - 2018-06-11 21:43:48 --> UTF-8 Support Enabled
INFO - 2018-06-11 21:43:48 --> Utf8 Class Initialized
INFO - 2018-06-11 21:43:48 --> URI Class Initialized
INFO - 2018-06-11 21:43:48 --> Router Class Initialized
INFO - 2018-06-11 21:43:48 --> Output Class Initialized
INFO - 2018-06-11 21:43:48 --> Security Class Initialized
DEBUG - 2018-06-11 21:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 21:43:48 --> CSRF cookie sent
INFO - 2018-06-11 21:43:48 --> Input Class Initialized
INFO - 2018-06-11 21:43:48 --> Language Class Initialized
INFO - 2018-06-11 21:43:48 --> Loader Class Initialized
INFO - 2018-06-11 21:43:48 --> Helper loaded: url_helper
INFO - 2018-06-11 21:43:48 --> Helper loaded: form_helper
INFO - 2018-06-11 21:43:48 --> Helper loaded: language_helper
DEBUG - 2018-06-11 21:43:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 21:43:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 21:43:48 --> User Agent Class Initialized
INFO - 2018-06-11 21:43:48 --> Controller Class Initialized
INFO - 2018-06-11 21:43:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 21:43:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 21:43:48 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 21:43:48 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 21:43:49 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 21:43:49 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 21:43:49 --> File loaded: E:\www\yacopoo\application\views\buy_gift.php
INFO - 2018-06-11 21:43:49 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 21:43:49 --> Final output sent to browser
DEBUG - 2018-06-11 21:43:49 --> Total execution time: 0.3482
INFO - 2018-06-11 21:45:22 --> Config Class Initialized
INFO - 2018-06-11 21:45:22 --> Hooks Class Initialized
DEBUG - 2018-06-11 21:45:22 --> UTF-8 Support Enabled
INFO - 2018-06-11 21:45:22 --> Utf8 Class Initialized
INFO - 2018-06-11 21:45:22 --> URI Class Initialized
INFO - 2018-06-11 21:45:22 --> Router Class Initialized
INFO - 2018-06-11 21:45:22 --> Output Class Initialized
INFO - 2018-06-11 21:45:22 --> Security Class Initialized
DEBUG - 2018-06-11 21:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 21:45:22 --> CSRF cookie sent
INFO - 2018-06-11 21:45:22 --> Input Class Initialized
INFO - 2018-06-11 21:45:22 --> Language Class Initialized
INFO - 2018-06-11 21:45:22 --> Loader Class Initialized
INFO - 2018-06-11 21:45:22 --> Helper loaded: url_helper
INFO - 2018-06-11 21:45:22 --> Helper loaded: form_helper
INFO - 2018-06-11 21:45:22 --> Helper loaded: language_helper
DEBUG - 2018-06-11 21:45:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 21:45:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 21:45:22 --> User Agent Class Initialized
INFO - 2018-06-11 21:45:22 --> Controller Class Initialized
INFO - 2018-06-11 21:45:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 21:45:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 21:45:22 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 21:45:22 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 21:45:22 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 21:45:22 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 21:45:22 --> File loaded: E:\www\yacopoo\application\views\buy_gift.php
INFO - 2018-06-11 21:45:22 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 21:45:22 --> Final output sent to browser
DEBUG - 2018-06-11 21:45:22 --> Total execution time: 0.3489
INFO - 2018-06-11 21:46:51 --> Config Class Initialized
INFO - 2018-06-11 21:46:51 --> Hooks Class Initialized
DEBUG - 2018-06-11 21:46:51 --> UTF-8 Support Enabled
INFO - 2018-06-11 21:46:51 --> Utf8 Class Initialized
INFO - 2018-06-11 21:46:51 --> URI Class Initialized
INFO - 2018-06-11 21:46:51 --> Router Class Initialized
INFO - 2018-06-11 21:46:51 --> Output Class Initialized
INFO - 2018-06-11 21:46:51 --> Security Class Initialized
DEBUG - 2018-06-11 21:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 21:46:52 --> CSRF cookie sent
INFO - 2018-06-11 21:46:52 --> Input Class Initialized
INFO - 2018-06-11 21:46:52 --> Language Class Initialized
INFO - 2018-06-11 21:46:52 --> Loader Class Initialized
INFO - 2018-06-11 21:46:52 --> Helper loaded: url_helper
INFO - 2018-06-11 21:46:52 --> Helper loaded: form_helper
INFO - 2018-06-11 21:46:52 --> Helper loaded: language_helper
DEBUG - 2018-06-11 21:46:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 21:46:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 21:46:52 --> User Agent Class Initialized
INFO - 2018-06-11 21:46:52 --> Controller Class Initialized
INFO - 2018-06-11 21:46:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 21:46:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 21:46:52 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 21:46:52 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 21:46:52 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 21:46:52 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 21:46:52 --> File loaded: E:\www\yacopoo\application\views\buy_gift.php
INFO - 2018-06-11 21:46:52 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 21:46:52 --> Final output sent to browser
DEBUG - 2018-06-11 21:46:52 --> Total execution time: 0.3552
INFO - 2018-06-11 21:47:16 --> Config Class Initialized
INFO - 2018-06-11 21:47:16 --> Hooks Class Initialized
DEBUG - 2018-06-11 21:47:16 --> UTF-8 Support Enabled
INFO - 2018-06-11 21:47:16 --> Utf8 Class Initialized
INFO - 2018-06-11 21:47:16 --> URI Class Initialized
INFO - 2018-06-11 21:47:16 --> Router Class Initialized
INFO - 2018-06-11 21:47:16 --> Output Class Initialized
INFO - 2018-06-11 21:47:16 --> Security Class Initialized
DEBUG - 2018-06-11 21:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 21:47:16 --> CSRF cookie sent
INFO - 2018-06-11 21:47:16 --> Input Class Initialized
INFO - 2018-06-11 21:47:16 --> Language Class Initialized
INFO - 2018-06-11 21:47:16 --> Loader Class Initialized
INFO - 2018-06-11 21:47:16 --> Helper loaded: url_helper
INFO - 2018-06-11 21:47:16 --> Helper loaded: form_helper
INFO - 2018-06-11 21:47:16 --> Helper loaded: language_helper
DEBUG - 2018-06-11 21:47:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 21:47:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 21:47:16 --> User Agent Class Initialized
INFO - 2018-06-11 21:47:16 --> Controller Class Initialized
INFO - 2018-06-11 21:47:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 21:47:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 21:47:16 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 21:47:16 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 21:47:16 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 21:47:16 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 21:47:16 --> File loaded: E:\www\yacopoo\application\views\buy_gift.php
INFO - 2018-06-11 21:47:16 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 21:47:16 --> Final output sent to browser
DEBUG - 2018-06-11 21:47:16 --> Total execution time: 0.3493
INFO - 2018-06-11 21:48:19 --> Config Class Initialized
INFO - 2018-06-11 21:48:19 --> Hooks Class Initialized
DEBUG - 2018-06-11 21:48:19 --> UTF-8 Support Enabled
INFO - 2018-06-11 21:48:20 --> Utf8 Class Initialized
INFO - 2018-06-11 21:48:20 --> URI Class Initialized
INFO - 2018-06-11 21:48:20 --> Router Class Initialized
INFO - 2018-06-11 21:48:20 --> Output Class Initialized
INFO - 2018-06-11 21:48:20 --> Security Class Initialized
DEBUG - 2018-06-11 21:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 21:48:20 --> CSRF cookie sent
INFO - 2018-06-11 21:48:20 --> Input Class Initialized
INFO - 2018-06-11 21:48:20 --> Language Class Initialized
INFO - 2018-06-11 21:48:20 --> Loader Class Initialized
INFO - 2018-06-11 21:48:20 --> Helper loaded: url_helper
INFO - 2018-06-11 21:48:20 --> Helper loaded: form_helper
INFO - 2018-06-11 21:48:20 --> Helper loaded: language_helper
DEBUG - 2018-06-11 21:48:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 21:48:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 21:48:20 --> User Agent Class Initialized
INFO - 2018-06-11 21:48:20 --> Controller Class Initialized
INFO - 2018-06-11 21:48:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 21:48:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 21:48:20 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 21:48:20 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 21:48:20 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 21:48:20 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 21:48:20 --> File loaded: E:\www\yacopoo\application\views\buy_gift.php
INFO - 2018-06-11 21:48:20 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 21:48:20 --> Final output sent to browser
DEBUG - 2018-06-11 21:48:20 --> Total execution time: 0.3593
INFO - 2018-06-11 21:48:35 --> Config Class Initialized
INFO - 2018-06-11 21:48:35 --> Hooks Class Initialized
DEBUG - 2018-06-11 21:48:35 --> UTF-8 Support Enabled
INFO - 2018-06-11 21:48:35 --> Utf8 Class Initialized
INFO - 2018-06-11 21:48:35 --> URI Class Initialized
DEBUG - 2018-06-11 21:48:35 --> No URI present. Default controller set.
INFO - 2018-06-11 21:48:35 --> Router Class Initialized
INFO - 2018-06-11 21:48:36 --> Output Class Initialized
INFO - 2018-06-11 21:48:36 --> Security Class Initialized
DEBUG - 2018-06-11 21:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 21:48:36 --> CSRF cookie sent
INFO - 2018-06-11 21:48:36 --> Input Class Initialized
INFO - 2018-06-11 21:48:36 --> Language Class Initialized
INFO - 2018-06-11 21:48:36 --> Loader Class Initialized
INFO - 2018-06-11 21:48:36 --> Helper loaded: url_helper
INFO - 2018-06-11 21:48:36 --> Helper loaded: form_helper
INFO - 2018-06-11 21:48:36 --> Helper loaded: language_helper
DEBUG - 2018-06-11 21:48:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 21:48:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 21:48:36 --> User Agent Class Initialized
INFO - 2018-06-11 21:48:36 --> Controller Class Initialized
INFO - 2018-06-11 21:48:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 21:48:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 21:48:36 --> Pixel_Model class loaded
INFO - 2018-06-11 21:48:36 --> Database Driver Class Initialized
INFO - 2018-06-11 21:48:36 --> Model "QuestionsModel" initialized
INFO - 2018-06-11 21:48:36 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 21:48:36 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 21:48:36 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-06-11 21:48:36 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 21:48:36 --> Final output sent to browser
DEBUG - 2018-06-11 21:48:36 --> Total execution time: 0.5547
INFO - 2018-06-11 21:48:40 --> Config Class Initialized
INFO - 2018-06-11 21:48:40 --> Hooks Class Initialized
DEBUG - 2018-06-11 21:48:40 --> UTF-8 Support Enabled
INFO - 2018-06-11 21:48:40 --> Utf8 Class Initialized
INFO - 2018-06-11 21:48:40 --> URI Class Initialized
INFO - 2018-06-11 21:48:40 --> Router Class Initialized
INFO - 2018-06-11 21:48:40 --> Output Class Initialized
INFO - 2018-06-11 21:48:40 --> Security Class Initialized
DEBUG - 2018-06-11 21:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 21:48:40 --> CSRF cookie sent
INFO - 2018-06-11 21:48:40 --> Input Class Initialized
INFO - 2018-06-11 21:48:40 --> Language Class Initialized
INFO - 2018-06-11 21:48:40 --> Loader Class Initialized
INFO - 2018-06-11 21:48:40 --> Helper loaded: url_helper
INFO - 2018-06-11 21:48:40 --> Helper loaded: form_helper
INFO - 2018-06-11 21:48:40 --> Helper loaded: language_helper
DEBUG - 2018-06-11 21:48:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 21:48:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 21:48:40 --> User Agent Class Initialized
INFO - 2018-06-11 21:48:40 --> Controller Class Initialized
INFO - 2018-06-11 21:48:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 21:48:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 21:48:40 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 21:48:40 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 21:48:40 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 21:48:40 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 21:48:40 --> File loaded: E:\www\yacopoo\application\views\buy_gift.php
INFO - 2018-06-11 21:48:40 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 21:48:40 --> Final output sent to browser
DEBUG - 2018-06-11 21:48:40 --> Total execution time: 0.3888
INFO - 2018-06-11 21:49:50 --> Config Class Initialized
INFO - 2018-06-11 21:49:50 --> Hooks Class Initialized
DEBUG - 2018-06-11 21:49:50 --> UTF-8 Support Enabled
INFO - 2018-06-11 21:49:50 --> Utf8 Class Initialized
INFO - 2018-06-11 21:49:50 --> URI Class Initialized
DEBUG - 2018-06-11 21:49:50 --> No URI present. Default controller set.
INFO - 2018-06-11 21:49:50 --> Router Class Initialized
INFO - 2018-06-11 21:49:50 --> Output Class Initialized
INFO - 2018-06-11 21:49:50 --> Security Class Initialized
DEBUG - 2018-06-11 21:49:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 21:49:50 --> CSRF cookie sent
INFO - 2018-06-11 21:49:50 --> Input Class Initialized
INFO - 2018-06-11 21:49:50 --> Language Class Initialized
INFO - 2018-06-11 21:49:50 --> Loader Class Initialized
INFO - 2018-06-11 21:49:50 --> Helper loaded: url_helper
INFO - 2018-06-11 21:49:50 --> Helper loaded: form_helper
INFO - 2018-06-11 21:49:50 --> Helper loaded: language_helper
DEBUG - 2018-06-11 21:49:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 21:49:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 21:49:50 --> User Agent Class Initialized
INFO - 2018-06-11 21:49:50 --> Controller Class Initialized
INFO - 2018-06-11 21:49:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 21:49:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 21:49:50 --> Pixel_Model class loaded
INFO - 2018-06-11 21:49:50 --> Database Driver Class Initialized
INFO - 2018-06-11 21:49:50 --> Model "QuestionsModel" initialized
INFO - 2018-06-11 21:49:51 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 21:49:51 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 21:49:51 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-06-11 21:49:51 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 21:49:51 --> Final output sent to browser
DEBUG - 2018-06-11 21:49:51 --> Total execution time: 0.4160
INFO - 2018-06-11 21:49:53 --> Config Class Initialized
INFO - 2018-06-11 21:49:53 --> Hooks Class Initialized
DEBUG - 2018-06-11 21:49:53 --> UTF-8 Support Enabled
INFO - 2018-06-11 21:49:53 --> Utf8 Class Initialized
INFO - 2018-06-11 21:49:53 --> URI Class Initialized
INFO - 2018-06-11 21:49:53 --> Router Class Initialized
INFO - 2018-06-11 21:49:53 --> Output Class Initialized
INFO - 2018-06-11 21:49:53 --> Security Class Initialized
DEBUG - 2018-06-11 21:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 21:49:53 --> CSRF cookie sent
INFO - 2018-06-11 21:49:53 --> CSRF token verified
INFO - 2018-06-11 21:49:53 --> Input Class Initialized
INFO - 2018-06-11 21:49:53 --> Language Class Initialized
INFO - 2018-06-11 21:49:53 --> Loader Class Initialized
INFO - 2018-06-11 21:49:53 --> Helper loaded: url_helper
INFO - 2018-06-11 21:49:53 --> Helper loaded: form_helper
INFO - 2018-06-11 21:49:53 --> Helper loaded: language_helper
DEBUG - 2018-06-11 21:49:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 21:49:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 21:49:53 --> User Agent Class Initialized
INFO - 2018-06-11 21:49:53 --> Controller Class Initialized
INFO - 2018-06-11 21:49:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 21:49:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 21:49:53 --> Pixel_Model class loaded
INFO - 2018-06-11 21:49:53 --> Database Driver Class Initialized
INFO - 2018-06-11 21:49:53 --> Model "QuestionsModel" initialized
INFO - 2018-06-11 21:49:53 --> Config Class Initialized
INFO - 2018-06-11 21:49:53 --> Hooks Class Initialized
DEBUG - 2018-06-11 21:49:53 --> UTF-8 Support Enabled
INFO - 2018-06-11 21:49:53 --> Utf8 Class Initialized
INFO - 2018-06-11 21:49:53 --> URI Class Initialized
INFO - 2018-06-11 21:49:53 --> Router Class Initialized
INFO - 2018-06-11 21:49:53 --> Output Class Initialized
INFO - 2018-06-11 21:49:53 --> Security Class Initialized
DEBUG - 2018-06-11 21:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 21:49:53 --> CSRF cookie sent
INFO - 2018-06-11 21:49:54 --> Input Class Initialized
INFO - 2018-06-11 21:49:54 --> Language Class Initialized
INFO - 2018-06-11 21:49:54 --> Loader Class Initialized
INFO - 2018-06-11 21:49:54 --> Helper loaded: url_helper
INFO - 2018-06-11 21:49:54 --> Helper loaded: form_helper
INFO - 2018-06-11 21:49:54 --> Helper loaded: language_helper
DEBUG - 2018-06-11 21:49:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 21:49:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 21:49:54 --> User Agent Class Initialized
INFO - 2018-06-11 21:49:54 --> Controller Class Initialized
INFO - 2018-06-11 21:49:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 21:49:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 21:49:54 --> Pixel_Model class loaded
INFO - 2018-06-11 21:49:54 --> Database Driver Class Initialized
INFO - 2018-06-11 21:49:54 --> Model "RegistrationModel" initialized
DEBUG - 2018-06-11 21:49:54 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-06-11 21:49:54 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 21:49:54 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 21:49:54 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 21:49:54 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-06-11 21:49:54 --> Could not find the language line "req_email"
INFO - 2018-06-11 21:49:54 --> File loaded: E:\www\yacopoo\application\views\register/signup.php
INFO - 2018-06-11 21:49:54 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 21:49:54 --> Final output sent to browser
DEBUG - 2018-06-11 21:49:54 --> Total execution time: 0.4720
INFO - 2018-06-11 21:50:19 --> Config Class Initialized
INFO - 2018-06-11 21:50:19 --> Hooks Class Initialized
DEBUG - 2018-06-11 21:50:19 --> UTF-8 Support Enabled
INFO - 2018-06-11 21:50:19 --> Utf8 Class Initialized
INFO - 2018-06-11 21:50:19 --> URI Class Initialized
DEBUG - 2018-06-11 21:50:19 --> No URI present. Default controller set.
INFO - 2018-06-11 21:50:19 --> Router Class Initialized
INFO - 2018-06-11 21:50:19 --> Output Class Initialized
INFO - 2018-06-11 21:50:19 --> Security Class Initialized
DEBUG - 2018-06-11 21:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 21:50:19 --> CSRF cookie sent
INFO - 2018-06-11 21:50:19 --> Input Class Initialized
INFO - 2018-06-11 21:50:19 --> Language Class Initialized
INFO - 2018-06-11 21:50:19 --> Loader Class Initialized
INFO - 2018-06-11 21:50:19 --> Helper loaded: url_helper
INFO - 2018-06-11 21:50:19 --> Helper loaded: form_helper
INFO - 2018-06-11 21:50:19 --> Helper loaded: language_helper
DEBUG - 2018-06-11 21:50:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 21:50:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 21:50:19 --> User Agent Class Initialized
INFO - 2018-06-11 21:50:19 --> Controller Class Initialized
INFO - 2018-06-11 21:50:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 21:50:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 21:50:19 --> Pixel_Model class loaded
INFO - 2018-06-11 21:50:20 --> Database Driver Class Initialized
INFO - 2018-06-11 21:50:20 --> Model "QuestionsModel" initialized
INFO - 2018-06-11 21:50:20 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 21:50:20 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 21:50:20 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-06-11 21:50:20 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 21:50:20 --> Final output sent to browser
DEBUG - 2018-06-11 21:50:20 --> Total execution time: 0.4016
INFO - 2018-06-11 21:50:21 --> Config Class Initialized
INFO - 2018-06-11 21:50:21 --> Hooks Class Initialized
DEBUG - 2018-06-11 21:50:21 --> UTF-8 Support Enabled
INFO - 2018-06-11 21:50:21 --> Utf8 Class Initialized
INFO - 2018-06-11 21:50:21 --> URI Class Initialized
DEBUG - 2018-06-11 21:50:21 --> No URI present. Default controller set.
INFO - 2018-06-11 21:50:21 --> Router Class Initialized
INFO - 2018-06-11 21:50:21 --> Output Class Initialized
INFO - 2018-06-11 21:50:21 --> Security Class Initialized
DEBUG - 2018-06-11 21:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 21:50:21 --> CSRF cookie sent
INFO - 2018-06-11 21:50:21 --> Input Class Initialized
INFO - 2018-06-11 21:50:21 --> Language Class Initialized
INFO - 2018-06-11 21:50:21 --> Loader Class Initialized
INFO - 2018-06-11 21:50:21 --> Helper loaded: url_helper
INFO - 2018-06-11 21:50:21 --> Helper loaded: form_helper
INFO - 2018-06-11 21:50:21 --> Helper loaded: language_helper
DEBUG - 2018-06-11 21:50:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 21:50:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 21:50:21 --> User Agent Class Initialized
INFO - 2018-06-11 21:50:21 --> Controller Class Initialized
INFO - 2018-06-11 21:50:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 21:50:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 21:50:21 --> Pixel_Model class loaded
INFO - 2018-06-11 21:50:21 --> Database Driver Class Initialized
INFO - 2018-06-11 21:50:21 --> Model "QuestionsModel" initialized
INFO - 2018-06-11 21:50:21 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 21:50:21 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 21:50:21 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-06-11 21:50:21 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 21:50:21 --> Final output sent to browser
DEBUG - 2018-06-11 21:50:21 --> Total execution time: 0.4740
INFO - 2018-06-11 21:50:23 --> Config Class Initialized
INFO - 2018-06-11 21:50:23 --> Hooks Class Initialized
DEBUG - 2018-06-11 21:50:23 --> UTF-8 Support Enabled
INFO - 2018-06-11 21:50:23 --> Utf8 Class Initialized
INFO - 2018-06-11 21:50:23 --> URI Class Initialized
INFO - 2018-06-11 21:50:23 --> Router Class Initialized
INFO - 2018-06-11 21:50:23 --> Output Class Initialized
INFO - 2018-06-11 21:50:23 --> Security Class Initialized
DEBUG - 2018-06-11 21:50:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 21:50:23 --> CSRF cookie sent
INFO - 2018-06-11 21:50:23 --> CSRF token verified
INFO - 2018-06-11 21:50:23 --> Input Class Initialized
INFO - 2018-06-11 21:50:23 --> Language Class Initialized
INFO - 2018-06-11 21:50:23 --> Loader Class Initialized
INFO - 2018-06-11 21:50:23 --> Helper loaded: url_helper
INFO - 2018-06-11 21:50:23 --> Helper loaded: form_helper
INFO - 2018-06-11 21:50:23 --> Helper loaded: language_helper
DEBUG - 2018-06-11 21:50:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 21:50:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 21:50:24 --> User Agent Class Initialized
INFO - 2018-06-11 21:50:24 --> Controller Class Initialized
INFO - 2018-06-11 21:50:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 21:50:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 21:50:24 --> Pixel_Model class loaded
INFO - 2018-06-11 21:50:24 --> Database Driver Class Initialized
INFO - 2018-06-11 21:50:24 --> Model "QuestionsModel" initialized
INFO - 2018-06-11 21:50:24 --> Config Class Initialized
INFO - 2018-06-11 21:50:24 --> Hooks Class Initialized
DEBUG - 2018-06-11 21:50:24 --> UTF-8 Support Enabled
INFO - 2018-06-11 21:50:24 --> Utf8 Class Initialized
INFO - 2018-06-11 21:50:24 --> URI Class Initialized
INFO - 2018-06-11 21:50:24 --> Router Class Initialized
INFO - 2018-06-11 21:50:24 --> Output Class Initialized
INFO - 2018-06-11 21:50:24 --> Security Class Initialized
DEBUG - 2018-06-11 21:50:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 21:50:24 --> CSRF cookie sent
INFO - 2018-06-11 21:50:24 --> Input Class Initialized
INFO - 2018-06-11 21:50:24 --> Language Class Initialized
INFO - 2018-06-11 21:50:24 --> Loader Class Initialized
INFO - 2018-06-11 21:50:24 --> Helper loaded: url_helper
INFO - 2018-06-11 21:50:24 --> Helper loaded: form_helper
INFO - 2018-06-11 21:50:24 --> Helper loaded: language_helper
DEBUG - 2018-06-11 21:50:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 21:50:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 21:50:24 --> User Agent Class Initialized
INFO - 2018-06-11 21:50:24 --> Controller Class Initialized
INFO - 2018-06-11 21:50:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 21:50:24 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-11 21:50:24 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-06-11 21:50:24 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 21:50:24 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 21:50:24 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 21:50:24 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-06-11 21:50:24 --> Could not find the language line "req_email"
INFO - 2018-06-11 21:50:24 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-06-11 21:50:24 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 21:50:24 --> Final output sent to browser
DEBUG - 2018-06-11 21:50:24 --> Total execution time: 0.3808
INFO - 2018-06-11 21:52:46 --> Config Class Initialized
INFO - 2018-06-11 21:52:46 --> Hooks Class Initialized
DEBUG - 2018-06-11 21:52:46 --> UTF-8 Support Enabled
INFO - 2018-06-11 21:52:46 --> Utf8 Class Initialized
INFO - 2018-06-11 21:52:46 --> URI Class Initialized
DEBUG - 2018-06-11 21:52:46 --> No URI present. Default controller set.
INFO - 2018-06-11 21:52:46 --> Router Class Initialized
INFO - 2018-06-11 21:52:46 --> Output Class Initialized
INFO - 2018-06-11 21:52:46 --> Security Class Initialized
DEBUG - 2018-06-11 21:52:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 21:52:46 --> CSRF cookie sent
INFO - 2018-06-11 21:52:46 --> Input Class Initialized
INFO - 2018-06-11 21:52:46 --> Language Class Initialized
INFO - 2018-06-11 21:52:46 --> Loader Class Initialized
INFO - 2018-06-11 21:52:47 --> Helper loaded: url_helper
INFO - 2018-06-11 21:52:47 --> Helper loaded: form_helper
INFO - 2018-06-11 21:52:47 --> Helper loaded: language_helper
DEBUG - 2018-06-11 21:52:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 21:52:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 21:52:47 --> User Agent Class Initialized
INFO - 2018-06-11 21:52:47 --> Controller Class Initialized
INFO - 2018-06-11 21:52:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 21:52:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 21:52:47 --> Pixel_Model class loaded
INFO - 2018-06-11 21:52:47 --> Database Driver Class Initialized
INFO - 2018-06-11 21:52:47 --> Model "QuestionsModel" initialized
INFO - 2018-06-11 21:52:47 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 21:52:47 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 21:52:47 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-06-11 21:52:47 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 21:52:47 --> Final output sent to browser
DEBUG - 2018-06-11 21:52:47 --> Total execution time: 0.4039
INFO - 2018-06-11 21:52:48 --> Config Class Initialized
INFO - 2018-06-11 21:52:48 --> Hooks Class Initialized
DEBUG - 2018-06-11 21:52:48 --> UTF-8 Support Enabled
INFO - 2018-06-11 21:52:48 --> Utf8 Class Initialized
INFO - 2018-06-11 21:52:48 --> URI Class Initialized
INFO - 2018-06-11 21:52:48 --> Router Class Initialized
INFO - 2018-06-11 21:52:48 --> Output Class Initialized
INFO - 2018-06-11 21:52:48 --> Security Class Initialized
DEBUG - 2018-06-11 21:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 21:52:48 --> CSRF cookie sent
INFO - 2018-06-11 21:52:49 --> Input Class Initialized
INFO - 2018-06-11 21:52:49 --> Language Class Initialized
INFO - 2018-06-11 21:52:49 --> Loader Class Initialized
INFO - 2018-06-11 21:52:49 --> Helper loaded: url_helper
INFO - 2018-06-11 21:52:49 --> Helper loaded: form_helper
INFO - 2018-06-11 21:52:49 --> Helper loaded: language_helper
DEBUG - 2018-06-11 21:52:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 21:52:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 21:52:49 --> User Agent Class Initialized
INFO - 2018-06-11 21:52:49 --> Controller Class Initialized
INFO - 2018-06-11 21:52:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 21:52:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 21:52:49 --> Pixel_Model class loaded
INFO - 2018-06-11 21:52:49 --> Database Driver Class Initialized
INFO - 2018-06-11 21:52:49 --> Model "QuestionsModel" initialized
INFO - 2018-06-11 21:52:49 --> Config Class Initialized
INFO - 2018-06-11 21:52:49 --> Hooks Class Initialized
DEBUG - 2018-06-11 21:52:49 --> UTF-8 Support Enabled
INFO - 2018-06-11 21:52:49 --> Utf8 Class Initialized
INFO - 2018-06-11 21:52:49 --> URI Class Initialized
INFO - 2018-06-11 21:52:49 --> Router Class Initialized
INFO - 2018-06-11 21:52:49 --> Output Class Initialized
INFO - 2018-06-11 21:52:49 --> Security Class Initialized
DEBUG - 2018-06-11 21:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 21:52:49 --> CSRF cookie sent
INFO - 2018-06-11 21:52:49 --> Input Class Initialized
INFO - 2018-06-11 21:52:49 --> Language Class Initialized
INFO - 2018-06-11 21:52:49 --> Loader Class Initialized
INFO - 2018-06-11 21:52:49 --> Helper loaded: url_helper
INFO - 2018-06-11 21:52:49 --> Helper loaded: form_helper
INFO - 2018-06-11 21:52:49 --> Helper loaded: language_helper
DEBUG - 2018-06-11 21:52:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 21:52:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 21:52:49 --> User Agent Class Initialized
INFO - 2018-06-11 21:52:49 --> Controller Class Initialized
INFO - 2018-06-11 21:52:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 21:52:49 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-11 21:52:49 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-06-11 21:52:49 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 21:52:49 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 21:52:49 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 21:52:49 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-06-11 21:52:49 --> Could not find the language line "req_email"
INFO - 2018-06-11 21:52:49 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-06-11 21:52:49 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 21:52:49 --> Final output sent to browser
DEBUG - 2018-06-11 21:52:49 --> Total execution time: 0.4299
INFO - 2018-06-11 21:53:45 --> Config Class Initialized
INFO - 2018-06-11 21:53:45 --> Hooks Class Initialized
DEBUG - 2018-06-11 21:53:45 --> UTF-8 Support Enabled
INFO - 2018-06-11 21:53:45 --> Utf8 Class Initialized
INFO - 2018-06-11 21:53:45 --> URI Class Initialized
INFO - 2018-06-11 21:53:45 --> Router Class Initialized
INFO - 2018-06-11 21:53:45 --> Output Class Initialized
INFO - 2018-06-11 21:53:45 --> Security Class Initialized
DEBUG - 2018-06-11 21:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 21:53:45 --> CSRF cookie sent
INFO - 2018-06-11 21:53:45 --> CSRF token verified
INFO - 2018-06-11 21:53:45 --> Input Class Initialized
INFO - 2018-06-11 21:53:45 --> Language Class Initialized
INFO - 2018-06-11 21:53:45 --> Loader Class Initialized
INFO - 2018-06-11 21:53:45 --> Helper loaded: url_helper
INFO - 2018-06-11 21:53:45 --> Helper loaded: form_helper
INFO - 2018-06-11 21:53:45 --> Helper loaded: language_helper
DEBUG - 2018-06-11 21:53:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 21:53:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 21:53:45 --> User Agent Class Initialized
INFO - 2018-06-11 21:53:45 --> Controller Class Initialized
INFO - 2018-06-11 21:53:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 21:53:45 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-11 21:53:45 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-06-11 21:53:46 --> Form Validation Class Initialized
INFO - 2018-06-11 21:53:46 --> Pixel_Model class loaded
INFO - 2018-06-11 21:53:46 --> Database Driver Class Initialized
INFO - 2018-06-11 21:53:46 --> Model "AuthenticationModel" initialized
INFO - 2018-06-11 21:53:46 --> Config Class Initialized
INFO - 2018-06-11 21:53:46 --> Hooks Class Initialized
DEBUG - 2018-06-11 21:53:46 --> UTF-8 Support Enabled
INFO - 2018-06-11 21:53:46 --> Utf8 Class Initialized
INFO - 2018-06-11 21:53:46 --> URI Class Initialized
INFO - 2018-06-11 21:53:46 --> Router Class Initialized
INFO - 2018-06-11 21:53:46 --> Output Class Initialized
INFO - 2018-06-11 21:53:46 --> Security Class Initialized
DEBUG - 2018-06-11 21:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 21:53:46 --> CSRF cookie sent
INFO - 2018-06-11 21:53:46 --> Input Class Initialized
INFO - 2018-06-11 21:53:46 --> Language Class Initialized
INFO - 2018-06-11 21:53:46 --> Loader Class Initialized
INFO - 2018-06-11 21:53:46 --> Helper loaded: url_helper
INFO - 2018-06-11 21:53:46 --> Helper loaded: form_helper
INFO - 2018-06-11 21:53:46 --> Helper loaded: language_helper
DEBUG - 2018-06-11 21:53:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 21:53:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 21:53:46 --> User Agent Class Initialized
INFO - 2018-06-11 21:53:46 --> Controller Class Initialized
INFO - 2018-06-11 21:53:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 21:53:46 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-11 21:53:46 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-06-11 21:53:46 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 21:53:46 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 21:53:46 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 21:53:46 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 21:53:46 --> File loaded: E:\www\yacopoo\application\views\shared/_soft_error.php
ERROR - 2018-06-11 21:53:46 --> Could not find the language line "req_email"
INFO - 2018-06-11 21:53:46 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-06-11 21:53:46 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 21:53:46 --> Final output sent to browser
DEBUG - 2018-06-11 21:53:46 --> Total execution time: 0.3884
INFO - 2018-06-11 21:53:53 --> Config Class Initialized
INFO - 2018-06-11 21:53:53 --> Hooks Class Initialized
DEBUG - 2018-06-11 21:53:53 --> UTF-8 Support Enabled
INFO - 2018-06-11 21:53:53 --> Utf8 Class Initialized
INFO - 2018-06-11 21:53:53 --> URI Class Initialized
INFO - 2018-06-11 21:53:53 --> Router Class Initialized
INFO - 2018-06-11 21:53:53 --> Output Class Initialized
INFO - 2018-06-11 21:53:53 --> Security Class Initialized
DEBUG - 2018-06-11 21:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 21:53:53 --> CSRF cookie sent
INFO - 2018-06-11 21:53:53 --> CSRF token verified
INFO - 2018-06-11 21:53:53 --> Input Class Initialized
INFO - 2018-06-11 21:53:53 --> Language Class Initialized
INFO - 2018-06-11 21:53:53 --> Loader Class Initialized
INFO - 2018-06-11 21:53:53 --> Helper loaded: url_helper
INFO - 2018-06-11 21:53:53 --> Helper loaded: form_helper
INFO - 2018-06-11 21:53:53 --> Helper loaded: language_helper
DEBUG - 2018-06-11 21:53:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 21:53:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 21:53:53 --> User Agent Class Initialized
INFO - 2018-06-11 21:53:53 --> Controller Class Initialized
INFO - 2018-06-11 21:53:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 21:53:53 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-11 21:53:53 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-06-11 21:53:53 --> Config Class Initialized
INFO - 2018-06-11 21:53:54 --> Hooks Class Initialized
DEBUG - 2018-06-11 21:53:54 --> UTF-8 Support Enabled
INFO - 2018-06-11 21:53:54 --> Utf8 Class Initialized
INFO - 2018-06-11 21:53:54 --> URI Class Initialized
INFO - 2018-06-11 21:53:54 --> Router Class Initialized
INFO - 2018-06-11 21:53:54 --> Output Class Initialized
INFO - 2018-06-11 21:53:54 --> Security Class Initialized
DEBUG - 2018-06-11 21:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 21:53:54 --> CSRF cookie sent
INFO - 2018-06-11 21:53:54 --> Input Class Initialized
INFO - 2018-06-11 21:53:54 --> Language Class Initialized
INFO - 2018-06-11 21:53:54 --> Loader Class Initialized
INFO - 2018-06-11 21:53:54 --> Helper loaded: url_helper
INFO - 2018-06-11 21:53:54 --> Helper loaded: form_helper
INFO - 2018-06-11 21:53:54 --> Helper loaded: language_helper
DEBUG - 2018-06-11 21:53:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 21:53:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 21:53:54 --> User Agent Class Initialized
INFO - 2018-06-11 21:53:54 --> Controller Class Initialized
INFO - 2018-06-11 21:53:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 21:53:54 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-11 21:53:54 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-06-11 21:53:54 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 21:53:54 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 21:53:54 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 21:53:54 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 21:53:54 --> File loaded: E:\www\yacopoo\application\views\shared/_soft_error.php
ERROR - 2018-06-11 21:53:54 --> Could not find the language line "req_email"
INFO - 2018-06-11 21:53:54 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-06-11 21:53:54 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 21:53:54 --> Final output sent to browser
DEBUG - 2018-06-11 21:53:54 --> Total execution time: 0.3924
INFO - 2018-06-11 21:54:06 --> Config Class Initialized
INFO - 2018-06-11 21:54:06 --> Hooks Class Initialized
DEBUG - 2018-06-11 21:54:06 --> UTF-8 Support Enabled
INFO - 2018-06-11 21:54:06 --> Utf8 Class Initialized
INFO - 2018-06-11 21:54:06 --> URI Class Initialized
INFO - 2018-06-11 21:54:06 --> Router Class Initialized
INFO - 2018-06-11 21:54:07 --> Output Class Initialized
INFO - 2018-06-11 21:54:07 --> Security Class Initialized
DEBUG - 2018-06-11 21:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 21:54:07 --> CSRF cookie sent
INFO - 2018-06-11 21:54:07 --> CSRF token verified
INFO - 2018-06-11 21:54:07 --> Input Class Initialized
INFO - 2018-06-11 21:54:07 --> Language Class Initialized
INFO - 2018-06-11 21:54:07 --> Loader Class Initialized
INFO - 2018-06-11 21:54:07 --> Helper loaded: url_helper
INFO - 2018-06-11 21:54:07 --> Helper loaded: form_helper
INFO - 2018-06-11 21:54:07 --> Helper loaded: language_helper
DEBUG - 2018-06-11 21:54:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 21:54:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 21:54:07 --> User Agent Class Initialized
INFO - 2018-06-11 21:54:07 --> Controller Class Initialized
INFO - 2018-06-11 21:54:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 21:54:07 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-11 21:54:07 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-06-11 21:54:07 --> Form Validation Class Initialized
INFO - 2018-06-11 21:54:07 --> Pixel_Model class loaded
INFO - 2018-06-11 21:54:07 --> Database Driver Class Initialized
INFO - 2018-06-11 21:54:07 --> Model "AuthenticationModel" initialized
INFO - 2018-06-11 21:54:07 --> Config Class Initialized
INFO - 2018-06-11 21:54:07 --> Hooks Class Initialized
DEBUG - 2018-06-11 21:54:07 --> UTF-8 Support Enabled
INFO - 2018-06-11 21:54:07 --> Utf8 Class Initialized
INFO - 2018-06-11 21:54:07 --> URI Class Initialized
INFO - 2018-06-11 21:54:07 --> Router Class Initialized
INFO - 2018-06-11 21:54:07 --> Output Class Initialized
INFO - 2018-06-11 21:54:07 --> Security Class Initialized
DEBUG - 2018-06-11 21:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 21:54:07 --> CSRF cookie sent
INFO - 2018-06-11 21:54:07 --> Input Class Initialized
INFO - 2018-06-11 21:54:07 --> Language Class Initialized
INFO - 2018-06-11 21:54:07 --> Loader Class Initialized
INFO - 2018-06-11 21:54:07 --> Helper loaded: url_helper
INFO - 2018-06-11 21:54:07 --> Helper loaded: form_helper
INFO - 2018-06-11 21:54:07 --> Helper loaded: language_helper
DEBUG - 2018-06-11 21:54:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 21:54:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 21:54:08 --> User Agent Class Initialized
INFO - 2018-06-11 21:54:08 --> Controller Class Initialized
INFO - 2018-06-11 21:54:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 21:54:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 21:54:08 --> Pixel_Model class loaded
INFO - 2018-06-11 21:54:08 --> Database Driver Class Initialized
INFO - 2018-06-11 21:54:08 --> Model "MyAccountModel" initialized
INFO - 2018-06-11 21:54:08 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 21:54:08 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-06-11 21:54:08 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 21:54:08 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 21:54:08 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 21:54:08 --> File loaded: E:\www\yacopoo\application\views\myaccount/application_list.php
INFO - 2018-06-11 21:54:08 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 21:54:08 --> Final output sent to browser
DEBUG - 2018-06-11 21:54:08 --> Total execution time: 0.5237
INFO - 2018-06-11 21:54:10 --> Config Class Initialized
INFO - 2018-06-11 21:54:10 --> Hooks Class Initialized
DEBUG - 2018-06-11 21:54:10 --> UTF-8 Support Enabled
INFO - 2018-06-11 21:54:10 --> Utf8 Class Initialized
INFO - 2018-06-11 21:54:10 --> URI Class Initialized
INFO - 2018-06-11 21:54:10 --> Router Class Initialized
INFO - 2018-06-11 21:54:10 --> Output Class Initialized
INFO - 2018-06-11 21:54:10 --> Security Class Initialized
DEBUG - 2018-06-11 21:54:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 21:54:10 --> CSRF cookie sent
INFO - 2018-06-11 21:54:10 --> Input Class Initialized
INFO - 2018-06-11 21:54:10 --> Language Class Initialized
INFO - 2018-06-11 21:54:10 --> Loader Class Initialized
INFO - 2018-06-11 21:54:10 --> Helper loaded: url_helper
INFO - 2018-06-11 21:54:10 --> Helper loaded: form_helper
INFO - 2018-06-11 21:54:10 --> Helper loaded: language_helper
DEBUG - 2018-06-11 21:54:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 21:54:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 21:54:10 --> User Agent Class Initialized
INFO - 2018-06-11 21:54:10 --> Controller Class Initialized
INFO - 2018-06-11 21:54:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 21:54:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 21:54:10 --> Pixel_Model class loaded
INFO - 2018-06-11 21:54:10 --> Database Driver Class Initialized
INFO - 2018-06-11 21:54:10 --> Model "MyAccountModel" initialized
INFO - 2018-06-11 21:54:10 --> Config Class Initialized
INFO - 2018-06-11 21:54:10 --> Hooks Class Initialized
DEBUG - 2018-06-11 21:54:10 --> UTF-8 Support Enabled
INFO - 2018-06-11 21:54:10 --> Utf8 Class Initialized
INFO - 2018-06-11 21:54:10 --> URI Class Initialized
INFO - 2018-06-11 21:54:10 --> Router Class Initialized
INFO - 2018-06-11 21:54:10 --> Output Class Initialized
INFO - 2018-06-11 21:54:10 --> Security Class Initialized
DEBUG - 2018-06-11 21:54:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 21:54:10 --> CSRF cookie sent
INFO - 2018-06-11 21:54:10 --> Input Class Initialized
INFO - 2018-06-11 21:54:10 --> Language Class Initialized
INFO - 2018-06-11 21:54:10 --> Loader Class Initialized
INFO - 2018-06-11 21:54:10 --> Helper loaded: url_helper
INFO - 2018-06-11 21:54:10 --> Helper loaded: form_helper
INFO - 2018-06-11 21:54:10 --> Helper loaded: language_helper
DEBUG - 2018-06-11 21:54:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 21:54:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 21:54:10 --> User Agent Class Initialized
INFO - 2018-06-11 21:54:11 --> Controller Class Initialized
INFO - 2018-06-11 21:54:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 21:54:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 21:54:11 --> Pixel_Model class loaded
INFO - 2018-06-11 21:54:11 --> Database Driver Class Initialized
INFO - 2018-06-11 21:54:11 --> Model "QuestionsModel" initialized
INFO - 2018-06-11 21:54:11 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 21:54:11 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-06-11 21:54:11 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 21:54:11 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-06-11 21:54:11 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 21:54:11 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 21:54:11 --> File loaded: E:\www\yacopoo\application\views\shared/_bar.php
INFO - 2018-06-11 21:54:11 --> File loaded: E:\www\yacopoo\application\views\shared/_buttons.php
INFO - 2018-06-11 21:54:11 --> File loaded: E:\www\yacopoo\application\views\questions/relation_ship_status.php
INFO - 2018-06-11 21:54:11 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 21:54:11 --> Final output sent to browser
DEBUG - 2018-06-11 21:54:11 --> Total execution time: 0.4735
INFO - 2018-06-11 21:54:19 --> Config Class Initialized
INFO - 2018-06-11 21:54:19 --> Hooks Class Initialized
DEBUG - 2018-06-11 21:54:19 --> UTF-8 Support Enabled
INFO - 2018-06-11 21:54:19 --> Utf8 Class Initialized
INFO - 2018-06-11 21:54:19 --> URI Class Initialized
INFO - 2018-06-11 21:54:19 --> Router Class Initialized
INFO - 2018-06-11 21:54:19 --> Output Class Initialized
INFO - 2018-06-11 21:54:19 --> Security Class Initialized
DEBUG - 2018-06-11 21:54:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 21:54:20 --> CSRF cookie sent
INFO - 2018-06-11 21:54:20 --> Input Class Initialized
INFO - 2018-06-11 21:54:20 --> Language Class Initialized
INFO - 2018-06-11 21:54:20 --> Loader Class Initialized
INFO - 2018-06-11 21:54:20 --> Helper loaded: url_helper
INFO - 2018-06-11 21:54:20 --> Helper loaded: form_helper
INFO - 2018-06-11 21:54:20 --> Helper loaded: language_helper
DEBUG - 2018-06-11 21:54:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 21:54:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 21:54:20 --> User Agent Class Initialized
INFO - 2018-06-11 21:54:20 --> Controller Class Initialized
INFO - 2018-06-11 21:54:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 21:54:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 21:54:20 --> Pixel_Model class loaded
INFO - 2018-06-11 21:54:20 --> Database Driver Class Initialized
INFO - 2018-06-11 21:54:20 --> Model "QuestionsModel" initialized
INFO - 2018-06-11 21:54:20 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 21:54:20 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-06-11 21:54:20 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 21:54:20 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 21:54:20 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 21:54:20 --> File loaded: E:\www\yacopoo\application\views\shared/_bar.php
INFO - 2018-06-11 21:54:20 --> File loaded: E:\www\yacopoo\application\views\shared/_buttons.php
INFO - 2018-06-11 21:54:20 --> File loaded: E:\www\yacopoo\application\views\questions/start_questions.php
INFO - 2018-06-11 21:54:20 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 21:54:20 --> Final output sent to browser
DEBUG - 2018-06-11 21:54:20 --> Total execution time: 0.4672
INFO - 2018-06-11 21:54:43 --> Config Class Initialized
INFO - 2018-06-11 21:54:43 --> Hooks Class Initialized
DEBUG - 2018-06-11 21:54:43 --> UTF-8 Support Enabled
INFO - 2018-06-11 21:54:43 --> Utf8 Class Initialized
INFO - 2018-06-11 21:54:43 --> URI Class Initialized
INFO - 2018-06-11 21:54:43 --> Router Class Initialized
INFO - 2018-06-11 21:54:43 --> Output Class Initialized
INFO - 2018-06-11 21:54:43 --> Security Class Initialized
DEBUG - 2018-06-11 21:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 21:54:43 --> CSRF cookie sent
INFO - 2018-06-11 21:54:43 --> Input Class Initialized
INFO - 2018-06-11 21:54:43 --> Language Class Initialized
ERROR - 2018-06-11 21:54:43 --> 404 Page Not Found: Assets/css
INFO - 2018-06-11 21:55:06 --> Config Class Initialized
INFO - 2018-06-11 21:55:06 --> Hooks Class Initialized
DEBUG - 2018-06-11 21:55:06 --> UTF-8 Support Enabled
INFO - 2018-06-11 21:55:06 --> Utf8 Class Initialized
INFO - 2018-06-11 21:55:06 --> URI Class Initialized
INFO - 2018-06-11 21:55:06 --> Router Class Initialized
INFO - 2018-06-11 21:55:06 --> Output Class Initialized
INFO - 2018-06-11 21:55:06 --> Security Class Initialized
DEBUG - 2018-06-11 21:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 21:55:06 --> CSRF cookie sent
INFO - 2018-06-11 21:55:06 --> CSRF token verified
INFO - 2018-06-11 21:55:06 --> Input Class Initialized
INFO - 2018-06-11 21:55:06 --> Language Class Initialized
INFO - 2018-06-11 21:55:06 --> Loader Class Initialized
INFO - 2018-06-11 21:55:06 --> Helper loaded: url_helper
INFO - 2018-06-11 21:55:06 --> Helper loaded: form_helper
INFO - 2018-06-11 21:55:06 --> Helper loaded: language_helper
DEBUG - 2018-06-11 21:55:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 21:55:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 21:55:06 --> User Agent Class Initialized
INFO - 2018-06-11 21:55:06 --> Controller Class Initialized
INFO - 2018-06-11 21:55:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 21:55:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 21:55:06 --> Pixel_Model class loaded
INFO - 2018-06-11 21:55:06 --> Database Driver Class Initialized
INFO - 2018-06-11 21:55:06 --> Model "QuestionsModel" initialized
INFO - 2018-06-11 21:55:06 --> Form Validation Class Initialized
INFO - 2018-06-11 21:55:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-11 21:55:06 --> Config Class Initialized
INFO - 2018-06-11 21:55:06 --> Hooks Class Initialized
DEBUG - 2018-06-11 21:55:06 --> UTF-8 Support Enabled
INFO - 2018-06-11 21:55:06 --> Utf8 Class Initialized
INFO - 2018-06-11 21:55:06 --> URI Class Initialized
INFO - 2018-06-11 21:55:07 --> Router Class Initialized
INFO - 2018-06-11 21:55:07 --> Output Class Initialized
INFO - 2018-06-11 21:55:07 --> Security Class Initialized
DEBUG - 2018-06-11 21:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 21:55:07 --> CSRF cookie sent
INFO - 2018-06-11 21:55:07 --> Input Class Initialized
INFO - 2018-06-11 21:55:07 --> Language Class Initialized
INFO - 2018-06-11 21:55:07 --> Loader Class Initialized
INFO - 2018-06-11 21:55:07 --> Helper loaded: url_helper
INFO - 2018-06-11 21:55:07 --> Helper loaded: form_helper
INFO - 2018-06-11 21:55:07 --> Helper loaded: language_helper
DEBUG - 2018-06-11 21:55:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 21:55:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 21:55:07 --> User Agent Class Initialized
INFO - 2018-06-11 21:55:07 --> Controller Class Initialized
INFO - 2018-06-11 21:55:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 21:55:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 21:55:07 --> Pixel_Model class loaded
INFO - 2018-06-11 21:55:07 --> Database Driver Class Initialized
INFO - 2018-06-11 21:55:07 --> Model "QuestionsModel" initialized
INFO - 2018-06-11 21:55:07 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 21:55:07 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-06-11 21:55:07 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 21:55:07 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner.php
INFO - 2018-06-11 21:55:07 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 21:55:07 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 21:55:07 --> File loaded: E:\www\yacopoo\application\views\shared/_bar.php
INFO - 2018-06-11 21:55:07 --> File loaded: E:\www\yacopoo\application\views\shared/_buttons.php
INFO - 2018-06-11 21:55:07 --> File loaded: E:\www\yacopoo\application\views\questions/relation_ship_status.php
INFO - 2018-06-11 21:55:07 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 21:55:07 --> Final output sent to browser
DEBUG - 2018-06-11 21:55:07 --> Total execution time: 0.4745
INFO - 2018-06-11 21:55:07 --> Config Class Initialized
INFO - 2018-06-11 21:55:07 --> Hooks Class Initialized
DEBUG - 2018-06-11 21:55:07 --> UTF-8 Support Enabled
INFO - 2018-06-11 21:55:07 --> Utf8 Class Initialized
INFO - 2018-06-11 21:55:07 --> URI Class Initialized
INFO - 2018-06-11 21:55:07 --> Router Class Initialized
INFO - 2018-06-11 21:55:07 --> Output Class Initialized
INFO - 2018-06-11 21:55:07 --> Security Class Initialized
DEBUG - 2018-06-11 21:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 21:55:07 --> CSRF cookie sent
INFO - 2018-06-11 21:55:07 --> Input Class Initialized
INFO - 2018-06-11 21:55:08 --> Language Class Initialized
ERROR - 2018-06-11 21:55:08 --> 404 Page Not Found: Assets/css
INFO - 2018-06-11 21:55:19 --> Config Class Initialized
INFO - 2018-06-11 21:55:19 --> Hooks Class Initialized
DEBUG - 2018-06-11 21:55:19 --> UTF-8 Support Enabled
INFO - 2018-06-11 21:55:19 --> Utf8 Class Initialized
INFO - 2018-06-11 21:55:19 --> URI Class Initialized
INFO - 2018-06-11 21:55:19 --> Router Class Initialized
INFO - 2018-06-11 21:55:19 --> Output Class Initialized
INFO - 2018-06-11 21:55:19 --> Security Class Initialized
DEBUG - 2018-06-11 21:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 21:55:19 --> CSRF cookie sent
INFO - 2018-06-11 21:55:19 --> CSRF token verified
INFO - 2018-06-11 21:55:19 --> Input Class Initialized
INFO - 2018-06-11 21:55:19 --> Language Class Initialized
INFO - 2018-06-11 21:55:19 --> Loader Class Initialized
INFO - 2018-06-11 21:55:19 --> Helper loaded: url_helper
INFO - 2018-06-11 21:55:19 --> Helper loaded: form_helper
INFO - 2018-06-11 21:55:19 --> Helper loaded: language_helper
DEBUG - 2018-06-11 21:55:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 21:55:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 21:55:19 --> User Agent Class Initialized
INFO - 2018-06-11 21:55:19 --> Controller Class Initialized
INFO - 2018-06-11 21:55:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 21:55:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 21:55:19 --> Pixel_Model class loaded
INFO - 2018-06-11 21:55:19 --> Database Driver Class Initialized
INFO - 2018-06-11 21:55:19 --> Model "QuestionsModel" initialized
INFO - 2018-06-11 21:55:19 --> Form Validation Class Initialized
INFO - 2018-06-11 21:55:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-11 21:55:19 --> Config Class Initialized
INFO - 2018-06-11 21:55:19 --> Hooks Class Initialized
DEBUG - 2018-06-11 21:55:19 --> UTF-8 Support Enabled
INFO - 2018-06-11 21:55:19 --> Utf8 Class Initialized
INFO - 2018-06-11 21:55:19 --> URI Class Initialized
INFO - 2018-06-11 21:55:19 --> Router Class Initialized
INFO - 2018-06-11 21:55:19 --> Output Class Initialized
INFO - 2018-06-11 21:55:19 --> Security Class Initialized
DEBUG - 2018-06-11 21:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 21:55:19 --> CSRF cookie sent
INFO - 2018-06-11 21:55:19 --> Input Class Initialized
INFO - 2018-06-11 21:55:19 --> Language Class Initialized
INFO - 2018-06-11 21:55:19 --> Loader Class Initialized
INFO - 2018-06-11 21:55:19 --> Helper loaded: url_helper
INFO - 2018-06-11 21:55:19 --> Helper loaded: form_helper
INFO - 2018-06-11 21:55:19 --> Helper loaded: language_helper
DEBUG - 2018-06-11 21:55:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 21:55:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 21:55:19 --> User Agent Class Initialized
INFO - 2018-06-11 21:55:19 --> Controller Class Initialized
INFO - 2018-06-11 21:55:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 21:55:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 21:55:19 --> Pixel_Model class loaded
INFO - 2018-06-11 21:55:19 --> Database Driver Class Initialized
INFO - 2018-06-11 21:55:19 --> Model "QuestionsModel" initialized
INFO - 2018-06-11 21:55:19 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 21:55:19 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-06-11 21:55:19 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 21:55:19 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 21:55:19 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 21:55:19 --> File loaded: E:\www\yacopoo\application\views\shared/_bar.php
INFO - 2018-06-11 21:55:19 --> File loaded: E:\www\yacopoo\application\views\shared/_buttons.php
INFO - 2018-06-11 21:55:19 --> File loaded: E:\www\yacopoo\application\views\questions/income.php
INFO - 2018-06-11 21:55:19 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 21:55:19 --> Final output sent to browser
DEBUG - 2018-06-11 21:55:19 --> Total execution time: 0.4610
INFO - 2018-06-11 21:55:20 --> Config Class Initialized
INFO - 2018-06-11 21:55:20 --> Hooks Class Initialized
DEBUG - 2018-06-11 21:55:20 --> UTF-8 Support Enabled
INFO - 2018-06-11 21:55:20 --> Utf8 Class Initialized
INFO - 2018-06-11 21:55:20 --> URI Class Initialized
INFO - 2018-06-11 21:55:20 --> Router Class Initialized
INFO - 2018-06-11 21:55:20 --> Output Class Initialized
INFO - 2018-06-11 21:55:20 --> Security Class Initialized
DEBUG - 2018-06-11 21:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 21:55:20 --> CSRF cookie sent
INFO - 2018-06-11 21:55:20 --> Input Class Initialized
INFO - 2018-06-11 21:55:20 --> Language Class Initialized
ERROR - 2018-06-11 21:55:20 --> 404 Page Not Found: Assets/css
INFO - 2018-06-11 21:55:45 --> Config Class Initialized
INFO - 2018-06-11 21:55:45 --> Hooks Class Initialized
DEBUG - 2018-06-11 21:55:45 --> UTF-8 Support Enabled
INFO - 2018-06-11 21:55:45 --> Utf8 Class Initialized
INFO - 2018-06-11 21:55:45 --> URI Class Initialized
INFO - 2018-06-11 21:55:45 --> Router Class Initialized
INFO - 2018-06-11 21:55:45 --> Output Class Initialized
INFO - 2018-06-11 21:55:45 --> Security Class Initialized
DEBUG - 2018-06-11 21:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 21:55:45 --> CSRF cookie sent
INFO - 2018-06-11 21:55:45 --> CSRF token verified
INFO - 2018-06-11 21:55:45 --> Input Class Initialized
INFO - 2018-06-11 21:55:45 --> Language Class Initialized
INFO - 2018-06-11 21:55:45 --> Loader Class Initialized
INFO - 2018-06-11 21:55:45 --> Helper loaded: url_helper
INFO - 2018-06-11 21:55:45 --> Helper loaded: form_helper
INFO - 2018-06-11 21:55:45 --> Helper loaded: language_helper
DEBUG - 2018-06-11 21:55:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 21:55:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 21:55:45 --> User Agent Class Initialized
INFO - 2018-06-11 21:55:45 --> Controller Class Initialized
INFO - 2018-06-11 21:55:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 21:55:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 21:55:45 --> Pixel_Model class loaded
INFO - 2018-06-11 21:55:45 --> Database Driver Class Initialized
INFO - 2018-06-11 21:55:45 --> Model "QuestionsModel" initialized
INFO - 2018-06-11 21:55:45 --> Form Validation Class Initialized
INFO - 2018-06-11 21:55:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-11 21:55:45 --> Database Driver Class Initialized
INFO - 2018-06-11 21:55:45 --> Model "QuestionsModel" initialized
INFO - 2018-06-11 21:55:45 --> Config Class Initialized
INFO - 2018-06-11 21:55:45 --> Hooks Class Initialized
DEBUG - 2018-06-11 21:55:45 --> UTF-8 Support Enabled
INFO - 2018-06-11 21:55:45 --> Utf8 Class Initialized
INFO - 2018-06-11 21:55:45 --> URI Class Initialized
INFO - 2018-06-11 21:55:45 --> Router Class Initialized
INFO - 2018-06-11 21:55:45 --> Output Class Initialized
INFO - 2018-06-11 21:55:45 --> Security Class Initialized
DEBUG - 2018-06-11 21:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 21:55:45 --> CSRF cookie sent
INFO - 2018-06-11 21:55:45 --> Input Class Initialized
INFO - 2018-06-11 21:55:45 --> Language Class Initialized
INFO - 2018-06-11 21:55:45 --> Loader Class Initialized
INFO - 2018-06-11 21:55:45 --> Helper loaded: url_helper
INFO - 2018-06-11 21:55:45 --> Helper loaded: form_helper
INFO - 2018-06-11 21:55:45 --> Helper loaded: language_helper
DEBUG - 2018-06-11 21:55:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 21:55:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 21:55:45 --> User Agent Class Initialized
INFO - 2018-06-11 21:55:46 --> Controller Class Initialized
INFO - 2018-06-11 21:55:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 21:55:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 21:55:46 --> Pixel_Model class loaded
INFO - 2018-06-11 21:55:46 --> Database Driver Class Initialized
INFO - 2018-06-11 21:55:46 --> Model "QuestionsModel" initialized
INFO - 2018-06-11 21:55:46 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 21:55:46 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-06-11 21:55:46 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 21:55:46 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 21:55:46 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 21:55:46 --> File loaded: E:\www\yacopoo\application\views\shared/_buttons.php
INFO - 2018-06-11 21:55:46 --> File loaded: E:\www\yacopoo\application\views\questions/cohabitation.php
INFO - 2018-06-11 21:55:46 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 21:55:46 --> Final output sent to browser
DEBUG - 2018-06-11 21:55:46 --> Total execution time: 0.4744
INFO - 2018-06-11 21:55:46 --> Config Class Initialized
INFO - 2018-06-11 21:55:46 --> Hooks Class Initialized
DEBUG - 2018-06-11 21:55:46 --> UTF-8 Support Enabled
INFO - 2018-06-11 21:55:46 --> Utf8 Class Initialized
INFO - 2018-06-11 21:55:46 --> URI Class Initialized
INFO - 2018-06-11 21:55:46 --> Router Class Initialized
INFO - 2018-06-11 21:55:46 --> Output Class Initialized
INFO - 2018-06-11 21:55:46 --> Security Class Initialized
DEBUG - 2018-06-11 21:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 21:55:46 --> CSRF cookie sent
INFO - 2018-06-11 21:55:46 --> Input Class Initialized
INFO - 2018-06-11 21:55:46 --> Language Class Initialized
ERROR - 2018-06-11 21:55:46 --> 404 Page Not Found: Assets/css
INFO - 2018-06-11 21:56:07 --> Config Class Initialized
INFO - 2018-06-11 21:56:07 --> Hooks Class Initialized
DEBUG - 2018-06-11 21:56:07 --> UTF-8 Support Enabled
INFO - 2018-06-11 21:56:07 --> Utf8 Class Initialized
INFO - 2018-06-11 21:56:07 --> URI Class Initialized
DEBUG - 2018-06-11 21:56:07 --> No URI present. Default controller set.
INFO - 2018-06-11 21:56:07 --> Router Class Initialized
INFO - 2018-06-11 21:56:07 --> Output Class Initialized
INFO - 2018-06-11 21:56:07 --> Security Class Initialized
DEBUG - 2018-06-11 21:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 21:56:07 --> CSRF cookie sent
INFO - 2018-06-11 21:56:07 --> Input Class Initialized
INFO - 2018-06-11 21:56:07 --> Language Class Initialized
INFO - 2018-06-11 21:56:07 --> Loader Class Initialized
INFO - 2018-06-11 21:56:07 --> Helper loaded: url_helper
INFO - 2018-06-11 21:56:07 --> Helper loaded: form_helper
INFO - 2018-06-11 21:56:07 --> Helper loaded: language_helper
DEBUG - 2018-06-11 21:56:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 21:56:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 21:56:07 --> User Agent Class Initialized
INFO - 2018-06-11 21:56:07 --> Controller Class Initialized
INFO - 2018-06-11 21:56:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 21:56:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 21:56:07 --> Pixel_Model class loaded
INFO - 2018-06-11 21:56:07 --> Database Driver Class Initialized
INFO - 2018-06-11 21:56:07 --> Model "QuestionsModel" initialized
INFO - 2018-06-11 21:56:07 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 21:56:07 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-06-11 21:56:07 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 21:56:08 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-06-11 21:56:08 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 21:56:08 --> Final output sent to browser
DEBUG - 2018-06-11 21:56:08 --> Total execution time: 0.4326
INFO - 2018-06-11 21:56:15 --> Config Class Initialized
INFO - 2018-06-11 21:56:15 --> Hooks Class Initialized
DEBUG - 2018-06-11 21:56:15 --> UTF-8 Support Enabled
INFO - 2018-06-11 21:56:15 --> Utf8 Class Initialized
INFO - 2018-06-11 21:56:15 --> URI Class Initialized
INFO - 2018-06-11 21:56:15 --> Router Class Initialized
INFO - 2018-06-11 21:56:15 --> Output Class Initialized
INFO - 2018-06-11 21:56:15 --> Security Class Initialized
DEBUG - 2018-06-11 21:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 21:56:15 --> CSRF cookie sent
INFO - 2018-06-11 21:56:15 --> Input Class Initialized
INFO - 2018-06-11 21:56:15 --> Language Class Initialized
INFO - 2018-06-11 21:56:15 --> Loader Class Initialized
INFO - 2018-06-11 21:56:15 --> Helper loaded: url_helper
INFO - 2018-06-11 21:56:15 --> Helper loaded: form_helper
INFO - 2018-06-11 21:56:15 --> Helper loaded: language_helper
DEBUG - 2018-06-11 21:56:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 21:56:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 21:56:15 --> User Agent Class Initialized
INFO - 2018-06-11 21:56:15 --> Controller Class Initialized
INFO - 2018-06-11 21:56:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 21:56:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 21:56:15 --> Pixel_Model class loaded
INFO - 2018-06-11 21:56:15 --> Database Driver Class Initialized
INFO - 2018-06-11 21:56:15 --> Model "MyAccountModel" initialized
INFO - 2018-06-11 21:56:15 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 21:56:15 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-06-11 21:56:15 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 21:56:15 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 21:56:15 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 21:56:15 --> File loaded: E:\www\yacopoo\application\views\myaccount/application_list.php
INFO - 2018-06-11 21:56:15 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 21:56:15 --> Final output sent to browser
DEBUG - 2018-06-11 21:56:15 --> Total execution time: 0.4553
INFO - 2018-06-11 21:56:17 --> Config Class Initialized
INFO - 2018-06-11 21:56:17 --> Hooks Class Initialized
DEBUG - 2018-06-11 21:56:17 --> UTF-8 Support Enabled
INFO - 2018-06-11 21:56:17 --> Utf8 Class Initialized
INFO - 2018-06-11 21:56:17 --> URI Class Initialized
INFO - 2018-06-11 21:56:17 --> Router Class Initialized
INFO - 2018-06-11 21:56:17 --> Output Class Initialized
INFO - 2018-06-11 21:56:17 --> Security Class Initialized
DEBUG - 2018-06-11 21:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 21:56:17 --> CSRF cookie sent
INFO - 2018-06-11 21:56:17 --> Input Class Initialized
INFO - 2018-06-11 21:56:17 --> Language Class Initialized
INFO - 2018-06-11 21:56:17 --> Loader Class Initialized
INFO - 2018-06-11 21:56:17 --> Helper loaded: url_helper
INFO - 2018-06-11 21:56:17 --> Helper loaded: form_helper
INFO - 2018-06-11 21:56:17 --> Helper loaded: language_helper
DEBUG - 2018-06-11 21:56:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 21:56:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 21:56:17 --> User Agent Class Initialized
INFO - 2018-06-11 21:56:17 --> Controller Class Initialized
INFO - 2018-06-11 21:56:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 21:56:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 21:56:17 --> Pixel_Model class loaded
INFO - 2018-06-11 21:56:17 --> Database Driver Class Initialized
INFO - 2018-06-11 21:56:17 --> Model "MyAccountModel" initialized
INFO - 2018-06-11 21:56:17 --> Config Class Initialized
INFO - 2018-06-11 21:56:17 --> Hooks Class Initialized
DEBUG - 2018-06-11 21:56:17 --> UTF-8 Support Enabled
INFO - 2018-06-11 21:56:17 --> Utf8 Class Initialized
INFO - 2018-06-11 21:56:17 --> URI Class Initialized
INFO - 2018-06-11 21:56:17 --> Router Class Initialized
INFO - 2018-06-11 21:56:17 --> Output Class Initialized
INFO - 2018-06-11 21:56:17 --> Security Class Initialized
DEBUG - 2018-06-11 21:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 21:56:17 --> CSRF cookie sent
INFO - 2018-06-11 21:56:17 --> Input Class Initialized
INFO - 2018-06-11 21:56:17 --> Language Class Initialized
INFO - 2018-06-11 21:56:17 --> Loader Class Initialized
INFO - 2018-06-11 21:56:17 --> Helper loaded: url_helper
INFO - 2018-06-11 21:56:17 --> Helper loaded: form_helper
INFO - 2018-06-11 21:56:17 --> Helper loaded: language_helper
DEBUG - 2018-06-11 21:56:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 21:56:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 21:56:17 --> User Agent Class Initialized
INFO - 2018-06-11 21:56:17 --> Controller Class Initialized
INFO - 2018-06-11 21:56:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 21:56:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 21:56:17 --> Pixel_Model class loaded
INFO - 2018-06-11 21:56:18 --> Database Driver Class Initialized
INFO - 2018-06-11 21:56:18 --> Model "QuestionsModel" initialized
INFO - 2018-06-11 21:56:18 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 21:56:18 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-06-11 21:56:18 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 21:56:18 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 21:56:18 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 21:56:18 --> File loaded: E:\www\yacopoo\application\views\shared/_buttons.php
INFO - 2018-06-11 21:56:18 --> File loaded: E:\www\yacopoo\application\views\questions/cohabitation.php
INFO - 2018-06-11 21:56:18 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 21:56:18 --> Final output sent to browser
DEBUG - 2018-06-11 21:56:18 --> Total execution time: 0.4655
INFO - 2018-06-11 21:56:24 --> Config Class Initialized
INFO - 2018-06-11 21:56:24 --> Hooks Class Initialized
DEBUG - 2018-06-11 21:56:24 --> UTF-8 Support Enabled
INFO - 2018-06-11 21:56:24 --> Utf8 Class Initialized
INFO - 2018-06-11 21:56:24 --> URI Class Initialized
INFO - 2018-06-11 21:56:24 --> Router Class Initialized
INFO - 2018-06-11 21:56:24 --> Output Class Initialized
INFO - 2018-06-11 21:56:24 --> Security Class Initialized
DEBUG - 2018-06-11 21:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 21:56:24 --> CSRF cookie sent
INFO - 2018-06-11 21:56:24 --> CSRF token verified
INFO - 2018-06-11 21:56:24 --> Input Class Initialized
INFO - 2018-06-11 21:56:24 --> Language Class Initialized
INFO - 2018-06-11 21:56:24 --> Loader Class Initialized
INFO - 2018-06-11 21:56:24 --> Helper loaded: url_helper
INFO - 2018-06-11 21:56:24 --> Helper loaded: form_helper
INFO - 2018-06-11 21:56:24 --> Helper loaded: language_helper
DEBUG - 2018-06-11 21:56:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 21:56:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 21:56:24 --> User Agent Class Initialized
INFO - 2018-06-11 21:56:24 --> Controller Class Initialized
INFO - 2018-06-11 21:56:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 21:56:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 21:56:24 --> Pixel_Model class loaded
INFO - 2018-06-11 21:56:24 --> Database Driver Class Initialized
INFO - 2018-06-11 21:56:24 --> Model "QuestionsModel" initialized
INFO - 2018-06-11 21:56:24 --> Form Validation Class Initialized
INFO - 2018-06-11 21:56:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-11 21:56:24 --> Database Driver Class Initialized
INFO - 2018-06-11 21:56:24 --> Model "QuestionsModel" initialized
INFO - 2018-06-11 21:56:24 --> Config Class Initialized
INFO - 2018-06-11 21:56:24 --> Hooks Class Initialized
DEBUG - 2018-06-11 21:56:24 --> UTF-8 Support Enabled
INFO - 2018-06-11 21:56:24 --> Utf8 Class Initialized
INFO - 2018-06-11 21:56:24 --> URI Class Initialized
INFO - 2018-06-11 21:56:24 --> Router Class Initialized
INFO - 2018-06-11 21:56:24 --> Output Class Initialized
INFO - 2018-06-11 21:56:24 --> Security Class Initialized
DEBUG - 2018-06-11 21:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 21:56:24 --> CSRF cookie sent
INFO - 2018-06-11 21:56:24 --> Input Class Initialized
INFO - 2018-06-11 21:56:24 --> Language Class Initialized
INFO - 2018-06-11 21:56:24 --> Loader Class Initialized
INFO - 2018-06-11 21:56:24 --> Helper loaded: url_helper
INFO - 2018-06-11 21:56:24 --> Helper loaded: form_helper
INFO - 2018-06-11 21:56:24 --> Helper loaded: language_helper
DEBUG - 2018-06-11 21:56:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 21:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 21:56:25 --> User Agent Class Initialized
INFO - 2018-06-11 21:56:25 --> Controller Class Initialized
INFO - 2018-06-11 21:56:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 21:56:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 21:56:25 --> Pixel_Model class loaded
INFO - 2018-06-11 21:56:25 --> Database Driver Class Initialized
INFO - 2018-06-11 21:56:25 --> Model "QuestionsModel" initialized
INFO - 2018-06-11 21:56:25 --> Database Driver Class Initialized
INFO - 2018-06-11 21:56:25 --> Model "QuestionsModel" initialized
INFO - 2018-06-11 21:56:25 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 21:56:25 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-06-11 21:56:25 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 21:56:25 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 21:56:25 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 21:56:25 --> File loaded: E:\www\yacopoo\application\views\shared/_bar.php
INFO - 2018-06-11 21:56:25 --> File loaded: E:\www\yacopoo\application\views\shared/_buttons.php
INFO - 2018-06-11 21:56:25 --> File loaded: E:\www\yacopoo\application\views\questions/pension.php
INFO - 2018-06-11 21:56:25 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 21:56:25 --> Final output sent to browser
DEBUG - 2018-06-11 21:56:25 --> Total execution time: 0.5502
INFO - 2018-06-11 21:58:12 --> Config Class Initialized
INFO - 2018-06-11 21:58:12 --> Hooks Class Initialized
DEBUG - 2018-06-11 21:58:12 --> UTF-8 Support Enabled
INFO - 2018-06-11 21:58:12 --> Utf8 Class Initialized
INFO - 2018-06-11 21:58:12 --> URI Class Initialized
INFO - 2018-06-11 21:58:12 --> Router Class Initialized
INFO - 2018-06-11 21:58:12 --> Output Class Initialized
INFO - 2018-06-11 21:58:12 --> Security Class Initialized
DEBUG - 2018-06-11 21:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 21:58:12 --> CSRF cookie sent
INFO - 2018-06-11 21:58:12 --> Input Class Initialized
INFO - 2018-06-11 21:58:12 --> Language Class Initialized
ERROR - 2018-06-11 21:58:12 --> 404 Page Not Found: Assets/css
INFO - 2018-06-11 22:05:05 --> Config Class Initialized
INFO - 2018-06-11 22:05:05 --> Hooks Class Initialized
DEBUG - 2018-06-11 22:05:05 --> UTF-8 Support Enabled
INFO - 2018-06-11 22:05:05 --> Utf8 Class Initialized
INFO - 2018-06-11 22:05:05 --> URI Class Initialized
INFO - 2018-06-11 22:05:05 --> Router Class Initialized
INFO - 2018-06-11 22:05:05 --> Output Class Initialized
INFO - 2018-06-11 22:05:05 --> Security Class Initialized
DEBUG - 2018-06-11 22:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 22:05:05 --> CSRF cookie sent
INFO - 2018-06-11 22:05:05 --> Input Class Initialized
INFO - 2018-06-11 22:05:05 --> Language Class Initialized
INFO - 2018-06-11 22:05:05 --> Loader Class Initialized
INFO - 2018-06-11 22:05:05 --> Helper loaded: url_helper
INFO - 2018-06-11 22:05:05 --> Helper loaded: form_helper
INFO - 2018-06-11 22:05:05 --> Helper loaded: language_helper
DEBUG - 2018-06-11 22:05:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 22:05:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 22:05:05 --> User Agent Class Initialized
INFO - 2018-06-11 22:05:05 --> Controller Class Initialized
INFO - 2018-06-11 22:05:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 22:05:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 22:05:05 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 22:05:05 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-06-11 22:05:05 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 22:05:05 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 22:05:05 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 22:05:05 --> File loaded: E:\www\yacopoo\application\views\advisors.php
INFO - 2018-06-11 22:05:05 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 22:05:05 --> Final output sent to browser
DEBUG - 2018-06-11 22:05:05 --> Total execution time: 0.4176
INFO - 2018-06-11 22:05:05 --> Config Class Initialized
INFO - 2018-06-11 22:05:05 --> Hooks Class Initialized
DEBUG - 2018-06-11 22:05:05 --> UTF-8 Support Enabled
INFO - 2018-06-11 22:05:05 --> Utf8 Class Initialized
INFO - 2018-06-11 22:05:06 --> URI Class Initialized
INFO - 2018-06-11 22:05:06 --> Router Class Initialized
INFO - 2018-06-11 22:05:06 --> Output Class Initialized
INFO - 2018-06-11 22:05:06 --> Security Class Initialized
DEBUG - 2018-06-11 22:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 22:05:06 --> CSRF cookie sent
INFO - 2018-06-11 22:05:06 --> Input Class Initialized
INFO - 2018-06-11 22:05:06 --> Language Class Initialized
ERROR - 2018-06-11 22:05:06 --> 404 Page Not Found: Assets/css
INFO - 2018-06-11 22:05:08 --> Config Class Initialized
INFO - 2018-06-11 22:05:08 --> Hooks Class Initialized
DEBUG - 2018-06-11 22:05:08 --> UTF-8 Support Enabled
INFO - 2018-06-11 22:05:08 --> Utf8 Class Initialized
INFO - 2018-06-11 22:05:08 --> URI Class Initialized
INFO - 2018-06-11 22:05:08 --> Router Class Initialized
INFO - 2018-06-11 22:05:08 --> Output Class Initialized
INFO - 2018-06-11 22:05:08 --> Security Class Initialized
DEBUG - 2018-06-11 22:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 22:05:08 --> CSRF cookie sent
INFO - 2018-06-11 22:05:08 --> Input Class Initialized
INFO - 2018-06-11 22:05:08 --> Language Class Initialized
INFO - 2018-06-11 22:05:08 --> Loader Class Initialized
INFO - 2018-06-11 22:05:08 --> Helper loaded: url_helper
INFO - 2018-06-11 22:05:08 --> Helper loaded: form_helper
INFO - 2018-06-11 22:05:09 --> Helper loaded: language_helper
DEBUG - 2018-06-11 22:05:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 22:05:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 22:05:09 --> User Agent Class Initialized
INFO - 2018-06-11 22:05:09 --> Controller Class Initialized
INFO - 2018-06-11 22:05:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 22:05:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 22:05:09 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 22:05:09 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-06-11 22:05:09 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 22:05:09 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 22:05:09 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 22:05:09 --> File loaded: E:\www\yacopoo\application\views\preview.php
INFO - 2018-06-11 22:05:09 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 22:05:09 --> Final output sent to browser
DEBUG - 2018-06-11 22:05:09 --> Total execution time: 0.4429
INFO - 2018-06-11 22:05:09 --> Config Class Initialized
INFO - 2018-06-11 22:05:09 --> Hooks Class Initialized
DEBUG - 2018-06-11 22:05:09 --> UTF-8 Support Enabled
INFO - 2018-06-11 22:05:09 --> Utf8 Class Initialized
INFO - 2018-06-11 22:05:09 --> URI Class Initialized
INFO - 2018-06-11 22:05:09 --> Router Class Initialized
INFO - 2018-06-11 22:05:09 --> Output Class Initialized
INFO - 2018-06-11 22:05:09 --> Security Class Initialized
DEBUG - 2018-06-11 22:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 22:05:09 --> CSRF cookie sent
INFO - 2018-06-11 22:05:09 --> Input Class Initialized
INFO - 2018-06-11 22:05:09 --> Language Class Initialized
ERROR - 2018-06-11 22:05:09 --> 404 Page Not Found: Assets/css
INFO - 2018-06-11 22:05:28 --> Config Class Initialized
INFO - 2018-06-11 22:05:28 --> Hooks Class Initialized
DEBUG - 2018-06-11 22:05:28 --> UTF-8 Support Enabled
INFO - 2018-06-11 22:05:28 --> Utf8 Class Initialized
INFO - 2018-06-11 22:05:28 --> URI Class Initialized
INFO - 2018-06-11 22:05:28 --> Router Class Initialized
INFO - 2018-06-11 22:05:28 --> Output Class Initialized
INFO - 2018-06-11 22:05:28 --> Security Class Initialized
DEBUG - 2018-06-11 22:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 22:05:28 --> CSRF cookie sent
INFO - 2018-06-11 22:05:28 --> Input Class Initialized
INFO - 2018-06-11 22:05:28 --> Language Class Initialized
INFO - 2018-06-11 22:05:28 --> Loader Class Initialized
INFO - 2018-06-11 22:05:28 --> Helper loaded: url_helper
INFO - 2018-06-11 22:05:28 --> Helper loaded: form_helper
INFO - 2018-06-11 22:05:28 --> Helper loaded: language_helper
DEBUG - 2018-06-11 22:05:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 22:05:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 22:05:28 --> User Agent Class Initialized
INFO - 2018-06-11 22:05:28 --> Controller Class Initialized
INFO - 2018-06-11 22:05:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 22:05:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 22:05:28 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 22:05:28 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-06-11 22:05:28 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 22:05:28 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 22:05:28 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 22:05:28 --> File loaded: E:\www\yacopoo\application\views\preview.php
INFO - 2018-06-11 22:05:28 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 22:05:28 --> Final output sent to browser
DEBUG - 2018-06-11 22:05:28 --> Total execution time: 0.4127
INFO - 2018-06-11 22:05:29 --> Config Class Initialized
INFO - 2018-06-11 22:05:29 --> Hooks Class Initialized
DEBUG - 2018-06-11 22:05:29 --> UTF-8 Support Enabled
INFO - 2018-06-11 22:05:29 --> Utf8 Class Initialized
INFO - 2018-06-11 22:05:29 --> URI Class Initialized
INFO - 2018-06-11 22:05:29 --> Router Class Initialized
INFO - 2018-06-11 22:05:29 --> Output Class Initialized
INFO - 2018-06-11 22:05:29 --> Security Class Initialized
DEBUG - 2018-06-11 22:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 22:05:29 --> CSRF cookie sent
INFO - 2018-06-11 22:05:29 --> Input Class Initialized
INFO - 2018-06-11 22:05:29 --> Language Class Initialized
ERROR - 2018-06-11 22:05:29 --> 404 Page Not Found: Assets/css
INFO - 2018-06-11 22:05:33 --> Config Class Initialized
INFO - 2018-06-11 22:05:33 --> Hooks Class Initialized
DEBUG - 2018-06-11 22:05:33 --> UTF-8 Support Enabled
INFO - 2018-06-11 22:05:33 --> Utf8 Class Initialized
INFO - 2018-06-11 22:05:33 --> URI Class Initialized
INFO - 2018-06-11 22:05:33 --> Router Class Initialized
INFO - 2018-06-11 22:05:33 --> Output Class Initialized
INFO - 2018-06-11 22:05:33 --> Security Class Initialized
DEBUG - 2018-06-11 22:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 22:05:33 --> CSRF cookie sent
INFO - 2018-06-11 22:05:33 --> Input Class Initialized
INFO - 2018-06-11 22:05:33 --> Language Class Initialized
INFO - 2018-06-11 22:05:33 --> Loader Class Initialized
INFO - 2018-06-11 22:05:33 --> Helper loaded: url_helper
INFO - 2018-06-11 22:05:33 --> Helper loaded: form_helper
INFO - 2018-06-11 22:05:33 --> Helper loaded: language_helper
DEBUG - 2018-06-11 22:05:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 22:05:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 22:05:33 --> User Agent Class Initialized
INFO - 2018-06-11 22:05:33 --> Controller Class Initialized
INFO - 2018-06-11 22:05:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 22:05:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 22:05:33 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 22:05:33 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-06-11 22:05:33 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 22:05:33 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 22:05:33 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 22:05:33 --> File loaded: E:\www\yacopoo\application\views\preview.php
INFO - 2018-06-11 22:05:33 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 22:05:33 --> Final output sent to browser
DEBUG - 2018-06-11 22:05:33 --> Total execution time: 0.4041
INFO - 2018-06-11 22:05:34 --> Config Class Initialized
INFO - 2018-06-11 22:05:34 --> Hooks Class Initialized
DEBUG - 2018-06-11 22:05:34 --> UTF-8 Support Enabled
INFO - 2018-06-11 22:05:34 --> Utf8 Class Initialized
INFO - 2018-06-11 22:05:34 --> URI Class Initialized
INFO - 2018-06-11 22:05:34 --> Router Class Initialized
INFO - 2018-06-11 22:05:34 --> Output Class Initialized
INFO - 2018-06-11 22:05:34 --> Security Class Initialized
DEBUG - 2018-06-11 22:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 22:05:34 --> CSRF cookie sent
INFO - 2018-06-11 22:05:34 --> Input Class Initialized
INFO - 2018-06-11 22:05:34 --> Language Class Initialized
ERROR - 2018-06-11 22:05:34 --> 404 Page Not Found: Assets/css
INFO - 2018-06-11 22:06:09 --> Config Class Initialized
INFO - 2018-06-11 22:06:09 --> Hooks Class Initialized
DEBUG - 2018-06-11 22:06:09 --> UTF-8 Support Enabled
INFO - 2018-06-11 22:06:09 --> Utf8 Class Initialized
INFO - 2018-06-11 22:06:09 --> URI Class Initialized
INFO - 2018-06-11 22:06:09 --> Router Class Initialized
INFO - 2018-06-11 22:06:09 --> Output Class Initialized
INFO - 2018-06-11 22:06:09 --> Security Class Initialized
DEBUG - 2018-06-11 22:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 22:06:09 --> CSRF cookie sent
INFO - 2018-06-11 22:06:09 --> Input Class Initialized
INFO - 2018-06-11 22:06:09 --> Language Class Initialized
INFO - 2018-06-11 22:06:09 --> Loader Class Initialized
INFO - 2018-06-11 22:06:09 --> Helper loaded: url_helper
INFO - 2018-06-11 22:06:09 --> Helper loaded: form_helper
INFO - 2018-06-11 22:06:09 --> Helper loaded: language_helper
DEBUG - 2018-06-11 22:06:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 22:06:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 22:06:09 --> User Agent Class Initialized
INFO - 2018-06-11 22:06:09 --> Controller Class Initialized
INFO - 2018-06-11 22:06:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 22:06:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 22:06:09 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 22:06:09 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-06-11 22:06:09 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 22:06:09 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 22:06:09 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 22:06:09 --> File loaded: E:\www\yacopoo\application\views\preview.php
INFO - 2018-06-11 22:06:09 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 22:06:09 --> Final output sent to browser
DEBUG - 2018-06-11 22:06:09 --> Total execution time: 0.4113
INFO - 2018-06-11 22:06:09 --> Config Class Initialized
INFO - 2018-06-11 22:06:09 --> Hooks Class Initialized
DEBUG - 2018-06-11 22:06:09 --> UTF-8 Support Enabled
INFO - 2018-06-11 22:06:09 --> Utf8 Class Initialized
INFO - 2018-06-11 22:06:09 --> URI Class Initialized
INFO - 2018-06-11 22:06:09 --> Router Class Initialized
INFO - 2018-06-11 22:06:09 --> Output Class Initialized
INFO - 2018-06-11 22:06:09 --> Security Class Initialized
DEBUG - 2018-06-11 22:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 22:06:09 --> CSRF cookie sent
INFO - 2018-06-11 22:06:10 --> Input Class Initialized
INFO - 2018-06-11 22:06:10 --> Language Class Initialized
ERROR - 2018-06-11 22:06:10 --> 404 Page Not Found: Assets/css
INFO - 2018-06-11 22:09:06 --> Config Class Initialized
INFO - 2018-06-11 22:09:06 --> Hooks Class Initialized
DEBUG - 2018-06-11 22:09:06 --> UTF-8 Support Enabled
INFO - 2018-06-11 22:09:06 --> Utf8 Class Initialized
INFO - 2018-06-11 22:09:06 --> URI Class Initialized
INFO - 2018-06-11 22:09:06 --> Router Class Initialized
INFO - 2018-06-11 22:09:06 --> Output Class Initialized
INFO - 2018-06-11 22:09:06 --> Security Class Initialized
DEBUG - 2018-06-11 22:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 22:09:06 --> CSRF cookie sent
INFO - 2018-06-11 22:09:06 --> Input Class Initialized
INFO - 2018-06-11 22:09:06 --> Language Class Initialized
INFO - 2018-06-11 22:09:06 --> Loader Class Initialized
INFO - 2018-06-11 22:09:06 --> Helper loaded: url_helper
INFO - 2018-06-11 22:09:06 --> Helper loaded: form_helper
INFO - 2018-06-11 22:09:06 --> Helper loaded: language_helper
DEBUG - 2018-06-11 22:09:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 22:09:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 22:09:06 --> User Agent Class Initialized
INFO - 2018-06-11 22:09:06 --> Controller Class Initialized
INFO - 2018-06-11 22:09:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 22:09:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 22:09:06 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 22:09:06 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-06-11 22:09:06 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 22:09:06 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 22:09:06 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 22:09:06 --> File loaded: E:\www\yacopoo\application\views\preview.php
INFO - 2018-06-11 22:09:06 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 22:09:06 --> Final output sent to browser
DEBUG - 2018-06-11 22:09:06 --> Total execution time: 0.4099
INFO - 2018-06-11 22:12:58 --> Config Class Initialized
INFO - 2018-06-11 22:12:58 --> Hooks Class Initialized
DEBUG - 2018-06-11 22:12:58 --> UTF-8 Support Enabled
INFO - 2018-06-11 22:12:58 --> Utf8 Class Initialized
INFO - 2018-06-11 22:12:58 --> URI Class Initialized
INFO - 2018-06-11 22:12:58 --> Router Class Initialized
INFO - 2018-06-11 22:12:58 --> Output Class Initialized
INFO - 2018-06-11 22:12:58 --> Security Class Initialized
DEBUG - 2018-06-11 22:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 22:12:58 --> CSRF cookie sent
INFO - 2018-06-11 22:12:58 --> Input Class Initialized
INFO - 2018-06-11 22:12:58 --> Language Class Initialized
INFO - 2018-06-11 22:12:58 --> Loader Class Initialized
INFO - 2018-06-11 22:12:58 --> Helper loaded: url_helper
INFO - 2018-06-11 22:12:58 --> Helper loaded: form_helper
INFO - 2018-06-11 22:12:58 --> Helper loaded: language_helper
DEBUG - 2018-06-11 22:12:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 22:12:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 22:12:58 --> User Agent Class Initialized
INFO - 2018-06-11 22:12:58 --> Controller Class Initialized
INFO - 2018-06-11 22:12:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 22:12:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 22:12:58 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 22:12:58 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-06-11 22:12:58 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 22:12:58 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 22:12:58 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 22:12:58 --> File loaded: E:\www\yacopoo\application\views\preview.php
INFO - 2018-06-11 22:12:58 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 22:12:58 --> Final output sent to browser
DEBUG - 2018-06-11 22:12:58 --> Total execution time: 0.4547
INFO - 2018-06-11 22:13:00 --> Config Class Initialized
INFO - 2018-06-11 22:13:00 --> Hooks Class Initialized
DEBUG - 2018-06-11 22:13:00 --> UTF-8 Support Enabled
INFO - 2018-06-11 22:13:00 --> Utf8 Class Initialized
INFO - 2018-06-11 22:13:00 --> URI Class Initialized
INFO - 2018-06-11 22:13:00 --> Router Class Initialized
INFO - 2018-06-11 22:13:00 --> Output Class Initialized
INFO - 2018-06-11 22:13:00 --> Security Class Initialized
DEBUG - 2018-06-11 22:13:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 22:13:00 --> CSRF cookie sent
INFO - 2018-06-11 22:13:00 --> Input Class Initialized
INFO - 2018-06-11 22:13:00 --> Language Class Initialized
INFO - 2018-06-11 22:13:00 --> Loader Class Initialized
INFO - 2018-06-11 22:13:00 --> Helper loaded: url_helper
INFO - 2018-06-11 22:13:00 --> Helper loaded: form_helper
INFO - 2018-06-11 22:13:00 --> Helper loaded: language_helper
DEBUG - 2018-06-11 22:13:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 22:13:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 22:13:00 --> User Agent Class Initialized
INFO - 2018-06-11 22:13:00 --> Controller Class Initialized
INFO - 2018-06-11 22:13:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 22:13:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 22:13:00 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 22:13:00 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-06-11 22:13:00 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 22:13:00 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 22:13:00 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 22:13:00 --> File loaded: E:\www\yacopoo\application\views\lawyers.php
INFO - 2018-06-11 22:13:00 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 22:13:00 --> Final output sent to browser
DEBUG - 2018-06-11 22:13:00 --> Total execution time: 0.4173
INFO - 2018-06-11 22:13:36 --> Config Class Initialized
INFO - 2018-06-11 22:13:36 --> Hooks Class Initialized
DEBUG - 2018-06-11 22:13:36 --> UTF-8 Support Enabled
INFO - 2018-06-11 22:13:36 --> Utf8 Class Initialized
INFO - 2018-06-11 22:13:36 --> URI Class Initialized
INFO - 2018-06-11 22:13:36 --> Router Class Initialized
INFO - 2018-06-11 22:13:36 --> Output Class Initialized
INFO - 2018-06-11 22:13:36 --> Security Class Initialized
DEBUG - 2018-06-11 22:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 22:13:36 --> CSRF cookie sent
INFO - 2018-06-11 22:13:36 --> Input Class Initialized
INFO - 2018-06-11 22:13:36 --> Language Class Initialized
INFO - 2018-06-11 22:13:36 --> Loader Class Initialized
INFO - 2018-06-11 22:13:36 --> Helper loaded: url_helper
INFO - 2018-06-11 22:13:36 --> Helper loaded: form_helper
INFO - 2018-06-11 22:13:36 --> Helper loaded: language_helper
DEBUG - 2018-06-11 22:13:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 22:13:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 22:13:36 --> User Agent Class Initialized
INFO - 2018-06-11 22:13:36 --> Controller Class Initialized
INFO - 2018-06-11 22:13:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 22:13:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 22:13:36 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 22:13:36 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-06-11 22:13:36 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 22:13:36 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 22:13:36 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 22:13:36 --> File loaded: E:\www\yacopoo\application\views\lawyers.php
INFO - 2018-06-11 22:13:36 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 22:13:36 --> Final output sent to browser
DEBUG - 2018-06-11 22:13:36 --> Total execution time: 0.4063
INFO - 2018-06-11 22:13:38 --> Config Class Initialized
INFO - 2018-06-11 22:13:38 --> Hooks Class Initialized
DEBUG - 2018-06-11 22:13:38 --> UTF-8 Support Enabled
INFO - 2018-06-11 22:13:38 --> Utf8 Class Initialized
INFO - 2018-06-11 22:13:38 --> URI Class Initialized
INFO - 2018-06-11 22:13:38 --> Router Class Initialized
INFO - 2018-06-11 22:13:38 --> Output Class Initialized
INFO - 2018-06-11 22:13:38 --> Security Class Initialized
DEBUG - 2018-06-11 22:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 22:13:38 --> CSRF cookie sent
INFO - 2018-06-11 22:13:38 --> Input Class Initialized
INFO - 2018-06-11 22:13:38 --> Language Class Initialized
INFO - 2018-06-11 22:13:38 --> Loader Class Initialized
INFO - 2018-06-11 22:13:38 --> Helper loaded: url_helper
INFO - 2018-06-11 22:13:38 --> Helper loaded: form_helper
INFO - 2018-06-11 22:13:38 --> Helper loaded: language_helper
DEBUG - 2018-06-11 22:13:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 22:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 22:13:38 --> User Agent Class Initialized
INFO - 2018-06-11 22:13:38 --> Controller Class Initialized
INFO - 2018-06-11 22:13:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 22:13:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 22:13:38 --> Config Class Initialized
INFO - 2018-06-11 22:13:38 --> Hooks Class Initialized
DEBUG - 2018-06-11 22:13:38 --> UTF-8 Support Enabled
INFO - 2018-06-11 22:13:38 --> Utf8 Class Initialized
INFO - 2018-06-11 22:13:38 --> URI Class Initialized
INFO - 2018-06-11 22:13:38 --> Router Class Initialized
INFO - 2018-06-11 22:13:38 --> Output Class Initialized
INFO - 2018-06-11 22:13:38 --> Security Class Initialized
DEBUG - 2018-06-11 22:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 22:13:38 --> CSRF cookie sent
INFO - 2018-06-11 22:13:38 --> Input Class Initialized
INFO - 2018-06-11 22:13:38 --> Language Class Initialized
INFO - 2018-06-11 22:13:38 --> Loader Class Initialized
INFO - 2018-06-11 22:13:38 --> Helper loaded: url_helper
INFO - 2018-06-11 22:13:38 --> Helper loaded: form_helper
INFO - 2018-06-11 22:13:38 --> Helper loaded: language_helper
DEBUG - 2018-06-11 22:13:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 22:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 22:13:38 --> User Agent Class Initialized
INFO - 2018-06-11 22:13:38 --> Controller Class Initialized
INFO - 2018-06-11 22:13:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 22:13:38 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-11 22:13:38 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-06-11 22:13:38 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 22:13:38 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-06-11 22:13:38 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 22:13:38 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 22:13:38 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-06-11 22:13:38 --> Could not find the language line "req_email"
INFO - 2018-06-11 22:13:38 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-06-11 22:13:38 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 22:13:38 --> Final output sent to browser
DEBUG - 2018-06-11 22:13:38 --> Total execution time: 0.4867
INFO - 2018-06-11 22:13:42 --> Config Class Initialized
INFO - 2018-06-11 22:13:42 --> Hooks Class Initialized
DEBUG - 2018-06-11 22:13:42 --> UTF-8 Support Enabled
INFO - 2018-06-11 22:13:42 --> Utf8 Class Initialized
INFO - 2018-06-11 22:13:42 --> URI Class Initialized
INFO - 2018-06-11 22:13:42 --> Router Class Initialized
INFO - 2018-06-11 22:13:42 --> Output Class Initialized
INFO - 2018-06-11 22:13:42 --> Security Class Initialized
DEBUG - 2018-06-11 22:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 22:13:42 --> CSRF cookie sent
INFO - 2018-06-11 22:13:42 --> Input Class Initialized
INFO - 2018-06-11 22:13:42 --> Language Class Initialized
INFO - 2018-06-11 22:13:42 --> Loader Class Initialized
INFO - 2018-06-11 22:13:42 --> Helper loaded: url_helper
INFO - 2018-06-11 22:13:42 --> Helper loaded: form_helper
INFO - 2018-06-11 22:13:42 --> Helper loaded: language_helper
DEBUG - 2018-06-11 22:13:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 22:13:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 22:13:42 --> User Agent Class Initialized
INFO - 2018-06-11 22:13:42 --> Controller Class Initialized
INFO - 2018-06-11 22:13:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 22:13:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 22:13:42 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 22:13:42 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-06-11 22:13:42 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 22:13:42 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 22:13:42 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 22:13:42 --> File loaded: E:\www\yacopoo\application\views\lawyers.php
INFO - 2018-06-11 22:13:42 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 22:13:42 --> Final output sent to browser
DEBUG - 2018-06-11 22:13:42 --> Total execution time: 0.4082
INFO - 2018-06-11 22:13:45 --> Config Class Initialized
INFO - 2018-06-11 22:13:45 --> Hooks Class Initialized
DEBUG - 2018-06-11 22:13:45 --> UTF-8 Support Enabled
INFO - 2018-06-11 22:13:45 --> Utf8 Class Initialized
INFO - 2018-06-11 22:13:45 --> URI Class Initialized
INFO - 2018-06-11 22:13:45 --> Router Class Initialized
INFO - 2018-06-11 22:13:45 --> Output Class Initialized
INFO - 2018-06-11 22:13:45 --> Security Class Initialized
DEBUG - 2018-06-11 22:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 22:13:45 --> CSRF cookie sent
INFO - 2018-06-11 22:13:45 --> Input Class Initialized
INFO - 2018-06-11 22:13:45 --> Language Class Initialized
INFO - 2018-06-11 22:13:45 --> Loader Class Initialized
INFO - 2018-06-11 22:13:45 --> Helper loaded: url_helper
INFO - 2018-06-11 22:13:45 --> Helper loaded: form_helper
INFO - 2018-06-11 22:13:45 --> Helper loaded: language_helper
DEBUG - 2018-06-11 22:13:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 22:13:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 22:13:45 --> User Agent Class Initialized
INFO - 2018-06-11 22:13:45 --> Controller Class Initialized
INFO - 2018-06-11 22:13:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 22:13:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 22:13:45 --> Config Class Initialized
INFO - 2018-06-11 22:13:45 --> Hooks Class Initialized
DEBUG - 2018-06-11 22:13:45 --> UTF-8 Support Enabled
INFO - 2018-06-11 22:13:45 --> Utf8 Class Initialized
INFO - 2018-06-11 22:13:45 --> URI Class Initialized
INFO - 2018-06-11 22:13:45 --> Router Class Initialized
INFO - 2018-06-11 22:13:45 --> Output Class Initialized
INFO - 2018-06-11 22:13:45 --> Security Class Initialized
DEBUG - 2018-06-11 22:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 22:13:45 --> CSRF cookie sent
INFO - 2018-06-11 22:13:45 --> Input Class Initialized
INFO - 2018-06-11 22:13:45 --> Language Class Initialized
INFO - 2018-06-11 22:13:45 --> Loader Class Initialized
INFO - 2018-06-11 22:13:45 --> Helper loaded: url_helper
INFO - 2018-06-11 22:13:45 --> Helper loaded: form_helper
INFO - 2018-06-11 22:13:45 --> Helper loaded: language_helper
DEBUG - 2018-06-11 22:13:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 22:13:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 22:13:45 --> User Agent Class Initialized
INFO - 2018-06-11 22:13:45 --> Controller Class Initialized
INFO - 2018-06-11 22:13:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 22:13:45 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-11 22:13:45 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-06-11 22:13:45 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 22:13:46 --> File loaded: E:\www\yacopoo\application\views\shared/_end_user_nav.php
INFO - 2018-06-11 22:13:46 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 22:13:46 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 22:13:46 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-06-11 22:13:46 --> Could not find the language line "req_email"
INFO - 2018-06-11 22:13:46 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-06-11 22:13:46 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 22:13:46 --> Final output sent to browser
DEBUG - 2018-06-11 22:13:46 --> Total execution time: 0.4222
INFO - 2018-06-11 22:13:48 --> Config Class Initialized
INFO - 2018-06-11 22:13:48 --> Hooks Class Initialized
DEBUG - 2018-06-11 22:13:48 --> UTF-8 Support Enabled
INFO - 2018-06-11 22:13:48 --> Utf8 Class Initialized
INFO - 2018-06-11 22:13:48 --> URI Class Initialized
INFO - 2018-06-11 22:13:48 --> Router Class Initialized
INFO - 2018-06-11 22:13:48 --> Output Class Initialized
INFO - 2018-06-11 22:13:48 --> Security Class Initialized
DEBUG - 2018-06-11 22:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 22:13:48 --> CSRF cookie sent
INFO - 2018-06-11 22:13:48 --> Input Class Initialized
INFO - 2018-06-11 22:13:48 --> Language Class Initialized
INFO - 2018-06-11 22:13:48 --> Loader Class Initialized
INFO - 2018-06-11 22:13:48 --> Helper loaded: url_helper
INFO - 2018-06-11 22:13:48 --> Helper loaded: form_helper
INFO - 2018-06-11 22:13:48 --> Helper loaded: language_helper
DEBUG - 2018-06-11 22:13:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 22:13:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 22:13:48 --> User Agent Class Initialized
INFO - 2018-06-11 22:13:48 --> Controller Class Initialized
INFO - 2018-06-11 22:13:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 22:13:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 22:13:48 --> CSRF cookie sent
INFO - 2018-06-11 22:13:48 --> Config Class Initialized
INFO - 2018-06-11 22:13:48 --> Hooks Class Initialized
DEBUG - 2018-06-11 22:13:48 --> UTF-8 Support Enabled
INFO - 2018-06-11 22:13:48 --> Utf8 Class Initialized
INFO - 2018-06-11 22:13:48 --> URI Class Initialized
DEBUG - 2018-06-11 22:13:48 --> No URI present. Default controller set.
INFO - 2018-06-11 22:13:48 --> Router Class Initialized
INFO - 2018-06-11 22:13:48 --> Output Class Initialized
INFO - 2018-06-11 22:13:48 --> Security Class Initialized
DEBUG - 2018-06-11 22:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 22:13:48 --> CSRF cookie sent
INFO - 2018-06-11 22:13:48 --> Input Class Initialized
INFO - 2018-06-11 22:13:48 --> Language Class Initialized
INFO - 2018-06-11 22:13:48 --> Loader Class Initialized
INFO - 2018-06-11 22:13:48 --> Helper loaded: url_helper
INFO - 2018-06-11 22:13:48 --> Helper loaded: form_helper
INFO - 2018-06-11 22:13:48 --> Helper loaded: language_helper
DEBUG - 2018-06-11 22:13:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 22:13:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 22:13:48 --> User Agent Class Initialized
INFO - 2018-06-11 22:13:48 --> Controller Class Initialized
INFO - 2018-06-11 22:13:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 22:13:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 22:13:48 --> Pixel_Model class loaded
INFO - 2018-06-11 22:13:48 --> Database Driver Class Initialized
INFO - 2018-06-11 22:13:48 --> Model "QuestionsModel" initialized
INFO - 2018-06-11 22:13:48 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 22:13:48 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 22:13:48 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-06-11 22:13:48 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 22:13:48 --> Final output sent to browser
DEBUG - 2018-06-11 22:13:48 --> Total execution time: 0.4243
INFO - 2018-06-11 22:13:50 --> Config Class Initialized
INFO - 2018-06-11 22:13:50 --> Hooks Class Initialized
DEBUG - 2018-06-11 22:13:50 --> UTF-8 Support Enabled
INFO - 2018-06-11 22:13:50 --> Utf8 Class Initialized
INFO - 2018-06-11 22:13:50 --> URI Class Initialized
INFO - 2018-06-11 22:13:50 --> Router Class Initialized
INFO - 2018-06-11 22:13:50 --> Output Class Initialized
INFO - 2018-06-11 22:13:50 --> Security Class Initialized
DEBUG - 2018-06-11 22:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 22:13:50 --> CSRF cookie sent
INFO - 2018-06-11 22:13:50 --> Input Class Initialized
INFO - 2018-06-11 22:13:50 --> Language Class Initialized
INFO - 2018-06-11 22:13:50 --> Loader Class Initialized
INFO - 2018-06-11 22:13:50 --> Helper loaded: url_helper
INFO - 2018-06-11 22:13:50 --> Helper loaded: form_helper
INFO - 2018-06-11 22:13:50 --> Helper loaded: language_helper
DEBUG - 2018-06-11 22:13:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 22:13:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 22:13:50 --> User Agent Class Initialized
INFO - 2018-06-11 22:13:50 --> Controller Class Initialized
INFO - 2018-06-11 22:13:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 22:13:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 22:13:50 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 22:13:50 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 22:13:50 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 22:13:50 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 22:13:50 --> File loaded: E:\www\yacopoo\application\views\lawyers.php
INFO - 2018-06-11 22:13:50 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 22:13:50 --> Final output sent to browser
DEBUG - 2018-06-11 22:13:50 --> Total execution time: 0.4751
INFO - 2018-06-11 22:13:52 --> Config Class Initialized
INFO - 2018-06-11 22:13:52 --> Hooks Class Initialized
DEBUG - 2018-06-11 22:13:52 --> UTF-8 Support Enabled
INFO - 2018-06-11 22:13:52 --> Utf8 Class Initialized
INFO - 2018-06-11 22:13:52 --> URI Class Initialized
INFO - 2018-06-11 22:13:52 --> Router Class Initialized
INFO - 2018-06-11 22:13:52 --> Output Class Initialized
INFO - 2018-06-11 22:13:52 --> Security Class Initialized
DEBUG - 2018-06-11 22:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 22:13:52 --> CSRF cookie sent
INFO - 2018-06-11 22:13:52 --> Input Class Initialized
INFO - 2018-06-11 22:13:52 --> Language Class Initialized
INFO - 2018-06-11 22:13:52 --> Loader Class Initialized
INFO - 2018-06-11 22:13:52 --> Helper loaded: url_helper
INFO - 2018-06-11 22:13:52 --> Helper loaded: form_helper
INFO - 2018-06-11 22:13:52 --> Helper loaded: language_helper
DEBUG - 2018-06-11 22:13:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 22:13:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 22:13:52 --> User Agent Class Initialized
INFO - 2018-06-11 22:13:52 --> Controller Class Initialized
INFO - 2018-06-11 22:13:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 22:13:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 22:13:52 --> Pixel_Model class loaded
INFO - 2018-06-11 22:13:52 --> Database Driver Class Initialized
INFO - 2018-06-11 22:13:52 --> Model "RegistrationModel" initialized
DEBUG - 2018-06-11 22:13:52 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-06-11 22:13:52 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 22:13:52 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 22:13:52 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 22:13:52 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-06-11 22:13:52 --> Could not find the language line "req_email"
INFO - 2018-06-11 22:13:52 --> File loaded: E:\www\yacopoo\application\views\register/signup_lawyer.php
INFO - 2018-06-11 22:13:52 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 22:13:52 --> Final output sent to browser
DEBUG - 2018-06-11 22:13:52 --> Total execution time: 0.5147
INFO - 2018-06-11 22:14:41 --> Config Class Initialized
INFO - 2018-06-11 22:14:41 --> Hooks Class Initialized
DEBUG - 2018-06-11 22:14:41 --> UTF-8 Support Enabled
INFO - 2018-06-11 22:14:41 --> Utf8 Class Initialized
INFO - 2018-06-11 22:14:41 --> URI Class Initialized
INFO - 2018-06-11 22:14:41 --> Router Class Initialized
INFO - 2018-06-11 22:14:41 --> Output Class Initialized
INFO - 2018-06-11 22:14:41 --> Security Class Initialized
DEBUG - 2018-06-11 22:14:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 22:14:41 --> CSRF cookie sent
INFO - 2018-06-11 22:14:41 --> Input Class Initialized
INFO - 2018-06-11 22:14:41 --> Language Class Initialized
INFO - 2018-06-11 22:14:41 --> Loader Class Initialized
INFO - 2018-06-11 22:14:41 --> Helper loaded: url_helper
INFO - 2018-06-11 22:14:41 --> Helper loaded: form_helper
INFO - 2018-06-11 22:14:41 --> Helper loaded: language_helper
DEBUG - 2018-06-11 22:14:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 22:14:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 22:14:41 --> User Agent Class Initialized
INFO - 2018-06-11 22:14:41 --> Controller Class Initialized
INFO - 2018-06-11 22:14:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 22:14:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 22:14:41 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 22:14:41 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 22:14:41 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 22:14:41 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 22:14:41 --> File loaded: E:\www\yacopoo\application\views\lawyers.php
INFO - 2018-06-11 22:14:41 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 22:14:41 --> Final output sent to browser
DEBUG - 2018-06-11 22:14:41 --> Total execution time: 0.4378
INFO - 2018-06-11 22:15:02 --> Config Class Initialized
INFO - 2018-06-11 22:15:02 --> Hooks Class Initialized
DEBUG - 2018-06-11 22:15:02 --> UTF-8 Support Enabled
INFO - 2018-06-11 22:15:02 --> Utf8 Class Initialized
INFO - 2018-06-11 22:15:02 --> URI Class Initialized
INFO - 2018-06-11 22:15:02 --> Router Class Initialized
INFO - 2018-06-11 22:15:02 --> Output Class Initialized
INFO - 2018-06-11 22:15:02 --> Security Class Initialized
DEBUG - 2018-06-11 22:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 22:15:02 --> CSRF cookie sent
INFO - 2018-06-11 22:15:02 --> Input Class Initialized
INFO - 2018-06-11 22:15:02 --> Language Class Initialized
INFO - 2018-06-11 22:15:03 --> Loader Class Initialized
INFO - 2018-06-11 22:15:03 --> Helper loaded: url_helper
INFO - 2018-06-11 22:15:03 --> Helper loaded: form_helper
INFO - 2018-06-11 22:15:03 --> Helper loaded: language_helper
DEBUG - 2018-06-11 22:15:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 22:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 22:15:03 --> User Agent Class Initialized
INFO - 2018-06-11 22:15:03 --> Controller Class Initialized
INFO - 2018-06-11 22:15:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 22:15:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 22:15:03 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 22:15:03 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 22:15:03 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 22:15:03 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 22:15:03 --> File loaded: E:\www\yacopoo\application\views\wedding_gifts.php
INFO - 2018-06-11 22:15:03 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 22:15:03 --> Final output sent to browser
DEBUG - 2018-06-11 22:15:03 --> Total execution time: 0.4138
INFO - 2018-06-11 22:16:16 --> Config Class Initialized
INFO - 2018-06-11 22:16:16 --> Hooks Class Initialized
DEBUG - 2018-06-11 22:16:16 --> UTF-8 Support Enabled
INFO - 2018-06-11 22:16:16 --> Utf8 Class Initialized
INFO - 2018-06-11 22:16:16 --> URI Class Initialized
INFO - 2018-06-11 22:16:16 --> Router Class Initialized
INFO - 2018-06-11 22:16:16 --> Output Class Initialized
INFO - 2018-06-11 22:16:16 --> Security Class Initialized
DEBUG - 2018-06-11 22:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 22:16:16 --> CSRF cookie sent
INFO - 2018-06-11 22:16:16 --> Input Class Initialized
INFO - 2018-06-11 22:16:16 --> Language Class Initialized
INFO - 2018-06-11 22:16:16 --> Loader Class Initialized
INFO - 2018-06-11 22:16:16 --> Helper loaded: url_helper
INFO - 2018-06-11 22:16:16 --> Helper loaded: form_helper
INFO - 2018-06-11 22:16:16 --> Helper loaded: language_helper
DEBUG - 2018-06-11 22:16:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 22:16:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 22:16:16 --> User Agent Class Initialized
INFO - 2018-06-11 22:16:16 --> Controller Class Initialized
INFO - 2018-06-11 22:16:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 22:16:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 22:16:16 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 22:16:16 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 22:16:17 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 22:16:17 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 22:16:17 --> File loaded: E:\www\yacopoo\application\views\wedding_gifts.php
INFO - 2018-06-11 22:16:17 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 22:16:17 --> Final output sent to browser
DEBUG - 2018-06-11 22:16:17 --> Total execution time: 0.4217
INFO - 2018-06-11 22:16:22 --> Config Class Initialized
INFO - 2018-06-11 22:16:22 --> Hooks Class Initialized
DEBUG - 2018-06-11 22:16:22 --> UTF-8 Support Enabled
INFO - 2018-06-11 22:16:22 --> Utf8 Class Initialized
INFO - 2018-06-11 22:16:22 --> URI Class Initialized
INFO - 2018-06-11 22:16:22 --> Router Class Initialized
INFO - 2018-06-11 22:16:22 --> Output Class Initialized
INFO - 2018-06-11 22:16:22 --> Security Class Initialized
DEBUG - 2018-06-11 22:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 22:16:22 --> CSRF cookie sent
INFO - 2018-06-11 22:16:22 --> Input Class Initialized
INFO - 2018-06-11 22:16:22 --> Language Class Initialized
INFO - 2018-06-11 22:16:22 --> Loader Class Initialized
INFO - 2018-06-11 22:16:22 --> Helper loaded: url_helper
INFO - 2018-06-11 22:16:23 --> Helper loaded: form_helper
INFO - 2018-06-11 22:16:23 --> Helper loaded: language_helper
DEBUG - 2018-06-11 22:16:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 22:16:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 22:16:23 --> User Agent Class Initialized
INFO - 2018-06-11 22:16:23 --> Controller Class Initialized
INFO - 2018-06-11 22:16:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 22:16:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 22:16:23 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 22:16:23 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 22:16:23 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 22:16:23 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 22:16:23 --> File loaded: E:\www\yacopoo\application\views\lawyers.php
INFO - 2018-06-11 22:16:23 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 22:16:23 --> Final output sent to browser
DEBUG - 2018-06-11 22:16:23 --> Total execution time: 0.4006
INFO - 2018-06-11 22:20:03 --> Config Class Initialized
INFO - 2018-06-11 22:20:03 --> Hooks Class Initialized
DEBUG - 2018-06-11 22:20:03 --> UTF-8 Support Enabled
INFO - 2018-06-11 22:20:03 --> Utf8 Class Initialized
INFO - 2018-06-11 22:20:03 --> URI Class Initialized
INFO - 2018-06-11 22:20:03 --> Router Class Initialized
INFO - 2018-06-11 22:20:03 --> Output Class Initialized
INFO - 2018-06-11 22:20:03 --> Security Class Initialized
DEBUG - 2018-06-11 22:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 22:20:03 --> CSRF cookie sent
INFO - 2018-06-11 22:20:03 --> Input Class Initialized
INFO - 2018-06-11 22:20:03 --> Language Class Initialized
INFO - 2018-06-11 22:20:03 --> Loader Class Initialized
INFO - 2018-06-11 22:20:03 --> Helper loaded: url_helper
INFO - 2018-06-11 22:20:03 --> Helper loaded: form_helper
INFO - 2018-06-11 22:20:03 --> Helper loaded: language_helper
DEBUG - 2018-06-11 22:20:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 22:20:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 22:20:03 --> User Agent Class Initialized
INFO - 2018-06-11 22:20:03 --> Controller Class Initialized
INFO - 2018-06-11 22:20:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 22:20:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 22:20:03 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 22:20:03 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 22:20:03 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 22:20:04 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 22:20:04 --> File loaded: E:\www\yacopoo\application\views\professions.php
INFO - 2018-06-11 22:20:04 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 22:20:04 --> Final output sent to browser
DEBUG - 2018-06-11 22:20:04 --> Total execution time: 0.4000
INFO - 2018-06-11 22:20:04 --> Config Class Initialized
INFO - 2018-06-11 22:20:04 --> Hooks Class Initialized
INFO - 2018-06-11 22:20:04 --> Config Class Initialized
INFO - 2018-06-11 22:20:04 --> Config Class Initialized
INFO - 2018-06-11 22:20:04 --> Hooks Class Initialized
INFO - 2018-06-11 22:20:04 --> Hooks Class Initialized
INFO - 2018-06-11 22:20:04 --> Config Class Initialized
DEBUG - 2018-06-11 22:20:04 --> UTF-8 Support Enabled
INFO - 2018-06-11 22:20:04 --> Utf8 Class Initialized
INFO - 2018-06-11 22:20:04 --> Hooks Class Initialized
DEBUG - 2018-06-11 22:20:04 --> UTF-8 Support Enabled
DEBUG - 2018-06-11 22:20:04 --> UTF-8 Support Enabled
INFO - 2018-06-11 22:20:04 --> Utf8 Class Initialized
INFO - 2018-06-11 22:20:04 --> Utf8 Class Initialized
INFO - 2018-06-11 22:20:04 --> URI Class Initialized
DEBUG - 2018-06-11 22:20:04 --> UTF-8 Support Enabled
INFO - 2018-06-11 22:20:04 --> Utf8 Class Initialized
INFO - 2018-06-11 22:20:04 --> URI Class Initialized
INFO - 2018-06-11 22:20:04 --> URI Class Initialized
INFO - 2018-06-11 22:20:04 --> Router Class Initialized
INFO - 2018-06-11 22:20:04 --> Output Class Initialized
INFO - 2018-06-11 22:20:04 --> URI Class Initialized
INFO - 2018-06-11 22:20:04 --> Router Class Initialized
INFO - 2018-06-11 22:20:04 --> Router Class Initialized
INFO - 2018-06-11 22:20:04 --> Security Class Initialized
INFO - 2018-06-11 22:20:04 --> Output Class Initialized
INFO - 2018-06-11 22:20:04 --> Output Class Initialized
INFO - 2018-06-11 22:20:04 --> Router Class Initialized
INFO - 2018-06-11 22:20:04 --> Output Class Initialized
INFO - 2018-06-11 22:20:04 --> Security Class Initialized
DEBUG - 2018-06-11 22:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 22:20:04 --> Security Class Initialized
INFO - 2018-06-11 22:20:04 --> CSRF cookie sent
DEBUG - 2018-06-11 22:20:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-06-11 22:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 22:20:04 --> Security Class Initialized
INFO - 2018-06-11 22:20:04 --> CSRF cookie sent
INFO - 2018-06-11 22:20:04 --> Input Class Initialized
INFO - 2018-06-11 22:20:04 --> CSRF cookie sent
DEBUG - 2018-06-11 22:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 22:20:04 --> Input Class Initialized
INFO - 2018-06-11 22:20:04 --> Input Class Initialized
INFO - 2018-06-11 22:20:04 --> CSRF cookie sent
INFO - 2018-06-11 22:20:04 --> Language Class Initialized
INFO - 2018-06-11 22:20:04 --> Language Class Initialized
INFO - 2018-06-11 22:20:04 --> Language Class Initialized
INFO - 2018-06-11 22:20:04 --> Input Class Initialized
ERROR - 2018-06-11 22:20:04 --> 404 Page Not Found: Images/team
INFO - 2018-06-11 22:20:04 --> Language Class Initialized
ERROR - 2018-06-11 22:20:04 --> 404 Page Not Found: Images/team
ERROR - 2018-06-11 22:20:04 --> 404 Page Not Found: Images/team
ERROR - 2018-06-11 22:20:04 --> 404 Page Not Found: Images/team
INFO - 2018-06-11 22:22:18 --> Config Class Initialized
INFO - 2018-06-11 22:22:18 --> Hooks Class Initialized
DEBUG - 2018-06-11 22:22:18 --> UTF-8 Support Enabled
INFO - 2018-06-11 22:22:18 --> Utf8 Class Initialized
INFO - 2018-06-11 22:22:18 --> URI Class Initialized
INFO - 2018-06-11 22:22:18 --> Router Class Initialized
INFO - 2018-06-11 22:22:18 --> Output Class Initialized
INFO - 2018-06-11 22:22:18 --> Security Class Initialized
DEBUG - 2018-06-11 22:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 22:22:18 --> CSRF cookie sent
INFO - 2018-06-11 22:22:18 --> Input Class Initialized
INFO - 2018-06-11 22:22:19 --> Language Class Initialized
INFO - 2018-06-11 22:22:19 --> Loader Class Initialized
INFO - 2018-06-11 22:22:19 --> Helper loaded: url_helper
INFO - 2018-06-11 22:22:19 --> Helper loaded: form_helper
INFO - 2018-06-11 22:22:19 --> Helper loaded: language_helper
DEBUG - 2018-06-11 22:22:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 22:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 22:22:19 --> User Agent Class Initialized
INFO - 2018-06-11 22:22:19 --> Controller Class Initialized
INFO - 2018-06-11 22:22:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 22:22:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 22:22:19 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 22:22:19 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 22:22:19 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 22:22:19 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 22:22:19 --> File loaded: E:\www\yacopoo\application\views\professions.php
INFO - 2018-06-11 22:22:19 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 22:22:19 --> Final output sent to browser
DEBUG - 2018-06-11 22:22:19 --> Total execution time: 0.4022
INFO - 2018-06-11 22:22:42 --> Config Class Initialized
INFO - 2018-06-11 22:22:42 --> Hooks Class Initialized
DEBUG - 2018-06-11 22:22:42 --> UTF-8 Support Enabled
INFO - 2018-06-11 22:22:42 --> Utf8 Class Initialized
INFO - 2018-06-11 22:22:42 --> URI Class Initialized
INFO - 2018-06-11 22:22:42 --> Router Class Initialized
INFO - 2018-06-11 22:22:42 --> Output Class Initialized
INFO - 2018-06-11 22:22:42 --> Security Class Initialized
DEBUG - 2018-06-11 22:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 22:22:42 --> CSRF cookie sent
INFO - 2018-06-11 22:22:42 --> Input Class Initialized
INFO - 2018-06-11 22:22:42 --> Language Class Initialized
INFO - 2018-06-11 22:22:42 --> Loader Class Initialized
INFO - 2018-06-11 22:22:42 --> Helper loaded: url_helper
INFO - 2018-06-11 22:22:42 --> Helper loaded: form_helper
INFO - 2018-06-11 22:22:42 --> Helper loaded: language_helper
DEBUG - 2018-06-11 22:22:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 22:22:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 22:22:42 --> User Agent Class Initialized
INFO - 2018-06-11 22:22:42 --> Controller Class Initialized
INFO - 2018-06-11 22:22:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 22:22:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 22:22:42 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 22:22:42 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 22:22:42 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 22:22:42 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 22:22:42 --> File loaded: E:\www\yacopoo\application\views\professions.php
INFO - 2018-06-11 22:22:42 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 22:22:42 --> Final output sent to browser
DEBUG - 2018-06-11 22:22:42 --> Total execution time: 0.4015
INFO - 2018-06-11 22:24:25 --> Config Class Initialized
INFO - 2018-06-11 22:24:25 --> Hooks Class Initialized
DEBUG - 2018-06-11 22:24:25 --> UTF-8 Support Enabled
INFO - 2018-06-11 22:24:25 --> Utf8 Class Initialized
INFO - 2018-06-11 22:24:25 --> URI Class Initialized
INFO - 2018-06-11 22:24:25 --> Router Class Initialized
INFO - 2018-06-11 22:24:25 --> Output Class Initialized
INFO - 2018-06-11 22:24:25 --> Security Class Initialized
DEBUG - 2018-06-11 22:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 22:24:26 --> CSRF cookie sent
INFO - 2018-06-11 22:24:26 --> Input Class Initialized
INFO - 2018-06-11 22:24:26 --> Language Class Initialized
INFO - 2018-06-11 22:24:26 --> Loader Class Initialized
INFO - 2018-06-11 22:24:26 --> Helper loaded: url_helper
INFO - 2018-06-11 22:24:26 --> Helper loaded: form_helper
INFO - 2018-06-11 22:24:26 --> Helper loaded: language_helper
DEBUG - 2018-06-11 22:24:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 22:24:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 22:24:26 --> User Agent Class Initialized
INFO - 2018-06-11 22:24:26 --> Controller Class Initialized
INFO - 2018-06-11 22:24:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 22:24:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 22:24:26 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 22:24:26 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 22:24:26 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 22:24:26 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 22:24:26 --> File loaded: E:\www\yacopoo\application\views\advisors.php
INFO - 2018-06-11 22:24:26 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 22:24:26 --> Final output sent to browser
DEBUG - 2018-06-11 22:24:26 --> Total execution time: 0.4007
INFO - 2018-06-11 22:25:50 --> Config Class Initialized
INFO - 2018-06-11 22:25:51 --> Hooks Class Initialized
DEBUG - 2018-06-11 22:25:51 --> UTF-8 Support Enabled
INFO - 2018-06-11 22:25:51 --> Utf8 Class Initialized
INFO - 2018-06-11 22:25:51 --> URI Class Initialized
INFO - 2018-06-11 22:25:51 --> Router Class Initialized
INFO - 2018-06-11 22:25:51 --> Output Class Initialized
INFO - 2018-06-11 22:25:51 --> Security Class Initialized
DEBUG - 2018-06-11 22:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 22:25:51 --> CSRF cookie sent
INFO - 2018-06-11 22:25:51 --> Input Class Initialized
INFO - 2018-06-11 22:25:51 --> Language Class Initialized
INFO - 2018-06-11 22:25:51 --> Loader Class Initialized
INFO - 2018-06-11 22:25:51 --> Helper loaded: url_helper
INFO - 2018-06-11 22:25:51 --> Helper loaded: form_helper
INFO - 2018-06-11 22:25:51 --> Helper loaded: language_helper
DEBUG - 2018-06-11 22:25:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 22:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 22:25:51 --> User Agent Class Initialized
INFO - 2018-06-11 22:25:51 --> Controller Class Initialized
INFO - 2018-06-11 22:25:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 22:25:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 22:25:51 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 22:25:51 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 22:25:51 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 22:25:51 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 22:25:51 --> File loaded: E:\www\yacopoo\application\views\professions.php
INFO - 2018-06-11 22:25:51 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 22:25:51 --> Final output sent to browser
DEBUG - 2018-06-11 22:25:51 --> Total execution time: 0.4107
INFO - 2018-06-11 22:30:26 --> Config Class Initialized
INFO - 2018-06-11 22:30:26 --> Hooks Class Initialized
DEBUG - 2018-06-11 22:30:26 --> UTF-8 Support Enabled
INFO - 2018-06-11 22:30:26 --> Utf8 Class Initialized
INFO - 2018-06-11 22:30:26 --> URI Class Initialized
INFO - 2018-06-11 22:30:26 --> Router Class Initialized
INFO - 2018-06-11 22:30:26 --> Output Class Initialized
INFO - 2018-06-11 22:30:26 --> Security Class Initialized
DEBUG - 2018-06-11 22:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 22:30:26 --> CSRF cookie sent
INFO - 2018-06-11 22:30:26 --> Input Class Initialized
INFO - 2018-06-11 22:30:26 --> Language Class Initialized
INFO - 2018-06-11 22:30:26 --> Loader Class Initialized
INFO - 2018-06-11 22:30:26 --> Helper loaded: url_helper
INFO - 2018-06-11 22:30:26 --> Helper loaded: form_helper
INFO - 2018-06-11 22:30:26 --> Helper loaded: language_helper
DEBUG - 2018-06-11 22:30:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 22:30:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 22:30:26 --> User Agent Class Initialized
INFO - 2018-06-11 22:30:26 --> Controller Class Initialized
INFO - 2018-06-11 22:30:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 22:30:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 22:30:26 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 22:30:26 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 22:30:26 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 22:30:26 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 22:30:26 --> File loaded: E:\www\yacopoo\application\views\professions.php
INFO - 2018-06-11 22:30:26 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 22:30:26 --> Final output sent to browser
DEBUG - 2018-06-11 22:30:26 --> Total execution time: 0.4086
INFO - 2018-06-11 22:30:55 --> Config Class Initialized
INFO - 2018-06-11 22:30:55 --> Hooks Class Initialized
DEBUG - 2018-06-11 22:30:55 --> UTF-8 Support Enabled
INFO - 2018-06-11 22:30:55 --> Utf8 Class Initialized
INFO - 2018-06-11 22:30:55 --> URI Class Initialized
INFO - 2018-06-11 22:30:55 --> Router Class Initialized
INFO - 2018-06-11 22:30:55 --> Output Class Initialized
INFO - 2018-06-11 22:30:55 --> Security Class Initialized
DEBUG - 2018-06-11 22:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 22:30:55 --> CSRF cookie sent
INFO - 2018-06-11 22:30:55 --> Input Class Initialized
INFO - 2018-06-11 22:30:55 --> Language Class Initialized
INFO - 2018-06-11 22:30:55 --> Loader Class Initialized
INFO - 2018-06-11 22:30:55 --> Helper loaded: url_helper
INFO - 2018-06-11 22:30:55 --> Helper loaded: form_helper
INFO - 2018-06-11 22:30:55 --> Helper loaded: language_helper
DEBUG - 2018-06-11 22:30:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 22:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 22:30:55 --> User Agent Class Initialized
INFO - 2018-06-11 22:30:55 --> Controller Class Initialized
INFO - 2018-06-11 22:30:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 22:30:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 22:30:55 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 22:30:55 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 22:30:55 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 22:30:55 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 22:30:55 --> File loaded: E:\www\yacopoo\application\views\professions.php
INFO - 2018-06-11 22:30:55 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 22:30:55 --> Final output sent to browser
DEBUG - 2018-06-11 22:30:55 --> Total execution time: 0.4184
INFO - 2018-06-11 22:31:31 --> Config Class Initialized
INFO - 2018-06-11 22:31:31 --> Hooks Class Initialized
DEBUG - 2018-06-11 22:31:31 --> UTF-8 Support Enabled
INFO - 2018-06-11 22:31:31 --> Utf8 Class Initialized
INFO - 2018-06-11 22:31:31 --> URI Class Initialized
INFO - 2018-06-11 22:31:31 --> Router Class Initialized
INFO - 2018-06-11 22:31:31 --> Output Class Initialized
INFO - 2018-06-11 22:31:31 --> Security Class Initialized
DEBUG - 2018-06-11 22:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 22:31:31 --> CSRF cookie sent
INFO - 2018-06-11 22:31:31 --> Input Class Initialized
INFO - 2018-06-11 22:31:31 --> Language Class Initialized
INFO - 2018-06-11 22:31:31 --> Loader Class Initialized
INFO - 2018-06-11 22:31:31 --> Helper loaded: url_helper
INFO - 2018-06-11 22:31:31 --> Helper loaded: form_helper
INFO - 2018-06-11 22:31:31 --> Helper loaded: language_helper
DEBUG - 2018-06-11 22:31:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 22:31:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 22:31:31 --> User Agent Class Initialized
INFO - 2018-06-11 22:31:31 --> Controller Class Initialized
INFO - 2018-06-11 22:31:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 22:31:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 22:31:31 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 22:31:31 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 22:31:31 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 22:31:31 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 22:31:31 --> File loaded: E:\www\yacopoo\application\views\professions.php
INFO - 2018-06-11 22:31:31 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 22:31:31 --> Final output sent to browser
DEBUG - 2018-06-11 22:31:31 --> Total execution time: 0.4036
INFO - 2018-06-11 22:32:55 --> Config Class Initialized
INFO - 2018-06-11 22:32:55 --> Hooks Class Initialized
DEBUG - 2018-06-11 22:32:55 --> UTF-8 Support Enabled
INFO - 2018-06-11 22:32:55 --> Utf8 Class Initialized
INFO - 2018-06-11 22:32:55 --> URI Class Initialized
INFO - 2018-06-11 22:32:55 --> Router Class Initialized
INFO - 2018-06-11 22:32:55 --> Output Class Initialized
INFO - 2018-06-11 22:32:55 --> Security Class Initialized
DEBUG - 2018-06-11 22:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 22:32:55 --> CSRF cookie sent
INFO - 2018-06-11 22:32:55 --> Input Class Initialized
INFO - 2018-06-11 22:32:55 --> Language Class Initialized
INFO - 2018-06-11 22:32:55 --> Loader Class Initialized
INFO - 2018-06-11 22:32:55 --> Helper loaded: url_helper
INFO - 2018-06-11 22:32:55 --> Helper loaded: form_helper
INFO - 2018-06-11 22:32:55 --> Helper loaded: language_helper
DEBUG - 2018-06-11 22:32:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 22:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 22:32:55 --> User Agent Class Initialized
INFO - 2018-06-11 22:32:55 --> Controller Class Initialized
INFO - 2018-06-11 22:32:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 22:32:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 22:32:55 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 22:32:55 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 22:32:55 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 22:32:55 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 22:32:55 --> File loaded: E:\www\yacopoo\application\views\professions.php
INFO - 2018-06-11 22:32:55 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 22:32:55 --> Final output sent to browser
DEBUG - 2018-06-11 22:32:56 --> Total execution time: 0.4061
INFO - 2018-06-11 22:38:56 --> Config Class Initialized
INFO - 2018-06-11 22:38:56 --> Hooks Class Initialized
DEBUG - 2018-06-11 22:38:56 --> UTF-8 Support Enabled
INFO - 2018-06-11 22:38:56 --> Utf8 Class Initialized
INFO - 2018-06-11 22:38:56 --> URI Class Initialized
INFO - 2018-06-11 22:38:56 --> Router Class Initialized
INFO - 2018-06-11 22:38:56 --> Output Class Initialized
INFO - 2018-06-11 22:38:56 --> Security Class Initialized
DEBUG - 2018-06-11 22:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 22:38:56 --> CSRF cookie sent
INFO - 2018-06-11 22:38:56 --> Input Class Initialized
INFO - 2018-06-11 22:38:56 --> Language Class Initialized
INFO - 2018-06-11 22:38:56 --> Loader Class Initialized
INFO - 2018-06-11 22:38:56 --> Helper loaded: url_helper
INFO - 2018-06-11 22:38:56 --> Helper loaded: form_helper
INFO - 2018-06-11 22:38:56 --> Helper loaded: language_helper
DEBUG - 2018-06-11 22:38:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 22:38:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 22:38:56 --> User Agent Class Initialized
INFO - 2018-06-11 22:38:56 --> Controller Class Initialized
INFO - 2018-06-11 22:38:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 22:38:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 22:38:56 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 22:38:56 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 22:38:56 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 22:38:56 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 22:38:56 --> File loaded: E:\www\yacopoo\application\views\professions.php
INFO - 2018-06-11 22:38:56 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 22:38:56 --> Final output sent to browser
DEBUG - 2018-06-11 22:38:56 --> Total execution time: 0.4157
INFO - 2018-06-11 22:38:58 --> Config Class Initialized
INFO - 2018-06-11 22:38:58 --> Hooks Class Initialized
DEBUG - 2018-06-11 22:38:58 --> UTF-8 Support Enabled
INFO - 2018-06-11 22:38:58 --> Utf8 Class Initialized
INFO - 2018-06-11 22:38:58 --> URI Class Initialized
INFO - 2018-06-11 22:38:58 --> Router Class Initialized
INFO - 2018-06-11 22:38:58 --> Output Class Initialized
INFO - 2018-06-11 22:38:58 --> Security Class Initialized
DEBUG - 2018-06-11 22:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 22:38:58 --> CSRF cookie sent
INFO - 2018-06-11 22:38:58 --> Input Class Initialized
INFO - 2018-06-11 22:38:58 --> Language Class Initialized
INFO - 2018-06-11 22:38:58 --> Loader Class Initialized
INFO - 2018-06-11 22:38:58 --> Helper loaded: url_helper
INFO - 2018-06-11 22:38:58 --> Helper loaded: form_helper
INFO - 2018-06-11 22:38:58 --> Helper loaded: language_helper
DEBUG - 2018-06-11 22:38:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 22:38:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 22:38:58 --> User Agent Class Initialized
INFO - 2018-06-11 22:38:58 --> Controller Class Initialized
INFO - 2018-06-11 22:38:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 22:38:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 22:38:58 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 22:38:58 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 22:38:58 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 22:38:58 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 22:38:58 --> File loaded: E:\www\yacopoo\application\views\911.php
INFO - 2018-06-11 22:38:58 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 22:38:58 --> Final output sent to browser
DEBUG - 2018-06-11 22:38:58 --> Total execution time: 0.4096
INFO - 2018-06-11 22:39:04 --> Config Class Initialized
INFO - 2018-06-11 22:39:04 --> Hooks Class Initialized
DEBUG - 2018-06-11 22:39:04 --> UTF-8 Support Enabled
INFO - 2018-06-11 22:39:04 --> Utf8 Class Initialized
INFO - 2018-06-11 22:39:04 --> URI Class Initialized
INFO - 2018-06-11 22:39:04 --> Router Class Initialized
INFO - 2018-06-11 22:39:04 --> Output Class Initialized
INFO - 2018-06-11 22:39:05 --> Security Class Initialized
DEBUG - 2018-06-11 22:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 22:39:05 --> CSRF cookie sent
INFO - 2018-06-11 22:39:05 --> Input Class Initialized
INFO - 2018-06-11 22:39:05 --> Language Class Initialized
ERROR - 2018-06-11 22:39:05 --> 404 Page Not Found: Assets/css
INFO - 2018-06-11 22:39:28 --> Config Class Initialized
INFO - 2018-06-11 22:39:28 --> Hooks Class Initialized
DEBUG - 2018-06-11 22:39:28 --> UTF-8 Support Enabled
INFO - 2018-06-11 22:39:28 --> Utf8 Class Initialized
INFO - 2018-06-11 22:39:28 --> URI Class Initialized
INFO - 2018-06-11 22:39:29 --> Router Class Initialized
INFO - 2018-06-11 22:39:29 --> Output Class Initialized
INFO - 2018-06-11 22:39:29 --> Security Class Initialized
DEBUG - 2018-06-11 22:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 22:39:29 --> CSRF cookie sent
INFO - 2018-06-11 22:39:29 --> Input Class Initialized
INFO - 2018-06-11 22:39:29 --> Language Class Initialized
INFO - 2018-06-11 22:39:29 --> Loader Class Initialized
INFO - 2018-06-11 22:39:29 --> Helper loaded: url_helper
INFO - 2018-06-11 22:39:29 --> Helper loaded: form_helper
INFO - 2018-06-11 22:39:29 --> Helper loaded: language_helper
DEBUG - 2018-06-11 22:39:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 22:39:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 22:39:29 --> User Agent Class Initialized
INFO - 2018-06-11 22:39:29 --> Controller Class Initialized
INFO - 2018-06-11 22:39:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 22:39:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 22:39:29 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 22:39:29 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 22:39:29 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 22:39:29 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 22:39:29 --> File loaded: E:\www\yacopoo\application\views\911.php
INFO - 2018-06-11 22:39:29 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 22:39:29 --> Final output sent to browser
DEBUG - 2018-06-11 22:39:29 --> Total execution time: 0.4168
INFO - 2018-06-11 22:39:38 --> Config Class Initialized
INFO - 2018-06-11 22:39:38 --> Hooks Class Initialized
DEBUG - 2018-06-11 22:39:38 --> UTF-8 Support Enabled
INFO - 2018-06-11 22:39:38 --> Utf8 Class Initialized
INFO - 2018-06-11 22:39:38 --> URI Class Initialized
INFO - 2018-06-11 22:39:38 --> Router Class Initialized
INFO - 2018-06-11 22:39:38 --> Output Class Initialized
INFO - 2018-06-11 22:39:38 --> Security Class Initialized
DEBUG - 2018-06-11 22:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 22:39:38 --> CSRF cookie sent
INFO - 2018-06-11 22:39:38 --> Input Class Initialized
INFO - 2018-06-11 22:39:38 --> Language Class Initialized
ERROR - 2018-06-11 22:39:38 --> 404 Page Not Found: Assets/css
INFO - 2018-06-11 22:40:16 --> Config Class Initialized
INFO - 2018-06-11 22:40:16 --> Hooks Class Initialized
DEBUG - 2018-06-11 22:40:16 --> UTF-8 Support Enabled
INFO - 2018-06-11 22:40:16 --> Utf8 Class Initialized
INFO - 2018-06-11 22:40:16 --> URI Class Initialized
INFO - 2018-06-11 22:40:16 --> Router Class Initialized
INFO - 2018-06-11 22:40:16 --> Output Class Initialized
INFO - 2018-06-11 22:40:16 --> Security Class Initialized
DEBUG - 2018-06-11 22:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 22:40:16 --> CSRF cookie sent
INFO - 2018-06-11 22:40:16 --> Input Class Initialized
INFO - 2018-06-11 22:40:16 --> Language Class Initialized
INFO - 2018-06-11 22:40:16 --> Loader Class Initialized
INFO - 2018-06-11 22:40:17 --> Helper loaded: url_helper
INFO - 2018-06-11 22:40:17 --> Helper loaded: form_helper
INFO - 2018-06-11 22:40:17 --> Helper loaded: language_helper
DEBUG - 2018-06-11 22:40:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 22:40:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 22:40:17 --> User Agent Class Initialized
INFO - 2018-06-11 22:40:17 --> Controller Class Initialized
INFO - 2018-06-11 22:40:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 22:40:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 22:40:17 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 22:40:17 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 22:40:17 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 22:40:17 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 22:40:17 --> File loaded: E:\www\yacopoo\application\views\911.php
INFO - 2018-06-11 22:40:17 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 22:40:17 --> Final output sent to browser
DEBUG - 2018-06-11 22:40:17 --> Total execution time: 0.4209
INFO - 2018-06-11 22:40:17 --> Config Class Initialized
INFO - 2018-06-11 22:40:17 --> Hooks Class Initialized
DEBUG - 2018-06-11 22:40:17 --> UTF-8 Support Enabled
INFO - 2018-06-11 22:40:17 --> Utf8 Class Initialized
INFO - 2018-06-11 22:40:17 --> URI Class Initialized
INFO - 2018-06-11 22:40:17 --> Router Class Initialized
INFO - 2018-06-11 22:40:17 --> Output Class Initialized
INFO - 2018-06-11 22:40:17 --> Security Class Initialized
DEBUG - 2018-06-11 22:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 22:40:17 --> CSRF cookie sent
INFO - 2018-06-11 22:40:17 --> Input Class Initialized
INFO - 2018-06-11 22:40:17 --> Language Class Initialized
ERROR - 2018-06-11 22:40:17 --> 404 Page Not Found: Assets/css
INFO - 2018-06-11 22:40:30 --> Config Class Initialized
INFO - 2018-06-11 22:40:30 --> Hooks Class Initialized
DEBUG - 2018-06-11 22:40:30 --> UTF-8 Support Enabled
INFO - 2018-06-11 22:40:30 --> Utf8 Class Initialized
INFO - 2018-06-11 22:40:30 --> URI Class Initialized
INFO - 2018-06-11 22:40:30 --> Router Class Initialized
INFO - 2018-06-11 22:40:30 --> Output Class Initialized
INFO - 2018-06-11 22:40:30 --> Security Class Initialized
DEBUG - 2018-06-11 22:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 22:40:30 --> CSRF cookie sent
INFO - 2018-06-11 22:40:30 --> Input Class Initialized
INFO - 2018-06-11 22:40:30 --> Language Class Initialized
INFO - 2018-06-11 22:40:30 --> Loader Class Initialized
INFO - 2018-06-11 22:40:30 --> Helper loaded: url_helper
INFO - 2018-06-11 22:40:30 --> Helper loaded: form_helper
INFO - 2018-06-11 22:40:30 --> Helper loaded: language_helper
DEBUG - 2018-06-11 22:40:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 22:40:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 22:40:30 --> User Agent Class Initialized
INFO - 2018-06-11 22:40:30 --> Controller Class Initialized
INFO - 2018-06-11 22:40:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 22:40:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 22:40:30 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 22:40:30 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 22:40:30 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 22:40:30 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 22:40:30 --> File loaded: E:\www\yacopoo\application\views\advisors.php
INFO - 2018-06-11 22:40:30 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 22:40:30 --> Final output sent to browser
DEBUG - 2018-06-11 22:40:30 --> Total execution time: 0.4189
INFO - 2018-06-11 22:40:31 --> Config Class Initialized
INFO - 2018-06-11 22:40:31 --> Hooks Class Initialized
DEBUG - 2018-06-11 22:40:31 --> UTF-8 Support Enabled
INFO - 2018-06-11 22:40:31 --> Utf8 Class Initialized
INFO - 2018-06-11 22:40:31 --> URI Class Initialized
INFO - 2018-06-11 22:40:31 --> Router Class Initialized
INFO - 2018-06-11 22:40:31 --> Output Class Initialized
INFO - 2018-06-11 22:40:31 --> Security Class Initialized
DEBUG - 2018-06-11 22:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 22:40:31 --> CSRF cookie sent
INFO - 2018-06-11 22:40:31 --> Input Class Initialized
INFO - 2018-06-11 22:40:31 --> Language Class Initialized
ERROR - 2018-06-11 22:40:31 --> 404 Page Not Found: Assets/css
INFO - 2018-06-11 22:42:00 --> Config Class Initialized
INFO - 2018-06-11 22:42:00 --> Hooks Class Initialized
DEBUG - 2018-06-11 22:42:00 --> UTF-8 Support Enabled
INFO - 2018-06-11 22:42:00 --> Utf8 Class Initialized
INFO - 2018-06-11 22:42:00 --> URI Class Initialized
INFO - 2018-06-11 22:42:00 --> Router Class Initialized
INFO - 2018-06-11 22:42:00 --> Output Class Initialized
INFO - 2018-06-11 22:42:00 --> Security Class Initialized
DEBUG - 2018-06-11 22:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 22:42:00 --> CSRF cookie sent
INFO - 2018-06-11 22:42:00 --> Input Class Initialized
INFO - 2018-06-11 22:42:00 --> Language Class Initialized
INFO - 2018-06-11 22:42:00 --> Loader Class Initialized
INFO - 2018-06-11 22:42:00 --> Helper loaded: url_helper
INFO - 2018-06-11 22:42:00 --> Helper loaded: form_helper
INFO - 2018-06-11 22:42:00 --> Helper loaded: language_helper
DEBUG - 2018-06-11 22:42:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 22:42:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 22:42:00 --> User Agent Class Initialized
INFO - 2018-06-11 22:42:00 --> Controller Class Initialized
INFO - 2018-06-11 22:42:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 22:42:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 22:42:00 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 22:42:00 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 22:42:00 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 22:42:00 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 22:42:00 --> File loaded: E:\www\yacopoo\application\views\professions.php
INFO - 2018-06-11 22:42:00 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 22:42:00 --> Final output sent to browser
DEBUG - 2018-06-11 22:42:00 --> Total execution time: 0.4139
INFO - 2018-06-11 22:42:01 --> Config Class Initialized
INFO - 2018-06-11 22:42:01 --> Hooks Class Initialized
DEBUG - 2018-06-11 22:42:01 --> UTF-8 Support Enabled
INFO - 2018-06-11 22:42:01 --> Utf8 Class Initialized
INFO - 2018-06-11 22:42:01 --> URI Class Initialized
INFO - 2018-06-11 22:42:01 --> Router Class Initialized
INFO - 2018-06-11 22:42:01 --> Output Class Initialized
INFO - 2018-06-11 22:42:01 --> Security Class Initialized
DEBUG - 2018-06-11 22:42:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 22:42:01 --> CSRF cookie sent
INFO - 2018-06-11 22:42:01 --> Input Class Initialized
INFO - 2018-06-11 22:42:01 --> Language Class Initialized
ERROR - 2018-06-11 22:42:01 --> 404 Page Not Found: Assets/css
INFO - 2018-06-11 22:42:02 --> Config Class Initialized
INFO - 2018-06-11 22:42:02 --> Hooks Class Initialized
DEBUG - 2018-06-11 22:42:02 --> UTF-8 Support Enabled
INFO - 2018-06-11 22:42:02 --> Utf8 Class Initialized
INFO - 2018-06-11 22:42:02 --> URI Class Initialized
INFO - 2018-06-11 22:42:02 --> Router Class Initialized
INFO - 2018-06-11 22:42:02 --> Output Class Initialized
INFO - 2018-06-11 22:42:02 --> Security Class Initialized
DEBUG - 2018-06-11 22:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 22:42:02 --> CSRF cookie sent
INFO - 2018-06-11 22:42:02 --> Input Class Initialized
INFO - 2018-06-11 22:42:02 --> Language Class Initialized
INFO - 2018-06-11 22:42:02 --> Loader Class Initialized
INFO - 2018-06-11 22:42:02 --> Helper loaded: url_helper
INFO - 2018-06-11 22:42:02 --> Helper loaded: form_helper
INFO - 2018-06-11 22:42:02 --> Helper loaded: language_helper
DEBUG - 2018-06-11 22:42:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 22:42:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 22:42:02 --> User Agent Class Initialized
INFO - 2018-06-11 22:42:02 --> Controller Class Initialized
INFO - 2018-06-11 22:42:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 22:42:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 22:42:02 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 22:42:02 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 22:42:02 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 22:42:02 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 22:42:02 --> File loaded: E:\www\yacopoo\application\views\911.php
INFO - 2018-06-11 22:42:02 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 22:42:02 --> Final output sent to browser
DEBUG - 2018-06-11 22:42:02 --> Total execution time: 0.4526
INFO - 2018-06-11 22:42:03 --> Config Class Initialized
INFO - 2018-06-11 22:42:03 --> Hooks Class Initialized
DEBUG - 2018-06-11 22:42:03 --> UTF-8 Support Enabled
INFO - 2018-06-11 22:42:03 --> Utf8 Class Initialized
INFO - 2018-06-11 22:42:03 --> URI Class Initialized
INFO - 2018-06-11 22:42:03 --> Router Class Initialized
INFO - 2018-06-11 22:42:03 --> Output Class Initialized
INFO - 2018-06-11 22:42:03 --> Security Class Initialized
DEBUG - 2018-06-11 22:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 22:42:03 --> CSRF cookie sent
INFO - 2018-06-11 22:42:03 --> Input Class Initialized
INFO - 2018-06-11 22:42:03 --> Language Class Initialized
ERROR - 2018-06-11 22:42:03 --> 404 Page Not Found: Assets/css
INFO - 2018-06-11 22:42:05 --> Config Class Initialized
INFO - 2018-06-11 22:42:05 --> Hooks Class Initialized
DEBUG - 2018-06-11 22:42:05 --> UTF-8 Support Enabled
INFO - 2018-06-11 22:42:05 --> Utf8 Class Initialized
INFO - 2018-06-11 22:42:05 --> URI Class Initialized
INFO - 2018-06-11 22:42:05 --> Router Class Initialized
INFO - 2018-06-11 22:42:05 --> Output Class Initialized
INFO - 2018-06-11 22:42:05 --> Security Class Initialized
DEBUG - 2018-06-11 22:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 22:42:05 --> CSRF cookie sent
INFO - 2018-06-11 22:42:05 --> Input Class Initialized
INFO - 2018-06-11 22:42:05 --> Language Class Initialized
INFO - 2018-06-11 22:42:05 --> Loader Class Initialized
INFO - 2018-06-11 22:42:05 --> Helper loaded: url_helper
INFO - 2018-06-11 22:42:05 --> Helper loaded: form_helper
INFO - 2018-06-11 22:42:05 --> Helper loaded: language_helper
DEBUG - 2018-06-11 22:42:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 22:42:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 22:42:05 --> User Agent Class Initialized
INFO - 2018-06-11 22:42:05 --> Controller Class Initialized
INFO - 2018-06-11 22:42:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 22:42:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 22:42:05 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 22:42:05 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 22:42:05 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 22:42:05 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 22:42:05 --> File loaded: E:\www\yacopoo\application\views\911.php
INFO - 2018-06-11 22:42:05 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 22:42:05 --> Final output sent to browser
DEBUG - 2018-06-11 22:42:05 --> Total execution time: 0.4577
INFO - 2018-06-11 22:42:06 --> Config Class Initialized
INFO - 2018-06-11 22:42:06 --> Hooks Class Initialized
DEBUG - 2018-06-11 22:42:06 --> UTF-8 Support Enabled
INFO - 2018-06-11 22:42:06 --> Utf8 Class Initialized
INFO - 2018-06-11 22:42:06 --> URI Class Initialized
INFO - 2018-06-11 22:42:06 --> Router Class Initialized
INFO - 2018-06-11 22:42:06 --> Output Class Initialized
INFO - 2018-06-11 22:42:06 --> Security Class Initialized
DEBUG - 2018-06-11 22:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 22:42:06 --> CSRF cookie sent
INFO - 2018-06-11 22:42:06 --> Input Class Initialized
INFO - 2018-06-11 22:42:06 --> Language Class Initialized
ERROR - 2018-06-11 22:42:06 --> 404 Page Not Found: Assets/css
INFO - 2018-06-11 22:42:45 --> Config Class Initialized
INFO - 2018-06-11 22:42:45 --> Hooks Class Initialized
DEBUG - 2018-06-11 22:42:45 --> UTF-8 Support Enabled
INFO - 2018-06-11 22:42:45 --> Utf8 Class Initialized
INFO - 2018-06-11 22:42:45 --> URI Class Initialized
INFO - 2018-06-11 22:42:45 --> Router Class Initialized
INFO - 2018-06-11 22:42:45 --> Output Class Initialized
INFO - 2018-06-11 22:42:45 --> Security Class Initialized
DEBUG - 2018-06-11 22:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 22:42:45 --> CSRF cookie sent
INFO - 2018-06-11 22:42:45 --> Input Class Initialized
INFO - 2018-06-11 22:42:45 --> Language Class Initialized
INFO - 2018-06-11 22:42:45 --> Loader Class Initialized
INFO - 2018-06-11 22:42:45 --> Helper loaded: url_helper
INFO - 2018-06-11 22:42:45 --> Helper loaded: form_helper
INFO - 2018-06-11 22:42:45 --> Helper loaded: language_helper
DEBUG - 2018-06-11 22:42:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 22:42:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 22:42:45 --> User Agent Class Initialized
INFO - 2018-06-11 22:42:45 --> Controller Class Initialized
INFO - 2018-06-11 22:42:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 22:42:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 22:42:45 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 22:42:45 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 22:42:45 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 22:42:45 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 22:42:45 --> File loaded: E:\www\yacopoo\application\views\911.php
INFO - 2018-06-11 22:42:45 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 22:42:45 --> Final output sent to browser
DEBUG - 2018-06-11 22:42:45 --> Total execution time: 0.4262
INFO - 2018-06-11 22:42:46 --> Config Class Initialized
INFO - 2018-06-11 22:42:46 --> Hooks Class Initialized
DEBUG - 2018-06-11 22:42:46 --> UTF-8 Support Enabled
INFO - 2018-06-11 22:42:46 --> Utf8 Class Initialized
INFO - 2018-06-11 22:42:46 --> URI Class Initialized
INFO - 2018-06-11 22:42:46 --> Router Class Initialized
INFO - 2018-06-11 22:42:46 --> Output Class Initialized
INFO - 2018-06-11 22:42:46 --> Security Class Initialized
DEBUG - 2018-06-11 22:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 22:42:46 --> CSRF cookie sent
INFO - 2018-06-11 22:42:46 --> Input Class Initialized
INFO - 2018-06-11 22:42:46 --> Language Class Initialized
ERROR - 2018-06-11 22:42:46 --> 404 Page Not Found: Assets/css
INFO - 2018-06-11 22:46:30 --> Config Class Initialized
INFO - 2018-06-11 22:46:30 --> Hooks Class Initialized
DEBUG - 2018-06-11 22:46:30 --> UTF-8 Support Enabled
INFO - 2018-06-11 22:46:30 --> Utf8 Class Initialized
INFO - 2018-06-11 22:46:30 --> URI Class Initialized
INFO - 2018-06-11 22:46:30 --> Router Class Initialized
INFO - 2018-06-11 22:46:30 --> Output Class Initialized
INFO - 2018-06-11 22:46:30 --> Security Class Initialized
DEBUG - 2018-06-11 22:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 22:46:30 --> CSRF cookie sent
INFO - 2018-06-11 22:46:30 --> Input Class Initialized
INFO - 2018-06-11 22:46:30 --> Language Class Initialized
INFO - 2018-06-11 22:46:30 --> Loader Class Initialized
INFO - 2018-06-11 22:46:30 --> Helper loaded: url_helper
INFO - 2018-06-11 22:46:30 --> Helper loaded: form_helper
INFO - 2018-06-11 22:46:30 --> Helper loaded: language_helper
DEBUG - 2018-06-11 22:46:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 22:46:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 22:46:30 --> User Agent Class Initialized
INFO - 2018-06-11 22:46:30 --> Controller Class Initialized
INFO - 2018-06-11 22:46:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 22:46:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 22:46:30 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 22:46:30 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 22:46:30 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 22:46:30 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 22:46:30 --> File loaded: E:\www\yacopoo\application\views\professions.php
INFO - 2018-06-11 22:46:30 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 22:46:30 --> Final output sent to browser
DEBUG - 2018-06-11 22:46:30 --> Total execution time: 0.4379
INFO - 2018-06-11 22:46:31 --> Config Class Initialized
INFO - 2018-06-11 22:46:31 --> Hooks Class Initialized
DEBUG - 2018-06-11 22:46:31 --> UTF-8 Support Enabled
INFO - 2018-06-11 22:46:31 --> Utf8 Class Initialized
INFO - 2018-06-11 22:46:31 --> URI Class Initialized
INFO - 2018-06-11 22:46:31 --> Router Class Initialized
INFO - 2018-06-11 22:46:31 --> Output Class Initialized
INFO - 2018-06-11 22:46:31 --> Security Class Initialized
DEBUG - 2018-06-11 22:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 22:46:31 --> CSRF cookie sent
INFO - 2018-06-11 22:46:31 --> Input Class Initialized
INFO - 2018-06-11 22:46:31 --> Language Class Initialized
ERROR - 2018-06-11 22:46:31 --> 404 Page Not Found: Assets/css
INFO - 2018-06-11 22:46:33 --> Config Class Initialized
INFO - 2018-06-11 22:46:33 --> Hooks Class Initialized
DEBUG - 2018-06-11 22:46:33 --> UTF-8 Support Enabled
INFO - 2018-06-11 22:46:33 --> Utf8 Class Initialized
INFO - 2018-06-11 22:46:33 --> URI Class Initialized
INFO - 2018-06-11 22:46:33 --> Router Class Initialized
INFO - 2018-06-11 22:46:33 --> Output Class Initialized
INFO - 2018-06-11 22:46:33 --> Security Class Initialized
DEBUG - 2018-06-11 22:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 22:46:33 --> CSRF cookie sent
INFO - 2018-06-11 22:46:33 --> Input Class Initialized
INFO - 2018-06-11 22:46:33 --> Language Class Initialized
INFO - 2018-06-11 22:46:33 --> Loader Class Initialized
INFO - 2018-06-11 22:46:33 --> Helper loaded: url_helper
INFO - 2018-06-11 22:46:33 --> Helper loaded: form_helper
INFO - 2018-06-11 22:46:33 --> Helper loaded: language_helper
DEBUG - 2018-06-11 22:46:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 22:46:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 22:46:33 --> User Agent Class Initialized
INFO - 2018-06-11 22:46:33 --> Controller Class Initialized
INFO - 2018-06-11 22:46:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 22:46:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 22:46:33 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 22:46:33 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 22:46:33 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 22:46:33 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 22:46:33 --> File loaded: E:\www\yacopoo\application\views\professions.php
INFO - 2018-06-11 22:46:33 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 22:46:33 --> Final output sent to browser
DEBUG - 2018-06-11 22:46:33 --> Total execution time: 0.5037
INFO - 2018-06-11 22:46:34 --> Config Class Initialized
INFO - 2018-06-11 22:46:34 --> Hooks Class Initialized
DEBUG - 2018-06-11 22:46:34 --> UTF-8 Support Enabled
INFO - 2018-06-11 22:46:34 --> Utf8 Class Initialized
INFO - 2018-06-11 22:46:34 --> URI Class Initialized
INFO - 2018-06-11 22:46:34 --> Router Class Initialized
INFO - 2018-06-11 22:46:34 --> Output Class Initialized
INFO - 2018-06-11 22:46:34 --> Security Class Initialized
DEBUG - 2018-06-11 22:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 22:46:34 --> CSRF cookie sent
INFO - 2018-06-11 22:46:34 --> Input Class Initialized
INFO - 2018-06-11 22:46:35 --> Language Class Initialized
INFO - 2018-06-11 22:46:35 --> Loader Class Initialized
INFO - 2018-06-11 22:46:35 --> Helper loaded: url_helper
INFO - 2018-06-11 22:46:35 --> Helper loaded: form_helper
INFO - 2018-06-11 22:46:35 --> Helper loaded: language_helper
DEBUG - 2018-06-11 22:46:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 22:46:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 22:46:35 --> User Agent Class Initialized
INFO - 2018-06-11 22:46:35 --> Controller Class Initialized
INFO - 2018-06-11 22:46:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 22:46:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 22:46:35 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 22:46:35 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 22:46:35 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 22:46:35 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 22:46:35 --> File loaded: E:\www\yacopoo\application\views\teacher.php
INFO - 2018-06-11 22:46:35 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 22:46:35 --> Final output sent to browser
DEBUG - 2018-06-11 22:46:35 --> Total execution time: 0.4320
INFO - 2018-06-11 22:46:39 --> Config Class Initialized
INFO - 2018-06-11 22:46:39 --> Hooks Class Initialized
DEBUG - 2018-06-11 22:46:39 --> UTF-8 Support Enabled
INFO - 2018-06-11 22:46:39 --> Utf8 Class Initialized
INFO - 2018-06-11 22:46:39 --> URI Class Initialized
INFO - 2018-06-11 22:46:39 --> Router Class Initialized
INFO - 2018-06-11 22:46:39 --> Output Class Initialized
INFO - 2018-06-11 22:46:39 --> Security Class Initialized
DEBUG - 2018-06-11 22:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 22:46:39 --> CSRF cookie sent
INFO - 2018-06-11 22:46:39 --> Input Class Initialized
INFO - 2018-06-11 22:46:39 --> Language Class Initialized
INFO - 2018-06-11 22:46:39 --> Loader Class Initialized
INFO - 2018-06-11 22:46:39 --> Helper loaded: url_helper
INFO - 2018-06-11 22:46:39 --> Helper loaded: form_helper
INFO - 2018-06-11 22:46:39 --> Helper loaded: language_helper
DEBUG - 2018-06-11 22:46:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 22:46:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 22:46:39 --> User Agent Class Initialized
INFO - 2018-06-11 22:46:39 --> Controller Class Initialized
INFO - 2018-06-11 22:46:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 22:46:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 22:46:39 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 22:46:39 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 22:46:39 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 22:46:39 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 22:46:39 --> File loaded: E:\www\yacopoo\application\views\professions.php
INFO - 2018-06-11 22:46:39 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 22:46:39 --> Final output sent to browser
DEBUG - 2018-06-11 22:46:39 --> Total execution time: 0.4637
INFO - 2018-06-11 22:46:40 --> Config Class Initialized
INFO - 2018-06-11 22:46:40 --> Hooks Class Initialized
DEBUG - 2018-06-11 22:46:40 --> UTF-8 Support Enabled
INFO - 2018-06-11 22:46:40 --> Utf8 Class Initialized
INFO - 2018-06-11 22:46:41 --> URI Class Initialized
INFO - 2018-06-11 22:46:41 --> Router Class Initialized
INFO - 2018-06-11 22:46:41 --> Output Class Initialized
INFO - 2018-06-11 22:46:41 --> Security Class Initialized
DEBUG - 2018-06-11 22:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 22:46:41 --> CSRF cookie sent
INFO - 2018-06-11 22:46:41 --> Input Class Initialized
INFO - 2018-06-11 22:46:41 --> Language Class Initialized
INFO - 2018-06-11 22:46:41 --> Loader Class Initialized
INFO - 2018-06-11 22:46:41 --> Helper loaded: url_helper
INFO - 2018-06-11 22:46:41 --> Helper loaded: form_helper
INFO - 2018-06-11 22:46:41 --> Helper loaded: language_helper
DEBUG - 2018-06-11 22:46:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 22:46:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 22:46:41 --> User Agent Class Initialized
INFO - 2018-06-11 22:46:41 --> Controller Class Initialized
INFO - 2018-06-11 22:46:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 22:46:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 22:46:41 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 22:46:41 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 22:46:41 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 22:46:41 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 22:46:41 --> File loaded: E:\www\yacopoo\application\views\medical.php
INFO - 2018-06-11 22:46:41 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 22:46:41 --> Final output sent to browser
DEBUG - 2018-06-11 22:46:41 --> Total execution time: 0.4266
INFO - 2018-06-11 22:46:43 --> Config Class Initialized
INFO - 2018-06-11 22:46:43 --> Hooks Class Initialized
DEBUG - 2018-06-11 22:46:43 --> UTF-8 Support Enabled
INFO - 2018-06-11 22:46:43 --> Utf8 Class Initialized
INFO - 2018-06-11 22:46:43 --> URI Class Initialized
INFO - 2018-06-11 22:46:43 --> Router Class Initialized
INFO - 2018-06-11 22:46:43 --> Output Class Initialized
INFO - 2018-06-11 22:46:43 --> Security Class Initialized
DEBUG - 2018-06-11 22:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 22:46:43 --> CSRF cookie sent
INFO - 2018-06-11 22:46:43 --> Input Class Initialized
INFO - 2018-06-11 22:46:43 --> Language Class Initialized
INFO - 2018-06-11 22:46:43 --> Loader Class Initialized
INFO - 2018-06-11 22:46:43 --> Helper loaded: url_helper
INFO - 2018-06-11 22:46:43 --> Helper loaded: form_helper
INFO - 2018-06-11 22:46:43 --> Helper loaded: language_helper
DEBUG - 2018-06-11 22:46:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 22:46:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 22:46:43 --> User Agent Class Initialized
INFO - 2018-06-11 22:46:43 --> Controller Class Initialized
INFO - 2018-06-11 22:46:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 22:46:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 22:46:43 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 22:46:43 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 22:46:43 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 22:46:43 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 22:46:43 --> File loaded: E:\www\yacopoo\application\views\professions.php
INFO - 2018-06-11 22:46:43 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 22:46:43 --> Final output sent to browser
DEBUG - 2018-06-11 22:46:43 --> Total execution time: 0.4926
INFO - 2018-06-11 22:46:44 --> Config Class Initialized
INFO - 2018-06-11 22:46:44 --> Hooks Class Initialized
DEBUG - 2018-06-11 22:46:44 --> UTF-8 Support Enabled
INFO - 2018-06-11 22:46:44 --> Utf8 Class Initialized
INFO - 2018-06-11 22:46:44 --> URI Class Initialized
INFO - 2018-06-11 22:46:44 --> Router Class Initialized
INFO - 2018-06-11 22:46:45 --> Output Class Initialized
INFO - 2018-06-11 22:46:45 --> Security Class Initialized
DEBUG - 2018-06-11 22:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 22:46:45 --> CSRF cookie sent
INFO - 2018-06-11 22:46:45 --> Input Class Initialized
INFO - 2018-06-11 22:46:45 --> Language Class Initialized
INFO - 2018-06-11 22:46:45 --> Loader Class Initialized
INFO - 2018-06-11 22:46:45 --> Helper loaded: url_helper
INFO - 2018-06-11 22:46:45 --> Helper loaded: form_helper
INFO - 2018-06-11 22:46:45 --> Helper loaded: language_helper
DEBUG - 2018-06-11 22:46:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 22:46:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 22:46:45 --> User Agent Class Initialized
INFO - 2018-06-11 22:46:45 --> Controller Class Initialized
INFO - 2018-06-11 22:46:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 22:46:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 22:46:45 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 22:46:45 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 22:46:45 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 22:46:45 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 22:46:45 --> File loaded: E:\www\yacopoo\application\views\executive.php
INFO - 2018-06-11 22:46:45 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 22:46:45 --> Final output sent to browser
DEBUG - 2018-06-11 22:46:45 --> Total execution time: 0.4344
INFO - 2018-06-11 22:46:47 --> Config Class Initialized
INFO - 2018-06-11 22:46:47 --> Hooks Class Initialized
DEBUG - 2018-06-11 22:46:47 --> UTF-8 Support Enabled
INFO - 2018-06-11 22:46:47 --> Utf8 Class Initialized
INFO - 2018-06-11 22:46:47 --> URI Class Initialized
INFO - 2018-06-11 22:46:47 --> Router Class Initialized
INFO - 2018-06-11 22:46:47 --> Output Class Initialized
INFO - 2018-06-11 22:46:47 --> Security Class Initialized
DEBUG - 2018-06-11 22:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 22:46:47 --> CSRF cookie sent
INFO - 2018-06-11 22:46:47 --> Input Class Initialized
INFO - 2018-06-11 22:46:47 --> Language Class Initialized
INFO - 2018-06-11 22:46:47 --> Loader Class Initialized
INFO - 2018-06-11 22:46:47 --> Helper loaded: url_helper
INFO - 2018-06-11 22:46:47 --> Helper loaded: form_helper
INFO - 2018-06-11 22:46:47 --> Helper loaded: language_helper
DEBUG - 2018-06-11 22:46:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 22:46:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 22:46:47 --> User Agent Class Initialized
INFO - 2018-06-11 22:46:47 --> Controller Class Initialized
INFO - 2018-06-11 22:46:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 22:46:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 22:46:47 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 22:46:47 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 22:46:47 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 22:46:47 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 22:46:47 --> File loaded: E:\www\yacopoo\application\views\professions.php
INFO - 2018-06-11 22:46:47 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 22:46:47 --> Final output sent to browser
DEBUG - 2018-06-11 22:46:47 --> Total execution time: 0.4867
INFO - 2018-06-11 22:46:49 --> Config Class Initialized
INFO - 2018-06-11 22:46:49 --> Hooks Class Initialized
DEBUG - 2018-06-11 22:46:49 --> UTF-8 Support Enabled
INFO - 2018-06-11 22:46:49 --> Utf8 Class Initialized
INFO - 2018-06-11 22:46:49 --> URI Class Initialized
INFO - 2018-06-11 22:46:49 --> Router Class Initialized
INFO - 2018-06-11 22:46:49 --> Output Class Initialized
INFO - 2018-06-11 22:46:49 --> Security Class Initialized
DEBUG - 2018-06-11 22:46:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 22:46:49 --> CSRF cookie sent
INFO - 2018-06-11 22:46:49 --> Input Class Initialized
INFO - 2018-06-11 22:46:49 --> Language Class Initialized
INFO - 2018-06-11 22:46:49 --> Loader Class Initialized
INFO - 2018-06-11 22:46:49 --> Helper loaded: url_helper
INFO - 2018-06-11 22:46:49 --> Helper loaded: form_helper
INFO - 2018-06-11 22:46:49 --> Helper loaded: language_helper
DEBUG - 2018-06-11 22:46:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 22:46:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 22:46:49 --> User Agent Class Initialized
INFO - 2018-06-11 22:46:49 --> Controller Class Initialized
INFO - 2018-06-11 22:46:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 22:46:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 22:46:49 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 22:46:49 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 22:46:49 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 22:46:49 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 22:46:49 --> File loaded: E:\www\yacopoo\application\views\finance.php
INFO - 2018-06-11 22:46:49 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 22:46:49 --> Final output sent to browser
DEBUG - 2018-06-11 22:46:49 --> Total execution time: 0.4275
INFO - 2018-06-11 22:46:51 --> Config Class Initialized
INFO - 2018-06-11 22:46:51 --> Hooks Class Initialized
DEBUG - 2018-06-11 22:46:51 --> UTF-8 Support Enabled
INFO - 2018-06-11 22:46:51 --> Utf8 Class Initialized
INFO - 2018-06-11 22:46:51 --> URI Class Initialized
INFO - 2018-06-11 22:46:51 --> Router Class Initialized
INFO - 2018-06-11 22:46:51 --> Output Class Initialized
INFO - 2018-06-11 22:46:51 --> Security Class Initialized
DEBUG - 2018-06-11 22:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 22:46:51 --> CSRF cookie sent
INFO - 2018-06-11 22:46:51 --> Input Class Initialized
INFO - 2018-06-11 22:46:51 --> Language Class Initialized
INFO - 2018-06-11 22:46:51 --> Loader Class Initialized
INFO - 2018-06-11 22:46:51 --> Helper loaded: url_helper
INFO - 2018-06-11 22:46:51 --> Helper loaded: form_helper
INFO - 2018-06-11 22:46:51 --> Helper loaded: language_helper
DEBUG - 2018-06-11 22:46:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 22:46:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 22:46:51 --> User Agent Class Initialized
INFO - 2018-06-11 22:46:51 --> Controller Class Initialized
INFO - 2018-06-11 22:46:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 22:46:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 22:46:51 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 22:46:51 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 22:46:51 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 22:46:51 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 22:46:51 --> File loaded: E:\www\yacopoo\application\views\professions.php
INFO - 2018-06-11 22:46:51 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 22:46:51 --> Final output sent to browser
DEBUG - 2018-06-11 22:46:51 --> Total execution time: 0.4973
INFO - 2018-06-11 22:46:52 --> Config Class Initialized
INFO - 2018-06-11 22:46:52 --> Hooks Class Initialized
DEBUG - 2018-06-11 22:46:52 --> UTF-8 Support Enabled
INFO - 2018-06-11 22:46:52 --> Utf8 Class Initialized
INFO - 2018-06-11 22:46:52 --> URI Class Initialized
INFO - 2018-06-11 22:46:52 --> Router Class Initialized
INFO - 2018-06-11 22:46:52 --> Output Class Initialized
INFO - 2018-06-11 22:46:52 --> Security Class Initialized
DEBUG - 2018-06-11 22:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 22:46:52 --> CSRF cookie sent
INFO - 2018-06-11 22:46:53 --> Input Class Initialized
INFO - 2018-06-11 22:46:53 --> Language Class Initialized
INFO - 2018-06-11 22:46:53 --> Loader Class Initialized
INFO - 2018-06-11 22:46:53 --> Helper loaded: url_helper
INFO - 2018-06-11 22:46:53 --> Helper loaded: form_helper
INFO - 2018-06-11 22:46:53 --> Helper loaded: language_helper
DEBUG - 2018-06-11 22:46:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 22:46:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 22:46:53 --> User Agent Class Initialized
INFO - 2018-06-11 22:46:53 --> Controller Class Initialized
INFO - 2018-06-11 22:46:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 22:46:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 22:46:53 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 22:46:53 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 22:46:53 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 22:46:53 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 22:46:53 --> File loaded: E:\www\yacopoo\application\views\consultant.php
INFO - 2018-06-11 22:46:53 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 22:46:53 --> Final output sent to browser
DEBUG - 2018-06-11 22:46:53 --> Total execution time: 0.4331
INFO - 2018-06-11 22:46:54 --> Config Class Initialized
INFO - 2018-06-11 22:46:54 --> Hooks Class Initialized
DEBUG - 2018-06-11 22:46:54 --> UTF-8 Support Enabled
INFO - 2018-06-11 22:46:54 --> Utf8 Class Initialized
INFO - 2018-06-11 22:46:54 --> URI Class Initialized
INFO - 2018-06-11 22:46:54 --> Router Class Initialized
INFO - 2018-06-11 22:46:54 --> Output Class Initialized
INFO - 2018-06-11 22:46:54 --> Security Class Initialized
DEBUG - 2018-06-11 22:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 22:46:54 --> CSRF cookie sent
INFO - 2018-06-11 22:46:54 --> Input Class Initialized
INFO - 2018-06-11 22:46:54 --> Language Class Initialized
INFO - 2018-06-11 22:46:54 --> Loader Class Initialized
INFO - 2018-06-11 22:46:54 --> Helper loaded: url_helper
INFO - 2018-06-11 22:46:54 --> Helper loaded: form_helper
INFO - 2018-06-11 22:46:54 --> Helper loaded: language_helper
DEBUG - 2018-06-11 22:46:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 22:46:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 22:46:55 --> User Agent Class Initialized
INFO - 2018-06-11 22:46:55 --> Controller Class Initialized
INFO - 2018-06-11 22:46:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 22:46:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 22:46:55 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 22:46:55 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 22:46:55 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 22:46:55 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 22:46:55 --> File loaded: E:\www\yacopoo\application\views\professions.php
INFO - 2018-06-11 22:46:55 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 22:46:55 --> Final output sent to browser
DEBUG - 2018-06-11 22:46:55 --> Total execution time: 0.4863
INFO - 2018-06-11 22:47:56 --> Config Class Initialized
INFO - 2018-06-11 22:47:56 --> Hooks Class Initialized
DEBUG - 2018-06-11 22:47:56 --> UTF-8 Support Enabled
INFO - 2018-06-11 22:47:56 --> Utf8 Class Initialized
INFO - 2018-06-11 22:47:56 --> URI Class Initialized
INFO - 2018-06-11 22:47:56 --> Router Class Initialized
INFO - 2018-06-11 22:47:56 --> Output Class Initialized
INFO - 2018-06-11 22:47:56 --> Security Class Initialized
DEBUG - 2018-06-11 22:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 22:47:56 --> CSRF cookie sent
INFO - 2018-06-11 22:47:56 --> Input Class Initialized
INFO - 2018-06-11 22:47:56 --> Language Class Initialized
INFO - 2018-06-11 22:47:56 --> Loader Class Initialized
INFO - 2018-06-11 22:47:56 --> Helper loaded: url_helper
INFO - 2018-06-11 22:47:56 --> Helper loaded: form_helper
INFO - 2018-06-11 22:47:56 --> Helper loaded: language_helper
DEBUG - 2018-06-11 22:47:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 22:47:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 22:47:57 --> User Agent Class Initialized
INFO - 2018-06-11 22:47:57 --> Controller Class Initialized
INFO - 2018-06-11 22:47:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 22:47:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 22:47:57 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 22:47:57 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 22:47:57 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 22:47:57 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 22:47:57 --> File loaded: E:\www\yacopoo\application\views\professions.php
INFO - 2018-06-11 22:47:57 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 22:47:57 --> Final output sent to browser
DEBUG - 2018-06-11 22:47:57 --> Total execution time: 0.4504
INFO - 2018-06-11 22:47:58 --> Config Class Initialized
INFO - 2018-06-11 22:47:58 --> Hooks Class Initialized
DEBUG - 2018-06-11 22:47:58 --> UTF-8 Support Enabled
INFO - 2018-06-11 22:47:58 --> Utf8 Class Initialized
INFO - 2018-06-11 22:47:58 --> URI Class Initialized
INFO - 2018-06-11 22:47:58 --> Router Class Initialized
INFO - 2018-06-11 22:47:59 --> Output Class Initialized
INFO - 2018-06-11 22:47:59 --> Security Class Initialized
DEBUG - 2018-06-11 22:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 22:47:59 --> CSRF cookie sent
INFO - 2018-06-11 22:47:59 --> Input Class Initialized
INFO - 2018-06-11 22:47:59 --> Language Class Initialized
INFO - 2018-06-11 22:47:59 --> Loader Class Initialized
INFO - 2018-06-11 22:47:59 --> Helper loaded: url_helper
INFO - 2018-06-11 22:47:59 --> Helper loaded: form_helper
INFO - 2018-06-11 22:47:59 --> Helper loaded: language_helper
DEBUG - 2018-06-11 22:47:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 22:47:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 22:47:59 --> User Agent Class Initialized
INFO - 2018-06-11 22:47:59 --> Controller Class Initialized
INFO - 2018-06-11 22:47:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 22:47:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 22:47:59 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 22:47:59 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 22:47:59 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 22:47:59 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 22:47:59 --> File loaded: E:\www\yacopoo\application\views\teacher.php
INFO - 2018-06-11 22:47:59 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 22:47:59 --> Final output sent to browser
DEBUG - 2018-06-11 22:47:59 --> Total execution time: 0.4342
INFO - 2018-06-11 22:48:03 --> Config Class Initialized
INFO - 2018-06-11 22:48:03 --> Hooks Class Initialized
DEBUG - 2018-06-11 22:48:03 --> UTF-8 Support Enabled
INFO - 2018-06-11 22:48:03 --> Utf8 Class Initialized
INFO - 2018-06-11 22:48:03 --> URI Class Initialized
INFO - 2018-06-11 22:48:04 --> Router Class Initialized
INFO - 2018-06-11 22:48:04 --> Output Class Initialized
INFO - 2018-06-11 22:48:04 --> Security Class Initialized
DEBUG - 2018-06-11 22:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 22:48:04 --> CSRF cookie sent
INFO - 2018-06-11 22:48:04 --> Input Class Initialized
INFO - 2018-06-11 22:48:04 --> Language Class Initialized
INFO - 2018-06-11 22:48:04 --> Loader Class Initialized
INFO - 2018-06-11 22:48:04 --> Helper loaded: url_helper
INFO - 2018-06-11 22:48:04 --> Helper loaded: form_helper
INFO - 2018-06-11 22:48:04 --> Helper loaded: language_helper
DEBUG - 2018-06-11 22:48:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 22:48:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 22:48:04 --> User Agent Class Initialized
INFO - 2018-06-11 22:48:04 --> Controller Class Initialized
INFO - 2018-06-11 22:48:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 22:48:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 22:48:04 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 22:48:04 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 22:48:04 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 22:48:04 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 22:48:04 --> File loaded: E:\www\yacopoo\application\views\professions.php
INFO - 2018-06-11 22:48:04 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 22:48:04 --> Final output sent to browser
DEBUG - 2018-06-11 22:48:04 --> Total execution time: 0.4540
INFO - 2018-06-11 23:58:50 --> Config Class Initialized
INFO - 2018-06-11 23:58:50 --> Hooks Class Initialized
DEBUG - 2018-06-11 23:58:50 --> UTF-8 Support Enabled
INFO - 2018-06-11 23:58:50 --> Utf8 Class Initialized
INFO - 2018-06-11 23:58:50 --> URI Class Initialized
DEBUG - 2018-06-11 23:58:50 --> No URI present. Default controller set.
INFO - 2018-06-11 23:58:50 --> Router Class Initialized
INFO - 2018-06-11 23:58:50 --> Output Class Initialized
INFO - 2018-06-11 23:58:50 --> Security Class Initialized
DEBUG - 2018-06-11 23:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 23:58:50 --> CSRF cookie sent
INFO - 2018-06-11 23:58:50 --> Input Class Initialized
INFO - 2018-06-11 23:58:50 --> Language Class Initialized
INFO - 2018-06-11 23:58:50 --> Loader Class Initialized
INFO - 2018-06-11 23:58:50 --> Helper loaded: url_helper
INFO - 2018-06-11 23:58:50 --> Helper loaded: form_helper
INFO - 2018-06-11 23:58:50 --> Helper loaded: language_helper
DEBUG - 2018-06-11 23:58:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 23:58:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 23:58:50 --> User Agent Class Initialized
INFO - 2018-06-11 23:58:50 --> Controller Class Initialized
INFO - 2018-06-11 23:58:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 23:58:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 23:58:50 --> Pixel_Model class loaded
INFO - 2018-06-11 23:58:50 --> Database Driver Class Initialized
INFO - 2018-06-11 23:58:50 --> Model "QuestionsModel" initialized
INFO - 2018-06-11 23:58:50 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 23:58:50 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 23:58:50 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-06-11 23:58:50 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 23:58:50 --> Final output sent to browser
DEBUG - 2018-06-11 23:58:50 --> Total execution time: 0.5464
INFO - 2018-06-11 23:59:17 --> Config Class Initialized
INFO - 2018-06-11 23:59:17 --> Hooks Class Initialized
DEBUG - 2018-06-11 23:59:17 --> UTF-8 Support Enabled
INFO - 2018-06-11 23:59:17 --> Utf8 Class Initialized
INFO - 2018-06-11 23:59:17 --> URI Class Initialized
INFO - 2018-06-11 23:59:17 --> Router Class Initialized
INFO - 2018-06-11 23:59:17 --> Output Class Initialized
INFO - 2018-06-11 23:59:17 --> Security Class Initialized
DEBUG - 2018-06-11 23:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 23:59:17 --> CSRF cookie sent
INFO - 2018-06-11 23:59:17 --> CSRF token verified
INFO - 2018-06-11 23:59:17 --> Input Class Initialized
INFO - 2018-06-11 23:59:17 --> Language Class Initialized
INFO - 2018-06-11 23:59:17 --> Loader Class Initialized
INFO - 2018-06-11 23:59:17 --> Helper loaded: url_helper
INFO - 2018-06-11 23:59:18 --> Helper loaded: form_helper
INFO - 2018-06-11 23:59:18 --> Helper loaded: language_helper
DEBUG - 2018-06-11 23:59:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 23:59:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 23:59:18 --> User Agent Class Initialized
INFO - 2018-06-11 23:59:18 --> Controller Class Initialized
INFO - 2018-06-11 23:59:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 23:59:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 23:59:18 --> Pixel_Model class loaded
INFO - 2018-06-11 23:59:18 --> Database Driver Class Initialized
INFO - 2018-06-11 23:59:18 --> Model "QuestionsModel" initialized
INFO - 2018-06-11 23:59:18 --> Config Class Initialized
INFO - 2018-06-11 23:59:18 --> Hooks Class Initialized
DEBUG - 2018-06-11 23:59:18 --> UTF-8 Support Enabled
INFO - 2018-06-11 23:59:18 --> Utf8 Class Initialized
INFO - 2018-06-11 23:59:18 --> URI Class Initialized
INFO - 2018-06-11 23:59:18 --> Router Class Initialized
INFO - 2018-06-11 23:59:18 --> Output Class Initialized
INFO - 2018-06-11 23:59:18 --> Security Class Initialized
DEBUG - 2018-06-11 23:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 23:59:18 --> CSRF cookie sent
INFO - 2018-06-11 23:59:18 --> Input Class Initialized
INFO - 2018-06-11 23:59:18 --> Language Class Initialized
INFO - 2018-06-11 23:59:18 --> Loader Class Initialized
INFO - 2018-06-11 23:59:18 --> Helper loaded: url_helper
INFO - 2018-06-11 23:59:18 --> Helper loaded: form_helper
INFO - 2018-06-11 23:59:18 --> Helper loaded: language_helper
DEBUG - 2018-06-11 23:59:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 23:59:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 23:59:18 --> User Agent Class Initialized
INFO - 2018-06-11 23:59:18 --> Controller Class Initialized
INFO - 2018-06-11 23:59:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 23:59:18 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-11 23:59:18 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-06-11 23:59:18 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 23:59:18 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 23:59:18 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 23:59:18 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-06-11 23:59:18 --> Could not find the language line "req_email"
INFO - 2018-06-11 23:59:18 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-06-11 23:59:18 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 23:59:18 --> Final output sent to browser
DEBUG - 2018-06-11 23:59:18 --> Total execution time: 0.4582
INFO - 2018-06-11 23:59:21 --> Config Class Initialized
INFO - 2018-06-11 23:59:21 --> Hooks Class Initialized
DEBUG - 2018-06-11 23:59:21 --> UTF-8 Support Enabled
INFO - 2018-06-11 23:59:21 --> Utf8 Class Initialized
INFO - 2018-06-11 23:59:21 --> URI Class Initialized
DEBUG - 2018-06-11 23:59:21 --> No URI present. Default controller set.
INFO - 2018-06-11 23:59:21 --> Router Class Initialized
INFO - 2018-06-11 23:59:21 --> Output Class Initialized
INFO - 2018-06-11 23:59:21 --> Security Class Initialized
DEBUG - 2018-06-11 23:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 23:59:21 --> CSRF cookie sent
INFO - 2018-06-11 23:59:21 --> Input Class Initialized
INFO - 2018-06-11 23:59:21 --> Language Class Initialized
INFO - 2018-06-11 23:59:21 --> Loader Class Initialized
INFO - 2018-06-11 23:59:21 --> Helper loaded: url_helper
INFO - 2018-06-11 23:59:21 --> Helper loaded: form_helper
INFO - 2018-06-11 23:59:21 --> Helper loaded: language_helper
DEBUG - 2018-06-11 23:59:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 23:59:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 23:59:21 --> User Agent Class Initialized
INFO - 2018-06-11 23:59:21 --> Controller Class Initialized
INFO - 2018-06-11 23:59:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 23:59:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 23:59:21 --> Pixel_Model class loaded
INFO - 2018-06-11 23:59:21 --> Database Driver Class Initialized
INFO - 2018-06-11 23:59:21 --> Model "QuestionsModel" initialized
INFO - 2018-06-11 23:59:21 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 23:59:21 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 23:59:21 --> File loaded: E:\www\yacopoo\application\views\home.php
INFO - 2018-06-11 23:59:21 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 23:59:21 --> Final output sent to browser
DEBUG - 2018-06-11 23:59:21 --> Total execution time: 0.4820
INFO - 2018-06-11 23:59:23 --> Config Class Initialized
INFO - 2018-06-11 23:59:23 --> Hooks Class Initialized
DEBUG - 2018-06-11 23:59:23 --> UTF-8 Support Enabled
INFO - 2018-06-11 23:59:23 --> Utf8 Class Initialized
INFO - 2018-06-11 23:59:23 --> URI Class Initialized
INFO - 2018-06-11 23:59:23 --> Router Class Initialized
INFO - 2018-06-11 23:59:23 --> Output Class Initialized
INFO - 2018-06-11 23:59:23 --> Security Class Initialized
DEBUG - 2018-06-11 23:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 23:59:23 --> CSRF cookie sent
INFO - 2018-06-11 23:59:23 --> Input Class Initialized
INFO - 2018-06-11 23:59:23 --> Language Class Initialized
INFO - 2018-06-11 23:59:23 --> Loader Class Initialized
INFO - 2018-06-11 23:59:23 --> Helper loaded: url_helper
INFO - 2018-06-11 23:59:23 --> Helper loaded: form_helper
INFO - 2018-06-11 23:59:23 --> Helper loaded: language_helper
DEBUG - 2018-06-11 23:59:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 23:59:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 23:59:23 --> User Agent Class Initialized
INFO - 2018-06-11 23:59:23 --> Controller Class Initialized
INFO - 2018-06-11 23:59:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 23:59:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 23:59:23 --> Pixel_Model class loaded
INFO - 2018-06-11 23:59:23 --> Database Driver Class Initialized
INFO - 2018-06-11 23:59:23 --> Model "QuestionsModel" initialized
INFO - 2018-06-11 23:59:23 --> Config Class Initialized
INFO - 2018-06-11 23:59:23 --> Hooks Class Initialized
DEBUG - 2018-06-11 23:59:23 --> UTF-8 Support Enabled
INFO - 2018-06-11 23:59:24 --> Utf8 Class Initialized
INFO - 2018-06-11 23:59:24 --> URI Class Initialized
INFO - 2018-06-11 23:59:24 --> Router Class Initialized
INFO - 2018-06-11 23:59:24 --> Output Class Initialized
INFO - 2018-06-11 23:59:24 --> Security Class Initialized
DEBUG - 2018-06-11 23:59:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 23:59:24 --> CSRF cookie sent
INFO - 2018-06-11 23:59:24 --> Input Class Initialized
INFO - 2018-06-11 23:59:24 --> Language Class Initialized
INFO - 2018-06-11 23:59:24 --> Loader Class Initialized
INFO - 2018-06-11 23:59:24 --> Helper loaded: url_helper
INFO - 2018-06-11 23:59:24 --> Helper loaded: form_helper
INFO - 2018-06-11 23:59:24 --> Helper loaded: language_helper
DEBUG - 2018-06-11 23:59:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 23:59:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 23:59:24 --> User Agent Class Initialized
INFO - 2018-06-11 23:59:24 --> Controller Class Initialized
INFO - 2018-06-11 23:59:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 23:59:24 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-11 23:59:24 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-06-11 23:59:24 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 23:59:24 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 23:59:24 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 23:59:24 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-06-11 23:59:24 --> Could not find the language line "req_email"
INFO - 2018-06-11 23:59:24 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-06-11 23:59:24 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 23:59:24 --> Final output sent to browser
DEBUG - 2018-06-11 23:59:24 --> Total execution time: 0.4989
INFO - 2018-06-11 23:59:26 --> Config Class Initialized
INFO - 2018-06-11 23:59:26 --> Hooks Class Initialized
DEBUG - 2018-06-11 23:59:26 --> UTF-8 Support Enabled
INFO - 2018-06-11 23:59:26 --> Utf8 Class Initialized
INFO - 2018-06-11 23:59:26 --> URI Class Initialized
INFO - 2018-06-11 23:59:26 --> Router Class Initialized
INFO - 2018-06-11 23:59:26 --> Output Class Initialized
INFO - 2018-06-11 23:59:26 --> Security Class Initialized
DEBUG - 2018-06-11 23:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 23:59:26 --> CSRF cookie sent
INFO - 2018-06-11 23:59:26 --> Input Class Initialized
INFO - 2018-06-11 23:59:26 --> Language Class Initialized
INFO - 2018-06-11 23:59:26 --> Loader Class Initialized
INFO - 2018-06-11 23:59:26 --> Helper loaded: url_helper
INFO - 2018-06-11 23:59:26 --> Helper loaded: form_helper
INFO - 2018-06-11 23:59:26 --> Helper loaded: language_helper
DEBUG - 2018-06-11 23:59:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 23:59:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 23:59:27 --> User Agent Class Initialized
INFO - 2018-06-11 23:59:27 --> Controller Class Initialized
INFO - 2018-06-11 23:59:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 23:59:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 23:59:27 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 23:59:27 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 23:59:27 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 23:59:27 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 23:59:27 --> File loaded: E:\www\yacopoo\application\views\advisors.php
INFO - 2018-06-11 23:59:27 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 23:59:27 --> Final output sent to browser
DEBUG - 2018-06-11 23:59:27 --> Total execution time: 0.4482
INFO - 2018-06-11 23:59:31 --> Config Class Initialized
INFO - 2018-06-11 23:59:31 --> Hooks Class Initialized
DEBUG - 2018-06-11 23:59:31 --> UTF-8 Support Enabled
INFO - 2018-06-11 23:59:31 --> Utf8 Class Initialized
INFO - 2018-06-11 23:59:31 --> URI Class Initialized
INFO - 2018-06-11 23:59:31 --> Router Class Initialized
INFO - 2018-06-11 23:59:31 --> Output Class Initialized
INFO - 2018-06-11 23:59:31 --> Security Class Initialized
DEBUG - 2018-06-11 23:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 23:59:31 --> CSRF cookie sent
INFO - 2018-06-11 23:59:31 --> Input Class Initialized
INFO - 2018-06-11 23:59:31 --> Language Class Initialized
INFO - 2018-06-11 23:59:31 --> Loader Class Initialized
INFO - 2018-06-11 23:59:31 --> Helper loaded: url_helper
INFO - 2018-06-11 23:59:31 --> Helper loaded: form_helper
INFO - 2018-06-11 23:59:32 --> Helper loaded: language_helper
DEBUG - 2018-06-11 23:59:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 23:59:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 23:59:32 --> User Agent Class Initialized
INFO - 2018-06-11 23:59:32 --> Controller Class Initialized
INFO - 2018-06-11 23:59:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 23:59:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 23:59:32 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 23:59:32 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 23:59:32 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 23:59:32 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 23:59:32 --> File loaded: E:\www\yacopoo\application\views\preview.php
INFO - 2018-06-11 23:59:32 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 23:59:32 --> Final output sent to browser
DEBUG - 2018-06-11 23:59:32 --> Total execution time: 0.4513
INFO - 2018-06-11 23:59:36 --> Config Class Initialized
INFO - 2018-06-11 23:59:36 --> Hooks Class Initialized
DEBUG - 2018-06-11 23:59:36 --> UTF-8 Support Enabled
INFO - 2018-06-11 23:59:36 --> Utf8 Class Initialized
INFO - 2018-06-11 23:59:36 --> URI Class Initialized
INFO - 2018-06-11 23:59:36 --> Router Class Initialized
INFO - 2018-06-11 23:59:36 --> Output Class Initialized
INFO - 2018-06-11 23:59:36 --> Security Class Initialized
DEBUG - 2018-06-11 23:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 23:59:36 --> CSRF cookie sent
INFO - 2018-06-11 23:59:36 --> Input Class Initialized
INFO - 2018-06-11 23:59:36 --> Language Class Initialized
INFO - 2018-06-11 23:59:36 --> Loader Class Initialized
INFO - 2018-06-11 23:59:36 --> Helper loaded: url_helper
INFO - 2018-06-11 23:59:36 --> Helper loaded: form_helper
INFO - 2018-06-11 23:59:36 --> Helper loaded: language_helper
DEBUG - 2018-06-11 23:59:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 23:59:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 23:59:36 --> User Agent Class Initialized
INFO - 2018-06-11 23:59:36 --> Controller Class Initialized
INFO - 2018-06-11 23:59:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 23:59:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 23:59:36 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 23:59:36 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 23:59:36 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 23:59:36 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 23:59:36 --> File loaded: E:\www\yacopoo\application\views\advisors.php
INFO - 2018-06-11 23:59:36 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 23:59:36 --> Final output sent to browser
DEBUG - 2018-06-11 23:59:36 --> Total execution time: 0.4466
INFO - 2018-06-11 23:59:40 --> Config Class Initialized
INFO - 2018-06-11 23:59:40 --> Hooks Class Initialized
DEBUG - 2018-06-11 23:59:40 --> UTF-8 Support Enabled
INFO - 2018-06-11 23:59:40 --> Utf8 Class Initialized
INFO - 2018-06-11 23:59:41 --> URI Class Initialized
INFO - 2018-06-11 23:59:41 --> Router Class Initialized
INFO - 2018-06-11 23:59:41 --> Output Class Initialized
INFO - 2018-06-11 23:59:41 --> Security Class Initialized
DEBUG - 2018-06-11 23:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 23:59:41 --> CSRF cookie sent
INFO - 2018-06-11 23:59:41 --> Input Class Initialized
INFO - 2018-06-11 23:59:41 --> Language Class Initialized
INFO - 2018-06-11 23:59:41 --> Loader Class Initialized
INFO - 2018-06-11 23:59:41 --> Helper loaded: url_helper
INFO - 2018-06-11 23:59:41 --> Helper loaded: form_helper
INFO - 2018-06-11 23:59:41 --> Helper loaded: language_helper
DEBUG - 2018-06-11 23:59:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 23:59:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 23:59:41 --> User Agent Class Initialized
INFO - 2018-06-11 23:59:41 --> Controller Class Initialized
INFO - 2018-06-11 23:59:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 23:59:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 23:59:41 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 23:59:41 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 23:59:41 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 23:59:41 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 23:59:41 --> File loaded: E:\www\yacopoo\application\views\advisors.php
INFO - 2018-06-11 23:59:41 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 23:59:41 --> Final output sent to browser
DEBUG - 2018-06-11 23:59:41 --> Total execution time: 0.4374
INFO - 2018-06-11 23:59:42 --> Config Class Initialized
INFO - 2018-06-11 23:59:42 --> Hooks Class Initialized
DEBUG - 2018-06-11 23:59:42 --> UTF-8 Support Enabled
INFO - 2018-06-11 23:59:42 --> Utf8 Class Initialized
INFO - 2018-06-11 23:59:42 --> URI Class Initialized
INFO - 2018-06-11 23:59:42 --> Router Class Initialized
INFO - 2018-06-11 23:59:42 --> Output Class Initialized
INFO - 2018-06-11 23:59:42 --> Security Class Initialized
DEBUG - 2018-06-11 23:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 23:59:42 --> CSRF cookie sent
INFO - 2018-06-11 23:59:43 --> Input Class Initialized
INFO - 2018-06-11 23:59:43 --> Language Class Initialized
INFO - 2018-06-11 23:59:43 --> Loader Class Initialized
INFO - 2018-06-11 23:59:43 --> Helper loaded: url_helper
INFO - 2018-06-11 23:59:43 --> Helper loaded: form_helper
INFO - 2018-06-11 23:59:43 --> Helper loaded: language_helper
DEBUG - 2018-06-11 23:59:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 23:59:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 23:59:43 --> User Agent Class Initialized
INFO - 2018-06-11 23:59:43 --> Controller Class Initialized
INFO - 2018-06-11 23:59:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 23:59:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 23:59:43 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 23:59:43 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 23:59:43 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 23:59:43 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 23:59:43 --> File loaded: E:\www\yacopoo\application\views\faqs.php
INFO - 2018-06-11 23:59:43 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 23:59:43 --> Final output sent to browser
DEBUG - 2018-06-11 23:59:43 --> Total execution time: 0.4821
INFO - 2018-06-11 23:59:45 --> Config Class Initialized
INFO - 2018-06-11 23:59:45 --> Hooks Class Initialized
DEBUG - 2018-06-11 23:59:45 --> UTF-8 Support Enabled
INFO - 2018-06-11 23:59:45 --> Utf8 Class Initialized
INFO - 2018-06-11 23:59:45 --> URI Class Initialized
INFO - 2018-06-11 23:59:45 --> Router Class Initialized
INFO - 2018-06-11 23:59:45 --> Output Class Initialized
INFO - 2018-06-11 23:59:45 --> Security Class Initialized
DEBUG - 2018-06-11 23:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 23:59:45 --> CSRF cookie sent
INFO - 2018-06-11 23:59:45 --> Input Class Initialized
INFO - 2018-06-11 23:59:45 --> Language Class Initialized
INFO - 2018-06-11 23:59:45 --> Loader Class Initialized
INFO - 2018-06-11 23:59:45 --> Helper loaded: url_helper
INFO - 2018-06-11 23:59:45 --> Helper loaded: form_helper
INFO - 2018-06-11 23:59:45 --> Helper loaded: language_helper
DEBUG - 2018-06-11 23:59:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 23:59:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 23:59:45 --> User Agent Class Initialized
INFO - 2018-06-11 23:59:45 --> Controller Class Initialized
INFO - 2018-06-11 23:59:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 23:59:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 23:59:45 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 23:59:45 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 23:59:45 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 23:59:45 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 23:59:45 --> File loaded: E:\www\yacopoo\application\views\advisors.php
INFO - 2018-06-11 23:59:45 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 23:59:45 --> Final output sent to browser
DEBUG - 2018-06-11 23:59:45 --> Total execution time: 0.4434
INFO - 2018-06-11 23:59:47 --> Config Class Initialized
INFO - 2018-06-11 23:59:47 --> Hooks Class Initialized
DEBUG - 2018-06-11 23:59:47 --> UTF-8 Support Enabled
INFO - 2018-06-11 23:59:47 --> Utf8 Class Initialized
INFO - 2018-06-11 23:59:47 --> URI Class Initialized
INFO - 2018-06-11 23:59:47 --> Router Class Initialized
INFO - 2018-06-11 23:59:47 --> Output Class Initialized
INFO - 2018-06-11 23:59:47 --> Security Class Initialized
DEBUG - 2018-06-11 23:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 23:59:47 --> CSRF cookie sent
INFO - 2018-06-11 23:59:47 --> Input Class Initialized
INFO - 2018-06-11 23:59:47 --> Language Class Initialized
INFO - 2018-06-11 23:59:47 --> Loader Class Initialized
INFO - 2018-06-11 23:59:47 --> Helper loaded: url_helper
INFO - 2018-06-11 23:59:47 --> Helper loaded: form_helper
INFO - 2018-06-11 23:59:47 --> Helper loaded: language_helper
DEBUG - 2018-06-11 23:59:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 23:59:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 23:59:47 --> User Agent Class Initialized
INFO - 2018-06-11 23:59:47 --> Controller Class Initialized
INFO - 2018-06-11 23:59:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 23:59:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 23:59:47 --> Config Class Initialized
INFO - 2018-06-11 23:59:47 --> Hooks Class Initialized
DEBUG - 2018-06-11 23:59:47 --> UTF-8 Support Enabled
INFO - 2018-06-11 23:59:47 --> Utf8 Class Initialized
INFO - 2018-06-11 23:59:47 --> URI Class Initialized
INFO - 2018-06-11 23:59:47 --> Router Class Initialized
INFO - 2018-06-11 23:59:47 --> Output Class Initialized
INFO - 2018-06-11 23:59:47 --> Security Class Initialized
DEBUG - 2018-06-11 23:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 23:59:48 --> CSRF cookie sent
INFO - 2018-06-11 23:59:48 --> Input Class Initialized
INFO - 2018-06-11 23:59:48 --> Language Class Initialized
INFO - 2018-06-11 23:59:48 --> Loader Class Initialized
INFO - 2018-06-11 23:59:48 --> Helper loaded: url_helper
INFO - 2018-06-11 23:59:48 --> Helper loaded: form_helper
INFO - 2018-06-11 23:59:48 --> Helper loaded: language_helper
DEBUG - 2018-06-11 23:59:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 23:59:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 23:59:48 --> User Agent Class Initialized
INFO - 2018-06-11 23:59:48 --> Controller Class Initialized
INFO - 2018-06-11 23:59:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 23:59:48 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-11 23:59:48 --> Config file loaded: E:\www\yacopoo\application\config/recaptcha.php
INFO - 2018-06-11 23:59:48 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 23:59:48 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 23:59:48 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 23:59:48 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
ERROR - 2018-06-11 23:59:48 --> Could not find the language line "req_email"
INFO - 2018-06-11 23:59:48 --> File loaded: E:\www\yacopoo\application\views\myaccount/signin.php
INFO - 2018-06-11 23:59:48 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 23:59:48 --> Final output sent to browser
DEBUG - 2018-06-11 23:59:48 --> Total execution time: 0.4666
INFO - 2018-06-11 23:59:54 --> Config Class Initialized
INFO - 2018-06-11 23:59:54 --> Hooks Class Initialized
DEBUG - 2018-06-11 23:59:54 --> UTF-8 Support Enabled
INFO - 2018-06-11 23:59:54 --> Utf8 Class Initialized
INFO - 2018-06-11 23:59:54 --> URI Class Initialized
INFO - 2018-06-11 23:59:54 --> Router Class Initialized
INFO - 2018-06-11 23:59:54 --> Output Class Initialized
INFO - 2018-06-11 23:59:54 --> Security Class Initialized
DEBUG - 2018-06-11 23:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 23:59:54 --> CSRF cookie sent
INFO - 2018-06-11 23:59:54 --> Input Class Initialized
INFO - 2018-06-11 23:59:54 --> Language Class Initialized
INFO - 2018-06-11 23:59:54 --> Loader Class Initialized
INFO - 2018-06-11 23:59:54 --> Helper loaded: url_helper
INFO - 2018-06-11 23:59:54 --> Helper loaded: form_helper
INFO - 2018-06-11 23:59:54 --> Helper loaded: language_helper
DEBUG - 2018-06-11 23:59:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 23:59:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 23:59:54 --> User Agent Class Initialized
INFO - 2018-06-11 23:59:54 --> Controller Class Initialized
INFO - 2018-06-11 23:59:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 23:59:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 23:59:54 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 23:59:54 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 23:59:54 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 23:59:54 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 23:59:54 --> File loaded: E:\www\yacopoo\application\views\advisors.php
INFO - 2018-06-11 23:59:54 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 23:59:54 --> Final output sent to browser
DEBUG - 2018-06-11 23:59:54 --> Total execution time: 0.4424
INFO - 2018-06-11 23:59:56 --> Config Class Initialized
INFO - 2018-06-11 23:59:56 --> Hooks Class Initialized
DEBUG - 2018-06-11 23:59:56 --> UTF-8 Support Enabled
INFO - 2018-06-11 23:59:56 --> Utf8 Class Initialized
INFO - 2018-06-11 23:59:56 --> URI Class Initialized
INFO - 2018-06-11 23:59:56 --> Router Class Initialized
INFO - 2018-06-11 23:59:56 --> Output Class Initialized
INFO - 2018-06-11 23:59:56 --> Security Class Initialized
DEBUG - 2018-06-11 23:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-11 23:59:56 --> CSRF cookie sent
INFO - 2018-06-11 23:59:56 --> Input Class Initialized
INFO - 2018-06-11 23:59:57 --> Language Class Initialized
INFO - 2018-06-11 23:59:57 --> Loader Class Initialized
INFO - 2018-06-11 23:59:57 --> Helper loaded: url_helper
INFO - 2018-06-11 23:59:57 --> Helper loaded: form_helper
INFO - 2018-06-11 23:59:57 --> Helper loaded: language_helper
DEBUG - 2018-06-11 23:59:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-11 23:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-11 23:59:57 --> User Agent Class Initialized
INFO - 2018-06-11 23:59:57 --> Controller Class Initialized
INFO - 2018-06-11 23:59:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-11 23:59:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-11 23:59:57 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-11 23:59:57 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-11 23:59:57 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-11 23:59:57 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-11 23:59:57 --> File loaded: E:\www\yacopoo\application\views\lawyers.php
INFO - 2018-06-11 23:59:57 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-11 23:59:57 --> Final output sent to browser
DEBUG - 2018-06-11 23:59:57 --> Total execution time: 0.4452

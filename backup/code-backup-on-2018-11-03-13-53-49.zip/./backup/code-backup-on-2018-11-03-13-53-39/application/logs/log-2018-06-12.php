<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-06-12 00:00:01 --> Config Class Initialized
INFO - 2018-06-12 00:00:01 --> Hooks Class Initialized
DEBUG - 2018-06-12 00:00:01 --> UTF-8 Support Enabled
INFO - 2018-06-12 00:00:01 --> Utf8 Class Initialized
INFO - 2018-06-12 00:00:01 --> URI Class Initialized
INFO - 2018-06-12 00:00:01 --> Router Class Initialized
INFO - 2018-06-12 00:00:01 --> Output Class Initialized
INFO - 2018-06-12 00:00:01 --> Security Class Initialized
DEBUG - 2018-06-12 00:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-12 00:00:01 --> CSRF cookie sent
INFO - 2018-06-12 00:00:01 --> Input Class Initialized
INFO - 2018-06-12 00:00:01 --> Language Class Initialized
INFO - 2018-06-12 00:00:01 --> Loader Class Initialized
INFO - 2018-06-12 00:00:01 --> Helper loaded: url_helper
INFO - 2018-06-12 00:00:01 --> Helper loaded: form_helper
INFO - 2018-06-12 00:00:01 --> Helper loaded: language_helper
DEBUG - 2018-06-12 00:00:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-12 00:00:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-12 00:00:01 --> User Agent Class Initialized
INFO - 2018-06-12 00:00:01 --> Controller Class Initialized
INFO - 2018-06-12 00:00:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-12 00:00:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-12 00:00:01 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-12 00:00:01 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-12 00:00:01 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-12 00:00:01 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-12 00:00:01 --> File loaded: E:\www\yacopoo\application\views\professions.php
INFO - 2018-06-12 00:00:01 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-12 00:00:01 --> Final output sent to browser
DEBUG - 2018-06-12 00:00:01 --> Total execution time: 0.2587
INFO - 2018-06-12 00:00:03 --> Config Class Initialized
INFO - 2018-06-12 00:00:03 --> Hooks Class Initialized
DEBUG - 2018-06-12 00:00:03 --> UTF-8 Support Enabled
INFO - 2018-06-12 00:00:03 --> Utf8 Class Initialized
INFO - 2018-06-12 00:00:03 --> URI Class Initialized
INFO - 2018-06-12 00:00:03 --> Router Class Initialized
INFO - 2018-06-12 00:00:03 --> Output Class Initialized
INFO - 2018-06-12 00:00:03 --> Security Class Initialized
DEBUG - 2018-06-12 00:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-12 00:00:03 --> CSRF cookie sent
INFO - 2018-06-12 00:00:03 --> Input Class Initialized
INFO - 2018-06-12 00:00:03 --> Language Class Initialized
INFO - 2018-06-12 00:00:03 --> Loader Class Initialized
INFO - 2018-06-12 00:00:03 --> Helper loaded: url_helper
INFO - 2018-06-12 00:00:03 --> Helper loaded: form_helper
INFO - 2018-06-12 00:00:03 --> Helper loaded: language_helper
DEBUG - 2018-06-12 00:00:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-12 00:00:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-12 00:00:03 --> User Agent Class Initialized
INFO - 2018-06-12 00:00:03 --> Controller Class Initialized
INFO - 2018-06-12 00:00:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-12 00:00:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-12 00:00:03 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-12 00:00:03 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-12 00:00:03 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-12 00:00:03 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-12 00:00:03 --> File loaded: E:\www\yacopoo\application\views\wedding_gifts.php
INFO - 2018-06-12 00:00:03 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-12 00:00:03 --> Final output sent to browser
DEBUG - 2018-06-12 00:00:04 --> Total execution time: 0.3114
INFO - 2018-06-12 00:00:11 --> Config Class Initialized
INFO - 2018-06-12 00:00:11 --> Hooks Class Initialized
DEBUG - 2018-06-12 00:00:11 --> UTF-8 Support Enabled
INFO - 2018-06-12 00:00:11 --> Utf8 Class Initialized
INFO - 2018-06-12 00:00:11 --> URI Class Initialized
INFO - 2018-06-12 00:00:11 --> Router Class Initialized
INFO - 2018-06-12 00:00:11 --> Output Class Initialized
INFO - 2018-06-12 00:00:11 --> Security Class Initialized
DEBUG - 2018-06-12 00:00:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-12 00:00:11 --> CSRF cookie sent
INFO - 2018-06-12 00:00:11 --> Input Class Initialized
INFO - 2018-06-12 00:00:11 --> Language Class Initialized
INFO - 2018-06-12 00:00:11 --> Loader Class Initialized
INFO - 2018-06-12 00:00:11 --> Helper loaded: url_helper
INFO - 2018-06-12 00:00:11 --> Helper loaded: form_helper
INFO - 2018-06-12 00:00:11 --> Helper loaded: language_helper
DEBUG - 2018-06-12 00:00:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-12 00:00:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-12 00:00:11 --> User Agent Class Initialized
INFO - 2018-06-12 00:00:11 --> Controller Class Initialized
INFO - 2018-06-12 00:00:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-12 00:00:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-12 00:00:11 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-12 00:00:11 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-12 00:00:11 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-12 00:00:11 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-12 00:00:11 --> File loaded: E:\www\yacopoo\application\views\professions.php
INFO - 2018-06-12 00:00:11 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-12 00:00:11 --> Final output sent to browser
DEBUG - 2018-06-12 00:00:11 --> Total execution time: 0.2510
INFO - 2018-06-12 00:00:15 --> Config Class Initialized
INFO - 2018-06-12 00:00:15 --> Hooks Class Initialized
DEBUG - 2018-06-12 00:00:15 --> UTF-8 Support Enabled
INFO - 2018-06-12 00:00:15 --> Utf8 Class Initialized
INFO - 2018-06-12 00:00:15 --> URI Class Initialized
INFO - 2018-06-12 00:00:15 --> Router Class Initialized
INFO - 2018-06-12 00:00:15 --> Output Class Initialized
INFO - 2018-06-12 00:00:15 --> Security Class Initialized
DEBUG - 2018-06-12 00:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-12 00:00:15 --> CSRF cookie sent
INFO - 2018-06-12 00:00:15 --> Input Class Initialized
INFO - 2018-06-12 00:00:15 --> Language Class Initialized
INFO - 2018-06-12 00:00:15 --> Loader Class Initialized
INFO - 2018-06-12 00:00:15 --> Helper loaded: url_helper
INFO - 2018-06-12 00:00:15 --> Helper loaded: form_helper
INFO - 2018-06-12 00:00:15 --> Helper loaded: language_helper
DEBUG - 2018-06-12 00:00:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-12 00:00:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-12 00:00:15 --> User Agent Class Initialized
INFO - 2018-06-12 00:00:15 --> Controller Class Initialized
INFO - 2018-06-12 00:00:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-12 00:00:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-12 00:00:15 --> File loaded: E:\www\yacopoo\application\views\shared/_basic_nav.php
INFO - 2018-06-12 00:00:15 --> File loaded: E:\www\yacopoo\application\views\shared/_header.php
INFO - 2018-06-12 00:00:15 --> File loaded: E:\www\yacopoo\application\views\shared/_page_banner_empty.php
INFO - 2018-06-12 00:00:15 --> File loaded: E:\www\yacopoo\application\views\shared/_page_header.php
INFO - 2018-06-12 00:00:15 --> File loaded: E:\www\yacopoo\application\views\911.php
INFO - 2018-06-12 00:00:15 --> File loaded: E:\www\yacopoo\application\views\shared/_footer.php
INFO - 2018-06-12 00:00:15 --> Final output sent to browser
DEBUG - 2018-06-12 00:00:15 --> Total execution time: 0.2325

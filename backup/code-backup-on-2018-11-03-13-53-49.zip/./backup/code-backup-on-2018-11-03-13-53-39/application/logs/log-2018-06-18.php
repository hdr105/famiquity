<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-06-18 18:25:47 --> Config Class Initialized
INFO - 2018-06-18 18:25:47 --> Hooks Class Initialized
DEBUG - 2018-06-18 18:25:47 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:25:47 --> Utf8 Class Initialized
INFO - 2018-06-18 18:25:47 --> URI Class Initialized
INFO - 2018-06-18 18:25:47 --> Router Class Initialized
INFO - 2018-06-18 18:25:47 --> Output Class Initialized
INFO - 2018-06-18 18:25:47 --> Security Class Initialized
DEBUG - 2018-06-18 18:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:25:47 --> CSRF cookie sent
INFO - 2018-06-18 18:25:47 --> Input Class Initialized
INFO - 2018-06-18 18:25:47 --> Language Class Initialized
ERROR - 2018-06-18 18:25:47 --> 404 Page Not Found: Faviconico/index
INFO - 2018-06-18 18:28:47 --> Config Class Initialized
INFO - 2018-06-18 18:28:47 --> Hooks Class Initialized
DEBUG - 2018-06-18 18:28:47 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:28:47 --> Utf8 Class Initialized
INFO - 2018-06-18 18:28:47 --> URI Class Initialized
DEBUG - 2018-06-18 18:28:47 --> No URI present. Default controller set.
INFO - 2018-06-18 18:28:47 --> Router Class Initialized
INFO - 2018-06-18 18:28:47 --> Output Class Initialized
INFO - 2018-06-18 18:28:47 --> Security Class Initialized
DEBUG - 2018-06-18 18:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:28:47 --> CSRF cookie sent
INFO - 2018-06-18 18:28:47 --> Input Class Initialized
INFO - 2018-06-18 18:28:47 --> Language Class Initialized
INFO - 2018-06-18 18:28:47 --> Loader Class Initialized
INFO - 2018-06-18 18:28:47 --> Helper loaded: url_helper
INFO - 2018-06-18 18:28:47 --> Helper loaded: form_helper
INFO - 2018-06-18 18:28:47 --> Helper loaded: language_helper
DEBUG - 2018-06-18 18:28:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 18:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 18:28:47 --> User Agent Class Initialized
INFO - 2018-06-18 18:28:47 --> Controller Class Initialized
INFO - 2018-06-18 18:28:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-18 18:28:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-18 18:28:47 --> Pixel_Model class loaded
INFO - 2018-06-18 18:28:47 --> Database Driver Class Initialized
INFO - 2018-06-18 18:28:47 --> Model "QuestionsModel" initialized
INFO - 2018-06-18 18:28:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-18 18:28:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-18 18:28:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-18 18:28:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-18 18:28:47 --> Final output sent to browser
DEBUG - 2018-06-18 18:28:47 --> Total execution time: 0.1622
INFO - 2018-06-18 18:28:47 --> Config Class Initialized
INFO - 2018-06-18 18:28:47 --> Hooks Class Initialized
DEBUG - 2018-06-18 18:28:47 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:28:47 --> Utf8 Class Initialized
INFO - 2018-06-18 18:28:47 --> URI Class Initialized
INFO - 2018-06-18 18:28:47 --> Router Class Initialized
INFO - 2018-06-18 18:28:47 --> Output Class Initialized
INFO - 2018-06-18 18:28:47 --> Security Class Initialized
DEBUG - 2018-06-18 18:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:28:47 --> CSRF cookie sent
INFO - 2018-06-18 18:28:47 --> Input Class Initialized
INFO - 2018-06-18 18:28:47 --> Language Class Initialized
ERROR - 2018-06-18 18:28:47 --> 404 Page Not Found: Assets/css
INFO - 2018-06-18 18:28:47 --> Config Class Initialized
INFO - 2018-06-18 18:28:47 --> Hooks Class Initialized
INFO - 2018-06-18 18:28:47 --> Config Class Initialized
INFO - 2018-06-18 18:28:47 --> Hooks Class Initialized
INFO - 2018-06-18 18:28:47 --> Config Class Initialized
INFO - 2018-06-18 18:28:47 --> Hooks Class Initialized
DEBUG - 2018-06-18 18:28:47 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:28:47 --> Utf8 Class Initialized
INFO - 2018-06-18 18:28:47 --> URI Class Initialized
DEBUG - 2018-06-18 18:28:47 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:28:47 --> Utf8 Class Initialized
INFO - 2018-06-18 18:28:47 --> URI Class Initialized
DEBUG - 2018-06-18 18:28:47 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:28:47 --> Utf8 Class Initialized
INFO - 2018-06-18 18:28:47 --> URI Class Initialized
INFO - 2018-06-18 18:28:47 --> Config Class Initialized
INFO - 2018-06-18 18:28:47 --> Hooks Class Initialized
INFO - 2018-06-18 18:28:47 --> Router Class Initialized
DEBUG - 2018-06-18 18:28:47 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:28:47 --> Utf8 Class Initialized
INFO - 2018-06-18 18:28:47 --> URI Class Initialized
INFO - 2018-06-18 18:28:47 --> Router Class Initialized
INFO - 2018-06-18 18:28:47 --> Router Class Initialized
INFO - 2018-06-18 18:28:47 --> Router Class Initialized
INFO - 2018-06-18 18:28:47 --> Output Class Initialized
INFO - 2018-06-18 18:28:47 --> Output Class Initialized
INFO - 2018-06-18 18:28:47 --> Config Class Initialized
INFO - 2018-06-18 18:28:47 --> Hooks Class Initialized
INFO - 2018-06-18 18:28:47 --> Output Class Initialized
INFO - 2018-06-18 18:28:47 --> Security Class Initialized
INFO - 2018-06-18 18:28:47 --> Output Class Initialized
DEBUG - 2018-06-18 18:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:28:47 --> CSRF cookie sent
INFO - 2018-06-18 18:28:47 --> Input Class Initialized
INFO - 2018-06-18 18:28:47 --> Config Class Initialized
INFO - 2018-06-18 18:28:47 --> Hooks Class Initialized
INFO - 2018-06-18 18:28:47 --> Security Class Initialized
DEBUG - 2018-06-18 18:28:47 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:28:47 --> Utf8 Class Initialized
INFO - 2018-06-18 18:28:47 --> Language Class Initialized
ERROR - 2018-06-18 18:28:47 --> 404 Page Not Found: Assets/css
DEBUG - 2018-06-18 18:28:47 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:28:47 --> Utf8 Class Initialized
INFO - 2018-06-18 18:28:47 --> Security Class Initialized
INFO - 2018-06-18 18:28:47 --> Security Class Initialized
INFO - 2018-06-18 18:28:47 --> URI Class Initialized
DEBUG - 2018-06-18 18:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:28:47 --> URI Class Initialized
INFO - 2018-06-18 18:28:47 --> CSRF cookie sent
INFO - 2018-06-18 18:28:47 --> Input Class Initialized
INFO - 2018-06-18 18:28:47 --> Language Class Initialized
DEBUG - 2018-06-18 18:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:28:47 --> CSRF cookie sent
INFO - 2018-06-18 18:28:47 --> Input Class Initialized
INFO - 2018-06-18 18:28:47 --> Language Class Initialized
INFO - 2018-06-18 18:28:47 --> Router Class Initialized
INFO - 2018-06-18 18:28:47 --> Router Class Initialized
DEBUG - 2018-06-18 18:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:28:47 --> CSRF cookie sent
INFO - 2018-06-18 18:28:47 --> Input Class Initialized
INFO - 2018-06-18 18:28:47 --> Language Class Initialized
INFO - 2018-06-18 18:28:47 --> Output Class Initialized
INFO - 2018-06-18 18:28:47 --> Output Class Initialized
ERROR - 2018-06-18 18:28:47 --> 404 Page Not Found: Assets/css
ERROR - 2018-06-18 18:28:47 --> 404 Page Not Found: Assets/css
ERROR - 2018-06-18 18:28:47 --> 404 Page Not Found: Assets/revolution
INFO - 2018-06-18 18:28:47 --> Security Class Initialized
INFO - 2018-06-18 18:28:47 --> Security Class Initialized
DEBUG - 2018-06-18 18:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:28:47 --> CSRF cookie sent
INFO - 2018-06-18 18:28:47 --> Input Class Initialized
INFO - 2018-06-18 18:28:47 --> Language Class Initialized
DEBUG - 2018-06-18 18:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:28:47 --> CSRF cookie sent
INFO - 2018-06-18 18:28:47 --> Input Class Initialized
INFO - 2018-06-18 18:28:47 --> Language Class Initialized
ERROR - 2018-06-18 18:28:47 --> 404 Page Not Found: Assets/css
ERROR - 2018-06-18 18:28:47 --> 404 Page Not Found: Assets/css
INFO - 2018-06-18 18:28:47 --> Config Class Initialized
INFO - 2018-06-18 18:28:47 --> Hooks Class Initialized
DEBUG - 2018-06-18 18:28:47 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:28:47 --> Utf8 Class Initialized
INFO - 2018-06-18 18:28:47 --> Config Class Initialized
INFO - 2018-06-18 18:28:47 --> Hooks Class Initialized
DEBUG - 2018-06-18 18:28:47 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:28:47 --> Utf8 Class Initialized
INFO - 2018-06-18 18:28:47 --> URI Class Initialized
INFO - 2018-06-18 18:28:47 --> Config Class Initialized
INFO - 2018-06-18 18:28:47 --> Hooks Class Initialized
INFO - 2018-06-18 18:28:47 --> Config Class Initialized
INFO - 2018-06-18 18:28:47 --> Hooks Class Initialized
DEBUG - 2018-06-18 18:28:47 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:28:47 --> Utf8 Class Initialized
INFO - 2018-06-18 18:28:47 --> URI Class Initialized
DEBUG - 2018-06-18 18:28:47 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:28:47 --> Utf8 Class Initialized
INFO - 2018-06-18 18:28:47 --> URI Class Initialized
INFO - 2018-06-18 18:28:47 --> Router Class Initialized
INFO - 2018-06-18 18:28:47 --> URI Class Initialized
INFO - 2018-06-18 18:28:47 --> Router Class Initialized
INFO - 2018-06-18 18:28:47 --> Router Class Initialized
INFO - 2018-06-18 18:28:47 --> Output Class Initialized
INFO - 2018-06-18 18:28:47 --> Config Class Initialized
INFO - 2018-06-18 18:28:47 --> Hooks Class Initialized
INFO - 2018-06-18 18:28:47 --> Security Class Initialized
INFO - 2018-06-18 18:28:47 --> Output Class Initialized
DEBUG - 2018-06-18 18:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:28:47 --> CSRF cookie sent
INFO - 2018-06-18 18:28:47 --> Input Class Initialized
INFO - 2018-06-18 18:28:47 --> Language Class Initialized
ERROR - 2018-06-18 18:28:47 --> 404 Page Not Found: Assets/js
INFO - 2018-06-18 18:28:47 --> Output Class Initialized
INFO - 2018-06-18 18:28:47 --> Security Class Initialized
INFO - 2018-06-18 18:28:47 --> Router Class Initialized
INFO - 2018-06-18 18:28:47 --> Config Class Initialized
INFO - 2018-06-18 18:28:47 --> Security Class Initialized
INFO - 2018-06-18 18:28:47 --> Hooks Class Initialized
DEBUG - 2018-06-18 18:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:28:47 --> CSRF cookie sent
INFO - 2018-06-18 18:28:47 --> Input Class Initialized
INFO - 2018-06-18 18:28:47 --> Language Class Initialized
DEBUG - 2018-06-18 18:28:47 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:28:47 --> Utf8 Class Initialized
DEBUG - 2018-06-18 18:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:28:47 --> CSRF cookie sent
INFO - 2018-06-18 18:28:47 --> Input Class Initialized
INFO - 2018-06-18 18:28:47 --> Language Class Initialized
ERROR - 2018-06-18 18:28:47 --> 404 Page Not Found: Assets/js
ERROR - 2018-06-18 18:28:47 --> 404 Page Not Found: Assets/revolution
INFO - 2018-06-18 18:28:47 --> URI Class Initialized
INFO - 2018-06-18 18:28:47 --> Output Class Initialized
DEBUG - 2018-06-18 18:28:47 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:28:47 --> Utf8 Class Initialized
INFO - 2018-06-18 18:28:47 --> URI Class Initialized
INFO - 2018-06-18 18:28:47 --> Security Class Initialized
INFO - 2018-06-18 18:28:47 --> Router Class Initialized
INFO - 2018-06-18 18:28:47 --> Output Class Initialized
INFO - 2018-06-18 18:28:47 --> Security Class Initialized
INFO - 2018-06-18 18:28:47 --> Router Class Initialized
INFO - 2018-06-18 18:28:47 --> Output Class Initialized
INFO - 2018-06-18 18:28:47 --> Security Class Initialized
DEBUG - 2018-06-18 18:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:28:47 --> CSRF cookie sent
INFO - 2018-06-18 18:28:47 --> Input Class Initialized
DEBUG - 2018-06-18 18:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:28:47 --> CSRF cookie sent
INFO - 2018-06-18 18:28:47 --> Input Class Initialized
INFO - 2018-06-18 18:28:47 --> Language Class Initialized
DEBUG - 2018-06-18 18:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:28:47 --> CSRF cookie sent
INFO - 2018-06-18 18:28:47 --> Input Class Initialized
INFO - 2018-06-18 18:28:47 --> Language Class Initialized
INFO - 2018-06-18 18:28:47 --> Language Class Initialized
INFO - 2018-06-18 18:28:47 --> Config Class Initialized
INFO - 2018-06-18 18:28:47 --> Hooks Class Initialized
ERROR - 2018-06-18 18:28:47 --> 404 Page Not Found: Assets/revolution
ERROR - 2018-06-18 18:28:47 --> 404 Page Not Found: Assets/revolution
INFO - 2018-06-18 18:28:47 --> Config Class Initialized
INFO - 2018-06-18 18:28:47 --> Hooks Class Initialized
ERROR - 2018-06-18 18:28:47 --> 404 Page Not Found: Assets/revolution
INFO - 2018-06-18 18:28:47 --> Config Class Initialized
INFO - 2018-06-18 18:28:47 --> Hooks Class Initialized
DEBUG - 2018-06-18 18:28:47 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:28:47 --> Utf8 Class Initialized
DEBUG - 2018-06-18 18:28:47 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:28:47 --> Utf8 Class Initialized
INFO - 2018-06-18 18:28:47 --> URI Class Initialized
INFO - 2018-06-18 18:28:47 --> Router Class Initialized
INFO - 2018-06-18 18:28:47 --> Output Class Initialized
DEBUG - 2018-06-18 18:28:47 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:28:47 --> Utf8 Class Initialized
INFO - 2018-06-18 18:28:47 --> Security Class Initialized
DEBUG - 2018-06-18 18:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:28:47 --> CSRF cookie sent
INFO - 2018-06-18 18:28:47 --> Input Class Initialized
INFO - 2018-06-18 18:28:47 --> URI Class Initialized
INFO - 2018-06-18 18:28:47 --> Language Class Initialized
ERROR - 2018-06-18 18:28:47 --> 404 Page Not Found: Assets/images
INFO - 2018-06-18 18:28:47 --> URI Class Initialized
INFO - 2018-06-18 18:28:47 --> Router Class Initialized
INFO - 2018-06-18 18:28:47 --> Router Class Initialized
INFO - 2018-06-18 18:28:47 --> Output Class Initialized
INFO - 2018-06-18 18:28:47 --> Output Class Initialized
INFO - 2018-06-18 18:28:47 --> Security Class Initialized
INFO - 2018-06-18 18:28:47 --> Security Class Initialized
DEBUG - 2018-06-18 18:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:28:47 --> CSRF cookie sent
INFO - 2018-06-18 18:28:47 --> Input Class Initialized
DEBUG - 2018-06-18 18:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:28:47 --> CSRF cookie sent
INFO - 2018-06-18 18:28:47 --> Input Class Initialized
INFO - 2018-06-18 18:28:47 --> Language Class Initialized
INFO - 2018-06-18 18:28:47 --> Language Class Initialized
ERROR - 2018-06-18 18:28:47 --> 404 Page Not Found: Assets/images
ERROR - 2018-06-18 18:28:47 --> 404 Page Not Found: Assets/revolution
INFO - 2018-06-18 18:28:47 --> Config Class Initialized
INFO - 2018-06-18 18:28:47 --> Hooks Class Initialized
DEBUG - 2018-06-18 18:28:47 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:28:47 --> Utf8 Class Initialized
INFO - 2018-06-18 18:28:47 --> URI Class Initialized
INFO - 2018-06-18 18:28:47 --> Config Class Initialized
INFO - 2018-06-18 18:28:47 --> Hooks Class Initialized
INFO - 2018-06-18 18:28:47 --> Router Class Initialized
INFO - 2018-06-18 18:28:47 --> Output Class Initialized
DEBUG - 2018-06-18 18:28:47 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:28:47 --> Utf8 Class Initialized
INFO - 2018-06-18 18:28:47 --> URI Class Initialized
INFO - 2018-06-18 18:28:47 --> Config Class Initialized
INFO - 2018-06-18 18:28:47 --> Hooks Class Initialized
INFO - 2018-06-18 18:28:47 --> Security Class Initialized
DEBUG - 2018-06-18 18:28:47 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:28:47 --> Utf8 Class Initialized
INFO - 2018-06-18 18:28:47 --> URI Class Initialized
INFO - 2018-06-18 18:28:47 --> Config Class Initialized
INFO - 2018-06-18 18:28:47 --> Hooks Class Initialized
INFO - 2018-06-18 18:28:47 --> Config Class Initialized
INFO - 2018-06-18 18:28:47 --> Hooks Class Initialized
DEBUG - 2018-06-18 18:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:28:47 --> CSRF cookie sent
INFO - 2018-06-18 18:28:47 --> Input Class Initialized
INFO - 2018-06-18 18:28:47 --> Language Class Initialized
ERROR - 2018-06-18 18:28:47 --> 404 Page Not Found: Assets/js
INFO - 2018-06-18 18:28:47 --> Router Class Initialized
INFO - 2018-06-18 18:28:47 --> Output Class Initialized
INFO - 2018-06-18 18:28:47 --> Security Class Initialized
INFO - 2018-06-18 18:28:47 --> Config Class Initialized
INFO - 2018-06-18 18:28:47 --> Hooks Class Initialized
DEBUG - 2018-06-18 18:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:28:47 --> CSRF cookie sent
INFO - 2018-06-18 18:28:47 --> Input Class Initialized
INFO - 2018-06-18 18:28:47 --> Language Class Initialized
DEBUG - 2018-06-18 18:28:47 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:28:47 --> Utf8 Class Initialized
INFO - 2018-06-18 18:28:47 --> URI Class Initialized
INFO - 2018-06-18 18:28:47 --> Router Class Initialized
INFO - 2018-06-18 18:28:47 --> Output Class Initialized
INFO - 2018-06-18 18:28:47 --> Security Class Initialized
ERROR - 2018-06-18 18:28:47 --> 404 Page Not Found: Assets/revolution
DEBUG - 2018-06-18 18:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:28:47 --> CSRF cookie sent
INFO - 2018-06-18 18:28:47 --> Input Class Initialized
INFO - 2018-06-18 18:28:47 --> Language Class Initialized
INFO - 2018-06-18 18:28:47 --> Router Class Initialized
INFO - 2018-06-18 18:28:47 --> Output Class Initialized
INFO - 2018-06-18 18:28:47 --> Security Class Initialized
ERROR - 2018-06-18 18:28:47 --> 404 Page Not Found: Assets/revolution
DEBUG - 2018-06-18 18:28:47 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:28:47 --> Utf8 Class Initialized
INFO - 2018-06-18 18:28:47 --> URI Class Initialized
INFO - 2018-06-18 18:28:47 --> Router Class Initialized
INFO - 2018-06-18 18:28:47 --> Output Class Initialized
INFO - 2018-06-18 18:28:47 --> Security Class Initialized
DEBUG - 2018-06-18 18:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:28:47 --> CSRF cookie sent
INFO - 2018-06-18 18:28:47 --> Input Class Initialized
INFO - 2018-06-18 18:28:47 --> Language Class Initialized
DEBUG - 2018-06-18 18:28:47 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:28:47 --> Utf8 Class Initialized
DEBUG - 2018-06-18 18:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:28:47 --> CSRF cookie sent
INFO - 2018-06-18 18:28:47 --> Input Class Initialized
INFO - 2018-06-18 18:28:47 --> Language Class Initialized
ERROR - 2018-06-18 18:28:47 --> 404 Page Not Found: Assets/revolution
ERROR - 2018-06-18 18:28:47 --> 404 Page Not Found: Assets/revolution
INFO - 2018-06-18 18:28:47 --> URI Class Initialized
INFO - 2018-06-18 18:28:47 --> Router Class Initialized
INFO - 2018-06-18 18:28:47 --> Output Class Initialized
INFO - 2018-06-18 18:28:47 --> Security Class Initialized
INFO - 2018-06-18 18:28:47 --> Config Class Initialized
INFO - 2018-06-18 18:28:47 --> Hooks Class Initialized
DEBUG - 2018-06-18 18:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:28:47 --> CSRF cookie sent
INFO - 2018-06-18 18:28:47 --> Input Class Initialized
INFO - 2018-06-18 18:28:47 --> Language Class Initialized
ERROR - 2018-06-18 18:28:47 --> 404 Page Not Found: Assets/revolution
DEBUG - 2018-06-18 18:28:47 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:28:47 --> Utf8 Class Initialized
INFO - 2018-06-18 18:28:47 --> Config Class Initialized
INFO - 2018-06-18 18:28:47 --> Hooks Class Initialized
INFO - 2018-06-18 18:28:47 --> URI Class Initialized
DEBUG - 2018-06-18 18:28:47 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:28:47 --> Utf8 Class Initialized
INFO - 2018-06-18 18:28:47 --> URI Class Initialized
INFO - 2018-06-18 18:28:47 --> Router Class Initialized
INFO - 2018-06-18 18:28:47 --> Output Class Initialized
INFO - 2018-06-18 18:28:47 --> Security Class Initialized
INFO - 2018-06-18 18:28:47 --> Config Class Initialized
INFO - 2018-06-18 18:28:47 --> Hooks Class Initialized
DEBUG - 2018-06-18 18:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:28:47 --> CSRF cookie sent
INFO - 2018-06-18 18:28:47 --> Input Class Initialized
INFO - 2018-06-18 18:28:47 --> Language Class Initialized
INFO - 2018-06-18 18:28:47 --> Router Class Initialized
ERROR - 2018-06-18 18:28:47 --> 404 Page Not Found: Assets/revolution
DEBUG - 2018-06-18 18:28:47 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:28:47 --> Utf8 Class Initialized
INFO - 2018-06-18 18:28:47 --> URI Class Initialized
INFO - 2018-06-18 18:28:47 --> Output Class Initialized
INFO - 2018-06-18 18:28:47 --> Security Class Initialized
DEBUG - 2018-06-18 18:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:28:47 --> CSRF cookie sent
INFO - 2018-06-18 18:28:47 --> Input Class Initialized
INFO - 2018-06-18 18:28:47 --> Language Class Initialized
ERROR - 2018-06-18 18:28:47 --> 404 Page Not Found: Assets/revolution
INFO - 2018-06-18 18:28:47 --> Router Class Initialized
INFO - 2018-06-18 18:28:47 --> Config Class Initialized
INFO - 2018-06-18 18:28:47 --> Hooks Class Initialized
INFO - 2018-06-18 18:28:47 --> Config Class Initialized
INFO - 2018-06-18 18:28:47 --> Hooks Class Initialized
DEBUG - 2018-06-18 18:28:47 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:28:47 --> Utf8 Class Initialized
DEBUG - 2018-06-18 18:28:47 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:28:47 --> URI Class Initialized
INFO - 2018-06-18 18:28:47 --> Output Class Initialized
INFO - 2018-06-18 18:28:47 --> Utf8 Class Initialized
INFO - 2018-06-18 18:28:47 --> Router Class Initialized
INFO - 2018-06-18 18:28:47 --> URI Class Initialized
INFO - 2018-06-18 18:28:47 --> Security Class Initialized
INFO - 2018-06-18 18:28:47 --> Output Class Initialized
DEBUG - 2018-06-18 18:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:28:47 --> Security Class Initialized
INFO - 2018-06-18 18:28:47 --> Router Class Initialized
INFO - 2018-06-18 18:28:47 --> CSRF cookie sent
INFO - 2018-06-18 18:28:47 --> Input Class Initialized
INFO - 2018-06-18 18:28:47 --> Language Class Initialized
INFO - 2018-06-18 18:28:47 --> Output Class Initialized
ERROR - 2018-06-18 18:28:47 --> 404 Page Not Found: Assets/revolution
INFO - 2018-06-18 18:28:47 --> Config Class Initialized
INFO - 2018-06-18 18:28:47 --> Hooks Class Initialized
INFO - 2018-06-18 18:28:47 --> Security Class Initialized
DEBUG - 2018-06-18 18:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:28:47 --> CSRF cookie sent
DEBUG - 2018-06-18 18:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:28:47 --> CSRF cookie sent
INFO - 2018-06-18 18:28:47 --> Input Class Initialized
INFO - 2018-06-18 18:28:47 --> Input Class Initialized
INFO - 2018-06-18 18:28:47 --> Language Class Initialized
INFO - 2018-06-18 18:28:47 --> Language Class Initialized
DEBUG - 2018-06-18 18:28:47 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:28:47 --> Utf8 Class Initialized
ERROR - 2018-06-18 18:28:47 --> 404 Page Not Found: Assets/js
INFO - 2018-06-18 18:28:47 --> URI Class Initialized
ERROR - 2018-06-18 18:28:47 --> 404 Page Not Found: Assets/js
INFO - 2018-06-18 18:28:47 --> Router Class Initialized
INFO - 2018-06-18 18:28:47 --> Output Class Initialized
INFO - 2018-06-18 18:28:47 --> Security Class Initialized
DEBUG - 2018-06-18 18:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:28:47 --> CSRF cookie sent
INFO - 2018-06-18 18:28:47 --> Input Class Initialized
INFO - 2018-06-18 18:28:47 --> Language Class Initialized
ERROR - 2018-06-18 18:28:47 --> 404 Page Not Found: Assets/images
INFO - 2018-06-18 18:28:48 --> Config Class Initialized
INFO - 2018-06-18 18:28:48 --> Hooks Class Initialized
DEBUG - 2018-06-18 18:28:48 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:28:48 --> Utf8 Class Initialized
INFO - 2018-06-18 18:28:48 --> URI Class Initialized
INFO - 2018-06-18 18:28:48 --> Router Class Initialized
INFO - 2018-06-18 18:28:48 --> Output Class Initialized
INFO - 2018-06-18 18:28:48 --> Security Class Initialized
DEBUG - 2018-06-18 18:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:28:48 --> CSRF cookie sent
INFO - 2018-06-18 18:28:48 --> Input Class Initialized
INFO - 2018-06-18 18:28:48 --> Language Class Initialized
ERROR - 2018-06-18 18:28:48 --> 404 Page Not Found: Assets/revolution
INFO - 2018-06-18 18:28:48 --> Config Class Initialized
INFO - 2018-06-18 18:28:48 --> Hooks Class Initialized
DEBUG - 2018-06-18 18:28:48 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:28:48 --> Utf8 Class Initialized
INFO - 2018-06-18 18:28:48 --> URI Class Initialized
INFO - 2018-06-18 18:28:48 --> Router Class Initialized
INFO - 2018-06-18 18:28:48 --> Output Class Initialized
INFO - 2018-06-18 18:28:48 --> Security Class Initialized
DEBUG - 2018-06-18 18:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:28:48 --> CSRF cookie sent
INFO - 2018-06-18 18:28:48 --> Input Class Initialized
INFO - 2018-06-18 18:28:48 --> Language Class Initialized
ERROR - 2018-06-18 18:28:48 --> 404 Page Not Found: Assets/revolution
INFO - 2018-06-18 18:28:48 --> Config Class Initialized
INFO - 2018-06-18 18:28:48 --> Hooks Class Initialized
DEBUG - 2018-06-18 18:28:48 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:28:48 --> Utf8 Class Initialized
INFO - 2018-06-18 18:28:48 --> URI Class Initialized
INFO - 2018-06-18 18:28:48 --> Router Class Initialized
INFO - 2018-06-18 18:28:48 --> Output Class Initialized
INFO - 2018-06-18 18:28:48 --> Security Class Initialized
DEBUG - 2018-06-18 18:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:28:48 --> CSRF cookie sent
INFO - 2018-06-18 18:28:48 --> Input Class Initialized
INFO - 2018-06-18 18:28:48 --> Language Class Initialized
ERROR - 2018-06-18 18:28:48 --> 404 Page Not Found: Assets/revolution
INFO - 2018-06-18 18:28:48 --> Config Class Initialized
INFO - 2018-06-18 18:28:48 --> Hooks Class Initialized
DEBUG - 2018-06-18 18:28:48 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:28:48 --> Utf8 Class Initialized
INFO - 2018-06-18 18:28:48 --> URI Class Initialized
INFO - 2018-06-18 18:28:48 --> Router Class Initialized
INFO - 2018-06-18 18:28:48 --> Output Class Initialized
INFO - 2018-06-18 18:28:48 --> Security Class Initialized
DEBUG - 2018-06-18 18:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:28:48 --> CSRF cookie sent
INFO - 2018-06-18 18:28:48 --> Input Class Initialized
INFO - 2018-06-18 18:28:48 --> Language Class Initialized
ERROR - 2018-06-18 18:28:48 --> 404 Page Not Found: Assets/revolution
INFO - 2018-06-18 18:28:48 --> Config Class Initialized
INFO - 2018-06-18 18:28:48 --> Hooks Class Initialized
DEBUG - 2018-06-18 18:28:48 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:28:48 --> Utf8 Class Initialized
INFO - 2018-06-18 18:28:48 --> URI Class Initialized
INFO - 2018-06-18 18:28:48 --> Router Class Initialized
INFO - 2018-06-18 18:28:48 --> Output Class Initialized
INFO - 2018-06-18 18:28:48 --> Security Class Initialized
DEBUG - 2018-06-18 18:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:28:48 --> CSRF cookie sent
INFO - 2018-06-18 18:28:48 --> Input Class Initialized
INFO - 2018-06-18 18:28:48 --> Language Class Initialized
ERROR - 2018-06-18 18:28:48 --> 404 Page Not Found: Assets/revolution
INFO - 2018-06-18 18:28:48 --> Config Class Initialized
INFO - 2018-06-18 18:28:48 --> Hooks Class Initialized
DEBUG - 2018-06-18 18:28:48 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:28:48 --> Utf8 Class Initialized
INFO - 2018-06-18 18:28:48 --> URI Class Initialized
INFO - 2018-06-18 18:28:48 --> Router Class Initialized
INFO - 2018-06-18 18:28:48 --> Output Class Initialized
INFO - 2018-06-18 18:28:48 --> Security Class Initialized
DEBUG - 2018-06-18 18:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:28:48 --> CSRF cookie sent
INFO - 2018-06-18 18:28:48 --> Input Class Initialized
INFO - 2018-06-18 18:28:48 --> Language Class Initialized
ERROR - 2018-06-18 18:28:48 --> 404 Page Not Found: Assets/revolution
INFO - 2018-06-18 18:28:48 --> Config Class Initialized
INFO - 2018-06-18 18:28:48 --> Hooks Class Initialized
DEBUG - 2018-06-18 18:28:48 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:28:48 --> Utf8 Class Initialized
INFO - 2018-06-18 18:28:48 --> URI Class Initialized
INFO - 2018-06-18 18:28:48 --> Router Class Initialized
INFO - 2018-06-18 18:28:48 --> Output Class Initialized
INFO - 2018-06-18 18:28:48 --> Security Class Initialized
DEBUG - 2018-06-18 18:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:28:48 --> CSRF cookie sent
INFO - 2018-06-18 18:28:48 --> Input Class Initialized
INFO - 2018-06-18 18:28:48 --> Language Class Initialized
ERROR - 2018-06-18 18:28:48 --> 404 Page Not Found: Assets/revolution
INFO - 2018-06-18 18:28:48 --> Config Class Initialized
INFO - 2018-06-18 18:28:48 --> Hooks Class Initialized
DEBUG - 2018-06-18 18:28:48 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:28:48 --> Utf8 Class Initialized
INFO - 2018-06-18 18:28:48 --> URI Class Initialized
INFO - 2018-06-18 18:28:48 --> Router Class Initialized
INFO - 2018-06-18 18:28:48 --> Output Class Initialized
INFO - 2018-06-18 18:28:48 --> Security Class Initialized
DEBUG - 2018-06-18 18:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:28:48 --> CSRF cookie sent
INFO - 2018-06-18 18:28:48 --> Input Class Initialized
INFO - 2018-06-18 18:28:48 --> Language Class Initialized
ERROR - 2018-06-18 18:28:48 --> 404 Page Not Found: Assets/revolution
INFO - 2018-06-18 18:28:48 --> Config Class Initialized
INFO - 2018-06-18 18:28:48 --> Hooks Class Initialized
DEBUG - 2018-06-18 18:28:48 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:28:48 --> Utf8 Class Initialized
INFO - 2018-06-18 18:28:48 --> URI Class Initialized
INFO - 2018-06-18 18:28:48 --> Router Class Initialized
INFO - 2018-06-18 18:28:48 --> Output Class Initialized
INFO - 2018-06-18 18:28:48 --> Security Class Initialized
DEBUG - 2018-06-18 18:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:28:48 --> CSRF cookie sent
INFO - 2018-06-18 18:28:48 --> Input Class Initialized
INFO - 2018-06-18 18:28:48 --> Language Class Initialized
ERROR - 2018-06-18 18:28:48 --> 404 Page Not Found: Assets/revolution
INFO - 2018-06-18 18:28:48 --> Config Class Initialized
INFO - 2018-06-18 18:28:48 --> Hooks Class Initialized
DEBUG - 2018-06-18 18:28:48 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:28:48 --> Utf8 Class Initialized
INFO - 2018-06-18 18:28:48 --> URI Class Initialized
INFO - 2018-06-18 18:28:48 --> Router Class Initialized
INFO - 2018-06-18 18:28:48 --> Output Class Initialized
INFO - 2018-06-18 18:28:48 --> Security Class Initialized
DEBUG - 2018-06-18 18:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:28:48 --> CSRF cookie sent
INFO - 2018-06-18 18:28:48 --> Input Class Initialized
INFO - 2018-06-18 18:28:48 --> Language Class Initialized
ERROR - 2018-06-18 18:28:48 --> 404 Page Not Found: Assets/revolution
INFO - 2018-06-18 18:28:48 --> Config Class Initialized
INFO - 2018-06-18 18:28:48 --> Hooks Class Initialized
DEBUG - 2018-06-18 18:28:48 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:28:48 --> Utf8 Class Initialized
INFO - 2018-06-18 18:28:48 --> URI Class Initialized
INFO - 2018-06-18 18:28:48 --> Router Class Initialized
INFO - 2018-06-18 18:28:48 --> Output Class Initialized
INFO - 2018-06-18 18:28:48 --> Security Class Initialized
DEBUG - 2018-06-18 18:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:28:48 --> CSRF cookie sent
INFO - 2018-06-18 18:28:48 --> Input Class Initialized
INFO - 2018-06-18 18:28:48 --> Language Class Initialized
ERROR - 2018-06-18 18:28:48 --> 404 Page Not Found: Assets/revolution
INFO - 2018-06-18 18:28:48 --> Config Class Initialized
INFO - 2018-06-18 18:28:48 --> Hooks Class Initialized
DEBUG - 2018-06-18 18:28:48 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:28:48 --> Utf8 Class Initialized
INFO - 2018-06-18 18:28:48 --> URI Class Initialized
INFO - 2018-06-18 18:28:48 --> Router Class Initialized
INFO - 2018-06-18 18:28:48 --> Output Class Initialized
INFO - 2018-06-18 18:28:48 --> Security Class Initialized
DEBUG - 2018-06-18 18:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:28:48 --> CSRF cookie sent
INFO - 2018-06-18 18:28:48 --> Input Class Initialized
INFO - 2018-06-18 18:28:48 --> Language Class Initialized
ERROR - 2018-06-18 18:28:48 --> 404 Page Not Found: Assets/js
INFO - 2018-06-18 18:28:48 --> Config Class Initialized
INFO - 2018-06-18 18:28:48 --> Hooks Class Initialized
DEBUG - 2018-06-18 18:28:48 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:28:48 --> Utf8 Class Initialized
INFO - 2018-06-18 18:28:48 --> URI Class Initialized
INFO - 2018-06-18 18:28:48 --> Router Class Initialized
INFO - 2018-06-18 18:28:48 --> Output Class Initialized
INFO - 2018-06-18 18:28:48 --> Security Class Initialized
DEBUG - 2018-06-18 18:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:28:48 --> CSRF cookie sent
INFO - 2018-06-18 18:28:48 --> Input Class Initialized
INFO - 2018-06-18 18:28:48 --> Language Class Initialized
ERROR - 2018-06-18 18:28:48 --> 404 Page Not Found: Assets/js
INFO - 2018-06-18 18:28:49 --> Config Class Initialized
INFO - 2018-06-18 18:28:49 --> Hooks Class Initialized
DEBUG - 2018-06-18 18:28:49 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:28:49 --> Utf8 Class Initialized
INFO - 2018-06-18 18:28:49 --> URI Class Initialized
INFO - 2018-06-18 18:28:49 --> Router Class Initialized
INFO - 2018-06-18 18:28:49 --> Output Class Initialized
INFO - 2018-06-18 18:28:49 --> Security Class Initialized
DEBUG - 2018-06-18 18:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:28:49 --> CSRF cookie sent
INFO - 2018-06-18 18:28:49 --> Input Class Initialized
INFO - 2018-06-18 18:28:49 --> Language Class Initialized
ERROR - 2018-06-18 18:28:49 --> 404 Page Not Found: Assets/images
INFO - 2018-06-18 18:28:59 --> Config Class Initialized
INFO - 2018-06-18 18:28:59 --> Hooks Class Initialized
DEBUG - 2018-06-18 18:28:59 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:28:59 --> Utf8 Class Initialized
INFO - 2018-06-18 18:28:59 --> URI Class Initialized
INFO - 2018-06-18 18:28:59 --> Router Class Initialized
INFO - 2018-06-18 18:28:59 --> Config Class Initialized
INFO - 2018-06-18 18:28:59 --> Hooks Class Initialized
INFO - 2018-06-18 18:28:59 --> Output Class Initialized
DEBUG - 2018-06-18 18:28:59 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:28:59 --> Utf8 Class Initialized
INFO - 2018-06-18 18:28:59 --> Config Class Initialized
INFO - 2018-06-18 18:28:59 --> Hooks Class Initialized
INFO - 2018-06-18 18:28:59 --> URI Class Initialized
INFO - 2018-06-18 18:28:59 --> Config Class Initialized
INFO - 2018-06-18 18:28:59 --> Hooks Class Initialized
INFO - 2018-06-18 18:28:59 --> Config Class Initialized
INFO - 2018-06-18 18:28:59 --> Hooks Class Initialized
INFO - 2018-06-18 18:28:59 --> Security Class Initialized
INFO - 2018-06-18 18:28:59 --> Config Class Initialized
INFO - 2018-06-18 18:28:59 --> Hooks Class Initialized
DEBUG - 2018-06-18 18:28:59 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:28:59 --> Utf8 Class Initialized
DEBUG - 2018-06-18 18:28:59 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:28:59 --> Utf8 Class Initialized
DEBUG - 2018-06-18 18:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:28:59 --> CSRF cookie sent
INFO - 2018-06-18 18:28:59 --> Input Class Initialized
INFO - 2018-06-18 18:28:59 --> Language Class Initialized
INFO - 2018-06-18 18:28:59 --> URI Class Initialized
INFO - 2018-06-18 18:28:59 --> Router Class Initialized
ERROR - 2018-06-18 18:28:59 --> 404 Page Not Found: Assets/css
DEBUG - 2018-06-18 18:28:59 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:28:59 --> Utf8 Class Initialized
INFO - 2018-06-18 18:28:59 --> URI Class Initialized
DEBUG - 2018-06-18 18:28:59 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:28:59 --> Utf8 Class Initialized
INFO - 2018-06-18 18:28:59 --> URI Class Initialized
INFO - 2018-06-18 18:28:59 --> URI Class Initialized
INFO - 2018-06-18 18:28:59 --> Output Class Initialized
INFO - 2018-06-18 18:28:59 --> Router Class Initialized
INFO - 2018-06-18 18:28:59 --> Router Class Initialized
INFO - 2018-06-18 18:28:59 --> Router Class Initialized
INFO - 2018-06-18 18:28:59 --> Security Class Initialized
INFO - 2018-06-18 18:28:59 --> Output Class Initialized
INFO - 2018-06-18 18:28:59 --> Router Class Initialized
INFO - 2018-06-18 18:28:59 --> Output Class Initialized
INFO - 2018-06-18 18:28:59 --> Output Class Initialized
DEBUG - 2018-06-18 18:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:28:59 --> CSRF cookie sent
INFO - 2018-06-18 18:28:59 --> Input Class Initialized
INFO - 2018-06-18 18:28:59 --> Security Class Initialized
INFO - 2018-06-18 18:28:59 --> Output Class Initialized
INFO - 2018-06-18 18:28:59 --> Language Class Initialized
INFO - 2018-06-18 18:28:59 --> Security Class Initialized
INFO - 2018-06-18 18:28:59 --> Security Class Initialized
ERROR - 2018-06-18 18:28:59 --> 404 Page Not Found: Assets/revolution
DEBUG - 2018-06-18 18:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:28:59 --> Security Class Initialized
INFO - 2018-06-18 18:28:59 --> CSRF cookie sent
INFO - 2018-06-18 18:28:59 --> Input Class Initialized
INFO - 2018-06-18 18:28:59 --> Language Class Initialized
DEBUG - 2018-06-18 18:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:28:59 --> CSRF cookie sent
INFO - 2018-06-18 18:28:59 --> Input Class Initialized
INFO - 2018-06-18 18:28:59 --> Language Class Initialized
DEBUG - 2018-06-18 18:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:28:59 --> CSRF cookie sent
INFO - 2018-06-18 18:28:59 --> Input Class Initialized
INFO - 2018-06-18 18:28:59 --> Language Class Initialized
ERROR - 2018-06-18 18:28:59 --> 404 Page Not Found: Assets/css
DEBUG - 2018-06-18 18:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:28:59 --> CSRF cookie sent
INFO - 2018-06-18 18:28:59 --> Input Class Initialized
ERROR - 2018-06-18 18:28:59 --> 404 Page Not Found: Assets/css
INFO - 2018-06-18 18:28:59 --> Language Class Initialized
ERROR - 2018-06-18 18:28:59 --> 404 Page Not Found: Assets/css
ERROR - 2018-06-18 18:28:59 --> 404 Page Not Found: Assets/css
INFO - 2018-06-18 18:28:59 --> Config Class Initialized
INFO - 2018-06-18 18:28:59 --> Hooks Class Initialized
DEBUG - 2018-06-18 18:28:59 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:28:59 --> Utf8 Class Initialized
INFO - 2018-06-18 18:28:59 --> URI Class Initialized
INFO - 2018-06-18 18:28:59 --> Router Class Initialized
INFO - 2018-06-18 18:28:59 --> Output Class Initialized
INFO - 2018-06-18 18:28:59 --> Security Class Initialized
DEBUG - 2018-06-18 18:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:28:59 --> CSRF cookie sent
INFO - 2018-06-18 18:28:59 --> Input Class Initialized
INFO - 2018-06-18 18:28:59 --> Language Class Initialized
ERROR - 2018-06-18 18:28:59 --> 404 Page Not Found: Assets/css
INFO - 2018-06-18 18:30:18 --> Config Class Initialized
INFO - 2018-06-18 18:30:18 --> Hooks Class Initialized
DEBUG - 2018-06-18 18:30:18 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:30:18 --> Utf8 Class Initialized
INFO - 2018-06-18 18:30:18 --> URI Class Initialized
DEBUG - 2018-06-18 18:30:18 --> No URI present. Default controller set.
INFO - 2018-06-18 18:30:18 --> Router Class Initialized
INFO - 2018-06-18 18:30:18 --> Output Class Initialized
INFO - 2018-06-18 18:30:18 --> Security Class Initialized
DEBUG - 2018-06-18 18:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:30:18 --> CSRF cookie sent
INFO - 2018-06-18 18:30:18 --> Input Class Initialized
INFO - 2018-06-18 18:30:18 --> Language Class Initialized
INFO - 2018-06-18 18:30:18 --> Loader Class Initialized
INFO - 2018-06-18 18:30:18 --> Helper loaded: url_helper
INFO - 2018-06-18 18:30:18 --> Helper loaded: form_helper
INFO - 2018-06-18 18:30:18 --> Helper loaded: language_helper
DEBUG - 2018-06-18 18:30:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 18:30:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 18:30:18 --> User Agent Class Initialized
INFO - 2018-06-18 18:30:18 --> Controller Class Initialized
INFO - 2018-06-18 18:30:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-18 18:30:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-18 18:30:18 --> Pixel_Model class loaded
INFO - 2018-06-18 18:30:18 --> Database Driver Class Initialized
INFO - 2018-06-18 18:30:18 --> Model "QuestionsModel" initialized
INFO - 2018-06-18 18:30:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-18 18:30:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-18 18:30:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-18 18:30:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-18 18:30:18 --> Final output sent to browser
DEBUG - 2018-06-18 18:30:18 --> Total execution time: 0.0452
INFO - 2018-06-18 18:30:19 --> Config Class Initialized
INFO - 2018-06-18 18:30:19 --> Hooks Class Initialized
DEBUG - 2018-06-18 18:30:19 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:30:19 --> Utf8 Class Initialized
INFO - 2018-06-18 18:30:19 --> URI Class Initialized
INFO - 2018-06-18 18:30:19 --> Router Class Initialized
INFO - 2018-06-18 18:30:19 --> Output Class Initialized
INFO - 2018-06-18 18:30:19 --> Security Class Initialized
DEBUG - 2018-06-18 18:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:30:19 --> CSRF cookie sent
INFO - 2018-06-18 18:30:19 --> Input Class Initialized
INFO - 2018-06-18 18:30:19 --> Language Class Initialized
ERROR - 2018-06-18 18:30:19 --> 404 Page Not Found: Assets/css
INFO - 2018-06-18 18:30:20 --> Config Class Initialized
INFO - 2018-06-18 18:30:20 --> Hooks Class Initialized
DEBUG - 2018-06-18 18:30:20 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:30:20 --> Utf8 Class Initialized
INFO - 2018-06-18 18:30:20 --> URI Class Initialized
INFO - 2018-06-18 18:30:20 --> Router Class Initialized
INFO - 2018-06-18 18:30:20 --> Output Class Initialized
INFO - 2018-06-18 18:30:20 --> Security Class Initialized
DEBUG - 2018-06-18 18:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:30:20 --> Config Class Initialized
INFO - 2018-06-18 18:30:20 --> CSRF cookie sent
INFO - 2018-06-18 18:30:20 --> Hooks Class Initialized
INFO - 2018-06-18 18:30:20 --> Input Class Initialized
INFO - 2018-06-18 18:30:20 --> Language Class Initialized
ERROR - 2018-06-18 18:30:20 --> 404 Page Not Found: Yacopoo/assets
DEBUG - 2018-06-18 18:30:20 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:30:20 --> Utf8 Class Initialized
INFO - 2018-06-18 18:30:20 --> URI Class Initialized
INFO - 2018-06-18 18:30:20 --> Config Class Initialized
INFO - 2018-06-18 18:30:20 --> Hooks Class Initialized
INFO - 2018-06-18 18:30:20 --> Router Class Initialized
DEBUG - 2018-06-18 18:30:20 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:30:20 --> Utf8 Class Initialized
INFO - 2018-06-18 18:30:20 --> Output Class Initialized
INFO - 2018-06-18 18:30:20 --> URI Class Initialized
INFO - 2018-06-18 18:30:20 --> Security Class Initialized
INFO - 2018-06-18 18:30:20 --> Router Class Initialized
DEBUG - 2018-06-18 18:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:30:20 --> CSRF cookie sent
INFO - 2018-06-18 18:30:20 --> Input Class Initialized
INFO - 2018-06-18 18:30:20 --> Language Class Initialized
INFO - 2018-06-18 18:30:20 --> Output Class Initialized
ERROR - 2018-06-18 18:30:20 --> 404 Page Not Found: Yacopoo/assets
INFO - 2018-06-18 18:30:20 --> Security Class Initialized
DEBUG - 2018-06-18 18:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:30:20 --> CSRF cookie sent
INFO - 2018-06-18 18:30:20 --> Input Class Initialized
INFO - 2018-06-18 18:30:20 --> Language Class Initialized
ERROR - 2018-06-18 18:30:20 --> 404 Page Not Found: Yacopoo/assets
INFO - 2018-06-18 18:30:40 --> Config Class Initialized
INFO - 2018-06-18 18:30:40 --> Hooks Class Initialized
DEBUG - 2018-06-18 18:30:40 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:30:40 --> Utf8 Class Initialized
INFO - 2018-06-18 18:30:40 --> URI Class Initialized
DEBUG - 2018-06-18 18:30:40 --> No URI present. Default controller set.
INFO - 2018-06-18 18:30:40 --> Router Class Initialized
INFO - 2018-06-18 18:30:40 --> Output Class Initialized
INFO - 2018-06-18 18:30:40 --> Security Class Initialized
DEBUG - 2018-06-18 18:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:30:40 --> CSRF cookie sent
INFO - 2018-06-18 18:30:40 --> Input Class Initialized
INFO - 2018-06-18 18:30:40 --> Language Class Initialized
INFO - 2018-06-18 18:30:40 --> Loader Class Initialized
INFO - 2018-06-18 18:30:40 --> Helper loaded: url_helper
INFO - 2018-06-18 18:30:40 --> Helper loaded: form_helper
INFO - 2018-06-18 18:30:40 --> Helper loaded: language_helper
DEBUG - 2018-06-18 18:30:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 18:30:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 18:30:40 --> User Agent Class Initialized
INFO - 2018-06-18 18:30:40 --> Controller Class Initialized
INFO - 2018-06-18 18:30:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-18 18:30:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-18 18:30:40 --> Pixel_Model class loaded
INFO - 2018-06-18 18:30:40 --> Database Driver Class Initialized
INFO - 2018-06-18 18:30:40 --> Model "QuestionsModel" initialized
INFO - 2018-06-18 18:30:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-18 18:30:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-18 18:30:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-18 18:30:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-18 18:30:40 --> Final output sent to browser
DEBUG - 2018-06-18 18:30:40 --> Total execution time: 0.0610
INFO - 2018-06-18 18:30:42 --> Config Class Initialized
INFO - 2018-06-18 18:30:42 --> Hooks Class Initialized
INFO - 2018-06-18 18:30:42 --> Config Class Initialized
INFO - 2018-06-18 18:30:42 --> Hooks Class Initialized
DEBUG - 2018-06-18 18:30:42 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:30:42 --> Utf8 Class Initialized
DEBUG - 2018-06-18 18:30:42 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:30:42 --> Utf8 Class Initialized
INFO - 2018-06-18 18:30:42 --> URI Class Initialized
INFO - 2018-06-18 18:30:42 --> Router Class Initialized
INFO - 2018-06-18 18:30:42 --> URI Class Initialized
INFO - 2018-06-18 18:30:42 --> Output Class Initialized
INFO - 2018-06-18 18:30:42 --> Security Class Initialized
DEBUG - 2018-06-18 18:30:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:30:42 --> CSRF cookie sent
INFO - 2018-06-18 18:30:42 --> Input Class Initialized
INFO - 2018-06-18 18:30:42 --> Language Class Initialized
ERROR - 2018-06-18 18:30:42 --> 404 Page Not Found: Yacopoo/assets
INFO - 2018-06-18 18:30:42 --> Router Class Initialized
INFO - 2018-06-18 18:30:42 --> Output Class Initialized
INFO - 2018-06-18 18:30:42 --> Security Class Initialized
INFO - 2018-06-18 18:30:42 --> Config Class Initialized
INFO - 2018-06-18 18:30:42 --> Hooks Class Initialized
DEBUG - 2018-06-18 18:30:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:30:42 --> CSRF cookie sent
INFO - 2018-06-18 18:30:42 --> Input Class Initialized
INFO - 2018-06-18 18:30:42 --> Language Class Initialized
DEBUG - 2018-06-18 18:30:42 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:30:42 --> Utf8 Class Initialized
ERROR - 2018-06-18 18:30:42 --> 404 Page Not Found: Yacopoo/assets
INFO - 2018-06-18 18:30:42 --> URI Class Initialized
INFO - 2018-06-18 18:30:42 --> Router Class Initialized
INFO - 2018-06-18 18:30:42 --> Output Class Initialized
INFO - 2018-06-18 18:30:42 --> Security Class Initialized
DEBUG - 2018-06-18 18:30:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:30:42 --> CSRF cookie sent
INFO - 2018-06-18 18:30:42 --> Input Class Initialized
INFO - 2018-06-18 18:30:42 --> Language Class Initialized
ERROR - 2018-06-18 18:30:42 --> 404 Page Not Found: Yacopoo/assets
INFO - 2018-06-18 18:30:45 --> Config Class Initialized
INFO - 2018-06-18 18:30:45 --> Hooks Class Initialized
DEBUG - 2018-06-18 18:30:45 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:30:45 --> Utf8 Class Initialized
INFO - 2018-06-18 18:30:45 --> URI Class Initialized
INFO - 2018-06-18 18:30:45 --> Router Class Initialized
INFO - 2018-06-18 18:30:45 --> Output Class Initialized
INFO - 2018-06-18 18:30:45 --> Security Class Initialized
DEBUG - 2018-06-18 18:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:30:45 --> CSRF cookie sent
INFO - 2018-06-18 18:30:45 --> Input Class Initialized
INFO - 2018-06-18 18:30:45 --> Language Class Initialized
ERROR - 2018-06-18 18:30:45 --> 404 Page Not Found: Assets/css
INFO - 2018-06-18 18:31:59 --> Config Class Initialized
INFO - 2018-06-18 18:31:59 --> Hooks Class Initialized
DEBUG - 2018-06-18 18:31:59 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:31:59 --> Utf8 Class Initialized
INFO - 2018-06-18 18:31:59 --> URI Class Initialized
DEBUG - 2018-06-18 18:31:59 --> No URI present. Default controller set.
INFO - 2018-06-18 18:31:59 --> Router Class Initialized
INFO - 2018-06-18 18:31:59 --> Output Class Initialized
INFO - 2018-06-18 18:31:59 --> Security Class Initialized
DEBUG - 2018-06-18 18:31:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:31:59 --> CSRF cookie sent
INFO - 2018-06-18 18:31:59 --> Input Class Initialized
INFO - 2018-06-18 18:31:59 --> Language Class Initialized
INFO - 2018-06-18 18:31:59 --> Loader Class Initialized
INFO - 2018-06-18 18:31:59 --> Helper loaded: url_helper
INFO - 2018-06-18 18:31:59 --> Helper loaded: form_helper
INFO - 2018-06-18 18:31:59 --> Helper loaded: language_helper
DEBUG - 2018-06-18 18:31:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 18:31:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 18:31:59 --> User Agent Class Initialized
INFO - 2018-06-18 18:31:59 --> Controller Class Initialized
INFO - 2018-06-18 18:31:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-18 18:31:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-18 18:31:59 --> Pixel_Model class loaded
INFO - 2018-06-18 18:31:59 --> Database Driver Class Initialized
INFO - 2018-06-18 18:31:59 --> Model "QuestionsModel" initialized
INFO - 2018-06-18 18:31:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-18 18:31:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-18 18:31:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-18 18:31:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-18 18:31:59 --> Final output sent to browser
DEBUG - 2018-06-18 18:31:59 --> Total execution time: 0.0699
INFO - 2018-06-18 18:32:00 --> Config Class Initialized
INFO - 2018-06-18 18:32:00 --> Hooks Class Initialized
DEBUG - 2018-06-18 18:32:00 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:32:00 --> Utf8 Class Initialized
INFO - 2018-06-18 18:32:00 --> URI Class Initialized
INFO - 2018-06-18 18:32:00 --> Router Class Initialized
INFO - 2018-06-18 18:32:00 --> Output Class Initialized
INFO - 2018-06-18 18:32:00 --> Security Class Initialized
DEBUG - 2018-06-18 18:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:32:00 --> CSRF cookie sent
INFO - 2018-06-18 18:32:00 --> Input Class Initialized
INFO - 2018-06-18 18:32:00 --> Language Class Initialized
ERROR - 2018-06-18 18:32:00 --> 404 Page Not Found: Assets/css
INFO - 2018-06-18 18:32:30 --> Config Class Initialized
INFO - 2018-06-18 18:32:30 --> Hooks Class Initialized
DEBUG - 2018-06-18 18:32:30 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:32:30 --> Utf8 Class Initialized
INFO - 2018-06-18 18:32:30 --> URI Class Initialized
DEBUG - 2018-06-18 18:32:30 --> No URI present. Default controller set.
INFO - 2018-06-18 18:32:30 --> Router Class Initialized
INFO - 2018-06-18 18:32:30 --> Output Class Initialized
INFO - 2018-06-18 18:32:30 --> Security Class Initialized
DEBUG - 2018-06-18 18:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:32:30 --> CSRF cookie sent
INFO - 2018-06-18 18:32:30 --> Input Class Initialized
INFO - 2018-06-18 18:32:30 --> Language Class Initialized
INFO - 2018-06-18 18:32:30 --> Loader Class Initialized
INFO - 2018-06-18 18:32:30 --> Helper loaded: url_helper
INFO - 2018-06-18 18:32:30 --> Helper loaded: form_helper
INFO - 2018-06-18 18:32:30 --> Helper loaded: language_helper
DEBUG - 2018-06-18 18:32:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 18:32:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 18:32:30 --> User Agent Class Initialized
INFO - 2018-06-18 18:32:30 --> Controller Class Initialized
INFO - 2018-06-18 18:32:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-18 18:32:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-18 18:32:30 --> Pixel_Model class loaded
INFO - 2018-06-18 18:32:30 --> Database Driver Class Initialized
INFO - 2018-06-18 18:32:30 --> Model "QuestionsModel" initialized
INFO - 2018-06-18 18:32:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-18 18:32:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-18 18:32:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-18 18:32:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-18 18:32:30 --> Final output sent to browser
DEBUG - 2018-06-18 18:32:30 --> Total execution time: 0.0448
INFO - 2018-06-18 18:32:31 --> Config Class Initialized
INFO - 2018-06-18 18:32:31 --> Hooks Class Initialized
DEBUG - 2018-06-18 18:32:31 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:32:31 --> Utf8 Class Initialized
INFO - 2018-06-18 18:32:31 --> URI Class Initialized
INFO - 2018-06-18 18:32:31 --> Router Class Initialized
INFO - 2018-06-18 18:32:31 --> Output Class Initialized
INFO - 2018-06-18 18:32:31 --> Security Class Initialized
DEBUG - 2018-06-18 18:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:32:31 --> CSRF cookie sent
INFO - 2018-06-18 18:32:31 --> Input Class Initialized
INFO - 2018-06-18 18:32:31 --> Language Class Initialized
ERROR - 2018-06-18 18:32:31 --> 404 Page Not Found: Assets/css
INFO - 2018-06-18 18:32:39 --> Config Class Initialized
INFO - 2018-06-18 18:32:39 --> Hooks Class Initialized
DEBUG - 2018-06-18 18:32:39 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:32:39 --> Utf8 Class Initialized
INFO - 2018-06-18 18:32:39 --> URI Class Initialized
DEBUG - 2018-06-18 18:32:39 --> No URI present. Default controller set.
INFO - 2018-06-18 18:32:39 --> Router Class Initialized
INFO - 2018-06-18 18:32:39 --> Output Class Initialized
INFO - 2018-06-18 18:32:39 --> Security Class Initialized
DEBUG - 2018-06-18 18:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:32:39 --> CSRF cookie sent
INFO - 2018-06-18 18:32:39 --> Input Class Initialized
INFO - 2018-06-18 18:32:39 --> Language Class Initialized
INFO - 2018-06-18 18:32:39 --> Loader Class Initialized
INFO - 2018-06-18 18:32:39 --> Helper loaded: url_helper
INFO - 2018-06-18 18:32:39 --> Helper loaded: form_helper
INFO - 2018-06-18 18:32:39 --> Helper loaded: language_helper
DEBUG - 2018-06-18 18:32:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 18:32:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 18:32:39 --> User Agent Class Initialized
INFO - 2018-06-18 18:32:39 --> Controller Class Initialized
INFO - 2018-06-18 18:32:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-18 18:32:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-18 18:32:39 --> Pixel_Model class loaded
INFO - 2018-06-18 18:32:39 --> Database Driver Class Initialized
INFO - 2018-06-18 18:32:39 --> Model "QuestionsModel" initialized
INFO - 2018-06-18 18:32:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-18 18:32:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-18 18:32:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-18 18:32:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-18 18:32:39 --> Final output sent to browser
DEBUG - 2018-06-18 18:32:39 --> Total execution time: 0.0628
INFO - 2018-06-18 18:32:45 --> Config Class Initialized
INFO - 2018-06-18 18:32:45 --> Hooks Class Initialized
DEBUG - 2018-06-18 18:32:45 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:32:45 --> Utf8 Class Initialized
INFO - 2018-06-18 18:32:45 --> URI Class Initialized
INFO - 2018-06-18 18:32:45 --> Router Class Initialized
INFO - 2018-06-18 18:32:45 --> Output Class Initialized
INFO - 2018-06-18 18:32:45 --> Security Class Initialized
DEBUG - 2018-06-18 18:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:32:45 --> CSRF cookie sent
INFO - 2018-06-18 18:32:45 --> Input Class Initialized
INFO - 2018-06-18 18:32:45 --> Language Class Initialized
INFO - 2018-06-18 18:32:45 --> Loader Class Initialized
INFO - 2018-06-18 18:32:45 --> Helper loaded: url_helper
INFO - 2018-06-18 18:32:45 --> Helper loaded: form_helper
INFO - 2018-06-18 18:32:45 --> Helper loaded: language_helper
DEBUG - 2018-06-18 18:32:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 18:32:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 18:32:45 --> User Agent Class Initialized
INFO - 2018-06-18 18:32:45 --> Controller Class Initialized
INFO - 2018-06-18 18:32:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-18 18:32:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-18 18:32:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-18 18:32:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-18 18:32:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-18 18:32:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-18 18:32:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-06-18 18:32:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-18 18:32:45 --> Final output sent to browser
DEBUG - 2018-06-18 18:32:45 --> Total execution time: 0.0412
INFO - 2018-06-18 18:32:52 --> Config Class Initialized
INFO - 2018-06-18 18:32:52 --> Hooks Class Initialized
DEBUG - 2018-06-18 18:32:52 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:32:52 --> Utf8 Class Initialized
INFO - 2018-06-18 18:32:52 --> URI Class Initialized
INFO - 2018-06-18 18:32:52 --> Router Class Initialized
INFO - 2018-06-18 18:32:52 --> Output Class Initialized
INFO - 2018-06-18 18:32:52 --> Security Class Initialized
DEBUG - 2018-06-18 18:32:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:32:52 --> CSRF cookie sent
INFO - 2018-06-18 18:32:52 --> Input Class Initialized
INFO - 2018-06-18 18:32:52 --> Language Class Initialized
INFO - 2018-06-18 18:32:52 --> Loader Class Initialized
INFO - 2018-06-18 18:32:52 --> Helper loaded: url_helper
INFO - 2018-06-18 18:32:52 --> Helper loaded: form_helper
INFO - 2018-06-18 18:32:52 --> Helper loaded: language_helper
DEBUG - 2018-06-18 18:32:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 18:32:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 18:32:52 --> User Agent Class Initialized
INFO - 2018-06-18 18:32:52 --> Controller Class Initialized
INFO - 2018-06-18 18:32:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-18 18:32:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-18 18:32:52 --> Pixel_Model class loaded
INFO - 2018-06-18 18:32:52 --> Database Driver Class Initialized
INFO - 2018-06-18 18:32:52 --> Model "QuestionsModel" initialized
INFO - 2018-06-18 18:32:52 --> Config Class Initialized
INFO - 2018-06-18 18:32:52 --> Hooks Class Initialized
DEBUG - 2018-06-18 18:32:52 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:32:52 --> Utf8 Class Initialized
INFO - 2018-06-18 18:32:52 --> URI Class Initialized
INFO - 2018-06-18 18:32:52 --> Router Class Initialized
INFO - 2018-06-18 18:32:52 --> Output Class Initialized
INFO - 2018-06-18 18:32:52 --> Security Class Initialized
DEBUG - 2018-06-18 18:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:32:53 --> CSRF cookie sent
INFO - 2018-06-18 18:32:53 --> Input Class Initialized
INFO - 2018-06-18 18:32:53 --> Language Class Initialized
INFO - 2018-06-18 18:32:53 --> Loader Class Initialized
INFO - 2018-06-18 18:32:53 --> Helper loaded: url_helper
INFO - 2018-06-18 18:32:53 --> Helper loaded: form_helper
INFO - 2018-06-18 18:32:53 --> Helper loaded: language_helper
DEBUG - 2018-06-18 18:32:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 18:32:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 18:32:53 --> User Agent Class Initialized
INFO - 2018-06-18 18:32:53 --> Controller Class Initialized
INFO - 2018-06-18 18:32:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-18 18:32:53 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-18 18:32:53 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-18 18:32:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-18 18:32:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-18 18:32:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-18 18:32:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-18 18:32:53 --> Could not find the language line "req_email"
INFO - 2018-06-18 18:32:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-06-18 18:32:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-18 18:32:53 --> Final output sent to browser
DEBUG - 2018-06-18 18:32:53 --> Total execution time: 0.0549
INFO - 2018-06-18 18:33:48 --> Config Class Initialized
INFO - 2018-06-18 18:33:48 --> Hooks Class Initialized
DEBUG - 2018-06-18 18:33:48 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:33:48 --> Utf8 Class Initialized
INFO - 2018-06-18 18:33:48 --> URI Class Initialized
INFO - 2018-06-18 18:33:48 --> Router Class Initialized
INFO - 2018-06-18 18:33:48 --> Output Class Initialized
INFO - 2018-06-18 18:33:48 --> Security Class Initialized
DEBUG - 2018-06-18 18:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:33:48 --> CSRF cookie sent
INFO - 2018-06-18 18:33:48 --> Input Class Initialized
INFO - 2018-06-18 18:33:48 --> Language Class Initialized
INFO - 2018-06-18 18:33:48 --> Loader Class Initialized
INFO - 2018-06-18 18:33:48 --> Helper loaded: url_helper
INFO - 2018-06-18 18:33:48 --> Helper loaded: form_helper
INFO - 2018-06-18 18:33:48 --> Helper loaded: language_helper
DEBUG - 2018-06-18 18:33:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 18:33:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 18:33:48 --> User Agent Class Initialized
INFO - 2018-06-18 18:33:48 --> Controller Class Initialized
INFO - 2018-06-18 18:33:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-18 18:33:48 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-18 18:33:48 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-18 18:33:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-18 18:33:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-18 18:33:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-18 18:33:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-18 18:33:48 --> Could not find the language line "req_email"
INFO - 2018-06-18 18:33:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-06-18 18:33:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-18 18:33:48 --> Final output sent to browser
DEBUG - 2018-06-18 18:33:48 --> Total execution time: 0.0609
INFO - 2018-06-18 18:33:50 --> Config Class Initialized
INFO - 2018-06-18 18:33:50 --> Hooks Class Initialized
DEBUG - 2018-06-18 18:33:50 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:33:50 --> Utf8 Class Initialized
INFO - 2018-06-18 18:33:50 --> URI Class Initialized
INFO - 2018-06-18 18:33:50 --> Router Class Initialized
INFO - 2018-06-18 18:33:50 --> Output Class Initialized
INFO - 2018-06-18 18:33:50 --> Security Class Initialized
DEBUG - 2018-06-18 18:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:33:50 --> CSRF cookie sent
INFO - 2018-06-18 18:33:50 --> Input Class Initialized
INFO - 2018-06-18 18:33:50 --> Language Class Initialized
INFO - 2018-06-18 18:33:50 --> Loader Class Initialized
INFO - 2018-06-18 18:33:50 --> Helper loaded: url_helper
INFO - 2018-06-18 18:33:50 --> Helper loaded: form_helper
INFO - 2018-06-18 18:33:50 --> Helper loaded: language_helper
DEBUG - 2018-06-18 18:33:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 18:33:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 18:33:50 --> User Agent Class Initialized
INFO - 2018-06-18 18:33:50 --> Controller Class Initialized
INFO - 2018-06-18 18:33:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-18 18:33:50 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-18 18:33:50 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-18 18:33:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-18 18:33:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-18 18:33:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-18 18:33:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-18 18:33:50 --> Could not find the language line "req_email"
INFO - 2018-06-18 18:33:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-06-18 18:33:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-18 18:33:50 --> Final output sent to browser
DEBUG - 2018-06-18 18:33:50 --> Total execution time: 0.0368
INFO - 2018-06-18 18:33:52 --> Config Class Initialized
INFO - 2018-06-18 18:33:52 --> Hooks Class Initialized
DEBUG - 2018-06-18 18:33:52 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:33:52 --> Utf8 Class Initialized
INFO - 2018-06-18 18:33:52 --> URI Class Initialized
INFO - 2018-06-18 18:33:52 --> Router Class Initialized
INFO - 2018-06-18 18:33:52 --> Output Class Initialized
INFO - 2018-06-18 18:33:52 --> Security Class Initialized
DEBUG - 2018-06-18 18:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:33:52 --> CSRF cookie sent
INFO - 2018-06-18 18:33:52 --> Input Class Initialized
INFO - 2018-06-18 18:33:52 --> Language Class Initialized
INFO - 2018-06-18 18:33:52 --> Loader Class Initialized
INFO - 2018-06-18 18:33:52 --> Helper loaded: url_helper
INFO - 2018-06-18 18:33:52 --> Helper loaded: form_helper
INFO - 2018-06-18 18:33:52 --> Helper loaded: language_helper
DEBUG - 2018-06-18 18:33:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 18:33:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 18:33:52 --> User Agent Class Initialized
INFO - 2018-06-18 18:33:52 --> Controller Class Initialized
INFO - 2018-06-18 18:33:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-18 18:33:52 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-18 18:33:52 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-18 18:33:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-18 18:33:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-18 18:33:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-18 18:33:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-18 18:33:52 --> Could not find the language line "req_email"
INFO - 2018-06-18 18:33:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-06-18 18:33:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-18 18:33:52 --> Final output sent to browser
DEBUG - 2018-06-18 18:33:52 --> Total execution time: 0.0366
INFO - 2018-06-18 18:34:17 --> Config Class Initialized
INFO - 2018-06-18 18:34:17 --> Hooks Class Initialized
DEBUG - 2018-06-18 18:34:17 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:34:17 --> Utf8 Class Initialized
INFO - 2018-06-18 18:34:17 --> URI Class Initialized
INFO - 2018-06-18 18:34:17 --> Router Class Initialized
INFO - 2018-06-18 18:34:17 --> Output Class Initialized
INFO - 2018-06-18 18:34:17 --> Security Class Initialized
DEBUG - 2018-06-18 18:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:34:17 --> CSRF cookie sent
INFO - 2018-06-18 18:34:17 --> Input Class Initialized
INFO - 2018-06-18 18:34:17 --> Language Class Initialized
INFO - 2018-06-18 18:34:17 --> Loader Class Initialized
INFO - 2018-06-18 18:34:17 --> Helper loaded: url_helper
INFO - 2018-06-18 18:34:17 --> Helper loaded: form_helper
INFO - 2018-06-18 18:34:17 --> Helper loaded: language_helper
DEBUG - 2018-06-18 18:34:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 18:34:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 18:34:17 --> User Agent Class Initialized
INFO - 2018-06-18 18:34:17 --> Controller Class Initialized
INFO - 2018-06-18 18:34:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-18 18:34:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-18 18:34:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-18 18:34:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-18 18:34:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-18 18:34:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-18 18:34:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-06-18 18:34:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-18 18:34:17 --> Final output sent to browser
DEBUG - 2018-06-18 18:34:17 --> Total execution time: 0.0409
INFO - 2018-06-18 18:34:19 --> Config Class Initialized
INFO - 2018-06-18 18:34:19 --> Hooks Class Initialized
DEBUG - 2018-06-18 18:34:19 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:34:19 --> Utf8 Class Initialized
INFO - 2018-06-18 18:34:19 --> URI Class Initialized
INFO - 2018-06-18 18:34:19 --> Router Class Initialized
INFO - 2018-06-18 18:34:19 --> Output Class Initialized
INFO - 2018-06-18 18:34:19 --> Security Class Initialized
DEBUG - 2018-06-18 18:34:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:34:19 --> CSRF cookie sent
INFO - 2018-06-18 18:34:19 --> Input Class Initialized
INFO - 2018-06-18 18:34:19 --> Language Class Initialized
INFO - 2018-06-18 18:34:19 --> Loader Class Initialized
INFO - 2018-06-18 18:34:19 --> Helper loaded: url_helper
INFO - 2018-06-18 18:34:19 --> Helper loaded: form_helper
INFO - 2018-06-18 18:34:19 --> Helper loaded: language_helper
DEBUG - 2018-06-18 18:34:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 18:34:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 18:34:19 --> User Agent Class Initialized
INFO - 2018-06-18 18:34:19 --> Controller Class Initialized
INFO - 2018-06-18 18:34:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-18 18:34:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-18 18:34:19 --> Pixel_Model class loaded
INFO - 2018-06-18 18:34:19 --> Database Driver Class Initialized
INFO - 2018-06-18 18:34:19 --> Model "RegistrationModel" initialized
DEBUG - 2018-06-18 18:34:19 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-18 18:34:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-18 18:34:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-18 18:34:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-18 18:34:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-18 18:34:19 --> Could not find the language line "req_email"
INFO - 2018-06-18 18:34:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup_lawyer.php
INFO - 2018-06-18 18:34:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-18 18:34:19 --> Final output sent to browser
DEBUG - 2018-06-18 18:34:19 --> Total execution time: 0.0443
INFO - 2018-06-18 18:37:50 --> Config Class Initialized
INFO - 2018-06-18 18:37:50 --> Hooks Class Initialized
DEBUG - 2018-06-18 18:37:50 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:37:50 --> Utf8 Class Initialized
INFO - 2018-06-18 18:37:50 --> URI Class Initialized
INFO - 2018-06-18 18:37:50 --> Router Class Initialized
INFO - 2018-06-18 18:37:50 --> Output Class Initialized
INFO - 2018-06-18 18:37:50 --> Security Class Initialized
DEBUG - 2018-06-18 18:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:37:50 --> CSRF cookie sent
INFO - 2018-06-18 18:37:50 --> Input Class Initialized
INFO - 2018-06-18 18:37:50 --> Language Class Initialized
INFO - 2018-06-18 18:37:50 --> Loader Class Initialized
INFO - 2018-06-18 18:37:50 --> Helper loaded: url_helper
INFO - 2018-06-18 18:37:50 --> Helper loaded: form_helper
INFO - 2018-06-18 18:37:50 --> Helper loaded: language_helper
DEBUG - 2018-06-18 18:37:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 18:37:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 18:37:50 --> User Agent Class Initialized
INFO - 2018-06-18 18:37:50 --> Controller Class Initialized
INFO - 2018-06-18 18:37:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-18 18:37:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-18 18:37:50 --> Pixel_Model class loaded
INFO - 2018-06-18 18:37:50 --> Database Driver Class Initialized
INFO - 2018-06-18 18:37:50 --> Model "QuestionsModel" initialized
INFO - 2018-06-18 18:37:50 --> Config Class Initialized
INFO - 2018-06-18 18:37:50 --> Hooks Class Initialized
DEBUG - 2018-06-18 18:37:50 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:37:50 --> Utf8 Class Initialized
INFO - 2018-06-18 18:37:50 --> URI Class Initialized
INFO - 2018-06-18 18:37:50 --> Router Class Initialized
INFO - 2018-06-18 18:37:50 --> Output Class Initialized
INFO - 2018-06-18 18:37:50 --> Security Class Initialized
DEBUG - 2018-06-18 18:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:37:50 --> CSRF cookie sent
INFO - 2018-06-18 18:37:50 --> Input Class Initialized
INFO - 2018-06-18 18:37:50 --> Language Class Initialized
INFO - 2018-06-18 18:37:50 --> Loader Class Initialized
INFO - 2018-06-18 18:37:50 --> Helper loaded: url_helper
INFO - 2018-06-18 18:37:50 --> Helper loaded: form_helper
INFO - 2018-06-18 18:37:50 --> Helper loaded: language_helper
DEBUG - 2018-06-18 18:37:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 18:37:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 18:37:50 --> User Agent Class Initialized
INFO - 2018-06-18 18:37:50 --> Controller Class Initialized
INFO - 2018-06-18 18:37:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-18 18:37:50 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-18 18:37:50 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-18 18:37:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-18 18:37:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-18 18:37:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-18 18:37:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-18 18:37:50 --> Could not find the language line "req_email"
INFO - 2018-06-18 18:37:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-06-18 18:37:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-18 18:37:50 --> Final output sent to browser
DEBUG - 2018-06-18 18:37:50 --> Total execution time: 0.0450
INFO - 2018-06-18 18:38:45 --> Config Class Initialized
INFO - 2018-06-18 18:38:45 --> Hooks Class Initialized
DEBUG - 2018-06-18 18:38:45 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:38:45 --> Utf8 Class Initialized
INFO - 2018-06-18 18:38:45 --> URI Class Initialized
INFO - 2018-06-18 18:38:45 --> Router Class Initialized
INFO - 2018-06-18 18:38:45 --> Output Class Initialized
INFO - 2018-06-18 18:38:45 --> Security Class Initialized
DEBUG - 2018-06-18 18:38:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:38:45 --> CSRF cookie sent
INFO - 2018-06-18 18:38:45 --> CSRF token verified
INFO - 2018-06-18 18:38:45 --> Input Class Initialized
INFO - 2018-06-18 18:38:45 --> Language Class Initialized
INFO - 2018-06-18 18:38:45 --> Loader Class Initialized
INFO - 2018-06-18 18:38:45 --> Helper loaded: url_helper
INFO - 2018-06-18 18:38:45 --> Helper loaded: form_helper
INFO - 2018-06-18 18:38:45 --> Helper loaded: language_helper
DEBUG - 2018-06-18 18:38:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 18:38:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 18:38:45 --> User Agent Class Initialized
INFO - 2018-06-18 18:38:45 --> Controller Class Initialized
INFO - 2018-06-18 18:38:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-18 18:38:45 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-18 18:38:45 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-18 18:38:46 --> Form Validation Class Initialized
INFO - 2018-06-18 18:38:46 --> Pixel_Model class loaded
INFO - 2018-06-18 18:38:46 --> Database Driver Class Initialized
INFO - 2018-06-18 18:38:46 --> Model "AuthenticationModel" initialized
INFO - 2018-06-18 18:38:46 --> Config Class Initialized
INFO - 2018-06-18 18:38:46 --> Hooks Class Initialized
DEBUG - 2018-06-18 18:38:46 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:38:46 --> Utf8 Class Initialized
INFO - 2018-06-18 18:38:46 --> URI Class Initialized
INFO - 2018-06-18 18:38:46 --> Router Class Initialized
INFO - 2018-06-18 18:38:46 --> Output Class Initialized
INFO - 2018-06-18 18:38:46 --> Security Class Initialized
DEBUG - 2018-06-18 18:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:38:46 --> CSRF cookie sent
INFO - 2018-06-18 18:38:46 --> Input Class Initialized
INFO - 2018-06-18 18:38:46 --> Language Class Initialized
INFO - 2018-06-18 18:38:46 --> Loader Class Initialized
INFO - 2018-06-18 18:38:46 --> Helper loaded: url_helper
INFO - 2018-06-18 18:38:46 --> Helper loaded: form_helper
INFO - 2018-06-18 18:38:46 --> Helper loaded: language_helper
DEBUG - 2018-06-18 18:38:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 18:38:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 18:38:46 --> User Agent Class Initialized
INFO - 2018-06-18 18:38:46 --> Controller Class Initialized
INFO - 2018-06-18 18:38:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-18 18:38:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-18 18:38:46 --> Pixel_Model class loaded
INFO - 2018-06-18 18:38:46 --> Database Driver Class Initialized
INFO - 2018-06-18 18:38:46 --> Model "MyAccountModel" initialized
INFO - 2018-06-18 18:38:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-18 18:38:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-18 18:38:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-18 18:38:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-18 18:38:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-18 18:38:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/application_list.php
INFO - 2018-06-18 18:38:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-18 18:38:46 --> Final output sent to browser
DEBUG - 2018-06-18 18:38:46 --> Total execution time: 0.0659
INFO - 2018-06-18 18:38:49 --> Config Class Initialized
INFO - 2018-06-18 18:38:49 --> Hooks Class Initialized
DEBUG - 2018-06-18 18:38:49 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:38:49 --> Utf8 Class Initialized
INFO - 2018-06-18 18:38:49 --> URI Class Initialized
INFO - 2018-06-18 18:38:49 --> Router Class Initialized
INFO - 2018-06-18 18:38:49 --> Output Class Initialized
INFO - 2018-06-18 18:38:49 --> Security Class Initialized
DEBUG - 2018-06-18 18:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:38:49 --> CSRF cookie sent
INFO - 2018-06-18 18:38:49 --> Input Class Initialized
INFO - 2018-06-18 18:38:49 --> Language Class Initialized
INFO - 2018-06-18 18:38:49 --> Loader Class Initialized
INFO - 2018-06-18 18:38:49 --> Helper loaded: url_helper
INFO - 2018-06-18 18:38:49 --> Helper loaded: form_helper
INFO - 2018-06-18 18:38:49 --> Helper loaded: language_helper
DEBUG - 2018-06-18 18:38:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 18:38:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 18:38:49 --> User Agent Class Initialized
INFO - 2018-06-18 18:38:49 --> Controller Class Initialized
INFO - 2018-06-18 18:38:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-18 18:38:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-18 18:38:49 --> Pixel_Model class loaded
INFO - 2018-06-18 18:38:49 --> Database Driver Class Initialized
INFO - 2018-06-18 18:38:49 --> Model "MyAccountModel" initialized
INFO - 2018-06-18 18:38:49 --> Config Class Initialized
INFO - 2018-06-18 18:38:49 --> Hooks Class Initialized
DEBUG - 2018-06-18 18:38:49 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:38:49 --> Utf8 Class Initialized
INFO - 2018-06-18 18:38:49 --> URI Class Initialized
DEBUG - 2018-06-18 18:38:49 --> No URI present. Default controller set.
INFO - 2018-06-18 18:38:49 --> Router Class Initialized
INFO - 2018-06-18 18:38:49 --> Output Class Initialized
INFO - 2018-06-18 18:38:49 --> Security Class Initialized
DEBUG - 2018-06-18 18:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:38:49 --> CSRF cookie sent
INFO - 2018-06-18 18:38:49 --> Input Class Initialized
INFO - 2018-06-18 18:38:49 --> Language Class Initialized
INFO - 2018-06-18 18:38:49 --> Loader Class Initialized
INFO - 2018-06-18 18:38:49 --> Helper loaded: url_helper
INFO - 2018-06-18 18:38:49 --> Helper loaded: form_helper
INFO - 2018-06-18 18:38:49 --> Helper loaded: language_helper
DEBUG - 2018-06-18 18:38:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 18:38:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 18:38:49 --> User Agent Class Initialized
INFO - 2018-06-18 18:38:49 --> Controller Class Initialized
INFO - 2018-06-18 18:38:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-18 18:38:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-18 18:38:49 --> Pixel_Model class loaded
INFO - 2018-06-18 18:38:49 --> Database Driver Class Initialized
INFO - 2018-06-18 18:38:49 --> Model "QuestionsModel" initialized
INFO - 2018-06-18 18:38:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-18 18:38:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-18 18:38:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-18 18:38:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-18 18:38:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-18 18:38:49 --> Final output sent to browser
DEBUG - 2018-06-18 18:38:49 --> Total execution time: 0.0490
INFO - 2018-06-18 18:38:55 --> Config Class Initialized
INFO - 2018-06-18 18:38:55 --> Hooks Class Initialized
DEBUG - 2018-06-18 18:38:55 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:38:55 --> Utf8 Class Initialized
INFO - 2018-06-18 18:38:55 --> URI Class Initialized
INFO - 2018-06-18 18:38:55 --> Router Class Initialized
INFO - 2018-06-18 18:38:55 --> Output Class Initialized
INFO - 2018-06-18 18:38:55 --> Security Class Initialized
DEBUG - 2018-06-18 18:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:38:55 --> CSRF cookie sent
INFO - 2018-06-18 18:38:55 --> Input Class Initialized
INFO - 2018-06-18 18:38:55 --> Language Class Initialized
INFO - 2018-06-18 18:38:55 --> Loader Class Initialized
INFO - 2018-06-18 18:38:55 --> Helper loaded: url_helper
INFO - 2018-06-18 18:38:55 --> Helper loaded: form_helper
INFO - 2018-06-18 18:38:55 --> Helper loaded: language_helper
DEBUG - 2018-06-18 18:38:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 18:38:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 18:38:55 --> User Agent Class Initialized
INFO - 2018-06-18 18:38:55 --> Controller Class Initialized
INFO - 2018-06-18 18:38:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-18 18:38:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-18 18:38:55 --> Pixel_Model class loaded
INFO - 2018-06-18 18:38:55 --> Database Driver Class Initialized
INFO - 2018-06-18 18:38:55 --> Model "MyAccountModel" initialized
INFO - 2018-06-18 18:38:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-18 18:38:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-18 18:38:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-18 18:38:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-18 18:38:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-18 18:38:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/application_list.php
INFO - 2018-06-18 18:38:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-18 18:38:55 --> Final output sent to browser
DEBUG - 2018-06-18 18:38:55 --> Total execution time: 0.0482
INFO - 2018-06-18 18:38:59 --> Config Class Initialized
INFO - 2018-06-18 18:38:59 --> Hooks Class Initialized
DEBUG - 2018-06-18 18:38:59 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:38:59 --> Utf8 Class Initialized
INFO - 2018-06-18 18:38:59 --> URI Class Initialized
INFO - 2018-06-18 18:38:59 --> Router Class Initialized
INFO - 2018-06-18 18:38:59 --> Output Class Initialized
INFO - 2018-06-18 18:38:59 --> Security Class Initialized
DEBUG - 2018-06-18 18:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:38:59 --> CSRF cookie sent
INFO - 2018-06-18 18:38:59 --> Input Class Initialized
INFO - 2018-06-18 18:38:59 --> Language Class Initialized
INFO - 2018-06-18 18:38:59 --> Loader Class Initialized
INFO - 2018-06-18 18:38:59 --> Helper loaded: url_helper
INFO - 2018-06-18 18:38:59 --> Helper loaded: form_helper
INFO - 2018-06-18 18:38:59 --> Helper loaded: language_helper
DEBUG - 2018-06-18 18:38:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 18:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 18:38:59 --> User Agent Class Initialized
INFO - 2018-06-18 18:38:59 --> Controller Class Initialized
INFO - 2018-06-18 18:38:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-18 18:38:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-18 18:38:59 --> Pixel_Model class loaded
INFO - 2018-06-18 18:38:59 --> Database Driver Class Initialized
INFO - 2018-06-18 18:38:59 --> Model "MyAccountModel" initialized
INFO - 2018-06-18 18:38:59 --> Config Class Initialized
INFO - 2018-06-18 18:38:59 --> Hooks Class Initialized
DEBUG - 2018-06-18 18:38:59 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:38:59 --> Utf8 Class Initialized
INFO - 2018-06-18 18:38:59 --> URI Class Initialized
DEBUG - 2018-06-18 18:38:59 --> No URI present. Default controller set.
INFO - 2018-06-18 18:38:59 --> Router Class Initialized
INFO - 2018-06-18 18:38:59 --> Output Class Initialized
INFO - 2018-06-18 18:38:59 --> Security Class Initialized
DEBUG - 2018-06-18 18:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:38:59 --> CSRF cookie sent
INFO - 2018-06-18 18:38:59 --> Input Class Initialized
INFO - 2018-06-18 18:38:59 --> Language Class Initialized
INFO - 2018-06-18 18:39:00 --> Loader Class Initialized
INFO - 2018-06-18 18:39:00 --> Helper loaded: url_helper
INFO - 2018-06-18 18:39:00 --> Helper loaded: form_helper
INFO - 2018-06-18 18:39:00 --> Helper loaded: language_helper
DEBUG - 2018-06-18 18:39:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 18:39:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 18:39:00 --> User Agent Class Initialized
INFO - 2018-06-18 18:39:00 --> Controller Class Initialized
INFO - 2018-06-18 18:39:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-18 18:39:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-18 18:39:00 --> Pixel_Model class loaded
INFO - 2018-06-18 18:39:00 --> Database Driver Class Initialized
INFO - 2018-06-18 18:39:00 --> Model "QuestionsModel" initialized
INFO - 2018-06-18 18:39:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-18 18:39:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-18 18:39:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-18 18:39:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-18 18:39:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-18 18:39:00 --> Final output sent to browser
DEBUG - 2018-06-18 18:39:00 --> Total execution time: 0.0760
INFO - 2018-06-18 18:39:02 --> Config Class Initialized
INFO - 2018-06-18 18:39:02 --> Hooks Class Initialized
DEBUG - 2018-06-18 18:39:02 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:39:02 --> Utf8 Class Initialized
INFO - 2018-06-18 18:39:02 --> URI Class Initialized
INFO - 2018-06-18 18:39:02 --> Router Class Initialized
INFO - 2018-06-18 18:39:02 --> Output Class Initialized
INFO - 2018-06-18 18:39:02 --> Security Class Initialized
DEBUG - 2018-06-18 18:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:39:02 --> CSRF cookie sent
INFO - 2018-06-18 18:39:02 --> Input Class Initialized
INFO - 2018-06-18 18:39:02 --> Language Class Initialized
INFO - 2018-06-18 18:39:02 --> Loader Class Initialized
INFO - 2018-06-18 18:39:02 --> Helper loaded: url_helper
INFO - 2018-06-18 18:39:02 --> Helper loaded: form_helper
INFO - 2018-06-18 18:39:02 --> Helper loaded: language_helper
DEBUG - 2018-06-18 18:39:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 18:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 18:39:02 --> User Agent Class Initialized
INFO - 2018-06-18 18:39:02 --> Controller Class Initialized
INFO - 2018-06-18 18:39:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-18 18:39:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-18 18:39:02 --> Pixel_Model class loaded
INFO - 2018-06-18 18:39:02 --> Database Driver Class Initialized
INFO - 2018-06-18 18:39:02 --> Model "QuestionsModel" initialized
INFO - 2018-06-18 18:39:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-18 18:39:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-18 18:39:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-18 18:39:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-18 18:39:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-18 18:39:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-18 18:39:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-18 18:39:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-06-18 18:39:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-18 18:39:02 --> Final output sent to browser
DEBUG - 2018-06-18 18:39:02 --> Total execution time: 0.0486
INFO - 2018-06-18 18:39:19 --> Config Class Initialized
INFO - 2018-06-18 18:39:19 --> Hooks Class Initialized
DEBUG - 2018-06-18 18:39:19 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:39:19 --> Utf8 Class Initialized
INFO - 2018-06-18 18:39:19 --> URI Class Initialized
INFO - 2018-06-18 18:39:19 --> Router Class Initialized
INFO - 2018-06-18 18:39:19 --> Output Class Initialized
INFO - 2018-06-18 18:39:19 --> Security Class Initialized
DEBUG - 2018-06-18 18:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:39:19 --> CSRF cookie sent
INFO - 2018-06-18 18:39:19 --> CSRF token verified
INFO - 2018-06-18 18:39:19 --> Input Class Initialized
INFO - 2018-06-18 18:39:19 --> Language Class Initialized
INFO - 2018-06-18 18:39:19 --> Loader Class Initialized
INFO - 2018-06-18 18:39:19 --> Helper loaded: url_helper
INFO - 2018-06-18 18:39:19 --> Helper loaded: form_helper
INFO - 2018-06-18 18:39:19 --> Helper loaded: language_helper
DEBUG - 2018-06-18 18:39:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 18:39:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 18:39:19 --> User Agent Class Initialized
INFO - 2018-06-18 18:39:19 --> Controller Class Initialized
INFO - 2018-06-18 18:39:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-18 18:39:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-18 18:39:19 --> Pixel_Model class loaded
INFO - 2018-06-18 18:39:19 --> Database Driver Class Initialized
INFO - 2018-06-18 18:39:19 --> Model "QuestionsModel" initialized
INFO - 2018-06-18 18:39:19 --> Form Validation Class Initialized
INFO - 2018-06-18 18:39:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-18 18:39:19 --> Config Class Initialized
INFO - 2018-06-18 18:39:19 --> Hooks Class Initialized
DEBUG - 2018-06-18 18:39:19 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:39:19 --> Utf8 Class Initialized
INFO - 2018-06-18 18:39:19 --> URI Class Initialized
INFO - 2018-06-18 18:39:19 --> Router Class Initialized
INFO - 2018-06-18 18:39:19 --> Output Class Initialized
INFO - 2018-06-18 18:39:19 --> Security Class Initialized
DEBUG - 2018-06-18 18:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:39:19 --> CSRF cookie sent
INFO - 2018-06-18 18:39:19 --> Input Class Initialized
INFO - 2018-06-18 18:39:19 --> Language Class Initialized
INFO - 2018-06-18 18:39:19 --> Loader Class Initialized
INFO - 2018-06-18 18:39:19 --> Helper loaded: url_helper
INFO - 2018-06-18 18:39:19 --> Helper loaded: form_helper
INFO - 2018-06-18 18:39:19 --> Helper loaded: language_helper
DEBUG - 2018-06-18 18:39:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 18:39:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 18:39:19 --> User Agent Class Initialized
INFO - 2018-06-18 18:39:19 --> Controller Class Initialized
INFO - 2018-06-18 18:39:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-18 18:39:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-18 18:39:19 --> Pixel_Model class loaded
INFO - 2018-06-18 18:39:19 --> Database Driver Class Initialized
INFO - 2018-06-18 18:39:19 --> Model "QuestionsModel" initialized
INFO - 2018-06-18 18:39:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-18 18:39:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-18 18:39:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-18 18:39:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-06-18 18:39:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-18 18:39:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-18 18:39:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-18 18:39:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-18 18:39:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-06-18 18:39:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-18 18:39:19 --> Final output sent to browser
DEBUG - 2018-06-18 18:39:19 --> Total execution time: 0.0495
INFO - 2018-06-18 18:39:22 --> Config Class Initialized
INFO - 2018-06-18 18:39:22 --> Hooks Class Initialized
DEBUG - 2018-06-18 18:39:22 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:39:22 --> Utf8 Class Initialized
INFO - 2018-06-18 18:39:22 --> URI Class Initialized
INFO - 2018-06-18 18:39:22 --> Router Class Initialized
INFO - 2018-06-18 18:39:22 --> Output Class Initialized
INFO - 2018-06-18 18:39:22 --> Security Class Initialized
DEBUG - 2018-06-18 18:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:39:22 --> CSRF cookie sent
INFO - 2018-06-18 18:39:22 --> CSRF token verified
INFO - 2018-06-18 18:39:22 --> Input Class Initialized
INFO - 2018-06-18 18:39:22 --> Language Class Initialized
INFO - 2018-06-18 18:39:22 --> Loader Class Initialized
INFO - 2018-06-18 18:39:22 --> Helper loaded: url_helper
INFO - 2018-06-18 18:39:22 --> Helper loaded: form_helper
INFO - 2018-06-18 18:39:22 --> Helper loaded: language_helper
DEBUG - 2018-06-18 18:39:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 18:39:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 18:39:22 --> User Agent Class Initialized
INFO - 2018-06-18 18:39:22 --> Controller Class Initialized
INFO - 2018-06-18 18:39:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-18 18:39:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-18 18:39:22 --> Pixel_Model class loaded
INFO - 2018-06-18 18:39:22 --> Database Driver Class Initialized
INFO - 2018-06-18 18:39:22 --> Model "QuestionsModel" initialized
INFO - 2018-06-18 18:39:22 --> Form Validation Class Initialized
INFO - 2018-06-18 18:39:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-18 18:39:22 --> Config Class Initialized
INFO - 2018-06-18 18:39:22 --> Hooks Class Initialized
DEBUG - 2018-06-18 18:39:22 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:39:22 --> Utf8 Class Initialized
INFO - 2018-06-18 18:39:22 --> URI Class Initialized
INFO - 2018-06-18 18:39:22 --> Router Class Initialized
INFO - 2018-06-18 18:39:22 --> Output Class Initialized
INFO - 2018-06-18 18:39:22 --> Security Class Initialized
DEBUG - 2018-06-18 18:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:39:22 --> CSRF cookie sent
INFO - 2018-06-18 18:39:22 --> Input Class Initialized
INFO - 2018-06-18 18:39:22 --> Language Class Initialized
INFO - 2018-06-18 18:39:22 --> Loader Class Initialized
INFO - 2018-06-18 18:39:22 --> Helper loaded: url_helper
INFO - 2018-06-18 18:39:22 --> Helper loaded: form_helper
INFO - 2018-06-18 18:39:22 --> Helper loaded: language_helper
DEBUG - 2018-06-18 18:39:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 18:39:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 18:39:22 --> User Agent Class Initialized
INFO - 2018-06-18 18:39:22 --> Controller Class Initialized
INFO - 2018-06-18 18:39:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-18 18:39:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-18 18:39:22 --> Pixel_Model class loaded
INFO - 2018-06-18 18:39:22 --> Database Driver Class Initialized
INFO - 2018-06-18 18:39:22 --> Model "QuestionsModel" initialized
INFO - 2018-06-18 18:39:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-18 18:39:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-18 18:39:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-18 18:39:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-18 18:39:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-18 18:39:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-18 18:39:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-18 18:39:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-06-18 18:39:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-18 18:39:22 --> Final output sent to browser
DEBUG - 2018-06-18 18:39:22 --> Total execution time: 0.0460
INFO - 2018-06-18 18:39:24 --> Config Class Initialized
INFO - 2018-06-18 18:39:24 --> Hooks Class Initialized
DEBUG - 2018-06-18 18:39:24 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:39:24 --> Utf8 Class Initialized
INFO - 2018-06-18 18:39:24 --> URI Class Initialized
INFO - 2018-06-18 18:39:24 --> Router Class Initialized
INFO - 2018-06-18 18:39:24 --> Output Class Initialized
INFO - 2018-06-18 18:39:24 --> Security Class Initialized
DEBUG - 2018-06-18 18:39:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:39:24 --> CSRF cookie sent
INFO - 2018-06-18 18:39:24 --> CSRF token verified
INFO - 2018-06-18 18:39:24 --> Input Class Initialized
INFO - 2018-06-18 18:39:24 --> Language Class Initialized
INFO - 2018-06-18 18:39:24 --> Loader Class Initialized
INFO - 2018-06-18 18:39:24 --> Helper loaded: url_helper
INFO - 2018-06-18 18:39:24 --> Helper loaded: form_helper
INFO - 2018-06-18 18:39:24 --> Helper loaded: language_helper
DEBUG - 2018-06-18 18:39:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 18:39:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 18:39:24 --> User Agent Class Initialized
INFO - 2018-06-18 18:39:24 --> Controller Class Initialized
INFO - 2018-06-18 18:39:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-18 18:39:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-18 18:39:24 --> Pixel_Model class loaded
INFO - 2018-06-18 18:39:24 --> Database Driver Class Initialized
INFO - 2018-06-18 18:39:24 --> Model "QuestionsModel" initialized
INFO - 2018-06-18 18:39:24 --> Form Validation Class Initialized
INFO - 2018-06-18 18:39:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-18 18:39:24 --> Database Driver Class Initialized
INFO - 2018-06-18 18:39:24 --> Model "QuestionsModel" initialized
INFO - 2018-06-18 18:39:24 --> Config Class Initialized
INFO - 2018-06-18 18:39:24 --> Hooks Class Initialized
DEBUG - 2018-06-18 18:39:24 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:39:24 --> Utf8 Class Initialized
INFO - 2018-06-18 18:39:24 --> URI Class Initialized
INFO - 2018-06-18 18:39:24 --> Router Class Initialized
INFO - 2018-06-18 18:39:24 --> Output Class Initialized
INFO - 2018-06-18 18:39:24 --> Security Class Initialized
DEBUG - 2018-06-18 18:39:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:39:24 --> CSRF cookie sent
INFO - 2018-06-18 18:39:24 --> Input Class Initialized
INFO - 2018-06-18 18:39:24 --> Language Class Initialized
INFO - 2018-06-18 18:39:24 --> Loader Class Initialized
INFO - 2018-06-18 18:39:24 --> Helper loaded: url_helper
INFO - 2018-06-18 18:39:24 --> Helper loaded: form_helper
INFO - 2018-06-18 18:39:24 --> Helper loaded: language_helper
DEBUG - 2018-06-18 18:39:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 18:39:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 18:39:24 --> User Agent Class Initialized
INFO - 2018-06-18 18:39:24 --> Controller Class Initialized
INFO - 2018-06-18 18:39:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-18 18:39:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-18 18:39:24 --> Pixel_Model class loaded
INFO - 2018-06-18 18:39:24 --> Database Driver Class Initialized
INFO - 2018-06-18 18:39:24 --> Model "QuestionsModel" initialized
INFO - 2018-06-18 18:39:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-18 18:39:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-18 18:39:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-18 18:39:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-18 18:39:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-18 18:39:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-18 18:39:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-18 18:39:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/marriage.php
INFO - 2018-06-18 18:39:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-18 18:39:24 --> Final output sent to browser
DEBUG - 2018-06-18 18:39:24 --> Total execution time: 0.0716
INFO - 2018-06-18 18:39:32 --> Config Class Initialized
INFO - 2018-06-18 18:39:32 --> Hooks Class Initialized
DEBUG - 2018-06-18 18:39:32 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:39:32 --> Utf8 Class Initialized
INFO - 2018-06-18 18:39:32 --> URI Class Initialized
INFO - 2018-06-18 18:39:32 --> Router Class Initialized
INFO - 2018-06-18 18:39:32 --> Output Class Initialized
INFO - 2018-06-18 18:39:32 --> Security Class Initialized
DEBUG - 2018-06-18 18:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:39:32 --> CSRF cookie sent
INFO - 2018-06-18 18:39:32 --> Input Class Initialized
INFO - 2018-06-18 18:39:32 --> Language Class Initialized
INFO - 2018-06-18 18:39:32 --> Loader Class Initialized
INFO - 2018-06-18 18:39:32 --> Helper loaded: url_helper
INFO - 2018-06-18 18:39:32 --> Helper loaded: form_helper
INFO - 2018-06-18 18:39:32 --> Helper loaded: language_helper
DEBUG - 2018-06-18 18:39:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 18:39:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 18:39:32 --> User Agent Class Initialized
INFO - 2018-06-18 18:39:32 --> Controller Class Initialized
INFO - 2018-06-18 18:39:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-18 18:39:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-18 18:39:32 --> Pixel_Model class loaded
INFO - 2018-06-18 18:39:32 --> Database Driver Class Initialized
INFO - 2018-06-18 18:39:32 --> Model "MyAccountModel" initialized
INFO - 2018-06-18 18:39:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-18 18:39:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-18 18:39:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-18 18:39:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-18 18:39:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-18 18:39:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/application_list.php
INFO - 2018-06-18 18:39:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-18 18:39:32 --> Final output sent to browser
DEBUG - 2018-06-18 18:39:32 --> Total execution time: 0.0669
INFO - 2018-06-18 18:39:34 --> Config Class Initialized
INFO - 2018-06-18 18:39:34 --> Hooks Class Initialized
DEBUG - 2018-06-18 18:39:34 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:39:34 --> Utf8 Class Initialized
INFO - 2018-06-18 18:39:34 --> URI Class Initialized
INFO - 2018-06-18 18:39:34 --> Router Class Initialized
INFO - 2018-06-18 18:39:34 --> Output Class Initialized
INFO - 2018-06-18 18:39:34 --> Security Class Initialized
DEBUG - 2018-06-18 18:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:39:34 --> CSRF cookie sent
INFO - 2018-06-18 18:39:34 --> Input Class Initialized
INFO - 2018-06-18 18:39:34 --> Language Class Initialized
INFO - 2018-06-18 18:39:34 --> Loader Class Initialized
INFO - 2018-06-18 18:39:34 --> Helper loaded: url_helper
INFO - 2018-06-18 18:39:34 --> Helper loaded: form_helper
INFO - 2018-06-18 18:39:34 --> Helper loaded: language_helper
DEBUG - 2018-06-18 18:39:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 18:39:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 18:39:34 --> User Agent Class Initialized
INFO - 2018-06-18 18:39:34 --> Controller Class Initialized
INFO - 2018-06-18 18:39:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-18 18:39:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-18 18:39:34 --> Pixel_Model class loaded
INFO - 2018-06-18 18:39:34 --> Database Driver Class Initialized
INFO - 2018-06-18 18:39:34 --> Model "MyAccountModel" initialized
INFO - 2018-06-18 18:39:35 --> Config Class Initialized
INFO - 2018-06-18 18:39:35 --> Hooks Class Initialized
DEBUG - 2018-06-18 18:39:35 --> UTF-8 Support Enabled
INFO - 2018-06-18 18:39:35 --> Utf8 Class Initialized
INFO - 2018-06-18 18:39:35 --> URI Class Initialized
INFO - 2018-06-18 18:39:35 --> Router Class Initialized
INFO - 2018-06-18 18:39:35 --> Output Class Initialized
INFO - 2018-06-18 18:39:35 --> Security Class Initialized
DEBUG - 2018-06-18 18:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 18:39:35 --> CSRF cookie sent
INFO - 2018-06-18 18:39:35 --> Input Class Initialized
INFO - 2018-06-18 18:39:35 --> Language Class Initialized
INFO - 2018-06-18 18:39:35 --> Loader Class Initialized
INFO - 2018-06-18 18:39:35 --> Helper loaded: url_helper
INFO - 2018-06-18 18:39:35 --> Helper loaded: form_helper
INFO - 2018-06-18 18:39:35 --> Helper loaded: language_helper
DEBUG - 2018-06-18 18:39:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 18:39:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 18:39:35 --> User Agent Class Initialized
INFO - 2018-06-18 18:39:35 --> Controller Class Initialized
INFO - 2018-06-18 18:39:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-18 18:39:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-18 18:39:35 --> Pixel_Model class loaded
INFO - 2018-06-18 18:39:35 --> Database Driver Class Initialized
INFO - 2018-06-18 18:39:35 --> Model "QuestionsModel" initialized
INFO - 2018-06-18 18:39:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-18 18:39:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-18 18:39:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-18 18:39:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-18 18:39:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-18 18:39:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-18 18:39:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-18 18:39:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/marriage.php
INFO - 2018-06-18 18:39:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-18 18:39:35 --> Final output sent to browser
DEBUG - 2018-06-18 18:39:35 --> Total execution time: 0.0420
INFO - 2018-06-18 20:51:35 --> Config Class Initialized
INFO - 2018-06-18 20:51:35 --> Hooks Class Initialized
DEBUG - 2018-06-18 20:51:35 --> UTF-8 Support Enabled
INFO - 2018-06-18 20:51:35 --> Utf8 Class Initialized
INFO - 2018-06-18 20:51:35 --> URI Class Initialized
DEBUG - 2018-06-18 20:51:35 --> No URI present. Default controller set.
INFO - 2018-06-18 20:51:35 --> Router Class Initialized
INFO - 2018-06-18 20:51:35 --> Output Class Initialized
INFO - 2018-06-18 20:51:35 --> Security Class Initialized
DEBUG - 2018-06-18 20:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 20:51:35 --> CSRF cookie sent
INFO - 2018-06-18 20:51:35 --> Input Class Initialized
INFO - 2018-06-18 20:51:35 --> Language Class Initialized
INFO - 2018-06-18 20:51:35 --> Loader Class Initialized
INFO - 2018-06-18 20:51:35 --> Helper loaded: url_helper
INFO - 2018-06-18 20:51:35 --> Helper loaded: form_helper
INFO - 2018-06-18 20:51:35 --> Helper loaded: language_helper
DEBUG - 2018-06-18 20:51:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 20:51:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 20:51:35 --> User Agent Class Initialized
INFO - 2018-06-18 20:51:35 --> Controller Class Initialized
INFO - 2018-06-18 20:51:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-18 20:51:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-18 20:51:35 --> Pixel_Model class loaded
INFO - 2018-06-18 20:51:35 --> Database Driver Class Initialized
INFO - 2018-06-18 20:51:35 --> Model "QuestionsModel" initialized
INFO - 2018-06-18 20:51:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-18 20:51:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-18 20:51:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-18 20:51:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-18 20:51:36 --> Final output sent to browser
DEBUG - 2018-06-18 20:51:36 --> Total execution time: 0.0596
INFO - 2018-06-18 22:15:28 --> Config Class Initialized
INFO - 2018-06-18 22:15:28 --> Hooks Class Initialized
DEBUG - 2018-06-18 22:15:28 --> UTF-8 Support Enabled
INFO - 2018-06-18 22:15:28 --> Utf8 Class Initialized
INFO - 2018-06-18 22:15:28 --> URI Class Initialized
DEBUG - 2018-06-18 22:15:28 --> No URI present. Default controller set.
INFO - 2018-06-18 22:15:28 --> Router Class Initialized
INFO - 2018-06-18 22:15:28 --> Output Class Initialized
INFO - 2018-06-18 22:15:28 --> Security Class Initialized
DEBUG - 2018-06-18 22:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 22:15:28 --> CSRF cookie sent
INFO - 2018-06-18 22:15:28 --> Input Class Initialized
INFO - 2018-06-18 22:15:28 --> Language Class Initialized
INFO - 2018-06-18 22:15:28 --> Loader Class Initialized
INFO - 2018-06-18 22:15:28 --> Helper loaded: url_helper
INFO - 2018-06-18 22:15:28 --> Helper loaded: form_helper
INFO - 2018-06-18 22:15:28 --> Helper loaded: language_helper
DEBUG - 2018-06-18 22:15:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 22:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 22:15:28 --> User Agent Class Initialized
INFO - 2018-06-18 22:15:28 --> Controller Class Initialized
INFO - 2018-06-18 22:15:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-18 22:15:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-18 22:15:28 --> Pixel_Model class loaded
INFO - 2018-06-18 22:15:28 --> Database Driver Class Initialized
INFO - 2018-06-18 22:15:28 --> Model "QuestionsModel" initialized
INFO - 2018-06-18 22:15:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-18 22:15:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-18 22:15:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-18 22:15:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-18 22:15:28 --> Final output sent to browser
DEBUG - 2018-06-18 22:15:28 --> Total execution time: 0.0722
INFO - 2018-06-18 22:49:47 --> Config Class Initialized
INFO - 2018-06-18 22:49:47 --> Hooks Class Initialized
DEBUG - 2018-06-18 22:49:48 --> UTF-8 Support Enabled
INFO - 2018-06-18 22:49:48 --> Utf8 Class Initialized
INFO - 2018-06-18 22:49:48 --> URI Class Initialized
DEBUG - 2018-06-18 22:49:48 --> No URI present. Default controller set.
INFO - 2018-06-18 22:49:48 --> Router Class Initialized
INFO - 2018-06-18 22:49:48 --> Output Class Initialized
INFO - 2018-06-18 22:49:48 --> Security Class Initialized
DEBUG - 2018-06-18 22:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 22:49:48 --> CSRF cookie sent
INFO - 2018-06-18 22:49:48 --> Input Class Initialized
INFO - 2018-06-18 22:49:48 --> Language Class Initialized
INFO - 2018-06-18 22:49:48 --> Loader Class Initialized
INFO - 2018-06-18 22:49:48 --> Helper loaded: url_helper
INFO - 2018-06-18 22:49:48 --> Helper loaded: form_helper
INFO - 2018-06-18 22:49:48 --> Helper loaded: language_helper
DEBUG - 2018-06-18 22:49:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 22:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 22:49:48 --> User Agent Class Initialized
INFO - 2018-06-18 22:49:48 --> Controller Class Initialized
INFO - 2018-06-18 22:49:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-18 22:49:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-18 22:49:48 --> Pixel_Model class loaded
INFO - 2018-06-18 22:49:48 --> Database Driver Class Initialized
INFO - 2018-06-18 22:49:48 --> Model "QuestionsModel" initialized
INFO - 2018-06-18 22:49:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-18 22:49:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-18 22:49:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-18 22:49:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-18 22:49:48 --> Final output sent to browser
DEBUG - 2018-06-18 22:49:48 --> Total execution time: 0.1525
INFO - 2018-06-18 23:09:03 --> Config Class Initialized
INFO - 2018-06-18 23:09:03 --> Hooks Class Initialized
DEBUG - 2018-06-18 23:09:03 --> UTF-8 Support Enabled
INFO - 2018-06-18 23:09:03 --> Utf8 Class Initialized
INFO - 2018-06-18 23:09:03 --> URI Class Initialized
DEBUG - 2018-06-18 23:09:03 --> No URI present. Default controller set.
INFO - 2018-06-18 23:09:03 --> Router Class Initialized
INFO - 2018-06-18 23:09:03 --> Output Class Initialized
INFO - 2018-06-18 23:09:03 --> Security Class Initialized
DEBUG - 2018-06-18 23:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 23:09:03 --> CSRF cookie sent
INFO - 2018-06-18 23:09:03 --> Input Class Initialized
INFO - 2018-06-18 23:09:03 --> Language Class Initialized
INFO - 2018-06-18 23:09:03 --> Loader Class Initialized
INFO - 2018-06-18 23:09:03 --> Helper loaded: url_helper
INFO - 2018-06-18 23:09:03 --> Helper loaded: form_helper
INFO - 2018-06-18 23:09:03 --> Helper loaded: language_helper
DEBUG - 2018-06-18 23:09:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 23:09:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 23:09:03 --> User Agent Class Initialized
INFO - 2018-06-18 23:09:03 --> Controller Class Initialized
INFO - 2018-06-18 23:09:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-18 23:09:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-18 23:09:03 --> Pixel_Model class loaded
INFO - 2018-06-18 23:09:03 --> Database Driver Class Initialized
INFO - 2018-06-18 23:09:03 --> Model "QuestionsModel" initialized
INFO - 2018-06-18 23:09:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-18 23:09:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-18 23:09:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-18 23:09:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-18 23:09:03 --> Final output sent to browser
DEBUG - 2018-06-18 23:09:03 --> Total execution time: 0.0604
INFO - 2018-06-18 23:21:12 --> Config Class Initialized
INFO - 2018-06-18 23:21:12 --> Hooks Class Initialized
DEBUG - 2018-06-18 23:21:12 --> UTF-8 Support Enabled
INFO - 2018-06-18 23:21:12 --> Utf8 Class Initialized
INFO - 2018-06-18 23:21:12 --> URI Class Initialized
DEBUG - 2018-06-18 23:21:12 --> No URI present. Default controller set.
INFO - 2018-06-18 23:21:12 --> Router Class Initialized
INFO - 2018-06-18 23:21:12 --> Output Class Initialized
INFO - 2018-06-18 23:21:12 --> Security Class Initialized
DEBUG - 2018-06-18 23:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 23:21:12 --> CSRF cookie sent
INFO - 2018-06-18 23:21:12 --> Input Class Initialized
INFO - 2018-06-18 23:21:12 --> Language Class Initialized
INFO - 2018-06-18 23:21:12 --> Loader Class Initialized
INFO - 2018-06-18 23:21:12 --> Helper loaded: url_helper
INFO - 2018-06-18 23:21:12 --> Helper loaded: form_helper
INFO - 2018-06-18 23:21:12 --> Helper loaded: language_helper
DEBUG - 2018-06-18 23:21:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 23:21:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 23:21:12 --> User Agent Class Initialized
INFO - 2018-06-18 23:21:12 --> Controller Class Initialized
INFO - 2018-06-18 23:21:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-18 23:21:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-18 23:21:12 --> Pixel_Model class loaded
INFO - 2018-06-18 23:21:12 --> Database Driver Class Initialized
INFO - 2018-06-18 23:21:12 --> Model "QuestionsModel" initialized
INFO - 2018-06-18 23:21:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-18 23:21:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-18 23:21:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-18 23:21:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-18 23:21:13 --> Final output sent to browser
DEBUG - 2018-06-18 23:21:13 --> Total execution time: 0.1496

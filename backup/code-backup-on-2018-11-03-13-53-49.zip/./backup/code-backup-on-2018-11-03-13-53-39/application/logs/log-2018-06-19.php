<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-06-19 02:16:26 --> Config Class Initialized
INFO - 2018-06-19 02:16:26 --> Hooks Class Initialized
DEBUG - 2018-06-19 02:16:26 --> UTF-8 Support Enabled
INFO - 2018-06-19 02:16:26 --> Utf8 Class Initialized
INFO - 2018-06-19 02:16:26 --> URI Class Initialized
DEBUG - 2018-06-19 02:16:26 --> No URI present. Default controller set.
INFO - 2018-06-19 02:16:26 --> Router Class Initialized
INFO - 2018-06-19 02:16:26 --> Output Class Initialized
INFO - 2018-06-19 02:16:26 --> Security Class Initialized
DEBUG - 2018-06-19 02:16:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 02:16:26 --> CSRF cookie sent
INFO - 2018-06-19 02:16:26 --> Input Class Initialized
INFO - 2018-06-19 02:16:26 --> Language Class Initialized
INFO - 2018-06-19 02:16:26 --> Loader Class Initialized
INFO - 2018-06-19 02:16:26 --> Helper loaded: url_helper
INFO - 2018-06-19 02:16:26 --> Helper loaded: form_helper
INFO - 2018-06-19 02:16:26 --> Helper loaded: language_helper
DEBUG - 2018-06-19 02:16:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 02:16:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 02:16:26 --> User Agent Class Initialized
INFO - 2018-06-19 02:16:26 --> Controller Class Initialized
INFO - 2018-06-19 02:16:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 02:16:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 02:16:26 --> Pixel_Model class loaded
INFO - 2018-06-19 02:16:26 --> Database Driver Class Initialized
INFO - 2018-06-19 02:16:26 --> Model "QuestionsModel" initialized
INFO - 2018-06-19 02:16:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 02:16:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 02:16:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-19 02:16:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 02:16:26 --> Final output sent to browser
DEBUG - 2018-06-19 02:16:26 --> Total execution time: 0.0625
INFO - 2018-06-19 02:41:51 --> Config Class Initialized
INFO - 2018-06-19 02:41:51 --> Hooks Class Initialized
DEBUG - 2018-06-19 02:41:51 --> UTF-8 Support Enabled
INFO - 2018-06-19 02:41:51 --> Utf8 Class Initialized
INFO - 2018-06-19 02:41:51 --> URI Class Initialized
DEBUG - 2018-06-19 02:41:51 --> No URI present. Default controller set.
INFO - 2018-06-19 02:41:51 --> Router Class Initialized
INFO - 2018-06-19 02:41:51 --> Output Class Initialized
INFO - 2018-06-19 02:41:51 --> Security Class Initialized
DEBUG - 2018-06-19 02:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 02:41:51 --> CSRF cookie sent
INFO - 2018-06-19 02:41:51 --> Input Class Initialized
INFO - 2018-06-19 02:41:51 --> Language Class Initialized
INFO - 2018-06-19 02:41:51 --> Loader Class Initialized
INFO - 2018-06-19 02:41:51 --> Helper loaded: url_helper
INFO - 2018-06-19 02:41:51 --> Helper loaded: form_helper
INFO - 2018-06-19 02:41:51 --> Helper loaded: language_helper
DEBUG - 2018-06-19 02:41:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 02:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 02:41:51 --> User Agent Class Initialized
INFO - 2018-06-19 02:41:51 --> Controller Class Initialized
INFO - 2018-06-19 02:41:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 02:41:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 02:41:51 --> Pixel_Model class loaded
INFO - 2018-06-19 02:41:51 --> Database Driver Class Initialized
INFO - 2018-06-19 02:41:51 --> Model "QuestionsModel" initialized
INFO - 2018-06-19 02:41:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 02:41:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 02:41:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-19 02:41:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 02:41:51 --> Final output sent to browser
DEBUG - 2018-06-19 02:41:51 --> Total execution time: 0.0575
INFO - 2018-06-19 02:41:54 --> Config Class Initialized
INFO - 2018-06-19 02:41:54 --> Hooks Class Initialized
DEBUG - 2018-06-19 02:41:54 --> UTF-8 Support Enabled
INFO - 2018-06-19 02:41:54 --> Utf8 Class Initialized
INFO - 2018-06-19 02:41:54 --> URI Class Initialized
INFO - 2018-06-19 02:41:54 --> Router Class Initialized
INFO - 2018-06-19 02:41:54 --> Output Class Initialized
INFO - 2018-06-19 02:41:54 --> Security Class Initialized
DEBUG - 2018-06-19 02:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 02:41:54 --> CSRF cookie sent
INFO - 2018-06-19 02:41:54 --> Input Class Initialized
INFO - 2018-06-19 02:41:54 --> Language Class Initialized
INFO - 2018-06-19 02:41:54 --> Loader Class Initialized
INFO - 2018-06-19 02:41:54 --> Helper loaded: url_helper
INFO - 2018-06-19 02:41:54 --> Helper loaded: form_helper
INFO - 2018-06-19 02:41:54 --> Helper loaded: language_helper
DEBUG - 2018-06-19 02:41:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 02:41:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 02:41:54 --> User Agent Class Initialized
INFO - 2018-06-19 02:41:54 --> Controller Class Initialized
INFO - 2018-06-19 02:41:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 02:41:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 02:41:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 02:41:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 02:41:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-19 02:41:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-19 02:41:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-06-19 02:41:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 02:41:54 --> Final output sent to browser
DEBUG - 2018-06-19 02:41:54 --> Total execution time: 0.0405
INFO - 2018-06-19 02:41:56 --> Config Class Initialized
INFO - 2018-06-19 02:41:56 --> Hooks Class Initialized
DEBUG - 2018-06-19 02:41:56 --> UTF-8 Support Enabled
INFO - 2018-06-19 02:41:56 --> Utf8 Class Initialized
INFO - 2018-06-19 02:41:56 --> URI Class Initialized
INFO - 2018-06-19 02:41:56 --> Router Class Initialized
INFO - 2018-06-19 02:41:56 --> Output Class Initialized
INFO - 2018-06-19 02:41:56 --> Security Class Initialized
DEBUG - 2018-06-19 02:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 02:41:56 --> CSRF cookie sent
INFO - 2018-06-19 02:41:56 --> Input Class Initialized
INFO - 2018-06-19 02:41:56 --> Language Class Initialized
INFO - 2018-06-19 02:41:56 --> Loader Class Initialized
INFO - 2018-06-19 02:41:56 --> Helper loaded: url_helper
INFO - 2018-06-19 02:41:56 --> Helper loaded: form_helper
INFO - 2018-06-19 02:41:56 --> Helper loaded: language_helper
DEBUG - 2018-06-19 02:41:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 02:41:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 02:41:56 --> User Agent Class Initialized
INFO - 2018-06-19 02:41:56 --> Controller Class Initialized
INFO - 2018-06-19 02:41:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 02:41:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 02:41:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 02:41:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 02:41:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-19 02:41:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-19 02:41:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-06-19 02:41:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 02:41:56 --> Final output sent to browser
DEBUG - 2018-06-19 02:41:56 --> Total execution time: 0.0454
INFO - 2018-06-19 02:42:00 --> Config Class Initialized
INFO - 2018-06-19 02:42:00 --> Hooks Class Initialized
DEBUG - 2018-06-19 02:42:00 --> UTF-8 Support Enabled
INFO - 2018-06-19 02:42:00 --> Utf8 Class Initialized
INFO - 2018-06-19 02:42:00 --> URI Class Initialized
INFO - 2018-06-19 02:42:00 --> Router Class Initialized
INFO - 2018-06-19 02:42:00 --> Output Class Initialized
INFO - 2018-06-19 02:42:00 --> Security Class Initialized
DEBUG - 2018-06-19 02:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 02:42:00 --> CSRF cookie sent
INFO - 2018-06-19 02:42:00 --> Input Class Initialized
INFO - 2018-06-19 02:42:00 --> Language Class Initialized
INFO - 2018-06-19 02:42:00 --> Loader Class Initialized
INFO - 2018-06-19 02:42:00 --> Helper loaded: url_helper
INFO - 2018-06-19 02:42:00 --> Helper loaded: form_helper
INFO - 2018-06-19 02:42:00 --> Helper loaded: language_helper
DEBUG - 2018-06-19 02:42:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 02:42:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 02:42:00 --> User Agent Class Initialized
INFO - 2018-06-19 02:42:00 --> Controller Class Initialized
INFO - 2018-06-19 02:42:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 02:42:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 02:42:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 02:42:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 02:42:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-19 02:42:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-19 02:42:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-06-19 02:42:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 02:42:00 --> Final output sent to browser
DEBUG - 2018-06-19 02:42:00 --> Total execution time: 0.0409
INFO - 2018-06-19 02:42:44 --> Config Class Initialized
INFO - 2018-06-19 02:42:44 --> Hooks Class Initialized
DEBUG - 2018-06-19 02:42:44 --> UTF-8 Support Enabled
INFO - 2018-06-19 02:42:44 --> Utf8 Class Initialized
INFO - 2018-06-19 02:42:44 --> URI Class Initialized
DEBUG - 2018-06-19 02:42:44 --> No URI present. Default controller set.
INFO - 2018-06-19 02:42:44 --> Router Class Initialized
INFO - 2018-06-19 02:42:44 --> Output Class Initialized
INFO - 2018-06-19 02:42:44 --> Security Class Initialized
DEBUG - 2018-06-19 02:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 02:42:44 --> CSRF cookie sent
INFO - 2018-06-19 02:42:44 --> Input Class Initialized
INFO - 2018-06-19 02:42:44 --> Language Class Initialized
INFO - 2018-06-19 02:42:44 --> Loader Class Initialized
INFO - 2018-06-19 02:42:44 --> Helper loaded: url_helper
INFO - 2018-06-19 02:42:44 --> Helper loaded: form_helper
INFO - 2018-06-19 02:42:44 --> Helper loaded: language_helper
DEBUG - 2018-06-19 02:42:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 02:42:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 02:42:44 --> User Agent Class Initialized
INFO - 2018-06-19 02:42:44 --> Controller Class Initialized
INFO - 2018-06-19 02:42:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 02:42:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 02:42:44 --> Pixel_Model class loaded
INFO - 2018-06-19 02:42:44 --> Database Driver Class Initialized
INFO - 2018-06-19 02:42:44 --> Model "QuestionsModel" initialized
INFO - 2018-06-19 02:42:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 02:42:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 02:42:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-19 02:42:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 02:42:44 --> Final output sent to browser
DEBUG - 2018-06-19 02:42:44 --> Total execution time: 0.0652
INFO - 2018-06-19 02:44:23 --> Config Class Initialized
INFO - 2018-06-19 02:44:23 --> Hooks Class Initialized
DEBUG - 2018-06-19 02:44:23 --> UTF-8 Support Enabled
INFO - 2018-06-19 02:44:23 --> Utf8 Class Initialized
INFO - 2018-06-19 02:44:23 --> URI Class Initialized
DEBUG - 2018-06-19 02:44:23 --> No URI present. Default controller set.
INFO - 2018-06-19 02:44:23 --> Router Class Initialized
INFO - 2018-06-19 02:44:23 --> Output Class Initialized
INFO - 2018-06-19 02:44:23 --> Security Class Initialized
DEBUG - 2018-06-19 02:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 02:44:23 --> CSRF cookie sent
INFO - 2018-06-19 02:44:23 --> Input Class Initialized
INFO - 2018-06-19 02:44:23 --> Language Class Initialized
INFO - 2018-06-19 02:44:23 --> Loader Class Initialized
INFO - 2018-06-19 02:44:23 --> Helper loaded: url_helper
INFO - 2018-06-19 02:44:23 --> Helper loaded: form_helper
INFO - 2018-06-19 02:44:23 --> Helper loaded: language_helper
DEBUG - 2018-06-19 02:44:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 02:44:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 02:44:23 --> User Agent Class Initialized
INFO - 2018-06-19 02:44:23 --> Controller Class Initialized
INFO - 2018-06-19 02:44:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 02:44:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 02:44:23 --> Pixel_Model class loaded
INFO - 2018-06-19 02:44:23 --> Database Driver Class Initialized
INFO - 2018-06-19 02:44:23 --> Model "QuestionsModel" initialized
INFO - 2018-06-19 02:44:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 02:44:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 02:44:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-19 02:44:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 02:44:23 --> Final output sent to browser
DEBUG - 2018-06-19 02:44:23 --> Total execution time: 0.0485
INFO - 2018-06-19 02:44:35 --> Config Class Initialized
INFO - 2018-06-19 02:44:35 --> Hooks Class Initialized
DEBUG - 2018-06-19 02:44:35 --> UTF-8 Support Enabled
INFO - 2018-06-19 02:44:35 --> Utf8 Class Initialized
INFO - 2018-06-19 02:44:35 --> URI Class Initialized
INFO - 2018-06-19 02:44:35 --> Router Class Initialized
INFO - 2018-06-19 02:44:35 --> Output Class Initialized
INFO - 2018-06-19 02:44:35 --> Security Class Initialized
DEBUG - 2018-06-19 02:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 02:44:35 --> CSRF cookie sent
INFO - 2018-06-19 02:44:35 --> Input Class Initialized
INFO - 2018-06-19 02:44:35 --> Language Class Initialized
INFO - 2018-06-19 02:44:35 --> Loader Class Initialized
INFO - 2018-06-19 02:44:35 --> Helper loaded: url_helper
INFO - 2018-06-19 02:44:35 --> Helper loaded: form_helper
INFO - 2018-06-19 02:44:35 --> Helper loaded: language_helper
DEBUG - 2018-06-19 02:44:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 02:44:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 02:44:35 --> User Agent Class Initialized
INFO - 2018-06-19 02:44:35 --> Controller Class Initialized
INFO - 2018-06-19 02:44:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 02:44:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 02:44:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 02:44:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 02:44:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-19 02:44:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-19 02:44:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-06-19 02:44:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 02:44:35 --> Final output sent to browser
DEBUG - 2018-06-19 02:44:35 --> Total execution time: 0.0484
INFO - 2018-06-19 02:44:54 --> Config Class Initialized
INFO - 2018-06-19 02:44:54 --> Hooks Class Initialized
DEBUG - 2018-06-19 02:44:54 --> UTF-8 Support Enabled
INFO - 2018-06-19 02:44:54 --> Utf8 Class Initialized
INFO - 2018-06-19 02:44:54 --> URI Class Initialized
INFO - 2018-06-19 02:44:54 --> Router Class Initialized
INFO - 2018-06-19 02:44:54 --> Output Class Initialized
INFO - 2018-06-19 02:44:54 --> Security Class Initialized
DEBUG - 2018-06-19 02:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 02:44:54 --> CSRF cookie sent
INFO - 2018-06-19 02:44:54 --> Input Class Initialized
INFO - 2018-06-19 02:44:54 --> Language Class Initialized
INFO - 2018-06-19 02:44:54 --> Loader Class Initialized
INFO - 2018-06-19 02:44:54 --> Helper loaded: url_helper
INFO - 2018-06-19 02:44:54 --> Helper loaded: form_helper
INFO - 2018-06-19 02:44:54 --> Helper loaded: language_helper
DEBUG - 2018-06-19 02:44:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 02:44:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 02:44:54 --> User Agent Class Initialized
INFO - 2018-06-19 02:44:54 --> Controller Class Initialized
INFO - 2018-06-19 02:44:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 02:44:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 02:44:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 02:44:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 02:44:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-19 02:44:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-19 02:44:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-06-19 02:44:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 02:44:54 --> Final output sent to browser
DEBUG - 2018-06-19 02:44:54 --> Total execution time: 0.0362
INFO - 2018-06-19 03:57:24 --> Config Class Initialized
INFO - 2018-06-19 03:57:24 --> Hooks Class Initialized
DEBUG - 2018-06-19 03:57:24 --> UTF-8 Support Enabled
INFO - 2018-06-19 03:57:24 --> Utf8 Class Initialized
INFO - 2018-06-19 03:57:24 --> URI Class Initialized
DEBUG - 2018-06-19 03:57:24 --> No URI present. Default controller set.
INFO - 2018-06-19 03:57:24 --> Router Class Initialized
INFO - 2018-06-19 03:57:24 --> Output Class Initialized
INFO - 2018-06-19 03:57:24 --> Security Class Initialized
DEBUG - 2018-06-19 03:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 03:57:24 --> CSRF cookie sent
INFO - 2018-06-19 03:57:24 --> Input Class Initialized
INFO - 2018-06-19 03:57:24 --> Language Class Initialized
INFO - 2018-06-19 03:57:24 --> Loader Class Initialized
INFO - 2018-06-19 03:57:24 --> Helper loaded: url_helper
INFO - 2018-06-19 03:57:24 --> Helper loaded: form_helper
INFO - 2018-06-19 03:57:24 --> Helper loaded: language_helper
DEBUG - 2018-06-19 03:57:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 03:57:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 03:57:24 --> User Agent Class Initialized
INFO - 2018-06-19 03:57:24 --> Controller Class Initialized
INFO - 2018-06-19 03:57:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 03:57:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 03:57:24 --> Pixel_Model class loaded
INFO - 2018-06-19 03:57:24 --> Database Driver Class Initialized
INFO - 2018-06-19 03:57:24 --> Model "QuestionsModel" initialized
INFO - 2018-06-19 03:57:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 03:57:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 03:57:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-19 03:57:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 03:57:24 --> Final output sent to browser
DEBUG - 2018-06-19 03:57:24 --> Total execution time: 0.0507
INFO - 2018-06-19 05:44:35 --> Config Class Initialized
INFO - 2018-06-19 05:44:35 --> Hooks Class Initialized
DEBUG - 2018-06-19 05:44:35 --> UTF-8 Support Enabled
INFO - 2018-06-19 05:44:35 --> Utf8 Class Initialized
INFO - 2018-06-19 05:44:35 --> URI Class Initialized
DEBUG - 2018-06-19 05:44:35 --> No URI present. Default controller set.
INFO - 2018-06-19 05:44:35 --> Router Class Initialized
INFO - 2018-06-19 05:44:35 --> Output Class Initialized
INFO - 2018-06-19 05:44:35 --> Security Class Initialized
DEBUG - 2018-06-19 05:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 05:44:35 --> CSRF cookie sent
INFO - 2018-06-19 05:44:35 --> Input Class Initialized
INFO - 2018-06-19 05:44:35 --> Language Class Initialized
INFO - 2018-06-19 05:44:35 --> Loader Class Initialized
INFO - 2018-06-19 05:44:35 --> Helper loaded: url_helper
INFO - 2018-06-19 05:44:35 --> Helper loaded: form_helper
INFO - 2018-06-19 05:44:35 --> Helper loaded: language_helper
DEBUG - 2018-06-19 05:44:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 05:44:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 05:44:35 --> User Agent Class Initialized
INFO - 2018-06-19 05:44:35 --> Controller Class Initialized
INFO - 2018-06-19 05:44:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 05:44:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 05:44:35 --> Pixel_Model class loaded
INFO - 2018-06-19 05:44:35 --> Database Driver Class Initialized
INFO - 2018-06-19 05:44:35 --> Model "QuestionsModel" initialized
INFO - 2018-06-19 05:44:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 05:44:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 05:44:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-19 05:44:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 05:44:35 --> Final output sent to browser
DEBUG - 2018-06-19 05:44:35 --> Total execution time: 0.0451
INFO - 2018-06-19 05:44:52 --> Config Class Initialized
INFO - 2018-06-19 05:44:52 --> Hooks Class Initialized
DEBUG - 2018-06-19 05:44:52 --> UTF-8 Support Enabled
INFO - 2018-06-19 05:44:52 --> Utf8 Class Initialized
INFO - 2018-06-19 05:44:52 --> URI Class Initialized
INFO - 2018-06-19 05:44:52 --> Router Class Initialized
INFO - 2018-06-19 05:44:52 --> Output Class Initialized
INFO - 2018-06-19 05:44:52 --> Security Class Initialized
DEBUG - 2018-06-19 05:44:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 05:44:52 --> CSRF cookie sent
INFO - 2018-06-19 05:44:52 --> CSRF token verified
INFO - 2018-06-19 05:44:52 --> Input Class Initialized
INFO - 2018-06-19 05:44:52 --> Language Class Initialized
INFO - 2018-06-19 05:44:52 --> Loader Class Initialized
INFO - 2018-06-19 05:44:52 --> Helper loaded: url_helper
INFO - 2018-06-19 05:44:52 --> Helper loaded: form_helper
INFO - 2018-06-19 05:44:52 --> Helper loaded: language_helper
DEBUG - 2018-06-19 05:44:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 05:44:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 05:44:52 --> User Agent Class Initialized
INFO - 2018-06-19 05:44:52 --> Controller Class Initialized
INFO - 2018-06-19 05:44:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 05:44:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 05:44:52 --> Pixel_Model class loaded
INFO - 2018-06-19 05:44:52 --> Database Driver Class Initialized
INFO - 2018-06-19 05:44:52 --> Model "QuestionsModel" initialized
INFO - 2018-06-19 05:44:52 --> Config Class Initialized
INFO - 2018-06-19 05:44:52 --> Hooks Class Initialized
DEBUG - 2018-06-19 05:44:52 --> UTF-8 Support Enabled
INFO - 2018-06-19 05:44:52 --> Utf8 Class Initialized
INFO - 2018-06-19 05:44:52 --> URI Class Initialized
INFO - 2018-06-19 05:44:52 --> Router Class Initialized
INFO - 2018-06-19 05:44:52 --> Output Class Initialized
INFO - 2018-06-19 05:44:52 --> Security Class Initialized
DEBUG - 2018-06-19 05:44:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 05:44:52 --> CSRF cookie sent
INFO - 2018-06-19 05:44:52 --> Input Class Initialized
INFO - 2018-06-19 05:44:52 --> Language Class Initialized
INFO - 2018-06-19 05:44:52 --> Loader Class Initialized
INFO - 2018-06-19 05:44:52 --> Helper loaded: url_helper
INFO - 2018-06-19 05:44:52 --> Helper loaded: form_helper
INFO - 2018-06-19 05:44:52 --> Helper loaded: language_helper
DEBUG - 2018-06-19 05:44:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 05:44:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 05:44:52 --> User Agent Class Initialized
INFO - 2018-06-19 05:44:52 --> Controller Class Initialized
INFO - 2018-06-19 05:44:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 05:44:52 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-19 05:44:52 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-19 05:44:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 05:44:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 05:44:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-19 05:44:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-19 05:44:52 --> Could not find the language line "req_email"
INFO - 2018-06-19 05:44:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-06-19 05:44:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 05:44:52 --> Final output sent to browser
DEBUG - 2018-06-19 05:44:52 --> Total execution time: 0.0325
INFO - 2018-06-19 05:44:58 --> Config Class Initialized
INFO - 2018-06-19 05:44:58 --> Hooks Class Initialized
DEBUG - 2018-06-19 05:44:58 --> UTF-8 Support Enabled
INFO - 2018-06-19 05:44:58 --> Utf8 Class Initialized
INFO - 2018-06-19 05:44:58 --> URI Class Initialized
INFO - 2018-06-19 05:44:58 --> Router Class Initialized
INFO - 2018-06-19 05:44:58 --> Output Class Initialized
INFO - 2018-06-19 05:44:58 --> Security Class Initialized
DEBUG - 2018-06-19 05:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 05:44:58 --> CSRF cookie sent
INFO - 2018-06-19 05:44:58 --> Input Class Initialized
INFO - 2018-06-19 05:44:58 --> Language Class Initialized
INFO - 2018-06-19 05:44:58 --> Loader Class Initialized
INFO - 2018-06-19 05:44:58 --> Helper loaded: url_helper
INFO - 2018-06-19 05:44:58 --> Helper loaded: form_helper
INFO - 2018-06-19 05:44:58 --> Helper loaded: language_helper
DEBUG - 2018-06-19 05:44:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 05:44:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 05:44:58 --> User Agent Class Initialized
INFO - 2018-06-19 05:44:58 --> Controller Class Initialized
INFO - 2018-06-19 05:44:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 05:44:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 05:44:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 05:44:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 05:44:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-19 05:44:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-19 05:44:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-06-19 05:44:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 05:44:58 --> Final output sent to browser
DEBUG - 2018-06-19 05:44:58 --> Total execution time: 0.0308
INFO - 2018-06-19 05:45:08 --> Config Class Initialized
INFO - 2018-06-19 05:45:08 --> Hooks Class Initialized
DEBUG - 2018-06-19 05:45:08 --> UTF-8 Support Enabled
INFO - 2018-06-19 05:45:08 --> Utf8 Class Initialized
INFO - 2018-06-19 05:45:08 --> URI Class Initialized
INFO - 2018-06-19 05:45:08 --> Router Class Initialized
INFO - 2018-06-19 05:45:08 --> Output Class Initialized
INFO - 2018-06-19 05:45:08 --> Security Class Initialized
DEBUG - 2018-06-19 05:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 05:45:08 --> CSRF cookie sent
INFO - 2018-06-19 05:45:08 --> Input Class Initialized
INFO - 2018-06-19 05:45:08 --> Language Class Initialized
INFO - 2018-06-19 05:45:08 --> Loader Class Initialized
INFO - 2018-06-19 05:45:08 --> Helper loaded: url_helper
INFO - 2018-06-19 05:45:08 --> Helper loaded: form_helper
INFO - 2018-06-19 05:45:08 --> Helper loaded: language_helper
DEBUG - 2018-06-19 05:45:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 05:45:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 05:45:08 --> User Agent Class Initialized
INFO - 2018-06-19 05:45:08 --> Controller Class Initialized
INFO - 2018-06-19 05:45:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 05:45:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 05:45:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 05:45:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 05:45:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-19 05:45:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-19 05:45:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/911.php
INFO - 2018-06-19 05:45:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 05:45:08 --> Final output sent to browser
DEBUG - 2018-06-19 05:45:08 --> Total execution time: 0.0472
INFO - 2018-06-19 05:45:22 --> Config Class Initialized
INFO - 2018-06-19 05:45:22 --> Hooks Class Initialized
DEBUG - 2018-06-19 05:45:22 --> UTF-8 Support Enabled
INFO - 2018-06-19 05:45:22 --> Utf8 Class Initialized
INFO - 2018-06-19 05:45:22 --> URI Class Initialized
INFO - 2018-06-19 05:45:22 --> Router Class Initialized
INFO - 2018-06-19 05:45:22 --> Output Class Initialized
INFO - 2018-06-19 05:45:22 --> Security Class Initialized
DEBUG - 2018-06-19 05:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 05:45:22 --> CSRF cookie sent
INFO - 2018-06-19 05:45:22 --> Input Class Initialized
INFO - 2018-06-19 05:45:22 --> Language Class Initialized
INFO - 2018-06-19 05:45:22 --> Loader Class Initialized
INFO - 2018-06-19 05:45:22 --> Helper loaded: url_helper
INFO - 2018-06-19 05:45:22 --> Helper loaded: form_helper
INFO - 2018-06-19 05:45:22 --> Helper loaded: language_helper
DEBUG - 2018-06-19 05:45:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 05:45:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 05:45:22 --> User Agent Class Initialized
INFO - 2018-06-19 05:45:22 --> Controller Class Initialized
INFO - 2018-06-19 05:45:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 05:45:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 05:45:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 05:45:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 05:45:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-19 05:45:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-19 05:45:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-06-19 05:45:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 05:45:22 --> Final output sent to browser
DEBUG - 2018-06-19 05:45:22 --> Total execution time: 0.0666
INFO - 2018-06-19 09:49:27 --> Config Class Initialized
INFO - 2018-06-19 09:49:27 --> Hooks Class Initialized
DEBUG - 2018-06-19 09:49:27 --> UTF-8 Support Enabled
INFO - 2018-06-19 09:49:27 --> Utf8 Class Initialized
INFO - 2018-06-19 09:49:27 --> URI Class Initialized
DEBUG - 2018-06-19 09:49:27 --> No URI present. Default controller set.
INFO - 2018-06-19 09:49:27 --> Router Class Initialized
INFO - 2018-06-19 09:49:27 --> Output Class Initialized
INFO - 2018-06-19 09:49:27 --> Security Class Initialized
DEBUG - 2018-06-19 09:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 09:49:27 --> CSRF cookie sent
INFO - 2018-06-19 09:49:27 --> Input Class Initialized
INFO - 2018-06-19 09:49:27 --> Language Class Initialized
INFO - 2018-06-19 09:49:27 --> Loader Class Initialized
INFO - 2018-06-19 09:49:27 --> Helper loaded: url_helper
INFO - 2018-06-19 09:49:27 --> Helper loaded: form_helper
INFO - 2018-06-19 09:49:27 --> Helper loaded: language_helper
DEBUG - 2018-06-19 09:49:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 09:49:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 09:49:27 --> User Agent Class Initialized
INFO - 2018-06-19 09:49:27 --> Controller Class Initialized
INFO - 2018-06-19 09:49:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 09:49:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 09:49:27 --> Pixel_Model class loaded
INFO - 2018-06-19 09:49:27 --> Database Driver Class Initialized
INFO - 2018-06-19 09:49:27 --> Model "QuestionsModel" initialized
INFO - 2018-06-19 09:49:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 09:49:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 09:49:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-19 09:49:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 09:49:27 --> Final output sent to browser
DEBUG - 2018-06-19 09:49:27 --> Total execution time: 0.0433
INFO - 2018-06-19 09:49:27 --> Config Class Initialized
INFO - 2018-06-19 09:49:27 --> Hooks Class Initialized
DEBUG - 2018-06-19 09:49:27 --> UTF-8 Support Enabled
INFO - 2018-06-19 09:49:27 --> Utf8 Class Initialized
INFO - 2018-06-19 09:49:27 --> URI Class Initialized
INFO - 2018-06-19 09:49:27 --> Router Class Initialized
INFO - 2018-06-19 09:49:27 --> Output Class Initialized
INFO - 2018-06-19 09:49:27 --> Security Class Initialized
DEBUG - 2018-06-19 09:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 09:49:27 --> CSRF cookie sent
INFO - 2018-06-19 09:49:28 --> Config Class Initialized
INFO - 2018-06-19 09:49:28 --> Hooks Class Initialized
DEBUG - 2018-06-19 09:49:28 --> UTF-8 Support Enabled
INFO - 2018-06-19 09:49:28 --> Utf8 Class Initialized
INFO - 2018-06-19 09:49:28 --> URI Class Initialized
INFO - 2018-06-19 09:49:28 --> Router Class Initialized
INFO - 2018-06-19 09:49:28 --> Output Class Initialized
INFO - 2018-06-19 09:49:28 --> Security Class Initialized
DEBUG - 2018-06-19 09:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 09:49:28 --> CSRF cookie sent
INFO - 2018-06-19 09:49:28 --> Config Class Initialized
INFO - 2018-06-19 09:49:28 --> Hooks Class Initialized
DEBUG - 2018-06-19 09:49:28 --> UTF-8 Support Enabled
INFO - 2018-06-19 09:49:28 --> Utf8 Class Initialized
INFO - 2018-06-19 09:49:28 --> URI Class Initialized
INFO - 2018-06-19 09:49:28 --> Router Class Initialized
INFO - 2018-06-19 09:49:28 --> Output Class Initialized
INFO - 2018-06-19 09:49:28 --> Security Class Initialized
DEBUG - 2018-06-19 09:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 09:49:28 --> CSRF cookie sent
INFO - 2018-06-19 09:49:28 --> Config Class Initialized
INFO - 2018-06-19 09:49:28 --> Hooks Class Initialized
DEBUG - 2018-06-19 09:49:28 --> UTF-8 Support Enabled
INFO - 2018-06-19 09:49:28 --> Utf8 Class Initialized
INFO - 2018-06-19 09:49:28 --> URI Class Initialized
INFO - 2018-06-19 09:49:28 --> Router Class Initialized
INFO - 2018-06-19 09:49:28 --> Output Class Initialized
INFO - 2018-06-19 09:49:28 --> Security Class Initialized
DEBUG - 2018-06-19 09:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 09:49:28 --> CSRF cookie sent
INFO - 2018-06-19 09:49:28 --> Config Class Initialized
INFO - 2018-06-19 09:49:28 --> Hooks Class Initialized
DEBUG - 2018-06-19 09:49:28 --> UTF-8 Support Enabled
INFO - 2018-06-19 09:49:28 --> Utf8 Class Initialized
INFO - 2018-06-19 09:49:28 --> URI Class Initialized
INFO - 2018-06-19 09:49:28 --> Router Class Initialized
INFO - 2018-06-19 09:49:28 --> Output Class Initialized
INFO - 2018-06-19 09:49:28 --> Security Class Initialized
DEBUG - 2018-06-19 09:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 09:49:28 --> CSRF cookie sent
INFO - 2018-06-19 09:49:29 --> Config Class Initialized
INFO - 2018-06-19 09:49:29 --> Hooks Class Initialized
DEBUG - 2018-06-19 09:49:29 --> UTF-8 Support Enabled
INFO - 2018-06-19 09:49:29 --> Utf8 Class Initialized
INFO - 2018-06-19 09:49:29 --> URI Class Initialized
INFO - 2018-06-19 09:49:29 --> Router Class Initialized
INFO - 2018-06-19 09:49:29 --> Output Class Initialized
INFO - 2018-06-19 09:49:29 --> Security Class Initialized
DEBUG - 2018-06-19 09:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 09:49:29 --> CSRF cookie sent
INFO - 2018-06-19 09:49:29 --> Config Class Initialized
INFO - 2018-06-19 09:49:29 --> Hooks Class Initialized
DEBUG - 2018-06-19 09:49:29 --> UTF-8 Support Enabled
INFO - 2018-06-19 09:49:29 --> Utf8 Class Initialized
INFO - 2018-06-19 09:49:29 --> URI Class Initialized
INFO - 2018-06-19 09:49:29 --> Router Class Initialized
INFO - 2018-06-19 09:49:29 --> Output Class Initialized
INFO - 2018-06-19 09:49:29 --> Security Class Initialized
DEBUG - 2018-06-19 09:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 09:49:29 --> CSRF cookie sent
INFO - 2018-06-19 09:49:29 --> Config Class Initialized
INFO - 2018-06-19 09:49:29 --> Hooks Class Initialized
DEBUG - 2018-06-19 09:49:29 --> UTF-8 Support Enabled
INFO - 2018-06-19 09:49:29 --> Utf8 Class Initialized
INFO - 2018-06-19 09:49:29 --> URI Class Initialized
INFO - 2018-06-19 09:49:29 --> Router Class Initialized
INFO - 2018-06-19 09:49:29 --> Output Class Initialized
INFO - 2018-06-19 09:49:29 --> Security Class Initialized
DEBUG - 2018-06-19 09:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 09:49:29 --> CSRF cookie sent
INFO - 2018-06-19 09:49:29 --> Config Class Initialized
INFO - 2018-06-19 09:49:29 --> Hooks Class Initialized
DEBUG - 2018-06-19 09:49:29 --> UTF-8 Support Enabled
INFO - 2018-06-19 09:49:29 --> Utf8 Class Initialized
INFO - 2018-06-19 09:49:29 --> URI Class Initialized
INFO - 2018-06-19 09:49:29 --> Router Class Initialized
INFO - 2018-06-19 09:49:29 --> Output Class Initialized
INFO - 2018-06-19 09:49:29 --> Security Class Initialized
DEBUG - 2018-06-19 09:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 09:49:29 --> CSRF cookie sent
INFO - 2018-06-19 09:49:30 --> Config Class Initialized
INFO - 2018-06-19 09:49:30 --> Hooks Class Initialized
DEBUG - 2018-06-19 09:49:30 --> UTF-8 Support Enabled
INFO - 2018-06-19 09:49:30 --> Utf8 Class Initialized
INFO - 2018-06-19 09:49:30 --> URI Class Initialized
INFO - 2018-06-19 09:49:30 --> Router Class Initialized
INFO - 2018-06-19 09:49:30 --> Output Class Initialized
INFO - 2018-06-19 09:49:30 --> Security Class Initialized
DEBUG - 2018-06-19 09:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 09:49:30 --> CSRF cookie sent
INFO - 2018-06-19 09:49:30 --> Config Class Initialized
INFO - 2018-06-19 09:49:30 --> Hooks Class Initialized
DEBUG - 2018-06-19 09:49:30 --> UTF-8 Support Enabled
INFO - 2018-06-19 09:49:30 --> Utf8 Class Initialized
INFO - 2018-06-19 09:49:30 --> URI Class Initialized
INFO - 2018-06-19 09:49:30 --> Router Class Initialized
INFO - 2018-06-19 09:49:30 --> Output Class Initialized
INFO - 2018-06-19 09:49:30 --> Security Class Initialized
DEBUG - 2018-06-19 09:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 09:49:30 --> CSRF cookie sent
INFO - 2018-06-19 09:49:30 --> Config Class Initialized
INFO - 2018-06-19 09:49:30 --> Hooks Class Initialized
DEBUG - 2018-06-19 09:49:30 --> UTF-8 Support Enabled
INFO - 2018-06-19 09:49:30 --> Utf8 Class Initialized
INFO - 2018-06-19 09:49:30 --> URI Class Initialized
DEBUG - 2018-06-19 09:49:30 --> No URI present. Default controller set.
INFO - 2018-06-19 09:49:30 --> Router Class Initialized
INFO - 2018-06-19 09:49:30 --> Output Class Initialized
INFO - 2018-06-19 09:49:30 --> Security Class Initialized
DEBUG - 2018-06-19 09:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 09:49:30 --> CSRF cookie sent
INFO - 2018-06-19 09:49:30 --> Input Class Initialized
INFO - 2018-06-19 09:49:30 --> Language Class Initialized
INFO - 2018-06-19 09:49:30 --> Loader Class Initialized
INFO - 2018-06-19 09:49:30 --> Helper loaded: url_helper
INFO - 2018-06-19 09:49:30 --> Helper loaded: form_helper
INFO - 2018-06-19 09:49:30 --> Helper loaded: language_helper
DEBUG - 2018-06-19 09:49:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 09:49:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 09:49:30 --> User Agent Class Initialized
INFO - 2018-06-19 09:49:30 --> Controller Class Initialized
INFO - 2018-06-19 09:49:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 09:49:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 09:49:30 --> Pixel_Model class loaded
INFO - 2018-06-19 09:49:30 --> Database Driver Class Initialized
INFO - 2018-06-19 09:49:30 --> Model "QuestionsModel" initialized
INFO - 2018-06-19 09:49:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 09:49:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 09:49:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-19 09:49:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 09:49:30 --> Final output sent to browser
DEBUG - 2018-06-19 09:49:30 --> Total execution time: 0.0496
INFO - 2018-06-19 09:49:31 --> Config Class Initialized
INFO - 2018-06-19 09:49:31 --> Hooks Class Initialized
DEBUG - 2018-06-19 09:49:31 --> UTF-8 Support Enabled
INFO - 2018-06-19 09:49:31 --> Utf8 Class Initialized
INFO - 2018-06-19 09:49:31 --> URI Class Initialized
DEBUG - 2018-06-19 09:49:31 --> No URI present. Default controller set.
INFO - 2018-06-19 09:49:31 --> Router Class Initialized
INFO - 2018-06-19 09:49:31 --> Output Class Initialized
INFO - 2018-06-19 09:49:31 --> Security Class Initialized
DEBUG - 2018-06-19 09:49:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 09:49:31 --> CSRF cookie sent
INFO - 2018-06-19 09:49:31 --> Input Class Initialized
INFO - 2018-06-19 09:49:31 --> Language Class Initialized
INFO - 2018-06-19 09:49:31 --> Loader Class Initialized
INFO - 2018-06-19 09:49:31 --> Helper loaded: url_helper
INFO - 2018-06-19 09:49:31 --> Helper loaded: form_helper
INFO - 2018-06-19 09:49:31 --> Helper loaded: language_helper
DEBUG - 2018-06-19 09:49:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 09:49:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 09:49:31 --> User Agent Class Initialized
INFO - 2018-06-19 09:49:31 --> Controller Class Initialized
INFO - 2018-06-19 09:49:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 09:49:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 09:49:31 --> Pixel_Model class loaded
INFO - 2018-06-19 09:49:31 --> Database Driver Class Initialized
INFO - 2018-06-19 09:49:31 --> Model "QuestionsModel" initialized
INFO - 2018-06-19 09:49:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 09:49:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 09:49:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-19 09:49:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 09:49:31 --> Final output sent to browser
DEBUG - 2018-06-19 09:49:31 --> Total execution time: 0.0396
INFO - 2018-06-19 09:49:31 --> Config Class Initialized
INFO - 2018-06-19 09:49:31 --> Hooks Class Initialized
DEBUG - 2018-06-19 09:49:31 --> UTF-8 Support Enabled
INFO - 2018-06-19 09:49:31 --> Utf8 Class Initialized
INFO - 2018-06-19 09:49:31 --> URI Class Initialized
DEBUG - 2018-06-19 09:49:31 --> No URI present. Default controller set.
INFO - 2018-06-19 09:49:31 --> Router Class Initialized
INFO - 2018-06-19 09:49:31 --> Output Class Initialized
INFO - 2018-06-19 09:49:31 --> Security Class Initialized
DEBUG - 2018-06-19 09:49:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 09:49:31 --> CSRF cookie sent
INFO - 2018-06-19 09:49:31 --> Input Class Initialized
INFO - 2018-06-19 09:49:31 --> Language Class Initialized
INFO - 2018-06-19 09:49:31 --> Loader Class Initialized
INFO - 2018-06-19 09:49:31 --> Helper loaded: url_helper
INFO - 2018-06-19 09:49:31 --> Helper loaded: form_helper
INFO - 2018-06-19 09:49:31 --> Helper loaded: language_helper
DEBUG - 2018-06-19 09:49:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 09:49:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 09:49:31 --> User Agent Class Initialized
INFO - 2018-06-19 09:49:31 --> Controller Class Initialized
INFO - 2018-06-19 09:49:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 09:49:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 09:49:31 --> Pixel_Model class loaded
INFO - 2018-06-19 09:49:31 --> Database Driver Class Initialized
INFO - 2018-06-19 09:49:31 --> Model "QuestionsModel" initialized
INFO - 2018-06-19 09:49:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 09:49:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 09:49:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-19 09:49:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 09:49:31 --> Final output sent to browser
DEBUG - 2018-06-19 09:49:31 --> Total execution time: 0.0539
INFO - 2018-06-19 09:49:31 --> Config Class Initialized
INFO - 2018-06-19 09:49:31 --> Hooks Class Initialized
DEBUG - 2018-06-19 09:49:31 --> UTF-8 Support Enabled
INFO - 2018-06-19 09:49:31 --> Utf8 Class Initialized
INFO - 2018-06-19 09:49:31 --> URI Class Initialized
DEBUG - 2018-06-19 09:49:31 --> No URI present. Default controller set.
INFO - 2018-06-19 09:49:31 --> Router Class Initialized
INFO - 2018-06-19 09:49:31 --> Output Class Initialized
INFO - 2018-06-19 09:49:31 --> Security Class Initialized
DEBUG - 2018-06-19 09:49:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 09:49:31 --> CSRF cookie sent
INFO - 2018-06-19 09:49:31 --> Input Class Initialized
INFO - 2018-06-19 09:49:31 --> Language Class Initialized
INFO - 2018-06-19 09:49:31 --> Loader Class Initialized
INFO - 2018-06-19 09:49:31 --> Helper loaded: url_helper
INFO - 2018-06-19 09:49:31 --> Helper loaded: form_helper
INFO - 2018-06-19 09:49:31 --> Helper loaded: language_helper
DEBUG - 2018-06-19 09:49:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 09:49:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 09:49:31 --> User Agent Class Initialized
INFO - 2018-06-19 09:49:31 --> Controller Class Initialized
INFO - 2018-06-19 09:49:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 09:49:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 09:49:31 --> Pixel_Model class loaded
INFO - 2018-06-19 09:49:31 --> Database Driver Class Initialized
INFO - 2018-06-19 09:49:31 --> Model "QuestionsModel" initialized
INFO - 2018-06-19 09:49:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 09:49:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 09:49:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-19 09:49:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 09:49:31 --> Final output sent to browser
DEBUG - 2018-06-19 09:49:31 --> Total execution time: 0.0616
INFO - 2018-06-19 09:49:32 --> Config Class Initialized
INFO - 2018-06-19 09:49:32 --> Hooks Class Initialized
DEBUG - 2018-06-19 09:49:32 --> UTF-8 Support Enabled
INFO - 2018-06-19 09:49:32 --> Utf8 Class Initialized
INFO - 2018-06-19 09:49:32 --> URI Class Initialized
DEBUG - 2018-06-19 09:49:32 --> No URI present. Default controller set.
INFO - 2018-06-19 09:49:32 --> Router Class Initialized
INFO - 2018-06-19 09:49:32 --> Output Class Initialized
INFO - 2018-06-19 09:49:32 --> Security Class Initialized
DEBUG - 2018-06-19 09:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 09:49:32 --> CSRF cookie sent
INFO - 2018-06-19 09:49:32 --> Input Class Initialized
INFO - 2018-06-19 09:49:32 --> Language Class Initialized
INFO - 2018-06-19 09:49:32 --> Loader Class Initialized
INFO - 2018-06-19 09:49:32 --> Helper loaded: url_helper
INFO - 2018-06-19 09:49:32 --> Helper loaded: form_helper
INFO - 2018-06-19 09:49:32 --> Helper loaded: language_helper
DEBUG - 2018-06-19 09:49:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 09:49:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 09:49:32 --> User Agent Class Initialized
INFO - 2018-06-19 09:49:32 --> Controller Class Initialized
INFO - 2018-06-19 09:49:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 09:49:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 09:49:32 --> Pixel_Model class loaded
INFO - 2018-06-19 09:49:32 --> Database Driver Class Initialized
INFO - 2018-06-19 09:49:32 --> Model "QuestionsModel" initialized
INFO - 2018-06-19 09:49:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 09:49:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 09:49:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-19 09:49:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 09:49:32 --> Final output sent to browser
DEBUG - 2018-06-19 09:49:32 --> Total execution time: 0.0406
INFO - 2018-06-19 09:49:32 --> Config Class Initialized
INFO - 2018-06-19 09:49:32 --> Hooks Class Initialized
DEBUG - 2018-06-19 09:49:32 --> UTF-8 Support Enabled
INFO - 2018-06-19 09:49:32 --> Utf8 Class Initialized
INFO - 2018-06-19 09:49:32 --> URI Class Initialized
DEBUG - 2018-06-19 09:49:32 --> No URI present. Default controller set.
INFO - 2018-06-19 09:49:32 --> Router Class Initialized
INFO - 2018-06-19 09:49:32 --> Output Class Initialized
INFO - 2018-06-19 09:49:32 --> Security Class Initialized
DEBUG - 2018-06-19 09:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 09:49:32 --> CSRF cookie sent
INFO - 2018-06-19 09:49:32 --> Input Class Initialized
INFO - 2018-06-19 09:49:32 --> Language Class Initialized
INFO - 2018-06-19 09:49:32 --> Loader Class Initialized
INFO - 2018-06-19 09:49:32 --> Helper loaded: url_helper
INFO - 2018-06-19 09:49:32 --> Helper loaded: form_helper
INFO - 2018-06-19 09:49:32 --> Helper loaded: language_helper
DEBUG - 2018-06-19 09:49:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 09:49:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 09:49:32 --> User Agent Class Initialized
INFO - 2018-06-19 09:49:32 --> Controller Class Initialized
INFO - 2018-06-19 09:49:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 09:49:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 09:49:32 --> Pixel_Model class loaded
INFO - 2018-06-19 09:49:32 --> Database Driver Class Initialized
INFO - 2018-06-19 09:49:32 --> Model "QuestionsModel" initialized
INFO - 2018-06-19 09:49:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 09:49:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 09:49:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-19 09:49:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 09:49:32 --> Final output sent to browser
DEBUG - 2018-06-19 09:49:32 --> Total execution time: 0.0683
INFO - 2018-06-19 09:49:33 --> Config Class Initialized
INFO - 2018-06-19 09:49:33 --> Hooks Class Initialized
DEBUG - 2018-06-19 09:49:33 --> UTF-8 Support Enabled
INFO - 2018-06-19 09:49:33 --> Utf8 Class Initialized
INFO - 2018-06-19 09:49:33 --> URI Class Initialized
DEBUG - 2018-06-19 09:49:33 --> No URI present. Default controller set.
INFO - 2018-06-19 09:49:33 --> Router Class Initialized
INFO - 2018-06-19 09:49:33 --> Output Class Initialized
INFO - 2018-06-19 09:49:33 --> Security Class Initialized
DEBUG - 2018-06-19 09:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 09:49:33 --> CSRF cookie sent
INFO - 2018-06-19 09:49:33 --> Input Class Initialized
INFO - 2018-06-19 09:49:33 --> Language Class Initialized
INFO - 2018-06-19 09:49:33 --> Loader Class Initialized
INFO - 2018-06-19 09:49:33 --> Helper loaded: url_helper
INFO - 2018-06-19 09:49:33 --> Helper loaded: form_helper
INFO - 2018-06-19 09:49:33 --> Helper loaded: language_helper
DEBUG - 2018-06-19 09:49:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 09:49:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 09:49:33 --> User Agent Class Initialized
INFO - 2018-06-19 09:49:33 --> Controller Class Initialized
INFO - 2018-06-19 09:49:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 09:49:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 09:49:33 --> Pixel_Model class loaded
INFO - 2018-06-19 09:49:33 --> Database Driver Class Initialized
INFO - 2018-06-19 09:49:33 --> Model "QuestionsModel" initialized
INFO - 2018-06-19 09:49:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 09:49:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 09:49:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-19 09:49:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 09:49:33 --> Final output sent to browser
DEBUG - 2018-06-19 09:49:33 --> Total execution time: 0.0537
INFO - 2018-06-19 09:49:33 --> Config Class Initialized
INFO - 2018-06-19 09:49:33 --> Hooks Class Initialized
DEBUG - 2018-06-19 09:49:33 --> UTF-8 Support Enabled
INFO - 2018-06-19 09:49:33 --> Utf8 Class Initialized
INFO - 2018-06-19 09:49:33 --> URI Class Initialized
DEBUG - 2018-06-19 09:49:33 --> No URI present. Default controller set.
INFO - 2018-06-19 09:49:33 --> Router Class Initialized
INFO - 2018-06-19 09:49:33 --> Output Class Initialized
INFO - 2018-06-19 09:49:33 --> Security Class Initialized
DEBUG - 2018-06-19 09:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 09:49:33 --> CSRF cookie sent
INFO - 2018-06-19 09:49:33 --> Input Class Initialized
INFO - 2018-06-19 09:49:33 --> Language Class Initialized
INFO - 2018-06-19 09:49:33 --> Loader Class Initialized
INFO - 2018-06-19 09:49:33 --> Helper loaded: url_helper
INFO - 2018-06-19 09:49:33 --> Helper loaded: form_helper
INFO - 2018-06-19 09:49:33 --> Helper loaded: language_helper
DEBUG - 2018-06-19 09:49:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 09:49:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 09:49:33 --> User Agent Class Initialized
INFO - 2018-06-19 09:49:33 --> Controller Class Initialized
INFO - 2018-06-19 09:49:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 09:49:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 09:49:33 --> Pixel_Model class loaded
INFO - 2018-06-19 09:49:33 --> Database Driver Class Initialized
INFO - 2018-06-19 09:49:33 --> Model "QuestionsModel" initialized
INFO - 2018-06-19 09:49:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 09:49:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 09:49:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-19 09:49:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 09:49:33 --> Final output sent to browser
DEBUG - 2018-06-19 09:49:33 --> Total execution time: 0.0435
INFO - 2018-06-19 09:49:33 --> Config Class Initialized
INFO - 2018-06-19 09:49:33 --> Hooks Class Initialized
DEBUG - 2018-06-19 09:49:33 --> UTF-8 Support Enabled
INFO - 2018-06-19 09:49:33 --> Utf8 Class Initialized
INFO - 2018-06-19 09:49:33 --> URI Class Initialized
DEBUG - 2018-06-19 09:49:33 --> No URI present. Default controller set.
INFO - 2018-06-19 09:49:33 --> Router Class Initialized
INFO - 2018-06-19 09:49:33 --> Output Class Initialized
INFO - 2018-06-19 09:49:33 --> Security Class Initialized
DEBUG - 2018-06-19 09:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 09:49:33 --> CSRF cookie sent
INFO - 2018-06-19 09:49:33 --> Input Class Initialized
INFO - 2018-06-19 09:49:33 --> Language Class Initialized
INFO - 2018-06-19 09:49:33 --> Loader Class Initialized
INFO - 2018-06-19 09:49:33 --> Helper loaded: url_helper
INFO - 2018-06-19 09:49:33 --> Helper loaded: form_helper
INFO - 2018-06-19 09:49:33 --> Helper loaded: language_helper
DEBUG - 2018-06-19 09:49:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 09:49:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 09:49:33 --> User Agent Class Initialized
INFO - 2018-06-19 09:49:33 --> Controller Class Initialized
INFO - 2018-06-19 09:49:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 09:49:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 09:49:33 --> Pixel_Model class loaded
INFO - 2018-06-19 09:49:34 --> Database Driver Class Initialized
INFO - 2018-06-19 09:49:34 --> Model "QuestionsModel" initialized
INFO - 2018-06-19 09:49:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 09:49:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 09:49:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-19 09:49:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 09:49:34 --> Final output sent to browser
DEBUG - 2018-06-19 09:49:34 --> Total execution time: 0.0522
INFO - 2018-06-19 09:49:34 --> Config Class Initialized
INFO - 2018-06-19 09:49:34 --> Hooks Class Initialized
DEBUG - 2018-06-19 09:49:34 --> UTF-8 Support Enabled
INFO - 2018-06-19 09:49:34 --> Utf8 Class Initialized
INFO - 2018-06-19 09:49:34 --> URI Class Initialized
DEBUG - 2018-06-19 09:49:34 --> No URI present. Default controller set.
INFO - 2018-06-19 09:49:34 --> Router Class Initialized
INFO - 2018-06-19 09:49:34 --> Output Class Initialized
INFO - 2018-06-19 09:49:34 --> Security Class Initialized
DEBUG - 2018-06-19 09:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 09:49:34 --> CSRF cookie sent
INFO - 2018-06-19 09:49:34 --> Input Class Initialized
INFO - 2018-06-19 09:49:34 --> Language Class Initialized
INFO - 2018-06-19 09:49:34 --> Loader Class Initialized
INFO - 2018-06-19 09:49:34 --> Helper loaded: url_helper
INFO - 2018-06-19 09:49:34 --> Helper loaded: form_helper
INFO - 2018-06-19 09:49:34 --> Helper loaded: language_helper
DEBUG - 2018-06-19 09:49:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 09:49:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 09:49:34 --> User Agent Class Initialized
INFO - 2018-06-19 09:49:34 --> Controller Class Initialized
INFO - 2018-06-19 09:49:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 09:49:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 09:49:34 --> Pixel_Model class loaded
INFO - 2018-06-19 09:49:34 --> Database Driver Class Initialized
INFO - 2018-06-19 09:49:34 --> Model "QuestionsModel" initialized
INFO - 2018-06-19 09:49:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 09:49:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 09:49:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-19 09:49:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 09:49:34 --> Final output sent to browser
DEBUG - 2018-06-19 09:49:34 --> Total execution time: 0.0488
INFO - 2018-06-19 13:14:47 --> Config Class Initialized
INFO - 2018-06-19 13:14:47 --> Hooks Class Initialized
DEBUG - 2018-06-19 13:14:47 --> UTF-8 Support Enabled
INFO - 2018-06-19 13:14:47 --> Utf8 Class Initialized
INFO - 2018-06-19 13:14:47 --> URI Class Initialized
DEBUG - 2018-06-19 13:14:47 --> No URI present. Default controller set.
INFO - 2018-06-19 13:14:47 --> Router Class Initialized
INFO - 2018-06-19 13:14:47 --> Output Class Initialized
INFO - 2018-06-19 13:14:47 --> Security Class Initialized
DEBUG - 2018-06-19 13:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 13:14:47 --> CSRF cookie sent
INFO - 2018-06-19 13:14:47 --> Input Class Initialized
INFO - 2018-06-19 13:14:47 --> Language Class Initialized
INFO - 2018-06-19 13:14:47 --> Loader Class Initialized
INFO - 2018-06-19 13:14:47 --> Helper loaded: url_helper
INFO - 2018-06-19 13:14:47 --> Helper loaded: form_helper
INFO - 2018-06-19 13:14:47 --> Helper loaded: language_helper
DEBUG - 2018-06-19 13:14:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 13:14:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 13:14:47 --> User Agent Class Initialized
INFO - 2018-06-19 13:14:47 --> Controller Class Initialized
INFO - 2018-06-19 13:14:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 13:14:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 13:14:47 --> Pixel_Model class loaded
INFO - 2018-06-19 13:14:47 --> Database Driver Class Initialized
INFO - 2018-06-19 13:14:47 --> Model "QuestionsModel" initialized
INFO - 2018-06-19 13:14:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 13:14:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 13:14:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-19 13:14:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 13:14:47 --> Final output sent to browser
DEBUG - 2018-06-19 13:14:47 --> Total execution time: 0.0644
INFO - 2018-06-19 13:14:54 --> Config Class Initialized
INFO - 2018-06-19 13:14:54 --> Hooks Class Initialized
DEBUG - 2018-06-19 13:14:54 --> UTF-8 Support Enabled
INFO - 2018-06-19 13:14:54 --> Utf8 Class Initialized
INFO - 2018-06-19 13:14:54 --> URI Class Initialized
DEBUG - 2018-06-19 13:14:54 --> No URI present. Default controller set.
INFO - 2018-06-19 13:14:54 --> Router Class Initialized
INFO - 2018-06-19 13:14:54 --> Output Class Initialized
INFO - 2018-06-19 13:14:54 --> Security Class Initialized
DEBUG - 2018-06-19 13:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 13:14:54 --> CSRF cookie sent
INFO - 2018-06-19 13:14:54 --> Input Class Initialized
INFO - 2018-06-19 13:14:54 --> Language Class Initialized
INFO - 2018-06-19 13:14:54 --> Loader Class Initialized
INFO - 2018-06-19 13:14:54 --> Helper loaded: url_helper
INFO - 2018-06-19 13:14:54 --> Helper loaded: form_helper
INFO - 2018-06-19 13:14:54 --> Helper loaded: language_helper
DEBUG - 2018-06-19 13:14:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 13:14:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 13:14:54 --> User Agent Class Initialized
INFO - 2018-06-19 13:14:54 --> Controller Class Initialized
INFO - 2018-06-19 13:14:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 13:14:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 13:14:54 --> Pixel_Model class loaded
INFO - 2018-06-19 13:14:54 --> Database Driver Class Initialized
INFO - 2018-06-19 13:14:54 --> Model "QuestionsModel" initialized
INFO - 2018-06-19 13:14:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 13:14:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 13:14:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-19 13:14:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 13:14:54 --> Final output sent to browser
DEBUG - 2018-06-19 13:14:54 --> Total execution time: 0.0551
INFO - 2018-06-19 13:15:23 --> Config Class Initialized
INFO - 2018-06-19 13:15:23 --> Hooks Class Initialized
DEBUG - 2018-06-19 13:15:23 --> UTF-8 Support Enabled
INFO - 2018-06-19 13:15:23 --> Utf8 Class Initialized
INFO - 2018-06-19 13:15:23 --> URI Class Initialized
DEBUG - 2018-06-19 13:15:23 --> No URI present. Default controller set.
INFO - 2018-06-19 13:15:23 --> Router Class Initialized
INFO - 2018-06-19 13:15:23 --> Output Class Initialized
INFO - 2018-06-19 13:15:23 --> Security Class Initialized
DEBUG - 2018-06-19 13:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 13:15:23 --> CSRF cookie sent
INFO - 2018-06-19 13:15:23 --> Input Class Initialized
INFO - 2018-06-19 13:15:23 --> Language Class Initialized
INFO - 2018-06-19 13:15:23 --> Loader Class Initialized
INFO - 2018-06-19 13:15:23 --> Helper loaded: url_helper
INFO - 2018-06-19 13:15:23 --> Helper loaded: form_helper
INFO - 2018-06-19 13:15:23 --> Helper loaded: language_helper
DEBUG - 2018-06-19 13:15:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 13:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 13:15:23 --> User Agent Class Initialized
INFO - 2018-06-19 13:15:23 --> Controller Class Initialized
INFO - 2018-06-19 13:15:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 13:15:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 13:15:23 --> Pixel_Model class loaded
INFO - 2018-06-19 13:15:23 --> Database Driver Class Initialized
INFO - 2018-06-19 13:15:23 --> Model "QuestionsModel" initialized
INFO - 2018-06-19 13:15:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 13:15:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 13:15:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-19 13:15:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 13:15:23 --> Final output sent to browser
DEBUG - 2018-06-19 13:15:23 --> Total execution time: 0.0618
INFO - 2018-06-19 13:15:27 --> Config Class Initialized
INFO - 2018-06-19 13:15:28 --> Hooks Class Initialized
DEBUG - 2018-06-19 13:15:28 --> UTF-8 Support Enabled
INFO - 2018-06-19 13:15:28 --> Utf8 Class Initialized
INFO - 2018-06-19 13:15:28 --> URI Class Initialized
DEBUG - 2018-06-19 13:15:28 --> No URI present. Default controller set.
INFO - 2018-06-19 13:15:28 --> Router Class Initialized
INFO - 2018-06-19 13:15:28 --> Output Class Initialized
INFO - 2018-06-19 13:15:28 --> Security Class Initialized
DEBUG - 2018-06-19 13:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 13:15:28 --> CSRF cookie sent
INFO - 2018-06-19 13:15:28 --> Input Class Initialized
INFO - 2018-06-19 13:15:28 --> Language Class Initialized
INFO - 2018-06-19 13:15:28 --> Loader Class Initialized
INFO - 2018-06-19 13:15:28 --> Helper loaded: url_helper
INFO - 2018-06-19 13:15:28 --> Helper loaded: form_helper
INFO - 2018-06-19 13:15:28 --> Helper loaded: language_helper
DEBUG - 2018-06-19 13:15:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 13:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 13:15:28 --> User Agent Class Initialized
INFO - 2018-06-19 13:15:28 --> Controller Class Initialized
INFO - 2018-06-19 13:15:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 13:15:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 13:15:28 --> Pixel_Model class loaded
INFO - 2018-06-19 13:15:28 --> Database Driver Class Initialized
INFO - 2018-06-19 13:15:28 --> Model "QuestionsModel" initialized
INFO - 2018-06-19 13:15:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 13:15:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 13:15:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-19 13:15:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 13:15:28 --> Final output sent to browser
DEBUG - 2018-06-19 13:15:28 --> Total execution time: 0.2428
INFO - 2018-06-19 13:16:27 --> Config Class Initialized
INFO - 2018-06-19 13:16:27 --> Hooks Class Initialized
DEBUG - 2018-06-19 13:16:27 --> UTF-8 Support Enabled
INFO - 2018-06-19 13:16:27 --> Utf8 Class Initialized
INFO - 2018-06-19 13:16:27 --> URI Class Initialized
DEBUG - 2018-06-19 13:16:27 --> No URI present. Default controller set.
INFO - 2018-06-19 13:16:27 --> Router Class Initialized
INFO - 2018-06-19 13:16:27 --> Output Class Initialized
INFO - 2018-06-19 13:16:27 --> Security Class Initialized
DEBUG - 2018-06-19 13:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 13:16:27 --> CSRF cookie sent
INFO - 2018-06-19 13:16:27 --> Input Class Initialized
INFO - 2018-06-19 13:16:27 --> Language Class Initialized
INFO - 2018-06-19 13:16:27 --> Loader Class Initialized
INFO - 2018-06-19 13:16:27 --> Helper loaded: url_helper
INFO - 2018-06-19 13:16:27 --> Helper loaded: form_helper
INFO - 2018-06-19 13:16:27 --> Helper loaded: language_helper
DEBUG - 2018-06-19 13:16:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 13:16:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 13:16:27 --> User Agent Class Initialized
INFO - 2018-06-19 13:16:27 --> Controller Class Initialized
INFO - 2018-06-19 13:16:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 13:16:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 13:16:27 --> Pixel_Model class loaded
INFO - 2018-06-19 13:16:27 --> Database Driver Class Initialized
INFO - 2018-06-19 13:16:27 --> Model "QuestionsModel" initialized
INFO - 2018-06-19 13:16:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 13:16:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 13:16:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-19 13:16:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 13:16:27 --> Final output sent to browser
DEBUG - 2018-06-19 13:16:27 --> Total execution time: 0.0531
INFO - 2018-06-19 13:16:32 --> Config Class Initialized
INFO - 2018-06-19 13:16:32 --> Hooks Class Initialized
DEBUG - 2018-06-19 13:16:32 --> UTF-8 Support Enabled
INFO - 2018-06-19 13:16:32 --> Utf8 Class Initialized
INFO - 2018-06-19 13:16:32 --> URI Class Initialized
DEBUG - 2018-06-19 13:16:32 --> No URI present. Default controller set.
INFO - 2018-06-19 13:16:32 --> Router Class Initialized
INFO - 2018-06-19 13:16:32 --> Output Class Initialized
INFO - 2018-06-19 13:16:32 --> Security Class Initialized
DEBUG - 2018-06-19 13:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 13:16:33 --> CSRF cookie sent
INFO - 2018-06-19 13:16:33 --> Input Class Initialized
INFO - 2018-06-19 13:16:33 --> Language Class Initialized
INFO - 2018-06-19 13:16:33 --> Loader Class Initialized
INFO - 2018-06-19 13:16:33 --> Helper loaded: url_helper
INFO - 2018-06-19 13:16:33 --> Helper loaded: form_helper
INFO - 2018-06-19 13:16:33 --> Helper loaded: language_helper
DEBUG - 2018-06-19 13:16:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 13:16:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 13:16:33 --> User Agent Class Initialized
INFO - 2018-06-19 13:16:33 --> Controller Class Initialized
INFO - 2018-06-19 13:16:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 13:16:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 13:16:33 --> Pixel_Model class loaded
INFO - 2018-06-19 13:16:33 --> Database Driver Class Initialized
INFO - 2018-06-19 13:16:33 --> Model "QuestionsModel" initialized
INFO - 2018-06-19 13:16:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 13:16:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 13:16:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-19 13:16:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 13:16:33 --> Final output sent to browser
DEBUG - 2018-06-19 13:16:33 --> Total execution time: 0.0520
INFO - 2018-06-19 13:17:42 --> Config Class Initialized
INFO - 2018-06-19 13:17:42 --> Hooks Class Initialized
DEBUG - 2018-06-19 13:17:42 --> UTF-8 Support Enabled
INFO - 2018-06-19 13:17:42 --> Utf8 Class Initialized
INFO - 2018-06-19 13:17:42 --> URI Class Initialized
DEBUG - 2018-06-19 13:17:42 --> No URI present. Default controller set.
INFO - 2018-06-19 13:17:42 --> Router Class Initialized
INFO - 2018-06-19 13:17:42 --> Output Class Initialized
INFO - 2018-06-19 13:17:42 --> Security Class Initialized
DEBUG - 2018-06-19 13:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 13:17:42 --> CSRF cookie sent
INFO - 2018-06-19 13:17:42 --> Input Class Initialized
INFO - 2018-06-19 13:17:42 --> Language Class Initialized
INFO - 2018-06-19 13:17:42 --> Loader Class Initialized
INFO - 2018-06-19 13:17:42 --> Helper loaded: url_helper
INFO - 2018-06-19 13:17:42 --> Helper loaded: form_helper
INFO - 2018-06-19 13:17:42 --> Helper loaded: language_helper
DEBUG - 2018-06-19 13:17:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 13:17:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 13:17:42 --> User Agent Class Initialized
INFO - 2018-06-19 13:17:42 --> Controller Class Initialized
INFO - 2018-06-19 13:17:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 13:17:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 13:17:42 --> Pixel_Model class loaded
INFO - 2018-06-19 13:17:42 --> Database Driver Class Initialized
INFO - 2018-06-19 13:17:42 --> Model "QuestionsModel" initialized
INFO - 2018-06-19 13:17:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 13:17:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 13:17:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-19 13:17:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 13:17:42 --> Final output sent to browser
DEBUG - 2018-06-19 13:17:42 --> Total execution time: 0.0850
INFO - 2018-06-19 13:17:48 --> Config Class Initialized
INFO - 2018-06-19 13:17:48 --> Hooks Class Initialized
DEBUG - 2018-06-19 13:17:48 --> UTF-8 Support Enabled
INFO - 2018-06-19 13:17:48 --> Utf8 Class Initialized
INFO - 2018-06-19 13:17:48 --> URI Class Initialized
DEBUG - 2018-06-19 13:17:48 --> No URI present. Default controller set.
INFO - 2018-06-19 13:17:48 --> Router Class Initialized
INFO - 2018-06-19 13:17:48 --> Output Class Initialized
INFO - 2018-06-19 13:17:48 --> Security Class Initialized
DEBUG - 2018-06-19 13:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 13:17:48 --> CSRF cookie sent
INFO - 2018-06-19 13:17:48 --> Input Class Initialized
INFO - 2018-06-19 13:17:48 --> Language Class Initialized
INFO - 2018-06-19 13:17:48 --> Loader Class Initialized
INFO - 2018-06-19 13:17:48 --> Helper loaded: url_helper
INFO - 2018-06-19 13:17:48 --> Helper loaded: form_helper
INFO - 2018-06-19 13:17:48 --> Helper loaded: language_helper
DEBUG - 2018-06-19 13:17:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 13:17:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 13:17:48 --> User Agent Class Initialized
INFO - 2018-06-19 13:17:48 --> Controller Class Initialized
INFO - 2018-06-19 13:17:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 13:17:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 13:17:48 --> Pixel_Model class loaded
INFO - 2018-06-19 13:17:48 --> Database Driver Class Initialized
INFO - 2018-06-19 13:17:48 --> Model "QuestionsModel" initialized
INFO - 2018-06-19 13:17:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 13:17:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 13:17:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-19 13:17:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 13:17:48 --> Final output sent to browser
DEBUG - 2018-06-19 13:17:48 --> Total execution time: 0.0523
INFO - 2018-06-19 13:17:50 --> Config Class Initialized
INFO - 2018-06-19 13:17:50 --> Hooks Class Initialized
DEBUG - 2018-06-19 13:17:50 --> UTF-8 Support Enabled
INFO - 2018-06-19 13:17:50 --> Utf8 Class Initialized
INFO - 2018-06-19 13:17:50 --> URI Class Initialized
DEBUG - 2018-06-19 13:17:50 --> No URI present. Default controller set.
INFO - 2018-06-19 13:17:50 --> Router Class Initialized
INFO - 2018-06-19 13:17:50 --> Output Class Initialized
INFO - 2018-06-19 13:17:50 --> Security Class Initialized
DEBUG - 2018-06-19 13:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 13:17:50 --> CSRF cookie sent
INFO - 2018-06-19 13:17:50 --> Input Class Initialized
INFO - 2018-06-19 13:17:50 --> Language Class Initialized
INFO - 2018-06-19 13:17:50 --> Loader Class Initialized
INFO - 2018-06-19 13:17:50 --> Helper loaded: url_helper
INFO - 2018-06-19 13:17:50 --> Helper loaded: form_helper
INFO - 2018-06-19 13:17:50 --> Helper loaded: language_helper
DEBUG - 2018-06-19 13:17:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 13:17:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 13:17:50 --> User Agent Class Initialized
INFO - 2018-06-19 13:17:50 --> Controller Class Initialized
INFO - 2018-06-19 13:17:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 13:17:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 13:17:50 --> Pixel_Model class loaded
INFO - 2018-06-19 13:17:50 --> Database Driver Class Initialized
INFO - 2018-06-19 13:17:50 --> Model "QuestionsModel" initialized
INFO - 2018-06-19 13:17:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 13:17:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 13:17:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-19 13:17:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 13:17:50 --> Final output sent to browser
DEBUG - 2018-06-19 13:17:50 --> Total execution time: 0.0492
INFO - 2018-06-19 13:18:00 --> Config Class Initialized
INFO - 2018-06-19 13:18:00 --> Hooks Class Initialized
DEBUG - 2018-06-19 13:18:00 --> UTF-8 Support Enabled
INFO - 2018-06-19 13:18:00 --> Utf8 Class Initialized
INFO - 2018-06-19 13:18:00 --> URI Class Initialized
DEBUG - 2018-06-19 13:18:00 --> No URI present. Default controller set.
INFO - 2018-06-19 13:18:00 --> Router Class Initialized
INFO - 2018-06-19 13:18:00 --> Output Class Initialized
INFO - 2018-06-19 13:18:00 --> Security Class Initialized
DEBUG - 2018-06-19 13:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 13:18:00 --> CSRF cookie sent
INFO - 2018-06-19 13:18:00 --> Input Class Initialized
INFO - 2018-06-19 13:18:00 --> Language Class Initialized
INFO - 2018-06-19 13:18:00 --> Loader Class Initialized
INFO - 2018-06-19 13:18:00 --> Helper loaded: url_helper
INFO - 2018-06-19 13:18:00 --> Helper loaded: form_helper
INFO - 2018-06-19 13:18:00 --> Helper loaded: language_helper
DEBUG - 2018-06-19 13:18:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 13:18:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 13:18:00 --> User Agent Class Initialized
INFO - 2018-06-19 13:18:00 --> Controller Class Initialized
INFO - 2018-06-19 13:18:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 13:18:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 13:18:00 --> Pixel_Model class loaded
INFO - 2018-06-19 13:18:00 --> Database Driver Class Initialized
INFO - 2018-06-19 13:18:00 --> Model "QuestionsModel" initialized
INFO - 2018-06-19 13:18:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 13:18:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 13:18:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-19 13:18:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 13:18:00 --> Final output sent to browser
DEBUG - 2018-06-19 13:18:00 --> Total execution time: 0.0878
INFO - 2018-06-19 13:18:09 --> Config Class Initialized
INFO - 2018-06-19 13:18:09 --> Hooks Class Initialized
DEBUG - 2018-06-19 13:18:09 --> UTF-8 Support Enabled
INFO - 2018-06-19 13:18:09 --> Utf8 Class Initialized
INFO - 2018-06-19 13:18:09 --> URI Class Initialized
INFO - 2018-06-19 13:18:09 --> Router Class Initialized
INFO - 2018-06-19 13:18:09 --> Output Class Initialized
INFO - 2018-06-19 13:18:09 --> Security Class Initialized
DEBUG - 2018-06-19 13:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 13:18:09 --> CSRF cookie sent
INFO - 2018-06-19 13:18:09 --> Input Class Initialized
INFO - 2018-06-19 13:18:09 --> Language Class Initialized
INFO - 2018-06-19 13:18:09 --> Loader Class Initialized
INFO - 2018-06-19 13:18:09 --> Helper loaded: url_helper
INFO - 2018-06-19 13:18:09 --> Helper loaded: form_helper
INFO - 2018-06-19 13:18:09 --> Helper loaded: language_helper
DEBUG - 2018-06-19 13:18:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 13:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 13:18:09 --> User Agent Class Initialized
INFO - 2018-06-19 13:18:09 --> Controller Class Initialized
INFO - 2018-06-19 13:18:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 13:18:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 13:18:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 13:18:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 13:18:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-19 13:18:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-19 13:18:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-06-19 13:18:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 13:18:09 --> Final output sent to browser
DEBUG - 2018-06-19 13:18:09 --> Total execution time: 0.0740
INFO - 2018-06-19 13:18:19 --> Config Class Initialized
INFO - 2018-06-19 13:18:19 --> Hooks Class Initialized
DEBUG - 2018-06-19 13:18:19 --> UTF-8 Support Enabled
INFO - 2018-06-19 13:18:19 --> Utf8 Class Initialized
INFO - 2018-06-19 13:18:19 --> URI Class Initialized
INFO - 2018-06-19 13:18:19 --> Router Class Initialized
INFO - 2018-06-19 13:18:19 --> Output Class Initialized
INFO - 2018-06-19 13:18:19 --> Security Class Initialized
DEBUG - 2018-06-19 13:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 13:18:19 --> CSRF cookie sent
INFO - 2018-06-19 13:18:19 --> Input Class Initialized
INFO - 2018-06-19 13:18:19 --> Language Class Initialized
INFO - 2018-06-19 13:18:19 --> Loader Class Initialized
INFO - 2018-06-19 13:18:19 --> Helper loaded: url_helper
INFO - 2018-06-19 13:18:19 --> Helper loaded: form_helper
INFO - 2018-06-19 13:18:19 --> Helper loaded: language_helper
DEBUG - 2018-06-19 13:18:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 13:18:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 13:18:19 --> User Agent Class Initialized
INFO - 2018-06-19 13:18:19 --> Controller Class Initialized
INFO - 2018-06-19 13:18:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 13:18:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 13:18:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 13:18:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 13:18:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-19 13:18:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-19 13:18:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-06-19 13:18:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 13:18:19 --> Final output sent to browser
DEBUG - 2018-06-19 13:18:19 --> Total execution time: 0.0693
INFO - 2018-06-19 13:18:21 --> Config Class Initialized
INFO - 2018-06-19 13:18:21 --> Hooks Class Initialized
DEBUG - 2018-06-19 13:18:21 --> UTF-8 Support Enabled
INFO - 2018-06-19 13:18:21 --> Utf8 Class Initialized
INFO - 2018-06-19 13:18:21 --> URI Class Initialized
DEBUG - 2018-06-19 13:18:21 --> No URI present. Default controller set.
INFO - 2018-06-19 13:18:21 --> Router Class Initialized
INFO - 2018-06-19 13:18:21 --> Output Class Initialized
INFO - 2018-06-19 13:18:21 --> Security Class Initialized
DEBUG - 2018-06-19 13:18:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 13:18:21 --> CSRF cookie sent
INFO - 2018-06-19 13:18:21 --> Input Class Initialized
INFO - 2018-06-19 13:18:21 --> Language Class Initialized
INFO - 2018-06-19 13:18:21 --> Loader Class Initialized
INFO - 2018-06-19 13:18:21 --> Helper loaded: url_helper
INFO - 2018-06-19 13:18:21 --> Helper loaded: form_helper
INFO - 2018-06-19 13:18:21 --> Helper loaded: language_helper
DEBUG - 2018-06-19 13:18:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 13:18:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 13:18:21 --> User Agent Class Initialized
INFO - 2018-06-19 13:18:21 --> Controller Class Initialized
INFO - 2018-06-19 13:18:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 13:18:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 13:18:21 --> Pixel_Model class loaded
INFO - 2018-06-19 13:18:21 --> Database Driver Class Initialized
INFO - 2018-06-19 13:18:21 --> Model "QuestionsModel" initialized
INFO - 2018-06-19 13:18:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 13:18:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 13:18:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-19 13:18:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 13:18:21 --> Final output sent to browser
DEBUG - 2018-06-19 13:18:21 --> Total execution time: 0.0598
INFO - 2018-06-19 13:18:54 --> Config Class Initialized
INFO - 2018-06-19 13:18:54 --> Hooks Class Initialized
DEBUG - 2018-06-19 13:18:54 --> UTF-8 Support Enabled
INFO - 2018-06-19 13:18:54 --> Utf8 Class Initialized
INFO - 2018-06-19 13:18:54 --> URI Class Initialized
DEBUG - 2018-06-19 13:18:54 --> No URI present. Default controller set.
INFO - 2018-06-19 13:18:54 --> Router Class Initialized
INFO - 2018-06-19 13:18:54 --> Output Class Initialized
INFO - 2018-06-19 13:18:54 --> Security Class Initialized
DEBUG - 2018-06-19 13:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 13:18:54 --> CSRF cookie sent
INFO - 2018-06-19 13:18:54 --> Input Class Initialized
INFO - 2018-06-19 13:18:54 --> Language Class Initialized
INFO - 2018-06-19 13:18:54 --> Loader Class Initialized
INFO - 2018-06-19 13:18:54 --> Helper loaded: url_helper
INFO - 2018-06-19 13:18:54 --> Helper loaded: form_helper
INFO - 2018-06-19 13:18:54 --> Helper loaded: language_helper
DEBUG - 2018-06-19 13:18:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 13:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 13:18:54 --> User Agent Class Initialized
INFO - 2018-06-19 13:18:54 --> Controller Class Initialized
INFO - 2018-06-19 13:18:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 13:18:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 13:18:54 --> Pixel_Model class loaded
INFO - 2018-06-19 13:18:54 --> Database Driver Class Initialized
INFO - 2018-06-19 13:18:54 --> Model "QuestionsModel" initialized
INFO - 2018-06-19 13:18:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 13:18:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 13:18:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-19 13:18:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 13:18:54 --> Final output sent to browser
DEBUG - 2018-06-19 13:18:54 --> Total execution time: 0.0676
INFO - 2018-06-19 13:19:29 --> Config Class Initialized
INFO - 2018-06-19 13:19:29 --> Hooks Class Initialized
DEBUG - 2018-06-19 13:19:29 --> UTF-8 Support Enabled
INFO - 2018-06-19 13:19:29 --> Utf8 Class Initialized
INFO - 2018-06-19 13:19:29 --> URI Class Initialized
INFO - 2018-06-19 13:19:29 --> Router Class Initialized
INFO - 2018-06-19 13:19:29 --> Output Class Initialized
INFO - 2018-06-19 13:19:29 --> Security Class Initialized
DEBUG - 2018-06-19 13:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 13:19:29 --> CSRF cookie sent
INFO - 2018-06-19 13:19:29 --> Input Class Initialized
INFO - 2018-06-19 13:19:29 --> Language Class Initialized
INFO - 2018-06-19 13:19:29 --> Loader Class Initialized
INFO - 2018-06-19 13:19:29 --> Helper loaded: url_helper
INFO - 2018-06-19 13:19:29 --> Helper loaded: form_helper
INFO - 2018-06-19 13:19:29 --> Helper loaded: language_helper
DEBUG - 2018-06-19 13:19:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 13:19:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 13:19:29 --> User Agent Class Initialized
INFO - 2018-06-19 13:19:29 --> Controller Class Initialized
INFO - 2018-06-19 13:19:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 13:19:29 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-19 13:19:29 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-19 13:19:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 13:19:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 13:19:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-19 13:19:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-19 13:19:29 --> Could not find the language line "req_email"
INFO - 2018-06-19 13:19:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-06-19 13:19:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 13:19:29 --> Final output sent to browser
DEBUG - 2018-06-19 13:19:29 --> Total execution time: 0.0543
INFO - 2018-06-19 13:35:56 --> Config Class Initialized
INFO - 2018-06-19 13:35:56 --> Hooks Class Initialized
DEBUG - 2018-06-19 13:35:56 --> UTF-8 Support Enabled
INFO - 2018-06-19 13:35:56 --> Utf8 Class Initialized
INFO - 2018-06-19 13:35:56 --> URI Class Initialized
DEBUG - 2018-06-19 13:35:56 --> No URI present. Default controller set.
INFO - 2018-06-19 13:35:56 --> Router Class Initialized
INFO - 2018-06-19 13:35:56 --> Output Class Initialized
INFO - 2018-06-19 13:35:56 --> Security Class Initialized
DEBUG - 2018-06-19 13:35:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 13:35:56 --> CSRF cookie sent
INFO - 2018-06-19 13:35:56 --> Input Class Initialized
INFO - 2018-06-19 13:35:56 --> Language Class Initialized
INFO - 2018-06-19 13:35:56 --> Loader Class Initialized
INFO - 2018-06-19 13:35:56 --> Helper loaded: url_helper
INFO - 2018-06-19 13:35:56 --> Helper loaded: form_helper
INFO - 2018-06-19 13:35:56 --> Helper loaded: language_helper
DEBUG - 2018-06-19 13:35:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 13:35:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 13:35:56 --> User Agent Class Initialized
INFO - 2018-06-19 13:35:56 --> Controller Class Initialized
INFO - 2018-06-19 13:35:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 13:35:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 13:35:56 --> Pixel_Model class loaded
INFO - 2018-06-19 13:35:56 --> Database Driver Class Initialized
INFO - 2018-06-19 13:35:56 --> Model "QuestionsModel" initialized
INFO - 2018-06-19 13:35:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 13:35:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 13:35:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-19 13:35:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 13:35:56 --> Final output sent to browser
DEBUG - 2018-06-19 13:35:56 --> Total execution time: 0.0767
INFO - 2018-06-19 13:36:15 --> Config Class Initialized
INFO - 2018-06-19 13:36:15 --> Hooks Class Initialized
DEBUG - 2018-06-19 13:36:15 --> UTF-8 Support Enabled
INFO - 2018-06-19 13:36:15 --> Utf8 Class Initialized
INFO - 2018-06-19 13:36:15 --> URI Class Initialized
INFO - 2018-06-19 13:36:15 --> Router Class Initialized
INFO - 2018-06-19 13:36:15 --> Output Class Initialized
INFO - 2018-06-19 13:36:15 --> Security Class Initialized
DEBUG - 2018-06-19 13:36:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 13:36:15 --> CSRF cookie sent
INFO - 2018-06-19 13:36:15 --> Input Class Initialized
INFO - 2018-06-19 13:36:15 --> Language Class Initialized
INFO - 2018-06-19 13:36:15 --> Loader Class Initialized
INFO - 2018-06-19 13:36:15 --> Helper loaded: url_helper
INFO - 2018-06-19 13:36:15 --> Helper loaded: form_helper
INFO - 2018-06-19 13:36:15 --> Helper loaded: language_helper
DEBUG - 2018-06-19 13:36:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 13:36:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 13:36:15 --> User Agent Class Initialized
INFO - 2018-06-19 13:36:15 --> Controller Class Initialized
INFO - 2018-06-19 13:36:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 13:36:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 13:36:15 --> Pixel_Model class loaded
INFO - 2018-06-19 13:36:15 --> Database Driver Class Initialized
INFO - 2018-06-19 13:36:15 --> Model "QuestionsModel" initialized
INFO - 2018-06-19 13:36:15 --> Config Class Initialized
INFO - 2018-06-19 13:36:15 --> Hooks Class Initialized
DEBUG - 2018-06-19 13:36:15 --> UTF-8 Support Enabled
INFO - 2018-06-19 13:36:15 --> Utf8 Class Initialized
INFO - 2018-06-19 13:36:15 --> URI Class Initialized
INFO - 2018-06-19 13:36:15 --> Router Class Initialized
INFO - 2018-06-19 13:36:15 --> Output Class Initialized
INFO - 2018-06-19 13:36:15 --> Security Class Initialized
DEBUG - 2018-06-19 13:36:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 13:36:15 --> CSRF cookie sent
INFO - 2018-06-19 13:36:15 --> Input Class Initialized
INFO - 2018-06-19 13:36:15 --> Language Class Initialized
INFO - 2018-06-19 13:36:15 --> Loader Class Initialized
INFO - 2018-06-19 13:36:15 --> Helper loaded: url_helper
INFO - 2018-06-19 13:36:15 --> Helper loaded: form_helper
INFO - 2018-06-19 13:36:15 --> Helper loaded: language_helper
DEBUG - 2018-06-19 13:36:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 13:36:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 13:36:15 --> User Agent Class Initialized
INFO - 2018-06-19 13:36:15 --> Controller Class Initialized
INFO - 2018-06-19 13:36:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 13:36:15 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-19 13:36:15 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-19 13:36:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 13:36:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 13:36:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-19 13:36:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-19 13:36:15 --> Could not find the language line "req_email"
INFO - 2018-06-19 13:36:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-06-19 13:36:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 13:36:15 --> Final output sent to browser
DEBUG - 2018-06-19 13:36:15 --> Total execution time: 0.0553
INFO - 2018-06-19 13:36:19 --> Config Class Initialized
INFO - 2018-06-19 13:36:19 --> Hooks Class Initialized
DEBUG - 2018-06-19 13:36:19 --> UTF-8 Support Enabled
INFO - 2018-06-19 13:36:19 --> Utf8 Class Initialized
INFO - 2018-06-19 13:36:19 --> URI Class Initialized
DEBUG - 2018-06-19 13:36:19 --> No URI present. Default controller set.
INFO - 2018-06-19 13:36:19 --> Router Class Initialized
INFO - 2018-06-19 13:36:19 --> Output Class Initialized
INFO - 2018-06-19 13:36:19 --> Security Class Initialized
DEBUG - 2018-06-19 13:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 13:36:19 --> CSRF cookie sent
INFO - 2018-06-19 13:36:19 --> Input Class Initialized
INFO - 2018-06-19 13:36:19 --> Language Class Initialized
INFO - 2018-06-19 13:36:19 --> Loader Class Initialized
INFO - 2018-06-19 13:36:19 --> Helper loaded: url_helper
INFO - 2018-06-19 13:36:19 --> Helper loaded: form_helper
INFO - 2018-06-19 13:36:19 --> Helper loaded: language_helper
DEBUG - 2018-06-19 13:36:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 13:36:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 13:36:19 --> User Agent Class Initialized
INFO - 2018-06-19 13:36:19 --> Controller Class Initialized
INFO - 2018-06-19 13:36:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 13:36:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 13:36:19 --> Pixel_Model class loaded
INFO - 2018-06-19 13:36:19 --> Database Driver Class Initialized
INFO - 2018-06-19 13:36:19 --> Model "QuestionsModel" initialized
INFO - 2018-06-19 13:36:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 13:36:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 13:36:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-19 13:36:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 13:36:19 --> Final output sent to browser
DEBUG - 2018-06-19 13:36:19 --> Total execution time: 0.0727
INFO - 2018-06-19 15:02:15 --> Config Class Initialized
INFO - 2018-06-19 15:02:15 --> Hooks Class Initialized
DEBUG - 2018-06-19 15:02:15 --> UTF-8 Support Enabled
INFO - 2018-06-19 15:02:15 --> Utf8 Class Initialized
INFO - 2018-06-19 15:02:15 --> URI Class Initialized
DEBUG - 2018-06-19 15:02:15 --> No URI present. Default controller set.
INFO - 2018-06-19 15:02:15 --> Router Class Initialized
INFO - 2018-06-19 15:02:15 --> Output Class Initialized
INFO - 2018-06-19 15:02:15 --> Security Class Initialized
DEBUG - 2018-06-19 15:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 15:02:15 --> CSRF cookie sent
INFO - 2018-06-19 15:02:15 --> Input Class Initialized
INFO - 2018-06-19 15:02:15 --> Language Class Initialized
INFO - 2018-06-19 15:02:15 --> Loader Class Initialized
INFO - 2018-06-19 15:02:15 --> Helper loaded: url_helper
INFO - 2018-06-19 15:02:15 --> Helper loaded: form_helper
INFO - 2018-06-19 15:02:15 --> Helper loaded: language_helper
DEBUG - 2018-06-19 15:02:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 15:02:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 15:02:15 --> User Agent Class Initialized
INFO - 2018-06-19 15:02:15 --> Controller Class Initialized
INFO - 2018-06-19 15:02:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 15:02:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 15:02:15 --> Pixel_Model class loaded
INFO - 2018-06-19 15:02:15 --> Database Driver Class Initialized
INFO - 2018-06-19 15:02:15 --> Model "QuestionsModel" initialized
INFO - 2018-06-19 15:02:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 15:02:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 15:02:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-19 15:02:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 15:02:15 --> Final output sent to browser
DEBUG - 2018-06-19 15:02:15 --> Total execution time: 0.0769
INFO - 2018-06-19 15:05:37 --> Config Class Initialized
INFO - 2018-06-19 15:05:37 --> Hooks Class Initialized
DEBUG - 2018-06-19 15:05:37 --> UTF-8 Support Enabled
INFO - 2018-06-19 15:05:37 --> Utf8 Class Initialized
INFO - 2018-06-19 15:05:37 --> URI Class Initialized
DEBUG - 2018-06-19 15:05:37 --> No URI present. Default controller set.
INFO - 2018-06-19 15:05:37 --> Router Class Initialized
INFO - 2018-06-19 15:05:37 --> Output Class Initialized
INFO - 2018-06-19 15:05:37 --> Security Class Initialized
DEBUG - 2018-06-19 15:05:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 15:05:37 --> CSRF cookie sent
INFO - 2018-06-19 15:05:37 --> Input Class Initialized
INFO - 2018-06-19 15:05:37 --> Language Class Initialized
INFO - 2018-06-19 15:05:37 --> Loader Class Initialized
INFO - 2018-06-19 15:05:37 --> Helper loaded: url_helper
INFO - 2018-06-19 15:05:37 --> Helper loaded: form_helper
INFO - 2018-06-19 15:05:37 --> Helper loaded: language_helper
DEBUG - 2018-06-19 15:05:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 15:05:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 15:05:37 --> User Agent Class Initialized
INFO - 2018-06-19 15:05:37 --> Controller Class Initialized
INFO - 2018-06-19 15:05:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 15:05:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 15:05:37 --> Pixel_Model class loaded
INFO - 2018-06-19 15:05:37 --> Database Driver Class Initialized
INFO - 2018-06-19 15:05:37 --> Model "QuestionsModel" initialized
INFO - 2018-06-19 15:05:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 15:05:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 15:05:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-19 15:05:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 15:05:37 --> Final output sent to browser
DEBUG - 2018-06-19 15:05:37 --> Total execution time: 0.0635
INFO - 2018-06-19 15:15:06 --> Config Class Initialized
INFO - 2018-06-19 15:15:06 --> Hooks Class Initialized
DEBUG - 2018-06-19 15:15:06 --> UTF-8 Support Enabled
INFO - 2018-06-19 15:15:06 --> Utf8 Class Initialized
INFO - 2018-06-19 15:15:06 --> URI Class Initialized
INFO - 2018-06-19 15:15:06 --> Router Class Initialized
INFO - 2018-06-19 15:15:06 --> Output Class Initialized
INFO - 2018-06-19 15:15:06 --> Security Class Initialized
DEBUG - 2018-06-19 15:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 15:15:06 --> CSRF cookie sent
INFO - 2018-06-19 15:15:06 --> Input Class Initialized
INFO - 2018-06-19 15:15:06 --> Language Class Initialized
ERROR - 2018-06-19 15:15:06 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-06-19 16:41:08 --> Config Class Initialized
INFO - 2018-06-19 16:41:08 --> Hooks Class Initialized
DEBUG - 2018-06-19 16:41:08 --> UTF-8 Support Enabled
INFO - 2018-06-19 16:41:08 --> Utf8 Class Initialized
INFO - 2018-06-19 16:41:08 --> URI Class Initialized
DEBUG - 2018-06-19 16:41:08 --> No URI present. Default controller set.
INFO - 2018-06-19 16:41:08 --> Router Class Initialized
INFO - 2018-06-19 16:41:08 --> Output Class Initialized
INFO - 2018-06-19 16:41:08 --> Security Class Initialized
DEBUG - 2018-06-19 16:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 16:41:08 --> CSRF cookie sent
INFO - 2018-06-19 16:41:08 --> Input Class Initialized
INFO - 2018-06-19 16:41:08 --> Language Class Initialized
INFO - 2018-06-19 16:41:08 --> Loader Class Initialized
INFO - 2018-06-19 16:41:08 --> Helper loaded: url_helper
INFO - 2018-06-19 16:41:08 --> Helper loaded: form_helper
INFO - 2018-06-19 16:41:08 --> Helper loaded: language_helper
DEBUG - 2018-06-19 16:41:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 16:41:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 16:41:08 --> User Agent Class Initialized
INFO - 2018-06-19 16:41:08 --> Controller Class Initialized
INFO - 2018-06-19 16:41:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 16:41:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 16:41:08 --> Pixel_Model class loaded
INFO - 2018-06-19 16:41:08 --> Database Driver Class Initialized
INFO - 2018-06-19 16:41:08 --> Model "QuestionsModel" initialized
INFO - 2018-06-19 16:41:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 16:41:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 16:41:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-19 16:41:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 16:41:08 --> Final output sent to browser
DEBUG - 2018-06-19 16:41:08 --> Total execution time: 0.0570
INFO - 2018-06-19 16:58:11 --> Config Class Initialized
INFO - 2018-06-19 16:58:11 --> Hooks Class Initialized
DEBUG - 2018-06-19 16:58:11 --> UTF-8 Support Enabled
INFO - 2018-06-19 16:58:11 --> Utf8 Class Initialized
INFO - 2018-06-19 16:58:11 --> URI Class Initialized
DEBUG - 2018-06-19 16:58:11 --> No URI present. Default controller set.
INFO - 2018-06-19 16:58:11 --> Router Class Initialized
INFO - 2018-06-19 16:58:11 --> Output Class Initialized
INFO - 2018-06-19 16:58:11 --> Security Class Initialized
DEBUG - 2018-06-19 16:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 16:58:11 --> CSRF cookie sent
INFO - 2018-06-19 16:58:11 --> Input Class Initialized
INFO - 2018-06-19 16:58:11 --> Language Class Initialized
INFO - 2018-06-19 16:58:11 --> Loader Class Initialized
INFO - 2018-06-19 16:58:11 --> Helper loaded: url_helper
INFO - 2018-06-19 16:58:11 --> Helper loaded: form_helper
INFO - 2018-06-19 16:58:11 --> Helper loaded: language_helper
DEBUG - 2018-06-19 16:58:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 16:58:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 16:58:11 --> User Agent Class Initialized
INFO - 2018-06-19 16:58:11 --> Controller Class Initialized
INFO - 2018-06-19 16:58:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 16:58:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 16:58:11 --> Pixel_Model class loaded
INFO - 2018-06-19 16:58:11 --> Database Driver Class Initialized
INFO - 2018-06-19 16:58:12 --> Model "QuestionsModel" initialized
INFO - 2018-06-19 16:58:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 16:58:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 16:58:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-19 16:58:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 16:58:12 --> Final output sent to browser
DEBUG - 2018-06-19 16:58:12 --> Total execution time: 0.0678
INFO - 2018-06-19 16:58:12 --> Config Class Initialized
INFO - 2018-06-19 16:58:12 --> Hooks Class Initialized
DEBUG - 2018-06-19 16:58:12 --> UTF-8 Support Enabled
INFO - 2018-06-19 16:58:12 --> Utf8 Class Initialized
INFO - 2018-06-19 16:58:12 --> URI Class Initialized
DEBUG - 2018-06-19 16:58:12 --> No URI present. Default controller set.
INFO - 2018-06-19 16:58:12 --> Router Class Initialized
INFO - 2018-06-19 16:58:12 --> Output Class Initialized
INFO - 2018-06-19 16:58:12 --> Security Class Initialized
DEBUG - 2018-06-19 16:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 16:58:12 --> CSRF cookie sent
INFO - 2018-06-19 16:58:12 --> Input Class Initialized
INFO - 2018-06-19 16:58:12 --> Language Class Initialized
INFO - 2018-06-19 16:58:12 --> Loader Class Initialized
INFO - 2018-06-19 16:58:12 --> Helper loaded: url_helper
INFO - 2018-06-19 16:58:12 --> Helper loaded: form_helper
INFO - 2018-06-19 16:58:12 --> Helper loaded: language_helper
DEBUG - 2018-06-19 16:58:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 16:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 16:58:12 --> User Agent Class Initialized
INFO - 2018-06-19 16:58:12 --> Controller Class Initialized
INFO - 2018-06-19 16:58:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 16:58:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 16:58:12 --> Pixel_Model class loaded
INFO - 2018-06-19 16:58:12 --> Database Driver Class Initialized
INFO - 2018-06-19 16:58:12 --> Model "QuestionsModel" initialized
INFO - 2018-06-19 16:58:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 16:58:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 16:58:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-19 16:58:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 16:58:12 --> Final output sent to browser
DEBUG - 2018-06-19 16:58:12 --> Total execution time: 0.0609
INFO - 2018-06-19 16:58:13 --> Config Class Initialized
INFO - 2018-06-19 16:58:13 --> Hooks Class Initialized
DEBUG - 2018-06-19 16:58:13 --> UTF-8 Support Enabled
INFO - 2018-06-19 16:58:13 --> Utf8 Class Initialized
INFO - 2018-06-19 16:58:13 --> URI Class Initialized
DEBUG - 2018-06-19 16:58:13 --> No URI present. Default controller set.
INFO - 2018-06-19 16:58:13 --> Router Class Initialized
INFO - 2018-06-19 16:58:13 --> Output Class Initialized
INFO - 2018-06-19 16:58:13 --> Security Class Initialized
DEBUG - 2018-06-19 16:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 16:58:13 --> CSRF cookie sent
INFO - 2018-06-19 16:58:13 --> Input Class Initialized
INFO - 2018-06-19 16:58:13 --> Language Class Initialized
INFO - 2018-06-19 16:58:13 --> Loader Class Initialized
INFO - 2018-06-19 16:58:13 --> Helper loaded: url_helper
INFO - 2018-06-19 16:58:13 --> Helper loaded: form_helper
INFO - 2018-06-19 16:58:13 --> Helper loaded: language_helper
DEBUG - 2018-06-19 16:58:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 16:58:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 16:58:13 --> User Agent Class Initialized
INFO - 2018-06-19 16:58:13 --> Controller Class Initialized
INFO - 2018-06-19 16:58:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 16:58:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 16:58:13 --> Pixel_Model class loaded
INFO - 2018-06-19 16:58:13 --> Database Driver Class Initialized
INFO - 2018-06-19 16:58:13 --> Model "QuestionsModel" initialized
INFO - 2018-06-19 16:58:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 16:58:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 16:58:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-19 16:58:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 16:58:13 --> Final output sent to browser
DEBUG - 2018-06-19 16:58:13 --> Total execution time: 0.0608
INFO - 2018-06-19 16:58:14 --> Config Class Initialized
INFO - 2018-06-19 16:58:14 --> Hooks Class Initialized
DEBUG - 2018-06-19 16:58:14 --> UTF-8 Support Enabled
INFO - 2018-06-19 16:58:14 --> Utf8 Class Initialized
INFO - 2018-06-19 16:58:14 --> URI Class Initialized
INFO - 2018-06-19 16:58:14 --> Router Class Initialized
INFO - 2018-06-19 16:58:14 --> Output Class Initialized
INFO - 2018-06-19 16:58:14 --> Security Class Initialized
DEBUG - 2018-06-19 16:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 16:58:14 --> CSRF cookie sent
INFO - 2018-06-19 16:58:14 --> Input Class Initialized
INFO - 2018-06-19 16:58:14 --> Language Class Initialized
ERROR - 2018-06-19 16:58:14 --> 404 Page Not Found: 405shtml/index
INFO - 2018-06-19 16:58:20 --> Config Class Initialized
INFO - 2018-06-19 16:58:20 --> Hooks Class Initialized
DEBUG - 2018-06-19 16:58:20 --> UTF-8 Support Enabled
INFO - 2018-06-19 16:58:20 --> Utf8 Class Initialized
INFO - 2018-06-19 16:58:20 --> URI Class Initialized
DEBUG - 2018-06-19 16:58:20 --> No URI present. Default controller set.
INFO - 2018-06-19 16:58:20 --> Router Class Initialized
INFO - 2018-06-19 16:58:20 --> Output Class Initialized
INFO - 2018-06-19 16:58:20 --> Security Class Initialized
DEBUG - 2018-06-19 16:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 16:58:20 --> CSRF cookie sent
INFO - 2018-06-19 16:58:20 --> Input Class Initialized
INFO - 2018-06-19 16:58:20 --> Language Class Initialized
INFO - 2018-06-19 16:58:20 --> Loader Class Initialized
INFO - 2018-06-19 16:58:20 --> Helper loaded: url_helper
INFO - 2018-06-19 16:58:20 --> Helper loaded: form_helper
INFO - 2018-06-19 16:58:20 --> Helper loaded: language_helper
DEBUG - 2018-06-19 16:58:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 16:58:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 16:58:20 --> User Agent Class Initialized
INFO - 2018-06-19 16:58:20 --> Controller Class Initialized
INFO - 2018-06-19 16:58:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 16:58:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 16:58:20 --> Pixel_Model class loaded
INFO - 2018-06-19 16:58:20 --> Database Driver Class Initialized
INFO - 2018-06-19 16:58:20 --> Model "QuestionsModel" initialized
INFO - 2018-06-19 16:58:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 16:58:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 16:58:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-19 16:58:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 16:58:20 --> Final output sent to browser
DEBUG - 2018-06-19 16:58:20 --> Total execution time: 0.0568
INFO - 2018-06-19 16:58:20 --> Config Class Initialized
INFO - 2018-06-19 16:58:20 --> Hooks Class Initialized
DEBUG - 2018-06-19 16:58:20 --> UTF-8 Support Enabled
INFO - 2018-06-19 16:58:20 --> Utf8 Class Initialized
INFO - 2018-06-19 16:58:20 --> URI Class Initialized
INFO - 2018-06-19 16:58:20 --> Router Class Initialized
INFO - 2018-06-19 16:58:20 --> Output Class Initialized
INFO - 2018-06-19 16:58:20 --> Security Class Initialized
DEBUG - 2018-06-19 16:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 16:58:20 --> CSRF cookie sent
INFO - 2018-06-19 16:58:20 --> Input Class Initialized
INFO - 2018-06-19 16:58:20 --> Language Class Initialized
ERROR - 2018-06-19 16:58:20 --> 404 Page Not Found: 404testpage4525d2fdc/index
INFO - 2018-06-19 16:58:21 --> Config Class Initialized
INFO - 2018-06-19 16:58:21 --> Hooks Class Initialized
DEBUG - 2018-06-19 16:58:21 --> UTF-8 Support Enabled
INFO - 2018-06-19 16:58:21 --> Utf8 Class Initialized
INFO - 2018-06-19 16:58:21 --> URI Class Initialized
INFO - 2018-06-19 16:58:21 --> Router Class Initialized
INFO - 2018-06-19 16:58:21 --> Output Class Initialized
INFO - 2018-06-19 16:58:21 --> Security Class Initialized
DEBUG - 2018-06-19 16:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 16:58:21 --> CSRF cookie sent
INFO - 2018-06-19 16:58:21 --> Input Class Initialized
INFO - 2018-06-19 16:58:21 --> Language Class Initialized
ERROR - 2018-06-19 16:58:21 --> 404 Page Not Found: 404javascriptjs/index
INFO - 2018-06-19 16:58:21 --> Config Class Initialized
INFO - 2018-06-19 16:58:21 --> Hooks Class Initialized
DEBUG - 2018-06-19 16:58:21 --> UTF-8 Support Enabled
INFO - 2018-06-19 16:58:21 --> Utf8 Class Initialized
INFO - 2018-06-19 16:58:21 --> URI Class Initialized
INFO - 2018-06-19 16:58:21 --> Router Class Initialized
INFO - 2018-06-19 16:58:21 --> Output Class Initialized
INFO - 2018-06-19 16:58:21 --> Security Class Initialized
DEBUG - 2018-06-19 16:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 16:58:21 --> CSRF cookie sent
INFO - 2018-06-19 16:58:21 --> Input Class Initialized
INFO - 2018-06-19 16:58:21 --> Language Class Initialized
INFO - 2018-06-19 16:58:21 --> Loader Class Initialized
INFO - 2018-06-19 16:58:21 --> Helper loaded: url_helper
INFO - 2018-06-19 16:58:21 --> Helper loaded: form_helper
INFO - 2018-06-19 16:58:21 --> Helper loaded: language_helper
DEBUG - 2018-06-19 16:58:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 16:58:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 16:58:21 --> User Agent Class Initialized
INFO - 2018-06-19 16:58:21 --> Controller Class Initialized
INFO - 2018-06-19 16:58:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 16:58:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 16:58:21 --> Pixel_Model class loaded
INFO - 2018-06-19 16:58:21 --> Database Driver Class Initialized
INFO - 2018-06-19 16:58:21 --> Model "QuestionsModel" initialized
ERROR - 2018-06-19 16:58:21 --> Severity: Notice --> Undefined index: HTTP_REFERER /home/fxp6bn7rqemh/public_html/application/core/Pixel_Controller.php 87
INFO - 2018-06-19 16:58:21 --> Config Class Initialized
INFO - 2018-06-19 16:58:21 --> Hooks Class Initialized
DEBUG - 2018-06-19 16:58:21 --> UTF-8 Support Enabled
INFO - 2018-06-19 16:58:21 --> Utf8 Class Initialized
INFO - 2018-06-19 16:58:21 --> URI Class Initialized
INFO - 2018-06-19 16:58:21 --> Router Class Initialized
INFO - 2018-06-19 16:58:21 --> Output Class Initialized
INFO - 2018-06-19 16:58:21 --> Security Class Initialized
DEBUG - 2018-06-19 16:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 16:58:21 --> CSRF cookie sent
INFO - 2018-06-19 16:58:21 --> Input Class Initialized
INFO - 2018-06-19 16:58:21 --> Language Class Initialized
INFO - 2018-06-19 16:58:21 --> Loader Class Initialized
INFO - 2018-06-19 16:58:21 --> Helper loaded: url_helper
INFO - 2018-06-19 16:58:21 --> Helper loaded: form_helper
INFO - 2018-06-19 16:58:21 --> Helper loaded: language_helper
DEBUG - 2018-06-19 16:58:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 16:58:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 16:58:21 --> User Agent Class Initialized
INFO - 2018-06-19 16:58:21 --> Controller Class Initialized
INFO - 2018-06-19 16:58:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 16:58:21 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-19 16:58:21 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-19 16:58:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 16:58:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 16:58:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-19 16:58:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-19 16:58:21 --> Could not find the language line "req_email"
INFO - 2018-06-19 16:58:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-06-19 16:58:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 16:58:21 --> Final output sent to browser
DEBUG - 2018-06-19 16:58:21 --> Total execution time: 0.0525
INFO - 2018-06-19 16:58:22 --> Config Class Initialized
INFO - 2018-06-19 16:58:22 --> Hooks Class Initialized
DEBUG - 2018-06-19 16:58:22 --> UTF-8 Support Enabled
INFO - 2018-06-19 16:58:22 --> Utf8 Class Initialized
INFO - 2018-06-19 16:58:22 --> URI Class Initialized
INFO - 2018-06-19 16:58:22 --> Router Class Initialized
INFO - 2018-06-19 16:58:22 --> Output Class Initialized
INFO - 2018-06-19 16:58:22 --> Security Class Initialized
DEBUG - 2018-06-19 16:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 16:58:22 --> CSRF cookie sent
INFO - 2018-06-19 16:58:22 --> Input Class Initialized
INFO - 2018-06-19 16:58:22 --> Language Class Initialized
INFO - 2018-06-19 16:58:22 --> Loader Class Initialized
INFO - 2018-06-19 16:58:22 --> Helper loaded: url_helper
INFO - 2018-06-19 16:58:22 --> Helper loaded: form_helper
INFO - 2018-06-19 16:58:22 --> Helper loaded: language_helper
DEBUG - 2018-06-19 16:58:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 16:58:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 16:58:22 --> User Agent Class Initialized
INFO - 2018-06-19 16:58:22 --> Controller Class Initialized
INFO - 2018-06-19 16:58:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 16:58:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 16:58:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 16:58:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 16:58:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-19 16:58:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-19 16:58:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-06-19 16:58:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 16:58:22 --> Final output sent to browser
DEBUG - 2018-06-19 16:58:22 --> Total execution time: 0.0344
INFO - 2018-06-19 16:58:22 --> Config Class Initialized
INFO - 2018-06-19 16:58:22 --> Hooks Class Initialized
DEBUG - 2018-06-19 16:58:22 --> UTF-8 Support Enabled
INFO - 2018-06-19 16:58:22 --> Utf8 Class Initialized
INFO - 2018-06-19 16:58:22 --> URI Class Initialized
INFO - 2018-06-19 16:58:22 --> Router Class Initialized
INFO - 2018-06-19 16:58:22 --> Output Class Initialized
INFO - 2018-06-19 16:58:22 --> Security Class Initialized
DEBUG - 2018-06-19 16:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 16:58:22 --> CSRF cookie sent
INFO - 2018-06-19 16:58:22 --> Input Class Initialized
INFO - 2018-06-19 16:58:22 --> Language Class Initialized
INFO - 2018-06-19 16:58:22 --> Loader Class Initialized
INFO - 2018-06-19 16:58:22 --> Helper loaded: url_helper
INFO - 2018-06-19 16:58:22 --> Helper loaded: form_helper
INFO - 2018-06-19 16:58:22 --> Helper loaded: language_helper
DEBUG - 2018-06-19 16:58:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 16:58:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 16:58:22 --> User Agent Class Initialized
INFO - 2018-06-19 16:58:22 --> Controller Class Initialized
INFO - 2018-06-19 16:58:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 16:58:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 16:58:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 16:58:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 16:58:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-19 16:58:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-19 16:58:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-06-19 16:58:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 16:58:22 --> Final output sent to browser
DEBUG - 2018-06-19 16:58:22 --> Total execution time: 0.0541
INFO - 2018-06-19 16:58:22 --> Config Class Initialized
INFO - 2018-06-19 16:58:22 --> Hooks Class Initialized
DEBUG - 2018-06-19 16:58:22 --> UTF-8 Support Enabled
INFO - 2018-06-19 16:58:22 --> Utf8 Class Initialized
INFO - 2018-06-19 16:58:22 --> URI Class Initialized
INFO - 2018-06-19 16:58:22 --> Router Class Initialized
INFO - 2018-06-19 16:58:22 --> Output Class Initialized
INFO - 2018-06-19 16:58:22 --> Security Class Initialized
DEBUG - 2018-06-19 16:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 16:58:22 --> CSRF cookie sent
INFO - 2018-06-19 16:58:22 --> Input Class Initialized
INFO - 2018-06-19 16:58:22 --> Language Class Initialized
INFO - 2018-06-19 16:58:22 --> Loader Class Initialized
INFO - 2018-06-19 16:58:22 --> Helper loaded: url_helper
INFO - 2018-06-19 16:58:22 --> Helper loaded: form_helper
INFO - 2018-06-19 16:58:22 --> Helper loaded: language_helper
DEBUG - 2018-06-19 16:58:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 16:58:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 16:58:22 --> User Agent Class Initialized
INFO - 2018-06-19 16:58:22 --> Controller Class Initialized
INFO - 2018-06-19 16:58:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 16:58:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 16:58:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 16:58:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 16:58:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-19 16:58:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-19 16:58:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-06-19 16:58:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 16:58:22 --> Final output sent to browser
DEBUG - 2018-06-19 16:58:22 --> Total execution time: 0.0394
INFO - 2018-06-19 16:58:23 --> Config Class Initialized
INFO - 2018-06-19 16:58:23 --> Hooks Class Initialized
DEBUG - 2018-06-19 16:58:23 --> UTF-8 Support Enabled
INFO - 2018-06-19 16:58:23 --> Utf8 Class Initialized
INFO - 2018-06-19 16:58:23 --> URI Class Initialized
INFO - 2018-06-19 16:58:23 --> Router Class Initialized
INFO - 2018-06-19 16:58:23 --> Output Class Initialized
INFO - 2018-06-19 16:58:23 --> Security Class Initialized
DEBUG - 2018-06-19 16:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 16:58:23 --> CSRF cookie sent
INFO - 2018-06-19 16:58:23 --> Input Class Initialized
INFO - 2018-06-19 16:58:23 --> Language Class Initialized
INFO - 2018-06-19 16:58:23 --> Loader Class Initialized
INFO - 2018-06-19 16:58:23 --> Helper loaded: url_helper
INFO - 2018-06-19 16:58:23 --> Helper loaded: form_helper
INFO - 2018-06-19 16:58:23 --> Helper loaded: language_helper
DEBUG - 2018-06-19 16:58:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 16:58:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 16:58:23 --> User Agent Class Initialized
INFO - 2018-06-19 16:58:23 --> Controller Class Initialized
INFO - 2018-06-19 16:58:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 16:58:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 16:58:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 16:58:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 16:58:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-19 16:58:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-19 16:58:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-06-19 16:58:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 16:58:23 --> Final output sent to browser
DEBUG - 2018-06-19 16:58:23 --> Total execution time: 0.0500
INFO - 2018-06-19 16:58:23 --> Config Class Initialized
INFO - 2018-06-19 16:58:23 --> Hooks Class Initialized
DEBUG - 2018-06-19 16:58:23 --> UTF-8 Support Enabled
INFO - 2018-06-19 16:58:23 --> Utf8 Class Initialized
INFO - 2018-06-19 16:58:23 --> URI Class Initialized
INFO - 2018-06-19 16:58:23 --> Router Class Initialized
INFO - 2018-06-19 16:58:23 --> Output Class Initialized
INFO - 2018-06-19 16:58:23 --> Security Class Initialized
DEBUG - 2018-06-19 16:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 16:58:23 --> CSRF cookie sent
INFO - 2018-06-19 16:58:23 --> Input Class Initialized
INFO - 2018-06-19 16:58:23 --> Language Class Initialized
INFO - 2018-06-19 16:58:23 --> Loader Class Initialized
INFO - 2018-06-19 16:58:23 --> Helper loaded: url_helper
INFO - 2018-06-19 16:58:23 --> Helper loaded: form_helper
INFO - 2018-06-19 16:58:23 --> Helper loaded: language_helper
DEBUG - 2018-06-19 16:58:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 16:58:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 16:58:23 --> User Agent Class Initialized
INFO - 2018-06-19 16:58:23 --> Controller Class Initialized
INFO - 2018-06-19 16:58:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 16:58:23 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-19 16:58:23 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-19 16:58:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 16:58:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 16:58:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-19 16:58:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-19 16:58:23 --> Could not find the language line "req_email"
INFO - 2018-06-19 16:58:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-06-19 16:58:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 16:58:23 --> Final output sent to browser
DEBUG - 2018-06-19 16:58:23 --> Total execution time: 0.0416
INFO - 2018-06-19 16:58:24 --> Config Class Initialized
INFO - 2018-06-19 16:58:24 --> Hooks Class Initialized
DEBUG - 2018-06-19 16:58:24 --> UTF-8 Support Enabled
INFO - 2018-06-19 16:58:24 --> Utf8 Class Initialized
INFO - 2018-06-19 16:58:24 --> URI Class Initialized
INFO - 2018-06-19 16:58:24 --> Router Class Initialized
INFO - 2018-06-19 16:58:24 --> Output Class Initialized
INFO - 2018-06-19 16:58:24 --> Security Class Initialized
DEBUG - 2018-06-19 16:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 16:58:24 --> CSRF cookie sent
INFO - 2018-06-19 16:58:24 --> Input Class Initialized
INFO - 2018-06-19 16:58:24 --> Language Class Initialized
INFO - 2018-06-19 16:58:24 --> Loader Class Initialized
INFO - 2018-06-19 16:58:24 --> Helper loaded: url_helper
INFO - 2018-06-19 16:58:24 --> Helper loaded: form_helper
INFO - 2018-06-19 16:58:24 --> Helper loaded: language_helper
DEBUG - 2018-06-19 16:58:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 16:58:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 16:58:24 --> User Agent Class Initialized
INFO - 2018-06-19 16:58:24 --> Controller Class Initialized
INFO - 2018-06-19 16:58:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 16:58:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 16:58:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 16:58:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 16:58:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-19 16:58:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-19 16:58:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/buy_gift.php
INFO - 2018-06-19 16:58:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 16:58:24 --> Final output sent to browser
DEBUG - 2018-06-19 16:58:24 --> Total execution time: 0.0431
INFO - 2018-06-19 19:39:41 --> Config Class Initialized
INFO - 2018-06-19 19:39:41 --> Hooks Class Initialized
DEBUG - 2018-06-19 19:39:41 --> UTF-8 Support Enabled
INFO - 2018-06-19 19:39:41 --> Utf8 Class Initialized
INFO - 2018-06-19 19:39:41 --> URI Class Initialized
DEBUG - 2018-06-19 19:39:41 --> No URI present. Default controller set.
INFO - 2018-06-19 19:39:41 --> Router Class Initialized
INFO - 2018-06-19 19:39:41 --> Output Class Initialized
INFO - 2018-06-19 19:39:41 --> Security Class Initialized
DEBUG - 2018-06-19 19:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 19:39:41 --> CSRF cookie sent
INFO - 2018-06-19 19:39:41 --> Input Class Initialized
INFO - 2018-06-19 19:39:41 --> Language Class Initialized
INFO - 2018-06-19 19:39:41 --> Loader Class Initialized
INFO - 2018-06-19 19:39:41 --> Helper loaded: url_helper
INFO - 2018-06-19 19:39:41 --> Helper loaded: form_helper
INFO - 2018-06-19 19:39:41 --> Helper loaded: language_helper
DEBUG - 2018-06-19 19:39:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 19:39:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 19:39:41 --> User Agent Class Initialized
INFO - 2018-06-19 19:39:41 --> Controller Class Initialized
INFO - 2018-06-19 19:39:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 19:39:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 19:39:41 --> Pixel_Model class loaded
INFO - 2018-06-19 19:39:41 --> Database Driver Class Initialized
INFO - 2018-06-19 19:39:41 --> Model "QuestionsModel" initialized
INFO - 2018-06-19 19:39:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 19:39:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 19:39:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-19 19:39:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 19:39:41 --> Final output sent to browser
DEBUG - 2018-06-19 19:39:41 --> Total execution time: 0.0699
INFO - 2018-06-19 19:53:12 --> Config Class Initialized
INFO - 2018-06-19 19:53:12 --> Hooks Class Initialized
DEBUG - 2018-06-19 19:53:12 --> UTF-8 Support Enabled
INFO - 2018-06-19 19:53:12 --> Utf8 Class Initialized
INFO - 2018-06-19 19:53:12 --> URI Class Initialized
DEBUG - 2018-06-19 19:53:12 --> No URI present. Default controller set.
INFO - 2018-06-19 19:53:12 --> Router Class Initialized
INFO - 2018-06-19 19:53:12 --> Output Class Initialized
INFO - 2018-06-19 19:53:12 --> Security Class Initialized
DEBUG - 2018-06-19 19:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 19:53:12 --> CSRF cookie sent
INFO - 2018-06-19 19:53:12 --> Input Class Initialized
INFO - 2018-06-19 19:53:12 --> Language Class Initialized
INFO - 2018-06-19 19:53:12 --> Loader Class Initialized
INFO - 2018-06-19 19:53:12 --> Helper loaded: url_helper
INFO - 2018-06-19 19:53:12 --> Helper loaded: form_helper
INFO - 2018-06-19 19:53:12 --> Helper loaded: language_helper
DEBUG - 2018-06-19 19:53:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 19:53:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 19:53:12 --> User Agent Class Initialized
INFO - 2018-06-19 19:53:12 --> Controller Class Initialized
INFO - 2018-06-19 19:53:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 19:53:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 19:53:12 --> Pixel_Model class loaded
INFO - 2018-06-19 19:53:12 --> Database Driver Class Initialized
INFO - 2018-06-19 19:53:12 --> Model "QuestionsModel" initialized
INFO - 2018-06-19 19:53:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 19:53:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 19:53:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-19 19:53:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 19:53:12 --> Final output sent to browser
DEBUG - 2018-06-19 19:53:12 --> Total execution time: 0.1023
INFO - 2018-06-19 20:06:09 --> Config Class Initialized
INFO - 2018-06-19 20:06:09 --> Hooks Class Initialized
DEBUG - 2018-06-19 20:06:09 --> UTF-8 Support Enabled
INFO - 2018-06-19 20:06:09 --> Utf8 Class Initialized
INFO - 2018-06-19 20:06:09 --> URI Class Initialized
DEBUG - 2018-06-19 20:06:09 --> No URI present. Default controller set.
INFO - 2018-06-19 20:06:09 --> Router Class Initialized
INFO - 2018-06-19 20:06:09 --> Output Class Initialized
INFO - 2018-06-19 20:06:09 --> Security Class Initialized
DEBUG - 2018-06-19 20:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 20:06:09 --> CSRF cookie sent
INFO - 2018-06-19 20:06:09 --> Input Class Initialized
INFO - 2018-06-19 20:06:09 --> Language Class Initialized
INFO - 2018-06-19 20:06:09 --> Loader Class Initialized
INFO - 2018-06-19 20:06:09 --> Helper loaded: url_helper
INFO - 2018-06-19 20:06:09 --> Helper loaded: form_helper
INFO - 2018-06-19 20:06:09 --> Helper loaded: language_helper
DEBUG - 2018-06-19 20:06:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 20:06:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 20:06:09 --> User Agent Class Initialized
INFO - 2018-06-19 20:06:09 --> Controller Class Initialized
INFO - 2018-06-19 20:06:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 20:06:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 20:06:09 --> Pixel_Model class loaded
INFO - 2018-06-19 20:06:09 --> Database Driver Class Initialized
INFO - 2018-06-19 20:06:09 --> Model "QuestionsModel" initialized
INFO - 2018-06-19 20:06:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 20:06:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 20:06:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-19 20:06:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 20:06:09 --> Final output sent to browser
DEBUG - 2018-06-19 20:06:09 --> Total execution time: 0.0985
INFO - 2018-06-19 20:06:33 --> Config Class Initialized
INFO - 2018-06-19 20:06:33 --> Hooks Class Initialized
DEBUG - 2018-06-19 20:06:33 --> UTF-8 Support Enabled
INFO - 2018-06-19 20:06:33 --> Utf8 Class Initialized
INFO - 2018-06-19 20:06:33 --> URI Class Initialized
DEBUG - 2018-06-19 20:06:33 --> No URI present. Default controller set.
INFO - 2018-06-19 20:06:33 --> Router Class Initialized
INFO - 2018-06-19 20:06:33 --> Output Class Initialized
INFO - 2018-06-19 20:06:33 --> Security Class Initialized
DEBUG - 2018-06-19 20:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 20:06:33 --> CSRF cookie sent
INFO - 2018-06-19 20:06:33 --> Input Class Initialized
INFO - 2018-06-19 20:06:33 --> Language Class Initialized
INFO - 2018-06-19 20:06:33 --> Loader Class Initialized
INFO - 2018-06-19 20:06:33 --> Helper loaded: url_helper
INFO - 2018-06-19 20:06:33 --> Helper loaded: form_helper
INFO - 2018-06-19 20:06:33 --> Helper loaded: language_helper
DEBUG - 2018-06-19 20:06:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 20:06:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 20:06:33 --> User Agent Class Initialized
INFO - 2018-06-19 20:06:33 --> Controller Class Initialized
INFO - 2018-06-19 20:06:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 20:06:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 20:06:33 --> Pixel_Model class loaded
INFO - 2018-06-19 20:06:33 --> Database Driver Class Initialized
INFO - 2018-06-19 20:06:33 --> Model "QuestionsModel" initialized
INFO - 2018-06-19 20:06:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 20:06:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 20:06:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-19 20:06:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 20:06:33 --> Final output sent to browser
DEBUG - 2018-06-19 20:06:33 --> Total execution time: 0.0756
INFO - 2018-06-19 20:08:13 --> Config Class Initialized
INFO - 2018-06-19 20:08:13 --> Hooks Class Initialized
DEBUG - 2018-06-19 20:08:13 --> UTF-8 Support Enabled
INFO - 2018-06-19 20:08:13 --> Utf8 Class Initialized
INFO - 2018-06-19 20:08:13 --> URI Class Initialized
INFO - 2018-06-19 20:08:13 --> Router Class Initialized
INFO - 2018-06-19 20:08:13 --> Output Class Initialized
INFO - 2018-06-19 20:08:13 --> Security Class Initialized
DEBUG - 2018-06-19 20:08:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 20:08:13 --> CSRF cookie sent
INFO - 2018-06-19 20:08:13 --> Input Class Initialized
INFO - 2018-06-19 20:08:13 --> Language Class Initialized
INFO - 2018-06-19 20:08:13 --> Loader Class Initialized
INFO - 2018-06-19 20:08:13 --> Helper loaded: url_helper
INFO - 2018-06-19 20:08:13 --> Helper loaded: form_helper
INFO - 2018-06-19 20:08:13 --> Helper loaded: language_helper
DEBUG - 2018-06-19 20:08:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 20:08:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 20:08:13 --> User Agent Class Initialized
INFO - 2018-06-19 20:08:13 --> Controller Class Initialized
INFO - 2018-06-19 20:08:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 20:08:13 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-19 20:08:13 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-19 20:08:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 20:08:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 20:08:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-19 20:08:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-19 20:08:13 --> Could not find the language line "req_email"
INFO - 2018-06-19 20:08:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-06-19 20:08:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 20:08:13 --> Final output sent to browser
DEBUG - 2018-06-19 20:08:13 --> Total execution time: 0.0457
INFO - 2018-06-19 20:10:11 --> Config Class Initialized
INFO - 2018-06-19 20:10:11 --> Hooks Class Initialized
DEBUG - 2018-06-19 20:10:11 --> UTF-8 Support Enabled
INFO - 2018-06-19 20:10:11 --> Utf8 Class Initialized
INFO - 2018-06-19 20:10:11 --> URI Class Initialized
INFO - 2018-06-19 20:10:11 --> Router Class Initialized
INFO - 2018-06-19 20:10:11 --> Output Class Initialized
INFO - 2018-06-19 20:10:11 --> Security Class Initialized
DEBUG - 2018-06-19 20:10:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 20:10:11 --> CSRF cookie sent
INFO - 2018-06-19 20:10:11 --> Input Class Initialized
INFO - 2018-06-19 20:10:11 --> Language Class Initialized
INFO - 2018-06-19 20:10:11 --> Loader Class Initialized
INFO - 2018-06-19 20:10:11 --> Helper loaded: url_helper
INFO - 2018-06-19 20:10:11 --> Helper loaded: form_helper
INFO - 2018-06-19 20:10:11 --> Helper loaded: language_helper
DEBUG - 2018-06-19 20:10:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 20:10:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 20:10:11 --> User Agent Class Initialized
INFO - 2018-06-19 20:10:11 --> Controller Class Initialized
INFO - 2018-06-19 20:10:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 20:10:11 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-19 20:10:11 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-19 20:10:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 20:10:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 20:10:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-19 20:10:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-19 20:10:11 --> Could not find the language line "req_email"
INFO - 2018-06-19 20:10:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-06-19 20:10:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 20:10:11 --> Final output sent to browser
DEBUG - 2018-06-19 20:10:11 --> Total execution time: 0.0559
INFO - 2018-06-19 20:14:42 --> Config Class Initialized
INFO - 2018-06-19 20:14:42 --> Hooks Class Initialized
DEBUG - 2018-06-19 20:14:42 --> UTF-8 Support Enabled
INFO - 2018-06-19 20:14:42 --> Utf8 Class Initialized
INFO - 2018-06-19 20:14:42 --> URI Class Initialized
INFO - 2018-06-19 20:14:42 --> Router Class Initialized
INFO - 2018-06-19 20:14:42 --> Output Class Initialized
INFO - 2018-06-19 20:14:42 --> Security Class Initialized
DEBUG - 2018-06-19 20:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 20:14:42 --> CSRF cookie sent
INFO - 2018-06-19 20:14:42 --> Input Class Initialized
INFO - 2018-06-19 20:14:42 --> Language Class Initialized
INFO - 2018-06-19 20:14:42 --> Loader Class Initialized
INFO - 2018-06-19 20:14:42 --> Helper loaded: url_helper
INFO - 2018-06-19 20:14:42 --> Helper loaded: form_helper
INFO - 2018-06-19 20:14:42 --> Helper loaded: language_helper
DEBUG - 2018-06-19 20:14:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 20:14:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 20:14:42 --> User Agent Class Initialized
INFO - 2018-06-19 20:14:42 --> Controller Class Initialized
INFO - 2018-06-19 20:14:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 20:14:42 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-19 20:14:42 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-19 20:14:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 20:14:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 20:14:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-19 20:14:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-19 20:14:42 --> Could not find the language line "req_email"
INFO - 2018-06-19 20:14:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-06-19 20:14:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 20:14:42 --> Final output sent to browser
DEBUG - 2018-06-19 20:14:42 --> Total execution time: 0.0494
INFO - 2018-06-19 20:14:44 --> Config Class Initialized
INFO - 2018-06-19 20:14:44 --> Hooks Class Initialized
DEBUG - 2018-06-19 20:14:44 --> UTF-8 Support Enabled
INFO - 2018-06-19 20:14:44 --> Utf8 Class Initialized
INFO - 2018-06-19 20:14:44 --> URI Class Initialized
INFO - 2018-06-19 20:14:44 --> Router Class Initialized
INFO - 2018-06-19 20:14:44 --> Output Class Initialized
INFO - 2018-06-19 20:14:44 --> Security Class Initialized
DEBUG - 2018-06-19 20:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 20:14:44 --> CSRF cookie sent
INFO - 2018-06-19 20:14:44 --> Input Class Initialized
INFO - 2018-06-19 20:14:44 --> Language Class Initialized
INFO - 2018-06-19 20:14:44 --> Loader Class Initialized
INFO - 2018-06-19 20:14:44 --> Helper loaded: url_helper
INFO - 2018-06-19 20:14:44 --> Helper loaded: form_helper
INFO - 2018-06-19 20:14:44 --> Helper loaded: language_helper
DEBUG - 2018-06-19 20:14:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 20:14:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 20:14:44 --> User Agent Class Initialized
INFO - 2018-06-19 20:14:44 --> Controller Class Initialized
INFO - 2018-06-19 20:14:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 20:14:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 20:14:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 20:14:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 20:14:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-19 20:14:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-19 20:14:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-06-19 20:14:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 20:14:44 --> Final output sent to browser
DEBUG - 2018-06-19 20:14:44 --> Total execution time: 0.0473
INFO - 2018-06-19 20:14:44 --> Config Class Initialized
INFO - 2018-06-19 20:14:44 --> Hooks Class Initialized
DEBUG - 2018-06-19 20:14:44 --> UTF-8 Support Enabled
INFO - 2018-06-19 20:14:44 --> Utf8 Class Initialized
INFO - 2018-06-19 20:14:44 --> URI Class Initialized
INFO - 2018-06-19 20:14:44 --> Router Class Initialized
INFO - 2018-06-19 20:14:44 --> Output Class Initialized
INFO - 2018-06-19 20:14:44 --> Security Class Initialized
DEBUG - 2018-06-19 20:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 20:14:44 --> CSRF cookie sent
INFO - 2018-06-19 20:14:44 --> Input Class Initialized
INFO - 2018-06-19 20:14:44 --> Language Class Initialized
ERROR - 2018-06-19 20:14:44 --> 404 Page Not Found: Assets/css
INFO - 2018-06-19 20:16:26 --> Config Class Initialized
INFO - 2018-06-19 20:16:26 --> Hooks Class Initialized
DEBUG - 2018-06-19 20:16:26 --> UTF-8 Support Enabled
INFO - 2018-06-19 20:16:26 --> Utf8 Class Initialized
INFO - 2018-06-19 20:16:26 --> URI Class Initialized
DEBUG - 2018-06-19 20:16:26 --> No URI present. Default controller set.
INFO - 2018-06-19 20:16:26 --> Router Class Initialized
INFO - 2018-06-19 20:16:26 --> Output Class Initialized
INFO - 2018-06-19 20:16:26 --> Security Class Initialized
DEBUG - 2018-06-19 20:16:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 20:16:26 --> CSRF cookie sent
INFO - 2018-06-19 20:16:26 --> Input Class Initialized
INFO - 2018-06-19 20:16:26 --> Language Class Initialized
INFO - 2018-06-19 20:16:26 --> Loader Class Initialized
INFO - 2018-06-19 20:16:26 --> Helper loaded: url_helper
INFO - 2018-06-19 20:16:26 --> Helper loaded: form_helper
INFO - 2018-06-19 20:16:26 --> Helper loaded: language_helper
DEBUG - 2018-06-19 20:16:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 20:16:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 20:16:26 --> User Agent Class Initialized
INFO - 2018-06-19 20:16:26 --> Controller Class Initialized
INFO - 2018-06-19 20:16:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 20:16:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 20:16:26 --> Pixel_Model class loaded
INFO - 2018-06-19 20:16:26 --> Database Driver Class Initialized
INFO - 2018-06-19 20:16:26 --> Model "QuestionsModel" initialized
INFO - 2018-06-19 20:16:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 20:16:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 20:16:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-19 20:16:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 20:16:26 --> Final output sent to browser
DEBUG - 2018-06-19 20:16:26 --> Total execution time: 0.0557
INFO - 2018-06-19 20:16:37 --> Config Class Initialized
INFO - 2018-06-19 20:16:37 --> Hooks Class Initialized
DEBUG - 2018-06-19 20:16:37 --> UTF-8 Support Enabled
INFO - 2018-06-19 20:16:37 --> Utf8 Class Initialized
INFO - 2018-06-19 20:16:37 --> URI Class Initialized
INFO - 2018-06-19 20:16:37 --> Router Class Initialized
INFO - 2018-06-19 20:16:37 --> Output Class Initialized
INFO - 2018-06-19 20:16:37 --> Security Class Initialized
DEBUG - 2018-06-19 20:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 20:16:37 --> CSRF cookie sent
INFO - 2018-06-19 20:16:37 --> Input Class Initialized
INFO - 2018-06-19 20:16:37 --> Language Class Initialized
INFO - 2018-06-19 20:16:37 --> Loader Class Initialized
INFO - 2018-06-19 20:16:37 --> Helper loaded: url_helper
INFO - 2018-06-19 20:16:37 --> Helper loaded: form_helper
INFO - 2018-06-19 20:16:37 --> Helper loaded: language_helper
DEBUG - 2018-06-19 20:16:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 20:16:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 20:16:37 --> User Agent Class Initialized
INFO - 2018-06-19 20:16:37 --> Controller Class Initialized
INFO - 2018-06-19 20:16:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 20:16:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 20:16:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 20:16:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 20:16:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-19 20:16:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-19 20:16:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-06-19 20:16:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 20:16:37 --> Final output sent to browser
DEBUG - 2018-06-19 20:16:37 --> Total execution time: 0.0644
INFO - 2018-06-19 20:16:49 --> Config Class Initialized
INFO - 2018-06-19 20:16:49 --> Hooks Class Initialized
DEBUG - 2018-06-19 20:16:49 --> UTF-8 Support Enabled
INFO - 2018-06-19 20:16:49 --> Utf8 Class Initialized
INFO - 2018-06-19 20:16:49 --> URI Class Initialized
DEBUG - 2018-06-19 20:16:49 --> No URI present. Default controller set.
INFO - 2018-06-19 20:16:49 --> Router Class Initialized
INFO - 2018-06-19 20:16:49 --> Output Class Initialized
INFO - 2018-06-19 20:16:49 --> Security Class Initialized
DEBUG - 2018-06-19 20:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 20:16:49 --> CSRF cookie sent
INFO - 2018-06-19 20:16:49 --> Input Class Initialized
INFO - 2018-06-19 20:16:49 --> Language Class Initialized
INFO - 2018-06-19 20:16:49 --> Loader Class Initialized
INFO - 2018-06-19 20:16:49 --> Helper loaded: url_helper
INFO - 2018-06-19 20:16:49 --> Helper loaded: form_helper
INFO - 2018-06-19 20:16:49 --> Helper loaded: language_helper
DEBUG - 2018-06-19 20:16:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 20:16:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 20:16:49 --> User Agent Class Initialized
INFO - 2018-06-19 20:16:49 --> Controller Class Initialized
INFO - 2018-06-19 20:16:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 20:16:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 20:16:49 --> Pixel_Model class loaded
INFO - 2018-06-19 20:16:49 --> Database Driver Class Initialized
INFO - 2018-06-19 20:16:49 --> Model "QuestionsModel" initialized
INFO - 2018-06-19 20:16:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 20:16:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 20:16:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-19 20:16:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 20:16:49 --> Final output sent to browser
DEBUG - 2018-06-19 20:16:49 --> Total execution time: 0.0437
INFO - 2018-06-19 20:16:54 --> Config Class Initialized
INFO - 2018-06-19 20:16:54 --> Hooks Class Initialized
DEBUG - 2018-06-19 20:16:54 --> UTF-8 Support Enabled
INFO - 2018-06-19 20:16:54 --> Utf8 Class Initialized
INFO - 2018-06-19 20:16:54 --> URI Class Initialized
INFO - 2018-06-19 20:16:54 --> Router Class Initialized
INFO - 2018-06-19 20:16:54 --> Output Class Initialized
INFO - 2018-06-19 20:16:54 --> Security Class Initialized
DEBUG - 2018-06-19 20:16:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 20:16:54 --> CSRF cookie sent
INFO - 2018-06-19 20:16:54 --> Input Class Initialized
INFO - 2018-06-19 20:16:54 --> Language Class Initialized
ERROR - 2018-06-19 20:16:54 --> 404 Page Not Found: Assets/css
INFO - 2018-06-19 20:21:30 --> Config Class Initialized
INFO - 2018-06-19 20:21:30 --> Hooks Class Initialized
DEBUG - 2018-06-19 20:21:30 --> UTF-8 Support Enabled
INFO - 2018-06-19 20:21:30 --> Utf8 Class Initialized
INFO - 2018-06-19 20:21:30 --> URI Class Initialized
DEBUG - 2018-06-19 20:21:30 --> No URI present. Default controller set.
INFO - 2018-06-19 20:21:30 --> Router Class Initialized
INFO - 2018-06-19 20:21:30 --> Output Class Initialized
INFO - 2018-06-19 20:21:30 --> Security Class Initialized
DEBUG - 2018-06-19 20:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 20:21:30 --> CSRF cookie sent
INFO - 2018-06-19 20:21:30 --> Input Class Initialized
INFO - 2018-06-19 20:21:30 --> Language Class Initialized
INFO - 2018-06-19 20:21:30 --> Loader Class Initialized
INFO - 2018-06-19 20:21:30 --> Helper loaded: url_helper
INFO - 2018-06-19 20:21:30 --> Helper loaded: form_helper
INFO - 2018-06-19 20:21:30 --> Helper loaded: language_helper
DEBUG - 2018-06-19 20:21:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 20:21:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 20:21:30 --> User Agent Class Initialized
INFO - 2018-06-19 20:21:30 --> Controller Class Initialized
INFO - 2018-06-19 20:21:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 20:21:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 20:21:30 --> Pixel_Model class loaded
INFO - 2018-06-19 20:21:30 --> Database Driver Class Initialized
INFO - 2018-06-19 20:21:30 --> Model "QuestionsModel" initialized
INFO - 2018-06-19 20:21:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 20:21:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 20:21:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-19 20:21:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 20:21:30 --> Final output sent to browser
DEBUG - 2018-06-19 20:21:30 --> Total execution time: 0.0737
INFO - 2018-06-19 20:21:31 --> Config Class Initialized
INFO - 2018-06-19 20:21:31 --> Hooks Class Initialized
DEBUG - 2018-06-19 20:21:31 --> UTF-8 Support Enabled
INFO - 2018-06-19 20:21:31 --> Utf8 Class Initialized
INFO - 2018-06-19 20:21:31 --> URI Class Initialized
INFO - 2018-06-19 20:21:31 --> Router Class Initialized
INFO - 2018-06-19 20:21:31 --> Output Class Initialized
INFO - 2018-06-19 20:21:31 --> Security Class Initialized
DEBUG - 2018-06-19 20:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 20:21:31 --> CSRF cookie sent
INFO - 2018-06-19 20:21:31 --> Input Class Initialized
INFO - 2018-06-19 20:21:31 --> Language Class Initialized
ERROR - 2018-06-19 20:21:31 --> 404 Page Not Found: Assets/css
INFO - 2018-06-19 20:21:38 --> Config Class Initialized
INFO - 2018-06-19 20:21:38 --> Hooks Class Initialized
DEBUG - 2018-06-19 20:21:38 --> UTF-8 Support Enabled
INFO - 2018-06-19 20:21:38 --> Utf8 Class Initialized
INFO - 2018-06-19 20:21:38 --> URI Class Initialized
DEBUG - 2018-06-19 20:21:38 --> No URI present. Default controller set.
INFO - 2018-06-19 20:21:38 --> Router Class Initialized
INFO - 2018-06-19 20:21:38 --> Output Class Initialized
INFO - 2018-06-19 20:21:38 --> Security Class Initialized
DEBUG - 2018-06-19 20:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 20:21:38 --> CSRF cookie sent
INFO - 2018-06-19 20:21:38 --> Input Class Initialized
INFO - 2018-06-19 20:21:38 --> Language Class Initialized
INFO - 2018-06-19 20:21:38 --> Loader Class Initialized
INFO - 2018-06-19 20:21:38 --> Helper loaded: url_helper
INFO - 2018-06-19 20:21:38 --> Helper loaded: form_helper
INFO - 2018-06-19 20:21:38 --> Helper loaded: language_helper
DEBUG - 2018-06-19 20:21:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 20:21:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 20:21:38 --> User Agent Class Initialized
INFO - 2018-06-19 20:21:38 --> Controller Class Initialized
INFO - 2018-06-19 20:21:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 20:21:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 20:21:38 --> Pixel_Model class loaded
INFO - 2018-06-19 20:21:38 --> Database Driver Class Initialized
INFO - 2018-06-19 20:21:38 --> Model "QuestionsModel" initialized
INFO - 2018-06-19 20:21:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 20:21:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 20:21:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-19 20:21:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 20:21:38 --> Final output sent to browser
DEBUG - 2018-06-19 20:21:38 --> Total execution time: 0.0748
INFO - 2018-06-19 20:21:38 --> Config Class Initialized
INFO - 2018-06-19 20:21:38 --> Hooks Class Initialized
DEBUG - 2018-06-19 20:21:38 --> UTF-8 Support Enabled
INFO - 2018-06-19 20:21:38 --> Utf8 Class Initialized
INFO - 2018-06-19 20:21:38 --> URI Class Initialized
INFO - 2018-06-19 20:21:38 --> Router Class Initialized
INFO - 2018-06-19 20:21:38 --> Output Class Initialized
INFO - 2018-06-19 20:21:38 --> Security Class Initialized
DEBUG - 2018-06-19 20:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 20:21:38 --> CSRF cookie sent
INFO - 2018-06-19 20:21:38 --> Input Class Initialized
INFO - 2018-06-19 20:21:38 --> Language Class Initialized
ERROR - 2018-06-19 20:21:38 --> 404 Page Not Found: Assets/css
INFO - 2018-06-19 20:24:48 --> Config Class Initialized
INFO - 2018-06-19 20:24:48 --> Hooks Class Initialized
DEBUG - 2018-06-19 20:24:48 --> UTF-8 Support Enabled
INFO - 2018-06-19 20:24:48 --> Utf8 Class Initialized
INFO - 2018-06-19 20:24:48 --> URI Class Initialized
INFO - 2018-06-19 20:24:48 --> Router Class Initialized
INFO - 2018-06-19 20:24:48 --> Output Class Initialized
INFO - 2018-06-19 20:24:48 --> Security Class Initialized
DEBUG - 2018-06-19 20:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 20:24:48 --> CSRF cookie sent
INFO - 2018-06-19 20:24:48 --> Input Class Initialized
INFO - 2018-06-19 20:24:48 --> Language Class Initialized
INFO - 2018-06-19 20:24:48 --> Loader Class Initialized
INFO - 2018-06-19 20:24:48 --> Helper loaded: url_helper
INFO - 2018-06-19 20:24:48 --> Helper loaded: form_helper
INFO - 2018-06-19 20:24:48 --> Helper loaded: language_helper
DEBUG - 2018-06-19 20:24:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 20:24:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 20:24:48 --> User Agent Class Initialized
INFO - 2018-06-19 20:24:48 --> Controller Class Initialized
INFO - 2018-06-19 20:24:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 20:24:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 20:24:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 20:24:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 20:24:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-19 20:24:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-19 20:24:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-06-19 20:24:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 20:24:48 --> Final output sent to browser
DEBUG - 2018-06-19 20:24:48 --> Total execution time: 0.0366
INFO - 2018-06-19 20:24:54 --> Config Class Initialized
INFO - 2018-06-19 20:24:54 --> Hooks Class Initialized
DEBUG - 2018-06-19 20:24:54 --> UTF-8 Support Enabled
INFO - 2018-06-19 20:24:54 --> Utf8 Class Initialized
INFO - 2018-06-19 20:24:54 --> URI Class Initialized
INFO - 2018-06-19 20:24:54 --> Router Class Initialized
INFO - 2018-06-19 20:24:54 --> Output Class Initialized
INFO - 2018-06-19 20:24:54 --> Security Class Initialized
DEBUG - 2018-06-19 20:24:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 20:24:54 --> CSRF cookie sent
INFO - 2018-06-19 20:24:54 --> Input Class Initialized
INFO - 2018-06-19 20:24:54 --> Language Class Initialized
ERROR - 2018-06-19 20:24:54 --> 404 Page Not Found: Faviconico/index
INFO - 2018-06-19 20:25:00 --> Config Class Initialized
INFO - 2018-06-19 20:25:00 --> Hooks Class Initialized
DEBUG - 2018-06-19 20:25:00 --> UTF-8 Support Enabled
INFO - 2018-06-19 20:25:00 --> Utf8 Class Initialized
INFO - 2018-06-19 20:25:00 --> URI Class Initialized
INFO - 2018-06-19 20:25:00 --> Router Class Initialized
INFO - 2018-06-19 20:25:00 --> Output Class Initialized
INFO - 2018-06-19 20:25:00 --> Security Class Initialized
DEBUG - 2018-06-19 20:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 20:25:00 --> CSRF cookie sent
INFO - 2018-06-19 20:25:00 --> Input Class Initialized
INFO - 2018-06-19 20:25:00 --> Language Class Initialized
INFO - 2018-06-19 20:25:00 --> Loader Class Initialized
INFO - 2018-06-19 20:25:00 --> Helper loaded: url_helper
INFO - 2018-06-19 20:25:00 --> Helper loaded: form_helper
INFO - 2018-06-19 20:25:00 --> Helper loaded: language_helper
DEBUG - 2018-06-19 20:25:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 20:25:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 20:25:00 --> User Agent Class Initialized
INFO - 2018-06-19 20:25:00 --> Controller Class Initialized
INFO - 2018-06-19 20:25:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 20:25:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 20:25:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 20:25:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 20:25:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-19 20:25:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-19 20:25:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-06-19 20:25:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 20:25:00 --> Final output sent to browser
DEBUG - 2018-06-19 20:25:00 --> Total execution time: 0.0329
INFO - 2018-06-19 20:25:39 --> Config Class Initialized
INFO - 2018-06-19 20:25:39 --> Hooks Class Initialized
DEBUG - 2018-06-19 20:25:39 --> UTF-8 Support Enabled
INFO - 2018-06-19 20:25:39 --> Utf8 Class Initialized
INFO - 2018-06-19 20:25:39 --> URI Class Initialized
INFO - 2018-06-19 20:25:39 --> Router Class Initialized
INFO - 2018-06-19 20:25:39 --> Output Class Initialized
INFO - 2018-06-19 20:25:39 --> Security Class Initialized
DEBUG - 2018-06-19 20:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 20:25:39 --> CSRF cookie sent
INFO - 2018-06-19 20:25:39 --> Input Class Initialized
INFO - 2018-06-19 20:25:39 --> Language Class Initialized
ERROR - 2018-06-19 20:25:39 --> 404 Page Not Found: Faviconico/index
INFO - 2018-06-19 20:26:19 --> Config Class Initialized
INFO - 2018-06-19 20:26:19 --> Hooks Class Initialized
DEBUG - 2018-06-19 20:26:19 --> UTF-8 Support Enabled
INFO - 2018-06-19 20:26:19 --> Utf8 Class Initialized
INFO - 2018-06-19 20:26:19 --> URI Class Initialized
INFO - 2018-06-19 20:26:19 --> Router Class Initialized
INFO - 2018-06-19 20:26:19 --> Output Class Initialized
INFO - 2018-06-19 20:26:19 --> Security Class Initialized
DEBUG - 2018-06-19 20:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 20:26:19 --> CSRF cookie sent
INFO - 2018-06-19 20:26:19 --> Input Class Initialized
INFO - 2018-06-19 20:26:19 --> Language Class Initialized
INFO - 2018-06-19 20:26:19 --> Loader Class Initialized
INFO - 2018-06-19 20:26:19 --> Helper loaded: url_helper
INFO - 2018-06-19 20:26:19 --> Helper loaded: form_helper
INFO - 2018-06-19 20:26:19 --> Helper loaded: language_helper
DEBUG - 2018-06-19 20:26:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 20:26:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 20:26:19 --> User Agent Class Initialized
INFO - 2018-06-19 20:26:19 --> Controller Class Initialized
INFO - 2018-06-19 20:26:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 20:26:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 20:26:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 20:26:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 20:26:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-19 20:26:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-19 20:26:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-06-19 20:26:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 20:26:19 --> Final output sent to browser
DEBUG - 2018-06-19 20:26:19 --> Total execution time: 0.1110
INFO - 2018-06-19 20:26:54 --> Config Class Initialized
INFO - 2018-06-19 20:26:54 --> Hooks Class Initialized
DEBUG - 2018-06-19 20:26:54 --> UTF-8 Support Enabled
INFO - 2018-06-19 20:26:54 --> Utf8 Class Initialized
INFO - 2018-06-19 20:26:54 --> URI Class Initialized
INFO - 2018-06-19 20:26:54 --> Router Class Initialized
INFO - 2018-06-19 20:26:54 --> Output Class Initialized
INFO - 2018-06-19 20:26:54 --> Security Class Initialized
DEBUG - 2018-06-19 20:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 20:26:54 --> CSRF cookie sent
INFO - 2018-06-19 20:26:54 --> Input Class Initialized
INFO - 2018-06-19 20:26:54 --> Language Class Initialized
INFO - 2018-06-19 20:26:54 --> Loader Class Initialized
INFO - 2018-06-19 20:26:54 --> Helper loaded: url_helper
INFO - 2018-06-19 20:26:54 --> Helper loaded: form_helper
INFO - 2018-06-19 20:26:54 --> Helper loaded: language_helper
DEBUG - 2018-06-19 20:26:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 20:26:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 20:26:54 --> User Agent Class Initialized
INFO - 2018-06-19 20:26:54 --> Controller Class Initialized
INFO - 2018-06-19 20:26:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 20:26:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 20:26:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 20:26:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 20:26:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-19 20:26:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-19 20:26:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-06-19 20:26:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 20:26:54 --> Final output sent to browser
DEBUG - 2018-06-19 20:26:54 --> Total execution time: 0.0460
INFO - 2018-06-19 20:50:54 --> Config Class Initialized
INFO - 2018-06-19 20:50:54 --> Hooks Class Initialized
DEBUG - 2018-06-19 20:50:54 --> UTF-8 Support Enabled
INFO - 2018-06-19 20:50:54 --> Utf8 Class Initialized
INFO - 2018-06-19 20:50:54 --> URI Class Initialized
DEBUG - 2018-06-19 20:50:54 --> No URI present. Default controller set.
INFO - 2018-06-19 20:50:54 --> Router Class Initialized
INFO - 2018-06-19 20:50:54 --> Output Class Initialized
INFO - 2018-06-19 20:50:54 --> Security Class Initialized
DEBUG - 2018-06-19 20:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 20:50:54 --> CSRF cookie sent
INFO - 2018-06-19 20:50:54 --> Input Class Initialized
INFO - 2018-06-19 20:50:54 --> Language Class Initialized
INFO - 2018-06-19 20:50:54 --> Loader Class Initialized
INFO - 2018-06-19 20:50:54 --> Helper loaded: url_helper
INFO - 2018-06-19 20:50:54 --> Helper loaded: form_helper
INFO - 2018-06-19 20:50:54 --> Helper loaded: language_helper
DEBUG - 2018-06-19 20:50:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 20:50:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 20:50:54 --> User Agent Class Initialized
INFO - 2018-06-19 20:50:54 --> Controller Class Initialized
INFO - 2018-06-19 20:50:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 20:50:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 20:50:54 --> Pixel_Model class loaded
INFO - 2018-06-19 20:50:54 --> Database Driver Class Initialized
INFO - 2018-06-19 20:50:54 --> Model "QuestionsModel" initialized
INFO - 2018-06-19 20:50:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 20:50:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 20:50:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-19 20:50:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 20:50:54 --> Final output sent to browser
DEBUG - 2018-06-19 20:50:54 --> Total execution time: 0.0533
INFO - 2018-06-19 20:51:17 --> Config Class Initialized
INFO - 2018-06-19 20:51:17 --> Hooks Class Initialized
DEBUG - 2018-06-19 20:51:17 --> UTF-8 Support Enabled
INFO - 2018-06-19 20:51:17 --> Utf8 Class Initialized
INFO - 2018-06-19 20:51:17 --> URI Class Initialized
DEBUG - 2018-06-19 20:51:17 --> No URI present. Default controller set.
INFO - 2018-06-19 20:51:17 --> Router Class Initialized
INFO - 2018-06-19 20:51:17 --> Output Class Initialized
INFO - 2018-06-19 20:51:17 --> Security Class Initialized
DEBUG - 2018-06-19 20:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 20:51:17 --> CSRF cookie sent
INFO - 2018-06-19 20:51:17 --> Input Class Initialized
INFO - 2018-06-19 20:51:17 --> Language Class Initialized
INFO - 2018-06-19 20:51:17 --> Loader Class Initialized
INFO - 2018-06-19 20:51:17 --> Helper loaded: url_helper
INFO - 2018-06-19 20:51:17 --> Helper loaded: form_helper
INFO - 2018-06-19 20:51:17 --> Helper loaded: language_helper
DEBUG - 2018-06-19 20:51:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 20:51:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 20:51:18 --> User Agent Class Initialized
INFO - 2018-06-19 20:51:18 --> Controller Class Initialized
INFO - 2018-06-19 20:51:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 20:51:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 20:51:18 --> Pixel_Model class loaded
INFO - 2018-06-19 20:51:18 --> Database Driver Class Initialized
INFO - 2018-06-19 20:51:18 --> Model "QuestionsModel" initialized
INFO - 2018-06-19 20:51:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 20:51:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 20:51:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-19 20:51:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 20:51:18 --> Final output sent to browser
DEBUG - 2018-06-19 20:51:18 --> Total execution time: 0.1554
INFO - 2018-06-19 20:51:30 --> Config Class Initialized
INFO - 2018-06-19 20:51:30 --> Hooks Class Initialized
DEBUG - 2018-06-19 20:51:30 --> UTF-8 Support Enabled
INFO - 2018-06-19 20:51:30 --> Utf8 Class Initialized
INFO - 2018-06-19 20:51:30 --> URI Class Initialized
DEBUG - 2018-06-19 20:51:30 --> No URI present. Default controller set.
INFO - 2018-06-19 20:51:30 --> Router Class Initialized
INFO - 2018-06-19 20:51:30 --> Output Class Initialized
INFO - 2018-06-19 20:51:30 --> Security Class Initialized
DEBUG - 2018-06-19 20:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 20:51:30 --> CSRF cookie sent
INFO - 2018-06-19 20:51:30 --> Input Class Initialized
INFO - 2018-06-19 20:51:30 --> Language Class Initialized
INFO - 2018-06-19 20:51:30 --> Loader Class Initialized
INFO - 2018-06-19 20:51:30 --> Helper loaded: url_helper
INFO - 2018-06-19 20:51:30 --> Helper loaded: form_helper
INFO - 2018-06-19 20:51:30 --> Helper loaded: language_helper
DEBUG - 2018-06-19 20:51:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 20:51:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 20:51:30 --> User Agent Class Initialized
INFO - 2018-06-19 20:51:30 --> Controller Class Initialized
INFO - 2018-06-19 20:51:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 20:51:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 20:51:30 --> Pixel_Model class loaded
INFO - 2018-06-19 20:51:30 --> Database Driver Class Initialized
INFO - 2018-06-19 20:51:30 --> Model "QuestionsModel" initialized
INFO - 2018-06-19 20:51:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 20:51:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 20:51:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-19 20:51:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 20:51:30 --> Final output sent to browser
DEBUG - 2018-06-19 20:51:30 --> Total execution time: 0.0719
INFO - 2018-06-19 20:51:38 --> Config Class Initialized
INFO - 2018-06-19 20:51:38 --> Hooks Class Initialized
DEBUG - 2018-06-19 20:51:38 --> UTF-8 Support Enabled
INFO - 2018-06-19 20:51:38 --> Utf8 Class Initialized
INFO - 2018-06-19 20:51:38 --> URI Class Initialized
INFO - 2018-06-19 20:51:38 --> Router Class Initialized
INFO - 2018-06-19 20:51:38 --> Output Class Initialized
INFO - 2018-06-19 20:51:38 --> Security Class Initialized
DEBUG - 2018-06-19 20:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 20:51:38 --> CSRF cookie sent
INFO - 2018-06-19 20:51:38 --> Input Class Initialized
INFO - 2018-06-19 20:51:38 --> Language Class Initialized
ERROR - 2018-06-19 20:51:38 --> 404 Page Not Found: Assets/css
INFO - 2018-06-19 21:37:10 --> Config Class Initialized
INFO - 2018-06-19 21:37:10 --> Hooks Class Initialized
DEBUG - 2018-06-19 21:37:10 --> UTF-8 Support Enabled
INFO - 2018-06-19 21:37:10 --> Utf8 Class Initialized
INFO - 2018-06-19 21:37:10 --> URI Class Initialized
INFO - 2018-06-19 21:37:10 --> Router Class Initialized
INFO - 2018-06-19 21:37:10 --> Output Class Initialized
INFO - 2018-06-19 21:37:10 --> Security Class Initialized
DEBUG - 2018-06-19 21:37:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 21:37:10 --> CSRF cookie sent
INFO - 2018-06-19 21:37:10 --> Input Class Initialized
INFO - 2018-06-19 21:37:10 --> Language Class Initialized
INFO - 2018-06-19 21:37:10 --> Loader Class Initialized
INFO - 2018-06-19 21:37:10 --> Helper loaded: url_helper
INFO - 2018-06-19 21:37:10 --> Helper loaded: form_helper
INFO - 2018-06-19 21:37:10 --> Helper loaded: language_helper
DEBUG - 2018-06-19 21:37:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 21:37:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 21:37:10 --> User Agent Class Initialized
INFO - 2018-06-19 21:37:10 --> Controller Class Initialized
INFO - 2018-06-19 21:37:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 21:37:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 21:37:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 21:37:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 21:37:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-19 21:37:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-19 21:37:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-06-19 21:37:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 21:37:10 --> Final output sent to browser
DEBUG - 2018-06-19 21:37:10 --> Total execution time: 0.0385
INFO - 2018-06-19 22:17:22 --> Config Class Initialized
INFO - 2018-06-19 22:17:22 --> Hooks Class Initialized
DEBUG - 2018-06-19 22:17:22 --> UTF-8 Support Enabled
INFO - 2018-06-19 22:17:22 --> Utf8 Class Initialized
INFO - 2018-06-19 22:17:22 --> URI Class Initialized
DEBUG - 2018-06-19 22:17:22 --> No URI present. Default controller set.
INFO - 2018-06-19 22:17:22 --> Router Class Initialized
INFO - 2018-06-19 22:17:22 --> Output Class Initialized
INFO - 2018-06-19 22:17:22 --> Security Class Initialized
DEBUG - 2018-06-19 22:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 22:17:22 --> CSRF cookie sent
INFO - 2018-06-19 22:17:22 --> Input Class Initialized
INFO - 2018-06-19 22:17:22 --> Language Class Initialized
INFO - 2018-06-19 22:17:22 --> Loader Class Initialized
INFO - 2018-06-19 22:17:22 --> Helper loaded: url_helper
INFO - 2018-06-19 22:17:22 --> Helper loaded: form_helper
INFO - 2018-06-19 22:17:22 --> Helper loaded: language_helper
DEBUG - 2018-06-19 22:17:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 22:17:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 22:17:22 --> User Agent Class Initialized
INFO - 2018-06-19 22:17:22 --> Controller Class Initialized
INFO - 2018-06-19 22:17:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 22:17:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 22:17:22 --> Pixel_Model class loaded
INFO - 2018-06-19 22:17:22 --> Database Driver Class Initialized
INFO - 2018-06-19 22:17:22 --> Model "QuestionsModel" initialized
INFO - 2018-06-19 22:17:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 22:17:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 22:17:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-19 22:17:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 22:17:22 --> Final output sent to browser
DEBUG - 2018-06-19 22:17:22 --> Total execution time: 0.0407
INFO - 2018-06-19 22:17:27 --> Config Class Initialized
INFO - 2018-06-19 22:17:27 --> Hooks Class Initialized
DEBUG - 2018-06-19 22:17:27 --> UTF-8 Support Enabled
INFO - 2018-06-19 22:17:27 --> Utf8 Class Initialized
INFO - 2018-06-19 22:17:27 --> URI Class Initialized
INFO - 2018-06-19 22:17:27 --> Router Class Initialized
INFO - 2018-06-19 22:17:27 --> Output Class Initialized
INFO - 2018-06-19 22:17:27 --> Security Class Initialized
DEBUG - 2018-06-19 22:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 22:17:27 --> CSRF cookie sent
INFO - 2018-06-19 22:17:27 --> Input Class Initialized
INFO - 2018-06-19 22:17:27 --> Language Class Initialized
INFO - 2018-06-19 22:17:27 --> Loader Class Initialized
INFO - 2018-06-19 22:17:27 --> Helper loaded: url_helper
INFO - 2018-06-19 22:17:27 --> Helper loaded: form_helper
INFO - 2018-06-19 22:17:27 --> Helper loaded: language_helper
DEBUG - 2018-06-19 22:17:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 22:17:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 22:17:27 --> User Agent Class Initialized
INFO - 2018-06-19 22:17:27 --> Controller Class Initialized
INFO - 2018-06-19 22:17:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 22:17:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 22:17:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 22:17:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 22:17:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-19 22:17:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-19 22:17:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-06-19 22:17:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 22:17:27 --> Final output sent to browser
DEBUG - 2018-06-19 22:17:27 --> Total execution time: 0.0438
INFO - 2018-06-19 22:17:30 --> Config Class Initialized
INFO - 2018-06-19 22:17:30 --> Hooks Class Initialized
DEBUG - 2018-06-19 22:17:30 --> UTF-8 Support Enabled
INFO - 2018-06-19 22:17:30 --> Utf8 Class Initialized
INFO - 2018-06-19 22:17:30 --> URI Class Initialized
INFO - 2018-06-19 22:17:30 --> Router Class Initialized
INFO - 2018-06-19 22:17:30 --> Output Class Initialized
INFO - 2018-06-19 22:17:30 --> Security Class Initialized
DEBUG - 2018-06-19 22:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 22:17:30 --> CSRF cookie sent
INFO - 2018-06-19 22:17:30 --> Input Class Initialized
INFO - 2018-06-19 22:17:30 --> Language Class Initialized
INFO - 2018-06-19 22:17:30 --> Loader Class Initialized
INFO - 2018-06-19 22:17:30 --> Helper loaded: url_helper
INFO - 2018-06-19 22:17:30 --> Helper loaded: form_helper
INFO - 2018-06-19 22:17:30 --> Helper loaded: language_helper
DEBUG - 2018-06-19 22:17:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 22:17:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 22:17:30 --> User Agent Class Initialized
INFO - 2018-06-19 22:17:30 --> Controller Class Initialized
INFO - 2018-06-19 22:17:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 22:17:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 22:17:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 22:17:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 22:17:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-19 22:17:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-19 22:17:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-06-19 22:17:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 22:17:30 --> Final output sent to browser
DEBUG - 2018-06-19 22:17:30 --> Total execution time: 0.0327
INFO - 2018-06-19 22:17:39 --> Config Class Initialized
INFO - 2018-06-19 22:17:39 --> Hooks Class Initialized
DEBUG - 2018-06-19 22:17:39 --> UTF-8 Support Enabled
INFO - 2018-06-19 22:17:39 --> Utf8 Class Initialized
INFO - 2018-06-19 22:17:39 --> URI Class Initialized
INFO - 2018-06-19 22:17:39 --> Router Class Initialized
INFO - 2018-06-19 22:17:39 --> Output Class Initialized
INFO - 2018-06-19 22:17:39 --> Security Class Initialized
DEBUG - 2018-06-19 22:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 22:17:39 --> CSRF cookie sent
INFO - 2018-06-19 22:17:39 --> Input Class Initialized
INFO - 2018-06-19 22:17:39 --> Language Class Initialized
INFO - 2018-06-19 22:17:39 --> Loader Class Initialized
INFO - 2018-06-19 22:17:39 --> Helper loaded: url_helper
INFO - 2018-06-19 22:17:39 --> Helper loaded: form_helper
INFO - 2018-06-19 22:17:39 --> Helper loaded: language_helper
DEBUG - 2018-06-19 22:17:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 22:17:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 22:17:39 --> User Agent Class Initialized
INFO - 2018-06-19 22:17:39 --> Controller Class Initialized
INFO - 2018-06-19 22:17:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 22:17:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 22:17:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 22:17:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 22:17:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-19 22:17:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-19 22:17:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-06-19 22:17:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 22:17:39 --> Final output sent to browser
DEBUG - 2018-06-19 22:17:39 --> Total execution time: 0.0237
INFO - 2018-06-19 22:17:43 --> Config Class Initialized
INFO - 2018-06-19 22:17:43 --> Hooks Class Initialized
DEBUG - 2018-06-19 22:17:43 --> UTF-8 Support Enabled
INFO - 2018-06-19 22:17:43 --> Utf8 Class Initialized
INFO - 2018-06-19 22:17:43 --> URI Class Initialized
INFO - 2018-06-19 22:17:43 --> Router Class Initialized
INFO - 2018-06-19 22:17:43 --> Output Class Initialized
INFO - 2018-06-19 22:17:43 --> Security Class Initialized
DEBUG - 2018-06-19 22:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 22:17:43 --> CSRF cookie sent
INFO - 2018-06-19 22:17:43 --> Input Class Initialized
INFO - 2018-06-19 22:17:43 --> Language Class Initialized
INFO - 2018-06-19 22:17:43 --> Loader Class Initialized
INFO - 2018-06-19 22:17:43 --> Helper loaded: url_helper
INFO - 2018-06-19 22:17:43 --> Helper loaded: form_helper
INFO - 2018-06-19 22:17:43 --> Helper loaded: language_helper
DEBUG - 2018-06-19 22:17:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 22:17:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 22:17:43 --> User Agent Class Initialized
INFO - 2018-06-19 22:17:43 --> Controller Class Initialized
INFO - 2018-06-19 22:17:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 22:17:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 22:17:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 22:17:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 22:17:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-19 22:17:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-19 22:17:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-06-19 22:17:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 22:17:43 --> Final output sent to browser
DEBUG - 2018-06-19 22:17:43 --> Total execution time: 0.0325
INFO - 2018-06-19 22:17:44 --> Config Class Initialized
INFO - 2018-06-19 22:17:44 --> Hooks Class Initialized
DEBUG - 2018-06-19 22:17:44 --> UTF-8 Support Enabled
INFO - 2018-06-19 22:17:44 --> Utf8 Class Initialized
INFO - 2018-06-19 22:17:44 --> URI Class Initialized
INFO - 2018-06-19 22:17:44 --> Router Class Initialized
INFO - 2018-06-19 22:17:44 --> Output Class Initialized
INFO - 2018-06-19 22:17:44 --> Security Class Initialized
DEBUG - 2018-06-19 22:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 22:17:44 --> CSRF cookie sent
INFO - 2018-06-19 22:17:44 --> Input Class Initialized
INFO - 2018-06-19 22:17:44 --> Language Class Initialized
INFO - 2018-06-19 22:17:44 --> Loader Class Initialized
INFO - 2018-06-19 22:17:44 --> Helper loaded: url_helper
INFO - 2018-06-19 22:17:44 --> Helper loaded: form_helper
INFO - 2018-06-19 22:17:44 --> Helper loaded: language_helper
DEBUG - 2018-06-19 22:17:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 22:17:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 22:17:44 --> User Agent Class Initialized
INFO - 2018-06-19 22:17:44 --> Controller Class Initialized
INFO - 2018-06-19 22:17:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 22:17:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 22:17:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 22:17:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 22:17:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-19 22:17:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-19 22:17:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-06-19 22:17:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 22:17:44 --> Final output sent to browser
DEBUG - 2018-06-19 22:17:44 --> Total execution time: 0.0392
INFO - 2018-06-19 22:17:49 --> Config Class Initialized
INFO - 2018-06-19 22:17:49 --> Hooks Class Initialized
DEBUG - 2018-06-19 22:17:49 --> UTF-8 Support Enabled
INFO - 2018-06-19 22:17:49 --> Utf8 Class Initialized
INFO - 2018-06-19 22:17:49 --> URI Class Initialized
INFO - 2018-06-19 22:17:49 --> Router Class Initialized
INFO - 2018-06-19 22:17:49 --> Output Class Initialized
INFO - 2018-06-19 22:17:49 --> Security Class Initialized
DEBUG - 2018-06-19 22:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 22:17:49 --> CSRF cookie sent
INFO - 2018-06-19 22:17:49 --> Input Class Initialized
INFO - 2018-06-19 22:17:49 --> Language Class Initialized
INFO - 2018-06-19 22:17:49 --> Loader Class Initialized
INFO - 2018-06-19 22:17:49 --> Helper loaded: url_helper
INFO - 2018-06-19 22:17:49 --> Helper loaded: form_helper
INFO - 2018-06-19 22:17:49 --> Helper loaded: language_helper
DEBUG - 2018-06-19 22:17:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 22:17:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 22:17:49 --> User Agent Class Initialized
INFO - 2018-06-19 22:17:49 --> Controller Class Initialized
INFO - 2018-06-19 22:17:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 22:17:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 22:17:49 --> Pixel_Model class loaded
INFO - 2018-06-19 22:17:49 --> Database Driver Class Initialized
INFO - 2018-06-19 22:17:49 --> Model "QuestionsModel" initialized
INFO - 2018-06-19 22:17:49 --> Config Class Initialized
INFO - 2018-06-19 22:17:49 --> Hooks Class Initialized
DEBUG - 2018-06-19 22:17:49 --> UTF-8 Support Enabled
INFO - 2018-06-19 22:17:49 --> Utf8 Class Initialized
INFO - 2018-06-19 22:17:49 --> URI Class Initialized
INFO - 2018-06-19 22:17:49 --> Router Class Initialized
INFO - 2018-06-19 22:17:49 --> Output Class Initialized
INFO - 2018-06-19 22:17:49 --> Security Class Initialized
DEBUG - 2018-06-19 22:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 22:17:49 --> CSRF cookie sent
INFO - 2018-06-19 22:17:49 --> Input Class Initialized
INFO - 2018-06-19 22:17:49 --> Language Class Initialized
INFO - 2018-06-19 22:17:49 --> Loader Class Initialized
INFO - 2018-06-19 22:17:49 --> Helper loaded: url_helper
INFO - 2018-06-19 22:17:49 --> Helper loaded: form_helper
INFO - 2018-06-19 22:17:49 --> Helper loaded: language_helper
DEBUG - 2018-06-19 22:17:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 22:17:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 22:17:49 --> User Agent Class Initialized
INFO - 2018-06-19 22:17:49 --> Controller Class Initialized
INFO - 2018-06-19 22:17:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 22:17:49 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-19 22:17:49 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-19 22:17:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 22:17:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 22:17:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-19 22:17:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-19 22:17:49 --> Could not find the language line "req_email"
INFO - 2018-06-19 22:17:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-06-19 22:17:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 22:17:49 --> Final output sent to browser
DEBUG - 2018-06-19 22:17:49 --> Total execution time: 0.0341
INFO - 2018-06-19 22:17:50 --> Config Class Initialized
INFO - 2018-06-19 22:17:50 --> Hooks Class Initialized
DEBUG - 2018-06-19 22:17:50 --> UTF-8 Support Enabled
INFO - 2018-06-19 22:17:50 --> Utf8 Class Initialized
INFO - 2018-06-19 22:17:50 --> URI Class Initialized
DEBUG - 2018-06-19 22:17:50 --> No URI present. Default controller set.
INFO - 2018-06-19 22:17:50 --> Router Class Initialized
INFO - 2018-06-19 22:17:50 --> Output Class Initialized
INFO - 2018-06-19 22:17:50 --> Security Class Initialized
DEBUG - 2018-06-19 22:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 22:17:50 --> CSRF cookie sent
INFO - 2018-06-19 22:17:50 --> Input Class Initialized
INFO - 2018-06-19 22:17:50 --> Language Class Initialized
INFO - 2018-06-19 22:17:50 --> Loader Class Initialized
INFO - 2018-06-19 22:17:50 --> Helper loaded: url_helper
INFO - 2018-06-19 22:17:50 --> Helper loaded: form_helper
INFO - 2018-06-19 22:17:50 --> Helper loaded: language_helper
DEBUG - 2018-06-19 22:17:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 22:17:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 22:17:50 --> User Agent Class Initialized
INFO - 2018-06-19 22:17:50 --> Controller Class Initialized
INFO - 2018-06-19 22:17:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 22:17:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 22:17:50 --> Pixel_Model class loaded
INFO - 2018-06-19 22:17:50 --> Database Driver Class Initialized
INFO - 2018-06-19 22:17:50 --> Model "QuestionsModel" initialized
INFO - 2018-06-19 22:17:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 22:17:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 22:17:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-19 22:17:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 22:17:50 --> Final output sent to browser
DEBUG - 2018-06-19 22:17:50 --> Total execution time: 0.0767
INFO - 2018-06-19 22:17:52 --> Config Class Initialized
INFO - 2018-06-19 22:17:52 --> Hooks Class Initialized
DEBUG - 2018-06-19 22:17:52 --> UTF-8 Support Enabled
INFO - 2018-06-19 22:17:52 --> Utf8 Class Initialized
INFO - 2018-06-19 22:17:52 --> URI Class Initialized
INFO - 2018-06-19 22:17:52 --> Router Class Initialized
INFO - 2018-06-19 22:17:52 --> Output Class Initialized
INFO - 2018-06-19 22:17:52 --> Security Class Initialized
DEBUG - 2018-06-19 22:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 22:17:52 --> CSRF cookie sent
INFO - 2018-06-19 22:17:52 --> Input Class Initialized
INFO - 2018-06-19 22:17:52 --> Language Class Initialized
INFO - 2018-06-19 22:17:52 --> Loader Class Initialized
INFO - 2018-06-19 22:17:52 --> Helper loaded: url_helper
INFO - 2018-06-19 22:17:52 --> Helper loaded: form_helper
INFO - 2018-06-19 22:17:52 --> Helper loaded: language_helper
DEBUG - 2018-06-19 22:17:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 22:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 22:17:52 --> User Agent Class Initialized
INFO - 2018-06-19 22:17:52 --> Controller Class Initialized
INFO - 2018-06-19 22:17:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 22:17:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 22:17:52 --> Pixel_Model class loaded
INFO - 2018-06-19 22:17:52 --> Database Driver Class Initialized
INFO - 2018-06-19 22:17:52 --> Model "QuestionsModel" initialized
INFO - 2018-06-19 22:17:52 --> Config Class Initialized
INFO - 2018-06-19 22:17:52 --> Hooks Class Initialized
DEBUG - 2018-06-19 22:17:52 --> UTF-8 Support Enabled
INFO - 2018-06-19 22:17:52 --> Utf8 Class Initialized
INFO - 2018-06-19 22:17:52 --> URI Class Initialized
INFO - 2018-06-19 22:17:52 --> Router Class Initialized
INFO - 2018-06-19 22:17:52 --> Output Class Initialized
INFO - 2018-06-19 22:17:52 --> Security Class Initialized
DEBUG - 2018-06-19 22:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 22:17:52 --> CSRF cookie sent
INFO - 2018-06-19 22:17:52 --> Input Class Initialized
INFO - 2018-06-19 22:17:52 --> Language Class Initialized
INFO - 2018-06-19 22:17:52 --> Loader Class Initialized
INFO - 2018-06-19 22:17:52 --> Helper loaded: url_helper
INFO - 2018-06-19 22:17:52 --> Helper loaded: form_helper
INFO - 2018-06-19 22:17:52 --> Helper loaded: language_helper
DEBUG - 2018-06-19 22:17:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 22:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 22:17:52 --> User Agent Class Initialized
INFO - 2018-06-19 22:17:52 --> Controller Class Initialized
INFO - 2018-06-19 22:17:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 22:17:52 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-19 22:17:52 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-19 22:17:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 22:17:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 22:17:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-19 22:17:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-19 22:17:52 --> Could not find the language line "req_email"
INFO - 2018-06-19 22:17:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-06-19 22:17:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 22:17:52 --> Final output sent to browser
DEBUG - 2018-06-19 22:17:52 --> Total execution time: 0.0328
INFO - 2018-06-19 22:17:54 --> Config Class Initialized
INFO - 2018-06-19 22:17:54 --> Hooks Class Initialized
DEBUG - 2018-06-19 22:17:54 --> UTF-8 Support Enabled
INFO - 2018-06-19 22:17:54 --> Utf8 Class Initialized
INFO - 2018-06-19 22:17:54 --> URI Class Initialized
DEBUG - 2018-06-19 22:17:54 --> No URI present. Default controller set.
INFO - 2018-06-19 22:17:54 --> Router Class Initialized
INFO - 2018-06-19 22:17:54 --> Output Class Initialized
INFO - 2018-06-19 22:17:54 --> Security Class Initialized
DEBUG - 2018-06-19 22:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 22:17:54 --> CSRF cookie sent
INFO - 2018-06-19 22:17:54 --> Input Class Initialized
INFO - 2018-06-19 22:17:54 --> Language Class Initialized
INFO - 2018-06-19 22:17:54 --> Loader Class Initialized
INFO - 2018-06-19 22:17:54 --> Helper loaded: url_helper
INFO - 2018-06-19 22:17:54 --> Helper loaded: form_helper
INFO - 2018-06-19 22:17:54 --> Helper loaded: language_helper
DEBUG - 2018-06-19 22:17:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 22:17:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 22:17:54 --> User Agent Class Initialized
INFO - 2018-06-19 22:17:54 --> Controller Class Initialized
INFO - 2018-06-19 22:17:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 22:17:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 22:17:54 --> Pixel_Model class loaded
INFO - 2018-06-19 22:17:54 --> Database Driver Class Initialized
INFO - 2018-06-19 22:17:54 --> Model "QuestionsModel" initialized
INFO - 2018-06-19 22:17:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 22:17:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 22:17:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-19 22:17:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 22:17:54 --> Final output sent to browser
DEBUG - 2018-06-19 22:17:54 --> Total execution time: 0.0446
INFO - 2018-06-19 22:18:04 --> Config Class Initialized
INFO - 2018-06-19 22:18:04 --> Hooks Class Initialized
DEBUG - 2018-06-19 22:18:04 --> UTF-8 Support Enabled
INFO - 2018-06-19 22:18:04 --> Utf8 Class Initialized
INFO - 2018-06-19 22:18:04 --> URI Class Initialized
DEBUG - 2018-06-19 22:18:04 --> No URI present. Default controller set.
INFO - 2018-06-19 22:18:04 --> Router Class Initialized
INFO - 2018-06-19 22:18:04 --> Output Class Initialized
INFO - 2018-06-19 22:18:04 --> Security Class Initialized
DEBUG - 2018-06-19 22:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 22:18:04 --> CSRF cookie sent
INFO - 2018-06-19 22:18:04 --> Input Class Initialized
INFO - 2018-06-19 22:18:04 --> Language Class Initialized
INFO - 2018-06-19 22:18:04 --> Loader Class Initialized
INFO - 2018-06-19 22:18:04 --> Helper loaded: url_helper
INFO - 2018-06-19 22:18:04 --> Helper loaded: form_helper
INFO - 2018-06-19 22:18:04 --> Helper loaded: language_helper
DEBUG - 2018-06-19 22:18:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 22:18:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 22:18:04 --> User Agent Class Initialized
INFO - 2018-06-19 22:18:04 --> Controller Class Initialized
INFO - 2018-06-19 22:18:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 22:18:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 22:18:04 --> Pixel_Model class loaded
INFO - 2018-06-19 22:18:04 --> Database Driver Class Initialized
INFO - 2018-06-19 22:18:04 --> Model "QuestionsModel" initialized
INFO - 2018-06-19 22:18:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 22:18:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 22:18:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-19 22:18:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 22:18:04 --> Final output sent to browser
DEBUG - 2018-06-19 22:18:04 --> Total execution time: 0.0444
INFO - 2018-06-19 22:18:25 --> Config Class Initialized
INFO - 2018-06-19 22:18:25 --> Hooks Class Initialized
DEBUG - 2018-06-19 22:18:25 --> UTF-8 Support Enabled
INFO - 2018-06-19 22:18:25 --> Utf8 Class Initialized
INFO - 2018-06-19 22:18:25 --> URI Class Initialized
DEBUG - 2018-06-19 22:18:25 --> No URI present. Default controller set.
INFO - 2018-06-19 22:18:25 --> Router Class Initialized
INFO - 2018-06-19 22:18:25 --> Output Class Initialized
INFO - 2018-06-19 22:18:25 --> Security Class Initialized
DEBUG - 2018-06-19 22:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 22:18:25 --> CSRF cookie sent
INFO - 2018-06-19 22:18:25 --> Input Class Initialized
INFO - 2018-06-19 22:18:25 --> Language Class Initialized
INFO - 2018-06-19 22:18:25 --> Loader Class Initialized
INFO - 2018-06-19 22:18:25 --> Helper loaded: url_helper
INFO - 2018-06-19 22:18:25 --> Helper loaded: form_helper
INFO - 2018-06-19 22:18:25 --> Helper loaded: language_helper
DEBUG - 2018-06-19 22:18:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 22:18:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 22:18:25 --> User Agent Class Initialized
INFO - 2018-06-19 22:18:25 --> Controller Class Initialized
INFO - 2018-06-19 22:18:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 22:18:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 22:18:25 --> Pixel_Model class loaded
INFO - 2018-06-19 22:18:25 --> Database Driver Class Initialized
INFO - 2018-06-19 22:18:25 --> Model "QuestionsModel" initialized
INFO - 2018-06-19 22:18:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 22:18:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 22:18:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-19 22:18:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 22:18:25 --> Final output sent to browser
DEBUG - 2018-06-19 22:18:25 --> Total execution time: 0.0741
INFO - 2018-06-19 23:00:54 --> Config Class Initialized
INFO - 2018-06-19 23:00:54 --> Hooks Class Initialized
DEBUG - 2018-06-19 23:00:54 --> UTF-8 Support Enabled
INFO - 2018-06-19 23:00:54 --> Utf8 Class Initialized
INFO - 2018-06-19 23:00:54 --> URI Class Initialized
DEBUG - 2018-06-19 23:00:54 --> No URI present. Default controller set.
INFO - 2018-06-19 23:00:54 --> Router Class Initialized
INFO - 2018-06-19 23:00:54 --> Output Class Initialized
INFO - 2018-06-19 23:00:54 --> Security Class Initialized
DEBUG - 2018-06-19 23:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 23:00:54 --> CSRF cookie sent
INFO - 2018-06-19 23:00:54 --> Input Class Initialized
INFO - 2018-06-19 23:00:54 --> Language Class Initialized
INFO - 2018-06-19 23:00:54 --> Loader Class Initialized
INFO - 2018-06-19 23:00:54 --> Helper loaded: url_helper
INFO - 2018-06-19 23:00:54 --> Helper loaded: form_helper
INFO - 2018-06-19 23:00:54 --> Helper loaded: language_helper
DEBUG - 2018-06-19 23:00:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 23:00:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 23:00:54 --> User Agent Class Initialized
INFO - 2018-06-19 23:00:54 --> Controller Class Initialized
INFO - 2018-06-19 23:00:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 23:00:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 23:00:54 --> Pixel_Model class loaded
INFO - 2018-06-19 23:00:54 --> Database Driver Class Initialized
INFO - 2018-06-19 23:00:54 --> Model "QuestionsModel" initialized
INFO - 2018-06-19 23:00:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 23:00:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 23:00:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-19 23:00:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 23:00:54 --> Final output sent to browser
DEBUG - 2018-06-19 23:00:54 --> Total execution time: 0.0506
INFO - 2018-06-19 23:01:08 --> Config Class Initialized
INFO - 2018-06-19 23:01:08 --> Hooks Class Initialized
DEBUG - 2018-06-19 23:01:08 --> UTF-8 Support Enabled
INFO - 2018-06-19 23:01:08 --> Utf8 Class Initialized
INFO - 2018-06-19 23:01:08 --> URI Class Initialized
INFO - 2018-06-19 23:01:08 --> Router Class Initialized
INFO - 2018-06-19 23:01:08 --> Output Class Initialized
INFO - 2018-06-19 23:01:08 --> Security Class Initialized
DEBUG - 2018-06-19 23:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 23:01:08 --> CSRF cookie sent
INFO - 2018-06-19 23:01:08 --> Input Class Initialized
INFO - 2018-06-19 23:01:08 --> Language Class Initialized
INFO - 2018-06-19 23:01:08 --> Loader Class Initialized
INFO - 2018-06-19 23:01:08 --> Helper loaded: url_helper
INFO - 2018-06-19 23:01:08 --> Helper loaded: form_helper
INFO - 2018-06-19 23:01:08 --> Helper loaded: language_helper
DEBUG - 2018-06-19 23:01:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 23:01:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 23:01:08 --> User Agent Class Initialized
INFO - 2018-06-19 23:01:08 --> Controller Class Initialized
INFO - 2018-06-19 23:01:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 23:01:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 23:01:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 23:01:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 23:01:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-19 23:01:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-19 23:01:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-06-19 23:01:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 23:01:08 --> Final output sent to browser
DEBUG - 2018-06-19 23:01:08 --> Total execution time: 0.0685
INFO - 2018-06-19 23:01:28 --> Config Class Initialized
INFO - 2018-06-19 23:01:28 --> Hooks Class Initialized
DEBUG - 2018-06-19 23:01:28 --> UTF-8 Support Enabled
INFO - 2018-06-19 23:01:28 --> Utf8 Class Initialized
INFO - 2018-06-19 23:01:28 --> URI Class Initialized
INFO - 2018-06-19 23:01:28 --> Router Class Initialized
INFO - 2018-06-19 23:01:28 --> Output Class Initialized
INFO - 2018-06-19 23:01:28 --> Security Class Initialized
DEBUG - 2018-06-19 23:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 23:01:28 --> CSRF cookie sent
INFO - 2018-06-19 23:01:28 --> Input Class Initialized
INFO - 2018-06-19 23:01:28 --> Language Class Initialized
INFO - 2018-06-19 23:01:28 --> Loader Class Initialized
INFO - 2018-06-19 23:01:28 --> Helper loaded: url_helper
INFO - 2018-06-19 23:01:28 --> Helper loaded: form_helper
INFO - 2018-06-19 23:01:28 --> Helper loaded: language_helper
DEBUG - 2018-06-19 23:01:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 23:01:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 23:01:28 --> User Agent Class Initialized
INFO - 2018-06-19 23:01:28 --> Controller Class Initialized
INFO - 2018-06-19 23:01:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 23:01:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 23:01:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 23:01:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 23:01:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-19 23:01:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-19 23:01:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-06-19 23:01:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 23:01:28 --> Final output sent to browser
DEBUG - 2018-06-19 23:01:28 --> Total execution time: 0.0427
INFO - 2018-06-19 23:01:44 --> Config Class Initialized
INFO - 2018-06-19 23:01:44 --> Hooks Class Initialized
DEBUG - 2018-06-19 23:01:44 --> UTF-8 Support Enabled
INFO - 2018-06-19 23:01:44 --> Utf8 Class Initialized
INFO - 2018-06-19 23:01:44 --> URI Class Initialized
DEBUG - 2018-06-19 23:01:44 --> No URI present. Default controller set.
INFO - 2018-06-19 23:01:44 --> Router Class Initialized
INFO - 2018-06-19 23:01:44 --> Output Class Initialized
INFO - 2018-06-19 23:01:44 --> Security Class Initialized
DEBUG - 2018-06-19 23:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 23:01:44 --> CSRF cookie sent
INFO - 2018-06-19 23:01:44 --> Input Class Initialized
INFO - 2018-06-19 23:01:44 --> Language Class Initialized
INFO - 2018-06-19 23:01:44 --> Loader Class Initialized
INFO - 2018-06-19 23:01:44 --> Helper loaded: url_helper
INFO - 2018-06-19 23:01:44 --> Helper loaded: form_helper
INFO - 2018-06-19 23:01:44 --> Helper loaded: language_helper
DEBUG - 2018-06-19 23:01:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 23:01:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 23:01:44 --> User Agent Class Initialized
INFO - 2018-06-19 23:01:44 --> Controller Class Initialized
INFO - 2018-06-19 23:01:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 23:01:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 23:01:44 --> Pixel_Model class loaded
INFO - 2018-06-19 23:01:44 --> Database Driver Class Initialized
INFO - 2018-06-19 23:01:44 --> Model "QuestionsModel" initialized
INFO - 2018-06-19 23:01:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 23:01:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 23:01:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-19 23:01:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 23:01:44 --> Final output sent to browser
DEBUG - 2018-06-19 23:01:44 --> Total execution time: 0.0696
INFO - 2018-06-19 23:02:56 --> Config Class Initialized
INFO - 2018-06-19 23:02:56 --> Hooks Class Initialized
DEBUG - 2018-06-19 23:02:57 --> UTF-8 Support Enabled
INFO - 2018-06-19 23:02:57 --> Utf8 Class Initialized
INFO - 2018-06-19 23:02:57 --> URI Class Initialized
DEBUG - 2018-06-19 23:02:57 --> No URI present. Default controller set.
INFO - 2018-06-19 23:02:57 --> Router Class Initialized
INFO - 2018-06-19 23:02:57 --> Output Class Initialized
INFO - 2018-06-19 23:02:57 --> Security Class Initialized
DEBUG - 2018-06-19 23:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 23:02:57 --> CSRF cookie sent
INFO - 2018-06-19 23:02:57 --> Input Class Initialized
INFO - 2018-06-19 23:02:57 --> Language Class Initialized
INFO - 2018-06-19 23:02:57 --> Loader Class Initialized
INFO - 2018-06-19 23:02:57 --> Helper loaded: url_helper
INFO - 2018-06-19 23:02:57 --> Helper loaded: form_helper
INFO - 2018-06-19 23:02:57 --> Helper loaded: language_helper
DEBUG - 2018-06-19 23:02:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 23:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 23:02:57 --> User Agent Class Initialized
INFO - 2018-06-19 23:02:57 --> Controller Class Initialized
INFO - 2018-06-19 23:02:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 23:02:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 23:02:57 --> Pixel_Model class loaded
INFO - 2018-06-19 23:02:57 --> Database Driver Class Initialized
INFO - 2018-06-19 23:02:57 --> Model "QuestionsModel" initialized
INFO - 2018-06-19 23:02:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 23:02:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 23:02:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-19 23:02:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 23:02:57 --> Final output sent to browser
DEBUG - 2018-06-19 23:02:57 --> Total execution time: 0.0827
INFO - 2018-06-19 23:03:07 --> Config Class Initialized
INFO - 2018-06-19 23:03:07 --> Hooks Class Initialized
DEBUG - 2018-06-19 23:03:07 --> UTF-8 Support Enabled
INFO - 2018-06-19 23:03:07 --> Utf8 Class Initialized
INFO - 2018-06-19 23:03:07 --> URI Class Initialized
INFO - 2018-06-19 23:03:07 --> Router Class Initialized
INFO - 2018-06-19 23:03:07 --> Output Class Initialized
INFO - 2018-06-19 23:03:07 --> Security Class Initialized
DEBUG - 2018-06-19 23:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-19 23:03:07 --> CSRF cookie sent
INFO - 2018-06-19 23:03:07 --> Input Class Initialized
INFO - 2018-06-19 23:03:07 --> Language Class Initialized
INFO - 2018-06-19 23:03:07 --> Loader Class Initialized
INFO - 2018-06-19 23:03:07 --> Helper loaded: url_helper
INFO - 2018-06-19 23:03:07 --> Helper loaded: form_helper
INFO - 2018-06-19 23:03:07 --> Helper loaded: language_helper
DEBUG - 2018-06-19 23:03:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-19 23:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-19 23:03:07 --> User Agent Class Initialized
INFO - 2018-06-19 23:03:07 --> Controller Class Initialized
INFO - 2018-06-19 23:03:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-19 23:03:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-19 23:03:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-19 23:03:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-19 23:03:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-19 23:03:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-19 23:03:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-06-19 23:03:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-19 23:03:07 --> Final output sent to browser
DEBUG - 2018-06-19 23:03:07 --> Total execution time: 0.0682

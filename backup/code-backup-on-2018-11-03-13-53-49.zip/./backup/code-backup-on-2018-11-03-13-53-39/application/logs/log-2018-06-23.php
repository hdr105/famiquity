<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-06-23 01:16:57 --> Config Class Initialized
INFO - 2018-06-23 01:16:57 --> Hooks Class Initialized
DEBUG - 2018-06-23 01:16:57 --> UTF-8 Support Enabled
INFO - 2018-06-23 01:16:57 --> Utf8 Class Initialized
INFO - 2018-06-23 01:16:57 --> URI Class Initialized
DEBUG - 2018-06-23 01:16:57 --> No URI present. Default controller set.
INFO - 2018-06-23 01:16:57 --> Router Class Initialized
INFO - 2018-06-23 01:16:57 --> Output Class Initialized
INFO - 2018-06-23 01:16:57 --> Security Class Initialized
DEBUG - 2018-06-23 01:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 01:16:57 --> CSRF cookie sent
INFO - 2018-06-23 01:16:57 --> Input Class Initialized
INFO - 2018-06-23 01:16:57 --> Language Class Initialized
INFO - 2018-06-23 01:16:57 --> Loader Class Initialized
INFO - 2018-06-23 01:16:57 --> Helper loaded: url_helper
INFO - 2018-06-23 01:16:57 --> Helper loaded: form_helper
INFO - 2018-06-23 01:16:57 --> Helper loaded: language_helper
DEBUG - 2018-06-23 01:16:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 01:16:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 01:16:57 --> User Agent Class Initialized
INFO - 2018-06-23 01:16:57 --> Controller Class Initialized
INFO - 2018-06-23 01:16:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-23 01:16:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-23 01:16:57 --> Pixel_Model class loaded
INFO - 2018-06-23 01:16:57 --> Database Driver Class Initialized
INFO - 2018-06-23 01:16:57 --> Model "QuestionsModel" initialized
INFO - 2018-06-23 01:16:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-23 01:16:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-23 01:16:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-23 01:16:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-23 01:16:57 --> Final output sent to browser
DEBUG - 2018-06-23 01:16:57 --> Total execution time: 0.0447
INFO - 2018-06-23 01:28:14 --> Config Class Initialized
INFO - 2018-06-23 01:28:14 --> Hooks Class Initialized
DEBUG - 2018-06-23 01:28:14 --> UTF-8 Support Enabled
INFO - 2018-06-23 01:28:14 --> Utf8 Class Initialized
INFO - 2018-06-23 01:28:14 --> URI Class Initialized
DEBUG - 2018-06-23 01:28:14 --> No URI present. Default controller set.
INFO - 2018-06-23 01:28:14 --> Router Class Initialized
INFO - 2018-06-23 01:28:14 --> Output Class Initialized
INFO - 2018-06-23 01:28:14 --> Security Class Initialized
DEBUG - 2018-06-23 01:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 01:28:14 --> CSRF cookie sent
INFO - 2018-06-23 01:28:14 --> Input Class Initialized
INFO - 2018-06-23 01:28:14 --> Language Class Initialized
INFO - 2018-06-23 01:28:14 --> Loader Class Initialized
INFO - 2018-06-23 01:28:14 --> Helper loaded: url_helper
INFO - 2018-06-23 01:28:14 --> Helper loaded: form_helper
INFO - 2018-06-23 01:28:14 --> Helper loaded: language_helper
DEBUG - 2018-06-23 01:28:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 01:28:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 01:28:14 --> User Agent Class Initialized
INFO - 2018-06-23 01:28:14 --> Controller Class Initialized
INFO - 2018-06-23 01:28:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-23 01:28:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-23 01:28:14 --> Pixel_Model class loaded
INFO - 2018-06-23 01:28:14 --> Database Driver Class Initialized
INFO - 2018-06-23 01:28:14 --> Model "QuestionsModel" initialized
INFO - 2018-06-23 01:28:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-23 01:28:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-23 01:28:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-23 01:28:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-23 01:28:14 --> Final output sent to browser
DEBUG - 2018-06-23 01:28:14 --> Total execution time: 0.0347
INFO - 2018-06-23 01:28:17 --> Config Class Initialized
INFO - 2018-06-23 01:28:17 --> Hooks Class Initialized
DEBUG - 2018-06-23 01:28:17 --> UTF-8 Support Enabled
INFO - 2018-06-23 01:28:17 --> Utf8 Class Initialized
INFO - 2018-06-23 01:28:17 --> URI Class Initialized
INFO - 2018-06-23 01:28:17 --> Router Class Initialized
INFO - 2018-06-23 01:28:17 --> Output Class Initialized
INFO - 2018-06-23 01:28:17 --> Security Class Initialized
DEBUG - 2018-06-23 01:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 01:28:17 --> CSRF cookie sent
INFO - 2018-06-23 01:28:17 --> Input Class Initialized
INFO - 2018-06-23 01:28:17 --> Language Class Initialized
INFO - 2018-06-23 01:28:17 --> Loader Class Initialized
INFO - 2018-06-23 01:28:17 --> Helper loaded: url_helper
INFO - 2018-06-23 01:28:17 --> Helper loaded: form_helper
INFO - 2018-06-23 01:28:17 --> Helper loaded: language_helper
DEBUG - 2018-06-23 01:28:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 01:28:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 01:28:17 --> User Agent Class Initialized
INFO - 2018-06-23 01:28:17 --> Controller Class Initialized
INFO - 2018-06-23 01:28:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-23 01:28:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-23 01:28:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-23 01:28:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-23 01:28:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-23 01:28:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-23 01:28:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-06-23 01:28:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-23 01:28:17 --> Final output sent to browser
DEBUG - 2018-06-23 01:28:17 --> Total execution time: 0.0262
INFO - 2018-06-23 01:28:22 --> Config Class Initialized
INFO - 2018-06-23 01:28:22 --> Hooks Class Initialized
DEBUG - 2018-06-23 01:28:22 --> UTF-8 Support Enabled
INFO - 2018-06-23 01:28:22 --> Utf8 Class Initialized
INFO - 2018-06-23 01:28:22 --> URI Class Initialized
INFO - 2018-06-23 01:28:22 --> Router Class Initialized
INFO - 2018-06-23 01:28:22 --> Output Class Initialized
INFO - 2018-06-23 01:28:22 --> Security Class Initialized
DEBUG - 2018-06-23 01:28:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 01:28:22 --> CSRF cookie sent
INFO - 2018-06-23 01:28:22 --> Input Class Initialized
INFO - 2018-06-23 01:28:22 --> Language Class Initialized
ERROR - 2018-06-23 01:28:22 --> 404 Page Not Found: Faviconico/index
INFO - 2018-06-23 01:28:25 --> Config Class Initialized
INFO - 2018-06-23 01:28:25 --> Hooks Class Initialized
DEBUG - 2018-06-23 01:28:25 --> UTF-8 Support Enabled
INFO - 2018-06-23 01:28:25 --> Utf8 Class Initialized
INFO - 2018-06-23 01:28:25 --> URI Class Initialized
INFO - 2018-06-23 01:28:25 --> Router Class Initialized
INFO - 2018-06-23 01:28:25 --> Output Class Initialized
INFO - 2018-06-23 01:28:25 --> Security Class Initialized
DEBUG - 2018-06-23 01:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 01:28:25 --> CSRF cookie sent
INFO - 2018-06-23 01:28:25 --> Input Class Initialized
INFO - 2018-06-23 01:28:25 --> Language Class Initialized
INFO - 2018-06-23 01:28:25 --> Loader Class Initialized
INFO - 2018-06-23 01:28:25 --> Helper loaded: url_helper
INFO - 2018-06-23 01:28:25 --> Helper loaded: form_helper
INFO - 2018-06-23 01:28:25 --> Helper loaded: language_helper
DEBUG - 2018-06-23 01:28:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 01:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 01:28:25 --> User Agent Class Initialized
INFO - 2018-06-23 01:28:25 --> Controller Class Initialized
INFO - 2018-06-23 01:28:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-23 01:28:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-23 01:28:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-23 01:28:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-23 01:28:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-23 01:28:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-23 01:28:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-06-23 01:28:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-23 01:28:25 --> Final output sent to browser
DEBUG - 2018-06-23 01:28:25 --> Total execution time: 0.0219
INFO - 2018-06-23 01:28:34 --> Config Class Initialized
INFO - 2018-06-23 01:28:34 --> Hooks Class Initialized
DEBUG - 2018-06-23 01:28:34 --> UTF-8 Support Enabled
INFO - 2018-06-23 01:28:34 --> Utf8 Class Initialized
INFO - 2018-06-23 01:28:34 --> URI Class Initialized
INFO - 2018-06-23 01:28:34 --> Router Class Initialized
INFO - 2018-06-23 01:28:34 --> Output Class Initialized
INFO - 2018-06-23 01:28:34 --> Security Class Initialized
DEBUG - 2018-06-23 01:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 01:28:34 --> CSRF cookie sent
INFO - 2018-06-23 01:28:34 --> Input Class Initialized
INFO - 2018-06-23 01:28:34 --> Language Class Initialized
INFO - 2018-06-23 01:28:34 --> Loader Class Initialized
INFO - 2018-06-23 01:28:34 --> Helper loaded: url_helper
INFO - 2018-06-23 01:28:34 --> Helper loaded: form_helper
INFO - 2018-06-23 01:28:34 --> Helper loaded: language_helper
DEBUG - 2018-06-23 01:28:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 01:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 01:28:34 --> User Agent Class Initialized
INFO - 2018-06-23 01:28:34 --> Controller Class Initialized
INFO - 2018-06-23 01:28:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-23 01:28:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-23 01:28:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-23 01:28:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-23 01:28:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-23 01:28:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-23 01:28:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-06-23 01:28:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-23 01:28:34 --> Final output sent to browser
DEBUG - 2018-06-23 01:28:34 --> Total execution time: 0.0222
INFO - 2018-06-23 01:28:38 --> Config Class Initialized
INFO - 2018-06-23 01:28:38 --> Hooks Class Initialized
DEBUG - 2018-06-23 01:28:38 --> UTF-8 Support Enabled
INFO - 2018-06-23 01:28:38 --> Utf8 Class Initialized
INFO - 2018-06-23 01:28:38 --> URI Class Initialized
INFO - 2018-06-23 01:28:38 --> Router Class Initialized
INFO - 2018-06-23 01:28:38 --> Output Class Initialized
INFO - 2018-06-23 01:28:38 --> Security Class Initialized
DEBUG - 2018-06-23 01:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 01:28:38 --> CSRF cookie sent
INFO - 2018-06-23 01:28:38 --> Input Class Initialized
INFO - 2018-06-23 01:28:38 --> Language Class Initialized
INFO - 2018-06-23 01:28:38 --> Loader Class Initialized
INFO - 2018-06-23 01:28:38 --> Helper loaded: url_helper
INFO - 2018-06-23 01:28:38 --> Helper loaded: form_helper
INFO - 2018-06-23 01:28:38 --> Helper loaded: language_helper
DEBUG - 2018-06-23 01:28:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 01:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 01:28:38 --> User Agent Class Initialized
INFO - 2018-06-23 01:28:38 --> Controller Class Initialized
INFO - 2018-06-23 01:28:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-23 01:28:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-23 01:28:38 --> Pixel_Model class loaded
INFO - 2018-06-23 01:28:38 --> Database Driver Class Initialized
INFO - 2018-06-23 01:28:38 --> Model "QuestionsModel" initialized
INFO - 2018-06-23 01:28:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-23 01:28:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-23 01:28:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-23 01:28:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-23 01:28:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/buy_gift.php
INFO - 2018-06-23 01:28:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-23 01:28:38 --> Final output sent to browser
DEBUG - 2018-06-23 01:28:38 --> Total execution time: 0.0330
INFO - 2018-06-23 01:30:15 --> Config Class Initialized
INFO - 2018-06-23 01:30:15 --> Hooks Class Initialized
DEBUG - 2018-06-23 01:30:15 --> UTF-8 Support Enabled
INFO - 2018-06-23 01:30:15 --> Utf8 Class Initialized
INFO - 2018-06-23 01:30:15 --> URI Class Initialized
INFO - 2018-06-23 01:30:15 --> Router Class Initialized
INFO - 2018-06-23 01:30:15 --> Output Class Initialized
INFO - 2018-06-23 01:30:15 --> Security Class Initialized
DEBUG - 2018-06-23 01:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 01:30:15 --> CSRF cookie sent
INFO - 2018-06-23 01:30:15 --> Input Class Initialized
INFO - 2018-06-23 01:30:15 --> Language Class Initialized
INFO - 2018-06-23 01:30:15 --> Loader Class Initialized
INFO - 2018-06-23 01:30:15 --> Helper loaded: url_helper
INFO - 2018-06-23 01:30:15 --> Helper loaded: form_helper
INFO - 2018-06-23 01:30:15 --> Helper loaded: language_helper
DEBUG - 2018-06-23 01:30:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 01:30:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 01:30:15 --> User Agent Class Initialized
INFO - 2018-06-23 01:30:15 --> Controller Class Initialized
INFO - 2018-06-23 01:30:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-23 01:30:15 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-23 01:30:15 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-23 01:30:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-23 01:30:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-23 01:30:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-23 01:30:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-23 01:30:15 --> Could not find the language line "req_email"
INFO - 2018-06-23 01:30:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-06-23 01:30:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-23 01:30:15 --> Final output sent to browser
DEBUG - 2018-06-23 01:30:15 --> Total execution time: 0.0236
INFO - 2018-06-23 01:30:18 --> Config Class Initialized
INFO - 2018-06-23 01:30:18 --> Hooks Class Initialized
DEBUG - 2018-06-23 01:30:18 --> UTF-8 Support Enabled
INFO - 2018-06-23 01:30:18 --> Utf8 Class Initialized
INFO - 2018-06-23 01:30:18 --> URI Class Initialized
INFO - 2018-06-23 01:30:18 --> Router Class Initialized
INFO - 2018-06-23 01:30:18 --> Output Class Initialized
INFO - 2018-06-23 01:30:18 --> Security Class Initialized
DEBUG - 2018-06-23 01:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 01:30:18 --> CSRF cookie sent
INFO - 2018-06-23 01:30:18 --> Input Class Initialized
INFO - 2018-06-23 01:30:18 --> Language Class Initialized
INFO - 2018-06-23 01:30:18 --> Loader Class Initialized
INFO - 2018-06-23 01:30:18 --> Helper loaded: url_helper
INFO - 2018-06-23 01:30:18 --> Helper loaded: form_helper
INFO - 2018-06-23 01:30:18 --> Helper loaded: language_helper
DEBUG - 2018-06-23 01:30:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 01:30:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 01:30:18 --> User Agent Class Initialized
INFO - 2018-06-23 01:30:18 --> Controller Class Initialized
INFO - 2018-06-23 01:30:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-23 01:30:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-23 01:30:18 --> Pixel_Model class loaded
INFO - 2018-06-23 01:30:18 --> Database Driver Class Initialized
INFO - 2018-06-23 01:30:18 --> Model "RegistrationModel" initialized
DEBUG - 2018-06-23 01:30:18 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-23 01:30:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-23 01:30:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-23 01:30:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-23 01:30:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-23 01:30:18 --> Could not find the language line "req_email"
INFO - 2018-06-23 01:30:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup.php
INFO - 2018-06-23 01:30:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-23 01:30:18 --> Final output sent to browser
DEBUG - 2018-06-23 01:30:18 --> Total execution time: 0.0330
INFO - 2018-06-23 03:23:10 --> Config Class Initialized
INFO - 2018-06-23 03:23:10 --> Hooks Class Initialized
DEBUG - 2018-06-23 03:23:10 --> UTF-8 Support Enabled
INFO - 2018-06-23 03:23:10 --> Utf8 Class Initialized
INFO - 2018-06-23 03:23:10 --> URI Class Initialized
INFO - 2018-06-23 03:23:10 --> Router Class Initialized
INFO - 2018-06-23 03:23:10 --> Output Class Initialized
INFO - 2018-06-23 03:23:10 --> Security Class Initialized
DEBUG - 2018-06-23 03:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 03:23:10 --> CSRF cookie sent
INFO - 2018-06-23 03:23:10 --> Input Class Initialized
INFO - 2018-06-23 03:23:10 --> Language Class Initialized
ERROR - 2018-06-23 03:23:10 --> 404 Page Not Found: NNibZ/index
INFO - 2018-06-23 04:19:01 --> Config Class Initialized
INFO - 2018-06-23 04:19:01 --> Hooks Class Initialized
DEBUG - 2018-06-23 04:19:01 --> UTF-8 Support Enabled
INFO - 2018-06-23 04:19:01 --> Utf8 Class Initialized
INFO - 2018-06-23 04:19:01 --> URI Class Initialized
DEBUG - 2018-06-23 04:19:01 --> No URI present. Default controller set.
INFO - 2018-06-23 04:19:01 --> Router Class Initialized
INFO - 2018-06-23 04:19:01 --> Output Class Initialized
INFO - 2018-06-23 04:19:01 --> Security Class Initialized
DEBUG - 2018-06-23 04:19:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 04:19:01 --> CSRF cookie sent
INFO - 2018-06-23 04:19:01 --> Input Class Initialized
INFO - 2018-06-23 04:19:01 --> Language Class Initialized
INFO - 2018-06-23 04:19:01 --> Loader Class Initialized
INFO - 2018-06-23 04:19:01 --> Helper loaded: url_helper
INFO - 2018-06-23 04:19:01 --> Helper loaded: form_helper
INFO - 2018-06-23 04:19:01 --> Helper loaded: language_helper
DEBUG - 2018-06-23 04:19:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 04:19:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 04:19:01 --> User Agent Class Initialized
INFO - 2018-06-23 04:19:01 --> Controller Class Initialized
INFO - 2018-06-23 04:19:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-23 04:19:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-23 04:19:01 --> Pixel_Model class loaded
INFO - 2018-06-23 04:19:01 --> Database Driver Class Initialized
INFO - 2018-06-23 04:19:01 --> Model "QuestionsModel" initialized
INFO - 2018-06-23 04:19:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-23 04:19:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-23 04:19:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-23 04:19:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-23 04:19:01 --> Final output sent to browser
DEBUG - 2018-06-23 04:19:01 --> Total execution time: 0.0316
INFO - 2018-06-23 10:12:24 --> Config Class Initialized
INFO - 2018-06-23 10:12:24 --> Hooks Class Initialized
DEBUG - 2018-06-23 10:12:24 --> UTF-8 Support Enabled
INFO - 2018-06-23 10:12:24 --> Utf8 Class Initialized
INFO - 2018-06-23 10:12:24 --> URI Class Initialized
DEBUG - 2018-06-23 10:12:24 --> No URI present. Default controller set.
INFO - 2018-06-23 10:12:24 --> Router Class Initialized
INFO - 2018-06-23 10:12:24 --> Output Class Initialized
INFO - 2018-06-23 10:12:24 --> Security Class Initialized
DEBUG - 2018-06-23 10:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 10:12:24 --> CSRF cookie sent
INFO - 2018-06-23 10:12:24 --> Input Class Initialized
INFO - 2018-06-23 10:12:24 --> Language Class Initialized
INFO - 2018-06-23 10:12:24 --> Loader Class Initialized
INFO - 2018-06-23 10:12:24 --> Helper loaded: url_helper
INFO - 2018-06-23 10:12:24 --> Helper loaded: form_helper
INFO - 2018-06-23 10:12:24 --> Helper loaded: language_helper
DEBUG - 2018-06-23 10:12:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 10:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 10:12:24 --> User Agent Class Initialized
INFO - 2018-06-23 10:12:24 --> Controller Class Initialized
INFO - 2018-06-23 10:12:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-23 10:12:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-23 10:12:24 --> Pixel_Model class loaded
INFO - 2018-06-23 10:12:24 --> Database Driver Class Initialized
INFO - 2018-06-23 10:12:24 --> Model "QuestionsModel" initialized
INFO - 2018-06-23 10:12:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-23 10:12:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-23 10:12:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-23 10:12:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-23 10:12:24 --> Final output sent to browser
DEBUG - 2018-06-23 10:12:24 --> Total execution time: 0.0332
INFO - 2018-06-23 16:00:00 --> Config Class Initialized
INFO - 2018-06-23 16:00:00 --> Hooks Class Initialized
DEBUG - 2018-06-23 16:00:00 --> UTF-8 Support Enabled
INFO - 2018-06-23 16:00:00 --> Utf8 Class Initialized
INFO - 2018-06-23 16:00:00 --> URI Class Initialized
DEBUG - 2018-06-23 16:00:00 --> No URI present. Default controller set.
INFO - 2018-06-23 16:00:00 --> Router Class Initialized
INFO - 2018-06-23 16:00:00 --> Output Class Initialized
INFO - 2018-06-23 16:00:00 --> Security Class Initialized
DEBUG - 2018-06-23 16:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 16:00:00 --> CSRF cookie sent
INFO - 2018-06-23 16:00:00 --> Input Class Initialized
INFO - 2018-06-23 16:00:00 --> Language Class Initialized
INFO - 2018-06-23 16:00:00 --> Loader Class Initialized
INFO - 2018-06-23 16:00:00 --> Helper loaded: url_helper
INFO - 2018-06-23 16:00:00 --> Helper loaded: form_helper
INFO - 2018-06-23 16:00:00 --> Helper loaded: language_helper
DEBUG - 2018-06-23 16:00:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 16:00:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 16:00:00 --> User Agent Class Initialized
INFO - 2018-06-23 16:00:00 --> Controller Class Initialized
INFO - 2018-06-23 16:00:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-23 16:00:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-23 16:00:00 --> Pixel_Model class loaded
INFO - 2018-06-23 16:00:00 --> Database Driver Class Initialized
INFO - 2018-06-23 16:00:00 --> Model "QuestionsModel" initialized
INFO - 2018-06-23 16:00:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-23 16:00:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-23 16:00:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-23 16:00:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-23 16:00:00 --> Final output sent to browser
DEBUG - 2018-06-23 16:00:00 --> Total execution time: 0.0390
INFO - 2018-06-23 17:01:03 --> Config Class Initialized
INFO - 2018-06-23 17:01:03 --> Hooks Class Initialized
DEBUG - 2018-06-23 17:01:03 --> UTF-8 Support Enabled
INFO - 2018-06-23 17:01:03 --> Utf8 Class Initialized
INFO - 2018-06-23 17:01:03 --> URI Class Initialized
DEBUG - 2018-06-23 17:01:03 --> No URI present. Default controller set.
INFO - 2018-06-23 17:01:03 --> Router Class Initialized
INFO - 2018-06-23 17:01:03 --> Output Class Initialized
INFO - 2018-06-23 17:01:03 --> Security Class Initialized
DEBUG - 2018-06-23 17:01:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 17:01:03 --> CSRF cookie sent
INFO - 2018-06-23 17:01:03 --> Input Class Initialized
INFO - 2018-06-23 17:01:03 --> Language Class Initialized
INFO - 2018-06-23 17:01:03 --> Loader Class Initialized
INFO - 2018-06-23 17:01:03 --> Helper loaded: url_helper
INFO - 2018-06-23 17:01:03 --> Helper loaded: form_helper
INFO - 2018-06-23 17:01:03 --> Helper loaded: language_helper
DEBUG - 2018-06-23 17:01:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 17:01:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 17:01:03 --> User Agent Class Initialized
INFO - 2018-06-23 17:01:03 --> Controller Class Initialized
INFO - 2018-06-23 17:01:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-23 17:01:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-23 17:01:03 --> Pixel_Model class loaded
INFO - 2018-06-23 17:01:03 --> Database Driver Class Initialized
INFO - 2018-06-23 17:01:03 --> Model "QuestionsModel" initialized
INFO - 2018-06-23 17:01:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-23 17:01:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-23 17:01:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-23 17:01:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-23 17:01:03 --> Final output sent to browser
DEBUG - 2018-06-23 17:01:03 --> Total execution time: 0.0370
INFO - 2018-06-23 17:16:11 --> Config Class Initialized
INFO - 2018-06-23 17:16:11 --> Hooks Class Initialized
DEBUG - 2018-06-23 17:16:11 --> UTF-8 Support Enabled
INFO - 2018-06-23 17:16:11 --> Utf8 Class Initialized
INFO - 2018-06-23 17:16:11 --> URI Class Initialized
DEBUG - 2018-06-23 17:16:11 --> No URI present. Default controller set.
INFO - 2018-06-23 17:16:11 --> Router Class Initialized
INFO - 2018-06-23 17:16:11 --> Output Class Initialized
INFO - 2018-06-23 17:16:11 --> Security Class Initialized
DEBUG - 2018-06-23 17:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 17:16:11 --> CSRF cookie sent
INFO - 2018-06-23 17:16:11 --> Input Class Initialized
INFO - 2018-06-23 17:16:11 --> Language Class Initialized
INFO - 2018-06-23 17:16:11 --> Loader Class Initialized
INFO - 2018-06-23 17:16:11 --> Helper loaded: url_helper
INFO - 2018-06-23 17:16:11 --> Helper loaded: form_helper
INFO - 2018-06-23 17:16:11 --> Helper loaded: language_helper
DEBUG - 2018-06-23 17:16:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 17:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 17:16:11 --> User Agent Class Initialized
INFO - 2018-06-23 17:16:11 --> Controller Class Initialized
INFO - 2018-06-23 17:16:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-23 17:16:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-23 17:16:11 --> Pixel_Model class loaded
INFO - 2018-06-23 17:16:11 --> Database Driver Class Initialized
INFO - 2018-06-23 17:16:11 --> Model "QuestionsModel" initialized
INFO - 2018-06-23 17:16:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-23 17:16:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-23 17:16:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-23 17:16:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-23 17:16:11 --> Final output sent to browser
DEBUG - 2018-06-23 17:16:11 --> Total execution time: 0.0353
INFO - 2018-06-23 17:16:11 --> Config Class Initialized
INFO - 2018-06-23 17:16:11 --> Hooks Class Initialized
DEBUG - 2018-06-23 17:16:11 --> UTF-8 Support Enabled
INFO - 2018-06-23 17:16:11 --> Utf8 Class Initialized
INFO - 2018-06-23 17:16:11 --> URI Class Initialized
DEBUG - 2018-06-23 17:16:11 --> No URI present. Default controller set.
INFO - 2018-06-23 17:16:11 --> Router Class Initialized
INFO - 2018-06-23 17:16:11 --> Output Class Initialized
INFO - 2018-06-23 17:16:11 --> Security Class Initialized
DEBUG - 2018-06-23 17:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 17:16:11 --> CSRF cookie sent
INFO - 2018-06-23 17:16:11 --> Input Class Initialized
INFO - 2018-06-23 17:16:11 --> Language Class Initialized
INFO - 2018-06-23 17:16:11 --> Loader Class Initialized
INFO - 2018-06-23 17:16:11 --> Helper loaded: url_helper
INFO - 2018-06-23 17:16:11 --> Helper loaded: form_helper
INFO - 2018-06-23 17:16:11 --> Helper loaded: language_helper
DEBUG - 2018-06-23 17:16:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 17:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 17:16:11 --> User Agent Class Initialized
INFO - 2018-06-23 17:16:11 --> Controller Class Initialized
INFO - 2018-06-23 17:16:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-23 17:16:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-23 17:16:11 --> Pixel_Model class loaded
INFO - 2018-06-23 17:16:11 --> Database Driver Class Initialized
INFO - 2018-06-23 17:16:11 --> Model "QuestionsModel" initialized
INFO - 2018-06-23 17:16:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-23 17:16:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-23 17:16:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-23 17:16:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-23 17:16:11 --> Final output sent to browser
DEBUG - 2018-06-23 17:16:11 --> Total execution time: 0.0319
INFO - 2018-06-23 17:16:12 --> Config Class Initialized
INFO - 2018-06-23 17:16:12 --> Hooks Class Initialized
DEBUG - 2018-06-23 17:16:12 --> UTF-8 Support Enabled
INFO - 2018-06-23 17:16:12 --> Utf8 Class Initialized
INFO - 2018-06-23 17:16:12 --> URI Class Initialized
DEBUG - 2018-06-23 17:16:12 --> No URI present. Default controller set.
INFO - 2018-06-23 17:16:12 --> Router Class Initialized
INFO - 2018-06-23 17:16:12 --> Output Class Initialized
INFO - 2018-06-23 17:16:12 --> Security Class Initialized
DEBUG - 2018-06-23 17:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 17:16:12 --> CSRF cookie sent
INFO - 2018-06-23 17:16:12 --> Input Class Initialized
INFO - 2018-06-23 17:16:12 --> Language Class Initialized
INFO - 2018-06-23 17:16:12 --> Loader Class Initialized
INFO - 2018-06-23 17:16:12 --> Helper loaded: url_helper
INFO - 2018-06-23 17:16:12 --> Helper loaded: form_helper
INFO - 2018-06-23 17:16:12 --> Helper loaded: language_helper
DEBUG - 2018-06-23 17:16:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 17:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 17:16:12 --> User Agent Class Initialized
INFO - 2018-06-23 17:16:12 --> Controller Class Initialized
INFO - 2018-06-23 17:16:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-23 17:16:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-23 17:16:12 --> Pixel_Model class loaded
INFO - 2018-06-23 17:16:12 --> Database Driver Class Initialized
INFO - 2018-06-23 17:16:12 --> Model "QuestionsModel" initialized
INFO - 2018-06-23 17:16:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-23 17:16:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-23 17:16:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-23 17:16:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-23 17:16:12 --> Final output sent to browser
DEBUG - 2018-06-23 17:16:12 --> Total execution time: 0.0526
INFO - 2018-06-23 17:16:13 --> Config Class Initialized
INFO - 2018-06-23 17:16:13 --> Hooks Class Initialized
DEBUG - 2018-06-23 17:16:13 --> UTF-8 Support Enabled
INFO - 2018-06-23 17:16:13 --> Utf8 Class Initialized
INFO - 2018-06-23 17:16:13 --> URI Class Initialized
INFO - 2018-06-23 17:16:13 --> Router Class Initialized
INFO - 2018-06-23 17:16:13 --> Output Class Initialized
INFO - 2018-06-23 17:16:13 --> Security Class Initialized
DEBUG - 2018-06-23 17:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 17:16:13 --> CSRF cookie sent
INFO - 2018-06-23 17:16:13 --> Input Class Initialized
INFO - 2018-06-23 17:16:13 --> Language Class Initialized
ERROR - 2018-06-23 17:16:13 --> 404 Page Not Found: 405shtml/index
INFO - 2018-06-23 17:16:19 --> Config Class Initialized
INFO - 2018-06-23 17:16:19 --> Hooks Class Initialized
DEBUG - 2018-06-23 17:16:19 --> UTF-8 Support Enabled
INFO - 2018-06-23 17:16:19 --> Utf8 Class Initialized
INFO - 2018-06-23 17:16:19 --> URI Class Initialized
DEBUG - 2018-06-23 17:16:19 --> No URI present. Default controller set.
INFO - 2018-06-23 17:16:19 --> Router Class Initialized
INFO - 2018-06-23 17:16:19 --> Output Class Initialized
INFO - 2018-06-23 17:16:19 --> Security Class Initialized
DEBUG - 2018-06-23 17:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 17:16:19 --> CSRF cookie sent
INFO - 2018-06-23 17:16:19 --> Input Class Initialized
INFO - 2018-06-23 17:16:19 --> Language Class Initialized
INFO - 2018-06-23 17:16:19 --> Loader Class Initialized
INFO - 2018-06-23 17:16:19 --> Helper loaded: url_helper
INFO - 2018-06-23 17:16:19 --> Helper loaded: form_helper
INFO - 2018-06-23 17:16:19 --> Helper loaded: language_helper
DEBUG - 2018-06-23 17:16:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 17:16:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 17:16:19 --> User Agent Class Initialized
INFO - 2018-06-23 17:16:19 --> Controller Class Initialized
INFO - 2018-06-23 17:16:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-23 17:16:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-23 17:16:19 --> Pixel_Model class loaded
INFO - 2018-06-23 17:16:19 --> Database Driver Class Initialized
INFO - 2018-06-23 17:16:19 --> Model "QuestionsModel" initialized
INFO - 2018-06-23 17:16:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-23 17:16:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-23 17:16:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-23 17:16:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-23 17:16:19 --> Final output sent to browser
DEBUG - 2018-06-23 17:16:19 --> Total execution time: 0.0322
INFO - 2018-06-23 17:16:19 --> Config Class Initialized
INFO - 2018-06-23 17:16:19 --> Hooks Class Initialized
DEBUG - 2018-06-23 17:16:19 --> UTF-8 Support Enabled
INFO - 2018-06-23 17:16:19 --> Utf8 Class Initialized
INFO - 2018-06-23 17:16:19 --> URI Class Initialized
INFO - 2018-06-23 17:16:19 --> Router Class Initialized
INFO - 2018-06-23 17:16:19 --> Output Class Initialized
INFO - 2018-06-23 17:16:19 --> Security Class Initialized
DEBUG - 2018-06-23 17:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 17:16:19 --> CSRF cookie sent
INFO - 2018-06-23 17:16:19 --> Input Class Initialized
INFO - 2018-06-23 17:16:19 --> Language Class Initialized
ERROR - 2018-06-23 17:16:19 --> 404 Page Not Found: 404testpage4525d2fdc/index
INFO - 2018-06-23 17:16:20 --> Config Class Initialized
INFO - 2018-06-23 17:16:20 --> Hooks Class Initialized
DEBUG - 2018-06-23 17:16:20 --> UTF-8 Support Enabled
INFO - 2018-06-23 17:16:20 --> Utf8 Class Initialized
INFO - 2018-06-23 17:16:20 --> URI Class Initialized
INFO - 2018-06-23 17:16:20 --> Router Class Initialized
INFO - 2018-06-23 17:16:20 --> Output Class Initialized
INFO - 2018-06-23 17:16:20 --> Security Class Initialized
DEBUG - 2018-06-23 17:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 17:16:20 --> CSRF cookie sent
INFO - 2018-06-23 17:16:20 --> Input Class Initialized
INFO - 2018-06-23 17:16:20 --> Language Class Initialized
ERROR - 2018-06-23 17:16:20 --> 404 Page Not Found: 404javascriptjs/index
INFO - 2018-06-23 17:16:20 --> Config Class Initialized
INFO - 2018-06-23 17:16:20 --> Hooks Class Initialized
DEBUG - 2018-06-23 17:16:20 --> UTF-8 Support Enabled
INFO - 2018-06-23 17:16:20 --> Utf8 Class Initialized
INFO - 2018-06-23 17:16:20 --> URI Class Initialized
INFO - 2018-06-23 17:16:20 --> Router Class Initialized
INFO - 2018-06-23 17:16:20 --> Output Class Initialized
INFO - 2018-06-23 17:16:20 --> Security Class Initialized
DEBUG - 2018-06-23 17:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 17:16:20 --> CSRF cookie sent
INFO - 2018-06-23 17:16:20 --> Input Class Initialized
INFO - 2018-06-23 17:16:20 --> Language Class Initialized
INFO - 2018-06-23 17:16:20 --> Loader Class Initialized
INFO - 2018-06-23 17:16:20 --> Helper loaded: url_helper
INFO - 2018-06-23 17:16:20 --> Helper loaded: form_helper
INFO - 2018-06-23 17:16:20 --> Helper loaded: language_helper
DEBUG - 2018-06-23 17:16:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 17:16:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 17:16:20 --> User Agent Class Initialized
INFO - 2018-06-23 17:16:20 --> Controller Class Initialized
INFO - 2018-06-23 17:16:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-23 17:16:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-23 17:16:20 --> Pixel_Model class loaded
INFO - 2018-06-23 17:16:20 --> Database Driver Class Initialized
INFO - 2018-06-23 17:16:20 --> Model "QuestionsModel" initialized
ERROR - 2018-06-23 17:16:20 --> Severity: Notice --> Undefined index: HTTP_REFERER /home/fxp6bn7rqemh/public_html/application/core/Pixel_Controller.php 87
INFO - 2018-06-23 17:16:20 --> Config Class Initialized
INFO - 2018-06-23 17:16:20 --> Hooks Class Initialized
DEBUG - 2018-06-23 17:16:20 --> UTF-8 Support Enabled
INFO - 2018-06-23 17:16:20 --> Utf8 Class Initialized
INFO - 2018-06-23 17:16:20 --> URI Class Initialized
INFO - 2018-06-23 17:16:20 --> Router Class Initialized
INFO - 2018-06-23 17:16:20 --> Output Class Initialized
INFO - 2018-06-23 17:16:20 --> Security Class Initialized
DEBUG - 2018-06-23 17:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 17:16:20 --> CSRF cookie sent
INFO - 2018-06-23 17:16:20 --> Input Class Initialized
INFO - 2018-06-23 17:16:20 --> Language Class Initialized
INFO - 2018-06-23 17:16:20 --> Loader Class Initialized
INFO - 2018-06-23 17:16:20 --> Helper loaded: url_helper
INFO - 2018-06-23 17:16:20 --> Helper loaded: form_helper
INFO - 2018-06-23 17:16:20 --> Helper loaded: language_helper
DEBUG - 2018-06-23 17:16:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 17:16:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 17:16:20 --> User Agent Class Initialized
INFO - 2018-06-23 17:16:20 --> Controller Class Initialized
INFO - 2018-06-23 17:16:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-23 17:16:20 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-23 17:16:20 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-23 17:16:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-23 17:16:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-23 17:16:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-23 17:16:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-23 17:16:20 --> Could not find the language line "req_email"
INFO - 2018-06-23 17:16:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-06-23 17:16:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-23 17:16:20 --> Final output sent to browser
DEBUG - 2018-06-23 17:16:20 --> Total execution time: 0.0266
INFO - 2018-06-23 17:16:20 --> Config Class Initialized
INFO - 2018-06-23 17:16:20 --> Hooks Class Initialized
DEBUG - 2018-06-23 17:16:20 --> UTF-8 Support Enabled
INFO - 2018-06-23 17:16:20 --> Utf8 Class Initialized
INFO - 2018-06-23 17:16:20 --> URI Class Initialized
INFO - 2018-06-23 17:16:20 --> Router Class Initialized
INFO - 2018-06-23 17:16:20 --> Output Class Initialized
INFO - 2018-06-23 17:16:20 --> Security Class Initialized
DEBUG - 2018-06-23 17:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 17:16:20 --> CSRF cookie sent
INFO - 2018-06-23 17:16:20 --> Input Class Initialized
INFO - 2018-06-23 17:16:20 --> Language Class Initialized
INFO - 2018-06-23 17:16:20 --> Loader Class Initialized
INFO - 2018-06-23 17:16:20 --> Helper loaded: url_helper
INFO - 2018-06-23 17:16:20 --> Helper loaded: form_helper
INFO - 2018-06-23 17:16:20 --> Helper loaded: language_helper
DEBUG - 2018-06-23 17:16:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 17:16:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 17:16:20 --> User Agent Class Initialized
INFO - 2018-06-23 17:16:20 --> Controller Class Initialized
INFO - 2018-06-23 17:16:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-23 17:16:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-23 17:16:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-23 17:16:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-23 17:16:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-23 17:16:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-23 17:16:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-06-23 17:16:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-23 17:16:20 --> Final output sent to browser
DEBUG - 2018-06-23 17:16:20 --> Total execution time: 0.0216
INFO - 2018-06-23 17:16:21 --> Config Class Initialized
INFO - 2018-06-23 17:16:21 --> Hooks Class Initialized
DEBUG - 2018-06-23 17:16:21 --> UTF-8 Support Enabled
INFO - 2018-06-23 17:16:21 --> Utf8 Class Initialized
INFO - 2018-06-23 17:16:21 --> URI Class Initialized
INFO - 2018-06-23 17:16:21 --> Router Class Initialized
INFO - 2018-06-23 17:16:21 --> Output Class Initialized
INFO - 2018-06-23 17:16:21 --> Security Class Initialized
DEBUG - 2018-06-23 17:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 17:16:21 --> CSRF cookie sent
INFO - 2018-06-23 17:16:21 --> Input Class Initialized
INFO - 2018-06-23 17:16:21 --> Language Class Initialized
INFO - 2018-06-23 17:16:21 --> Loader Class Initialized
INFO - 2018-06-23 17:16:21 --> Helper loaded: url_helper
INFO - 2018-06-23 17:16:21 --> Helper loaded: form_helper
INFO - 2018-06-23 17:16:21 --> Helper loaded: language_helper
DEBUG - 2018-06-23 17:16:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 17:16:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 17:16:21 --> User Agent Class Initialized
INFO - 2018-06-23 17:16:21 --> Controller Class Initialized
INFO - 2018-06-23 17:16:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-23 17:16:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-23 17:16:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-23 17:16:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-23 17:16:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-23 17:16:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-23 17:16:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-06-23 17:16:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-23 17:16:21 --> Final output sent to browser
DEBUG - 2018-06-23 17:16:21 --> Total execution time: 0.0203
INFO - 2018-06-23 17:16:21 --> Config Class Initialized
INFO - 2018-06-23 17:16:21 --> Hooks Class Initialized
DEBUG - 2018-06-23 17:16:21 --> UTF-8 Support Enabled
INFO - 2018-06-23 17:16:21 --> Utf8 Class Initialized
INFO - 2018-06-23 17:16:21 --> URI Class Initialized
INFO - 2018-06-23 17:16:21 --> Router Class Initialized
INFO - 2018-06-23 17:16:21 --> Output Class Initialized
INFO - 2018-06-23 17:16:21 --> Security Class Initialized
DEBUG - 2018-06-23 17:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 17:16:21 --> CSRF cookie sent
INFO - 2018-06-23 17:16:21 --> Input Class Initialized
INFO - 2018-06-23 17:16:21 --> Language Class Initialized
INFO - 2018-06-23 17:16:21 --> Loader Class Initialized
INFO - 2018-06-23 17:16:21 --> Helper loaded: url_helper
INFO - 2018-06-23 17:16:21 --> Helper loaded: form_helper
INFO - 2018-06-23 17:16:21 --> Helper loaded: language_helper
DEBUG - 2018-06-23 17:16:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 17:16:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 17:16:21 --> User Agent Class Initialized
INFO - 2018-06-23 17:16:21 --> Controller Class Initialized
INFO - 2018-06-23 17:16:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-23 17:16:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-23 17:16:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-23 17:16:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-23 17:16:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-23 17:16:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-23 17:16:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-06-23 17:16:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-23 17:16:21 --> Final output sent to browser
DEBUG - 2018-06-23 17:16:21 --> Total execution time: 0.0223
INFO - 2018-06-23 17:16:22 --> Config Class Initialized
INFO - 2018-06-23 17:16:22 --> Hooks Class Initialized
DEBUG - 2018-06-23 17:16:22 --> UTF-8 Support Enabled
INFO - 2018-06-23 17:16:22 --> Utf8 Class Initialized
INFO - 2018-06-23 17:16:22 --> URI Class Initialized
INFO - 2018-06-23 17:16:22 --> Router Class Initialized
INFO - 2018-06-23 17:16:22 --> Output Class Initialized
INFO - 2018-06-23 17:16:22 --> Security Class Initialized
DEBUG - 2018-06-23 17:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 17:16:22 --> CSRF cookie sent
INFO - 2018-06-23 17:16:22 --> Input Class Initialized
INFO - 2018-06-23 17:16:22 --> Language Class Initialized
INFO - 2018-06-23 17:16:22 --> Loader Class Initialized
INFO - 2018-06-23 17:16:22 --> Helper loaded: url_helper
INFO - 2018-06-23 17:16:22 --> Helper loaded: form_helper
INFO - 2018-06-23 17:16:22 --> Helper loaded: language_helper
DEBUG - 2018-06-23 17:16:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 17:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 17:16:22 --> User Agent Class Initialized
INFO - 2018-06-23 17:16:22 --> Controller Class Initialized
INFO - 2018-06-23 17:16:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-23 17:16:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-23 17:16:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-23 17:16:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-23 17:16:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-23 17:16:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-23 17:16:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-06-23 17:16:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-23 17:16:22 --> Final output sent to browser
DEBUG - 2018-06-23 17:16:22 --> Total execution time: 0.0215
INFO - 2018-06-23 17:16:22 --> Config Class Initialized
INFO - 2018-06-23 17:16:22 --> Hooks Class Initialized
DEBUG - 2018-06-23 17:16:22 --> UTF-8 Support Enabled
INFO - 2018-06-23 17:16:22 --> Utf8 Class Initialized
INFO - 2018-06-23 17:16:22 --> URI Class Initialized
INFO - 2018-06-23 17:16:22 --> Router Class Initialized
INFO - 2018-06-23 17:16:22 --> Output Class Initialized
INFO - 2018-06-23 17:16:22 --> Security Class Initialized
DEBUG - 2018-06-23 17:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 17:16:22 --> CSRF cookie sent
INFO - 2018-06-23 17:16:22 --> Input Class Initialized
INFO - 2018-06-23 17:16:22 --> Language Class Initialized
INFO - 2018-06-23 17:16:22 --> Loader Class Initialized
INFO - 2018-06-23 17:16:22 --> Helper loaded: url_helper
INFO - 2018-06-23 17:16:22 --> Helper loaded: form_helper
INFO - 2018-06-23 17:16:22 --> Helper loaded: language_helper
DEBUG - 2018-06-23 17:16:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 17:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 17:16:22 --> User Agent Class Initialized
INFO - 2018-06-23 17:16:22 --> Controller Class Initialized
INFO - 2018-06-23 17:16:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-23 17:16:22 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-23 17:16:22 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-23 17:16:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-23 17:16:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-23 17:16:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-23 17:16:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-23 17:16:22 --> Could not find the language line "req_email"
INFO - 2018-06-23 17:16:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-06-23 17:16:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-23 17:16:22 --> Final output sent to browser
DEBUG - 2018-06-23 17:16:22 --> Total execution time: 0.0233
INFO - 2018-06-23 17:16:22 --> Config Class Initialized
INFO - 2018-06-23 17:16:22 --> Hooks Class Initialized
DEBUG - 2018-06-23 17:16:22 --> UTF-8 Support Enabled
INFO - 2018-06-23 17:16:22 --> Utf8 Class Initialized
INFO - 2018-06-23 17:16:22 --> URI Class Initialized
INFO - 2018-06-23 17:16:22 --> Router Class Initialized
INFO - 2018-06-23 17:16:22 --> Output Class Initialized
INFO - 2018-06-23 17:16:22 --> Security Class Initialized
DEBUG - 2018-06-23 17:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 17:16:22 --> CSRF cookie sent
INFO - 2018-06-23 17:16:22 --> Input Class Initialized
INFO - 2018-06-23 17:16:22 --> Language Class Initialized
INFO - 2018-06-23 17:16:22 --> Loader Class Initialized
INFO - 2018-06-23 17:16:22 --> Helper loaded: url_helper
INFO - 2018-06-23 17:16:22 --> Helper loaded: form_helper
INFO - 2018-06-23 17:16:22 --> Helper loaded: language_helper
DEBUG - 2018-06-23 17:16:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 17:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 17:16:22 --> User Agent Class Initialized
INFO - 2018-06-23 17:16:22 --> Controller Class Initialized
INFO - 2018-06-23 17:16:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-23 17:16:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-23 17:16:22 --> Pixel_Model class loaded
INFO - 2018-06-23 17:16:22 --> Database Driver Class Initialized
INFO - 2018-06-23 17:16:22 --> Model "QuestionsModel" initialized
INFO - 2018-06-23 17:16:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-23 17:16:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-23 17:16:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-23 17:16:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-23 17:16:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/buy_gift.php
INFO - 2018-06-23 17:16:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-23 17:16:22 --> Final output sent to browser
DEBUG - 2018-06-23 17:16:22 --> Total execution time: 0.0344
INFO - 2018-06-23 19:22:04 --> Config Class Initialized
INFO - 2018-06-23 19:22:04 --> Hooks Class Initialized
DEBUG - 2018-06-23 19:22:04 --> UTF-8 Support Enabled
INFO - 2018-06-23 19:22:04 --> Utf8 Class Initialized
INFO - 2018-06-23 19:22:04 --> URI Class Initialized
INFO - 2018-06-23 19:22:04 --> Router Class Initialized
INFO - 2018-06-23 19:22:04 --> Output Class Initialized
INFO - 2018-06-23 19:22:04 --> Security Class Initialized
DEBUG - 2018-06-23 19:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 19:22:04 --> CSRF cookie sent
INFO - 2018-06-23 19:22:04 --> Input Class Initialized
INFO - 2018-06-23 19:22:04 --> Language Class Initialized
ERROR - 2018-06-23 19:22:04 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-06-23 21:27:05 --> Config Class Initialized
INFO - 2018-06-23 21:27:05 --> Hooks Class Initialized
DEBUG - 2018-06-23 21:27:05 --> UTF-8 Support Enabled
INFO - 2018-06-23 21:27:05 --> Utf8 Class Initialized
INFO - 2018-06-23 21:27:05 --> URI Class Initialized
DEBUG - 2018-06-23 21:27:05 --> No URI present. Default controller set.
INFO - 2018-06-23 21:27:05 --> Router Class Initialized
INFO - 2018-06-23 21:27:05 --> Output Class Initialized
INFO - 2018-06-23 21:27:05 --> Security Class Initialized
DEBUG - 2018-06-23 21:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 21:27:05 --> CSRF cookie sent
INFO - 2018-06-23 21:27:05 --> Input Class Initialized
INFO - 2018-06-23 21:27:05 --> Language Class Initialized
INFO - 2018-06-23 21:27:05 --> Loader Class Initialized
INFO - 2018-06-23 21:27:05 --> Helper loaded: url_helper
INFO - 2018-06-23 21:27:05 --> Helper loaded: form_helper
INFO - 2018-06-23 21:27:05 --> Helper loaded: language_helper
DEBUG - 2018-06-23 21:27:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 21:27:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 21:27:05 --> User Agent Class Initialized
INFO - 2018-06-23 21:27:05 --> Controller Class Initialized
INFO - 2018-06-23 21:27:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-23 21:27:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-23 21:27:05 --> Pixel_Model class loaded
INFO - 2018-06-23 21:27:05 --> Database Driver Class Initialized
INFO - 2018-06-23 21:27:05 --> Model "QuestionsModel" initialized
INFO - 2018-06-23 21:27:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-23 21:27:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-23 21:27:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-23 21:27:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-23 21:27:05 --> Final output sent to browser
DEBUG - 2018-06-23 21:27:05 --> Total execution time: 0.0359
INFO - 2018-06-23 22:43:41 --> Config Class Initialized
INFO - 2018-06-23 22:43:41 --> Hooks Class Initialized
DEBUG - 2018-06-23 22:43:41 --> UTF-8 Support Enabled
INFO - 2018-06-23 22:43:41 --> Utf8 Class Initialized
INFO - 2018-06-23 22:43:41 --> URI Class Initialized
INFO - 2018-06-23 22:43:41 --> Router Class Initialized
INFO - 2018-06-23 22:43:41 --> Output Class Initialized
INFO - 2018-06-23 22:43:41 --> Security Class Initialized
DEBUG - 2018-06-23 22:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 22:43:41 --> CSRF cookie sent
INFO - 2018-06-23 22:43:41 --> Input Class Initialized
INFO - 2018-06-23 22:43:41 --> Language Class Initialized
ERROR - 2018-06-23 22:43:41 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-06-23 22:43:53 --> Config Class Initialized
INFO - 2018-06-23 22:43:53 --> Hooks Class Initialized
DEBUG - 2018-06-23 22:43:53 --> UTF-8 Support Enabled
INFO - 2018-06-23 22:43:53 --> Utf8 Class Initialized
INFO - 2018-06-23 22:43:53 --> URI Class Initialized
INFO - 2018-06-23 22:43:53 --> Router Class Initialized
INFO - 2018-06-23 22:43:53 --> Output Class Initialized
INFO - 2018-06-23 22:43:53 --> Security Class Initialized
DEBUG - 2018-06-23 22:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 22:43:53 --> CSRF cookie sent
INFO - 2018-06-23 22:43:53 --> Input Class Initialized
INFO - 2018-06-23 22:43:53 --> Language Class Initialized
INFO - 2018-06-23 22:43:53 --> Loader Class Initialized
INFO - 2018-06-23 22:43:53 --> Helper loaded: url_helper
INFO - 2018-06-23 22:43:53 --> Helper loaded: form_helper
INFO - 2018-06-23 22:43:53 --> Helper loaded: language_helper
DEBUG - 2018-06-23 22:43:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 22:43:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 22:43:53 --> User Agent Class Initialized
INFO - 2018-06-23 22:43:53 --> Controller Class Initialized
INFO - 2018-06-23 22:43:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-23 22:43:53 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-23 22:43:53 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-23 22:43:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-23 22:43:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-23 22:43:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-23 22:43:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-23 22:43:53 --> Could not find the language line "req_email"
INFO - 2018-06-23 22:43:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-06-23 22:43:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-23 22:43:53 --> Final output sent to browser
DEBUG - 2018-06-23 22:43:53 --> Total execution time: 0.0234
INFO - 2018-06-23 22:46:59 --> Config Class Initialized
INFO - 2018-06-23 22:46:59 --> Hooks Class Initialized
DEBUG - 2018-06-23 22:46:59 --> UTF-8 Support Enabled
INFO - 2018-06-23 22:46:59 --> Utf8 Class Initialized
INFO - 2018-06-23 22:46:59 --> URI Class Initialized
INFO - 2018-06-23 22:46:59 --> Router Class Initialized
INFO - 2018-06-23 22:46:59 --> Output Class Initialized
INFO - 2018-06-23 22:46:59 --> Security Class Initialized
DEBUG - 2018-06-23 22:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 22:46:59 --> CSRF cookie sent
INFO - 2018-06-23 22:46:59 --> Input Class Initialized
INFO - 2018-06-23 22:46:59 --> Language Class Initialized
ERROR - 2018-06-23 22:46:59 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-06-23 22:47:03 --> Config Class Initialized
INFO - 2018-06-23 22:47:03 --> Hooks Class Initialized
DEBUG - 2018-06-23 22:47:03 --> UTF-8 Support Enabled
INFO - 2018-06-23 22:47:03 --> Utf8 Class Initialized
INFO - 2018-06-23 22:47:03 --> URI Class Initialized
INFO - 2018-06-23 22:47:03 --> Router Class Initialized
INFO - 2018-06-23 22:47:03 --> Output Class Initialized
INFO - 2018-06-23 22:47:03 --> Security Class Initialized
DEBUG - 2018-06-23 22:47:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 22:47:03 --> CSRF cookie sent
INFO - 2018-06-23 22:47:03 --> Input Class Initialized
INFO - 2018-06-23 22:47:03 --> Language Class Initialized
INFO - 2018-06-23 22:47:03 --> Loader Class Initialized
INFO - 2018-06-23 22:47:03 --> Helper loaded: url_helper
INFO - 2018-06-23 22:47:03 --> Helper loaded: form_helper
INFO - 2018-06-23 22:47:03 --> Helper loaded: language_helper
DEBUG - 2018-06-23 22:47:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 22:47:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 22:47:03 --> User Agent Class Initialized
INFO - 2018-06-23 22:47:03 --> Controller Class Initialized
INFO - 2018-06-23 22:47:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-23 22:47:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-23 22:47:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-23 22:47:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-23 22:47:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-23 22:47:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-23 22:47:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-06-23 22:47:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-23 22:47:03 --> Final output sent to browser
DEBUG - 2018-06-23 22:47:03 --> Total execution time: 0.0222
INFO - 2018-06-23 22:48:00 --> Config Class Initialized
INFO - 2018-06-23 22:48:00 --> Hooks Class Initialized
DEBUG - 2018-06-23 22:48:00 --> UTF-8 Support Enabled
INFO - 2018-06-23 22:48:00 --> Utf8 Class Initialized
INFO - 2018-06-23 22:48:00 --> URI Class Initialized
INFO - 2018-06-23 22:48:00 --> Router Class Initialized
INFO - 2018-06-23 22:48:00 --> Output Class Initialized
INFO - 2018-06-23 22:48:00 --> Security Class Initialized
DEBUG - 2018-06-23 22:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 22:48:00 --> CSRF cookie sent
INFO - 2018-06-23 22:48:00 --> Input Class Initialized
INFO - 2018-06-23 22:48:00 --> Language Class Initialized
INFO - 2018-06-23 22:48:00 --> Loader Class Initialized
INFO - 2018-06-23 22:48:00 --> Helper loaded: url_helper
INFO - 2018-06-23 22:48:00 --> Helper loaded: form_helper
INFO - 2018-06-23 22:48:00 --> Helper loaded: language_helper
DEBUG - 2018-06-23 22:48:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 22:48:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 22:48:00 --> User Agent Class Initialized
INFO - 2018-06-23 22:48:00 --> Controller Class Initialized
INFO - 2018-06-23 22:48:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-23 22:48:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-23 22:48:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-23 22:48:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-23 22:48:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-23 22:48:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-23 22:48:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-06-23 22:48:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-23 22:48:00 --> Final output sent to browser
DEBUG - 2018-06-23 22:48:00 --> Total execution time: 0.0237

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-06-24 00:01:46 --> Config Class Initialized
INFO - 2018-06-24 00:01:46 --> Hooks Class Initialized
DEBUG - 2018-06-24 00:01:46 --> UTF-8 Support Enabled
INFO - 2018-06-24 00:01:46 --> Utf8 Class Initialized
INFO - 2018-06-24 00:01:46 --> URI Class Initialized
INFO - 2018-06-24 00:01:46 --> Router Class Initialized
INFO - 2018-06-24 00:01:46 --> Output Class Initialized
INFO - 2018-06-24 00:01:46 --> Security Class Initialized
DEBUG - 2018-06-24 00:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-24 00:01:46 --> CSRF cookie sent
INFO - 2018-06-24 00:01:46 --> Input Class Initialized
INFO - 2018-06-24 00:01:46 --> Language Class Initialized
INFO - 2018-06-24 00:01:46 --> Loader Class Initialized
INFO - 2018-06-24 00:01:46 --> Helper loaded: url_helper
INFO - 2018-06-24 00:01:46 --> Helper loaded: form_helper
INFO - 2018-06-24 00:01:46 --> Helper loaded: language_helper
DEBUG - 2018-06-24 00:01:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-24 00:01:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-24 00:01:46 --> User Agent Class Initialized
INFO - 2018-06-24 00:01:46 --> Controller Class Initialized
INFO - 2018-06-24 00:01:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-24 00:01:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-24 00:01:46 --> Pixel_Model class loaded
INFO - 2018-06-24 00:01:47 --> Database Driver Class Initialized
INFO - 2018-06-24 00:01:47 --> Model "QuestionsModel" initialized
INFO - 2018-06-24 00:01:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-24 00:01:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-24 00:01:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-24 00:01:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-24 00:01:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/buy_gift.php
INFO - 2018-06-24 00:01:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-24 00:01:47 --> Final output sent to browser
DEBUG - 2018-06-24 00:01:47 --> Total execution time: 0.0369
INFO - 2018-06-24 00:08:17 --> Config Class Initialized
INFO - 2018-06-24 00:08:17 --> Hooks Class Initialized
DEBUG - 2018-06-24 00:08:17 --> UTF-8 Support Enabled
INFO - 2018-06-24 00:08:17 --> Utf8 Class Initialized
INFO - 2018-06-24 00:08:17 --> URI Class Initialized
INFO - 2018-06-24 00:08:17 --> Router Class Initialized
INFO - 2018-06-24 00:08:17 --> Output Class Initialized
INFO - 2018-06-24 00:08:17 --> Security Class Initialized
DEBUG - 2018-06-24 00:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-24 00:08:17 --> CSRF cookie sent
INFO - 2018-06-24 00:08:17 --> Input Class Initialized
INFO - 2018-06-24 00:08:17 --> Language Class Initialized
INFO - 2018-06-24 00:08:17 --> Loader Class Initialized
INFO - 2018-06-24 00:08:17 --> Helper loaded: url_helper
INFO - 2018-06-24 00:08:17 --> Helper loaded: form_helper
INFO - 2018-06-24 00:08:17 --> Helper loaded: language_helper
DEBUG - 2018-06-24 00:08:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-24 00:08:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-24 00:08:17 --> User Agent Class Initialized
INFO - 2018-06-24 00:08:17 --> Controller Class Initialized
INFO - 2018-06-24 00:08:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-24 00:08:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-24 00:08:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-24 00:08:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-24 00:08:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-06-24 00:08:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-24 00:08:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/thanks.php
INFO - 2018-06-24 00:08:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-24 00:08:17 --> Final output sent to browser
DEBUG - 2018-06-24 00:08:17 --> Total execution time: 0.0280
INFO - 2018-06-24 03:13:36 --> Config Class Initialized
INFO - 2018-06-24 03:13:36 --> Hooks Class Initialized
DEBUG - 2018-06-24 03:13:36 --> UTF-8 Support Enabled
INFO - 2018-06-24 03:13:36 --> Utf8 Class Initialized
INFO - 2018-06-24 03:13:36 --> URI Class Initialized
DEBUG - 2018-06-24 03:13:36 --> No URI present. Default controller set.
INFO - 2018-06-24 03:13:36 --> Router Class Initialized
INFO - 2018-06-24 03:13:36 --> Output Class Initialized
INFO - 2018-06-24 03:13:36 --> Security Class Initialized
DEBUG - 2018-06-24 03:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-24 03:13:36 --> CSRF cookie sent
INFO - 2018-06-24 03:13:36 --> Input Class Initialized
INFO - 2018-06-24 03:13:36 --> Language Class Initialized
INFO - 2018-06-24 03:13:36 --> Loader Class Initialized
INFO - 2018-06-24 03:13:36 --> Helper loaded: url_helper
INFO - 2018-06-24 03:13:36 --> Helper loaded: form_helper
INFO - 2018-06-24 03:13:36 --> Helper loaded: language_helper
DEBUG - 2018-06-24 03:13:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-24 03:13:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-24 03:13:36 --> User Agent Class Initialized
INFO - 2018-06-24 03:13:36 --> Controller Class Initialized
INFO - 2018-06-24 03:13:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-24 03:13:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-24 03:13:36 --> Pixel_Model class loaded
INFO - 2018-06-24 03:13:36 --> Database Driver Class Initialized
INFO - 2018-06-24 03:13:36 --> Model "QuestionsModel" initialized
INFO - 2018-06-24 03:13:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-24 03:13:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-24 03:13:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-24 03:13:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-24 03:13:36 --> Final output sent to browser
DEBUG - 2018-06-24 03:13:36 --> Total execution time: 0.0359
INFO - 2018-06-24 03:46:54 --> Config Class Initialized
INFO - 2018-06-24 03:46:54 --> Hooks Class Initialized
DEBUG - 2018-06-24 03:46:54 --> UTF-8 Support Enabled
INFO - 2018-06-24 03:46:54 --> Utf8 Class Initialized
INFO - 2018-06-24 03:46:54 --> URI Class Initialized
DEBUG - 2018-06-24 03:46:54 --> No URI present. Default controller set.
INFO - 2018-06-24 03:46:54 --> Router Class Initialized
INFO - 2018-06-24 03:46:54 --> Output Class Initialized
INFO - 2018-06-24 03:46:54 --> Security Class Initialized
DEBUG - 2018-06-24 03:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-24 03:46:54 --> CSRF cookie sent
INFO - 2018-06-24 03:46:54 --> Input Class Initialized
INFO - 2018-06-24 03:46:54 --> Language Class Initialized
INFO - 2018-06-24 03:46:54 --> Loader Class Initialized
INFO - 2018-06-24 03:46:54 --> Helper loaded: url_helper
INFO - 2018-06-24 03:46:54 --> Helper loaded: form_helper
INFO - 2018-06-24 03:46:54 --> Helper loaded: language_helper
DEBUG - 2018-06-24 03:46:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-24 03:46:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-24 03:46:54 --> User Agent Class Initialized
INFO - 2018-06-24 03:46:54 --> Controller Class Initialized
INFO - 2018-06-24 03:46:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-24 03:46:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-24 03:46:54 --> Pixel_Model class loaded
INFO - 2018-06-24 03:46:54 --> Database Driver Class Initialized
INFO - 2018-06-24 03:46:54 --> Model "QuestionsModel" initialized
INFO - 2018-06-24 03:46:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-24 03:46:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-24 03:46:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-24 03:46:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-24 03:46:54 --> Final output sent to browser
DEBUG - 2018-06-24 03:46:54 --> Total execution time: 0.0331
INFO - 2018-06-24 04:13:20 --> Config Class Initialized
INFO - 2018-06-24 04:13:20 --> Hooks Class Initialized
DEBUG - 2018-06-24 04:13:20 --> UTF-8 Support Enabled
INFO - 2018-06-24 04:13:20 --> Utf8 Class Initialized
INFO - 2018-06-24 04:13:20 --> URI Class Initialized
INFO - 2018-06-24 04:13:20 --> Router Class Initialized
INFO - 2018-06-24 04:13:20 --> Output Class Initialized
INFO - 2018-06-24 04:13:20 --> Security Class Initialized
DEBUG - 2018-06-24 04:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-24 04:13:20 --> CSRF cookie sent
INFO - 2018-06-24 04:13:20 --> Input Class Initialized
INFO - 2018-06-24 04:13:20 --> Language Class Initialized
ERROR - 2018-06-24 04:13:20 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-06-24 04:13:24 --> Config Class Initialized
INFO - 2018-06-24 04:13:24 --> Hooks Class Initialized
DEBUG - 2018-06-24 04:13:24 --> UTF-8 Support Enabled
INFO - 2018-06-24 04:13:24 --> Utf8 Class Initialized
INFO - 2018-06-24 04:13:24 --> URI Class Initialized
DEBUG - 2018-06-24 04:13:24 --> No URI present. Default controller set.
INFO - 2018-06-24 04:13:24 --> Router Class Initialized
INFO - 2018-06-24 04:13:24 --> Output Class Initialized
INFO - 2018-06-24 04:13:24 --> Security Class Initialized
DEBUG - 2018-06-24 04:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-24 04:13:24 --> CSRF cookie sent
INFO - 2018-06-24 04:13:24 --> Input Class Initialized
INFO - 2018-06-24 04:13:24 --> Language Class Initialized
INFO - 2018-06-24 04:13:24 --> Loader Class Initialized
INFO - 2018-06-24 04:13:24 --> Helper loaded: url_helper
INFO - 2018-06-24 04:13:24 --> Helper loaded: form_helper
INFO - 2018-06-24 04:13:24 --> Helper loaded: language_helper
DEBUG - 2018-06-24 04:13:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-24 04:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-24 04:13:24 --> User Agent Class Initialized
INFO - 2018-06-24 04:13:24 --> Controller Class Initialized
INFO - 2018-06-24 04:13:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-24 04:13:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-24 04:13:24 --> Pixel_Model class loaded
INFO - 2018-06-24 04:13:24 --> Database Driver Class Initialized
INFO - 2018-06-24 04:13:24 --> Model "QuestionsModel" initialized
INFO - 2018-06-24 04:13:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-24 04:13:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-24 04:13:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-24 04:13:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-24 04:13:24 --> Final output sent to browser
DEBUG - 2018-06-24 04:13:24 --> Total execution time: 0.0377
INFO - 2018-06-24 05:02:52 --> Config Class Initialized
INFO - 2018-06-24 05:02:52 --> Hooks Class Initialized
DEBUG - 2018-06-24 05:02:52 --> UTF-8 Support Enabled
INFO - 2018-06-24 05:02:52 --> Utf8 Class Initialized
INFO - 2018-06-24 05:02:52 --> URI Class Initialized
DEBUG - 2018-06-24 05:02:52 --> No URI present. Default controller set.
INFO - 2018-06-24 05:02:52 --> Router Class Initialized
INFO - 2018-06-24 05:02:52 --> Output Class Initialized
INFO - 2018-06-24 05:02:52 --> Security Class Initialized
DEBUG - 2018-06-24 05:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-24 05:02:52 --> CSRF cookie sent
INFO - 2018-06-24 05:02:52 --> Input Class Initialized
INFO - 2018-06-24 05:02:52 --> Language Class Initialized
INFO - 2018-06-24 05:02:52 --> Loader Class Initialized
INFO - 2018-06-24 05:02:52 --> Helper loaded: url_helper
INFO - 2018-06-24 05:02:52 --> Helper loaded: form_helper
INFO - 2018-06-24 05:02:52 --> Helper loaded: language_helper
DEBUG - 2018-06-24 05:02:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-24 05:02:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-24 05:02:52 --> User Agent Class Initialized
INFO - 2018-06-24 05:02:52 --> Controller Class Initialized
INFO - 2018-06-24 05:02:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-24 05:02:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-24 05:02:52 --> Pixel_Model class loaded
INFO - 2018-06-24 05:02:52 --> Database Driver Class Initialized
INFO - 2018-06-24 05:02:52 --> Model "QuestionsModel" initialized
INFO - 2018-06-24 05:02:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-24 05:02:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-24 05:02:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-24 05:02:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-24 05:02:52 --> Final output sent to browser
DEBUG - 2018-06-24 05:02:52 --> Total execution time: 0.0511
INFO - 2018-06-24 05:10:28 --> Config Class Initialized
INFO - 2018-06-24 05:10:28 --> Hooks Class Initialized
DEBUG - 2018-06-24 05:10:28 --> UTF-8 Support Enabled
INFO - 2018-06-24 05:10:28 --> Utf8 Class Initialized
INFO - 2018-06-24 05:10:28 --> URI Class Initialized
INFO - 2018-06-24 05:10:28 --> Router Class Initialized
INFO - 2018-06-24 05:10:28 --> Output Class Initialized
INFO - 2018-06-24 05:10:28 --> Security Class Initialized
DEBUG - 2018-06-24 05:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-24 05:10:28 --> CSRF cookie sent
INFO - 2018-06-24 05:10:28 --> Input Class Initialized
INFO - 2018-06-24 05:10:28 --> Language Class Initialized
ERROR - 2018-06-24 05:10:28 --> 404 Page Not Found: Faviconico/index
INFO - 2018-06-24 06:11:56 --> Config Class Initialized
INFO - 2018-06-24 06:11:56 --> Hooks Class Initialized
DEBUG - 2018-06-24 06:11:56 --> UTF-8 Support Enabled
INFO - 2018-06-24 06:11:56 --> Utf8 Class Initialized
INFO - 2018-06-24 06:11:56 --> URI Class Initialized
INFO - 2018-06-24 06:11:56 --> Router Class Initialized
INFO - 2018-06-24 06:11:56 --> Output Class Initialized
INFO - 2018-06-24 06:11:56 --> Security Class Initialized
DEBUG - 2018-06-24 06:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-24 06:11:56 --> CSRF cookie sent
INFO - 2018-06-24 06:11:56 --> Input Class Initialized
INFO - 2018-06-24 06:11:56 --> Language Class Initialized
INFO - 2018-06-24 06:11:56 --> Loader Class Initialized
INFO - 2018-06-24 06:11:56 --> Helper loaded: url_helper
INFO - 2018-06-24 06:11:56 --> Helper loaded: form_helper
INFO - 2018-06-24 06:11:56 --> Helper loaded: language_helper
DEBUG - 2018-06-24 06:11:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-24 06:11:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-24 06:11:56 --> User Agent Class Initialized
INFO - 2018-06-24 06:11:56 --> Controller Class Initialized
INFO - 2018-06-24 06:11:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-24 06:11:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-24 06:11:56 --> Pixel_Model class loaded
INFO - 2018-06-24 06:11:56 --> Database Driver Class Initialized
INFO - 2018-06-24 06:11:56 --> Model "RegistrationModel" initialized
DEBUG - 2018-06-24 06:11:56 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-24 06:11:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-24 06:11:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-24 06:11:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-24 06:11:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-24 06:11:56 --> Could not find the language line "req_email"
INFO - 2018-06-24 06:11:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup_fa.php
INFO - 2018-06-24 06:11:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-24 06:11:56 --> Final output sent to browser
DEBUG - 2018-06-24 06:11:56 --> Total execution time: 0.0385
INFO - 2018-06-24 06:11:56 --> Config Class Initialized
INFO - 2018-06-24 06:11:56 --> Hooks Class Initialized
DEBUG - 2018-06-24 06:11:56 --> UTF-8 Support Enabled
INFO - 2018-06-24 06:11:56 --> Utf8 Class Initialized
INFO - 2018-06-24 06:11:56 --> URI Class Initialized
INFO - 2018-06-24 06:11:56 --> Router Class Initialized
INFO - 2018-06-24 06:11:56 --> Output Class Initialized
INFO - 2018-06-24 06:11:56 --> Security Class Initialized
DEBUG - 2018-06-24 06:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-24 06:11:56 --> CSRF cookie sent
INFO - 2018-06-24 06:11:56 --> Input Class Initialized
INFO - 2018-06-24 06:11:56 --> Language Class Initialized
INFO - 2018-06-24 06:11:56 --> Loader Class Initialized
INFO - 2018-06-24 06:11:56 --> Helper loaded: url_helper
INFO - 2018-06-24 06:11:56 --> Helper loaded: form_helper
INFO - 2018-06-24 06:11:56 --> Helper loaded: language_helper
DEBUG - 2018-06-24 06:11:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-24 06:11:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-24 06:11:56 --> User Agent Class Initialized
INFO - 2018-06-24 06:11:56 --> Controller Class Initialized
INFO - 2018-06-24 06:11:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-24 06:11:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-24 06:11:56 --> Pixel_Model class loaded
INFO - 2018-06-24 06:11:56 --> Database Driver Class Initialized
INFO - 2018-06-24 06:11:56 --> Model "QuestionsModel" initialized
INFO - 2018-06-24 06:11:57 --> Config Class Initialized
INFO - 2018-06-24 06:11:57 --> Hooks Class Initialized
DEBUG - 2018-06-24 06:11:57 --> UTF-8 Support Enabled
INFO - 2018-06-24 06:11:57 --> Utf8 Class Initialized
INFO - 2018-06-24 06:11:57 --> URI Class Initialized
INFO - 2018-06-24 06:11:57 --> Router Class Initialized
INFO - 2018-06-24 06:11:57 --> Output Class Initialized
INFO - 2018-06-24 06:11:57 --> Security Class Initialized
DEBUG - 2018-06-24 06:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-24 06:11:57 --> CSRF cookie sent
INFO - 2018-06-24 06:11:57 --> Input Class Initialized
INFO - 2018-06-24 06:11:57 --> Language Class Initialized
INFO - 2018-06-24 06:11:57 --> Loader Class Initialized
INFO - 2018-06-24 06:11:57 --> Helper loaded: url_helper
INFO - 2018-06-24 06:11:57 --> Helper loaded: form_helper
INFO - 2018-06-24 06:11:57 --> Helper loaded: language_helper
DEBUG - 2018-06-24 06:11:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-24 06:11:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-24 06:11:57 --> User Agent Class Initialized
INFO - 2018-06-24 06:11:57 --> Controller Class Initialized
INFO - 2018-06-24 06:11:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-24 06:11:57 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-24 06:11:57 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-24 06:11:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-24 06:11:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-24 06:11:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-24 06:11:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-24 06:11:57 --> Could not find the language line "req_email"
INFO - 2018-06-24 06:11:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-06-24 06:11:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-24 06:11:57 --> Final output sent to browser
DEBUG - 2018-06-24 06:11:57 --> Total execution time: 0.0239
INFO - 2018-06-24 07:17:47 --> Config Class Initialized
INFO - 2018-06-24 07:17:47 --> Hooks Class Initialized
DEBUG - 2018-06-24 07:17:47 --> UTF-8 Support Enabled
INFO - 2018-06-24 07:17:47 --> Utf8 Class Initialized
INFO - 2018-06-24 07:17:47 --> URI Class Initialized
INFO - 2018-06-24 07:17:47 --> Router Class Initialized
INFO - 2018-06-24 07:17:47 --> Output Class Initialized
INFO - 2018-06-24 07:17:47 --> Security Class Initialized
DEBUG - 2018-06-24 07:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-24 07:17:47 --> CSRF cookie sent
INFO - 2018-06-24 07:17:47 --> Input Class Initialized
INFO - 2018-06-24 07:17:47 --> Language Class Initialized
ERROR - 2018-06-24 07:17:47 --> 404 Page Not Found: Well-known/assetlinks.json
INFO - 2018-06-24 07:47:06 --> Config Class Initialized
INFO - 2018-06-24 07:47:06 --> Hooks Class Initialized
DEBUG - 2018-06-24 07:47:06 --> UTF-8 Support Enabled
INFO - 2018-06-24 07:47:06 --> Utf8 Class Initialized
INFO - 2018-06-24 07:47:06 --> URI Class Initialized
DEBUG - 2018-06-24 07:47:06 --> No URI present. Default controller set.
INFO - 2018-06-24 07:47:06 --> Router Class Initialized
INFO - 2018-06-24 07:47:06 --> Output Class Initialized
INFO - 2018-06-24 07:47:06 --> Security Class Initialized
DEBUG - 2018-06-24 07:47:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-24 07:47:06 --> CSRF cookie sent
INFO - 2018-06-24 07:47:06 --> Input Class Initialized
INFO - 2018-06-24 07:47:06 --> Language Class Initialized
INFO - 2018-06-24 07:47:06 --> Loader Class Initialized
INFO - 2018-06-24 07:47:06 --> Helper loaded: url_helper
INFO - 2018-06-24 07:47:06 --> Helper loaded: form_helper
INFO - 2018-06-24 07:47:06 --> Helper loaded: language_helper
DEBUG - 2018-06-24 07:47:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-24 07:47:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-24 07:47:06 --> User Agent Class Initialized
INFO - 2018-06-24 07:47:06 --> Controller Class Initialized
INFO - 2018-06-24 07:47:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-24 07:47:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-24 07:47:06 --> Pixel_Model class loaded
INFO - 2018-06-24 07:47:06 --> Database Driver Class Initialized
INFO - 2018-06-24 07:47:06 --> Model "QuestionsModel" initialized
INFO - 2018-06-24 07:47:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-24 07:47:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-24 07:47:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-24 07:47:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-24 07:47:06 --> Final output sent to browser
DEBUG - 2018-06-24 07:47:06 --> Total execution time: 0.0341
INFO - 2018-06-24 07:47:21 --> Config Class Initialized
INFO - 2018-06-24 07:47:21 --> Hooks Class Initialized
DEBUG - 2018-06-24 07:47:21 --> UTF-8 Support Enabled
INFO - 2018-06-24 07:47:21 --> Utf8 Class Initialized
INFO - 2018-06-24 07:47:21 --> URI Class Initialized
DEBUG - 2018-06-24 07:47:21 --> No URI present. Default controller set.
INFO - 2018-06-24 07:47:21 --> Router Class Initialized
INFO - 2018-06-24 07:47:21 --> Output Class Initialized
INFO - 2018-06-24 07:47:21 --> Security Class Initialized
DEBUG - 2018-06-24 07:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-24 07:47:21 --> CSRF cookie sent
INFO - 2018-06-24 07:47:21 --> Input Class Initialized
INFO - 2018-06-24 07:47:21 --> Language Class Initialized
INFO - 2018-06-24 07:47:21 --> Loader Class Initialized
INFO - 2018-06-24 07:47:21 --> Helper loaded: url_helper
INFO - 2018-06-24 07:47:21 --> Helper loaded: form_helper
INFO - 2018-06-24 07:47:21 --> Helper loaded: language_helper
DEBUG - 2018-06-24 07:47:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-24 07:47:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-24 07:47:21 --> User Agent Class Initialized
INFO - 2018-06-24 07:47:21 --> Controller Class Initialized
INFO - 2018-06-24 07:47:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-24 07:47:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-24 07:47:21 --> Pixel_Model class loaded
INFO - 2018-06-24 07:47:21 --> Database Driver Class Initialized
INFO - 2018-06-24 07:47:21 --> Model "QuestionsModel" initialized
INFO - 2018-06-24 07:47:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-24 07:47:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-24 07:47:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-24 07:47:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-24 07:47:21 --> Final output sent to browser
DEBUG - 2018-06-24 07:47:21 --> Total execution time: 0.0343
INFO - 2018-06-24 07:47:26 --> Config Class Initialized
INFO - 2018-06-24 07:47:26 --> Hooks Class Initialized
DEBUG - 2018-06-24 07:47:26 --> UTF-8 Support Enabled
INFO - 2018-06-24 07:47:26 --> Utf8 Class Initialized
INFO - 2018-06-24 07:47:26 --> URI Class Initialized
INFO - 2018-06-24 07:47:26 --> Router Class Initialized
INFO - 2018-06-24 07:47:26 --> Output Class Initialized
INFO - 2018-06-24 07:47:26 --> Security Class Initialized
DEBUG - 2018-06-24 07:47:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-24 07:47:26 --> CSRF cookie sent
INFO - 2018-06-24 07:47:26 --> Input Class Initialized
INFO - 2018-06-24 07:47:26 --> Language Class Initialized
INFO - 2018-06-24 07:47:26 --> Loader Class Initialized
INFO - 2018-06-24 07:47:26 --> Helper loaded: url_helper
INFO - 2018-06-24 07:47:26 --> Helper loaded: form_helper
INFO - 2018-06-24 07:47:26 --> Helper loaded: language_helper
DEBUG - 2018-06-24 07:47:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-24 07:47:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-24 07:47:26 --> User Agent Class Initialized
INFO - 2018-06-24 07:47:26 --> Controller Class Initialized
INFO - 2018-06-24 07:47:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-24 07:47:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-24 07:47:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-24 07:47:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-24 07:47:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-24 07:47:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-24 07:47:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-06-24 07:47:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-24 07:47:26 --> Final output sent to browser
DEBUG - 2018-06-24 07:47:26 --> Total execution time: 0.0204
INFO - 2018-06-24 07:47:36 --> Config Class Initialized
INFO - 2018-06-24 07:47:36 --> Hooks Class Initialized
DEBUG - 2018-06-24 07:47:36 --> UTF-8 Support Enabled
INFO - 2018-06-24 07:47:36 --> Utf8 Class Initialized
INFO - 2018-06-24 07:47:36 --> URI Class Initialized
INFO - 2018-06-24 07:47:36 --> Router Class Initialized
INFO - 2018-06-24 07:47:36 --> Output Class Initialized
INFO - 2018-06-24 07:47:36 --> Security Class Initialized
DEBUG - 2018-06-24 07:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-24 07:47:36 --> CSRF cookie sent
INFO - 2018-06-24 07:47:36 --> Input Class Initialized
INFO - 2018-06-24 07:47:36 --> Language Class Initialized
INFO - 2018-06-24 07:47:36 --> Loader Class Initialized
INFO - 2018-06-24 07:47:36 --> Helper loaded: url_helper
INFO - 2018-06-24 07:47:36 --> Helper loaded: form_helper
INFO - 2018-06-24 07:47:36 --> Helper loaded: language_helper
DEBUG - 2018-06-24 07:47:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-24 07:47:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-24 07:47:36 --> User Agent Class Initialized
INFO - 2018-06-24 07:47:36 --> Controller Class Initialized
INFO - 2018-06-24 07:47:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-24 07:47:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-24 07:47:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-24 07:47:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-24 07:47:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-24 07:47:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-24 07:47:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-06-24 07:47:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-24 07:47:36 --> Final output sent to browser
DEBUG - 2018-06-24 07:47:36 --> Total execution time: 0.0216
INFO - 2018-06-24 07:47:46 --> Config Class Initialized
INFO - 2018-06-24 07:47:46 --> Hooks Class Initialized
DEBUG - 2018-06-24 07:47:46 --> UTF-8 Support Enabled
INFO - 2018-06-24 07:47:46 --> Utf8 Class Initialized
INFO - 2018-06-24 07:47:46 --> URI Class Initialized
INFO - 2018-06-24 07:47:46 --> Router Class Initialized
INFO - 2018-06-24 07:47:46 --> Output Class Initialized
INFO - 2018-06-24 07:47:46 --> Security Class Initialized
DEBUG - 2018-06-24 07:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-24 07:47:46 --> CSRF cookie sent
INFO - 2018-06-24 07:47:46 --> Input Class Initialized
INFO - 2018-06-24 07:47:46 --> Language Class Initialized
INFO - 2018-06-24 07:47:46 --> Loader Class Initialized
INFO - 2018-06-24 07:47:46 --> Helper loaded: url_helper
INFO - 2018-06-24 07:47:46 --> Helper loaded: form_helper
INFO - 2018-06-24 07:47:46 --> Helper loaded: language_helper
DEBUG - 2018-06-24 07:47:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-24 07:47:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-24 07:47:46 --> User Agent Class Initialized
INFO - 2018-06-24 07:47:46 --> Controller Class Initialized
INFO - 2018-06-24 07:47:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-24 07:47:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-24 07:47:46 --> Pixel_Model class loaded
INFO - 2018-06-24 07:47:46 --> Database Driver Class Initialized
INFO - 2018-06-24 07:47:46 --> Model "QuestionsModel" initialized
INFO - 2018-06-24 07:47:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-24 07:47:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-24 07:47:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-24 07:47:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-24 07:47:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/buy_gift.php
INFO - 2018-06-24 07:47:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-24 07:47:46 --> Final output sent to browser
DEBUG - 2018-06-24 07:47:46 --> Total execution time: 0.0320
INFO - 2018-06-24 07:47:53 --> Config Class Initialized
INFO - 2018-06-24 07:47:53 --> Hooks Class Initialized
DEBUG - 2018-06-24 07:47:53 --> UTF-8 Support Enabled
INFO - 2018-06-24 07:47:53 --> Utf8 Class Initialized
INFO - 2018-06-24 07:47:53 --> URI Class Initialized
INFO - 2018-06-24 07:47:53 --> Router Class Initialized
INFO - 2018-06-24 07:47:53 --> Output Class Initialized
INFO - 2018-06-24 07:47:53 --> Security Class Initialized
DEBUG - 2018-06-24 07:47:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-24 07:47:53 --> CSRF cookie sent
INFO - 2018-06-24 07:47:53 --> Input Class Initialized
INFO - 2018-06-24 07:47:53 --> Language Class Initialized
INFO - 2018-06-24 07:47:53 --> Loader Class Initialized
INFO - 2018-06-24 07:47:53 --> Helper loaded: url_helper
INFO - 2018-06-24 07:47:53 --> Helper loaded: form_helper
INFO - 2018-06-24 07:47:53 --> Helper loaded: language_helper
DEBUG - 2018-06-24 07:47:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-24 07:47:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-24 07:47:53 --> User Agent Class Initialized
INFO - 2018-06-24 07:47:53 --> Controller Class Initialized
INFO - 2018-06-24 07:47:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-24 07:47:53 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-24 07:47:53 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-24 07:47:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-24 07:47:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-24 07:47:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-24 07:47:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-24 07:47:53 --> Could not find the language line "req_email"
INFO - 2018-06-24 07:47:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-06-24 07:47:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-24 07:47:53 --> Final output sent to browser
DEBUG - 2018-06-24 07:47:53 --> Total execution time: 0.0245
INFO - 2018-06-24 08:30:11 --> Config Class Initialized
INFO - 2018-06-24 08:30:11 --> Hooks Class Initialized
DEBUG - 2018-06-24 08:30:11 --> UTF-8 Support Enabled
INFO - 2018-06-24 08:30:11 --> Utf8 Class Initialized
INFO - 2018-06-24 08:30:11 --> URI Class Initialized
DEBUG - 2018-06-24 08:30:11 --> No URI present. Default controller set.
INFO - 2018-06-24 08:30:11 --> Router Class Initialized
INFO - 2018-06-24 08:30:11 --> Output Class Initialized
INFO - 2018-06-24 08:30:11 --> Security Class Initialized
DEBUG - 2018-06-24 08:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-24 08:30:11 --> CSRF cookie sent
INFO - 2018-06-24 08:30:11 --> Input Class Initialized
INFO - 2018-06-24 08:30:11 --> Language Class Initialized
INFO - 2018-06-24 08:30:11 --> Loader Class Initialized
INFO - 2018-06-24 08:30:11 --> Helper loaded: url_helper
INFO - 2018-06-24 08:30:11 --> Helper loaded: form_helper
INFO - 2018-06-24 08:30:11 --> Helper loaded: language_helper
DEBUG - 2018-06-24 08:30:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-24 08:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-24 08:30:11 --> User Agent Class Initialized
INFO - 2018-06-24 08:30:11 --> Controller Class Initialized
INFO - 2018-06-24 08:30:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-24 08:30:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-24 08:30:11 --> Pixel_Model class loaded
INFO - 2018-06-24 08:30:11 --> Database Driver Class Initialized
INFO - 2018-06-24 08:30:11 --> Model "QuestionsModel" initialized
INFO - 2018-06-24 08:30:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-24 08:30:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-24 08:30:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-24 08:30:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-24 08:30:11 --> Final output sent to browser
DEBUG - 2018-06-24 08:30:11 --> Total execution time: 0.0365
INFO - 2018-06-24 10:18:45 --> Config Class Initialized
INFO - 2018-06-24 10:18:45 --> Hooks Class Initialized
DEBUG - 2018-06-24 10:18:45 --> UTF-8 Support Enabled
INFO - 2018-06-24 10:18:45 --> Utf8 Class Initialized
INFO - 2018-06-24 10:18:45 --> URI Class Initialized
INFO - 2018-06-24 10:18:45 --> Router Class Initialized
INFO - 2018-06-24 10:18:45 --> Output Class Initialized
INFO - 2018-06-24 10:18:45 --> Security Class Initialized
DEBUG - 2018-06-24 10:18:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-24 10:18:45 --> CSRF cookie sent
INFO - 2018-06-24 10:18:45 --> Input Class Initialized
INFO - 2018-06-24 10:18:45 --> Language Class Initialized
ERROR - 2018-06-24 10:18:45 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-06-24 10:18:45 --> Config Class Initialized
INFO - 2018-06-24 10:18:45 --> Hooks Class Initialized
DEBUG - 2018-06-24 10:18:45 --> UTF-8 Support Enabled
INFO - 2018-06-24 10:18:45 --> Utf8 Class Initialized
INFO - 2018-06-24 10:18:45 --> URI Class Initialized
INFO - 2018-06-24 10:18:45 --> Router Class Initialized
INFO - 2018-06-24 10:18:45 --> Output Class Initialized
INFO - 2018-06-24 10:18:45 --> Security Class Initialized
DEBUG - 2018-06-24 10:18:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-24 10:18:45 --> CSRF cookie sent
INFO - 2018-06-24 10:18:45 --> Input Class Initialized
INFO - 2018-06-24 10:18:45 --> Language Class Initialized
INFO - 2018-06-24 10:18:45 --> Loader Class Initialized
INFO - 2018-06-24 10:18:45 --> Helper loaded: url_helper
INFO - 2018-06-24 10:18:45 --> Helper loaded: form_helper
INFO - 2018-06-24 10:18:45 --> Helper loaded: language_helper
DEBUG - 2018-06-24 10:18:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-24 10:18:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-24 10:18:45 --> User Agent Class Initialized
INFO - 2018-06-24 10:18:45 --> Controller Class Initialized
INFO - 2018-06-24 10:18:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-24 10:18:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-24 10:18:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-24 10:18:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-24 10:18:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-24 10:18:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-24 10:18:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/consultant.php
INFO - 2018-06-24 10:18:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-24 10:18:45 --> Final output sent to browser
DEBUG - 2018-06-24 10:18:45 --> Total execution time: 0.0233
INFO - 2018-06-24 11:07:42 --> Config Class Initialized
INFO - 2018-06-24 11:07:42 --> Hooks Class Initialized
DEBUG - 2018-06-24 11:07:42 --> UTF-8 Support Enabled
INFO - 2018-06-24 11:07:42 --> Utf8 Class Initialized
INFO - 2018-06-24 11:07:42 --> URI Class Initialized
INFO - 2018-06-24 11:07:42 --> Router Class Initialized
INFO - 2018-06-24 11:07:42 --> Output Class Initialized
INFO - 2018-06-24 11:07:42 --> Security Class Initialized
DEBUG - 2018-06-24 11:07:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-24 11:07:42 --> CSRF cookie sent
INFO - 2018-06-24 11:07:42 --> Input Class Initialized
INFO - 2018-06-24 11:07:42 --> Language Class Initialized
INFO - 2018-06-24 11:07:42 --> Loader Class Initialized
INFO - 2018-06-24 11:07:42 --> Helper loaded: url_helper
INFO - 2018-06-24 11:07:42 --> Helper loaded: form_helper
INFO - 2018-06-24 11:07:42 --> Helper loaded: language_helper
DEBUG - 2018-06-24 11:07:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-24 11:07:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-24 11:07:42 --> User Agent Class Initialized
INFO - 2018-06-24 11:07:42 --> Controller Class Initialized
INFO - 2018-06-24 11:07:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-24 11:07:42 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-24 11:07:42 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-24 11:07:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-24 11:07:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-24 11:07:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-24 11:07:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-24 11:07:42 --> Could not find the language line "req_email"
INFO - 2018-06-24 11:07:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-06-24 11:07:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-24 11:07:42 --> Final output sent to browser
DEBUG - 2018-06-24 11:07:42 --> Total execution time: 0.0241
INFO - 2018-06-24 12:58:59 --> Config Class Initialized
INFO - 2018-06-24 12:58:59 --> Hooks Class Initialized
DEBUG - 2018-06-24 12:58:59 --> UTF-8 Support Enabled
INFO - 2018-06-24 12:58:59 --> Utf8 Class Initialized
INFO - 2018-06-24 12:58:59 --> URI Class Initialized
INFO - 2018-06-24 12:58:59 --> Router Class Initialized
INFO - 2018-06-24 12:58:59 --> Output Class Initialized
INFO - 2018-06-24 12:58:59 --> Security Class Initialized
DEBUG - 2018-06-24 12:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-24 12:58:59 --> CSRF cookie sent
INFO - 2018-06-24 12:58:59 --> Input Class Initialized
INFO - 2018-06-24 12:58:59 --> Language Class Initialized
ERROR - 2018-06-24 12:58:59 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-06-24 12:58:59 --> Config Class Initialized
INFO - 2018-06-24 12:58:59 --> Hooks Class Initialized
DEBUG - 2018-06-24 12:58:59 --> UTF-8 Support Enabled
INFO - 2018-06-24 12:58:59 --> Utf8 Class Initialized
INFO - 2018-06-24 12:58:59 --> URI Class Initialized
DEBUG - 2018-06-24 12:58:59 --> No URI present. Default controller set.
INFO - 2018-06-24 12:58:59 --> Router Class Initialized
INFO - 2018-06-24 12:58:59 --> Output Class Initialized
INFO - 2018-06-24 12:58:59 --> Security Class Initialized
DEBUG - 2018-06-24 12:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-24 12:58:59 --> CSRF cookie sent
INFO - 2018-06-24 12:58:59 --> Input Class Initialized
INFO - 2018-06-24 12:58:59 --> Language Class Initialized
INFO - 2018-06-24 12:58:59 --> Loader Class Initialized
INFO - 2018-06-24 12:58:59 --> Helper loaded: url_helper
INFO - 2018-06-24 12:58:59 --> Helper loaded: form_helper
INFO - 2018-06-24 12:58:59 --> Helper loaded: language_helper
DEBUG - 2018-06-24 12:58:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-24 12:58:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-24 12:58:59 --> User Agent Class Initialized
INFO - 2018-06-24 12:58:59 --> Controller Class Initialized
INFO - 2018-06-24 12:58:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-24 12:58:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-24 12:58:59 --> Pixel_Model class loaded
INFO - 2018-06-24 12:58:59 --> Database Driver Class Initialized
INFO - 2018-06-24 12:58:59 --> Model "QuestionsModel" initialized
INFO - 2018-06-24 12:58:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-24 12:58:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-24 12:58:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-24 12:58:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-24 12:58:59 --> Final output sent to browser
DEBUG - 2018-06-24 12:58:59 --> Total execution time: 0.0311
INFO - 2018-06-24 13:52:43 --> Config Class Initialized
INFO - 2018-06-24 13:52:43 --> Hooks Class Initialized
DEBUG - 2018-06-24 13:52:44 --> UTF-8 Support Enabled
INFO - 2018-06-24 13:52:44 --> Utf8 Class Initialized
INFO - 2018-06-24 13:52:44 --> URI Class Initialized
DEBUG - 2018-06-24 13:52:44 --> No URI present. Default controller set.
INFO - 2018-06-24 13:52:44 --> Router Class Initialized
INFO - 2018-06-24 13:52:44 --> Output Class Initialized
INFO - 2018-06-24 13:52:44 --> Security Class Initialized
DEBUG - 2018-06-24 13:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-24 13:52:44 --> CSRF cookie sent
INFO - 2018-06-24 13:52:44 --> Input Class Initialized
INFO - 2018-06-24 13:52:44 --> Language Class Initialized
INFO - 2018-06-24 13:52:44 --> Loader Class Initialized
INFO - 2018-06-24 13:52:44 --> Helper loaded: url_helper
INFO - 2018-06-24 13:52:44 --> Helper loaded: form_helper
INFO - 2018-06-24 13:52:44 --> Helper loaded: language_helper
DEBUG - 2018-06-24 13:52:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-24 13:52:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-24 13:52:44 --> User Agent Class Initialized
INFO - 2018-06-24 13:52:44 --> Controller Class Initialized
INFO - 2018-06-24 13:52:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-24 13:52:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-24 13:52:44 --> Pixel_Model class loaded
INFO - 2018-06-24 13:52:44 --> Database Driver Class Initialized
INFO - 2018-06-24 13:52:44 --> Model "QuestionsModel" initialized
INFO - 2018-06-24 13:52:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-24 13:52:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-24 13:52:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-24 13:52:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-24 13:52:44 --> Final output sent to browser
DEBUG - 2018-06-24 13:52:44 --> Total execution time: 0.0333
INFO - 2018-06-24 14:47:44 --> Config Class Initialized
INFO - 2018-06-24 14:47:44 --> Hooks Class Initialized
DEBUG - 2018-06-24 14:47:44 --> UTF-8 Support Enabled
INFO - 2018-06-24 14:47:44 --> Utf8 Class Initialized
INFO - 2018-06-24 14:47:44 --> URI Class Initialized
INFO - 2018-06-24 14:47:44 --> Router Class Initialized
INFO - 2018-06-24 14:47:44 --> Output Class Initialized
INFO - 2018-06-24 14:47:44 --> Security Class Initialized
DEBUG - 2018-06-24 14:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-24 14:47:44 --> CSRF cookie sent
INFO - 2018-06-24 14:47:44 --> Input Class Initialized
INFO - 2018-06-24 14:47:44 --> Language Class Initialized
INFO - 2018-06-24 14:47:44 --> Loader Class Initialized
INFO - 2018-06-24 14:47:44 --> Helper loaded: url_helper
INFO - 2018-06-24 14:47:44 --> Helper loaded: form_helper
INFO - 2018-06-24 14:47:44 --> Helper loaded: language_helper
DEBUG - 2018-06-24 14:47:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-24 14:47:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-24 14:47:44 --> User Agent Class Initialized
INFO - 2018-06-24 14:47:44 --> Controller Class Initialized
INFO - 2018-06-24 14:47:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-24 14:47:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-24 14:47:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-24 14:47:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-24 14:47:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-24 14:47:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-24 14:47:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/faqs.php
INFO - 2018-06-24 14:47:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-24 14:47:44 --> Final output sent to browser
DEBUG - 2018-06-24 14:47:44 --> Total execution time: 0.0235
INFO - 2018-06-24 14:55:54 --> Config Class Initialized
INFO - 2018-06-24 14:55:54 --> Hooks Class Initialized
DEBUG - 2018-06-24 14:55:54 --> UTF-8 Support Enabled
INFO - 2018-06-24 14:55:54 --> Utf8 Class Initialized
INFO - 2018-06-24 14:55:54 --> URI Class Initialized
DEBUG - 2018-06-24 14:55:54 --> No URI present. Default controller set.
INFO - 2018-06-24 14:55:54 --> Router Class Initialized
INFO - 2018-06-24 14:55:54 --> Output Class Initialized
INFO - 2018-06-24 14:55:54 --> Security Class Initialized
DEBUG - 2018-06-24 14:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-24 14:55:54 --> CSRF cookie sent
INFO - 2018-06-24 14:55:54 --> Input Class Initialized
INFO - 2018-06-24 14:55:54 --> Language Class Initialized
INFO - 2018-06-24 14:55:54 --> Loader Class Initialized
INFO - 2018-06-24 14:55:54 --> Helper loaded: url_helper
INFO - 2018-06-24 14:55:54 --> Helper loaded: form_helper
INFO - 2018-06-24 14:55:54 --> Helper loaded: language_helper
DEBUG - 2018-06-24 14:55:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-24 14:55:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-24 14:55:54 --> User Agent Class Initialized
INFO - 2018-06-24 14:55:54 --> Controller Class Initialized
INFO - 2018-06-24 14:55:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-24 14:55:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-24 14:55:54 --> Pixel_Model class loaded
INFO - 2018-06-24 14:55:54 --> Database Driver Class Initialized
INFO - 2018-06-24 14:55:54 --> Model "QuestionsModel" initialized
INFO - 2018-06-24 14:55:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-24 14:55:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-24 14:55:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-24 14:55:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-24 14:55:54 --> Final output sent to browser
DEBUG - 2018-06-24 14:55:54 --> Total execution time: 0.0334
INFO - 2018-06-24 16:42:41 --> Config Class Initialized
INFO - 2018-06-24 16:42:41 --> Hooks Class Initialized
DEBUG - 2018-06-24 16:42:41 --> UTF-8 Support Enabled
INFO - 2018-06-24 16:42:41 --> Utf8 Class Initialized
INFO - 2018-06-24 16:42:41 --> URI Class Initialized
INFO - 2018-06-24 16:42:41 --> Router Class Initialized
INFO - 2018-06-24 16:42:41 --> Output Class Initialized
INFO - 2018-06-24 16:42:41 --> Security Class Initialized
DEBUG - 2018-06-24 16:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-24 16:42:41 --> CSRF cookie sent
INFO - 2018-06-24 16:42:41 --> Input Class Initialized
INFO - 2018-06-24 16:42:41 --> Language Class Initialized
ERROR - 2018-06-24 16:42:41 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-06-24 17:06:02 --> Config Class Initialized
INFO - 2018-06-24 17:06:02 --> Hooks Class Initialized
DEBUG - 2018-06-24 17:06:02 --> UTF-8 Support Enabled
INFO - 2018-06-24 17:06:02 --> Utf8 Class Initialized
INFO - 2018-06-24 17:06:02 --> URI Class Initialized
DEBUG - 2018-06-24 17:06:02 --> No URI present. Default controller set.
INFO - 2018-06-24 17:06:02 --> Router Class Initialized
INFO - 2018-06-24 17:06:02 --> Output Class Initialized
INFO - 2018-06-24 17:06:02 --> Security Class Initialized
DEBUG - 2018-06-24 17:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-24 17:06:02 --> CSRF cookie sent
INFO - 2018-06-24 17:06:02 --> Input Class Initialized
INFO - 2018-06-24 17:06:02 --> Language Class Initialized
INFO - 2018-06-24 17:06:02 --> Loader Class Initialized
INFO - 2018-06-24 17:06:02 --> Helper loaded: url_helper
INFO - 2018-06-24 17:06:03 --> Helper loaded: form_helper
INFO - 2018-06-24 17:06:03 --> Helper loaded: language_helper
DEBUG - 2018-06-24 17:06:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-24 17:06:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-24 17:06:03 --> User Agent Class Initialized
INFO - 2018-06-24 17:06:03 --> Controller Class Initialized
INFO - 2018-06-24 17:06:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-24 17:06:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-24 17:06:03 --> Pixel_Model class loaded
INFO - 2018-06-24 17:06:03 --> Database Driver Class Initialized
INFO - 2018-06-24 17:06:03 --> Model "QuestionsModel" initialized
INFO - 2018-06-24 17:06:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-24 17:06:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-24 17:06:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-24 17:06:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-24 17:06:03 --> Final output sent to browser
DEBUG - 2018-06-24 17:06:03 --> Total execution time: 0.0304
INFO - 2018-06-24 17:21:16 --> Config Class Initialized
INFO - 2018-06-24 17:21:16 --> Hooks Class Initialized
DEBUG - 2018-06-24 17:21:16 --> UTF-8 Support Enabled
INFO - 2018-06-24 17:21:16 --> Utf8 Class Initialized
INFO - 2018-06-24 17:21:16 --> URI Class Initialized
DEBUG - 2018-06-24 17:21:16 --> No URI present. Default controller set.
INFO - 2018-06-24 17:21:16 --> Router Class Initialized
INFO - 2018-06-24 17:21:16 --> Output Class Initialized
INFO - 2018-06-24 17:21:16 --> Security Class Initialized
DEBUG - 2018-06-24 17:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-24 17:21:16 --> CSRF cookie sent
INFO - 2018-06-24 17:21:16 --> Input Class Initialized
INFO - 2018-06-24 17:21:16 --> Language Class Initialized
INFO - 2018-06-24 17:21:16 --> Loader Class Initialized
INFO - 2018-06-24 17:21:16 --> Helper loaded: url_helper
INFO - 2018-06-24 17:21:16 --> Helper loaded: form_helper
INFO - 2018-06-24 17:21:16 --> Helper loaded: language_helper
DEBUG - 2018-06-24 17:21:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-24 17:21:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-24 17:21:16 --> User Agent Class Initialized
INFO - 2018-06-24 17:21:16 --> Controller Class Initialized
INFO - 2018-06-24 17:21:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-24 17:21:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-24 17:21:16 --> Pixel_Model class loaded
INFO - 2018-06-24 17:21:16 --> Database Driver Class Initialized
INFO - 2018-06-24 17:21:16 --> Model "QuestionsModel" initialized
INFO - 2018-06-24 17:21:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-24 17:21:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-24 17:21:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-24 17:21:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-24 17:21:16 --> Final output sent to browser
DEBUG - 2018-06-24 17:21:16 --> Total execution time: 0.0355
INFO - 2018-06-24 17:21:17 --> Config Class Initialized
INFO - 2018-06-24 17:21:17 --> Hooks Class Initialized
DEBUG - 2018-06-24 17:21:17 --> UTF-8 Support Enabled
INFO - 2018-06-24 17:21:17 --> Utf8 Class Initialized
INFO - 2018-06-24 17:21:17 --> URI Class Initialized
DEBUG - 2018-06-24 17:21:17 --> No URI present. Default controller set.
INFO - 2018-06-24 17:21:17 --> Router Class Initialized
INFO - 2018-06-24 17:21:17 --> Output Class Initialized
INFO - 2018-06-24 17:21:17 --> Security Class Initialized
DEBUG - 2018-06-24 17:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-24 17:21:17 --> CSRF cookie sent
INFO - 2018-06-24 17:21:17 --> Input Class Initialized
INFO - 2018-06-24 17:21:17 --> Language Class Initialized
INFO - 2018-06-24 17:21:17 --> Loader Class Initialized
INFO - 2018-06-24 17:21:17 --> Helper loaded: url_helper
INFO - 2018-06-24 17:21:17 --> Helper loaded: form_helper
INFO - 2018-06-24 17:21:17 --> Helper loaded: language_helper
DEBUG - 2018-06-24 17:21:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-24 17:21:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-24 17:21:17 --> User Agent Class Initialized
INFO - 2018-06-24 17:21:17 --> Controller Class Initialized
INFO - 2018-06-24 17:21:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-24 17:21:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-24 17:21:17 --> Pixel_Model class loaded
INFO - 2018-06-24 17:21:17 --> Database Driver Class Initialized
INFO - 2018-06-24 17:21:17 --> Model "QuestionsModel" initialized
INFO - 2018-06-24 17:21:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-24 17:21:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-24 17:21:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-24 17:21:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-24 17:21:17 --> Final output sent to browser
DEBUG - 2018-06-24 17:21:17 --> Total execution time: 0.0437
INFO - 2018-06-24 17:21:17 --> Config Class Initialized
INFO - 2018-06-24 17:21:17 --> Hooks Class Initialized
DEBUG - 2018-06-24 17:21:17 --> UTF-8 Support Enabled
INFO - 2018-06-24 17:21:17 --> Utf8 Class Initialized
INFO - 2018-06-24 17:21:17 --> URI Class Initialized
DEBUG - 2018-06-24 17:21:17 --> No URI present. Default controller set.
INFO - 2018-06-24 17:21:17 --> Router Class Initialized
INFO - 2018-06-24 17:21:17 --> Output Class Initialized
INFO - 2018-06-24 17:21:17 --> Security Class Initialized
DEBUG - 2018-06-24 17:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-24 17:21:17 --> CSRF cookie sent
INFO - 2018-06-24 17:21:17 --> Input Class Initialized
INFO - 2018-06-24 17:21:17 --> Language Class Initialized
INFO - 2018-06-24 17:21:17 --> Loader Class Initialized
INFO - 2018-06-24 17:21:17 --> Helper loaded: url_helper
INFO - 2018-06-24 17:21:17 --> Helper loaded: form_helper
INFO - 2018-06-24 17:21:17 --> Helper loaded: language_helper
DEBUG - 2018-06-24 17:21:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-24 17:21:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-24 17:21:17 --> User Agent Class Initialized
INFO - 2018-06-24 17:21:17 --> Controller Class Initialized
INFO - 2018-06-24 17:21:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-24 17:21:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-24 17:21:17 --> Pixel_Model class loaded
INFO - 2018-06-24 17:21:17 --> Database Driver Class Initialized
INFO - 2018-06-24 17:21:17 --> Model "QuestionsModel" initialized
INFO - 2018-06-24 17:21:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-24 17:21:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-24 17:21:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-24 17:21:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-24 17:21:17 --> Final output sent to browser
DEBUG - 2018-06-24 17:21:17 --> Total execution time: 0.0425
INFO - 2018-06-24 17:21:18 --> Config Class Initialized
INFO - 2018-06-24 17:21:18 --> Hooks Class Initialized
DEBUG - 2018-06-24 17:21:18 --> UTF-8 Support Enabled
INFO - 2018-06-24 17:21:18 --> Utf8 Class Initialized
INFO - 2018-06-24 17:21:18 --> URI Class Initialized
INFO - 2018-06-24 17:21:18 --> Router Class Initialized
INFO - 2018-06-24 17:21:18 --> Output Class Initialized
INFO - 2018-06-24 17:21:18 --> Security Class Initialized
DEBUG - 2018-06-24 17:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-24 17:21:18 --> CSRF cookie sent
INFO - 2018-06-24 17:21:18 --> Input Class Initialized
INFO - 2018-06-24 17:21:18 --> Language Class Initialized
ERROR - 2018-06-24 17:21:18 --> 404 Page Not Found: 405shtml/index
INFO - 2018-06-24 17:21:25 --> Config Class Initialized
INFO - 2018-06-24 17:21:25 --> Hooks Class Initialized
DEBUG - 2018-06-24 17:21:25 --> UTF-8 Support Enabled
INFO - 2018-06-24 17:21:25 --> Utf8 Class Initialized
INFO - 2018-06-24 17:21:25 --> URI Class Initialized
DEBUG - 2018-06-24 17:21:25 --> No URI present. Default controller set.
INFO - 2018-06-24 17:21:25 --> Router Class Initialized
INFO - 2018-06-24 17:21:25 --> Output Class Initialized
INFO - 2018-06-24 17:21:25 --> Security Class Initialized
DEBUG - 2018-06-24 17:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-24 17:21:25 --> CSRF cookie sent
INFO - 2018-06-24 17:21:25 --> Input Class Initialized
INFO - 2018-06-24 17:21:25 --> Language Class Initialized
INFO - 2018-06-24 17:21:25 --> Loader Class Initialized
INFO - 2018-06-24 17:21:25 --> Helper loaded: url_helper
INFO - 2018-06-24 17:21:25 --> Helper loaded: form_helper
INFO - 2018-06-24 17:21:25 --> Helper loaded: language_helper
DEBUG - 2018-06-24 17:21:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-24 17:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-24 17:21:25 --> User Agent Class Initialized
INFO - 2018-06-24 17:21:25 --> Controller Class Initialized
INFO - 2018-06-24 17:21:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-24 17:21:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-24 17:21:25 --> Pixel_Model class loaded
INFO - 2018-06-24 17:21:25 --> Database Driver Class Initialized
INFO - 2018-06-24 17:21:25 --> Model "QuestionsModel" initialized
INFO - 2018-06-24 17:21:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-24 17:21:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-24 17:21:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-24 17:21:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-24 17:21:25 --> Final output sent to browser
DEBUG - 2018-06-24 17:21:25 --> Total execution time: 0.0340
INFO - 2018-06-24 17:21:25 --> Config Class Initialized
INFO - 2018-06-24 17:21:25 --> Hooks Class Initialized
DEBUG - 2018-06-24 17:21:25 --> UTF-8 Support Enabled
INFO - 2018-06-24 17:21:25 --> Utf8 Class Initialized
INFO - 2018-06-24 17:21:25 --> URI Class Initialized
INFO - 2018-06-24 17:21:25 --> Router Class Initialized
INFO - 2018-06-24 17:21:25 --> Output Class Initialized
INFO - 2018-06-24 17:21:25 --> Security Class Initialized
DEBUG - 2018-06-24 17:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-24 17:21:25 --> CSRF cookie sent
INFO - 2018-06-24 17:21:25 --> Input Class Initialized
INFO - 2018-06-24 17:21:25 --> Language Class Initialized
ERROR - 2018-06-24 17:21:25 --> 404 Page Not Found: 404testpage4525d2fdc/index
INFO - 2018-06-24 17:21:25 --> Config Class Initialized
INFO - 2018-06-24 17:21:25 --> Hooks Class Initialized
DEBUG - 2018-06-24 17:21:25 --> UTF-8 Support Enabled
INFO - 2018-06-24 17:21:25 --> Utf8 Class Initialized
INFO - 2018-06-24 17:21:25 --> URI Class Initialized
INFO - 2018-06-24 17:21:25 --> Router Class Initialized
INFO - 2018-06-24 17:21:25 --> Output Class Initialized
INFO - 2018-06-24 17:21:25 --> Security Class Initialized
DEBUG - 2018-06-24 17:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-24 17:21:25 --> CSRF cookie sent
INFO - 2018-06-24 17:21:25 --> Input Class Initialized
INFO - 2018-06-24 17:21:25 --> Language Class Initialized
ERROR - 2018-06-24 17:21:25 --> 404 Page Not Found: 404javascriptjs/index
INFO - 2018-06-24 17:21:26 --> Config Class Initialized
INFO - 2018-06-24 17:21:26 --> Hooks Class Initialized
DEBUG - 2018-06-24 17:21:26 --> UTF-8 Support Enabled
INFO - 2018-06-24 17:21:26 --> Utf8 Class Initialized
INFO - 2018-06-24 17:21:26 --> URI Class Initialized
INFO - 2018-06-24 17:21:26 --> Router Class Initialized
INFO - 2018-06-24 17:21:26 --> Output Class Initialized
INFO - 2018-06-24 17:21:26 --> Security Class Initialized
DEBUG - 2018-06-24 17:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-24 17:21:26 --> CSRF cookie sent
INFO - 2018-06-24 17:21:26 --> Input Class Initialized
INFO - 2018-06-24 17:21:26 --> Language Class Initialized
INFO - 2018-06-24 17:21:26 --> Loader Class Initialized
INFO - 2018-06-24 17:21:26 --> Helper loaded: url_helper
INFO - 2018-06-24 17:21:26 --> Helper loaded: form_helper
INFO - 2018-06-24 17:21:26 --> Helper loaded: language_helper
DEBUG - 2018-06-24 17:21:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-24 17:21:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-24 17:21:26 --> User Agent Class Initialized
INFO - 2018-06-24 17:21:26 --> Controller Class Initialized
INFO - 2018-06-24 17:21:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-24 17:21:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-24 17:21:26 --> Pixel_Model class loaded
INFO - 2018-06-24 17:21:26 --> Database Driver Class Initialized
INFO - 2018-06-24 17:21:26 --> Model "QuestionsModel" initialized
ERROR - 2018-06-24 17:21:26 --> Severity: Notice --> Undefined index: HTTP_REFERER /home/fxp6bn7rqemh/public_html/application/core/Pixel_Controller.php 87
INFO - 2018-06-24 17:21:26 --> Config Class Initialized
INFO - 2018-06-24 17:21:26 --> Hooks Class Initialized
DEBUG - 2018-06-24 17:21:26 --> UTF-8 Support Enabled
INFO - 2018-06-24 17:21:26 --> Utf8 Class Initialized
INFO - 2018-06-24 17:21:26 --> URI Class Initialized
INFO - 2018-06-24 17:21:26 --> Router Class Initialized
INFO - 2018-06-24 17:21:26 --> Output Class Initialized
INFO - 2018-06-24 17:21:26 --> Security Class Initialized
DEBUG - 2018-06-24 17:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-24 17:21:26 --> CSRF cookie sent
INFO - 2018-06-24 17:21:26 --> Input Class Initialized
INFO - 2018-06-24 17:21:26 --> Language Class Initialized
INFO - 2018-06-24 17:21:26 --> Loader Class Initialized
INFO - 2018-06-24 17:21:26 --> Helper loaded: url_helper
INFO - 2018-06-24 17:21:26 --> Helper loaded: form_helper
INFO - 2018-06-24 17:21:26 --> Helper loaded: language_helper
DEBUG - 2018-06-24 17:21:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-24 17:21:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-24 17:21:26 --> User Agent Class Initialized
INFO - 2018-06-24 17:21:26 --> Controller Class Initialized
INFO - 2018-06-24 17:21:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-24 17:21:26 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-24 17:21:26 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-24 17:21:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-24 17:21:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-24 17:21:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-24 17:21:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-24 17:21:26 --> Could not find the language line "req_email"
INFO - 2018-06-24 17:21:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-06-24 17:21:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-24 17:21:26 --> Final output sent to browser
DEBUG - 2018-06-24 17:21:26 --> Total execution time: 0.0288
INFO - 2018-06-24 17:21:26 --> Config Class Initialized
INFO - 2018-06-24 17:21:26 --> Hooks Class Initialized
DEBUG - 2018-06-24 17:21:26 --> UTF-8 Support Enabled
INFO - 2018-06-24 17:21:26 --> Utf8 Class Initialized
INFO - 2018-06-24 17:21:26 --> URI Class Initialized
INFO - 2018-06-24 17:21:26 --> Router Class Initialized
INFO - 2018-06-24 17:21:26 --> Output Class Initialized
INFO - 2018-06-24 17:21:26 --> Security Class Initialized
DEBUG - 2018-06-24 17:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-24 17:21:26 --> CSRF cookie sent
INFO - 2018-06-24 17:21:26 --> Input Class Initialized
INFO - 2018-06-24 17:21:26 --> Language Class Initialized
INFO - 2018-06-24 17:21:26 --> Loader Class Initialized
INFO - 2018-06-24 17:21:26 --> Helper loaded: url_helper
INFO - 2018-06-24 17:21:26 --> Helper loaded: form_helper
INFO - 2018-06-24 17:21:26 --> Helper loaded: language_helper
DEBUG - 2018-06-24 17:21:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-24 17:21:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-24 17:21:26 --> User Agent Class Initialized
INFO - 2018-06-24 17:21:26 --> Controller Class Initialized
INFO - 2018-06-24 17:21:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-24 17:21:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-24 17:21:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-24 17:21:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-24 17:21:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-24 17:21:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-24 17:21:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-06-24 17:21:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-24 17:21:26 --> Final output sent to browser
DEBUG - 2018-06-24 17:21:26 --> Total execution time: 0.0219
INFO - 2018-06-24 17:21:27 --> Config Class Initialized
INFO - 2018-06-24 17:21:27 --> Hooks Class Initialized
DEBUG - 2018-06-24 17:21:27 --> UTF-8 Support Enabled
INFO - 2018-06-24 17:21:27 --> Utf8 Class Initialized
INFO - 2018-06-24 17:21:27 --> URI Class Initialized
INFO - 2018-06-24 17:21:27 --> Router Class Initialized
INFO - 2018-06-24 17:21:27 --> Output Class Initialized
INFO - 2018-06-24 17:21:27 --> Security Class Initialized
DEBUG - 2018-06-24 17:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-24 17:21:27 --> CSRF cookie sent
INFO - 2018-06-24 17:21:27 --> Input Class Initialized
INFO - 2018-06-24 17:21:27 --> Language Class Initialized
INFO - 2018-06-24 17:21:27 --> Loader Class Initialized
INFO - 2018-06-24 17:21:27 --> Helper loaded: url_helper
INFO - 2018-06-24 17:21:27 --> Helper loaded: form_helper
INFO - 2018-06-24 17:21:27 --> Helper loaded: language_helper
DEBUG - 2018-06-24 17:21:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-24 17:21:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-24 17:21:27 --> User Agent Class Initialized
INFO - 2018-06-24 17:21:27 --> Controller Class Initialized
INFO - 2018-06-24 17:21:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-24 17:21:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-24 17:21:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-24 17:21:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-24 17:21:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-24 17:21:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-24 17:21:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-06-24 17:21:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-24 17:21:27 --> Final output sent to browser
DEBUG - 2018-06-24 17:21:27 --> Total execution time: 0.0210
INFO - 2018-06-24 17:21:27 --> Config Class Initialized
INFO - 2018-06-24 17:21:27 --> Hooks Class Initialized
DEBUG - 2018-06-24 17:21:27 --> UTF-8 Support Enabled
INFO - 2018-06-24 17:21:27 --> Utf8 Class Initialized
INFO - 2018-06-24 17:21:27 --> URI Class Initialized
INFO - 2018-06-24 17:21:27 --> Router Class Initialized
INFO - 2018-06-24 17:21:27 --> Output Class Initialized
INFO - 2018-06-24 17:21:27 --> Security Class Initialized
DEBUG - 2018-06-24 17:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-24 17:21:27 --> CSRF cookie sent
INFO - 2018-06-24 17:21:27 --> Input Class Initialized
INFO - 2018-06-24 17:21:27 --> Language Class Initialized
INFO - 2018-06-24 17:21:27 --> Loader Class Initialized
INFO - 2018-06-24 17:21:27 --> Helper loaded: url_helper
INFO - 2018-06-24 17:21:27 --> Helper loaded: form_helper
INFO - 2018-06-24 17:21:27 --> Helper loaded: language_helper
DEBUG - 2018-06-24 17:21:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-24 17:21:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-24 17:21:27 --> User Agent Class Initialized
INFO - 2018-06-24 17:21:27 --> Controller Class Initialized
INFO - 2018-06-24 17:21:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-24 17:21:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-24 17:21:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-24 17:21:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-24 17:21:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-24 17:21:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-24 17:21:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-06-24 17:21:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-24 17:21:27 --> Final output sent to browser
DEBUG - 2018-06-24 17:21:27 --> Total execution time: 0.0207
INFO - 2018-06-24 17:21:27 --> Config Class Initialized
INFO - 2018-06-24 17:21:27 --> Hooks Class Initialized
DEBUG - 2018-06-24 17:21:27 --> UTF-8 Support Enabled
INFO - 2018-06-24 17:21:27 --> Utf8 Class Initialized
INFO - 2018-06-24 17:21:27 --> URI Class Initialized
INFO - 2018-06-24 17:21:27 --> Router Class Initialized
INFO - 2018-06-24 17:21:27 --> Output Class Initialized
INFO - 2018-06-24 17:21:27 --> Security Class Initialized
DEBUG - 2018-06-24 17:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-24 17:21:27 --> CSRF cookie sent
INFO - 2018-06-24 17:21:27 --> Input Class Initialized
INFO - 2018-06-24 17:21:27 --> Language Class Initialized
INFO - 2018-06-24 17:21:27 --> Loader Class Initialized
INFO - 2018-06-24 17:21:27 --> Helper loaded: url_helper
INFO - 2018-06-24 17:21:27 --> Helper loaded: form_helper
INFO - 2018-06-24 17:21:27 --> Helper loaded: language_helper
DEBUG - 2018-06-24 17:21:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-24 17:21:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-24 17:21:27 --> User Agent Class Initialized
INFO - 2018-06-24 17:21:27 --> Controller Class Initialized
INFO - 2018-06-24 17:21:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-24 17:21:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-24 17:21:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-24 17:21:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-24 17:21:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-24 17:21:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-24 17:21:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-06-24 17:21:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-24 17:21:27 --> Final output sent to browser
DEBUG - 2018-06-24 17:21:27 --> Total execution time: 0.0224
INFO - 2018-06-24 17:21:28 --> Config Class Initialized
INFO - 2018-06-24 17:21:28 --> Hooks Class Initialized
DEBUG - 2018-06-24 17:21:28 --> UTF-8 Support Enabled
INFO - 2018-06-24 17:21:28 --> Utf8 Class Initialized
INFO - 2018-06-24 17:21:28 --> URI Class Initialized
INFO - 2018-06-24 17:21:28 --> Router Class Initialized
INFO - 2018-06-24 17:21:28 --> Output Class Initialized
INFO - 2018-06-24 17:21:28 --> Security Class Initialized
DEBUG - 2018-06-24 17:21:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-24 17:21:28 --> CSRF cookie sent
INFO - 2018-06-24 17:21:28 --> Input Class Initialized
INFO - 2018-06-24 17:21:28 --> Language Class Initialized
INFO - 2018-06-24 17:21:28 --> Loader Class Initialized
INFO - 2018-06-24 17:21:28 --> Helper loaded: url_helper
INFO - 2018-06-24 17:21:28 --> Helper loaded: form_helper
INFO - 2018-06-24 17:21:28 --> Helper loaded: language_helper
DEBUG - 2018-06-24 17:21:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-24 17:21:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-24 17:21:28 --> User Agent Class Initialized
INFO - 2018-06-24 17:21:28 --> Controller Class Initialized
INFO - 2018-06-24 17:21:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-24 17:21:28 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-24 17:21:28 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-24 17:21:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-24 17:21:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-24 17:21:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-24 17:21:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-24 17:21:28 --> Could not find the language line "req_email"
INFO - 2018-06-24 17:21:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-06-24 17:21:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-24 17:21:28 --> Final output sent to browser
DEBUG - 2018-06-24 17:21:28 --> Total execution time: 0.0219
INFO - 2018-06-24 17:21:28 --> Config Class Initialized
INFO - 2018-06-24 17:21:28 --> Hooks Class Initialized
DEBUG - 2018-06-24 17:21:28 --> UTF-8 Support Enabled
INFO - 2018-06-24 17:21:28 --> Utf8 Class Initialized
INFO - 2018-06-24 17:21:28 --> URI Class Initialized
INFO - 2018-06-24 17:21:28 --> Router Class Initialized
INFO - 2018-06-24 17:21:28 --> Output Class Initialized
INFO - 2018-06-24 17:21:28 --> Security Class Initialized
DEBUG - 2018-06-24 17:21:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-24 17:21:28 --> CSRF cookie sent
INFO - 2018-06-24 17:21:28 --> Input Class Initialized
INFO - 2018-06-24 17:21:28 --> Language Class Initialized
INFO - 2018-06-24 17:21:28 --> Loader Class Initialized
INFO - 2018-06-24 17:21:28 --> Helper loaded: url_helper
INFO - 2018-06-24 17:21:28 --> Helper loaded: form_helper
INFO - 2018-06-24 17:21:28 --> Helper loaded: language_helper
DEBUG - 2018-06-24 17:21:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-24 17:21:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-24 17:21:28 --> User Agent Class Initialized
INFO - 2018-06-24 17:21:28 --> Controller Class Initialized
INFO - 2018-06-24 17:21:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-24 17:21:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-24 17:21:28 --> Pixel_Model class loaded
INFO - 2018-06-24 17:21:28 --> Database Driver Class Initialized
INFO - 2018-06-24 17:21:28 --> Model "QuestionsModel" initialized
INFO - 2018-06-24 17:21:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-24 17:21:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-24 17:21:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-24 17:21:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-24 17:21:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/buy_gift.php
INFO - 2018-06-24 17:21:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-24 17:21:28 --> Final output sent to browser
DEBUG - 2018-06-24 17:21:28 --> Total execution time: 0.0322
INFO - 2018-06-24 20:06:36 --> Config Class Initialized
INFO - 2018-06-24 20:06:36 --> Hooks Class Initialized
DEBUG - 2018-06-24 20:06:36 --> UTF-8 Support Enabled
INFO - 2018-06-24 20:06:36 --> Utf8 Class Initialized
INFO - 2018-06-24 20:06:36 --> URI Class Initialized
DEBUG - 2018-06-24 20:06:36 --> No URI present. Default controller set.
INFO - 2018-06-24 20:06:36 --> Router Class Initialized
INFO - 2018-06-24 20:06:36 --> Output Class Initialized
INFO - 2018-06-24 20:06:36 --> Security Class Initialized
DEBUG - 2018-06-24 20:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-24 20:06:36 --> CSRF cookie sent
INFO - 2018-06-24 20:06:36 --> Input Class Initialized
INFO - 2018-06-24 20:06:36 --> Language Class Initialized
INFO - 2018-06-24 20:06:36 --> Loader Class Initialized
INFO - 2018-06-24 20:06:36 --> Helper loaded: url_helper
INFO - 2018-06-24 20:06:36 --> Helper loaded: form_helper
INFO - 2018-06-24 20:06:36 --> Helper loaded: language_helper
DEBUG - 2018-06-24 20:06:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-24 20:06:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-24 20:06:36 --> User Agent Class Initialized
INFO - 2018-06-24 20:06:36 --> Controller Class Initialized
INFO - 2018-06-24 20:06:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-24 20:06:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-24 20:06:36 --> Pixel_Model class loaded
INFO - 2018-06-24 20:06:36 --> Database Driver Class Initialized
INFO - 2018-06-24 20:06:36 --> Model "QuestionsModel" initialized
INFO - 2018-06-24 20:06:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-24 20:06:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-24 20:06:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-24 20:06:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-24 20:06:36 --> Final output sent to browser
DEBUG - 2018-06-24 20:06:36 --> Total execution time: 0.0360
INFO - 2018-06-24 20:07:36 --> Config Class Initialized
INFO - 2018-06-24 20:07:36 --> Hooks Class Initialized
DEBUG - 2018-06-24 20:07:36 --> UTF-8 Support Enabled
INFO - 2018-06-24 20:07:36 --> Utf8 Class Initialized
INFO - 2018-06-24 20:07:36 --> URI Class Initialized
DEBUG - 2018-06-24 20:07:36 --> No URI present. Default controller set.
INFO - 2018-06-24 20:07:36 --> Router Class Initialized
INFO - 2018-06-24 20:07:36 --> Output Class Initialized
INFO - 2018-06-24 20:07:36 --> Security Class Initialized
DEBUG - 2018-06-24 20:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-24 20:07:36 --> CSRF cookie sent
INFO - 2018-06-24 20:07:36 --> Input Class Initialized
INFO - 2018-06-24 20:07:36 --> Language Class Initialized
INFO - 2018-06-24 20:07:36 --> Loader Class Initialized
INFO - 2018-06-24 20:07:36 --> Helper loaded: url_helper
INFO - 2018-06-24 20:07:36 --> Helper loaded: form_helper
INFO - 2018-06-24 20:07:36 --> Helper loaded: language_helper
DEBUG - 2018-06-24 20:07:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-24 20:07:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-24 20:07:36 --> User Agent Class Initialized
INFO - 2018-06-24 20:07:36 --> Controller Class Initialized
INFO - 2018-06-24 20:07:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-24 20:07:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-24 20:07:36 --> Pixel_Model class loaded
INFO - 2018-06-24 20:07:36 --> Database Driver Class Initialized
INFO - 2018-06-24 20:07:36 --> Model "QuestionsModel" initialized
INFO - 2018-06-24 20:07:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-24 20:07:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-24 20:07:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-24 20:07:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-24 20:07:36 --> Final output sent to browser
DEBUG - 2018-06-24 20:07:36 --> Total execution time: 0.0305
INFO - 2018-06-24 22:55:25 --> Config Class Initialized
INFO - 2018-06-24 22:55:25 --> Hooks Class Initialized
DEBUG - 2018-06-24 22:55:25 --> UTF-8 Support Enabled
INFO - 2018-06-24 22:55:25 --> Utf8 Class Initialized
INFO - 2018-06-24 22:55:25 --> URI Class Initialized
INFO - 2018-06-24 22:55:25 --> Router Class Initialized
INFO - 2018-06-24 22:55:25 --> Output Class Initialized
INFO - 2018-06-24 22:55:25 --> Security Class Initialized
DEBUG - 2018-06-24 22:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-24 22:55:25 --> CSRF cookie sent
INFO - 2018-06-24 22:55:25 --> Input Class Initialized
INFO - 2018-06-24 22:55:25 --> Language Class Initialized
ERROR - 2018-06-24 22:55:25 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-06-24 22:55:25 --> Config Class Initialized
INFO - 2018-06-24 22:55:25 --> Hooks Class Initialized
DEBUG - 2018-06-24 22:55:25 --> UTF-8 Support Enabled
INFO - 2018-06-24 22:55:25 --> Utf8 Class Initialized
INFO - 2018-06-24 22:55:25 --> URI Class Initialized
INFO - 2018-06-24 22:55:25 --> Router Class Initialized
INFO - 2018-06-24 22:55:25 --> Output Class Initialized
INFO - 2018-06-24 22:55:25 --> Security Class Initialized
DEBUG - 2018-06-24 22:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-24 22:55:25 --> CSRF cookie sent
INFO - 2018-06-24 22:55:25 --> Input Class Initialized
INFO - 2018-06-24 22:55:25 --> Language Class Initialized
INFO - 2018-06-24 22:55:25 --> Loader Class Initialized
INFO - 2018-06-24 22:55:25 --> Helper loaded: url_helper
INFO - 2018-06-24 22:55:25 --> Helper loaded: form_helper
INFO - 2018-06-24 22:55:25 --> Helper loaded: language_helper
DEBUG - 2018-06-24 22:55:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-24 22:55:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-24 22:55:25 --> User Agent Class Initialized
INFO - 2018-06-24 22:55:25 --> Controller Class Initialized
INFO - 2018-06-24 22:55:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-24 22:55:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-24 22:55:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-24 22:55:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-24 22:55:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-24 22:55:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-24 22:55:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-06-24 22:55:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-24 22:55:25 --> Final output sent to browser
DEBUG - 2018-06-24 22:55:25 --> Total execution time: 0.0220

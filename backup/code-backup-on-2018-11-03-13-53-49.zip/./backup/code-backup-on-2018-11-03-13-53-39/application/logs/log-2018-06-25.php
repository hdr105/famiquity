<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-06-25 00:21:39 --> Config Class Initialized
INFO - 2018-06-25 00:21:39 --> Hooks Class Initialized
DEBUG - 2018-06-25 00:21:39 --> UTF-8 Support Enabled
INFO - 2018-06-25 00:21:39 --> Utf8 Class Initialized
INFO - 2018-06-25 00:21:39 --> URI Class Initialized
INFO - 2018-06-25 00:21:39 --> Router Class Initialized
INFO - 2018-06-25 00:21:39 --> Output Class Initialized
INFO - 2018-06-25 00:21:39 --> Security Class Initialized
DEBUG - 2018-06-25 00:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 00:21:39 --> CSRF cookie sent
INFO - 2018-06-25 00:21:39 --> Input Class Initialized
INFO - 2018-06-25 00:21:39 --> Language Class Initialized
INFO - 2018-06-25 00:21:39 --> Loader Class Initialized
INFO - 2018-06-25 00:21:39 --> Helper loaded: url_helper
INFO - 2018-06-25 00:21:39 --> Helper loaded: form_helper
INFO - 2018-06-25 00:21:39 --> Helper loaded: language_helper
DEBUG - 2018-06-25 00:21:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 00:21:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 00:21:39 --> User Agent Class Initialized
INFO - 2018-06-25 00:21:39 --> Controller Class Initialized
INFO - 2018-06-25 00:21:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-25 00:21:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-25 00:21:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-25 00:21:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-25 00:21:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-25 00:21:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-25 00:21:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-06-25 00:21:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-25 00:21:39 --> Final output sent to browser
DEBUG - 2018-06-25 00:21:39 --> Total execution time: 0.0204
INFO - 2018-06-25 00:37:36 --> Config Class Initialized
INFO - 2018-06-25 00:37:36 --> Hooks Class Initialized
DEBUG - 2018-06-25 00:37:36 --> UTF-8 Support Enabled
INFO - 2018-06-25 00:37:36 --> Utf8 Class Initialized
INFO - 2018-06-25 00:37:36 --> URI Class Initialized
DEBUG - 2018-06-25 00:37:36 --> No URI present. Default controller set.
INFO - 2018-06-25 00:37:36 --> Router Class Initialized
INFO - 2018-06-25 00:37:36 --> Output Class Initialized
INFO - 2018-06-25 00:37:36 --> Security Class Initialized
DEBUG - 2018-06-25 00:37:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 00:37:36 --> CSRF cookie sent
INFO - 2018-06-25 00:37:36 --> Input Class Initialized
INFO - 2018-06-25 00:37:36 --> Language Class Initialized
INFO - 2018-06-25 00:37:36 --> Loader Class Initialized
INFO - 2018-06-25 00:37:36 --> Helper loaded: url_helper
INFO - 2018-06-25 00:37:36 --> Helper loaded: form_helper
INFO - 2018-06-25 00:37:36 --> Helper loaded: language_helper
DEBUG - 2018-06-25 00:37:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 00:37:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 00:37:36 --> User Agent Class Initialized
INFO - 2018-06-25 00:37:36 --> Controller Class Initialized
INFO - 2018-06-25 00:37:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-25 00:37:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-25 00:37:36 --> Pixel_Model class loaded
INFO - 2018-06-25 00:37:36 --> Database Driver Class Initialized
INFO - 2018-06-25 00:37:36 --> Model "QuestionsModel" initialized
INFO - 2018-06-25 00:37:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-25 00:37:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-25 00:37:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-25 00:37:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-25 00:37:36 --> Final output sent to browser
DEBUG - 2018-06-25 00:37:36 --> Total execution time: 0.0347
INFO - 2018-06-25 01:24:17 --> Config Class Initialized
INFO - 2018-06-25 01:24:17 --> Hooks Class Initialized
DEBUG - 2018-06-25 01:24:17 --> UTF-8 Support Enabled
INFO - 2018-06-25 01:24:17 --> Utf8 Class Initialized
INFO - 2018-06-25 01:24:17 --> URI Class Initialized
DEBUG - 2018-06-25 01:24:17 --> No URI present. Default controller set.
INFO - 2018-06-25 01:24:17 --> Router Class Initialized
INFO - 2018-06-25 01:24:17 --> Output Class Initialized
INFO - 2018-06-25 01:24:17 --> Security Class Initialized
DEBUG - 2018-06-25 01:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 01:24:17 --> CSRF cookie sent
INFO - 2018-06-25 01:24:17 --> Input Class Initialized
INFO - 2018-06-25 01:24:17 --> Language Class Initialized
INFO - 2018-06-25 01:24:17 --> Loader Class Initialized
INFO - 2018-06-25 01:24:17 --> Helper loaded: url_helper
INFO - 2018-06-25 01:24:17 --> Helper loaded: form_helper
INFO - 2018-06-25 01:24:17 --> Helper loaded: language_helper
DEBUG - 2018-06-25 01:24:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 01:24:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 01:24:17 --> User Agent Class Initialized
INFO - 2018-06-25 01:24:17 --> Controller Class Initialized
INFO - 2018-06-25 01:24:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-25 01:24:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-25 01:24:17 --> Pixel_Model class loaded
INFO - 2018-06-25 01:24:17 --> Database Driver Class Initialized
INFO - 2018-06-25 01:24:17 --> Model "QuestionsModel" initialized
INFO - 2018-06-25 01:24:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-25 01:24:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-25 01:24:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-25 01:24:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-25 01:24:17 --> Final output sent to browser
DEBUG - 2018-06-25 01:24:17 --> Total execution time: 0.0464
INFO - 2018-06-25 05:20:28 --> Config Class Initialized
INFO - 2018-06-25 05:20:28 --> Hooks Class Initialized
DEBUG - 2018-06-25 05:20:28 --> UTF-8 Support Enabled
INFO - 2018-06-25 05:20:28 --> Utf8 Class Initialized
INFO - 2018-06-25 05:20:28 --> URI Class Initialized
INFO - 2018-06-25 05:20:28 --> Router Class Initialized
INFO - 2018-06-25 05:20:28 --> Output Class Initialized
INFO - 2018-06-25 05:20:28 --> Security Class Initialized
DEBUG - 2018-06-25 05:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 05:20:28 --> CSRF cookie sent
INFO - 2018-06-25 05:20:28 --> Input Class Initialized
INFO - 2018-06-25 05:20:28 --> Language Class Initialized
ERROR - 2018-06-25 05:20:28 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-06-25 05:20:31 --> Config Class Initialized
INFO - 2018-06-25 05:20:31 --> Hooks Class Initialized
DEBUG - 2018-06-25 05:20:31 --> UTF-8 Support Enabled
INFO - 2018-06-25 05:20:31 --> Utf8 Class Initialized
INFO - 2018-06-25 05:20:31 --> URI Class Initialized
DEBUG - 2018-06-25 05:20:31 --> No URI present. Default controller set.
INFO - 2018-06-25 05:20:31 --> Router Class Initialized
INFO - 2018-06-25 05:20:31 --> Output Class Initialized
INFO - 2018-06-25 05:20:31 --> Security Class Initialized
DEBUG - 2018-06-25 05:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 05:20:31 --> CSRF cookie sent
INFO - 2018-06-25 05:20:31 --> Input Class Initialized
INFO - 2018-06-25 05:20:31 --> Language Class Initialized
INFO - 2018-06-25 05:20:31 --> Loader Class Initialized
INFO - 2018-06-25 05:20:31 --> Helper loaded: url_helper
INFO - 2018-06-25 05:20:31 --> Helper loaded: form_helper
INFO - 2018-06-25 05:20:31 --> Helper loaded: language_helper
DEBUG - 2018-06-25 05:20:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 05:20:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 05:20:31 --> User Agent Class Initialized
INFO - 2018-06-25 05:20:31 --> Controller Class Initialized
INFO - 2018-06-25 05:20:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-25 05:20:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-25 05:20:31 --> Pixel_Model class loaded
INFO - 2018-06-25 05:20:31 --> Database Driver Class Initialized
INFO - 2018-06-25 05:20:31 --> Model "QuestionsModel" initialized
INFO - 2018-06-25 05:20:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-25 05:20:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-25 05:20:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-25 05:20:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-25 05:20:31 --> Final output sent to browser
DEBUG - 2018-06-25 05:20:31 --> Total execution time: 0.0323
INFO - 2018-06-25 05:34:49 --> Config Class Initialized
INFO - 2018-06-25 05:34:49 --> Hooks Class Initialized
DEBUG - 2018-06-25 05:34:49 --> UTF-8 Support Enabled
INFO - 2018-06-25 05:34:49 --> Utf8 Class Initialized
INFO - 2018-06-25 05:34:49 --> URI Class Initialized
INFO - 2018-06-25 05:34:49 --> Router Class Initialized
INFO - 2018-06-25 05:34:49 --> Output Class Initialized
INFO - 2018-06-25 05:34:49 --> Security Class Initialized
DEBUG - 2018-06-25 05:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 05:34:49 --> CSRF cookie sent
INFO - 2018-06-25 05:34:49 --> Input Class Initialized
INFO - 2018-06-25 05:34:49 --> Language Class Initialized
INFO - 2018-06-25 05:34:49 --> Loader Class Initialized
INFO - 2018-06-25 05:34:49 --> Helper loaded: url_helper
INFO - 2018-06-25 05:34:49 --> Helper loaded: form_helper
INFO - 2018-06-25 05:34:49 --> Helper loaded: language_helper
DEBUG - 2018-06-25 05:34:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 05:34:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 05:34:49 --> User Agent Class Initialized
INFO - 2018-06-25 05:34:49 --> Controller Class Initialized
INFO - 2018-06-25 05:34:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-25 05:34:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-25 05:34:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-25 05:34:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-25 05:34:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-25 05:34:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-25 05:34:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-06-25 05:34:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-25 05:34:49 --> Final output sent to browser
DEBUG - 2018-06-25 05:34:49 --> Total execution time: 0.0230
INFO - 2018-06-25 05:36:36 --> Config Class Initialized
INFO - 2018-06-25 05:36:36 --> Hooks Class Initialized
DEBUG - 2018-06-25 05:36:37 --> UTF-8 Support Enabled
INFO - 2018-06-25 05:36:37 --> Utf8 Class Initialized
INFO - 2018-06-25 05:36:37 --> URI Class Initialized
INFO - 2018-06-25 05:36:37 --> Router Class Initialized
INFO - 2018-06-25 05:36:37 --> Output Class Initialized
INFO - 2018-06-25 05:36:37 --> Security Class Initialized
DEBUG - 2018-06-25 05:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 05:36:37 --> CSRF cookie sent
INFO - 2018-06-25 05:36:37 --> Input Class Initialized
INFO - 2018-06-25 05:36:37 --> Language Class Initialized
INFO - 2018-06-25 05:36:37 --> Loader Class Initialized
INFO - 2018-06-25 05:36:37 --> Helper loaded: url_helper
INFO - 2018-06-25 05:36:37 --> Helper loaded: form_helper
INFO - 2018-06-25 05:36:37 --> Helper loaded: language_helper
DEBUG - 2018-06-25 05:36:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 05:36:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 05:36:37 --> User Agent Class Initialized
INFO - 2018-06-25 05:36:37 --> Controller Class Initialized
INFO - 2018-06-25 05:36:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-25 05:36:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-25 05:36:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-25 05:36:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-25 05:36:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-25 05:36:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-25 05:36:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-06-25 05:36:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-25 05:36:37 --> Final output sent to browser
DEBUG - 2018-06-25 05:36:37 --> Total execution time: 0.0220
INFO - 2018-06-25 10:54:47 --> Config Class Initialized
INFO - 2018-06-25 10:54:47 --> Hooks Class Initialized
DEBUG - 2018-06-25 10:54:47 --> UTF-8 Support Enabled
INFO - 2018-06-25 10:54:47 --> Utf8 Class Initialized
INFO - 2018-06-25 10:54:47 --> URI Class Initialized
INFO - 2018-06-25 10:54:47 --> Router Class Initialized
INFO - 2018-06-25 10:54:47 --> Output Class Initialized
INFO - 2018-06-25 10:54:47 --> Security Class Initialized
DEBUG - 2018-06-25 10:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 10:54:47 --> CSRF cookie sent
INFO - 2018-06-25 10:54:47 --> Input Class Initialized
INFO - 2018-06-25 10:54:47 --> Language Class Initialized
ERROR - 2018-06-25 10:54:47 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-06-25 10:54:50 --> Config Class Initialized
INFO - 2018-06-25 10:54:50 --> Hooks Class Initialized
DEBUG - 2018-06-25 10:54:50 --> UTF-8 Support Enabled
INFO - 2018-06-25 10:54:50 --> Utf8 Class Initialized
INFO - 2018-06-25 10:54:50 --> URI Class Initialized
INFO - 2018-06-25 10:54:50 --> Router Class Initialized
INFO - 2018-06-25 10:54:50 --> Output Class Initialized
INFO - 2018-06-25 10:54:50 --> Security Class Initialized
DEBUG - 2018-06-25 10:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 10:54:50 --> CSRF cookie sent
INFO - 2018-06-25 10:54:50 --> Input Class Initialized
INFO - 2018-06-25 10:54:50 --> Language Class Initialized
INFO - 2018-06-25 10:54:50 --> Loader Class Initialized
INFO - 2018-06-25 10:54:50 --> Helper loaded: url_helper
INFO - 2018-06-25 10:54:50 --> Helper loaded: form_helper
INFO - 2018-06-25 10:54:50 --> Helper loaded: language_helper
DEBUG - 2018-06-25 10:54:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 10:54:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 10:54:50 --> User Agent Class Initialized
INFO - 2018-06-25 10:54:50 --> Controller Class Initialized
INFO - 2018-06-25 10:54:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-25 10:54:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-25 10:54:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-25 10:54:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-25 10:54:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-25 10:54:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-25 10:54:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-06-25 10:54:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-25 10:54:50 --> Final output sent to browser
DEBUG - 2018-06-25 10:54:50 --> Total execution time: 0.0225
INFO - 2018-06-25 12:26:43 --> Config Class Initialized
INFO - 2018-06-25 12:26:43 --> Hooks Class Initialized
DEBUG - 2018-06-25 12:26:43 --> UTF-8 Support Enabled
INFO - 2018-06-25 12:26:43 --> Utf8 Class Initialized
INFO - 2018-06-25 12:26:43 --> URI Class Initialized
INFO - 2018-06-25 12:26:43 --> Router Class Initialized
INFO - 2018-06-25 12:26:43 --> Output Class Initialized
INFO - 2018-06-25 12:26:43 --> Security Class Initialized
DEBUG - 2018-06-25 12:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 12:26:43 --> CSRF cookie sent
INFO - 2018-06-25 12:26:43 --> Input Class Initialized
INFO - 2018-06-25 12:26:43 --> Language Class Initialized
INFO - 2018-06-25 12:26:43 --> Loader Class Initialized
INFO - 2018-06-25 12:26:43 --> Helper loaded: url_helper
INFO - 2018-06-25 12:26:43 --> Helper loaded: form_helper
INFO - 2018-06-25 12:26:43 --> Helper loaded: language_helper
DEBUG - 2018-06-25 12:26:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 12:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 12:26:43 --> User Agent Class Initialized
INFO - 2018-06-25 12:26:43 --> Controller Class Initialized
INFO - 2018-06-25 12:26:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-25 12:26:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-25 12:26:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-25 12:26:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-25 12:26:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-25 12:26:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-25 12:26:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-06-25 12:26:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-25 12:26:43 --> Final output sent to browser
DEBUG - 2018-06-25 12:26:43 --> Total execution time: 0.0227
INFO - 2018-06-25 15:13:33 --> Config Class Initialized
INFO - 2018-06-25 15:13:33 --> Hooks Class Initialized
DEBUG - 2018-06-25 15:13:33 --> UTF-8 Support Enabled
INFO - 2018-06-25 15:13:33 --> Utf8 Class Initialized
INFO - 2018-06-25 15:13:33 --> URI Class Initialized
INFO - 2018-06-25 15:13:33 --> Router Class Initialized
INFO - 2018-06-25 15:13:33 --> Output Class Initialized
INFO - 2018-06-25 15:13:33 --> Security Class Initialized
DEBUG - 2018-06-25 15:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 15:13:33 --> CSRF cookie sent
INFO - 2018-06-25 15:13:33 --> Input Class Initialized
INFO - 2018-06-25 15:13:33 --> Language Class Initialized
ERROR - 2018-06-25 15:13:33 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-06-25 15:13:36 --> Config Class Initialized
INFO - 2018-06-25 15:13:36 --> Hooks Class Initialized
DEBUG - 2018-06-25 15:13:36 --> UTF-8 Support Enabled
INFO - 2018-06-25 15:13:36 --> Utf8 Class Initialized
INFO - 2018-06-25 15:13:36 --> URI Class Initialized
INFO - 2018-06-25 15:13:36 --> Router Class Initialized
INFO - 2018-06-25 15:13:36 --> Output Class Initialized
INFO - 2018-06-25 15:13:36 --> Security Class Initialized
DEBUG - 2018-06-25 15:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 15:13:36 --> CSRF cookie sent
INFO - 2018-06-25 15:13:36 --> Input Class Initialized
INFO - 2018-06-25 15:13:36 --> Language Class Initialized
INFO - 2018-06-25 15:13:36 --> Loader Class Initialized
INFO - 2018-06-25 15:13:36 --> Helper loaded: url_helper
INFO - 2018-06-25 15:13:36 --> Helper loaded: form_helper
INFO - 2018-06-25 15:13:36 --> Helper loaded: language_helper
DEBUG - 2018-06-25 15:13:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 15:13:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 15:13:36 --> User Agent Class Initialized
INFO - 2018-06-25 15:13:36 --> Controller Class Initialized
INFO - 2018-06-25 15:13:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-25 15:13:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-25 15:13:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-25 15:13:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-25 15:13:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-25 15:13:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-25 15:13:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-06-25 15:13:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-25 15:13:36 --> Final output sent to browser
DEBUG - 2018-06-25 15:13:36 --> Total execution time: 0.0322
INFO - 2018-06-25 16:16:18 --> Config Class Initialized
INFO - 2018-06-25 16:16:18 --> Hooks Class Initialized
DEBUG - 2018-06-25 16:16:18 --> UTF-8 Support Enabled
INFO - 2018-06-25 16:16:18 --> Utf8 Class Initialized
INFO - 2018-06-25 16:16:18 --> URI Class Initialized
DEBUG - 2018-06-25 16:16:18 --> No URI present. Default controller set.
INFO - 2018-06-25 16:16:18 --> Router Class Initialized
INFO - 2018-06-25 16:16:18 --> Output Class Initialized
INFO - 2018-06-25 16:16:18 --> Security Class Initialized
DEBUG - 2018-06-25 16:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 16:16:18 --> CSRF cookie sent
INFO - 2018-06-25 16:16:18 --> Input Class Initialized
INFO - 2018-06-25 16:16:18 --> Language Class Initialized
INFO - 2018-06-25 16:16:18 --> Loader Class Initialized
INFO - 2018-06-25 16:16:18 --> Helper loaded: url_helper
INFO - 2018-06-25 16:16:18 --> Helper loaded: form_helper
INFO - 2018-06-25 16:16:18 --> Helper loaded: language_helper
DEBUG - 2018-06-25 16:16:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 16:16:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 16:16:18 --> User Agent Class Initialized
INFO - 2018-06-25 16:16:18 --> Controller Class Initialized
INFO - 2018-06-25 16:16:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-25 16:16:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-25 16:16:18 --> Pixel_Model class loaded
INFO - 2018-06-25 16:16:18 --> Database Driver Class Initialized
INFO - 2018-06-25 16:16:18 --> Model "QuestionsModel" initialized
INFO - 2018-06-25 16:16:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-25 16:16:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-25 16:16:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-25 16:16:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-25 16:16:18 --> Final output sent to browser
DEBUG - 2018-06-25 16:16:18 --> Total execution time: 0.0350
INFO - 2018-06-25 16:28:06 --> Config Class Initialized
INFO - 2018-06-25 16:28:06 --> Hooks Class Initialized
DEBUG - 2018-06-25 16:28:06 --> UTF-8 Support Enabled
INFO - 2018-06-25 16:28:06 --> Utf8 Class Initialized
INFO - 2018-06-25 16:28:06 --> URI Class Initialized
INFO - 2018-06-25 16:28:06 --> Router Class Initialized
INFO - 2018-06-25 16:28:06 --> Output Class Initialized
INFO - 2018-06-25 16:28:06 --> Security Class Initialized
DEBUG - 2018-06-25 16:28:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 16:28:06 --> CSRF cookie sent
INFO - 2018-06-25 16:28:06 --> Input Class Initialized
INFO - 2018-06-25 16:28:06 --> Language Class Initialized
INFO - 2018-06-25 16:28:06 --> Loader Class Initialized
INFO - 2018-06-25 16:28:06 --> Helper loaded: url_helper
INFO - 2018-06-25 16:28:06 --> Helper loaded: form_helper
INFO - 2018-06-25 16:28:06 --> Helper loaded: language_helper
DEBUG - 2018-06-25 16:28:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 16:28:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 16:28:06 --> User Agent Class Initialized
INFO - 2018-06-25 16:28:06 --> Controller Class Initialized
INFO - 2018-06-25 16:28:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-25 16:28:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-25 16:28:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-25 16:28:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-25 16:28:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-25 16:28:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-25 16:28:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/executive.php
INFO - 2018-06-25 16:28:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-25 16:28:06 --> Final output sent to browser
DEBUG - 2018-06-25 16:28:06 --> Total execution time: 0.0232
INFO - 2018-06-25 17:11:03 --> Config Class Initialized
INFO - 2018-06-25 17:11:03 --> Hooks Class Initialized
DEBUG - 2018-06-25 17:11:03 --> UTF-8 Support Enabled
INFO - 2018-06-25 17:11:03 --> Utf8 Class Initialized
INFO - 2018-06-25 17:11:03 --> URI Class Initialized
DEBUG - 2018-06-25 17:11:03 --> No URI present. Default controller set.
INFO - 2018-06-25 17:11:03 --> Router Class Initialized
INFO - 2018-06-25 17:11:03 --> Output Class Initialized
INFO - 2018-06-25 17:11:03 --> Security Class Initialized
DEBUG - 2018-06-25 17:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 17:11:03 --> CSRF cookie sent
INFO - 2018-06-25 17:11:03 --> Input Class Initialized
INFO - 2018-06-25 17:11:03 --> Language Class Initialized
INFO - 2018-06-25 17:11:03 --> Loader Class Initialized
INFO - 2018-06-25 17:11:03 --> Helper loaded: url_helper
INFO - 2018-06-25 17:11:03 --> Helper loaded: form_helper
INFO - 2018-06-25 17:11:03 --> Helper loaded: language_helper
DEBUG - 2018-06-25 17:11:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 17:11:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 17:11:03 --> User Agent Class Initialized
INFO - 2018-06-25 17:11:03 --> Controller Class Initialized
INFO - 2018-06-25 17:11:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-25 17:11:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-25 17:11:03 --> Pixel_Model class loaded
INFO - 2018-06-25 17:11:03 --> Database Driver Class Initialized
INFO - 2018-06-25 17:11:03 --> Model "QuestionsModel" initialized
INFO - 2018-06-25 17:11:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-25 17:11:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-25 17:11:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-25 17:11:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-25 17:11:03 --> Final output sent to browser
DEBUG - 2018-06-25 17:11:03 --> Total execution time: 0.0367
INFO - 2018-06-25 17:25:29 --> Config Class Initialized
INFO - 2018-06-25 17:25:29 --> Hooks Class Initialized
DEBUG - 2018-06-25 17:25:29 --> UTF-8 Support Enabled
INFO - 2018-06-25 17:25:29 --> Utf8 Class Initialized
INFO - 2018-06-25 17:25:29 --> URI Class Initialized
DEBUG - 2018-06-25 17:25:29 --> No URI present. Default controller set.
INFO - 2018-06-25 17:25:29 --> Router Class Initialized
INFO - 2018-06-25 17:25:29 --> Output Class Initialized
INFO - 2018-06-25 17:25:29 --> Security Class Initialized
DEBUG - 2018-06-25 17:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 17:25:29 --> CSRF cookie sent
INFO - 2018-06-25 17:25:29 --> Input Class Initialized
INFO - 2018-06-25 17:25:29 --> Language Class Initialized
INFO - 2018-06-25 17:25:29 --> Loader Class Initialized
INFO - 2018-06-25 17:25:29 --> Helper loaded: url_helper
INFO - 2018-06-25 17:25:29 --> Helper loaded: form_helper
INFO - 2018-06-25 17:25:29 --> Helper loaded: language_helper
DEBUG - 2018-06-25 17:25:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 17:25:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 17:25:29 --> User Agent Class Initialized
INFO - 2018-06-25 17:25:29 --> Controller Class Initialized
INFO - 2018-06-25 17:25:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-25 17:25:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-25 17:25:29 --> Pixel_Model class loaded
INFO - 2018-06-25 17:25:29 --> Database Driver Class Initialized
INFO - 2018-06-25 17:25:29 --> Model "QuestionsModel" initialized
INFO - 2018-06-25 17:25:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-25 17:25:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-25 17:25:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-25 17:25:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-25 17:25:29 --> Final output sent to browser
DEBUG - 2018-06-25 17:25:29 --> Total execution time: 0.0317
INFO - 2018-06-25 17:25:29 --> Config Class Initialized
INFO - 2018-06-25 17:25:29 --> Hooks Class Initialized
DEBUG - 2018-06-25 17:25:29 --> UTF-8 Support Enabled
INFO - 2018-06-25 17:25:29 --> Utf8 Class Initialized
INFO - 2018-06-25 17:25:29 --> URI Class Initialized
DEBUG - 2018-06-25 17:25:29 --> No URI present. Default controller set.
INFO - 2018-06-25 17:25:29 --> Router Class Initialized
INFO - 2018-06-25 17:25:29 --> Output Class Initialized
INFO - 2018-06-25 17:25:29 --> Security Class Initialized
DEBUG - 2018-06-25 17:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 17:25:29 --> CSRF cookie sent
INFO - 2018-06-25 17:25:29 --> Input Class Initialized
INFO - 2018-06-25 17:25:29 --> Language Class Initialized
INFO - 2018-06-25 17:25:29 --> Loader Class Initialized
INFO - 2018-06-25 17:25:29 --> Helper loaded: url_helper
INFO - 2018-06-25 17:25:29 --> Helper loaded: form_helper
INFO - 2018-06-25 17:25:29 --> Helper loaded: language_helper
DEBUG - 2018-06-25 17:25:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 17:25:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 17:25:29 --> User Agent Class Initialized
INFO - 2018-06-25 17:25:29 --> Controller Class Initialized
INFO - 2018-06-25 17:25:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-25 17:25:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-25 17:25:29 --> Pixel_Model class loaded
INFO - 2018-06-25 17:25:29 --> Database Driver Class Initialized
INFO - 2018-06-25 17:25:29 --> Model "QuestionsModel" initialized
INFO - 2018-06-25 17:25:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-25 17:25:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-25 17:25:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-25 17:25:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-25 17:25:29 --> Final output sent to browser
DEBUG - 2018-06-25 17:25:29 --> Total execution time: 0.0321
INFO - 2018-06-25 17:25:30 --> Config Class Initialized
INFO - 2018-06-25 17:25:30 --> Hooks Class Initialized
DEBUG - 2018-06-25 17:25:30 --> UTF-8 Support Enabled
INFO - 2018-06-25 17:25:30 --> Utf8 Class Initialized
INFO - 2018-06-25 17:25:30 --> URI Class Initialized
DEBUG - 2018-06-25 17:25:30 --> No URI present. Default controller set.
INFO - 2018-06-25 17:25:30 --> Router Class Initialized
INFO - 2018-06-25 17:25:30 --> Output Class Initialized
INFO - 2018-06-25 17:25:30 --> Security Class Initialized
DEBUG - 2018-06-25 17:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 17:25:30 --> CSRF cookie sent
INFO - 2018-06-25 17:25:30 --> Input Class Initialized
INFO - 2018-06-25 17:25:30 --> Language Class Initialized
INFO - 2018-06-25 17:25:30 --> Loader Class Initialized
INFO - 2018-06-25 17:25:30 --> Helper loaded: url_helper
INFO - 2018-06-25 17:25:30 --> Helper loaded: form_helper
INFO - 2018-06-25 17:25:30 --> Helper loaded: language_helper
DEBUG - 2018-06-25 17:25:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 17:25:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 17:25:30 --> User Agent Class Initialized
INFO - 2018-06-25 17:25:30 --> Controller Class Initialized
INFO - 2018-06-25 17:25:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-25 17:25:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-25 17:25:30 --> Pixel_Model class loaded
INFO - 2018-06-25 17:25:30 --> Database Driver Class Initialized
INFO - 2018-06-25 17:25:30 --> Model "QuestionsModel" initialized
INFO - 2018-06-25 17:25:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-25 17:25:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-25 17:25:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-25 17:25:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-25 17:25:30 --> Final output sent to browser
DEBUG - 2018-06-25 17:25:30 --> Total execution time: 0.0304
INFO - 2018-06-25 17:25:31 --> Config Class Initialized
INFO - 2018-06-25 17:25:31 --> Hooks Class Initialized
DEBUG - 2018-06-25 17:25:31 --> UTF-8 Support Enabled
INFO - 2018-06-25 17:25:31 --> Utf8 Class Initialized
INFO - 2018-06-25 17:25:31 --> URI Class Initialized
INFO - 2018-06-25 17:25:31 --> Router Class Initialized
INFO - 2018-06-25 17:25:31 --> Output Class Initialized
INFO - 2018-06-25 17:25:31 --> Security Class Initialized
DEBUG - 2018-06-25 17:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 17:25:31 --> CSRF cookie sent
INFO - 2018-06-25 17:25:31 --> Input Class Initialized
INFO - 2018-06-25 17:25:31 --> Language Class Initialized
ERROR - 2018-06-25 17:25:31 --> 404 Page Not Found: 405shtml/index
INFO - 2018-06-25 17:25:37 --> Config Class Initialized
INFO - 2018-06-25 17:25:37 --> Hooks Class Initialized
DEBUG - 2018-06-25 17:25:37 --> UTF-8 Support Enabled
INFO - 2018-06-25 17:25:37 --> Utf8 Class Initialized
INFO - 2018-06-25 17:25:37 --> URI Class Initialized
DEBUG - 2018-06-25 17:25:37 --> No URI present. Default controller set.
INFO - 2018-06-25 17:25:37 --> Router Class Initialized
INFO - 2018-06-25 17:25:37 --> Output Class Initialized
INFO - 2018-06-25 17:25:37 --> Security Class Initialized
DEBUG - 2018-06-25 17:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 17:25:37 --> CSRF cookie sent
INFO - 2018-06-25 17:25:37 --> Input Class Initialized
INFO - 2018-06-25 17:25:37 --> Language Class Initialized
INFO - 2018-06-25 17:25:37 --> Loader Class Initialized
INFO - 2018-06-25 17:25:37 --> Helper loaded: url_helper
INFO - 2018-06-25 17:25:37 --> Helper loaded: form_helper
INFO - 2018-06-25 17:25:37 --> Helper loaded: language_helper
DEBUG - 2018-06-25 17:25:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 17:25:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 17:25:37 --> User Agent Class Initialized
INFO - 2018-06-25 17:25:37 --> Controller Class Initialized
INFO - 2018-06-25 17:25:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-25 17:25:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-25 17:25:37 --> Pixel_Model class loaded
INFO - 2018-06-25 17:25:37 --> Database Driver Class Initialized
INFO - 2018-06-25 17:25:37 --> Model "QuestionsModel" initialized
INFO - 2018-06-25 17:25:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-25 17:25:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-25 17:25:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-25 17:25:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-25 17:25:37 --> Final output sent to browser
DEBUG - 2018-06-25 17:25:37 --> Total execution time: 0.0307
INFO - 2018-06-25 17:25:38 --> Config Class Initialized
INFO - 2018-06-25 17:25:38 --> Hooks Class Initialized
DEBUG - 2018-06-25 17:25:38 --> UTF-8 Support Enabled
INFO - 2018-06-25 17:25:38 --> Utf8 Class Initialized
INFO - 2018-06-25 17:25:38 --> URI Class Initialized
INFO - 2018-06-25 17:25:38 --> Router Class Initialized
INFO - 2018-06-25 17:25:38 --> Output Class Initialized
INFO - 2018-06-25 17:25:38 --> Security Class Initialized
DEBUG - 2018-06-25 17:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 17:25:38 --> CSRF cookie sent
INFO - 2018-06-25 17:25:38 --> Input Class Initialized
INFO - 2018-06-25 17:25:38 --> Language Class Initialized
ERROR - 2018-06-25 17:25:38 --> 404 Page Not Found: 404testpage4525d2fdc/index
INFO - 2018-06-25 17:25:38 --> Config Class Initialized
INFO - 2018-06-25 17:25:38 --> Hooks Class Initialized
DEBUG - 2018-06-25 17:25:38 --> UTF-8 Support Enabled
INFO - 2018-06-25 17:25:38 --> Utf8 Class Initialized
INFO - 2018-06-25 17:25:38 --> URI Class Initialized
INFO - 2018-06-25 17:25:38 --> Router Class Initialized
INFO - 2018-06-25 17:25:38 --> Output Class Initialized
INFO - 2018-06-25 17:25:38 --> Security Class Initialized
DEBUG - 2018-06-25 17:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 17:25:38 --> CSRF cookie sent
INFO - 2018-06-25 17:25:38 --> Input Class Initialized
INFO - 2018-06-25 17:25:38 --> Language Class Initialized
ERROR - 2018-06-25 17:25:38 --> 404 Page Not Found: 404javascriptjs/index
INFO - 2018-06-25 17:25:38 --> Config Class Initialized
INFO - 2018-06-25 17:25:38 --> Hooks Class Initialized
DEBUG - 2018-06-25 17:25:38 --> UTF-8 Support Enabled
INFO - 2018-06-25 17:25:38 --> Utf8 Class Initialized
INFO - 2018-06-25 17:25:38 --> URI Class Initialized
INFO - 2018-06-25 17:25:38 --> Router Class Initialized
INFO - 2018-06-25 17:25:38 --> Output Class Initialized
INFO - 2018-06-25 17:25:38 --> Security Class Initialized
DEBUG - 2018-06-25 17:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 17:25:38 --> CSRF cookie sent
INFO - 2018-06-25 17:25:38 --> Input Class Initialized
INFO - 2018-06-25 17:25:38 --> Language Class Initialized
INFO - 2018-06-25 17:25:38 --> Loader Class Initialized
INFO - 2018-06-25 17:25:38 --> Helper loaded: url_helper
INFO - 2018-06-25 17:25:38 --> Helper loaded: form_helper
INFO - 2018-06-25 17:25:38 --> Helper loaded: language_helper
DEBUG - 2018-06-25 17:25:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 17:25:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 17:25:38 --> User Agent Class Initialized
INFO - 2018-06-25 17:25:38 --> Controller Class Initialized
INFO - 2018-06-25 17:25:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-25 17:25:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-25 17:25:38 --> Pixel_Model class loaded
INFO - 2018-06-25 17:25:38 --> Database Driver Class Initialized
INFO - 2018-06-25 17:25:38 --> Model "QuestionsModel" initialized
ERROR - 2018-06-25 17:25:38 --> Severity: Notice --> Undefined index: HTTP_REFERER /home/fxp6bn7rqemh/public_html/application/core/Pixel_Controller.php 87
INFO - 2018-06-25 17:25:38 --> Config Class Initialized
INFO - 2018-06-25 17:25:38 --> Hooks Class Initialized
DEBUG - 2018-06-25 17:25:38 --> UTF-8 Support Enabled
INFO - 2018-06-25 17:25:38 --> Utf8 Class Initialized
INFO - 2018-06-25 17:25:38 --> URI Class Initialized
INFO - 2018-06-25 17:25:38 --> Router Class Initialized
INFO - 2018-06-25 17:25:38 --> Output Class Initialized
INFO - 2018-06-25 17:25:38 --> Security Class Initialized
DEBUG - 2018-06-25 17:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 17:25:38 --> CSRF cookie sent
INFO - 2018-06-25 17:25:38 --> Input Class Initialized
INFO - 2018-06-25 17:25:38 --> Language Class Initialized
INFO - 2018-06-25 17:25:38 --> Loader Class Initialized
INFO - 2018-06-25 17:25:38 --> Helper loaded: url_helper
INFO - 2018-06-25 17:25:38 --> Helper loaded: form_helper
INFO - 2018-06-25 17:25:38 --> Helper loaded: language_helper
DEBUG - 2018-06-25 17:25:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 17:25:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 17:25:38 --> User Agent Class Initialized
INFO - 2018-06-25 17:25:38 --> Controller Class Initialized
INFO - 2018-06-25 17:25:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-25 17:25:38 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-25 17:25:38 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-25 17:25:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-25 17:25:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-25 17:25:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-25 17:25:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-25 17:25:38 --> Could not find the language line "req_email"
INFO - 2018-06-25 17:25:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-06-25 17:25:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-25 17:25:38 --> Final output sent to browser
DEBUG - 2018-06-25 17:25:38 --> Total execution time: 0.0231
INFO - 2018-06-25 17:25:39 --> Config Class Initialized
INFO - 2018-06-25 17:25:39 --> Hooks Class Initialized
DEBUG - 2018-06-25 17:25:39 --> UTF-8 Support Enabled
INFO - 2018-06-25 17:25:39 --> Utf8 Class Initialized
INFO - 2018-06-25 17:25:39 --> URI Class Initialized
INFO - 2018-06-25 17:25:39 --> Router Class Initialized
INFO - 2018-06-25 17:25:39 --> Output Class Initialized
INFO - 2018-06-25 17:25:39 --> Security Class Initialized
DEBUG - 2018-06-25 17:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 17:25:39 --> CSRF cookie sent
INFO - 2018-06-25 17:25:39 --> Input Class Initialized
INFO - 2018-06-25 17:25:39 --> Language Class Initialized
INFO - 2018-06-25 17:25:39 --> Loader Class Initialized
INFO - 2018-06-25 17:25:39 --> Helper loaded: url_helper
INFO - 2018-06-25 17:25:39 --> Helper loaded: form_helper
INFO - 2018-06-25 17:25:39 --> Helper loaded: language_helper
DEBUG - 2018-06-25 17:25:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 17:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 17:25:39 --> User Agent Class Initialized
INFO - 2018-06-25 17:25:39 --> Controller Class Initialized
INFO - 2018-06-25 17:25:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-25 17:25:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-25 17:25:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-25 17:25:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-25 17:25:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-25 17:25:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-25 17:25:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-06-25 17:25:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-25 17:25:39 --> Final output sent to browser
DEBUG - 2018-06-25 17:25:39 --> Total execution time: 0.0227
INFO - 2018-06-25 17:25:39 --> Config Class Initialized
INFO - 2018-06-25 17:25:39 --> Hooks Class Initialized
DEBUG - 2018-06-25 17:25:39 --> UTF-8 Support Enabled
INFO - 2018-06-25 17:25:39 --> Utf8 Class Initialized
INFO - 2018-06-25 17:25:39 --> URI Class Initialized
INFO - 2018-06-25 17:25:39 --> Router Class Initialized
INFO - 2018-06-25 17:25:39 --> Output Class Initialized
INFO - 2018-06-25 17:25:39 --> Security Class Initialized
DEBUG - 2018-06-25 17:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 17:25:39 --> CSRF cookie sent
INFO - 2018-06-25 17:25:39 --> Input Class Initialized
INFO - 2018-06-25 17:25:39 --> Language Class Initialized
INFO - 2018-06-25 17:25:39 --> Loader Class Initialized
INFO - 2018-06-25 17:25:39 --> Helper loaded: url_helper
INFO - 2018-06-25 17:25:39 --> Helper loaded: form_helper
INFO - 2018-06-25 17:25:39 --> Helper loaded: language_helper
DEBUG - 2018-06-25 17:25:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 17:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 17:25:39 --> User Agent Class Initialized
INFO - 2018-06-25 17:25:39 --> Controller Class Initialized
INFO - 2018-06-25 17:25:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-25 17:25:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-25 17:25:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-25 17:25:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-25 17:25:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-25 17:25:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-25 17:25:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-06-25 17:25:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-25 17:25:39 --> Final output sent to browser
DEBUG - 2018-06-25 17:25:39 --> Total execution time: 0.0217
INFO - 2018-06-25 17:25:39 --> Config Class Initialized
INFO - 2018-06-25 17:25:39 --> Hooks Class Initialized
DEBUG - 2018-06-25 17:25:39 --> UTF-8 Support Enabled
INFO - 2018-06-25 17:25:39 --> Utf8 Class Initialized
INFO - 2018-06-25 17:25:39 --> URI Class Initialized
INFO - 2018-06-25 17:25:39 --> Router Class Initialized
INFO - 2018-06-25 17:25:39 --> Output Class Initialized
INFO - 2018-06-25 17:25:39 --> Security Class Initialized
DEBUG - 2018-06-25 17:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 17:25:39 --> CSRF cookie sent
INFO - 2018-06-25 17:25:39 --> Input Class Initialized
INFO - 2018-06-25 17:25:39 --> Language Class Initialized
INFO - 2018-06-25 17:25:39 --> Loader Class Initialized
INFO - 2018-06-25 17:25:39 --> Helper loaded: url_helper
INFO - 2018-06-25 17:25:39 --> Helper loaded: form_helper
INFO - 2018-06-25 17:25:39 --> Helper loaded: language_helper
DEBUG - 2018-06-25 17:25:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 17:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 17:25:39 --> User Agent Class Initialized
INFO - 2018-06-25 17:25:39 --> Controller Class Initialized
INFO - 2018-06-25 17:25:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-25 17:25:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-25 17:25:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-25 17:25:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-25 17:25:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-25 17:25:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-25 17:25:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-06-25 17:25:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-25 17:25:39 --> Final output sent to browser
DEBUG - 2018-06-25 17:25:39 --> Total execution time: 0.0194
INFO - 2018-06-25 17:25:40 --> Config Class Initialized
INFO - 2018-06-25 17:25:40 --> Hooks Class Initialized
DEBUG - 2018-06-25 17:25:40 --> UTF-8 Support Enabled
INFO - 2018-06-25 17:25:40 --> Utf8 Class Initialized
INFO - 2018-06-25 17:25:40 --> URI Class Initialized
INFO - 2018-06-25 17:25:40 --> Router Class Initialized
INFO - 2018-06-25 17:25:40 --> Output Class Initialized
INFO - 2018-06-25 17:25:40 --> Security Class Initialized
DEBUG - 2018-06-25 17:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 17:25:40 --> CSRF cookie sent
INFO - 2018-06-25 17:25:40 --> Input Class Initialized
INFO - 2018-06-25 17:25:40 --> Language Class Initialized
INFO - 2018-06-25 17:25:40 --> Loader Class Initialized
INFO - 2018-06-25 17:25:40 --> Helper loaded: url_helper
INFO - 2018-06-25 17:25:40 --> Helper loaded: form_helper
INFO - 2018-06-25 17:25:40 --> Helper loaded: language_helper
DEBUG - 2018-06-25 17:25:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 17:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 17:25:40 --> User Agent Class Initialized
INFO - 2018-06-25 17:25:40 --> Controller Class Initialized
INFO - 2018-06-25 17:25:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-25 17:25:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-25 17:25:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-25 17:25:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-25 17:25:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-25 17:25:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-25 17:25:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-06-25 17:25:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-25 17:25:40 --> Final output sent to browser
DEBUG - 2018-06-25 17:25:40 --> Total execution time: 0.0239
INFO - 2018-06-25 17:25:40 --> Config Class Initialized
INFO - 2018-06-25 17:25:40 --> Hooks Class Initialized
DEBUG - 2018-06-25 17:25:40 --> UTF-8 Support Enabled
INFO - 2018-06-25 17:25:40 --> Utf8 Class Initialized
INFO - 2018-06-25 17:25:40 --> URI Class Initialized
INFO - 2018-06-25 17:25:40 --> Router Class Initialized
INFO - 2018-06-25 17:25:40 --> Output Class Initialized
INFO - 2018-06-25 17:25:40 --> Security Class Initialized
DEBUG - 2018-06-25 17:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 17:25:40 --> CSRF cookie sent
INFO - 2018-06-25 17:25:40 --> Input Class Initialized
INFO - 2018-06-25 17:25:40 --> Language Class Initialized
INFO - 2018-06-25 17:25:40 --> Loader Class Initialized
INFO - 2018-06-25 17:25:40 --> Helper loaded: url_helper
INFO - 2018-06-25 17:25:40 --> Helper loaded: form_helper
INFO - 2018-06-25 17:25:40 --> Helper loaded: language_helper
DEBUG - 2018-06-25 17:25:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 17:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 17:25:40 --> User Agent Class Initialized
INFO - 2018-06-25 17:25:40 --> Controller Class Initialized
INFO - 2018-06-25 17:25:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-25 17:25:40 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-25 17:25:40 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-25 17:25:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-25 17:25:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-25 17:25:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-25 17:25:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-25 17:25:40 --> Could not find the language line "req_email"
INFO - 2018-06-25 17:25:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-06-25 17:25:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-25 17:25:40 --> Final output sent to browser
DEBUG - 2018-06-25 17:25:40 --> Total execution time: 0.0233
INFO - 2018-06-25 17:25:40 --> Config Class Initialized
INFO - 2018-06-25 17:25:40 --> Hooks Class Initialized
DEBUG - 2018-06-25 17:25:40 --> UTF-8 Support Enabled
INFO - 2018-06-25 17:25:40 --> Utf8 Class Initialized
INFO - 2018-06-25 17:25:40 --> URI Class Initialized
INFO - 2018-06-25 17:25:40 --> Router Class Initialized
INFO - 2018-06-25 17:25:40 --> Output Class Initialized
INFO - 2018-06-25 17:25:40 --> Security Class Initialized
DEBUG - 2018-06-25 17:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 17:25:40 --> CSRF cookie sent
INFO - 2018-06-25 17:25:40 --> Input Class Initialized
INFO - 2018-06-25 17:25:40 --> Language Class Initialized
INFO - 2018-06-25 17:25:40 --> Loader Class Initialized
INFO - 2018-06-25 17:25:40 --> Helper loaded: url_helper
INFO - 2018-06-25 17:25:40 --> Helper loaded: form_helper
INFO - 2018-06-25 17:25:40 --> Helper loaded: language_helper
DEBUG - 2018-06-25 17:25:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 17:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 17:25:40 --> User Agent Class Initialized
INFO - 2018-06-25 17:25:40 --> Controller Class Initialized
INFO - 2018-06-25 17:25:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-25 17:25:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-25 17:25:40 --> Pixel_Model class loaded
INFO - 2018-06-25 17:25:40 --> Database Driver Class Initialized
INFO - 2018-06-25 17:25:40 --> Model "QuestionsModel" initialized
INFO - 2018-06-25 17:25:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-25 17:25:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-25 17:25:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-25 17:25:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-25 17:25:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/buy_gift.php
INFO - 2018-06-25 17:25:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-25 17:25:40 --> Final output sent to browser
DEBUG - 2018-06-25 17:25:40 --> Total execution time: 0.0438
INFO - 2018-06-25 17:44:07 --> Config Class Initialized
INFO - 2018-06-25 17:44:07 --> Hooks Class Initialized
DEBUG - 2018-06-25 17:44:07 --> UTF-8 Support Enabled
INFO - 2018-06-25 17:44:07 --> Utf8 Class Initialized
INFO - 2018-06-25 17:44:07 --> URI Class Initialized
INFO - 2018-06-25 17:44:07 --> Router Class Initialized
INFO - 2018-06-25 17:44:07 --> Output Class Initialized
INFO - 2018-06-25 17:44:07 --> Security Class Initialized
DEBUG - 2018-06-25 17:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 17:44:07 --> CSRF cookie sent
INFO - 2018-06-25 17:44:07 --> Input Class Initialized
INFO - 2018-06-25 17:44:07 --> Language Class Initialized
INFO - 2018-06-25 17:44:07 --> Loader Class Initialized
INFO - 2018-06-25 17:44:07 --> Helper loaded: url_helper
INFO - 2018-06-25 17:44:07 --> Helper loaded: form_helper
INFO - 2018-06-25 17:44:07 --> Helper loaded: language_helper
DEBUG - 2018-06-25 17:44:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 17:44:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 17:44:07 --> User Agent Class Initialized
INFO - 2018-06-25 17:44:07 --> Controller Class Initialized
INFO - 2018-06-25 17:44:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-25 17:44:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-25 17:44:07 --> Pixel_Model class loaded
INFO - 2018-06-25 17:44:07 --> Database Driver Class Initialized
INFO - 2018-06-25 17:44:07 --> Model "QuestionsModel" initialized
INFO - 2018-06-25 17:44:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-25 17:44:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-25 17:44:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-25 17:44:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-25 17:44:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/buy_gift.php
INFO - 2018-06-25 17:44:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-25 17:44:07 --> Final output sent to browser
DEBUG - 2018-06-25 17:44:07 --> Total execution time: 0.0421
INFO - 2018-06-25 18:07:43 --> Config Class Initialized
INFO - 2018-06-25 18:07:43 --> Hooks Class Initialized
DEBUG - 2018-06-25 18:07:43 --> UTF-8 Support Enabled
INFO - 2018-06-25 18:07:43 --> Utf8 Class Initialized
INFO - 2018-06-25 18:07:43 --> URI Class Initialized
DEBUG - 2018-06-25 18:07:43 --> No URI present. Default controller set.
INFO - 2018-06-25 18:07:43 --> Router Class Initialized
INFO - 2018-06-25 18:07:43 --> Output Class Initialized
INFO - 2018-06-25 18:07:43 --> Security Class Initialized
DEBUG - 2018-06-25 18:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 18:07:43 --> CSRF cookie sent
INFO - 2018-06-25 18:07:43 --> Input Class Initialized
INFO - 2018-06-25 18:07:43 --> Language Class Initialized
INFO - 2018-06-25 18:07:43 --> Loader Class Initialized
INFO - 2018-06-25 18:07:43 --> Helper loaded: url_helper
INFO - 2018-06-25 18:07:43 --> Helper loaded: form_helper
INFO - 2018-06-25 18:07:43 --> Helper loaded: language_helper
DEBUG - 2018-06-25 18:07:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 18:07:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 18:07:43 --> User Agent Class Initialized
INFO - 2018-06-25 18:07:43 --> Controller Class Initialized
INFO - 2018-06-25 18:07:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-25 18:07:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-25 18:07:43 --> Pixel_Model class loaded
INFO - 2018-06-25 18:07:43 --> Database Driver Class Initialized
INFO - 2018-06-25 18:07:43 --> Model "QuestionsModel" initialized
INFO - 2018-06-25 18:07:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-25 18:07:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-25 18:07:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-25 18:07:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-25 18:07:43 --> Final output sent to browser
DEBUG - 2018-06-25 18:07:43 --> Total execution time: 0.0366
INFO - 2018-06-25 19:14:17 --> Config Class Initialized
INFO - 2018-06-25 19:14:17 --> Hooks Class Initialized
DEBUG - 2018-06-25 19:14:17 --> UTF-8 Support Enabled
INFO - 2018-06-25 19:14:17 --> Utf8 Class Initialized
INFO - 2018-06-25 19:14:17 --> URI Class Initialized
DEBUG - 2018-06-25 19:14:17 --> No URI present. Default controller set.
INFO - 2018-06-25 19:14:17 --> Router Class Initialized
INFO - 2018-06-25 19:14:17 --> Output Class Initialized
INFO - 2018-06-25 19:14:17 --> Security Class Initialized
DEBUG - 2018-06-25 19:14:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 19:14:17 --> CSRF cookie sent
INFO - 2018-06-25 19:14:17 --> Input Class Initialized
INFO - 2018-06-25 19:14:17 --> Language Class Initialized
INFO - 2018-06-25 19:14:17 --> Loader Class Initialized
INFO - 2018-06-25 19:14:17 --> Helper loaded: url_helper
INFO - 2018-06-25 19:14:17 --> Helper loaded: form_helper
INFO - 2018-06-25 19:14:17 --> Helper loaded: language_helper
DEBUG - 2018-06-25 19:14:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 19:14:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 19:14:17 --> User Agent Class Initialized
INFO - 2018-06-25 19:14:17 --> Controller Class Initialized
INFO - 2018-06-25 19:14:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-25 19:14:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-25 19:14:17 --> Pixel_Model class loaded
INFO - 2018-06-25 19:14:17 --> Database Driver Class Initialized
INFO - 2018-06-25 19:14:17 --> Model "QuestionsModel" initialized
INFO - 2018-06-25 19:14:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-25 19:14:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-25 19:14:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-25 19:14:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-25 19:14:17 --> Final output sent to browser
DEBUG - 2018-06-25 19:14:17 --> Total execution time: 0.0342
INFO - 2018-06-25 19:32:43 --> Config Class Initialized
INFO - 2018-06-25 19:32:43 --> Hooks Class Initialized
DEBUG - 2018-06-25 19:32:43 --> UTF-8 Support Enabled
INFO - 2018-06-25 19:32:43 --> Utf8 Class Initialized
INFO - 2018-06-25 19:32:43 --> URI Class Initialized
INFO - 2018-06-25 19:32:43 --> Router Class Initialized
INFO - 2018-06-25 19:32:43 --> Output Class Initialized
INFO - 2018-06-25 19:32:43 --> Security Class Initialized
DEBUG - 2018-06-25 19:32:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 19:32:43 --> CSRF cookie sent
INFO - 2018-06-25 19:32:43 --> Input Class Initialized
INFO - 2018-06-25 19:32:43 --> Language Class Initialized
ERROR - 2018-06-25 19:32:43 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-06-25 20:27:16 --> Config Class Initialized
INFO - 2018-06-25 20:27:16 --> Hooks Class Initialized
DEBUG - 2018-06-25 20:27:16 --> UTF-8 Support Enabled
INFO - 2018-06-25 20:27:16 --> Utf8 Class Initialized
INFO - 2018-06-25 20:27:16 --> URI Class Initialized
INFO - 2018-06-25 20:27:16 --> Router Class Initialized
INFO - 2018-06-25 20:27:16 --> Output Class Initialized
INFO - 2018-06-25 20:27:16 --> Security Class Initialized
DEBUG - 2018-06-25 20:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 20:27:16 --> CSRF cookie sent
INFO - 2018-06-25 20:27:16 --> Input Class Initialized
INFO - 2018-06-25 20:27:16 --> Language Class Initialized
INFO - 2018-06-25 20:27:16 --> Loader Class Initialized
INFO - 2018-06-25 20:27:16 --> Helper loaded: url_helper
INFO - 2018-06-25 20:27:16 --> Helper loaded: form_helper
INFO - 2018-06-25 20:27:16 --> Helper loaded: language_helper
DEBUG - 2018-06-25 20:27:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 20:27:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 20:27:16 --> User Agent Class Initialized
INFO - 2018-06-25 20:27:16 --> Controller Class Initialized
INFO - 2018-06-25 20:27:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-25 20:27:16 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-25 20:27:16 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-25 20:27:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-25 20:27:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-25 20:27:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-25 20:27:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-25 20:27:16 --> Could not find the language line "req_email"
INFO - 2018-06-25 20:27:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-06-25 20:27:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-25 20:27:16 --> Final output sent to browser
DEBUG - 2018-06-25 20:27:16 --> Total execution time: 0.0234
INFO - 2018-06-25 23:17:22 --> Config Class Initialized
INFO - 2018-06-25 23:17:22 --> Hooks Class Initialized
DEBUG - 2018-06-25 23:17:22 --> UTF-8 Support Enabled
INFO - 2018-06-25 23:17:22 --> Utf8 Class Initialized
INFO - 2018-06-25 23:17:22 --> URI Class Initialized
INFO - 2018-06-25 23:17:22 --> Router Class Initialized
INFO - 2018-06-25 23:17:22 --> Output Class Initialized
INFO - 2018-06-25 23:17:22 --> Security Class Initialized
DEBUG - 2018-06-25 23:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 23:17:22 --> CSRF cookie sent
INFO - 2018-06-25 23:17:22 --> Input Class Initialized
INFO - 2018-06-25 23:17:22 --> Language Class Initialized
ERROR - 2018-06-25 23:17:22 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-06-25 23:17:25 --> Config Class Initialized
INFO - 2018-06-25 23:17:25 --> Hooks Class Initialized
DEBUG - 2018-06-25 23:17:25 --> UTF-8 Support Enabled
INFO - 2018-06-25 23:17:25 --> Utf8 Class Initialized
INFO - 2018-06-25 23:17:25 --> URI Class Initialized
INFO - 2018-06-25 23:17:25 --> Router Class Initialized
INFO - 2018-06-25 23:17:25 --> Output Class Initialized
INFO - 2018-06-25 23:17:25 --> Security Class Initialized
DEBUG - 2018-06-25 23:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 23:17:25 --> CSRF cookie sent
INFO - 2018-06-25 23:17:25 --> Input Class Initialized
INFO - 2018-06-25 23:17:25 --> Language Class Initialized
INFO - 2018-06-25 23:17:25 --> Loader Class Initialized
INFO - 2018-06-25 23:17:25 --> Helper loaded: url_helper
INFO - 2018-06-25 23:17:25 --> Helper loaded: form_helper
INFO - 2018-06-25 23:17:25 --> Helper loaded: language_helper
DEBUG - 2018-06-25 23:17:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 23:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 23:17:25 --> User Agent Class Initialized
INFO - 2018-06-25 23:17:25 --> Controller Class Initialized
INFO - 2018-06-25 23:17:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-25 23:17:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-25 23:17:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-25 23:17:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-25 23:17:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-25 23:17:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-25 23:17:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/executive.php
INFO - 2018-06-25 23:17:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-25 23:17:25 --> Final output sent to browser
DEBUG - 2018-06-25 23:17:25 --> Total execution time: 0.0212

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-06-27 00:45:26 --> Config Class Initialized
INFO - 2018-06-27 00:45:26 --> Hooks Class Initialized
DEBUG - 2018-06-27 00:45:26 --> UTF-8 Support Enabled
INFO - 2018-06-27 00:45:26 --> Utf8 Class Initialized
INFO - 2018-06-27 00:45:26 --> URI Class Initialized
INFO - 2018-06-27 00:45:26 --> Router Class Initialized
INFO - 2018-06-27 00:45:26 --> Output Class Initialized
INFO - 2018-06-27 00:45:26 --> Security Class Initialized
DEBUG - 2018-06-27 00:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 00:45:26 --> CSRF cookie sent
INFO - 2018-06-27 00:45:26 --> Input Class Initialized
INFO - 2018-06-27 00:45:26 --> Language Class Initialized
ERROR - 2018-06-27 00:45:26 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-06-27 00:45:26 --> Config Class Initialized
INFO - 2018-06-27 00:45:26 --> Hooks Class Initialized
DEBUG - 2018-06-27 00:45:26 --> UTF-8 Support Enabled
INFO - 2018-06-27 00:45:26 --> Utf8 Class Initialized
INFO - 2018-06-27 00:45:26 --> URI Class Initialized
INFO - 2018-06-27 00:45:26 --> Router Class Initialized
INFO - 2018-06-27 00:45:26 --> Output Class Initialized
INFO - 2018-06-27 00:45:26 --> Security Class Initialized
DEBUG - 2018-06-27 00:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 00:45:26 --> CSRF cookie sent
INFO - 2018-06-27 00:45:26 --> Input Class Initialized
INFO - 2018-06-27 00:45:26 --> Language Class Initialized
INFO - 2018-06-27 00:45:26 --> Loader Class Initialized
INFO - 2018-06-27 00:45:26 --> Helper loaded: url_helper
INFO - 2018-06-27 00:45:26 --> Helper loaded: form_helper
INFO - 2018-06-27 00:45:26 --> Helper loaded: language_helper
DEBUG - 2018-06-27 00:45:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 00:45:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 00:45:26 --> User Agent Class Initialized
INFO - 2018-06-27 00:45:26 --> Controller Class Initialized
INFO - 2018-06-27 00:45:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-27 00:45:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-27 00:45:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-27 00:45:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-27 00:45:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-27 00:45:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-27 00:45:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-06-27 00:45:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-27 00:45:26 --> Final output sent to browser
DEBUG - 2018-06-27 00:45:26 --> Total execution time: 0.0215
INFO - 2018-06-27 00:50:02 --> Config Class Initialized
INFO - 2018-06-27 00:50:02 --> Hooks Class Initialized
DEBUG - 2018-06-27 00:50:02 --> UTF-8 Support Enabled
INFO - 2018-06-27 00:50:02 --> Utf8 Class Initialized
INFO - 2018-06-27 00:50:02 --> URI Class Initialized
INFO - 2018-06-27 00:50:02 --> Router Class Initialized
INFO - 2018-06-27 00:50:02 --> Output Class Initialized
INFO - 2018-06-27 00:50:02 --> Security Class Initialized
DEBUG - 2018-06-27 00:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 00:50:02 --> CSRF cookie sent
INFO - 2018-06-27 00:50:02 --> Input Class Initialized
INFO - 2018-06-27 00:50:02 --> Language Class Initialized
ERROR - 2018-06-27 00:50:02 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-06-27 00:50:02 --> Config Class Initialized
INFO - 2018-06-27 00:50:02 --> Hooks Class Initialized
DEBUG - 2018-06-27 00:50:02 --> UTF-8 Support Enabled
INFO - 2018-06-27 00:50:02 --> Utf8 Class Initialized
INFO - 2018-06-27 00:50:02 --> URI Class Initialized
INFO - 2018-06-27 00:50:02 --> Router Class Initialized
INFO - 2018-06-27 00:50:02 --> Output Class Initialized
INFO - 2018-06-27 00:50:02 --> Security Class Initialized
DEBUG - 2018-06-27 00:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 00:50:02 --> CSRF cookie sent
INFO - 2018-06-27 00:50:02 --> Input Class Initialized
INFO - 2018-06-27 00:50:02 --> Language Class Initialized
ERROR - 2018-06-27 00:50:02 --> 404 Page Not Found: Assets/js
INFO - 2018-06-27 05:00:12 --> Config Class Initialized
INFO - 2018-06-27 05:00:12 --> Hooks Class Initialized
DEBUG - 2018-06-27 05:00:12 --> UTF-8 Support Enabled
INFO - 2018-06-27 05:00:12 --> Utf8 Class Initialized
INFO - 2018-06-27 05:00:12 --> URI Class Initialized
INFO - 2018-06-27 05:00:12 --> Router Class Initialized
INFO - 2018-06-27 05:00:12 --> Output Class Initialized
INFO - 2018-06-27 05:00:12 --> Security Class Initialized
DEBUG - 2018-06-27 05:00:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 05:00:12 --> CSRF cookie sent
INFO - 2018-06-27 05:00:12 --> Input Class Initialized
INFO - 2018-06-27 05:00:12 --> Language Class Initialized
ERROR - 2018-06-27 05:00:12 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-06-27 08:14:48 --> Config Class Initialized
INFO - 2018-06-27 08:14:48 --> Hooks Class Initialized
DEBUG - 2018-06-27 08:14:48 --> UTF-8 Support Enabled
INFO - 2018-06-27 08:14:48 --> Utf8 Class Initialized
INFO - 2018-06-27 08:14:48 --> URI Class Initialized
INFO - 2018-06-27 08:14:48 --> Router Class Initialized
INFO - 2018-06-27 08:14:48 --> Output Class Initialized
INFO - 2018-06-27 08:14:48 --> Security Class Initialized
DEBUG - 2018-06-27 08:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 08:14:48 --> CSRF cookie sent
INFO - 2018-06-27 08:14:48 --> Input Class Initialized
INFO - 2018-06-27 08:14:48 --> Language Class Initialized
ERROR - 2018-06-27 08:14:48 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-06-27 08:14:52 --> Config Class Initialized
INFO - 2018-06-27 08:14:52 --> Hooks Class Initialized
DEBUG - 2018-06-27 08:14:52 --> UTF-8 Support Enabled
INFO - 2018-06-27 08:14:52 --> Utf8 Class Initialized
INFO - 2018-06-27 08:14:52 --> URI Class Initialized
DEBUG - 2018-06-27 08:14:52 --> No URI present. Default controller set.
INFO - 2018-06-27 08:14:52 --> Router Class Initialized
INFO - 2018-06-27 08:14:52 --> Output Class Initialized
INFO - 2018-06-27 08:14:52 --> Security Class Initialized
DEBUG - 2018-06-27 08:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 08:14:52 --> CSRF cookie sent
INFO - 2018-06-27 08:14:52 --> Input Class Initialized
INFO - 2018-06-27 08:14:52 --> Language Class Initialized
INFO - 2018-06-27 08:14:52 --> Loader Class Initialized
INFO - 2018-06-27 08:14:52 --> Helper loaded: url_helper
INFO - 2018-06-27 08:14:52 --> Helper loaded: form_helper
INFO - 2018-06-27 08:14:52 --> Helper loaded: language_helper
DEBUG - 2018-06-27 08:14:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 08:14:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 08:14:52 --> User Agent Class Initialized
INFO - 2018-06-27 08:14:52 --> Controller Class Initialized
INFO - 2018-06-27 08:14:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-27 08:14:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-27 08:14:52 --> Pixel_Model class loaded
INFO - 2018-06-27 08:14:52 --> Database Driver Class Initialized
INFO - 2018-06-27 08:14:52 --> Model "QuestionsModel" initialized
INFO - 2018-06-27 08:14:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-27 08:14:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-27 08:14:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-27 08:14:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-27 08:14:52 --> Final output sent to browser
DEBUG - 2018-06-27 08:14:52 --> Total execution time: 0.0426
INFO - 2018-06-27 10:08:59 --> Config Class Initialized
INFO - 2018-06-27 10:08:59 --> Hooks Class Initialized
DEBUG - 2018-06-27 10:08:59 --> UTF-8 Support Enabled
INFO - 2018-06-27 10:08:59 --> Utf8 Class Initialized
INFO - 2018-06-27 10:08:59 --> URI Class Initialized
DEBUG - 2018-06-27 10:08:59 --> No URI present. Default controller set.
INFO - 2018-06-27 10:08:59 --> Router Class Initialized
INFO - 2018-06-27 10:08:59 --> Output Class Initialized
INFO - 2018-06-27 10:08:59 --> Security Class Initialized
DEBUG - 2018-06-27 10:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 10:08:59 --> CSRF cookie sent
INFO - 2018-06-27 10:08:59 --> Input Class Initialized
INFO - 2018-06-27 10:08:59 --> Language Class Initialized
INFO - 2018-06-27 10:08:59 --> Loader Class Initialized
INFO - 2018-06-27 10:08:59 --> Helper loaded: url_helper
INFO - 2018-06-27 10:08:59 --> Helper loaded: form_helper
INFO - 2018-06-27 10:08:59 --> Helper loaded: language_helper
DEBUG - 2018-06-27 10:08:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 10:08:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 10:08:59 --> User Agent Class Initialized
INFO - 2018-06-27 10:08:59 --> Controller Class Initialized
INFO - 2018-06-27 10:08:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-27 10:08:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-27 10:08:59 --> Pixel_Model class loaded
INFO - 2018-06-27 10:08:59 --> Database Driver Class Initialized
INFO - 2018-06-27 10:08:59 --> Model "QuestionsModel" initialized
INFO - 2018-06-27 10:08:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-27 10:08:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-27 10:08:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-27 10:08:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-27 10:08:59 --> Final output sent to browser
DEBUG - 2018-06-27 10:08:59 --> Total execution time: 0.0485
INFO - 2018-06-27 10:42:18 --> Config Class Initialized
INFO - 2018-06-27 10:42:18 --> Hooks Class Initialized
DEBUG - 2018-06-27 10:42:18 --> UTF-8 Support Enabled
INFO - 2018-06-27 10:42:18 --> Utf8 Class Initialized
INFO - 2018-06-27 10:42:18 --> URI Class Initialized
INFO - 2018-06-27 10:42:18 --> Router Class Initialized
INFO - 2018-06-27 10:42:18 --> Output Class Initialized
INFO - 2018-06-27 10:42:18 --> Security Class Initialized
DEBUG - 2018-06-27 10:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 10:42:18 --> CSRF cookie sent
INFO - 2018-06-27 10:42:18 --> Input Class Initialized
INFO - 2018-06-27 10:42:18 --> Language Class Initialized
ERROR - 2018-06-27 10:42:18 --> 404 Page Not Found: NNibZ/index
INFO - 2018-06-27 11:47:45 --> Config Class Initialized
INFO - 2018-06-27 11:47:45 --> Hooks Class Initialized
DEBUG - 2018-06-27 11:47:45 --> UTF-8 Support Enabled
INFO - 2018-06-27 11:47:45 --> Utf8 Class Initialized
INFO - 2018-06-27 11:47:45 --> URI Class Initialized
INFO - 2018-06-27 11:47:45 --> Router Class Initialized
INFO - 2018-06-27 11:47:45 --> Output Class Initialized
INFO - 2018-06-27 11:47:45 --> Security Class Initialized
DEBUG - 2018-06-27 11:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 11:47:45 --> CSRF cookie sent
INFO - 2018-06-27 11:47:45 --> Input Class Initialized
INFO - 2018-06-27 11:47:45 --> Language Class Initialized
ERROR - 2018-06-27 11:47:45 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-06-27 11:47:48 --> Config Class Initialized
INFO - 2018-06-27 11:47:48 --> Hooks Class Initialized
DEBUG - 2018-06-27 11:47:48 --> UTF-8 Support Enabled
INFO - 2018-06-27 11:47:48 --> Utf8 Class Initialized
INFO - 2018-06-27 11:47:48 --> URI Class Initialized
INFO - 2018-06-27 11:47:48 --> Router Class Initialized
INFO - 2018-06-27 11:47:48 --> Output Class Initialized
INFO - 2018-06-27 11:47:48 --> Security Class Initialized
DEBUG - 2018-06-27 11:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 11:47:48 --> CSRF cookie sent
INFO - 2018-06-27 11:47:48 --> Input Class Initialized
INFO - 2018-06-27 11:47:48 --> Language Class Initialized
INFO - 2018-06-27 11:47:48 --> Loader Class Initialized
INFO - 2018-06-27 11:47:48 --> Helper loaded: url_helper
INFO - 2018-06-27 11:47:48 --> Helper loaded: form_helper
INFO - 2018-06-27 11:47:48 --> Helper loaded: language_helper
DEBUG - 2018-06-27 11:47:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 11:47:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 11:47:48 --> User Agent Class Initialized
INFO - 2018-06-27 11:47:48 --> Controller Class Initialized
INFO - 2018-06-27 11:47:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-27 11:47:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-27 11:47:48 --> Pixel_Model class loaded
INFO - 2018-06-27 11:47:48 --> Database Driver Class Initialized
INFO - 2018-06-27 11:47:48 --> Model "QuestionsModel" initialized
INFO - 2018-06-27 11:47:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-27 11:47:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-27 11:47:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-27 11:47:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-27 11:47:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/buy_gift.php
INFO - 2018-06-27 11:47:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-27 11:47:48 --> Final output sent to browser
DEBUG - 2018-06-27 11:47:48 --> Total execution time: 0.0354
INFO - 2018-06-27 12:58:59 --> Config Class Initialized
INFO - 2018-06-27 12:58:59 --> Hooks Class Initialized
DEBUG - 2018-06-27 12:58:59 --> UTF-8 Support Enabled
INFO - 2018-06-27 12:58:59 --> Utf8 Class Initialized
INFO - 2018-06-27 12:58:59 --> URI Class Initialized
INFO - 2018-06-27 12:58:59 --> Router Class Initialized
INFO - 2018-06-27 12:58:59 --> Output Class Initialized
INFO - 2018-06-27 12:58:59 --> Security Class Initialized
DEBUG - 2018-06-27 12:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 12:58:59 --> CSRF cookie sent
INFO - 2018-06-27 12:58:59 --> Input Class Initialized
INFO - 2018-06-27 12:58:59 --> Language Class Initialized
ERROR - 2018-06-27 12:58:59 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-06-27 12:59:00 --> Config Class Initialized
INFO - 2018-06-27 12:59:00 --> Hooks Class Initialized
DEBUG - 2018-06-27 12:59:00 --> UTF-8 Support Enabled
INFO - 2018-06-27 12:59:00 --> Utf8 Class Initialized
INFO - 2018-06-27 12:59:00 --> URI Class Initialized
DEBUG - 2018-06-27 12:59:00 --> No URI present. Default controller set.
INFO - 2018-06-27 12:59:00 --> Router Class Initialized
INFO - 2018-06-27 12:59:00 --> Output Class Initialized
INFO - 2018-06-27 12:59:00 --> Security Class Initialized
DEBUG - 2018-06-27 12:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 12:59:00 --> CSRF cookie sent
INFO - 2018-06-27 12:59:00 --> Input Class Initialized
INFO - 2018-06-27 12:59:00 --> Language Class Initialized
INFO - 2018-06-27 12:59:00 --> Loader Class Initialized
INFO - 2018-06-27 12:59:00 --> Helper loaded: url_helper
INFO - 2018-06-27 12:59:00 --> Helper loaded: form_helper
INFO - 2018-06-27 12:59:00 --> Helper loaded: language_helper
DEBUG - 2018-06-27 12:59:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 12:59:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 12:59:00 --> User Agent Class Initialized
INFO - 2018-06-27 12:59:00 --> Controller Class Initialized
INFO - 2018-06-27 12:59:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-27 12:59:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-27 12:59:00 --> Pixel_Model class loaded
INFO - 2018-06-27 12:59:00 --> Database Driver Class Initialized
INFO - 2018-06-27 12:59:00 --> Model "QuestionsModel" initialized
INFO - 2018-06-27 12:59:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-27 12:59:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-27 12:59:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-27 12:59:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-27 12:59:00 --> Final output sent to browser
DEBUG - 2018-06-27 12:59:00 --> Total execution time: 0.0312
INFO - 2018-06-27 12:59:04 --> Config Class Initialized
INFO - 2018-06-27 12:59:04 --> Hooks Class Initialized
DEBUG - 2018-06-27 12:59:04 --> UTF-8 Support Enabled
INFO - 2018-06-27 12:59:04 --> Utf8 Class Initialized
INFO - 2018-06-27 12:59:04 --> URI Class Initialized
INFO - 2018-06-27 12:59:04 --> Router Class Initialized
INFO - 2018-06-27 12:59:04 --> Output Class Initialized
INFO - 2018-06-27 12:59:04 --> Security Class Initialized
DEBUG - 2018-06-27 12:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 12:59:04 --> CSRF cookie sent
INFO - 2018-06-27 12:59:04 --> Input Class Initialized
INFO - 2018-06-27 12:59:04 --> Language Class Initialized
ERROR - 2018-06-27 12:59:04 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-06-27 14:35:47 --> Config Class Initialized
INFO - 2018-06-27 14:35:47 --> Hooks Class Initialized
DEBUG - 2018-06-27 14:35:47 --> UTF-8 Support Enabled
INFO - 2018-06-27 14:35:47 --> Utf8 Class Initialized
INFO - 2018-06-27 14:35:47 --> URI Class Initialized
INFO - 2018-06-27 14:35:47 --> Router Class Initialized
INFO - 2018-06-27 14:35:47 --> Output Class Initialized
INFO - 2018-06-27 14:35:47 --> Security Class Initialized
DEBUG - 2018-06-27 14:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 14:35:47 --> CSRF cookie sent
INFO - 2018-06-27 14:35:47 --> Input Class Initialized
INFO - 2018-06-27 14:35:47 --> Language Class Initialized
ERROR - 2018-06-27 14:35:47 --> 404 Page Not Found: Faviconico/index
INFO - 2018-06-27 16:33:37 --> Config Class Initialized
INFO - 2018-06-27 16:33:37 --> Hooks Class Initialized
DEBUG - 2018-06-27 16:33:37 --> UTF-8 Support Enabled
INFO - 2018-06-27 16:33:37 --> Utf8 Class Initialized
INFO - 2018-06-27 16:33:37 --> URI Class Initialized
INFO - 2018-06-27 16:33:37 --> Router Class Initialized
INFO - 2018-06-27 16:33:37 --> Output Class Initialized
INFO - 2018-06-27 16:33:37 --> Security Class Initialized
DEBUG - 2018-06-27 16:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 16:33:37 --> CSRF cookie sent
INFO - 2018-06-27 16:33:37 --> Input Class Initialized
INFO - 2018-06-27 16:33:37 --> Language Class Initialized
ERROR - 2018-06-27 16:33:37 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-06-27 16:33:40 --> Config Class Initialized
INFO - 2018-06-27 16:33:40 --> Hooks Class Initialized
DEBUG - 2018-06-27 16:33:40 --> UTF-8 Support Enabled
INFO - 2018-06-27 16:33:40 --> Utf8 Class Initialized
INFO - 2018-06-27 16:33:40 --> URI Class Initialized
INFO - 2018-06-27 16:33:40 --> Router Class Initialized
INFO - 2018-06-27 16:33:40 --> Output Class Initialized
INFO - 2018-06-27 16:33:40 --> Security Class Initialized
DEBUG - 2018-06-27 16:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 16:33:40 --> CSRF cookie sent
INFO - 2018-06-27 16:33:40 --> Input Class Initialized
INFO - 2018-06-27 16:33:40 --> Language Class Initialized
INFO - 2018-06-27 16:33:40 --> Loader Class Initialized
INFO - 2018-06-27 16:33:40 --> Helper loaded: url_helper
INFO - 2018-06-27 16:33:40 --> Helper loaded: form_helper
INFO - 2018-06-27 16:33:40 --> Helper loaded: language_helper
DEBUG - 2018-06-27 16:33:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 16:33:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 16:33:40 --> User Agent Class Initialized
INFO - 2018-06-27 16:33:40 --> Controller Class Initialized
INFO - 2018-06-27 16:33:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-27 16:33:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-27 16:33:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-27 16:33:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-27 16:33:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-27 16:33:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-27 16:33:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/teacher.php
INFO - 2018-06-27 16:33:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-27 16:33:40 --> Final output sent to browser
DEBUG - 2018-06-27 16:33:40 --> Total execution time: 0.0226
INFO - 2018-06-27 16:38:23 --> Config Class Initialized
INFO - 2018-06-27 16:38:23 --> Hooks Class Initialized
DEBUG - 2018-06-27 16:38:23 --> UTF-8 Support Enabled
INFO - 2018-06-27 16:38:23 --> Utf8 Class Initialized
INFO - 2018-06-27 16:38:23 --> URI Class Initialized
INFO - 2018-06-27 16:38:23 --> Router Class Initialized
INFO - 2018-06-27 16:38:23 --> Output Class Initialized
INFO - 2018-06-27 16:38:23 --> Security Class Initialized
DEBUG - 2018-06-27 16:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 16:38:23 --> CSRF cookie sent
INFO - 2018-06-27 16:38:23 --> Input Class Initialized
INFO - 2018-06-27 16:38:23 --> Language Class Initialized
INFO - 2018-06-27 16:38:23 --> Loader Class Initialized
INFO - 2018-06-27 16:38:23 --> Helper loaded: url_helper
INFO - 2018-06-27 16:38:23 --> Helper loaded: form_helper
INFO - 2018-06-27 16:38:23 --> Helper loaded: language_helper
DEBUG - 2018-06-27 16:38:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 16:38:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 16:38:23 --> User Agent Class Initialized
INFO - 2018-06-27 16:38:23 --> Controller Class Initialized
INFO - 2018-06-27 16:38:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-27 16:38:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-27 16:38:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-27 16:38:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-27 16:38:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-27 16:38:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-27 16:38:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-06-27 16:38:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-27 16:38:23 --> Final output sent to browser
DEBUG - 2018-06-27 16:38:23 --> Total execution time: 0.0246
INFO - 2018-06-27 16:57:12 --> Config Class Initialized
INFO - 2018-06-27 16:57:12 --> Hooks Class Initialized
DEBUG - 2018-06-27 16:57:12 --> UTF-8 Support Enabled
INFO - 2018-06-27 16:57:12 --> Utf8 Class Initialized
INFO - 2018-06-27 16:57:12 --> URI Class Initialized
INFO - 2018-06-27 16:57:12 --> Router Class Initialized
INFO - 2018-06-27 16:57:12 --> Output Class Initialized
INFO - 2018-06-27 16:57:12 --> Security Class Initialized
DEBUG - 2018-06-27 16:57:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 16:57:12 --> CSRF cookie sent
INFO - 2018-06-27 16:57:12 --> Input Class Initialized
INFO - 2018-06-27 16:57:12 --> Language Class Initialized
ERROR - 2018-06-27 16:57:12 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-06-27 17:11:43 --> Config Class Initialized
INFO - 2018-06-27 17:11:43 --> Hooks Class Initialized
DEBUG - 2018-06-27 17:11:43 --> UTF-8 Support Enabled
INFO - 2018-06-27 17:11:43 --> Utf8 Class Initialized
INFO - 2018-06-27 17:11:43 --> URI Class Initialized
INFO - 2018-06-27 17:11:43 --> Router Class Initialized
INFO - 2018-06-27 17:11:43 --> Output Class Initialized
INFO - 2018-06-27 17:11:43 --> Security Class Initialized
DEBUG - 2018-06-27 17:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 17:11:43 --> CSRF cookie sent
INFO - 2018-06-27 17:11:43 --> Input Class Initialized
INFO - 2018-06-27 17:11:43 --> Language Class Initialized
INFO - 2018-06-27 17:11:43 --> Loader Class Initialized
INFO - 2018-06-27 17:11:43 --> Helper loaded: url_helper
INFO - 2018-06-27 17:11:43 --> Helper loaded: form_helper
INFO - 2018-06-27 17:11:43 --> Helper loaded: language_helper
DEBUG - 2018-06-27 17:11:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 17:11:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 17:11:43 --> User Agent Class Initialized
INFO - 2018-06-27 17:11:43 --> Controller Class Initialized
INFO - 2018-06-27 17:11:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-27 17:11:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-27 17:11:43 --> Pixel_Model class loaded
INFO - 2018-06-27 17:11:43 --> Database Driver Class Initialized
INFO - 2018-06-27 17:11:43 --> Model "QuestionsModel" initialized
ERROR - 2018-06-27 17:11:43 --> Severity: Notice --> Undefined index: HTTP_REFERER /home/fxp6bn7rqemh/public_html/application/core/Pixel_Controller.php 87
INFO - 2018-06-27 17:11:44 --> Config Class Initialized
INFO - 2018-06-27 17:11:44 --> Hooks Class Initialized
DEBUG - 2018-06-27 17:11:44 --> UTF-8 Support Enabled
INFO - 2018-06-27 17:11:44 --> Utf8 Class Initialized
INFO - 2018-06-27 17:11:44 --> URI Class Initialized
INFO - 2018-06-27 17:11:44 --> Router Class Initialized
INFO - 2018-06-27 17:11:44 --> Output Class Initialized
INFO - 2018-06-27 17:11:44 --> Security Class Initialized
DEBUG - 2018-06-27 17:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 17:11:44 --> CSRF cookie sent
INFO - 2018-06-27 17:11:44 --> Input Class Initialized
INFO - 2018-06-27 17:11:44 --> Language Class Initialized
INFO - 2018-06-27 17:11:44 --> Loader Class Initialized
INFO - 2018-06-27 17:11:44 --> Helper loaded: url_helper
INFO - 2018-06-27 17:11:44 --> Helper loaded: form_helper
INFO - 2018-06-27 17:11:44 --> Helper loaded: language_helper
DEBUG - 2018-06-27 17:11:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 17:11:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 17:11:44 --> User Agent Class Initialized
INFO - 2018-06-27 17:11:44 --> Controller Class Initialized
INFO - 2018-06-27 17:11:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-27 17:11:44 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-27 17:11:44 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-27 17:11:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-27 17:11:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-27 17:11:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-27 17:11:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-27 17:11:44 --> Could not find the language line "req_email"
INFO - 2018-06-27 17:11:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-06-27 17:11:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-27 17:11:44 --> Final output sent to browser
DEBUG - 2018-06-27 17:11:44 --> Total execution time: 0.0213
INFO - 2018-06-27 17:22:00 --> Config Class Initialized
INFO - 2018-06-27 17:22:00 --> Hooks Class Initialized
DEBUG - 2018-06-27 17:22:00 --> UTF-8 Support Enabled
INFO - 2018-06-27 17:22:00 --> Utf8 Class Initialized
INFO - 2018-06-27 17:22:00 --> URI Class Initialized
DEBUG - 2018-06-27 17:22:00 --> No URI present. Default controller set.
INFO - 2018-06-27 17:22:00 --> Router Class Initialized
INFO - 2018-06-27 17:22:00 --> Output Class Initialized
INFO - 2018-06-27 17:22:00 --> Security Class Initialized
DEBUG - 2018-06-27 17:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 17:22:00 --> CSRF cookie sent
INFO - 2018-06-27 17:22:00 --> Input Class Initialized
INFO - 2018-06-27 17:22:00 --> Language Class Initialized
INFO - 2018-06-27 17:22:00 --> Loader Class Initialized
INFO - 2018-06-27 17:22:00 --> Helper loaded: url_helper
INFO - 2018-06-27 17:22:00 --> Helper loaded: form_helper
INFO - 2018-06-27 17:22:00 --> Helper loaded: language_helper
DEBUG - 2018-06-27 17:22:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 17:22:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 17:22:00 --> User Agent Class Initialized
INFO - 2018-06-27 17:22:00 --> Controller Class Initialized
INFO - 2018-06-27 17:22:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-27 17:22:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-27 17:22:00 --> Pixel_Model class loaded
INFO - 2018-06-27 17:22:00 --> Database Driver Class Initialized
INFO - 2018-06-27 17:22:00 --> Model "QuestionsModel" initialized
INFO - 2018-06-27 17:22:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-27 17:22:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-27 17:22:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-27 17:22:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-27 17:22:00 --> Final output sent to browser
DEBUG - 2018-06-27 17:22:00 --> Total execution time: 0.0334
INFO - 2018-06-27 17:36:28 --> Config Class Initialized
INFO - 2018-06-27 17:36:28 --> Hooks Class Initialized
DEBUG - 2018-06-27 17:36:28 --> UTF-8 Support Enabled
INFO - 2018-06-27 17:36:28 --> Utf8 Class Initialized
INFO - 2018-06-27 17:36:28 --> URI Class Initialized
DEBUG - 2018-06-27 17:36:28 --> No URI present. Default controller set.
INFO - 2018-06-27 17:36:28 --> Router Class Initialized
INFO - 2018-06-27 17:36:28 --> Output Class Initialized
INFO - 2018-06-27 17:36:28 --> Security Class Initialized
DEBUG - 2018-06-27 17:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 17:36:28 --> CSRF cookie sent
INFO - 2018-06-27 17:36:28 --> Input Class Initialized
INFO - 2018-06-27 17:36:28 --> Language Class Initialized
INFO - 2018-06-27 17:36:28 --> Loader Class Initialized
INFO - 2018-06-27 17:36:28 --> Helper loaded: url_helper
INFO - 2018-06-27 17:36:28 --> Helper loaded: form_helper
INFO - 2018-06-27 17:36:28 --> Helper loaded: language_helper
DEBUG - 2018-06-27 17:36:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 17:36:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 17:36:28 --> User Agent Class Initialized
INFO - 2018-06-27 17:36:28 --> Controller Class Initialized
INFO - 2018-06-27 17:36:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-27 17:36:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-27 17:36:28 --> Pixel_Model class loaded
INFO - 2018-06-27 17:36:28 --> Database Driver Class Initialized
INFO - 2018-06-27 17:36:28 --> Model "QuestionsModel" initialized
INFO - 2018-06-27 17:36:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-27 17:36:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-27 17:36:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-27 17:36:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-27 17:36:28 --> Final output sent to browser
DEBUG - 2018-06-27 17:36:28 --> Total execution time: 0.0424
INFO - 2018-06-27 17:36:29 --> Config Class Initialized
INFO - 2018-06-27 17:36:29 --> Hooks Class Initialized
DEBUG - 2018-06-27 17:36:29 --> UTF-8 Support Enabled
INFO - 2018-06-27 17:36:29 --> Utf8 Class Initialized
INFO - 2018-06-27 17:36:29 --> URI Class Initialized
DEBUG - 2018-06-27 17:36:29 --> No URI present. Default controller set.
INFO - 2018-06-27 17:36:29 --> Router Class Initialized
INFO - 2018-06-27 17:36:29 --> Output Class Initialized
INFO - 2018-06-27 17:36:29 --> Security Class Initialized
DEBUG - 2018-06-27 17:36:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 17:36:29 --> CSRF cookie sent
INFO - 2018-06-27 17:36:29 --> Input Class Initialized
INFO - 2018-06-27 17:36:29 --> Language Class Initialized
INFO - 2018-06-27 17:36:29 --> Loader Class Initialized
INFO - 2018-06-27 17:36:29 --> Helper loaded: url_helper
INFO - 2018-06-27 17:36:29 --> Helper loaded: form_helper
INFO - 2018-06-27 17:36:29 --> Helper loaded: language_helper
DEBUG - 2018-06-27 17:36:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 17:36:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 17:36:29 --> User Agent Class Initialized
INFO - 2018-06-27 17:36:29 --> Controller Class Initialized
INFO - 2018-06-27 17:36:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-27 17:36:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-27 17:36:29 --> Pixel_Model class loaded
INFO - 2018-06-27 17:36:29 --> Database Driver Class Initialized
INFO - 2018-06-27 17:36:29 --> Model "QuestionsModel" initialized
INFO - 2018-06-27 17:36:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-27 17:36:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-27 17:36:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-27 17:36:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-27 17:36:29 --> Final output sent to browser
DEBUG - 2018-06-27 17:36:29 --> Total execution time: 0.0324
INFO - 2018-06-27 17:36:29 --> Config Class Initialized
INFO - 2018-06-27 17:36:29 --> Hooks Class Initialized
DEBUG - 2018-06-27 17:36:29 --> UTF-8 Support Enabled
INFO - 2018-06-27 17:36:29 --> Utf8 Class Initialized
INFO - 2018-06-27 17:36:29 --> URI Class Initialized
DEBUG - 2018-06-27 17:36:29 --> No URI present. Default controller set.
INFO - 2018-06-27 17:36:29 --> Router Class Initialized
INFO - 2018-06-27 17:36:29 --> Output Class Initialized
INFO - 2018-06-27 17:36:29 --> Security Class Initialized
DEBUG - 2018-06-27 17:36:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 17:36:29 --> CSRF cookie sent
INFO - 2018-06-27 17:36:29 --> Input Class Initialized
INFO - 2018-06-27 17:36:29 --> Language Class Initialized
INFO - 2018-06-27 17:36:29 --> Loader Class Initialized
INFO - 2018-06-27 17:36:29 --> Helper loaded: url_helper
INFO - 2018-06-27 17:36:29 --> Helper loaded: form_helper
INFO - 2018-06-27 17:36:29 --> Helper loaded: language_helper
DEBUG - 2018-06-27 17:36:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 17:36:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 17:36:29 --> User Agent Class Initialized
INFO - 2018-06-27 17:36:29 --> Controller Class Initialized
INFO - 2018-06-27 17:36:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-27 17:36:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-27 17:36:29 --> Pixel_Model class loaded
INFO - 2018-06-27 17:36:29 --> Database Driver Class Initialized
INFO - 2018-06-27 17:36:29 --> Model "QuestionsModel" initialized
INFO - 2018-06-27 17:36:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-27 17:36:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-27 17:36:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-27 17:36:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-27 17:36:29 --> Final output sent to browser
DEBUG - 2018-06-27 17:36:29 --> Total execution time: 0.0323
INFO - 2018-06-27 17:36:30 --> Config Class Initialized
INFO - 2018-06-27 17:36:30 --> Hooks Class Initialized
DEBUG - 2018-06-27 17:36:30 --> UTF-8 Support Enabled
INFO - 2018-06-27 17:36:30 --> Utf8 Class Initialized
INFO - 2018-06-27 17:36:30 --> URI Class Initialized
INFO - 2018-06-27 17:36:30 --> Router Class Initialized
INFO - 2018-06-27 17:36:30 --> Output Class Initialized
INFO - 2018-06-27 17:36:30 --> Security Class Initialized
DEBUG - 2018-06-27 17:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 17:36:30 --> CSRF cookie sent
INFO - 2018-06-27 17:36:30 --> Input Class Initialized
INFO - 2018-06-27 17:36:30 --> Language Class Initialized
ERROR - 2018-06-27 17:36:30 --> 404 Page Not Found: 405shtml/index
INFO - 2018-06-27 17:36:36 --> Config Class Initialized
INFO - 2018-06-27 17:36:36 --> Hooks Class Initialized
DEBUG - 2018-06-27 17:36:36 --> UTF-8 Support Enabled
INFO - 2018-06-27 17:36:36 --> Utf8 Class Initialized
INFO - 2018-06-27 17:36:36 --> URI Class Initialized
DEBUG - 2018-06-27 17:36:36 --> No URI present. Default controller set.
INFO - 2018-06-27 17:36:36 --> Router Class Initialized
INFO - 2018-06-27 17:36:36 --> Output Class Initialized
INFO - 2018-06-27 17:36:36 --> Security Class Initialized
DEBUG - 2018-06-27 17:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 17:36:36 --> CSRF cookie sent
INFO - 2018-06-27 17:36:36 --> Input Class Initialized
INFO - 2018-06-27 17:36:36 --> Language Class Initialized
INFO - 2018-06-27 17:36:36 --> Loader Class Initialized
INFO - 2018-06-27 17:36:36 --> Helper loaded: url_helper
INFO - 2018-06-27 17:36:36 --> Helper loaded: form_helper
INFO - 2018-06-27 17:36:36 --> Helper loaded: language_helper
DEBUG - 2018-06-27 17:36:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 17:36:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 17:36:36 --> User Agent Class Initialized
INFO - 2018-06-27 17:36:36 --> Controller Class Initialized
INFO - 2018-06-27 17:36:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-27 17:36:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-27 17:36:36 --> Pixel_Model class loaded
INFO - 2018-06-27 17:36:36 --> Database Driver Class Initialized
INFO - 2018-06-27 17:36:36 --> Model "QuestionsModel" initialized
INFO - 2018-06-27 17:36:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-27 17:36:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-27 17:36:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-27 17:36:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-27 17:36:36 --> Final output sent to browser
DEBUG - 2018-06-27 17:36:36 --> Total execution time: 0.0328
INFO - 2018-06-27 17:36:37 --> Config Class Initialized
INFO - 2018-06-27 17:36:37 --> Hooks Class Initialized
DEBUG - 2018-06-27 17:36:37 --> UTF-8 Support Enabled
INFO - 2018-06-27 17:36:37 --> Utf8 Class Initialized
INFO - 2018-06-27 17:36:37 --> URI Class Initialized
INFO - 2018-06-27 17:36:37 --> Router Class Initialized
INFO - 2018-06-27 17:36:37 --> Output Class Initialized
INFO - 2018-06-27 17:36:37 --> Security Class Initialized
DEBUG - 2018-06-27 17:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 17:36:37 --> CSRF cookie sent
INFO - 2018-06-27 17:36:37 --> Input Class Initialized
INFO - 2018-06-27 17:36:37 --> Language Class Initialized
ERROR - 2018-06-27 17:36:37 --> 404 Page Not Found: 404testpage4525d2fdc/index
INFO - 2018-06-27 17:36:37 --> Config Class Initialized
INFO - 2018-06-27 17:36:37 --> Hooks Class Initialized
DEBUG - 2018-06-27 17:36:37 --> UTF-8 Support Enabled
INFO - 2018-06-27 17:36:37 --> Utf8 Class Initialized
INFO - 2018-06-27 17:36:37 --> URI Class Initialized
INFO - 2018-06-27 17:36:37 --> Router Class Initialized
INFO - 2018-06-27 17:36:37 --> Output Class Initialized
INFO - 2018-06-27 17:36:37 --> Security Class Initialized
DEBUG - 2018-06-27 17:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 17:36:37 --> CSRF cookie sent
INFO - 2018-06-27 17:36:37 --> Input Class Initialized
INFO - 2018-06-27 17:36:37 --> Language Class Initialized
ERROR - 2018-06-27 17:36:37 --> 404 Page Not Found: 404javascriptjs/index
INFO - 2018-06-27 17:36:37 --> Config Class Initialized
INFO - 2018-06-27 17:36:37 --> Hooks Class Initialized
DEBUG - 2018-06-27 17:36:37 --> UTF-8 Support Enabled
INFO - 2018-06-27 17:36:37 --> Utf8 Class Initialized
INFO - 2018-06-27 17:36:37 --> URI Class Initialized
INFO - 2018-06-27 17:36:37 --> Router Class Initialized
INFO - 2018-06-27 17:36:37 --> Output Class Initialized
INFO - 2018-06-27 17:36:37 --> Security Class Initialized
DEBUG - 2018-06-27 17:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 17:36:37 --> CSRF cookie sent
INFO - 2018-06-27 17:36:37 --> Input Class Initialized
INFO - 2018-06-27 17:36:37 --> Language Class Initialized
INFO - 2018-06-27 17:36:37 --> Loader Class Initialized
INFO - 2018-06-27 17:36:37 --> Helper loaded: url_helper
INFO - 2018-06-27 17:36:37 --> Helper loaded: form_helper
INFO - 2018-06-27 17:36:37 --> Helper loaded: language_helper
DEBUG - 2018-06-27 17:36:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 17:36:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 17:36:37 --> User Agent Class Initialized
INFO - 2018-06-27 17:36:37 --> Controller Class Initialized
INFO - 2018-06-27 17:36:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-27 17:36:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-27 17:36:37 --> Pixel_Model class loaded
INFO - 2018-06-27 17:36:37 --> Database Driver Class Initialized
INFO - 2018-06-27 17:36:37 --> Model "QuestionsModel" initialized
ERROR - 2018-06-27 17:36:37 --> Severity: Notice --> Undefined index: HTTP_REFERER /home/fxp6bn7rqemh/public_html/application/core/Pixel_Controller.php 87
INFO - 2018-06-27 17:36:37 --> Config Class Initialized
INFO - 2018-06-27 17:36:37 --> Hooks Class Initialized
DEBUG - 2018-06-27 17:36:37 --> UTF-8 Support Enabled
INFO - 2018-06-27 17:36:37 --> Utf8 Class Initialized
INFO - 2018-06-27 17:36:37 --> URI Class Initialized
INFO - 2018-06-27 17:36:37 --> Router Class Initialized
INFO - 2018-06-27 17:36:37 --> Output Class Initialized
INFO - 2018-06-27 17:36:37 --> Security Class Initialized
DEBUG - 2018-06-27 17:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 17:36:37 --> CSRF cookie sent
INFO - 2018-06-27 17:36:37 --> Input Class Initialized
INFO - 2018-06-27 17:36:37 --> Language Class Initialized
INFO - 2018-06-27 17:36:37 --> Loader Class Initialized
INFO - 2018-06-27 17:36:37 --> Helper loaded: url_helper
INFO - 2018-06-27 17:36:37 --> Helper loaded: form_helper
INFO - 2018-06-27 17:36:37 --> Helper loaded: language_helper
DEBUG - 2018-06-27 17:36:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 17:36:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 17:36:37 --> User Agent Class Initialized
INFO - 2018-06-27 17:36:37 --> Controller Class Initialized
INFO - 2018-06-27 17:36:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-27 17:36:37 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-27 17:36:37 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-27 17:36:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-27 17:36:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-27 17:36:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-27 17:36:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-27 17:36:37 --> Could not find the language line "req_email"
INFO - 2018-06-27 17:36:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-06-27 17:36:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-27 17:36:37 --> Final output sent to browser
DEBUG - 2018-06-27 17:36:37 --> Total execution time: 0.0215
INFO - 2018-06-27 17:36:38 --> Config Class Initialized
INFO - 2018-06-27 17:36:38 --> Hooks Class Initialized
DEBUG - 2018-06-27 17:36:38 --> UTF-8 Support Enabled
INFO - 2018-06-27 17:36:38 --> Utf8 Class Initialized
INFO - 2018-06-27 17:36:38 --> URI Class Initialized
INFO - 2018-06-27 17:36:38 --> Router Class Initialized
INFO - 2018-06-27 17:36:38 --> Output Class Initialized
INFO - 2018-06-27 17:36:38 --> Security Class Initialized
DEBUG - 2018-06-27 17:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 17:36:38 --> CSRF cookie sent
INFO - 2018-06-27 17:36:38 --> Input Class Initialized
INFO - 2018-06-27 17:36:38 --> Language Class Initialized
INFO - 2018-06-27 17:36:38 --> Loader Class Initialized
INFO - 2018-06-27 17:36:38 --> Helper loaded: url_helper
INFO - 2018-06-27 17:36:38 --> Helper loaded: form_helper
INFO - 2018-06-27 17:36:38 --> Helper loaded: language_helper
DEBUG - 2018-06-27 17:36:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 17:36:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 17:36:38 --> User Agent Class Initialized
INFO - 2018-06-27 17:36:38 --> Controller Class Initialized
INFO - 2018-06-27 17:36:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-27 17:36:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-27 17:36:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-27 17:36:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-27 17:36:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-27 17:36:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-27 17:36:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-06-27 17:36:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-27 17:36:38 --> Final output sent to browser
DEBUG - 2018-06-27 17:36:38 --> Total execution time: 0.0218
INFO - 2018-06-27 17:36:38 --> Config Class Initialized
INFO - 2018-06-27 17:36:38 --> Hooks Class Initialized
DEBUG - 2018-06-27 17:36:38 --> UTF-8 Support Enabled
INFO - 2018-06-27 17:36:38 --> Utf8 Class Initialized
INFO - 2018-06-27 17:36:38 --> URI Class Initialized
INFO - 2018-06-27 17:36:38 --> Router Class Initialized
INFO - 2018-06-27 17:36:38 --> Output Class Initialized
INFO - 2018-06-27 17:36:38 --> Security Class Initialized
DEBUG - 2018-06-27 17:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 17:36:38 --> CSRF cookie sent
INFO - 2018-06-27 17:36:38 --> Input Class Initialized
INFO - 2018-06-27 17:36:38 --> Language Class Initialized
INFO - 2018-06-27 17:36:38 --> Loader Class Initialized
INFO - 2018-06-27 17:36:38 --> Helper loaded: url_helper
INFO - 2018-06-27 17:36:38 --> Helper loaded: form_helper
INFO - 2018-06-27 17:36:38 --> Helper loaded: language_helper
DEBUG - 2018-06-27 17:36:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 17:36:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 17:36:38 --> User Agent Class Initialized
INFO - 2018-06-27 17:36:38 --> Controller Class Initialized
INFO - 2018-06-27 17:36:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-27 17:36:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-27 17:36:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-27 17:36:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-27 17:36:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-27 17:36:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-27 17:36:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-06-27 17:36:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-27 17:36:38 --> Final output sent to browser
DEBUG - 2018-06-27 17:36:38 --> Total execution time: 0.0466
INFO - 2018-06-27 17:36:38 --> Config Class Initialized
INFO - 2018-06-27 17:36:38 --> Hooks Class Initialized
DEBUG - 2018-06-27 17:36:38 --> UTF-8 Support Enabled
INFO - 2018-06-27 17:36:38 --> Utf8 Class Initialized
INFO - 2018-06-27 17:36:38 --> URI Class Initialized
INFO - 2018-06-27 17:36:38 --> Router Class Initialized
INFO - 2018-06-27 17:36:38 --> Output Class Initialized
INFO - 2018-06-27 17:36:38 --> Security Class Initialized
DEBUG - 2018-06-27 17:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 17:36:38 --> CSRF cookie sent
INFO - 2018-06-27 17:36:38 --> Input Class Initialized
INFO - 2018-06-27 17:36:38 --> Language Class Initialized
INFO - 2018-06-27 17:36:38 --> Loader Class Initialized
INFO - 2018-06-27 17:36:38 --> Helper loaded: url_helper
INFO - 2018-06-27 17:36:38 --> Helper loaded: form_helper
INFO - 2018-06-27 17:36:38 --> Helper loaded: language_helper
DEBUG - 2018-06-27 17:36:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 17:36:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 17:36:38 --> User Agent Class Initialized
INFO - 2018-06-27 17:36:38 --> Controller Class Initialized
INFO - 2018-06-27 17:36:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-27 17:36:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-27 17:36:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-27 17:36:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-27 17:36:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-27 17:36:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-27 17:36:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-06-27 17:36:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-27 17:36:38 --> Final output sent to browser
DEBUG - 2018-06-27 17:36:38 --> Total execution time: 0.0236
INFO - 2018-06-27 17:36:39 --> Config Class Initialized
INFO - 2018-06-27 17:36:39 --> Hooks Class Initialized
DEBUG - 2018-06-27 17:36:39 --> UTF-8 Support Enabled
INFO - 2018-06-27 17:36:39 --> Utf8 Class Initialized
INFO - 2018-06-27 17:36:39 --> URI Class Initialized
INFO - 2018-06-27 17:36:39 --> Router Class Initialized
INFO - 2018-06-27 17:36:39 --> Output Class Initialized
INFO - 2018-06-27 17:36:39 --> Security Class Initialized
DEBUG - 2018-06-27 17:36:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 17:36:39 --> CSRF cookie sent
INFO - 2018-06-27 17:36:39 --> Input Class Initialized
INFO - 2018-06-27 17:36:39 --> Language Class Initialized
INFO - 2018-06-27 17:36:39 --> Loader Class Initialized
INFO - 2018-06-27 17:36:39 --> Helper loaded: url_helper
INFO - 2018-06-27 17:36:39 --> Helper loaded: form_helper
INFO - 2018-06-27 17:36:39 --> Helper loaded: language_helper
DEBUG - 2018-06-27 17:36:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 17:36:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 17:36:39 --> User Agent Class Initialized
INFO - 2018-06-27 17:36:39 --> Controller Class Initialized
INFO - 2018-06-27 17:36:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-27 17:36:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-27 17:36:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-27 17:36:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-27 17:36:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-27 17:36:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-27 17:36:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-06-27 17:36:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-27 17:36:39 --> Final output sent to browser
DEBUG - 2018-06-27 17:36:39 --> Total execution time: 0.0226
INFO - 2018-06-27 17:36:39 --> Config Class Initialized
INFO - 2018-06-27 17:36:39 --> Hooks Class Initialized
DEBUG - 2018-06-27 17:36:39 --> UTF-8 Support Enabled
INFO - 2018-06-27 17:36:39 --> Utf8 Class Initialized
INFO - 2018-06-27 17:36:39 --> URI Class Initialized
INFO - 2018-06-27 17:36:39 --> Router Class Initialized
INFO - 2018-06-27 17:36:39 --> Output Class Initialized
INFO - 2018-06-27 17:36:39 --> Security Class Initialized
DEBUG - 2018-06-27 17:36:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 17:36:39 --> CSRF cookie sent
INFO - 2018-06-27 17:36:39 --> Input Class Initialized
INFO - 2018-06-27 17:36:39 --> Language Class Initialized
INFO - 2018-06-27 17:36:39 --> Loader Class Initialized
INFO - 2018-06-27 17:36:39 --> Helper loaded: url_helper
INFO - 2018-06-27 17:36:39 --> Helper loaded: form_helper
INFO - 2018-06-27 17:36:39 --> Helper loaded: language_helper
DEBUG - 2018-06-27 17:36:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 17:36:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 17:36:39 --> User Agent Class Initialized
INFO - 2018-06-27 17:36:39 --> Controller Class Initialized
INFO - 2018-06-27 17:36:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-27 17:36:39 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-27 17:36:39 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-27 17:36:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-27 17:36:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-27 17:36:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-27 17:36:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-27 17:36:39 --> Could not find the language line "req_email"
INFO - 2018-06-27 17:36:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-06-27 17:36:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-27 17:36:39 --> Final output sent to browser
DEBUG - 2018-06-27 17:36:39 --> Total execution time: 0.0244
INFO - 2018-06-27 17:36:39 --> Config Class Initialized
INFO - 2018-06-27 17:36:39 --> Hooks Class Initialized
DEBUG - 2018-06-27 17:36:39 --> UTF-8 Support Enabled
INFO - 2018-06-27 17:36:39 --> Utf8 Class Initialized
INFO - 2018-06-27 17:36:39 --> URI Class Initialized
INFO - 2018-06-27 17:36:39 --> Router Class Initialized
INFO - 2018-06-27 17:36:39 --> Output Class Initialized
INFO - 2018-06-27 17:36:39 --> Security Class Initialized
DEBUG - 2018-06-27 17:36:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 17:36:39 --> CSRF cookie sent
INFO - 2018-06-27 17:36:39 --> Input Class Initialized
INFO - 2018-06-27 17:36:39 --> Language Class Initialized
INFO - 2018-06-27 17:36:39 --> Loader Class Initialized
INFO - 2018-06-27 17:36:39 --> Helper loaded: url_helper
INFO - 2018-06-27 17:36:39 --> Helper loaded: form_helper
INFO - 2018-06-27 17:36:39 --> Helper loaded: language_helper
DEBUG - 2018-06-27 17:36:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 17:36:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 17:36:39 --> User Agent Class Initialized
INFO - 2018-06-27 17:36:39 --> Controller Class Initialized
INFO - 2018-06-27 17:36:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-27 17:36:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-27 17:36:39 --> Pixel_Model class loaded
INFO - 2018-06-27 17:36:39 --> Database Driver Class Initialized
INFO - 2018-06-27 17:36:39 --> Model "QuestionsModel" initialized
INFO - 2018-06-27 17:36:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-27 17:36:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-27 17:36:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-27 17:36:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-27 17:36:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/buy_gift.php
INFO - 2018-06-27 17:36:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-27 17:36:39 --> Final output sent to browser
DEBUG - 2018-06-27 17:36:39 --> Total execution time: 0.0373
INFO - 2018-06-27 18:18:22 --> Config Class Initialized
INFO - 2018-06-27 18:18:22 --> Hooks Class Initialized
DEBUG - 2018-06-27 18:18:22 --> UTF-8 Support Enabled
INFO - 2018-06-27 18:18:22 --> Utf8 Class Initialized
INFO - 2018-06-27 18:18:22 --> URI Class Initialized
DEBUG - 2018-06-27 18:18:22 --> No URI present. Default controller set.
INFO - 2018-06-27 18:18:22 --> Router Class Initialized
INFO - 2018-06-27 18:18:22 --> Output Class Initialized
INFO - 2018-06-27 18:18:22 --> Security Class Initialized
DEBUG - 2018-06-27 18:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 18:18:22 --> CSRF cookie sent
INFO - 2018-06-27 18:18:22 --> Input Class Initialized
INFO - 2018-06-27 18:18:22 --> Language Class Initialized
INFO - 2018-06-27 18:18:22 --> Loader Class Initialized
INFO - 2018-06-27 18:18:22 --> Helper loaded: url_helper
INFO - 2018-06-27 18:18:22 --> Helper loaded: form_helper
INFO - 2018-06-27 18:18:22 --> Helper loaded: language_helper
DEBUG - 2018-06-27 18:18:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 18:18:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 18:18:22 --> User Agent Class Initialized
INFO - 2018-06-27 18:18:22 --> Controller Class Initialized
INFO - 2018-06-27 18:18:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-27 18:18:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-27 18:18:22 --> Pixel_Model class loaded
INFO - 2018-06-27 18:18:22 --> Database Driver Class Initialized
INFO - 2018-06-27 18:18:22 --> Model "QuestionsModel" initialized
INFO - 2018-06-27 18:18:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-27 18:18:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-27 18:18:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-27 18:18:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-27 18:18:22 --> Final output sent to browser
DEBUG - 2018-06-27 18:18:22 --> Total execution time: 0.0364
INFO - 2018-06-27 19:12:47 --> Config Class Initialized
INFO - 2018-06-27 19:12:47 --> Hooks Class Initialized
DEBUG - 2018-06-27 19:12:47 --> UTF-8 Support Enabled
INFO - 2018-06-27 19:12:47 --> Utf8 Class Initialized
INFO - 2018-06-27 19:12:47 --> URI Class Initialized
DEBUG - 2018-06-27 19:12:47 --> No URI present. Default controller set.
INFO - 2018-06-27 19:12:47 --> Router Class Initialized
INFO - 2018-06-27 19:12:47 --> Output Class Initialized
INFO - 2018-06-27 19:12:47 --> Security Class Initialized
DEBUG - 2018-06-27 19:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 19:12:47 --> CSRF cookie sent
INFO - 2018-06-27 19:12:47 --> Input Class Initialized
INFO - 2018-06-27 19:12:47 --> Language Class Initialized
INFO - 2018-06-27 19:12:47 --> Loader Class Initialized
INFO - 2018-06-27 19:12:47 --> Helper loaded: url_helper
INFO - 2018-06-27 19:12:47 --> Helper loaded: form_helper
INFO - 2018-06-27 19:12:47 --> Helper loaded: language_helper
DEBUG - 2018-06-27 19:12:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 19:12:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 19:12:47 --> User Agent Class Initialized
INFO - 2018-06-27 19:12:47 --> Controller Class Initialized
INFO - 2018-06-27 19:12:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-27 19:12:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-27 19:12:47 --> Pixel_Model class loaded
INFO - 2018-06-27 19:12:47 --> Database Driver Class Initialized
INFO - 2018-06-27 19:12:47 --> Model "QuestionsModel" initialized
INFO - 2018-06-27 19:12:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-27 19:12:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-27 19:12:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-27 19:12:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-27 19:12:47 --> Final output sent to browser
DEBUG - 2018-06-27 19:12:47 --> Total execution time: 0.0350
INFO - 2018-06-27 19:33:44 --> Config Class Initialized
INFO - 2018-06-27 19:33:44 --> Hooks Class Initialized
DEBUG - 2018-06-27 19:33:44 --> UTF-8 Support Enabled
INFO - 2018-06-27 19:33:44 --> Utf8 Class Initialized
INFO - 2018-06-27 19:33:44 --> URI Class Initialized
DEBUG - 2018-06-27 19:33:44 --> No URI present. Default controller set.
INFO - 2018-06-27 19:33:44 --> Router Class Initialized
INFO - 2018-06-27 19:33:44 --> Output Class Initialized
INFO - 2018-06-27 19:33:44 --> Security Class Initialized
DEBUG - 2018-06-27 19:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 19:33:44 --> CSRF cookie sent
INFO - 2018-06-27 19:33:44 --> Input Class Initialized
INFO - 2018-06-27 19:33:44 --> Language Class Initialized
INFO - 2018-06-27 19:33:44 --> Loader Class Initialized
INFO - 2018-06-27 19:33:44 --> Helper loaded: url_helper
INFO - 2018-06-27 19:33:44 --> Helper loaded: form_helper
INFO - 2018-06-27 19:33:44 --> Helper loaded: language_helper
DEBUG - 2018-06-27 19:33:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 19:33:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 19:33:44 --> User Agent Class Initialized
INFO - 2018-06-27 19:33:44 --> Controller Class Initialized
INFO - 2018-06-27 19:33:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-27 19:33:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-27 19:33:44 --> Pixel_Model class loaded
INFO - 2018-06-27 19:33:44 --> Database Driver Class Initialized
INFO - 2018-06-27 19:33:44 --> Model "QuestionsModel" initialized
INFO - 2018-06-27 19:33:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-27 19:33:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-27 19:33:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-27 19:33:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-27 19:33:44 --> Final output sent to browser
DEBUG - 2018-06-27 19:33:44 --> Total execution time: 0.0344
INFO - 2018-06-27 20:14:31 --> Config Class Initialized
INFO - 2018-06-27 20:14:31 --> Hooks Class Initialized
DEBUG - 2018-06-27 20:14:31 --> UTF-8 Support Enabled
INFO - 2018-06-27 20:14:31 --> Utf8 Class Initialized
INFO - 2018-06-27 20:14:31 --> URI Class Initialized
INFO - 2018-06-27 20:14:31 --> Router Class Initialized
INFO - 2018-06-27 20:14:31 --> Output Class Initialized
INFO - 2018-06-27 20:14:31 --> Security Class Initialized
DEBUG - 2018-06-27 20:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 20:14:31 --> CSRF cookie sent
INFO - 2018-06-27 20:14:31 --> Input Class Initialized
INFO - 2018-06-27 20:14:31 --> Language Class Initialized
ERROR - 2018-06-27 20:14:31 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-06-27 20:14:34 --> Config Class Initialized
INFO - 2018-06-27 20:14:34 --> Hooks Class Initialized
DEBUG - 2018-06-27 20:14:34 --> UTF-8 Support Enabled
INFO - 2018-06-27 20:14:34 --> Utf8 Class Initialized
INFO - 2018-06-27 20:14:34 --> URI Class Initialized
INFO - 2018-06-27 20:14:34 --> Router Class Initialized
INFO - 2018-06-27 20:14:34 --> Output Class Initialized
INFO - 2018-06-27 20:14:34 --> Security Class Initialized
DEBUG - 2018-06-27 20:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 20:14:34 --> CSRF cookie sent
INFO - 2018-06-27 20:14:34 --> Input Class Initialized
INFO - 2018-06-27 20:14:34 --> Language Class Initialized
INFO - 2018-06-27 20:14:34 --> Loader Class Initialized
INFO - 2018-06-27 20:14:34 --> Helper loaded: url_helper
INFO - 2018-06-27 20:14:34 --> Helper loaded: form_helper
INFO - 2018-06-27 20:14:34 --> Helper loaded: language_helper
DEBUG - 2018-06-27 20:14:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 20:14:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 20:14:34 --> User Agent Class Initialized
INFO - 2018-06-27 20:14:34 --> Controller Class Initialized
INFO - 2018-06-27 20:14:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-27 20:14:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-27 20:14:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-27 20:14:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-27 20:14:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-27 20:14:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-27 20:14:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-06-27 20:14:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-27 20:14:34 --> Final output sent to browser
DEBUG - 2018-06-27 20:14:34 --> Total execution time: 0.0208
INFO - 2018-06-27 20:17:19 --> Config Class Initialized
INFO - 2018-06-27 20:17:19 --> Hooks Class Initialized
DEBUG - 2018-06-27 20:17:19 --> UTF-8 Support Enabled
INFO - 2018-06-27 20:17:19 --> Utf8 Class Initialized
INFO - 2018-06-27 20:17:19 --> URI Class Initialized
DEBUG - 2018-06-27 20:17:19 --> No URI present. Default controller set.
INFO - 2018-06-27 20:17:19 --> Router Class Initialized
INFO - 2018-06-27 20:17:19 --> Output Class Initialized
INFO - 2018-06-27 20:17:19 --> Security Class Initialized
DEBUG - 2018-06-27 20:17:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 20:17:19 --> CSRF cookie sent
INFO - 2018-06-27 20:17:19 --> Input Class Initialized
INFO - 2018-06-27 20:17:19 --> Language Class Initialized
INFO - 2018-06-27 20:17:19 --> Loader Class Initialized
INFO - 2018-06-27 20:17:19 --> Helper loaded: url_helper
INFO - 2018-06-27 20:17:19 --> Helper loaded: form_helper
INFO - 2018-06-27 20:17:19 --> Helper loaded: language_helper
DEBUG - 2018-06-27 20:17:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 20:17:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 20:17:19 --> User Agent Class Initialized
INFO - 2018-06-27 20:17:19 --> Controller Class Initialized
INFO - 2018-06-27 20:17:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-27 20:17:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-27 20:17:19 --> Pixel_Model class loaded
INFO - 2018-06-27 20:17:19 --> Database Driver Class Initialized
INFO - 2018-06-27 20:17:19 --> Model "QuestionsModel" initialized
INFO - 2018-06-27 20:17:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-27 20:17:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-27 20:17:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-27 20:17:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-27 20:17:19 --> Final output sent to browser
DEBUG - 2018-06-27 20:17:19 --> Total execution time: 0.0335
INFO - 2018-06-27 20:21:50 --> Config Class Initialized
INFO - 2018-06-27 20:21:50 --> Hooks Class Initialized
DEBUG - 2018-06-27 20:21:50 --> UTF-8 Support Enabled
INFO - 2018-06-27 20:21:50 --> Utf8 Class Initialized
INFO - 2018-06-27 20:21:50 --> URI Class Initialized
INFO - 2018-06-27 20:21:50 --> Router Class Initialized
INFO - 2018-06-27 20:21:50 --> Output Class Initialized
INFO - 2018-06-27 20:21:50 --> Security Class Initialized
DEBUG - 2018-06-27 20:21:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 20:21:50 --> CSRF cookie sent
INFO - 2018-06-27 20:21:50 --> Input Class Initialized
INFO - 2018-06-27 20:21:50 --> Language Class Initialized
INFO - 2018-06-27 20:21:50 --> Loader Class Initialized
INFO - 2018-06-27 20:21:50 --> Helper loaded: url_helper
INFO - 2018-06-27 20:21:50 --> Helper loaded: form_helper
INFO - 2018-06-27 20:21:50 --> Helper loaded: language_helper
DEBUG - 2018-06-27 20:21:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 20:21:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 20:21:50 --> User Agent Class Initialized
INFO - 2018-06-27 20:21:50 --> Controller Class Initialized
INFO - 2018-06-27 20:21:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-27 20:21:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-27 20:21:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-27 20:21:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-27 20:21:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-27 20:21:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-27 20:21:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-06-27 20:21:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-27 20:21:50 --> Final output sent to browser
DEBUG - 2018-06-27 20:21:50 --> Total execution time: 0.0393
INFO - 2018-06-27 20:32:40 --> Config Class Initialized
INFO - 2018-06-27 20:32:40 --> Hooks Class Initialized
DEBUG - 2018-06-27 20:32:40 --> UTF-8 Support Enabled
INFO - 2018-06-27 20:32:40 --> Utf8 Class Initialized
INFO - 2018-06-27 20:32:40 --> URI Class Initialized
INFO - 2018-06-27 20:32:40 --> Router Class Initialized
INFO - 2018-06-27 20:32:40 --> Output Class Initialized
INFO - 2018-06-27 20:32:40 --> Security Class Initialized
DEBUG - 2018-06-27 20:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 20:32:40 --> CSRF cookie sent
INFO - 2018-06-27 20:32:40 --> Input Class Initialized
INFO - 2018-06-27 20:32:40 --> Language Class Initialized
INFO - 2018-06-27 20:32:40 --> Loader Class Initialized
INFO - 2018-06-27 20:32:40 --> Helper loaded: url_helper
INFO - 2018-06-27 20:32:40 --> Helper loaded: form_helper
INFO - 2018-06-27 20:32:40 --> Helper loaded: language_helper
DEBUG - 2018-06-27 20:32:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 20:32:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 20:32:40 --> User Agent Class Initialized
INFO - 2018-06-27 20:32:40 --> Controller Class Initialized
INFO - 2018-06-27 20:32:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-27 20:32:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-27 20:32:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-27 20:32:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-27 20:32:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-27 20:32:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-27 20:32:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-06-27 20:32:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-27 20:32:40 --> Final output sent to browser
DEBUG - 2018-06-27 20:32:40 --> Total execution time: 0.0212
INFO - 2018-06-27 21:19:58 --> Config Class Initialized
INFO - 2018-06-27 21:19:58 --> Hooks Class Initialized
DEBUG - 2018-06-27 21:19:58 --> UTF-8 Support Enabled
INFO - 2018-06-27 21:19:58 --> Utf8 Class Initialized
INFO - 2018-06-27 21:19:58 --> URI Class Initialized
DEBUG - 2018-06-27 21:19:58 --> No URI present. Default controller set.
INFO - 2018-06-27 21:19:58 --> Router Class Initialized
INFO - 2018-06-27 21:19:58 --> Output Class Initialized
INFO - 2018-06-27 21:19:58 --> Security Class Initialized
DEBUG - 2018-06-27 21:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 21:19:58 --> CSRF cookie sent
INFO - 2018-06-27 21:19:58 --> Input Class Initialized
INFO - 2018-06-27 21:19:58 --> Language Class Initialized
INFO - 2018-06-27 21:19:58 --> Loader Class Initialized
INFO - 2018-06-27 21:19:58 --> Helper loaded: url_helper
INFO - 2018-06-27 21:19:58 --> Helper loaded: form_helper
INFO - 2018-06-27 21:19:58 --> Helper loaded: language_helper
DEBUG - 2018-06-27 21:19:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 21:19:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 21:19:58 --> User Agent Class Initialized
INFO - 2018-06-27 21:19:58 --> Controller Class Initialized
INFO - 2018-06-27 21:19:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-27 21:19:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-27 21:19:58 --> Pixel_Model class loaded
INFO - 2018-06-27 21:19:58 --> Database Driver Class Initialized
INFO - 2018-06-27 21:19:58 --> Model "QuestionsModel" initialized
INFO - 2018-06-27 21:19:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-27 21:19:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-27 21:19:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-27 21:19:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-27 21:19:58 --> Final output sent to browser
DEBUG - 2018-06-27 21:19:58 --> Total execution time: 0.0305

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-06-28 01:04:18 --> Config Class Initialized
INFO - 2018-06-28 01:04:18 --> Hooks Class Initialized
DEBUG - 2018-06-28 01:04:18 --> UTF-8 Support Enabled
INFO - 2018-06-28 01:04:18 --> Utf8 Class Initialized
INFO - 2018-06-28 01:04:18 --> URI Class Initialized
INFO - 2018-06-28 01:04:18 --> Router Class Initialized
INFO - 2018-06-28 01:04:18 --> Output Class Initialized
INFO - 2018-06-28 01:04:18 --> Security Class Initialized
DEBUG - 2018-06-28 01:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-28 01:04:18 --> CSRF cookie sent
INFO - 2018-06-28 01:04:18 --> Input Class Initialized
INFO - 2018-06-28 01:04:18 --> Language Class Initialized
INFO - 2018-06-28 01:04:18 --> Loader Class Initialized
INFO - 2018-06-28 01:04:18 --> Helper loaded: url_helper
INFO - 2018-06-28 01:04:18 --> Helper loaded: form_helper
INFO - 2018-06-28 01:04:18 --> Helper loaded: language_helper
DEBUG - 2018-06-28 01:04:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-28 01:04:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-28 01:04:18 --> User Agent Class Initialized
INFO - 2018-06-28 01:04:18 --> Controller Class Initialized
INFO - 2018-06-28 01:04:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-28 01:04:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-28 01:04:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-28 01:04:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-28 01:04:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-28 01:04:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-28 01:04:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-06-28 01:04:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-28 01:04:18 --> Final output sent to browser
DEBUG - 2018-06-28 01:04:18 --> Total execution time: 0.0232
INFO - 2018-06-28 04:04:17 --> Config Class Initialized
INFO - 2018-06-28 04:04:17 --> Hooks Class Initialized
DEBUG - 2018-06-28 04:04:17 --> UTF-8 Support Enabled
INFO - 2018-06-28 04:04:17 --> Utf8 Class Initialized
INFO - 2018-06-28 04:04:17 --> URI Class Initialized
DEBUG - 2018-06-28 04:04:17 --> No URI present. Default controller set.
INFO - 2018-06-28 04:04:17 --> Router Class Initialized
INFO - 2018-06-28 04:04:17 --> Output Class Initialized
INFO - 2018-06-28 04:04:17 --> Security Class Initialized
DEBUG - 2018-06-28 04:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-28 04:04:17 --> CSRF cookie sent
INFO - 2018-06-28 04:04:17 --> Input Class Initialized
INFO - 2018-06-28 04:04:17 --> Language Class Initialized
INFO - 2018-06-28 04:04:17 --> Loader Class Initialized
INFO - 2018-06-28 04:04:17 --> Helper loaded: url_helper
INFO - 2018-06-28 04:04:17 --> Helper loaded: form_helper
INFO - 2018-06-28 04:04:17 --> Helper loaded: language_helper
DEBUG - 2018-06-28 04:04:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-28 04:04:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-28 04:04:17 --> User Agent Class Initialized
INFO - 2018-06-28 04:04:17 --> Controller Class Initialized
INFO - 2018-06-28 04:04:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-28 04:04:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-28 04:04:17 --> Pixel_Model class loaded
INFO - 2018-06-28 04:04:17 --> Database Driver Class Initialized
INFO - 2018-06-28 04:04:17 --> Model "QuestionsModel" initialized
INFO - 2018-06-28 04:04:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-28 04:04:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-28 04:04:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-28 04:04:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-28 04:04:17 --> Final output sent to browser
DEBUG - 2018-06-28 04:04:17 --> Total execution time: 0.0314
INFO - 2018-06-28 06:44:34 --> Config Class Initialized
INFO - 2018-06-28 06:44:34 --> Hooks Class Initialized
DEBUG - 2018-06-28 06:44:34 --> UTF-8 Support Enabled
INFO - 2018-06-28 06:44:34 --> Utf8 Class Initialized
INFO - 2018-06-28 06:44:34 --> URI Class Initialized
INFO - 2018-06-28 06:44:34 --> Router Class Initialized
INFO - 2018-06-28 06:44:34 --> Output Class Initialized
INFO - 2018-06-28 06:44:34 --> Security Class Initialized
DEBUG - 2018-06-28 06:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-28 06:44:34 --> CSRF cookie sent
INFO - 2018-06-28 06:44:34 --> Input Class Initialized
INFO - 2018-06-28 06:44:34 --> Language Class Initialized
ERROR - 2018-06-28 06:44:34 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-06-28 06:44:37 --> Config Class Initialized
INFO - 2018-06-28 06:44:37 --> Hooks Class Initialized
DEBUG - 2018-06-28 06:44:37 --> UTF-8 Support Enabled
INFO - 2018-06-28 06:44:37 --> Utf8 Class Initialized
INFO - 2018-06-28 06:44:37 --> URI Class Initialized
INFO - 2018-06-28 06:44:37 --> Router Class Initialized
INFO - 2018-06-28 06:44:37 --> Output Class Initialized
INFO - 2018-06-28 06:44:37 --> Security Class Initialized
DEBUG - 2018-06-28 06:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-28 06:44:37 --> CSRF cookie sent
INFO - 2018-06-28 06:44:37 --> Input Class Initialized
INFO - 2018-06-28 06:44:37 --> Language Class Initialized
INFO - 2018-06-28 06:44:37 --> Loader Class Initialized
INFO - 2018-06-28 06:44:37 --> Helper loaded: url_helper
INFO - 2018-06-28 06:44:37 --> Helper loaded: form_helper
INFO - 2018-06-28 06:44:37 --> Helper loaded: language_helper
DEBUG - 2018-06-28 06:44:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-28 06:44:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-28 06:44:37 --> User Agent Class Initialized
INFO - 2018-06-28 06:44:37 --> Controller Class Initialized
INFO - 2018-06-28 06:44:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-28 06:44:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-28 06:44:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-28 06:44:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-28 06:44:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-28 06:44:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-28 06:44:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-06-28 06:44:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-28 06:44:37 --> Final output sent to browser
DEBUG - 2018-06-28 06:44:37 --> Total execution time: 0.0219
INFO - 2018-06-28 10:04:17 --> Config Class Initialized
INFO - 2018-06-28 10:04:17 --> Hooks Class Initialized
DEBUG - 2018-06-28 10:04:17 --> UTF-8 Support Enabled
INFO - 2018-06-28 10:04:17 --> Utf8 Class Initialized
INFO - 2018-06-28 10:04:17 --> URI Class Initialized
DEBUG - 2018-06-28 10:04:17 --> No URI present. Default controller set.
INFO - 2018-06-28 10:04:17 --> Router Class Initialized
INFO - 2018-06-28 10:04:17 --> Output Class Initialized
INFO - 2018-06-28 10:04:17 --> Security Class Initialized
DEBUG - 2018-06-28 10:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-28 10:04:17 --> CSRF cookie sent
INFO - 2018-06-28 10:04:17 --> Input Class Initialized
INFO - 2018-06-28 10:04:17 --> Language Class Initialized
INFO - 2018-06-28 10:04:17 --> Loader Class Initialized
INFO - 2018-06-28 10:04:17 --> Helper loaded: url_helper
INFO - 2018-06-28 10:04:17 --> Helper loaded: form_helper
INFO - 2018-06-28 10:04:17 --> Helper loaded: language_helper
DEBUG - 2018-06-28 10:04:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-28 10:04:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-28 10:04:17 --> User Agent Class Initialized
INFO - 2018-06-28 10:04:17 --> Controller Class Initialized
INFO - 2018-06-28 10:04:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-28 10:04:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-28 10:04:17 --> Pixel_Model class loaded
INFO - 2018-06-28 10:04:17 --> Database Driver Class Initialized
INFO - 2018-06-28 10:04:17 --> Model "QuestionsModel" initialized
INFO - 2018-06-28 10:04:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-28 10:04:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-28 10:04:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-28 10:04:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-28 10:04:17 --> Final output sent to browser
DEBUG - 2018-06-28 10:04:17 --> Total execution time: 0.0409
INFO - 2018-06-28 14:24:11 --> Config Class Initialized
INFO - 2018-06-28 14:24:11 --> Hooks Class Initialized
DEBUG - 2018-06-28 14:24:11 --> UTF-8 Support Enabled
INFO - 2018-06-28 14:24:11 --> Utf8 Class Initialized
INFO - 2018-06-28 14:24:11 --> URI Class Initialized
INFO - 2018-06-28 14:24:11 --> Router Class Initialized
INFO - 2018-06-28 14:24:11 --> Output Class Initialized
INFO - 2018-06-28 14:24:11 --> Security Class Initialized
DEBUG - 2018-06-28 14:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-28 14:24:11 --> CSRF cookie sent
INFO - 2018-06-28 14:24:11 --> Input Class Initialized
INFO - 2018-06-28 14:24:11 --> Language Class Initialized
ERROR - 2018-06-28 14:24:11 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-06-28 15:44:56 --> Config Class Initialized
INFO - 2018-06-28 15:44:56 --> Hooks Class Initialized
DEBUG - 2018-06-28 15:44:56 --> UTF-8 Support Enabled
INFO - 2018-06-28 15:44:56 --> Utf8 Class Initialized
INFO - 2018-06-28 15:44:56 --> URI Class Initialized
DEBUG - 2018-06-28 15:44:56 --> No URI present. Default controller set.
INFO - 2018-06-28 15:44:56 --> Router Class Initialized
INFO - 2018-06-28 15:44:56 --> Output Class Initialized
INFO - 2018-06-28 15:44:56 --> Security Class Initialized
DEBUG - 2018-06-28 15:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-28 15:44:56 --> CSRF cookie sent
INFO - 2018-06-28 15:44:56 --> Input Class Initialized
INFO - 2018-06-28 15:44:56 --> Language Class Initialized
INFO - 2018-06-28 15:44:56 --> Loader Class Initialized
INFO - 2018-06-28 15:44:56 --> Helper loaded: url_helper
INFO - 2018-06-28 15:44:56 --> Helper loaded: form_helper
INFO - 2018-06-28 15:44:56 --> Helper loaded: language_helper
DEBUG - 2018-06-28 15:44:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-28 15:44:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-28 15:44:56 --> User Agent Class Initialized
INFO - 2018-06-28 15:44:56 --> Controller Class Initialized
INFO - 2018-06-28 15:44:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-28 15:44:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-28 15:44:56 --> Pixel_Model class loaded
INFO - 2018-06-28 15:44:56 --> Database Driver Class Initialized
INFO - 2018-06-28 15:44:56 --> Model "QuestionsModel" initialized
INFO - 2018-06-28 15:44:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-28 15:44:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-28 15:44:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-28 15:44:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-28 15:44:56 --> Final output sent to browser
DEBUG - 2018-06-28 15:44:56 --> Total execution time: 0.0391
INFO - 2018-06-28 16:41:45 --> Config Class Initialized
INFO - 2018-06-28 16:41:45 --> Hooks Class Initialized
DEBUG - 2018-06-28 16:41:45 --> UTF-8 Support Enabled
INFO - 2018-06-28 16:41:45 --> Utf8 Class Initialized
INFO - 2018-06-28 16:41:45 --> URI Class Initialized
DEBUG - 2018-06-28 16:41:45 --> No URI present. Default controller set.
INFO - 2018-06-28 16:41:45 --> Router Class Initialized
INFO - 2018-06-28 16:41:45 --> Output Class Initialized
INFO - 2018-06-28 16:41:45 --> Security Class Initialized
DEBUG - 2018-06-28 16:41:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-28 16:41:45 --> CSRF cookie sent
INFO - 2018-06-28 16:41:45 --> Input Class Initialized
INFO - 2018-06-28 16:41:45 --> Language Class Initialized
INFO - 2018-06-28 16:41:45 --> Loader Class Initialized
INFO - 2018-06-28 16:41:45 --> Helper loaded: url_helper
INFO - 2018-06-28 16:41:45 --> Helper loaded: form_helper
INFO - 2018-06-28 16:41:45 --> Helper loaded: language_helper
DEBUG - 2018-06-28 16:41:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-28 16:41:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-28 16:41:45 --> User Agent Class Initialized
INFO - 2018-06-28 16:41:45 --> Controller Class Initialized
INFO - 2018-06-28 16:41:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-28 16:41:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-28 16:41:45 --> Pixel_Model class loaded
INFO - 2018-06-28 16:41:45 --> Database Driver Class Initialized
INFO - 2018-06-28 16:41:45 --> Model "QuestionsModel" initialized
INFO - 2018-06-28 16:41:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-28 16:41:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-28 16:41:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-28 16:41:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-28 16:41:45 --> Final output sent to browser
DEBUG - 2018-06-28 16:41:45 --> Total execution time: 0.0356
INFO - 2018-06-28 16:52:05 --> Config Class Initialized
INFO - 2018-06-28 16:52:05 --> Hooks Class Initialized
DEBUG - 2018-06-28 16:52:05 --> UTF-8 Support Enabled
INFO - 2018-06-28 16:52:05 --> Utf8 Class Initialized
INFO - 2018-06-28 16:52:05 --> URI Class Initialized
INFO - 2018-06-28 16:52:05 --> Router Class Initialized
INFO - 2018-06-28 16:52:05 --> Output Class Initialized
INFO - 2018-06-28 16:52:06 --> Security Class Initialized
DEBUG - 2018-06-28 16:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-28 16:52:06 --> CSRF cookie sent
INFO - 2018-06-28 16:52:06 --> Input Class Initialized
INFO - 2018-06-28 16:52:06 --> Language Class Initialized
ERROR - 2018-06-28 16:52:06 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-06-28 17:26:03 --> Config Class Initialized
INFO - 2018-06-28 17:26:03 --> Hooks Class Initialized
DEBUG - 2018-06-28 17:26:03 --> UTF-8 Support Enabled
INFO - 2018-06-28 17:26:03 --> Utf8 Class Initialized
INFO - 2018-06-28 17:26:03 --> URI Class Initialized
DEBUG - 2018-06-28 17:26:03 --> No URI present. Default controller set.
INFO - 2018-06-28 17:26:03 --> Router Class Initialized
INFO - 2018-06-28 17:26:03 --> Output Class Initialized
INFO - 2018-06-28 17:26:03 --> Security Class Initialized
DEBUG - 2018-06-28 17:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-28 17:26:03 --> CSRF cookie sent
INFO - 2018-06-28 17:26:03 --> Input Class Initialized
INFO - 2018-06-28 17:26:03 --> Language Class Initialized
INFO - 2018-06-28 17:26:03 --> Loader Class Initialized
INFO - 2018-06-28 17:26:03 --> Helper loaded: url_helper
INFO - 2018-06-28 17:26:03 --> Helper loaded: form_helper
INFO - 2018-06-28 17:26:03 --> Helper loaded: language_helper
DEBUG - 2018-06-28 17:26:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-28 17:26:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-28 17:26:03 --> User Agent Class Initialized
INFO - 2018-06-28 17:26:03 --> Controller Class Initialized
INFO - 2018-06-28 17:26:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-28 17:26:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-28 17:26:03 --> Pixel_Model class loaded
INFO - 2018-06-28 17:26:03 --> Database Driver Class Initialized
INFO - 2018-06-28 17:26:03 --> Model "QuestionsModel" initialized
INFO - 2018-06-28 17:26:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-28 17:26:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-28 17:26:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-28 17:26:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-28 17:26:03 --> Final output sent to browser
DEBUG - 2018-06-28 17:26:03 --> Total execution time: 0.0444
INFO - 2018-06-28 17:45:12 --> Config Class Initialized
INFO - 2018-06-28 17:45:12 --> Hooks Class Initialized
DEBUG - 2018-06-28 17:45:12 --> UTF-8 Support Enabled
INFO - 2018-06-28 17:45:12 --> Utf8 Class Initialized
INFO - 2018-06-28 17:45:12 --> URI Class Initialized
DEBUG - 2018-06-28 17:45:12 --> No URI present. Default controller set.
INFO - 2018-06-28 17:45:12 --> Router Class Initialized
INFO - 2018-06-28 17:45:12 --> Output Class Initialized
INFO - 2018-06-28 17:45:12 --> Security Class Initialized
DEBUG - 2018-06-28 17:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-28 17:45:12 --> CSRF cookie sent
INFO - 2018-06-28 17:45:12 --> Input Class Initialized
INFO - 2018-06-28 17:45:12 --> Language Class Initialized
INFO - 2018-06-28 17:45:12 --> Loader Class Initialized
INFO - 2018-06-28 17:45:12 --> Helper loaded: url_helper
INFO - 2018-06-28 17:45:12 --> Helper loaded: form_helper
INFO - 2018-06-28 17:45:12 --> Helper loaded: language_helper
DEBUG - 2018-06-28 17:45:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-28 17:45:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-28 17:45:12 --> User Agent Class Initialized
INFO - 2018-06-28 17:45:12 --> Controller Class Initialized
INFO - 2018-06-28 17:45:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-28 17:45:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-28 17:45:12 --> Pixel_Model class loaded
INFO - 2018-06-28 17:45:12 --> Database Driver Class Initialized
INFO - 2018-06-28 17:45:12 --> Model "QuestionsModel" initialized
INFO - 2018-06-28 17:45:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-28 17:45:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-28 17:45:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-28 17:45:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-28 17:45:12 --> Final output sent to browser
DEBUG - 2018-06-28 17:45:12 --> Total execution time: 0.0332
INFO - 2018-06-28 17:45:13 --> Config Class Initialized
INFO - 2018-06-28 17:45:13 --> Hooks Class Initialized
DEBUG - 2018-06-28 17:45:13 --> UTF-8 Support Enabled
INFO - 2018-06-28 17:45:13 --> Utf8 Class Initialized
INFO - 2018-06-28 17:45:13 --> URI Class Initialized
DEBUG - 2018-06-28 17:45:13 --> No URI present. Default controller set.
INFO - 2018-06-28 17:45:13 --> Router Class Initialized
INFO - 2018-06-28 17:45:13 --> Output Class Initialized
INFO - 2018-06-28 17:45:13 --> Security Class Initialized
DEBUG - 2018-06-28 17:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-28 17:45:13 --> CSRF cookie sent
INFO - 2018-06-28 17:45:13 --> Input Class Initialized
INFO - 2018-06-28 17:45:13 --> Language Class Initialized
INFO - 2018-06-28 17:45:13 --> Loader Class Initialized
INFO - 2018-06-28 17:45:13 --> Helper loaded: url_helper
INFO - 2018-06-28 17:45:13 --> Helper loaded: form_helper
INFO - 2018-06-28 17:45:13 --> Helper loaded: language_helper
DEBUG - 2018-06-28 17:45:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-28 17:45:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-28 17:45:13 --> User Agent Class Initialized
INFO - 2018-06-28 17:45:13 --> Controller Class Initialized
INFO - 2018-06-28 17:45:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-28 17:45:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-28 17:45:13 --> Pixel_Model class loaded
INFO - 2018-06-28 17:45:13 --> Database Driver Class Initialized
INFO - 2018-06-28 17:45:13 --> Model "QuestionsModel" initialized
INFO - 2018-06-28 17:45:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-28 17:45:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-28 17:45:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-28 17:45:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-28 17:45:13 --> Final output sent to browser
DEBUG - 2018-06-28 17:45:13 --> Total execution time: 0.0293
INFO - 2018-06-28 17:45:13 --> Config Class Initialized
INFO - 2018-06-28 17:45:13 --> Hooks Class Initialized
DEBUG - 2018-06-28 17:45:13 --> UTF-8 Support Enabled
INFO - 2018-06-28 17:45:13 --> Utf8 Class Initialized
INFO - 2018-06-28 17:45:13 --> URI Class Initialized
DEBUG - 2018-06-28 17:45:13 --> No URI present. Default controller set.
INFO - 2018-06-28 17:45:13 --> Router Class Initialized
INFO - 2018-06-28 17:45:13 --> Output Class Initialized
INFO - 2018-06-28 17:45:13 --> Security Class Initialized
DEBUG - 2018-06-28 17:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-28 17:45:13 --> CSRF cookie sent
INFO - 2018-06-28 17:45:13 --> Input Class Initialized
INFO - 2018-06-28 17:45:13 --> Language Class Initialized
INFO - 2018-06-28 17:45:13 --> Loader Class Initialized
INFO - 2018-06-28 17:45:13 --> Helper loaded: url_helper
INFO - 2018-06-28 17:45:13 --> Helper loaded: form_helper
INFO - 2018-06-28 17:45:13 --> Helper loaded: language_helper
DEBUG - 2018-06-28 17:45:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-28 17:45:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-28 17:45:13 --> User Agent Class Initialized
INFO - 2018-06-28 17:45:13 --> Controller Class Initialized
INFO - 2018-06-28 17:45:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-28 17:45:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-28 17:45:13 --> Pixel_Model class loaded
INFO - 2018-06-28 17:45:13 --> Database Driver Class Initialized
INFO - 2018-06-28 17:45:13 --> Model "QuestionsModel" initialized
INFO - 2018-06-28 17:45:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-28 17:45:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-28 17:45:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-28 17:45:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-28 17:45:13 --> Final output sent to browser
DEBUG - 2018-06-28 17:45:13 --> Total execution time: 0.0384
INFO - 2018-06-28 17:45:14 --> Config Class Initialized
INFO - 2018-06-28 17:45:14 --> Hooks Class Initialized
DEBUG - 2018-06-28 17:45:14 --> UTF-8 Support Enabled
INFO - 2018-06-28 17:45:14 --> Utf8 Class Initialized
INFO - 2018-06-28 17:45:14 --> URI Class Initialized
INFO - 2018-06-28 17:45:14 --> Router Class Initialized
INFO - 2018-06-28 17:45:14 --> Output Class Initialized
INFO - 2018-06-28 17:45:14 --> Security Class Initialized
DEBUG - 2018-06-28 17:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-28 17:45:14 --> CSRF cookie sent
INFO - 2018-06-28 17:45:14 --> Input Class Initialized
INFO - 2018-06-28 17:45:14 --> Language Class Initialized
ERROR - 2018-06-28 17:45:14 --> 404 Page Not Found: 405shtml/index
INFO - 2018-06-28 17:45:20 --> Config Class Initialized
INFO - 2018-06-28 17:45:20 --> Hooks Class Initialized
DEBUG - 2018-06-28 17:45:20 --> UTF-8 Support Enabled
INFO - 2018-06-28 17:45:20 --> Utf8 Class Initialized
INFO - 2018-06-28 17:45:20 --> URI Class Initialized
DEBUG - 2018-06-28 17:45:20 --> No URI present. Default controller set.
INFO - 2018-06-28 17:45:20 --> Router Class Initialized
INFO - 2018-06-28 17:45:20 --> Output Class Initialized
INFO - 2018-06-28 17:45:20 --> Security Class Initialized
DEBUG - 2018-06-28 17:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-28 17:45:20 --> CSRF cookie sent
INFO - 2018-06-28 17:45:20 --> Input Class Initialized
INFO - 2018-06-28 17:45:20 --> Language Class Initialized
INFO - 2018-06-28 17:45:20 --> Loader Class Initialized
INFO - 2018-06-28 17:45:20 --> Helper loaded: url_helper
INFO - 2018-06-28 17:45:20 --> Helper loaded: form_helper
INFO - 2018-06-28 17:45:20 --> Helper loaded: language_helper
DEBUG - 2018-06-28 17:45:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-28 17:45:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-28 17:45:20 --> User Agent Class Initialized
INFO - 2018-06-28 17:45:20 --> Controller Class Initialized
INFO - 2018-06-28 17:45:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-28 17:45:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-28 17:45:20 --> Pixel_Model class loaded
INFO - 2018-06-28 17:45:20 --> Database Driver Class Initialized
INFO - 2018-06-28 17:45:20 --> Model "QuestionsModel" initialized
INFO - 2018-06-28 17:45:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-28 17:45:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-28 17:45:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-28 17:45:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-28 17:45:20 --> Final output sent to browser
DEBUG - 2018-06-28 17:45:20 --> Total execution time: 0.0380
INFO - 2018-06-28 17:45:21 --> Config Class Initialized
INFO - 2018-06-28 17:45:21 --> Hooks Class Initialized
DEBUG - 2018-06-28 17:45:21 --> UTF-8 Support Enabled
INFO - 2018-06-28 17:45:21 --> Utf8 Class Initialized
INFO - 2018-06-28 17:45:21 --> URI Class Initialized
INFO - 2018-06-28 17:45:21 --> Router Class Initialized
INFO - 2018-06-28 17:45:21 --> Output Class Initialized
INFO - 2018-06-28 17:45:21 --> Security Class Initialized
DEBUG - 2018-06-28 17:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-28 17:45:21 --> CSRF cookie sent
INFO - 2018-06-28 17:45:21 --> Input Class Initialized
INFO - 2018-06-28 17:45:21 --> Language Class Initialized
ERROR - 2018-06-28 17:45:21 --> 404 Page Not Found: 404testpage4525d2fdc/index
INFO - 2018-06-28 17:45:21 --> Config Class Initialized
INFO - 2018-06-28 17:45:21 --> Hooks Class Initialized
DEBUG - 2018-06-28 17:45:21 --> UTF-8 Support Enabled
INFO - 2018-06-28 17:45:21 --> Utf8 Class Initialized
INFO - 2018-06-28 17:45:21 --> URI Class Initialized
INFO - 2018-06-28 17:45:21 --> Router Class Initialized
INFO - 2018-06-28 17:45:21 --> Output Class Initialized
INFO - 2018-06-28 17:45:21 --> Security Class Initialized
DEBUG - 2018-06-28 17:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-28 17:45:21 --> CSRF cookie sent
INFO - 2018-06-28 17:45:21 --> Input Class Initialized
INFO - 2018-06-28 17:45:21 --> Language Class Initialized
ERROR - 2018-06-28 17:45:21 --> 404 Page Not Found: 404javascriptjs/index
INFO - 2018-06-28 17:45:21 --> Config Class Initialized
INFO - 2018-06-28 17:45:21 --> Hooks Class Initialized
DEBUG - 2018-06-28 17:45:21 --> UTF-8 Support Enabled
INFO - 2018-06-28 17:45:21 --> Utf8 Class Initialized
INFO - 2018-06-28 17:45:21 --> URI Class Initialized
INFO - 2018-06-28 17:45:21 --> Router Class Initialized
INFO - 2018-06-28 17:45:21 --> Output Class Initialized
INFO - 2018-06-28 17:45:21 --> Security Class Initialized
DEBUG - 2018-06-28 17:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-28 17:45:21 --> CSRF cookie sent
INFO - 2018-06-28 17:45:21 --> Input Class Initialized
INFO - 2018-06-28 17:45:21 --> Language Class Initialized
INFO - 2018-06-28 17:45:21 --> Loader Class Initialized
INFO - 2018-06-28 17:45:21 --> Helper loaded: url_helper
INFO - 2018-06-28 17:45:21 --> Helper loaded: form_helper
INFO - 2018-06-28 17:45:21 --> Helper loaded: language_helper
DEBUG - 2018-06-28 17:45:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-28 17:45:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-28 17:45:21 --> User Agent Class Initialized
INFO - 2018-06-28 17:45:21 --> Controller Class Initialized
INFO - 2018-06-28 17:45:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-28 17:45:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-28 17:45:21 --> Pixel_Model class loaded
INFO - 2018-06-28 17:45:21 --> Database Driver Class Initialized
INFO - 2018-06-28 17:45:21 --> Model "QuestionsModel" initialized
ERROR - 2018-06-28 17:45:21 --> Severity: Notice --> Undefined index: HTTP_REFERER /home/fxp6bn7rqemh/public_html/application/core/Pixel_Controller.php 87
INFO - 2018-06-28 17:45:21 --> Config Class Initialized
INFO - 2018-06-28 17:45:21 --> Hooks Class Initialized
DEBUG - 2018-06-28 17:45:21 --> UTF-8 Support Enabled
INFO - 2018-06-28 17:45:21 --> Utf8 Class Initialized
INFO - 2018-06-28 17:45:21 --> URI Class Initialized
INFO - 2018-06-28 17:45:21 --> Router Class Initialized
INFO - 2018-06-28 17:45:21 --> Output Class Initialized
INFO - 2018-06-28 17:45:21 --> Security Class Initialized
DEBUG - 2018-06-28 17:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-28 17:45:21 --> CSRF cookie sent
INFO - 2018-06-28 17:45:21 --> Input Class Initialized
INFO - 2018-06-28 17:45:21 --> Language Class Initialized
INFO - 2018-06-28 17:45:21 --> Loader Class Initialized
INFO - 2018-06-28 17:45:21 --> Helper loaded: url_helper
INFO - 2018-06-28 17:45:21 --> Helper loaded: form_helper
INFO - 2018-06-28 17:45:21 --> Helper loaded: language_helper
DEBUG - 2018-06-28 17:45:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-28 17:45:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-28 17:45:21 --> User Agent Class Initialized
INFO - 2018-06-28 17:45:21 --> Controller Class Initialized
INFO - 2018-06-28 17:45:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-28 17:45:21 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-28 17:45:21 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-28 17:45:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-28 17:45:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-28 17:45:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-28 17:45:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-28 17:45:21 --> Could not find the language line "req_email"
INFO - 2018-06-28 17:45:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-06-28 17:45:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-28 17:45:21 --> Final output sent to browser
DEBUG - 2018-06-28 17:45:21 --> Total execution time: 0.0229
INFO - 2018-06-28 17:45:22 --> Config Class Initialized
INFO - 2018-06-28 17:45:22 --> Hooks Class Initialized
DEBUG - 2018-06-28 17:45:22 --> UTF-8 Support Enabled
INFO - 2018-06-28 17:45:22 --> Utf8 Class Initialized
INFO - 2018-06-28 17:45:22 --> URI Class Initialized
INFO - 2018-06-28 17:45:22 --> Router Class Initialized
INFO - 2018-06-28 17:45:22 --> Output Class Initialized
INFO - 2018-06-28 17:45:22 --> Security Class Initialized
DEBUG - 2018-06-28 17:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-28 17:45:22 --> CSRF cookie sent
INFO - 2018-06-28 17:45:22 --> Input Class Initialized
INFO - 2018-06-28 17:45:22 --> Language Class Initialized
INFO - 2018-06-28 17:45:22 --> Loader Class Initialized
INFO - 2018-06-28 17:45:22 --> Helper loaded: url_helper
INFO - 2018-06-28 17:45:22 --> Helper loaded: form_helper
INFO - 2018-06-28 17:45:22 --> Helper loaded: language_helper
DEBUG - 2018-06-28 17:45:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-28 17:45:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-28 17:45:22 --> User Agent Class Initialized
INFO - 2018-06-28 17:45:22 --> Controller Class Initialized
INFO - 2018-06-28 17:45:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-28 17:45:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-28 17:45:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-28 17:45:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-28 17:45:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-28 17:45:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-28 17:45:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-06-28 17:45:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-28 17:45:22 --> Final output sent to browser
DEBUG - 2018-06-28 17:45:22 --> Total execution time: 0.0230
INFO - 2018-06-28 17:45:22 --> Config Class Initialized
INFO - 2018-06-28 17:45:22 --> Hooks Class Initialized
DEBUG - 2018-06-28 17:45:22 --> UTF-8 Support Enabled
INFO - 2018-06-28 17:45:22 --> Utf8 Class Initialized
INFO - 2018-06-28 17:45:22 --> URI Class Initialized
INFO - 2018-06-28 17:45:22 --> Router Class Initialized
INFO - 2018-06-28 17:45:22 --> Output Class Initialized
INFO - 2018-06-28 17:45:22 --> Security Class Initialized
DEBUG - 2018-06-28 17:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-28 17:45:22 --> CSRF cookie sent
INFO - 2018-06-28 17:45:22 --> Input Class Initialized
INFO - 2018-06-28 17:45:22 --> Language Class Initialized
INFO - 2018-06-28 17:45:22 --> Loader Class Initialized
INFO - 2018-06-28 17:45:22 --> Helper loaded: url_helper
INFO - 2018-06-28 17:45:22 --> Helper loaded: form_helper
INFO - 2018-06-28 17:45:22 --> Helper loaded: language_helper
DEBUG - 2018-06-28 17:45:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-28 17:45:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-28 17:45:22 --> User Agent Class Initialized
INFO - 2018-06-28 17:45:22 --> Controller Class Initialized
INFO - 2018-06-28 17:45:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-28 17:45:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-28 17:45:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-28 17:45:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-28 17:45:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-28 17:45:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-28 17:45:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-06-28 17:45:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-28 17:45:22 --> Final output sent to browser
DEBUG - 2018-06-28 17:45:22 --> Total execution time: 0.0217
INFO - 2018-06-28 17:45:22 --> Config Class Initialized
INFO - 2018-06-28 17:45:22 --> Hooks Class Initialized
DEBUG - 2018-06-28 17:45:22 --> UTF-8 Support Enabled
INFO - 2018-06-28 17:45:22 --> Utf8 Class Initialized
INFO - 2018-06-28 17:45:22 --> URI Class Initialized
INFO - 2018-06-28 17:45:22 --> Router Class Initialized
INFO - 2018-06-28 17:45:22 --> Output Class Initialized
INFO - 2018-06-28 17:45:22 --> Security Class Initialized
DEBUG - 2018-06-28 17:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-28 17:45:22 --> CSRF cookie sent
INFO - 2018-06-28 17:45:22 --> Input Class Initialized
INFO - 2018-06-28 17:45:22 --> Language Class Initialized
INFO - 2018-06-28 17:45:22 --> Loader Class Initialized
INFO - 2018-06-28 17:45:22 --> Helper loaded: url_helper
INFO - 2018-06-28 17:45:22 --> Helper loaded: form_helper
INFO - 2018-06-28 17:45:22 --> Helper loaded: language_helper
DEBUG - 2018-06-28 17:45:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-28 17:45:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-28 17:45:22 --> User Agent Class Initialized
INFO - 2018-06-28 17:45:22 --> Controller Class Initialized
INFO - 2018-06-28 17:45:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-28 17:45:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-28 17:45:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-28 17:45:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-28 17:45:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-28 17:45:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-28 17:45:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-06-28 17:45:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-28 17:45:22 --> Final output sent to browser
DEBUG - 2018-06-28 17:45:22 --> Total execution time: 0.0195
INFO - 2018-06-28 17:45:23 --> Config Class Initialized
INFO - 2018-06-28 17:45:23 --> Hooks Class Initialized
DEBUG - 2018-06-28 17:45:23 --> UTF-8 Support Enabled
INFO - 2018-06-28 17:45:23 --> Utf8 Class Initialized
INFO - 2018-06-28 17:45:23 --> URI Class Initialized
INFO - 2018-06-28 17:45:23 --> Router Class Initialized
INFO - 2018-06-28 17:45:23 --> Output Class Initialized
INFO - 2018-06-28 17:45:23 --> Security Class Initialized
DEBUG - 2018-06-28 17:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-28 17:45:23 --> CSRF cookie sent
INFO - 2018-06-28 17:45:23 --> Input Class Initialized
INFO - 2018-06-28 17:45:23 --> Language Class Initialized
INFO - 2018-06-28 17:45:23 --> Loader Class Initialized
INFO - 2018-06-28 17:45:23 --> Helper loaded: url_helper
INFO - 2018-06-28 17:45:23 --> Helper loaded: form_helper
INFO - 2018-06-28 17:45:23 --> Helper loaded: language_helper
DEBUG - 2018-06-28 17:45:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-28 17:45:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-28 17:45:23 --> User Agent Class Initialized
INFO - 2018-06-28 17:45:23 --> Controller Class Initialized
INFO - 2018-06-28 17:45:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-28 17:45:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-28 17:45:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-28 17:45:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-28 17:45:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-28 17:45:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-28 17:45:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-06-28 17:45:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-28 17:45:23 --> Final output sent to browser
DEBUG - 2018-06-28 17:45:23 --> Total execution time: 0.0239
INFO - 2018-06-28 17:45:23 --> Config Class Initialized
INFO - 2018-06-28 17:45:23 --> Hooks Class Initialized
DEBUG - 2018-06-28 17:45:23 --> UTF-8 Support Enabled
INFO - 2018-06-28 17:45:23 --> Utf8 Class Initialized
INFO - 2018-06-28 17:45:23 --> URI Class Initialized
INFO - 2018-06-28 17:45:23 --> Router Class Initialized
INFO - 2018-06-28 17:45:23 --> Output Class Initialized
INFO - 2018-06-28 17:45:23 --> Security Class Initialized
DEBUG - 2018-06-28 17:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-28 17:45:23 --> CSRF cookie sent
INFO - 2018-06-28 17:45:23 --> Input Class Initialized
INFO - 2018-06-28 17:45:23 --> Language Class Initialized
INFO - 2018-06-28 17:45:23 --> Loader Class Initialized
INFO - 2018-06-28 17:45:23 --> Helper loaded: url_helper
INFO - 2018-06-28 17:45:23 --> Helper loaded: form_helper
INFO - 2018-06-28 17:45:23 --> Helper loaded: language_helper
DEBUG - 2018-06-28 17:45:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-28 17:45:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-28 17:45:23 --> User Agent Class Initialized
INFO - 2018-06-28 17:45:23 --> Controller Class Initialized
INFO - 2018-06-28 17:45:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-28 17:45:23 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-28 17:45:23 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-28 17:45:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-28 17:45:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-28 17:45:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-28 17:45:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-28 17:45:23 --> Could not find the language line "req_email"
INFO - 2018-06-28 17:45:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-06-28 17:45:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-28 17:45:23 --> Final output sent to browser
DEBUG - 2018-06-28 17:45:23 --> Total execution time: 0.0279
INFO - 2018-06-28 17:45:23 --> Config Class Initialized
INFO - 2018-06-28 17:45:23 --> Hooks Class Initialized
DEBUG - 2018-06-28 17:45:23 --> UTF-8 Support Enabled
INFO - 2018-06-28 17:45:23 --> Utf8 Class Initialized
INFO - 2018-06-28 17:45:23 --> URI Class Initialized
INFO - 2018-06-28 17:45:23 --> Router Class Initialized
INFO - 2018-06-28 17:45:23 --> Output Class Initialized
INFO - 2018-06-28 17:45:23 --> Security Class Initialized
DEBUG - 2018-06-28 17:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-28 17:45:23 --> CSRF cookie sent
INFO - 2018-06-28 17:45:23 --> Input Class Initialized
INFO - 2018-06-28 17:45:23 --> Language Class Initialized
INFO - 2018-06-28 17:45:23 --> Loader Class Initialized
INFO - 2018-06-28 17:45:23 --> Helper loaded: url_helper
INFO - 2018-06-28 17:45:24 --> Helper loaded: form_helper
INFO - 2018-06-28 17:45:24 --> Helper loaded: language_helper
DEBUG - 2018-06-28 17:45:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-28 17:45:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-28 17:45:24 --> User Agent Class Initialized
INFO - 2018-06-28 17:45:24 --> Controller Class Initialized
INFO - 2018-06-28 17:45:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-28 17:45:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-28 17:45:24 --> Pixel_Model class loaded
INFO - 2018-06-28 17:45:24 --> Database Driver Class Initialized
INFO - 2018-06-28 17:45:24 --> Model "QuestionsModel" initialized
INFO - 2018-06-28 17:45:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-28 17:45:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-28 17:45:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-28 17:45:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-28 17:45:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/buy_gift.php
INFO - 2018-06-28 17:45:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-28 17:45:24 --> Final output sent to browser
DEBUG - 2018-06-28 17:45:24 --> Total execution time: 0.0469
INFO - 2018-06-28 17:47:48 --> Config Class Initialized
INFO - 2018-06-28 17:47:48 --> Hooks Class Initialized
DEBUG - 2018-06-28 17:47:48 --> UTF-8 Support Enabled
INFO - 2018-06-28 17:47:48 --> Utf8 Class Initialized
INFO - 2018-06-28 17:47:48 --> URI Class Initialized
DEBUG - 2018-06-28 17:47:48 --> No URI present. Default controller set.
INFO - 2018-06-28 17:47:48 --> Router Class Initialized
INFO - 2018-06-28 17:47:48 --> Output Class Initialized
INFO - 2018-06-28 17:47:48 --> Security Class Initialized
DEBUG - 2018-06-28 17:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-28 17:47:48 --> CSRF cookie sent
INFO - 2018-06-28 17:47:48 --> Input Class Initialized
INFO - 2018-06-28 17:47:48 --> Language Class Initialized
INFO - 2018-06-28 17:47:48 --> Loader Class Initialized
INFO - 2018-06-28 17:47:48 --> Helper loaded: url_helper
INFO - 2018-06-28 17:47:48 --> Helper loaded: form_helper
INFO - 2018-06-28 17:47:48 --> Helper loaded: language_helper
DEBUG - 2018-06-28 17:47:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-28 17:47:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-28 17:47:48 --> User Agent Class Initialized
INFO - 2018-06-28 17:47:48 --> Controller Class Initialized
INFO - 2018-06-28 17:47:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-28 17:47:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-28 17:47:48 --> Pixel_Model class loaded
INFO - 2018-06-28 17:47:48 --> Database Driver Class Initialized
INFO - 2018-06-28 17:47:48 --> Model "QuestionsModel" initialized
INFO - 2018-06-28 17:47:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-28 17:47:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-28 17:47:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-28 17:47:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-28 17:47:48 --> Final output sent to browser
DEBUG - 2018-06-28 17:47:48 --> Total execution time: 0.0333
INFO - 2018-06-28 18:40:20 --> Config Class Initialized
INFO - 2018-06-28 18:40:20 --> Hooks Class Initialized
DEBUG - 2018-06-28 18:40:20 --> UTF-8 Support Enabled
INFO - 2018-06-28 18:40:20 --> Utf8 Class Initialized
INFO - 2018-06-28 18:40:20 --> URI Class Initialized
INFO - 2018-06-28 18:40:20 --> Router Class Initialized
INFO - 2018-06-28 18:40:20 --> Output Class Initialized
INFO - 2018-06-28 18:40:20 --> Security Class Initialized
DEBUG - 2018-06-28 18:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-28 18:40:20 --> CSRF cookie sent
INFO - 2018-06-28 18:40:20 --> Input Class Initialized
INFO - 2018-06-28 18:40:20 --> Language Class Initialized
ERROR - 2018-06-28 18:40:20 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-06-28 18:40:23 --> Config Class Initialized
INFO - 2018-06-28 18:40:23 --> Hooks Class Initialized
DEBUG - 2018-06-28 18:40:23 --> UTF-8 Support Enabled
INFO - 2018-06-28 18:40:23 --> Utf8 Class Initialized
INFO - 2018-06-28 18:40:23 --> URI Class Initialized
DEBUG - 2018-06-28 18:40:23 --> No URI present. Default controller set.
INFO - 2018-06-28 18:40:23 --> Router Class Initialized
INFO - 2018-06-28 18:40:23 --> Output Class Initialized
INFO - 2018-06-28 18:40:23 --> Security Class Initialized
DEBUG - 2018-06-28 18:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-28 18:40:23 --> CSRF cookie sent
INFO - 2018-06-28 18:40:23 --> Input Class Initialized
INFO - 2018-06-28 18:40:23 --> Language Class Initialized
INFO - 2018-06-28 18:40:23 --> Loader Class Initialized
INFO - 2018-06-28 18:40:23 --> Helper loaded: url_helper
INFO - 2018-06-28 18:40:23 --> Helper loaded: form_helper
INFO - 2018-06-28 18:40:23 --> Helper loaded: language_helper
DEBUG - 2018-06-28 18:40:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-28 18:40:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-28 18:40:23 --> User Agent Class Initialized
INFO - 2018-06-28 18:40:23 --> Controller Class Initialized
INFO - 2018-06-28 18:40:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-28 18:40:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-28 18:40:23 --> Pixel_Model class loaded
INFO - 2018-06-28 18:40:23 --> Database Driver Class Initialized
INFO - 2018-06-28 18:40:23 --> Model "QuestionsModel" initialized
INFO - 2018-06-28 18:40:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-28 18:40:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-28 18:40:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-28 18:40:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-28 18:40:23 --> Final output sent to browser
DEBUG - 2018-06-28 18:40:23 --> Total execution time: 0.0315
INFO - 2018-06-28 19:35:52 --> Config Class Initialized
INFO - 2018-06-28 19:35:52 --> Hooks Class Initialized
DEBUG - 2018-06-28 19:35:52 --> UTF-8 Support Enabled
INFO - 2018-06-28 19:35:52 --> Utf8 Class Initialized
INFO - 2018-06-28 19:35:52 --> URI Class Initialized
INFO - 2018-06-28 19:35:52 --> Router Class Initialized
INFO - 2018-06-28 19:35:52 --> Output Class Initialized
INFO - 2018-06-28 19:35:52 --> Security Class Initialized
DEBUG - 2018-06-28 19:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-28 19:35:52 --> CSRF cookie sent
INFO - 2018-06-28 19:35:52 --> Input Class Initialized
INFO - 2018-06-28 19:35:52 --> Language Class Initialized
ERROR - 2018-06-28 19:35:52 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-06-28 19:35:52 --> Config Class Initialized
INFO - 2018-06-28 19:35:52 --> Hooks Class Initialized
DEBUG - 2018-06-28 19:35:52 --> UTF-8 Support Enabled
INFO - 2018-06-28 19:35:52 --> Utf8 Class Initialized
INFO - 2018-06-28 19:35:52 --> URI Class Initialized
INFO - 2018-06-28 19:35:52 --> Router Class Initialized
INFO - 2018-06-28 19:35:52 --> Output Class Initialized
INFO - 2018-06-28 19:35:52 --> Security Class Initialized
DEBUG - 2018-06-28 19:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-28 19:35:52 --> CSRF cookie sent
INFO - 2018-06-28 19:35:52 --> Input Class Initialized
INFO - 2018-06-28 19:35:52 --> Language Class Initialized
INFO - 2018-06-28 19:35:52 --> Loader Class Initialized
INFO - 2018-06-28 19:35:52 --> Helper loaded: url_helper
INFO - 2018-06-28 19:35:52 --> Helper loaded: form_helper
INFO - 2018-06-28 19:35:52 --> Helper loaded: language_helper
DEBUG - 2018-06-28 19:35:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-28 19:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-28 19:35:52 --> User Agent Class Initialized
INFO - 2018-06-28 19:35:52 --> Controller Class Initialized
INFO - 2018-06-28 19:35:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-28 19:35:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-28 19:35:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-28 19:35:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-28 19:35:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-28 19:35:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-28 19:35:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-06-28 19:35:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-28 19:35:52 --> Final output sent to browser
DEBUG - 2018-06-28 19:35:52 --> Total execution time: 0.0319

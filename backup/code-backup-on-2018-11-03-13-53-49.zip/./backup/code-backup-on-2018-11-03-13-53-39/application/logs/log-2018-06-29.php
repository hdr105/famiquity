<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-06-29 00:51:35 --> Config Class Initialized
INFO - 2018-06-29 00:51:35 --> Hooks Class Initialized
DEBUG - 2018-06-29 00:51:35 --> UTF-8 Support Enabled
INFO - 2018-06-29 00:51:35 --> Utf8 Class Initialized
INFO - 2018-06-29 00:51:35 --> URI Class Initialized
INFO - 2018-06-29 00:51:35 --> Router Class Initialized
INFO - 2018-06-29 00:51:35 --> Output Class Initialized
INFO - 2018-06-29 00:51:35 --> Security Class Initialized
DEBUG - 2018-06-29 00:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 00:51:35 --> CSRF cookie sent
INFO - 2018-06-29 00:51:35 --> Input Class Initialized
INFO - 2018-06-29 00:51:35 --> Language Class Initialized
INFO - 2018-06-29 00:51:35 --> Loader Class Initialized
INFO - 2018-06-29 00:51:35 --> Helper loaded: url_helper
INFO - 2018-06-29 00:51:35 --> Helper loaded: form_helper
INFO - 2018-06-29 00:51:35 --> Helper loaded: language_helper
DEBUG - 2018-06-29 00:51:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 00:51:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 00:51:35 --> User Agent Class Initialized
INFO - 2018-06-29 00:51:35 --> Controller Class Initialized
INFO - 2018-06-29 00:51:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 00:51:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 00:51:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 00:51:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 00:51:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 00:51:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 00:51:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-06-29 00:51:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 00:51:35 --> Final output sent to browser
DEBUG - 2018-06-29 00:51:35 --> Total execution time: 0.0268
INFO - 2018-06-29 01:47:28 --> Config Class Initialized
INFO - 2018-06-29 01:47:28 --> Hooks Class Initialized
DEBUG - 2018-06-29 01:47:28 --> UTF-8 Support Enabled
INFO - 2018-06-29 01:47:28 --> Utf8 Class Initialized
INFO - 2018-06-29 01:47:28 --> URI Class Initialized
DEBUG - 2018-06-29 01:47:28 --> No URI present. Default controller set.
INFO - 2018-06-29 01:47:28 --> Router Class Initialized
INFO - 2018-06-29 01:47:28 --> Output Class Initialized
INFO - 2018-06-29 01:47:28 --> Security Class Initialized
DEBUG - 2018-06-29 01:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 01:47:28 --> CSRF cookie sent
INFO - 2018-06-29 01:47:28 --> Input Class Initialized
INFO - 2018-06-29 01:47:28 --> Language Class Initialized
INFO - 2018-06-29 01:47:28 --> Loader Class Initialized
INFO - 2018-06-29 01:47:28 --> Helper loaded: url_helper
INFO - 2018-06-29 01:47:28 --> Helper loaded: form_helper
INFO - 2018-06-29 01:47:28 --> Helper loaded: language_helper
DEBUG - 2018-06-29 01:47:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 01:47:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 01:47:28 --> User Agent Class Initialized
INFO - 2018-06-29 01:47:28 --> Controller Class Initialized
INFO - 2018-06-29 01:47:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 01:47:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 01:47:28 --> Pixel_Model class loaded
INFO - 2018-06-29 01:47:28 --> Database Driver Class Initialized
INFO - 2018-06-29 01:47:28 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 01:47:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 01:47:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 01:47:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-29 01:47:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 01:47:28 --> Final output sent to browser
DEBUG - 2018-06-29 01:47:28 --> Total execution time: 0.0370
INFO - 2018-06-29 07:01:24 --> Config Class Initialized
INFO - 2018-06-29 07:01:24 --> Hooks Class Initialized
DEBUG - 2018-06-29 07:01:24 --> UTF-8 Support Enabled
INFO - 2018-06-29 07:01:24 --> Utf8 Class Initialized
INFO - 2018-06-29 07:01:24 --> URI Class Initialized
DEBUG - 2018-06-29 07:01:24 --> No URI present. Default controller set.
INFO - 2018-06-29 07:01:24 --> Router Class Initialized
INFO - 2018-06-29 07:01:24 --> Output Class Initialized
INFO - 2018-06-29 07:01:24 --> Security Class Initialized
DEBUG - 2018-06-29 07:01:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 07:01:24 --> CSRF cookie sent
INFO - 2018-06-29 07:01:24 --> Input Class Initialized
INFO - 2018-06-29 07:01:24 --> Language Class Initialized
INFO - 2018-06-29 07:01:24 --> Loader Class Initialized
INFO - 2018-06-29 07:01:24 --> Helper loaded: url_helper
INFO - 2018-06-29 07:01:24 --> Helper loaded: form_helper
INFO - 2018-06-29 07:01:24 --> Helper loaded: language_helper
DEBUG - 2018-06-29 07:01:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 07:01:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 07:01:24 --> User Agent Class Initialized
INFO - 2018-06-29 07:01:24 --> Controller Class Initialized
INFO - 2018-06-29 07:01:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 07:01:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 07:01:24 --> Pixel_Model class loaded
INFO - 2018-06-29 07:01:24 --> Database Driver Class Initialized
INFO - 2018-06-29 07:01:24 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 07:01:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 07:01:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 07:01:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-29 07:01:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 07:01:24 --> Final output sent to browser
DEBUG - 2018-06-29 07:01:24 --> Total execution time: 0.0381
INFO - 2018-06-29 07:07:48 --> Config Class Initialized
INFO - 2018-06-29 07:07:48 --> Hooks Class Initialized
DEBUG - 2018-06-29 07:07:48 --> UTF-8 Support Enabled
INFO - 2018-06-29 07:07:48 --> Utf8 Class Initialized
INFO - 2018-06-29 07:07:48 --> URI Class Initialized
INFO - 2018-06-29 07:07:48 --> Router Class Initialized
INFO - 2018-06-29 07:07:48 --> Output Class Initialized
INFO - 2018-06-29 07:07:48 --> Security Class Initialized
DEBUG - 2018-06-29 07:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 07:07:48 --> CSRF cookie sent
INFO - 2018-06-29 07:07:48 --> Input Class Initialized
INFO - 2018-06-29 07:07:48 --> Language Class Initialized
INFO - 2018-06-29 07:07:48 --> Loader Class Initialized
INFO - 2018-06-29 07:07:48 --> Helper loaded: url_helper
INFO - 2018-06-29 07:07:48 --> Helper loaded: form_helper
INFO - 2018-06-29 07:07:48 --> Helper loaded: language_helper
DEBUG - 2018-06-29 07:07:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 07:07:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 07:07:48 --> User Agent Class Initialized
INFO - 2018-06-29 07:07:48 --> Controller Class Initialized
INFO - 2018-06-29 07:07:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 07:07:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 07:07:48 --> Pixel_Model class loaded
INFO - 2018-06-29 07:07:48 --> Database Driver Class Initialized
INFO - 2018-06-29 07:07:48 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 07:07:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 07:07:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 07:07:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 07:07:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 07:07:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/buy_gift.php
INFO - 2018-06-29 07:07:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 07:07:48 --> Final output sent to browser
DEBUG - 2018-06-29 07:07:48 --> Total execution time: 0.0353
INFO - 2018-06-29 07:40:16 --> Config Class Initialized
INFO - 2018-06-29 07:40:16 --> Hooks Class Initialized
DEBUG - 2018-06-29 07:40:16 --> UTF-8 Support Enabled
INFO - 2018-06-29 07:40:16 --> Utf8 Class Initialized
INFO - 2018-06-29 07:40:16 --> URI Class Initialized
INFO - 2018-06-29 07:40:16 --> Router Class Initialized
INFO - 2018-06-29 07:40:16 --> Output Class Initialized
INFO - 2018-06-29 07:40:16 --> Security Class Initialized
DEBUG - 2018-06-29 07:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 07:40:16 --> CSRF cookie sent
INFO - 2018-06-29 07:40:16 --> Input Class Initialized
INFO - 2018-06-29 07:40:16 --> Language Class Initialized
ERROR - 2018-06-29 07:40:16 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-06-29 09:33:43 --> Config Class Initialized
INFO - 2018-06-29 09:33:43 --> Hooks Class Initialized
DEBUG - 2018-06-29 09:33:43 --> UTF-8 Support Enabled
INFO - 2018-06-29 09:33:43 --> Utf8 Class Initialized
INFO - 2018-06-29 09:33:43 --> URI Class Initialized
INFO - 2018-06-29 09:33:43 --> Router Class Initialized
INFO - 2018-06-29 09:33:43 --> Output Class Initialized
INFO - 2018-06-29 09:33:43 --> Security Class Initialized
DEBUG - 2018-06-29 09:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 09:33:43 --> CSRF cookie sent
INFO - 2018-06-29 09:33:43 --> Input Class Initialized
INFO - 2018-06-29 09:33:43 --> Language Class Initialized
ERROR - 2018-06-29 09:33:43 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-06-29 09:33:46 --> Config Class Initialized
INFO - 2018-06-29 09:33:46 --> Hooks Class Initialized
DEBUG - 2018-06-29 09:33:46 --> UTF-8 Support Enabled
INFO - 2018-06-29 09:33:46 --> Utf8 Class Initialized
INFO - 2018-06-29 09:33:46 --> URI Class Initialized
DEBUG - 2018-06-29 09:33:46 --> No URI present. Default controller set.
INFO - 2018-06-29 09:33:46 --> Router Class Initialized
INFO - 2018-06-29 09:33:46 --> Output Class Initialized
INFO - 2018-06-29 09:33:46 --> Security Class Initialized
DEBUG - 2018-06-29 09:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 09:33:46 --> CSRF cookie sent
INFO - 2018-06-29 09:33:46 --> Input Class Initialized
INFO - 2018-06-29 09:33:46 --> Language Class Initialized
INFO - 2018-06-29 09:33:46 --> Loader Class Initialized
INFO - 2018-06-29 09:33:46 --> Helper loaded: url_helper
INFO - 2018-06-29 09:33:46 --> Helper loaded: form_helper
INFO - 2018-06-29 09:33:46 --> Helper loaded: language_helper
DEBUG - 2018-06-29 09:33:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 09:33:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 09:33:46 --> User Agent Class Initialized
INFO - 2018-06-29 09:33:46 --> Controller Class Initialized
INFO - 2018-06-29 09:33:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 09:33:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 09:33:46 --> Pixel_Model class loaded
INFO - 2018-06-29 09:33:46 --> Database Driver Class Initialized
INFO - 2018-06-29 09:33:46 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 09:33:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 09:33:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 09:33:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-29 09:33:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 09:33:46 --> Final output sent to browser
DEBUG - 2018-06-29 09:33:46 --> Total execution time: 0.0317
INFO - 2018-06-29 09:46:42 --> Config Class Initialized
INFO - 2018-06-29 09:46:42 --> Hooks Class Initialized
DEBUG - 2018-06-29 09:46:42 --> UTF-8 Support Enabled
INFO - 2018-06-29 09:46:42 --> Utf8 Class Initialized
INFO - 2018-06-29 09:46:42 --> URI Class Initialized
DEBUG - 2018-06-29 09:46:42 --> No URI present. Default controller set.
INFO - 2018-06-29 09:46:42 --> Router Class Initialized
INFO - 2018-06-29 09:46:42 --> Output Class Initialized
INFO - 2018-06-29 09:46:42 --> Security Class Initialized
DEBUG - 2018-06-29 09:46:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 09:46:42 --> CSRF cookie sent
INFO - 2018-06-29 09:46:42 --> Input Class Initialized
INFO - 2018-06-29 09:46:42 --> Language Class Initialized
INFO - 2018-06-29 09:46:42 --> Loader Class Initialized
INFO - 2018-06-29 09:46:42 --> Helper loaded: url_helper
INFO - 2018-06-29 09:46:42 --> Helper loaded: form_helper
INFO - 2018-06-29 09:46:42 --> Helper loaded: language_helper
DEBUG - 2018-06-29 09:46:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 09:46:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 09:46:42 --> User Agent Class Initialized
INFO - 2018-06-29 09:46:42 --> Controller Class Initialized
INFO - 2018-06-29 09:46:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 09:46:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 09:46:42 --> Pixel_Model class loaded
INFO - 2018-06-29 09:46:42 --> Database Driver Class Initialized
INFO - 2018-06-29 09:46:42 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 09:46:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 09:46:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 09:46:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-29 09:46:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 09:46:42 --> Final output sent to browser
DEBUG - 2018-06-29 09:46:42 --> Total execution time: 0.0365
INFO - 2018-06-29 15:00:45 --> Config Class Initialized
INFO - 2018-06-29 15:00:45 --> Hooks Class Initialized
DEBUG - 2018-06-29 15:00:45 --> UTF-8 Support Enabled
INFO - 2018-06-29 15:00:45 --> Utf8 Class Initialized
INFO - 2018-06-29 15:00:45 --> URI Class Initialized
DEBUG - 2018-06-29 15:00:45 --> No URI present. Default controller set.
INFO - 2018-06-29 15:00:45 --> Router Class Initialized
INFO - 2018-06-29 15:00:45 --> Output Class Initialized
INFO - 2018-06-29 15:00:45 --> Security Class Initialized
DEBUG - 2018-06-29 15:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 15:00:45 --> CSRF cookie sent
INFO - 2018-06-29 15:00:45 --> Input Class Initialized
INFO - 2018-06-29 15:00:45 --> Language Class Initialized
INFO - 2018-06-29 15:00:45 --> Loader Class Initialized
INFO - 2018-06-29 15:00:45 --> Helper loaded: url_helper
INFO - 2018-06-29 15:00:45 --> Helper loaded: form_helper
INFO - 2018-06-29 15:00:45 --> Helper loaded: language_helper
DEBUG - 2018-06-29 15:00:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 15:00:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 15:00:45 --> User Agent Class Initialized
INFO - 2018-06-29 15:00:45 --> Controller Class Initialized
INFO - 2018-06-29 15:00:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 15:00:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 15:00:45 --> Pixel_Model class loaded
INFO - 2018-06-29 15:00:45 --> Database Driver Class Initialized
INFO - 2018-06-29 15:00:45 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 15:00:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 15:00:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 15:00:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-29 15:00:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 15:00:45 --> Final output sent to browser
DEBUG - 2018-06-29 15:00:45 --> Total execution time: 0.0331
INFO - 2018-06-29 15:00:52 --> Config Class Initialized
INFO - 2018-06-29 15:00:52 --> Hooks Class Initialized
DEBUG - 2018-06-29 15:00:52 --> UTF-8 Support Enabled
INFO - 2018-06-29 15:00:52 --> Utf8 Class Initialized
INFO - 2018-06-29 15:00:52 --> URI Class Initialized
INFO - 2018-06-29 15:00:52 --> Router Class Initialized
INFO - 2018-06-29 15:00:52 --> Output Class Initialized
INFO - 2018-06-29 15:00:52 --> Security Class Initialized
DEBUG - 2018-06-29 15:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 15:00:52 --> CSRF cookie sent
INFO - 2018-06-29 15:00:52 --> CSRF token verified
INFO - 2018-06-29 15:00:52 --> Input Class Initialized
INFO - 2018-06-29 15:00:52 --> Language Class Initialized
INFO - 2018-06-29 15:00:52 --> Loader Class Initialized
INFO - 2018-06-29 15:00:52 --> Helper loaded: url_helper
INFO - 2018-06-29 15:00:52 --> Helper loaded: form_helper
INFO - 2018-06-29 15:00:52 --> Helper loaded: language_helper
DEBUG - 2018-06-29 15:00:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 15:00:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 15:00:52 --> User Agent Class Initialized
INFO - 2018-06-29 15:00:52 --> Controller Class Initialized
INFO - 2018-06-29 15:00:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 15:00:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 15:00:52 --> Pixel_Model class loaded
INFO - 2018-06-29 15:00:52 --> Database Driver Class Initialized
INFO - 2018-06-29 15:00:52 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 15:00:52 --> Config Class Initialized
INFO - 2018-06-29 15:00:52 --> Hooks Class Initialized
DEBUG - 2018-06-29 15:00:52 --> UTF-8 Support Enabled
INFO - 2018-06-29 15:00:52 --> Utf8 Class Initialized
INFO - 2018-06-29 15:00:52 --> URI Class Initialized
INFO - 2018-06-29 15:00:52 --> Router Class Initialized
INFO - 2018-06-29 15:00:52 --> Output Class Initialized
INFO - 2018-06-29 15:00:52 --> Security Class Initialized
DEBUG - 2018-06-29 15:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 15:00:52 --> CSRF cookie sent
INFO - 2018-06-29 15:00:52 --> Input Class Initialized
INFO - 2018-06-29 15:00:52 --> Language Class Initialized
INFO - 2018-06-29 15:00:52 --> Loader Class Initialized
INFO - 2018-06-29 15:00:52 --> Helper loaded: url_helper
INFO - 2018-06-29 15:00:52 --> Helper loaded: form_helper
INFO - 2018-06-29 15:00:52 --> Helper loaded: language_helper
DEBUG - 2018-06-29 15:00:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 15:00:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 15:00:52 --> User Agent Class Initialized
INFO - 2018-06-29 15:00:52 --> Controller Class Initialized
INFO - 2018-06-29 15:00:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 15:00:52 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-29 15:00:52 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-29 15:00:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 15:00:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 15:00:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 15:00:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-29 15:00:52 --> Could not find the language line "req_email"
INFO - 2018-06-29 15:00:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-06-29 15:00:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 15:00:52 --> Final output sent to browser
DEBUG - 2018-06-29 15:00:52 --> Total execution time: 0.0233
INFO - 2018-06-29 16:57:35 --> Config Class Initialized
INFO - 2018-06-29 16:57:35 --> Hooks Class Initialized
DEBUG - 2018-06-29 16:57:35 --> UTF-8 Support Enabled
INFO - 2018-06-29 16:57:35 --> Utf8 Class Initialized
INFO - 2018-06-29 16:57:35 --> URI Class Initialized
INFO - 2018-06-29 16:57:35 --> Router Class Initialized
INFO - 2018-06-29 16:57:35 --> Output Class Initialized
INFO - 2018-06-29 16:57:35 --> Security Class Initialized
DEBUG - 2018-06-29 16:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 16:57:35 --> CSRF cookie sent
INFO - 2018-06-29 16:57:35 --> Input Class Initialized
INFO - 2018-06-29 16:57:35 --> Language Class Initialized
ERROR - 2018-06-29 16:57:35 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-06-29 17:31:03 --> Config Class Initialized
INFO - 2018-06-29 17:31:03 --> Hooks Class Initialized
DEBUG - 2018-06-29 17:31:03 --> UTF-8 Support Enabled
INFO - 2018-06-29 17:31:03 --> Utf8 Class Initialized
INFO - 2018-06-29 17:31:03 --> URI Class Initialized
DEBUG - 2018-06-29 17:31:03 --> No URI present. Default controller set.
INFO - 2018-06-29 17:31:03 --> Router Class Initialized
INFO - 2018-06-29 17:31:03 --> Output Class Initialized
INFO - 2018-06-29 17:31:03 --> Security Class Initialized
DEBUG - 2018-06-29 17:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 17:31:03 --> CSRF cookie sent
INFO - 2018-06-29 17:31:03 --> Input Class Initialized
INFO - 2018-06-29 17:31:03 --> Language Class Initialized
INFO - 2018-06-29 17:31:03 --> Loader Class Initialized
INFO - 2018-06-29 17:31:03 --> Helper loaded: url_helper
INFO - 2018-06-29 17:31:03 --> Helper loaded: form_helper
INFO - 2018-06-29 17:31:03 --> Helper loaded: language_helper
DEBUG - 2018-06-29 17:31:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 17:31:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 17:31:03 --> User Agent Class Initialized
INFO - 2018-06-29 17:31:03 --> Controller Class Initialized
INFO - 2018-06-29 17:31:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 17:31:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 17:31:03 --> Pixel_Model class loaded
INFO - 2018-06-29 17:31:03 --> Database Driver Class Initialized
INFO - 2018-06-29 17:31:03 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 17:31:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 17:31:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 17:31:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-29 17:31:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 17:31:03 --> Final output sent to browser
DEBUG - 2018-06-29 17:31:03 --> Total execution time: 0.0358
INFO - 2018-06-29 17:47:17 --> Config Class Initialized
INFO - 2018-06-29 17:47:17 --> Hooks Class Initialized
DEBUG - 2018-06-29 17:47:17 --> UTF-8 Support Enabled
INFO - 2018-06-29 17:47:17 --> Utf8 Class Initialized
INFO - 2018-06-29 17:47:17 --> URI Class Initialized
DEBUG - 2018-06-29 17:47:17 --> No URI present. Default controller set.
INFO - 2018-06-29 17:47:17 --> Router Class Initialized
INFO - 2018-06-29 17:47:17 --> Output Class Initialized
INFO - 2018-06-29 17:47:17 --> Security Class Initialized
DEBUG - 2018-06-29 17:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 17:47:17 --> CSRF cookie sent
INFO - 2018-06-29 17:47:17 --> Input Class Initialized
INFO - 2018-06-29 17:47:17 --> Language Class Initialized
INFO - 2018-06-29 17:47:17 --> Loader Class Initialized
INFO - 2018-06-29 17:47:17 --> Helper loaded: url_helper
INFO - 2018-06-29 17:47:17 --> Helper loaded: form_helper
INFO - 2018-06-29 17:47:17 --> Helper loaded: language_helper
DEBUG - 2018-06-29 17:47:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 17:47:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 17:47:17 --> User Agent Class Initialized
INFO - 2018-06-29 17:47:17 --> Controller Class Initialized
INFO - 2018-06-29 17:47:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 17:47:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 17:47:17 --> Pixel_Model class loaded
INFO - 2018-06-29 17:47:17 --> Database Driver Class Initialized
INFO - 2018-06-29 17:47:17 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 17:47:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 17:47:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 17:47:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-29 17:47:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 17:47:17 --> Final output sent to browser
DEBUG - 2018-06-29 17:47:17 --> Total execution time: 0.0304
INFO - 2018-06-29 17:47:18 --> Config Class Initialized
INFO - 2018-06-29 17:47:18 --> Hooks Class Initialized
DEBUG - 2018-06-29 17:47:18 --> UTF-8 Support Enabled
INFO - 2018-06-29 17:47:18 --> Utf8 Class Initialized
INFO - 2018-06-29 17:47:18 --> URI Class Initialized
DEBUG - 2018-06-29 17:47:18 --> No URI present. Default controller set.
INFO - 2018-06-29 17:47:18 --> Router Class Initialized
INFO - 2018-06-29 17:47:18 --> Output Class Initialized
INFO - 2018-06-29 17:47:18 --> Security Class Initialized
DEBUG - 2018-06-29 17:47:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 17:47:18 --> CSRF cookie sent
INFO - 2018-06-29 17:47:18 --> Input Class Initialized
INFO - 2018-06-29 17:47:18 --> Language Class Initialized
INFO - 2018-06-29 17:47:18 --> Loader Class Initialized
INFO - 2018-06-29 17:47:18 --> Helper loaded: url_helper
INFO - 2018-06-29 17:47:18 --> Helper loaded: form_helper
INFO - 2018-06-29 17:47:18 --> Helper loaded: language_helper
DEBUG - 2018-06-29 17:47:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 17:47:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 17:47:18 --> User Agent Class Initialized
INFO - 2018-06-29 17:47:18 --> Controller Class Initialized
INFO - 2018-06-29 17:47:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 17:47:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 17:47:18 --> Pixel_Model class loaded
INFO - 2018-06-29 17:47:18 --> Database Driver Class Initialized
INFO - 2018-06-29 17:47:18 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 17:47:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 17:47:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 17:47:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-29 17:47:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 17:47:18 --> Final output sent to browser
DEBUG - 2018-06-29 17:47:18 --> Total execution time: 0.0304
INFO - 2018-06-29 17:47:19 --> Config Class Initialized
INFO - 2018-06-29 17:47:19 --> Hooks Class Initialized
DEBUG - 2018-06-29 17:47:19 --> UTF-8 Support Enabled
INFO - 2018-06-29 17:47:19 --> Utf8 Class Initialized
INFO - 2018-06-29 17:47:19 --> URI Class Initialized
DEBUG - 2018-06-29 17:47:19 --> No URI present. Default controller set.
INFO - 2018-06-29 17:47:19 --> Router Class Initialized
INFO - 2018-06-29 17:47:19 --> Output Class Initialized
INFO - 2018-06-29 17:47:19 --> Security Class Initialized
DEBUG - 2018-06-29 17:47:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 17:47:19 --> CSRF cookie sent
INFO - 2018-06-29 17:47:19 --> Input Class Initialized
INFO - 2018-06-29 17:47:19 --> Language Class Initialized
INFO - 2018-06-29 17:47:19 --> Loader Class Initialized
INFO - 2018-06-29 17:47:19 --> Helper loaded: url_helper
INFO - 2018-06-29 17:47:19 --> Helper loaded: form_helper
INFO - 2018-06-29 17:47:19 --> Helper loaded: language_helper
DEBUG - 2018-06-29 17:47:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 17:47:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 17:47:19 --> User Agent Class Initialized
INFO - 2018-06-29 17:47:19 --> Controller Class Initialized
INFO - 2018-06-29 17:47:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 17:47:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 17:47:19 --> Pixel_Model class loaded
INFO - 2018-06-29 17:47:19 --> Database Driver Class Initialized
INFO - 2018-06-29 17:47:19 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 17:47:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 17:47:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 17:47:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-29 17:47:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 17:47:19 --> Final output sent to browser
DEBUG - 2018-06-29 17:47:19 --> Total execution time: 0.0363
INFO - 2018-06-29 17:47:19 --> Config Class Initialized
INFO - 2018-06-29 17:47:19 --> Hooks Class Initialized
DEBUG - 2018-06-29 17:47:19 --> UTF-8 Support Enabled
INFO - 2018-06-29 17:47:19 --> Utf8 Class Initialized
INFO - 2018-06-29 17:47:19 --> URI Class Initialized
INFO - 2018-06-29 17:47:19 --> Router Class Initialized
INFO - 2018-06-29 17:47:19 --> Output Class Initialized
INFO - 2018-06-29 17:47:19 --> Security Class Initialized
DEBUG - 2018-06-29 17:47:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 17:47:19 --> CSRF cookie sent
INFO - 2018-06-29 17:47:19 --> Input Class Initialized
INFO - 2018-06-29 17:47:19 --> Language Class Initialized
ERROR - 2018-06-29 17:47:19 --> 404 Page Not Found: 405shtml/index
INFO - 2018-06-29 17:47:26 --> Config Class Initialized
INFO - 2018-06-29 17:47:26 --> Hooks Class Initialized
DEBUG - 2018-06-29 17:47:26 --> UTF-8 Support Enabled
INFO - 2018-06-29 17:47:26 --> Utf8 Class Initialized
INFO - 2018-06-29 17:47:26 --> URI Class Initialized
DEBUG - 2018-06-29 17:47:26 --> No URI present. Default controller set.
INFO - 2018-06-29 17:47:26 --> Router Class Initialized
INFO - 2018-06-29 17:47:26 --> Output Class Initialized
INFO - 2018-06-29 17:47:26 --> Security Class Initialized
DEBUG - 2018-06-29 17:47:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 17:47:26 --> CSRF cookie sent
INFO - 2018-06-29 17:47:26 --> Input Class Initialized
INFO - 2018-06-29 17:47:26 --> Language Class Initialized
INFO - 2018-06-29 17:47:26 --> Loader Class Initialized
INFO - 2018-06-29 17:47:26 --> Helper loaded: url_helper
INFO - 2018-06-29 17:47:26 --> Helper loaded: form_helper
INFO - 2018-06-29 17:47:26 --> Helper loaded: language_helper
DEBUG - 2018-06-29 17:47:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 17:47:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 17:47:26 --> User Agent Class Initialized
INFO - 2018-06-29 17:47:26 --> Controller Class Initialized
INFO - 2018-06-29 17:47:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 17:47:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 17:47:26 --> Pixel_Model class loaded
INFO - 2018-06-29 17:47:26 --> Database Driver Class Initialized
INFO - 2018-06-29 17:47:26 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 17:47:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 17:47:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 17:47:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-29 17:47:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 17:47:26 --> Final output sent to browser
DEBUG - 2018-06-29 17:47:26 --> Total execution time: 0.0359
INFO - 2018-06-29 17:47:26 --> Config Class Initialized
INFO - 2018-06-29 17:47:26 --> Hooks Class Initialized
DEBUG - 2018-06-29 17:47:26 --> UTF-8 Support Enabled
INFO - 2018-06-29 17:47:26 --> Utf8 Class Initialized
INFO - 2018-06-29 17:47:26 --> URI Class Initialized
INFO - 2018-06-29 17:47:26 --> Router Class Initialized
INFO - 2018-06-29 17:47:26 --> Output Class Initialized
INFO - 2018-06-29 17:47:26 --> Security Class Initialized
DEBUG - 2018-06-29 17:47:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 17:47:26 --> CSRF cookie sent
INFO - 2018-06-29 17:47:26 --> Input Class Initialized
INFO - 2018-06-29 17:47:26 --> Language Class Initialized
ERROR - 2018-06-29 17:47:26 --> 404 Page Not Found: 404testpage4525d2fdc/index
INFO - 2018-06-29 17:47:27 --> Config Class Initialized
INFO - 2018-06-29 17:47:27 --> Hooks Class Initialized
DEBUG - 2018-06-29 17:47:27 --> UTF-8 Support Enabled
INFO - 2018-06-29 17:47:27 --> Utf8 Class Initialized
INFO - 2018-06-29 17:47:27 --> URI Class Initialized
INFO - 2018-06-29 17:47:27 --> Router Class Initialized
INFO - 2018-06-29 17:47:27 --> Output Class Initialized
INFO - 2018-06-29 17:47:27 --> Security Class Initialized
DEBUG - 2018-06-29 17:47:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 17:47:27 --> CSRF cookie sent
INFO - 2018-06-29 17:47:27 --> Input Class Initialized
INFO - 2018-06-29 17:47:27 --> Language Class Initialized
ERROR - 2018-06-29 17:47:27 --> 404 Page Not Found: 404javascriptjs/index
INFO - 2018-06-29 17:47:27 --> Config Class Initialized
INFO - 2018-06-29 17:47:27 --> Hooks Class Initialized
DEBUG - 2018-06-29 17:47:27 --> UTF-8 Support Enabled
INFO - 2018-06-29 17:47:27 --> Utf8 Class Initialized
INFO - 2018-06-29 17:47:27 --> URI Class Initialized
INFO - 2018-06-29 17:47:27 --> Router Class Initialized
INFO - 2018-06-29 17:47:27 --> Output Class Initialized
INFO - 2018-06-29 17:47:27 --> Security Class Initialized
DEBUG - 2018-06-29 17:47:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 17:47:27 --> CSRF cookie sent
INFO - 2018-06-29 17:47:27 --> Input Class Initialized
INFO - 2018-06-29 17:47:27 --> Language Class Initialized
INFO - 2018-06-29 17:47:27 --> Loader Class Initialized
INFO - 2018-06-29 17:47:27 --> Helper loaded: url_helper
INFO - 2018-06-29 17:47:27 --> Helper loaded: form_helper
INFO - 2018-06-29 17:47:27 --> Helper loaded: language_helper
DEBUG - 2018-06-29 17:47:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 17:47:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 17:47:27 --> User Agent Class Initialized
INFO - 2018-06-29 17:47:27 --> Controller Class Initialized
INFO - 2018-06-29 17:47:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 17:47:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 17:47:27 --> Pixel_Model class loaded
INFO - 2018-06-29 17:47:27 --> Database Driver Class Initialized
INFO - 2018-06-29 17:47:27 --> Model "QuestionsModel" initialized
ERROR - 2018-06-29 17:47:27 --> Severity: Notice --> Undefined index: HTTP_REFERER /home/fxp6bn7rqemh/public_html/application/core/Pixel_Controller.php 87
INFO - 2018-06-29 17:47:27 --> Config Class Initialized
INFO - 2018-06-29 17:47:27 --> Hooks Class Initialized
DEBUG - 2018-06-29 17:47:27 --> UTF-8 Support Enabled
INFO - 2018-06-29 17:47:27 --> Utf8 Class Initialized
INFO - 2018-06-29 17:47:27 --> URI Class Initialized
INFO - 2018-06-29 17:47:27 --> Router Class Initialized
INFO - 2018-06-29 17:47:27 --> Output Class Initialized
INFO - 2018-06-29 17:47:27 --> Security Class Initialized
DEBUG - 2018-06-29 17:47:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 17:47:27 --> CSRF cookie sent
INFO - 2018-06-29 17:47:27 --> Input Class Initialized
INFO - 2018-06-29 17:47:27 --> Language Class Initialized
INFO - 2018-06-29 17:47:27 --> Loader Class Initialized
INFO - 2018-06-29 17:47:27 --> Helper loaded: url_helper
INFO - 2018-06-29 17:47:27 --> Helper loaded: form_helper
INFO - 2018-06-29 17:47:27 --> Helper loaded: language_helper
DEBUG - 2018-06-29 17:47:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 17:47:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 17:47:27 --> User Agent Class Initialized
INFO - 2018-06-29 17:47:27 --> Controller Class Initialized
INFO - 2018-06-29 17:47:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 17:47:27 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-29 17:47:27 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-29 17:47:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 17:47:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 17:47:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 17:47:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-29 17:47:27 --> Could not find the language line "req_email"
INFO - 2018-06-29 17:47:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-06-29 17:47:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 17:47:27 --> Final output sent to browser
DEBUG - 2018-06-29 17:47:27 --> Total execution time: 0.0234
INFO - 2018-06-29 17:47:27 --> Config Class Initialized
INFO - 2018-06-29 17:47:27 --> Hooks Class Initialized
DEBUG - 2018-06-29 17:47:27 --> UTF-8 Support Enabled
INFO - 2018-06-29 17:47:27 --> Utf8 Class Initialized
INFO - 2018-06-29 17:47:27 --> URI Class Initialized
INFO - 2018-06-29 17:47:27 --> Router Class Initialized
INFO - 2018-06-29 17:47:27 --> Output Class Initialized
INFO - 2018-06-29 17:47:27 --> Security Class Initialized
DEBUG - 2018-06-29 17:47:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 17:47:27 --> CSRF cookie sent
INFO - 2018-06-29 17:47:27 --> Input Class Initialized
INFO - 2018-06-29 17:47:27 --> Language Class Initialized
INFO - 2018-06-29 17:47:27 --> Loader Class Initialized
INFO - 2018-06-29 17:47:27 --> Helper loaded: url_helper
INFO - 2018-06-29 17:47:27 --> Helper loaded: form_helper
INFO - 2018-06-29 17:47:27 --> Helper loaded: language_helper
DEBUG - 2018-06-29 17:47:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 17:47:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 17:47:27 --> User Agent Class Initialized
INFO - 2018-06-29 17:47:27 --> Controller Class Initialized
INFO - 2018-06-29 17:47:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 17:47:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 17:47:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 17:47:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 17:47:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 17:47:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 17:47:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-06-29 17:47:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 17:47:27 --> Final output sent to browser
DEBUG - 2018-06-29 17:47:27 --> Total execution time: 0.0193
INFO - 2018-06-29 17:47:28 --> Config Class Initialized
INFO - 2018-06-29 17:47:28 --> Hooks Class Initialized
DEBUG - 2018-06-29 17:47:28 --> UTF-8 Support Enabled
INFO - 2018-06-29 17:47:28 --> Utf8 Class Initialized
INFO - 2018-06-29 17:47:28 --> URI Class Initialized
INFO - 2018-06-29 17:47:28 --> Router Class Initialized
INFO - 2018-06-29 17:47:28 --> Output Class Initialized
INFO - 2018-06-29 17:47:28 --> Security Class Initialized
DEBUG - 2018-06-29 17:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 17:47:28 --> CSRF cookie sent
INFO - 2018-06-29 17:47:28 --> Input Class Initialized
INFO - 2018-06-29 17:47:28 --> Language Class Initialized
INFO - 2018-06-29 17:47:28 --> Loader Class Initialized
INFO - 2018-06-29 17:47:28 --> Helper loaded: url_helper
INFO - 2018-06-29 17:47:28 --> Helper loaded: form_helper
INFO - 2018-06-29 17:47:28 --> Helper loaded: language_helper
DEBUG - 2018-06-29 17:47:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 17:47:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 17:47:28 --> User Agent Class Initialized
INFO - 2018-06-29 17:47:28 --> Controller Class Initialized
INFO - 2018-06-29 17:47:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 17:47:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 17:47:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 17:47:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 17:47:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 17:47:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 17:47:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-06-29 17:47:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 17:47:28 --> Final output sent to browser
DEBUG - 2018-06-29 17:47:28 --> Total execution time: 0.0268
INFO - 2018-06-29 17:47:28 --> Config Class Initialized
INFO - 2018-06-29 17:47:28 --> Hooks Class Initialized
DEBUG - 2018-06-29 17:47:28 --> UTF-8 Support Enabled
INFO - 2018-06-29 17:47:28 --> Utf8 Class Initialized
INFO - 2018-06-29 17:47:28 --> URI Class Initialized
INFO - 2018-06-29 17:47:28 --> Router Class Initialized
INFO - 2018-06-29 17:47:28 --> Output Class Initialized
INFO - 2018-06-29 17:47:28 --> Security Class Initialized
DEBUG - 2018-06-29 17:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 17:47:28 --> CSRF cookie sent
INFO - 2018-06-29 17:47:28 --> Input Class Initialized
INFO - 2018-06-29 17:47:28 --> Language Class Initialized
INFO - 2018-06-29 17:47:28 --> Loader Class Initialized
INFO - 2018-06-29 17:47:28 --> Helper loaded: url_helper
INFO - 2018-06-29 17:47:28 --> Helper loaded: form_helper
INFO - 2018-06-29 17:47:28 --> Helper loaded: language_helper
DEBUG - 2018-06-29 17:47:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 17:47:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 17:47:28 --> User Agent Class Initialized
INFO - 2018-06-29 17:47:28 --> Controller Class Initialized
INFO - 2018-06-29 17:47:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 17:47:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 17:47:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 17:47:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 17:47:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 17:47:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 17:47:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-06-29 17:47:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 17:47:28 --> Final output sent to browser
DEBUG - 2018-06-29 17:47:28 --> Total execution time: 0.0225
INFO - 2018-06-29 17:47:28 --> Config Class Initialized
INFO - 2018-06-29 17:47:28 --> Hooks Class Initialized
DEBUG - 2018-06-29 17:47:28 --> UTF-8 Support Enabled
INFO - 2018-06-29 17:47:28 --> Utf8 Class Initialized
INFO - 2018-06-29 17:47:28 --> URI Class Initialized
INFO - 2018-06-29 17:47:28 --> Router Class Initialized
INFO - 2018-06-29 17:47:28 --> Output Class Initialized
INFO - 2018-06-29 17:47:28 --> Security Class Initialized
DEBUG - 2018-06-29 17:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 17:47:28 --> CSRF cookie sent
INFO - 2018-06-29 17:47:28 --> Input Class Initialized
INFO - 2018-06-29 17:47:28 --> Language Class Initialized
INFO - 2018-06-29 17:47:28 --> Loader Class Initialized
INFO - 2018-06-29 17:47:28 --> Helper loaded: url_helper
INFO - 2018-06-29 17:47:28 --> Helper loaded: form_helper
INFO - 2018-06-29 17:47:28 --> Helper loaded: language_helper
DEBUG - 2018-06-29 17:47:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 17:47:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 17:47:28 --> User Agent Class Initialized
INFO - 2018-06-29 17:47:28 --> Controller Class Initialized
INFO - 2018-06-29 17:47:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 17:47:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 17:47:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 17:47:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 17:47:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 17:47:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 17:47:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-06-29 17:47:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 17:47:28 --> Final output sent to browser
DEBUG - 2018-06-29 17:47:28 --> Total execution time: 0.0244
INFO - 2018-06-29 17:47:29 --> Config Class Initialized
INFO - 2018-06-29 17:47:29 --> Hooks Class Initialized
DEBUG - 2018-06-29 17:47:29 --> UTF-8 Support Enabled
INFO - 2018-06-29 17:47:29 --> Utf8 Class Initialized
INFO - 2018-06-29 17:47:29 --> URI Class Initialized
INFO - 2018-06-29 17:47:29 --> Router Class Initialized
INFO - 2018-06-29 17:47:29 --> Output Class Initialized
INFO - 2018-06-29 17:47:29 --> Security Class Initialized
DEBUG - 2018-06-29 17:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 17:47:29 --> CSRF cookie sent
INFO - 2018-06-29 17:47:29 --> Input Class Initialized
INFO - 2018-06-29 17:47:29 --> Language Class Initialized
INFO - 2018-06-29 17:47:29 --> Loader Class Initialized
INFO - 2018-06-29 17:47:29 --> Helper loaded: url_helper
INFO - 2018-06-29 17:47:29 --> Helper loaded: form_helper
INFO - 2018-06-29 17:47:29 --> Helper loaded: language_helper
DEBUG - 2018-06-29 17:47:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 17:47:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 17:47:29 --> User Agent Class Initialized
INFO - 2018-06-29 17:47:29 --> Controller Class Initialized
INFO - 2018-06-29 17:47:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 17:47:29 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-29 17:47:29 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-29 17:47:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 17:47:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 17:47:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 17:47:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-29 17:47:29 --> Could not find the language line "req_email"
INFO - 2018-06-29 17:47:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-06-29 17:47:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 17:47:29 --> Final output sent to browser
DEBUG - 2018-06-29 17:47:29 --> Total execution time: 0.0222
INFO - 2018-06-29 17:47:29 --> Config Class Initialized
INFO - 2018-06-29 17:47:29 --> Hooks Class Initialized
DEBUG - 2018-06-29 17:47:29 --> UTF-8 Support Enabled
INFO - 2018-06-29 17:47:29 --> Utf8 Class Initialized
INFO - 2018-06-29 17:47:29 --> URI Class Initialized
INFO - 2018-06-29 17:47:29 --> Router Class Initialized
INFO - 2018-06-29 17:47:29 --> Output Class Initialized
INFO - 2018-06-29 17:47:29 --> Security Class Initialized
DEBUG - 2018-06-29 17:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 17:47:29 --> CSRF cookie sent
INFO - 2018-06-29 17:47:29 --> Input Class Initialized
INFO - 2018-06-29 17:47:29 --> Language Class Initialized
INFO - 2018-06-29 17:47:29 --> Loader Class Initialized
INFO - 2018-06-29 17:47:29 --> Helper loaded: url_helper
INFO - 2018-06-29 17:47:29 --> Helper loaded: form_helper
INFO - 2018-06-29 17:47:29 --> Helper loaded: language_helper
DEBUG - 2018-06-29 17:47:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 17:47:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 17:47:29 --> User Agent Class Initialized
INFO - 2018-06-29 17:47:29 --> Controller Class Initialized
INFO - 2018-06-29 17:47:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 17:47:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 17:47:29 --> Pixel_Model class loaded
INFO - 2018-06-29 17:47:29 --> Database Driver Class Initialized
INFO - 2018-06-29 17:47:29 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 17:47:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 17:47:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 17:47:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 17:47:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 17:47:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/buy_gift.php
INFO - 2018-06-29 17:47:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 17:47:29 --> Final output sent to browser
DEBUG - 2018-06-29 17:47:29 --> Total execution time: 0.0312
INFO - 2018-06-29 17:47:34 --> Config Class Initialized
INFO - 2018-06-29 17:47:34 --> Hooks Class Initialized
DEBUG - 2018-06-29 17:47:34 --> UTF-8 Support Enabled
INFO - 2018-06-29 17:47:34 --> Utf8 Class Initialized
INFO - 2018-06-29 17:47:34 --> URI Class Initialized
DEBUG - 2018-06-29 17:47:34 --> No URI present. Default controller set.
INFO - 2018-06-29 17:47:34 --> Router Class Initialized
INFO - 2018-06-29 17:47:34 --> Output Class Initialized
INFO - 2018-06-29 17:47:34 --> Security Class Initialized
DEBUG - 2018-06-29 17:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 17:47:34 --> CSRF cookie sent
INFO - 2018-06-29 17:47:34 --> Input Class Initialized
INFO - 2018-06-29 17:47:34 --> Language Class Initialized
INFO - 2018-06-29 17:47:34 --> Loader Class Initialized
INFO - 2018-06-29 17:47:34 --> Helper loaded: url_helper
INFO - 2018-06-29 17:47:34 --> Helper loaded: form_helper
INFO - 2018-06-29 17:47:34 --> Helper loaded: language_helper
DEBUG - 2018-06-29 17:47:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 17:47:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 17:47:34 --> User Agent Class Initialized
INFO - 2018-06-29 17:47:34 --> Controller Class Initialized
INFO - 2018-06-29 17:47:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 17:47:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 17:47:34 --> Pixel_Model class loaded
INFO - 2018-06-29 17:47:34 --> Database Driver Class Initialized
INFO - 2018-06-29 17:47:34 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 17:47:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 17:47:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 17:47:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-29 17:47:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 17:47:34 --> Final output sent to browser
DEBUG - 2018-06-29 17:47:34 --> Total execution time: 0.0320
INFO - 2018-06-29 19:01:26 --> Config Class Initialized
INFO - 2018-06-29 19:01:26 --> Hooks Class Initialized
DEBUG - 2018-06-29 19:01:26 --> UTF-8 Support Enabled
INFO - 2018-06-29 19:01:26 --> Utf8 Class Initialized
INFO - 2018-06-29 19:01:26 --> URI Class Initialized
DEBUG - 2018-06-29 19:01:26 --> No URI present. Default controller set.
INFO - 2018-06-29 19:01:26 --> Router Class Initialized
INFO - 2018-06-29 19:01:26 --> Output Class Initialized
INFO - 2018-06-29 19:01:26 --> Security Class Initialized
DEBUG - 2018-06-29 19:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 19:01:26 --> CSRF cookie sent
INFO - 2018-06-29 19:01:26 --> Input Class Initialized
INFO - 2018-06-29 19:01:26 --> Language Class Initialized
INFO - 2018-06-29 19:01:26 --> Loader Class Initialized
INFO - 2018-06-29 19:01:26 --> Helper loaded: url_helper
INFO - 2018-06-29 19:01:26 --> Helper loaded: form_helper
INFO - 2018-06-29 19:01:26 --> Helper loaded: language_helper
DEBUG - 2018-06-29 19:01:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 19:01:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 19:01:26 --> User Agent Class Initialized
INFO - 2018-06-29 19:01:26 --> Controller Class Initialized
INFO - 2018-06-29 19:01:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 19:01:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 19:01:26 --> Pixel_Model class loaded
INFO - 2018-06-29 19:01:26 --> Database Driver Class Initialized
INFO - 2018-06-29 19:01:26 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 19:01:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 19:01:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 19:01:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-29 19:01:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 19:01:26 --> Final output sent to browser
DEBUG - 2018-06-29 19:01:26 --> Total execution time: 0.0320
INFO - 2018-06-29 19:01:26 --> Config Class Initialized
INFO - 2018-06-29 19:01:26 --> Hooks Class Initialized
DEBUG - 2018-06-29 19:01:26 --> UTF-8 Support Enabled
INFO - 2018-06-29 19:01:26 --> Utf8 Class Initialized
INFO - 2018-06-29 19:01:26 --> URI Class Initialized
INFO - 2018-06-29 19:01:26 --> Router Class Initialized
INFO - 2018-06-29 19:01:26 --> Output Class Initialized
INFO - 2018-06-29 19:01:26 --> Security Class Initialized
DEBUG - 2018-06-29 19:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 19:01:26 --> CSRF cookie sent
INFO - 2018-06-29 19:01:26 --> Input Class Initialized
INFO - 2018-06-29 19:01:26 --> Language Class Initialized
ERROR - 2018-06-29 19:01:26 --> 404 Page Not Found: Images/team
INFO - 2018-06-29 19:01:26 --> Config Class Initialized
INFO - 2018-06-29 19:01:26 --> Hooks Class Initialized
INFO - 2018-06-29 19:01:26 --> Config Class Initialized
INFO - 2018-06-29 19:01:26 --> Hooks Class Initialized
DEBUG - 2018-06-29 19:01:26 --> UTF-8 Support Enabled
INFO - 2018-06-29 19:01:26 --> Utf8 Class Initialized
DEBUG - 2018-06-29 19:01:26 --> UTF-8 Support Enabled
INFO - 2018-06-29 19:01:26 --> Utf8 Class Initialized
INFO - 2018-06-29 19:01:26 --> URI Class Initialized
INFO - 2018-06-29 19:01:26 --> Config Class Initialized
INFO - 2018-06-29 19:01:26 --> Config Class Initialized
INFO - 2018-06-29 19:01:26 --> Hooks Class Initialized
INFO - 2018-06-29 19:01:26 --> Hooks Class Initialized
DEBUG - 2018-06-29 19:01:26 --> UTF-8 Support Enabled
INFO - 2018-06-29 19:01:26 --> Utf8 Class Initialized
INFO - 2018-06-29 19:01:26 --> URI Class Initialized
INFO - 2018-06-29 19:01:26 --> Router Class Initialized
DEBUG - 2018-06-29 19:01:26 --> UTF-8 Support Enabled
INFO - 2018-06-29 19:01:26 --> Utf8 Class Initialized
INFO - 2018-06-29 19:01:26 --> Router Class Initialized
INFO - 2018-06-29 19:01:26 --> URI Class Initialized
INFO - 2018-06-29 19:01:26 --> Output Class Initialized
INFO - 2018-06-29 19:01:26 --> URI Class Initialized
INFO - 2018-06-29 19:01:26 --> Output Class Initialized
INFO - 2018-06-29 19:01:26 --> Router Class Initialized
INFO - 2018-06-29 19:01:26 --> Router Class Initialized
INFO - 2018-06-29 19:01:26 --> Output Class Initialized
INFO - 2018-06-29 19:01:26 --> Security Class Initialized
INFO - 2018-06-29 19:01:26 --> Security Class Initialized
DEBUG - 2018-06-29 19:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 19:01:26 --> CSRF cookie sent
INFO - 2018-06-29 19:01:26 --> Input Class Initialized
DEBUG - 2018-06-29 19:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 19:01:26 --> Output Class Initialized
INFO - 2018-06-29 19:01:26 --> CSRF cookie sent
INFO - 2018-06-29 19:01:26 --> Input Class Initialized
INFO - 2018-06-29 19:01:26 --> Language Class Initialized
INFO - 2018-06-29 19:01:26 --> Security Class Initialized
ERROR - 2018-06-29 19:01:26 --> 404 Page Not Found: Images/team
INFO - 2018-06-29 19:01:26 --> Language Class Initialized
ERROR - 2018-06-29 19:01:26 --> 404 Page Not Found: Images/team
INFO - 2018-06-29 19:01:26 --> Security Class Initialized
DEBUG - 2018-06-29 19:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 19:01:26 --> CSRF cookie sent
INFO - 2018-06-29 19:01:26 --> Input Class Initialized
DEBUG - 2018-06-29 19:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 19:01:26 --> Language Class Initialized
INFO - 2018-06-29 19:01:26 --> CSRF cookie sent
INFO - 2018-06-29 19:01:26 --> Input Class Initialized
INFO - 2018-06-29 19:01:26 --> Language Class Initialized
ERROR - 2018-06-29 19:01:26 --> 404 Page Not Found: Images/team
ERROR - 2018-06-29 19:01:26 --> 404 Page Not Found: Faviconico/index
INFO - 2018-06-29 20:05:29 --> Config Class Initialized
INFO - 2018-06-29 20:05:29 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:05:29 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:05:29 --> Utf8 Class Initialized
INFO - 2018-06-29 20:05:29 --> URI Class Initialized
DEBUG - 2018-06-29 20:05:29 --> No URI present. Default controller set.
INFO - 2018-06-29 20:05:29 --> Router Class Initialized
INFO - 2018-06-29 20:05:29 --> Output Class Initialized
INFO - 2018-06-29 20:05:29 --> Security Class Initialized
DEBUG - 2018-06-29 20:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:05:29 --> CSRF cookie sent
INFO - 2018-06-29 20:05:29 --> Input Class Initialized
INFO - 2018-06-29 20:05:29 --> Language Class Initialized
INFO - 2018-06-29 20:05:29 --> Loader Class Initialized
INFO - 2018-06-29 20:05:29 --> Helper loaded: url_helper
INFO - 2018-06-29 20:05:29 --> Helper loaded: form_helper
INFO - 2018-06-29 20:05:29 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:05:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:05:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:05:29 --> User Agent Class Initialized
INFO - 2018-06-29 20:05:29 --> Controller Class Initialized
INFO - 2018-06-29 20:05:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:05:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:05:29 --> Pixel_Model class loaded
INFO - 2018-06-29 20:05:29 --> Database Driver Class Initialized
INFO - 2018-06-29 20:05:29 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:05:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:05:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:05:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-29 20:05:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:05:29 --> Final output sent to browser
DEBUG - 2018-06-29 20:05:29 --> Total execution time: 0.0312
INFO - 2018-06-29 20:05:33 --> Config Class Initialized
INFO - 2018-06-29 20:05:33 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:05:33 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:05:33 --> Utf8 Class Initialized
INFO - 2018-06-29 20:05:33 --> URI Class Initialized
INFO - 2018-06-29 20:05:33 --> Router Class Initialized
INFO - 2018-06-29 20:05:33 --> Output Class Initialized
INFO - 2018-06-29 20:05:33 --> Security Class Initialized
DEBUG - 2018-06-29 20:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:05:33 --> CSRF cookie sent
INFO - 2018-06-29 20:05:33 --> Input Class Initialized
INFO - 2018-06-29 20:05:33 --> Language Class Initialized
INFO - 2018-06-29 20:05:33 --> Loader Class Initialized
INFO - 2018-06-29 20:05:33 --> Helper loaded: url_helper
INFO - 2018-06-29 20:05:33 --> Helper loaded: form_helper
INFO - 2018-06-29 20:05:33 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:05:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:05:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:05:33 --> User Agent Class Initialized
INFO - 2018-06-29 20:05:33 --> Controller Class Initialized
INFO - 2018-06-29 20:05:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:05:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:05:33 --> Pixel_Model class loaded
INFO - 2018-06-29 20:05:33 --> Database Driver Class Initialized
INFO - 2018-06-29 20:05:33 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:05:33 --> Config Class Initialized
INFO - 2018-06-29 20:05:33 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:05:33 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:05:33 --> Utf8 Class Initialized
INFO - 2018-06-29 20:05:33 --> URI Class Initialized
INFO - 2018-06-29 20:05:33 --> Router Class Initialized
INFO - 2018-06-29 20:05:33 --> Output Class Initialized
INFO - 2018-06-29 20:05:33 --> Security Class Initialized
DEBUG - 2018-06-29 20:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:05:33 --> CSRF cookie sent
INFO - 2018-06-29 20:05:33 --> Input Class Initialized
INFO - 2018-06-29 20:05:33 --> Language Class Initialized
INFO - 2018-06-29 20:05:33 --> Loader Class Initialized
INFO - 2018-06-29 20:05:33 --> Helper loaded: url_helper
INFO - 2018-06-29 20:05:33 --> Helper loaded: form_helper
INFO - 2018-06-29 20:05:33 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:05:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:05:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:05:33 --> User Agent Class Initialized
INFO - 2018-06-29 20:05:33 --> Controller Class Initialized
INFO - 2018-06-29 20:05:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:05:33 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-29 20:05:33 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-29 20:05:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:05:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:05:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:05:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-29 20:05:33 --> Could not find the language line "req_email"
INFO - 2018-06-29 20:05:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-06-29 20:05:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:05:33 --> Final output sent to browser
DEBUG - 2018-06-29 20:05:33 --> Total execution time: 0.0182
INFO - 2018-06-29 20:05:43 --> Config Class Initialized
INFO - 2018-06-29 20:05:43 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:05:43 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:05:43 --> Utf8 Class Initialized
INFO - 2018-06-29 20:05:43 --> URI Class Initialized
INFO - 2018-06-29 20:05:43 --> Router Class Initialized
INFO - 2018-06-29 20:05:43 --> Output Class Initialized
INFO - 2018-06-29 20:05:43 --> Security Class Initialized
DEBUG - 2018-06-29 20:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:05:43 --> CSRF cookie sent
INFO - 2018-06-29 20:05:43 --> CSRF token verified
INFO - 2018-06-29 20:05:43 --> Input Class Initialized
INFO - 2018-06-29 20:05:43 --> Language Class Initialized
INFO - 2018-06-29 20:05:43 --> Loader Class Initialized
INFO - 2018-06-29 20:05:43 --> Helper loaded: url_helper
INFO - 2018-06-29 20:05:43 --> Helper loaded: form_helper
INFO - 2018-06-29 20:05:43 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:05:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:05:43 --> User Agent Class Initialized
INFO - 2018-06-29 20:05:43 --> Controller Class Initialized
INFO - 2018-06-29 20:05:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:05:43 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-29 20:05:43 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-29 20:05:43 --> Config Class Initialized
INFO - 2018-06-29 20:05:43 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:05:43 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:05:43 --> Utf8 Class Initialized
INFO - 2018-06-29 20:05:43 --> URI Class Initialized
INFO - 2018-06-29 20:05:43 --> Router Class Initialized
INFO - 2018-06-29 20:05:43 --> Output Class Initialized
INFO - 2018-06-29 20:05:43 --> Security Class Initialized
DEBUG - 2018-06-29 20:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:05:43 --> CSRF cookie sent
INFO - 2018-06-29 20:05:43 --> Input Class Initialized
INFO - 2018-06-29 20:05:43 --> Language Class Initialized
INFO - 2018-06-29 20:05:43 --> Loader Class Initialized
INFO - 2018-06-29 20:05:43 --> Helper loaded: url_helper
INFO - 2018-06-29 20:05:43 --> Helper loaded: form_helper
INFO - 2018-06-29 20:05:43 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:05:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:05:43 --> User Agent Class Initialized
INFO - 2018-06-29 20:05:43 --> Controller Class Initialized
INFO - 2018-06-29 20:05:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:05:43 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-29 20:05:43 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-29 20:05:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:05:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:05:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:05:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:05:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_soft_error.php
ERROR - 2018-06-29 20:05:43 --> Could not find the language line "req_email"
INFO - 2018-06-29 20:05:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-06-29 20:05:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:05:43 --> Final output sent to browser
DEBUG - 2018-06-29 20:05:43 --> Total execution time: 0.0216
INFO - 2018-06-29 20:05:54 --> Config Class Initialized
INFO - 2018-06-29 20:05:54 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:05:54 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:05:54 --> Utf8 Class Initialized
INFO - 2018-06-29 20:05:54 --> URI Class Initialized
INFO - 2018-06-29 20:05:54 --> Router Class Initialized
INFO - 2018-06-29 20:05:54 --> Output Class Initialized
INFO - 2018-06-29 20:05:54 --> Security Class Initialized
DEBUG - 2018-06-29 20:05:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:05:54 --> CSRF cookie sent
INFO - 2018-06-29 20:05:54 --> CSRF token verified
INFO - 2018-06-29 20:05:54 --> Input Class Initialized
INFO - 2018-06-29 20:05:54 --> Language Class Initialized
INFO - 2018-06-29 20:05:54 --> Loader Class Initialized
INFO - 2018-06-29 20:05:54 --> Helper loaded: url_helper
INFO - 2018-06-29 20:05:54 --> Helper loaded: form_helper
INFO - 2018-06-29 20:05:54 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:05:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:05:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:05:54 --> User Agent Class Initialized
INFO - 2018-06-29 20:05:54 --> Controller Class Initialized
INFO - 2018-06-29 20:05:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:05:54 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-29 20:05:54 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-29 20:05:54 --> Form Validation Class Initialized
INFO - 2018-06-29 20:05:54 --> Pixel_Model class loaded
INFO - 2018-06-29 20:05:54 --> Database Driver Class Initialized
INFO - 2018-06-29 20:05:54 --> Model "AuthenticationModel" initialized
INFO - 2018-06-29 20:05:55 --> Config Class Initialized
INFO - 2018-06-29 20:05:55 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:05:55 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:05:55 --> Utf8 Class Initialized
INFO - 2018-06-29 20:05:55 --> URI Class Initialized
INFO - 2018-06-29 20:05:55 --> Router Class Initialized
INFO - 2018-06-29 20:05:55 --> Output Class Initialized
INFO - 2018-06-29 20:05:55 --> Security Class Initialized
DEBUG - 2018-06-29 20:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:05:55 --> CSRF cookie sent
INFO - 2018-06-29 20:05:55 --> Input Class Initialized
INFO - 2018-06-29 20:05:55 --> Language Class Initialized
INFO - 2018-06-29 20:05:55 --> Loader Class Initialized
INFO - 2018-06-29 20:05:55 --> Helper loaded: url_helper
INFO - 2018-06-29 20:05:55 --> Helper loaded: form_helper
INFO - 2018-06-29 20:05:55 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:05:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:05:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:05:55 --> User Agent Class Initialized
INFO - 2018-06-29 20:05:55 --> Controller Class Initialized
INFO - 2018-06-29 20:05:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:05:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:05:55 --> Pixel_Model class loaded
INFO - 2018-06-29 20:05:55 --> Database Driver Class Initialized
INFO - 2018-06-29 20:05:55 --> Model "MyAccountModel" initialized
INFO - 2018-06-29 20:05:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:05:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:05:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:05:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:05:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:05:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/application_list.php
INFO - 2018-06-29 20:05:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:05:55 --> Final output sent to browser
DEBUG - 2018-06-29 20:05:55 --> Total execution time: 0.0307
INFO - 2018-06-29 20:06:02 --> Config Class Initialized
INFO - 2018-06-29 20:06:02 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:06:02 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:06:02 --> Utf8 Class Initialized
INFO - 2018-06-29 20:06:02 --> URI Class Initialized
INFO - 2018-06-29 20:06:02 --> Router Class Initialized
INFO - 2018-06-29 20:06:02 --> Output Class Initialized
INFO - 2018-06-29 20:06:02 --> Security Class Initialized
DEBUG - 2018-06-29 20:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:06:02 --> CSRF cookie sent
INFO - 2018-06-29 20:06:02 --> Input Class Initialized
INFO - 2018-06-29 20:06:02 --> Language Class Initialized
INFO - 2018-06-29 20:06:02 --> Loader Class Initialized
INFO - 2018-06-29 20:06:02 --> Helper loaded: url_helper
INFO - 2018-06-29 20:06:02 --> Helper loaded: form_helper
INFO - 2018-06-29 20:06:02 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:06:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:06:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:06:02 --> User Agent Class Initialized
INFO - 2018-06-29 20:06:02 --> Controller Class Initialized
INFO - 2018-06-29 20:06:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:06:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:06:02 --> Pixel_Model class loaded
INFO - 2018-06-29 20:06:02 --> Database Driver Class Initialized
INFO - 2018-06-29 20:06:02 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:06:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:06:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:06:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:06:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:06:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:06:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:06:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:06:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-06-29 20:06:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:06:02 --> Final output sent to browser
DEBUG - 2018-06-29 20:06:02 --> Total execution time: 0.0360
INFO - 2018-06-29 20:14:03 --> Config Class Initialized
INFO - 2018-06-29 20:14:03 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:14:03 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:14:03 --> Utf8 Class Initialized
INFO - 2018-06-29 20:14:03 --> URI Class Initialized
INFO - 2018-06-29 20:14:03 --> Router Class Initialized
INFO - 2018-06-29 20:14:03 --> Output Class Initialized
INFO - 2018-06-29 20:14:03 --> Security Class Initialized
DEBUG - 2018-06-29 20:14:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:14:03 --> CSRF cookie sent
INFO - 2018-06-29 20:14:03 --> CSRF token verified
INFO - 2018-06-29 20:14:03 --> Input Class Initialized
INFO - 2018-06-29 20:14:03 --> Language Class Initialized
INFO - 2018-06-29 20:14:03 --> Loader Class Initialized
INFO - 2018-06-29 20:14:03 --> Helper loaded: url_helper
INFO - 2018-06-29 20:14:03 --> Helper loaded: form_helper
INFO - 2018-06-29 20:14:03 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:14:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:14:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:14:03 --> User Agent Class Initialized
INFO - 2018-06-29 20:14:03 --> Controller Class Initialized
INFO - 2018-06-29 20:14:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:14:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:14:03 --> Pixel_Model class loaded
INFO - 2018-06-29 20:14:03 --> Database Driver Class Initialized
INFO - 2018-06-29 20:14:03 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:14:03 --> Form Validation Class Initialized
INFO - 2018-06-29 20:14:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-29 20:14:03 --> Database Driver Class Initialized
INFO - 2018-06-29 20:14:03 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:14:03 --> Config Class Initialized
INFO - 2018-06-29 20:14:03 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:14:03 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:14:03 --> Utf8 Class Initialized
INFO - 2018-06-29 20:14:03 --> URI Class Initialized
DEBUG - 2018-06-29 20:14:03 --> No URI present. Default controller set.
INFO - 2018-06-29 20:14:03 --> Router Class Initialized
INFO - 2018-06-29 20:14:03 --> Output Class Initialized
INFO - 2018-06-29 20:14:03 --> Security Class Initialized
DEBUG - 2018-06-29 20:14:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:14:03 --> CSRF cookie sent
INFO - 2018-06-29 20:14:03 --> Input Class Initialized
INFO - 2018-06-29 20:14:03 --> Language Class Initialized
INFO - 2018-06-29 20:14:03 --> Loader Class Initialized
INFO - 2018-06-29 20:14:03 --> Helper loaded: url_helper
INFO - 2018-06-29 20:14:03 --> Helper loaded: form_helper
INFO - 2018-06-29 20:14:03 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:14:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:14:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:14:03 --> User Agent Class Initialized
INFO - 2018-06-29 20:14:03 --> Controller Class Initialized
INFO - 2018-06-29 20:14:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:14:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:14:03 --> Pixel_Model class loaded
INFO - 2018-06-29 20:14:03 --> Database Driver Class Initialized
INFO - 2018-06-29 20:14:03 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:14:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:14:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:14:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:14:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-29 20:14:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:14:03 --> Final output sent to browser
DEBUG - 2018-06-29 20:14:03 --> Total execution time: 0.0277
INFO - 2018-06-29 20:15:12 --> Config Class Initialized
INFO - 2018-06-29 20:15:12 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:15:12 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:15:12 --> Utf8 Class Initialized
INFO - 2018-06-29 20:15:12 --> URI Class Initialized
INFO - 2018-06-29 20:15:12 --> Router Class Initialized
INFO - 2018-06-29 20:15:12 --> Output Class Initialized
INFO - 2018-06-29 20:15:12 --> Security Class Initialized
DEBUG - 2018-06-29 20:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:15:12 --> CSRF cookie sent
INFO - 2018-06-29 20:15:12 --> Input Class Initialized
INFO - 2018-06-29 20:15:12 --> Language Class Initialized
INFO - 2018-06-29 20:15:12 --> Loader Class Initialized
INFO - 2018-06-29 20:15:12 --> Helper loaded: url_helper
INFO - 2018-06-29 20:15:12 --> Helper loaded: form_helper
INFO - 2018-06-29 20:15:12 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:15:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:15:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:15:12 --> User Agent Class Initialized
INFO - 2018-06-29 20:15:12 --> Controller Class Initialized
INFO - 2018-06-29 20:15:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:15:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:15:12 --> Pixel_Model class loaded
INFO - 2018-06-29 20:15:12 --> Database Driver Class Initialized
INFO - 2018-06-29 20:15:12 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:15:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:15:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:15:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:15:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:15:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:15:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:15:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:15:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-06-29 20:15:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:15:12 --> Final output sent to browser
DEBUG - 2018-06-29 20:15:12 --> Total execution time: 0.0356
INFO - 2018-06-29 20:15:20 --> Config Class Initialized
INFO - 2018-06-29 20:15:20 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:15:20 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:15:20 --> Utf8 Class Initialized
INFO - 2018-06-29 20:15:20 --> URI Class Initialized
INFO - 2018-06-29 20:15:20 --> Router Class Initialized
INFO - 2018-06-29 20:15:20 --> Output Class Initialized
INFO - 2018-06-29 20:15:20 --> Security Class Initialized
DEBUG - 2018-06-29 20:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:15:20 --> CSRF cookie sent
INFO - 2018-06-29 20:15:20 --> CSRF token verified
INFO - 2018-06-29 20:15:20 --> Input Class Initialized
INFO - 2018-06-29 20:15:20 --> Language Class Initialized
INFO - 2018-06-29 20:15:20 --> Loader Class Initialized
INFO - 2018-06-29 20:15:20 --> Helper loaded: url_helper
INFO - 2018-06-29 20:15:20 --> Helper loaded: form_helper
INFO - 2018-06-29 20:15:20 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:15:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:15:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:15:20 --> User Agent Class Initialized
INFO - 2018-06-29 20:15:20 --> Controller Class Initialized
INFO - 2018-06-29 20:15:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:15:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:15:20 --> Pixel_Model class loaded
INFO - 2018-06-29 20:15:20 --> Database Driver Class Initialized
INFO - 2018-06-29 20:15:20 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:15:20 --> Form Validation Class Initialized
INFO - 2018-06-29 20:15:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-29 20:15:20 --> Database Driver Class Initialized
INFO - 2018-06-29 20:15:20 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:15:20 --> Config Class Initialized
INFO - 2018-06-29 20:15:20 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:15:20 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:15:20 --> Utf8 Class Initialized
INFO - 2018-06-29 20:15:20 --> URI Class Initialized
INFO - 2018-06-29 20:15:20 --> Router Class Initialized
INFO - 2018-06-29 20:15:20 --> Output Class Initialized
INFO - 2018-06-29 20:15:20 --> Security Class Initialized
DEBUG - 2018-06-29 20:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:15:20 --> CSRF cookie sent
INFO - 2018-06-29 20:15:20 --> Input Class Initialized
INFO - 2018-06-29 20:15:20 --> Language Class Initialized
INFO - 2018-06-29 20:15:20 --> Loader Class Initialized
INFO - 2018-06-29 20:15:20 --> Helper loaded: url_helper
INFO - 2018-06-29 20:15:20 --> Helper loaded: form_helper
INFO - 2018-06-29 20:15:20 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:15:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:15:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:15:20 --> User Agent Class Initialized
INFO - 2018-06-29 20:15:20 --> Controller Class Initialized
INFO - 2018-06-29 20:15:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:15:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:15:20 --> Pixel_Model class loaded
INFO - 2018-06-29 20:15:20 --> Database Driver Class Initialized
INFO - 2018-06-29 20:15:20 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:15:20 --> Database Driver Class Initialized
INFO - 2018-06-29 20:15:20 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:15:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:15:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:15:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:15:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:15:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:15:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:15:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:15:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-06-29 20:15:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:15:20 --> Final output sent to browser
DEBUG - 2018-06-29 20:15:20 --> Total execution time: 0.0586
INFO - 2018-06-29 20:15:29 --> Config Class Initialized
INFO - 2018-06-29 20:15:29 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:15:29 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:15:29 --> Utf8 Class Initialized
INFO - 2018-06-29 20:15:29 --> URI Class Initialized
INFO - 2018-06-29 20:15:29 --> Router Class Initialized
INFO - 2018-06-29 20:15:29 --> Output Class Initialized
INFO - 2018-06-29 20:15:29 --> Security Class Initialized
DEBUG - 2018-06-29 20:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:15:29 --> CSRF cookie sent
INFO - 2018-06-29 20:15:29 --> CSRF token verified
INFO - 2018-06-29 20:15:29 --> Input Class Initialized
INFO - 2018-06-29 20:15:29 --> Language Class Initialized
INFO - 2018-06-29 20:15:29 --> Loader Class Initialized
INFO - 2018-06-29 20:15:29 --> Helper loaded: url_helper
INFO - 2018-06-29 20:15:29 --> Helper loaded: form_helper
INFO - 2018-06-29 20:15:29 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:15:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:15:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:15:29 --> User Agent Class Initialized
INFO - 2018-06-29 20:15:29 --> Controller Class Initialized
INFO - 2018-06-29 20:15:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:15:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:15:29 --> Pixel_Model class loaded
INFO - 2018-06-29 20:15:29 --> Database Driver Class Initialized
INFO - 2018-06-29 20:15:29 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:15:29 --> Form Validation Class Initialized
INFO - 2018-06-29 20:15:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-29 20:15:29 --> Database Driver Class Initialized
INFO - 2018-06-29 20:15:29 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:15:29 --> Config Class Initialized
INFO - 2018-06-29 20:15:29 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:15:29 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:15:29 --> Utf8 Class Initialized
INFO - 2018-06-29 20:15:29 --> URI Class Initialized
INFO - 2018-06-29 20:15:29 --> Router Class Initialized
INFO - 2018-06-29 20:15:29 --> Output Class Initialized
INFO - 2018-06-29 20:15:29 --> Security Class Initialized
DEBUG - 2018-06-29 20:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:15:29 --> CSRF cookie sent
INFO - 2018-06-29 20:15:29 --> Input Class Initialized
INFO - 2018-06-29 20:15:29 --> Language Class Initialized
INFO - 2018-06-29 20:15:29 --> Loader Class Initialized
INFO - 2018-06-29 20:15:29 --> Helper loaded: url_helper
INFO - 2018-06-29 20:15:29 --> Helper loaded: form_helper
INFO - 2018-06-29 20:15:29 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:15:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:15:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:15:29 --> User Agent Class Initialized
INFO - 2018-06-29 20:15:29 --> Controller Class Initialized
INFO - 2018-06-29 20:15:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:15:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:15:29 --> Pixel_Model class loaded
INFO - 2018-06-29 20:15:29 --> Database Driver Class Initialized
INFO - 2018-06-29 20:15:29 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:15:29 --> Database Driver Class Initialized
INFO - 2018-06-29 20:15:29 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:15:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:15:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:15:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:15:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:15:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:15:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:15:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:15:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-06-29 20:15:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:15:29 --> Final output sent to browser
DEBUG - 2018-06-29 20:15:29 --> Total execution time: 0.0405
INFO - 2018-06-29 20:15:36 --> Config Class Initialized
INFO - 2018-06-29 20:15:36 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:15:36 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:15:36 --> Utf8 Class Initialized
INFO - 2018-06-29 20:15:36 --> URI Class Initialized
INFO - 2018-06-29 20:15:36 --> Router Class Initialized
INFO - 2018-06-29 20:15:36 --> Output Class Initialized
INFO - 2018-06-29 20:15:36 --> Security Class Initialized
DEBUG - 2018-06-29 20:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:15:36 --> CSRF cookie sent
INFO - 2018-06-29 20:15:36 --> CSRF token verified
INFO - 2018-06-29 20:15:36 --> Input Class Initialized
INFO - 2018-06-29 20:15:36 --> Language Class Initialized
INFO - 2018-06-29 20:15:36 --> Loader Class Initialized
INFO - 2018-06-29 20:15:36 --> Helper loaded: url_helper
INFO - 2018-06-29 20:15:36 --> Helper loaded: form_helper
INFO - 2018-06-29 20:15:36 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:15:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:15:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:15:36 --> User Agent Class Initialized
INFO - 2018-06-29 20:15:36 --> Controller Class Initialized
INFO - 2018-06-29 20:15:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:15:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:15:36 --> Pixel_Model class loaded
INFO - 2018-06-29 20:15:36 --> Database Driver Class Initialized
INFO - 2018-06-29 20:15:36 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:15:36 --> Form Validation Class Initialized
INFO - 2018-06-29 20:15:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-29 20:15:36 --> Database Driver Class Initialized
INFO - 2018-06-29 20:15:36 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:15:36 --> Config Class Initialized
INFO - 2018-06-29 20:15:36 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:15:36 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:15:36 --> Utf8 Class Initialized
INFO - 2018-06-29 20:15:36 --> URI Class Initialized
INFO - 2018-06-29 20:15:36 --> Router Class Initialized
INFO - 2018-06-29 20:15:36 --> Output Class Initialized
INFO - 2018-06-29 20:15:36 --> Security Class Initialized
DEBUG - 2018-06-29 20:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:15:36 --> CSRF cookie sent
INFO - 2018-06-29 20:15:36 --> Input Class Initialized
INFO - 2018-06-29 20:15:36 --> Language Class Initialized
INFO - 2018-06-29 20:15:36 --> Loader Class Initialized
INFO - 2018-06-29 20:15:36 --> Helper loaded: url_helper
INFO - 2018-06-29 20:15:36 --> Helper loaded: form_helper
INFO - 2018-06-29 20:15:36 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:15:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:15:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:15:36 --> User Agent Class Initialized
INFO - 2018-06-29 20:15:36 --> Controller Class Initialized
INFO - 2018-06-29 20:15:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:15:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:15:36 --> Pixel_Model class loaded
INFO - 2018-06-29 20:15:36 --> Database Driver Class Initialized
INFO - 2018-06-29 20:15:36 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:15:36 --> Database Driver Class Initialized
INFO - 2018-06-29 20:15:36 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:15:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:15:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:15:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:15:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-06-29 20:15:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:15:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:15:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:15:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:15:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-06-29 20:15:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:15:36 --> Final output sent to browser
DEBUG - 2018-06-29 20:15:36 --> Total execution time: 0.0376
INFO - 2018-06-29 20:15:41 --> Config Class Initialized
INFO - 2018-06-29 20:15:41 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:15:41 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:15:41 --> Utf8 Class Initialized
INFO - 2018-06-29 20:15:41 --> URI Class Initialized
INFO - 2018-06-29 20:15:41 --> Router Class Initialized
INFO - 2018-06-29 20:15:41 --> Output Class Initialized
INFO - 2018-06-29 20:15:41 --> Security Class Initialized
DEBUG - 2018-06-29 20:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:15:41 --> CSRF cookie sent
INFO - 2018-06-29 20:15:41 --> CSRF token verified
INFO - 2018-06-29 20:15:41 --> Input Class Initialized
INFO - 2018-06-29 20:15:41 --> Language Class Initialized
INFO - 2018-06-29 20:15:41 --> Loader Class Initialized
INFO - 2018-06-29 20:15:41 --> Helper loaded: url_helper
INFO - 2018-06-29 20:15:41 --> Helper loaded: form_helper
INFO - 2018-06-29 20:15:41 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:15:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:15:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:15:41 --> User Agent Class Initialized
INFO - 2018-06-29 20:15:41 --> Controller Class Initialized
INFO - 2018-06-29 20:15:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:15:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:15:41 --> Pixel_Model class loaded
INFO - 2018-06-29 20:15:41 --> Database Driver Class Initialized
INFO - 2018-06-29 20:15:41 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:15:41 --> Form Validation Class Initialized
INFO - 2018-06-29 20:15:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-29 20:15:41 --> Database Driver Class Initialized
INFO - 2018-06-29 20:15:41 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:15:41 --> Config Class Initialized
INFO - 2018-06-29 20:15:41 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:15:41 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:15:41 --> Utf8 Class Initialized
INFO - 2018-06-29 20:15:41 --> URI Class Initialized
INFO - 2018-06-29 20:15:41 --> Router Class Initialized
INFO - 2018-06-29 20:15:41 --> Output Class Initialized
INFO - 2018-06-29 20:15:41 --> Security Class Initialized
DEBUG - 2018-06-29 20:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:15:41 --> CSRF cookie sent
INFO - 2018-06-29 20:15:41 --> Input Class Initialized
INFO - 2018-06-29 20:15:41 --> Language Class Initialized
INFO - 2018-06-29 20:15:41 --> Loader Class Initialized
INFO - 2018-06-29 20:15:41 --> Helper loaded: url_helper
INFO - 2018-06-29 20:15:41 --> Helper loaded: form_helper
INFO - 2018-06-29 20:15:41 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:15:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:15:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:15:41 --> User Agent Class Initialized
INFO - 2018-06-29 20:15:41 --> Controller Class Initialized
INFO - 2018-06-29 20:15:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:15:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:15:41 --> Pixel_Model class loaded
INFO - 2018-06-29 20:15:41 --> Database Driver Class Initialized
INFO - 2018-06-29 20:15:41 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:15:41 --> Database Driver Class Initialized
INFO - 2018-06-29 20:15:41 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:15:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:15:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:15:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:15:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:15:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:15:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:15:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:15:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-06-29 20:15:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:15:41 --> Final output sent to browser
DEBUG - 2018-06-29 20:15:41 --> Total execution time: 0.0356
INFO - 2018-06-29 20:15:48 --> Config Class Initialized
INFO - 2018-06-29 20:15:48 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:15:48 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:15:48 --> Utf8 Class Initialized
INFO - 2018-06-29 20:15:48 --> URI Class Initialized
INFO - 2018-06-29 20:15:48 --> Router Class Initialized
INFO - 2018-06-29 20:15:48 --> Output Class Initialized
INFO - 2018-06-29 20:15:48 --> Security Class Initialized
DEBUG - 2018-06-29 20:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:15:48 --> CSRF cookie sent
INFO - 2018-06-29 20:15:48 --> CSRF token verified
INFO - 2018-06-29 20:15:48 --> Input Class Initialized
INFO - 2018-06-29 20:15:48 --> Language Class Initialized
INFO - 2018-06-29 20:15:48 --> Loader Class Initialized
INFO - 2018-06-29 20:15:48 --> Helper loaded: url_helper
INFO - 2018-06-29 20:15:48 --> Helper loaded: form_helper
INFO - 2018-06-29 20:15:48 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:15:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:15:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:15:48 --> User Agent Class Initialized
INFO - 2018-06-29 20:15:48 --> Controller Class Initialized
INFO - 2018-06-29 20:15:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:15:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:15:48 --> Pixel_Model class loaded
INFO - 2018-06-29 20:15:48 --> Database Driver Class Initialized
INFO - 2018-06-29 20:15:48 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:15:48 --> Form Validation Class Initialized
INFO - 2018-06-29 20:15:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-29 20:15:48 --> Database Driver Class Initialized
INFO - 2018-06-29 20:15:48 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:15:48 --> Config Class Initialized
INFO - 2018-06-29 20:15:48 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:15:48 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:15:48 --> Utf8 Class Initialized
INFO - 2018-06-29 20:15:48 --> URI Class Initialized
INFO - 2018-06-29 20:15:48 --> Router Class Initialized
INFO - 2018-06-29 20:15:48 --> Output Class Initialized
INFO - 2018-06-29 20:15:48 --> Security Class Initialized
DEBUG - 2018-06-29 20:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:15:48 --> CSRF cookie sent
INFO - 2018-06-29 20:15:48 --> Input Class Initialized
INFO - 2018-06-29 20:15:48 --> Language Class Initialized
INFO - 2018-06-29 20:15:48 --> Loader Class Initialized
INFO - 2018-06-29 20:15:48 --> Helper loaded: url_helper
INFO - 2018-06-29 20:15:48 --> Helper loaded: form_helper
INFO - 2018-06-29 20:15:48 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:15:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:15:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:15:48 --> User Agent Class Initialized
INFO - 2018-06-29 20:15:48 --> Controller Class Initialized
INFO - 2018-06-29 20:15:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:15:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:15:48 --> Pixel_Model class loaded
INFO - 2018-06-29 20:15:48 --> Database Driver Class Initialized
INFO - 2018-06-29 20:15:48 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:15:48 --> Database Driver Class Initialized
INFO - 2018-06-29 20:15:48 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:15:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:15:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:15:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:15:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:15:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:15:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:15:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:15:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-06-29 20:15:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:15:48 --> Final output sent to browser
DEBUG - 2018-06-29 20:15:48 --> Total execution time: 0.0407
INFO - 2018-06-29 20:15:55 --> Config Class Initialized
INFO - 2018-06-29 20:15:55 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:15:55 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:15:55 --> Utf8 Class Initialized
INFO - 2018-06-29 20:15:55 --> URI Class Initialized
INFO - 2018-06-29 20:15:55 --> Router Class Initialized
INFO - 2018-06-29 20:15:55 --> Output Class Initialized
INFO - 2018-06-29 20:15:55 --> Security Class Initialized
DEBUG - 2018-06-29 20:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:15:55 --> CSRF cookie sent
INFO - 2018-06-29 20:15:55 --> CSRF token verified
INFO - 2018-06-29 20:15:55 --> Input Class Initialized
INFO - 2018-06-29 20:15:55 --> Language Class Initialized
INFO - 2018-06-29 20:15:55 --> Loader Class Initialized
INFO - 2018-06-29 20:15:55 --> Helper loaded: url_helper
INFO - 2018-06-29 20:15:55 --> Helper loaded: form_helper
INFO - 2018-06-29 20:15:55 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:15:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:15:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:15:55 --> User Agent Class Initialized
INFO - 2018-06-29 20:15:55 --> Controller Class Initialized
INFO - 2018-06-29 20:15:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:15:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:15:55 --> Pixel_Model class loaded
INFO - 2018-06-29 20:15:55 --> Database Driver Class Initialized
INFO - 2018-06-29 20:15:55 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:15:55 --> Form Validation Class Initialized
INFO - 2018-06-29 20:15:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-29 20:15:55 --> Database Driver Class Initialized
INFO - 2018-06-29 20:15:55 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:15:55 --> Config Class Initialized
INFO - 2018-06-29 20:15:55 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:15:55 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:15:55 --> Utf8 Class Initialized
INFO - 2018-06-29 20:15:55 --> URI Class Initialized
INFO - 2018-06-29 20:15:55 --> Router Class Initialized
INFO - 2018-06-29 20:15:55 --> Output Class Initialized
INFO - 2018-06-29 20:15:55 --> Security Class Initialized
DEBUG - 2018-06-29 20:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:15:55 --> CSRF cookie sent
INFO - 2018-06-29 20:15:55 --> Input Class Initialized
INFO - 2018-06-29 20:15:55 --> Language Class Initialized
INFO - 2018-06-29 20:15:55 --> Loader Class Initialized
INFO - 2018-06-29 20:15:55 --> Helper loaded: url_helper
INFO - 2018-06-29 20:15:55 --> Helper loaded: form_helper
INFO - 2018-06-29 20:15:55 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:15:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:15:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:15:55 --> User Agent Class Initialized
INFO - 2018-06-29 20:15:55 --> Controller Class Initialized
INFO - 2018-06-29 20:15:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:15:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:15:55 --> Pixel_Model class loaded
INFO - 2018-06-29 20:15:55 --> Database Driver Class Initialized
INFO - 2018-06-29 20:15:55 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:15:55 --> Database Driver Class Initialized
INFO - 2018-06-29 20:15:55 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:15:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:15:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:15:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:15:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:15:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:15:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:15:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:15:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-06-29 20:15:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:15:55 --> Final output sent to browser
DEBUG - 2018-06-29 20:15:55 --> Total execution time: 0.0405
INFO - 2018-06-29 20:16:07 --> Config Class Initialized
INFO - 2018-06-29 20:16:07 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:16:07 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:16:07 --> Utf8 Class Initialized
INFO - 2018-06-29 20:16:07 --> URI Class Initialized
INFO - 2018-06-29 20:16:07 --> Router Class Initialized
INFO - 2018-06-29 20:16:07 --> Output Class Initialized
INFO - 2018-06-29 20:16:07 --> Security Class Initialized
DEBUG - 2018-06-29 20:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:16:07 --> CSRF cookie sent
INFO - 2018-06-29 20:16:07 --> CSRF token verified
INFO - 2018-06-29 20:16:07 --> Input Class Initialized
INFO - 2018-06-29 20:16:07 --> Language Class Initialized
INFO - 2018-06-29 20:16:07 --> Loader Class Initialized
INFO - 2018-06-29 20:16:07 --> Helper loaded: url_helper
INFO - 2018-06-29 20:16:07 --> Helper loaded: form_helper
INFO - 2018-06-29 20:16:07 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:16:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:16:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:16:07 --> User Agent Class Initialized
INFO - 2018-06-29 20:16:07 --> Controller Class Initialized
INFO - 2018-06-29 20:16:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:16:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:16:07 --> Pixel_Model class loaded
INFO - 2018-06-29 20:16:07 --> Database Driver Class Initialized
INFO - 2018-06-29 20:16:07 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:16:07 --> Form Validation Class Initialized
INFO - 2018-06-29 20:16:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-29 20:16:07 --> Database Driver Class Initialized
INFO - 2018-06-29 20:16:07 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:16:07 --> Config Class Initialized
INFO - 2018-06-29 20:16:07 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:16:07 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:16:07 --> Utf8 Class Initialized
INFO - 2018-06-29 20:16:07 --> URI Class Initialized
INFO - 2018-06-29 20:16:07 --> Router Class Initialized
INFO - 2018-06-29 20:16:07 --> Output Class Initialized
INFO - 2018-06-29 20:16:07 --> Security Class Initialized
DEBUG - 2018-06-29 20:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:16:07 --> CSRF cookie sent
INFO - 2018-06-29 20:16:07 --> Input Class Initialized
INFO - 2018-06-29 20:16:07 --> Language Class Initialized
INFO - 2018-06-29 20:16:07 --> Loader Class Initialized
INFO - 2018-06-29 20:16:07 --> Helper loaded: url_helper
INFO - 2018-06-29 20:16:07 --> Helper loaded: form_helper
INFO - 2018-06-29 20:16:07 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:16:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:16:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:16:07 --> User Agent Class Initialized
INFO - 2018-06-29 20:16:07 --> Controller Class Initialized
INFO - 2018-06-29 20:16:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:16:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:16:07 --> Pixel_Model class loaded
INFO - 2018-06-29 20:16:07 --> Database Driver Class Initialized
INFO - 2018-06-29 20:16:07 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:16:07 --> Database Driver Class Initialized
INFO - 2018-06-29 20:16:07 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:16:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:16:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:16:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:16:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:16:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:16:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:16:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:16:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-06-29 20:16:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:16:07 --> Final output sent to browser
DEBUG - 2018-06-29 20:16:07 --> Total execution time: 0.0383
INFO - 2018-06-29 20:17:49 --> Config Class Initialized
INFO - 2018-06-29 20:17:49 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:17:49 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:17:49 --> Utf8 Class Initialized
INFO - 2018-06-29 20:17:49 --> URI Class Initialized
INFO - 2018-06-29 20:17:49 --> Router Class Initialized
INFO - 2018-06-29 20:17:49 --> Output Class Initialized
INFO - 2018-06-29 20:17:49 --> Security Class Initialized
DEBUG - 2018-06-29 20:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:17:49 --> CSRF cookie sent
INFO - 2018-06-29 20:17:49 --> Input Class Initialized
INFO - 2018-06-29 20:17:49 --> Language Class Initialized
INFO - 2018-06-29 20:17:49 --> Loader Class Initialized
INFO - 2018-06-29 20:17:49 --> Helper loaded: url_helper
INFO - 2018-06-29 20:17:49 --> Helper loaded: form_helper
INFO - 2018-06-29 20:17:49 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:17:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:17:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:17:49 --> User Agent Class Initialized
INFO - 2018-06-29 20:17:49 --> Controller Class Initialized
INFO - 2018-06-29 20:17:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:17:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:17:49 --> Pixel_Model class loaded
INFO - 2018-06-29 20:17:49 --> Database Driver Class Initialized
INFO - 2018-06-29 20:17:49 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:17:49 --> Database Driver Class Initialized
INFO - 2018-06-29 20:17:49 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:17:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:17:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:17:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:17:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:17:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:17:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:17:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:17:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-06-29 20:17:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:17:49 --> Final output sent to browser
DEBUG - 2018-06-29 20:17:49 --> Total execution time: 0.0419
INFO - 2018-06-29 20:17:59 --> Config Class Initialized
INFO - 2018-06-29 20:17:59 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:17:59 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:17:59 --> Utf8 Class Initialized
INFO - 2018-06-29 20:17:59 --> URI Class Initialized
INFO - 2018-06-29 20:17:59 --> Router Class Initialized
INFO - 2018-06-29 20:17:59 --> Output Class Initialized
INFO - 2018-06-29 20:17:59 --> Security Class Initialized
DEBUG - 2018-06-29 20:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:17:59 --> CSRF cookie sent
INFO - 2018-06-29 20:17:59 --> CSRF token verified
INFO - 2018-06-29 20:17:59 --> Input Class Initialized
INFO - 2018-06-29 20:17:59 --> Language Class Initialized
INFO - 2018-06-29 20:17:59 --> Loader Class Initialized
INFO - 2018-06-29 20:17:59 --> Helper loaded: url_helper
INFO - 2018-06-29 20:17:59 --> Helper loaded: form_helper
INFO - 2018-06-29 20:17:59 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:17:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:17:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:17:59 --> User Agent Class Initialized
INFO - 2018-06-29 20:17:59 --> Controller Class Initialized
INFO - 2018-06-29 20:17:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:17:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:17:59 --> Pixel_Model class loaded
INFO - 2018-06-29 20:17:59 --> Database Driver Class Initialized
INFO - 2018-06-29 20:17:59 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:17:59 --> Form Validation Class Initialized
INFO - 2018-06-29 20:17:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-29 20:17:59 --> Database Driver Class Initialized
INFO - 2018-06-29 20:17:59 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:17:59 --> Config Class Initialized
INFO - 2018-06-29 20:17:59 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:17:59 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:17:59 --> Utf8 Class Initialized
INFO - 2018-06-29 20:17:59 --> URI Class Initialized
INFO - 2018-06-29 20:17:59 --> Router Class Initialized
INFO - 2018-06-29 20:17:59 --> Output Class Initialized
INFO - 2018-06-29 20:17:59 --> Security Class Initialized
DEBUG - 2018-06-29 20:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:17:59 --> CSRF cookie sent
INFO - 2018-06-29 20:17:59 --> Input Class Initialized
INFO - 2018-06-29 20:17:59 --> Language Class Initialized
INFO - 2018-06-29 20:17:59 --> Loader Class Initialized
INFO - 2018-06-29 20:17:59 --> Helper loaded: url_helper
INFO - 2018-06-29 20:17:59 --> Helper loaded: form_helper
INFO - 2018-06-29 20:17:59 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:17:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:17:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:17:59 --> User Agent Class Initialized
INFO - 2018-06-29 20:17:59 --> Controller Class Initialized
INFO - 2018-06-29 20:17:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:17:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:17:59 --> Pixel_Model class loaded
INFO - 2018-06-29 20:17:59 --> Database Driver Class Initialized
INFO - 2018-06-29 20:17:59 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:17:59 --> Database Driver Class Initialized
INFO - 2018-06-29 20:17:59 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:17:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:17:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:17:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:17:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:17:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:17:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:17:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:17:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_title.php
INFO - 2018-06-29 20:17:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:17:59 --> Final output sent to browser
DEBUG - 2018-06-29 20:17:59 --> Total execution time: 0.0509
INFO - 2018-06-29 20:18:06 --> Config Class Initialized
INFO - 2018-06-29 20:18:06 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:18:06 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:18:06 --> Utf8 Class Initialized
INFO - 2018-06-29 20:18:06 --> URI Class Initialized
INFO - 2018-06-29 20:18:06 --> Router Class Initialized
INFO - 2018-06-29 20:18:06 --> Output Class Initialized
INFO - 2018-06-29 20:18:06 --> Security Class Initialized
DEBUG - 2018-06-29 20:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:18:06 --> CSRF cookie sent
INFO - 2018-06-29 20:18:06 --> CSRF token verified
INFO - 2018-06-29 20:18:06 --> Input Class Initialized
INFO - 2018-06-29 20:18:06 --> Language Class Initialized
INFO - 2018-06-29 20:18:06 --> Loader Class Initialized
INFO - 2018-06-29 20:18:06 --> Helper loaded: url_helper
INFO - 2018-06-29 20:18:06 --> Helper loaded: form_helper
INFO - 2018-06-29 20:18:06 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:18:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:18:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:18:06 --> User Agent Class Initialized
INFO - 2018-06-29 20:18:06 --> Controller Class Initialized
INFO - 2018-06-29 20:18:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:18:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:18:06 --> Pixel_Model class loaded
INFO - 2018-06-29 20:18:06 --> Database Driver Class Initialized
INFO - 2018-06-29 20:18:06 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:18:06 --> Form Validation Class Initialized
INFO - 2018-06-29 20:18:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-29 20:18:06 --> Database Driver Class Initialized
INFO - 2018-06-29 20:18:06 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:18:06 --> Config Class Initialized
INFO - 2018-06-29 20:18:06 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:18:06 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:18:06 --> Utf8 Class Initialized
INFO - 2018-06-29 20:18:06 --> URI Class Initialized
INFO - 2018-06-29 20:18:06 --> Router Class Initialized
INFO - 2018-06-29 20:18:06 --> Output Class Initialized
INFO - 2018-06-29 20:18:06 --> Security Class Initialized
DEBUG - 2018-06-29 20:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:18:06 --> CSRF cookie sent
INFO - 2018-06-29 20:18:06 --> Input Class Initialized
INFO - 2018-06-29 20:18:06 --> Language Class Initialized
INFO - 2018-06-29 20:18:06 --> Loader Class Initialized
INFO - 2018-06-29 20:18:06 --> Helper loaded: url_helper
INFO - 2018-06-29 20:18:06 --> Helper loaded: form_helper
INFO - 2018-06-29 20:18:06 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:18:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:18:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:18:06 --> User Agent Class Initialized
INFO - 2018-06-29 20:18:06 --> Controller Class Initialized
INFO - 2018-06-29 20:18:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:18:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:18:06 --> Pixel_Model class loaded
INFO - 2018-06-29 20:18:06 --> Database Driver Class Initialized
INFO - 2018-06-29 20:18:06 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:18:06 --> Database Driver Class Initialized
INFO - 2018-06-29 20:18:06 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:18:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:18:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:18:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:18:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:18:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:18:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:18:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:18:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-06-29 20:18:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:18:06 --> Final output sent to browser
DEBUG - 2018-06-29 20:18:06 --> Total execution time: 0.0461
INFO - 2018-06-29 20:18:14 --> Config Class Initialized
INFO - 2018-06-29 20:18:14 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:18:14 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:18:14 --> Utf8 Class Initialized
INFO - 2018-06-29 20:18:14 --> URI Class Initialized
INFO - 2018-06-29 20:18:14 --> Router Class Initialized
INFO - 2018-06-29 20:18:14 --> Output Class Initialized
INFO - 2018-06-29 20:18:14 --> Security Class Initialized
DEBUG - 2018-06-29 20:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:18:14 --> CSRF cookie sent
INFO - 2018-06-29 20:18:14 --> CSRF token verified
INFO - 2018-06-29 20:18:14 --> Input Class Initialized
INFO - 2018-06-29 20:18:14 --> Language Class Initialized
INFO - 2018-06-29 20:18:14 --> Loader Class Initialized
INFO - 2018-06-29 20:18:14 --> Helper loaded: url_helper
INFO - 2018-06-29 20:18:14 --> Helper loaded: form_helper
INFO - 2018-06-29 20:18:14 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:18:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:18:14 --> User Agent Class Initialized
INFO - 2018-06-29 20:18:14 --> Controller Class Initialized
INFO - 2018-06-29 20:18:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:18:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:18:14 --> Pixel_Model class loaded
INFO - 2018-06-29 20:18:14 --> Database Driver Class Initialized
INFO - 2018-06-29 20:18:14 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:18:14 --> Form Validation Class Initialized
INFO - 2018-06-29 20:18:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-29 20:18:14 --> Database Driver Class Initialized
INFO - 2018-06-29 20:18:14 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:18:14 --> Config Class Initialized
INFO - 2018-06-29 20:18:14 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:18:14 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:18:14 --> Utf8 Class Initialized
INFO - 2018-06-29 20:18:14 --> URI Class Initialized
INFO - 2018-06-29 20:18:14 --> Router Class Initialized
INFO - 2018-06-29 20:18:14 --> Output Class Initialized
INFO - 2018-06-29 20:18:14 --> Security Class Initialized
DEBUG - 2018-06-29 20:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:18:14 --> CSRF cookie sent
INFO - 2018-06-29 20:18:14 --> Input Class Initialized
INFO - 2018-06-29 20:18:14 --> Language Class Initialized
INFO - 2018-06-29 20:18:14 --> Loader Class Initialized
INFO - 2018-06-29 20:18:14 --> Helper loaded: url_helper
INFO - 2018-06-29 20:18:14 --> Helper loaded: form_helper
INFO - 2018-06-29 20:18:14 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:18:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:18:14 --> User Agent Class Initialized
INFO - 2018-06-29 20:18:14 --> Controller Class Initialized
INFO - 2018-06-29 20:18:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:18:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:18:14 --> Pixel_Model class loaded
INFO - 2018-06-29 20:18:14 --> Database Driver Class Initialized
INFO - 2018-06-29 20:18:14 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:18:14 --> Database Driver Class Initialized
INFO - 2018-06-29 20:18:14 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:18:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:18:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:18:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:18:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:18:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:18:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:18:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:18:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-06-29 20:18:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:18:14 --> Final output sent to browser
DEBUG - 2018-06-29 20:18:14 --> Total execution time: 0.0361
INFO - 2018-06-29 20:18:28 --> Config Class Initialized
INFO - 2018-06-29 20:18:28 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:18:28 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:18:28 --> Utf8 Class Initialized
INFO - 2018-06-29 20:18:28 --> URI Class Initialized
INFO - 2018-06-29 20:18:28 --> Router Class Initialized
INFO - 2018-06-29 20:18:28 --> Output Class Initialized
INFO - 2018-06-29 20:18:28 --> Security Class Initialized
DEBUG - 2018-06-29 20:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:18:28 --> CSRF cookie sent
INFO - 2018-06-29 20:18:28 --> CSRF token verified
INFO - 2018-06-29 20:18:28 --> Input Class Initialized
INFO - 2018-06-29 20:18:28 --> Language Class Initialized
INFO - 2018-06-29 20:18:28 --> Loader Class Initialized
INFO - 2018-06-29 20:18:28 --> Helper loaded: url_helper
INFO - 2018-06-29 20:18:28 --> Helper loaded: form_helper
INFO - 2018-06-29 20:18:28 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:18:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:18:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:18:28 --> User Agent Class Initialized
INFO - 2018-06-29 20:18:28 --> Controller Class Initialized
INFO - 2018-06-29 20:18:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:18:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:18:28 --> Pixel_Model class loaded
INFO - 2018-06-29 20:18:28 --> Database Driver Class Initialized
INFO - 2018-06-29 20:18:28 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:18:28 --> Form Validation Class Initialized
INFO - 2018-06-29 20:18:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-29 20:18:28 --> Database Driver Class Initialized
INFO - 2018-06-29 20:18:28 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:18:28 --> Config Class Initialized
INFO - 2018-06-29 20:18:28 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:18:28 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:18:28 --> Utf8 Class Initialized
INFO - 2018-06-29 20:18:28 --> URI Class Initialized
INFO - 2018-06-29 20:18:28 --> Router Class Initialized
INFO - 2018-06-29 20:18:28 --> Output Class Initialized
INFO - 2018-06-29 20:18:28 --> Security Class Initialized
DEBUG - 2018-06-29 20:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:18:28 --> CSRF cookie sent
INFO - 2018-06-29 20:18:28 --> Input Class Initialized
INFO - 2018-06-29 20:18:28 --> Language Class Initialized
INFO - 2018-06-29 20:18:28 --> Loader Class Initialized
INFO - 2018-06-29 20:18:28 --> Helper loaded: url_helper
INFO - 2018-06-29 20:18:28 --> Helper loaded: form_helper
INFO - 2018-06-29 20:18:28 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:18:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:18:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:18:28 --> User Agent Class Initialized
INFO - 2018-06-29 20:18:28 --> Controller Class Initialized
INFO - 2018-06-29 20:18:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:18:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:18:28 --> Pixel_Model class loaded
INFO - 2018-06-29 20:18:28 --> Database Driver Class Initialized
INFO - 2018-06-29 20:18:28 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:18:28 --> Database Driver Class Initialized
INFO - 2018-06-29 20:18:28 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:18:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:18:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:18:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:18:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:18:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:18:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:18:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:18:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids_info.php
INFO - 2018-06-29 20:18:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:18:28 --> Final output sent to browser
DEBUG - 2018-06-29 20:18:28 --> Total execution time: 0.0410
INFO - 2018-06-29 20:18:40 --> Config Class Initialized
INFO - 2018-06-29 20:18:40 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:18:40 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:18:40 --> Utf8 Class Initialized
INFO - 2018-06-29 20:18:40 --> URI Class Initialized
INFO - 2018-06-29 20:18:40 --> Router Class Initialized
INFO - 2018-06-29 20:18:40 --> Output Class Initialized
INFO - 2018-06-29 20:18:40 --> Security Class Initialized
DEBUG - 2018-06-29 20:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:18:40 --> CSRF cookie sent
INFO - 2018-06-29 20:18:40 --> Input Class Initialized
INFO - 2018-06-29 20:18:40 --> Language Class Initialized
INFO - 2018-06-29 20:18:40 --> Loader Class Initialized
INFO - 2018-06-29 20:18:40 --> Helper loaded: url_helper
INFO - 2018-06-29 20:18:40 --> Helper loaded: form_helper
INFO - 2018-06-29 20:18:40 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:18:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:18:40 --> User Agent Class Initialized
INFO - 2018-06-29 20:18:40 --> Controller Class Initialized
INFO - 2018-06-29 20:18:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:18:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:18:40 --> Pixel_Model class loaded
INFO - 2018-06-29 20:18:40 --> Database Driver Class Initialized
INFO - 2018-06-29 20:18:40 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:18:40 --> Database Driver Class Initialized
INFO - 2018-06-29 20:18:40 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:18:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:18:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:18:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:18:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:18:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:18:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:18:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:18:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-06-29 20:18:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:18:40 --> Final output sent to browser
DEBUG - 2018-06-29 20:18:40 --> Total execution time: 0.0423
INFO - 2018-06-29 20:18:46 --> Config Class Initialized
INFO - 2018-06-29 20:18:46 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:18:46 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:18:46 --> Utf8 Class Initialized
INFO - 2018-06-29 20:18:46 --> URI Class Initialized
INFO - 2018-06-29 20:18:46 --> Router Class Initialized
INFO - 2018-06-29 20:18:46 --> Output Class Initialized
INFO - 2018-06-29 20:18:46 --> Security Class Initialized
DEBUG - 2018-06-29 20:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:18:46 --> CSRF cookie sent
INFO - 2018-06-29 20:18:46 --> CSRF token verified
INFO - 2018-06-29 20:18:46 --> Input Class Initialized
INFO - 2018-06-29 20:18:46 --> Language Class Initialized
INFO - 2018-06-29 20:18:46 --> Loader Class Initialized
INFO - 2018-06-29 20:18:46 --> Helper loaded: url_helper
INFO - 2018-06-29 20:18:46 --> Helper loaded: form_helper
INFO - 2018-06-29 20:18:46 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:18:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:18:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:18:46 --> User Agent Class Initialized
INFO - 2018-06-29 20:18:46 --> Controller Class Initialized
INFO - 2018-06-29 20:18:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:18:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:18:46 --> Pixel_Model class loaded
INFO - 2018-06-29 20:18:46 --> Database Driver Class Initialized
INFO - 2018-06-29 20:18:46 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:18:46 --> Form Validation Class Initialized
INFO - 2018-06-29 20:18:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-29 20:18:46 --> Database Driver Class Initialized
INFO - 2018-06-29 20:18:46 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:18:46 --> Config Class Initialized
INFO - 2018-06-29 20:18:46 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:18:46 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:18:46 --> Utf8 Class Initialized
INFO - 2018-06-29 20:18:46 --> URI Class Initialized
INFO - 2018-06-29 20:18:46 --> Router Class Initialized
INFO - 2018-06-29 20:18:46 --> Output Class Initialized
INFO - 2018-06-29 20:18:46 --> Security Class Initialized
DEBUG - 2018-06-29 20:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:18:46 --> CSRF cookie sent
INFO - 2018-06-29 20:18:46 --> Input Class Initialized
INFO - 2018-06-29 20:18:46 --> Language Class Initialized
INFO - 2018-06-29 20:18:46 --> Loader Class Initialized
INFO - 2018-06-29 20:18:46 --> Helper loaded: url_helper
INFO - 2018-06-29 20:18:46 --> Helper loaded: form_helper
INFO - 2018-06-29 20:18:46 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:18:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:18:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:18:46 --> User Agent Class Initialized
INFO - 2018-06-29 20:18:46 --> Controller Class Initialized
INFO - 2018-06-29 20:18:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:18:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:18:46 --> Pixel_Model class loaded
INFO - 2018-06-29 20:18:46 --> Database Driver Class Initialized
INFO - 2018-06-29 20:18:46 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:18:46 --> Database Driver Class Initialized
INFO - 2018-06-29 20:18:46 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:18:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:18:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:18:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:18:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:18:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:18:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:18:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:18:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids_info.php
INFO - 2018-06-29 20:18:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:18:46 --> Final output sent to browser
DEBUG - 2018-06-29 20:18:46 --> Total execution time: 0.0402
INFO - 2018-06-29 20:18:50 --> Config Class Initialized
INFO - 2018-06-29 20:18:50 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:18:50 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:18:50 --> Utf8 Class Initialized
INFO - 2018-06-29 20:18:50 --> URI Class Initialized
INFO - 2018-06-29 20:18:50 --> Router Class Initialized
INFO - 2018-06-29 20:18:50 --> Output Class Initialized
INFO - 2018-06-29 20:18:50 --> Security Class Initialized
DEBUG - 2018-06-29 20:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:18:50 --> CSRF cookie sent
INFO - 2018-06-29 20:18:50 --> Input Class Initialized
INFO - 2018-06-29 20:18:50 --> Language Class Initialized
INFO - 2018-06-29 20:18:50 --> Loader Class Initialized
INFO - 2018-06-29 20:18:50 --> Helper loaded: url_helper
INFO - 2018-06-29 20:18:50 --> Helper loaded: form_helper
INFO - 2018-06-29 20:18:50 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:18:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:18:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:18:50 --> User Agent Class Initialized
INFO - 2018-06-29 20:18:50 --> Controller Class Initialized
INFO - 2018-06-29 20:18:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:18:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:18:50 --> Pixel_Model class loaded
INFO - 2018-06-29 20:18:50 --> Database Driver Class Initialized
INFO - 2018-06-29 20:18:50 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:18:50 --> Database Driver Class Initialized
INFO - 2018-06-29 20:18:50 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:18:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:18:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:18:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:18:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:18:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:18:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:18:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:18:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-06-29 20:18:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:18:50 --> Final output sent to browser
DEBUG - 2018-06-29 20:18:50 --> Total execution time: 0.0332
INFO - 2018-06-29 20:19:57 --> Config Class Initialized
INFO - 2018-06-29 20:19:57 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:19:57 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:19:57 --> Utf8 Class Initialized
INFO - 2018-06-29 20:19:57 --> URI Class Initialized
INFO - 2018-06-29 20:19:57 --> Router Class Initialized
INFO - 2018-06-29 20:19:57 --> Output Class Initialized
INFO - 2018-06-29 20:19:57 --> Security Class Initialized
DEBUG - 2018-06-29 20:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:19:57 --> CSRF cookie sent
INFO - 2018-06-29 20:19:57 --> CSRF token verified
INFO - 2018-06-29 20:19:57 --> Input Class Initialized
INFO - 2018-06-29 20:19:57 --> Language Class Initialized
INFO - 2018-06-29 20:19:57 --> Loader Class Initialized
INFO - 2018-06-29 20:19:57 --> Helper loaded: url_helper
INFO - 2018-06-29 20:19:57 --> Helper loaded: form_helper
INFO - 2018-06-29 20:19:57 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:19:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:19:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:19:57 --> User Agent Class Initialized
INFO - 2018-06-29 20:19:57 --> Controller Class Initialized
INFO - 2018-06-29 20:19:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:19:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:19:57 --> Pixel_Model class loaded
INFO - 2018-06-29 20:19:57 --> Database Driver Class Initialized
INFO - 2018-06-29 20:19:57 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:19:57 --> Form Validation Class Initialized
INFO - 2018-06-29 20:19:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-29 20:19:57 --> Database Driver Class Initialized
INFO - 2018-06-29 20:19:57 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:19:57 --> Config Class Initialized
INFO - 2018-06-29 20:19:57 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:19:57 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:19:57 --> Utf8 Class Initialized
INFO - 2018-06-29 20:19:57 --> URI Class Initialized
INFO - 2018-06-29 20:19:57 --> Router Class Initialized
INFO - 2018-06-29 20:19:57 --> Output Class Initialized
INFO - 2018-06-29 20:19:57 --> Security Class Initialized
DEBUG - 2018-06-29 20:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:19:57 --> CSRF cookie sent
INFO - 2018-06-29 20:19:57 --> Input Class Initialized
INFO - 2018-06-29 20:19:57 --> Language Class Initialized
INFO - 2018-06-29 20:19:57 --> Loader Class Initialized
INFO - 2018-06-29 20:19:57 --> Helper loaded: url_helper
INFO - 2018-06-29 20:19:57 --> Helper loaded: form_helper
INFO - 2018-06-29 20:19:57 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:19:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:19:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:19:57 --> User Agent Class Initialized
INFO - 2018-06-29 20:19:57 --> Controller Class Initialized
INFO - 2018-06-29 20:19:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:19:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:19:57 --> Pixel_Model class loaded
INFO - 2018-06-29 20:19:57 --> Database Driver Class Initialized
INFO - 2018-06-29 20:19:57 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:19:57 --> Database Driver Class Initialized
INFO - 2018-06-29 20:19:57 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:19:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:19:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:19:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:19:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:19:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:19:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:19:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:19:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids_info.php
INFO - 2018-06-29 20:19:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:19:57 --> Final output sent to browser
DEBUG - 2018-06-29 20:19:57 --> Total execution time: 0.0431
INFO - 2018-06-29 20:20:15 --> Config Class Initialized
INFO - 2018-06-29 20:20:15 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:20:15 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:20:15 --> Utf8 Class Initialized
INFO - 2018-06-29 20:20:15 --> URI Class Initialized
INFO - 2018-06-29 20:20:15 --> Router Class Initialized
INFO - 2018-06-29 20:20:15 --> Output Class Initialized
INFO - 2018-06-29 20:20:15 --> Security Class Initialized
DEBUG - 2018-06-29 20:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:20:15 --> CSRF cookie sent
INFO - 2018-06-29 20:20:15 --> Input Class Initialized
INFO - 2018-06-29 20:20:15 --> Language Class Initialized
INFO - 2018-06-29 20:20:15 --> Loader Class Initialized
INFO - 2018-06-29 20:20:15 --> Helper loaded: url_helper
INFO - 2018-06-29 20:20:15 --> Helper loaded: form_helper
INFO - 2018-06-29 20:20:15 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:20:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:20:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:20:15 --> User Agent Class Initialized
INFO - 2018-06-29 20:20:15 --> Controller Class Initialized
INFO - 2018-06-29 20:20:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:20:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:20:15 --> CSRF cookie sent
INFO - 2018-06-29 20:20:15 --> Config Class Initialized
INFO - 2018-06-29 20:20:15 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:20:15 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:20:15 --> Utf8 Class Initialized
INFO - 2018-06-29 20:20:15 --> URI Class Initialized
DEBUG - 2018-06-29 20:20:15 --> No URI present. Default controller set.
INFO - 2018-06-29 20:20:15 --> Router Class Initialized
INFO - 2018-06-29 20:20:15 --> Output Class Initialized
INFO - 2018-06-29 20:20:15 --> Security Class Initialized
DEBUG - 2018-06-29 20:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:20:15 --> CSRF cookie sent
INFO - 2018-06-29 20:20:15 --> Input Class Initialized
INFO - 2018-06-29 20:20:15 --> Language Class Initialized
INFO - 2018-06-29 20:20:15 --> Loader Class Initialized
INFO - 2018-06-29 20:20:15 --> Helper loaded: url_helper
INFO - 2018-06-29 20:20:15 --> Helper loaded: form_helper
INFO - 2018-06-29 20:20:15 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:20:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:20:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:20:15 --> User Agent Class Initialized
INFO - 2018-06-29 20:20:15 --> Controller Class Initialized
INFO - 2018-06-29 20:20:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:20:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:20:15 --> Pixel_Model class loaded
INFO - 2018-06-29 20:20:15 --> Database Driver Class Initialized
INFO - 2018-06-29 20:20:15 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:20:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:20:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:20:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-29 20:20:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:20:15 --> Final output sent to browser
DEBUG - 2018-06-29 20:20:15 --> Total execution time: 0.0444
INFO - 2018-06-29 20:20:17 --> Config Class Initialized
INFO - 2018-06-29 20:20:17 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:20:17 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:20:17 --> Utf8 Class Initialized
INFO - 2018-06-29 20:20:17 --> URI Class Initialized
INFO - 2018-06-29 20:20:17 --> Router Class Initialized
INFO - 2018-06-29 20:20:17 --> Output Class Initialized
INFO - 2018-06-29 20:20:17 --> Security Class Initialized
DEBUG - 2018-06-29 20:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:20:17 --> CSRF cookie sent
INFO - 2018-06-29 20:20:17 --> Input Class Initialized
INFO - 2018-06-29 20:20:17 --> Language Class Initialized
INFO - 2018-06-29 20:20:17 --> Loader Class Initialized
INFO - 2018-06-29 20:20:17 --> Helper loaded: url_helper
INFO - 2018-06-29 20:20:17 --> Helper loaded: form_helper
INFO - 2018-06-29 20:20:17 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:20:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:20:17 --> User Agent Class Initialized
INFO - 2018-06-29 20:20:17 --> Controller Class Initialized
INFO - 2018-06-29 20:20:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:20:17 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-29 20:20:17 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-29 20:20:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:20:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:20:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:20:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-29 20:20:17 --> Could not find the language line "req_email"
INFO - 2018-06-29 20:20:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-06-29 20:20:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:20:17 --> Final output sent to browser
DEBUG - 2018-06-29 20:20:17 --> Total execution time: 0.0203
INFO - 2018-06-29 20:20:21 --> Config Class Initialized
INFO - 2018-06-29 20:20:21 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:20:21 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:20:21 --> Utf8 Class Initialized
INFO - 2018-06-29 20:20:21 --> URI Class Initialized
INFO - 2018-06-29 20:20:21 --> Router Class Initialized
INFO - 2018-06-29 20:20:21 --> Output Class Initialized
INFO - 2018-06-29 20:20:21 --> Security Class Initialized
DEBUG - 2018-06-29 20:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:20:21 --> CSRF cookie sent
INFO - 2018-06-29 20:20:21 --> CSRF token verified
INFO - 2018-06-29 20:20:21 --> Input Class Initialized
INFO - 2018-06-29 20:20:21 --> Language Class Initialized
INFO - 2018-06-29 20:20:21 --> Loader Class Initialized
INFO - 2018-06-29 20:20:21 --> Helper loaded: url_helper
INFO - 2018-06-29 20:20:21 --> Helper loaded: form_helper
INFO - 2018-06-29 20:20:21 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:20:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:20:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:20:21 --> User Agent Class Initialized
INFO - 2018-06-29 20:20:21 --> Controller Class Initialized
INFO - 2018-06-29 20:20:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:20:21 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-29 20:20:21 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-29 20:20:21 --> Form Validation Class Initialized
INFO - 2018-06-29 20:20:21 --> Pixel_Model class loaded
INFO - 2018-06-29 20:20:21 --> Database Driver Class Initialized
INFO - 2018-06-29 20:20:21 --> Model "AuthenticationModel" initialized
INFO - 2018-06-29 20:20:21 --> Config Class Initialized
INFO - 2018-06-29 20:20:21 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:20:21 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:20:21 --> Utf8 Class Initialized
INFO - 2018-06-29 20:20:21 --> URI Class Initialized
INFO - 2018-06-29 20:20:21 --> Router Class Initialized
INFO - 2018-06-29 20:20:21 --> Output Class Initialized
INFO - 2018-06-29 20:20:21 --> Security Class Initialized
DEBUG - 2018-06-29 20:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:20:21 --> CSRF cookie sent
INFO - 2018-06-29 20:20:21 --> Input Class Initialized
INFO - 2018-06-29 20:20:21 --> Language Class Initialized
INFO - 2018-06-29 20:20:21 --> Loader Class Initialized
INFO - 2018-06-29 20:20:21 --> Helper loaded: url_helper
INFO - 2018-06-29 20:20:21 --> Helper loaded: form_helper
INFO - 2018-06-29 20:20:21 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:20:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:20:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:20:21 --> User Agent Class Initialized
INFO - 2018-06-29 20:20:21 --> Controller Class Initialized
INFO - 2018-06-29 20:20:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:20:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:20:21 --> Pixel_Model class loaded
INFO - 2018-06-29 20:20:21 --> Database Driver Class Initialized
INFO - 2018-06-29 20:20:21 --> Model "MyAccountModel" initialized
INFO - 2018-06-29 20:20:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:20:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:20:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:20:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:20:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:20:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/application_list.php
INFO - 2018-06-29 20:20:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:20:21 --> Final output sent to browser
DEBUG - 2018-06-29 20:20:21 --> Total execution time: 0.0323
INFO - 2018-06-29 20:20:24 --> Config Class Initialized
INFO - 2018-06-29 20:20:24 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:20:24 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:20:24 --> Utf8 Class Initialized
INFO - 2018-06-29 20:20:24 --> URI Class Initialized
INFO - 2018-06-29 20:20:24 --> Router Class Initialized
INFO - 2018-06-29 20:20:24 --> Output Class Initialized
INFO - 2018-06-29 20:20:24 --> Security Class Initialized
DEBUG - 2018-06-29 20:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:20:24 --> CSRF cookie sent
INFO - 2018-06-29 20:20:24 --> Input Class Initialized
INFO - 2018-06-29 20:20:24 --> Language Class Initialized
INFO - 2018-06-29 20:20:24 --> Loader Class Initialized
INFO - 2018-06-29 20:20:24 --> Helper loaded: url_helper
INFO - 2018-06-29 20:20:24 --> Helper loaded: form_helper
INFO - 2018-06-29 20:20:24 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:20:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:20:24 --> User Agent Class Initialized
INFO - 2018-06-29 20:20:24 --> Controller Class Initialized
INFO - 2018-06-29 20:20:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:20:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:20:24 --> Pixel_Model class loaded
INFO - 2018-06-29 20:20:24 --> Database Driver Class Initialized
INFO - 2018-06-29 20:20:24 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:20:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:20:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:20:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:20:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:20:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:20:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:20:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:20:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-06-29 20:20:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:20:24 --> Final output sent to browser
DEBUG - 2018-06-29 20:20:24 --> Total execution time: 0.0317
INFO - 2018-06-29 20:20:28 --> Config Class Initialized
INFO - 2018-06-29 20:20:28 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:20:28 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:20:28 --> Utf8 Class Initialized
INFO - 2018-06-29 20:20:28 --> URI Class Initialized
INFO - 2018-06-29 20:20:28 --> Router Class Initialized
INFO - 2018-06-29 20:20:28 --> Output Class Initialized
INFO - 2018-06-29 20:20:28 --> Security Class Initialized
DEBUG - 2018-06-29 20:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:20:28 --> CSRF cookie sent
INFO - 2018-06-29 20:20:28 --> CSRF token verified
INFO - 2018-06-29 20:20:28 --> Input Class Initialized
INFO - 2018-06-29 20:20:28 --> Language Class Initialized
INFO - 2018-06-29 20:20:28 --> Loader Class Initialized
INFO - 2018-06-29 20:20:28 --> Helper loaded: url_helper
INFO - 2018-06-29 20:20:28 --> Helper loaded: form_helper
INFO - 2018-06-29 20:20:28 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:20:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:20:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:20:28 --> User Agent Class Initialized
INFO - 2018-06-29 20:20:28 --> Controller Class Initialized
INFO - 2018-06-29 20:20:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:20:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:20:28 --> Pixel_Model class loaded
INFO - 2018-06-29 20:20:28 --> Database Driver Class Initialized
INFO - 2018-06-29 20:20:28 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:20:28 --> Form Validation Class Initialized
INFO - 2018-06-29 20:20:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-29 20:20:28 --> Database Driver Class Initialized
INFO - 2018-06-29 20:20:28 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:20:28 --> Config Class Initialized
INFO - 2018-06-29 20:20:28 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:20:28 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:20:28 --> Utf8 Class Initialized
INFO - 2018-06-29 20:20:28 --> URI Class Initialized
INFO - 2018-06-29 20:20:28 --> Router Class Initialized
INFO - 2018-06-29 20:20:28 --> Output Class Initialized
INFO - 2018-06-29 20:20:28 --> Security Class Initialized
DEBUG - 2018-06-29 20:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:20:28 --> CSRF cookie sent
INFO - 2018-06-29 20:20:28 --> Input Class Initialized
INFO - 2018-06-29 20:20:28 --> Language Class Initialized
INFO - 2018-06-29 20:20:28 --> Loader Class Initialized
INFO - 2018-06-29 20:20:28 --> Helper loaded: url_helper
INFO - 2018-06-29 20:20:28 --> Helper loaded: form_helper
INFO - 2018-06-29 20:20:28 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:20:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:20:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:20:28 --> User Agent Class Initialized
INFO - 2018-06-29 20:20:28 --> Controller Class Initialized
INFO - 2018-06-29 20:20:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:20:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:20:28 --> Pixel_Model class loaded
INFO - 2018-06-29 20:20:28 --> Database Driver Class Initialized
INFO - 2018-06-29 20:20:28 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:20:28 --> Database Driver Class Initialized
INFO - 2018-06-29 20:20:28 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:20:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:20:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:20:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:20:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:20:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:20:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:20:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:20:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-06-29 20:20:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:20:28 --> Final output sent to browser
DEBUG - 2018-06-29 20:20:28 --> Total execution time: 0.0434
INFO - 2018-06-29 20:20:31 --> Config Class Initialized
INFO - 2018-06-29 20:20:31 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:20:31 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:20:31 --> Utf8 Class Initialized
INFO - 2018-06-29 20:20:31 --> URI Class Initialized
INFO - 2018-06-29 20:20:31 --> Router Class Initialized
INFO - 2018-06-29 20:20:31 --> Output Class Initialized
INFO - 2018-06-29 20:20:31 --> Security Class Initialized
DEBUG - 2018-06-29 20:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:20:31 --> CSRF cookie sent
INFO - 2018-06-29 20:20:31 --> CSRF token verified
INFO - 2018-06-29 20:20:31 --> Input Class Initialized
INFO - 2018-06-29 20:20:31 --> Language Class Initialized
INFO - 2018-06-29 20:20:31 --> Loader Class Initialized
INFO - 2018-06-29 20:20:31 --> Helper loaded: url_helper
INFO - 2018-06-29 20:20:31 --> Helper loaded: form_helper
INFO - 2018-06-29 20:20:31 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:20:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:20:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:20:31 --> User Agent Class Initialized
INFO - 2018-06-29 20:20:31 --> Controller Class Initialized
INFO - 2018-06-29 20:20:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:20:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:20:31 --> Pixel_Model class loaded
INFO - 2018-06-29 20:20:31 --> Database Driver Class Initialized
INFO - 2018-06-29 20:20:31 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:20:31 --> Form Validation Class Initialized
INFO - 2018-06-29 20:20:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-29 20:20:31 --> Database Driver Class Initialized
INFO - 2018-06-29 20:20:31 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:20:31 --> Config Class Initialized
INFO - 2018-06-29 20:20:31 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:20:31 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:20:31 --> Utf8 Class Initialized
INFO - 2018-06-29 20:20:31 --> URI Class Initialized
INFO - 2018-06-29 20:20:31 --> Router Class Initialized
INFO - 2018-06-29 20:20:31 --> Output Class Initialized
INFO - 2018-06-29 20:20:31 --> Security Class Initialized
DEBUG - 2018-06-29 20:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:20:31 --> CSRF cookie sent
INFO - 2018-06-29 20:20:31 --> Input Class Initialized
INFO - 2018-06-29 20:20:31 --> Language Class Initialized
INFO - 2018-06-29 20:20:32 --> Loader Class Initialized
INFO - 2018-06-29 20:20:32 --> Helper loaded: url_helper
INFO - 2018-06-29 20:20:32 --> Helper loaded: form_helper
INFO - 2018-06-29 20:20:32 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:20:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:20:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:20:32 --> User Agent Class Initialized
INFO - 2018-06-29 20:20:32 --> Controller Class Initialized
INFO - 2018-06-29 20:20:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:20:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:20:32 --> Pixel_Model class loaded
INFO - 2018-06-29 20:20:32 --> Database Driver Class Initialized
INFO - 2018-06-29 20:20:32 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:20:32 --> Database Driver Class Initialized
INFO - 2018-06-29 20:20:32 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:20:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:20:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:20:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:20:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:20:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:20:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:20:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:20:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-06-29 20:20:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:20:32 --> Final output sent to browser
DEBUG - 2018-06-29 20:20:32 --> Total execution time: 0.0387
INFO - 2018-06-29 20:20:34 --> Config Class Initialized
INFO - 2018-06-29 20:20:34 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:20:34 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:20:34 --> Utf8 Class Initialized
INFO - 2018-06-29 20:20:34 --> URI Class Initialized
INFO - 2018-06-29 20:20:34 --> Router Class Initialized
INFO - 2018-06-29 20:20:34 --> Output Class Initialized
INFO - 2018-06-29 20:20:34 --> Security Class Initialized
DEBUG - 2018-06-29 20:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:20:34 --> CSRF cookie sent
INFO - 2018-06-29 20:20:34 --> CSRF token verified
INFO - 2018-06-29 20:20:34 --> Input Class Initialized
INFO - 2018-06-29 20:20:34 --> Language Class Initialized
INFO - 2018-06-29 20:20:34 --> Loader Class Initialized
INFO - 2018-06-29 20:20:34 --> Helper loaded: url_helper
INFO - 2018-06-29 20:20:34 --> Helper loaded: form_helper
INFO - 2018-06-29 20:20:34 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:20:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:20:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:20:34 --> User Agent Class Initialized
INFO - 2018-06-29 20:20:34 --> Controller Class Initialized
INFO - 2018-06-29 20:20:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:20:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:20:34 --> Pixel_Model class loaded
INFO - 2018-06-29 20:20:34 --> Database Driver Class Initialized
INFO - 2018-06-29 20:20:34 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:20:34 --> Form Validation Class Initialized
INFO - 2018-06-29 20:20:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-29 20:20:34 --> Database Driver Class Initialized
INFO - 2018-06-29 20:20:34 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:20:34 --> Config Class Initialized
INFO - 2018-06-29 20:20:34 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:20:34 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:20:34 --> Utf8 Class Initialized
INFO - 2018-06-29 20:20:34 --> URI Class Initialized
INFO - 2018-06-29 20:20:34 --> Router Class Initialized
INFO - 2018-06-29 20:20:34 --> Output Class Initialized
INFO - 2018-06-29 20:20:34 --> Security Class Initialized
DEBUG - 2018-06-29 20:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:20:34 --> CSRF cookie sent
INFO - 2018-06-29 20:20:34 --> Input Class Initialized
INFO - 2018-06-29 20:20:34 --> Language Class Initialized
INFO - 2018-06-29 20:20:34 --> Loader Class Initialized
INFO - 2018-06-29 20:20:34 --> Helper loaded: url_helper
INFO - 2018-06-29 20:20:34 --> Helper loaded: form_helper
INFO - 2018-06-29 20:20:34 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:20:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:20:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:20:34 --> User Agent Class Initialized
INFO - 2018-06-29 20:20:34 --> Controller Class Initialized
INFO - 2018-06-29 20:20:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:20:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:20:34 --> Pixel_Model class loaded
INFO - 2018-06-29 20:20:34 --> Database Driver Class Initialized
INFO - 2018-06-29 20:20:34 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:20:34 --> Database Driver Class Initialized
INFO - 2018-06-29 20:20:34 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:20:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:20:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:20:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:20:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-06-29 20:20:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:20:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:20:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:20:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:20:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-06-29 20:20:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:20:34 --> Final output sent to browser
DEBUG - 2018-06-29 20:20:34 --> Total execution time: 0.0504
INFO - 2018-06-29 20:20:38 --> Config Class Initialized
INFO - 2018-06-29 20:20:38 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:20:38 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:20:38 --> Utf8 Class Initialized
INFO - 2018-06-29 20:20:38 --> URI Class Initialized
INFO - 2018-06-29 20:20:38 --> Router Class Initialized
INFO - 2018-06-29 20:20:38 --> Output Class Initialized
INFO - 2018-06-29 20:20:38 --> Security Class Initialized
DEBUG - 2018-06-29 20:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:20:38 --> CSRF cookie sent
INFO - 2018-06-29 20:20:38 --> CSRF token verified
INFO - 2018-06-29 20:20:38 --> Input Class Initialized
INFO - 2018-06-29 20:20:38 --> Language Class Initialized
INFO - 2018-06-29 20:20:38 --> Loader Class Initialized
INFO - 2018-06-29 20:20:38 --> Helper loaded: url_helper
INFO - 2018-06-29 20:20:38 --> Helper loaded: form_helper
INFO - 2018-06-29 20:20:38 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:20:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:20:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:20:38 --> User Agent Class Initialized
INFO - 2018-06-29 20:20:38 --> Controller Class Initialized
INFO - 2018-06-29 20:20:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:20:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:20:38 --> Pixel_Model class loaded
INFO - 2018-06-29 20:20:38 --> Database Driver Class Initialized
INFO - 2018-06-29 20:20:38 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:20:38 --> Form Validation Class Initialized
INFO - 2018-06-29 20:20:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-29 20:20:38 --> Database Driver Class Initialized
INFO - 2018-06-29 20:20:38 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:20:38 --> Config Class Initialized
INFO - 2018-06-29 20:20:38 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:20:38 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:20:38 --> Utf8 Class Initialized
INFO - 2018-06-29 20:20:38 --> URI Class Initialized
INFO - 2018-06-29 20:20:38 --> Router Class Initialized
INFO - 2018-06-29 20:20:38 --> Output Class Initialized
INFO - 2018-06-29 20:20:38 --> Security Class Initialized
DEBUG - 2018-06-29 20:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:20:38 --> CSRF cookie sent
INFO - 2018-06-29 20:20:38 --> Input Class Initialized
INFO - 2018-06-29 20:20:38 --> Language Class Initialized
INFO - 2018-06-29 20:20:38 --> Loader Class Initialized
INFO - 2018-06-29 20:20:38 --> Helper loaded: url_helper
INFO - 2018-06-29 20:20:38 --> Helper loaded: form_helper
INFO - 2018-06-29 20:20:38 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:20:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:20:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:20:38 --> User Agent Class Initialized
INFO - 2018-06-29 20:20:38 --> Controller Class Initialized
INFO - 2018-06-29 20:20:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:20:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:20:38 --> Pixel_Model class loaded
INFO - 2018-06-29 20:20:38 --> Database Driver Class Initialized
INFO - 2018-06-29 20:20:38 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:20:38 --> Database Driver Class Initialized
INFO - 2018-06-29 20:20:38 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:20:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:20:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:20:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:20:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:20:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:20:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:20:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:20:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-06-29 20:20:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:20:38 --> Final output sent to browser
DEBUG - 2018-06-29 20:20:38 --> Total execution time: 0.0346
INFO - 2018-06-29 20:20:43 --> Config Class Initialized
INFO - 2018-06-29 20:20:43 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:20:43 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:20:43 --> Utf8 Class Initialized
INFO - 2018-06-29 20:20:43 --> URI Class Initialized
INFO - 2018-06-29 20:20:43 --> Router Class Initialized
INFO - 2018-06-29 20:20:43 --> Output Class Initialized
INFO - 2018-06-29 20:20:43 --> Security Class Initialized
DEBUG - 2018-06-29 20:20:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:20:43 --> CSRF cookie sent
INFO - 2018-06-29 20:20:43 --> CSRF token verified
INFO - 2018-06-29 20:20:43 --> Input Class Initialized
INFO - 2018-06-29 20:20:43 --> Language Class Initialized
INFO - 2018-06-29 20:20:43 --> Loader Class Initialized
INFO - 2018-06-29 20:20:43 --> Helper loaded: url_helper
INFO - 2018-06-29 20:20:43 --> Helper loaded: form_helper
INFO - 2018-06-29 20:20:43 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:20:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:20:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:20:43 --> User Agent Class Initialized
INFO - 2018-06-29 20:20:43 --> Controller Class Initialized
INFO - 2018-06-29 20:20:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:20:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:20:43 --> Pixel_Model class loaded
INFO - 2018-06-29 20:20:43 --> Database Driver Class Initialized
INFO - 2018-06-29 20:20:43 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:20:43 --> Form Validation Class Initialized
INFO - 2018-06-29 20:20:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-29 20:20:43 --> Database Driver Class Initialized
INFO - 2018-06-29 20:20:43 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:20:43 --> Config Class Initialized
INFO - 2018-06-29 20:20:43 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:20:43 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:20:43 --> Utf8 Class Initialized
INFO - 2018-06-29 20:20:43 --> URI Class Initialized
INFO - 2018-06-29 20:20:43 --> Router Class Initialized
INFO - 2018-06-29 20:20:43 --> Output Class Initialized
INFO - 2018-06-29 20:20:43 --> Security Class Initialized
DEBUG - 2018-06-29 20:20:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:20:43 --> CSRF cookie sent
INFO - 2018-06-29 20:20:43 --> Input Class Initialized
INFO - 2018-06-29 20:20:43 --> Language Class Initialized
INFO - 2018-06-29 20:20:43 --> Loader Class Initialized
INFO - 2018-06-29 20:20:43 --> Helper loaded: url_helper
INFO - 2018-06-29 20:20:43 --> Helper loaded: form_helper
INFO - 2018-06-29 20:20:43 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:20:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:20:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:20:43 --> User Agent Class Initialized
INFO - 2018-06-29 20:20:43 --> Controller Class Initialized
INFO - 2018-06-29 20:20:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:20:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:20:43 --> Pixel_Model class loaded
INFO - 2018-06-29 20:20:43 --> Database Driver Class Initialized
INFO - 2018-06-29 20:20:43 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:20:43 --> Database Driver Class Initialized
INFO - 2018-06-29 20:20:43 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:20:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:20:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:20:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:20:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:20:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:20:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:20:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:20:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-06-29 20:20:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:20:43 --> Final output sent to browser
DEBUG - 2018-06-29 20:20:43 --> Total execution time: 0.0428
INFO - 2018-06-29 20:20:50 --> Config Class Initialized
INFO - 2018-06-29 20:20:50 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:20:50 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:20:50 --> Utf8 Class Initialized
INFO - 2018-06-29 20:20:50 --> URI Class Initialized
INFO - 2018-06-29 20:20:50 --> Router Class Initialized
INFO - 2018-06-29 20:20:50 --> Output Class Initialized
INFO - 2018-06-29 20:20:50 --> Security Class Initialized
DEBUG - 2018-06-29 20:20:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:20:50 --> CSRF cookie sent
INFO - 2018-06-29 20:20:50 --> CSRF token verified
INFO - 2018-06-29 20:20:50 --> Input Class Initialized
INFO - 2018-06-29 20:20:50 --> Language Class Initialized
INFO - 2018-06-29 20:20:50 --> Loader Class Initialized
INFO - 2018-06-29 20:20:50 --> Helper loaded: url_helper
INFO - 2018-06-29 20:20:50 --> Helper loaded: form_helper
INFO - 2018-06-29 20:20:50 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:20:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:20:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:20:50 --> User Agent Class Initialized
INFO - 2018-06-29 20:20:50 --> Controller Class Initialized
INFO - 2018-06-29 20:20:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:20:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:20:50 --> Pixel_Model class loaded
INFO - 2018-06-29 20:20:50 --> Database Driver Class Initialized
INFO - 2018-06-29 20:20:50 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:20:50 --> Form Validation Class Initialized
INFO - 2018-06-29 20:20:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-29 20:20:50 --> Database Driver Class Initialized
INFO - 2018-06-29 20:20:50 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:20:51 --> Config Class Initialized
INFO - 2018-06-29 20:20:51 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:20:51 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:20:51 --> Utf8 Class Initialized
INFO - 2018-06-29 20:20:51 --> URI Class Initialized
INFO - 2018-06-29 20:20:51 --> Router Class Initialized
INFO - 2018-06-29 20:20:51 --> Output Class Initialized
INFO - 2018-06-29 20:20:51 --> Security Class Initialized
DEBUG - 2018-06-29 20:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:20:51 --> CSRF cookie sent
INFO - 2018-06-29 20:20:51 --> Input Class Initialized
INFO - 2018-06-29 20:20:51 --> Language Class Initialized
INFO - 2018-06-29 20:20:51 --> Loader Class Initialized
INFO - 2018-06-29 20:20:51 --> Helper loaded: url_helper
INFO - 2018-06-29 20:20:51 --> Helper loaded: form_helper
INFO - 2018-06-29 20:20:51 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:20:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:20:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:20:51 --> User Agent Class Initialized
INFO - 2018-06-29 20:20:51 --> Controller Class Initialized
INFO - 2018-06-29 20:20:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:20:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:20:51 --> Pixel_Model class loaded
INFO - 2018-06-29 20:20:51 --> Database Driver Class Initialized
INFO - 2018-06-29 20:20:51 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:20:51 --> Database Driver Class Initialized
INFO - 2018-06-29 20:20:51 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:20:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:20:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:20:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:20:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:20:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:20:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:20:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:20:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-06-29 20:20:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:20:51 --> Final output sent to browser
DEBUG - 2018-06-29 20:20:51 --> Total execution time: 0.0435
INFO - 2018-06-29 20:21:00 --> Config Class Initialized
INFO - 2018-06-29 20:21:00 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:21:00 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:21:00 --> Utf8 Class Initialized
INFO - 2018-06-29 20:21:00 --> URI Class Initialized
INFO - 2018-06-29 20:21:00 --> Router Class Initialized
INFO - 2018-06-29 20:21:00 --> Output Class Initialized
INFO - 2018-06-29 20:21:00 --> Security Class Initialized
DEBUG - 2018-06-29 20:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:21:00 --> CSRF cookie sent
INFO - 2018-06-29 20:21:00 --> Input Class Initialized
INFO - 2018-06-29 20:21:00 --> Language Class Initialized
INFO - 2018-06-29 20:21:00 --> Loader Class Initialized
INFO - 2018-06-29 20:21:00 --> Helper loaded: url_helper
INFO - 2018-06-29 20:21:00 --> Helper loaded: form_helper
INFO - 2018-06-29 20:21:00 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:21:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:21:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:21:00 --> User Agent Class Initialized
INFO - 2018-06-29 20:21:00 --> Controller Class Initialized
INFO - 2018-06-29 20:21:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:21:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:21:00 --> Pixel_Model class loaded
INFO - 2018-06-29 20:21:00 --> Database Driver Class Initialized
INFO - 2018-06-29 20:21:00 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:21:00 --> Database Driver Class Initialized
INFO - 2018-06-29 20:21:00 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:21:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:21:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:21:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:21:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:21:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:21:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:21:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:21:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-06-29 20:21:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:21:00 --> Final output sent to browser
DEBUG - 2018-06-29 20:21:00 --> Total execution time: 0.0446
INFO - 2018-06-29 20:21:02 --> Config Class Initialized
INFO - 2018-06-29 20:21:02 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:21:02 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:21:02 --> Utf8 Class Initialized
INFO - 2018-06-29 20:21:02 --> URI Class Initialized
INFO - 2018-06-29 20:21:02 --> Router Class Initialized
INFO - 2018-06-29 20:21:02 --> Output Class Initialized
INFO - 2018-06-29 20:21:02 --> Security Class Initialized
DEBUG - 2018-06-29 20:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:21:02 --> CSRF cookie sent
INFO - 2018-06-29 20:21:02 --> Input Class Initialized
INFO - 2018-06-29 20:21:02 --> Language Class Initialized
INFO - 2018-06-29 20:21:02 --> Loader Class Initialized
INFO - 2018-06-29 20:21:02 --> Helper loaded: url_helper
INFO - 2018-06-29 20:21:02 --> Helper loaded: form_helper
INFO - 2018-06-29 20:21:02 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:21:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:21:02 --> User Agent Class Initialized
INFO - 2018-06-29 20:21:02 --> Controller Class Initialized
INFO - 2018-06-29 20:21:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:21:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:21:02 --> Pixel_Model class loaded
INFO - 2018-06-29 20:21:02 --> Database Driver Class Initialized
INFO - 2018-06-29 20:21:02 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:21:02 --> Database Driver Class Initialized
INFO - 2018-06-29 20:21:02 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:21:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:21:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:21:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:21:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:21:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:21:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:21:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:21:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-06-29 20:21:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:21:02 --> Final output sent to browser
DEBUG - 2018-06-29 20:21:02 --> Total execution time: 0.0328
INFO - 2018-06-29 20:21:04 --> Config Class Initialized
INFO - 2018-06-29 20:21:04 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:21:04 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:21:04 --> Utf8 Class Initialized
INFO - 2018-06-29 20:21:04 --> URI Class Initialized
INFO - 2018-06-29 20:21:04 --> Router Class Initialized
INFO - 2018-06-29 20:21:04 --> Output Class Initialized
INFO - 2018-06-29 20:21:04 --> Security Class Initialized
DEBUG - 2018-06-29 20:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:21:04 --> CSRF cookie sent
INFO - 2018-06-29 20:21:04 --> CSRF token verified
INFO - 2018-06-29 20:21:04 --> Input Class Initialized
INFO - 2018-06-29 20:21:04 --> Language Class Initialized
INFO - 2018-06-29 20:21:04 --> Loader Class Initialized
INFO - 2018-06-29 20:21:04 --> Helper loaded: url_helper
INFO - 2018-06-29 20:21:04 --> Helper loaded: form_helper
INFO - 2018-06-29 20:21:04 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:21:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:21:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:21:04 --> User Agent Class Initialized
INFO - 2018-06-29 20:21:04 --> Controller Class Initialized
INFO - 2018-06-29 20:21:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:21:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:21:04 --> Pixel_Model class loaded
INFO - 2018-06-29 20:21:04 --> Database Driver Class Initialized
INFO - 2018-06-29 20:21:04 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:21:04 --> Form Validation Class Initialized
INFO - 2018-06-29 20:21:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-29 20:21:04 --> Database Driver Class Initialized
INFO - 2018-06-29 20:21:04 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:21:04 --> Config Class Initialized
INFO - 2018-06-29 20:21:04 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:21:04 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:21:04 --> Utf8 Class Initialized
INFO - 2018-06-29 20:21:04 --> URI Class Initialized
INFO - 2018-06-29 20:21:04 --> Router Class Initialized
INFO - 2018-06-29 20:21:04 --> Output Class Initialized
INFO - 2018-06-29 20:21:04 --> Security Class Initialized
DEBUG - 2018-06-29 20:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:21:04 --> CSRF cookie sent
INFO - 2018-06-29 20:21:04 --> Input Class Initialized
INFO - 2018-06-29 20:21:04 --> Language Class Initialized
INFO - 2018-06-29 20:21:04 --> Loader Class Initialized
INFO - 2018-06-29 20:21:04 --> Helper loaded: url_helper
INFO - 2018-06-29 20:21:04 --> Helper loaded: form_helper
INFO - 2018-06-29 20:21:04 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:21:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:21:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:21:04 --> User Agent Class Initialized
INFO - 2018-06-29 20:21:04 --> Controller Class Initialized
INFO - 2018-06-29 20:21:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:21:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:21:04 --> Pixel_Model class loaded
INFO - 2018-06-29 20:21:04 --> Database Driver Class Initialized
INFO - 2018-06-29 20:21:04 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:21:04 --> Database Driver Class Initialized
INFO - 2018-06-29 20:21:04 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:21:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:21:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:21:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:21:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:21:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:21:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:21:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:21:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-06-29 20:21:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:21:04 --> Final output sent to browser
DEBUG - 2018-06-29 20:21:04 --> Total execution time: 0.0425
INFO - 2018-06-29 20:21:05 --> Config Class Initialized
INFO - 2018-06-29 20:21:05 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:21:05 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:21:05 --> Utf8 Class Initialized
INFO - 2018-06-29 20:21:05 --> URI Class Initialized
INFO - 2018-06-29 20:21:05 --> Router Class Initialized
INFO - 2018-06-29 20:21:05 --> Output Class Initialized
INFO - 2018-06-29 20:21:05 --> Security Class Initialized
DEBUG - 2018-06-29 20:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:21:05 --> CSRF cookie sent
INFO - 2018-06-29 20:21:05 --> CSRF token verified
INFO - 2018-06-29 20:21:05 --> Input Class Initialized
INFO - 2018-06-29 20:21:05 --> Language Class Initialized
INFO - 2018-06-29 20:21:05 --> Loader Class Initialized
INFO - 2018-06-29 20:21:05 --> Helper loaded: url_helper
INFO - 2018-06-29 20:21:05 --> Helper loaded: form_helper
INFO - 2018-06-29 20:21:05 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:21:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:21:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:21:05 --> User Agent Class Initialized
INFO - 2018-06-29 20:21:05 --> Controller Class Initialized
INFO - 2018-06-29 20:21:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:21:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:21:05 --> Pixel_Model class loaded
INFO - 2018-06-29 20:21:05 --> Database Driver Class Initialized
INFO - 2018-06-29 20:21:05 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:21:05 --> Form Validation Class Initialized
INFO - 2018-06-29 20:21:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-29 20:21:05 --> Database Driver Class Initialized
INFO - 2018-06-29 20:21:05 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:21:05 --> Config Class Initialized
INFO - 2018-06-29 20:21:05 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:21:05 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:21:05 --> Utf8 Class Initialized
INFO - 2018-06-29 20:21:05 --> URI Class Initialized
INFO - 2018-06-29 20:21:05 --> Router Class Initialized
INFO - 2018-06-29 20:21:05 --> Output Class Initialized
INFO - 2018-06-29 20:21:05 --> Security Class Initialized
DEBUG - 2018-06-29 20:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:21:05 --> CSRF cookie sent
INFO - 2018-06-29 20:21:05 --> Input Class Initialized
INFO - 2018-06-29 20:21:05 --> Language Class Initialized
INFO - 2018-06-29 20:21:05 --> Loader Class Initialized
INFO - 2018-06-29 20:21:05 --> Helper loaded: url_helper
INFO - 2018-06-29 20:21:05 --> Helper loaded: form_helper
INFO - 2018-06-29 20:21:05 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:21:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:21:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:21:05 --> User Agent Class Initialized
INFO - 2018-06-29 20:21:05 --> Controller Class Initialized
INFO - 2018-06-29 20:21:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:21:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:21:05 --> Pixel_Model class loaded
INFO - 2018-06-29 20:21:05 --> Database Driver Class Initialized
INFO - 2018-06-29 20:21:05 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:21:05 --> Database Driver Class Initialized
INFO - 2018-06-29 20:21:05 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:21:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:21:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:21:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:21:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:21:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:21:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:21:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:21:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-06-29 20:21:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:21:05 --> Final output sent to browser
DEBUG - 2018-06-29 20:21:05 --> Total execution time: 0.0433
INFO - 2018-06-29 20:21:13 --> Config Class Initialized
INFO - 2018-06-29 20:21:13 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:21:13 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:21:13 --> Utf8 Class Initialized
INFO - 2018-06-29 20:21:13 --> URI Class Initialized
INFO - 2018-06-29 20:21:13 --> Router Class Initialized
INFO - 2018-06-29 20:21:13 --> Output Class Initialized
INFO - 2018-06-29 20:21:13 --> Security Class Initialized
DEBUG - 2018-06-29 20:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:21:13 --> CSRF cookie sent
INFO - 2018-06-29 20:21:13 --> CSRF token verified
INFO - 2018-06-29 20:21:13 --> Input Class Initialized
INFO - 2018-06-29 20:21:13 --> Language Class Initialized
INFO - 2018-06-29 20:21:13 --> Loader Class Initialized
INFO - 2018-06-29 20:21:13 --> Helper loaded: url_helper
INFO - 2018-06-29 20:21:13 --> Helper loaded: form_helper
INFO - 2018-06-29 20:21:13 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:21:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:21:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:21:13 --> User Agent Class Initialized
INFO - 2018-06-29 20:21:13 --> Controller Class Initialized
INFO - 2018-06-29 20:21:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:21:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:21:13 --> Pixel_Model class loaded
INFO - 2018-06-29 20:21:13 --> Database Driver Class Initialized
INFO - 2018-06-29 20:21:13 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:21:13 --> Form Validation Class Initialized
INFO - 2018-06-29 20:21:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-29 20:21:13 --> Database Driver Class Initialized
INFO - 2018-06-29 20:21:13 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:21:13 --> Config Class Initialized
INFO - 2018-06-29 20:21:13 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:21:13 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:21:13 --> Utf8 Class Initialized
INFO - 2018-06-29 20:21:13 --> URI Class Initialized
INFO - 2018-06-29 20:21:13 --> Router Class Initialized
INFO - 2018-06-29 20:21:13 --> Output Class Initialized
INFO - 2018-06-29 20:21:13 --> Security Class Initialized
DEBUG - 2018-06-29 20:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:21:13 --> CSRF cookie sent
INFO - 2018-06-29 20:21:13 --> Input Class Initialized
INFO - 2018-06-29 20:21:13 --> Language Class Initialized
INFO - 2018-06-29 20:21:13 --> Loader Class Initialized
INFO - 2018-06-29 20:21:13 --> Helper loaded: url_helper
INFO - 2018-06-29 20:21:13 --> Helper loaded: form_helper
INFO - 2018-06-29 20:21:13 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:21:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:21:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:21:13 --> User Agent Class Initialized
INFO - 2018-06-29 20:21:13 --> Controller Class Initialized
INFO - 2018-06-29 20:21:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:21:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:21:13 --> Pixel_Model class loaded
INFO - 2018-06-29 20:21:13 --> Database Driver Class Initialized
INFO - 2018-06-29 20:21:13 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:21:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:21:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:21:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:21:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:21:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:21:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:21:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:21:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/marriage.php
INFO - 2018-06-29 20:21:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:21:13 --> Final output sent to browser
DEBUG - 2018-06-29 20:21:13 --> Total execution time: 0.0327
INFO - 2018-06-29 20:21:22 --> Config Class Initialized
INFO - 2018-06-29 20:21:22 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:21:22 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:21:22 --> Utf8 Class Initialized
INFO - 2018-06-29 20:21:22 --> URI Class Initialized
INFO - 2018-06-29 20:21:22 --> Router Class Initialized
INFO - 2018-06-29 20:21:22 --> Output Class Initialized
INFO - 2018-06-29 20:21:22 --> Security Class Initialized
DEBUG - 2018-06-29 20:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:21:22 --> CSRF cookie sent
INFO - 2018-06-29 20:21:22 --> CSRF token verified
INFO - 2018-06-29 20:21:22 --> Input Class Initialized
INFO - 2018-06-29 20:21:22 --> Language Class Initialized
INFO - 2018-06-29 20:21:22 --> Loader Class Initialized
INFO - 2018-06-29 20:21:22 --> Helper loaded: url_helper
INFO - 2018-06-29 20:21:22 --> Helper loaded: form_helper
INFO - 2018-06-29 20:21:22 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:21:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:21:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:21:22 --> User Agent Class Initialized
INFO - 2018-06-29 20:21:22 --> Controller Class Initialized
INFO - 2018-06-29 20:21:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:21:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:21:22 --> Pixel_Model class loaded
INFO - 2018-06-29 20:21:22 --> Database Driver Class Initialized
INFO - 2018-06-29 20:21:22 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:21:22 --> Form Validation Class Initialized
INFO - 2018-06-29 20:21:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-29 20:21:22 --> Database Driver Class Initialized
INFO - 2018-06-29 20:21:22 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:21:23 --> Config Class Initialized
INFO - 2018-06-29 20:21:23 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:21:23 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:21:23 --> Utf8 Class Initialized
INFO - 2018-06-29 20:21:23 --> URI Class Initialized
INFO - 2018-06-29 20:21:23 --> Router Class Initialized
INFO - 2018-06-29 20:21:23 --> Output Class Initialized
INFO - 2018-06-29 20:21:23 --> Security Class Initialized
DEBUG - 2018-06-29 20:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:21:23 --> CSRF cookie sent
INFO - 2018-06-29 20:21:23 --> Input Class Initialized
INFO - 2018-06-29 20:21:23 --> Language Class Initialized
INFO - 2018-06-29 20:21:23 --> Loader Class Initialized
INFO - 2018-06-29 20:21:23 --> Helper loaded: url_helper
INFO - 2018-06-29 20:21:23 --> Helper loaded: form_helper
INFO - 2018-06-29 20:21:23 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:21:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:21:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:21:23 --> User Agent Class Initialized
INFO - 2018-06-29 20:21:23 --> Controller Class Initialized
INFO - 2018-06-29 20:21:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:21:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:21:23 --> Pixel_Model class loaded
INFO - 2018-06-29 20:21:23 --> Database Driver Class Initialized
INFO - 2018-06-29 20:21:23 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:21:23 --> Database Driver Class Initialized
INFO - 2018-06-29 20:21:23 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:21:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:21:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:21:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:21:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:21:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:21:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:21:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:21:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-06-29 20:21:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:21:23 --> Final output sent to browser
DEBUG - 2018-06-29 20:21:23 --> Total execution time: 0.0481
INFO - 2018-06-29 20:23:23 --> Config Class Initialized
INFO - 2018-06-29 20:23:23 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:23:23 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:23:23 --> Utf8 Class Initialized
INFO - 2018-06-29 20:23:23 --> URI Class Initialized
INFO - 2018-06-29 20:23:23 --> Router Class Initialized
INFO - 2018-06-29 20:23:23 --> Output Class Initialized
INFO - 2018-06-29 20:23:23 --> Security Class Initialized
DEBUG - 2018-06-29 20:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:23:23 --> CSRF cookie sent
INFO - 2018-06-29 20:23:23 --> Input Class Initialized
INFO - 2018-06-29 20:23:23 --> Language Class Initialized
INFO - 2018-06-29 20:23:23 --> Loader Class Initialized
INFO - 2018-06-29 20:23:23 --> Helper loaded: url_helper
INFO - 2018-06-29 20:23:23 --> Helper loaded: form_helper
INFO - 2018-06-29 20:23:23 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:23:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:23:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:23:23 --> User Agent Class Initialized
INFO - 2018-06-29 20:23:23 --> Controller Class Initialized
INFO - 2018-06-29 20:23:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:23:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:23:23 --> Pixel_Model class loaded
INFO - 2018-06-29 20:23:23 --> Database Driver Class Initialized
INFO - 2018-06-29 20:23:23 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:23:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:23:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:23:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:23:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:23:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:23:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:23:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:23:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/marriage.php
INFO - 2018-06-29 20:23:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:23:23 --> Final output sent to browser
DEBUG - 2018-06-29 20:23:23 --> Total execution time: 0.0457
INFO - 2018-06-29 20:23:30 --> Config Class Initialized
INFO - 2018-06-29 20:23:30 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:23:30 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:23:30 --> Utf8 Class Initialized
INFO - 2018-06-29 20:23:30 --> URI Class Initialized
INFO - 2018-06-29 20:23:30 --> Router Class Initialized
INFO - 2018-06-29 20:23:30 --> Output Class Initialized
INFO - 2018-06-29 20:23:30 --> Security Class Initialized
DEBUG - 2018-06-29 20:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:23:30 --> CSRF cookie sent
INFO - 2018-06-29 20:23:30 --> Input Class Initialized
INFO - 2018-06-29 20:23:30 --> Language Class Initialized
INFO - 2018-06-29 20:23:30 --> Loader Class Initialized
INFO - 2018-06-29 20:23:30 --> Helper loaded: url_helper
INFO - 2018-06-29 20:23:30 --> Helper loaded: form_helper
INFO - 2018-06-29 20:23:30 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:23:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:23:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:23:30 --> User Agent Class Initialized
INFO - 2018-06-29 20:23:30 --> Controller Class Initialized
INFO - 2018-06-29 20:23:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:23:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:23:30 --> Pixel_Model class loaded
INFO - 2018-06-29 20:23:30 --> Database Driver Class Initialized
INFO - 2018-06-29 20:23:30 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:23:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:23:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:23:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:23:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:23:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:23:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:23:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:23:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-06-29 20:23:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:23:30 --> Final output sent to browser
DEBUG - 2018-06-29 20:23:30 --> Total execution time: 0.0328
INFO - 2018-06-29 20:23:32 --> Config Class Initialized
INFO - 2018-06-29 20:23:32 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:23:32 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:23:32 --> Utf8 Class Initialized
INFO - 2018-06-29 20:23:32 --> URI Class Initialized
INFO - 2018-06-29 20:23:32 --> Router Class Initialized
INFO - 2018-06-29 20:23:32 --> Output Class Initialized
INFO - 2018-06-29 20:23:32 --> Security Class Initialized
DEBUG - 2018-06-29 20:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:23:32 --> CSRF cookie sent
INFO - 2018-06-29 20:23:32 --> CSRF token verified
INFO - 2018-06-29 20:23:32 --> Input Class Initialized
INFO - 2018-06-29 20:23:32 --> Language Class Initialized
INFO - 2018-06-29 20:23:32 --> Loader Class Initialized
INFO - 2018-06-29 20:23:32 --> Helper loaded: url_helper
INFO - 2018-06-29 20:23:32 --> Helper loaded: form_helper
INFO - 2018-06-29 20:23:32 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:23:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:23:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:23:32 --> User Agent Class Initialized
INFO - 2018-06-29 20:23:32 --> Controller Class Initialized
INFO - 2018-06-29 20:23:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:23:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:23:32 --> Pixel_Model class loaded
INFO - 2018-06-29 20:23:32 --> Database Driver Class Initialized
INFO - 2018-06-29 20:23:32 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:23:32 --> Form Validation Class Initialized
INFO - 2018-06-29 20:23:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-29 20:23:32 --> Database Driver Class Initialized
INFO - 2018-06-29 20:23:32 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:23:32 --> Config Class Initialized
INFO - 2018-06-29 20:23:32 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:23:32 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:23:32 --> Utf8 Class Initialized
INFO - 2018-06-29 20:23:32 --> URI Class Initialized
INFO - 2018-06-29 20:23:32 --> Router Class Initialized
INFO - 2018-06-29 20:23:32 --> Output Class Initialized
INFO - 2018-06-29 20:23:32 --> Security Class Initialized
DEBUG - 2018-06-29 20:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:23:32 --> CSRF cookie sent
INFO - 2018-06-29 20:23:32 --> Input Class Initialized
INFO - 2018-06-29 20:23:32 --> Language Class Initialized
INFO - 2018-06-29 20:23:32 --> Loader Class Initialized
INFO - 2018-06-29 20:23:32 --> Helper loaded: url_helper
INFO - 2018-06-29 20:23:32 --> Helper loaded: form_helper
INFO - 2018-06-29 20:23:32 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:23:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:23:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:23:32 --> User Agent Class Initialized
INFO - 2018-06-29 20:23:32 --> Controller Class Initialized
INFO - 2018-06-29 20:23:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:23:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:23:32 --> Pixel_Model class loaded
INFO - 2018-06-29 20:23:32 --> Database Driver Class Initialized
INFO - 2018-06-29 20:23:32 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:23:32 --> Database Driver Class Initialized
INFO - 2018-06-29 20:23:32 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:23:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:23:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:23:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:23:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:23:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:23:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:23:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:23:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-06-29 20:23:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:23:32 --> Final output sent to browser
DEBUG - 2018-06-29 20:23:32 --> Total execution time: 0.0459
INFO - 2018-06-29 20:23:33 --> Config Class Initialized
INFO - 2018-06-29 20:23:33 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:23:33 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:23:33 --> Utf8 Class Initialized
INFO - 2018-06-29 20:23:33 --> URI Class Initialized
INFO - 2018-06-29 20:23:33 --> Router Class Initialized
INFO - 2018-06-29 20:23:33 --> Output Class Initialized
INFO - 2018-06-29 20:23:33 --> Security Class Initialized
DEBUG - 2018-06-29 20:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:23:33 --> CSRF cookie sent
INFO - 2018-06-29 20:23:33 --> CSRF token verified
INFO - 2018-06-29 20:23:33 --> Input Class Initialized
INFO - 2018-06-29 20:23:33 --> Language Class Initialized
INFO - 2018-06-29 20:23:33 --> Loader Class Initialized
INFO - 2018-06-29 20:23:33 --> Helper loaded: url_helper
INFO - 2018-06-29 20:23:33 --> Helper loaded: form_helper
INFO - 2018-06-29 20:23:33 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:23:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:23:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:23:33 --> User Agent Class Initialized
INFO - 2018-06-29 20:23:33 --> Controller Class Initialized
INFO - 2018-06-29 20:23:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:23:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:23:33 --> Pixel_Model class loaded
INFO - 2018-06-29 20:23:33 --> Database Driver Class Initialized
INFO - 2018-06-29 20:23:33 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:23:33 --> Form Validation Class Initialized
INFO - 2018-06-29 20:23:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-29 20:23:33 --> Database Driver Class Initialized
INFO - 2018-06-29 20:23:33 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:23:33 --> Config Class Initialized
INFO - 2018-06-29 20:23:33 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:23:33 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:23:33 --> Utf8 Class Initialized
INFO - 2018-06-29 20:23:33 --> URI Class Initialized
INFO - 2018-06-29 20:23:33 --> Router Class Initialized
INFO - 2018-06-29 20:23:33 --> Output Class Initialized
INFO - 2018-06-29 20:23:33 --> Security Class Initialized
DEBUG - 2018-06-29 20:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:23:33 --> CSRF cookie sent
INFO - 2018-06-29 20:23:33 --> Input Class Initialized
INFO - 2018-06-29 20:23:33 --> Language Class Initialized
INFO - 2018-06-29 20:23:33 --> Loader Class Initialized
INFO - 2018-06-29 20:23:33 --> Helper loaded: url_helper
INFO - 2018-06-29 20:23:33 --> Helper loaded: form_helper
INFO - 2018-06-29 20:23:33 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:23:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:23:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:23:33 --> User Agent Class Initialized
INFO - 2018-06-29 20:23:33 --> Controller Class Initialized
INFO - 2018-06-29 20:23:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:23:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:23:33 --> Pixel_Model class loaded
INFO - 2018-06-29 20:23:33 --> Database Driver Class Initialized
INFO - 2018-06-29 20:23:33 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:23:33 --> Database Driver Class Initialized
INFO - 2018-06-29 20:23:33 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:23:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:23:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:23:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:23:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-06-29 20:23:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:23:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:23:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:23:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:23:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-06-29 20:23:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:23:33 --> Final output sent to browser
DEBUG - 2018-06-29 20:23:33 --> Total execution time: 0.0331
INFO - 2018-06-29 20:23:34 --> Config Class Initialized
INFO - 2018-06-29 20:23:34 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:23:34 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:23:34 --> Utf8 Class Initialized
INFO - 2018-06-29 20:23:34 --> URI Class Initialized
INFO - 2018-06-29 20:23:34 --> Router Class Initialized
INFO - 2018-06-29 20:23:34 --> Output Class Initialized
INFO - 2018-06-29 20:23:34 --> Security Class Initialized
DEBUG - 2018-06-29 20:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:23:34 --> CSRF cookie sent
INFO - 2018-06-29 20:23:34 --> CSRF token verified
INFO - 2018-06-29 20:23:34 --> Input Class Initialized
INFO - 2018-06-29 20:23:34 --> Language Class Initialized
INFO - 2018-06-29 20:23:34 --> Loader Class Initialized
INFO - 2018-06-29 20:23:34 --> Helper loaded: url_helper
INFO - 2018-06-29 20:23:34 --> Helper loaded: form_helper
INFO - 2018-06-29 20:23:34 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:23:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:23:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:23:34 --> User Agent Class Initialized
INFO - 2018-06-29 20:23:34 --> Controller Class Initialized
INFO - 2018-06-29 20:23:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:23:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:23:34 --> Pixel_Model class loaded
INFO - 2018-06-29 20:23:34 --> Database Driver Class Initialized
INFO - 2018-06-29 20:23:34 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:23:34 --> Form Validation Class Initialized
INFO - 2018-06-29 20:23:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-29 20:23:34 --> Database Driver Class Initialized
INFO - 2018-06-29 20:23:34 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:23:34 --> Config Class Initialized
INFO - 2018-06-29 20:23:34 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:23:34 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:23:34 --> Utf8 Class Initialized
INFO - 2018-06-29 20:23:34 --> URI Class Initialized
INFO - 2018-06-29 20:23:34 --> Router Class Initialized
INFO - 2018-06-29 20:23:34 --> Output Class Initialized
INFO - 2018-06-29 20:23:34 --> Security Class Initialized
DEBUG - 2018-06-29 20:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:23:34 --> CSRF cookie sent
INFO - 2018-06-29 20:23:34 --> Input Class Initialized
INFO - 2018-06-29 20:23:34 --> Language Class Initialized
INFO - 2018-06-29 20:23:34 --> Loader Class Initialized
INFO - 2018-06-29 20:23:34 --> Helper loaded: url_helper
INFO - 2018-06-29 20:23:34 --> Helper loaded: form_helper
INFO - 2018-06-29 20:23:34 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:23:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:23:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:23:34 --> User Agent Class Initialized
INFO - 2018-06-29 20:23:34 --> Controller Class Initialized
INFO - 2018-06-29 20:23:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:23:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:23:34 --> Pixel_Model class loaded
INFO - 2018-06-29 20:23:34 --> Database Driver Class Initialized
INFO - 2018-06-29 20:23:34 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:23:34 --> Database Driver Class Initialized
INFO - 2018-06-29 20:23:34 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:23:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:23:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:23:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:23:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:23:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:23:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:23:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:23:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-06-29 20:23:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:23:34 --> Final output sent to browser
DEBUG - 2018-06-29 20:23:34 --> Total execution time: 0.0417
INFO - 2018-06-29 20:23:36 --> Config Class Initialized
INFO - 2018-06-29 20:23:36 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:23:36 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:23:36 --> Utf8 Class Initialized
INFO - 2018-06-29 20:23:36 --> URI Class Initialized
INFO - 2018-06-29 20:23:36 --> Router Class Initialized
INFO - 2018-06-29 20:23:36 --> Output Class Initialized
INFO - 2018-06-29 20:23:36 --> Security Class Initialized
DEBUG - 2018-06-29 20:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:23:36 --> CSRF cookie sent
INFO - 2018-06-29 20:23:36 --> CSRF token verified
INFO - 2018-06-29 20:23:36 --> Input Class Initialized
INFO - 2018-06-29 20:23:36 --> Language Class Initialized
INFO - 2018-06-29 20:23:36 --> Loader Class Initialized
INFO - 2018-06-29 20:23:36 --> Helper loaded: url_helper
INFO - 2018-06-29 20:23:36 --> Helper loaded: form_helper
INFO - 2018-06-29 20:23:36 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:23:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:23:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:23:36 --> User Agent Class Initialized
INFO - 2018-06-29 20:23:36 --> Controller Class Initialized
INFO - 2018-06-29 20:23:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:23:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:23:36 --> Pixel_Model class loaded
INFO - 2018-06-29 20:23:36 --> Database Driver Class Initialized
INFO - 2018-06-29 20:23:36 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:23:36 --> Form Validation Class Initialized
INFO - 2018-06-29 20:23:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-29 20:23:36 --> Database Driver Class Initialized
INFO - 2018-06-29 20:23:36 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:23:36 --> Config Class Initialized
INFO - 2018-06-29 20:23:36 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:23:36 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:23:36 --> Utf8 Class Initialized
INFO - 2018-06-29 20:23:36 --> URI Class Initialized
INFO - 2018-06-29 20:23:36 --> Router Class Initialized
INFO - 2018-06-29 20:23:36 --> Output Class Initialized
INFO - 2018-06-29 20:23:36 --> Security Class Initialized
DEBUG - 2018-06-29 20:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:23:36 --> CSRF cookie sent
INFO - 2018-06-29 20:23:36 --> Input Class Initialized
INFO - 2018-06-29 20:23:36 --> Language Class Initialized
INFO - 2018-06-29 20:23:36 --> Loader Class Initialized
INFO - 2018-06-29 20:23:36 --> Helper loaded: url_helper
INFO - 2018-06-29 20:23:36 --> Helper loaded: form_helper
INFO - 2018-06-29 20:23:36 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:23:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:23:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:23:36 --> User Agent Class Initialized
INFO - 2018-06-29 20:23:36 --> Controller Class Initialized
INFO - 2018-06-29 20:23:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:23:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:23:36 --> Pixel_Model class loaded
INFO - 2018-06-29 20:23:36 --> Database Driver Class Initialized
INFO - 2018-06-29 20:23:36 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:23:36 --> Database Driver Class Initialized
INFO - 2018-06-29 20:23:36 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:23:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:23:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:23:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:23:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:23:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:23:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:23:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:23:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-06-29 20:23:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:23:36 --> Final output sent to browser
DEBUG - 2018-06-29 20:23:36 --> Total execution time: 0.0431
INFO - 2018-06-29 20:23:37 --> Config Class Initialized
INFO - 2018-06-29 20:23:37 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:23:37 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:23:37 --> Utf8 Class Initialized
INFO - 2018-06-29 20:23:37 --> URI Class Initialized
INFO - 2018-06-29 20:23:37 --> Router Class Initialized
INFO - 2018-06-29 20:23:37 --> Output Class Initialized
INFO - 2018-06-29 20:23:37 --> Security Class Initialized
DEBUG - 2018-06-29 20:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:23:37 --> CSRF cookie sent
INFO - 2018-06-29 20:23:37 --> CSRF token verified
INFO - 2018-06-29 20:23:37 --> Input Class Initialized
INFO - 2018-06-29 20:23:37 --> Language Class Initialized
INFO - 2018-06-29 20:23:37 --> Loader Class Initialized
INFO - 2018-06-29 20:23:37 --> Helper loaded: url_helper
INFO - 2018-06-29 20:23:37 --> Helper loaded: form_helper
INFO - 2018-06-29 20:23:37 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:23:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:23:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:23:37 --> User Agent Class Initialized
INFO - 2018-06-29 20:23:37 --> Controller Class Initialized
INFO - 2018-06-29 20:23:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:23:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:23:37 --> Pixel_Model class loaded
INFO - 2018-06-29 20:23:37 --> Database Driver Class Initialized
INFO - 2018-06-29 20:23:37 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:23:37 --> Form Validation Class Initialized
INFO - 2018-06-29 20:23:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-29 20:23:37 --> Database Driver Class Initialized
INFO - 2018-06-29 20:23:37 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:23:37 --> Config Class Initialized
INFO - 2018-06-29 20:23:37 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:23:37 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:23:37 --> Utf8 Class Initialized
INFO - 2018-06-29 20:23:37 --> URI Class Initialized
INFO - 2018-06-29 20:23:37 --> Router Class Initialized
INFO - 2018-06-29 20:23:37 --> Output Class Initialized
INFO - 2018-06-29 20:23:37 --> Security Class Initialized
DEBUG - 2018-06-29 20:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:23:37 --> CSRF cookie sent
INFO - 2018-06-29 20:23:37 --> Input Class Initialized
INFO - 2018-06-29 20:23:37 --> Language Class Initialized
INFO - 2018-06-29 20:23:37 --> Loader Class Initialized
INFO - 2018-06-29 20:23:37 --> Helper loaded: url_helper
INFO - 2018-06-29 20:23:37 --> Helper loaded: form_helper
INFO - 2018-06-29 20:23:37 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:23:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:23:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:23:37 --> User Agent Class Initialized
INFO - 2018-06-29 20:23:37 --> Controller Class Initialized
INFO - 2018-06-29 20:23:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:23:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:23:37 --> Pixel_Model class loaded
INFO - 2018-06-29 20:23:37 --> Database Driver Class Initialized
INFO - 2018-06-29 20:23:37 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:23:37 --> Database Driver Class Initialized
INFO - 2018-06-29 20:23:37 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:23:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:23:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:23:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:23:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:23:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:23:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:23:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:23:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-06-29 20:23:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:23:37 --> Final output sent to browser
DEBUG - 2018-06-29 20:23:37 --> Total execution time: 0.0462
INFO - 2018-06-29 20:23:47 --> Config Class Initialized
INFO - 2018-06-29 20:23:47 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:23:47 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:23:47 --> Utf8 Class Initialized
INFO - 2018-06-29 20:23:47 --> URI Class Initialized
INFO - 2018-06-29 20:23:47 --> Router Class Initialized
INFO - 2018-06-29 20:23:47 --> Output Class Initialized
INFO - 2018-06-29 20:23:47 --> Security Class Initialized
DEBUG - 2018-06-29 20:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:23:47 --> CSRF cookie sent
INFO - 2018-06-29 20:23:47 --> CSRF token verified
INFO - 2018-06-29 20:23:47 --> Input Class Initialized
INFO - 2018-06-29 20:23:47 --> Language Class Initialized
INFO - 2018-06-29 20:23:47 --> Loader Class Initialized
INFO - 2018-06-29 20:23:47 --> Helper loaded: url_helper
INFO - 2018-06-29 20:23:47 --> Helper loaded: form_helper
INFO - 2018-06-29 20:23:47 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:23:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:23:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:23:47 --> User Agent Class Initialized
INFO - 2018-06-29 20:23:47 --> Controller Class Initialized
INFO - 2018-06-29 20:23:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:23:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:23:47 --> Pixel_Model class loaded
INFO - 2018-06-29 20:23:47 --> Database Driver Class Initialized
INFO - 2018-06-29 20:23:47 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:23:47 --> Form Validation Class Initialized
INFO - 2018-06-29 20:23:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-29 20:23:47 --> Database Driver Class Initialized
INFO - 2018-06-29 20:23:47 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:23:47 --> Config Class Initialized
INFO - 2018-06-29 20:23:47 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:23:47 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:23:47 --> Utf8 Class Initialized
INFO - 2018-06-29 20:23:47 --> URI Class Initialized
INFO - 2018-06-29 20:23:47 --> Router Class Initialized
INFO - 2018-06-29 20:23:47 --> Output Class Initialized
INFO - 2018-06-29 20:23:47 --> Security Class Initialized
DEBUG - 2018-06-29 20:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:23:47 --> CSRF cookie sent
INFO - 2018-06-29 20:23:47 --> Input Class Initialized
INFO - 2018-06-29 20:23:47 --> Language Class Initialized
INFO - 2018-06-29 20:23:47 --> Loader Class Initialized
INFO - 2018-06-29 20:23:47 --> Helper loaded: url_helper
INFO - 2018-06-29 20:23:47 --> Helper loaded: form_helper
INFO - 2018-06-29 20:23:47 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:23:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:23:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:23:47 --> User Agent Class Initialized
INFO - 2018-06-29 20:23:47 --> Controller Class Initialized
INFO - 2018-06-29 20:23:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:23:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:23:47 --> Pixel_Model class loaded
INFO - 2018-06-29 20:23:47 --> Database Driver Class Initialized
INFO - 2018-06-29 20:23:47 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:23:47 --> Database Driver Class Initialized
INFO - 2018-06-29 20:23:47 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:23:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:23:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:23:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:23:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:23:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:23:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:23:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:23:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-06-29 20:23:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:23:47 --> Final output sent to browser
DEBUG - 2018-06-29 20:23:47 --> Total execution time: 0.0460
INFO - 2018-06-29 20:23:59 --> Config Class Initialized
INFO - 2018-06-29 20:23:59 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:23:59 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:23:59 --> Utf8 Class Initialized
INFO - 2018-06-29 20:23:59 --> URI Class Initialized
INFO - 2018-06-29 20:23:59 --> Router Class Initialized
INFO - 2018-06-29 20:23:59 --> Output Class Initialized
INFO - 2018-06-29 20:23:59 --> Security Class Initialized
DEBUG - 2018-06-29 20:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:23:59 --> CSRF cookie sent
INFO - 2018-06-29 20:23:59 --> CSRF token verified
INFO - 2018-06-29 20:23:59 --> Input Class Initialized
INFO - 2018-06-29 20:23:59 --> Language Class Initialized
INFO - 2018-06-29 20:23:59 --> Loader Class Initialized
INFO - 2018-06-29 20:23:59 --> Helper loaded: url_helper
INFO - 2018-06-29 20:23:59 --> Helper loaded: form_helper
INFO - 2018-06-29 20:23:59 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:23:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:23:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:23:59 --> User Agent Class Initialized
INFO - 2018-06-29 20:23:59 --> Controller Class Initialized
INFO - 2018-06-29 20:23:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:23:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:23:59 --> Pixel_Model class loaded
INFO - 2018-06-29 20:23:59 --> Database Driver Class Initialized
INFO - 2018-06-29 20:23:59 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:23:59 --> Form Validation Class Initialized
INFO - 2018-06-29 20:23:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-29 20:23:59 --> Database Driver Class Initialized
INFO - 2018-06-29 20:23:59 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:23:59 --> Config Class Initialized
INFO - 2018-06-29 20:23:59 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:23:59 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:23:59 --> Utf8 Class Initialized
INFO - 2018-06-29 20:23:59 --> URI Class Initialized
INFO - 2018-06-29 20:23:59 --> Router Class Initialized
INFO - 2018-06-29 20:23:59 --> Output Class Initialized
INFO - 2018-06-29 20:23:59 --> Security Class Initialized
DEBUG - 2018-06-29 20:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:23:59 --> CSRF cookie sent
INFO - 2018-06-29 20:23:59 --> Input Class Initialized
INFO - 2018-06-29 20:23:59 --> Language Class Initialized
INFO - 2018-06-29 20:23:59 --> Loader Class Initialized
INFO - 2018-06-29 20:23:59 --> Helper loaded: url_helper
INFO - 2018-06-29 20:23:59 --> Helper loaded: form_helper
INFO - 2018-06-29 20:23:59 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:23:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:23:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:23:59 --> User Agent Class Initialized
INFO - 2018-06-29 20:23:59 --> Controller Class Initialized
INFO - 2018-06-29 20:23:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:23:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:23:59 --> Pixel_Model class loaded
INFO - 2018-06-29 20:23:59 --> Database Driver Class Initialized
INFO - 2018-06-29 20:23:59 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:23:59 --> Database Driver Class Initialized
INFO - 2018-06-29 20:23:59 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:23:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:23:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:23:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:23:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:23:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:23:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:23:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:23:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_owner.php
INFO - 2018-06-29 20:23:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:23:59 --> Final output sent to browser
DEBUG - 2018-06-29 20:23:59 --> Total execution time: 0.0479
INFO - 2018-06-29 20:24:03 --> Config Class Initialized
INFO - 2018-06-29 20:24:03 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:24:03 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:24:03 --> Utf8 Class Initialized
INFO - 2018-06-29 20:24:03 --> URI Class Initialized
INFO - 2018-06-29 20:24:03 --> Router Class Initialized
INFO - 2018-06-29 20:24:03 --> Output Class Initialized
INFO - 2018-06-29 20:24:03 --> Security Class Initialized
DEBUG - 2018-06-29 20:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:24:03 --> CSRF cookie sent
INFO - 2018-06-29 20:24:03 --> CSRF token verified
INFO - 2018-06-29 20:24:03 --> Input Class Initialized
INFO - 2018-06-29 20:24:03 --> Language Class Initialized
INFO - 2018-06-29 20:24:03 --> Loader Class Initialized
INFO - 2018-06-29 20:24:03 --> Helper loaded: url_helper
INFO - 2018-06-29 20:24:03 --> Helper loaded: form_helper
INFO - 2018-06-29 20:24:03 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:24:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:24:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:24:03 --> User Agent Class Initialized
INFO - 2018-06-29 20:24:03 --> Controller Class Initialized
INFO - 2018-06-29 20:24:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:24:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:24:03 --> Pixel_Model class loaded
INFO - 2018-06-29 20:24:03 --> Database Driver Class Initialized
INFO - 2018-06-29 20:24:03 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:24:03 --> Form Validation Class Initialized
INFO - 2018-06-29 20:24:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-29 20:24:03 --> Database Driver Class Initialized
INFO - 2018-06-29 20:24:03 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:24:03 --> Config Class Initialized
INFO - 2018-06-29 20:24:03 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:24:03 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:24:03 --> Utf8 Class Initialized
INFO - 2018-06-29 20:24:03 --> URI Class Initialized
INFO - 2018-06-29 20:24:03 --> Router Class Initialized
INFO - 2018-06-29 20:24:03 --> Output Class Initialized
INFO - 2018-06-29 20:24:03 --> Security Class Initialized
DEBUG - 2018-06-29 20:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:24:03 --> CSRF cookie sent
INFO - 2018-06-29 20:24:03 --> Input Class Initialized
INFO - 2018-06-29 20:24:03 --> Language Class Initialized
INFO - 2018-06-29 20:24:03 --> Loader Class Initialized
INFO - 2018-06-29 20:24:03 --> Helper loaded: url_helper
INFO - 2018-06-29 20:24:03 --> Helper loaded: form_helper
INFO - 2018-06-29 20:24:03 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:24:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:24:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:24:03 --> User Agent Class Initialized
INFO - 2018-06-29 20:24:03 --> Controller Class Initialized
INFO - 2018-06-29 20:24:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:24:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:24:03 --> Pixel_Model class loaded
INFO - 2018-06-29 20:24:03 --> Database Driver Class Initialized
INFO - 2018-06-29 20:24:03 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:24:03 --> Database Driver Class Initialized
INFO - 2018-06-29 20:24:03 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:24:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:24:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:24:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:24:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:24:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:24:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:24:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:24:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_value.php
INFO - 2018-06-29 20:24:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:24:03 --> Final output sent to browser
DEBUG - 2018-06-29 20:24:03 --> Total execution time: 0.0671
INFO - 2018-06-29 20:25:50 --> Config Class Initialized
INFO - 2018-06-29 20:25:50 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:25:50 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:25:50 --> Utf8 Class Initialized
INFO - 2018-06-29 20:25:50 --> URI Class Initialized
INFO - 2018-06-29 20:25:50 --> Router Class Initialized
INFO - 2018-06-29 20:25:50 --> Output Class Initialized
INFO - 2018-06-29 20:25:50 --> Security Class Initialized
DEBUG - 2018-06-29 20:25:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:25:50 --> CSRF cookie sent
INFO - 2018-06-29 20:25:50 --> CSRF token verified
INFO - 2018-06-29 20:25:50 --> Input Class Initialized
INFO - 2018-06-29 20:25:50 --> Language Class Initialized
INFO - 2018-06-29 20:25:50 --> Loader Class Initialized
INFO - 2018-06-29 20:25:50 --> Helper loaded: url_helper
INFO - 2018-06-29 20:25:50 --> Helper loaded: form_helper
INFO - 2018-06-29 20:25:50 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:25:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:25:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:25:50 --> User Agent Class Initialized
INFO - 2018-06-29 20:25:50 --> Controller Class Initialized
INFO - 2018-06-29 20:25:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:25:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:25:50 --> Pixel_Model class loaded
INFO - 2018-06-29 20:25:50 --> Database Driver Class Initialized
INFO - 2018-06-29 20:25:50 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:25:50 --> Form Validation Class Initialized
INFO - 2018-06-29 20:25:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-29 20:25:50 --> Database Driver Class Initialized
INFO - 2018-06-29 20:25:50 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:25:50 --> Config Class Initialized
INFO - 2018-06-29 20:25:50 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:25:50 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:25:50 --> Utf8 Class Initialized
INFO - 2018-06-29 20:25:50 --> URI Class Initialized
INFO - 2018-06-29 20:25:50 --> Router Class Initialized
INFO - 2018-06-29 20:25:50 --> Output Class Initialized
INFO - 2018-06-29 20:25:50 --> Security Class Initialized
DEBUG - 2018-06-29 20:25:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:25:50 --> CSRF cookie sent
INFO - 2018-06-29 20:25:50 --> Input Class Initialized
INFO - 2018-06-29 20:25:50 --> Language Class Initialized
INFO - 2018-06-29 20:25:50 --> Loader Class Initialized
INFO - 2018-06-29 20:25:50 --> Helper loaded: url_helper
INFO - 2018-06-29 20:25:50 --> Helper loaded: form_helper
INFO - 2018-06-29 20:25:50 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:25:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:25:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:25:50 --> User Agent Class Initialized
INFO - 2018-06-29 20:25:50 --> Controller Class Initialized
INFO - 2018-06-29 20:25:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:25:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:25:50 --> Pixel_Model class loaded
INFO - 2018-06-29 20:25:50 --> Database Driver Class Initialized
INFO - 2018-06-29 20:25:50 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:25:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:25:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:25:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:25:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:25:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:25:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:25:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:25:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/marriage.php
INFO - 2018-06-29 20:25:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:25:50 --> Final output sent to browser
DEBUG - 2018-06-29 20:25:50 --> Total execution time: 0.0355
INFO - 2018-06-29 20:25:52 --> Config Class Initialized
INFO - 2018-06-29 20:25:52 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:25:52 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:25:52 --> Utf8 Class Initialized
INFO - 2018-06-29 20:25:52 --> URI Class Initialized
INFO - 2018-06-29 20:25:52 --> Router Class Initialized
INFO - 2018-06-29 20:25:52 --> Output Class Initialized
INFO - 2018-06-29 20:25:52 --> Security Class Initialized
DEBUG - 2018-06-29 20:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:25:52 --> CSRF cookie sent
INFO - 2018-06-29 20:25:52 --> CSRF token verified
INFO - 2018-06-29 20:25:52 --> Input Class Initialized
INFO - 2018-06-29 20:25:52 --> Language Class Initialized
INFO - 2018-06-29 20:25:52 --> Loader Class Initialized
INFO - 2018-06-29 20:25:52 --> Helper loaded: url_helper
INFO - 2018-06-29 20:25:52 --> Helper loaded: form_helper
INFO - 2018-06-29 20:25:52 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:25:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:25:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:25:52 --> User Agent Class Initialized
INFO - 2018-06-29 20:25:52 --> Controller Class Initialized
INFO - 2018-06-29 20:25:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:25:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:25:52 --> Pixel_Model class loaded
INFO - 2018-06-29 20:25:52 --> Database Driver Class Initialized
INFO - 2018-06-29 20:25:52 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:25:52 --> Form Validation Class Initialized
INFO - 2018-06-29 20:25:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-29 20:25:52 --> Database Driver Class Initialized
INFO - 2018-06-29 20:25:52 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:25:52 --> Config Class Initialized
INFO - 2018-06-29 20:25:52 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:25:52 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:25:52 --> Utf8 Class Initialized
INFO - 2018-06-29 20:25:52 --> URI Class Initialized
INFO - 2018-06-29 20:25:52 --> Router Class Initialized
INFO - 2018-06-29 20:25:52 --> Output Class Initialized
INFO - 2018-06-29 20:25:52 --> Security Class Initialized
DEBUG - 2018-06-29 20:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:25:52 --> CSRF cookie sent
INFO - 2018-06-29 20:25:52 --> Input Class Initialized
INFO - 2018-06-29 20:25:52 --> Language Class Initialized
INFO - 2018-06-29 20:25:52 --> Loader Class Initialized
INFO - 2018-06-29 20:25:52 --> Helper loaded: url_helper
INFO - 2018-06-29 20:25:52 --> Helper loaded: form_helper
INFO - 2018-06-29 20:25:52 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:25:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:25:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:25:52 --> User Agent Class Initialized
INFO - 2018-06-29 20:25:52 --> Controller Class Initialized
INFO - 2018-06-29 20:25:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:25:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:25:52 --> Pixel_Model class loaded
INFO - 2018-06-29 20:25:52 --> Database Driver Class Initialized
INFO - 2018-06-29 20:25:52 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:25:52 --> Database Driver Class Initialized
INFO - 2018-06-29 20:25:52 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:25:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:25:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:25:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:25:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:25:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:25:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:25:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:25:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/merriage_home_title.php
INFO - 2018-06-29 20:25:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:25:52 --> Final output sent to browser
DEBUG - 2018-06-29 20:25:52 --> Total execution time: 0.0468
INFO - 2018-06-29 20:26:01 --> Config Class Initialized
INFO - 2018-06-29 20:26:01 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:26:01 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:26:01 --> Utf8 Class Initialized
INFO - 2018-06-29 20:26:01 --> URI Class Initialized
INFO - 2018-06-29 20:26:01 --> Router Class Initialized
INFO - 2018-06-29 20:26:01 --> Output Class Initialized
INFO - 2018-06-29 20:26:01 --> Security Class Initialized
DEBUG - 2018-06-29 20:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:26:01 --> CSRF cookie sent
INFO - 2018-06-29 20:26:01 --> Input Class Initialized
INFO - 2018-06-29 20:26:01 --> Language Class Initialized
INFO - 2018-06-29 20:26:01 --> Loader Class Initialized
INFO - 2018-06-29 20:26:01 --> Helper loaded: url_helper
INFO - 2018-06-29 20:26:01 --> Helper loaded: form_helper
INFO - 2018-06-29 20:26:01 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:26:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:26:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:26:01 --> User Agent Class Initialized
INFO - 2018-06-29 20:26:01 --> Controller Class Initialized
INFO - 2018-06-29 20:26:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:26:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:26:01 --> Pixel_Model class loaded
INFO - 2018-06-29 20:26:01 --> Database Driver Class Initialized
INFO - 2018-06-29 20:26:01 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:26:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:26:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:26:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:26:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:26:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:26:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:26:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:26:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/marriage.php
INFO - 2018-06-29 20:26:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:26:01 --> Final output sent to browser
DEBUG - 2018-06-29 20:26:01 --> Total execution time: 0.0346
INFO - 2018-06-29 20:27:15 --> Config Class Initialized
INFO - 2018-06-29 20:27:15 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:27:15 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:27:15 --> Utf8 Class Initialized
INFO - 2018-06-29 20:27:15 --> URI Class Initialized
INFO - 2018-06-29 20:27:15 --> Router Class Initialized
INFO - 2018-06-29 20:27:15 --> Output Class Initialized
INFO - 2018-06-29 20:27:15 --> Security Class Initialized
DEBUG - 2018-06-29 20:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:27:15 --> CSRF cookie sent
INFO - 2018-06-29 20:27:15 --> Input Class Initialized
INFO - 2018-06-29 20:27:15 --> Language Class Initialized
INFO - 2018-06-29 20:27:15 --> Loader Class Initialized
INFO - 2018-06-29 20:27:15 --> Helper loaded: url_helper
INFO - 2018-06-29 20:27:15 --> Helper loaded: form_helper
INFO - 2018-06-29 20:27:15 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:27:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:27:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:27:15 --> User Agent Class Initialized
INFO - 2018-06-29 20:27:15 --> Controller Class Initialized
INFO - 2018-06-29 20:27:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:27:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:27:15 --> Pixel_Model class loaded
INFO - 2018-06-29 20:27:15 --> Database Driver Class Initialized
INFO - 2018-06-29 20:27:15 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:27:15 --> Database Driver Class Initialized
INFO - 2018-06-29 20:27:15 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:27:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:27:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:27:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:27:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:27:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:27:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:27:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:27:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/marriage.php
INFO - 2018-06-29 20:27:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:27:15 --> Final output sent to browser
DEBUG - 2018-06-29 20:27:15 --> Total execution time: 0.0410
INFO - 2018-06-29 20:27:17 --> Config Class Initialized
INFO - 2018-06-29 20:27:17 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:27:17 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:27:17 --> Utf8 Class Initialized
INFO - 2018-06-29 20:27:17 --> URI Class Initialized
INFO - 2018-06-29 20:27:17 --> Router Class Initialized
INFO - 2018-06-29 20:27:17 --> Output Class Initialized
INFO - 2018-06-29 20:27:17 --> Security Class Initialized
DEBUG - 2018-06-29 20:27:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:27:17 --> CSRF cookie sent
INFO - 2018-06-29 20:27:17 --> CSRF token verified
INFO - 2018-06-29 20:27:17 --> Input Class Initialized
INFO - 2018-06-29 20:27:17 --> Language Class Initialized
INFO - 2018-06-29 20:27:17 --> Loader Class Initialized
INFO - 2018-06-29 20:27:17 --> Helper loaded: url_helper
INFO - 2018-06-29 20:27:17 --> Helper loaded: form_helper
INFO - 2018-06-29 20:27:17 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:27:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:27:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:27:17 --> User Agent Class Initialized
INFO - 2018-06-29 20:27:17 --> Controller Class Initialized
INFO - 2018-06-29 20:27:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:27:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:27:17 --> Pixel_Model class loaded
INFO - 2018-06-29 20:27:17 --> Database Driver Class Initialized
INFO - 2018-06-29 20:27:17 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:27:17 --> Form Validation Class Initialized
INFO - 2018-06-29 20:27:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-29 20:27:17 --> Database Driver Class Initialized
INFO - 2018-06-29 20:27:17 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:27:17 --> Config Class Initialized
INFO - 2018-06-29 20:27:17 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:27:17 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:27:17 --> Utf8 Class Initialized
INFO - 2018-06-29 20:27:17 --> URI Class Initialized
INFO - 2018-06-29 20:27:17 --> Router Class Initialized
INFO - 2018-06-29 20:27:17 --> Output Class Initialized
INFO - 2018-06-29 20:27:17 --> Security Class Initialized
DEBUG - 2018-06-29 20:27:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:27:17 --> CSRF cookie sent
INFO - 2018-06-29 20:27:17 --> Input Class Initialized
INFO - 2018-06-29 20:27:17 --> Language Class Initialized
INFO - 2018-06-29 20:27:17 --> Loader Class Initialized
INFO - 2018-06-29 20:27:17 --> Helper loaded: url_helper
INFO - 2018-06-29 20:27:17 --> Helper loaded: form_helper
INFO - 2018-06-29 20:27:17 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:27:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:27:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:27:17 --> User Agent Class Initialized
INFO - 2018-06-29 20:27:17 --> Controller Class Initialized
INFO - 2018-06-29 20:27:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:27:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:27:17 --> Pixel_Model class loaded
INFO - 2018-06-29 20:27:17 --> Database Driver Class Initialized
INFO - 2018-06-29 20:27:17 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:27:17 --> Database Driver Class Initialized
INFO - 2018-06-29 20:27:17 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:27:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:27:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:27:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:27:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:27:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:27:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:27:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:27:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/merriage_home_title.php
INFO - 2018-06-29 20:27:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:27:17 --> Final output sent to browser
DEBUG - 2018-06-29 20:27:17 --> Total execution time: 0.0413
INFO - 2018-06-29 20:27:26 --> Config Class Initialized
INFO - 2018-06-29 20:27:26 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:27:26 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:27:26 --> Utf8 Class Initialized
INFO - 2018-06-29 20:27:26 --> URI Class Initialized
INFO - 2018-06-29 20:27:26 --> Router Class Initialized
INFO - 2018-06-29 20:27:26 --> Output Class Initialized
INFO - 2018-06-29 20:27:26 --> Security Class Initialized
DEBUG - 2018-06-29 20:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:27:26 --> CSRF cookie sent
INFO - 2018-06-29 20:27:26 --> CSRF token verified
INFO - 2018-06-29 20:27:26 --> Input Class Initialized
INFO - 2018-06-29 20:27:26 --> Language Class Initialized
INFO - 2018-06-29 20:27:26 --> Loader Class Initialized
INFO - 2018-06-29 20:27:26 --> Helper loaded: url_helper
INFO - 2018-06-29 20:27:26 --> Helper loaded: form_helper
INFO - 2018-06-29 20:27:26 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:27:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:27:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:27:26 --> User Agent Class Initialized
INFO - 2018-06-29 20:27:26 --> Controller Class Initialized
INFO - 2018-06-29 20:27:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:27:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:27:26 --> Pixel_Model class loaded
INFO - 2018-06-29 20:27:26 --> Database Driver Class Initialized
INFO - 2018-06-29 20:27:26 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:27:26 --> Form Validation Class Initialized
INFO - 2018-06-29 20:27:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-29 20:27:26 --> Database Driver Class Initialized
INFO - 2018-06-29 20:27:26 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:27:26 --> Config Class Initialized
INFO - 2018-06-29 20:27:26 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:27:26 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:27:26 --> Utf8 Class Initialized
INFO - 2018-06-29 20:27:26 --> URI Class Initialized
INFO - 2018-06-29 20:27:26 --> Router Class Initialized
INFO - 2018-06-29 20:27:26 --> Output Class Initialized
INFO - 2018-06-29 20:27:26 --> Security Class Initialized
DEBUG - 2018-06-29 20:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:27:26 --> CSRF cookie sent
INFO - 2018-06-29 20:27:26 --> Input Class Initialized
INFO - 2018-06-29 20:27:26 --> Language Class Initialized
INFO - 2018-06-29 20:27:26 --> Loader Class Initialized
INFO - 2018-06-29 20:27:26 --> Helper loaded: url_helper
INFO - 2018-06-29 20:27:26 --> Helper loaded: form_helper
INFO - 2018-06-29 20:27:26 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:27:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:27:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:27:26 --> User Agent Class Initialized
INFO - 2018-06-29 20:27:26 --> Controller Class Initialized
INFO - 2018-06-29 20:27:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:27:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:27:26 --> Pixel_Model class loaded
INFO - 2018-06-29 20:27:26 --> Database Driver Class Initialized
INFO - 2018-06-29 20:27:26 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:27:26 --> Database Driver Class Initialized
INFO - 2018-06-29 20:27:26 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:27:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:27:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:27:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:27:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:27:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:27:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:27:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:27:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-06-29 20:27:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:27:26 --> Final output sent to browser
DEBUG - 2018-06-29 20:27:26 --> Total execution time: 0.0444
INFO - 2018-06-29 20:27:29 --> Config Class Initialized
INFO - 2018-06-29 20:27:29 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:27:29 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:27:29 --> Utf8 Class Initialized
INFO - 2018-06-29 20:27:29 --> URI Class Initialized
INFO - 2018-06-29 20:27:29 --> Router Class Initialized
INFO - 2018-06-29 20:27:29 --> Output Class Initialized
INFO - 2018-06-29 20:27:29 --> Security Class Initialized
DEBUG - 2018-06-29 20:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:27:29 --> CSRF cookie sent
INFO - 2018-06-29 20:27:29 --> CSRF token verified
INFO - 2018-06-29 20:27:29 --> Input Class Initialized
INFO - 2018-06-29 20:27:29 --> Language Class Initialized
INFO - 2018-06-29 20:27:29 --> Loader Class Initialized
INFO - 2018-06-29 20:27:29 --> Helper loaded: url_helper
INFO - 2018-06-29 20:27:29 --> Helper loaded: form_helper
INFO - 2018-06-29 20:27:29 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:27:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:27:29 --> User Agent Class Initialized
INFO - 2018-06-29 20:27:29 --> Controller Class Initialized
INFO - 2018-06-29 20:27:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:27:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:27:29 --> Pixel_Model class loaded
INFO - 2018-06-29 20:27:29 --> Database Driver Class Initialized
INFO - 2018-06-29 20:27:29 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:27:29 --> Form Validation Class Initialized
INFO - 2018-06-29 20:27:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-29 20:27:29 --> Database Driver Class Initialized
INFO - 2018-06-29 20:27:29 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:27:29 --> Config Class Initialized
INFO - 2018-06-29 20:27:29 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:27:29 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:27:29 --> Utf8 Class Initialized
INFO - 2018-06-29 20:27:29 --> URI Class Initialized
INFO - 2018-06-29 20:27:29 --> Router Class Initialized
INFO - 2018-06-29 20:27:29 --> Output Class Initialized
INFO - 2018-06-29 20:27:29 --> Security Class Initialized
DEBUG - 2018-06-29 20:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:27:29 --> CSRF cookie sent
INFO - 2018-06-29 20:27:29 --> Input Class Initialized
INFO - 2018-06-29 20:27:29 --> Language Class Initialized
INFO - 2018-06-29 20:27:29 --> Loader Class Initialized
INFO - 2018-06-29 20:27:29 --> Helper loaded: url_helper
INFO - 2018-06-29 20:27:29 --> Helper loaded: form_helper
INFO - 2018-06-29 20:27:29 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:27:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:27:29 --> User Agent Class Initialized
INFO - 2018-06-29 20:27:29 --> Controller Class Initialized
INFO - 2018-06-29 20:27:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:27:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:27:29 --> Pixel_Model class loaded
INFO - 2018-06-29 20:27:29 --> Database Driver Class Initialized
INFO - 2018-06-29 20:27:29 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:27:29 --> Database Driver Class Initialized
INFO - 2018-06-29 20:27:29 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:27:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:27:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:27:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:27:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:27:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:27:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:27:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:27:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-06-29 20:27:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:27:29 --> Final output sent to browser
DEBUG - 2018-06-29 20:27:29 --> Total execution time: 0.0474
INFO - 2018-06-29 20:27:38 --> Config Class Initialized
INFO - 2018-06-29 20:27:38 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:27:38 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:27:38 --> Utf8 Class Initialized
INFO - 2018-06-29 20:27:38 --> URI Class Initialized
INFO - 2018-06-29 20:27:38 --> Router Class Initialized
INFO - 2018-06-29 20:27:38 --> Output Class Initialized
INFO - 2018-06-29 20:27:38 --> Security Class Initialized
DEBUG - 2018-06-29 20:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:27:38 --> CSRF cookie sent
INFO - 2018-06-29 20:27:38 --> CSRF token verified
INFO - 2018-06-29 20:27:38 --> Input Class Initialized
INFO - 2018-06-29 20:27:38 --> Language Class Initialized
INFO - 2018-06-29 20:27:38 --> Loader Class Initialized
INFO - 2018-06-29 20:27:38 --> Helper loaded: url_helper
INFO - 2018-06-29 20:27:38 --> Helper loaded: form_helper
INFO - 2018-06-29 20:27:38 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:27:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:27:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:27:38 --> User Agent Class Initialized
INFO - 2018-06-29 20:27:38 --> Controller Class Initialized
INFO - 2018-06-29 20:27:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:27:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:27:38 --> Pixel_Model class loaded
INFO - 2018-06-29 20:27:38 --> Database Driver Class Initialized
INFO - 2018-06-29 20:27:38 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:27:38 --> Form Validation Class Initialized
INFO - 2018-06-29 20:27:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-29 20:27:38 --> Database Driver Class Initialized
INFO - 2018-06-29 20:27:38 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:27:38 --> Config Class Initialized
INFO - 2018-06-29 20:27:38 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:27:38 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:27:38 --> Utf8 Class Initialized
INFO - 2018-06-29 20:27:38 --> URI Class Initialized
INFO - 2018-06-29 20:27:38 --> Router Class Initialized
INFO - 2018-06-29 20:27:38 --> Output Class Initialized
INFO - 2018-06-29 20:27:38 --> Security Class Initialized
DEBUG - 2018-06-29 20:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:27:38 --> CSRF cookie sent
INFO - 2018-06-29 20:27:38 --> Input Class Initialized
INFO - 2018-06-29 20:27:38 --> Language Class Initialized
INFO - 2018-06-29 20:27:38 --> Loader Class Initialized
INFO - 2018-06-29 20:27:38 --> Helper loaded: url_helper
INFO - 2018-06-29 20:27:38 --> Helper loaded: form_helper
INFO - 2018-06-29 20:27:38 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:27:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:27:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:27:38 --> User Agent Class Initialized
INFO - 2018-06-29 20:27:38 --> Controller Class Initialized
INFO - 2018-06-29 20:27:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:27:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:27:38 --> Pixel_Model class loaded
INFO - 2018-06-29 20:27:38 --> Database Driver Class Initialized
INFO - 2018-06-29 20:27:38 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:27:38 --> Database Driver Class Initialized
INFO - 2018-06-29 20:27:38 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:27:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:27:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:27:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:27:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:27:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:27:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:27:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:27:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids_info.php
INFO - 2018-06-29 20:27:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:27:38 --> Final output sent to browser
DEBUG - 2018-06-29 20:27:38 --> Total execution time: 0.0420
INFO - 2018-06-29 20:28:16 --> Config Class Initialized
INFO - 2018-06-29 20:28:16 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:28:16 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:28:16 --> Utf8 Class Initialized
INFO - 2018-06-29 20:28:16 --> URI Class Initialized
INFO - 2018-06-29 20:28:16 --> Router Class Initialized
INFO - 2018-06-29 20:28:16 --> Output Class Initialized
INFO - 2018-06-29 20:28:16 --> Security Class Initialized
DEBUG - 2018-06-29 20:28:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:28:16 --> CSRF cookie sent
INFO - 2018-06-29 20:28:16 --> CSRF token verified
INFO - 2018-06-29 20:28:16 --> Input Class Initialized
INFO - 2018-06-29 20:28:16 --> Language Class Initialized
INFO - 2018-06-29 20:28:16 --> Loader Class Initialized
INFO - 2018-06-29 20:28:16 --> Helper loaded: url_helper
INFO - 2018-06-29 20:28:16 --> Helper loaded: form_helper
INFO - 2018-06-29 20:28:16 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:28:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:28:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:28:16 --> User Agent Class Initialized
INFO - 2018-06-29 20:28:16 --> Controller Class Initialized
INFO - 2018-06-29 20:28:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:28:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:28:16 --> Pixel_Model class loaded
INFO - 2018-06-29 20:28:16 --> Database Driver Class Initialized
INFO - 2018-06-29 20:28:16 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:28:16 --> Form Validation Class Initialized
INFO - 2018-06-29 20:28:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-29 20:28:16 --> Database Driver Class Initialized
INFO - 2018-06-29 20:28:16 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:28:16 --> Config Class Initialized
INFO - 2018-06-29 20:28:16 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:28:16 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:28:16 --> Utf8 Class Initialized
INFO - 2018-06-29 20:28:16 --> URI Class Initialized
INFO - 2018-06-29 20:28:16 --> Router Class Initialized
INFO - 2018-06-29 20:28:16 --> Output Class Initialized
INFO - 2018-06-29 20:28:16 --> Security Class Initialized
DEBUG - 2018-06-29 20:28:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:28:16 --> CSRF cookie sent
INFO - 2018-06-29 20:28:16 --> Input Class Initialized
INFO - 2018-06-29 20:28:16 --> Language Class Initialized
INFO - 2018-06-29 20:28:16 --> Loader Class Initialized
INFO - 2018-06-29 20:28:16 --> Helper loaded: url_helper
INFO - 2018-06-29 20:28:16 --> Helper loaded: form_helper
INFO - 2018-06-29 20:28:16 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:28:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:28:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:28:16 --> User Agent Class Initialized
INFO - 2018-06-29 20:28:16 --> Controller Class Initialized
INFO - 2018-06-29 20:28:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:28:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:28:16 --> Pixel_Model class loaded
INFO - 2018-06-29 20:28:16 --> Database Driver Class Initialized
INFO - 2018-06-29 20:28:16 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:28:16 --> Database Driver Class Initialized
INFO - 2018-06-29 20:28:16 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:28:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:28:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:28:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:28:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:28:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:28:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:28:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:28:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/other_kids.php
INFO - 2018-06-29 20:28:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:28:16 --> Final output sent to browser
DEBUG - 2018-06-29 20:28:16 --> Total execution time: 0.0424
INFO - 2018-06-29 20:28:20 --> Config Class Initialized
INFO - 2018-06-29 20:28:20 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:28:20 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:28:20 --> Utf8 Class Initialized
INFO - 2018-06-29 20:28:20 --> URI Class Initialized
INFO - 2018-06-29 20:28:20 --> Router Class Initialized
INFO - 2018-06-29 20:28:20 --> Output Class Initialized
INFO - 2018-06-29 20:28:20 --> Security Class Initialized
DEBUG - 2018-06-29 20:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:28:20 --> CSRF cookie sent
INFO - 2018-06-29 20:28:20 --> CSRF token verified
INFO - 2018-06-29 20:28:20 --> Input Class Initialized
INFO - 2018-06-29 20:28:20 --> Language Class Initialized
INFO - 2018-06-29 20:28:20 --> Loader Class Initialized
INFO - 2018-06-29 20:28:20 --> Helper loaded: url_helper
INFO - 2018-06-29 20:28:20 --> Helper loaded: form_helper
INFO - 2018-06-29 20:28:20 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:28:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:28:20 --> User Agent Class Initialized
INFO - 2018-06-29 20:28:20 --> Controller Class Initialized
INFO - 2018-06-29 20:28:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:28:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:28:20 --> Pixel_Model class loaded
INFO - 2018-06-29 20:28:20 --> Database Driver Class Initialized
INFO - 2018-06-29 20:28:20 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:28:20 --> Form Validation Class Initialized
INFO - 2018-06-29 20:28:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-29 20:28:20 --> Database Driver Class Initialized
INFO - 2018-06-29 20:28:20 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:28:20 --> Config Class Initialized
INFO - 2018-06-29 20:28:20 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:28:20 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:28:20 --> Utf8 Class Initialized
INFO - 2018-06-29 20:28:20 --> URI Class Initialized
INFO - 2018-06-29 20:28:20 --> Router Class Initialized
INFO - 2018-06-29 20:28:20 --> Output Class Initialized
INFO - 2018-06-29 20:28:20 --> Security Class Initialized
DEBUG - 2018-06-29 20:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:28:20 --> CSRF cookie sent
INFO - 2018-06-29 20:28:20 --> Input Class Initialized
INFO - 2018-06-29 20:28:20 --> Language Class Initialized
INFO - 2018-06-29 20:28:20 --> Loader Class Initialized
INFO - 2018-06-29 20:28:20 --> Helper loaded: url_helper
INFO - 2018-06-29 20:28:20 --> Helper loaded: form_helper
INFO - 2018-06-29 20:28:20 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:28:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:28:20 --> User Agent Class Initialized
INFO - 2018-06-29 20:28:20 --> Controller Class Initialized
INFO - 2018-06-29 20:28:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:28:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:28:20 --> Pixel_Model class loaded
INFO - 2018-06-29 20:28:20 --> Database Driver Class Initialized
INFO - 2018-06-29 20:28:20 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:28:20 --> Database Driver Class Initialized
INFO - 2018-06-29 20:28:20 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:28:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:28:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:28:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:28:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:28:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:28:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:28:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:28:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids_activities.php
INFO - 2018-06-29 20:28:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:28:20 --> Final output sent to browser
DEBUG - 2018-06-29 20:28:20 --> Total execution time: 0.0505
INFO - 2018-06-29 20:28:27 --> Config Class Initialized
INFO - 2018-06-29 20:28:27 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:28:27 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:28:27 --> Utf8 Class Initialized
INFO - 2018-06-29 20:28:27 --> URI Class Initialized
INFO - 2018-06-29 20:28:27 --> Router Class Initialized
INFO - 2018-06-29 20:28:27 --> Output Class Initialized
INFO - 2018-06-29 20:28:27 --> Security Class Initialized
DEBUG - 2018-06-29 20:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:28:27 --> CSRF cookie sent
INFO - 2018-06-29 20:28:27 --> CSRF token verified
INFO - 2018-06-29 20:28:27 --> Input Class Initialized
INFO - 2018-06-29 20:28:27 --> Language Class Initialized
INFO - 2018-06-29 20:28:27 --> Loader Class Initialized
INFO - 2018-06-29 20:28:27 --> Helper loaded: url_helper
INFO - 2018-06-29 20:28:27 --> Helper loaded: form_helper
INFO - 2018-06-29 20:28:27 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:28:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:28:27 --> User Agent Class Initialized
INFO - 2018-06-29 20:28:27 --> Controller Class Initialized
INFO - 2018-06-29 20:28:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:28:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:28:27 --> Pixel_Model class loaded
INFO - 2018-06-29 20:28:27 --> Database Driver Class Initialized
INFO - 2018-06-29 20:28:27 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:28:27 --> Form Validation Class Initialized
INFO - 2018-06-29 20:28:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-29 20:28:27 --> Database Driver Class Initialized
INFO - 2018-06-29 20:28:27 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:28:27 --> Config Class Initialized
INFO - 2018-06-29 20:28:27 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:28:27 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:28:27 --> Utf8 Class Initialized
INFO - 2018-06-29 20:28:27 --> URI Class Initialized
INFO - 2018-06-29 20:28:27 --> Router Class Initialized
INFO - 2018-06-29 20:28:27 --> Output Class Initialized
INFO - 2018-06-29 20:28:27 --> Security Class Initialized
DEBUG - 2018-06-29 20:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:28:27 --> CSRF cookie sent
INFO - 2018-06-29 20:28:27 --> Input Class Initialized
INFO - 2018-06-29 20:28:27 --> Language Class Initialized
INFO - 2018-06-29 20:28:27 --> Loader Class Initialized
INFO - 2018-06-29 20:28:27 --> Helper loaded: url_helper
INFO - 2018-06-29 20:28:27 --> Helper loaded: form_helper
INFO - 2018-06-29 20:28:27 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:28:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:28:27 --> User Agent Class Initialized
INFO - 2018-06-29 20:28:27 --> Controller Class Initialized
INFO - 2018-06-29 20:28:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:28:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:28:27 --> Pixel_Model class loaded
INFO - 2018-06-29 20:28:27 --> Database Driver Class Initialized
INFO - 2018-06-29 20:28:27 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:28:27 --> Database Driver Class Initialized
INFO - 2018-06-29 20:28:27 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:28:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:28:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:28:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:28:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:28:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:28:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:28:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:28:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids_communicate.php
INFO - 2018-06-29 20:28:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:28:27 --> Final output sent to browser
DEBUG - 2018-06-29 20:28:27 --> Total execution time: 0.0433
INFO - 2018-06-29 20:28:31 --> Config Class Initialized
INFO - 2018-06-29 20:28:31 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:28:31 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:28:31 --> Utf8 Class Initialized
INFO - 2018-06-29 20:28:31 --> URI Class Initialized
INFO - 2018-06-29 20:28:31 --> Router Class Initialized
INFO - 2018-06-29 20:28:31 --> Output Class Initialized
INFO - 2018-06-29 20:28:31 --> Security Class Initialized
DEBUG - 2018-06-29 20:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:28:31 --> CSRF cookie sent
INFO - 2018-06-29 20:28:31 --> CSRF token verified
INFO - 2018-06-29 20:28:31 --> Input Class Initialized
INFO - 2018-06-29 20:28:31 --> Language Class Initialized
INFO - 2018-06-29 20:28:31 --> Loader Class Initialized
INFO - 2018-06-29 20:28:31 --> Helper loaded: url_helper
INFO - 2018-06-29 20:28:31 --> Helper loaded: form_helper
INFO - 2018-06-29 20:28:31 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:28:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:28:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:28:31 --> User Agent Class Initialized
INFO - 2018-06-29 20:28:31 --> Controller Class Initialized
INFO - 2018-06-29 20:28:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:28:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:28:31 --> Pixel_Model class loaded
INFO - 2018-06-29 20:28:31 --> Database Driver Class Initialized
INFO - 2018-06-29 20:28:31 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:28:31 --> Form Validation Class Initialized
INFO - 2018-06-29 20:28:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-29 20:28:31 --> Database Driver Class Initialized
INFO - 2018-06-29 20:28:31 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:28:31 --> Config Class Initialized
INFO - 2018-06-29 20:28:31 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:28:31 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:28:31 --> Utf8 Class Initialized
INFO - 2018-06-29 20:28:31 --> URI Class Initialized
INFO - 2018-06-29 20:28:31 --> Router Class Initialized
INFO - 2018-06-29 20:28:31 --> Output Class Initialized
INFO - 2018-06-29 20:28:31 --> Security Class Initialized
DEBUG - 2018-06-29 20:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:28:31 --> CSRF cookie sent
INFO - 2018-06-29 20:28:31 --> Input Class Initialized
INFO - 2018-06-29 20:28:31 --> Language Class Initialized
INFO - 2018-06-29 20:28:31 --> Loader Class Initialized
INFO - 2018-06-29 20:28:31 --> Helper loaded: url_helper
INFO - 2018-06-29 20:28:31 --> Helper loaded: form_helper
INFO - 2018-06-29 20:28:31 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:28:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:28:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:28:31 --> User Agent Class Initialized
INFO - 2018-06-29 20:28:31 --> Controller Class Initialized
INFO - 2018-06-29 20:28:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:28:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:28:31 --> Pixel_Model class loaded
INFO - 2018-06-29 20:28:31 --> Database Driver Class Initialized
INFO - 2018-06-29 20:28:31 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:28:31 --> Database Driver Class Initialized
INFO - 2018-06-29 20:28:31 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:28:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:28:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:28:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:28:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:28:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:28:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:28:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:28:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids_dinner.php
INFO - 2018-06-29 20:28:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:28:31 --> Final output sent to browser
DEBUG - 2018-06-29 20:28:31 --> Total execution time: 0.0498
INFO - 2018-06-29 20:28:35 --> Config Class Initialized
INFO - 2018-06-29 20:28:35 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:28:35 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:28:35 --> Utf8 Class Initialized
INFO - 2018-06-29 20:28:35 --> URI Class Initialized
INFO - 2018-06-29 20:28:35 --> Router Class Initialized
INFO - 2018-06-29 20:28:35 --> Output Class Initialized
INFO - 2018-06-29 20:28:35 --> Security Class Initialized
DEBUG - 2018-06-29 20:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:28:35 --> CSRF cookie sent
INFO - 2018-06-29 20:28:35 --> CSRF token verified
INFO - 2018-06-29 20:28:35 --> Input Class Initialized
INFO - 2018-06-29 20:28:35 --> Language Class Initialized
INFO - 2018-06-29 20:28:35 --> Loader Class Initialized
INFO - 2018-06-29 20:28:35 --> Helper loaded: url_helper
INFO - 2018-06-29 20:28:35 --> Helper loaded: form_helper
INFO - 2018-06-29 20:28:35 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:28:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:28:35 --> User Agent Class Initialized
INFO - 2018-06-29 20:28:35 --> Controller Class Initialized
INFO - 2018-06-29 20:28:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:28:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:28:35 --> Pixel_Model class loaded
INFO - 2018-06-29 20:28:35 --> Database Driver Class Initialized
INFO - 2018-06-29 20:28:35 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:28:35 --> Form Validation Class Initialized
INFO - 2018-06-29 20:28:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-29 20:28:35 --> Database Driver Class Initialized
INFO - 2018-06-29 20:28:35 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:28:35 --> Config Class Initialized
INFO - 2018-06-29 20:28:35 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:28:35 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:28:35 --> Utf8 Class Initialized
INFO - 2018-06-29 20:28:35 --> URI Class Initialized
INFO - 2018-06-29 20:28:35 --> Router Class Initialized
INFO - 2018-06-29 20:28:35 --> Output Class Initialized
INFO - 2018-06-29 20:28:35 --> Security Class Initialized
DEBUG - 2018-06-29 20:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:28:35 --> CSRF cookie sent
INFO - 2018-06-29 20:28:35 --> Input Class Initialized
INFO - 2018-06-29 20:28:35 --> Language Class Initialized
INFO - 2018-06-29 20:28:35 --> Loader Class Initialized
INFO - 2018-06-29 20:28:35 --> Helper loaded: url_helper
INFO - 2018-06-29 20:28:35 --> Helper loaded: form_helper
INFO - 2018-06-29 20:28:35 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:28:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:28:35 --> User Agent Class Initialized
INFO - 2018-06-29 20:28:35 --> Controller Class Initialized
INFO - 2018-06-29 20:28:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:28:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:28:35 --> Pixel_Model class loaded
INFO - 2018-06-29 20:28:35 --> Database Driver Class Initialized
INFO - 2018-06-29 20:28:35 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:28:35 --> Database Driver Class Initialized
INFO - 2018-06-29 20:28:35 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:28:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:28:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:28:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:28:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:28:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:28:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:28:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:28:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids_homework.php
INFO - 2018-06-29 20:28:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:28:35 --> Final output sent to browser
DEBUG - 2018-06-29 20:28:35 --> Total execution time: 0.0445
INFO - 2018-06-29 20:28:39 --> Config Class Initialized
INFO - 2018-06-29 20:28:39 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:28:39 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:28:39 --> Utf8 Class Initialized
INFO - 2018-06-29 20:28:39 --> URI Class Initialized
INFO - 2018-06-29 20:28:39 --> Router Class Initialized
INFO - 2018-06-29 20:28:39 --> Output Class Initialized
INFO - 2018-06-29 20:28:39 --> Security Class Initialized
DEBUG - 2018-06-29 20:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:28:39 --> CSRF cookie sent
INFO - 2018-06-29 20:28:39 --> CSRF token verified
INFO - 2018-06-29 20:28:39 --> Input Class Initialized
INFO - 2018-06-29 20:28:39 --> Language Class Initialized
INFO - 2018-06-29 20:28:39 --> Loader Class Initialized
INFO - 2018-06-29 20:28:39 --> Helper loaded: url_helper
INFO - 2018-06-29 20:28:39 --> Helper loaded: form_helper
INFO - 2018-06-29 20:28:39 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:28:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:28:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:28:39 --> User Agent Class Initialized
INFO - 2018-06-29 20:28:39 --> Controller Class Initialized
INFO - 2018-06-29 20:28:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:28:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:28:39 --> Pixel_Model class loaded
INFO - 2018-06-29 20:28:39 --> Database Driver Class Initialized
INFO - 2018-06-29 20:28:39 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:28:39 --> Form Validation Class Initialized
INFO - 2018-06-29 20:28:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-29 20:28:39 --> Database Driver Class Initialized
INFO - 2018-06-29 20:28:39 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:28:39 --> Config Class Initialized
INFO - 2018-06-29 20:28:39 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:28:39 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:28:39 --> Utf8 Class Initialized
INFO - 2018-06-29 20:28:39 --> URI Class Initialized
INFO - 2018-06-29 20:28:39 --> Router Class Initialized
INFO - 2018-06-29 20:28:39 --> Output Class Initialized
INFO - 2018-06-29 20:28:39 --> Security Class Initialized
DEBUG - 2018-06-29 20:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:28:39 --> CSRF cookie sent
INFO - 2018-06-29 20:28:39 --> Input Class Initialized
INFO - 2018-06-29 20:28:39 --> Language Class Initialized
INFO - 2018-06-29 20:28:39 --> Loader Class Initialized
INFO - 2018-06-29 20:28:39 --> Helper loaded: url_helper
INFO - 2018-06-29 20:28:39 --> Helper loaded: form_helper
INFO - 2018-06-29 20:28:39 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:28:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:28:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:28:39 --> User Agent Class Initialized
INFO - 2018-06-29 20:28:39 --> Controller Class Initialized
INFO - 2018-06-29 20:28:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:28:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:28:39 --> Pixel_Model class loaded
INFO - 2018-06-29 20:28:39 --> Database Driver Class Initialized
INFO - 2018-06-29 20:28:39 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:28:39 --> Database Driver Class Initialized
INFO - 2018-06-29 20:28:39 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:28:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:28:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:28:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:28:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:28:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:28:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:28:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:28:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids_doctor.php
INFO - 2018-06-29 20:28:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:28:39 --> Final output sent to browser
DEBUG - 2018-06-29 20:28:39 --> Total execution time: 0.0570
INFO - 2018-06-29 20:28:42 --> Config Class Initialized
INFO - 2018-06-29 20:28:42 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:28:42 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:28:42 --> Utf8 Class Initialized
INFO - 2018-06-29 20:28:42 --> URI Class Initialized
INFO - 2018-06-29 20:28:42 --> Router Class Initialized
INFO - 2018-06-29 20:28:42 --> Output Class Initialized
INFO - 2018-06-29 20:28:42 --> Security Class Initialized
DEBUG - 2018-06-29 20:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:28:42 --> CSRF cookie sent
INFO - 2018-06-29 20:28:42 --> CSRF token verified
INFO - 2018-06-29 20:28:42 --> Input Class Initialized
INFO - 2018-06-29 20:28:42 --> Language Class Initialized
INFO - 2018-06-29 20:28:42 --> Loader Class Initialized
INFO - 2018-06-29 20:28:42 --> Helper loaded: url_helper
INFO - 2018-06-29 20:28:42 --> Helper loaded: form_helper
INFO - 2018-06-29 20:28:42 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:28:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:28:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:28:42 --> User Agent Class Initialized
INFO - 2018-06-29 20:28:42 --> Controller Class Initialized
INFO - 2018-06-29 20:28:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:28:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:28:42 --> Pixel_Model class loaded
INFO - 2018-06-29 20:28:42 --> Database Driver Class Initialized
INFO - 2018-06-29 20:28:42 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:28:42 --> Form Validation Class Initialized
INFO - 2018-06-29 20:28:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-29 20:28:42 --> Database Driver Class Initialized
INFO - 2018-06-29 20:28:42 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:28:42 --> Config Class Initialized
INFO - 2018-06-29 20:28:42 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:28:42 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:28:42 --> Utf8 Class Initialized
INFO - 2018-06-29 20:28:42 --> URI Class Initialized
INFO - 2018-06-29 20:28:42 --> Router Class Initialized
INFO - 2018-06-29 20:28:42 --> Output Class Initialized
INFO - 2018-06-29 20:28:42 --> Security Class Initialized
DEBUG - 2018-06-29 20:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:28:42 --> CSRF cookie sent
INFO - 2018-06-29 20:28:42 --> Input Class Initialized
INFO - 2018-06-29 20:28:42 --> Language Class Initialized
INFO - 2018-06-29 20:28:42 --> Loader Class Initialized
INFO - 2018-06-29 20:28:42 --> Helper loaded: url_helper
INFO - 2018-06-29 20:28:42 --> Helper loaded: form_helper
INFO - 2018-06-29 20:28:42 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:28:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:28:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:28:42 --> User Agent Class Initialized
INFO - 2018-06-29 20:28:42 --> Controller Class Initialized
INFO - 2018-06-29 20:28:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:28:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:28:42 --> Pixel_Model class loaded
INFO - 2018-06-29 20:28:42 --> Database Driver Class Initialized
INFO - 2018-06-29 20:28:42 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:28:42 --> Database Driver Class Initialized
INFO - 2018-06-29 20:28:42 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:28:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:28:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:28:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:28:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:28:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:28:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:28:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:28:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids_help_complaint.php
INFO - 2018-06-29 20:28:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:28:42 --> Final output sent to browser
DEBUG - 2018-06-29 20:28:42 --> Total execution time: 0.0433
INFO - 2018-06-29 20:28:48 --> Config Class Initialized
INFO - 2018-06-29 20:28:48 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:28:48 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:28:48 --> Utf8 Class Initialized
INFO - 2018-06-29 20:28:48 --> URI Class Initialized
INFO - 2018-06-29 20:28:48 --> Router Class Initialized
INFO - 2018-06-29 20:28:48 --> Output Class Initialized
INFO - 2018-06-29 20:28:48 --> Security Class Initialized
DEBUG - 2018-06-29 20:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:28:48 --> CSRF cookie sent
INFO - 2018-06-29 20:28:48 --> CSRF token verified
INFO - 2018-06-29 20:28:48 --> Input Class Initialized
INFO - 2018-06-29 20:28:48 --> Language Class Initialized
INFO - 2018-06-29 20:28:48 --> Loader Class Initialized
INFO - 2018-06-29 20:28:48 --> Helper loaded: url_helper
INFO - 2018-06-29 20:28:48 --> Helper loaded: form_helper
INFO - 2018-06-29 20:28:48 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:28:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:28:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:28:48 --> User Agent Class Initialized
INFO - 2018-06-29 20:28:48 --> Controller Class Initialized
INFO - 2018-06-29 20:28:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:28:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:28:48 --> Pixel_Model class loaded
INFO - 2018-06-29 20:28:48 --> Database Driver Class Initialized
INFO - 2018-06-29 20:28:48 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:28:48 --> Form Validation Class Initialized
INFO - 2018-06-29 20:28:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-29 20:28:48 --> Database Driver Class Initialized
INFO - 2018-06-29 20:28:48 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:28:48 --> Config Class Initialized
INFO - 2018-06-29 20:28:48 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:28:48 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:28:48 --> Utf8 Class Initialized
INFO - 2018-06-29 20:28:48 --> URI Class Initialized
INFO - 2018-06-29 20:28:48 --> Router Class Initialized
INFO - 2018-06-29 20:28:48 --> Output Class Initialized
INFO - 2018-06-29 20:28:48 --> Security Class Initialized
DEBUG - 2018-06-29 20:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:28:48 --> CSRF cookie sent
INFO - 2018-06-29 20:28:48 --> Input Class Initialized
INFO - 2018-06-29 20:28:48 --> Language Class Initialized
INFO - 2018-06-29 20:28:48 --> Loader Class Initialized
INFO - 2018-06-29 20:28:48 --> Helper loaded: url_helper
INFO - 2018-06-29 20:28:48 --> Helper loaded: form_helper
INFO - 2018-06-29 20:28:48 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:28:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:28:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:28:48 --> User Agent Class Initialized
INFO - 2018-06-29 20:28:48 --> Controller Class Initialized
INFO - 2018-06-29 20:28:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:28:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:28:48 --> Pixel_Model class loaded
INFO - 2018-06-29 20:28:48 --> Database Driver Class Initialized
INFO - 2018-06-29 20:28:48 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:28:48 --> Database Driver Class Initialized
INFO - 2018-06-29 20:28:48 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:28:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:28:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:28:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:28:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:28:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:28:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:28:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:28:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/spouse_info.php
INFO - 2018-06-29 20:28:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:28:48 --> Final output sent to browser
DEBUG - 2018-06-29 20:28:48 --> Total execution time: 0.0407
INFO - 2018-06-29 20:29:01 --> Config Class Initialized
INFO - 2018-06-29 20:29:01 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:29:01 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:29:01 --> Utf8 Class Initialized
INFO - 2018-06-29 20:29:01 --> URI Class Initialized
INFO - 2018-06-29 20:29:01 --> Router Class Initialized
INFO - 2018-06-29 20:29:01 --> Output Class Initialized
INFO - 2018-06-29 20:29:01 --> Security Class Initialized
DEBUG - 2018-06-29 20:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:29:01 --> CSRF cookie sent
INFO - 2018-06-29 20:29:01 --> CSRF token verified
INFO - 2018-06-29 20:29:01 --> Input Class Initialized
INFO - 2018-06-29 20:29:01 --> Language Class Initialized
INFO - 2018-06-29 20:29:01 --> Loader Class Initialized
INFO - 2018-06-29 20:29:01 --> Helper loaded: url_helper
INFO - 2018-06-29 20:29:01 --> Helper loaded: form_helper
INFO - 2018-06-29 20:29:01 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:29:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:29:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:29:01 --> User Agent Class Initialized
INFO - 2018-06-29 20:29:01 --> Controller Class Initialized
INFO - 2018-06-29 20:29:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:29:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:29:01 --> Pixel_Model class loaded
INFO - 2018-06-29 20:29:01 --> Database Driver Class Initialized
INFO - 2018-06-29 20:29:01 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:29:01 --> Form Validation Class Initialized
INFO - 2018-06-29 20:29:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-29 20:29:01 --> Database Driver Class Initialized
INFO - 2018-06-29 20:29:01 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:29:01 --> Config Class Initialized
INFO - 2018-06-29 20:29:01 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:29:01 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:29:01 --> Utf8 Class Initialized
INFO - 2018-06-29 20:29:01 --> URI Class Initialized
INFO - 2018-06-29 20:29:01 --> Router Class Initialized
INFO - 2018-06-29 20:29:01 --> Output Class Initialized
INFO - 2018-06-29 20:29:01 --> Security Class Initialized
DEBUG - 2018-06-29 20:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:29:01 --> CSRF cookie sent
INFO - 2018-06-29 20:29:01 --> Input Class Initialized
INFO - 2018-06-29 20:29:01 --> Language Class Initialized
INFO - 2018-06-29 20:29:01 --> Loader Class Initialized
INFO - 2018-06-29 20:29:01 --> Helper loaded: url_helper
INFO - 2018-06-29 20:29:01 --> Helper loaded: form_helper
INFO - 2018-06-29 20:29:01 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:29:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:29:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:29:01 --> User Agent Class Initialized
INFO - 2018-06-29 20:29:01 --> Controller Class Initialized
INFO - 2018-06-29 20:29:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:29:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:29:01 --> Pixel_Model class loaded
INFO - 2018-06-29 20:29:01 --> Database Driver Class Initialized
INFO - 2018-06-29 20:29:01 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:29:01 --> Database Driver Class Initialized
INFO - 2018-06-29 20:29:01 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:29:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:29:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:29:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:29:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:29:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:29:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:29:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:29:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/spouse_job.php
INFO - 2018-06-29 20:29:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:29:01 --> Final output sent to browser
DEBUG - 2018-06-29 20:29:01 --> Total execution time: 0.0445
INFO - 2018-06-29 20:29:07 --> Config Class Initialized
INFO - 2018-06-29 20:29:07 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:29:07 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:29:07 --> Utf8 Class Initialized
INFO - 2018-06-29 20:29:07 --> URI Class Initialized
INFO - 2018-06-29 20:29:07 --> Router Class Initialized
INFO - 2018-06-29 20:29:07 --> Output Class Initialized
INFO - 2018-06-29 20:29:07 --> Security Class Initialized
DEBUG - 2018-06-29 20:29:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:29:07 --> CSRF cookie sent
INFO - 2018-06-29 20:29:07 --> CSRF token verified
INFO - 2018-06-29 20:29:07 --> Input Class Initialized
INFO - 2018-06-29 20:29:07 --> Language Class Initialized
INFO - 2018-06-29 20:29:07 --> Loader Class Initialized
INFO - 2018-06-29 20:29:07 --> Helper loaded: url_helper
INFO - 2018-06-29 20:29:07 --> Helper loaded: form_helper
INFO - 2018-06-29 20:29:07 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:29:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:29:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:29:07 --> User Agent Class Initialized
INFO - 2018-06-29 20:29:07 --> Controller Class Initialized
INFO - 2018-06-29 20:29:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:29:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:29:07 --> Pixel_Model class loaded
INFO - 2018-06-29 20:29:07 --> Database Driver Class Initialized
INFO - 2018-06-29 20:29:07 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:29:07 --> Form Validation Class Initialized
INFO - 2018-06-29 20:29:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-29 20:29:07 --> Database Driver Class Initialized
INFO - 2018-06-29 20:29:07 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:29:07 --> Config Class Initialized
INFO - 2018-06-29 20:29:07 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:29:07 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:29:07 --> Utf8 Class Initialized
INFO - 2018-06-29 20:29:07 --> URI Class Initialized
INFO - 2018-06-29 20:29:07 --> Router Class Initialized
INFO - 2018-06-29 20:29:07 --> Output Class Initialized
INFO - 2018-06-29 20:29:07 --> Security Class Initialized
DEBUG - 2018-06-29 20:29:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:29:07 --> CSRF cookie sent
INFO - 2018-06-29 20:29:07 --> Input Class Initialized
INFO - 2018-06-29 20:29:07 --> Language Class Initialized
INFO - 2018-06-29 20:29:07 --> Loader Class Initialized
INFO - 2018-06-29 20:29:07 --> Helper loaded: url_helper
INFO - 2018-06-29 20:29:07 --> Helper loaded: form_helper
INFO - 2018-06-29 20:29:07 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:29:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:29:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:29:07 --> User Agent Class Initialized
INFO - 2018-06-29 20:29:07 --> Controller Class Initialized
INFO - 2018-06-29 20:29:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:29:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:29:07 --> Pixel_Model class loaded
INFO - 2018-06-29 20:29:07 --> Database Driver Class Initialized
INFO - 2018-06-29 20:29:07 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:29:07 --> Database Driver Class Initialized
INFO - 2018-06-29 20:29:07 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:29:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:29:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:29:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:29:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:29:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:29:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:29:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:29:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/affectionate_salutation.php
INFO - 2018-06-29 20:29:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:29:07 --> Final output sent to browser
DEBUG - 2018-06-29 20:29:07 --> Total execution time: 0.0427
INFO - 2018-06-29 20:29:46 --> Config Class Initialized
INFO - 2018-06-29 20:29:46 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:29:46 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:29:46 --> Utf8 Class Initialized
INFO - 2018-06-29 20:29:46 --> URI Class Initialized
INFO - 2018-06-29 20:29:46 --> Router Class Initialized
INFO - 2018-06-29 20:29:46 --> Output Class Initialized
INFO - 2018-06-29 20:29:46 --> Security Class Initialized
DEBUG - 2018-06-29 20:29:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:29:46 --> CSRF cookie sent
INFO - 2018-06-29 20:29:46 --> CSRF token verified
INFO - 2018-06-29 20:29:46 --> Input Class Initialized
INFO - 2018-06-29 20:29:46 --> Language Class Initialized
INFO - 2018-06-29 20:29:46 --> Loader Class Initialized
INFO - 2018-06-29 20:29:46 --> Helper loaded: url_helper
INFO - 2018-06-29 20:29:46 --> Helper loaded: form_helper
INFO - 2018-06-29 20:29:46 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:29:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:29:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:29:46 --> User Agent Class Initialized
INFO - 2018-06-29 20:29:46 --> Controller Class Initialized
INFO - 2018-06-29 20:29:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:29:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:29:46 --> Pixel_Model class loaded
INFO - 2018-06-29 20:29:46 --> Database Driver Class Initialized
INFO - 2018-06-29 20:29:46 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:29:46 --> Form Validation Class Initialized
INFO - 2018-06-29 20:29:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-29 20:29:46 --> Database Driver Class Initialized
INFO - 2018-06-29 20:29:46 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:29:46 --> Config Class Initialized
INFO - 2018-06-29 20:29:46 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:29:46 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:29:46 --> Utf8 Class Initialized
INFO - 2018-06-29 20:29:46 --> URI Class Initialized
INFO - 2018-06-29 20:29:46 --> Router Class Initialized
INFO - 2018-06-29 20:29:46 --> Output Class Initialized
INFO - 2018-06-29 20:29:46 --> Security Class Initialized
DEBUG - 2018-06-29 20:29:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:29:46 --> CSRF cookie sent
INFO - 2018-06-29 20:29:46 --> Input Class Initialized
INFO - 2018-06-29 20:29:46 --> Language Class Initialized
INFO - 2018-06-29 20:29:46 --> Loader Class Initialized
INFO - 2018-06-29 20:29:46 --> Helper loaded: url_helper
INFO - 2018-06-29 20:29:46 --> Helper loaded: form_helper
INFO - 2018-06-29 20:29:46 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:29:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:29:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:29:46 --> User Agent Class Initialized
INFO - 2018-06-29 20:29:46 --> Controller Class Initialized
INFO - 2018-06-29 20:29:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:29:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:29:46 --> Pixel_Model class loaded
INFO - 2018-06-29 20:29:46 --> Database Driver Class Initialized
INFO - 2018-06-29 20:29:46 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:29:46 --> Database Driver Class Initialized
INFO - 2018-06-29 20:29:46 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:29:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:29:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:29:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:29:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:29:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:29:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:29:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:29:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/business_tax_info.php
INFO - 2018-06-29 20:29:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:29:46 --> Final output sent to browser
DEBUG - 2018-06-29 20:29:46 --> Total execution time: 0.0435
INFO - 2018-06-29 20:29:55 --> Config Class Initialized
INFO - 2018-06-29 20:29:55 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:29:55 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:29:55 --> Utf8 Class Initialized
INFO - 2018-06-29 20:29:55 --> URI Class Initialized
INFO - 2018-06-29 20:29:55 --> Router Class Initialized
INFO - 2018-06-29 20:29:55 --> Output Class Initialized
INFO - 2018-06-29 20:29:55 --> Security Class Initialized
DEBUG - 2018-06-29 20:29:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:29:55 --> CSRF cookie sent
INFO - 2018-06-29 20:29:55 --> CSRF token verified
INFO - 2018-06-29 20:29:55 --> Input Class Initialized
INFO - 2018-06-29 20:29:55 --> Language Class Initialized
INFO - 2018-06-29 20:29:55 --> Loader Class Initialized
INFO - 2018-06-29 20:29:55 --> Helper loaded: url_helper
INFO - 2018-06-29 20:29:55 --> Helper loaded: form_helper
INFO - 2018-06-29 20:29:55 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:29:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:29:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:29:55 --> User Agent Class Initialized
INFO - 2018-06-29 20:29:55 --> Controller Class Initialized
INFO - 2018-06-29 20:29:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:29:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:29:55 --> Pixel_Model class loaded
INFO - 2018-06-29 20:29:55 --> Database Driver Class Initialized
INFO - 2018-06-29 20:29:55 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:29:55 --> Form Validation Class Initialized
INFO - 2018-06-29 20:29:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-29 20:29:55 --> Database Driver Class Initialized
INFO - 2018-06-29 20:29:55 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:29:55 --> Config Class Initialized
INFO - 2018-06-29 20:29:55 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:29:55 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:29:55 --> Utf8 Class Initialized
INFO - 2018-06-29 20:29:55 --> URI Class Initialized
INFO - 2018-06-29 20:29:55 --> Router Class Initialized
INFO - 2018-06-29 20:29:55 --> Output Class Initialized
INFO - 2018-06-29 20:29:55 --> Security Class Initialized
DEBUG - 2018-06-29 20:29:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:29:55 --> CSRF cookie sent
INFO - 2018-06-29 20:29:55 --> Input Class Initialized
INFO - 2018-06-29 20:29:55 --> Language Class Initialized
INFO - 2018-06-29 20:29:55 --> Loader Class Initialized
INFO - 2018-06-29 20:29:55 --> Helper loaded: url_helper
INFO - 2018-06-29 20:29:55 --> Helper loaded: form_helper
INFO - 2018-06-29 20:29:55 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:29:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:29:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:29:55 --> User Agent Class Initialized
INFO - 2018-06-29 20:29:55 --> Controller Class Initialized
INFO - 2018-06-29 20:29:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:29:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:29:55 --> Pixel_Model class loaded
INFO - 2018-06-29 20:29:55 --> Database Driver Class Initialized
INFO - 2018-06-29 20:29:55 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:29:55 --> Database Driver Class Initialized
INFO - 2018-06-29 20:29:55 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:29:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:29:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:29:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:29:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:29:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:29:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:29:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:29:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/trust_info.php
INFO - 2018-06-29 20:29:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:29:55 --> Final output sent to browser
DEBUG - 2018-06-29 20:29:55 --> Total execution time: 0.0395
INFO - 2018-06-29 20:30:08 --> Config Class Initialized
INFO - 2018-06-29 20:30:08 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:30:08 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:30:08 --> Utf8 Class Initialized
INFO - 2018-06-29 20:30:08 --> URI Class Initialized
INFO - 2018-06-29 20:30:08 --> Router Class Initialized
INFO - 2018-06-29 20:30:08 --> Output Class Initialized
INFO - 2018-06-29 20:30:08 --> Security Class Initialized
DEBUG - 2018-06-29 20:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:30:08 --> CSRF cookie sent
INFO - 2018-06-29 20:30:08 --> CSRF token verified
INFO - 2018-06-29 20:30:08 --> Input Class Initialized
INFO - 2018-06-29 20:30:08 --> Language Class Initialized
INFO - 2018-06-29 20:30:08 --> Loader Class Initialized
INFO - 2018-06-29 20:30:08 --> Helper loaded: url_helper
INFO - 2018-06-29 20:30:08 --> Helper loaded: form_helper
INFO - 2018-06-29 20:30:08 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:30:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:30:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:30:08 --> User Agent Class Initialized
INFO - 2018-06-29 20:30:08 --> Controller Class Initialized
INFO - 2018-06-29 20:30:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:30:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:30:08 --> Pixel_Model class loaded
INFO - 2018-06-29 20:30:08 --> Database Driver Class Initialized
INFO - 2018-06-29 20:30:08 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:30:08 --> Form Validation Class Initialized
INFO - 2018-06-29 20:30:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-29 20:30:08 --> Database Driver Class Initialized
INFO - 2018-06-29 20:30:08 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:30:08 --> Config Class Initialized
INFO - 2018-06-29 20:30:08 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:30:08 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:30:08 --> Utf8 Class Initialized
INFO - 2018-06-29 20:30:08 --> URI Class Initialized
INFO - 2018-06-29 20:30:08 --> Router Class Initialized
INFO - 2018-06-29 20:30:08 --> Output Class Initialized
INFO - 2018-06-29 20:30:08 --> Security Class Initialized
DEBUG - 2018-06-29 20:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:30:08 --> CSRF cookie sent
INFO - 2018-06-29 20:30:08 --> Input Class Initialized
INFO - 2018-06-29 20:30:08 --> Language Class Initialized
INFO - 2018-06-29 20:30:08 --> Loader Class Initialized
INFO - 2018-06-29 20:30:08 --> Helper loaded: url_helper
INFO - 2018-06-29 20:30:08 --> Helper loaded: form_helper
INFO - 2018-06-29 20:30:08 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:30:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:30:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:30:08 --> User Agent Class Initialized
INFO - 2018-06-29 20:30:08 --> Controller Class Initialized
INFO - 2018-06-29 20:30:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:30:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:30:08 --> Pixel_Model class loaded
INFO - 2018-06-29 20:30:08 --> Database Driver Class Initialized
INFO - 2018-06-29 20:30:08 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:30:08 --> Database Driver Class Initialized
INFO - 2018-06-29 20:30:08 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:30:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:30:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:30:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:30:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:30:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:30:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:30:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:30:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inherited_income.php
INFO - 2018-06-29 20:30:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:30:08 --> Final output sent to browser
DEBUG - 2018-06-29 20:30:08 --> Total execution time: 0.0402
INFO - 2018-06-29 20:30:18 --> Config Class Initialized
INFO - 2018-06-29 20:30:18 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:30:18 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:30:18 --> Utf8 Class Initialized
INFO - 2018-06-29 20:30:18 --> URI Class Initialized
INFO - 2018-06-29 20:30:18 --> Router Class Initialized
INFO - 2018-06-29 20:30:18 --> Output Class Initialized
INFO - 2018-06-29 20:30:18 --> Security Class Initialized
DEBUG - 2018-06-29 20:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:30:18 --> CSRF cookie sent
INFO - 2018-06-29 20:30:18 --> CSRF token verified
INFO - 2018-06-29 20:30:18 --> Input Class Initialized
INFO - 2018-06-29 20:30:18 --> Language Class Initialized
INFO - 2018-06-29 20:30:18 --> Loader Class Initialized
INFO - 2018-06-29 20:30:18 --> Helper loaded: url_helper
INFO - 2018-06-29 20:30:18 --> Helper loaded: form_helper
INFO - 2018-06-29 20:30:18 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:30:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:30:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:30:18 --> User Agent Class Initialized
INFO - 2018-06-29 20:30:18 --> Controller Class Initialized
INFO - 2018-06-29 20:30:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:30:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:30:18 --> Pixel_Model class loaded
INFO - 2018-06-29 20:30:18 --> Database Driver Class Initialized
INFO - 2018-06-29 20:30:18 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:30:18 --> Form Validation Class Initialized
INFO - 2018-06-29 20:30:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-29 20:30:18 --> Database Driver Class Initialized
INFO - 2018-06-29 20:30:18 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:30:18 --> Config Class Initialized
INFO - 2018-06-29 20:30:18 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:30:18 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:30:18 --> Utf8 Class Initialized
INFO - 2018-06-29 20:30:18 --> URI Class Initialized
INFO - 2018-06-29 20:30:18 --> Router Class Initialized
INFO - 2018-06-29 20:30:18 --> Output Class Initialized
INFO - 2018-06-29 20:30:18 --> Security Class Initialized
DEBUG - 2018-06-29 20:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:30:18 --> CSRF cookie sent
INFO - 2018-06-29 20:30:18 --> Input Class Initialized
INFO - 2018-06-29 20:30:18 --> Language Class Initialized
INFO - 2018-06-29 20:30:18 --> Loader Class Initialized
INFO - 2018-06-29 20:30:18 --> Helper loaded: url_helper
INFO - 2018-06-29 20:30:18 --> Helper loaded: form_helper
INFO - 2018-06-29 20:30:18 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:30:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:30:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:30:18 --> User Agent Class Initialized
INFO - 2018-06-29 20:30:18 --> Controller Class Initialized
INFO - 2018-06-29 20:30:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:30:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:30:18 --> Pixel_Model class loaded
INFO - 2018-06-29 20:30:18 --> Database Driver Class Initialized
INFO - 2018-06-29 20:30:18 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:30:18 --> Database Driver Class Initialized
INFO - 2018-06-29 20:30:18 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:30:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:30:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:30:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:30:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:30:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:30:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:30:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:30:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/shift_work.php
INFO - 2018-06-29 20:30:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:30:18 --> Final output sent to browser
DEBUG - 2018-06-29 20:30:18 --> Total execution time: 0.0454
INFO - 2018-06-29 20:30:22 --> Config Class Initialized
INFO - 2018-06-29 20:30:22 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:30:22 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:30:22 --> Utf8 Class Initialized
INFO - 2018-06-29 20:30:22 --> URI Class Initialized
INFO - 2018-06-29 20:30:22 --> Router Class Initialized
INFO - 2018-06-29 20:30:22 --> Output Class Initialized
INFO - 2018-06-29 20:30:22 --> Security Class Initialized
DEBUG - 2018-06-29 20:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:30:22 --> CSRF cookie sent
INFO - 2018-06-29 20:30:22 --> CSRF token verified
INFO - 2018-06-29 20:30:22 --> Input Class Initialized
INFO - 2018-06-29 20:30:22 --> Language Class Initialized
INFO - 2018-06-29 20:30:22 --> Loader Class Initialized
INFO - 2018-06-29 20:30:22 --> Helper loaded: url_helper
INFO - 2018-06-29 20:30:22 --> Helper loaded: form_helper
INFO - 2018-06-29 20:30:22 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:30:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:30:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:30:22 --> User Agent Class Initialized
INFO - 2018-06-29 20:30:22 --> Controller Class Initialized
INFO - 2018-06-29 20:30:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:30:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:30:22 --> Pixel_Model class loaded
INFO - 2018-06-29 20:30:22 --> Database Driver Class Initialized
INFO - 2018-06-29 20:30:22 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:30:22 --> Form Validation Class Initialized
INFO - 2018-06-29 20:30:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-29 20:30:22 --> Database Driver Class Initialized
INFO - 2018-06-29 20:30:22 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:30:22 --> Config Class Initialized
INFO - 2018-06-29 20:30:22 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:30:22 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:30:22 --> Utf8 Class Initialized
INFO - 2018-06-29 20:30:22 --> URI Class Initialized
INFO - 2018-06-29 20:30:22 --> Router Class Initialized
INFO - 2018-06-29 20:30:22 --> Output Class Initialized
INFO - 2018-06-29 20:30:22 --> Security Class Initialized
DEBUG - 2018-06-29 20:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:30:22 --> CSRF cookie sent
INFO - 2018-06-29 20:30:22 --> Input Class Initialized
INFO - 2018-06-29 20:30:22 --> Language Class Initialized
INFO - 2018-06-29 20:30:22 --> Loader Class Initialized
INFO - 2018-06-29 20:30:22 --> Helper loaded: url_helper
INFO - 2018-06-29 20:30:22 --> Helper loaded: form_helper
INFO - 2018-06-29 20:30:22 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:30:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:30:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:30:22 --> User Agent Class Initialized
INFO - 2018-06-29 20:30:22 --> Controller Class Initialized
INFO - 2018-06-29 20:30:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:30:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:30:22 --> Pixel_Model class loaded
INFO - 2018-06-29 20:30:22 --> Database Driver Class Initialized
INFO - 2018-06-29 20:30:22 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:30:22 --> Database Driver Class Initialized
INFO - 2018-06-29 20:30:22 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:30:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:30:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:30:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:30:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:30:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:30:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:30:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:30:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/night_without_s.php
INFO - 2018-06-29 20:30:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:30:22 --> Final output sent to browser
DEBUG - 2018-06-29 20:30:22 --> Total execution time: 0.0589
INFO - 2018-06-29 20:30:29 --> Config Class Initialized
INFO - 2018-06-29 20:30:29 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:30:29 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:30:29 --> Utf8 Class Initialized
INFO - 2018-06-29 20:30:29 --> URI Class Initialized
INFO - 2018-06-29 20:30:29 --> Router Class Initialized
INFO - 2018-06-29 20:30:29 --> Output Class Initialized
INFO - 2018-06-29 20:30:29 --> Security Class Initialized
DEBUG - 2018-06-29 20:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:30:29 --> CSRF cookie sent
INFO - 2018-06-29 20:30:29 --> CSRF token verified
INFO - 2018-06-29 20:30:29 --> Input Class Initialized
INFO - 2018-06-29 20:30:29 --> Language Class Initialized
INFO - 2018-06-29 20:30:29 --> Loader Class Initialized
INFO - 2018-06-29 20:30:29 --> Helper loaded: url_helper
INFO - 2018-06-29 20:30:29 --> Helper loaded: form_helper
INFO - 2018-06-29 20:30:29 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:30:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:30:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:30:29 --> User Agent Class Initialized
INFO - 2018-06-29 20:30:29 --> Controller Class Initialized
INFO - 2018-06-29 20:30:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:30:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:30:29 --> Pixel_Model class loaded
INFO - 2018-06-29 20:30:29 --> Database Driver Class Initialized
INFO - 2018-06-29 20:30:29 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:30:29 --> Form Validation Class Initialized
INFO - 2018-06-29 20:30:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-29 20:30:29 --> Database Driver Class Initialized
INFO - 2018-06-29 20:30:29 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:30:29 --> Config Class Initialized
INFO - 2018-06-29 20:30:29 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:30:29 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:30:29 --> Utf8 Class Initialized
INFO - 2018-06-29 20:30:29 --> URI Class Initialized
INFO - 2018-06-29 20:30:29 --> Router Class Initialized
INFO - 2018-06-29 20:30:29 --> Output Class Initialized
INFO - 2018-06-29 20:30:29 --> Security Class Initialized
DEBUG - 2018-06-29 20:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:30:29 --> CSRF cookie sent
INFO - 2018-06-29 20:30:29 --> Input Class Initialized
INFO - 2018-06-29 20:30:29 --> Language Class Initialized
INFO - 2018-06-29 20:30:29 --> Loader Class Initialized
INFO - 2018-06-29 20:30:29 --> Helper loaded: url_helper
INFO - 2018-06-29 20:30:29 --> Helper loaded: form_helper
INFO - 2018-06-29 20:30:29 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:30:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:30:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:30:29 --> User Agent Class Initialized
INFO - 2018-06-29 20:30:29 --> Controller Class Initialized
INFO - 2018-06-29 20:30:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:30:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:30:29 --> Pixel_Model class loaded
INFO - 2018-06-29 20:30:29 --> Database Driver Class Initialized
INFO - 2018-06-29 20:30:29 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:30:29 --> Database Driver Class Initialized
INFO - 2018-06-29 20:30:29 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:30:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:30:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:30:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:30:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:30:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:30:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:30:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:30:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/have_date.php
INFO - 2018-06-29 20:30:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:30:29 --> Final output sent to browser
DEBUG - 2018-06-29 20:30:29 --> Total execution time: 0.0429
INFO - 2018-06-29 20:30:36 --> Config Class Initialized
INFO - 2018-06-29 20:30:36 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:30:36 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:30:36 --> Utf8 Class Initialized
INFO - 2018-06-29 20:30:36 --> URI Class Initialized
INFO - 2018-06-29 20:30:36 --> Router Class Initialized
INFO - 2018-06-29 20:30:36 --> Output Class Initialized
INFO - 2018-06-29 20:30:36 --> Security Class Initialized
DEBUG - 2018-06-29 20:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:30:36 --> CSRF cookie sent
INFO - 2018-06-29 20:30:36 --> CSRF token verified
INFO - 2018-06-29 20:30:36 --> Input Class Initialized
INFO - 2018-06-29 20:30:36 --> Language Class Initialized
INFO - 2018-06-29 20:30:36 --> Loader Class Initialized
INFO - 2018-06-29 20:30:36 --> Helper loaded: url_helper
INFO - 2018-06-29 20:30:36 --> Helper loaded: form_helper
INFO - 2018-06-29 20:30:36 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:30:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:30:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:30:36 --> User Agent Class Initialized
INFO - 2018-06-29 20:30:36 --> Controller Class Initialized
INFO - 2018-06-29 20:30:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:30:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:30:36 --> Pixel_Model class loaded
INFO - 2018-06-29 20:30:36 --> Database Driver Class Initialized
INFO - 2018-06-29 20:30:36 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:30:36 --> Form Validation Class Initialized
INFO - 2018-06-29 20:30:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-29 20:30:36 --> Database Driver Class Initialized
INFO - 2018-06-29 20:30:36 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:30:36 --> Config Class Initialized
INFO - 2018-06-29 20:30:36 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:30:36 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:30:36 --> Utf8 Class Initialized
INFO - 2018-06-29 20:30:36 --> URI Class Initialized
INFO - 2018-06-29 20:30:36 --> Router Class Initialized
INFO - 2018-06-29 20:30:36 --> Output Class Initialized
INFO - 2018-06-29 20:30:36 --> Security Class Initialized
DEBUG - 2018-06-29 20:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:30:36 --> CSRF cookie sent
INFO - 2018-06-29 20:30:36 --> Input Class Initialized
INFO - 2018-06-29 20:30:36 --> Language Class Initialized
INFO - 2018-06-29 20:30:36 --> Loader Class Initialized
INFO - 2018-06-29 20:30:36 --> Helper loaded: url_helper
INFO - 2018-06-29 20:30:36 --> Helper loaded: form_helper
INFO - 2018-06-29 20:30:36 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:30:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:30:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:30:36 --> User Agent Class Initialized
INFO - 2018-06-29 20:30:36 --> Controller Class Initialized
INFO - 2018-06-29 20:30:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:30:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:30:36 --> Pixel_Model class loaded
INFO - 2018-06-29 20:30:36 --> Database Driver Class Initialized
INFO - 2018-06-29 20:30:36 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:30:36 --> Database Driver Class Initialized
INFO - 2018-06-29 20:30:36 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:30:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:30:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:30:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:30:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:30:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:30:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:30:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:30:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/nights_not_home.php
INFO - 2018-06-29 20:30:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:30:36 --> Final output sent to browser
DEBUG - 2018-06-29 20:30:36 --> Total execution time: 0.0419
INFO - 2018-06-29 20:30:42 --> Config Class Initialized
INFO - 2018-06-29 20:30:42 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:30:42 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:30:42 --> Utf8 Class Initialized
INFO - 2018-06-29 20:30:42 --> URI Class Initialized
INFO - 2018-06-29 20:30:42 --> Router Class Initialized
INFO - 2018-06-29 20:30:42 --> Output Class Initialized
INFO - 2018-06-29 20:30:42 --> Security Class Initialized
DEBUG - 2018-06-29 20:30:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:30:42 --> CSRF cookie sent
INFO - 2018-06-29 20:30:42 --> CSRF token verified
INFO - 2018-06-29 20:30:42 --> Input Class Initialized
INFO - 2018-06-29 20:30:42 --> Language Class Initialized
INFO - 2018-06-29 20:30:42 --> Loader Class Initialized
INFO - 2018-06-29 20:30:42 --> Helper loaded: url_helper
INFO - 2018-06-29 20:30:42 --> Helper loaded: form_helper
INFO - 2018-06-29 20:30:42 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:30:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:30:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:30:42 --> User Agent Class Initialized
INFO - 2018-06-29 20:30:42 --> Controller Class Initialized
INFO - 2018-06-29 20:30:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:30:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:30:42 --> Pixel_Model class loaded
INFO - 2018-06-29 20:30:42 --> Database Driver Class Initialized
INFO - 2018-06-29 20:30:42 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:30:42 --> Form Validation Class Initialized
INFO - 2018-06-29 20:30:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-29 20:30:42 --> Database Driver Class Initialized
INFO - 2018-06-29 20:30:42 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:30:42 --> Config Class Initialized
INFO - 2018-06-29 20:30:42 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:30:42 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:30:42 --> Utf8 Class Initialized
INFO - 2018-06-29 20:30:42 --> URI Class Initialized
INFO - 2018-06-29 20:30:42 --> Router Class Initialized
INFO - 2018-06-29 20:30:42 --> Output Class Initialized
INFO - 2018-06-29 20:30:42 --> Security Class Initialized
DEBUG - 2018-06-29 20:30:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:30:42 --> CSRF cookie sent
INFO - 2018-06-29 20:30:42 --> Input Class Initialized
INFO - 2018-06-29 20:30:42 --> Language Class Initialized
INFO - 2018-06-29 20:30:42 --> Loader Class Initialized
INFO - 2018-06-29 20:30:42 --> Helper loaded: url_helper
INFO - 2018-06-29 20:30:42 --> Helper loaded: form_helper
INFO - 2018-06-29 20:30:42 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:30:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:30:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:30:42 --> User Agent Class Initialized
INFO - 2018-06-29 20:30:42 --> Controller Class Initialized
INFO - 2018-06-29 20:30:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:30:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:30:42 --> Pixel_Model class loaded
INFO - 2018-06-29 20:30:42 --> Database Driver Class Initialized
INFO - 2018-06-29 20:30:42 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:30:42 --> Database Driver Class Initialized
INFO - 2018-06-29 20:30:42 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:30:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:30:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:30:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:30:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:30:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:30:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:30:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:30:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/s_nights_not_home.php
INFO - 2018-06-29 20:30:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:30:42 --> Final output sent to browser
DEBUG - 2018-06-29 20:30:42 --> Total execution time: 0.0423
INFO - 2018-06-29 20:30:44 --> Config Class Initialized
INFO - 2018-06-29 20:30:44 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:30:44 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:30:44 --> Utf8 Class Initialized
INFO - 2018-06-29 20:30:44 --> URI Class Initialized
INFO - 2018-06-29 20:30:44 --> Router Class Initialized
INFO - 2018-06-29 20:30:44 --> Output Class Initialized
INFO - 2018-06-29 20:30:44 --> Security Class Initialized
DEBUG - 2018-06-29 20:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:30:44 --> CSRF cookie sent
INFO - 2018-06-29 20:30:44 --> CSRF token verified
INFO - 2018-06-29 20:30:44 --> Input Class Initialized
INFO - 2018-06-29 20:30:44 --> Language Class Initialized
INFO - 2018-06-29 20:30:44 --> Loader Class Initialized
INFO - 2018-06-29 20:30:44 --> Helper loaded: url_helper
INFO - 2018-06-29 20:30:44 --> Helper loaded: form_helper
INFO - 2018-06-29 20:30:44 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:30:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:30:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:30:44 --> User Agent Class Initialized
INFO - 2018-06-29 20:30:44 --> Controller Class Initialized
INFO - 2018-06-29 20:30:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:30:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:30:44 --> Pixel_Model class loaded
INFO - 2018-06-29 20:30:44 --> Database Driver Class Initialized
INFO - 2018-06-29 20:30:44 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:30:44 --> Form Validation Class Initialized
INFO - 2018-06-29 20:30:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-29 20:30:44 --> Database Driver Class Initialized
INFO - 2018-06-29 20:30:44 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:30:45 --> Config Class Initialized
INFO - 2018-06-29 20:30:45 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:30:45 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:30:45 --> Utf8 Class Initialized
INFO - 2018-06-29 20:30:45 --> URI Class Initialized
INFO - 2018-06-29 20:30:45 --> Router Class Initialized
INFO - 2018-06-29 20:30:45 --> Output Class Initialized
INFO - 2018-06-29 20:30:45 --> Security Class Initialized
DEBUG - 2018-06-29 20:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:30:45 --> CSRF cookie sent
INFO - 2018-06-29 20:30:45 --> Input Class Initialized
INFO - 2018-06-29 20:30:45 --> Language Class Initialized
INFO - 2018-06-29 20:30:45 --> Loader Class Initialized
INFO - 2018-06-29 20:30:45 --> Helper loaded: url_helper
INFO - 2018-06-29 20:30:45 --> Helper loaded: form_helper
INFO - 2018-06-29 20:30:45 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:30:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:30:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:30:45 --> User Agent Class Initialized
INFO - 2018-06-29 20:30:45 --> Controller Class Initialized
INFO - 2018-06-29 20:30:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:30:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:30:45 --> Pixel_Model class loaded
INFO - 2018-06-29 20:30:45 --> Database Driver Class Initialized
INFO - 2018-06-29 20:30:45 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:30:45 --> Database Driver Class Initialized
INFO - 2018-06-29 20:30:45 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:30:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:30:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:30:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:30:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:30:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:30:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:30:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:30:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/s_nights_without_you.php
INFO - 2018-06-29 20:30:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:30:45 --> Final output sent to browser
DEBUG - 2018-06-29 20:30:45 --> Total execution time: 0.1113
INFO - 2018-06-29 20:30:47 --> Config Class Initialized
INFO - 2018-06-29 20:30:47 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:30:47 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:30:47 --> Utf8 Class Initialized
INFO - 2018-06-29 20:30:47 --> URI Class Initialized
INFO - 2018-06-29 20:30:47 --> Router Class Initialized
INFO - 2018-06-29 20:30:47 --> Output Class Initialized
INFO - 2018-06-29 20:30:47 --> Security Class Initialized
DEBUG - 2018-06-29 20:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:30:47 --> CSRF cookie sent
INFO - 2018-06-29 20:30:47 --> CSRF token verified
INFO - 2018-06-29 20:30:47 --> Input Class Initialized
INFO - 2018-06-29 20:30:47 --> Language Class Initialized
INFO - 2018-06-29 20:30:47 --> Loader Class Initialized
INFO - 2018-06-29 20:30:47 --> Helper loaded: url_helper
INFO - 2018-06-29 20:30:47 --> Helper loaded: form_helper
INFO - 2018-06-29 20:30:47 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:30:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:30:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:30:47 --> User Agent Class Initialized
INFO - 2018-06-29 20:30:47 --> Controller Class Initialized
INFO - 2018-06-29 20:30:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:30:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:30:47 --> Pixel_Model class loaded
INFO - 2018-06-29 20:30:47 --> Database Driver Class Initialized
INFO - 2018-06-29 20:30:47 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:30:47 --> Form Validation Class Initialized
INFO - 2018-06-29 20:30:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-29 20:30:47 --> Database Driver Class Initialized
INFO - 2018-06-29 20:30:47 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:30:47 --> Config Class Initialized
INFO - 2018-06-29 20:30:47 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:30:47 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:30:47 --> Utf8 Class Initialized
INFO - 2018-06-29 20:30:47 --> URI Class Initialized
INFO - 2018-06-29 20:30:47 --> Router Class Initialized
INFO - 2018-06-29 20:30:47 --> Output Class Initialized
INFO - 2018-06-29 20:30:47 --> Security Class Initialized
DEBUG - 2018-06-29 20:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:30:47 --> CSRF cookie sent
INFO - 2018-06-29 20:30:47 --> Input Class Initialized
INFO - 2018-06-29 20:30:47 --> Language Class Initialized
INFO - 2018-06-29 20:30:47 --> Loader Class Initialized
INFO - 2018-06-29 20:30:47 --> Helper loaded: url_helper
INFO - 2018-06-29 20:30:47 --> Helper loaded: form_helper
INFO - 2018-06-29 20:30:47 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:30:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:30:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:30:47 --> User Agent Class Initialized
INFO - 2018-06-29 20:30:47 --> Controller Class Initialized
INFO - 2018-06-29 20:30:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:30:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:30:47 --> Pixel_Model class loaded
INFO - 2018-06-29 20:30:47 --> Database Driver Class Initialized
INFO - 2018-06-29 20:30:47 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:30:47 --> Database Driver Class Initialized
INFO - 2018-06-29 20:30:47 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:30:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:30:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:30:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:30:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:30:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:30:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:30:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:30:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/alcoholic_drinks_per_week.php
INFO - 2018-06-29 20:30:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:30:47 --> Final output sent to browser
DEBUG - 2018-06-29 20:30:47 --> Total execution time: 0.0402
INFO - 2018-06-29 20:30:49 --> Config Class Initialized
INFO - 2018-06-29 20:30:49 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:30:49 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:30:49 --> Utf8 Class Initialized
INFO - 2018-06-29 20:30:49 --> URI Class Initialized
INFO - 2018-06-29 20:30:49 --> Router Class Initialized
INFO - 2018-06-29 20:30:49 --> Output Class Initialized
INFO - 2018-06-29 20:30:49 --> Security Class Initialized
DEBUG - 2018-06-29 20:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:30:49 --> CSRF cookie sent
INFO - 2018-06-29 20:30:49 --> CSRF token verified
INFO - 2018-06-29 20:30:49 --> Input Class Initialized
INFO - 2018-06-29 20:30:49 --> Language Class Initialized
INFO - 2018-06-29 20:30:49 --> Loader Class Initialized
INFO - 2018-06-29 20:30:49 --> Helper loaded: url_helper
INFO - 2018-06-29 20:30:49 --> Helper loaded: form_helper
INFO - 2018-06-29 20:30:49 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:30:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:30:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:30:49 --> User Agent Class Initialized
INFO - 2018-06-29 20:30:49 --> Controller Class Initialized
INFO - 2018-06-29 20:30:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:30:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:30:49 --> Pixel_Model class loaded
INFO - 2018-06-29 20:30:49 --> Database Driver Class Initialized
INFO - 2018-06-29 20:30:49 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:30:49 --> Form Validation Class Initialized
INFO - 2018-06-29 20:30:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-29 20:30:49 --> Database Driver Class Initialized
INFO - 2018-06-29 20:30:49 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:30:49 --> Config Class Initialized
INFO - 2018-06-29 20:30:49 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:30:49 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:30:49 --> Utf8 Class Initialized
INFO - 2018-06-29 20:30:49 --> URI Class Initialized
INFO - 2018-06-29 20:30:49 --> Router Class Initialized
INFO - 2018-06-29 20:30:49 --> Output Class Initialized
INFO - 2018-06-29 20:30:49 --> Security Class Initialized
DEBUG - 2018-06-29 20:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:30:49 --> CSRF cookie sent
INFO - 2018-06-29 20:30:49 --> Input Class Initialized
INFO - 2018-06-29 20:30:49 --> Language Class Initialized
INFO - 2018-06-29 20:30:49 --> Loader Class Initialized
INFO - 2018-06-29 20:30:49 --> Helper loaded: url_helper
INFO - 2018-06-29 20:30:49 --> Helper loaded: form_helper
INFO - 2018-06-29 20:30:49 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:30:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:30:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:30:49 --> User Agent Class Initialized
INFO - 2018-06-29 20:30:49 --> Controller Class Initialized
INFO - 2018-06-29 20:30:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:30:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:30:49 --> Pixel_Model class loaded
INFO - 2018-06-29 20:30:49 --> Database Driver Class Initialized
INFO - 2018-06-29 20:30:49 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:30:49 --> Database Driver Class Initialized
INFO - 2018-06-29 20:30:49 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:30:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:30:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:30:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:30:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:30:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:30:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:30:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:30:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/have_drugs.php
INFO - 2018-06-29 20:30:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:30:49 --> Final output sent to browser
DEBUG - 2018-06-29 20:30:49 --> Total execution time: 0.0423
INFO - 2018-06-29 20:30:52 --> Config Class Initialized
INFO - 2018-06-29 20:30:52 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:30:52 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:30:52 --> Utf8 Class Initialized
INFO - 2018-06-29 20:30:52 --> URI Class Initialized
INFO - 2018-06-29 20:30:52 --> Router Class Initialized
INFO - 2018-06-29 20:30:52 --> Output Class Initialized
INFO - 2018-06-29 20:30:52 --> Security Class Initialized
DEBUG - 2018-06-29 20:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:30:52 --> CSRF cookie sent
INFO - 2018-06-29 20:30:52 --> CSRF token verified
INFO - 2018-06-29 20:30:52 --> Input Class Initialized
INFO - 2018-06-29 20:30:52 --> Language Class Initialized
INFO - 2018-06-29 20:30:52 --> Loader Class Initialized
INFO - 2018-06-29 20:30:52 --> Helper loaded: url_helper
INFO - 2018-06-29 20:30:52 --> Helper loaded: form_helper
INFO - 2018-06-29 20:30:52 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:30:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:30:52 --> User Agent Class Initialized
INFO - 2018-06-29 20:30:52 --> Controller Class Initialized
INFO - 2018-06-29 20:30:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:30:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:30:52 --> Pixel_Model class loaded
INFO - 2018-06-29 20:30:52 --> Database Driver Class Initialized
INFO - 2018-06-29 20:30:52 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:30:52 --> Form Validation Class Initialized
INFO - 2018-06-29 20:30:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-29 20:30:52 --> Database Driver Class Initialized
INFO - 2018-06-29 20:30:52 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:30:52 --> Config Class Initialized
INFO - 2018-06-29 20:30:52 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:30:52 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:30:52 --> Utf8 Class Initialized
INFO - 2018-06-29 20:30:52 --> URI Class Initialized
INFO - 2018-06-29 20:30:52 --> Router Class Initialized
INFO - 2018-06-29 20:30:52 --> Output Class Initialized
INFO - 2018-06-29 20:30:52 --> Security Class Initialized
DEBUG - 2018-06-29 20:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:30:52 --> CSRF cookie sent
INFO - 2018-06-29 20:30:52 --> Input Class Initialized
INFO - 2018-06-29 20:30:52 --> Language Class Initialized
INFO - 2018-06-29 20:30:52 --> Loader Class Initialized
INFO - 2018-06-29 20:30:52 --> Helper loaded: url_helper
INFO - 2018-06-29 20:30:52 --> Helper loaded: form_helper
INFO - 2018-06-29 20:30:52 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:30:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:30:52 --> User Agent Class Initialized
INFO - 2018-06-29 20:30:52 --> Controller Class Initialized
INFO - 2018-06-29 20:30:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:30:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:30:52 --> Pixel_Model class loaded
INFO - 2018-06-29 20:30:52 --> Database Driver Class Initialized
INFO - 2018-06-29 20:30:52 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:30:52 --> Database Driver Class Initialized
INFO - 2018-06-29 20:30:52 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:30:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:30:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:30:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:30:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:30:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:30:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:30:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:30:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/has_addiction_problem.php
INFO - 2018-06-29 20:30:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:30:52 --> Final output sent to browser
DEBUG - 2018-06-29 20:30:52 --> Total execution time: 0.0419
INFO - 2018-06-29 20:30:58 --> Config Class Initialized
INFO - 2018-06-29 20:30:58 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:30:58 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:30:58 --> Utf8 Class Initialized
INFO - 2018-06-29 20:30:58 --> URI Class Initialized
INFO - 2018-06-29 20:30:58 --> Router Class Initialized
INFO - 2018-06-29 20:30:58 --> Output Class Initialized
INFO - 2018-06-29 20:30:58 --> Security Class Initialized
DEBUG - 2018-06-29 20:30:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:30:58 --> CSRF cookie sent
INFO - 2018-06-29 20:30:58 --> CSRF token verified
INFO - 2018-06-29 20:30:58 --> Input Class Initialized
INFO - 2018-06-29 20:30:58 --> Language Class Initialized
INFO - 2018-06-29 20:30:58 --> Loader Class Initialized
INFO - 2018-06-29 20:30:58 --> Helper loaded: url_helper
INFO - 2018-06-29 20:30:58 --> Helper loaded: form_helper
INFO - 2018-06-29 20:30:58 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:30:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:30:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:30:58 --> User Agent Class Initialized
INFO - 2018-06-29 20:30:58 --> Controller Class Initialized
INFO - 2018-06-29 20:30:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:30:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:30:58 --> Pixel_Model class loaded
INFO - 2018-06-29 20:30:58 --> Database Driver Class Initialized
INFO - 2018-06-29 20:30:58 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:30:58 --> Form Validation Class Initialized
INFO - 2018-06-29 20:30:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-29 20:30:58 --> Database Driver Class Initialized
INFO - 2018-06-29 20:30:58 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:30:58 --> Config Class Initialized
INFO - 2018-06-29 20:30:58 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:30:58 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:30:58 --> Utf8 Class Initialized
INFO - 2018-06-29 20:30:58 --> URI Class Initialized
INFO - 2018-06-29 20:30:58 --> Router Class Initialized
INFO - 2018-06-29 20:30:58 --> Output Class Initialized
INFO - 2018-06-29 20:30:58 --> Security Class Initialized
DEBUG - 2018-06-29 20:30:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:30:58 --> CSRF cookie sent
INFO - 2018-06-29 20:30:58 --> Input Class Initialized
INFO - 2018-06-29 20:30:58 --> Language Class Initialized
INFO - 2018-06-29 20:30:58 --> Loader Class Initialized
INFO - 2018-06-29 20:30:58 --> Helper loaded: url_helper
INFO - 2018-06-29 20:30:58 --> Helper loaded: form_helper
INFO - 2018-06-29 20:30:58 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:30:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:30:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:30:58 --> User Agent Class Initialized
INFO - 2018-06-29 20:30:58 --> Controller Class Initialized
INFO - 2018-06-29 20:30:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:30:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:30:58 --> Pixel_Model class loaded
INFO - 2018-06-29 20:30:58 --> Database Driver Class Initialized
INFO - 2018-06-29 20:30:58 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:30:58 --> Database Driver Class Initialized
INFO - 2018-06-29 20:30:58 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:30:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:30:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:30:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:30:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:30:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:30:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:30:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:30:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/have_hit_s.php
INFO - 2018-06-29 20:30:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:30:58 --> Final output sent to browser
DEBUG - 2018-06-29 20:30:58 --> Total execution time: 0.0387
INFO - 2018-06-29 20:31:07 --> Config Class Initialized
INFO - 2018-06-29 20:31:07 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:31:07 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:31:07 --> Utf8 Class Initialized
INFO - 2018-06-29 20:31:07 --> URI Class Initialized
INFO - 2018-06-29 20:31:07 --> Router Class Initialized
INFO - 2018-06-29 20:31:07 --> Output Class Initialized
INFO - 2018-06-29 20:31:07 --> Security Class Initialized
DEBUG - 2018-06-29 20:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:31:07 --> CSRF cookie sent
INFO - 2018-06-29 20:31:07 --> CSRF token verified
INFO - 2018-06-29 20:31:07 --> Input Class Initialized
INFO - 2018-06-29 20:31:07 --> Language Class Initialized
INFO - 2018-06-29 20:31:07 --> Loader Class Initialized
INFO - 2018-06-29 20:31:07 --> Helper loaded: url_helper
INFO - 2018-06-29 20:31:07 --> Helper loaded: form_helper
INFO - 2018-06-29 20:31:07 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:31:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:31:07 --> User Agent Class Initialized
INFO - 2018-06-29 20:31:07 --> Controller Class Initialized
INFO - 2018-06-29 20:31:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:31:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:31:07 --> Pixel_Model class loaded
INFO - 2018-06-29 20:31:08 --> Database Driver Class Initialized
INFO - 2018-06-29 20:31:08 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:31:08 --> Form Validation Class Initialized
INFO - 2018-06-29 20:31:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-29 20:31:08 --> Database Driver Class Initialized
INFO - 2018-06-29 20:31:08 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:31:08 --> Config Class Initialized
INFO - 2018-06-29 20:31:08 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:31:08 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:31:08 --> Utf8 Class Initialized
INFO - 2018-06-29 20:31:08 --> URI Class Initialized
INFO - 2018-06-29 20:31:08 --> Router Class Initialized
INFO - 2018-06-29 20:31:08 --> Output Class Initialized
INFO - 2018-06-29 20:31:08 --> Security Class Initialized
DEBUG - 2018-06-29 20:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:31:08 --> CSRF cookie sent
INFO - 2018-06-29 20:31:08 --> Input Class Initialized
INFO - 2018-06-29 20:31:08 --> Language Class Initialized
INFO - 2018-06-29 20:31:08 --> Loader Class Initialized
INFO - 2018-06-29 20:31:08 --> Helper loaded: url_helper
INFO - 2018-06-29 20:31:08 --> Helper loaded: form_helper
INFO - 2018-06-29 20:31:08 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:31:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:31:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:31:08 --> User Agent Class Initialized
INFO - 2018-06-29 20:31:08 --> Controller Class Initialized
INFO - 2018-06-29 20:31:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:31:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:31:08 --> Pixel_Model class loaded
INFO - 2018-06-29 20:31:08 --> Database Driver Class Initialized
INFO - 2018-06-29 20:31:08 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:31:08 --> Database Driver Class Initialized
INFO - 2018-06-29 20:31:08 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:31:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:31:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:31:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:31:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:31:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:31:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:31:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:31:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial_control.php
INFO - 2018-06-29 20:31:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:31:08 --> Final output sent to browser
DEBUG - 2018-06-29 20:31:08 --> Total execution time: 0.0384
INFO - 2018-06-29 20:31:13 --> Config Class Initialized
INFO - 2018-06-29 20:31:13 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:31:13 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:31:13 --> Utf8 Class Initialized
INFO - 2018-06-29 20:31:13 --> URI Class Initialized
INFO - 2018-06-29 20:31:13 --> Router Class Initialized
INFO - 2018-06-29 20:31:13 --> Output Class Initialized
INFO - 2018-06-29 20:31:13 --> Security Class Initialized
DEBUG - 2018-06-29 20:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:31:13 --> CSRF cookie sent
INFO - 2018-06-29 20:31:13 --> CSRF token verified
INFO - 2018-06-29 20:31:13 --> Input Class Initialized
INFO - 2018-06-29 20:31:13 --> Language Class Initialized
INFO - 2018-06-29 20:31:13 --> Loader Class Initialized
INFO - 2018-06-29 20:31:13 --> Helper loaded: url_helper
INFO - 2018-06-29 20:31:13 --> Helper loaded: form_helper
INFO - 2018-06-29 20:31:13 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:31:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:31:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:31:13 --> User Agent Class Initialized
INFO - 2018-06-29 20:31:13 --> Controller Class Initialized
INFO - 2018-06-29 20:31:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:31:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:31:13 --> Pixel_Model class loaded
INFO - 2018-06-29 20:31:13 --> Database Driver Class Initialized
INFO - 2018-06-29 20:31:13 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:31:13 --> Form Validation Class Initialized
INFO - 2018-06-29 20:31:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-29 20:31:13 --> Database Driver Class Initialized
INFO - 2018-06-29 20:31:13 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:31:13 --> Config Class Initialized
INFO - 2018-06-29 20:31:13 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:31:13 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:31:13 --> Utf8 Class Initialized
INFO - 2018-06-29 20:31:13 --> URI Class Initialized
INFO - 2018-06-29 20:31:13 --> Router Class Initialized
INFO - 2018-06-29 20:31:13 --> Output Class Initialized
INFO - 2018-06-29 20:31:13 --> Security Class Initialized
DEBUG - 2018-06-29 20:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:31:13 --> CSRF cookie sent
INFO - 2018-06-29 20:31:13 --> Input Class Initialized
INFO - 2018-06-29 20:31:13 --> Language Class Initialized
INFO - 2018-06-29 20:31:13 --> Loader Class Initialized
INFO - 2018-06-29 20:31:13 --> Helper loaded: url_helper
INFO - 2018-06-29 20:31:13 --> Helper loaded: form_helper
INFO - 2018-06-29 20:31:13 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:31:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:31:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:31:13 --> User Agent Class Initialized
INFO - 2018-06-29 20:31:13 --> Controller Class Initialized
INFO - 2018-06-29 20:31:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:31:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:31:13 --> Pixel_Model class loaded
INFO - 2018-06-29 20:31:13 --> Database Driver Class Initialized
INFO - 2018-06-29 20:31:13 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:31:13 --> Database Driver Class Initialized
INFO - 2018-06-29 20:31:13 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:31:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:31:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:31:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:31:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:31:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:31:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:31:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:31:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/has_hit_kids.php
INFO - 2018-06-29 20:31:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:31:13 --> Final output sent to browser
DEBUG - 2018-06-29 20:31:13 --> Total execution time: 0.0486
INFO - 2018-06-29 20:31:18 --> Config Class Initialized
INFO - 2018-06-29 20:31:18 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:31:18 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:31:18 --> Utf8 Class Initialized
INFO - 2018-06-29 20:31:18 --> URI Class Initialized
INFO - 2018-06-29 20:31:18 --> Router Class Initialized
INFO - 2018-06-29 20:31:18 --> Output Class Initialized
INFO - 2018-06-29 20:31:18 --> Security Class Initialized
DEBUG - 2018-06-29 20:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:31:18 --> CSRF cookie sent
INFO - 2018-06-29 20:31:18 --> CSRF token verified
INFO - 2018-06-29 20:31:18 --> Input Class Initialized
INFO - 2018-06-29 20:31:18 --> Language Class Initialized
INFO - 2018-06-29 20:31:18 --> Loader Class Initialized
INFO - 2018-06-29 20:31:18 --> Helper loaded: url_helper
INFO - 2018-06-29 20:31:18 --> Helper loaded: form_helper
INFO - 2018-06-29 20:31:18 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:31:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:31:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:31:18 --> User Agent Class Initialized
INFO - 2018-06-29 20:31:18 --> Controller Class Initialized
INFO - 2018-06-29 20:31:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:31:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:31:18 --> Pixel_Model class loaded
INFO - 2018-06-29 20:31:18 --> Database Driver Class Initialized
INFO - 2018-06-29 20:31:18 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:31:18 --> Form Validation Class Initialized
INFO - 2018-06-29 20:31:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-29 20:31:18 --> Database Driver Class Initialized
INFO - 2018-06-29 20:31:18 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:31:18 --> Config Class Initialized
INFO - 2018-06-29 20:31:18 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:31:18 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:31:18 --> Utf8 Class Initialized
INFO - 2018-06-29 20:31:18 --> URI Class Initialized
INFO - 2018-06-29 20:31:18 --> Router Class Initialized
INFO - 2018-06-29 20:31:18 --> Output Class Initialized
INFO - 2018-06-29 20:31:18 --> Security Class Initialized
DEBUG - 2018-06-29 20:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:31:18 --> CSRF cookie sent
INFO - 2018-06-29 20:31:18 --> Input Class Initialized
INFO - 2018-06-29 20:31:18 --> Language Class Initialized
INFO - 2018-06-29 20:31:18 --> Loader Class Initialized
INFO - 2018-06-29 20:31:18 --> Helper loaded: url_helper
INFO - 2018-06-29 20:31:18 --> Helper loaded: form_helper
INFO - 2018-06-29 20:31:18 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:31:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:31:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:31:18 --> User Agent Class Initialized
INFO - 2018-06-29 20:31:18 --> Controller Class Initialized
INFO - 2018-06-29 20:31:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:31:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:31:18 --> Pixel_Model class loaded
INFO - 2018-06-29 20:31:18 --> Database Driver Class Initialized
INFO - 2018-06-29 20:31:18 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:31:18 --> Database Driver Class Initialized
INFO - 2018-06-29 20:31:18 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:31:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:31:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:31:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:31:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:31:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:31:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:31:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:31:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/withheld_sex.php
INFO - 2018-06-29 20:31:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:31:18 --> Final output sent to browser
DEBUG - 2018-06-29 20:31:18 --> Total execution time: 0.0412
INFO - 2018-06-29 20:31:23 --> Config Class Initialized
INFO - 2018-06-29 20:31:23 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:31:23 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:31:23 --> Utf8 Class Initialized
INFO - 2018-06-29 20:31:23 --> URI Class Initialized
INFO - 2018-06-29 20:31:23 --> Router Class Initialized
INFO - 2018-06-29 20:31:23 --> Output Class Initialized
INFO - 2018-06-29 20:31:23 --> Security Class Initialized
DEBUG - 2018-06-29 20:31:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:31:23 --> CSRF cookie sent
INFO - 2018-06-29 20:31:23 --> CSRF token verified
INFO - 2018-06-29 20:31:23 --> Input Class Initialized
INFO - 2018-06-29 20:31:23 --> Language Class Initialized
INFO - 2018-06-29 20:31:23 --> Loader Class Initialized
INFO - 2018-06-29 20:31:23 --> Helper loaded: url_helper
INFO - 2018-06-29 20:31:23 --> Helper loaded: form_helper
INFO - 2018-06-29 20:31:23 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:31:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:31:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:31:23 --> User Agent Class Initialized
INFO - 2018-06-29 20:31:23 --> Controller Class Initialized
INFO - 2018-06-29 20:31:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:31:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:31:23 --> Pixel_Model class loaded
INFO - 2018-06-29 20:31:23 --> Database Driver Class Initialized
INFO - 2018-06-29 20:31:23 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:31:23 --> Form Validation Class Initialized
INFO - 2018-06-29 20:31:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-29 20:31:23 --> Database Driver Class Initialized
INFO - 2018-06-29 20:31:23 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:31:23 --> Config Class Initialized
INFO - 2018-06-29 20:31:23 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:31:23 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:31:23 --> Utf8 Class Initialized
INFO - 2018-06-29 20:31:23 --> URI Class Initialized
INFO - 2018-06-29 20:31:23 --> Router Class Initialized
INFO - 2018-06-29 20:31:23 --> Output Class Initialized
INFO - 2018-06-29 20:31:23 --> Security Class Initialized
DEBUG - 2018-06-29 20:31:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:31:23 --> CSRF cookie sent
INFO - 2018-06-29 20:31:23 --> Input Class Initialized
INFO - 2018-06-29 20:31:23 --> Language Class Initialized
INFO - 2018-06-29 20:31:23 --> Loader Class Initialized
INFO - 2018-06-29 20:31:23 --> Helper loaded: url_helper
INFO - 2018-06-29 20:31:23 --> Helper loaded: form_helper
INFO - 2018-06-29 20:31:23 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:31:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:31:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:31:23 --> User Agent Class Initialized
INFO - 2018-06-29 20:31:23 --> Controller Class Initialized
INFO - 2018-06-29 20:31:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:31:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:31:23 --> Pixel_Model class loaded
INFO - 2018-06-29 20:31:23 --> Database Driver Class Initialized
INFO - 2018-06-29 20:31:23 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:31:23 --> Database Driver Class Initialized
INFO - 2018-06-29 20:31:23 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:31:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:31:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:31:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:31:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:31:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:31:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:31:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:31:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pet_abuse.php
INFO - 2018-06-29 20:31:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:31:23 --> Final output sent to browser
DEBUG - 2018-06-29 20:31:23 --> Total execution time: 0.0421
INFO - 2018-06-29 20:31:28 --> Config Class Initialized
INFO - 2018-06-29 20:31:28 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:31:28 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:31:28 --> Utf8 Class Initialized
INFO - 2018-06-29 20:31:28 --> URI Class Initialized
INFO - 2018-06-29 20:31:28 --> Router Class Initialized
INFO - 2018-06-29 20:31:28 --> Output Class Initialized
INFO - 2018-06-29 20:31:28 --> Security Class Initialized
DEBUG - 2018-06-29 20:31:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:31:28 --> CSRF cookie sent
INFO - 2018-06-29 20:31:28 --> CSRF token verified
INFO - 2018-06-29 20:31:28 --> Input Class Initialized
INFO - 2018-06-29 20:31:28 --> Language Class Initialized
INFO - 2018-06-29 20:31:28 --> Loader Class Initialized
INFO - 2018-06-29 20:31:28 --> Helper loaded: url_helper
INFO - 2018-06-29 20:31:28 --> Helper loaded: form_helper
INFO - 2018-06-29 20:31:28 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:31:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:31:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:31:28 --> User Agent Class Initialized
INFO - 2018-06-29 20:31:28 --> Controller Class Initialized
INFO - 2018-06-29 20:31:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:31:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:31:28 --> Pixel_Model class loaded
INFO - 2018-06-29 20:31:28 --> Database Driver Class Initialized
INFO - 2018-06-29 20:31:28 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:31:28 --> Form Validation Class Initialized
INFO - 2018-06-29 20:31:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-29 20:31:28 --> Database Driver Class Initialized
INFO - 2018-06-29 20:31:28 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:31:28 --> Config Class Initialized
INFO - 2018-06-29 20:31:28 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:31:28 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:31:28 --> Utf8 Class Initialized
INFO - 2018-06-29 20:31:28 --> URI Class Initialized
INFO - 2018-06-29 20:31:28 --> Router Class Initialized
INFO - 2018-06-29 20:31:28 --> Output Class Initialized
INFO - 2018-06-29 20:31:28 --> Security Class Initialized
DEBUG - 2018-06-29 20:31:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:31:28 --> CSRF cookie sent
INFO - 2018-06-29 20:31:28 --> Input Class Initialized
INFO - 2018-06-29 20:31:28 --> Language Class Initialized
INFO - 2018-06-29 20:31:28 --> Loader Class Initialized
INFO - 2018-06-29 20:31:28 --> Helper loaded: url_helper
INFO - 2018-06-29 20:31:28 --> Helper loaded: form_helper
INFO - 2018-06-29 20:31:28 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:31:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:31:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:31:28 --> User Agent Class Initialized
INFO - 2018-06-29 20:31:28 --> Controller Class Initialized
INFO - 2018-06-29 20:31:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:31:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:31:28 --> Pixel_Model class loaded
INFO - 2018-06-29 20:31:28 --> Database Driver Class Initialized
INFO - 2018-06-29 20:31:28 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:31:28 --> Database Driver Class Initialized
INFO - 2018-06-29 20:31:28 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:31:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:31:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:31:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:31:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:31:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:31:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:31:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:31:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/has_dating_profile.php
INFO - 2018-06-29 20:31:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:31:28 --> Final output sent to browser
DEBUG - 2018-06-29 20:31:28 --> Total execution time: 0.0332
INFO - 2018-06-29 20:31:31 --> Config Class Initialized
INFO - 2018-06-29 20:31:31 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:31:31 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:31:31 --> Utf8 Class Initialized
INFO - 2018-06-29 20:31:31 --> URI Class Initialized
INFO - 2018-06-29 20:31:31 --> Router Class Initialized
INFO - 2018-06-29 20:31:31 --> Output Class Initialized
INFO - 2018-06-29 20:31:31 --> Security Class Initialized
DEBUG - 2018-06-29 20:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:31:31 --> CSRF cookie sent
INFO - 2018-06-29 20:31:31 --> Input Class Initialized
INFO - 2018-06-29 20:31:31 --> Language Class Initialized
INFO - 2018-06-29 20:31:31 --> Loader Class Initialized
INFO - 2018-06-29 20:31:31 --> Helper loaded: url_helper
INFO - 2018-06-29 20:31:31 --> Helper loaded: form_helper
INFO - 2018-06-29 20:31:31 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:31:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:31:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:31:31 --> User Agent Class Initialized
INFO - 2018-06-29 20:31:31 --> Controller Class Initialized
INFO - 2018-06-29 20:31:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:31:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:31:31 --> Pixel_Model class loaded
INFO - 2018-06-29 20:31:31 --> Database Driver Class Initialized
INFO - 2018-06-29 20:31:31 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:31:31 --> Database Driver Class Initialized
INFO - 2018-06-29 20:31:31 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:31:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:31:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:31:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:31:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:31:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:31:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:31:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:31:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/times_slept_couch.php
INFO - 2018-06-29 20:31:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:31:31 --> Final output sent to browser
DEBUG - 2018-06-29 20:31:31 --> Total execution time: 0.0450
INFO - 2018-06-29 20:31:34 --> Config Class Initialized
INFO - 2018-06-29 20:31:34 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:31:34 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:31:34 --> Utf8 Class Initialized
INFO - 2018-06-29 20:31:34 --> URI Class Initialized
INFO - 2018-06-29 20:31:34 --> Router Class Initialized
INFO - 2018-06-29 20:31:34 --> Output Class Initialized
INFO - 2018-06-29 20:31:34 --> Security Class Initialized
DEBUG - 2018-06-29 20:31:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:31:34 --> CSRF cookie sent
INFO - 2018-06-29 20:31:34 --> Input Class Initialized
INFO - 2018-06-29 20:31:34 --> Language Class Initialized
INFO - 2018-06-29 20:31:34 --> Loader Class Initialized
INFO - 2018-06-29 20:31:34 --> Helper loaded: url_helper
INFO - 2018-06-29 20:31:34 --> Helper loaded: form_helper
INFO - 2018-06-29 20:31:34 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:31:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:31:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:31:34 --> User Agent Class Initialized
INFO - 2018-06-29 20:31:34 --> Controller Class Initialized
INFO - 2018-06-29 20:31:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:31:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:31:34 --> Pixel_Model class loaded
INFO - 2018-06-29 20:31:34 --> Database Driver Class Initialized
INFO - 2018-06-29 20:31:34 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:31:34 --> Database Driver Class Initialized
INFO - 2018-06-29 20:31:34 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:31:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:31:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:31:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:31:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:31:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:31:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:31:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:31:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/has_relationship_outside.php
INFO - 2018-06-29 20:31:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:31:34 --> Final output sent to browser
DEBUG - 2018-06-29 20:31:34 --> Total execution time: 0.0453
INFO - 2018-06-29 20:31:36 --> Config Class Initialized
INFO - 2018-06-29 20:31:36 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:31:36 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:31:36 --> Utf8 Class Initialized
INFO - 2018-06-29 20:31:36 --> URI Class Initialized
INFO - 2018-06-29 20:31:36 --> Router Class Initialized
INFO - 2018-06-29 20:31:36 --> Output Class Initialized
INFO - 2018-06-29 20:31:36 --> Security Class Initialized
DEBUG - 2018-06-29 20:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:31:36 --> CSRF cookie sent
INFO - 2018-06-29 20:31:36 --> Input Class Initialized
INFO - 2018-06-29 20:31:36 --> Language Class Initialized
INFO - 2018-06-29 20:31:36 --> Loader Class Initialized
INFO - 2018-06-29 20:31:36 --> Helper loaded: url_helper
INFO - 2018-06-29 20:31:36 --> Helper loaded: form_helper
INFO - 2018-06-29 20:31:36 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:31:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:31:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:31:36 --> User Agent Class Initialized
INFO - 2018-06-29 20:31:36 --> Controller Class Initialized
INFO - 2018-06-29 20:31:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:31:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:31:36 --> Pixel_Model class loaded
INFO - 2018-06-29 20:31:36 --> Database Driver Class Initialized
INFO - 2018-06-29 20:31:36 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:31:36 --> Database Driver Class Initialized
INFO - 2018-06-29 20:31:36 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:31:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:31:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:31:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:31:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:31:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:31:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:31:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:31:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/liens_on_house.php
INFO - 2018-06-29 20:31:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:31:36 --> Final output sent to browser
DEBUG - 2018-06-29 20:31:36 --> Total execution time: 0.0402
INFO - 2018-06-29 20:31:37 --> Config Class Initialized
INFO - 2018-06-29 20:31:37 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:31:37 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:31:37 --> Utf8 Class Initialized
INFO - 2018-06-29 20:31:37 --> URI Class Initialized
INFO - 2018-06-29 20:31:37 --> Router Class Initialized
INFO - 2018-06-29 20:31:37 --> Output Class Initialized
INFO - 2018-06-29 20:31:37 --> Security Class Initialized
DEBUG - 2018-06-29 20:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:31:37 --> CSRF cookie sent
INFO - 2018-06-29 20:31:37 --> Input Class Initialized
INFO - 2018-06-29 20:31:37 --> Language Class Initialized
INFO - 2018-06-29 20:31:37 --> Loader Class Initialized
INFO - 2018-06-29 20:31:37 --> Helper loaded: url_helper
INFO - 2018-06-29 20:31:37 --> Helper loaded: form_helper
INFO - 2018-06-29 20:31:37 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:31:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:31:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:31:37 --> User Agent Class Initialized
INFO - 2018-06-29 20:31:37 --> Controller Class Initialized
INFO - 2018-06-29 20:31:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:31:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:31:37 --> Pixel_Model class loaded
INFO - 2018-06-29 20:31:37 --> Database Driver Class Initialized
INFO - 2018-06-29 20:31:37 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:31:37 --> Database Driver Class Initialized
INFO - 2018-06-29 20:31:37 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:31:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:31:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:31:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:31:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:31:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:31:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:31:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:31:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/have_loan_money.php
INFO - 2018-06-29 20:31:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:31:37 --> Final output sent to browser
DEBUG - 2018-06-29 20:31:37 --> Total execution time: 0.0389
INFO - 2018-06-29 20:31:38 --> Config Class Initialized
INFO - 2018-06-29 20:31:38 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:31:38 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:31:38 --> Utf8 Class Initialized
INFO - 2018-06-29 20:31:38 --> URI Class Initialized
INFO - 2018-06-29 20:31:38 --> Router Class Initialized
INFO - 2018-06-29 20:31:38 --> Output Class Initialized
INFO - 2018-06-29 20:31:38 --> Security Class Initialized
DEBUG - 2018-06-29 20:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:31:38 --> CSRF cookie sent
INFO - 2018-06-29 20:31:38 --> Input Class Initialized
INFO - 2018-06-29 20:31:38 --> Language Class Initialized
INFO - 2018-06-29 20:31:38 --> Loader Class Initialized
INFO - 2018-06-29 20:31:38 --> Helper loaded: url_helper
INFO - 2018-06-29 20:31:38 --> Helper loaded: form_helper
INFO - 2018-06-29 20:31:38 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:31:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:31:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:31:38 --> User Agent Class Initialized
INFO - 2018-06-29 20:31:38 --> Controller Class Initialized
INFO - 2018-06-29 20:31:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:31:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:31:38 --> Pixel_Model class loaded
INFO - 2018-06-29 20:31:38 --> Database Driver Class Initialized
INFO - 2018-06-29 20:31:38 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:31:38 --> Database Driver Class Initialized
INFO - 2018-06-29 20:31:38 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:31:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:31:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:31:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:31:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:31:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:31:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:31:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:31:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/ethnic_background.php
INFO - 2018-06-29 20:31:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:31:38 --> Final output sent to browser
DEBUG - 2018-06-29 20:31:38 --> Total execution time: 0.0394
INFO - 2018-06-29 20:31:41 --> Config Class Initialized
INFO - 2018-06-29 20:31:41 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:31:41 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:31:41 --> Utf8 Class Initialized
INFO - 2018-06-29 20:31:41 --> URI Class Initialized
INFO - 2018-06-29 20:31:41 --> Router Class Initialized
INFO - 2018-06-29 20:31:41 --> Output Class Initialized
INFO - 2018-06-29 20:31:41 --> Security Class Initialized
DEBUG - 2018-06-29 20:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:31:41 --> CSRF cookie sent
INFO - 2018-06-29 20:31:41 --> Input Class Initialized
INFO - 2018-06-29 20:31:41 --> Language Class Initialized
INFO - 2018-06-29 20:31:41 --> Loader Class Initialized
INFO - 2018-06-29 20:31:41 --> Helper loaded: url_helper
INFO - 2018-06-29 20:31:41 --> Helper loaded: form_helper
INFO - 2018-06-29 20:31:41 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:31:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:31:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:31:41 --> User Agent Class Initialized
INFO - 2018-06-29 20:31:41 --> Controller Class Initialized
INFO - 2018-06-29 20:31:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:31:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:31:41 --> Pixel_Model class loaded
INFO - 2018-06-29 20:31:41 --> Database Driver Class Initialized
INFO - 2018-06-29 20:31:41 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:31:41 --> Database Driver Class Initialized
INFO - 2018-06-29 20:31:41 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:31:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:31:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:31:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:31:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:31:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:31:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:31:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:31:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/have_loan_money.php
INFO - 2018-06-29 20:31:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:31:41 --> Final output sent to browser
DEBUG - 2018-06-29 20:31:41 --> Total execution time: 0.0538
INFO - 2018-06-29 20:31:42 --> Config Class Initialized
INFO - 2018-06-29 20:31:42 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:31:42 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:31:42 --> Utf8 Class Initialized
INFO - 2018-06-29 20:31:42 --> URI Class Initialized
INFO - 2018-06-29 20:31:42 --> Router Class Initialized
INFO - 2018-06-29 20:31:42 --> Output Class Initialized
INFO - 2018-06-29 20:31:42 --> Security Class Initialized
DEBUG - 2018-06-29 20:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:31:42 --> CSRF cookie sent
INFO - 2018-06-29 20:31:42 --> Input Class Initialized
INFO - 2018-06-29 20:31:42 --> Language Class Initialized
INFO - 2018-06-29 20:31:42 --> Loader Class Initialized
INFO - 2018-06-29 20:31:42 --> Helper loaded: url_helper
INFO - 2018-06-29 20:31:42 --> Helper loaded: form_helper
INFO - 2018-06-29 20:31:42 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:31:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:31:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:31:42 --> User Agent Class Initialized
INFO - 2018-06-29 20:31:42 --> Controller Class Initialized
INFO - 2018-06-29 20:31:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:31:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:31:42 --> Pixel_Model class loaded
INFO - 2018-06-29 20:31:42 --> Database Driver Class Initialized
INFO - 2018-06-29 20:31:42 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:31:42 --> Database Driver Class Initialized
INFO - 2018-06-29 20:31:42 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:31:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:31:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:31:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:31:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:31:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:31:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:31:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:31:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/liens_on_house.php
INFO - 2018-06-29 20:31:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:31:42 --> Final output sent to browser
DEBUG - 2018-06-29 20:31:42 --> Total execution time: 0.0398
INFO - 2018-06-29 20:31:43 --> Config Class Initialized
INFO - 2018-06-29 20:31:43 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:31:43 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:31:43 --> Utf8 Class Initialized
INFO - 2018-06-29 20:31:43 --> URI Class Initialized
INFO - 2018-06-29 20:31:43 --> Router Class Initialized
INFO - 2018-06-29 20:31:43 --> Output Class Initialized
INFO - 2018-06-29 20:31:43 --> Security Class Initialized
DEBUG - 2018-06-29 20:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:31:43 --> CSRF cookie sent
INFO - 2018-06-29 20:31:43 --> Input Class Initialized
INFO - 2018-06-29 20:31:43 --> Language Class Initialized
INFO - 2018-06-29 20:31:43 --> Loader Class Initialized
INFO - 2018-06-29 20:31:43 --> Helper loaded: url_helper
INFO - 2018-06-29 20:31:43 --> Helper loaded: form_helper
INFO - 2018-06-29 20:31:43 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:31:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:31:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:31:43 --> User Agent Class Initialized
INFO - 2018-06-29 20:31:43 --> Controller Class Initialized
INFO - 2018-06-29 20:31:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:31:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:31:43 --> Pixel_Model class loaded
INFO - 2018-06-29 20:31:43 --> Database Driver Class Initialized
INFO - 2018-06-29 20:31:43 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:31:43 --> Database Driver Class Initialized
INFO - 2018-06-29 20:31:43 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:31:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:31:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:31:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:31:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:31:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:31:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:31:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:31:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/has_relationship_outside.php
INFO - 2018-06-29 20:31:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:31:43 --> Final output sent to browser
DEBUG - 2018-06-29 20:31:43 --> Total execution time: 0.0461
INFO - 2018-06-29 20:31:47 --> Config Class Initialized
INFO - 2018-06-29 20:31:47 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:31:47 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:31:47 --> Utf8 Class Initialized
INFO - 2018-06-29 20:31:47 --> URI Class Initialized
INFO - 2018-06-29 20:31:47 --> Router Class Initialized
INFO - 2018-06-29 20:31:47 --> Output Class Initialized
INFO - 2018-06-29 20:31:47 --> Security Class Initialized
DEBUG - 2018-06-29 20:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:31:47 --> CSRF cookie sent
INFO - 2018-06-29 20:31:47 --> Input Class Initialized
INFO - 2018-06-29 20:31:47 --> Language Class Initialized
INFO - 2018-06-29 20:31:47 --> Loader Class Initialized
INFO - 2018-06-29 20:31:47 --> Helper loaded: url_helper
INFO - 2018-06-29 20:31:47 --> Helper loaded: form_helper
INFO - 2018-06-29 20:31:47 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:31:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:31:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:31:47 --> User Agent Class Initialized
INFO - 2018-06-29 20:31:47 --> Controller Class Initialized
INFO - 2018-06-29 20:31:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:31:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:31:47 --> Pixel_Model class loaded
INFO - 2018-06-29 20:31:47 --> Database Driver Class Initialized
INFO - 2018-06-29 20:31:47 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:31:47 --> Database Driver Class Initialized
INFO - 2018-06-29 20:31:47 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:31:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:31:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:31:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:31:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:31:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:31:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:31:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:31:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/liens_on_house.php
INFO - 2018-06-29 20:31:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:31:47 --> Final output sent to browser
DEBUG - 2018-06-29 20:31:47 --> Total execution time: 0.0617
INFO - 2018-06-29 20:31:48 --> Config Class Initialized
INFO - 2018-06-29 20:31:48 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:31:48 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:31:48 --> Utf8 Class Initialized
INFO - 2018-06-29 20:31:48 --> URI Class Initialized
INFO - 2018-06-29 20:31:48 --> Router Class Initialized
INFO - 2018-06-29 20:31:48 --> Output Class Initialized
INFO - 2018-06-29 20:31:48 --> Security Class Initialized
DEBUG - 2018-06-29 20:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:31:48 --> CSRF cookie sent
INFO - 2018-06-29 20:31:48 --> Input Class Initialized
INFO - 2018-06-29 20:31:48 --> Language Class Initialized
INFO - 2018-06-29 20:31:48 --> Loader Class Initialized
INFO - 2018-06-29 20:31:48 --> Helper loaded: url_helper
INFO - 2018-06-29 20:31:48 --> Helper loaded: form_helper
INFO - 2018-06-29 20:31:48 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:31:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:31:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:31:48 --> User Agent Class Initialized
INFO - 2018-06-29 20:31:48 --> Controller Class Initialized
INFO - 2018-06-29 20:31:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:31:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:31:48 --> Pixel_Model class loaded
INFO - 2018-06-29 20:31:48 --> Database Driver Class Initialized
INFO - 2018-06-29 20:31:48 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:31:48 --> Database Driver Class Initialized
INFO - 2018-06-29 20:31:48 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:31:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:31:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:31:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:31:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:31:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:31:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:31:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:31:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/have_loan_money.php
INFO - 2018-06-29 20:31:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:31:48 --> Final output sent to browser
DEBUG - 2018-06-29 20:31:48 --> Total execution time: 0.0415
INFO - 2018-06-29 20:31:49 --> Config Class Initialized
INFO - 2018-06-29 20:31:49 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:31:49 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:31:49 --> Utf8 Class Initialized
INFO - 2018-06-29 20:31:49 --> URI Class Initialized
INFO - 2018-06-29 20:31:49 --> Router Class Initialized
INFO - 2018-06-29 20:31:49 --> Output Class Initialized
INFO - 2018-06-29 20:31:49 --> Security Class Initialized
DEBUG - 2018-06-29 20:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:31:49 --> CSRF cookie sent
INFO - 2018-06-29 20:31:49 --> Input Class Initialized
INFO - 2018-06-29 20:31:49 --> Language Class Initialized
INFO - 2018-06-29 20:31:49 --> Loader Class Initialized
INFO - 2018-06-29 20:31:49 --> Helper loaded: url_helper
INFO - 2018-06-29 20:31:49 --> Helper loaded: form_helper
INFO - 2018-06-29 20:31:49 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:31:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:31:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:31:49 --> User Agent Class Initialized
INFO - 2018-06-29 20:31:49 --> Controller Class Initialized
INFO - 2018-06-29 20:31:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:31:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:31:49 --> Pixel_Model class loaded
INFO - 2018-06-29 20:31:49 --> Database Driver Class Initialized
INFO - 2018-06-29 20:31:49 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:31:49 --> Database Driver Class Initialized
INFO - 2018-06-29 20:31:49 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:31:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:31:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:31:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:31:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:31:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:31:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:31:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:31:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/ethnic_background.php
INFO - 2018-06-29 20:31:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:31:49 --> Final output sent to browser
DEBUG - 2018-06-29 20:31:49 --> Total execution time: 0.0420
INFO - 2018-06-29 20:31:51 --> Config Class Initialized
INFO - 2018-06-29 20:31:51 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:31:51 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:31:51 --> Utf8 Class Initialized
INFO - 2018-06-29 20:31:51 --> URI Class Initialized
INFO - 2018-06-29 20:31:51 --> Router Class Initialized
INFO - 2018-06-29 20:31:51 --> Output Class Initialized
INFO - 2018-06-29 20:31:51 --> Security Class Initialized
DEBUG - 2018-06-29 20:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:31:51 --> CSRF cookie sent
INFO - 2018-06-29 20:31:51 --> Input Class Initialized
INFO - 2018-06-29 20:31:51 --> Language Class Initialized
INFO - 2018-06-29 20:31:51 --> Loader Class Initialized
INFO - 2018-06-29 20:31:51 --> Helper loaded: url_helper
INFO - 2018-06-29 20:31:51 --> Helper loaded: form_helper
INFO - 2018-06-29 20:31:51 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:31:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:31:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:31:51 --> User Agent Class Initialized
INFO - 2018-06-29 20:31:51 --> Controller Class Initialized
INFO - 2018-06-29 20:31:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:31:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:31:51 --> Pixel_Model class loaded
INFO - 2018-06-29 20:31:51 --> Database Driver Class Initialized
INFO - 2018-06-29 20:31:51 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:31:51 --> Database Driver Class Initialized
INFO - 2018-06-29 20:31:51 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:31:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:31:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:31:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:31:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:31:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:31:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:31:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:31:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/assets_info.php
INFO - 2018-06-29 20:31:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:31:51 --> Final output sent to browser
DEBUG - 2018-06-29 20:31:51 --> Total execution time: 0.0513
INFO - 2018-06-29 20:31:56 --> Config Class Initialized
INFO - 2018-06-29 20:31:56 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:31:56 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:31:56 --> Utf8 Class Initialized
INFO - 2018-06-29 20:31:56 --> URI Class Initialized
INFO - 2018-06-29 20:31:56 --> Router Class Initialized
INFO - 2018-06-29 20:31:56 --> Output Class Initialized
INFO - 2018-06-29 20:31:56 --> Security Class Initialized
DEBUG - 2018-06-29 20:31:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:31:56 --> CSRF cookie sent
INFO - 2018-06-29 20:31:56 --> CSRF token verified
INFO - 2018-06-29 20:31:56 --> Input Class Initialized
INFO - 2018-06-29 20:31:56 --> Language Class Initialized
INFO - 2018-06-29 20:31:56 --> Loader Class Initialized
INFO - 2018-06-29 20:31:56 --> Helper loaded: url_helper
INFO - 2018-06-29 20:31:56 --> Helper loaded: form_helper
INFO - 2018-06-29 20:31:56 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:31:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:31:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:31:56 --> User Agent Class Initialized
INFO - 2018-06-29 20:31:56 --> Controller Class Initialized
INFO - 2018-06-29 20:31:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:31:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:31:56 --> Pixel_Model class loaded
INFO - 2018-06-29 20:31:56 --> Database Driver Class Initialized
INFO - 2018-06-29 20:31:56 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:31:56 --> Form Validation Class Initialized
INFO - 2018-06-29 20:31:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-29 20:31:56 --> Database Driver Class Initialized
INFO - 2018-06-29 20:31:56 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:31:56 --> Config Class Initialized
INFO - 2018-06-29 20:31:56 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:31:56 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:31:56 --> Utf8 Class Initialized
INFO - 2018-06-29 20:31:56 --> URI Class Initialized
INFO - 2018-06-29 20:31:56 --> Router Class Initialized
INFO - 2018-06-29 20:31:56 --> Output Class Initialized
INFO - 2018-06-29 20:31:56 --> Security Class Initialized
DEBUG - 2018-06-29 20:31:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:31:56 --> CSRF cookie sent
INFO - 2018-06-29 20:31:56 --> Input Class Initialized
INFO - 2018-06-29 20:31:56 --> Language Class Initialized
INFO - 2018-06-29 20:31:56 --> Loader Class Initialized
INFO - 2018-06-29 20:31:56 --> Helper loaded: url_helper
INFO - 2018-06-29 20:31:56 --> Helper loaded: form_helper
INFO - 2018-06-29 20:31:56 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:31:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:31:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:31:56 --> User Agent Class Initialized
INFO - 2018-06-29 20:31:56 --> Controller Class Initialized
INFO - 2018-06-29 20:31:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:31:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:31:56 --> Pixel_Model class loaded
INFO - 2018-06-29 20:31:56 --> Database Driver Class Initialized
INFO - 2018-06-29 20:31:56 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:31:56 --> Database Driver Class Initialized
INFO - 2018-06-29 20:31:56 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:31:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:31:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:31:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:31:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:31:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:31:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:31:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:31:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/assets_details.php
INFO - 2018-06-29 20:31:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:31:56 --> Final output sent to browser
DEBUG - 2018-06-29 20:31:56 --> Total execution time: 0.0462
INFO - 2018-06-29 20:32:09 --> Config Class Initialized
INFO - 2018-06-29 20:32:09 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:32:09 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:32:09 --> Utf8 Class Initialized
INFO - 2018-06-29 20:32:09 --> URI Class Initialized
INFO - 2018-06-29 20:32:09 --> Router Class Initialized
INFO - 2018-06-29 20:32:09 --> Output Class Initialized
INFO - 2018-06-29 20:32:09 --> Security Class Initialized
DEBUG - 2018-06-29 20:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:32:09 --> CSRF cookie sent
INFO - 2018-06-29 20:32:09 --> CSRF token verified
INFO - 2018-06-29 20:32:09 --> Input Class Initialized
INFO - 2018-06-29 20:32:09 --> Language Class Initialized
INFO - 2018-06-29 20:32:09 --> Loader Class Initialized
INFO - 2018-06-29 20:32:09 --> Helper loaded: url_helper
INFO - 2018-06-29 20:32:09 --> Helper loaded: form_helper
INFO - 2018-06-29 20:32:09 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:32:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:32:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:32:09 --> User Agent Class Initialized
INFO - 2018-06-29 20:32:09 --> Controller Class Initialized
INFO - 2018-06-29 20:32:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:32:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:32:09 --> Pixel_Model class loaded
INFO - 2018-06-29 20:32:09 --> Database Driver Class Initialized
INFO - 2018-06-29 20:32:09 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:32:09 --> Form Validation Class Initialized
INFO - 2018-06-29 20:32:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-29 20:32:09 --> Database Driver Class Initialized
INFO - 2018-06-29 20:32:09 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:32:09 --> Config Class Initialized
INFO - 2018-06-29 20:32:09 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:32:09 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:32:09 --> Utf8 Class Initialized
INFO - 2018-06-29 20:32:09 --> URI Class Initialized
INFO - 2018-06-29 20:32:09 --> Router Class Initialized
INFO - 2018-06-29 20:32:09 --> Output Class Initialized
INFO - 2018-06-29 20:32:09 --> Security Class Initialized
DEBUG - 2018-06-29 20:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:32:09 --> CSRF cookie sent
INFO - 2018-06-29 20:32:09 --> Input Class Initialized
INFO - 2018-06-29 20:32:09 --> Language Class Initialized
INFO - 2018-06-29 20:32:09 --> Loader Class Initialized
INFO - 2018-06-29 20:32:09 --> Helper loaded: url_helper
INFO - 2018-06-29 20:32:09 --> Helper loaded: form_helper
INFO - 2018-06-29 20:32:09 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:32:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:32:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:32:09 --> User Agent Class Initialized
INFO - 2018-06-29 20:32:09 --> Controller Class Initialized
INFO - 2018-06-29 20:32:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:32:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:32:09 --> Pixel_Model class loaded
INFO - 2018-06-29 20:32:09 --> Database Driver Class Initialized
INFO - 2018-06-29 20:32:09 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:32:09 --> Database Driver Class Initialized
INFO - 2018-06-29 20:32:09 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:32:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:32:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:32:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:32:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:32:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:32:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:32:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:32:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/gifts_info.php
INFO - 2018-06-29 20:32:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:32:09 --> Final output sent to browser
DEBUG - 2018-06-29 20:32:09 --> Total execution time: 0.0521
INFO - 2018-06-29 20:32:12 --> Config Class Initialized
INFO - 2018-06-29 20:32:12 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:32:12 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:32:12 --> Utf8 Class Initialized
INFO - 2018-06-29 20:32:12 --> URI Class Initialized
INFO - 2018-06-29 20:32:12 --> Router Class Initialized
INFO - 2018-06-29 20:32:12 --> Output Class Initialized
INFO - 2018-06-29 20:32:12 --> Security Class Initialized
DEBUG - 2018-06-29 20:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:32:12 --> CSRF cookie sent
INFO - 2018-06-29 20:32:12 --> CSRF token verified
INFO - 2018-06-29 20:32:12 --> Input Class Initialized
INFO - 2018-06-29 20:32:12 --> Language Class Initialized
INFO - 2018-06-29 20:32:12 --> Loader Class Initialized
INFO - 2018-06-29 20:32:12 --> Helper loaded: url_helper
INFO - 2018-06-29 20:32:12 --> Helper loaded: form_helper
INFO - 2018-06-29 20:32:12 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:32:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:32:12 --> User Agent Class Initialized
INFO - 2018-06-29 20:32:12 --> Controller Class Initialized
INFO - 2018-06-29 20:32:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:32:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:32:12 --> Pixel_Model class loaded
INFO - 2018-06-29 20:32:12 --> Database Driver Class Initialized
INFO - 2018-06-29 20:32:12 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:32:12 --> Form Validation Class Initialized
INFO - 2018-06-29 20:32:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-29 20:32:12 --> Database Driver Class Initialized
INFO - 2018-06-29 20:32:12 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:32:12 --> Config Class Initialized
INFO - 2018-06-29 20:32:12 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:32:13 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:32:13 --> Utf8 Class Initialized
INFO - 2018-06-29 20:32:13 --> URI Class Initialized
INFO - 2018-06-29 20:32:13 --> Router Class Initialized
INFO - 2018-06-29 20:32:13 --> Output Class Initialized
INFO - 2018-06-29 20:32:13 --> Security Class Initialized
DEBUG - 2018-06-29 20:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:32:13 --> CSRF cookie sent
INFO - 2018-06-29 20:32:13 --> Input Class Initialized
INFO - 2018-06-29 20:32:13 --> Language Class Initialized
INFO - 2018-06-29 20:32:13 --> Loader Class Initialized
INFO - 2018-06-29 20:32:13 --> Helper loaded: url_helper
INFO - 2018-06-29 20:32:13 --> Helper loaded: form_helper
INFO - 2018-06-29 20:32:13 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:32:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:32:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:32:13 --> User Agent Class Initialized
INFO - 2018-06-29 20:32:13 --> Controller Class Initialized
INFO - 2018-06-29 20:32:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:32:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:32:13 --> Pixel_Model class loaded
INFO - 2018-06-29 20:32:13 --> Database Driver Class Initialized
INFO - 2018-06-29 20:32:13 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:32:13 --> Database Driver Class Initialized
INFO - 2018-06-29 20:32:13 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:32:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:32:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:32:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:32:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:32:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:32:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:32:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:32:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/gift_details.php
INFO - 2018-06-29 20:32:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:32:13 --> Final output sent to browser
DEBUG - 2018-06-29 20:32:13 --> Total execution time: 0.0497
INFO - 2018-06-29 20:32:20 --> Config Class Initialized
INFO - 2018-06-29 20:32:20 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:32:20 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:32:20 --> Utf8 Class Initialized
INFO - 2018-06-29 20:32:20 --> URI Class Initialized
INFO - 2018-06-29 20:32:20 --> Router Class Initialized
INFO - 2018-06-29 20:32:20 --> Output Class Initialized
INFO - 2018-06-29 20:32:20 --> Security Class Initialized
DEBUG - 2018-06-29 20:32:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:32:20 --> CSRF cookie sent
INFO - 2018-06-29 20:32:20 --> CSRF token verified
INFO - 2018-06-29 20:32:20 --> Input Class Initialized
INFO - 2018-06-29 20:32:20 --> Language Class Initialized
INFO - 2018-06-29 20:32:20 --> Loader Class Initialized
INFO - 2018-06-29 20:32:20 --> Helper loaded: url_helper
INFO - 2018-06-29 20:32:20 --> Helper loaded: form_helper
INFO - 2018-06-29 20:32:20 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:32:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:32:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:32:20 --> User Agent Class Initialized
INFO - 2018-06-29 20:32:20 --> Controller Class Initialized
INFO - 2018-06-29 20:32:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:32:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:32:20 --> Pixel_Model class loaded
INFO - 2018-06-29 20:32:20 --> Database Driver Class Initialized
INFO - 2018-06-29 20:32:20 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:32:20 --> Form Validation Class Initialized
INFO - 2018-06-29 20:32:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-29 20:32:20 --> Database Driver Class Initialized
INFO - 2018-06-29 20:32:20 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:32:20 --> Config Class Initialized
INFO - 2018-06-29 20:32:20 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:32:20 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:32:20 --> Utf8 Class Initialized
INFO - 2018-06-29 20:32:20 --> URI Class Initialized
INFO - 2018-06-29 20:32:20 --> Router Class Initialized
INFO - 2018-06-29 20:32:20 --> Output Class Initialized
INFO - 2018-06-29 20:32:20 --> Security Class Initialized
DEBUG - 2018-06-29 20:32:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:32:20 --> CSRF cookie sent
INFO - 2018-06-29 20:32:20 --> Input Class Initialized
INFO - 2018-06-29 20:32:20 --> Language Class Initialized
INFO - 2018-06-29 20:32:20 --> Loader Class Initialized
INFO - 2018-06-29 20:32:20 --> Helper loaded: url_helper
INFO - 2018-06-29 20:32:20 --> Helper loaded: form_helper
INFO - 2018-06-29 20:32:20 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:32:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:32:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:32:20 --> User Agent Class Initialized
INFO - 2018-06-29 20:32:20 --> Controller Class Initialized
INFO - 2018-06-29 20:32:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:32:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:32:20 --> Pixel_Model class loaded
INFO - 2018-06-29 20:32:20 --> Database Driver Class Initialized
INFO - 2018-06-29 20:32:20 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:32:20 --> Database Driver Class Initialized
INFO - 2018-06-29 20:32:20 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:32:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:32:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:32:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:32:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:32:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:32:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:32:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:32:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/automobile.php
INFO - 2018-06-29 20:32:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:32:20 --> Final output sent to browser
DEBUG - 2018-06-29 20:32:20 --> Total execution time: 0.0419
INFO - 2018-06-29 20:32:30 --> Config Class Initialized
INFO - 2018-06-29 20:32:30 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:32:30 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:32:30 --> Utf8 Class Initialized
INFO - 2018-06-29 20:32:30 --> URI Class Initialized
INFO - 2018-06-29 20:32:30 --> Router Class Initialized
INFO - 2018-06-29 20:32:30 --> Output Class Initialized
INFO - 2018-06-29 20:32:30 --> Security Class Initialized
DEBUG - 2018-06-29 20:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:32:30 --> CSRF cookie sent
INFO - 2018-06-29 20:32:30 --> CSRF token verified
INFO - 2018-06-29 20:32:30 --> Input Class Initialized
INFO - 2018-06-29 20:32:30 --> Language Class Initialized
INFO - 2018-06-29 20:32:30 --> Loader Class Initialized
INFO - 2018-06-29 20:32:30 --> Helper loaded: url_helper
INFO - 2018-06-29 20:32:30 --> Helper loaded: form_helper
INFO - 2018-06-29 20:32:30 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:32:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:32:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:32:30 --> User Agent Class Initialized
INFO - 2018-06-29 20:32:30 --> Controller Class Initialized
INFO - 2018-06-29 20:32:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:32:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:32:30 --> Pixel_Model class loaded
INFO - 2018-06-29 20:32:30 --> Database Driver Class Initialized
INFO - 2018-06-29 20:32:30 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:32:30 --> Form Validation Class Initialized
INFO - 2018-06-29 20:32:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-29 20:32:30 --> Database Driver Class Initialized
INFO - 2018-06-29 20:32:30 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:32:30 --> Config Class Initialized
INFO - 2018-06-29 20:32:30 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:32:30 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:32:30 --> Utf8 Class Initialized
INFO - 2018-06-29 20:32:30 --> URI Class Initialized
INFO - 2018-06-29 20:32:30 --> Router Class Initialized
INFO - 2018-06-29 20:32:30 --> Output Class Initialized
INFO - 2018-06-29 20:32:30 --> Security Class Initialized
DEBUG - 2018-06-29 20:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:32:30 --> CSRF cookie sent
INFO - 2018-06-29 20:32:30 --> Input Class Initialized
INFO - 2018-06-29 20:32:30 --> Language Class Initialized
INFO - 2018-06-29 20:32:30 --> Loader Class Initialized
INFO - 2018-06-29 20:32:30 --> Helper loaded: url_helper
INFO - 2018-06-29 20:32:30 --> Helper loaded: form_helper
INFO - 2018-06-29 20:32:30 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:32:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:32:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:32:30 --> User Agent Class Initialized
INFO - 2018-06-29 20:32:30 --> Controller Class Initialized
INFO - 2018-06-29 20:32:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:32:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:32:30 --> Pixel_Model class loaded
INFO - 2018-06-29 20:32:30 --> Database Driver Class Initialized
INFO - 2018-06-29 20:32:30 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:32:30 --> Database Driver Class Initialized
INFO - 2018-06-29 20:32:30 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:32:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:32:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:32:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:32:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:32:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:32:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:32:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:32:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/other_autos.php
INFO - 2018-06-29 20:32:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:32:30 --> Final output sent to browser
DEBUG - 2018-06-29 20:32:30 --> Total execution time: 0.0507
INFO - 2018-06-29 20:32:33 --> Config Class Initialized
INFO - 2018-06-29 20:32:33 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:32:33 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:32:33 --> Utf8 Class Initialized
INFO - 2018-06-29 20:32:33 --> URI Class Initialized
INFO - 2018-06-29 20:32:33 --> Router Class Initialized
INFO - 2018-06-29 20:32:33 --> Output Class Initialized
INFO - 2018-06-29 20:32:33 --> Security Class Initialized
DEBUG - 2018-06-29 20:32:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:32:33 --> CSRF cookie sent
INFO - 2018-06-29 20:32:33 --> Input Class Initialized
INFO - 2018-06-29 20:32:33 --> Language Class Initialized
INFO - 2018-06-29 20:32:33 --> Loader Class Initialized
INFO - 2018-06-29 20:32:33 --> Helper loaded: url_helper
INFO - 2018-06-29 20:32:33 --> Helper loaded: form_helper
INFO - 2018-06-29 20:32:33 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:32:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:32:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:32:33 --> User Agent Class Initialized
INFO - 2018-06-29 20:32:33 --> Controller Class Initialized
INFO - 2018-06-29 20:32:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:32:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:32:33 --> Pixel_Model class loaded
INFO - 2018-06-29 20:32:33 --> Database Driver Class Initialized
INFO - 2018-06-29 20:32:33 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:32:33 --> Database Driver Class Initialized
INFO - 2018-06-29 20:32:33 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:32:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:32:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:32:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:32:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:32:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:32:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:32:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:32:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/collectables.php
INFO - 2018-06-29 20:32:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:32:33 --> Final output sent to browser
DEBUG - 2018-06-29 20:32:33 --> Total execution time: 0.0452
INFO - 2018-06-29 20:32:35 --> Config Class Initialized
INFO - 2018-06-29 20:32:35 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:32:35 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:32:35 --> Utf8 Class Initialized
INFO - 2018-06-29 20:32:35 --> URI Class Initialized
INFO - 2018-06-29 20:32:35 --> Router Class Initialized
INFO - 2018-06-29 20:32:35 --> Output Class Initialized
INFO - 2018-06-29 20:32:35 --> Security Class Initialized
DEBUG - 2018-06-29 20:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:32:35 --> CSRF cookie sent
INFO - 2018-06-29 20:32:35 --> Input Class Initialized
INFO - 2018-06-29 20:32:35 --> Language Class Initialized
INFO - 2018-06-29 20:32:35 --> Loader Class Initialized
INFO - 2018-06-29 20:32:35 --> Helper loaded: url_helper
INFO - 2018-06-29 20:32:35 --> Helper loaded: form_helper
INFO - 2018-06-29 20:32:35 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:32:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:32:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:32:35 --> User Agent Class Initialized
INFO - 2018-06-29 20:32:35 --> Controller Class Initialized
INFO - 2018-06-29 20:32:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:32:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:32:35 --> Pixel_Model class loaded
INFO - 2018-06-29 20:32:35 --> Database Driver Class Initialized
INFO - 2018-06-29 20:32:35 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:32:35 --> Database Driver Class Initialized
INFO - 2018-06-29 20:32:35 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:32:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:32:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:32:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:32:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:32:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:32:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:32:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:32:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/gadgets.php
INFO - 2018-06-29 20:32:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:32:35 --> Final output sent to browser
DEBUG - 2018-06-29 20:32:35 --> Total execution time: 0.0548
INFO - 2018-06-29 20:32:36 --> Config Class Initialized
INFO - 2018-06-29 20:32:36 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:32:36 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:32:36 --> Utf8 Class Initialized
INFO - 2018-06-29 20:32:36 --> URI Class Initialized
INFO - 2018-06-29 20:32:36 --> Router Class Initialized
INFO - 2018-06-29 20:32:36 --> Output Class Initialized
INFO - 2018-06-29 20:32:36 --> Security Class Initialized
DEBUG - 2018-06-29 20:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:32:36 --> CSRF cookie sent
INFO - 2018-06-29 20:32:36 --> Input Class Initialized
INFO - 2018-06-29 20:32:36 --> Language Class Initialized
INFO - 2018-06-29 20:32:36 --> Loader Class Initialized
INFO - 2018-06-29 20:32:36 --> Helper loaded: url_helper
INFO - 2018-06-29 20:32:36 --> Helper loaded: form_helper
INFO - 2018-06-29 20:32:36 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:32:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:32:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:32:36 --> User Agent Class Initialized
INFO - 2018-06-29 20:32:36 --> Controller Class Initialized
INFO - 2018-06-29 20:32:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:32:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:32:36 --> Pixel_Model class loaded
INFO - 2018-06-29 20:32:36 --> Database Driver Class Initialized
INFO - 2018-06-29 20:32:36 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:32:36 --> Database Driver Class Initialized
INFO - 2018-06-29 20:32:36 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:32:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:32:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:32:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:32:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:32:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:32:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:32:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:32:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/bank_accounts.php
INFO - 2018-06-29 20:32:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:32:36 --> Final output sent to browser
DEBUG - 2018-06-29 20:32:36 --> Total execution time: 0.0446
INFO - 2018-06-29 20:32:37 --> Config Class Initialized
INFO - 2018-06-29 20:32:37 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:32:37 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:32:37 --> Utf8 Class Initialized
INFO - 2018-06-29 20:32:37 --> URI Class Initialized
INFO - 2018-06-29 20:32:37 --> Router Class Initialized
INFO - 2018-06-29 20:32:37 --> Output Class Initialized
INFO - 2018-06-29 20:32:37 --> Security Class Initialized
DEBUG - 2018-06-29 20:32:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:32:37 --> CSRF cookie sent
INFO - 2018-06-29 20:32:37 --> Input Class Initialized
INFO - 2018-06-29 20:32:37 --> Language Class Initialized
INFO - 2018-06-29 20:32:37 --> Loader Class Initialized
INFO - 2018-06-29 20:32:37 --> Helper loaded: url_helper
INFO - 2018-06-29 20:32:37 --> Helper loaded: form_helper
INFO - 2018-06-29 20:32:37 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:32:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:32:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:32:37 --> User Agent Class Initialized
INFO - 2018-06-29 20:32:37 --> Controller Class Initialized
INFO - 2018-06-29 20:32:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:32:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:32:37 --> Pixel_Model class loaded
INFO - 2018-06-29 20:32:37 --> Database Driver Class Initialized
INFO - 2018-06-29 20:32:37 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:32:37 --> Database Driver Class Initialized
INFO - 2018-06-29 20:32:37 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:32:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:32:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:32:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:32:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:32:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:32:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:32:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:32:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/crypto_currencies.php
INFO - 2018-06-29 20:32:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:32:37 --> Final output sent to browser
DEBUG - 2018-06-29 20:32:37 --> Total execution time: 0.0437
INFO - 2018-06-29 20:32:38 --> Config Class Initialized
INFO - 2018-06-29 20:32:38 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:32:38 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:32:38 --> Utf8 Class Initialized
INFO - 2018-06-29 20:32:38 --> URI Class Initialized
INFO - 2018-06-29 20:32:38 --> Router Class Initialized
INFO - 2018-06-29 20:32:38 --> Output Class Initialized
INFO - 2018-06-29 20:32:38 --> Security Class Initialized
DEBUG - 2018-06-29 20:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:32:38 --> CSRF cookie sent
INFO - 2018-06-29 20:32:38 --> Input Class Initialized
INFO - 2018-06-29 20:32:38 --> Language Class Initialized
INFO - 2018-06-29 20:32:38 --> Loader Class Initialized
INFO - 2018-06-29 20:32:38 --> Helper loaded: url_helper
INFO - 2018-06-29 20:32:38 --> Helper loaded: form_helper
INFO - 2018-06-29 20:32:38 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:32:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:32:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:32:38 --> User Agent Class Initialized
INFO - 2018-06-29 20:32:38 --> Controller Class Initialized
INFO - 2018-06-29 20:32:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:32:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:32:38 --> Pixel_Model class loaded
INFO - 2018-06-29 20:32:38 --> Database Driver Class Initialized
INFO - 2018-06-29 20:32:38 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:32:38 --> Database Driver Class Initialized
INFO - 2018-06-29 20:32:38 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:32:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:32:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:32:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:32:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:32:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:32:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:32:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:32:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/money_owed_you.php
INFO - 2018-06-29 20:32:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:32:38 --> Final output sent to browser
DEBUG - 2018-06-29 20:32:38 --> Total execution time: 0.0349
INFO - 2018-06-29 20:32:38 --> Config Class Initialized
INFO - 2018-06-29 20:32:38 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:32:38 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:32:38 --> Utf8 Class Initialized
INFO - 2018-06-29 20:32:38 --> URI Class Initialized
INFO - 2018-06-29 20:32:38 --> Router Class Initialized
INFO - 2018-06-29 20:32:39 --> Output Class Initialized
INFO - 2018-06-29 20:32:39 --> Security Class Initialized
DEBUG - 2018-06-29 20:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:32:39 --> CSRF cookie sent
INFO - 2018-06-29 20:32:39 --> Input Class Initialized
INFO - 2018-06-29 20:32:39 --> Language Class Initialized
INFO - 2018-06-29 20:32:39 --> Loader Class Initialized
INFO - 2018-06-29 20:32:39 --> Helper loaded: url_helper
INFO - 2018-06-29 20:32:39 --> Helper loaded: form_helper
INFO - 2018-06-29 20:32:39 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:32:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:32:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:32:39 --> User Agent Class Initialized
INFO - 2018-06-29 20:32:39 --> Controller Class Initialized
INFO - 2018-06-29 20:32:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:32:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:32:39 --> Pixel_Model class loaded
INFO - 2018-06-29 20:32:39 --> Database Driver Class Initialized
INFO - 2018-06-29 20:32:39 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:32:39 --> Database Driver Class Initialized
INFO - 2018-06-29 20:32:39 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:32:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:32:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:32:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:32:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:32:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:32:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:32:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:32:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/investments_stocks.php
INFO - 2018-06-29 20:32:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:32:39 --> Final output sent to browser
DEBUG - 2018-06-29 20:32:39 --> Total execution time: 0.0432
INFO - 2018-06-29 20:32:39 --> Config Class Initialized
INFO - 2018-06-29 20:32:39 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:32:39 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:32:39 --> Utf8 Class Initialized
INFO - 2018-06-29 20:32:39 --> URI Class Initialized
INFO - 2018-06-29 20:32:39 --> Router Class Initialized
INFO - 2018-06-29 20:32:39 --> Output Class Initialized
INFO - 2018-06-29 20:32:39 --> Security Class Initialized
DEBUG - 2018-06-29 20:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:32:39 --> CSRF cookie sent
INFO - 2018-06-29 20:32:39 --> Input Class Initialized
INFO - 2018-06-29 20:32:39 --> Language Class Initialized
INFO - 2018-06-29 20:32:39 --> Loader Class Initialized
INFO - 2018-06-29 20:32:39 --> Helper loaded: url_helper
INFO - 2018-06-29 20:32:39 --> Helper loaded: form_helper
INFO - 2018-06-29 20:32:39 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:32:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:32:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:32:39 --> User Agent Class Initialized
INFO - 2018-06-29 20:32:39 --> Controller Class Initialized
INFO - 2018-06-29 20:32:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:32:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:32:39 --> Pixel_Model class loaded
INFO - 2018-06-29 20:32:39 --> Database Driver Class Initialized
INFO - 2018-06-29 20:32:39 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:32:39 --> Database Driver Class Initialized
INFO - 2018-06-29 20:32:39 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:32:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:32:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:32:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:32:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:32:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:32:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:32:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:32:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/business_value_assets.php
INFO - 2018-06-29 20:32:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:32:39 --> Final output sent to browser
DEBUG - 2018-06-29 20:32:39 --> Total execution time: 0.0399
INFO - 2018-06-29 20:32:40 --> Config Class Initialized
INFO - 2018-06-29 20:32:40 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:32:40 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:32:40 --> Utf8 Class Initialized
INFO - 2018-06-29 20:32:40 --> URI Class Initialized
INFO - 2018-06-29 20:32:40 --> Router Class Initialized
INFO - 2018-06-29 20:32:40 --> Output Class Initialized
INFO - 2018-06-29 20:32:40 --> Security Class Initialized
DEBUG - 2018-06-29 20:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:32:40 --> CSRF cookie sent
INFO - 2018-06-29 20:32:40 --> Input Class Initialized
INFO - 2018-06-29 20:32:40 --> Language Class Initialized
INFO - 2018-06-29 20:32:40 --> Loader Class Initialized
INFO - 2018-06-29 20:32:40 --> Helper loaded: url_helper
INFO - 2018-06-29 20:32:40 --> Helper loaded: form_helper
INFO - 2018-06-29 20:32:40 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:32:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:32:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:32:40 --> User Agent Class Initialized
INFO - 2018-06-29 20:32:40 --> Controller Class Initialized
INFO - 2018-06-29 20:32:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:32:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:32:40 --> Pixel_Model class loaded
INFO - 2018-06-29 20:32:40 --> Database Driver Class Initialized
INFO - 2018-06-29 20:32:40 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:32:40 --> Database Driver Class Initialized
INFO - 2018-06-29 20:32:40 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:32:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:32:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:32:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:32:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:32:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:32:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:32:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:32:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/disability_insurance.php
INFO - 2018-06-29 20:32:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:32:40 --> Final output sent to browser
DEBUG - 2018-06-29 20:32:40 --> Total execution time: 0.0418
INFO - 2018-06-29 20:32:41 --> Config Class Initialized
INFO - 2018-06-29 20:32:41 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:32:41 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:32:41 --> Utf8 Class Initialized
INFO - 2018-06-29 20:32:41 --> URI Class Initialized
INFO - 2018-06-29 20:32:41 --> Router Class Initialized
INFO - 2018-06-29 20:32:41 --> Output Class Initialized
INFO - 2018-06-29 20:32:41 --> Security Class Initialized
DEBUG - 2018-06-29 20:32:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:32:41 --> CSRF cookie sent
INFO - 2018-06-29 20:32:41 --> Input Class Initialized
INFO - 2018-06-29 20:32:41 --> Language Class Initialized
INFO - 2018-06-29 20:32:41 --> Loader Class Initialized
INFO - 2018-06-29 20:32:41 --> Helper loaded: url_helper
INFO - 2018-06-29 20:32:41 --> Helper loaded: form_helper
INFO - 2018-06-29 20:32:41 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:32:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:32:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:32:41 --> User Agent Class Initialized
INFO - 2018-06-29 20:32:41 --> Controller Class Initialized
INFO - 2018-06-29 20:32:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:32:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:32:41 --> Pixel_Model class loaded
INFO - 2018-06-29 20:32:41 --> Database Driver Class Initialized
INFO - 2018-06-29 20:32:41 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:32:41 --> Database Driver Class Initialized
INFO - 2018-06-29 20:32:41 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:32:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:32:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:32:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:32:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:32:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:32:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:32:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:32:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/personal_loans.php
INFO - 2018-06-29 20:32:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:32:41 --> Final output sent to browser
DEBUG - 2018-06-29 20:32:41 --> Total execution time: 0.0393
INFO - 2018-06-29 20:32:42 --> Config Class Initialized
INFO - 2018-06-29 20:32:42 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:32:42 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:32:42 --> Utf8 Class Initialized
INFO - 2018-06-29 20:32:42 --> URI Class Initialized
INFO - 2018-06-29 20:32:42 --> Router Class Initialized
INFO - 2018-06-29 20:32:42 --> Output Class Initialized
INFO - 2018-06-29 20:32:42 --> Security Class Initialized
DEBUG - 2018-06-29 20:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:32:42 --> CSRF cookie sent
INFO - 2018-06-29 20:32:42 --> Input Class Initialized
INFO - 2018-06-29 20:32:42 --> Language Class Initialized
INFO - 2018-06-29 20:32:42 --> Loader Class Initialized
INFO - 2018-06-29 20:32:42 --> Helper loaded: url_helper
INFO - 2018-06-29 20:32:42 --> Helper loaded: form_helper
INFO - 2018-06-29 20:32:42 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:32:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:32:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:32:42 --> User Agent Class Initialized
INFO - 2018-06-29 20:32:42 --> Controller Class Initialized
INFO - 2018-06-29 20:32:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:32:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:32:42 --> Pixel_Model class loaded
INFO - 2018-06-29 20:32:42 --> Database Driver Class Initialized
INFO - 2018-06-29 20:32:42 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:32:42 --> Database Driver Class Initialized
INFO - 2018-06-29 20:32:42 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:32:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:32:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:32:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:32:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:32:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:32:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:32:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:32:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/personal_credit_line.php
INFO - 2018-06-29 20:32:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:32:42 --> Final output sent to browser
DEBUG - 2018-06-29 20:32:42 --> Total execution time: 0.0440
INFO - 2018-06-29 20:32:44 --> Config Class Initialized
INFO - 2018-06-29 20:32:44 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:32:44 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:32:44 --> Utf8 Class Initialized
INFO - 2018-06-29 20:32:44 --> URI Class Initialized
INFO - 2018-06-29 20:32:44 --> Router Class Initialized
INFO - 2018-06-29 20:32:44 --> Output Class Initialized
INFO - 2018-06-29 20:32:44 --> Security Class Initialized
DEBUG - 2018-06-29 20:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:32:44 --> CSRF cookie sent
INFO - 2018-06-29 20:32:44 --> Input Class Initialized
INFO - 2018-06-29 20:32:44 --> Language Class Initialized
INFO - 2018-06-29 20:32:44 --> Loader Class Initialized
INFO - 2018-06-29 20:32:44 --> Helper loaded: url_helper
INFO - 2018-06-29 20:32:44 --> Helper loaded: form_helper
INFO - 2018-06-29 20:32:44 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:32:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:32:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:32:44 --> User Agent Class Initialized
INFO - 2018-06-29 20:32:44 --> Controller Class Initialized
INFO - 2018-06-29 20:32:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:32:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:32:44 --> Pixel_Model class loaded
INFO - 2018-06-29 20:32:44 --> Database Driver Class Initialized
INFO - 2018-06-29 20:32:44 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:32:44 --> Database Driver Class Initialized
INFO - 2018-06-29 20:32:44 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:32:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:32:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:32:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:32:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:32:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:32:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:32:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:32:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/credit_cards.php
INFO - 2018-06-29 20:32:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:32:44 --> Final output sent to browser
DEBUG - 2018-06-29 20:32:44 --> Total execution time: 0.0408
INFO - 2018-06-29 20:32:45 --> Config Class Initialized
INFO - 2018-06-29 20:32:45 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:32:45 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:32:45 --> Utf8 Class Initialized
INFO - 2018-06-29 20:32:45 --> URI Class Initialized
INFO - 2018-06-29 20:32:45 --> Router Class Initialized
INFO - 2018-06-29 20:32:45 --> Output Class Initialized
INFO - 2018-06-29 20:32:45 --> Security Class Initialized
DEBUG - 2018-06-29 20:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:32:45 --> CSRF cookie sent
INFO - 2018-06-29 20:32:45 --> Input Class Initialized
INFO - 2018-06-29 20:32:45 --> Language Class Initialized
INFO - 2018-06-29 20:32:45 --> Loader Class Initialized
INFO - 2018-06-29 20:32:45 --> Helper loaded: url_helper
INFO - 2018-06-29 20:32:45 --> Helper loaded: form_helper
INFO - 2018-06-29 20:32:45 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:32:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:32:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:32:45 --> User Agent Class Initialized
INFO - 2018-06-29 20:32:45 --> Controller Class Initialized
INFO - 2018-06-29 20:32:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:32:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:32:45 --> Pixel_Model class loaded
INFO - 2018-06-29 20:32:45 --> Database Driver Class Initialized
INFO - 2018-06-29 20:32:45 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:32:45 --> Database Driver Class Initialized
INFO - 2018-06-29 20:32:45 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:32:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:32:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:32:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:32:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:32:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:32:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:32:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:32:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/other_debt.php
INFO - 2018-06-29 20:32:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:32:45 --> Final output sent to browser
DEBUG - 2018-06-29 20:32:45 --> Total execution time: 0.0620
INFO - 2018-06-29 20:32:46 --> Config Class Initialized
INFO - 2018-06-29 20:32:46 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:32:46 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:32:46 --> Utf8 Class Initialized
INFO - 2018-06-29 20:32:46 --> URI Class Initialized
INFO - 2018-06-29 20:32:46 --> Router Class Initialized
INFO - 2018-06-29 20:32:46 --> Output Class Initialized
INFO - 2018-06-29 20:32:46 --> Security Class Initialized
DEBUG - 2018-06-29 20:32:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:32:46 --> CSRF cookie sent
INFO - 2018-06-29 20:32:46 --> Input Class Initialized
INFO - 2018-06-29 20:32:46 --> Language Class Initialized
INFO - 2018-06-29 20:32:46 --> Loader Class Initialized
INFO - 2018-06-29 20:32:46 --> Helper loaded: url_helper
INFO - 2018-06-29 20:32:46 --> Helper loaded: form_helper
INFO - 2018-06-29 20:32:46 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:32:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:32:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:32:46 --> User Agent Class Initialized
INFO - 2018-06-29 20:32:46 --> Controller Class Initialized
INFO - 2018-06-29 20:32:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:32:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:32:46 --> Pixel_Model class loaded
INFO - 2018-06-29 20:32:46 --> Database Driver Class Initialized
INFO - 2018-06-29 20:32:46 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:32:46 --> Database Driver Class Initialized
INFO - 2018-06-29 20:32:46 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:32:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:32:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:32:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:32:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:32:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:32:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:32:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:32:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/business_credit_line.php
INFO - 2018-06-29 20:32:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:32:46 --> Final output sent to browser
DEBUG - 2018-06-29 20:32:46 --> Total execution time: 0.0397
INFO - 2018-06-29 20:32:47 --> Config Class Initialized
INFO - 2018-06-29 20:32:47 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:32:47 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:32:47 --> Utf8 Class Initialized
INFO - 2018-06-29 20:32:47 --> URI Class Initialized
INFO - 2018-06-29 20:32:47 --> Router Class Initialized
INFO - 2018-06-29 20:32:47 --> Output Class Initialized
INFO - 2018-06-29 20:32:47 --> Security Class Initialized
DEBUG - 2018-06-29 20:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:32:47 --> CSRF cookie sent
INFO - 2018-06-29 20:32:47 --> Input Class Initialized
INFO - 2018-06-29 20:32:47 --> Language Class Initialized
ERROR - 2018-06-29 20:32:47 --> 404 Page Not Found: Risk-report/index
INFO - 2018-06-29 20:32:47 --> Config Class Initialized
INFO - 2018-06-29 20:32:47 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:32:47 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:32:47 --> Utf8 Class Initialized
INFO - 2018-06-29 20:32:47 --> URI Class Initialized
INFO - 2018-06-29 20:32:47 --> Router Class Initialized
INFO - 2018-06-29 20:32:47 --> Output Class Initialized
INFO - 2018-06-29 20:32:47 --> Security Class Initialized
DEBUG - 2018-06-29 20:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:32:47 --> CSRF cookie sent
INFO - 2018-06-29 20:32:47 --> Input Class Initialized
INFO - 2018-06-29 20:32:47 --> Language Class Initialized
ERROR - 2018-06-29 20:32:47 --> 404 Page Not Found: Faviconico/index
INFO - 2018-06-29 20:32:50 --> Config Class Initialized
INFO - 2018-06-29 20:32:50 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:32:50 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:32:50 --> Utf8 Class Initialized
INFO - 2018-06-29 20:32:50 --> URI Class Initialized
INFO - 2018-06-29 20:32:50 --> Router Class Initialized
INFO - 2018-06-29 20:32:50 --> Output Class Initialized
INFO - 2018-06-29 20:32:50 --> Security Class Initialized
DEBUG - 2018-06-29 20:32:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:32:50 --> CSRF cookie sent
INFO - 2018-06-29 20:32:50 --> Input Class Initialized
INFO - 2018-06-29 20:32:50 --> Language Class Initialized
INFO - 2018-06-29 20:32:50 --> Loader Class Initialized
INFO - 2018-06-29 20:32:50 --> Helper loaded: url_helper
INFO - 2018-06-29 20:32:50 --> Helper loaded: form_helper
INFO - 2018-06-29 20:32:50 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:32:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:32:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:32:50 --> User Agent Class Initialized
INFO - 2018-06-29 20:32:50 --> Controller Class Initialized
INFO - 2018-06-29 20:32:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:32:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:32:50 --> Pixel_Model class loaded
INFO - 2018-06-29 20:32:50 --> Database Driver Class Initialized
INFO - 2018-06-29 20:32:50 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:32:50 --> Database Driver Class Initialized
INFO - 2018-06-29 20:32:50 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:32:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:32:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:32:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:32:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:32:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:32:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:32:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:32:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/business_credit_line.php
INFO - 2018-06-29 20:32:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:32:50 --> Final output sent to browser
DEBUG - 2018-06-29 20:32:50 --> Total execution time: 0.0472
INFO - 2018-06-29 20:33:42 --> Config Class Initialized
INFO - 2018-06-29 20:33:42 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:33:42 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:33:42 --> Utf8 Class Initialized
INFO - 2018-06-29 20:33:42 --> URI Class Initialized
INFO - 2018-06-29 20:33:42 --> Router Class Initialized
INFO - 2018-06-29 20:33:42 --> Output Class Initialized
INFO - 2018-06-29 20:33:42 --> Security Class Initialized
DEBUG - 2018-06-29 20:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:33:42 --> CSRF cookie sent
INFO - 2018-06-29 20:33:42 --> Input Class Initialized
INFO - 2018-06-29 20:33:42 --> Language Class Initialized
ERROR - 2018-06-29 20:33:42 --> 404 Page Not Found: Risk-report/index
INFO - 2018-06-29 20:33:44 --> Config Class Initialized
INFO - 2018-06-29 20:33:44 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:33:44 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:33:44 --> Utf8 Class Initialized
INFO - 2018-06-29 20:33:44 --> URI Class Initialized
INFO - 2018-06-29 20:33:44 --> Router Class Initialized
INFO - 2018-06-29 20:33:44 --> Output Class Initialized
INFO - 2018-06-29 20:33:44 --> Security Class Initialized
DEBUG - 2018-06-29 20:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:33:44 --> CSRF cookie sent
INFO - 2018-06-29 20:33:44 --> Input Class Initialized
INFO - 2018-06-29 20:33:44 --> Language Class Initialized
INFO - 2018-06-29 20:33:44 --> Loader Class Initialized
INFO - 2018-06-29 20:33:44 --> Helper loaded: url_helper
INFO - 2018-06-29 20:33:44 --> Helper loaded: form_helper
INFO - 2018-06-29 20:33:44 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:33:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:33:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:33:44 --> User Agent Class Initialized
INFO - 2018-06-29 20:33:44 --> Controller Class Initialized
INFO - 2018-06-29 20:33:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:33:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:33:44 --> Pixel_Model class loaded
INFO - 2018-06-29 20:33:44 --> Database Driver Class Initialized
INFO - 2018-06-29 20:33:44 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:33:44 --> Database Driver Class Initialized
INFO - 2018-06-29 20:33:44 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:33:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:33:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:33:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:33:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:33:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:33:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:33:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:33:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/business_credit_line.php
INFO - 2018-06-29 20:33:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:33:44 --> Final output sent to browser
DEBUG - 2018-06-29 20:33:44 --> Total execution time: 0.0674
INFO - 2018-06-29 20:33:45 --> Config Class Initialized
INFO - 2018-06-29 20:33:45 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:33:45 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:33:45 --> Utf8 Class Initialized
INFO - 2018-06-29 20:33:45 --> URI Class Initialized
INFO - 2018-06-29 20:33:45 --> Router Class Initialized
INFO - 2018-06-29 20:33:45 --> Output Class Initialized
INFO - 2018-06-29 20:33:45 --> Security Class Initialized
DEBUG - 2018-06-29 20:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:33:45 --> CSRF cookie sent
INFO - 2018-06-29 20:33:45 --> Input Class Initialized
INFO - 2018-06-29 20:33:45 --> Language Class Initialized
INFO - 2018-06-29 20:33:45 --> Loader Class Initialized
INFO - 2018-06-29 20:33:45 --> Helper loaded: url_helper
INFO - 2018-06-29 20:33:45 --> Helper loaded: form_helper
INFO - 2018-06-29 20:33:45 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:33:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:33:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:33:45 --> User Agent Class Initialized
INFO - 2018-06-29 20:33:45 --> Controller Class Initialized
INFO - 2018-06-29 20:33:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:33:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:33:45 --> Pixel_Model class loaded
INFO - 2018-06-29 20:33:45 --> Database Driver Class Initialized
INFO - 2018-06-29 20:33:45 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:33:45 --> Database Driver Class Initialized
INFO - 2018-06-29 20:33:45 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:33:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:33:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:33:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:33:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:33:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:33:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:33:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:33:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/business_credit_line.php
INFO - 2018-06-29 20:33:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:33:45 --> Final output sent to browser
DEBUG - 2018-06-29 20:33:45 --> Total execution time: 0.0448
INFO - 2018-06-29 20:33:48 --> Config Class Initialized
INFO - 2018-06-29 20:33:48 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:33:48 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:33:48 --> Utf8 Class Initialized
INFO - 2018-06-29 20:33:48 --> URI Class Initialized
INFO - 2018-06-29 20:33:48 --> Router Class Initialized
INFO - 2018-06-29 20:33:48 --> Output Class Initialized
INFO - 2018-06-29 20:33:48 --> Security Class Initialized
DEBUG - 2018-06-29 20:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:33:48 --> CSRF cookie sent
INFO - 2018-06-29 20:33:48 --> Input Class Initialized
INFO - 2018-06-29 20:33:48 --> Language Class Initialized
INFO - 2018-06-29 20:33:48 --> Loader Class Initialized
INFO - 2018-06-29 20:33:48 --> Helper loaded: url_helper
INFO - 2018-06-29 20:33:48 --> Helper loaded: form_helper
INFO - 2018-06-29 20:33:48 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:33:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:33:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:33:48 --> User Agent Class Initialized
INFO - 2018-06-29 20:33:48 --> Controller Class Initialized
INFO - 2018-06-29 20:33:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:33:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:33:48 --> Pixel_Model class loaded
INFO - 2018-06-29 20:33:48 --> Database Driver Class Initialized
INFO - 2018-06-29 20:33:48 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:33:48 --> Database Driver Class Initialized
INFO - 2018-06-29 20:33:48 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:33:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:33:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:33:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:33:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:33:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:33:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-29 20:33:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-29 20:33:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/influencer_info.php
INFO - 2018-06-29 20:33:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:33:48 --> Final output sent to browser
DEBUG - 2018-06-29 20:33:48 --> Total execution time: 0.0417
INFO - 2018-06-29 20:34:10 --> Config Class Initialized
INFO - 2018-06-29 20:34:10 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:34:10 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:34:10 --> Utf8 Class Initialized
INFO - 2018-06-29 20:34:10 --> URI Class Initialized
INFO - 2018-06-29 20:34:10 --> Router Class Initialized
INFO - 2018-06-29 20:34:10 --> Output Class Initialized
INFO - 2018-06-29 20:34:10 --> Security Class Initialized
DEBUG - 2018-06-29 20:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:34:10 --> CSRF cookie sent
INFO - 2018-06-29 20:34:10 --> CSRF token verified
INFO - 2018-06-29 20:34:10 --> Input Class Initialized
INFO - 2018-06-29 20:34:10 --> Language Class Initialized
INFO - 2018-06-29 20:34:10 --> Loader Class Initialized
INFO - 2018-06-29 20:34:10 --> Helper loaded: url_helper
INFO - 2018-06-29 20:34:10 --> Helper loaded: form_helper
INFO - 2018-06-29 20:34:10 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:34:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:34:10 --> User Agent Class Initialized
INFO - 2018-06-29 20:34:10 --> Controller Class Initialized
INFO - 2018-06-29 20:34:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:34:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:34:10 --> Pixel_Model class loaded
INFO - 2018-06-29 20:34:10 --> Database Driver Class Initialized
INFO - 2018-06-29 20:34:10 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:34:10 --> Form Validation Class Initialized
INFO - 2018-06-29 20:34:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-29 20:34:10 --> Config Class Initialized
INFO - 2018-06-29 20:34:10 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:34:10 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:34:10 --> Utf8 Class Initialized
INFO - 2018-06-29 20:34:10 --> URI Class Initialized
INFO - 2018-06-29 20:34:10 --> Router Class Initialized
INFO - 2018-06-29 20:34:10 --> Output Class Initialized
INFO - 2018-06-29 20:34:10 --> Security Class Initialized
DEBUG - 2018-06-29 20:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:34:10 --> CSRF cookie sent
INFO - 2018-06-29 20:34:10 --> Input Class Initialized
INFO - 2018-06-29 20:34:10 --> Language Class Initialized
INFO - 2018-06-29 20:34:10 --> Loader Class Initialized
INFO - 2018-06-29 20:34:10 --> Helper loaded: url_helper
INFO - 2018-06-29 20:34:10 --> Helper loaded: form_helper
INFO - 2018-06-29 20:34:10 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:34:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:34:10 --> User Agent Class Initialized
INFO - 2018-06-29 20:34:10 --> Controller Class Initialized
INFO - 2018-06-29 20:34:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:34:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:34:10 --> Pixel_Model class loaded
INFO - 2018-06-29 20:34:10 --> Database Driver Class Initialized
INFO - 2018-06-29 20:34:10 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:34:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:34:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:34:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:34:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:34:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:34:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/finish.php
INFO - 2018-06-29 20:34:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:34:10 --> Final output sent to browser
DEBUG - 2018-06-29 20:34:10 --> Total execution time: 0.0591
INFO - 2018-06-29 20:34:19 --> Config Class Initialized
INFO - 2018-06-29 20:34:19 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:34:19 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:34:19 --> Utf8 Class Initialized
INFO - 2018-06-29 20:34:19 --> URI Class Initialized
INFO - 2018-06-29 20:34:19 --> Router Class Initialized
INFO - 2018-06-29 20:34:19 --> Output Class Initialized
INFO - 2018-06-29 20:34:19 --> Security Class Initialized
DEBUG - 2018-06-29 20:34:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:34:19 --> CSRF cookie sent
INFO - 2018-06-29 20:34:19 --> Input Class Initialized
INFO - 2018-06-29 20:34:19 --> Language Class Initialized
INFO - 2018-06-29 20:34:19 --> Loader Class Initialized
INFO - 2018-06-29 20:34:19 --> Helper loaded: url_helper
INFO - 2018-06-29 20:34:19 --> Helper loaded: form_helper
INFO - 2018-06-29 20:34:19 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:34:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:34:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:34:19 --> User Agent Class Initialized
INFO - 2018-06-29 20:34:19 --> Controller Class Initialized
INFO - 2018-06-29 20:34:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:34:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:34:19 --> Pixel_Model class loaded
INFO - 2018-06-29 20:34:19 --> Database Driver Class Initialized
INFO - 2018-06-29 20:34:19 --> Model "MyAccountModel" initialized
INFO - 2018-06-29 20:34:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:34:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:34:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:34:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:34:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:34:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/application_list.php
INFO - 2018-06-29 20:34:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:34:19 --> Final output sent to browser
DEBUG - 2018-06-29 20:34:19 --> Total execution time: 0.0364
INFO - 2018-06-29 20:34:21 --> Config Class Initialized
INFO - 2018-06-29 20:34:21 --> Hooks Class Initialized
DEBUG - 2018-06-29 20:34:21 --> UTF-8 Support Enabled
INFO - 2018-06-29 20:34:21 --> Utf8 Class Initialized
INFO - 2018-06-29 20:34:21 --> URI Class Initialized
INFO - 2018-06-29 20:34:21 --> Router Class Initialized
INFO - 2018-06-29 20:34:21 --> Output Class Initialized
INFO - 2018-06-29 20:34:21 --> Security Class Initialized
DEBUG - 2018-06-29 20:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 20:34:21 --> CSRF cookie sent
INFO - 2018-06-29 20:34:21 --> Input Class Initialized
INFO - 2018-06-29 20:34:21 --> Language Class Initialized
INFO - 2018-06-29 20:34:21 --> Loader Class Initialized
INFO - 2018-06-29 20:34:21 --> Helper loaded: url_helper
INFO - 2018-06-29 20:34:21 --> Helper loaded: form_helper
INFO - 2018-06-29 20:34:21 --> Helper loaded: language_helper
DEBUG - 2018-06-29 20:34:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 20:34:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 20:34:21 --> User Agent Class Initialized
INFO - 2018-06-29 20:34:21 --> Controller Class Initialized
INFO - 2018-06-29 20:34:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-29 20:34:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-29 20:34:21 --> Pixel_Model class loaded
INFO - 2018-06-29 20:34:21 --> Database Driver Class Initialized
INFO - 2018-06-29 20:34:21 --> Model "QuestionsModel" initialized
INFO - 2018-06-29 20:34:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-29 20:34:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-06-29 20:34:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-29 20:34:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-29 20:34:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-29 20:34:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/application_view.php
INFO - 2018-06-29 20:34:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-29 20:34:21 --> Final output sent to browser
DEBUG - 2018-06-29 20:34:21 --> Total execution time: 0.0409

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-06-30 00:18:55 --> Config Class Initialized
INFO - 2018-06-30 00:18:55 --> Hooks Class Initialized
DEBUG - 2018-06-30 00:18:55 --> UTF-8 Support Enabled
INFO - 2018-06-30 00:18:55 --> Utf8 Class Initialized
INFO - 2018-06-30 00:18:55 --> URI Class Initialized
INFO - 2018-06-30 00:18:55 --> Router Class Initialized
INFO - 2018-06-30 00:18:55 --> Output Class Initialized
INFO - 2018-06-30 00:18:55 --> Security Class Initialized
DEBUG - 2018-06-30 00:18:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 00:18:55 --> CSRF cookie sent
INFO - 2018-06-30 00:18:55 --> Input Class Initialized
INFO - 2018-06-30 00:18:55 --> Language Class Initialized
ERROR - 2018-06-30 00:18:55 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-06-30 00:18:56 --> Config Class Initialized
INFO - 2018-06-30 00:18:56 --> Hooks Class Initialized
DEBUG - 2018-06-30 00:18:56 --> UTF-8 Support Enabled
INFO - 2018-06-30 00:18:56 --> Utf8 Class Initialized
INFO - 2018-06-30 00:18:56 --> URI Class Initialized
DEBUG - 2018-06-30 00:18:56 --> No URI present. Default controller set.
INFO - 2018-06-30 00:18:56 --> Router Class Initialized
INFO - 2018-06-30 00:18:56 --> Output Class Initialized
INFO - 2018-06-30 00:18:56 --> Security Class Initialized
DEBUG - 2018-06-30 00:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 00:18:56 --> CSRF cookie sent
INFO - 2018-06-30 00:18:56 --> Input Class Initialized
INFO - 2018-06-30 00:18:56 --> Language Class Initialized
INFO - 2018-06-30 00:18:56 --> Loader Class Initialized
INFO - 2018-06-30 00:18:56 --> Helper loaded: url_helper
INFO - 2018-06-30 00:18:56 --> Helper loaded: form_helper
INFO - 2018-06-30 00:18:56 --> Helper loaded: language_helper
DEBUG - 2018-06-30 00:18:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 00:18:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 00:18:56 --> User Agent Class Initialized
INFO - 2018-06-30 00:18:56 --> Controller Class Initialized
INFO - 2018-06-30 00:18:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 00:18:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 00:18:56 --> Pixel_Model class loaded
INFO - 2018-06-30 00:18:56 --> Database Driver Class Initialized
INFO - 2018-06-30 00:18:56 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 00:18:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 00:18:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 00:18:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-30 00:18:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 00:18:56 --> Final output sent to browser
DEBUG - 2018-06-30 00:18:56 --> Total execution time: 0.0332
INFO - 2018-06-30 00:30:50 --> Config Class Initialized
INFO - 2018-06-30 00:30:50 --> Hooks Class Initialized
DEBUG - 2018-06-30 00:30:50 --> UTF-8 Support Enabled
INFO - 2018-06-30 00:30:50 --> Utf8 Class Initialized
INFO - 2018-06-30 00:30:50 --> URI Class Initialized
DEBUG - 2018-06-30 00:30:50 --> No URI present. Default controller set.
INFO - 2018-06-30 00:30:50 --> Router Class Initialized
INFO - 2018-06-30 00:30:50 --> Output Class Initialized
INFO - 2018-06-30 00:30:50 --> Security Class Initialized
DEBUG - 2018-06-30 00:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 00:30:50 --> CSRF cookie sent
INFO - 2018-06-30 00:30:50 --> Input Class Initialized
INFO - 2018-06-30 00:30:50 --> Language Class Initialized
INFO - 2018-06-30 00:30:50 --> Loader Class Initialized
INFO - 2018-06-30 00:30:50 --> Helper loaded: url_helper
INFO - 2018-06-30 00:30:50 --> Helper loaded: form_helper
INFO - 2018-06-30 00:30:50 --> Helper loaded: language_helper
DEBUG - 2018-06-30 00:30:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 00:30:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 00:30:50 --> User Agent Class Initialized
INFO - 2018-06-30 00:30:50 --> Controller Class Initialized
INFO - 2018-06-30 00:30:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 00:30:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 00:30:50 --> Pixel_Model class loaded
INFO - 2018-06-30 00:30:50 --> Database Driver Class Initialized
INFO - 2018-06-30 00:30:50 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 00:30:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 00:30:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 00:30:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-30 00:30:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 00:30:50 --> Final output sent to browser
DEBUG - 2018-06-30 00:30:50 --> Total execution time: 0.0342
INFO - 2018-06-30 00:30:56 --> Config Class Initialized
INFO - 2018-06-30 00:30:56 --> Hooks Class Initialized
DEBUG - 2018-06-30 00:30:56 --> UTF-8 Support Enabled
INFO - 2018-06-30 00:30:56 --> Utf8 Class Initialized
INFO - 2018-06-30 00:30:56 --> URI Class Initialized
DEBUG - 2018-06-30 00:30:56 --> No URI present. Default controller set.
INFO - 2018-06-30 00:30:56 --> Router Class Initialized
INFO - 2018-06-30 00:30:56 --> Output Class Initialized
INFO - 2018-06-30 00:30:56 --> Security Class Initialized
DEBUG - 2018-06-30 00:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 00:30:56 --> CSRF cookie sent
INFO - 2018-06-30 00:30:56 --> Input Class Initialized
INFO - 2018-06-30 00:30:56 --> Language Class Initialized
INFO - 2018-06-30 00:30:56 --> Loader Class Initialized
INFO - 2018-06-30 00:30:56 --> Helper loaded: url_helper
INFO - 2018-06-30 00:30:56 --> Helper loaded: form_helper
INFO - 2018-06-30 00:30:56 --> Helper loaded: language_helper
DEBUG - 2018-06-30 00:30:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 00:30:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 00:30:56 --> User Agent Class Initialized
INFO - 2018-06-30 00:30:56 --> Controller Class Initialized
INFO - 2018-06-30 00:30:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 00:30:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 00:30:56 --> Pixel_Model class loaded
INFO - 2018-06-30 00:30:56 --> Database Driver Class Initialized
INFO - 2018-06-30 00:30:56 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 00:30:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 00:30:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 00:30:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-30 00:30:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 00:30:56 --> Final output sent to browser
DEBUG - 2018-06-30 00:30:56 --> Total execution time: 0.0338
INFO - 2018-06-30 00:30:56 --> Config Class Initialized
INFO - 2018-06-30 00:30:56 --> Hooks Class Initialized
DEBUG - 2018-06-30 00:30:56 --> UTF-8 Support Enabled
INFO - 2018-06-30 00:30:56 --> Utf8 Class Initialized
INFO - 2018-06-30 00:30:56 --> URI Class Initialized
DEBUG - 2018-06-30 00:30:56 --> No URI present. Default controller set.
INFO - 2018-06-30 00:30:56 --> Router Class Initialized
INFO - 2018-06-30 00:30:56 --> Output Class Initialized
INFO - 2018-06-30 00:30:56 --> Security Class Initialized
DEBUG - 2018-06-30 00:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 00:30:56 --> CSRF cookie sent
INFO - 2018-06-30 00:30:56 --> Input Class Initialized
INFO - 2018-06-30 00:30:56 --> Language Class Initialized
INFO - 2018-06-30 00:30:56 --> Loader Class Initialized
INFO - 2018-06-30 00:30:56 --> Helper loaded: url_helper
INFO - 2018-06-30 00:30:56 --> Helper loaded: form_helper
INFO - 2018-06-30 00:30:56 --> Helper loaded: language_helper
DEBUG - 2018-06-30 00:30:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 00:30:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 00:30:56 --> User Agent Class Initialized
INFO - 2018-06-30 00:30:56 --> Controller Class Initialized
INFO - 2018-06-30 00:30:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 00:30:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 00:30:56 --> Pixel_Model class loaded
INFO - 2018-06-30 00:30:56 --> Database Driver Class Initialized
INFO - 2018-06-30 00:30:56 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 00:30:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 00:30:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 00:30:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-30 00:30:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 00:30:56 --> Final output sent to browser
DEBUG - 2018-06-30 00:30:56 --> Total execution time: 0.0272
INFO - 2018-06-30 00:30:56 --> Config Class Initialized
INFO - 2018-06-30 00:30:56 --> Hooks Class Initialized
DEBUG - 2018-06-30 00:30:56 --> UTF-8 Support Enabled
INFO - 2018-06-30 00:30:56 --> Utf8 Class Initialized
INFO - 2018-06-30 00:30:56 --> URI Class Initialized
DEBUG - 2018-06-30 00:30:56 --> No URI present. Default controller set.
INFO - 2018-06-30 00:30:56 --> Router Class Initialized
INFO - 2018-06-30 00:30:56 --> Output Class Initialized
INFO - 2018-06-30 00:30:56 --> Security Class Initialized
DEBUG - 2018-06-30 00:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 00:30:56 --> CSRF cookie sent
INFO - 2018-06-30 00:30:56 --> Input Class Initialized
INFO - 2018-06-30 00:30:56 --> Language Class Initialized
INFO - 2018-06-30 00:30:56 --> Loader Class Initialized
INFO - 2018-06-30 00:30:56 --> Helper loaded: url_helper
INFO - 2018-06-30 00:30:56 --> Helper loaded: form_helper
INFO - 2018-06-30 00:30:56 --> Helper loaded: language_helper
DEBUG - 2018-06-30 00:30:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 00:30:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 00:30:56 --> User Agent Class Initialized
INFO - 2018-06-30 00:30:56 --> Controller Class Initialized
INFO - 2018-06-30 00:30:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 00:30:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 00:30:56 --> Pixel_Model class loaded
INFO - 2018-06-30 00:30:56 --> Database Driver Class Initialized
INFO - 2018-06-30 00:30:56 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 00:30:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 00:30:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 00:30:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-30 00:30:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 00:30:56 --> Final output sent to browser
DEBUG - 2018-06-30 00:30:56 --> Total execution time: 0.0347
INFO - 2018-06-30 00:30:57 --> Config Class Initialized
INFO - 2018-06-30 00:30:57 --> Hooks Class Initialized
DEBUG - 2018-06-30 00:30:57 --> UTF-8 Support Enabled
INFO - 2018-06-30 00:30:57 --> Utf8 Class Initialized
INFO - 2018-06-30 00:30:57 --> URI Class Initialized
DEBUG - 2018-06-30 00:30:57 --> No URI present. Default controller set.
INFO - 2018-06-30 00:30:57 --> Router Class Initialized
INFO - 2018-06-30 00:30:57 --> Output Class Initialized
INFO - 2018-06-30 00:30:57 --> Security Class Initialized
DEBUG - 2018-06-30 00:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 00:30:57 --> CSRF cookie sent
INFO - 2018-06-30 00:30:57 --> Input Class Initialized
INFO - 2018-06-30 00:30:57 --> Language Class Initialized
INFO - 2018-06-30 00:30:57 --> Loader Class Initialized
INFO - 2018-06-30 00:30:57 --> Helper loaded: url_helper
INFO - 2018-06-30 00:30:57 --> Helper loaded: form_helper
INFO - 2018-06-30 00:30:57 --> Helper loaded: language_helper
DEBUG - 2018-06-30 00:30:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 00:30:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 00:30:57 --> User Agent Class Initialized
INFO - 2018-06-30 00:30:57 --> Controller Class Initialized
INFO - 2018-06-30 00:30:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 00:30:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 00:30:57 --> Pixel_Model class loaded
INFO - 2018-06-30 00:30:57 --> Database Driver Class Initialized
INFO - 2018-06-30 00:30:57 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 00:30:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 00:30:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 00:30:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-30 00:30:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 00:30:57 --> Final output sent to browser
DEBUG - 2018-06-30 00:30:57 --> Total execution time: 0.0253
INFO - 2018-06-30 00:30:57 --> Config Class Initialized
INFO - 2018-06-30 00:30:57 --> Hooks Class Initialized
DEBUG - 2018-06-30 00:30:57 --> UTF-8 Support Enabled
INFO - 2018-06-30 00:30:57 --> Utf8 Class Initialized
INFO - 2018-06-30 00:30:57 --> URI Class Initialized
DEBUG - 2018-06-30 00:30:57 --> No URI present. Default controller set.
INFO - 2018-06-30 00:30:57 --> Router Class Initialized
INFO - 2018-06-30 00:30:57 --> Output Class Initialized
INFO - 2018-06-30 00:30:57 --> Security Class Initialized
DEBUG - 2018-06-30 00:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 00:30:57 --> CSRF cookie sent
INFO - 2018-06-30 00:30:57 --> Input Class Initialized
INFO - 2018-06-30 00:30:57 --> Language Class Initialized
INFO - 2018-06-30 00:30:57 --> Loader Class Initialized
INFO - 2018-06-30 00:30:57 --> Helper loaded: url_helper
INFO - 2018-06-30 00:30:57 --> Helper loaded: form_helper
INFO - 2018-06-30 00:30:57 --> Helper loaded: language_helper
DEBUG - 2018-06-30 00:30:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 00:30:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 00:30:57 --> User Agent Class Initialized
INFO - 2018-06-30 00:30:57 --> Controller Class Initialized
INFO - 2018-06-30 00:30:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 00:30:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 00:30:57 --> Pixel_Model class loaded
INFO - 2018-06-30 00:30:57 --> Database Driver Class Initialized
INFO - 2018-06-30 00:30:57 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 00:30:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 00:30:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 00:30:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-30 00:30:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 00:30:57 --> Final output sent to browser
DEBUG - 2018-06-30 00:30:57 --> Total execution time: 0.0398
INFO - 2018-06-30 00:30:57 --> Config Class Initialized
INFO - 2018-06-30 00:30:57 --> Hooks Class Initialized
DEBUG - 2018-06-30 00:30:57 --> UTF-8 Support Enabled
INFO - 2018-06-30 00:30:57 --> Utf8 Class Initialized
INFO - 2018-06-30 00:30:57 --> URI Class Initialized
DEBUG - 2018-06-30 00:30:57 --> No URI present. Default controller set.
INFO - 2018-06-30 00:30:57 --> Router Class Initialized
INFO - 2018-06-30 00:30:57 --> Output Class Initialized
INFO - 2018-06-30 00:30:57 --> Security Class Initialized
DEBUG - 2018-06-30 00:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 00:30:57 --> CSRF cookie sent
INFO - 2018-06-30 00:30:57 --> Input Class Initialized
INFO - 2018-06-30 00:30:57 --> Language Class Initialized
INFO - 2018-06-30 00:30:57 --> Loader Class Initialized
INFO - 2018-06-30 00:30:57 --> Helper loaded: url_helper
INFO - 2018-06-30 00:30:57 --> Helper loaded: form_helper
INFO - 2018-06-30 00:30:57 --> Helper loaded: language_helper
DEBUG - 2018-06-30 00:30:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 00:30:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 00:30:57 --> User Agent Class Initialized
INFO - 2018-06-30 00:30:57 --> Controller Class Initialized
INFO - 2018-06-30 00:30:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 00:30:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 00:30:57 --> Pixel_Model class loaded
INFO - 2018-06-30 00:30:57 --> Database Driver Class Initialized
INFO - 2018-06-30 00:30:57 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 00:30:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 00:30:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 00:30:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-30 00:30:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 00:30:57 --> Final output sent to browser
DEBUG - 2018-06-30 00:30:57 --> Total execution time: 0.0280
INFO - 2018-06-30 01:50:16 --> Config Class Initialized
INFO - 2018-06-30 01:50:16 --> Hooks Class Initialized
DEBUG - 2018-06-30 01:50:16 --> UTF-8 Support Enabled
INFO - 2018-06-30 01:50:16 --> Utf8 Class Initialized
INFO - 2018-06-30 01:50:16 --> URI Class Initialized
DEBUG - 2018-06-30 01:50:16 --> No URI present. Default controller set.
INFO - 2018-06-30 01:50:16 --> Router Class Initialized
INFO - 2018-06-30 01:50:16 --> Output Class Initialized
INFO - 2018-06-30 01:50:16 --> Security Class Initialized
DEBUG - 2018-06-30 01:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 01:50:16 --> CSRF cookie sent
INFO - 2018-06-30 01:50:16 --> Input Class Initialized
INFO - 2018-06-30 01:50:16 --> Language Class Initialized
INFO - 2018-06-30 01:50:16 --> Loader Class Initialized
INFO - 2018-06-30 01:50:16 --> Helper loaded: url_helper
INFO - 2018-06-30 01:50:16 --> Helper loaded: form_helper
INFO - 2018-06-30 01:50:16 --> Helper loaded: language_helper
DEBUG - 2018-06-30 01:50:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 01:50:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 01:50:16 --> User Agent Class Initialized
INFO - 2018-06-30 01:50:16 --> Controller Class Initialized
INFO - 2018-06-30 01:50:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 01:50:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 01:50:16 --> Pixel_Model class loaded
INFO - 2018-06-30 01:50:16 --> Database Driver Class Initialized
INFO - 2018-06-30 01:50:16 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 01:50:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 01:50:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 01:50:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-30 01:50:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 01:50:16 --> Final output sent to browser
DEBUG - 2018-06-30 01:50:16 --> Total execution time: 0.0328
INFO - 2018-06-30 03:34:00 --> Config Class Initialized
INFO - 2018-06-30 03:34:00 --> Hooks Class Initialized
DEBUG - 2018-06-30 03:34:00 --> UTF-8 Support Enabled
INFO - 2018-06-30 03:34:00 --> Utf8 Class Initialized
INFO - 2018-06-30 03:34:00 --> URI Class Initialized
INFO - 2018-06-30 03:34:00 --> Router Class Initialized
INFO - 2018-06-30 03:34:00 --> Output Class Initialized
INFO - 2018-06-30 03:34:00 --> Security Class Initialized
DEBUG - 2018-06-30 03:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 03:34:00 --> CSRF cookie sent
INFO - 2018-06-30 03:34:00 --> Input Class Initialized
INFO - 2018-06-30 03:34:00 --> Language Class Initialized
ERROR - 2018-06-30 03:34:00 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-06-30 03:34:03 --> Config Class Initialized
INFO - 2018-06-30 03:34:03 --> Hooks Class Initialized
DEBUG - 2018-06-30 03:34:03 --> UTF-8 Support Enabled
INFO - 2018-06-30 03:34:03 --> Utf8 Class Initialized
INFO - 2018-06-30 03:34:03 --> URI Class Initialized
INFO - 2018-06-30 03:34:03 --> Router Class Initialized
INFO - 2018-06-30 03:34:03 --> Output Class Initialized
INFO - 2018-06-30 03:34:03 --> Security Class Initialized
DEBUG - 2018-06-30 03:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 03:34:03 --> CSRF cookie sent
INFO - 2018-06-30 03:34:03 --> Input Class Initialized
INFO - 2018-06-30 03:34:03 --> Language Class Initialized
INFO - 2018-06-30 03:34:03 --> Loader Class Initialized
INFO - 2018-06-30 03:34:03 --> Helper loaded: url_helper
INFO - 2018-06-30 03:34:03 --> Helper loaded: form_helper
INFO - 2018-06-30 03:34:03 --> Helper loaded: language_helper
DEBUG - 2018-06-30 03:34:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 03:34:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 03:34:03 --> User Agent Class Initialized
INFO - 2018-06-30 03:34:03 --> Controller Class Initialized
INFO - 2018-06-30 03:34:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 03:34:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 03:34:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 03:34:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 03:34:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 03:34:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 03:34:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/consultant.php
INFO - 2018-06-30 03:34:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 03:34:03 --> Final output sent to browser
DEBUG - 2018-06-30 03:34:03 --> Total execution time: 0.0216
INFO - 2018-06-30 04:27:45 --> Config Class Initialized
INFO - 2018-06-30 04:27:45 --> Hooks Class Initialized
DEBUG - 2018-06-30 04:27:45 --> UTF-8 Support Enabled
INFO - 2018-06-30 04:27:45 --> Utf8 Class Initialized
INFO - 2018-06-30 04:27:45 --> URI Class Initialized
DEBUG - 2018-06-30 04:27:45 --> No URI present. Default controller set.
INFO - 2018-06-30 04:27:45 --> Router Class Initialized
INFO - 2018-06-30 04:27:45 --> Output Class Initialized
INFO - 2018-06-30 04:27:45 --> Security Class Initialized
DEBUG - 2018-06-30 04:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 04:27:45 --> CSRF cookie sent
INFO - 2018-06-30 04:27:45 --> Input Class Initialized
INFO - 2018-06-30 04:27:45 --> Language Class Initialized
INFO - 2018-06-30 04:27:45 --> Loader Class Initialized
INFO - 2018-06-30 04:27:45 --> Helper loaded: url_helper
INFO - 2018-06-30 04:27:45 --> Helper loaded: form_helper
INFO - 2018-06-30 04:27:45 --> Helper loaded: language_helper
DEBUG - 2018-06-30 04:27:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 04:27:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 04:27:45 --> User Agent Class Initialized
INFO - 2018-06-30 04:27:45 --> Controller Class Initialized
INFO - 2018-06-30 04:27:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 04:27:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 04:27:45 --> Pixel_Model class loaded
INFO - 2018-06-30 04:27:45 --> Database Driver Class Initialized
INFO - 2018-06-30 04:27:45 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 04:27:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 04:27:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 04:27:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-30 04:27:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 04:27:45 --> Final output sent to browser
DEBUG - 2018-06-30 04:27:45 --> Total execution time: 0.0346
INFO - 2018-06-30 04:27:50 --> Config Class Initialized
INFO - 2018-06-30 04:27:50 --> Hooks Class Initialized
DEBUG - 2018-06-30 04:27:50 --> UTF-8 Support Enabled
INFO - 2018-06-30 04:27:50 --> Utf8 Class Initialized
INFO - 2018-06-30 04:27:50 --> URI Class Initialized
INFO - 2018-06-30 04:27:50 --> Router Class Initialized
INFO - 2018-06-30 04:27:50 --> Output Class Initialized
INFO - 2018-06-30 04:27:50 --> Security Class Initialized
DEBUG - 2018-06-30 04:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 04:27:50 --> CSRF cookie sent
INFO - 2018-06-30 04:27:50 --> Input Class Initialized
INFO - 2018-06-30 04:27:50 --> Language Class Initialized
ERROR - 2018-06-30 04:27:50 --> 404 Page Not Found: Apple-touch-icon-120x120-precomposedpng/index
INFO - 2018-06-30 04:27:50 --> Config Class Initialized
INFO - 2018-06-30 04:27:50 --> Hooks Class Initialized
DEBUG - 2018-06-30 04:27:50 --> UTF-8 Support Enabled
INFO - 2018-06-30 04:27:50 --> Utf8 Class Initialized
INFO - 2018-06-30 04:27:50 --> URI Class Initialized
INFO - 2018-06-30 04:27:50 --> Router Class Initialized
INFO - 2018-06-30 04:27:50 --> Output Class Initialized
INFO - 2018-06-30 04:27:50 --> Security Class Initialized
DEBUG - 2018-06-30 04:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 04:27:50 --> CSRF cookie sent
INFO - 2018-06-30 04:27:50 --> Input Class Initialized
INFO - 2018-06-30 04:27:50 --> Language Class Initialized
ERROR - 2018-06-30 04:27:50 --> 404 Page Not Found: Apple-touch-icon-120x120png/index
INFO - 2018-06-30 04:27:50 --> Config Class Initialized
INFO - 2018-06-30 04:27:50 --> Hooks Class Initialized
DEBUG - 2018-06-30 04:27:50 --> UTF-8 Support Enabled
INFO - 2018-06-30 04:27:50 --> Utf8 Class Initialized
INFO - 2018-06-30 04:27:50 --> URI Class Initialized
INFO - 2018-06-30 04:27:50 --> Router Class Initialized
INFO - 2018-06-30 04:27:50 --> Output Class Initialized
INFO - 2018-06-30 04:27:50 --> Security Class Initialized
DEBUG - 2018-06-30 04:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 04:27:50 --> CSRF cookie sent
INFO - 2018-06-30 04:27:50 --> Input Class Initialized
INFO - 2018-06-30 04:27:50 --> Language Class Initialized
ERROR - 2018-06-30 04:27:50 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
INFO - 2018-06-30 04:27:50 --> Config Class Initialized
INFO - 2018-06-30 04:27:50 --> Hooks Class Initialized
DEBUG - 2018-06-30 04:27:50 --> UTF-8 Support Enabled
INFO - 2018-06-30 04:27:50 --> Utf8 Class Initialized
INFO - 2018-06-30 04:27:50 --> URI Class Initialized
INFO - 2018-06-30 04:27:50 --> Router Class Initialized
INFO - 2018-06-30 04:27:50 --> Output Class Initialized
INFO - 2018-06-30 04:27:50 --> Security Class Initialized
DEBUG - 2018-06-30 04:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 04:27:50 --> CSRF cookie sent
INFO - 2018-06-30 04:27:50 --> Input Class Initialized
INFO - 2018-06-30 04:27:50 --> Language Class Initialized
ERROR - 2018-06-30 04:27:50 --> 404 Page Not Found: Apple-touch-iconpng/index
INFO - 2018-06-30 05:41:37 --> Config Class Initialized
INFO - 2018-06-30 05:41:37 --> Hooks Class Initialized
DEBUG - 2018-06-30 05:41:37 --> UTF-8 Support Enabled
INFO - 2018-06-30 05:41:37 --> Utf8 Class Initialized
INFO - 2018-06-30 05:41:37 --> URI Class Initialized
INFO - 2018-06-30 05:41:37 --> Router Class Initialized
INFO - 2018-06-30 05:41:37 --> Output Class Initialized
INFO - 2018-06-30 05:41:37 --> Security Class Initialized
DEBUG - 2018-06-30 05:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 05:41:37 --> CSRF cookie sent
INFO - 2018-06-30 05:41:37 --> Input Class Initialized
INFO - 2018-06-30 05:41:37 --> Language Class Initialized
INFO - 2018-06-30 05:41:37 --> Loader Class Initialized
INFO - 2018-06-30 05:41:37 --> Helper loaded: url_helper
INFO - 2018-06-30 05:41:37 --> Helper loaded: form_helper
INFO - 2018-06-30 05:41:37 --> Helper loaded: language_helper
DEBUG - 2018-06-30 05:41:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 05:41:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 05:41:37 --> User Agent Class Initialized
INFO - 2018-06-30 05:41:37 --> Controller Class Initialized
INFO - 2018-06-30 05:41:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 05:41:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 05:41:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 05:41:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 05:41:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 05:41:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 05:41:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/teacher.php
INFO - 2018-06-30 05:41:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 05:41:37 --> Final output sent to browser
DEBUG - 2018-06-30 05:41:37 --> Total execution time: 0.0205
INFO - 2018-06-30 06:10:01 --> Config Class Initialized
INFO - 2018-06-30 06:10:01 --> Hooks Class Initialized
DEBUG - 2018-06-30 06:10:01 --> UTF-8 Support Enabled
INFO - 2018-06-30 06:10:01 --> Utf8 Class Initialized
INFO - 2018-06-30 06:10:01 --> URI Class Initialized
INFO - 2018-06-30 06:10:01 --> Router Class Initialized
INFO - 2018-06-30 06:10:01 --> Output Class Initialized
INFO - 2018-06-30 06:10:01 --> Security Class Initialized
DEBUG - 2018-06-30 06:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 06:10:01 --> CSRF cookie sent
INFO - 2018-06-30 06:10:01 --> Input Class Initialized
INFO - 2018-06-30 06:10:01 --> Language Class Initialized
INFO - 2018-06-30 06:10:01 --> Loader Class Initialized
INFO - 2018-06-30 06:10:01 --> Helper loaded: url_helper
INFO - 2018-06-30 06:10:01 --> Helper loaded: form_helper
INFO - 2018-06-30 06:10:01 --> Helper loaded: language_helper
DEBUG - 2018-06-30 06:10:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 06:10:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 06:10:01 --> User Agent Class Initialized
INFO - 2018-06-30 06:10:01 --> Controller Class Initialized
INFO - 2018-06-30 06:10:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 06:10:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 06:10:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 06:10:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 06:10:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 06:10:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 06:10:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-06-30 06:10:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 06:10:01 --> Final output sent to browser
DEBUG - 2018-06-30 06:10:01 --> Total execution time: 0.0676
INFO - 2018-06-30 06:31:30 --> Config Class Initialized
INFO - 2018-06-30 06:31:30 --> Hooks Class Initialized
DEBUG - 2018-06-30 06:31:30 --> UTF-8 Support Enabled
INFO - 2018-06-30 06:31:30 --> Utf8 Class Initialized
INFO - 2018-06-30 06:31:30 --> URI Class Initialized
INFO - 2018-06-30 06:31:30 --> Router Class Initialized
INFO - 2018-06-30 06:31:30 --> Output Class Initialized
INFO - 2018-06-30 06:31:30 --> Security Class Initialized
DEBUG - 2018-06-30 06:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 06:31:30 --> CSRF cookie sent
INFO - 2018-06-30 06:31:30 --> Input Class Initialized
INFO - 2018-06-30 06:31:30 --> Language Class Initialized
ERROR - 2018-06-30 06:31:30 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-06-30 06:31:34 --> Config Class Initialized
INFO - 2018-06-30 06:31:34 --> Hooks Class Initialized
DEBUG - 2018-06-30 06:31:34 --> UTF-8 Support Enabled
INFO - 2018-06-30 06:31:34 --> Utf8 Class Initialized
INFO - 2018-06-30 06:31:34 --> URI Class Initialized
INFO - 2018-06-30 06:31:34 --> Router Class Initialized
INFO - 2018-06-30 06:31:34 --> Output Class Initialized
INFO - 2018-06-30 06:31:34 --> Security Class Initialized
DEBUG - 2018-06-30 06:31:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 06:31:34 --> CSRF cookie sent
INFO - 2018-06-30 06:31:34 --> Input Class Initialized
INFO - 2018-06-30 06:31:34 --> Language Class Initialized
INFO - 2018-06-30 06:31:34 --> Loader Class Initialized
INFO - 2018-06-30 06:31:34 --> Helper loaded: url_helper
INFO - 2018-06-30 06:31:34 --> Helper loaded: form_helper
INFO - 2018-06-30 06:31:34 --> Helper loaded: language_helper
DEBUG - 2018-06-30 06:31:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 06:31:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 06:31:34 --> User Agent Class Initialized
INFO - 2018-06-30 06:31:34 --> Controller Class Initialized
INFO - 2018-06-30 06:31:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 06:31:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 06:31:34 --> Pixel_Model class loaded
INFO - 2018-06-30 06:31:34 --> Database Driver Class Initialized
INFO - 2018-06-30 06:31:34 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 06:31:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 06:31:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 06:31:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 06:31:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 06:31:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/buy_gift.php
INFO - 2018-06-30 06:31:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 06:31:34 --> Final output sent to browser
DEBUG - 2018-06-30 06:31:34 --> Total execution time: 0.0370
INFO - 2018-06-30 08:48:18 --> Config Class Initialized
INFO - 2018-06-30 08:48:18 --> Hooks Class Initialized
DEBUG - 2018-06-30 08:48:18 --> UTF-8 Support Enabled
INFO - 2018-06-30 08:48:18 --> Utf8 Class Initialized
INFO - 2018-06-30 08:48:18 --> URI Class Initialized
INFO - 2018-06-30 08:48:18 --> Router Class Initialized
INFO - 2018-06-30 08:48:18 --> Output Class Initialized
INFO - 2018-06-30 08:48:18 --> Security Class Initialized
DEBUG - 2018-06-30 08:48:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 08:48:18 --> CSRF cookie sent
INFO - 2018-06-30 08:48:18 --> Input Class Initialized
INFO - 2018-06-30 08:48:18 --> Language Class Initialized
INFO - 2018-06-30 08:48:18 --> Loader Class Initialized
INFO - 2018-06-30 08:48:18 --> Helper loaded: url_helper
INFO - 2018-06-30 08:48:18 --> Helper loaded: form_helper
INFO - 2018-06-30 08:48:18 --> Helper loaded: language_helper
DEBUG - 2018-06-30 08:48:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 08:48:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 08:48:18 --> User Agent Class Initialized
INFO - 2018-06-30 08:48:18 --> Controller Class Initialized
INFO - 2018-06-30 08:48:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 08:48:18 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-30 08:48:18 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-30 08:48:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 08:48:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 08:48:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 08:48:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-30 08:48:18 --> Could not find the language line "req_email"
INFO - 2018-06-30 08:48:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-06-30 08:48:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 08:48:18 --> Final output sent to browser
DEBUG - 2018-06-30 08:48:18 --> Total execution time: 0.0231
INFO - 2018-06-30 09:40:29 --> Config Class Initialized
INFO - 2018-06-30 09:40:29 --> Hooks Class Initialized
DEBUG - 2018-06-30 09:40:29 --> UTF-8 Support Enabled
INFO - 2018-06-30 09:40:29 --> Utf8 Class Initialized
INFO - 2018-06-30 09:40:29 --> URI Class Initialized
INFO - 2018-06-30 09:40:29 --> Router Class Initialized
INFO - 2018-06-30 09:40:29 --> Output Class Initialized
INFO - 2018-06-30 09:40:29 --> Security Class Initialized
DEBUG - 2018-06-30 09:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 09:40:29 --> CSRF cookie sent
INFO - 2018-06-30 09:40:29 --> Input Class Initialized
INFO - 2018-06-30 09:40:29 --> Language Class Initialized
ERROR - 2018-06-30 09:40:29 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-06-30 09:40:33 --> Config Class Initialized
INFO - 2018-06-30 09:40:33 --> Hooks Class Initialized
DEBUG - 2018-06-30 09:40:33 --> UTF-8 Support Enabled
INFO - 2018-06-30 09:40:33 --> Utf8 Class Initialized
INFO - 2018-06-30 09:40:33 --> URI Class Initialized
DEBUG - 2018-06-30 09:40:33 --> No URI present. Default controller set.
INFO - 2018-06-30 09:40:33 --> Router Class Initialized
INFO - 2018-06-30 09:40:33 --> Output Class Initialized
INFO - 2018-06-30 09:40:33 --> Security Class Initialized
DEBUG - 2018-06-30 09:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 09:40:33 --> CSRF cookie sent
INFO - 2018-06-30 09:40:33 --> Input Class Initialized
INFO - 2018-06-30 09:40:33 --> Language Class Initialized
INFO - 2018-06-30 09:40:33 --> Loader Class Initialized
INFO - 2018-06-30 09:40:33 --> Helper loaded: url_helper
INFO - 2018-06-30 09:40:33 --> Helper loaded: form_helper
INFO - 2018-06-30 09:40:33 --> Helper loaded: language_helper
DEBUG - 2018-06-30 09:40:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 09:40:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 09:40:33 --> User Agent Class Initialized
INFO - 2018-06-30 09:40:33 --> Controller Class Initialized
INFO - 2018-06-30 09:40:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 09:40:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 09:40:33 --> Pixel_Model class loaded
INFO - 2018-06-30 09:40:33 --> Database Driver Class Initialized
INFO - 2018-06-30 09:40:33 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 09:40:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 09:40:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 09:40:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-30 09:40:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 09:40:33 --> Final output sent to browser
DEBUG - 2018-06-30 09:40:33 --> Total execution time: 0.0343
INFO - 2018-06-30 09:46:05 --> Config Class Initialized
INFO - 2018-06-30 09:46:05 --> Hooks Class Initialized
DEBUG - 2018-06-30 09:46:05 --> UTF-8 Support Enabled
INFO - 2018-06-30 09:46:05 --> Utf8 Class Initialized
INFO - 2018-06-30 09:46:05 --> URI Class Initialized
INFO - 2018-06-30 09:46:05 --> Router Class Initialized
INFO - 2018-06-30 09:46:05 --> Output Class Initialized
INFO - 2018-06-30 09:46:05 --> Security Class Initialized
DEBUG - 2018-06-30 09:46:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 09:46:05 --> CSRF cookie sent
INFO - 2018-06-30 09:46:05 --> Input Class Initialized
INFO - 2018-06-30 09:46:05 --> Language Class Initialized
ERROR - 2018-06-30 09:46:05 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-06-30 09:47:51 --> Config Class Initialized
INFO - 2018-06-30 09:47:51 --> Hooks Class Initialized
DEBUG - 2018-06-30 09:47:51 --> UTF-8 Support Enabled
INFO - 2018-06-30 09:47:51 --> Utf8 Class Initialized
INFO - 2018-06-30 09:47:51 --> URI Class Initialized
DEBUG - 2018-06-30 09:47:51 --> No URI present. Default controller set.
INFO - 2018-06-30 09:47:51 --> Router Class Initialized
INFO - 2018-06-30 09:47:51 --> Output Class Initialized
INFO - 2018-06-30 09:47:51 --> Security Class Initialized
DEBUG - 2018-06-30 09:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 09:47:51 --> CSRF cookie sent
INFO - 2018-06-30 09:47:51 --> Input Class Initialized
INFO - 2018-06-30 09:47:51 --> Language Class Initialized
INFO - 2018-06-30 09:47:51 --> Loader Class Initialized
INFO - 2018-06-30 09:47:51 --> Helper loaded: url_helper
INFO - 2018-06-30 09:47:51 --> Helper loaded: form_helper
INFO - 2018-06-30 09:47:51 --> Helper loaded: language_helper
DEBUG - 2018-06-30 09:47:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 09:47:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 09:47:51 --> User Agent Class Initialized
INFO - 2018-06-30 09:47:51 --> Controller Class Initialized
INFO - 2018-06-30 09:47:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 09:47:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 09:47:51 --> Pixel_Model class loaded
INFO - 2018-06-30 09:47:51 --> Database Driver Class Initialized
INFO - 2018-06-30 09:47:51 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 09:47:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 09:47:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 09:47:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-30 09:47:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 09:47:51 --> Final output sent to browser
DEBUG - 2018-06-30 09:47:51 --> Total execution time: 0.0386
INFO - 2018-06-30 09:57:42 --> Config Class Initialized
INFO - 2018-06-30 09:57:42 --> Hooks Class Initialized
DEBUG - 2018-06-30 09:57:42 --> UTF-8 Support Enabled
INFO - 2018-06-30 09:57:42 --> Utf8 Class Initialized
INFO - 2018-06-30 09:57:42 --> URI Class Initialized
INFO - 2018-06-30 09:57:42 --> Router Class Initialized
INFO - 2018-06-30 09:57:42 --> Output Class Initialized
INFO - 2018-06-30 09:57:42 --> Security Class Initialized
DEBUG - 2018-06-30 09:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 09:57:42 --> CSRF cookie sent
INFO - 2018-06-30 09:57:42 --> Input Class Initialized
INFO - 2018-06-30 09:57:42 --> Language Class Initialized
INFO - 2018-06-30 09:57:42 --> Loader Class Initialized
INFO - 2018-06-30 09:57:42 --> Helper loaded: url_helper
INFO - 2018-06-30 09:57:42 --> Helper loaded: form_helper
INFO - 2018-06-30 09:57:42 --> Helper loaded: language_helper
DEBUG - 2018-06-30 09:57:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 09:57:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 09:57:42 --> User Agent Class Initialized
INFO - 2018-06-30 09:57:42 --> Controller Class Initialized
INFO - 2018-06-30 09:57:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 09:57:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 09:57:42 --> Pixel_Model class loaded
INFO - 2018-06-30 09:57:42 --> Database Driver Class Initialized
INFO - 2018-06-30 09:57:42 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 09:57:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 09:57:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 09:57:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 09:57:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 09:57:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/buy_gift.php
INFO - 2018-06-30 09:57:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 09:57:42 --> Final output sent to browser
DEBUG - 2018-06-30 09:57:42 --> Total execution time: 0.0369
INFO - 2018-06-30 10:21:07 --> Config Class Initialized
INFO - 2018-06-30 10:21:07 --> Hooks Class Initialized
DEBUG - 2018-06-30 10:21:07 --> UTF-8 Support Enabled
INFO - 2018-06-30 10:21:07 --> Utf8 Class Initialized
INFO - 2018-06-30 10:21:07 --> URI Class Initialized
DEBUG - 2018-06-30 10:21:07 --> No URI present. Default controller set.
INFO - 2018-06-30 10:21:07 --> Router Class Initialized
INFO - 2018-06-30 10:21:07 --> Output Class Initialized
INFO - 2018-06-30 10:21:07 --> Security Class Initialized
DEBUG - 2018-06-30 10:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 10:21:07 --> CSRF cookie sent
INFO - 2018-06-30 10:21:07 --> Input Class Initialized
INFO - 2018-06-30 10:21:07 --> Language Class Initialized
INFO - 2018-06-30 10:21:07 --> Loader Class Initialized
INFO - 2018-06-30 10:21:07 --> Helper loaded: url_helper
INFO - 2018-06-30 10:21:07 --> Helper loaded: form_helper
INFO - 2018-06-30 10:21:07 --> Helper loaded: language_helper
DEBUG - 2018-06-30 10:21:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 10:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 10:21:07 --> User Agent Class Initialized
INFO - 2018-06-30 10:21:07 --> Controller Class Initialized
INFO - 2018-06-30 10:21:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 10:21:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 10:21:07 --> Pixel_Model class loaded
INFO - 2018-06-30 10:21:07 --> Database Driver Class Initialized
INFO - 2018-06-30 10:21:07 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 10:21:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 10:21:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 10:21:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-30 10:21:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 10:21:07 --> Final output sent to browser
DEBUG - 2018-06-30 10:21:07 --> Total execution time: 0.0349
INFO - 2018-06-30 10:52:43 --> Config Class Initialized
INFO - 2018-06-30 10:52:43 --> Hooks Class Initialized
DEBUG - 2018-06-30 10:52:43 --> UTF-8 Support Enabled
INFO - 2018-06-30 10:52:43 --> Utf8 Class Initialized
INFO - 2018-06-30 10:52:43 --> URI Class Initialized
INFO - 2018-06-30 10:52:43 --> Router Class Initialized
INFO - 2018-06-30 10:52:43 --> Output Class Initialized
INFO - 2018-06-30 10:52:43 --> Security Class Initialized
DEBUG - 2018-06-30 10:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 10:52:43 --> CSRF cookie sent
INFO - 2018-06-30 10:52:43 --> Input Class Initialized
INFO - 2018-06-30 10:52:43 --> Language Class Initialized
INFO - 2018-06-30 10:52:43 --> Loader Class Initialized
INFO - 2018-06-30 10:52:43 --> Helper loaded: url_helper
INFO - 2018-06-30 10:52:43 --> Helper loaded: form_helper
INFO - 2018-06-30 10:52:43 --> Helper loaded: language_helper
DEBUG - 2018-06-30 10:52:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 10:52:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 10:52:43 --> User Agent Class Initialized
INFO - 2018-06-30 10:52:43 --> Controller Class Initialized
INFO - 2018-06-30 10:52:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 10:52:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 10:52:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 10:52:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 10:52:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 10:52:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 10:52:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-06-30 10:52:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 10:52:43 --> Final output sent to browser
DEBUG - 2018-06-30 10:52:43 --> Total execution time: 0.0353
INFO - 2018-06-30 11:11:22 --> Config Class Initialized
INFO - 2018-06-30 11:11:22 --> Hooks Class Initialized
DEBUG - 2018-06-30 11:11:22 --> UTF-8 Support Enabled
INFO - 2018-06-30 11:11:22 --> Utf8 Class Initialized
INFO - 2018-06-30 11:11:22 --> URI Class Initialized
DEBUG - 2018-06-30 11:11:22 --> No URI present. Default controller set.
INFO - 2018-06-30 11:11:22 --> Router Class Initialized
INFO - 2018-06-30 11:11:22 --> Output Class Initialized
INFO - 2018-06-30 11:11:22 --> Security Class Initialized
DEBUG - 2018-06-30 11:11:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 11:11:22 --> CSRF cookie sent
INFO - 2018-06-30 11:11:22 --> Input Class Initialized
INFO - 2018-06-30 11:11:22 --> Language Class Initialized
INFO - 2018-06-30 11:11:22 --> Loader Class Initialized
INFO - 2018-06-30 11:11:22 --> Helper loaded: url_helper
INFO - 2018-06-30 11:11:22 --> Helper loaded: form_helper
INFO - 2018-06-30 11:11:22 --> Helper loaded: language_helper
DEBUG - 2018-06-30 11:11:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 11:11:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 11:11:22 --> User Agent Class Initialized
INFO - 2018-06-30 11:11:22 --> Controller Class Initialized
INFO - 2018-06-30 11:11:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 11:11:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 11:11:22 --> Pixel_Model class loaded
INFO - 2018-06-30 11:11:22 --> Database Driver Class Initialized
INFO - 2018-06-30 11:11:22 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 11:11:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 11:11:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 11:11:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-30 11:11:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 11:11:22 --> Final output sent to browser
DEBUG - 2018-06-30 11:11:22 --> Total execution time: 0.0380
INFO - 2018-06-30 11:11:27 --> Config Class Initialized
INFO - 2018-06-30 11:11:27 --> Hooks Class Initialized
DEBUG - 2018-06-30 11:11:27 --> UTF-8 Support Enabled
INFO - 2018-06-30 11:11:27 --> Utf8 Class Initialized
INFO - 2018-06-30 11:11:27 --> URI Class Initialized
INFO - 2018-06-30 11:11:27 --> Router Class Initialized
INFO - 2018-06-30 11:11:27 --> Output Class Initialized
INFO - 2018-06-30 11:11:27 --> Security Class Initialized
DEBUG - 2018-06-30 11:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 11:11:27 --> CSRF cookie sent
INFO - 2018-06-30 11:11:27 --> Input Class Initialized
INFO - 2018-06-30 11:11:27 --> Language Class Initialized
INFO - 2018-06-30 11:11:27 --> Loader Class Initialized
INFO - 2018-06-30 11:11:27 --> Helper loaded: url_helper
INFO - 2018-06-30 11:11:27 --> Helper loaded: form_helper
INFO - 2018-06-30 11:11:27 --> Helper loaded: language_helper
DEBUG - 2018-06-30 11:11:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 11:11:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 11:11:27 --> User Agent Class Initialized
INFO - 2018-06-30 11:11:27 --> Controller Class Initialized
INFO - 2018-06-30 11:11:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 11:11:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 11:11:27 --> Pixel_Model class loaded
INFO - 2018-06-30 11:11:27 --> Database Driver Class Initialized
INFO - 2018-06-30 11:11:27 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 11:11:27 --> Config Class Initialized
INFO - 2018-06-30 11:11:27 --> Hooks Class Initialized
DEBUG - 2018-06-30 11:11:27 --> UTF-8 Support Enabled
INFO - 2018-06-30 11:11:27 --> Utf8 Class Initialized
INFO - 2018-06-30 11:11:27 --> URI Class Initialized
INFO - 2018-06-30 11:11:27 --> Router Class Initialized
INFO - 2018-06-30 11:11:27 --> Output Class Initialized
INFO - 2018-06-30 11:11:27 --> Security Class Initialized
DEBUG - 2018-06-30 11:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 11:11:27 --> CSRF cookie sent
INFO - 2018-06-30 11:11:27 --> Input Class Initialized
INFO - 2018-06-30 11:11:27 --> Language Class Initialized
INFO - 2018-06-30 11:11:27 --> Loader Class Initialized
INFO - 2018-06-30 11:11:27 --> Helper loaded: url_helper
INFO - 2018-06-30 11:11:27 --> Helper loaded: form_helper
INFO - 2018-06-30 11:11:27 --> Helper loaded: language_helper
DEBUG - 2018-06-30 11:11:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 11:11:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 11:11:27 --> User Agent Class Initialized
INFO - 2018-06-30 11:11:27 --> Controller Class Initialized
INFO - 2018-06-30 11:11:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 11:11:27 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-30 11:11:27 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-30 11:11:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 11:11:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 11:11:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 11:11:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-30 11:11:27 --> Could not find the language line "req_email"
INFO - 2018-06-30 11:11:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-06-30 11:11:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 11:11:27 --> Final output sent to browser
DEBUG - 2018-06-30 11:11:27 --> Total execution time: 0.0232
INFO - 2018-06-30 11:11:55 --> Config Class Initialized
INFO - 2018-06-30 11:11:55 --> Hooks Class Initialized
DEBUG - 2018-06-30 11:11:55 --> UTF-8 Support Enabled
INFO - 2018-06-30 11:11:55 --> Utf8 Class Initialized
INFO - 2018-06-30 11:11:55 --> URI Class Initialized
DEBUG - 2018-06-30 11:11:55 --> No URI present. Default controller set.
INFO - 2018-06-30 11:11:55 --> Router Class Initialized
INFO - 2018-06-30 11:11:55 --> Output Class Initialized
INFO - 2018-06-30 11:11:55 --> Security Class Initialized
DEBUG - 2018-06-30 11:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 11:11:55 --> CSRF cookie sent
INFO - 2018-06-30 11:11:55 --> Input Class Initialized
INFO - 2018-06-30 11:11:55 --> Language Class Initialized
INFO - 2018-06-30 11:11:55 --> Loader Class Initialized
INFO - 2018-06-30 11:11:55 --> Helper loaded: url_helper
INFO - 2018-06-30 11:11:55 --> Helper loaded: form_helper
INFO - 2018-06-30 11:11:55 --> Helper loaded: language_helper
DEBUG - 2018-06-30 11:11:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 11:11:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 11:11:55 --> User Agent Class Initialized
INFO - 2018-06-30 11:11:55 --> Controller Class Initialized
INFO - 2018-06-30 11:11:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 11:11:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 11:11:55 --> Pixel_Model class loaded
INFO - 2018-06-30 11:11:55 --> Database Driver Class Initialized
INFO - 2018-06-30 11:11:55 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 11:11:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 11:11:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 11:11:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-30 11:11:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 11:11:55 --> Final output sent to browser
DEBUG - 2018-06-30 11:11:55 --> Total execution time: 0.0343
INFO - 2018-06-30 11:12:01 --> Config Class Initialized
INFO - 2018-06-30 11:12:01 --> Hooks Class Initialized
DEBUG - 2018-06-30 11:12:01 --> UTF-8 Support Enabled
INFO - 2018-06-30 11:12:01 --> Utf8 Class Initialized
INFO - 2018-06-30 11:12:01 --> URI Class Initialized
INFO - 2018-06-30 11:12:01 --> Router Class Initialized
INFO - 2018-06-30 11:12:01 --> Output Class Initialized
INFO - 2018-06-30 11:12:01 --> Security Class Initialized
DEBUG - 2018-06-30 11:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 11:12:01 --> CSRF cookie sent
INFO - 2018-06-30 11:12:01 --> CSRF token verified
INFO - 2018-06-30 11:12:01 --> Input Class Initialized
INFO - 2018-06-30 11:12:01 --> Language Class Initialized
INFO - 2018-06-30 11:12:01 --> Loader Class Initialized
INFO - 2018-06-30 11:12:01 --> Helper loaded: url_helper
INFO - 2018-06-30 11:12:01 --> Helper loaded: form_helper
INFO - 2018-06-30 11:12:01 --> Helper loaded: language_helper
DEBUG - 2018-06-30 11:12:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 11:12:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 11:12:01 --> User Agent Class Initialized
INFO - 2018-06-30 11:12:01 --> Controller Class Initialized
INFO - 2018-06-30 11:12:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 11:12:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 11:12:01 --> Pixel_Model class loaded
INFO - 2018-06-30 11:12:01 --> Database Driver Class Initialized
INFO - 2018-06-30 11:12:01 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 11:12:01 --> Config Class Initialized
INFO - 2018-06-30 11:12:01 --> Hooks Class Initialized
DEBUG - 2018-06-30 11:12:01 --> UTF-8 Support Enabled
INFO - 2018-06-30 11:12:01 --> Utf8 Class Initialized
INFO - 2018-06-30 11:12:01 --> URI Class Initialized
INFO - 2018-06-30 11:12:01 --> Router Class Initialized
INFO - 2018-06-30 11:12:01 --> Output Class Initialized
INFO - 2018-06-30 11:12:01 --> Security Class Initialized
DEBUG - 2018-06-30 11:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 11:12:01 --> CSRF cookie sent
INFO - 2018-06-30 11:12:01 --> Input Class Initialized
INFO - 2018-06-30 11:12:01 --> Language Class Initialized
INFO - 2018-06-30 11:12:01 --> Loader Class Initialized
INFO - 2018-06-30 11:12:01 --> Helper loaded: url_helper
INFO - 2018-06-30 11:12:01 --> Helper loaded: form_helper
INFO - 2018-06-30 11:12:01 --> Helper loaded: language_helper
DEBUG - 2018-06-30 11:12:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 11:12:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 11:12:01 --> User Agent Class Initialized
INFO - 2018-06-30 11:12:01 --> Controller Class Initialized
INFO - 2018-06-30 11:12:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 11:12:01 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-30 11:12:01 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-30 11:12:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 11:12:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 11:12:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 11:12:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-30 11:12:01 --> Could not find the language line "req_email"
INFO - 2018-06-30 11:12:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-06-30 11:12:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 11:12:01 --> Final output sent to browser
DEBUG - 2018-06-30 11:12:01 --> Total execution time: 0.0448
INFO - 2018-06-30 12:19:31 --> Config Class Initialized
INFO - 2018-06-30 12:19:31 --> Hooks Class Initialized
DEBUG - 2018-06-30 12:19:31 --> UTF-8 Support Enabled
INFO - 2018-06-30 12:19:31 --> Utf8 Class Initialized
INFO - 2018-06-30 12:19:31 --> URI Class Initialized
DEBUG - 2018-06-30 12:19:31 --> No URI present. Default controller set.
INFO - 2018-06-30 12:19:31 --> Router Class Initialized
INFO - 2018-06-30 12:19:31 --> Output Class Initialized
INFO - 2018-06-30 12:19:31 --> Security Class Initialized
DEBUG - 2018-06-30 12:19:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 12:19:31 --> CSRF cookie sent
INFO - 2018-06-30 12:19:31 --> Input Class Initialized
INFO - 2018-06-30 12:19:31 --> Language Class Initialized
INFO - 2018-06-30 12:19:31 --> Loader Class Initialized
INFO - 2018-06-30 12:19:31 --> Helper loaded: url_helper
INFO - 2018-06-30 12:19:31 --> Helper loaded: form_helper
INFO - 2018-06-30 12:19:31 --> Helper loaded: language_helper
DEBUG - 2018-06-30 12:19:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 12:19:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 12:19:31 --> User Agent Class Initialized
INFO - 2018-06-30 12:19:31 --> Controller Class Initialized
INFO - 2018-06-30 12:19:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 12:19:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 12:19:31 --> Pixel_Model class loaded
INFO - 2018-06-30 12:19:31 --> Database Driver Class Initialized
INFO - 2018-06-30 12:19:31 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 12:19:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 12:19:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 12:19:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-30 12:19:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 12:19:31 --> Final output sent to browser
DEBUG - 2018-06-30 12:19:31 --> Total execution time: 0.0345
INFO - 2018-06-30 12:35:24 --> Config Class Initialized
INFO - 2018-06-30 12:35:24 --> Hooks Class Initialized
DEBUG - 2018-06-30 12:35:24 --> UTF-8 Support Enabled
INFO - 2018-06-30 12:35:24 --> Utf8 Class Initialized
INFO - 2018-06-30 12:35:24 --> URI Class Initialized
INFO - 2018-06-30 12:35:24 --> Router Class Initialized
INFO - 2018-06-30 12:35:24 --> Output Class Initialized
INFO - 2018-06-30 12:35:24 --> Security Class Initialized
DEBUG - 2018-06-30 12:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 12:35:24 --> CSRF cookie sent
INFO - 2018-06-30 12:35:24 --> Input Class Initialized
INFO - 2018-06-30 12:35:24 --> Language Class Initialized
INFO - 2018-06-30 12:35:24 --> Loader Class Initialized
INFO - 2018-06-30 12:35:24 --> Helper loaded: url_helper
INFO - 2018-06-30 12:35:24 --> Helper loaded: form_helper
INFO - 2018-06-30 12:35:24 --> Helper loaded: language_helper
DEBUG - 2018-06-30 12:35:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 12:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 12:35:24 --> User Agent Class Initialized
INFO - 2018-06-30 12:35:24 --> Controller Class Initialized
INFO - 2018-06-30 12:35:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 12:35:24 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-30 12:35:24 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-30 12:35:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 12:35:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 12:35:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 12:35:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-30 12:35:24 --> Could not find the language line "req_email"
INFO - 2018-06-30 12:35:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-06-30 12:35:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 12:35:24 --> Final output sent to browser
DEBUG - 2018-06-30 12:35:24 --> Total execution time: 0.0221
INFO - 2018-06-30 12:50:09 --> Config Class Initialized
INFO - 2018-06-30 12:50:09 --> Hooks Class Initialized
DEBUG - 2018-06-30 12:50:09 --> UTF-8 Support Enabled
INFO - 2018-06-30 12:50:09 --> Utf8 Class Initialized
INFO - 2018-06-30 12:50:09 --> URI Class Initialized
INFO - 2018-06-30 12:50:09 --> Router Class Initialized
INFO - 2018-06-30 12:50:09 --> Output Class Initialized
INFO - 2018-06-30 12:50:09 --> Security Class Initialized
DEBUG - 2018-06-30 12:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 12:50:09 --> CSRF cookie sent
INFO - 2018-06-30 12:50:09 --> Input Class Initialized
INFO - 2018-06-30 12:50:09 --> Language Class Initialized
ERROR - 2018-06-30 12:50:09 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-06-30 12:50:13 --> Config Class Initialized
INFO - 2018-06-30 12:50:13 --> Hooks Class Initialized
DEBUG - 2018-06-30 12:50:13 --> UTF-8 Support Enabled
INFO - 2018-06-30 12:50:13 --> Utf8 Class Initialized
INFO - 2018-06-30 12:50:13 --> URI Class Initialized
INFO - 2018-06-30 12:50:13 --> Router Class Initialized
INFO - 2018-06-30 12:50:13 --> Output Class Initialized
INFO - 2018-06-30 12:50:13 --> Security Class Initialized
DEBUG - 2018-06-30 12:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 12:50:13 --> CSRF cookie sent
INFO - 2018-06-30 12:50:13 --> Input Class Initialized
INFO - 2018-06-30 12:50:13 --> Language Class Initialized
INFO - 2018-06-30 12:50:13 --> Loader Class Initialized
INFO - 2018-06-30 12:50:13 --> Helper loaded: url_helper
INFO - 2018-06-30 12:50:13 --> Helper loaded: form_helper
INFO - 2018-06-30 12:50:13 --> Helper loaded: language_helper
DEBUG - 2018-06-30 12:50:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 12:50:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 12:50:13 --> User Agent Class Initialized
INFO - 2018-06-30 12:50:13 --> Controller Class Initialized
INFO - 2018-06-30 12:50:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 12:50:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 12:50:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 12:50:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 12:50:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 12:50:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 12:50:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-06-30 12:50:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 12:50:13 --> Final output sent to browser
DEBUG - 2018-06-30 12:50:13 --> Total execution time: 0.0229
INFO - 2018-06-30 12:59:00 --> Config Class Initialized
INFO - 2018-06-30 12:59:00 --> Hooks Class Initialized
DEBUG - 2018-06-30 12:59:00 --> UTF-8 Support Enabled
INFO - 2018-06-30 12:59:00 --> Utf8 Class Initialized
INFO - 2018-06-30 12:59:00 --> URI Class Initialized
INFO - 2018-06-30 12:59:00 --> Router Class Initialized
INFO - 2018-06-30 12:59:00 --> Output Class Initialized
INFO - 2018-06-30 12:59:00 --> Security Class Initialized
DEBUG - 2018-06-30 12:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 12:59:00 --> CSRF cookie sent
INFO - 2018-06-30 12:59:00 --> Input Class Initialized
INFO - 2018-06-30 12:59:00 --> Language Class Initialized
ERROR - 2018-06-30 12:59:00 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-06-30 12:59:00 --> Config Class Initialized
INFO - 2018-06-30 12:59:00 --> Hooks Class Initialized
DEBUG - 2018-06-30 12:59:00 --> UTF-8 Support Enabled
INFO - 2018-06-30 12:59:00 --> Utf8 Class Initialized
INFO - 2018-06-30 12:59:00 --> URI Class Initialized
DEBUG - 2018-06-30 12:59:00 --> No URI present. Default controller set.
INFO - 2018-06-30 12:59:00 --> Router Class Initialized
INFO - 2018-06-30 12:59:00 --> Output Class Initialized
INFO - 2018-06-30 12:59:00 --> Security Class Initialized
DEBUG - 2018-06-30 12:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 12:59:00 --> CSRF cookie sent
INFO - 2018-06-30 12:59:00 --> Input Class Initialized
INFO - 2018-06-30 12:59:00 --> Language Class Initialized
INFO - 2018-06-30 12:59:00 --> Loader Class Initialized
INFO - 2018-06-30 12:59:00 --> Helper loaded: url_helper
INFO - 2018-06-30 12:59:00 --> Helper loaded: form_helper
INFO - 2018-06-30 12:59:00 --> Helper loaded: language_helper
DEBUG - 2018-06-30 12:59:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 12:59:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 12:59:00 --> User Agent Class Initialized
INFO - 2018-06-30 12:59:00 --> Controller Class Initialized
INFO - 2018-06-30 12:59:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 12:59:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 12:59:00 --> Pixel_Model class loaded
INFO - 2018-06-30 12:59:00 --> Database Driver Class Initialized
INFO - 2018-06-30 12:59:00 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 12:59:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 12:59:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 12:59:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-30 12:59:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 12:59:00 --> Final output sent to browser
DEBUG - 2018-06-30 12:59:00 --> Total execution time: 0.0339
INFO - 2018-06-30 12:59:02 --> Config Class Initialized
INFO - 2018-06-30 12:59:02 --> Hooks Class Initialized
DEBUG - 2018-06-30 12:59:02 --> UTF-8 Support Enabled
INFO - 2018-06-30 12:59:02 --> Utf8 Class Initialized
INFO - 2018-06-30 12:59:02 --> URI Class Initialized
INFO - 2018-06-30 12:59:02 --> Router Class Initialized
INFO - 2018-06-30 12:59:02 --> Output Class Initialized
INFO - 2018-06-30 12:59:02 --> Security Class Initialized
DEBUG - 2018-06-30 12:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 12:59:02 --> CSRF cookie sent
INFO - 2018-06-30 12:59:02 --> Input Class Initialized
INFO - 2018-06-30 12:59:02 --> Language Class Initialized
ERROR - 2018-06-30 12:59:02 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-06-30 13:20:33 --> Config Class Initialized
INFO - 2018-06-30 13:20:33 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:20:33 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:20:33 --> Utf8 Class Initialized
INFO - 2018-06-30 13:20:33 --> URI Class Initialized
DEBUG - 2018-06-30 13:20:33 --> No URI present. Default controller set.
INFO - 2018-06-30 13:20:33 --> Router Class Initialized
INFO - 2018-06-30 13:20:33 --> Output Class Initialized
INFO - 2018-06-30 13:20:33 --> Security Class Initialized
DEBUG - 2018-06-30 13:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:20:33 --> CSRF cookie sent
INFO - 2018-06-30 13:20:33 --> Input Class Initialized
INFO - 2018-06-30 13:20:33 --> Language Class Initialized
INFO - 2018-06-30 13:20:33 --> Loader Class Initialized
INFO - 2018-06-30 13:20:33 --> Helper loaded: url_helper
INFO - 2018-06-30 13:20:33 --> Helper loaded: form_helper
INFO - 2018-06-30 13:20:33 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:20:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:20:33 --> User Agent Class Initialized
INFO - 2018-06-30 13:20:33 --> Controller Class Initialized
INFO - 2018-06-30 13:20:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:20:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:20:33 --> Pixel_Model class loaded
INFO - 2018-06-30 13:20:33 --> Database Driver Class Initialized
INFO - 2018-06-30 13:20:33 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:20:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 13:20:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 13:20:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-30 13:20:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 13:20:33 --> Final output sent to browser
DEBUG - 2018-06-30 13:20:33 --> Total execution time: 0.0341
INFO - 2018-06-30 13:20:33 --> Config Class Initialized
INFO - 2018-06-30 13:20:33 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:20:33 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:20:33 --> Utf8 Class Initialized
INFO - 2018-06-30 13:20:33 --> URI Class Initialized
DEBUG - 2018-06-30 13:20:33 --> No URI present. Default controller set.
INFO - 2018-06-30 13:20:33 --> Router Class Initialized
INFO - 2018-06-30 13:20:33 --> Output Class Initialized
INFO - 2018-06-30 13:20:33 --> Security Class Initialized
DEBUG - 2018-06-30 13:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:20:33 --> CSRF cookie sent
INFO - 2018-06-30 13:20:33 --> Input Class Initialized
INFO - 2018-06-30 13:20:33 --> Language Class Initialized
INFO - 2018-06-30 13:20:33 --> Loader Class Initialized
INFO - 2018-06-30 13:20:33 --> Helper loaded: url_helper
INFO - 2018-06-30 13:20:33 --> Helper loaded: form_helper
INFO - 2018-06-30 13:20:33 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:20:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:20:33 --> User Agent Class Initialized
INFO - 2018-06-30 13:20:33 --> Controller Class Initialized
INFO - 2018-06-30 13:20:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:20:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:20:33 --> Pixel_Model class loaded
INFO - 2018-06-30 13:20:33 --> Database Driver Class Initialized
INFO - 2018-06-30 13:20:33 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:20:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 13:20:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 13:20:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-30 13:20:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 13:20:33 --> Final output sent to browser
DEBUG - 2018-06-30 13:20:33 --> Total execution time: 0.0313
INFO - 2018-06-30 13:20:48 --> Config Class Initialized
INFO - 2018-06-30 13:20:48 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:20:48 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:20:48 --> Utf8 Class Initialized
INFO - 2018-06-30 13:20:48 --> URI Class Initialized
INFO - 2018-06-30 13:20:48 --> Router Class Initialized
INFO - 2018-06-30 13:20:48 --> Output Class Initialized
INFO - 2018-06-30 13:20:48 --> Security Class Initialized
DEBUG - 2018-06-30 13:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:20:48 --> CSRF cookie sent
INFO - 2018-06-30 13:20:48 --> CSRF token verified
INFO - 2018-06-30 13:20:48 --> Input Class Initialized
INFO - 2018-06-30 13:20:48 --> Language Class Initialized
INFO - 2018-06-30 13:20:48 --> Loader Class Initialized
INFO - 2018-06-30 13:20:48 --> Helper loaded: url_helper
INFO - 2018-06-30 13:20:48 --> Helper loaded: form_helper
INFO - 2018-06-30 13:20:48 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:20:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:20:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:20:48 --> User Agent Class Initialized
INFO - 2018-06-30 13:20:48 --> Controller Class Initialized
INFO - 2018-06-30 13:20:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:20:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:20:48 --> Pixel_Model class loaded
INFO - 2018-06-30 13:20:48 --> Database Driver Class Initialized
INFO - 2018-06-30 13:20:48 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:20:48 --> Config Class Initialized
INFO - 2018-06-30 13:20:48 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:20:48 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:20:48 --> Utf8 Class Initialized
INFO - 2018-06-30 13:20:48 --> URI Class Initialized
INFO - 2018-06-30 13:20:48 --> Router Class Initialized
INFO - 2018-06-30 13:20:48 --> Output Class Initialized
INFO - 2018-06-30 13:20:48 --> Security Class Initialized
DEBUG - 2018-06-30 13:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:20:48 --> CSRF cookie sent
INFO - 2018-06-30 13:20:48 --> Input Class Initialized
INFO - 2018-06-30 13:20:48 --> Language Class Initialized
INFO - 2018-06-30 13:20:48 --> Loader Class Initialized
INFO - 2018-06-30 13:20:48 --> Helper loaded: url_helper
INFO - 2018-06-30 13:20:48 --> Helper loaded: form_helper
INFO - 2018-06-30 13:20:48 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:20:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:20:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:20:48 --> User Agent Class Initialized
INFO - 2018-06-30 13:20:48 --> Controller Class Initialized
INFO - 2018-06-30 13:20:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:20:48 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-30 13:20:48 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-30 13:20:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 13:20:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 13:20:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 13:20:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-30 13:20:48 --> Could not find the language line "req_email"
INFO - 2018-06-30 13:20:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-06-30 13:20:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 13:20:48 --> Final output sent to browser
DEBUG - 2018-06-30 13:20:48 --> Total execution time: 0.0263
INFO - 2018-06-30 13:21:19 --> Config Class Initialized
INFO - 2018-06-30 13:21:19 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:21:19 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:21:19 --> Utf8 Class Initialized
INFO - 2018-06-30 13:21:19 --> URI Class Initialized
INFO - 2018-06-30 13:21:19 --> Router Class Initialized
INFO - 2018-06-30 13:21:19 --> Output Class Initialized
INFO - 2018-06-30 13:21:19 --> Security Class Initialized
DEBUG - 2018-06-30 13:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:21:19 --> CSRF cookie sent
INFO - 2018-06-30 13:21:19 --> Input Class Initialized
INFO - 2018-06-30 13:21:19 --> Language Class Initialized
INFO - 2018-06-30 13:21:19 --> Loader Class Initialized
INFO - 2018-06-30 13:21:19 --> Helper loaded: url_helper
INFO - 2018-06-30 13:21:19 --> Helper loaded: form_helper
INFO - 2018-06-30 13:21:19 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:21:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:21:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:21:19 --> User Agent Class Initialized
INFO - 2018-06-30 13:21:19 --> Controller Class Initialized
INFO - 2018-06-30 13:21:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:21:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:21:19 --> Pixel_Model class loaded
INFO - 2018-06-30 13:21:19 --> Database Driver Class Initialized
INFO - 2018-06-30 13:21:19 --> Model "RegistrationModel" initialized
DEBUG - 2018-06-30 13:21:19 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-30 13:21:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 13:21:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 13:21:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 13:21:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-30 13:21:19 --> Could not find the language line "req_email"
INFO - 2018-06-30 13:21:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup.php
INFO - 2018-06-30 13:21:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 13:21:19 --> Final output sent to browser
DEBUG - 2018-06-30 13:21:19 --> Total execution time: 0.0381
INFO - 2018-06-30 13:21:44 --> Config Class Initialized
INFO - 2018-06-30 13:21:44 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:21:44 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:21:44 --> Utf8 Class Initialized
INFO - 2018-06-30 13:21:44 --> URI Class Initialized
INFO - 2018-06-30 13:21:44 --> Router Class Initialized
INFO - 2018-06-30 13:21:44 --> Output Class Initialized
INFO - 2018-06-30 13:21:44 --> Security Class Initialized
DEBUG - 2018-06-30 13:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:21:44 --> CSRF cookie sent
INFO - 2018-06-30 13:21:44 --> CSRF token verified
INFO - 2018-06-30 13:21:44 --> Input Class Initialized
INFO - 2018-06-30 13:21:44 --> Language Class Initialized
INFO - 2018-06-30 13:21:44 --> Loader Class Initialized
INFO - 2018-06-30 13:21:44 --> Helper loaded: url_helper
INFO - 2018-06-30 13:21:44 --> Helper loaded: form_helper
INFO - 2018-06-30 13:21:44 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:21:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:21:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:21:44 --> User Agent Class Initialized
INFO - 2018-06-30 13:21:44 --> Controller Class Initialized
INFO - 2018-06-30 13:21:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:21:44 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-30 13:21:44 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-30 13:21:44 --> Form Validation Class Initialized
INFO - 2018-06-30 13:21:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-30 13:21:44 --> Pixel_Model class loaded
INFO - 2018-06-30 13:21:44 --> Database Driver Class Initialized
INFO - 2018-06-30 13:21:44 --> Model "RegistrationModel" initialized
INFO - 2018-06-30 13:21:45 --> Config Class Initialized
INFO - 2018-06-30 13:21:45 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:21:45 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:21:45 --> Utf8 Class Initialized
INFO - 2018-06-30 13:21:45 --> URI Class Initialized
INFO - 2018-06-30 13:21:45 --> Router Class Initialized
INFO - 2018-06-30 13:21:45 --> Output Class Initialized
INFO - 2018-06-30 13:21:45 --> Security Class Initialized
DEBUG - 2018-06-30 13:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:21:45 --> CSRF cookie sent
INFO - 2018-06-30 13:21:45 --> Input Class Initialized
INFO - 2018-06-30 13:21:45 --> Language Class Initialized
INFO - 2018-06-30 13:21:45 --> Loader Class Initialized
INFO - 2018-06-30 13:21:45 --> Helper loaded: url_helper
INFO - 2018-06-30 13:21:45 --> Helper loaded: form_helper
INFO - 2018-06-30 13:21:45 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:21:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:21:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:21:45 --> User Agent Class Initialized
INFO - 2018-06-30 13:21:45 --> Controller Class Initialized
INFO - 2018-06-30 13:21:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:21:45 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-30 13:21:45 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-30 13:21:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 13:21:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 13:21:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 13:21:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 13:21:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_soft_error.php
ERROR - 2018-06-30 13:21:45 --> Could not find the language line "req_email"
INFO - 2018-06-30 13:21:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/forgot_password.php
INFO - 2018-06-30 13:21:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 13:21:45 --> Final output sent to browser
DEBUG - 2018-06-30 13:21:45 --> Total execution time: 0.0233
INFO - 2018-06-30 13:21:54 --> Config Class Initialized
INFO - 2018-06-30 13:21:54 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:21:54 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:21:54 --> Utf8 Class Initialized
INFO - 2018-06-30 13:21:54 --> URI Class Initialized
INFO - 2018-06-30 13:21:54 --> Router Class Initialized
INFO - 2018-06-30 13:21:54 --> Output Class Initialized
INFO - 2018-06-30 13:21:54 --> Security Class Initialized
DEBUG - 2018-06-30 13:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:21:54 --> CSRF cookie sent
INFO - 2018-06-30 13:21:54 --> Input Class Initialized
INFO - 2018-06-30 13:21:54 --> Language Class Initialized
INFO - 2018-06-30 13:21:54 --> Loader Class Initialized
INFO - 2018-06-30 13:21:54 --> Helper loaded: url_helper
INFO - 2018-06-30 13:21:54 --> Helper loaded: form_helper
INFO - 2018-06-30 13:21:54 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:21:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:21:54 --> User Agent Class Initialized
INFO - 2018-06-30 13:21:54 --> Controller Class Initialized
INFO - 2018-06-30 13:21:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:21:54 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-30 13:21:54 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-30 13:21:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 13:21:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 13:21:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 13:21:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-30 13:21:54 --> Could not find the language line "req_email"
INFO - 2018-06-30 13:21:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-06-30 13:21:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 13:21:54 --> Final output sent to browser
DEBUG - 2018-06-30 13:21:54 --> Total execution time: 0.0200
INFO - 2018-06-30 13:22:04 --> Config Class Initialized
INFO - 2018-06-30 13:22:04 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:22:04 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:22:04 --> Utf8 Class Initialized
INFO - 2018-06-30 13:22:04 --> URI Class Initialized
INFO - 2018-06-30 13:22:04 --> Router Class Initialized
INFO - 2018-06-30 13:22:04 --> Output Class Initialized
INFO - 2018-06-30 13:22:04 --> Security Class Initialized
DEBUG - 2018-06-30 13:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:22:04 --> CSRF cookie sent
INFO - 2018-06-30 13:22:04 --> CSRF token verified
INFO - 2018-06-30 13:22:04 --> Input Class Initialized
INFO - 2018-06-30 13:22:04 --> Language Class Initialized
INFO - 2018-06-30 13:22:04 --> Loader Class Initialized
INFO - 2018-06-30 13:22:04 --> Helper loaded: url_helper
INFO - 2018-06-30 13:22:04 --> Helper loaded: form_helper
INFO - 2018-06-30 13:22:04 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:22:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:22:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:22:04 --> User Agent Class Initialized
INFO - 2018-06-30 13:22:04 --> Controller Class Initialized
INFO - 2018-06-30 13:22:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:22:04 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-30 13:22:04 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-30 13:22:05 --> Form Validation Class Initialized
INFO - 2018-06-30 13:22:05 --> Pixel_Model class loaded
INFO - 2018-06-30 13:22:05 --> Database Driver Class Initialized
INFO - 2018-06-30 13:22:05 --> Model "AuthenticationModel" initialized
INFO - 2018-06-30 13:22:05 --> Config Class Initialized
INFO - 2018-06-30 13:22:05 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:22:05 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:22:05 --> Utf8 Class Initialized
INFO - 2018-06-30 13:22:05 --> URI Class Initialized
DEBUG - 2018-06-30 13:22:05 --> No URI present. Default controller set.
INFO - 2018-06-30 13:22:05 --> Router Class Initialized
INFO - 2018-06-30 13:22:05 --> Output Class Initialized
INFO - 2018-06-30 13:22:05 --> Security Class Initialized
DEBUG - 2018-06-30 13:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:22:05 --> CSRF cookie sent
INFO - 2018-06-30 13:22:05 --> Input Class Initialized
INFO - 2018-06-30 13:22:05 --> Language Class Initialized
INFO - 2018-06-30 13:22:05 --> Loader Class Initialized
INFO - 2018-06-30 13:22:05 --> Helper loaded: url_helper
INFO - 2018-06-30 13:22:05 --> Helper loaded: form_helper
INFO - 2018-06-30 13:22:05 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:22:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:22:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:22:05 --> User Agent Class Initialized
INFO - 2018-06-30 13:22:05 --> Controller Class Initialized
INFO - 2018-06-30 13:22:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:22:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:22:05 --> Pixel_Model class loaded
INFO - 2018-06-30 13:22:05 --> Database Driver Class Initialized
INFO - 2018-06-30 13:22:05 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:22:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 13:22:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-06-30 13:22:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 13:22:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-30 13:22:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 13:22:05 --> Final output sent to browser
DEBUG - 2018-06-30 13:22:05 --> Total execution time: 0.0327
INFO - 2018-06-30 13:22:15 --> Config Class Initialized
INFO - 2018-06-30 13:22:15 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:22:15 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:22:15 --> Utf8 Class Initialized
INFO - 2018-06-30 13:22:15 --> URI Class Initialized
INFO - 2018-06-30 13:22:15 --> Router Class Initialized
INFO - 2018-06-30 13:22:15 --> Output Class Initialized
INFO - 2018-06-30 13:22:15 --> Security Class Initialized
DEBUG - 2018-06-30 13:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:22:15 --> CSRF cookie sent
INFO - 2018-06-30 13:22:15 --> Input Class Initialized
INFO - 2018-06-30 13:22:15 --> Language Class Initialized
INFO - 2018-06-30 13:22:15 --> Loader Class Initialized
INFO - 2018-06-30 13:22:15 --> Helper loaded: url_helper
INFO - 2018-06-30 13:22:15 --> Helper loaded: form_helper
INFO - 2018-06-30 13:22:15 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:22:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:22:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:22:15 --> User Agent Class Initialized
INFO - 2018-06-30 13:22:15 --> Controller Class Initialized
INFO - 2018-06-30 13:22:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:22:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:22:15 --> Pixel_Model class loaded
INFO - 2018-06-30 13:22:15 --> Database Driver Class Initialized
INFO - 2018-06-30 13:22:15 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:22:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 13:22:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-06-30 13:22:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 13:22:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 13:22:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 13:22:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-30 13:22:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-30 13:22:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-06-30 13:22:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 13:22:15 --> Final output sent to browser
DEBUG - 2018-06-30 13:22:15 --> Total execution time: 0.0327
INFO - 2018-06-30 13:22:48 --> Config Class Initialized
INFO - 2018-06-30 13:22:48 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:22:48 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:22:48 --> Utf8 Class Initialized
INFO - 2018-06-30 13:22:48 --> URI Class Initialized
INFO - 2018-06-30 13:22:48 --> Router Class Initialized
INFO - 2018-06-30 13:22:48 --> Output Class Initialized
INFO - 2018-06-30 13:22:48 --> Security Class Initialized
DEBUG - 2018-06-30 13:22:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:22:48 --> CSRF cookie sent
INFO - 2018-06-30 13:22:48 --> CSRF token verified
INFO - 2018-06-30 13:22:48 --> Input Class Initialized
INFO - 2018-06-30 13:22:48 --> Language Class Initialized
INFO - 2018-06-30 13:22:48 --> Loader Class Initialized
INFO - 2018-06-30 13:22:48 --> Helper loaded: url_helper
INFO - 2018-06-30 13:22:48 --> Helper loaded: form_helper
INFO - 2018-06-30 13:22:48 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:22:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:22:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:22:48 --> User Agent Class Initialized
INFO - 2018-06-30 13:22:48 --> Controller Class Initialized
INFO - 2018-06-30 13:22:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:22:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:22:48 --> Pixel_Model class loaded
INFO - 2018-06-30 13:22:48 --> Database Driver Class Initialized
INFO - 2018-06-30 13:22:48 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:22:48 --> Form Validation Class Initialized
INFO - 2018-06-30 13:22:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-30 13:22:48 --> Database Driver Class Initialized
INFO - 2018-06-30 13:22:48 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:22:48 --> Config Class Initialized
INFO - 2018-06-30 13:22:48 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:22:48 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:22:48 --> Utf8 Class Initialized
INFO - 2018-06-30 13:22:48 --> URI Class Initialized
INFO - 2018-06-30 13:22:48 --> Router Class Initialized
INFO - 2018-06-30 13:22:48 --> Output Class Initialized
INFO - 2018-06-30 13:22:48 --> Security Class Initialized
DEBUG - 2018-06-30 13:22:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:22:48 --> CSRF cookie sent
INFO - 2018-06-30 13:22:48 --> Input Class Initialized
INFO - 2018-06-30 13:22:48 --> Language Class Initialized
INFO - 2018-06-30 13:22:48 --> Loader Class Initialized
INFO - 2018-06-30 13:22:48 --> Helper loaded: url_helper
INFO - 2018-06-30 13:22:48 --> Helper loaded: form_helper
INFO - 2018-06-30 13:22:48 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:22:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:22:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:22:48 --> User Agent Class Initialized
INFO - 2018-06-30 13:22:48 --> Controller Class Initialized
INFO - 2018-06-30 13:22:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:22:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:22:48 --> Pixel_Model class loaded
INFO - 2018-06-30 13:22:48 --> Database Driver Class Initialized
INFO - 2018-06-30 13:22:48 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:22:48 --> Database Driver Class Initialized
INFO - 2018-06-30 13:22:48 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:22:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 13:22:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-06-30 13:22:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 13:22:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 13:22:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 13:22:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-30 13:22:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-30 13:22:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-06-30 13:22:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 13:22:48 --> Final output sent to browser
DEBUG - 2018-06-30 13:22:48 --> Total execution time: 0.0431
INFO - 2018-06-30 13:22:58 --> Config Class Initialized
INFO - 2018-06-30 13:22:58 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:22:58 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:22:58 --> Utf8 Class Initialized
INFO - 2018-06-30 13:22:58 --> URI Class Initialized
INFO - 2018-06-30 13:22:58 --> Router Class Initialized
INFO - 2018-06-30 13:22:58 --> Output Class Initialized
INFO - 2018-06-30 13:22:58 --> Security Class Initialized
DEBUG - 2018-06-30 13:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:22:58 --> CSRF cookie sent
INFO - 2018-06-30 13:22:58 --> CSRF token verified
INFO - 2018-06-30 13:22:58 --> Input Class Initialized
INFO - 2018-06-30 13:22:58 --> Language Class Initialized
INFO - 2018-06-30 13:22:58 --> Loader Class Initialized
INFO - 2018-06-30 13:22:58 --> Helper loaded: url_helper
INFO - 2018-06-30 13:22:58 --> Helper loaded: form_helper
INFO - 2018-06-30 13:22:58 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:22:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:22:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:22:58 --> User Agent Class Initialized
INFO - 2018-06-30 13:22:58 --> Controller Class Initialized
INFO - 2018-06-30 13:22:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:22:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:22:58 --> Pixel_Model class loaded
INFO - 2018-06-30 13:22:58 --> Database Driver Class Initialized
INFO - 2018-06-30 13:22:58 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:22:58 --> Form Validation Class Initialized
INFO - 2018-06-30 13:22:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-30 13:22:58 --> Database Driver Class Initialized
INFO - 2018-06-30 13:22:58 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:22:58 --> Config Class Initialized
INFO - 2018-06-30 13:22:58 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:22:58 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:22:58 --> Utf8 Class Initialized
INFO - 2018-06-30 13:22:58 --> URI Class Initialized
INFO - 2018-06-30 13:22:58 --> Router Class Initialized
INFO - 2018-06-30 13:22:58 --> Output Class Initialized
INFO - 2018-06-30 13:22:58 --> Security Class Initialized
DEBUG - 2018-06-30 13:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:22:58 --> CSRF cookie sent
INFO - 2018-06-30 13:22:58 --> Input Class Initialized
INFO - 2018-06-30 13:22:58 --> Language Class Initialized
INFO - 2018-06-30 13:22:58 --> Loader Class Initialized
INFO - 2018-06-30 13:22:58 --> Helper loaded: url_helper
INFO - 2018-06-30 13:22:58 --> Helper loaded: form_helper
INFO - 2018-06-30 13:22:58 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:22:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:22:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:22:58 --> User Agent Class Initialized
INFO - 2018-06-30 13:22:58 --> Controller Class Initialized
INFO - 2018-06-30 13:22:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:22:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:22:58 --> Pixel_Model class loaded
INFO - 2018-06-30 13:22:58 --> Database Driver Class Initialized
INFO - 2018-06-30 13:22:58 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:22:58 --> Database Driver Class Initialized
INFO - 2018-06-30 13:22:58 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:22:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 13:22:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-06-30 13:22:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 13:22:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 13:22:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 13:22:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-30 13:22:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-30 13:22:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-06-30 13:22:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 13:22:58 --> Final output sent to browser
DEBUG - 2018-06-30 13:22:58 --> Total execution time: 0.0637
INFO - 2018-06-30 13:23:07 --> Config Class Initialized
INFO - 2018-06-30 13:23:07 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:23:07 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:23:07 --> Utf8 Class Initialized
INFO - 2018-06-30 13:23:07 --> URI Class Initialized
INFO - 2018-06-30 13:23:07 --> Router Class Initialized
INFO - 2018-06-30 13:23:07 --> Output Class Initialized
INFO - 2018-06-30 13:23:07 --> Security Class Initialized
DEBUG - 2018-06-30 13:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:23:07 --> CSRF cookie sent
INFO - 2018-06-30 13:23:07 --> CSRF token verified
INFO - 2018-06-30 13:23:07 --> Input Class Initialized
INFO - 2018-06-30 13:23:07 --> Language Class Initialized
INFO - 2018-06-30 13:23:07 --> Loader Class Initialized
INFO - 2018-06-30 13:23:07 --> Helper loaded: url_helper
INFO - 2018-06-30 13:23:07 --> Helper loaded: form_helper
INFO - 2018-06-30 13:23:07 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:23:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:23:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:23:07 --> User Agent Class Initialized
INFO - 2018-06-30 13:23:07 --> Controller Class Initialized
INFO - 2018-06-30 13:23:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:23:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:23:07 --> Pixel_Model class loaded
INFO - 2018-06-30 13:23:07 --> Database Driver Class Initialized
INFO - 2018-06-30 13:23:07 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:23:07 --> Form Validation Class Initialized
INFO - 2018-06-30 13:23:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-30 13:23:07 --> Database Driver Class Initialized
INFO - 2018-06-30 13:23:07 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:23:07 --> Config Class Initialized
INFO - 2018-06-30 13:23:07 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:23:07 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:23:07 --> Utf8 Class Initialized
INFO - 2018-06-30 13:23:07 --> URI Class Initialized
INFO - 2018-06-30 13:23:07 --> Router Class Initialized
INFO - 2018-06-30 13:23:07 --> Output Class Initialized
INFO - 2018-06-30 13:23:07 --> Security Class Initialized
DEBUG - 2018-06-30 13:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:23:07 --> CSRF cookie sent
INFO - 2018-06-30 13:23:07 --> Input Class Initialized
INFO - 2018-06-30 13:23:07 --> Language Class Initialized
INFO - 2018-06-30 13:23:07 --> Loader Class Initialized
INFO - 2018-06-30 13:23:07 --> Helper loaded: url_helper
INFO - 2018-06-30 13:23:07 --> Helper loaded: form_helper
INFO - 2018-06-30 13:23:07 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:23:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:23:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:23:07 --> User Agent Class Initialized
INFO - 2018-06-30 13:23:07 --> Controller Class Initialized
INFO - 2018-06-30 13:23:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:23:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:23:07 --> Pixel_Model class loaded
INFO - 2018-06-30 13:23:07 --> Database Driver Class Initialized
INFO - 2018-06-30 13:23:07 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:23:07 --> Database Driver Class Initialized
INFO - 2018-06-30 13:23:07 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:23:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 13:23:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-06-30 13:23:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 13:23:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-06-30 13:23:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 13:23:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 13:23:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-30 13:23:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-30 13:23:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-06-30 13:23:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 13:23:07 --> Final output sent to browser
DEBUG - 2018-06-30 13:23:07 --> Total execution time: 0.0378
INFO - 2018-06-30 13:23:09 --> Config Class Initialized
INFO - 2018-06-30 13:23:09 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:23:09 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:23:09 --> Utf8 Class Initialized
INFO - 2018-06-30 13:23:09 --> URI Class Initialized
INFO - 2018-06-30 13:23:09 --> Router Class Initialized
INFO - 2018-06-30 13:23:09 --> Output Class Initialized
INFO - 2018-06-30 13:23:09 --> Security Class Initialized
DEBUG - 2018-06-30 13:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:23:09 --> CSRF cookie sent
INFO - 2018-06-30 13:23:09 --> CSRF token verified
INFO - 2018-06-30 13:23:09 --> Input Class Initialized
INFO - 2018-06-30 13:23:09 --> Language Class Initialized
INFO - 2018-06-30 13:23:09 --> Loader Class Initialized
INFO - 2018-06-30 13:23:09 --> Helper loaded: url_helper
INFO - 2018-06-30 13:23:09 --> Helper loaded: form_helper
INFO - 2018-06-30 13:23:09 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:23:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:23:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:23:09 --> User Agent Class Initialized
INFO - 2018-06-30 13:23:09 --> Controller Class Initialized
INFO - 2018-06-30 13:23:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:23:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:23:09 --> Pixel_Model class loaded
INFO - 2018-06-30 13:23:09 --> Database Driver Class Initialized
INFO - 2018-06-30 13:23:09 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:23:09 --> Form Validation Class Initialized
INFO - 2018-06-30 13:23:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-30 13:23:09 --> Database Driver Class Initialized
INFO - 2018-06-30 13:23:09 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:23:09 --> Config Class Initialized
INFO - 2018-06-30 13:23:09 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:23:09 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:23:09 --> Utf8 Class Initialized
INFO - 2018-06-30 13:23:09 --> URI Class Initialized
INFO - 2018-06-30 13:23:09 --> Router Class Initialized
INFO - 2018-06-30 13:23:09 --> Output Class Initialized
INFO - 2018-06-30 13:23:09 --> Security Class Initialized
DEBUG - 2018-06-30 13:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:23:09 --> CSRF cookie sent
INFO - 2018-06-30 13:23:09 --> Input Class Initialized
INFO - 2018-06-30 13:23:09 --> Language Class Initialized
INFO - 2018-06-30 13:23:09 --> Loader Class Initialized
INFO - 2018-06-30 13:23:09 --> Helper loaded: url_helper
INFO - 2018-06-30 13:23:09 --> Helper loaded: form_helper
INFO - 2018-06-30 13:23:09 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:23:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:23:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:23:09 --> User Agent Class Initialized
INFO - 2018-06-30 13:23:09 --> Controller Class Initialized
INFO - 2018-06-30 13:23:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:23:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:23:09 --> Pixel_Model class loaded
INFO - 2018-06-30 13:23:09 --> Database Driver Class Initialized
INFO - 2018-06-30 13:23:09 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:23:09 --> Database Driver Class Initialized
INFO - 2018-06-30 13:23:09 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:23:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 13:23:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-06-30 13:23:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 13:23:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 13:23:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 13:23:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-30 13:23:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-30 13:23:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-06-30 13:23:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 13:23:09 --> Final output sent to browser
DEBUG - 2018-06-30 13:23:09 --> Total execution time: 0.0469
INFO - 2018-06-30 13:23:20 --> Config Class Initialized
INFO - 2018-06-30 13:23:20 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:23:20 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:23:20 --> Utf8 Class Initialized
INFO - 2018-06-30 13:23:20 --> URI Class Initialized
INFO - 2018-06-30 13:23:20 --> Router Class Initialized
INFO - 2018-06-30 13:23:20 --> Output Class Initialized
INFO - 2018-06-30 13:23:20 --> Security Class Initialized
DEBUG - 2018-06-30 13:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:23:20 --> CSRF cookie sent
INFO - 2018-06-30 13:23:20 --> CSRF token verified
INFO - 2018-06-30 13:23:20 --> Input Class Initialized
INFO - 2018-06-30 13:23:20 --> Language Class Initialized
INFO - 2018-06-30 13:23:20 --> Loader Class Initialized
INFO - 2018-06-30 13:23:20 --> Helper loaded: url_helper
INFO - 2018-06-30 13:23:20 --> Helper loaded: form_helper
INFO - 2018-06-30 13:23:20 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:23:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:23:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:23:20 --> User Agent Class Initialized
INFO - 2018-06-30 13:23:20 --> Controller Class Initialized
INFO - 2018-06-30 13:23:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:23:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:23:20 --> Pixel_Model class loaded
INFO - 2018-06-30 13:23:20 --> Database Driver Class Initialized
INFO - 2018-06-30 13:23:20 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:23:20 --> Form Validation Class Initialized
INFO - 2018-06-30 13:23:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-30 13:23:20 --> Database Driver Class Initialized
INFO - 2018-06-30 13:23:20 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:23:20 --> Config Class Initialized
INFO - 2018-06-30 13:23:20 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:23:20 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:23:20 --> Utf8 Class Initialized
INFO - 2018-06-30 13:23:20 --> URI Class Initialized
INFO - 2018-06-30 13:23:20 --> Router Class Initialized
INFO - 2018-06-30 13:23:20 --> Output Class Initialized
INFO - 2018-06-30 13:23:20 --> Security Class Initialized
DEBUG - 2018-06-30 13:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:23:20 --> CSRF cookie sent
INFO - 2018-06-30 13:23:20 --> Input Class Initialized
INFO - 2018-06-30 13:23:20 --> Language Class Initialized
INFO - 2018-06-30 13:23:20 --> Loader Class Initialized
INFO - 2018-06-30 13:23:20 --> Helper loaded: url_helper
INFO - 2018-06-30 13:23:20 --> Helper loaded: form_helper
INFO - 2018-06-30 13:23:20 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:23:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:23:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:23:20 --> User Agent Class Initialized
INFO - 2018-06-30 13:23:20 --> Controller Class Initialized
INFO - 2018-06-30 13:23:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:23:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:23:20 --> Pixel_Model class loaded
INFO - 2018-06-30 13:23:20 --> Database Driver Class Initialized
INFO - 2018-06-30 13:23:20 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:23:20 --> Database Driver Class Initialized
INFO - 2018-06-30 13:23:20 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:23:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 13:23:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-06-30 13:23:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 13:23:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 13:23:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 13:23:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-30 13:23:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-30 13:23:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-06-30 13:23:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 13:23:20 --> Final output sent to browser
DEBUG - 2018-06-30 13:23:20 --> Total execution time: 0.0381
INFO - 2018-06-30 13:23:41 --> Config Class Initialized
INFO - 2018-06-30 13:23:41 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:23:41 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:23:41 --> Utf8 Class Initialized
INFO - 2018-06-30 13:23:41 --> URI Class Initialized
INFO - 2018-06-30 13:23:41 --> Router Class Initialized
INFO - 2018-06-30 13:23:41 --> Output Class Initialized
INFO - 2018-06-30 13:23:41 --> Security Class Initialized
DEBUG - 2018-06-30 13:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:23:41 --> CSRF cookie sent
INFO - 2018-06-30 13:23:41 --> CSRF token verified
INFO - 2018-06-30 13:23:41 --> Input Class Initialized
INFO - 2018-06-30 13:23:41 --> Language Class Initialized
INFO - 2018-06-30 13:23:41 --> Loader Class Initialized
INFO - 2018-06-30 13:23:41 --> Helper loaded: url_helper
INFO - 2018-06-30 13:23:41 --> Helper loaded: form_helper
INFO - 2018-06-30 13:23:41 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:23:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:23:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:23:41 --> User Agent Class Initialized
INFO - 2018-06-30 13:23:41 --> Controller Class Initialized
INFO - 2018-06-30 13:23:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:23:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:23:41 --> Pixel_Model class loaded
INFO - 2018-06-30 13:23:41 --> Database Driver Class Initialized
INFO - 2018-06-30 13:23:41 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:23:41 --> Form Validation Class Initialized
INFO - 2018-06-30 13:23:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-30 13:23:41 --> Database Driver Class Initialized
INFO - 2018-06-30 13:23:41 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:23:41 --> Config Class Initialized
INFO - 2018-06-30 13:23:41 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:23:41 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:23:41 --> Utf8 Class Initialized
INFO - 2018-06-30 13:23:41 --> URI Class Initialized
INFO - 2018-06-30 13:23:41 --> Router Class Initialized
INFO - 2018-06-30 13:23:41 --> Output Class Initialized
INFO - 2018-06-30 13:23:41 --> Security Class Initialized
DEBUG - 2018-06-30 13:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:23:41 --> CSRF cookie sent
INFO - 2018-06-30 13:23:41 --> Input Class Initialized
INFO - 2018-06-30 13:23:41 --> Language Class Initialized
INFO - 2018-06-30 13:23:41 --> Loader Class Initialized
INFO - 2018-06-30 13:23:41 --> Helper loaded: url_helper
INFO - 2018-06-30 13:23:41 --> Helper loaded: form_helper
INFO - 2018-06-30 13:23:41 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:23:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:23:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:23:41 --> User Agent Class Initialized
INFO - 2018-06-30 13:23:41 --> Controller Class Initialized
INFO - 2018-06-30 13:23:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:23:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:23:41 --> Pixel_Model class loaded
INFO - 2018-06-30 13:23:41 --> Database Driver Class Initialized
INFO - 2018-06-30 13:23:41 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:23:41 --> Database Driver Class Initialized
INFO - 2018-06-30 13:23:41 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:23:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 13:23:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-06-30 13:23:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 13:23:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 13:23:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 13:23:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-30 13:23:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-30 13:23:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-06-30 13:23:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 13:23:41 --> Final output sent to browser
DEBUG - 2018-06-30 13:23:41 --> Total execution time: 0.0675
INFO - 2018-06-30 13:23:58 --> Config Class Initialized
INFO - 2018-06-30 13:23:58 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:23:58 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:23:58 --> Utf8 Class Initialized
INFO - 2018-06-30 13:23:58 --> URI Class Initialized
INFO - 2018-06-30 13:23:58 --> Router Class Initialized
INFO - 2018-06-30 13:23:58 --> Output Class Initialized
INFO - 2018-06-30 13:23:58 --> Security Class Initialized
DEBUG - 2018-06-30 13:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:23:58 --> CSRF cookie sent
INFO - 2018-06-30 13:23:58 --> CSRF token verified
INFO - 2018-06-30 13:23:58 --> Input Class Initialized
INFO - 2018-06-30 13:23:58 --> Language Class Initialized
INFO - 2018-06-30 13:23:58 --> Loader Class Initialized
INFO - 2018-06-30 13:23:58 --> Helper loaded: url_helper
INFO - 2018-06-30 13:23:58 --> Helper loaded: form_helper
INFO - 2018-06-30 13:23:58 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:23:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:23:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:23:58 --> User Agent Class Initialized
INFO - 2018-06-30 13:23:58 --> Controller Class Initialized
INFO - 2018-06-30 13:23:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:23:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:23:58 --> Pixel_Model class loaded
INFO - 2018-06-30 13:23:58 --> Database Driver Class Initialized
INFO - 2018-06-30 13:23:58 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:23:58 --> Form Validation Class Initialized
INFO - 2018-06-30 13:23:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-30 13:23:58 --> Database Driver Class Initialized
INFO - 2018-06-30 13:23:58 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:23:58 --> Config Class Initialized
INFO - 2018-06-30 13:23:58 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:23:58 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:23:58 --> Utf8 Class Initialized
INFO - 2018-06-30 13:23:58 --> URI Class Initialized
INFO - 2018-06-30 13:23:58 --> Router Class Initialized
INFO - 2018-06-30 13:23:58 --> Output Class Initialized
INFO - 2018-06-30 13:23:58 --> Security Class Initialized
DEBUG - 2018-06-30 13:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:23:58 --> CSRF cookie sent
INFO - 2018-06-30 13:23:58 --> Input Class Initialized
INFO - 2018-06-30 13:23:58 --> Language Class Initialized
INFO - 2018-06-30 13:23:58 --> Loader Class Initialized
INFO - 2018-06-30 13:23:58 --> Helper loaded: url_helper
INFO - 2018-06-30 13:23:58 --> Helper loaded: form_helper
INFO - 2018-06-30 13:23:58 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:23:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:23:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:23:58 --> User Agent Class Initialized
INFO - 2018-06-30 13:23:58 --> Controller Class Initialized
INFO - 2018-06-30 13:23:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:23:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:23:58 --> Pixel_Model class loaded
INFO - 2018-06-30 13:23:59 --> Database Driver Class Initialized
INFO - 2018-06-30 13:23:59 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:23:59 --> Database Driver Class Initialized
INFO - 2018-06-30 13:23:59 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:23:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 13:23:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-06-30 13:23:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 13:23:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 13:23:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 13:23:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-30 13:23:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-30 13:23:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-06-30 13:23:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 13:23:59 --> Final output sent to browser
DEBUG - 2018-06-30 13:23:59 --> Total execution time: 0.0441
INFO - 2018-06-30 13:24:06 --> Config Class Initialized
INFO - 2018-06-30 13:24:06 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:24:06 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:24:06 --> Utf8 Class Initialized
INFO - 2018-06-30 13:24:06 --> URI Class Initialized
INFO - 2018-06-30 13:24:06 --> Router Class Initialized
INFO - 2018-06-30 13:24:06 --> Output Class Initialized
INFO - 2018-06-30 13:24:06 --> Security Class Initialized
DEBUG - 2018-06-30 13:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:24:06 --> CSRF cookie sent
INFO - 2018-06-30 13:24:06 --> CSRF token verified
INFO - 2018-06-30 13:24:06 --> Input Class Initialized
INFO - 2018-06-30 13:24:06 --> Language Class Initialized
INFO - 2018-06-30 13:24:06 --> Loader Class Initialized
INFO - 2018-06-30 13:24:06 --> Helper loaded: url_helper
INFO - 2018-06-30 13:24:06 --> Helper loaded: form_helper
INFO - 2018-06-30 13:24:06 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:24:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:24:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:24:06 --> User Agent Class Initialized
INFO - 2018-06-30 13:24:06 --> Controller Class Initialized
INFO - 2018-06-30 13:24:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:24:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:24:06 --> Pixel_Model class loaded
INFO - 2018-06-30 13:24:06 --> Database Driver Class Initialized
INFO - 2018-06-30 13:24:06 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:24:06 --> Form Validation Class Initialized
INFO - 2018-06-30 13:24:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-30 13:24:06 --> Database Driver Class Initialized
INFO - 2018-06-30 13:24:06 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:24:06 --> Config Class Initialized
INFO - 2018-06-30 13:24:06 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:24:06 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:24:06 --> Utf8 Class Initialized
INFO - 2018-06-30 13:24:06 --> URI Class Initialized
INFO - 2018-06-30 13:24:06 --> Router Class Initialized
INFO - 2018-06-30 13:24:06 --> Output Class Initialized
INFO - 2018-06-30 13:24:06 --> Security Class Initialized
DEBUG - 2018-06-30 13:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:24:06 --> CSRF cookie sent
INFO - 2018-06-30 13:24:06 --> Input Class Initialized
INFO - 2018-06-30 13:24:06 --> Language Class Initialized
INFO - 2018-06-30 13:24:06 --> Loader Class Initialized
INFO - 2018-06-30 13:24:06 --> Helper loaded: url_helper
INFO - 2018-06-30 13:24:06 --> Helper loaded: form_helper
INFO - 2018-06-30 13:24:06 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:24:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:24:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:24:06 --> User Agent Class Initialized
INFO - 2018-06-30 13:24:06 --> Controller Class Initialized
INFO - 2018-06-30 13:24:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:24:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:24:06 --> Pixel_Model class loaded
INFO - 2018-06-30 13:24:06 --> Database Driver Class Initialized
INFO - 2018-06-30 13:24:06 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:24:06 --> Database Driver Class Initialized
INFO - 2018-06-30 13:24:06 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:24:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 13:24:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-06-30 13:24:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 13:24:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 13:24:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 13:24:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-30 13:24:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-30 13:24:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_title.php
INFO - 2018-06-30 13:24:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 13:24:06 --> Final output sent to browser
DEBUG - 2018-06-30 13:24:06 --> Total execution time: 0.0411
INFO - 2018-06-30 13:24:08 --> Config Class Initialized
INFO - 2018-06-30 13:24:08 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:24:08 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:24:08 --> Utf8 Class Initialized
INFO - 2018-06-30 13:24:08 --> URI Class Initialized
INFO - 2018-06-30 13:24:08 --> Router Class Initialized
INFO - 2018-06-30 13:24:08 --> Output Class Initialized
INFO - 2018-06-30 13:24:08 --> Security Class Initialized
DEBUG - 2018-06-30 13:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:24:08 --> CSRF cookie sent
INFO - 2018-06-30 13:24:08 --> CSRF token verified
INFO - 2018-06-30 13:24:08 --> Input Class Initialized
INFO - 2018-06-30 13:24:08 --> Language Class Initialized
INFO - 2018-06-30 13:24:08 --> Loader Class Initialized
INFO - 2018-06-30 13:24:08 --> Helper loaded: url_helper
INFO - 2018-06-30 13:24:08 --> Helper loaded: form_helper
INFO - 2018-06-30 13:24:08 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:24:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:24:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:24:08 --> User Agent Class Initialized
INFO - 2018-06-30 13:24:08 --> Controller Class Initialized
INFO - 2018-06-30 13:24:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:24:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:24:08 --> Pixel_Model class loaded
INFO - 2018-06-30 13:24:08 --> Database Driver Class Initialized
INFO - 2018-06-30 13:24:08 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:24:08 --> Form Validation Class Initialized
INFO - 2018-06-30 13:24:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-30 13:24:08 --> Database Driver Class Initialized
INFO - 2018-06-30 13:24:08 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:24:08 --> Config Class Initialized
INFO - 2018-06-30 13:24:08 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:24:08 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:24:08 --> Utf8 Class Initialized
INFO - 2018-06-30 13:24:08 --> URI Class Initialized
INFO - 2018-06-30 13:24:08 --> Router Class Initialized
INFO - 2018-06-30 13:24:08 --> Output Class Initialized
INFO - 2018-06-30 13:24:08 --> Security Class Initialized
DEBUG - 2018-06-30 13:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:24:08 --> CSRF cookie sent
INFO - 2018-06-30 13:24:08 --> Input Class Initialized
INFO - 2018-06-30 13:24:08 --> Language Class Initialized
INFO - 2018-06-30 13:24:08 --> Loader Class Initialized
INFO - 2018-06-30 13:24:08 --> Helper loaded: url_helper
INFO - 2018-06-30 13:24:08 --> Helper loaded: form_helper
INFO - 2018-06-30 13:24:08 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:24:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:24:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:24:08 --> User Agent Class Initialized
INFO - 2018-06-30 13:24:08 --> Controller Class Initialized
INFO - 2018-06-30 13:24:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:24:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:24:08 --> Pixel_Model class loaded
INFO - 2018-06-30 13:24:08 --> Database Driver Class Initialized
INFO - 2018-06-30 13:24:08 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:24:08 --> Database Driver Class Initialized
INFO - 2018-06-30 13:24:08 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:24:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 13:24:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-06-30 13:24:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 13:24:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 13:24:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 13:24:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-30 13:24:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-30 13:24:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-06-30 13:24:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 13:24:08 --> Final output sent to browser
DEBUG - 2018-06-30 13:24:08 --> Total execution time: 0.0445
INFO - 2018-06-30 13:24:14 --> Config Class Initialized
INFO - 2018-06-30 13:24:14 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:24:14 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:24:14 --> Utf8 Class Initialized
INFO - 2018-06-30 13:24:14 --> URI Class Initialized
INFO - 2018-06-30 13:24:14 --> Router Class Initialized
INFO - 2018-06-30 13:24:14 --> Output Class Initialized
INFO - 2018-06-30 13:24:14 --> Security Class Initialized
DEBUG - 2018-06-30 13:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:24:14 --> CSRF cookie sent
INFO - 2018-06-30 13:24:14 --> CSRF token verified
INFO - 2018-06-30 13:24:14 --> Input Class Initialized
INFO - 2018-06-30 13:24:14 --> Language Class Initialized
INFO - 2018-06-30 13:24:14 --> Loader Class Initialized
INFO - 2018-06-30 13:24:14 --> Helper loaded: url_helper
INFO - 2018-06-30 13:24:14 --> Helper loaded: form_helper
INFO - 2018-06-30 13:24:14 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:24:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:24:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:24:14 --> User Agent Class Initialized
INFO - 2018-06-30 13:24:14 --> Controller Class Initialized
INFO - 2018-06-30 13:24:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:24:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:24:14 --> Pixel_Model class loaded
INFO - 2018-06-30 13:24:14 --> Database Driver Class Initialized
INFO - 2018-06-30 13:24:14 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:24:14 --> Form Validation Class Initialized
INFO - 2018-06-30 13:24:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-30 13:24:14 --> Database Driver Class Initialized
INFO - 2018-06-30 13:24:14 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:24:15 --> Config Class Initialized
INFO - 2018-06-30 13:24:15 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:24:15 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:24:15 --> Utf8 Class Initialized
INFO - 2018-06-30 13:24:15 --> URI Class Initialized
INFO - 2018-06-30 13:24:15 --> Router Class Initialized
INFO - 2018-06-30 13:24:15 --> Output Class Initialized
INFO - 2018-06-30 13:24:15 --> Security Class Initialized
DEBUG - 2018-06-30 13:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:24:15 --> CSRF cookie sent
INFO - 2018-06-30 13:24:15 --> Input Class Initialized
INFO - 2018-06-30 13:24:15 --> Language Class Initialized
INFO - 2018-06-30 13:24:15 --> Loader Class Initialized
INFO - 2018-06-30 13:24:15 --> Helper loaded: url_helper
INFO - 2018-06-30 13:24:15 --> Helper loaded: form_helper
INFO - 2018-06-30 13:24:15 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:24:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:24:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:24:15 --> User Agent Class Initialized
INFO - 2018-06-30 13:24:15 --> Controller Class Initialized
INFO - 2018-06-30 13:24:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:24:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:24:15 --> Pixel_Model class loaded
INFO - 2018-06-30 13:24:15 --> Database Driver Class Initialized
INFO - 2018-06-30 13:24:15 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:24:15 --> Database Driver Class Initialized
INFO - 2018-06-30 13:24:15 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:24:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 13:24:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-06-30 13:24:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 13:24:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 13:24:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 13:24:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-30 13:24:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-30 13:24:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-06-30 13:24:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 13:24:15 --> Final output sent to browser
DEBUG - 2018-06-30 13:24:15 --> Total execution time: 0.0412
INFO - 2018-06-30 13:24:49 --> Config Class Initialized
INFO - 2018-06-30 13:24:49 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:24:49 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:24:49 --> Utf8 Class Initialized
INFO - 2018-06-30 13:24:49 --> URI Class Initialized
INFO - 2018-06-30 13:24:49 --> Router Class Initialized
INFO - 2018-06-30 13:24:49 --> Output Class Initialized
INFO - 2018-06-30 13:24:49 --> Security Class Initialized
DEBUG - 2018-06-30 13:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:24:49 --> CSRF cookie sent
INFO - 2018-06-30 13:24:49 --> CSRF token verified
INFO - 2018-06-30 13:24:49 --> Input Class Initialized
INFO - 2018-06-30 13:24:49 --> Language Class Initialized
INFO - 2018-06-30 13:24:49 --> Loader Class Initialized
INFO - 2018-06-30 13:24:49 --> Helper loaded: url_helper
INFO - 2018-06-30 13:24:49 --> Helper loaded: form_helper
INFO - 2018-06-30 13:24:49 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:24:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:24:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:24:49 --> User Agent Class Initialized
INFO - 2018-06-30 13:24:49 --> Controller Class Initialized
INFO - 2018-06-30 13:24:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:24:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:24:49 --> Pixel_Model class loaded
INFO - 2018-06-30 13:24:49 --> Database Driver Class Initialized
INFO - 2018-06-30 13:24:49 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:24:49 --> Form Validation Class Initialized
INFO - 2018-06-30 13:24:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-30 13:24:49 --> Database Driver Class Initialized
INFO - 2018-06-30 13:24:49 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:24:49 --> Config Class Initialized
INFO - 2018-06-30 13:24:49 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:24:49 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:24:49 --> Utf8 Class Initialized
INFO - 2018-06-30 13:24:49 --> URI Class Initialized
INFO - 2018-06-30 13:24:49 --> Router Class Initialized
INFO - 2018-06-30 13:24:49 --> Output Class Initialized
INFO - 2018-06-30 13:24:49 --> Security Class Initialized
DEBUG - 2018-06-30 13:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:24:49 --> CSRF cookie sent
INFO - 2018-06-30 13:24:49 --> Input Class Initialized
INFO - 2018-06-30 13:24:49 --> Language Class Initialized
INFO - 2018-06-30 13:24:49 --> Loader Class Initialized
INFO - 2018-06-30 13:24:49 --> Helper loaded: url_helper
INFO - 2018-06-30 13:24:49 --> Helper loaded: form_helper
INFO - 2018-06-30 13:24:49 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:24:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:24:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:24:49 --> User Agent Class Initialized
INFO - 2018-06-30 13:24:49 --> Controller Class Initialized
INFO - 2018-06-30 13:24:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:24:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:24:49 --> Pixel_Model class loaded
INFO - 2018-06-30 13:24:49 --> Database Driver Class Initialized
INFO - 2018-06-30 13:24:49 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:24:49 --> Database Driver Class Initialized
INFO - 2018-06-30 13:24:49 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:24:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 13:24:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-06-30 13:24:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 13:24:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 13:24:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 13:24:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-30 13:24:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-30 13:24:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids_info.php
INFO - 2018-06-30 13:24:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 13:24:49 --> Final output sent to browser
DEBUG - 2018-06-30 13:24:49 --> Total execution time: 0.0389
INFO - 2018-06-30 13:25:26 --> Config Class Initialized
INFO - 2018-06-30 13:25:26 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:25:26 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:25:26 --> Utf8 Class Initialized
INFO - 2018-06-30 13:25:26 --> URI Class Initialized
INFO - 2018-06-30 13:25:26 --> Router Class Initialized
INFO - 2018-06-30 13:25:26 --> Output Class Initialized
INFO - 2018-06-30 13:25:26 --> Security Class Initialized
DEBUG - 2018-06-30 13:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:25:26 --> CSRF cookie sent
INFO - 2018-06-30 13:25:26 --> CSRF token verified
INFO - 2018-06-30 13:25:26 --> Input Class Initialized
INFO - 2018-06-30 13:25:26 --> Language Class Initialized
INFO - 2018-06-30 13:25:26 --> Loader Class Initialized
INFO - 2018-06-30 13:25:26 --> Helper loaded: url_helper
INFO - 2018-06-30 13:25:26 --> Helper loaded: form_helper
INFO - 2018-06-30 13:25:26 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:25:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:25:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:25:26 --> User Agent Class Initialized
INFO - 2018-06-30 13:25:26 --> Controller Class Initialized
INFO - 2018-06-30 13:25:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:25:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:25:26 --> Pixel_Model class loaded
INFO - 2018-06-30 13:25:26 --> Database Driver Class Initialized
INFO - 2018-06-30 13:25:26 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:25:26 --> Form Validation Class Initialized
INFO - 2018-06-30 13:25:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-30 13:25:26 --> Database Driver Class Initialized
INFO - 2018-06-30 13:25:26 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:25:26 --> Config Class Initialized
INFO - 2018-06-30 13:25:26 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:25:26 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:25:26 --> Utf8 Class Initialized
INFO - 2018-06-30 13:25:26 --> URI Class Initialized
INFO - 2018-06-30 13:25:26 --> Router Class Initialized
INFO - 2018-06-30 13:25:26 --> Output Class Initialized
INFO - 2018-06-30 13:25:26 --> Security Class Initialized
DEBUG - 2018-06-30 13:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:25:26 --> CSRF cookie sent
INFO - 2018-06-30 13:25:26 --> Input Class Initialized
INFO - 2018-06-30 13:25:26 --> Language Class Initialized
INFO - 2018-06-30 13:25:26 --> Loader Class Initialized
INFO - 2018-06-30 13:25:26 --> Helper loaded: url_helper
INFO - 2018-06-30 13:25:26 --> Helper loaded: form_helper
INFO - 2018-06-30 13:25:26 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:25:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:25:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:25:26 --> User Agent Class Initialized
INFO - 2018-06-30 13:25:26 --> Controller Class Initialized
INFO - 2018-06-30 13:25:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:25:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:25:26 --> Pixel_Model class loaded
INFO - 2018-06-30 13:25:26 --> Database Driver Class Initialized
INFO - 2018-06-30 13:25:26 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:25:26 --> Database Driver Class Initialized
INFO - 2018-06-30 13:25:26 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:25:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 13:25:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-06-30 13:25:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 13:25:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 13:25:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 13:25:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-30 13:25:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-30 13:25:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/other_kids.php
INFO - 2018-06-30 13:25:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 13:25:26 --> Final output sent to browser
DEBUG - 2018-06-30 13:25:26 --> Total execution time: 0.0468
INFO - 2018-06-30 13:25:29 --> Config Class Initialized
INFO - 2018-06-30 13:25:29 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:25:29 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:25:29 --> Utf8 Class Initialized
INFO - 2018-06-30 13:25:29 --> URI Class Initialized
INFO - 2018-06-30 13:25:29 --> Router Class Initialized
INFO - 2018-06-30 13:25:29 --> Output Class Initialized
INFO - 2018-06-30 13:25:29 --> Security Class Initialized
DEBUG - 2018-06-30 13:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:25:29 --> CSRF cookie sent
INFO - 2018-06-30 13:25:29 --> CSRF token verified
INFO - 2018-06-30 13:25:29 --> Input Class Initialized
INFO - 2018-06-30 13:25:29 --> Language Class Initialized
INFO - 2018-06-30 13:25:29 --> Loader Class Initialized
INFO - 2018-06-30 13:25:29 --> Helper loaded: url_helper
INFO - 2018-06-30 13:25:29 --> Helper loaded: form_helper
INFO - 2018-06-30 13:25:29 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:25:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:25:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:25:29 --> User Agent Class Initialized
INFO - 2018-06-30 13:25:29 --> Controller Class Initialized
INFO - 2018-06-30 13:25:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:25:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:25:30 --> Pixel_Model class loaded
INFO - 2018-06-30 13:25:30 --> Database Driver Class Initialized
INFO - 2018-06-30 13:25:30 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:25:30 --> Form Validation Class Initialized
INFO - 2018-06-30 13:25:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-30 13:25:30 --> Database Driver Class Initialized
INFO - 2018-06-30 13:25:30 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:25:30 --> Config Class Initialized
INFO - 2018-06-30 13:25:30 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:25:30 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:25:30 --> Utf8 Class Initialized
INFO - 2018-06-30 13:25:30 --> URI Class Initialized
INFO - 2018-06-30 13:25:30 --> Router Class Initialized
INFO - 2018-06-30 13:25:30 --> Output Class Initialized
INFO - 2018-06-30 13:25:30 --> Security Class Initialized
DEBUG - 2018-06-30 13:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:25:30 --> CSRF cookie sent
INFO - 2018-06-30 13:25:30 --> Input Class Initialized
INFO - 2018-06-30 13:25:30 --> Language Class Initialized
INFO - 2018-06-30 13:25:30 --> Loader Class Initialized
INFO - 2018-06-30 13:25:30 --> Helper loaded: url_helper
INFO - 2018-06-30 13:25:30 --> Helper loaded: form_helper
INFO - 2018-06-30 13:25:30 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:25:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:25:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:25:30 --> User Agent Class Initialized
INFO - 2018-06-30 13:25:30 --> Controller Class Initialized
INFO - 2018-06-30 13:25:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:25:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:25:30 --> Pixel_Model class loaded
INFO - 2018-06-30 13:25:30 --> Database Driver Class Initialized
INFO - 2018-06-30 13:25:30 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:25:30 --> Database Driver Class Initialized
INFO - 2018-06-30 13:25:30 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:25:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 13:25:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-06-30 13:25:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 13:25:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 13:25:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 13:25:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-30 13:25:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-30 13:25:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids_activities.php
INFO - 2018-06-30 13:25:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 13:25:30 --> Final output sent to browser
DEBUG - 2018-06-30 13:25:30 --> Total execution time: 0.0439
INFO - 2018-06-30 13:25:43 --> Config Class Initialized
INFO - 2018-06-30 13:25:43 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:25:43 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:25:43 --> Utf8 Class Initialized
INFO - 2018-06-30 13:25:43 --> URI Class Initialized
INFO - 2018-06-30 13:25:43 --> Router Class Initialized
INFO - 2018-06-30 13:25:43 --> Output Class Initialized
INFO - 2018-06-30 13:25:43 --> Security Class Initialized
DEBUG - 2018-06-30 13:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:25:43 --> CSRF cookie sent
INFO - 2018-06-30 13:25:43 --> CSRF token verified
INFO - 2018-06-30 13:25:43 --> Input Class Initialized
INFO - 2018-06-30 13:25:43 --> Language Class Initialized
INFO - 2018-06-30 13:25:43 --> Loader Class Initialized
INFO - 2018-06-30 13:25:43 --> Helper loaded: url_helper
INFO - 2018-06-30 13:25:43 --> Helper loaded: form_helper
INFO - 2018-06-30 13:25:43 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:25:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:25:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:25:43 --> User Agent Class Initialized
INFO - 2018-06-30 13:25:43 --> Controller Class Initialized
INFO - 2018-06-30 13:25:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:25:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:25:43 --> Pixel_Model class loaded
INFO - 2018-06-30 13:25:43 --> Database Driver Class Initialized
INFO - 2018-06-30 13:25:43 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:25:43 --> Form Validation Class Initialized
INFO - 2018-06-30 13:25:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-30 13:25:43 --> Database Driver Class Initialized
INFO - 2018-06-30 13:25:43 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:25:43 --> Config Class Initialized
INFO - 2018-06-30 13:25:43 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:25:43 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:25:43 --> Utf8 Class Initialized
INFO - 2018-06-30 13:25:43 --> URI Class Initialized
INFO - 2018-06-30 13:25:43 --> Router Class Initialized
INFO - 2018-06-30 13:25:43 --> Output Class Initialized
INFO - 2018-06-30 13:25:43 --> Security Class Initialized
DEBUG - 2018-06-30 13:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:25:43 --> CSRF cookie sent
INFO - 2018-06-30 13:25:43 --> Input Class Initialized
INFO - 2018-06-30 13:25:43 --> Language Class Initialized
INFO - 2018-06-30 13:25:43 --> Loader Class Initialized
INFO - 2018-06-30 13:25:43 --> Helper loaded: url_helper
INFO - 2018-06-30 13:25:43 --> Helper loaded: form_helper
INFO - 2018-06-30 13:25:43 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:25:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:25:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:25:43 --> User Agent Class Initialized
INFO - 2018-06-30 13:25:43 --> Controller Class Initialized
INFO - 2018-06-30 13:25:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:25:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:25:43 --> Pixel_Model class loaded
INFO - 2018-06-30 13:25:43 --> Database Driver Class Initialized
INFO - 2018-06-30 13:25:43 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:25:43 --> Database Driver Class Initialized
INFO - 2018-06-30 13:25:43 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:25:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 13:25:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-06-30 13:25:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 13:25:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 13:25:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 13:25:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-30 13:25:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-30 13:25:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids_communicate.php
INFO - 2018-06-30 13:25:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 13:25:43 --> Final output sent to browser
DEBUG - 2018-06-30 13:25:43 --> Total execution time: 0.0438
INFO - 2018-06-30 13:25:51 --> Config Class Initialized
INFO - 2018-06-30 13:25:51 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:25:51 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:25:51 --> Utf8 Class Initialized
INFO - 2018-06-30 13:25:51 --> URI Class Initialized
INFO - 2018-06-30 13:25:51 --> Router Class Initialized
INFO - 2018-06-30 13:25:51 --> Output Class Initialized
INFO - 2018-06-30 13:25:51 --> Security Class Initialized
DEBUG - 2018-06-30 13:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:25:51 --> CSRF cookie sent
INFO - 2018-06-30 13:25:51 --> CSRF token verified
INFO - 2018-06-30 13:25:51 --> Input Class Initialized
INFO - 2018-06-30 13:25:51 --> Language Class Initialized
INFO - 2018-06-30 13:25:51 --> Loader Class Initialized
INFO - 2018-06-30 13:25:51 --> Helper loaded: url_helper
INFO - 2018-06-30 13:25:51 --> Helper loaded: form_helper
INFO - 2018-06-30 13:25:51 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:25:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:25:51 --> User Agent Class Initialized
INFO - 2018-06-30 13:25:51 --> Controller Class Initialized
INFO - 2018-06-30 13:25:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:25:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:25:51 --> Pixel_Model class loaded
INFO - 2018-06-30 13:25:51 --> Database Driver Class Initialized
INFO - 2018-06-30 13:25:51 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:25:51 --> Form Validation Class Initialized
INFO - 2018-06-30 13:25:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-30 13:25:51 --> Database Driver Class Initialized
INFO - 2018-06-30 13:25:51 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:25:51 --> Config Class Initialized
INFO - 2018-06-30 13:25:51 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:25:51 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:25:51 --> Utf8 Class Initialized
INFO - 2018-06-30 13:25:51 --> URI Class Initialized
INFO - 2018-06-30 13:25:51 --> Router Class Initialized
INFO - 2018-06-30 13:25:51 --> Output Class Initialized
INFO - 2018-06-30 13:25:51 --> Security Class Initialized
DEBUG - 2018-06-30 13:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:25:51 --> CSRF cookie sent
INFO - 2018-06-30 13:25:51 --> Input Class Initialized
INFO - 2018-06-30 13:25:51 --> Language Class Initialized
INFO - 2018-06-30 13:25:51 --> Loader Class Initialized
INFO - 2018-06-30 13:25:51 --> Helper loaded: url_helper
INFO - 2018-06-30 13:25:51 --> Helper loaded: form_helper
INFO - 2018-06-30 13:25:51 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:25:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:25:51 --> User Agent Class Initialized
INFO - 2018-06-30 13:25:51 --> Controller Class Initialized
INFO - 2018-06-30 13:25:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:25:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:25:51 --> Pixel_Model class loaded
INFO - 2018-06-30 13:25:51 --> Database Driver Class Initialized
INFO - 2018-06-30 13:25:51 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:25:51 --> Database Driver Class Initialized
INFO - 2018-06-30 13:25:51 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:25:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 13:25:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-06-30 13:25:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 13:25:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 13:25:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 13:25:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-30 13:25:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-30 13:25:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids_dinner.php
INFO - 2018-06-30 13:25:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 13:25:51 --> Final output sent to browser
DEBUG - 2018-06-30 13:25:51 --> Total execution time: 0.0581
INFO - 2018-06-30 13:26:01 --> Config Class Initialized
INFO - 2018-06-30 13:26:01 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:26:01 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:26:01 --> Utf8 Class Initialized
INFO - 2018-06-30 13:26:01 --> URI Class Initialized
INFO - 2018-06-30 13:26:01 --> Router Class Initialized
INFO - 2018-06-30 13:26:01 --> Output Class Initialized
INFO - 2018-06-30 13:26:01 --> Security Class Initialized
DEBUG - 2018-06-30 13:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:26:01 --> CSRF cookie sent
INFO - 2018-06-30 13:26:01 --> CSRF token verified
INFO - 2018-06-30 13:26:01 --> Input Class Initialized
INFO - 2018-06-30 13:26:01 --> Language Class Initialized
INFO - 2018-06-30 13:26:01 --> Loader Class Initialized
INFO - 2018-06-30 13:26:01 --> Helper loaded: url_helper
INFO - 2018-06-30 13:26:01 --> Helper loaded: form_helper
INFO - 2018-06-30 13:26:01 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:26:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:26:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:26:01 --> User Agent Class Initialized
INFO - 2018-06-30 13:26:01 --> Controller Class Initialized
INFO - 2018-06-30 13:26:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:26:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:26:01 --> Pixel_Model class loaded
INFO - 2018-06-30 13:26:01 --> Database Driver Class Initialized
INFO - 2018-06-30 13:26:01 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:26:01 --> Form Validation Class Initialized
INFO - 2018-06-30 13:26:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-30 13:26:01 --> Database Driver Class Initialized
INFO - 2018-06-30 13:26:01 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:26:01 --> Config Class Initialized
INFO - 2018-06-30 13:26:01 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:26:01 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:26:01 --> Utf8 Class Initialized
INFO - 2018-06-30 13:26:01 --> URI Class Initialized
INFO - 2018-06-30 13:26:01 --> Router Class Initialized
INFO - 2018-06-30 13:26:01 --> Output Class Initialized
INFO - 2018-06-30 13:26:01 --> Security Class Initialized
DEBUG - 2018-06-30 13:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:26:01 --> CSRF cookie sent
INFO - 2018-06-30 13:26:01 --> Input Class Initialized
INFO - 2018-06-30 13:26:01 --> Language Class Initialized
INFO - 2018-06-30 13:26:01 --> Loader Class Initialized
INFO - 2018-06-30 13:26:01 --> Helper loaded: url_helper
INFO - 2018-06-30 13:26:01 --> Helper loaded: form_helper
INFO - 2018-06-30 13:26:01 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:26:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:26:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:26:01 --> User Agent Class Initialized
INFO - 2018-06-30 13:26:01 --> Controller Class Initialized
INFO - 2018-06-30 13:26:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:26:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:26:01 --> Pixel_Model class loaded
INFO - 2018-06-30 13:26:01 --> Database Driver Class Initialized
INFO - 2018-06-30 13:26:01 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:26:01 --> Database Driver Class Initialized
INFO - 2018-06-30 13:26:01 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:26:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 13:26:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-06-30 13:26:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 13:26:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 13:26:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 13:26:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-30 13:26:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-30 13:26:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids_homework.php
INFO - 2018-06-30 13:26:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 13:26:01 --> Final output sent to browser
DEBUG - 2018-06-30 13:26:01 --> Total execution time: 0.0514
INFO - 2018-06-30 13:26:04 --> Config Class Initialized
INFO - 2018-06-30 13:26:04 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:26:04 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:26:04 --> Utf8 Class Initialized
INFO - 2018-06-30 13:26:04 --> URI Class Initialized
INFO - 2018-06-30 13:26:04 --> Router Class Initialized
INFO - 2018-06-30 13:26:04 --> Output Class Initialized
INFO - 2018-06-30 13:26:04 --> Security Class Initialized
DEBUG - 2018-06-30 13:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:26:04 --> CSRF cookie sent
INFO - 2018-06-30 13:26:04 --> CSRF token verified
INFO - 2018-06-30 13:26:04 --> Input Class Initialized
INFO - 2018-06-30 13:26:04 --> Language Class Initialized
INFO - 2018-06-30 13:26:04 --> Loader Class Initialized
INFO - 2018-06-30 13:26:04 --> Helper loaded: url_helper
INFO - 2018-06-30 13:26:04 --> Helper loaded: form_helper
INFO - 2018-06-30 13:26:04 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:26:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:26:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:26:04 --> User Agent Class Initialized
INFO - 2018-06-30 13:26:04 --> Controller Class Initialized
INFO - 2018-06-30 13:26:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:26:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:26:04 --> Pixel_Model class loaded
INFO - 2018-06-30 13:26:04 --> Database Driver Class Initialized
INFO - 2018-06-30 13:26:04 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:26:04 --> Form Validation Class Initialized
INFO - 2018-06-30 13:26:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-30 13:26:04 --> Database Driver Class Initialized
INFO - 2018-06-30 13:26:04 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:26:04 --> Config Class Initialized
INFO - 2018-06-30 13:26:04 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:26:04 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:26:04 --> Utf8 Class Initialized
INFO - 2018-06-30 13:26:04 --> URI Class Initialized
INFO - 2018-06-30 13:26:04 --> Router Class Initialized
INFO - 2018-06-30 13:26:04 --> Output Class Initialized
INFO - 2018-06-30 13:26:04 --> Security Class Initialized
DEBUG - 2018-06-30 13:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:26:04 --> CSRF cookie sent
INFO - 2018-06-30 13:26:04 --> Input Class Initialized
INFO - 2018-06-30 13:26:04 --> Language Class Initialized
INFO - 2018-06-30 13:26:04 --> Loader Class Initialized
INFO - 2018-06-30 13:26:04 --> Helper loaded: url_helper
INFO - 2018-06-30 13:26:04 --> Helper loaded: form_helper
INFO - 2018-06-30 13:26:04 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:26:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:26:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:26:04 --> User Agent Class Initialized
INFO - 2018-06-30 13:26:04 --> Controller Class Initialized
INFO - 2018-06-30 13:26:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:26:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:26:04 --> Pixel_Model class loaded
INFO - 2018-06-30 13:26:04 --> Database Driver Class Initialized
INFO - 2018-06-30 13:26:04 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:26:04 --> Database Driver Class Initialized
INFO - 2018-06-30 13:26:04 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:26:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 13:26:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-06-30 13:26:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 13:26:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 13:26:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 13:26:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-30 13:26:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-30 13:26:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids_doctor.php
INFO - 2018-06-30 13:26:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 13:26:04 --> Final output sent to browser
DEBUG - 2018-06-30 13:26:04 --> Total execution time: 0.0533
INFO - 2018-06-30 13:26:08 --> Config Class Initialized
INFO - 2018-06-30 13:26:08 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:26:08 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:26:08 --> Utf8 Class Initialized
INFO - 2018-06-30 13:26:08 --> URI Class Initialized
INFO - 2018-06-30 13:26:08 --> Router Class Initialized
INFO - 2018-06-30 13:26:08 --> Output Class Initialized
INFO - 2018-06-30 13:26:08 --> Security Class Initialized
DEBUG - 2018-06-30 13:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:26:08 --> CSRF cookie sent
INFO - 2018-06-30 13:26:08 --> CSRF token verified
INFO - 2018-06-30 13:26:08 --> Input Class Initialized
INFO - 2018-06-30 13:26:08 --> Language Class Initialized
INFO - 2018-06-30 13:26:08 --> Loader Class Initialized
INFO - 2018-06-30 13:26:08 --> Helper loaded: url_helper
INFO - 2018-06-30 13:26:08 --> Helper loaded: form_helper
INFO - 2018-06-30 13:26:08 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:26:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:26:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:26:08 --> User Agent Class Initialized
INFO - 2018-06-30 13:26:08 --> Controller Class Initialized
INFO - 2018-06-30 13:26:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:26:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:26:08 --> Pixel_Model class loaded
INFO - 2018-06-30 13:26:08 --> Database Driver Class Initialized
INFO - 2018-06-30 13:26:08 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:26:08 --> Form Validation Class Initialized
INFO - 2018-06-30 13:26:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-30 13:26:08 --> Database Driver Class Initialized
INFO - 2018-06-30 13:26:08 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:26:08 --> Config Class Initialized
INFO - 2018-06-30 13:26:08 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:26:08 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:26:08 --> Utf8 Class Initialized
INFO - 2018-06-30 13:26:08 --> URI Class Initialized
INFO - 2018-06-30 13:26:08 --> Router Class Initialized
INFO - 2018-06-30 13:26:08 --> Output Class Initialized
INFO - 2018-06-30 13:26:08 --> Security Class Initialized
DEBUG - 2018-06-30 13:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:26:08 --> CSRF cookie sent
INFO - 2018-06-30 13:26:08 --> Input Class Initialized
INFO - 2018-06-30 13:26:08 --> Language Class Initialized
INFO - 2018-06-30 13:26:08 --> Loader Class Initialized
INFO - 2018-06-30 13:26:08 --> Helper loaded: url_helper
INFO - 2018-06-30 13:26:08 --> Helper loaded: form_helper
INFO - 2018-06-30 13:26:08 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:26:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:26:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:26:08 --> User Agent Class Initialized
INFO - 2018-06-30 13:26:08 --> Controller Class Initialized
INFO - 2018-06-30 13:26:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:26:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:26:08 --> Pixel_Model class loaded
INFO - 2018-06-30 13:26:08 --> Database Driver Class Initialized
INFO - 2018-06-30 13:26:08 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:26:08 --> Database Driver Class Initialized
INFO - 2018-06-30 13:26:08 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:26:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 13:26:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-06-30 13:26:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 13:26:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 13:26:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 13:26:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-30 13:26:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-30 13:26:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids_help_complaint.php
INFO - 2018-06-30 13:26:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 13:26:08 --> Final output sent to browser
DEBUG - 2018-06-30 13:26:08 --> Total execution time: 0.0416
INFO - 2018-06-30 13:26:12 --> Config Class Initialized
INFO - 2018-06-30 13:26:12 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:26:12 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:26:12 --> Utf8 Class Initialized
INFO - 2018-06-30 13:26:12 --> URI Class Initialized
INFO - 2018-06-30 13:26:12 --> Router Class Initialized
INFO - 2018-06-30 13:26:12 --> Output Class Initialized
INFO - 2018-06-30 13:26:12 --> Security Class Initialized
DEBUG - 2018-06-30 13:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:26:12 --> CSRF cookie sent
INFO - 2018-06-30 13:26:12 --> CSRF token verified
INFO - 2018-06-30 13:26:12 --> Input Class Initialized
INFO - 2018-06-30 13:26:12 --> Language Class Initialized
INFO - 2018-06-30 13:26:12 --> Loader Class Initialized
INFO - 2018-06-30 13:26:12 --> Helper loaded: url_helper
INFO - 2018-06-30 13:26:12 --> Helper loaded: form_helper
INFO - 2018-06-30 13:26:12 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:26:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:26:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:26:12 --> User Agent Class Initialized
INFO - 2018-06-30 13:26:12 --> Controller Class Initialized
INFO - 2018-06-30 13:26:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:26:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:26:12 --> Pixel_Model class loaded
INFO - 2018-06-30 13:26:12 --> Database Driver Class Initialized
INFO - 2018-06-30 13:26:12 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:26:12 --> Form Validation Class Initialized
INFO - 2018-06-30 13:26:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-30 13:26:12 --> Database Driver Class Initialized
INFO - 2018-06-30 13:26:12 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:26:12 --> Config Class Initialized
INFO - 2018-06-30 13:26:12 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:26:12 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:26:12 --> Utf8 Class Initialized
INFO - 2018-06-30 13:26:12 --> URI Class Initialized
INFO - 2018-06-30 13:26:12 --> Router Class Initialized
INFO - 2018-06-30 13:26:12 --> Output Class Initialized
INFO - 2018-06-30 13:26:12 --> Security Class Initialized
DEBUG - 2018-06-30 13:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:26:12 --> CSRF cookie sent
INFO - 2018-06-30 13:26:12 --> Input Class Initialized
INFO - 2018-06-30 13:26:12 --> Language Class Initialized
INFO - 2018-06-30 13:26:12 --> Loader Class Initialized
INFO - 2018-06-30 13:26:12 --> Helper loaded: url_helper
INFO - 2018-06-30 13:26:12 --> Helper loaded: form_helper
INFO - 2018-06-30 13:26:12 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:26:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:26:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:26:12 --> User Agent Class Initialized
INFO - 2018-06-30 13:26:12 --> Controller Class Initialized
INFO - 2018-06-30 13:26:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:26:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:26:12 --> Pixel_Model class loaded
INFO - 2018-06-30 13:26:12 --> Database Driver Class Initialized
INFO - 2018-06-30 13:26:12 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:26:12 --> Database Driver Class Initialized
INFO - 2018-06-30 13:26:12 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:26:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 13:26:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-06-30 13:26:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 13:26:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 13:26:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 13:26:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-30 13:26:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-30 13:26:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/spouse_info.php
INFO - 2018-06-30 13:26:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 13:26:12 --> Final output sent to browser
DEBUG - 2018-06-30 13:26:12 --> Total execution time: 0.0514
INFO - 2018-06-30 13:26:25 --> Config Class Initialized
INFO - 2018-06-30 13:26:25 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:26:25 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:26:25 --> Utf8 Class Initialized
INFO - 2018-06-30 13:26:25 --> URI Class Initialized
INFO - 2018-06-30 13:26:25 --> Router Class Initialized
INFO - 2018-06-30 13:26:25 --> Output Class Initialized
INFO - 2018-06-30 13:26:25 --> Security Class Initialized
DEBUG - 2018-06-30 13:26:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:26:25 --> CSRF cookie sent
INFO - 2018-06-30 13:26:25 --> CSRF token verified
INFO - 2018-06-30 13:26:25 --> Input Class Initialized
INFO - 2018-06-30 13:26:25 --> Language Class Initialized
INFO - 2018-06-30 13:26:25 --> Loader Class Initialized
INFO - 2018-06-30 13:26:25 --> Helper loaded: url_helper
INFO - 2018-06-30 13:26:25 --> Helper loaded: form_helper
INFO - 2018-06-30 13:26:25 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:26:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:26:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:26:25 --> User Agent Class Initialized
INFO - 2018-06-30 13:26:25 --> Controller Class Initialized
INFO - 2018-06-30 13:26:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:26:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:26:25 --> Pixel_Model class loaded
INFO - 2018-06-30 13:26:25 --> Database Driver Class Initialized
INFO - 2018-06-30 13:26:25 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:26:25 --> Form Validation Class Initialized
INFO - 2018-06-30 13:26:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-30 13:26:25 --> Database Driver Class Initialized
INFO - 2018-06-30 13:26:25 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:26:25 --> Config Class Initialized
INFO - 2018-06-30 13:26:25 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:26:25 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:26:25 --> Utf8 Class Initialized
INFO - 2018-06-30 13:26:25 --> URI Class Initialized
INFO - 2018-06-30 13:26:25 --> Router Class Initialized
INFO - 2018-06-30 13:26:25 --> Output Class Initialized
INFO - 2018-06-30 13:26:25 --> Security Class Initialized
DEBUG - 2018-06-30 13:26:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:26:25 --> CSRF cookie sent
INFO - 2018-06-30 13:26:25 --> Input Class Initialized
INFO - 2018-06-30 13:26:25 --> Language Class Initialized
INFO - 2018-06-30 13:26:25 --> Loader Class Initialized
INFO - 2018-06-30 13:26:25 --> Helper loaded: url_helper
INFO - 2018-06-30 13:26:25 --> Helper loaded: form_helper
INFO - 2018-06-30 13:26:25 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:26:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:26:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:26:25 --> User Agent Class Initialized
INFO - 2018-06-30 13:26:25 --> Controller Class Initialized
INFO - 2018-06-30 13:26:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:26:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:26:25 --> Pixel_Model class loaded
INFO - 2018-06-30 13:26:25 --> Database Driver Class Initialized
INFO - 2018-06-30 13:26:25 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:26:25 --> Database Driver Class Initialized
INFO - 2018-06-30 13:26:25 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:26:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 13:26:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-06-30 13:26:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 13:26:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 13:26:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 13:26:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-30 13:26:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-30 13:26:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/spouse_job.php
INFO - 2018-06-30 13:26:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 13:26:25 --> Final output sent to browser
DEBUG - 2018-06-30 13:26:25 --> Total execution time: 0.0403
INFO - 2018-06-30 13:26:29 --> Config Class Initialized
INFO - 2018-06-30 13:26:29 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:26:29 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:26:29 --> Utf8 Class Initialized
INFO - 2018-06-30 13:26:29 --> URI Class Initialized
INFO - 2018-06-30 13:26:29 --> Router Class Initialized
INFO - 2018-06-30 13:26:29 --> Output Class Initialized
INFO - 2018-06-30 13:26:29 --> Security Class Initialized
DEBUG - 2018-06-30 13:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:26:29 --> CSRF cookie sent
INFO - 2018-06-30 13:26:29 --> CSRF token verified
INFO - 2018-06-30 13:26:29 --> Input Class Initialized
INFO - 2018-06-30 13:26:29 --> Language Class Initialized
INFO - 2018-06-30 13:26:29 --> Loader Class Initialized
INFO - 2018-06-30 13:26:29 --> Helper loaded: url_helper
INFO - 2018-06-30 13:26:29 --> Helper loaded: form_helper
INFO - 2018-06-30 13:26:29 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:26:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:26:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:26:29 --> User Agent Class Initialized
INFO - 2018-06-30 13:26:29 --> Controller Class Initialized
INFO - 2018-06-30 13:26:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:26:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:26:29 --> Pixel_Model class loaded
INFO - 2018-06-30 13:26:29 --> Database Driver Class Initialized
INFO - 2018-06-30 13:26:29 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:26:29 --> Form Validation Class Initialized
INFO - 2018-06-30 13:26:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-30 13:26:29 --> Database Driver Class Initialized
INFO - 2018-06-30 13:26:29 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:26:29 --> Config Class Initialized
INFO - 2018-06-30 13:26:29 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:26:29 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:26:29 --> Utf8 Class Initialized
INFO - 2018-06-30 13:26:29 --> URI Class Initialized
INFO - 2018-06-30 13:26:29 --> Router Class Initialized
INFO - 2018-06-30 13:26:29 --> Output Class Initialized
INFO - 2018-06-30 13:26:29 --> Security Class Initialized
DEBUG - 2018-06-30 13:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:26:29 --> CSRF cookie sent
INFO - 2018-06-30 13:26:29 --> Input Class Initialized
INFO - 2018-06-30 13:26:29 --> Language Class Initialized
INFO - 2018-06-30 13:26:29 --> Loader Class Initialized
INFO - 2018-06-30 13:26:29 --> Helper loaded: url_helper
INFO - 2018-06-30 13:26:29 --> Helper loaded: form_helper
INFO - 2018-06-30 13:26:29 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:26:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:26:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:26:29 --> User Agent Class Initialized
INFO - 2018-06-30 13:26:29 --> Controller Class Initialized
INFO - 2018-06-30 13:26:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:26:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:26:29 --> Pixel_Model class loaded
INFO - 2018-06-30 13:26:29 --> Database Driver Class Initialized
INFO - 2018-06-30 13:26:29 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:26:29 --> Database Driver Class Initialized
INFO - 2018-06-30 13:26:29 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:26:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 13:26:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-06-30 13:26:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 13:26:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 13:26:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 13:26:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-30 13:26:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-30 13:26:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/affectionate_salutation.php
INFO - 2018-06-30 13:26:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 13:26:29 --> Final output sent to browser
DEBUG - 2018-06-30 13:26:29 --> Total execution time: 0.0424
INFO - 2018-06-30 13:26:35 --> Config Class Initialized
INFO - 2018-06-30 13:26:35 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:26:35 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:26:35 --> Utf8 Class Initialized
INFO - 2018-06-30 13:26:35 --> URI Class Initialized
INFO - 2018-06-30 13:26:35 --> Router Class Initialized
INFO - 2018-06-30 13:26:35 --> Output Class Initialized
INFO - 2018-06-30 13:26:35 --> Security Class Initialized
DEBUG - 2018-06-30 13:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:26:35 --> CSRF cookie sent
INFO - 2018-06-30 13:26:35 --> CSRF token verified
INFO - 2018-06-30 13:26:35 --> Input Class Initialized
INFO - 2018-06-30 13:26:35 --> Language Class Initialized
INFO - 2018-06-30 13:26:35 --> Loader Class Initialized
INFO - 2018-06-30 13:26:35 --> Helper loaded: url_helper
INFO - 2018-06-30 13:26:35 --> Helper loaded: form_helper
INFO - 2018-06-30 13:26:35 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:26:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:26:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:26:35 --> User Agent Class Initialized
INFO - 2018-06-30 13:26:35 --> Controller Class Initialized
INFO - 2018-06-30 13:26:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:26:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:26:35 --> Pixel_Model class loaded
INFO - 2018-06-30 13:26:35 --> Database Driver Class Initialized
INFO - 2018-06-30 13:26:35 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:26:35 --> Form Validation Class Initialized
INFO - 2018-06-30 13:26:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-30 13:26:35 --> Database Driver Class Initialized
INFO - 2018-06-30 13:26:35 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:26:35 --> Config Class Initialized
INFO - 2018-06-30 13:26:35 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:26:35 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:26:35 --> Utf8 Class Initialized
INFO - 2018-06-30 13:26:35 --> URI Class Initialized
INFO - 2018-06-30 13:26:35 --> Router Class Initialized
INFO - 2018-06-30 13:26:35 --> Output Class Initialized
INFO - 2018-06-30 13:26:35 --> Security Class Initialized
DEBUG - 2018-06-30 13:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:26:35 --> CSRF cookie sent
INFO - 2018-06-30 13:26:35 --> Input Class Initialized
INFO - 2018-06-30 13:26:35 --> Language Class Initialized
INFO - 2018-06-30 13:26:35 --> Loader Class Initialized
INFO - 2018-06-30 13:26:35 --> Helper loaded: url_helper
INFO - 2018-06-30 13:26:35 --> Helper loaded: form_helper
INFO - 2018-06-30 13:26:35 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:26:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:26:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:26:35 --> User Agent Class Initialized
INFO - 2018-06-30 13:26:35 --> Controller Class Initialized
INFO - 2018-06-30 13:26:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:26:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:26:35 --> Pixel_Model class loaded
INFO - 2018-06-30 13:26:35 --> Database Driver Class Initialized
INFO - 2018-06-30 13:26:35 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:26:35 --> Database Driver Class Initialized
INFO - 2018-06-30 13:26:35 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:26:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 13:26:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-06-30 13:26:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 13:26:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 13:26:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 13:26:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-30 13:26:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-30 13:26:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/business_tax_info.php
INFO - 2018-06-30 13:26:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 13:26:35 --> Final output sent to browser
DEBUG - 2018-06-30 13:26:35 --> Total execution time: 0.0461
INFO - 2018-06-30 13:27:02 --> Config Class Initialized
INFO - 2018-06-30 13:27:02 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:27:02 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:27:02 --> Utf8 Class Initialized
INFO - 2018-06-30 13:27:02 --> URI Class Initialized
INFO - 2018-06-30 13:27:02 --> Router Class Initialized
INFO - 2018-06-30 13:27:02 --> Output Class Initialized
INFO - 2018-06-30 13:27:02 --> Security Class Initialized
DEBUG - 2018-06-30 13:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:27:02 --> CSRF cookie sent
INFO - 2018-06-30 13:27:02 --> CSRF token verified
INFO - 2018-06-30 13:27:02 --> Input Class Initialized
INFO - 2018-06-30 13:27:02 --> Language Class Initialized
INFO - 2018-06-30 13:27:02 --> Loader Class Initialized
INFO - 2018-06-30 13:27:02 --> Helper loaded: url_helper
INFO - 2018-06-30 13:27:02 --> Helper loaded: form_helper
INFO - 2018-06-30 13:27:02 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:27:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:27:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:27:02 --> User Agent Class Initialized
INFO - 2018-06-30 13:27:02 --> Controller Class Initialized
INFO - 2018-06-30 13:27:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:27:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:27:02 --> Pixel_Model class loaded
INFO - 2018-06-30 13:27:02 --> Database Driver Class Initialized
INFO - 2018-06-30 13:27:02 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:27:02 --> Form Validation Class Initialized
INFO - 2018-06-30 13:27:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-30 13:27:02 --> Database Driver Class Initialized
INFO - 2018-06-30 13:27:02 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:27:02 --> Config Class Initialized
INFO - 2018-06-30 13:27:02 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:27:02 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:27:02 --> Utf8 Class Initialized
INFO - 2018-06-30 13:27:02 --> URI Class Initialized
INFO - 2018-06-30 13:27:02 --> Router Class Initialized
INFO - 2018-06-30 13:27:02 --> Output Class Initialized
INFO - 2018-06-30 13:27:02 --> Security Class Initialized
DEBUG - 2018-06-30 13:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:27:02 --> CSRF cookie sent
INFO - 2018-06-30 13:27:02 --> Input Class Initialized
INFO - 2018-06-30 13:27:02 --> Language Class Initialized
INFO - 2018-06-30 13:27:02 --> Loader Class Initialized
INFO - 2018-06-30 13:27:02 --> Helper loaded: url_helper
INFO - 2018-06-30 13:27:02 --> Helper loaded: form_helper
INFO - 2018-06-30 13:27:02 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:27:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:27:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:27:02 --> User Agent Class Initialized
INFO - 2018-06-30 13:27:02 --> Controller Class Initialized
INFO - 2018-06-30 13:27:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:27:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:27:02 --> Pixel_Model class loaded
INFO - 2018-06-30 13:27:02 --> Database Driver Class Initialized
INFO - 2018-06-30 13:27:02 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:27:02 --> Database Driver Class Initialized
INFO - 2018-06-30 13:27:02 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:27:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 13:27:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-06-30 13:27:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 13:27:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 13:27:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 13:27:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-30 13:27:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-30 13:27:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/trust_info.php
INFO - 2018-06-30 13:27:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 13:27:02 --> Final output sent to browser
DEBUG - 2018-06-30 13:27:02 --> Total execution time: 0.0422
INFO - 2018-06-30 13:27:18 --> Config Class Initialized
INFO - 2018-06-30 13:27:18 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:27:18 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:27:18 --> Utf8 Class Initialized
INFO - 2018-06-30 13:27:18 --> URI Class Initialized
INFO - 2018-06-30 13:27:18 --> Router Class Initialized
INFO - 2018-06-30 13:27:18 --> Output Class Initialized
INFO - 2018-06-30 13:27:18 --> Security Class Initialized
DEBUG - 2018-06-30 13:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:27:18 --> CSRF cookie sent
INFO - 2018-06-30 13:27:18 --> CSRF token verified
INFO - 2018-06-30 13:27:18 --> Input Class Initialized
INFO - 2018-06-30 13:27:18 --> Language Class Initialized
INFO - 2018-06-30 13:27:18 --> Loader Class Initialized
INFO - 2018-06-30 13:27:18 --> Helper loaded: url_helper
INFO - 2018-06-30 13:27:18 --> Helper loaded: form_helper
INFO - 2018-06-30 13:27:18 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:27:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:27:18 --> User Agent Class Initialized
INFO - 2018-06-30 13:27:18 --> Controller Class Initialized
INFO - 2018-06-30 13:27:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:27:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:27:18 --> Pixel_Model class loaded
INFO - 2018-06-30 13:27:18 --> Database Driver Class Initialized
INFO - 2018-06-30 13:27:18 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:27:18 --> Form Validation Class Initialized
INFO - 2018-06-30 13:27:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-30 13:27:18 --> Database Driver Class Initialized
INFO - 2018-06-30 13:27:18 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:27:19 --> Config Class Initialized
INFO - 2018-06-30 13:27:19 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:27:19 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:27:19 --> Utf8 Class Initialized
INFO - 2018-06-30 13:27:19 --> URI Class Initialized
INFO - 2018-06-30 13:27:19 --> Router Class Initialized
INFO - 2018-06-30 13:27:19 --> Output Class Initialized
INFO - 2018-06-30 13:27:19 --> Security Class Initialized
DEBUG - 2018-06-30 13:27:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:27:19 --> CSRF cookie sent
INFO - 2018-06-30 13:27:19 --> Input Class Initialized
INFO - 2018-06-30 13:27:19 --> Language Class Initialized
INFO - 2018-06-30 13:27:19 --> Loader Class Initialized
INFO - 2018-06-30 13:27:19 --> Helper loaded: url_helper
INFO - 2018-06-30 13:27:19 --> Helper loaded: form_helper
INFO - 2018-06-30 13:27:19 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:27:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:27:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:27:19 --> User Agent Class Initialized
INFO - 2018-06-30 13:27:19 --> Controller Class Initialized
INFO - 2018-06-30 13:27:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:27:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:27:19 --> Pixel_Model class loaded
INFO - 2018-06-30 13:27:19 --> Database Driver Class Initialized
INFO - 2018-06-30 13:27:19 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:27:19 --> Database Driver Class Initialized
INFO - 2018-06-30 13:27:19 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:27:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 13:27:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-06-30 13:27:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 13:27:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 13:27:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 13:27:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-30 13:27:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-30 13:27:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inherited_income.php
INFO - 2018-06-30 13:27:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 13:27:19 --> Final output sent to browser
DEBUG - 2018-06-30 13:27:19 --> Total execution time: 0.0594
INFO - 2018-06-30 13:27:33 --> Config Class Initialized
INFO - 2018-06-30 13:27:33 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:27:33 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:27:33 --> Utf8 Class Initialized
INFO - 2018-06-30 13:27:33 --> URI Class Initialized
INFO - 2018-06-30 13:27:33 --> Router Class Initialized
INFO - 2018-06-30 13:27:33 --> Output Class Initialized
INFO - 2018-06-30 13:27:33 --> Security Class Initialized
DEBUG - 2018-06-30 13:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:27:33 --> CSRF cookie sent
INFO - 2018-06-30 13:27:33 --> CSRF token verified
INFO - 2018-06-30 13:27:33 --> Input Class Initialized
INFO - 2018-06-30 13:27:33 --> Language Class Initialized
INFO - 2018-06-30 13:27:33 --> Loader Class Initialized
INFO - 2018-06-30 13:27:33 --> Helper loaded: url_helper
INFO - 2018-06-30 13:27:33 --> Helper loaded: form_helper
INFO - 2018-06-30 13:27:33 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:27:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:27:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:27:33 --> User Agent Class Initialized
INFO - 2018-06-30 13:27:33 --> Controller Class Initialized
INFO - 2018-06-30 13:27:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:27:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:27:33 --> Pixel_Model class loaded
INFO - 2018-06-30 13:27:33 --> Database Driver Class Initialized
INFO - 2018-06-30 13:27:33 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:27:33 --> Form Validation Class Initialized
INFO - 2018-06-30 13:27:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-30 13:27:33 --> Database Driver Class Initialized
INFO - 2018-06-30 13:27:33 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:27:33 --> Config Class Initialized
INFO - 2018-06-30 13:27:33 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:27:33 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:27:33 --> Utf8 Class Initialized
INFO - 2018-06-30 13:27:33 --> URI Class Initialized
INFO - 2018-06-30 13:27:33 --> Router Class Initialized
INFO - 2018-06-30 13:27:33 --> Output Class Initialized
INFO - 2018-06-30 13:27:33 --> Security Class Initialized
DEBUG - 2018-06-30 13:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:27:33 --> CSRF cookie sent
INFO - 2018-06-30 13:27:33 --> Input Class Initialized
INFO - 2018-06-30 13:27:33 --> Language Class Initialized
INFO - 2018-06-30 13:27:33 --> Loader Class Initialized
INFO - 2018-06-30 13:27:33 --> Helper loaded: url_helper
INFO - 2018-06-30 13:27:33 --> Helper loaded: form_helper
INFO - 2018-06-30 13:27:33 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:27:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:27:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:27:33 --> User Agent Class Initialized
INFO - 2018-06-30 13:27:33 --> Controller Class Initialized
INFO - 2018-06-30 13:27:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:27:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:27:33 --> Pixel_Model class loaded
INFO - 2018-06-30 13:27:33 --> Database Driver Class Initialized
INFO - 2018-06-30 13:27:33 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:27:33 --> Database Driver Class Initialized
INFO - 2018-06-30 13:27:33 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:27:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 13:27:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-06-30 13:27:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 13:27:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 13:27:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 13:27:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-30 13:27:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-30 13:27:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/shift_work.php
INFO - 2018-06-30 13:27:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 13:27:33 --> Final output sent to browser
DEBUG - 2018-06-30 13:27:33 --> Total execution time: 0.0398
INFO - 2018-06-30 13:27:40 --> Config Class Initialized
INFO - 2018-06-30 13:27:40 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:27:40 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:27:40 --> Utf8 Class Initialized
INFO - 2018-06-30 13:27:40 --> URI Class Initialized
INFO - 2018-06-30 13:27:40 --> Router Class Initialized
INFO - 2018-06-30 13:27:40 --> Output Class Initialized
INFO - 2018-06-30 13:27:40 --> Security Class Initialized
DEBUG - 2018-06-30 13:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:27:40 --> CSRF cookie sent
INFO - 2018-06-30 13:27:40 --> CSRF token verified
INFO - 2018-06-30 13:27:40 --> Input Class Initialized
INFO - 2018-06-30 13:27:40 --> Language Class Initialized
INFO - 2018-06-30 13:27:40 --> Loader Class Initialized
INFO - 2018-06-30 13:27:40 --> Helper loaded: url_helper
INFO - 2018-06-30 13:27:40 --> Helper loaded: form_helper
INFO - 2018-06-30 13:27:40 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:27:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:27:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:27:40 --> User Agent Class Initialized
INFO - 2018-06-30 13:27:40 --> Controller Class Initialized
INFO - 2018-06-30 13:27:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:27:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:27:40 --> Pixel_Model class loaded
INFO - 2018-06-30 13:27:40 --> Database Driver Class Initialized
INFO - 2018-06-30 13:27:40 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:27:40 --> Form Validation Class Initialized
INFO - 2018-06-30 13:27:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-30 13:27:40 --> Database Driver Class Initialized
INFO - 2018-06-30 13:27:40 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:27:40 --> Config Class Initialized
INFO - 2018-06-30 13:27:40 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:27:40 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:27:40 --> Utf8 Class Initialized
INFO - 2018-06-30 13:27:40 --> URI Class Initialized
INFO - 2018-06-30 13:27:40 --> Router Class Initialized
INFO - 2018-06-30 13:27:40 --> Output Class Initialized
INFO - 2018-06-30 13:27:40 --> Security Class Initialized
DEBUG - 2018-06-30 13:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:27:40 --> CSRF cookie sent
INFO - 2018-06-30 13:27:40 --> Input Class Initialized
INFO - 2018-06-30 13:27:40 --> Language Class Initialized
INFO - 2018-06-30 13:27:40 --> Loader Class Initialized
INFO - 2018-06-30 13:27:40 --> Helper loaded: url_helper
INFO - 2018-06-30 13:27:40 --> Helper loaded: form_helper
INFO - 2018-06-30 13:27:40 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:27:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:27:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:27:40 --> User Agent Class Initialized
INFO - 2018-06-30 13:27:40 --> Controller Class Initialized
INFO - 2018-06-30 13:27:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:27:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:27:40 --> Pixel_Model class loaded
INFO - 2018-06-30 13:27:40 --> Database Driver Class Initialized
INFO - 2018-06-30 13:27:40 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:27:40 --> Database Driver Class Initialized
INFO - 2018-06-30 13:27:40 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:27:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 13:27:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-06-30 13:27:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 13:27:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 13:27:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 13:27:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-30 13:27:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-30 13:27:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/night_without_s.php
INFO - 2018-06-30 13:27:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 13:27:40 --> Final output sent to browser
DEBUG - 2018-06-30 13:27:40 --> Total execution time: 0.0418
INFO - 2018-06-30 13:27:53 --> Config Class Initialized
INFO - 2018-06-30 13:27:53 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:27:53 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:27:53 --> Utf8 Class Initialized
INFO - 2018-06-30 13:27:53 --> URI Class Initialized
INFO - 2018-06-30 13:27:53 --> Router Class Initialized
INFO - 2018-06-30 13:27:53 --> Output Class Initialized
INFO - 2018-06-30 13:27:53 --> Security Class Initialized
DEBUG - 2018-06-30 13:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:27:53 --> CSRF cookie sent
INFO - 2018-06-30 13:27:53 --> CSRF token verified
INFO - 2018-06-30 13:27:53 --> Input Class Initialized
INFO - 2018-06-30 13:27:53 --> Language Class Initialized
INFO - 2018-06-30 13:27:53 --> Loader Class Initialized
INFO - 2018-06-30 13:27:53 --> Helper loaded: url_helper
INFO - 2018-06-30 13:27:53 --> Helper loaded: form_helper
INFO - 2018-06-30 13:27:53 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:27:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:27:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:27:53 --> User Agent Class Initialized
INFO - 2018-06-30 13:27:53 --> Controller Class Initialized
INFO - 2018-06-30 13:27:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:27:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:27:53 --> Pixel_Model class loaded
INFO - 2018-06-30 13:27:53 --> Database Driver Class Initialized
INFO - 2018-06-30 13:27:53 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:27:53 --> Form Validation Class Initialized
INFO - 2018-06-30 13:27:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-30 13:27:53 --> Database Driver Class Initialized
INFO - 2018-06-30 13:27:53 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:27:54 --> Config Class Initialized
INFO - 2018-06-30 13:27:54 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:27:54 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:27:54 --> Utf8 Class Initialized
INFO - 2018-06-30 13:27:54 --> URI Class Initialized
INFO - 2018-06-30 13:27:54 --> Router Class Initialized
INFO - 2018-06-30 13:27:54 --> Output Class Initialized
INFO - 2018-06-30 13:27:54 --> Security Class Initialized
DEBUG - 2018-06-30 13:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:27:54 --> CSRF cookie sent
INFO - 2018-06-30 13:27:54 --> Input Class Initialized
INFO - 2018-06-30 13:27:54 --> Language Class Initialized
INFO - 2018-06-30 13:27:54 --> Loader Class Initialized
INFO - 2018-06-30 13:27:54 --> Helper loaded: url_helper
INFO - 2018-06-30 13:27:54 --> Helper loaded: form_helper
INFO - 2018-06-30 13:27:54 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:27:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:27:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:27:54 --> User Agent Class Initialized
INFO - 2018-06-30 13:27:54 --> Controller Class Initialized
INFO - 2018-06-30 13:27:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:27:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:27:54 --> Pixel_Model class loaded
INFO - 2018-06-30 13:27:54 --> Database Driver Class Initialized
INFO - 2018-06-30 13:27:54 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:27:54 --> Database Driver Class Initialized
INFO - 2018-06-30 13:27:54 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:27:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 13:27:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-06-30 13:27:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 13:27:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 13:27:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 13:27:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-30 13:27:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-30 13:27:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/have_date.php
INFO - 2018-06-30 13:27:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 13:27:54 --> Final output sent to browser
DEBUG - 2018-06-30 13:27:54 --> Total execution time: 0.0422
INFO - 2018-06-30 13:28:02 --> Config Class Initialized
INFO - 2018-06-30 13:28:02 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:28:02 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:28:02 --> Utf8 Class Initialized
INFO - 2018-06-30 13:28:02 --> URI Class Initialized
INFO - 2018-06-30 13:28:02 --> Router Class Initialized
INFO - 2018-06-30 13:28:02 --> Output Class Initialized
INFO - 2018-06-30 13:28:02 --> Security Class Initialized
DEBUG - 2018-06-30 13:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:28:02 --> CSRF cookie sent
INFO - 2018-06-30 13:28:02 --> CSRF token verified
INFO - 2018-06-30 13:28:02 --> Input Class Initialized
INFO - 2018-06-30 13:28:02 --> Language Class Initialized
INFO - 2018-06-30 13:28:02 --> Loader Class Initialized
INFO - 2018-06-30 13:28:02 --> Helper loaded: url_helper
INFO - 2018-06-30 13:28:02 --> Helper loaded: form_helper
INFO - 2018-06-30 13:28:02 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:28:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:28:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:28:02 --> User Agent Class Initialized
INFO - 2018-06-30 13:28:02 --> Controller Class Initialized
INFO - 2018-06-30 13:28:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:28:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:28:02 --> Pixel_Model class loaded
INFO - 2018-06-30 13:28:02 --> Database Driver Class Initialized
INFO - 2018-06-30 13:28:02 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:28:02 --> Form Validation Class Initialized
INFO - 2018-06-30 13:28:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-30 13:28:02 --> Database Driver Class Initialized
INFO - 2018-06-30 13:28:02 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:28:02 --> Config Class Initialized
INFO - 2018-06-30 13:28:02 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:28:02 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:28:02 --> Utf8 Class Initialized
INFO - 2018-06-30 13:28:02 --> URI Class Initialized
INFO - 2018-06-30 13:28:02 --> Router Class Initialized
INFO - 2018-06-30 13:28:02 --> Output Class Initialized
INFO - 2018-06-30 13:28:02 --> Security Class Initialized
DEBUG - 2018-06-30 13:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:28:02 --> CSRF cookie sent
INFO - 2018-06-30 13:28:02 --> Input Class Initialized
INFO - 2018-06-30 13:28:02 --> Language Class Initialized
INFO - 2018-06-30 13:28:02 --> Loader Class Initialized
INFO - 2018-06-30 13:28:02 --> Helper loaded: url_helper
INFO - 2018-06-30 13:28:02 --> Helper loaded: form_helper
INFO - 2018-06-30 13:28:02 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:28:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:28:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:28:02 --> User Agent Class Initialized
INFO - 2018-06-30 13:28:02 --> Controller Class Initialized
INFO - 2018-06-30 13:28:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:28:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:28:02 --> Pixel_Model class loaded
INFO - 2018-06-30 13:28:02 --> Database Driver Class Initialized
INFO - 2018-06-30 13:28:02 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:28:02 --> Database Driver Class Initialized
INFO - 2018-06-30 13:28:02 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:28:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 13:28:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-06-30 13:28:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 13:28:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 13:28:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 13:28:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-30 13:28:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-30 13:28:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/nights_not_home.php
INFO - 2018-06-30 13:28:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 13:28:02 --> Final output sent to browser
DEBUG - 2018-06-30 13:28:02 --> Total execution time: 0.0432
INFO - 2018-06-30 13:28:09 --> Config Class Initialized
INFO - 2018-06-30 13:28:09 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:28:09 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:28:09 --> Utf8 Class Initialized
INFO - 2018-06-30 13:28:09 --> URI Class Initialized
INFO - 2018-06-30 13:28:09 --> Router Class Initialized
INFO - 2018-06-30 13:28:09 --> Output Class Initialized
INFO - 2018-06-30 13:28:09 --> Security Class Initialized
DEBUG - 2018-06-30 13:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:28:09 --> CSRF cookie sent
INFO - 2018-06-30 13:28:09 --> CSRF token verified
INFO - 2018-06-30 13:28:09 --> Input Class Initialized
INFO - 2018-06-30 13:28:09 --> Language Class Initialized
INFO - 2018-06-30 13:28:09 --> Loader Class Initialized
INFO - 2018-06-30 13:28:09 --> Helper loaded: url_helper
INFO - 2018-06-30 13:28:09 --> Helper loaded: form_helper
INFO - 2018-06-30 13:28:09 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:28:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:28:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:28:09 --> User Agent Class Initialized
INFO - 2018-06-30 13:28:09 --> Controller Class Initialized
INFO - 2018-06-30 13:28:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:28:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:28:09 --> Pixel_Model class loaded
INFO - 2018-06-30 13:28:09 --> Database Driver Class Initialized
INFO - 2018-06-30 13:28:09 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:28:09 --> Form Validation Class Initialized
INFO - 2018-06-30 13:28:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-30 13:28:09 --> Database Driver Class Initialized
INFO - 2018-06-30 13:28:09 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:28:09 --> Config Class Initialized
INFO - 2018-06-30 13:28:09 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:28:09 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:28:09 --> Utf8 Class Initialized
INFO - 2018-06-30 13:28:09 --> URI Class Initialized
INFO - 2018-06-30 13:28:09 --> Router Class Initialized
INFO - 2018-06-30 13:28:09 --> Output Class Initialized
INFO - 2018-06-30 13:28:09 --> Security Class Initialized
DEBUG - 2018-06-30 13:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:28:09 --> CSRF cookie sent
INFO - 2018-06-30 13:28:09 --> Input Class Initialized
INFO - 2018-06-30 13:28:09 --> Language Class Initialized
INFO - 2018-06-30 13:28:09 --> Loader Class Initialized
INFO - 2018-06-30 13:28:09 --> Helper loaded: url_helper
INFO - 2018-06-30 13:28:09 --> Helper loaded: form_helper
INFO - 2018-06-30 13:28:09 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:28:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:28:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:28:09 --> User Agent Class Initialized
INFO - 2018-06-30 13:28:09 --> Controller Class Initialized
INFO - 2018-06-30 13:28:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:28:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:28:09 --> Pixel_Model class loaded
INFO - 2018-06-30 13:28:09 --> Database Driver Class Initialized
INFO - 2018-06-30 13:28:09 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:28:09 --> Database Driver Class Initialized
INFO - 2018-06-30 13:28:09 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:28:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 13:28:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-06-30 13:28:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 13:28:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 13:28:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 13:28:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-30 13:28:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-30 13:28:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/s_nights_not_home.php
INFO - 2018-06-30 13:28:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 13:28:09 --> Final output sent to browser
DEBUG - 2018-06-30 13:28:09 --> Total execution time: 0.0389
INFO - 2018-06-30 13:28:18 --> Config Class Initialized
INFO - 2018-06-30 13:28:18 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:28:18 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:28:18 --> Utf8 Class Initialized
INFO - 2018-06-30 13:28:18 --> URI Class Initialized
INFO - 2018-06-30 13:28:18 --> Router Class Initialized
INFO - 2018-06-30 13:28:18 --> Output Class Initialized
INFO - 2018-06-30 13:28:18 --> Security Class Initialized
DEBUG - 2018-06-30 13:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:28:18 --> CSRF cookie sent
INFO - 2018-06-30 13:28:18 --> CSRF token verified
INFO - 2018-06-30 13:28:18 --> Input Class Initialized
INFO - 2018-06-30 13:28:18 --> Language Class Initialized
INFO - 2018-06-30 13:28:18 --> Loader Class Initialized
INFO - 2018-06-30 13:28:18 --> Helper loaded: url_helper
INFO - 2018-06-30 13:28:18 --> Helper loaded: form_helper
INFO - 2018-06-30 13:28:18 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:28:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:28:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:28:18 --> User Agent Class Initialized
INFO - 2018-06-30 13:28:18 --> Controller Class Initialized
INFO - 2018-06-30 13:28:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:28:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:28:18 --> Pixel_Model class loaded
INFO - 2018-06-30 13:28:18 --> Database Driver Class Initialized
INFO - 2018-06-30 13:28:18 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:28:18 --> Form Validation Class Initialized
INFO - 2018-06-30 13:28:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-30 13:28:18 --> Database Driver Class Initialized
INFO - 2018-06-30 13:28:18 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:28:18 --> Config Class Initialized
INFO - 2018-06-30 13:28:18 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:28:18 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:28:18 --> Utf8 Class Initialized
INFO - 2018-06-30 13:28:18 --> URI Class Initialized
INFO - 2018-06-30 13:28:18 --> Router Class Initialized
INFO - 2018-06-30 13:28:18 --> Output Class Initialized
INFO - 2018-06-30 13:28:18 --> Security Class Initialized
DEBUG - 2018-06-30 13:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:28:18 --> CSRF cookie sent
INFO - 2018-06-30 13:28:18 --> Input Class Initialized
INFO - 2018-06-30 13:28:18 --> Language Class Initialized
INFO - 2018-06-30 13:28:18 --> Loader Class Initialized
INFO - 2018-06-30 13:28:18 --> Helper loaded: url_helper
INFO - 2018-06-30 13:28:18 --> Helper loaded: form_helper
INFO - 2018-06-30 13:28:18 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:28:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:28:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:28:18 --> User Agent Class Initialized
INFO - 2018-06-30 13:28:18 --> Controller Class Initialized
INFO - 2018-06-30 13:28:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:28:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:28:18 --> Pixel_Model class loaded
INFO - 2018-06-30 13:28:18 --> Database Driver Class Initialized
INFO - 2018-06-30 13:28:18 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:28:18 --> Database Driver Class Initialized
INFO - 2018-06-30 13:28:18 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:28:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 13:28:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-06-30 13:28:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 13:28:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 13:28:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 13:28:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-30 13:28:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-30 13:28:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/s_nights_without_you.php
INFO - 2018-06-30 13:28:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 13:28:18 --> Final output sent to browser
DEBUG - 2018-06-30 13:28:18 --> Total execution time: 0.0428
INFO - 2018-06-30 13:28:24 --> Config Class Initialized
INFO - 2018-06-30 13:28:24 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:28:24 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:28:24 --> Utf8 Class Initialized
INFO - 2018-06-30 13:28:24 --> URI Class Initialized
INFO - 2018-06-30 13:28:24 --> Router Class Initialized
INFO - 2018-06-30 13:28:24 --> Output Class Initialized
INFO - 2018-06-30 13:28:24 --> Security Class Initialized
DEBUG - 2018-06-30 13:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:28:24 --> CSRF cookie sent
INFO - 2018-06-30 13:28:24 --> CSRF token verified
INFO - 2018-06-30 13:28:24 --> Input Class Initialized
INFO - 2018-06-30 13:28:24 --> Language Class Initialized
INFO - 2018-06-30 13:28:24 --> Loader Class Initialized
INFO - 2018-06-30 13:28:24 --> Helper loaded: url_helper
INFO - 2018-06-30 13:28:24 --> Helper loaded: form_helper
INFO - 2018-06-30 13:28:24 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:28:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:28:24 --> User Agent Class Initialized
INFO - 2018-06-30 13:28:24 --> Controller Class Initialized
INFO - 2018-06-30 13:28:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:28:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:28:24 --> Pixel_Model class loaded
INFO - 2018-06-30 13:28:24 --> Database Driver Class Initialized
INFO - 2018-06-30 13:28:24 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:28:24 --> Form Validation Class Initialized
INFO - 2018-06-30 13:28:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-30 13:28:24 --> Database Driver Class Initialized
INFO - 2018-06-30 13:28:24 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:28:24 --> Config Class Initialized
INFO - 2018-06-30 13:28:24 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:28:24 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:28:24 --> Utf8 Class Initialized
INFO - 2018-06-30 13:28:24 --> URI Class Initialized
INFO - 2018-06-30 13:28:24 --> Router Class Initialized
INFO - 2018-06-30 13:28:24 --> Output Class Initialized
INFO - 2018-06-30 13:28:24 --> Security Class Initialized
DEBUG - 2018-06-30 13:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:28:24 --> CSRF cookie sent
INFO - 2018-06-30 13:28:24 --> Input Class Initialized
INFO - 2018-06-30 13:28:24 --> Language Class Initialized
INFO - 2018-06-30 13:28:24 --> Loader Class Initialized
INFO - 2018-06-30 13:28:24 --> Helper loaded: url_helper
INFO - 2018-06-30 13:28:24 --> Helper loaded: form_helper
INFO - 2018-06-30 13:28:24 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:28:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:28:24 --> User Agent Class Initialized
INFO - 2018-06-30 13:28:24 --> Controller Class Initialized
INFO - 2018-06-30 13:28:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:28:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:28:24 --> Pixel_Model class loaded
INFO - 2018-06-30 13:28:24 --> Database Driver Class Initialized
INFO - 2018-06-30 13:28:24 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:28:24 --> Database Driver Class Initialized
INFO - 2018-06-30 13:28:24 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:28:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 13:28:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-06-30 13:28:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 13:28:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 13:28:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 13:28:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-30 13:28:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-30 13:28:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/alcoholic_drinks_per_week.php
INFO - 2018-06-30 13:28:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 13:28:24 --> Final output sent to browser
DEBUG - 2018-06-30 13:28:24 --> Total execution time: 0.0448
INFO - 2018-06-30 13:28:26 --> Config Class Initialized
INFO - 2018-06-30 13:28:26 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:28:26 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:28:26 --> Utf8 Class Initialized
INFO - 2018-06-30 13:28:26 --> URI Class Initialized
INFO - 2018-06-30 13:28:26 --> Router Class Initialized
INFO - 2018-06-30 13:28:26 --> Output Class Initialized
INFO - 2018-06-30 13:28:26 --> Security Class Initialized
DEBUG - 2018-06-30 13:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:28:26 --> CSRF cookie sent
INFO - 2018-06-30 13:28:26 --> CSRF token verified
INFO - 2018-06-30 13:28:26 --> Input Class Initialized
INFO - 2018-06-30 13:28:26 --> Language Class Initialized
INFO - 2018-06-30 13:28:26 --> Loader Class Initialized
INFO - 2018-06-30 13:28:26 --> Helper loaded: url_helper
INFO - 2018-06-30 13:28:26 --> Helper loaded: form_helper
INFO - 2018-06-30 13:28:26 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:28:26 --> User Agent Class Initialized
INFO - 2018-06-30 13:28:26 --> Controller Class Initialized
INFO - 2018-06-30 13:28:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:28:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:28:26 --> Pixel_Model class loaded
INFO - 2018-06-30 13:28:26 --> Database Driver Class Initialized
INFO - 2018-06-30 13:28:26 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:28:26 --> Form Validation Class Initialized
INFO - 2018-06-30 13:28:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-30 13:28:26 --> Database Driver Class Initialized
INFO - 2018-06-30 13:28:26 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:28:26 --> Config Class Initialized
INFO - 2018-06-30 13:28:26 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:28:26 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:28:26 --> Utf8 Class Initialized
INFO - 2018-06-30 13:28:26 --> URI Class Initialized
INFO - 2018-06-30 13:28:26 --> Router Class Initialized
INFO - 2018-06-30 13:28:26 --> Output Class Initialized
INFO - 2018-06-30 13:28:26 --> Security Class Initialized
DEBUG - 2018-06-30 13:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:28:26 --> CSRF cookie sent
INFO - 2018-06-30 13:28:26 --> Input Class Initialized
INFO - 2018-06-30 13:28:26 --> Language Class Initialized
INFO - 2018-06-30 13:28:26 --> Loader Class Initialized
INFO - 2018-06-30 13:28:26 --> Helper loaded: url_helper
INFO - 2018-06-30 13:28:26 --> Helper loaded: form_helper
INFO - 2018-06-30 13:28:26 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:28:26 --> User Agent Class Initialized
INFO - 2018-06-30 13:28:26 --> Controller Class Initialized
INFO - 2018-06-30 13:28:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:28:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:28:26 --> Pixel_Model class loaded
INFO - 2018-06-30 13:28:26 --> Database Driver Class Initialized
INFO - 2018-06-30 13:28:26 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:28:26 --> Database Driver Class Initialized
INFO - 2018-06-30 13:28:26 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:28:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 13:28:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-06-30 13:28:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 13:28:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 13:28:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 13:28:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-30 13:28:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-30 13:28:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/have_drugs.php
INFO - 2018-06-30 13:28:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 13:28:26 --> Final output sent to browser
DEBUG - 2018-06-30 13:28:26 --> Total execution time: 0.0382
INFO - 2018-06-30 13:28:29 --> Config Class Initialized
INFO - 2018-06-30 13:28:29 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:28:29 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:28:29 --> Utf8 Class Initialized
INFO - 2018-06-30 13:28:29 --> URI Class Initialized
INFO - 2018-06-30 13:28:29 --> Router Class Initialized
INFO - 2018-06-30 13:28:29 --> Output Class Initialized
INFO - 2018-06-30 13:28:29 --> Security Class Initialized
DEBUG - 2018-06-30 13:28:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:28:29 --> CSRF cookie sent
INFO - 2018-06-30 13:28:29 --> CSRF token verified
INFO - 2018-06-30 13:28:29 --> Input Class Initialized
INFO - 2018-06-30 13:28:29 --> Language Class Initialized
INFO - 2018-06-30 13:28:29 --> Loader Class Initialized
INFO - 2018-06-30 13:28:29 --> Helper loaded: url_helper
INFO - 2018-06-30 13:28:29 --> Helper loaded: form_helper
INFO - 2018-06-30 13:28:29 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:28:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:28:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:28:29 --> User Agent Class Initialized
INFO - 2018-06-30 13:28:29 --> Controller Class Initialized
INFO - 2018-06-30 13:28:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:28:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:28:29 --> Pixel_Model class loaded
INFO - 2018-06-30 13:28:29 --> Database Driver Class Initialized
INFO - 2018-06-30 13:28:29 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:28:29 --> Form Validation Class Initialized
INFO - 2018-06-30 13:28:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-30 13:28:29 --> Database Driver Class Initialized
INFO - 2018-06-30 13:28:29 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:28:29 --> Config Class Initialized
INFO - 2018-06-30 13:28:29 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:28:29 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:28:29 --> Utf8 Class Initialized
INFO - 2018-06-30 13:28:29 --> URI Class Initialized
INFO - 2018-06-30 13:28:29 --> Router Class Initialized
INFO - 2018-06-30 13:28:29 --> Output Class Initialized
INFO - 2018-06-30 13:28:29 --> Security Class Initialized
DEBUG - 2018-06-30 13:28:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:28:29 --> CSRF cookie sent
INFO - 2018-06-30 13:28:29 --> Input Class Initialized
INFO - 2018-06-30 13:28:29 --> Language Class Initialized
INFO - 2018-06-30 13:28:29 --> Loader Class Initialized
INFO - 2018-06-30 13:28:29 --> Helper loaded: url_helper
INFO - 2018-06-30 13:28:29 --> Helper loaded: form_helper
INFO - 2018-06-30 13:28:29 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:28:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:28:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:28:29 --> User Agent Class Initialized
INFO - 2018-06-30 13:28:29 --> Controller Class Initialized
INFO - 2018-06-30 13:28:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:28:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:28:29 --> Pixel_Model class loaded
INFO - 2018-06-30 13:28:29 --> Database Driver Class Initialized
INFO - 2018-06-30 13:28:29 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:28:29 --> Database Driver Class Initialized
INFO - 2018-06-30 13:28:29 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:28:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 13:28:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-06-30 13:28:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 13:28:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 13:28:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 13:28:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-30 13:28:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-30 13:28:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/has_addiction_problem.php
INFO - 2018-06-30 13:28:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 13:28:29 --> Final output sent to browser
DEBUG - 2018-06-30 13:28:29 --> Total execution time: 0.0477
INFO - 2018-06-30 13:28:35 --> Config Class Initialized
INFO - 2018-06-30 13:28:35 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:28:35 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:28:35 --> Utf8 Class Initialized
INFO - 2018-06-30 13:28:35 --> URI Class Initialized
INFO - 2018-06-30 13:28:35 --> Router Class Initialized
INFO - 2018-06-30 13:28:35 --> Output Class Initialized
INFO - 2018-06-30 13:28:35 --> Security Class Initialized
DEBUG - 2018-06-30 13:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:28:35 --> CSRF cookie sent
INFO - 2018-06-30 13:28:35 --> CSRF token verified
INFO - 2018-06-30 13:28:35 --> Input Class Initialized
INFO - 2018-06-30 13:28:35 --> Language Class Initialized
INFO - 2018-06-30 13:28:35 --> Loader Class Initialized
INFO - 2018-06-30 13:28:35 --> Helper loaded: url_helper
INFO - 2018-06-30 13:28:35 --> Helper loaded: form_helper
INFO - 2018-06-30 13:28:35 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:28:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:28:35 --> User Agent Class Initialized
INFO - 2018-06-30 13:28:35 --> Controller Class Initialized
INFO - 2018-06-30 13:28:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:28:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:28:35 --> Pixel_Model class loaded
INFO - 2018-06-30 13:28:35 --> Database Driver Class Initialized
INFO - 2018-06-30 13:28:35 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:28:35 --> Form Validation Class Initialized
INFO - 2018-06-30 13:28:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-30 13:28:35 --> Database Driver Class Initialized
INFO - 2018-06-30 13:28:35 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:28:35 --> Config Class Initialized
INFO - 2018-06-30 13:28:35 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:28:35 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:28:35 --> Utf8 Class Initialized
INFO - 2018-06-30 13:28:35 --> URI Class Initialized
INFO - 2018-06-30 13:28:35 --> Router Class Initialized
INFO - 2018-06-30 13:28:35 --> Output Class Initialized
INFO - 2018-06-30 13:28:35 --> Security Class Initialized
DEBUG - 2018-06-30 13:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:28:35 --> CSRF cookie sent
INFO - 2018-06-30 13:28:35 --> Input Class Initialized
INFO - 2018-06-30 13:28:35 --> Language Class Initialized
INFO - 2018-06-30 13:28:35 --> Loader Class Initialized
INFO - 2018-06-30 13:28:35 --> Helper loaded: url_helper
INFO - 2018-06-30 13:28:35 --> Helper loaded: form_helper
INFO - 2018-06-30 13:28:35 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:28:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:28:35 --> User Agent Class Initialized
INFO - 2018-06-30 13:28:35 --> Controller Class Initialized
INFO - 2018-06-30 13:28:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:28:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:28:35 --> Pixel_Model class loaded
INFO - 2018-06-30 13:28:35 --> Database Driver Class Initialized
INFO - 2018-06-30 13:28:35 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:28:35 --> Database Driver Class Initialized
INFO - 2018-06-30 13:28:35 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:28:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 13:28:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-06-30 13:28:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 13:28:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 13:28:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 13:28:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-30 13:28:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-30 13:28:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/have_hit_s.php
INFO - 2018-06-30 13:28:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 13:28:35 --> Final output sent to browser
DEBUG - 2018-06-30 13:28:35 --> Total execution time: 0.0466
INFO - 2018-06-30 13:28:42 --> Config Class Initialized
INFO - 2018-06-30 13:28:42 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:28:42 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:28:42 --> Utf8 Class Initialized
INFO - 2018-06-30 13:28:42 --> URI Class Initialized
INFO - 2018-06-30 13:28:42 --> Router Class Initialized
INFO - 2018-06-30 13:28:42 --> Output Class Initialized
INFO - 2018-06-30 13:28:42 --> Security Class Initialized
DEBUG - 2018-06-30 13:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:28:42 --> CSRF cookie sent
INFO - 2018-06-30 13:28:42 --> CSRF token verified
INFO - 2018-06-30 13:28:42 --> Input Class Initialized
INFO - 2018-06-30 13:28:42 --> Language Class Initialized
INFO - 2018-06-30 13:28:42 --> Loader Class Initialized
INFO - 2018-06-30 13:28:42 --> Helper loaded: url_helper
INFO - 2018-06-30 13:28:42 --> Helper loaded: form_helper
INFO - 2018-06-30 13:28:42 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:28:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:28:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:28:42 --> User Agent Class Initialized
INFO - 2018-06-30 13:28:42 --> Controller Class Initialized
INFO - 2018-06-30 13:28:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:28:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:28:42 --> Pixel_Model class loaded
INFO - 2018-06-30 13:28:42 --> Database Driver Class Initialized
INFO - 2018-06-30 13:28:42 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:28:42 --> Form Validation Class Initialized
INFO - 2018-06-30 13:28:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-30 13:28:42 --> Database Driver Class Initialized
INFO - 2018-06-30 13:28:42 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:28:42 --> Config Class Initialized
INFO - 2018-06-30 13:28:42 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:28:42 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:28:42 --> Utf8 Class Initialized
INFO - 2018-06-30 13:28:42 --> URI Class Initialized
INFO - 2018-06-30 13:28:42 --> Router Class Initialized
INFO - 2018-06-30 13:28:42 --> Output Class Initialized
INFO - 2018-06-30 13:28:42 --> Security Class Initialized
DEBUG - 2018-06-30 13:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:28:42 --> CSRF cookie sent
INFO - 2018-06-30 13:28:42 --> Input Class Initialized
INFO - 2018-06-30 13:28:42 --> Language Class Initialized
INFO - 2018-06-30 13:28:42 --> Loader Class Initialized
INFO - 2018-06-30 13:28:42 --> Helper loaded: url_helper
INFO - 2018-06-30 13:28:42 --> Helper loaded: form_helper
INFO - 2018-06-30 13:28:42 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:28:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:28:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:28:42 --> User Agent Class Initialized
INFO - 2018-06-30 13:28:42 --> Controller Class Initialized
INFO - 2018-06-30 13:28:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:28:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:28:42 --> Pixel_Model class loaded
INFO - 2018-06-30 13:28:42 --> Database Driver Class Initialized
INFO - 2018-06-30 13:28:42 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:28:42 --> Database Driver Class Initialized
INFO - 2018-06-30 13:28:42 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:28:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 13:28:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-06-30 13:28:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 13:28:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 13:28:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 13:28:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-30 13:28:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-30 13:28:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial_control.php
INFO - 2018-06-30 13:28:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 13:28:42 --> Final output sent to browser
DEBUG - 2018-06-30 13:28:42 --> Total execution time: 0.0499
INFO - 2018-06-30 13:28:44 --> Config Class Initialized
INFO - 2018-06-30 13:28:44 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:28:44 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:28:44 --> Utf8 Class Initialized
INFO - 2018-06-30 13:28:44 --> URI Class Initialized
INFO - 2018-06-30 13:28:44 --> Router Class Initialized
INFO - 2018-06-30 13:28:44 --> Output Class Initialized
INFO - 2018-06-30 13:28:44 --> Security Class Initialized
DEBUG - 2018-06-30 13:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:28:44 --> CSRF cookie sent
INFO - 2018-06-30 13:28:44 --> CSRF token verified
INFO - 2018-06-30 13:28:44 --> Input Class Initialized
INFO - 2018-06-30 13:28:44 --> Language Class Initialized
INFO - 2018-06-30 13:28:44 --> Loader Class Initialized
INFO - 2018-06-30 13:28:44 --> Helper loaded: url_helper
INFO - 2018-06-30 13:28:44 --> Helper loaded: form_helper
INFO - 2018-06-30 13:28:44 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:28:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:28:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:28:44 --> User Agent Class Initialized
INFO - 2018-06-30 13:28:44 --> Controller Class Initialized
INFO - 2018-06-30 13:28:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:28:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:28:44 --> Pixel_Model class loaded
INFO - 2018-06-30 13:28:44 --> Database Driver Class Initialized
INFO - 2018-06-30 13:28:44 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:28:44 --> Form Validation Class Initialized
INFO - 2018-06-30 13:28:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-30 13:28:44 --> Database Driver Class Initialized
INFO - 2018-06-30 13:28:44 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:28:45 --> Config Class Initialized
INFO - 2018-06-30 13:28:45 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:28:45 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:28:45 --> Utf8 Class Initialized
INFO - 2018-06-30 13:28:45 --> URI Class Initialized
INFO - 2018-06-30 13:28:45 --> Router Class Initialized
INFO - 2018-06-30 13:28:45 --> Output Class Initialized
INFO - 2018-06-30 13:28:45 --> Security Class Initialized
DEBUG - 2018-06-30 13:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:28:45 --> CSRF cookie sent
INFO - 2018-06-30 13:28:45 --> Input Class Initialized
INFO - 2018-06-30 13:28:45 --> Language Class Initialized
INFO - 2018-06-30 13:28:45 --> Loader Class Initialized
INFO - 2018-06-30 13:28:45 --> Helper loaded: url_helper
INFO - 2018-06-30 13:28:45 --> Helper loaded: form_helper
INFO - 2018-06-30 13:28:45 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:28:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:28:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:28:45 --> User Agent Class Initialized
INFO - 2018-06-30 13:28:45 --> Controller Class Initialized
INFO - 2018-06-30 13:28:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:28:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:28:45 --> Pixel_Model class loaded
INFO - 2018-06-30 13:28:45 --> Database Driver Class Initialized
INFO - 2018-06-30 13:28:45 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:28:45 --> Database Driver Class Initialized
INFO - 2018-06-30 13:28:45 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:28:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 13:28:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-06-30 13:28:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 13:28:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 13:28:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 13:28:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-30 13:28:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-30 13:28:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/has_hit_kids.php
INFO - 2018-06-30 13:28:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 13:28:45 --> Final output sent to browser
DEBUG - 2018-06-30 13:28:45 --> Total execution time: 0.0394
INFO - 2018-06-30 13:28:48 --> Config Class Initialized
INFO - 2018-06-30 13:28:48 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:28:48 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:28:48 --> Utf8 Class Initialized
INFO - 2018-06-30 13:28:48 --> URI Class Initialized
INFO - 2018-06-30 13:28:48 --> Router Class Initialized
INFO - 2018-06-30 13:28:48 --> Output Class Initialized
INFO - 2018-06-30 13:28:48 --> Security Class Initialized
DEBUG - 2018-06-30 13:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:28:48 --> CSRF cookie sent
INFO - 2018-06-30 13:28:48 --> CSRF token verified
INFO - 2018-06-30 13:28:48 --> Input Class Initialized
INFO - 2018-06-30 13:28:48 --> Language Class Initialized
INFO - 2018-06-30 13:28:48 --> Loader Class Initialized
INFO - 2018-06-30 13:28:48 --> Helper loaded: url_helper
INFO - 2018-06-30 13:28:48 --> Helper loaded: form_helper
INFO - 2018-06-30 13:28:48 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:28:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:28:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:28:48 --> User Agent Class Initialized
INFO - 2018-06-30 13:28:48 --> Controller Class Initialized
INFO - 2018-06-30 13:28:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:28:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:28:48 --> Pixel_Model class loaded
INFO - 2018-06-30 13:28:48 --> Database Driver Class Initialized
INFO - 2018-06-30 13:28:48 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:28:48 --> Form Validation Class Initialized
INFO - 2018-06-30 13:28:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-30 13:28:48 --> Database Driver Class Initialized
INFO - 2018-06-30 13:28:48 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:28:48 --> Config Class Initialized
INFO - 2018-06-30 13:28:48 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:28:48 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:28:48 --> Utf8 Class Initialized
INFO - 2018-06-30 13:28:48 --> URI Class Initialized
INFO - 2018-06-30 13:28:48 --> Router Class Initialized
INFO - 2018-06-30 13:28:48 --> Output Class Initialized
INFO - 2018-06-30 13:28:48 --> Security Class Initialized
DEBUG - 2018-06-30 13:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:28:48 --> CSRF cookie sent
INFO - 2018-06-30 13:28:48 --> Input Class Initialized
INFO - 2018-06-30 13:28:48 --> Language Class Initialized
INFO - 2018-06-30 13:28:48 --> Loader Class Initialized
INFO - 2018-06-30 13:28:48 --> Helper loaded: url_helper
INFO - 2018-06-30 13:28:48 --> Helper loaded: form_helper
INFO - 2018-06-30 13:28:48 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:28:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:28:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:28:48 --> User Agent Class Initialized
INFO - 2018-06-30 13:28:48 --> Controller Class Initialized
INFO - 2018-06-30 13:28:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:28:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:28:48 --> Pixel_Model class loaded
INFO - 2018-06-30 13:28:48 --> Database Driver Class Initialized
INFO - 2018-06-30 13:28:48 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:28:48 --> Database Driver Class Initialized
INFO - 2018-06-30 13:28:48 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:28:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 13:28:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-06-30 13:28:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 13:28:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 13:28:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 13:28:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-30 13:28:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-30 13:28:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/withheld_sex.php
INFO - 2018-06-30 13:28:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 13:28:48 --> Final output sent to browser
DEBUG - 2018-06-30 13:28:48 --> Total execution time: 0.0539
INFO - 2018-06-30 13:28:53 --> Config Class Initialized
INFO - 2018-06-30 13:28:53 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:28:53 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:28:53 --> Utf8 Class Initialized
INFO - 2018-06-30 13:28:53 --> URI Class Initialized
INFO - 2018-06-30 13:28:53 --> Router Class Initialized
INFO - 2018-06-30 13:28:53 --> Output Class Initialized
INFO - 2018-06-30 13:28:53 --> Security Class Initialized
DEBUG - 2018-06-30 13:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:28:53 --> CSRF cookie sent
INFO - 2018-06-30 13:28:53 --> CSRF token verified
INFO - 2018-06-30 13:28:53 --> Input Class Initialized
INFO - 2018-06-30 13:28:53 --> Language Class Initialized
INFO - 2018-06-30 13:28:53 --> Loader Class Initialized
INFO - 2018-06-30 13:28:53 --> Helper loaded: url_helper
INFO - 2018-06-30 13:28:53 --> Helper loaded: form_helper
INFO - 2018-06-30 13:28:53 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:28:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:28:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:28:53 --> User Agent Class Initialized
INFO - 2018-06-30 13:28:53 --> Controller Class Initialized
INFO - 2018-06-30 13:28:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:28:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:28:53 --> Pixel_Model class loaded
INFO - 2018-06-30 13:28:53 --> Database Driver Class Initialized
INFO - 2018-06-30 13:28:53 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:28:53 --> Form Validation Class Initialized
INFO - 2018-06-30 13:28:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-30 13:28:53 --> Database Driver Class Initialized
INFO - 2018-06-30 13:28:53 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:28:53 --> Config Class Initialized
INFO - 2018-06-30 13:28:53 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:28:53 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:28:53 --> Utf8 Class Initialized
INFO - 2018-06-30 13:28:53 --> URI Class Initialized
INFO - 2018-06-30 13:28:53 --> Router Class Initialized
INFO - 2018-06-30 13:28:53 --> Output Class Initialized
INFO - 2018-06-30 13:28:53 --> Security Class Initialized
DEBUG - 2018-06-30 13:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:28:53 --> CSRF cookie sent
INFO - 2018-06-30 13:28:53 --> Input Class Initialized
INFO - 2018-06-30 13:28:53 --> Language Class Initialized
INFO - 2018-06-30 13:28:53 --> Loader Class Initialized
INFO - 2018-06-30 13:28:53 --> Helper loaded: url_helper
INFO - 2018-06-30 13:28:53 --> Helper loaded: form_helper
INFO - 2018-06-30 13:28:53 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:28:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:28:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:28:53 --> User Agent Class Initialized
INFO - 2018-06-30 13:28:53 --> Controller Class Initialized
INFO - 2018-06-30 13:28:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:28:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:28:53 --> Pixel_Model class loaded
INFO - 2018-06-30 13:28:53 --> Database Driver Class Initialized
INFO - 2018-06-30 13:28:53 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:28:53 --> Database Driver Class Initialized
INFO - 2018-06-30 13:28:53 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:28:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 13:28:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-06-30 13:28:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 13:28:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 13:28:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 13:28:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-30 13:28:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-30 13:28:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pet_abuse.php
INFO - 2018-06-30 13:28:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 13:28:53 --> Final output sent to browser
DEBUG - 2018-06-30 13:28:53 --> Total execution time: 0.0447
INFO - 2018-06-30 13:29:00 --> Config Class Initialized
INFO - 2018-06-30 13:29:00 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:29:00 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:29:00 --> Utf8 Class Initialized
INFO - 2018-06-30 13:29:00 --> URI Class Initialized
INFO - 2018-06-30 13:29:00 --> Router Class Initialized
INFO - 2018-06-30 13:29:00 --> Output Class Initialized
INFO - 2018-06-30 13:29:00 --> Security Class Initialized
DEBUG - 2018-06-30 13:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:29:00 --> CSRF cookie sent
INFO - 2018-06-30 13:29:00 --> CSRF token verified
INFO - 2018-06-30 13:29:00 --> Input Class Initialized
INFO - 2018-06-30 13:29:00 --> Language Class Initialized
INFO - 2018-06-30 13:29:00 --> Loader Class Initialized
INFO - 2018-06-30 13:29:00 --> Helper loaded: url_helper
INFO - 2018-06-30 13:29:00 --> Helper loaded: form_helper
INFO - 2018-06-30 13:29:00 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:29:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:29:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:29:00 --> User Agent Class Initialized
INFO - 2018-06-30 13:29:00 --> Controller Class Initialized
INFO - 2018-06-30 13:29:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:29:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:29:00 --> Pixel_Model class loaded
INFO - 2018-06-30 13:29:00 --> Database Driver Class Initialized
INFO - 2018-06-30 13:29:00 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:29:00 --> Form Validation Class Initialized
INFO - 2018-06-30 13:29:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-30 13:29:00 --> Database Driver Class Initialized
INFO - 2018-06-30 13:29:00 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:29:00 --> Config Class Initialized
INFO - 2018-06-30 13:29:00 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:29:00 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:29:00 --> Utf8 Class Initialized
INFO - 2018-06-30 13:29:00 --> URI Class Initialized
INFO - 2018-06-30 13:29:00 --> Router Class Initialized
INFO - 2018-06-30 13:29:00 --> Output Class Initialized
INFO - 2018-06-30 13:29:00 --> Security Class Initialized
DEBUG - 2018-06-30 13:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:29:00 --> CSRF cookie sent
INFO - 2018-06-30 13:29:00 --> Input Class Initialized
INFO - 2018-06-30 13:29:00 --> Language Class Initialized
INFO - 2018-06-30 13:29:00 --> Loader Class Initialized
INFO - 2018-06-30 13:29:00 --> Helper loaded: url_helper
INFO - 2018-06-30 13:29:00 --> Helper loaded: form_helper
INFO - 2018-06-30 13:29:00 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:29:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:29:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:29:00 --> User Agent Class Initialized
INFO - 2018-06-30 13:29:00 --> Controller Class Initialized
INFO - 2018-06-30 13:29:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:29:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:29:00 --> Pixel_Model class loaded
INFO - 2018-06-30 13:29:00 --> Database Driver Class Initialized
INFO - 2018-06-30 13:29:00 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:29:00 --> Database Driver Class Initialized
INFO - 2018-06-30 13:29:00 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:29:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 13:29:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-06-30 13:29:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 13:29:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 13:29:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 13:29:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-30 13:29:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-30 13:29:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/has_dating_profile.php
INFO - 2018-06-30 13:29:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 13:29:00 --> Final output sent to browser
DEBUG - 2018-06-30 13:29:00 --> Total execution time: 0.0464
INFO - 2018-06-30 13:29:05 --> Config Class Initialized
INFO - 2018-06-30 13:29:05 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:29:05 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:29:05 --> Utf8 Class Initialized
INFO - 2018-06-30 13:29:05 --> URI Class Initialized
INFO - 2018-06-30 13:29:05 --> Router Class Initialized
INFO - 2018-06-30 13:29:05 --> Output Class Initialized
INFO - 2018-06-30 13:29:05 --> Security Class Initialized
DEBUG - 2018-06-30 13:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:29:05 --> CSRF cookie sent
INFO - 2018-06-30 13:29:05 --> CSRF token verified
INFO - 2018-06-30 13:29:05 --> Input Class Initialized
INFO - 2018-06-30 13:29:05 --> Language Class Initialized
INFO - 2018-06-30 13:29:05 --> Loader Class Initialized
INFO - 2018-06-30 13:29:05 --> Helper loaded: url_helper
INFO - 2018-06-30 13:29:05 --> Helper loaded: form_helper
INFO - 2018-06-30 13:29:05 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:29:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:29:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:29:05 --> User Agent Class Initialized
INFO - 2018-06-30 13:29:05 --> Controller Class Initialized
INFO - 2018-06-30 13:29:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:29:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:29:05 --> Pixel_Model class loaded
INFO - 2018-06-30 13:29:05 --> Database Driver Class Initialized
INFO - 2018-06-30 13:29:05 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:29:05 --> Form Validation Class Initialized
INFO - 2018-06-30 13:29:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-30 13:29:05 --> Database Driver Class Initialized
INFO - 2018-06-30 13:29:05 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:29:05 --> Config Class Initialized
INFO - 2018-06-30 13:29:05 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:29:05 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:29:05 --> Utf8 Class Initialized
INFO - 2018-06-30 13:29:05 --> URI Class Initialized
INFO - 2018-06-30 13:29:05 --> Router Class Initialized
INFO - 2018-06-30 13:29:05 --> Output Class Initialized
INFO - 2018-06-30 13:29:05 --> Security Class Initialized
DEBUG - 2018-06-30 13:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:29:05 --> CSRF cookie sent
INFO - 2018-06-30 13:29:05 --> Input Class Initialized
INFO - 2018-06-30 13:29:05 --> Language Class Initialized
INFO - 2018-06-30 13:29:05 --> Loader Class Initialized
INFO - 2018-06-30 13:29:05 --> Helper loaded: url_helper
INFO - 2018-06-30 13:29:05 --> Helper loaded: form_helper
INFO - 2018-06-30 13:29:05 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:29:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:29:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:29:05 --> User Agent Class Initialized
INFO - 2018-06-30 13:29:05 --> Controller Class Initialized
INFO - 2018-06-30 13:29:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:29:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:29:05 --> Pixel_Model class loaded
INFO - 2018-06-30 13:29:05 --> Database Driver Class Initialized
INFO - 2018-06-30 13:29:05 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:29:05 --> Database Driver Class Initialized
INFO - 2018-06-30 13:29:05 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:29:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 13:29:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-06-30 13:29:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 13:29:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 13:29:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 13:29:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-30 13:29:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-30 13:29:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/times_slept_couch.php
INFO - 2018-06-30 13:29:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 13:29:05 --> Final output sent to browser
DEBUG - 2018-06-30 13:29:05 --> Total execution time: 0.0465
INFO - 2018-06-30 13:29:18 --> Config Class Initialized
INFO - 2018-06-30 13:29:18 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:29:18 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:29:18 --> Utf8 Class Initialized
INFO - 2018-06-30 13:29:18 --> URI Class Initialized
INFO - 2018-06-30 13:29:18 --> Router Class Initialized
INFO - 2018-06-30 13:29:18 --> Output Class Initialized
INFO - 2018-06-30 13:29:18 --> Security Class Initialized
DEBUG - 2018-06-30 13:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:29:18 --> CSRF cookie sent
INFO - 2018-06-30 13:29:18 --> CSRF token verified
INFO - 2018-06-30 13:29:18 --> Input Class Initialized
INFO - 2018-06-30 13:29:18 --> Language Class Initialized
INFO - 2018-06-30 13:29:18 --> Loader Class Initialized
INFO - 2018-06-30 13:29:18 --> Helper loaded: url_helper
INFO - 2018-06-30 13:29:18 --> Helper loaded: form_helper
INFO - 2018-06-30 13:29:18 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:29:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:29:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:29:18 --> User Agent Class Initialized
INFO - 2018-06-30 13:29:18 --> Controller Class Initialized
INFO - 2018-06-30 13:29:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:29:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:29:18 --> Pixel_Model class loaded
INFO - 2018-06-30 13:29:18 --> Database Driver Class Initialized
INFO - 2018-06-30 13:29:18 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:29:18 --> Form Validation Class Initialized
INFO - 2018-06-30 13:29:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-30 13:29:18 --> Database Driver Class Initialized
INFO - 2018-06-30 13:29:18 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:29:18 --> Config Class Initialized
INFO - 2018-06-30 13:29:18 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:29:18 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:29:18 --> Utf8 Class Initialized
INFO - 2018-06-30 13:29:18 --> URI Class Initialized
INFO - 2018-06-30 13:29:18 --> Router Class Initialized
INFO - 2018-06-30 13:29:18 --> Output Class Initialized
INFO - 2018-06-30 13:29:18 --> Security Class Initialized
DEBUG - 2018-06-30 13:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:29:18 --> CSRF cookie sent
INFO - 2018-06-30 13:29:18 --> Input Class Initialized
INFO - 2018-06-30 13:29:18 --> Language Class Initialized
INFO - 2018-06-30 13:29:18 --> Loader Class Initialized
INFO - 2018-06-30 13:29:18 --> Helper loaded: url_helper
INFO - 2018-06-30 13:29:18 --> Helper loaded: form_helper
INFO - 2018-06-30 13:29:18 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:29:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:29:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:29:18 --> User Agent Class Initialized
INFO - 2018-06-30 13:29:18 --> Controller Class Initialized
INFO - 2018-06-30 13:29:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:29:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:29:18 --> Pixel_Model class loaded
INFO - 2018-06-30 13:29:18 --> Database Driver Class Initialized
INFO - 2018-06-30 13:29:18 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:29:18 --> Database Driver Class Initialized
INFO - 2018-06-30 13:29:18 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:29:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 13:29:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-06-30 13:29:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 13:29:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 13:29:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 13:29:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-30 13:29:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-30 13:29:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/has_relationship_outside.php
INFO - 2018-06-30 13:29:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 13:29:18 --> Final output sent to browser
DEBUG - 2018-06-30 13:29:18 --> Total execution time: 0.0409
INFO - 2018-06-30 13:29:26 --> Config Class Initialized
INFO - 2018-06-30 13:29:26 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:29:26 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:29:26 --> Utf8 Class Initialized
INFO - 2018-06-30 13:29:26 --> URI Class Initialized
INFO - 2018-06-30 13:29:26 --> Router Class Initialized
INFO - 2018-06-30 13:29:26 --> Output Class Initialized
INFO - 2018-06-30 13:29:26 --> Security Class Initialized
DEBUG - 2018-06-30 13:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:29:26 --> CSRF cookie sent
INFO - 2018-06-30 13:29:26 --> CSRF token verified
INFO - 2018-06-30 13:29:26 --> Input Class Initialized
INFO - 2018-06-30 13:29:26 --> Language Class Initialized
INFO - 2018-06-30 13:29:26 --> Loader Class Initialized
INFO - 2018-06-30 13:29:26 --> Helper loaded: url_helper
INFO - 2018-06-30 13:29:26 --> Helper loaded: form_helper
INFO - 2018-06-30 13:29:26 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:29:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:29:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:29:26 --> User Agent Class Initialized
INFO - 2018-06-30 13:29:26 --> Controller Class Initialized
INFO - 2018-06-30 13:29:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:29:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:29:26 --> Pixel_Model class loaded
INFO - 2018-06-30 13:29:26 --> Database Driver Class Initialized
INFO - 2018-06-30 13:29:26 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:29:26 --> Form Validation Class Initialized
INFO - 2018-06-30 13:29:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-30 13:29:26 --> Database Driver Class Initialized
INFO - 2018-06-30 13:29:26 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:29:26 --> Config Class Initialized
INFO - 2018-06-30 13:29:26 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:29:26 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:29:26 --> Utf8 Class Initialized
INFO - 2018-06-30 13:29:26 --> URI Class Initialized
INFO - 2018-06-30 13:29:26 --> Router Class Initialized
INFO - 2018-06-30 13:29:26 --> Output Class Initialized
INFO - 2018-06-30 13:29:26 --> Security Class Initialized
DEBUG - 2018-06-30 13:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:29:26 --> CSRF cookie sent
INFO - 2018-06-30 13:29:26 --> Input Class Initialized
INFO - 2018-06-30 13:29:26 --> Language Class Initialized
INFO - 2018-06-30 13:29:26 --> Loader Class Initialized
INFO - 2018-06-30 13:29:26 --> Helper loaded: url_helper
INFO - 2018-06-30 13:29:26 --> Helper loaded: form_helper
INFO - 2018-06-30 13:29:26 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:29:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:29:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:29:26 --> User Agent Class Initialized
INFO - 2018-06-30 13:29:26 --> Controller Class Initialized
INFO - 2018-06-30 13:29:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:29:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:29:26 --> Pixel_Model class loaded
INFO - 2018-06-30 13:29:26 --> Database Driver Class Initialized
INFO - 2018-06-30 13:29:26 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:29:26 --> Database Driver Class Initialized
INFO - 2018-06-30 13:29:26 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:29:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 13:29:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-06-30 13:29:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 13:29:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 13:29:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 13:29:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-30 13:29:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-30 13:29:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/liens_on_house.php
INFO - 2018-06-30 13:29:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 13:29:26 --> Final output sent to browser
DEBUG - 2018-06-30 13:29:26 --> Total execution time: 0.0449
INFO - 2018-06-30 13:29:43 --> Config Class Initialized
INFO - 2018-06-30 13:29:43 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:29:43 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:29:43 --> Utf8 Class Initialized
INFO - 2018-06-30 13:29:43 --> URI Class Initialized
INFO - 2018-06-30 13:29:43 --> Router Class Initialized
INFO - 2018-06-30 13:29:43 --> Output Class Initialized
INFO - 2018-06-30 13:29:43 --> Security Class Initialized
DEBUG - 2018-06-30 13:29:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:29:43 --> CSRF cookie sent
INFO - 2018-06-30 13:29:43 --> CSRF token verified
INFO - 2018-06-30 13:29:43 --> Input Class Initialized
INFO - 2018-06-30 13:29:43 --> Language Class Initialized
INFO - 2018-06-30 13:29:43 --> Loader Class Initialized
INFO - 2018-06-30 13:29:43 --> Helper loaded: url_helper
INFO - 2018-06-30 13:29:43 --> Helper loaded: form_helper
INFO - 2018-06-30 13:29:43 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:29:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:29:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:29:43 --> User Agent Class Initialized
INFO - 2018-06-30 13:29:43 --> Controller Class Initialized
INFO - 2018-06-30 13:29:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:29:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:29:43 --> Pixel_Model class loaded
INFO - 2018-06-30 13:29:43 --> Database Driver Class Initialized
INFO - 2018-06-30 13:29:43 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:29:43 --> Form Validation Class Initialized
INFO - 2018-06-30 13:29:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-30 13:29:43 --> Database Driver Class Initialized
INFO - 2018-06-30 13:29:43 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:29:43 --> Config Class Initialized
INFO - 2018-06-30 13:29:43 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:29:43 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:29:43 --> Utf8 Class Initialized
INFO - 2018-06-30 13:29:43 --> URI Class Initialized
INFO - 2018-06-30 13:29:43 --> Router Class Initialized
INFO - 2018-06-30 13:29:43 --> Output Class Initialized
INFO - 2018-06-30 13:29:43 --> Security Class Initialized
DEBUG - 2018-06-30 13:29:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:29:43 --> CSRF cookie sent
INFO - 2018-06-30 13:29:43 --> Input Class Initialized
INFO - 2018-06-30 13:29:43 --> Language Class Initialized
INFO - 2018-06-30 13:29:43 --> Loader Class Initialized
INFO - 2018-06-30 13:29:43 --> Helper loaded: url_helper
INFO - 2018-06-30 13:29:43 --> Helper loaded: form_helper
INFO - 2018-06-30 13:29:43 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:29:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:29:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:29:43 --> User Agent Class Initialized
INFO - 2018-06-30 13:29:43 --> Controller Class Initialized
INFO - 2018-06-30 13:29:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:29:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:29:43 --> Pixel_Model class loaded
INFO - 2018-06-30 13:29:43 --> Database Driver Class Initialized
INFO - 2018-06-30 13:29:43 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:29:43 --> Database Driver Class Initialized
INFO - 2018-06-30 13:29:43 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:29:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 13:29:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-06-30 13:29:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 13:29:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 13:29:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 13:29:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-30 13:29:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-30 13:29:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/have_loan_money.php
INFO - 2018-06-30 13:29:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 13:29:43 --> Final output sent to browser
DEBUG - 2018-06-30 13:29:43 --> Total execution time: 0.0438
INFO - 2018-06-30 13:29:48 --> Config Class Initialized
INFO - 2018-06-30 13:29:48 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:29:48 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:29:48 --> Utf8 Class Initialized
INFO - 2018-06-30 13:29:48 --> URI Class Initialized
INFO - 2018-06-30 13:29:48 --> Router Class Initialized
INFO - 2018-06-30 13:29:48 --> Output Class Initialized
INFO - 2018-06-30 13:29:48 --> Security Class Initialized
DEBUG - 2018-06-30 13:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:29:48 --> CSRF cookie sent
INFO - 2018-06-30 13:29:48 --> CSRF token verified
INFO - 2018-06-30 13:29:48 --> Input Class Initialized
INFO - 2018-06-30 13:29:48 --> Language Class Initialized
INFO - 2018-06-30 13:29:48 --> Loader Class Initialized
INFO - 2018-06-30 13:29:48 --> Helper loaded: url_helper
INFO - 2018-06-30 13:29:48 --> Helper loaded: form_helper
INFO - 2018-06-30 13:29:48 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:29:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:29:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:29:48 --> User Agent Class Initialized
INFO - 2018-06-30 13:29:48 --> Controller Class Initialized
INFO - 2018-06-30 13:29:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:29:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:29:48 --> Pixel_Model class loaded
INFO - 2018-06-30 13:29:48 --> Database Driver Class Initialized
INFO - 2018-06-30 13:29:48 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:29:48 --> Form Validation Class Initialized
INFO - 2018-06-30 13:29:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-30 13:29:48 --> Database Driver Class Initialized
INFO - 2018-06-30 13:29:48 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:29:48 --> Config Class Initialized
INFO - 2018-06-30 13:29:48 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:29:48 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:29:48 --> Utf8 Class Initialized
INFO - 2018-06-30 13:29:48 --> URI Class Initialized
INFO - 2018-06-30 13:29:48 --> Router Class Initialized
INFO - 2018-06-30 13:29:48 --> Output Class Initialized
INFO - 2018-06-30 13:29:48 --> Security Class Initialized
DEBUG - 2018-06-30 13:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:29:48 --> CSRF cookie sent
INFO - 2018-06-30 13:29:48 --> Input Class Initialized
INFO - 2018-06-30 13:29:48 --> Language Class Initialized
INFO - 2018-06-30 13:29:48 --> Loader Class Initialized
INFO - 2018-06-30 13:29:48 --> Helper loaded: url_helper
INFO - 2018-06-30 13:29:48 --> Helper loaded: form_helper
INFO - 2018-06-30 13:29:48 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:29:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:29:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:29:48 --> User Agent Class Initialized
INFO - 2018-06-30 13:29:48 --> Controller Class Initialized
INFO - 2018-06-30 13:29:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:29:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:29:48 --> Pixel_Model class loaded
INFO - 2018-06-30 13:29:48 --> Database Driver Class Initialized
INFO - 2018-06-30 13:29:48 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:29:48 --> Database Driver Class Initialized
INFO - 2018-06-30 13:29:48 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:29:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 13:29:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-06-30 13:29:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 13:29:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 13:29:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 13:29:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-30 13:29:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-30 13:29:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/social_class.php
INFO - 2018-06-30 13:29:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 13:29:48 --> Final output sent to browser
DEBUG - 2018-06-30 13:29:48 --> Total execution time: 0.0433
INFO - 2018-06-30 13:29:54 --> Config Class Initialized
INFO - 2018-06-30 13:29:54 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:29:54 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:29:54 --> Utf8 Class Initialized
INFO - 2018-06-30 13:29:54 --> URI Class Initialized
INFO - 2018-06-30 13:29:54 --> Router Class Initialized
INFO - 2018-06-30 13:29:54 --> Output Class Initialized
INFO - 2018-06-30 13:29:54 --> Security Class Initialized
DEBUG - 2018-06-30 13:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:29:54 --> CSRF cookie sent
INFO - 2018-06-30 13:29:54 --> CSRF token verified
INFO - 2018-06-30 13:29:54 --> Input Class Initialized
INFO - 2018-06-30 13:29:54 --> Language Class Initialized
INFO - 2018-06-30 13:29:54 --> Loader Class Initialized
INFO - 2018-06-30 13:29:54 --> Helper loaded: url_helper
INFO - 2018-06-30 13:29:54 --> Helper loaded: form_helper
INFO - 2018-06-30 13:29:54 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:29:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:29:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:29:54 --> User Agent Class Initialized
INFO - 2018-06-30 13:29:54 --> Controller Class Initialized
INFO - 2018-06-30 13:29:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:29:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:29:54 --> Pixel_Model class loaded
INFO - 2018-06-30 13:29:54 --> Database Driver Class Initialized
INFO - 2018-06-30 13:29:54 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:29:54 --> Form Validation Class Initialized
INFO - 2018-06-30 13:29:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-30 13:29:54 --> Database Driver Class Initialized
INFO - 2018-06-30 13:29:54 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:29:54 --> Config Class Initialized
INFO - 2018-06-30 13:29:54 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:29:54 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:29:54 --> Utf8 Class Initialized
INFO - 2018-06-30 13:29:54 --> URI Class Initialized
INFO - 2018-06-30 13:29:54 --> Router Class Initialized
INFO - 2018-06-30 13:29:54 --> Output Class Initialized
INFO - 2018-06-30 13:29:54 --> Security Class Initialized
DEBUG - 2018-06-30 13:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:29:54 --> CSRF cookie sent
INFO - 2018-06-30 13:29:54 --> Input Class Initialized
INFO - 2018-06-30 13:29:54 --> Language Class Initialized
INFO - 2018-06-30 13:29:54 --> Loader Class Initialized
INFO - 2018-06-30 13:29:54 --> Helper loaded: url_helper
INFO - 2018-06-30 13:29:54 --> Helper loaded: form_helper
INFO - 2018-06-30 13:29:54 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:29:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:29:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:29:54 --> User Agent Class Initialized
INFO - 2018-06-30 13:29:54 --> Controller Class Initialized
INFO - 2018-06-30 13:29:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:29:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:29:54 --> Pixel_Model class loaded
INFO - 2018-06-30 13:29:54 --> Database Driver Class Initialized
INFO - 2018-06-30 13:29:54 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:29:54 --> Database Driver Class Initialized
INFO - 2018-06-30 13:29:54 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:29:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 13:29:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-06-30 13:29:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 13:29:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 13:29:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 13:29:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-30 13:29:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-30 13:29:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/s_social_class.php
INFO - 2018-06-30 13:29:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 13:29:54 --> Final output sent to browser
DEBUG - 2018-06-30 13:29:54 --> Total execution time: 0.0473
INFO - 2018-06-30 13:29:58 --> Config Class Initialized
INFO - 2018-06-30 13:29:58 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:29:58 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:29:58 --> Utf8 Class Initialized
INFO - 2018-06-30 13:29:58 --> URI Class Initialized
INFO - 2018-06-30 13:29:58 --> Router Class Initialized
INFO - 2018-06-30 13:29:58 --> Output Class Initialized
INFO - 2018-06-30 13:29:58 --> Security Class Initialized
DEBUG - 2018-06-30 13:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:29:58 --> CSRF cookie sent
INFO - 2018-06-30 13:29:58 --> CSRF token verified
INFO - 2018-06-30 13:29:58 --> Input Class Initialized
INFO - 2018-06-30 13:29:58 --> Language Class Initialized
INFO - 2018-06-30 13:29:58 --> Loader Class Initialized
INFO - 2018-06-30 13:29:58 --> Helper loaded: url_helper
INFO - 2018-06-30 13:29:58 --> Helper loaded: form_helper
INFO - 2018-06-30 13:29:58 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:29:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:29:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:29:58 --> User Agent Class Initialized
INFO - 2018-06-30 13:29:58 --> Controller Class Initialized
INFO - 2018-06-30 13:29:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:29:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:29:58 --> Pixel_Model class loaded
INFO - 2018-06-30 13:29:58 --> Database Driver Class Initialized
INFO - 2018-06-30 13:29:58 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:29:58 --> Form Validation Class Initialized
INFO - 2018-06-30 13:29:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-30 13:29:58 --> Database Driver Class Initialized
INFO - 2018-06-30 13:29:58 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:29:58 --> Config Class Initialized
INFO - 2018-06-30 13:29:58 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:29:58 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:29:58 --> Utf8 Class Initialized
INFO - 2018-06-30 13:29:58 --> URI Class Initialized
INFO - 2018-06-30 13:29:58 --> Router Class Initialized
INFO - 2018-06-30 13:29:58 --> Output Class Initialized
INFO - 2018-06-30 13:29:58 --> Security Class Initialized
DEBUG - 2018-06-30 13:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:29:58 --> CSRF cookie sent
INFO - 2018-06-30 13:29:58 --> Input Class Initialized
INFO - 2018-06-30 13:29:58 --> Language Class Initialized
INFO - 2018-06-30 13:29:58 --> Loader Class Initialized
INFO - 2018-06-30 13:29:58 --> Helper loaded: url_helper
INFO - 2018-06-30 13:29:58 --> Helper loaded: form_helper
INFO - 2018-06-30 13:29:58 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:29:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:29:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:29:58 --> User Agent Class Initialized
INFO - 2018-06-30 13:29:58 --> Controller Class Initialized
INFO - 2018-06-30 13:29:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:29:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:29:58 --> Pixel_Model class loaded
INFO - 2018-06-30 13:29:58 --> Database Driver Class Initialized
INFO - 2018-06-30 13:29:58 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:29:58 --> Database Driver Class Initialized
INFO - 2018-06-30 13:29:58 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:29:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 13:29:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-06-30 13:29:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 13:29:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 13:29:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 13:29:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-30 13:29:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-30 13:29:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/ethnic_background.php
INFO - 2018-06-30 13:29:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 13:29:58 --> Final output sent to browser
DEBUG - 2018-06-30 13:29:58 --> Total execution time: 0.0639
INFO - 2018-06-30 13:30:06 --> Config Class Initialized
INFO - 2018-06-30 13:30:06 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:30:06 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:30:06 --> Utf8 Class Initialized
INFO - 2018-06-30 13:30:06 --> URI Class Initialized
INFO - 2018-06-30 13:30:06 --> Router Class Initialized
INFO - 2018-06-30 13:30:06 --> Output Class Initialized
INFO - 2018-06-30 13:30:06 --> Security Class Initialized
DEBUG - 2018-06-30 13:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:30:06 --> CSRF cookie sent
INFO - 2018-06-30 13:30:06 --> CSRF token verified
INFO - 2018-06-30 13:30:06 --> Input Class Initialized
INFO - 2018-06-30 13:30:06 --> Language Class Initialized
INFO - 2018-06-30 13:30:06 --> Loader Class Initialized
INFO - 2018-06-30 13:30:06 --> Helper loaded: url_helper
INFO - 2018-06-30 13:30:06 --> Helper loaded: form_helper
INFO - 2018-06-30 13:30:06 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:30:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:30:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:30:06 --> User Agent Class Initialized
INFO - 2018-06-30 13:30:06 --> Controller Class Initialized
INFO - 2018-06-30 13:30:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:30:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:30:06 --> Pixel_Model class loaded
INFO - 2018-06-30 13:30:06 --> Database Driver Class Initialized
INFO - 2018-06-30 13:30:06 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:30:06 --> Form Validation Class Initialized
INFO - 2018-06-30 13:30:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-30 13:30:06 --> Database Driver Class Initialized
INFO - 2018-06-30 13:30:06 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:30:06 --> Config Class Initialized
INFO - 2018-06-30 13:30:06 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:30:06 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:30:06 --> Utf8 Class Initialized
INFO - 2018-06-30 13:30:06 --> URI Class Initialized
INFO - 2018-06-30 13:30:06 --> Router Class Initialized
INFO - 2018-06-30 13:30:06 --> Output Class Initialized
INFO - 2018-06-30 13:30:06 --> Security Class Initialized
DEBUG - 2018-06-30 13:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:30:06 --> CSRF cookie sent
INFO - 2018-06-30 13:30:06 --> Input Class Initialized
INFO - 2018-06-30 13:30:06 --> Language Class Initialized
INFO - 2018-06-30 13:30:06 --> Loader Class Initialized
INFO - 2018-06-30 13:30:06 --> Helper loaded: url_helper
INFO - 2018-06-30 13:30:07 --> Helper loaded: form_helper
INFO - 2018-06-30 13:30:07 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:30:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:30:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:30:07 --> User Agent Class Initialized
INFO - 2018-06-30 13:30:07 --> Controller Class Initialized
INFO - 2018-06-30 13:30:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:30:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:30:07 --> Pixel_Model class loaded
INFO - 2018-06-30 13:30:07 --> Database Driver Class Initialized
INFO - 2018-06-30 13:30:07 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:30:07 --> Database Driver Class Initialized
INFO - 2018-06-30 13:30:07 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:30:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 13:30:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-06-30 13:30:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 13:30:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 13:30:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 13:30:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-30 13:30:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-30 13:30:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/assets_info.php
INFO - 2018-06-30 13:30:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 13:30:07 --> Final output sent to browser
DEBUG - 2018-06-30 13:30:07 --> Total execution time: 0.0517
INFO - 2018-06-30 13:30:14 --> Config Class Initialized
INFO - 2018-06-30 13:30:14 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:30:14 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:30:14 --> Utf8 Class Initialized
INFO - 2018-06-30 13:30:14 --> URI Class Initialized
INFO - 2018-06-30 13:30:14 --> Router Class Initialized
INFO - 2018-06-30 13:30:14 --> Output Class Initialized
INFO - 2018-06-30 13:30:14 --> Security Class Initialized
DEBUG - 2018-06-30 13:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:30:14 --> CSRF cookie sent
INFO - 2018-06-30 13:30:14 --> CSRF token verified
INFO - 2018-06-30 13:30:14 --> Input Class Initialized
INFO - 2018-06-30 13:30:14 --> Language Class Initialized
INFO - 2018-06-30 13:30:14 --> Loader Class Initialized
INFO - 2018-06-30 13:30:14 --> Helper loaded: url_helper
INFO - 2018-06-30 13:30:14 --> Helper loaded: form_helper
INFO - 2018-06-30 13:30:14 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:30:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:30:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:30:14 --> User Agent Class Initialized
INFO - 2018-06-30 13:30:14 --> Controller Class Initialized
INFO - 2018-06-30 13:30:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:30:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:30:14 --> Pixel_Model class loaded
INFO - 2018-06-30 13:30:14 --> Database Driver Class Initialized
INFO - 2018-06-30 13:30:14 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:30:14 --> Form Validation Class Initialized
INFO - 2018-06-30 13:30:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-30 13:30:14 --> Database Driver Class Initialized
INFO - 2018-06-30 13:30:14 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:30:14 --> Config Class Initialized
INFO - 2018-06-30 13:30:14 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:30:14 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:30:14 --> Utf8 Class Initialized
INFO - 2018-06-30 13:30:14 --> URI Class Initialized
INFO - 2018-06-30 13:30:14 --> Router Class Initialized
INFO - 2018-06-30 13:30:14 --> Output Class Initialized
INFO - 2018-06-30 13:30:14 --> Security Class Initialized
DEBUG - 2018-06-30 13:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:30:14 --> CSRF cookie sent
INFO - 2018-06-30 13:30:14 --> Input Class Initialized
INFO - 2018-06-30 13:30:14 --> Language Class Initialized
INFO - 2018-06-30 13:30:14 --> Loader Class Initialized
INFO - 2018-06-30 13:30:14 --> Helper loaded: url_helper
INFO - 2018-06-30 13:30:14 --> Helper loaded: form_helper
INFO - 2018-06-30 13:30:14 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:30:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:30:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:30:14 --> User Agent Class Initialized
INFO - 2018-06-30 13:30:14 --> Controller Class Initialized
INFO - 2018-06-30 13:30:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:30:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:30:14 --> Pixel_Model class loaded
INFO - 2018-06-30 13:30:14 --> Database Driver Class Initialized
INFO - 2018-06-30 13:30:14 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:30:14 --> Database Driver Class Initialized
INFO - 2018-06-30 13:30:14 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:30:14 --> Config Class Initialized
INFO - 2018-06-30 13:30:14 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:30:14 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:30:14 --> Utf8 Class Initialized
INFO - 2018-06-30 13:30:14 --> URI Class Initialized
INFO - 2018-06-30 13:30:14 --> Router Class Initialized
INFO - 2018-06-30 13:30:14 --> Output Class Initialized
INFO - 2018-06-30 13:30:14 --> Security Class Initialized
DEBUG - 2018-06-30 13:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:30:14 --> CSRF cookie sent
INFO - 2018-06-30 13:30:14 --> Input Class Initialized
INFO - 2018-06-30 13:30:14 --> Language Class Initialized
INFO - 2018-06-30 13:30:14 --> Loader Class Initialized
INFO - 2018-06-30 13:30:14 --> Helper loaded: url_helper
INFO - 2018-06-30 13:30:14 --> Helper loaded: form_helper
INFO - 2018-06-30 13:30:14 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:30:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:30:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:30:14 --> User Agent Class Initialized
INFO - 2018-06-30 13:30:14 --> Controller Class Initialized
INFO - 2018-06-30 13:30:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:30:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:30:14 --> Pixel_Model class loaded
INFO - 2018-06-30 13:30:14 --> Database Driver Class Initialized
INFO - 2018-06-30 13:30:14 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:30:14 --> Database Driver Class Initialized
INFO - 2018-06-30 13:30:14 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:30:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 13:30:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-06-30 13:30:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 13:30:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 13:30:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 13:30:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-30 13:30:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-30 13:30:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/gifts_info.php
INFO - 2018-06-30 13:30:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 13:30:14 --> Final output sent to browser
DEBUG - 2018-06-30 13:30:14 --> Total execution time: 0.0435
INFO - 2018-06-30 13:30:17 --> Config Class Initialized
INFO - 2018-06-30 13:30:17 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:30:17 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:30:17 --> Utf8 Class Initialized
INFO - 2018-06-30 13:30:17 --> URI Class Initialized
INFO - 2018-06-30 13:30:17 --> Router Class Initialized
INFO - 2018-06-30 13:30:17 --> Output Class Initialized
INFO - 2018-06-30 13:30:17 --> Security Class Initialized
DEBUG - 2018-06-30 13:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:30:17 --> CSRF cookie sent
INFO - 2018-06-30 13:30:17 --> CSRF token verified
INFO - 2018-06-30 13:30:17 --> Input Class Initialized
INFO - 2018-06-30 13:30:17 --> Language Class Initialized
INFO - 2018-06-30 13:30:17 --> Loader Class Initialized
INFO - 2018-06-30 13:30:17 --> Helper loaded: url_helper
INFO - 2018-06-30 13:30:17 --> Helper loaded: form_helper
INFO - 2018-06-30 13:30:17 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:30:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:30:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:30:17 --> User Agent Class Initialized
INFO - 2018-06-30 13:30:17 --> Controller Class Initialized
INFO - 2018-06-30 13:30:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:30:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:30:17 --> Pixel_Model class loaded
INFO - 2018-06-30 13:30:17 --> Database Driver Class Initialized
INFO - 2018-06-30 13:30:17 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:30:17 --> Form Validation Class Initialized
INFO - 2018-06-30 13:30:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-30 13:30:17 --> Database Driver Class Initialized
INFO - 2018-06-30 13:30:17 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:30:17 --> Config Class Initialized
INFO - 2018-06-30 13:30:17 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:30:17 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:30:17 --> Utf8 Class Initialized
INFO - 2018-06-30 13:30:17 --> URI Class Initialized
INFO - 2018-06-30 13:30:17 --> Router Class Initialized
INFO - 2018-06-30 13:30:17 --> Output Class Initialized
INFO - 2018-06-30 13:30:17 --> Security Class Initialized
DEBUG - 2018-06-30 13:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:30:17 --> CSRF cookie sent
INFO - 2018-06-30 13:30:17 --> Input Class Initialized
INFO - 2018-06-30 13:30:17 --> Language Class Initialized
INFO - 2018-06-30 13:30:17 --> Loader Class Initialized
INFO - 2018-06-30 13:30:17 --> Helper loaded: url_helper
INFO - 2018-06-30 13:30:17 --> Helper loaded: form_helper
INFO - 2018-06-30 13:30:17 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:30:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:30:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:30:17 --> User Agent Class Initialized
INFO - 2018-06-30 13:30:17 --> Controller Class Initialized
INFO - 2018-06-30 13:30:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:30:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:30:17 --> Pixel_Model class loaded
INFO - 2018-06-30 13:30:17 --> Database Driver Class Initialized
INFO - 2018-06-30 13:30:17 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:30:17 --> Database Driver Class Initialized
INFO - 2018-06-30 13:30:17 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:30:17 --> Config Class Initialized
INFO - 2018-06-30 13:30:17 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:30:17 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:30:17 --> Utf8 Class Initialized
INFO - 2018-06-30 13:30:17 --> URI Class Initialized
INFO - 2018-06-30 13:30:17 --> Router Class Initialized
INFO - 2018-06-30 13:30:17 --> Output Class Initialized
INFO - 2018-06-30 13:30:17 --> Security Class Initialized
DEBUG - 2018-06-30 13:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:30:17 --> CSRF cookie sent
INFO - 2018-06-30 13:30:17 --> Input Class Initialized
INFO - 2018-06-30 13:30:17 --> Language Class Initialized
INFO - 2018-06-30 13:30:17 --> Loader Class Initialized
INFO - 2018-06-30 13:30:17 --> Helper loaded: url_helper
INFO - 2018-06-30 13:30:17 --> Helper loaded: form_helper
INFO - 2018-06-30 13:30:17 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:30:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:30:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:30:17 --> User Agent Class Initialized
INFO - 2018-06-30 13:30:17 --> Controller Class Initialized
INFO - 2018-06-30 13:30:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:30:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:30:17 --> Pixel_Model class loaded
INFO - 2018-06-30 13:30:17 --> Database Driver Class Initialized
INFO - 2018-06-30 13:30:17 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:30:17 --> Database Driver Class Initialized
INFO - 2018-06-30 13:30:17 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:30:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 13:30:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-06-30 13:30:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 13:30:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 13:30:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 13:30:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-30 13:30:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-30 13:30:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/automobile.php
INFO - 2018-06-30 13:30:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 13:30:17 --> Final output sent to browser
DEBUG - 2018-06-30 13:30:17 --> Total execution time: 0.0425
INFO - 2018-06-30 13:30:33 --> Config Class Initialized
INFO - 2018-06-30 13:30:33 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:30:33 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:30:33 --> Utf8 Class Initialized
INFO - 2018-06-30 13:30:33 --> URI Class Initialized
INFO - 2018-06-30 13:30:33 --> Router Class Initialized
INFO - 2018-06-30 13:30:33 --> Output Class Initialized
INFO - 2018-06-30 13:30:33 --> Security Class Initialized
DEBUG - 2018-06-30 13:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:30:33 --> CSRF cookie sent
INFO - 2018-06-30 13:30:33 --> CSRF token verified
INFO - 2018-06-30 13:30:33 --> Input Class Initialized
INFO - 2018-06-30 13:30:33 --> Language Class Initialized
INFO - 2018-06-30 13:30:33 --> Loader Class Initialized
INFO - 2018-06-30 13:30:33 --> Helper loaded: url_helper
INFO - 2018-06-30 13:30:33 --> Helper loaded: form_helper
INFO - 2018-06-30 13:30:33 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:30:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:30:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:30:33 --> User Agent Class Initialized
INFO - 2018-06-30 13:30:33 --> Controller Class Initialized
INFO - 2018-06-30 13:30:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:30:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:30:33 --> Pixel_Model class loaded
INFO - 2018-06-30 13:30:33 --> Database Driver Class Initialized
INFO - 2018-06-30 13:30:33 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:30:33 --> Form Validation Class Initialized
INFO - 2018-06-30 13:30:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-30 13:30:33 --> Database Driver Class Initialized
INFO - 2018-06-30 13:30:33 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:30:33 --> Config Class Initialized
INFO - 2018-06-30 13:30:33 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:30:33 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:30:33 --> Utf8 Class Initialized
INFO - 2018-06-30 13:30:33 --> URI Class Initialized
INFO - 2018-06-30 13:30:33 --> Router Class Initialized
INFO - 2018-06-30 13:30:33 --> Output Class Initialized
INFO - 2018-06-30 13:30:33 --> Security Class Initialized
DEBUG - 2018-06-30 13:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:30:33 --> CSRF cookie sent
INFO - 2018-06-30 13:30:33 --> Input Class Initialized
INFO - 2018-06-30 13:30:33 --> Language Class Initialized
INFO - 2018-06-30 13:30:33 --> Loader Class Initialized
INFO - 2018-06-30 13:30:33 --> Helper loaded: url_helper
INFO - 2018-06-30 13:30:33 --> Helper loaded: form_helper
INFO - 2018-06-30 13:30:33 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:30:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:30:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:30:33 --> User Agent Class Initialized
INFO - 2018-06-30 13:30:33 --> Controller Class Initialized
INFO - 2018-06-30 13:30:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:30:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:30:33 --> Pixel_Model class loaded
INFO - 2018-06-30 13:30:33 --> Database Driver Class Initialized
INFO - 2018-06-30 13:30:33 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:30:33 --> Database Driver Class Initialized
INFO - 2018-06-30 13:30:33 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:30:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 13:30:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-06-30 13:30:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 13:30:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 13:30:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 13:30:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-30 13:30:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-30 13:30:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/other_autos.php
INFO - 2018-06-30 13:30:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 13:30:33 --> Final output sent to browser
DEBUG - 2018-06-30 13:30:33 --> Total execution time: 0.0387
INFO - 2018-06-30 13:30:43 --> Config Class Initialized
INFO - 2018-06-30 13:30:43 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:30:43 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:30:43 --> Utf8 Class Initialized
INFO - 2018-06-30 13:30:43 --> URI Class Initialized
INFO - 2018-06-30 13:30:43 --> Router Class Initialized
INFO - 2018-06-30 13:30:43 --> Output Class Initialized
INFO - 2018-06-30 13:30:43 --> Security Class Initialized
DEBUG - 2018-06-30 13:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:30:43 --> CSRF cookie sent
INFO - 2018-06-30 13:30:43 --> CSRF token verified
INFO - 2018-06-30 13:30:43 --> Input Class Initialized
INFO - 2018-06-30 13:30:43 --> Language Class Initialized
INFO - 2018-06-30 13:30:43 --> Loader Class Initialized
INFO - 2018-06-30 13:30:43 --> Helper loaded: url_helper
INFO - 2018-06-30 13:30:43 --> Helper loaded: form_helper
INFO - 2018-06-30 13:30:43 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:30:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:30:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:30:43 --> User Agent Class Initialized
INFO - 2018-06-30 13:30:43 --> Controller Class Initialized
INFO - 2018-06-30 13:30:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:30:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:30:43 --> Pixel_Model class loaded
INFO - 2018-06-30 13:30:43 --> Database Driver Class Initialized
INFO - 2018-06-30 13:30:43 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:30:43 --> Form Validation Class Initialized
INFO - 2018-06-30 13:30:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-30 13:30:43 --> Database Driver Class Initialized
INFO - 2018-06-30 13:30:43 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:30:43 --> Config Class Initialized
INFO - 2018-06-30 13:30:43 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:30:43 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:30:43 --> Utf8 Class Initialized
INFO - 2018-06-30 13:30:43 --> URI Class Initialized
INFO - 2018-06-30 13:30:43 --> Router Class Initialized
INFO - 2018-06-30 13:30:43 --> Output Class Initialized
INFO - 2018-06-30 13:30:43 --> Security Class Initialized
DEBUG - 2018-06-30 13:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:30:43 --> CSRF cookie sent
INFO - 2018-06-30 13:30:43 --> Input Class Initialized
INFO - 2018-06-30 13:30:43 --> Language Class Initialized
INFO - 2018-06-30 13:30:43 --> Loader Class Initialized
INFO - 2018-06-30 13:30:43 --> Helper loaded: url_helper
INFO - 2018-06-30 13:30:43 --> Helper loaded: form_helper
INFO - 2018-06-30 13:30:43 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:30:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:30:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:30:43 --> User Agent Class Initialized
INFO - 2018-06-30 13:30:43 --> Controller Class Initialized
INFO - 2018-06-30 13:30:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:30:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:30:43 --> Pixel_Model class loaded
INFO - 2018-06-30 13:30:43 --> Database Driver Class Initialized
INFO - 2018-06-30 13:30:43 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:30:43 --> Database Driver Class Initialized
INFO - 2018-06-30 13:30:43 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:30:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 13:30:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-06-30 13:30:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 13:30:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 13:30:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 13:30:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-30 13:30:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-30 13:30:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/collectables.php
INFO - 2018-06-30 13:30:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 13:30:43 --> Final output sent to browser
DEBUG - 2018-06-30 13:30:43 --> Total execution time: 0.0431
INFO - 2018-06-30 13:30:50 --> Config Class Initialized
INFO - 2018-06-30 13:30:50 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:30:50 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:30:50 --> Utf8 Class Initialized
INFO - 2018-06-30 13:30:50 --> URI Class Initialized
INFO - 2018-06-30 13:30:50 --> Router Class Initialized
INFO - 2018-06-30 13:30:50 --> Output Class Initialized
INFO - 2018-06-30 13:30:50 --> Security Class Initialized
DEBUG - 2018-06-30 13:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:30:50 --> CSRF cookie sent
INFO - 2018-06-30 13:30:50 --> CSRF token verified
INFO - 2018-06-30 13:30:50 --> Input Class Initialized
INFO - 2018-06-30 13:30:50 --> Language Class Initialized
INFO - 2018-06-30 13:30:50 --> Loader Class Initialized
INFO - 2018-06-30 13:30:50 --> Helper loaded: url_helper
INFO - 2018-06-30 13:30:50 --> Helper loaded: form_helper
INFO - 2018-06-30 13:30:50 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:30:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:30:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:30:50 --> User Agent Class Initialized
INFO - 2018-06-30 13:30:50 --> Controller Class Initialized
INFO - 2018-06-30 13:30:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:30:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:30:50 --> Pixel_Model class loaded
INFO - 2018-06-30 13:30:50 --> Database Driver Class Initialized
INFO - 2018-06-30 13:30:50 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:30:50 --> Form Validation Class Initialized
INFO - 2018-06-30 13:30:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-30 13:30:50 --> Database Driver Class Initialized
INFO - 2018-06-30 13:30:50 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:30:50 --> Config Class Initialized
INFO - 2018-06-30 13:30:50 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:30:50 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:30:50 --> Utf8 Class Initialized
INFO - 2018-06-30 13:30:50 --> URI Class Initialized
INFO - 2018-06-30 13:30:50 --> Router Class Initialized
INFO - 2018-06-30 13:30:50 --> Output Class Initialized
INFO - 2018-06-30 13:30:50 --> Security Class Initialized
DEBUG - 2018-06-30 13:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:30:50 --> CSRF cookie sent
INFO - 2018-06-30 13:30:50 --> Input Class Initialized
INFO - 2018-06-30 13:30:50 --> Language Class Initialized
INFO - 2018-06-30 13:30:50 --> Loader Class Initialized
INFO - 2018-06-30 13:30:50 --> Helper loaded: url_helper
INFO - 2018-06-30 13:30:50 --> Helper loaded: form_helper
INFO - 2018-06-30 13:30:50 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:30:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:30:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:30:50 --> User Agent Class Initialized
INFO - 2018-06-30 13:30:50 --> Controller Class Initialized
INFO - 2018-06-30 13:30:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:30:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:30:50 --> Pixel_Model class loaded
INFO - 2018-06-30 13:30:50 --> Database Driver Class Initialized
INFO - 2018-06-30 13:30:50 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:30:50 --> Database Driver Class Initialized
INFO - 2018-06-30 13:30:50 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:30:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 13:30:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-06-30 13:30:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 13:30:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 13:30:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 13:30:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-30 13:30:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-30 13:30:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/gadgets.php
INFO - 2018-06-30 13:30:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 13:30:50 --> Final output sent to browser
DEBUG - 2018-06-30 13:30:50 --> Total execution time: 0.0567
INFO - 2018-06-30 13:31:05 --> Config Class Initialized
INFO - 2018-06-30 13:31:05 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:31:05 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:31:05 --> Utf8 Class Initialized
INFO - 2018-06-30 13:31:05 --> URI Class Initialized
INFO - 2018-06-30 13:31:05 --> Router Class Initialized
INFO - 2018-06-30 13:31:05 --> Output Class Initialized
INFO - 2018-06-30 13:31:05 --> Security Class Initialized
DEBUG - 2018-06-30 13:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:31:05 --> CSRF cookie sent
INFO - 2018-06-30 13:31:05 --> CSRF token verified
INFO - 2018-06-30 13:31:05 --> Input Class Initialized
INFO - 2018-06-30 13:31:05 --> Language Class Initialized
INFO - 2018-06-30 13:31:05 --> Loader Class Initialized
INFO - 2018-06-30 13:31:05 --> Helper loaded: url_helper
INFO - 2018-06-30 13:31:05 --> Helper loaded: form_helper
INFO - 2018-06-30 13:31:05 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:31:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:31:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:31:05 --> User Agent Class Initialized
INFO - 2018-06-30 13:31:05 --> Controller Class Initialized
INFO - 2018-06-30 13:31:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:31:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:31:05 --> Pixel_Model class loaded
INFO - 2018-06-30 13:31:05 --> Database Driver Class Initialized
INFO - 2018-06-30 13:31:05 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:31:05 --> Form Validation Class Initialized
INFO - 2018-06-30 13:31:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-30 13:31:05 --> Database Driver Class Initialized
INFO - 2018-06-30 13:31:05 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:31:05 --> Config Class Initialized
INFO - 2018-06-30 13:31:05 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:31:05 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:31:05 --> Utf8 Class Initialized
INFO - 2018-06-30 13:31:05 --> URI Class Initialized
INFO - 2018-06-30 13:31:05 --> Router Class Initialized
INFO - 2018-06-30 13:31:05 --> Output Class Initialized
INFO - 2018-06-30 13:31:05 --> Security Class Initialized
DEBUG - 2018-06-30 13:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:31:05 --> CSRF cookie sent
INFO - 2018-06-30 13:31:05 --> Input Class Initialized
INFO - 2018-06-30 13:31:05 --> Language Class Initialized
INFO - 2018-06-30 13:31:05 --> Loader Class Initialized
INFO - 2018-06-30 13:31:05 --> Helper loaded: url_helper
INFO - 2018-06-30 13:31:05 --> Helper loaded: form_helper
INFO - 2018-06-30 13:31:05 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:31:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:31:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:31:05 --> User Agent Class Initialized
INFO - 2018-06-30 13:31:05 --> Controller Class Initialized
INFO - 2018-06-30 13:31:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:31:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:31:05 --> Pixel_Model class loaded
INFO - 2018-06-30 13:31:05 --> Database Driver Class Initialized
INFO - 2018-06-30 13:31:05 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:31:05 --> Database Driver Class Initialized
INFO - 2018-06-30 13:31:05 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:31:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 13:31:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-06-30 13:31:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 13:31:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 13:31:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 13:31:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-30 13:31:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-30 13:31:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/bank_accounts.php
INFO - 2018-06-30 13:31:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 13:31:05 --> Final output sent to browser
DEBUG - 2018-06-30 13:31:05 --> Total execution time: 0.0382
INFO - 2018-06-30 13:31:22 --> Config Class Initialized
INFO - 2018-06-30 13:31:22 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:31:22 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:31:22 --> Utf8 Class Initialized
INFO - 2018-06-30 13:31:22 --> URI Class Initialized
INFO - 2018-06-30 13:31:22 --> Router Class Initialized
INFO - 2018-06-30 13:31:22 --> Output Class Initialized
INFO - 2018-06-30 13:31:22 --> Security Class Initialized
DEBUG - 2018-06-30 13:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:31:22 --> CSRF cookie sent
INFO - 2018-06-30 13:31:22 --> CSRF token verified
INFO - 2018-06-30 13:31:22 --> Input Class Initialized
INFO - 2018-06-30 13:31:22 --> Language Class Initialized
INFO - 2018-06-30 13:31:22 --> Loader Class Initialized
INFO - 2018-06-30 13:31:22 --> Helper loaded: url_helper
INFO - 2018-06-30 13:31:22 --> Helper loaded: form_helper
INFO - 2018-06-30 13:31:22 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:31:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:31:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:31:22 --> User Agent Class Initialized
INFO - 2018-06-30 13:31:22 --> Controller Class Initialized
INFO - 2018-06-30 13:31:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:31:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:31:22 --> Pixel_Model class loaded
INFO - 2018-06-30 13:31:22 --> Database Driver Class Initialized
INFO - 2018-06-30 13:31:22 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:31:22 --> Form Validation Class Initialized
INFO - 2018-06-30 13:31:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-30 13:31:22 --> Database Driver Class Initialized
INFO - 2018-06-30 13:31:22 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:31:22 --> Config Class Initialized
INFO - 2018-06-30 13:31:22 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:31:22 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:31:22 --> Utf8 Class Initialized
INFO - 2018-06-30 13:31:22 --> URI Class Initialized
INFO - 2018-06-30 13:31:22 --> Router Class Initialized
INFO - 2018-06-30 13:31:22 --> Output Class Initialized
INFO - 2018-06-30 13:31:22 --> Security Class Initialized
DEBUG - 2018-06-30 13:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:31:22 --> CSRF cookie sent
INFO - 2018-06-30 13:31:22 --> Input Class Initialized
INFO - 2018-06-30 13:31:22 --> Language Class Initialized
INFO - 2018-06-30 13:31:22 --> Loader Class Initialized
INFO - 2018-06-30 13:31:22 --> Helper loaded: url_helper
INFO - 2018-06-30 13:31:22 --> Helper loaded: form_helper
INFO - 2018-06-30 13:31:22 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:31:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:31:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:31:22 --> User Agent Class Initialized
INFO - 2018-06-30 13:31:22 --> Controller Class Initialized
INFO - 2018-06-30 13:31:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:31:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:31:22 --> Pixel_Model class loaded
INFO - 2018-06-30 13:31:22 --> Database Driver Class Initialized
INFO - 2018-06-30 13:31:22 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:31:22 --> Database Driver Class Initialized
INFO - 2018-06-30 13:31:22 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:31:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 13:31:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-06-30 13:31:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 13:31:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 13:31:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 13:31:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-30 13:31:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-30 13:31:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/crypto_currencies.php
INFO - 2018-06-30 13:31:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 13:31:22 --> Final output sent to browser
DEBUG - 2018-06-30 13:31:22 --> Total execution time: 0.0400
INFO - 2018-06-30 13:31:28 --> Config Class Initialized
INFO - 2018-06-30 13:31:28 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:31:28 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:31:28 --> Utf8 Class Initialized
INFO - 2018-06-30 13:31:28 --> URI Class Initialized
INFO - 2018-06-30 13:31:28 --> Router Class Initialized
INFO - 2018-06-30 13:31:28 --> Output Class Initialized
INFO - 2018-06-30 13:31:28 --> Security Class Initialized
DEBUG - 2018-06-30 13:31:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:31:28 --> CSRF cookie sent
INFO - 2018-06-30 13:31:28 --> CSRF token verified
INFO - 2018-06-30 13:31:28 --> Input Class Initialized
INFO - 2018-06-30 13:31:28 --> Language Class Initialized
INFO - 2018-06-30 13:31:28 --> Loader Class Initialized
INFO - 2018-06-30 13:31:28 --> Helper loaded: url_helper
INFO - 2018-06-30 13:31:28 --> Helper loaded: form_helper
INFO - 2018-06-30 13:31:28 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:31:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:31:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:31:28 --> User Agent Class Initialized
INFO - 2018-06-30 13:31:28 --> Controller Class Initialized
INFO - 2018-06-30 13:31:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:31:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:31:28 --> Pixel_Model class loaded
INFO - 2018-06-30 13:31:28 --> Database Driver Class Initialized
INFO - 2018-06-30 13:31:28 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:31:28 --> Form Validation Class Initialized
INFO - 2018-06-30 13:31:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-30 13:31:28 --> Database Driver Class Initialized
INFO - 2018-06-30 13:31:28 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:31:28 --> Config Class Initialized
INFO - 2018-06-30 13:31:28 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:31:28 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:31:28 --> Utf8 Class Initialized
INFO - 2018-06-30 13:31:28 --> URI Class Initialized
INFO - 2018-06-30 13:31:28 --> Router Class Initialized
INFO - 2018-06-30 13:31:28 --> Output Class Initialized
INFO - 2018-06-30 13:31:28 --> Security Class Initialized
DEBUG - 2018-06-30 13:31:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:31:28 --> CSRF cookie sent
INFO - 2018-06-30 13:31:28 --> Input Class Initialized
INFO - 2018-06-30 13:31:28 --> Language Class Initialized
INFO - 2018-06-30 13:31:28 --> Loader Class Initialized
INFO - 2018-06-30 13:31:28 --> Helper loaded: url_helper
INFO - 2018-06-30 13:31:28 --> Helper loaded: form_helper
INFO - 2018-06-30 13:31:28 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:31:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:31:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:31:28 --> User Agent Class Initialized
INFO - 2018-06-30 13:31:28 --> Controller Class Initialized
INFO - 2018-06-30 13:31:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:31:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:31:28 --> Pixel_Model class loaded
INFO - 2018-06-30 13:31:28 --> Database Driver Class Initialized
INFO - 2018-06-30 13:31:28 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:31:28 --> Database Driver Class Initialized
INFO - 2018-06-30 13:31:28 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:31:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 13:31:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-06-30 13:31:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 13:31:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 13:31:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 13:31:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-30 13:31:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-30 13:31:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/money_owed_you.php
INFO - 2018-06-30 13:31:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 13:31:28 --> Final output sent to browser
DEBUG - 2018-06-30 13:31:28 --> Total execution time: 0.0384
INFO - 2018-06-30 13:31:37 --> Config Class Initialized
INFO - 2018-06-30 13:31:37 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:31:37 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:31:37 --> Utf8 Class Initialized
INFO - 2018-06-30 13:31:37 --> URI Class Initialized
INFO - 2018-06-30 13:31:37 --> Router Class Initialized
INFO - 2018-06-30 13:31:37 --> Output Class Initialized
INFO - 2018-06-30 13:31:37 --> Security Class Initialized
DEBUG - 2018-06-30 13:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:31:37 --> CSRF cookie sent
INFO - 2018-06-30 13:31:37 --> CSRF token verified
INFO - 2018-06-30 13:31:37 --> Input Class Initialized
INFO - 2018-06-30 13:31:37 --> Language Class Initialized
INFO - 2018-06-30 13:31:37 --> Loader Class Initialized
INFO - 2018-06-30 13:31:37 --> Helper loaded: url_helper
INFO - 2018-06-30 13:31:37 --> Helper loaded: form_helper
INFO - 2018-06-30 13:31:37 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:31:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:31:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:31:37 --> User Agent Class Initialized
INFO - 2018-06-30 13:31:37 --> Controller Class Initialized
INFO - 2018-06-30 13:31:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:31:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:31:37 --> Pixel_Model class loaded
INFO - 2018-06-30 13:31:37 --> Database Driver Class Initialized
INFO - 2018-06-30 13:31:37 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:31:37 --> Form Validation Class Initialized
INFO - 2018-06-30 13:31:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-30 13:31:37 --> Database Driver Class Initialized
INFO - 2018-06-30 13:31:37 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:31:37 --> Config Class Initialized
INFO - 2018-06-30 13:31:37 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:31:37 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:31:37 --> Utf8 Class Initialized
INFO - 2018-06-30 13:31:37 --> URI Class Initialized
INFO - 2018-06-30 13:31:37 --> Router Class Initialized
INFO - 2018-06-30 13:31:37 --> Output Class Initialized
INFO - 2018-06-30 13:31:37 --> Security Class Initialized
DEBUG - 2018-06-30 13:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:31:37 --> CSRF cookie sent
INFO - 2018-06-30 13:31:37 --> Input Class Initialized
INFO - 2018-06-30 13:31:37 --> Language Class Initialized
INFO - 2018-06-30 13:31:37 --> Loader Class Initialized
INFO - 2018-06-30 13:31:37 --> Helper loaded: url_helper
INFO - 2018-06-30 13:31:37 --> Helper loaded: form_helper
INFO - 2018-06-30 13:31:37 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:31:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:31:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:31:37 --> User Agent Class Initialized
INFO - 2018-06-30 13:31:37 --> Controller Class Initialized
INFO - 2018-06-30 13:31:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:31:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:31:37 --> Pixel_Model class loaded
INFO - 2018-06-30 13:31:37 --> Database Driver Class Initialized
INFO - 2018-06-30 13:31:37 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:31:37 --> Database Driver Class Initialized
INFO - 2018-06-30 13:31:37 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:31:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 13:31:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-06-30 13:31:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 13:31:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 13:31:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 13:31:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-30 13:31:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-30 13:31:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/investments_stocks.php
INFO - 2018-06-30 13:31:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 13:31:37 --> Final output sent to browser
DEBUG - 2018-06-30 13:31:37 --> Total execution time: 0.0462
INFO - 2018-06-30 13:31:52 --> Config Class Initialized
INFO - 2018-06-30 13:31:52 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:31:52 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:31:52 --> Utf8 Class Initialized
INFO - 2018-06-30 13:31:52 --> URI Class Initialized
INFO - 2018-06-30 13:31:52 --> Router Class Initialized
INFO - 2018-06-30 13:31:52 --> Output Class Initialized
INFO - 2018-06-30 13:31:52 --> Security Class Initialized
DEBUG - 2018-06-30 13:31:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:31:52 --> CSRF cookie sent
INFO - 2018-06-30 13:31:52 --> CSRF token verified
INFO - 2018-06-30 13:31:52 --> Input Class Initialized
INFO - 2018-06-30 13:31:52 --> Language Class Initialized
INFO - 2018-06-30 13:31:52 --> Loader Class Initialized
INFO - 2018-06-30 13:31:53 --> Helper loaded: url_helper
INFO - 2018-06-30 13:31:53 --> Helper loaded: form_helper
INFO - 2018-06-30 13:31:53 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:31:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:31:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:31:53 --> User Agent Class Initialized
INFO - 2018-06-30 13:31:53 --> Controller Class Initialized
INFO - 2018-06-30 13:31:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:31:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:31:53 --> Pixel_Model class loaded
INFO - 2018-06-30 13:31:53 --> Database Driver Class Initialized
INFO - 2018-06-30 13:31:53 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:31:53 --> Form Validation Class Initialized
INFO - 2018-06-30 13:31:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-30 13:31:53 --> Database Driver Class Initialized
INFO - 2018-06-30 13:31:53 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:31:53 --> Config Class Initialized
INFO - 2018-06-30 13:31:53 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:31:53 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:31:53 --> Utf8 Class Initialized
INFO - 2018-06-30 13:31:53 --> URI Class Initialized
INFO - 2018-06-30 13:31:53 --> Router Class Initialized
INFO - 2018-06-30 13:31:53 --> Output Class Initialized
INFO - 2018-06-30 13:31:53 --> Security Class Initialized
DEBUG - 2018-06-30 13:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:31:53 --> CSRF cookie sent
INFO - 2018-06-30 13:31:53 --> Input Class Initialized
INFO - 2018-06-30 13:31:53 --> Language Class Initialized
INFO - 2018-06-30 13:31:53 --> Loader Class Initialized
INFO - 2018-06-30 13:31:53 --> Helper loaded: url_helper
INFO - 2018-06-30 13:31:53 --> Helper loaded: form_helper
INFO - 2018-06-30 13:31:53 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:31:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:31:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:31:53 --> User Agent Class Initialized
INFO - 2018-06-30 13:31:53 --> Controller Class Initialized
INFO - 2018-06-30 13:31:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:31:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:31:53 --> Pixel_Model class loaded
INFO - 2018-06-30 13:31:53 --> Database Driver Class Initialized
INFO - 2018-06-30 13:31:53 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:31:53 --> Database Driver Class Initialized
INFO - 2018-06-30 13:31:53 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:31:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 13:31:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-06-30 13:31:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 13:31:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 13:31:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 13:31:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-30 13:31:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-30 13:31:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/business_value_assets.php
INFO - 2018-06-30 13:31:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 13:31:53 --> Final output sent to browser
DEBUG - 2018-06-30 13:31:53 --> Total execution time: 0.0412
INFO - 2018-06-30 13:32:07 --> Config Class Initialized
INFO - 2018-06-30 13:32:07 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:32:07 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:32:07 --> Utf8 Class Initialized
INFO - 2018-06-30 13:32:07 --> URI Class Initialized
INFO - 2018-06-30 13:32:07 --> Router Class Initialized
INFO - 2018-06-30 13:32:07 --> Output Class Initialized
INFO - 2018-06-30 13:32:07 --> Security Class Initialized
DEBUG - 2018-06-30 13:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:32:07 --> CSRF cookie sent
INFO - 2018-06-30 13:32:07 --> CSRF token verified
INFO - 2018-06-30 13:32:07 --> Input Class Initialized
INFO - 2018-06-30 13:32:07 --> Language Class Initialized
INFO - 2018-06-30 13:32:07 --> Loader Class Initialized
INFO - 2018-06-30 13:32:07 --> Helper loaded: url_helper
INFO - 2018-06-30 13:32:07 --> Helper loaded: form_helper
INFO - 2018-06-30 13:32:07 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:32:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:32:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:32:07 --> User Agent Class Initialized
INFO - 2018-06-30 13:32:07 --> Controller Class Initialized
INFO - 2018-06-30 13:32:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:32:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:32:07 --> Pixel_Model class loaded
INFO - 2018-06-30 13:32:07 --> Database Driver Class Initialized
INFO - 2018-06-30 13:32:07 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:32:07 --> Form Validation Class Initialized
INFO - 2018-06-30 13:32:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-30 13:32:07 --> Database Driver Class Initialized
INFO - 2018-06-30 13:32:07 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:32:07 --> Config Class Initialized
INFO - 2018-06-30 13:32:07 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:32:07 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:32:07 --> Utf8 Class Initialized
INFO - 2018-06-30 13:32:07 --> URI Class Initialized
INFO - 2018-06-30 13:32:07 --> Router Class Initialized
INFO - 2018-06-30 13:32:07 --> Output Class Initialized
INFO - 2018-06-30 13:32:07 --> Security Class Initialized
DEBUG - 2018-06-30 13:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:32:07 --> CSRF cookie sent
INFO - 2018-06-30 13:32:07 --> Input Class Initialized
INFO - 2018-06-30 13:32:07 --> Language Class Initialized
INFO - 2018-06-30 13:32:07 --> Loader Class Initialized
INFO - 2018-06-30 13:32:07 --> Helper loaded: url_helper
INFO - 2018-06-30 13:32:07 --> Helper loaded: form_helper
INFO - 2018-06-30 13:32:07 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:32:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:32:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:32:07 --> User Agent Class Initialized
INFO - 2018-06-30 13:32:07 --> Controller Class Initialized
INFO - 2018-06-30 13:32:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:32:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:32:07 --> Pixel_Model class loaded
INFO - 2018-06-30 13:32:07 --> Database Driver Class Initialized
INFO - 2018-06-30 13:32:07 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:32:07 --> Database Driver Class Initialized
INFO - 2018-06-30 13:32:07 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:32:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 13:32:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-06-30 13:32:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 13:32:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 13:32:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 13:32:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-30 13:32:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-30 13:32:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/disability_insurance.php
INFO - 2018-06-30 13:32:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 13:32:07 --> Final output sent to browser
DEBUG - 2018-06-30 13:32:07 --> Total execution time: 0.0404
INFO - 2018-06-30 13:32:22 --> Config Class Initialized
INFO - 2018-06-30 13:32:22 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:32:22 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:32:22 --> Utf8 Class Initialized
INFO - 2018-06-30 13:32:22 --> URI Class Initialized
INFO - 2018-06-30 13:32:22 --> Router Class Initialized
INFO - 2018-06-30 13:32:22 --> Output Class Initialized
INFO - 2018-06-30 13:32:22 --> Security Class Initialized
DEBUG - 2018-06-30 13:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:32:22 --> CSRF cookie sent
INFO - 2018-06-30 13:32:22 --> CSRF token verified
INFO - 2018-06-30 13:32:22 --> Input Class Initialized
INFO - 2018-06-30 13:32:22 --> Language Class Initialized
INFO - 2018-06-30 13:32:22 --> Loader Class Initialized
INFO - 2018-06-30 13:32:22 --> Helper loaded: url_helper
INFO - 2018-06-30 13:32:22 --> Helper loaded: form_helper
INFO - 2018-06-30 13:32:22 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:32:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:32:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:32:22 --> User Agent Class Initialized
INFO - 2018-06-30 13:32:22 --> Controller Class Initialized
INFO - 2018-06-30 13:32:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:32:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:32:22 --> Pixel_Model class loaded
INFO - 2018-06-30 13:32:22 --> Database Driver Class Initialized
INFO - 2018-06-30 13:32:22 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:32:22 --> Form Validation Class Initialized
INFO - 2018-06-30 13:32:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-30 13:32:22 --> Database Driver Class Initialized
INFO - 2018-06-30 13:32:22 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:32:22 --> Config Class Initialized
INFO - 2018-06-30 13:32:22 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:32:22 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:32:22 --> Utf8 Class Initialized
INFO - 2018-06-30 13:32:22 --> URI Class Initialized
INFO - 2018-06-30 13:32:22 --> Router Class Initialized
INFO - 2018-06-30 13:32:22 --> Output Class Initialized
INFO - 2018-06-30 13:32:22 --> Security Class Initialized
DEBUG - 2018-06-30 13:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:32:22 --> CSRF cookie sent
INFO - 2018-06-30 13:32:22 --> Input Class Initialized
INFO - 2018-06-30 13:32:22 --> Language Class Initialized
INFO - 2018-06-30 13:32:22 --> Loader Class Initialized
INFO - 2018-06-30 13:32:22 --> Helper loaded: url_helper
INFO - 2018-06-30 13:32:22 --> Helper loaded: form_helper
INFO - 2018-06-30 13:32:22 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:32:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:32:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:32:22 --> User Agent Class Initialized
INFO - 2018-06-30 13:32:22 --> Controller Class Initialized
INFO - 2018-06-30 13:32:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:32:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:32:22 --> Pixel_Model class loaded
INFO - 2018-06-30 13:32:22 --> Database Driver Class Initialized
INFO - 2018-06-30 13:32:22 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:32:22 --> Database Driver Class Initialized
INFO - 2018-06-30 13:32:22 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:32:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 13:32:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-06-30 13:32:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 13:32:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 13:32:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 13:32:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-30 13:32:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-30 13:32:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/personal_loans.php
INFO - 2018-06-30 13:32:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 13:32:22 --> Final output sent to browser
DEBUG - 2018-06-30 13:32:22 --> Total execution time: 0.0397
INFO - 2018-06-30 13:32:31 --> Config Class Initialized
INFO - 2018-06-30 13:32:31 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:32:31 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:32:31 --> Utf8 Class Initialized
INFO - 2018-06-30 13:32:31 --> URI Class Initialized
INFO - 2018-06-30 13:32:31 --> Router Class Initialized
INFO - 2018-06-30 13:32:31 --> Output Class Initialized
INFO - 2018-06-30 13:32:31 --> Security Class Initialized
DEBUG - 2018-06-30 13:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:32:31 --> CSRF cookie sent
INFO - 2018-06-30 13:32:31 --> CSRF token verified
INFO - 2018-06-30 13:32:31 --> Input Class Initialized
INFO - 2018-06-30 13:32:31 --> Language Class Initialized
INFO - 2018-06-30 13:32:31 --> Loader Class Initialized
INFO - 2018-06-30 13:32:31 --> Helper loaded: url_helper
INFO - 2018-06-30 13:32:31 --> Helper loaded: form_helper
INFO - 2018-06-30 13:32:31 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:32:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:32:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:32:31 --> User Agent Class Initialized
INFO - 2018-06-30 13:32:31 --> Controller Class Initialized
INFO - 2018-06-30 13:32:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:32:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:32:31 --> Pixel_Model class loaded
INFO - 2018-06-30 13:32:31 --> Database Driver Class Initialized
INFO - 2018-06-30 13:32:31 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:32:31 --> Form Validation Class Initialized
INFO - 2018-06-30 13:32:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-30 13:32:31 --> Database Driver Class Initialized
INFO - 2018-06-30 13:32:31 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:32:31 --> Config Class Initialized
INFO - 2018-06-30 13:32:31 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:32:31 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:32:31 --> Utf8 Class Initialized
INFO - 2018-06-30 13:32:31 --> URI Class Initialized
INFO - 2018-06-30 13:32:31 --> Router Class Initialized
INFO - 2018-06-30 13:32:31 --> Output Class Initialized
INFO - 2018-06-30 13:32:31 --> Security Class Initialized
DEBUG - 2018-06-30 13:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:32:31 --> CSRF cookie sent
INFO - 2018-06-30 13:32:31 --> Input Class Initialized
INFO - 2018-06-30 13:32:31 --> Language Class Initialized
INFO - 2018-06-30 13:32:31 --> Loader Class Initialized
INFO - 2018-06-30 13:32:31 --> Helper loaded: url_helper
INFO - 2018-06-30 13:32:31 --> Helper loaded: form_helper
INFO - 2018-06-30 13:32:31 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:32:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:32:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:32:31 --> User Agent Class Initialized
INFO - 2018-06-30 13:32:31 --> Controller Class Initialized
INFO - 2018-06-30 13:32:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:32:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:32:31 --> Pixel_Model class loaded
INFO - 2018-06-30 13:32:31 --> Database Driver Class Initialized
INFO - 2018-06-30 13:32:31 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:32:31 --> Database Driver Class Initialized
INFO - 2018-06-30 13:32:31 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:32:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 13:32:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-06-30 13:32:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 13:32:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 13:32:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 13:32:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-30 13:32:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-30 13:32:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/personal_credit_line.php
INFO - 2018-06-30 13:32:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 13:32:31 --> Final output sent to browser
DEBUG - 2018-06-30 13:32:31 --> Total execution time: 0.0425
INFO - 2018-06-30 13:32:37 --> Config Class Initialized
INFO - 2018-06-30 13:32:37 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:32:37 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:32:37 --> Utf8 Class Initialized
INFO - 2018-06-30 13:32:37 --> URI Class Initialized
INFO - 2018-06-30 13:32:37 --> Router Class Initialized
INFO - 2018-06-30 13:32:37 --> Output Class Initialized
INFO - 2018-06-30 13:32:37 --> Security Class Initialized
DEBUG - 2018-06-30 13:32:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:32:37 --> CSRF cookie sent
INFO - 2018-06-30 13:32:37 --> CSRF token verified
INFO - 2018-06-30 13:32:37 --> Input Class Initialized
INFO - 2018-06-30 13:32:37 --> Language Class Initialized
INFO - 2018-06-30 13:32:37 --> Loader Class Initialized
INFO - 2018-06-30 13:32:37 --> Helper loaded: url_helper
INFO - 2018-06-30 13:32:37 --> Helper loaded: form_helper
INFO - 2018-06-30 13:32:37 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:32:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:32:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:32:37 --> User Agent Class Initialized
INFO - 2018-06-30 13:32:37 --> Controller Class Initialized
INFO - 2018-06-30 13:32:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:32:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:32:37 --> Pixel_Model class loaded
INFO - 2018-06-30 13:32:37 --> Database Driver Class Initialized
INFO - 2018-06-30 13:32:37 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:32:37 --> Form Validation Class Initialized
INFO - 2018-06-30 13:32:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-30 13:32:37 --> Database Driver Class Initialized
INFO - 2018-06-30 13:32:37 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:32:37 --> Config Class Initialized
INFO - 2018-06-30 13:32:37 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:32:37 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:32:37 --> Utf8 Class Initialized
INFO - 2018-06-30 13:32:37 --> URI Class Initialized
INFO - 2018-06-30 13:32:37 --> Router Class Initialized
INFO - 2018-06-30 13:32:37 --> Output Class Initialized
INFO - 2018-06-30 13:32:37 --> Security Class Initialized
DEBUG - 2018-06-30 13:32:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:32:37 --> CSRF cookie sent
INFO - 2018-06-30 13:32:37 --> Input Class Initialized
INFO - 2018-06-30 13:32:37 --> Language Class Initialized
INFO - 2018-06-30 13:32:37 --> Loader Class Initialized
INFO - 2018-06-30 13:32:37 --> Helper loaded: url_helper
INFO - 2018-06-30 13:32:37 --> Helper loaded: form_helper
INFO - 2018-06-30 13:32:37 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:32:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:32:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:32:37 --> User Agent Class Initialized
INFO - 2018-06-30 13:32:37 --> Controller Class Initialized
INFO - 2018-06-30 13:32:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:32:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:32:37 --> Pixel_Model class loaded
INFO - 2018-06-30 13:32:37 --> Database Driver Class Initialized
INFO - 2018-06-30 13:32:37 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:32:37 --> Database Driver Class Initialized
INFO - 2018-06-30 13:32:38 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:32:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 13:32:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-06-30 13:32:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 13:32:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 13:32:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 13:32:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-30 13:32:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-30 13:32:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/credit_cards.php
INFO - 2018-06-30 13:32:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 13:32:38 --> Final output sent to browser
DEBUG - 2018-06-30 13:32:38 --> Total execution time: 0.0430
INFO - 2018-06-30 13:32:42 --> Config Class Initialized
INFO - 2018-06-30 13:32:42 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:32:42 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:32:42 --> Utf8 Class Initialized
INFO - 2018-06-30 13:32:42 --> URI Class Initialized
INFO - 2018-06-30 13:32:42 --> Router Class Initialized
INFO - 2018-06-30 13:32:42 --> Output Class Initialized
INFO - 2018-06-30 13:32:42 --> Security Class Initialized
DEBUG - 2018-06-30 13:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:32:42 --> CSRF cookie sent
INFO - 2018-06-30 13:32:42 --> CSRF token verified
INFO - 2018-06-30 13:32:42 --> Input Class Initialized
INFO - 2018-06-30 13:32:42 --> Language Class Initialized
INFO - 2018-06-30 13:32:42 --> Loader Class Initialized
INFO - 2018-06-30 13:32:42 --> Helper loaded: url_helper
INFO - 2018-06-30 13:32:42 --> Helper loaded: form_helper
INFO - 2018-06-30 13:32:42 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:32:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:32:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:32:42 --> User Agent Class Initialized
INFO - 2018-06-30 13:32:42 --> Controller Class Initialized
INFO - 2018-06-30 13:32:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:32:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:32:42 --> Pixel_Model class loaded
INFO - 2018-06-30 13:32:42 --> Database Driver Class Initialized
INFO - 2018-06-30 13:32:42 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:32:42 --> Form Validation Class Initialized
INFO - 2018-06-30 13:32:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-30 13:32:42 --> Database Driver Class Initialized
INFO - 2018-06-30 13:32:42 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:32:42 --> Config Class Initialized
INFO - 2018-06-30 13:32:42 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:32:42 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:32:42 --> Utf8 Class Initialized
INFO - 2018-06-30 13:32:42 --> URI Class Initialized
INFO - 2018-06-30 13:32:42 --> Router Class Initialized
INFO - 2018-06-30 13:32:42 --> Output Class Initialized
INFO - 2018-06-30 13:32:42 --> Security Class Initialized
DEBUG - 2018-06-30 13:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:32:42 --> CSRF cookie sent
INFO - 2018-06-30 13:32:42 --> Input Class Initialized
INFO - 2018-06-30 13:32:42 --> Language Class Initialized
INFO - 2018-06-30 13:32:42 --> Loader Class Initialized
INFO - 2018-06-30 13:32:42 --> Helper loaded: url_helper
INFO - 2018-06-30 13:32:42 --> Helper loaded: form_helper
INFO - 2018-06-30 13:32:42 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:32:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:32:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:32:42 --> User Agent Class Initialized
INFO - 2018-06-30 13:32:42 --> Controller Class Initialized
INFO - 2018-06-30 13:32:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:32:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:32:42 --> Pixel_Model class loaded
INFO - 2018-06-30 13:32:42 --> Database Driver Class Initialized
INFO - 2018-06-30 13:32:42 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:32:42 --> Database Driver Class Initialized
INFO - 2018-06-30 13:32:42 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:32:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 13:32:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-06-30 13:32:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 13:32:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 13:32:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 13:32:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-30 13:32:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-30 13:32:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/other_debt.php
INFO - 2018-06-30 13:32:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 13:32:42 --> Final output sent to browser
DEBUG - 2018-06-30 13:32:42 --> Total execution time: 0.0405
INFO - 2018-06-30 13:32:48 --> Config Class Initialized
INFO - 2018-06-30 13:32:48 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:32:48 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:32:48 --> Utf8 Class Initialized
INFO - 2018-06-30 13:32:48 --> URI Class Initialized
INFO - 2018-06-30 13:32:48 --> Router Class Initialized
INFO - 2018-06-30 13:32:48 --> Output Class Initialized
INFO - 2018-06-30 13:32:48 --> Security Class Initialized
DEBUG - 2018-06-30 13:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:32:48 --> CSRF cookie sent
INFO - 2018-06-30 13:32:48 --> CSRF token verified
INFO - 2018-06-30 13:32:48 --> Input Class Initialized
INFO - 2018-06-30 13:32:48 --> Language Class Initialized
INFO - 2018-06-30 13:32:48 --> Loader Class Initialized
INFO - 2018-06-30 13:32:48 --> Helper loaded: url_helper
INFO - 2018-06-30 13:32:48 --> Helper loaded: form_helper
INFO - 2018-06-30 13:32:48 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:32:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:32:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:32:48 --> User Agent Class Initialized
INFO - 2018-06-30 13:32:48 --> Controller Class Initialized
INFO - 2018-06-30 13:32:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:32:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:32:48 --> Pixel_Model class loaded
INFO - 2018-06-30 13:32:48 --> Database Driver Class Initialized
INFO - 2018-06-30 13:32:48 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:32:48 --> Form Validation Class Initialized
INFO - 2018-06-30 13:32:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-30 13:32:48 --> Database Driver Class Initialized
INFO - 2018-06-30 13:32:48 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:32:48 --> Config Class Initialized
INFO - 2018-06-30 13:32:48 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:32:48 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:32:48 --> Utf8 Class Initialized
INFO - 2018-06-30 13:32:48 --> URI Class Initialized
INFO - 2018-06-30 13:32:48 --> Router Class Initialized
INFO - 2018-06-30 13:32:48 --> Output Class Initialized
INFO - 2018-06-30 13:32:48 --> Security Class Initialized
DEBUG - 2018-06-30 13:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:32:48 --> CSRF cookie sent
INFO - 2018-06-30 13:32:48 --> Input Class Initialized
INFO - 2018-06-30 13:32:48 --> Language Class Initialized
INFO - 2018-06-30 13:32:48 --> Loader Class Initialized
INFO - 2018-06-30 13:32:48 --> Helper loaded: url_helper
INFO - 2018-06-30 13:32:48 --> Helper loaded: form_helper
INFO - 2018-06-30 13:32:48 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:32:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:32:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:32:48 --> User Agent Class Initialized
INFO - 2018-06-30 13:32:48 --> Controller Class Initialized
INFO - 2018-06-30 13:32:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:32:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:32:48 --> Pixel_Model class loaded
INFO - 2018-06-30 13:32:48 --> Database Driver Class Initialized
INFO - 2018-06-30 13:32:48 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:32:48 --> Database Driver Class Initialized
INFO - 2018-06-30 13:32:48 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:32:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 13:32:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-06-30 13:32:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 13:32:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 13:32:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 13:32:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-30 13:32:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-30 13:32:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/business_credit_line.php
INFO - 2018-06-30 13:32:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 13:32:48 --> Final output sent to browser
DEBUG - 2018-06-30 13:32:48 --> Total execution time: 0.0618
INFO - 2018-06-30 13:32:54 --> Config Class Initialized
INFO - 2018-06-30 13:32:54 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:32:54 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:32:54 --> Utf8 Class Initialized
INFO - 2018-06-30 13:32:54 --> URI Class Initialized
INFO - 2018-06-30 13:32:54 --> Router Class Initialized
INFO - 2018-06-30 13:32:54 --> Output Class Initialized
INFO - 2018-06-30 13:32:54 --> Security Class Initialized
DEBUG - 2018-06-30 13:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:32:54 --> CSRF cookie sent
INFO - 2018-06-30 13:32:54 --> CSRF token verified
INFO - 2018-06-30 13:32:54 --> Input Class Initialized
INFO - 2018-06-30 13:32:54 --> Language Class Initialized
INFO - 2018-06-30 13:32:54 --> Loader Class Initialized
INFO - 2018-06-30 13:32:54 --> Helper loaded: url_helper
INFO - 2018-06-30 13:32:54 --> Helper loaded: form_helper
INFO - 2018-06-30 13:32:54 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:32:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:32:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:32:54 --> User Agent Class Initialized
INFO - 2018-06-30 13:32:54 --> Controller Class Initialized
INFO - 2018-06-30 13:32:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:32:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:32:54 --> Pixel_Model class loaded
INFO - 2018-06-30 13:32:54 --> Database Driver Class Initialized
INFO - 2018-06-30 13:32:54 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:32:54 --> Form Validation Class Initialized
INFO - 2018-06-30 13:32:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-30 13:32:54 --> Database Driver Class Initialized
INFO - 2018-06-30 13:32:54 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:32:54 --> Config Class Initialized
INFO - 2018-06-30 13:32:54 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:32:54 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:32:54 --> Utf8 Class Initialized
INFO - 2018-06-30 13:32:54 --> URI Class Initialized
INFO - 2018-06-30 13:32:54 --> Router Class Initialized
INFO - 2018-06-30 13:32:54 --> Output Class Initialized
INFO - 2018-06-30 13:32:54 --> Security Class Initialized
DEBUG - 2018-06-30 13:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:32:54 --> CSRF cookie sent
INFO - 2018-06-30 13:32:54 --> Input Class Initialized
INFO - 2018-06-30 13:32:54 --> Language Class Initialized
INFO - 2018-06-30 13:32:54 --> Loader Class Initialized
INFO - 2018-06-30 13:32:54 --> Helper loaded: url_helper
INFO - 2018-06-30 13:32:54 --> Helper loaded: form_helper
INFO - 2018-06-30 13:32:54 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:32:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:32:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:32:54 --> User Agent Class Initialized
INFO - 2018-06-30 13:32:54 --> Controller Class Initialized
INFO - 2018-06-30 13:32:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:32:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:32:54 --> Pixel_Model class loaded
INFO - 2018-06-30 13:32:54 --> Database Driver Class Initialized
INFO - 2018-06-30 13:32:54 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:32:54 --> Database Driver Class Initialized
INFO - 2018-06-30 13:32:54 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:32:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 13:32:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-06-30 13:32:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 13:32:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 13:32:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 13:32:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-06-30 13:32:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-06-30 13:32:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/influencer_info.php
INFO - 2018-06-30 13:32:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 13:32:54 --> Final output sent to browser
DEBUG - 2018-06-30 13:32:54 --> Total execution time: 0.0518
INFO - 2018-06-30 13:33:51 --> Config Class Initialized
INFO - 2018-06-30 13:33:51 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:33:51 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:33:51 --> Utf8 Class Initialized
INFO - 2018-06-30 13:33:51 --> URI Class Initialized
INFO - 2018-06-30 13:33:51 --> Router Class Initialized
INFO - 2018-06-30 13:33:51 --> Output Class Initialized
INFO - 2018-06-30 13:33:51 --> Security Class Initialized
DEBUG - 2018-06-30 13:33:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:33:51 --> CSRF cookie sent
INFO - 2018-06-30 13:33:51 --> CSRF token verified
INFO - 2018-06-30 13:33:51 --> Input Class Initialized
INFO - 2018-06-30 13:33:51 --> Language Class Initialized
INFO - 2018-06-30 13:33:51 --> Loader Class Initialized
INFO - 2018-06-30 13:33:51 --> Helper loaded: url_helper
INFO - 2018-06-30 13:33:51 --> Helper loaded: form_helper
INFO - 2018-06-30 13:33:51 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:33:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:33:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:33:51 --> User Agent Class Initialized
INFO - 2018-06-30 13:33:51 --> Controller Class Initialized
INFO - 2018-06-30 13:33:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:33:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:33:51 --> Pixel_Model class loaded
INFO - 2018-06-30 13:33:51 --> Database Driver Class Initialized
INFO - 2018-06-30 13:33:51 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:33:51 --> Form Validation Class Initialized
INFO - 2018-06-30 13:33:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-06-30 13:33:51 --> Config Class Initialized
INFO - 2018-06-30 13:33:51 --> Hooks Class Initialized
DEBUG - 2018-06-30 13:33:51 --> UTF-8 Support Enabled
INFO - 2018-06-30 13:33:51 --> Utf8 Class Initialized
INFO - 2018-06-30 13:33:51 --> URI Class Initialized
INFO - 2018-06-30 13:33:51 --> Router Class Initialized
INFO - 2018-06-30 13:33:51 --> Output Class Initialized
INFO - 2018-06-30 13:33:51 --> Security Class Initialized
DEBUG - 2018-06-30 13:33:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 13:33:51 --> CSRF cookie sent
INFO - 2018-06-30 13:33:51 --> Input Class Initialized
INFO - 2018-06-30 13:33:51 --> Language Class Initialized
INFO - 2018-06-30 13:33:51 --> Loader Class Initialized
INFO - 2018-06-30 13:33:51 --> Helper loaded: url_helper
INFO - 2018-06-30 13:33:51 --> Helper loaded: form_helper
INFO - 2018-06-30 13:33:51 --> Helper loaded: language_helper
DEBUG - 2018-06-30 13:33:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 13:33:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 13:33:51 --> User Agent Class Initialized
INFO - 2018-06-30 13:33:51 --> Controller Class Initialized
INFO - 2018-06-30 13:33:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 13:33:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 13:33:51 --> Pixel_Model class loaded
INFO - 2018-06-30 13:33:51 --> Database Driver Class Initialized
INFO - 2018-06-30 13:33:51 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 13:33:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 13:33:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-06-30 13:33:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 13:33:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 13:33:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 13:33:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/finish.php
INFO - 2018-06-30 13:33:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 13:33:51 --> Final output sent to browser
DEBUG - 2018-06-30 13:33:51 --> Total execution time: 0.0418
INFO - 2018-06-30 14:39:55 --> Config Class Initialized
INFO - 2018-06-30 14:39:55 --> Hooks Class Initialized
DEBUG - 2018-06-30 14:39:55 --> UTF-8 Support Enabled
INFO - 2018-06-30 14:39:55 --> Utf8 Class Initialized
INFO - 2018-06-30 14:39:55 --> URI Class Initialized
INFO - 2018-06-30 14:39:55 --> Router Class Initialized
INFO - 2018-06-30 14:39:55 --> Output Class Initialized
INFO - 2018-06-30 14:39:55 --> Security Class Initialized
DEBUG - 2018-06-30 14:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 14:39:55 --> CSRF cookie sent
INFO - 2018-06-30 14:39:55 --> Input Class Initialized
INFO - 2018-06-30 14:39:55 --> Language Class Initialized
INFO - 2018-06-30 14:39:55 --> Loader Class Initialized
INFO - 2018-06-30 14:39:55 --> Helper loaded: url_helper
INFO - 2018-06-30 14:39:55 --> Helper loaded: form_helper
INFO - 2018-06-30 14:39:55 --> Helper loaded: language_helper
DEBUG - 2018-06-30 14:39:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 14:39:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 14:39:55 --> User Agent Class Initialized
INFO - 2018-06-30 14:39:55 --> Controller Class Initialized
INFO - 2018-06-30 14:39:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 14:39:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 14:39:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 14:39:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 14:39:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 14:39:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 14:39:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-06-30 14:39:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 14:39:55 --> Final output sent to browser
DEBUG - 2018-06-30 14:39:55 --> Total execution time: 0.0308
INFO - 2018-06-30 16:09:55 --> Config Class Initialized
INFO - 2018-06-30 16:09:55 --> Hooks Class Initialized
DEBUG - 2018-06-30 16:09:55 --> UTF-8 Support Enabled
INFO - 2018-06-30 16:09:55 --> Utf8 Class Initialized
INFO - 2018-06-30 16:09:55 --> URI Class Initialized
INFO - 2018-06-30 16:09:55 --> Router Class Initialized
INFO - 2018-06-30 16:09:55 --> Output Class Initialized
INFO - 2018-06-30 16:09:55 --> Security Class Initialized
DEBUG - 2018-06-30 16:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 16:09:55 --> CSRF cookie sent
INFO - 2018-06-30 16:09:55 --> Input Class Initialized
INFO - 2018-06-30 16:09:55 --> Language Class Initialized
INFO - 2018-06-30 16:09:55 --> Loader Class Initialized
INFO - 2018-06-30 16:09:55 --> Helper loaded: url_helper
INFO - 2018-06-30 16:09:55 --> Helper loaded: form_helper
INFO - 2018-06-30 16:09:55 --> Helper loaded: language_helper
DEBUG - 2018-06-30 16:09:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 16:09:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 16:09:55 --> User Agent Class Initialized
INFO - 2018-06-30 16:09:55 --> Controller Class Initialized
INFO - 2018-06-30 16:09:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 16:09:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 16:09:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 16:09:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 16:09:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 16:09:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 16:09:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-06-30 16:09:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 16:09:55 --> Final output sent to browser
DEBUG - 2018-06-30 16:09:55 --> Total execution time: 0.0205
INFO - 2018-06-30 16:49:57 --> Config Class Initialized
INFO - 2018-06-30 16:49:57 --> Hooks Class Initialized
DEBUG - 2018-06-30 16:49:57 --> UTF-8 Support Enabled
INFO - 2018-06-30 16:49:57 --> Utf8 Class Initialized
INFO - 2018-06-30 16:49:57 --> URI Class Initialized
INFO - 2018-06-30 16:49:57 --> Router Class Initialized
INFO - 2018-06-30 16:49:57 --> Output Class Initialized
INFO - 2018-06-30 16:49:57 --> Security Class Initialized
DEBUG - 2018-06-30 16:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 16:49:57 --> CSRF cookie sent
INFO - 2018-06-30 16:49:57 --> Input Class Initialized
INFO - 2018-06-30 16:49:57 --> Language Class Initialized
ERROR - 2018-06-30 16:49:57 --> 404 Page Not Found: Well-known/assetlinks.json
INFO - 2018-06-30 16:55:41 --> Config Class Initialized
INFO - 2018-06-30 16:55:41 --> Hooks Class Initialized
DEBUG - 2018-06-30 16:55:41 --> UTF-8 Support Enabled
INFO - 2018-06-30 16:55:41 --> Utf8 Class Initialized
INFO - 2018-06-30 16:55:41 --> URI Class Initialized
INFO - 2018-06-30 16:55:41 --> Router Class Initialized
INFO - 2018-06-30 16:55:41 --> Output Class Initialized
INFO - 2018-06-30 16:55:41 --> Security Class Initialized
DEBUG - 2018-06-30 16:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 16:55:41 --> CSRF cookie sent
INFO - 2018-06-30 16:55:41 --> Input Class Initialized
INFO - 2018-06-30 16:55:41 --> Language Class Initialized
ERROR - 2018-06-30 16:55:41 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-06-30 16:55:44 --> Config Class Initialized
INFO - 2018-06-30 16:55:44 --> Hooks Class Initialized
DEBUG - 2018-06-30 16:55:44 --> UTF-8 Support Enabled
INFO - 2018-06-30 16:55:44 --> Utf8 Class Initialized
INFO - 2018-06-30 16:55:44 --> URI Class Initialized
INFO - 2018-06-30 16:55:44 --> Router Class Initialized
INFO - 2018-06-30 16:55:44 --> Output Class Initialized
INFO - 2018-06-30 16:55:44 --> Security Class Initialized
DEBUG - 2018-06-30 16:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 16:55:44 --> CSRF cookie sent
INFO - 2018-06-30 16:55:44 --> Input Class Initialized
INFO - 2018-06-30 16:55:44 --> Language Class Initialized
INFO - 2018-06-30 16:55:44 --> Loader Class Initialized
INFO - 2018-06-30 16:55:44 --> Helper loaded: url_helper
INFO - 2018-06-30 16:55:44 --> Helper loaded: form_helper
INFO - 2018-06-30 16:55:44 --> Helper loaded: language_helper
DEBUG - 2018-06-30 16:55:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 16:55:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 16:55:44 --> User Agent Class Initialized
INFO - 2018-06-30 16:55:44 --> Controller Class Initialized
INFO - 2018-06-30 16:55:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 16:55:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 16:55:44 --> Pixel_Model class loaded
INFO - 2018-06-30 16:55:44 --> Database Driver Class Initialized
INFO - 2018-06-30 16:55:44 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 16:55:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 16:55:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 16:55:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 16:55:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 16:55:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/buy_gift.php
INFO - 2018-06-30 16:55:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 16:55:44 --> Final output sent to browser
DEBUG - 2018-06-30 16:55:44 --> Total execution time: 0.0323
INFO - 2018-06-30 16:59:36 --> Config Class Initialized
INFO - 2018-06-30 16:59:36 --> Hooks Class Initialized
DEBUG - 2018-06-30 16:59:36 --> UTF-8 Support Enabled
INFO - 2018-06-30 16:59:36 --> Utf8 Class Initialized
INFO - 2018-06-30 16:59:36 --> URI Class Initialized
INFO - 2018-06-30 16:59:36 --> Router Class Initialized
INFO - 2018-06-30 16:59:36 --> Output Class Initialized
INFO - 2018-06-30 16:59:36 --> Security Class Initialized
DEBUG - 2018-06-30 16:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 16:59:36 --> CSRF cookie sent
INFO - 2018-06-30 16:59:36 --> Input Class Initialized
INFO - 2018-06-30 16:59:36 --> Language Class Initialized
ERROR - 2018-06-30 16:59:36 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-06-30 17:28:08 --> Config Class Initialized
INFO - 2018-06-30 17:28:08 --> Hooks Class Initialized
DEBUG - 2018-06-30 17:28:08 --> UTF-8 Support Enabled
INFO - 2018-06-30 17:28:08 --> Utf8 Class Initialized
INFO - 2018-06-30 17:28:08 --> URI Class Initialized
INFO - 2018-06-30 17:28:08 --> Router Class Initialized
INFO - 2018-06-30 17:28:08 --> Output Class Initialized
INFO - 2018-06-30 17:28:08 --> Security Class Initialized
DEBUG - 2018-06-30 17:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 17:28:08 --> CSRF cookie sent
INFO - 2018-06-30 17:28:08 --> Input Class Initialized
INFO - 2018-06-30 17:28:08 --> Language Class Initialized
ERROR - 2018-06-30 17:28:08 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-06-30 17:31:22 --> Config Class Initialized
INFO - 2018-06-30 17:31:22 --> Hooks Class Initialized
DEBUG - 2018-06-30 17:31:22 --> UTF-8 Support Enabled
INFO - 2018-06-30 17:31:22 --> Utf8 Class Initialized
INFO - 2018-06-30 17:31:22 --> URI Class Initialized
DEBUG - 2018-06-30 17:31:22 --> No URI present. Default controller set.
INFO - 2018-06-30 17:31:22 --> Router Class Initialized
INFO - 2018-06-30 17:31:22 --> Output Class Initialized
INFO - 2018-06-30 17:31:22 --> Security Class Initialized
DEBUG - 2018-06-30 17:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 17:31:22 --> CSRF cookie sent
INFO - 2018-06-30 17:31:22 --> Input Class Initialized
INFO - 2018-06-30 17:31:22 --> Language Class Initialized
INFO - 2018-06-30 17:31:22 --> Loader Class Initialized
INFO - 2018-06-30 17:31:22 --> Helper loaded: url_helper
INFO - 2018-06-30 17:31:22 --> Helper loaded: form_helper
INFO - 2018-06-30 17:31:22 --> Helper loaded: language_helper
DEBUG - 2018-06-30 17:31:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 17:31:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 17:31:22 --> User Agent Class Initialized
INFO - 2018-06-30 17:31:22 --> Controller Class Initialized
INFO - 2018-06-30 17:31:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 17:31:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 17:31:22 --> Pixel_Model class loaded
INFO - 2018-06-30 17:31:22 --> Database Driver Class Initialized
INFO - 2018-06-30 17:31:22 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 17:31:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 17:31:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 17:31:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-30 17:31:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 17:31:22 --> Final output sent to browser
DEBUG - 2018-06-30 17:31:22 --> Total execution time: 0.0349
INFO - 2018-06-30 17:48:22 --> Config Class Initialized
INFO - 2018-06-30 17:48:22 --> Hooks Class Initialized
DEBUG - 2018-06-30 17:48:22 --> UTF-8 Support Enabled
INFO - 2018-06-30 17:48:22 --> Utf8 Class Initialized
INFO - 2018-06-30 17:48:22 --> URI Class Initialized
DEBUG - 2018-06-30 17:48:22 --> No URI present. Default controller set.
INFO - 2018-06-30 17:48:22 --> Router Class Initialized
INFO - 2018-06-30 17:48:22 --> Output Class Initialized
INFO - 2018-06-30 17:48:22 --> Security Class Initialized
DEBUG - 2018-06-30 17:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 17:48:22 --> CSRF cookie sent
INFO - 2018-06-30 17:48:22 --> Input Class Initialized
INFO - 2018-06-30 17:48:22 --> Language Class Initialized
INFO - 2018-06-30 17:48:22 --> Loader Class Initialized
INFO - 2018-06-30 17:48:22 --> Helper loaded: url_helper
INFO - 2018-06-30 17:48:22 --> Helper loaded: form_helper
INFO - 2018-06-30 17:48:22 --> Helper loaded: language_helper
DEBUG - 2018-06-30 17:48:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 17:48:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 17:48:22 --> User Agent Class Initialized
INFO - 2018-06-30 17:48:22 --> Controller Class Initialized
INFO - 2018-06-30 17:48:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 17:48:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 17:48:22 --> Pixel_Model class loaded
INFO - 2018-06-30 17:48:22 --> Database Driver Class Initialized
INFO - 2018-06-30 17:48:22 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 17:48:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 17:48:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 17:48:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-30 17:48:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 17:48:23 --> Final output sent to browser
DEBUG - 2018-06-30 17:48:23 --> Total execution time: 0.0337
INFO - 2018-06-30 17:48:23 --> Config Class Initialized
INFO - 2018-06-30 17:48:23 --> Hooks Class Initialized
DEBUG - 2018-06-30 17:48:23 --> UTF-8 Support Enabled
INFO - 2018-06-30 17:48:23 --> Utf8 Class Initialized
INFO - 2018-06-30 17:48:23 --> URI Class Initialized
DEBUG - 2018-06-30 17:48:23 --> No URI present. Default controller set.
INFO - 2018-06-30 17:48:23 --> Router Class Initialized
INFO - 2018-06-30 17:48:23 --> Output Class Initialized
INFO - 2018-06-30 17:48:23 --> Security Class Initialized
DEBUG - 2018-06-30 17:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 17:48:23 --> CSRF cookie sent
INFO - 2018-06-30 17:48:23 --> Input Class Initialized
INFO - 2018-06-30 17:48:23 --> Language Class Initialized
INFO - 2018-06-30 17:48:23 --> Loader Class Initialized
INFO - 2018-06-30 17:48:23 --> Helper loaded: url_helper
INFO - 2018-06-30 17:48:23 --> Helper loaded: form_helper
INFO - 2018-06-30 17:48:23 --> Helper loaded: language_helper
DEBUG - 2018-06-30 17:48:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 17:48:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 17:48:23 --> User Agent Class Initialized
INFO - 2018-06-30 17:48:23 --> Controller Class Initialized
INFO - 2018-06-30 17:48:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 17:48:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 17:48:23 --> Pixel_Model class loaded
INFO - 2018-06-30 17:48:23 --> Database Driver Class Initialized
INFO - 2018-06-30 17:48:23 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 17:48:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 17:48:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 17:48:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-30 17:48:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 17:48:23 --> Final output sent to browser
DEBUG - 2018-06-30 17:48:23 --> Total execution time: 0.0298
INFO - 2018-06-30 17:48:24 --> Config Class Initialized
INFO - 2018-06-30 17:48:24 --> Hooks Class Initialized
DEBUG - 2018-06-30 17:48:24 --> UTF-8 Support Enabled
INFO - 2018-06-30 17:48:24 --> Utf8 Class Initialized
INFO - 2018-06-30 17:48:24 --> URI Class Initialized
DEBUG - 2018-06-30 17:48:24 --> No URI present. Default controller set.
INFO - 2018-06-30 17:48:24 --> Router Class Initialized
INFO - 2018-06-30 17:48:24 --> Output Class Initialized
INFO - 2018-06-30 17:48:24 --> Security Class Initialized
DEBUG - 2018-06-30 17:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 17:48:24 --> CSRF cookie sent
INFO - 2018-06-30 17:48:24 --> Input Class Initialized
INFO - 2018-06-30 17:48:24 --> Language Class Initialized
INFO - 2018-06-30 17:48:24 --> Loader Class Initialized
INFO - 2018-06-30 17:48:24 --> Helper loaded: url_helper
INFO - 2018-06-30 17:48:24 --> Helper loaded: form_helper
INFO - 2018-06-30 17:48:24 --> Helper loaded: language_helper
DEBUG - 2018-06-30 17:48:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 17:48:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 17:48:24 --> User Agent Class Initialized
INFO - 2018-06-30 17:48:24 --> Controller Class Initialized
INFO - 2018-06-30 17:48:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 17:48:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 17:48:24 --> Pixel_Model class loaded
INFO - 2018-06-30 17:48:24 --> Database Driver Class Initialized
INFO - 2018-06-30 17:48:24 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 17:48:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 17:48:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 17:48:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-30 17:48:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 17:48:24 --> Final output sent to browser
DEBUG - 2018-06-30 17:48:24 --> Total execution time: 0.0402
INFO - 2018-06-30 17:48:24 --> Config Class Initialized
INFO - 2018-06-30 17:48:24 --> Hooks Class Initialized
DEBUG - 2018-06-30 17:48:24 --> UTF-8 Support Enabled
INFO - 2018-06-30 17:48:24 --> Utf8 Class Initialized
INFO - 2018-06-30 17:48:24 --> URI Class Initialized
INFO - 2018-06-30 17:48:24 --> Router Class Initialized
INFO - 2018-06-30 17:48:24 --> Output Class Initialized
INFO - 2018-06-30 17:48:24 --> Security Class Initialized
DEBUG - 2018-06-30 17:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 17:48:24 --> CSRF cookie sent
INFO - 2018-06-30 17:48:24 --> Input Class Initialized
INFO - 2018-06-30 17:48:24 --> Language Class Initialized
ERROR - 2018-06-30 17:48:24 --> 404 Page Not Found: 405shtml/index
INFO - 2018-06-30 17:48:31 --> Config Class Initialized
INFO - 2018-06-30 17:48:31 --> Hooks Class Initialized
DEBUG - 2018-06-30 17:48:31 --> UTF-8 Support Enabled
INFO - 2018-06-30 17:48:31 --> Utf8 Class Initialized
INFO - 2018-06-30 17:48:31 --> URI Class Initialized
DEBUG - 2018-06-30 17:48:31 --> No URI present. Default controller set.
INFO - 2018-06-30 17:48:31 --> Router Class Initialized
INFO - 2018-06-30 17:48:31 --> Output Class Initialized
INFO - 2018-06-30 17:48:31 --> Security Class Initialized
DEBUG - 2018-06-30 17:48:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 17:48:31 --> CSRF cookie sent
INFO - 2018-06-30 17:48:31 --> Input Class Initialized
INFO - 2018-06-30 17:48:31 --> Language Class Initialized
INFO - 2018-06-30 17:48:31 --> Loader Class Initialized
INFO - 2018-06-30 17:48:31 --> Helper loaded: url_helper
INFO - 2018-06-30 17:48:31 --> Helper loaded: form_helper
INFO - 2018-06-30 17:48:31 --> Helper loaded: language_helper
DEBUG - 2018-06-30 17:48:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 17:48:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 17:48:31 --> User Agent Class Initialized
INFO - 2018-06-30 17:48:31 --> Controller Class Initialized
INFO - 2018-06-30 17:48:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 17:48:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 17:48:31 --> Pixel_Model class loaded
INFO - 2018-06-30 17:48:31 --> Database Driver Class Initialized
INFO - 2018-06-30 17:48:31 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 17:48:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 17:48:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 17:48:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-30 17:48:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 17:48:31 --> Final output sent to browser
DEBUG - 2018-06-30 17:48:31 --> Total execution time: 0.0344
INFO - 2018-06-30 17:48:32 --> Config Class Initialized
INFO - 2018-06-30 17:48:32 --> Hooks Class Initialized
DEBUG - 2018-06-30 17:48:32 --> UTF-8 Support Enabled
INFO - 2018-06-30 17:48:32 --> Utf8 Class Initialized
INFO - 2018-06-30 17:48:32 --> URI Class Initialized
INFO - 2018-06-30 17:48:32 --> Router Class Initialized
INFO - 2018-06-30 17:48:32 --> Output Class Initialized
INFO - 2018-06-30 17:48:32 --> Security Class Initialized
DEBUG - 2018-06-30 17:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 17:48:32 --> CSRF cookie sent
INFO - 2018-06-30 17:48:32 --> Input Class Initialized
INFO - 2018-06-30 17:48:32 --> Language Class Initialized
ERROR - 2018-06-30 17:48:32 --> 404 Page Not Found: 404testpage4525d2fdc/index
INFO - 2018-06-30 17:48:32 --> Config Class Initialized
INFO - 2018-06-30 17:48:32 --> Hooks Class Initialized
DEBUG - 2018-06-30 17:48:32 --> UTF-8 Support Enabled
INFO - 2018-06-30 17:48:32 --> Utf8 Class Initialized
INFO - 2018-06-30 17:48:32 --> URI Class Initialized
INFO - 2018-06-30 17:48:32 --> Router Class Initialized
INFO - 2018-06-30 17:48:32 --> Output Class Initialized
INFO - 2018-06-30 17:48:32 --> Security Class Initialized
DEBUG - 2018-06-30 17:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 17:48:32 --> CSRF cookie sent
INFO - 2018-06-30 17:48:32 --> Input Class Initialized
INFO - 2018-06-30 17:48:32 --> Language Class Initialized
ERROR - 2018-06-30 17:48:32 --> 404 Page Not Found: 404javascriptjs/index
INFO - 2018-06-30 17:48:32 --> Config Class Initialized
INFO - 2018-06-30 17:48:32 --> Hooks Class Initialized
DEBUG - 2018-06-30 17:48:32 --> UTF-8 Support Enabled
INFO - 2018-06-30 17:48:32 --> Utf8 Class Initialized
INFO - 2018-06-30 17:48:32 --> URI Class Initialized
INFO - 2018-06-30 17:48:32 --> Router Class Initialized
INFO - 2018-06-30 17:48:32 --> Output Class Initialized
INFO - 2018-06-30 17:48:32 --> Security Class Initialized
DEBUG - 2018-06-30 17:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 17:48:32 --> CSRF cookie sent
INFO - 2018-06-30 17:48:32 --> Input Class Initialized
INFO - 2018-06-30 17:48:32 --> Language Class Initialized
INFO - 2018-06-30 17:48:32 --> Loader Class Initialized
INFO - 2018-06-30 17:48:32 --> Helper loaded: url_helper
INFO - 2018-06-30 17:48:32 --> Helper loaded: form_helper
INFO - 2018-06-30 17:48:32 --> Helper loaded: language_helper
DEBUG - 2018-06-30 17:48:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 17:48:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 17:48:32 --> User Agent Class Initialized
INFO - 2018-06-30 17:48:32 --> Controller Class Initialized
INFO - 2018-06-30 17:48:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 17:48:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 17:48:32 --> Pixel_Model class loaded
INFO - 2018-06-30 17:48:32 --> Database Driver Class Initialized
INFO - 2018-06-30 17:48:32 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 17:48:32 --> Config Class Initialized
INFO - 2018-06-30 17:48:32 --> Hooks Class Initialized
DEBUG - 2018-06-30 17:48:32 --> UTF-8 Support Enabled
INFO - 2018-06-30 17:48:32 --> Utf8 Class Initialized
INFO - 2018-06-30 17:48:32 --> URI Class Initialized
INFO - 2018-06-30 17:48:32 --> Router Class Initialized
INFO - 2018-06-30 17:48:32 --> Output Class Initialized
INFO - 2018-06-30 17:48:32 --> Security Class Initialized
DEBUG - 2018-06-30 17:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 17:48:32 --> CSRF cookie sent
INFO - 2018-06-30 17:48:32 --> Input Class Initialized
INFO - 2018-06-30 17:48:32 --> Language Class Initialized
INFO - 2018-06-30 17:48:32 --> Loader Class Initialized
INFO - 2018-06-30 17:48:32 --> Helper loaded: url_helper
INFO - 2018-06-30 17:48:32 --> Helper loaded: form_helper
INFO - 2018-06-30 17:48:32 --> Helper loaded: language_helper
DEBUG - 2018-06-30 17:48:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 17:48:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 17:48:32 --> User Agent Class Initialized
INFO - 2018-06-30 17:48:32 --> Controller Class Initialized
INFO - 2018-06-30 17:48:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 17:48:32 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-30 17:48:32 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-30 17:48:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 17:48:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 17:48:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 17:48:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-30 17:48:32 --> Could not find the language line "req_email"
INFO - 2018-06-30 17:48:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-06-30 17:48:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 17:48:32 --> Final output sent to browser
DEBUG - 2018-06-30 17:48:32 --> Total execution time: 0.0216
INFO - 2018-06-30 17:48:33 --> Config Class Initialized
INFO - 2018-06-30 17:48:33 --> Hooks Class Initialized
DEBUG - 2018-06-30 17:48:33 --> UTF-8 Support Enabled
INFO - 2018-06-30 17:48:33 --> Utf8 Class Initialized
INFO - 2018-06-30 17:48:33 --> URI Class Initialized
INFO - 2018-06-30 17:48:33 --> Router Class Initialized
INFO - 2018-06-30 17:48:33 --> Output Class Initialized
INFO - 2018-06-30 17:48:33 --> Security Class Initialized
DEBUG - 2018-06-30 17:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 17:48:33 --> CSRF cookie sent
INFO - 2018-06-30 17:48:33 --> Input Class Initialized
INFO - 2018-06-30 17:48:33 --> Language Class Initialized
INFO - 2018-06-30 17:48:33 --> Loader Class Initialized
INFO - 2018-06-30 17:48:33 --> Helper loaded: url_helper
INFO - 2018-06-30 17:48:33 --> Helper loaded: form_helper
INFO - 2018-06-30 17:48:33 --> Helper loaded: language_helper
DEBUG - 2018-06-30 17:48:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 17:48:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 17:48:33 --> User Agent Class Initialized
INFO - 2018-06-30 17:48:33 --> Controller Class Initialized
INFO - 2018-06-30 17:48:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 17:48:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 17:48:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 17:48:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 17:48:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 17:48:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 17:48:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-06-30 17:48:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 17:48:33 --> Final output sent to browser
DEBUG - 2018-06-30 17:48:33 --> Total execution time: 0.0257
INFO - 2018-06-30 17:48:33 --> Config Class Initialized
INFO - 2018-06-30 17:48:33 --> Hooks Class Initialized
DEBUG - 2018-06-30 17:48:33 --> UTF-8 Support Enabled
INFO - 2018-06-30 17:48:33 --> Utf8 Class Initialized
INFO - 2018-06-30 17:48:33 --> URI Class Initialized
INFO - 2018-06-30 17:48:33 --> Router Class Initialized
INFO - 2018-06-30 17:48:33 --> Output Class Initialized
INFO - 2018-06-30 17:48:33 --> Security Class Initialized
DEBUG - 2018-06-30 17:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 17:48:33 --> CSRF cookie sent
INFO - 2018-06-30 17:48:33 --> Input Class Initialized
INFO - 2018-06-30 17:48:33 --> Language Class Initialized
INFO - 2018-06-30 17:48:33 --> Loader Class Initialized
INFO - 2018-06-30 17:48:33 --> Helper loaded: url_helper
INFO - 2018-06-30 17:48:33 --> Helper loaded: form_helper
INFO - 2018-06-30 17:48:33 --> Helper loaded: language_helper
DEBUG - 2018-06-30 17:48:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 17:48:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 17:48:33 --> User Agent Class Initialized
INFO - 2018-06-30 17:48:33 --> Controller Class Initialized
INFO - 2018-06-30 17:48:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 17:48:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 17:48:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 17:48:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 17:48:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 17:48:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 17:48:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-06-30 17:48:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 17:48:33 --> Final output sent to browser
DEBUG - 2018-06-30 17:48:33 --> Total execution time: 0.0204
INFO - 2018-06-30 17:48:33 --> Config Class Initialized
INFO - 2018-06-30 17:48:33 --> Hooks Class Initialized
DEBUG - 2018-06-30 17:48:33 --> UTF-8 Support Enabled
INFO - 2018-06-30 17:48:33 --> Utf8 Class Initialized
INFO - 2018-06-30 17:48:33 --> URI Class Initialized
INFO - 2018-06-30 17:48:33 --> Router Class Initialized
INFO - 2018-06-30 17:48:33 --> Output Class Initialized
INFO - 2018-06-30 17:48:33 --> Security Class Initialized
DEBUG - 2018-06-30 17:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 17:48:33 --> CSRF cookie sent
INFO - 2018-06-30 17:48:33 --> Input Class Initialized
INFO - 2018-06-30 17:48:33 --> Language Class Initialized
INFO - 2018-06-30 17:48:33 --> Loader Class Initialized
INFO - 2018-06-30 17:48:33 --> Helper loaded: url_helper
INFO - 2018-06-30 17:48:33 --> Helper loaded: form_helper
INFO - 2018-06-30 17:48:33 --> Helper loaded: language_helper
DEBUG - 2018-06-30 17:48:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 17:48:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 17:48:33 --> User Agent Class Initialized
INFO - 2018-06-30 17:48:33 --> Controller Class Initialized
INFO - 2018-06-30 17:48:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 17:48:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 17:48:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 17:48:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 17:48:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 17:48:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 17:48:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-06-30 17:48:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 17:48:33 --> Final output sent to browser
DEBUG - 2018-06-30 17:48:33 --> Total execution time: 0.0225
INFO - 2018-06-30 17:48:34 --> Config Class Initialized
INFO - 2018-06-30 17:48:34 --> Hooks Class Initialized
DEBUG - 2018-06-30 17:48:34 --> UTF-8 Support Enabled
INFO - 2018-06-30 17:48:34 --> Utf8 Class Initialized
INFO - 2018-06-30 17:48:34 --> URI Class Initialized
INFO - 2018-06-30 17:48:34 --> Router Class Initialized
INFO - 2018-06-30 17:48:34 --> Output Class Initialized
INFO - 2018-06-30 17:48:34 --> Security Class Initialized
DEBUG - 2018-06-30 17:48:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 17:48:34 --> CSRF cookie sent
INFO - 2018-06-30 17:48:34 --> Input Class Initialized
INFO - 2018-06-30 17:48:34 --> Language Class Initialized
INFO - 2018-06-30 17:48:34 --> Loader Class Initialized
INFO - 2018-06-30 17:48:34 --> Helper loaded: url_helper
INFO - 2018-06-30 17:48:34 --> Helper loaded: form_helper
INFO - 2018-06-30 17:48:34 --> Helper loaded: language_helper
DEBUG - 2018-06-30 17:48:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 17:48:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 17:48:34 --> User Agent Class Initialized
INFO - 2018-06-30 17:48:34 --> Controller Class Initialized
INFO - 2018-06-30 17:48:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 17:48:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 17:48:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 17:48:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 17:48:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 17:48:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 17:48:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-06-30 17:48:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 17:48:34 --> Final output sent to browser
DEBUG - 2018-06-30 17:48:34 --> Total execution time: 0.0226
INFO - 2018-06-30 17:48:34 --> Config Class Initialized
INFO - 2018-06-30 17:48:34 --> Hooks Class Initialized
DEBUG - 2018-06-30 17:48:34 --> UTF-8 Support Enabled
INFO - 2018-06-30 17:48:34 --> Utf8 Class Initialized
INFO - 2018-06-30 17:48:34 --> URI Class Initialized
INFO - 2018-06-30 17:48:34 --> Router Class Initialized
INFO - 2018-06-30 17:48:34 --> Output Class Initialized
INFO - 2018-06-30 17:48:34 --> Security Class Initialized
DEBUG - 2018-06-30 17:48:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 17:48:34 --> CSRF cookie sent
INFO - 2018-06-30 17:48:34 --> Input Class Initialized
INFO - 2018-06-30 17:48:34 --> Language Class Initialized
INFO - 2018-06-30 17:48:34 --> Loader Class Initialized
INFO - 2018-06-30 17:48:34 --> Helper loaded: url_helper
INFO - 2018-06-30 17:48:34 --> Helper loaded: form_helper
INFO - 2018-06-30 17:48:34 --> Helper loaded: language_helper
DEBUG - 2018-06-30 17:48:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 17:48:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 17:48:34 --> User Agent Class Initialized
INFO - 2018-06-30 17:48:34 --> Controller Class Initialized
INFO - 2018-06-30 17:48:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 17:48:34 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-06-30 17:48:34 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-06-30 17:48:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 17:48:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 17:48:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 17:48:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-06-30 17:48:34 --> Could not find the language line "req_email"
INFO - 2018-06-30 17:48:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-06-30 17:48:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 17:48:34 --> Final output sent to browser
DEBUG - 2018-06-30 17:48:34 --> Total execution time: 0.0205
INFO - 2018-06-30 17:48:34 --> Config Class Initialized
INFO - 2018-06-30 17:48:34 --> Hooks Class Initialized
DEBUG - 2018-06-30 17:48:34 --> UTF-8 Support Enabled
INFO - 2018-06-30 17:48:34 --> Utf8 Class Initialized
INFO - 2018-06-30 17:48:34 --> URI Class Initialized
INFO - 2018-06-30 17:48:34 --> Router Class Initialized
INFO - 2018-06-30 17:48:34 --> Output Class Initialized
INFO - 2018-06-30 17:48:34 --> Security Class Initialized
DEBUG - 2018-06-30 17:48:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 17:48:34 --> CSRF cookie sent
INFO - 2018-06-30 17:48:34 --> Input Class Initialized
INFO - 2018-06-30 17:48:34 --> Language Class Initialized
INFO - 2018-06-30 17:48:34 --> Loader Class Initialized
INFO - 2018-06-30 17:48:34 --> Helper loaded: url_helper
INFO - 2018-06-30 17:48:34 --> Helper loaded: form_helper
INFO - 2018-06-30 17:48:34 --> Helper loaded: language_helper
DEBUG - 2018-06-30 17:48:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 17:48:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 17:48:34 --> User Agent Class Initialized
INFO - 2018-06-30 17:48:34 --> Controller Class Initialized
INFO - 2018-06-30 17:48:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 17:48:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 17:48:34 --> Pixel_Model class loaded
INFO - 2018-06-30 17:48:34 --> Database Driver Class Initialized
INFO - 2018-06-30 17:48:34 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 17:48:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 17:48:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 17:48:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 17:48:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 17:48:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/buy_gift.php
INFO - 2018-06-30 17:48:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 17:48:34 --> Final output sent to browser
DEBUG - 2018-06-30 17:48:34 --> Total execution time: 0.0313
INFO - 2018-06-30 18:02:09 --> Config Class Initialized
INFO - 2018-06-30 18:02:09 --> Hooks Class Initialized
DEBUG - 2018-06-30 18:02:09 --> UTF-8 Support Enabled
INFO - 2018-06-30 18:02:09 --> Utf8 Class Initialized
INFO - 2018-06-30 18:02:09 --> URI Class Initialized
INFO - 2018-06-30 18:02:09 --> Router Class Initialized
INFO - 2018-06-30 18:02:09 --> Output Class Initialized
INFO - 2018-06-30 18:02:09 --> Security Class Initialized
DEBUG - 2018-06-30 18:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 18:02:09 --> CSRF cookie sent
INFO - 2018-06-30 18:02:09 --> Input Class Initialized
INFO - 2018-06-30 18:02:09 --> Language Class Initialized
INFO - 2018-06-30 18:02:09 --> Loader Class Initialized
INFO - 2018-06-30 18:02:09 --> Helper loaded: url_helper
INFO - 2018-06-30 18:02:09 --> Helper loaded: form_helper
INFO - 2018-06-30 18:02:09 --> Helper loaded: language_helper
DEBUG - 2018-06-30 18:02:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 18:02:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 18:02:09 --> User Agent Class Initialized
INFO - 2018-06-30 18:02:09 --> Controller Class Initialized
INFO - 2018-06-30 18:02:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 18:02:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 18:02:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 18:02:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 18:02:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 18:02:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 18:02:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-06-30 18:02:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 18:02:09 --> Final output sent to browser
DEBUG - 2018-06-30 18:02:09 --> Total execution time: 0.0232
INFO - 2018-06-30 19:11:52 --> Config Class Initialized
INFO - 2018-06-30 19:11:52 --> Hooks Class Initialized
DEBUG - 2018-06-30 19:11:52 --> UTF-8 Support Enabled
INFO - 2018-06-30 19:11:52 --> Utf8 Class Initialized
INFO - 2018-06-30 19:11:52 --> URI Class Initialized
DEBUG - 2018-06-30 19:11:52 --> No URI present. Default controller set.
INFO - 2018-06-30 19:11:52 --> Router Class Initialized
INFO - 2018-06-30 19:11:52 --> Output Class Initialized
INFO - 2018-06-30 19:11:52 --> Security Class Initialized
DEBUG - 2018-06-30 19:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 19:11:52 --> CSRF cookie sent
INFO - 2018-06-30 19:11:52 --> Input Class Initialized
INFO - 2018-06-30 19:11:52 --> Language Class Initialized
INFO - 2018-06-30 19:11:52 --> Loader Class Initialized
INFO - 2018-06-30 19:11:52 --> Helper loaded: url_helper
INFO - 2018-06-30 19:11:52 --> Helper loaded: form_helper
INFO - 2018-06-30 19:11:52 --> Helper loaded: language_helper
DEBUG - 2018-06-30 19:11:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 19:11:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 19:11:52 --> User Agent Class Initialized
INFO - 2018-06-30 19:11:52 --> Controller Class Initialized
INFO - 2018-06-30 19:11:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 19:11:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 19:11:52 --> Pixel_Model class loaded
INFO - 2018-06-30 19:11:52 --> Database Driver Class Initialized
INFO - 2018-06-30 19:11:52 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 19:11:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 19:11:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 19:11:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-30 19:11:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 19:11:52 --> Final output sent to browser
DEBUG - 2018-06-30 19:11:52 --> Total execution time: 0.0333
INFO - 2018-06-30 20:39:56 --> Config Class Initialized
INFO - 2018-06-30 20:39:56 --> Hooks Class Initialized
DEBUG - 2018-06-30 20:39:56 --> UTF-8 Support Enabled
INFO - 2018-06-30 20:39:56 --> Utf8 Class Initialized
INFO - 2018-06-30 20:39:56 --> URI Class Initialized
DEBUG - 2018-06-30 20:39:56 --> No URI present. Default controller set.
INFO - 2018-06-30 20:39:56 --> Router Class Initialized
INFO - 2018-06-30 20:39:56 --> Output Class Initialized
INFO - 2018-06-30 20:39:56 --> Security Class Initialized
DEBUG - 2018-06-30 20:39:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 20:39:56 --> CSRF cookie sent
INFO - 2018-06-30 20:39:56 --> Input Class Initialized
INFO - 2018-06-30 20:39:56 --> Language Class Initialized
INFO - 2018-06-30 20:39:56 --> Loader Class Initialized
INFO - 2018-06-30 20:39:56 --> Helper loaded: url_helper
INFO - 2018-06-30 20:39:56 --> Helper loaded: form_helper
INFO - 2018-06-30 20:39:56 --> Helper loaded: language_helper
DEBUG - 2018-06-30 20:39:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 20:39:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 20:39:56 --> User Agent Class Initialized
INFO - 2018-06-30 20:39:56 --> Controller Class Initialized
INFO - 2018-06-30 20:39:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 20:39:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 20:39:56 --> Pixel_Model class loaded
INFO - 2018-06-30 20:39:56 --> Database Driver Class Initialized
INFO - 2018-06-30 20:39:56 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 20:39:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 20:39:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 20:39:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-30 20:39:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 20:39:56 --> Final output sent to browser
DEBUG - 2018-06-30 20:39:56 --> Total execution time: 0.0344
INFO - 2018-06-30 20:45:35 --> Config Class Initialized
INFO - 2018-06-30 20:45:35 --> Hooks Class Initialized
DEBUG - 2018-06-30 20:45:35 --> UTF-8 Support Enabled
INFO - 2018-06-30 20:45:35 --> Utf8 Class Initialized
INFO - 2018-06-30 20:45:35 --> URI Class Initialized
INFO - 2018-06-30 20:45:35 --> Router Class Initialized
INFO - 2018-06-30 20:45:35 --> Output Class Initialized
INFO - 2018-06-30 20:45:35 --> Security Class Initialized
DEBUG - 2018-06-30 20:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 20:45:35 --> CSRF cookie sent
INFO - 2018-06-30 20:45:35 --> Input Class Initialized
INFO - 2018-06-30 20:45:35 --> Language Class Initialized
ERROR - 2018-06-30 20:45:35 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-06-30 20:45:39 --> Config Class Initialized
INFO - 2018-06-30 20:45:39 --> Hooks Class Initialized
DEBUG - 2018-06-30 20:45:39 --> UTF-8 Support Enabled
INFO - 2018-06-30 20:45:39 --> Utf8 Class Initialized
INFO - 2018-06-30 20:45:39 --> URI Class Initialized
INFO - 2018-06-30 20:45:39 --> Router Class Initialized
INFO - 2018-06-30 20:45:39 --> Output Class Initialized
INFO - 2018-06-30 20:45:39 --> Security Class Initialized
DEBUG - 2018-06-30 20:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 20:45:39 --> CSRF cookie sent
INFO - 2018-06-30 20:45:39 --> Input Class Initialized
INFO - 2018-06-30 20:45:39 --> Language Class Initialized
INFO - 2018-06-30 20:45:39 --> Loader Class Initialized
INFO - 2018-06-30 20:45:39 --> Helper loaded: url_helper
INFO - 2018-06-30 20:45:39 --> Helper loaded: form_helper
INFO - 2018-06-30 20:45:39 --> Helper loaded: language_helper
DEBUG - 2018-06-30 20:45:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 20:45:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 20:45:39 --> User Agent Class Initialized
INFO - 2018-06-30 20:45:39 --> Controller Class Initialized
INFO - 2018-06-30 20:45:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 20:45:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 20:45:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 20:45:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 20:45:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-06-30 20:45:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-06-30 20:45:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-06-30 20:45:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 20:45:39 --> Final output sent to browser
DEBUG - 2018-06-30 20:45:39 --> Total execution time: 0.0205
INFO - 2018-06-30 23:39:55 --> Config Class Initialized
INFO - 2018-06-30 23:39:55 --> Hooks Class Initialized
DEBUG - 2018-06-30 23:39:55 --> UTF-8 Support Enabled
INFO - 2018-06-30 23:39:55 --> Utf8 Class Initialized
INFO - 2018-06-30 23:39:55 --> URI Class Initialized
DEBUG - 2018-06-30 23:39:55 --> No URI present. Default controller set.
INFO - 2018-06-30 23:39:55 --> Router Class Initialized
INFO - 2018-06-30 23:39:55 --> Output Class Initialized
INFO - 2018-06-30 23:39:55 --> Security Class Initialized
DEBUG - 2018-06-30 23:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 23:39:55 --> CSRF cookie sent
INFO - 2018-06-30 23:39:55 --> Input Class Initialized
INFO - 2018-06-30 23:39:55 --> Language Class Initialized
INFO - 2018-06-30 23:39:55 --> Loader Class Initialized
INFO - 2018-06-30 23:39:55 --> Helper loaded: url_helper
INFO - 2018-06-30 23:39:55 --> Helper loaded: form_helper
INFO - 2018-06-30 23:39:55 --> Helper loaded: language_helper
DEBUG - 2018-06-30 23:39:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 23:39:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 23:39:55 --> User Agent Class Initialized
INFO - 2018-06-30 23:39:55 --> Controller Class Initialized
INFO - 2018-06-30 23:39:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 23:39:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 23:39:55 --> Pixel_Model class loaded
INFO - 2018-06-30 23:39:55 --> Database Driver Class Initialized
INFO - 2018-06-30 23:39:55 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 23:39:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 23:39:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 23:39:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-30 23:39:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 23:39:55 --> Final output sent to browser
DEBUG - 2018-06-30 23:39:55 --> Total execution time: 0.0453
INFO - 2018-06-30 23:48:59 --> Config Class Initialized
INFO - 2018-06-30 23:48:59 --> Hooks Class Initialized
DEBUG - 2018-06-30 23:48:59 --> UTF-8 Support Enabled
INFO - 2018-06-30 23:48:59 --> Utf8 Class Initialized
INFO - 2018-06-30 23:48:59 --> URI Class Initialized
INFO - 2018-06-30 23:48:59 --> Router Class Initialized
INFO - 2018-06-30 23:48:59 --> Output Class Initialized
INFO - 2018-06-30 23:48:59 --> Security Class Initialized
DEBUG - 2018-06-30 23:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 23:48:59 --> CSRF cookie sent
INFO - 2018-06-30 23:48:59 --> Input Class Initialized
INFO - 2018-06-30 23:48:59 --> Language Class Initialized
ERROR - 2018-06-30 23:48:59 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-06-30 23:49:02 --> Config Class Initialized
INFO - 2018-06-30 23:49:02 --> Hooks Class Initialized
DEBUG - 2018-06-30 23:49:02 --> UTF-8 Support Enabled
INFO - 2018-06-30 23:49:02 --> Utf8 Class Initialized
INFO - 2018-06-30 23:49:02 --> URI Class Initialized
DEBUG - 2018-06-30 23:49:02 --> No URI present. Default controller set.
INFO - 2018-06-30 23:49:02 --> Router Class Initialized
INFO - 2018-06-30 23:49:02 --> Output Class Initialized
INFO - 2018-06-30 23:49:02 --> Security Class Initialized
DEBUG - 2018-06-30 23:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 23:49:03 --> CSRF cookie sent
INFO - 2018-06-30 23:49:03 --> Input Class Initialized
INFO - 2018-06-30 23:49:03 --> Language Class Initialized
INFO - 2018-06-30 23:49:03 --> Loader Class Initialized
INFO - 2018-06-30 23:49:03 --> Helper loaded: url_helper
INFO - 2018-06-30 23:49:03 --> Helper loaded: form_helper
INFO - 2018-06-30 23:49:03 --> Helper loaded: language_helper
DEBUG - 2018-06-30 23:49:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 23:49:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 23:49:03 --> User Agent Class Initialized
INFO - 2018-06-30 23:49:03 --> Controller Class Initialized
INFO - 2018-06-30 23:49:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 23:49:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 23:49:03 --> Pixel_Model class loaded
INFO - 2018-06-30 23:49:03 --> Database Driver Class Initialized
INFO - 2018-06-30 23:49:03 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 23:49:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 23:49:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 23:49:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-30 23:49:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 23:49:03 --> Final output sent to browser
DEBUG - 2018-06-30 23:49:03 --> Total execution time: 0.0358
INFO - 2018-06-30 23:50:39 --> Config Class Initialized
INFO - 2018-06-30 23:50:39 --> Hooks Class Initialized
DEBUG - 2018-06-30 23:50:39 --> UTF-8 Support Enabled
INFO - 2018-06-30 23:50:39 --> Utf8 Class Initialized
INFO - 2018-06-30 23:50:39 --> URI Class Initialized
DEBUG - 2018-06-30 23:50:39 --> No URI present. Default controller set.
INFO - 2018-06-30 23:50:39 --> Router Class Initialized
INFO - 2018-06-30 23:50:39 --> Output Class Initialized
INFO - 2018-06-30 23:50:39 --> Security Class Initialized
DEBUG - 2018-06-30 23:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-30 23:50:39 --> CSRF cookie sent
INFO - 2018-06-30 23:50:39 --> Input Class Initialized
INFO - 2018-06-30 23:50:39 --> Language Class Initialized
INFO - 2018-06-30 23:50:39 --> Loader Class Initialized
INFO - 2018-06-30 23:50:39 --> Helper loaded: url_helper
INFO - 2018-06-30 23:50:39 --> Helper loaded: form_helper
INFO - 2018-06-30 23:50:39 --> Helper loaded: language_helper
DEBUG - 2018-06-30 23:50:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-30 23:50:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-30 23:50:39 --> User Agent Class Initialized
INFO - 2018-06-30 23:50:39 --> Controller Class Initialized
INFO - 2018-06-30 23:50:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-06-30 23:50:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-06-30 23:50:39 --> Pixel_Model class loaded
INFO - 2018-06-30 23:50:39 --> Database Driver Class Initialized
INFO - 2018-06-30 23:50:39 --> Model "QuestionsModel" initialized
INFO - 2018-06-30 23:50:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-06-30 23:50:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-06-30 23:50:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-06-30 23:50:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-06-30 23:50:39 --> Final output sent to browser
DEBUG - 2018-06-30 23:50:39 --> Total execution time: 0.0463

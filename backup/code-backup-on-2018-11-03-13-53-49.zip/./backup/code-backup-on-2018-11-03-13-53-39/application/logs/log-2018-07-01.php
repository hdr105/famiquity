<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-07-01 01:47:39 --> Config Class Initialized
INFO - 2018-07-01 01:47:39 --> Hooks Class Initialized
DEBUG - 2018-07-01 01:47:39 --> UTF-8 Support Enabled
INFO - 2018-07-01 01:47:39 --> Utf8 Class Initialized
INFO - 2018-07-01 01:47:39 --> URI Class Initialized
DEBUG - 2018-07-01 01:47:39 --> No URI present. Default controller set.
INFO - 2018-07-01 01:47:39 --> Router Class Initialized
INFO - 2018-07-01 01:47:39 --> Output Class Initialized
INFO - 2018-07-01 01:47:39 --> Security Class Initialized
DEBUG - 2018-07-01 01:47:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-01 01:47:39 --> CSRF cookie sent
INFO - 2018-07-01 01:47:39 --> Input Class Initialized
INFO - 2018-07-01 01:47:39 --> Language Class Initialized
INFO - 2018-07-01 01:47:39 --> Loader Class Initialized
INFO - 2018-07-01 01:47:39 --> Helper loaded: url_helper
INFO - 2018-07-01 01:47:39 --> Helper loaded: form_helper
INFO - 2018-07-01 01:47:39 --> Helper loaded: language_helper
DEBUG - 2018-07-01 01:47:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-01 01:47:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-01 01:47:39 --> User Agent Class Initialized
INFO - 2018-07-01 01:47:39 --> Controller Class Initialized
INFO - 2018-07-01 01:47:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-01 01:47:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-01 01:47:39 --> Pixel_Model class loaded
INFO - 2018-07-01 01:47:39 --> Database Driver Class Initialized
INFO - 2018-07-01 01:47:39 --> Model "QuestionsModel" initialized
INFO - 2018-07-01 01:47:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-01 01:47:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-01 01:47:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-01 01:47:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-01 01:47:39 --> Final output sent to browser
DEBUG - 2018-07-01 01:47:39 --> Total execution time: 0.0316
INFO - 2018-07-01 02:20:57 --> Config Class Initialized
INFO - 2018-07-01 02:20:57 --> Hooks Class Initialized
DEBUG - 2018-07-01 02:20:57 --> UTF-8 Support Enabled
INFO - 2018-07-01 02:20:57 --> Utf8 Class Initialized
INFO - 2018-07-01 02:20:57 --> URI Class Initialized
DEBUG - 2018-07-01 02:20:57 --> No URI present. Default controller set.
INFO - 2018-07-01 02:20:57 --> Router Class Initialized
INFO - 2018-07-01 02:20:57 --> Output Class Initialized
INFO - 2018-07-01 02:20:57 --> Security Class Initialized
DEBUG - 2018-07-01 02:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-01 02:20:57 --> CSRF cookie sent
INFO - 2018-07-01 02:20:57 --> Input Class Initialized
INFO - 2018-07-01 02:20:57 --> Language Class Initialized
INFO - 2018-07-01 02:20:57 --> Loader Class Initialized
INFO - 2018-07-01 02:20:57 --> Helper loaded: url_helper
INFO - 2018-07-01 02:20:57 --> Helper loaded: form_helper
INFO - 2018-07-01 02:20:57 --> Helper loaded: language_helper
DEBUG - 2018-07-01 02:20:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-01 02:20:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-01 02:20:57 --> User Agent Class Initialized
INFO - 2018-07-01 02:20:57 --> Controller Class Initialized
INFO - 2018-07-01 02:20:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-01 02:20:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-01 02:20:57 --> Pixel_Model class loaded
INFO - 2018-07-01 02:20:57 --> Database Driver Class Initialized
INFO - 2018-07-01 02:20:57 --> Model "QuestionsModel" initialized
INFO - 2018-07-01 02:20:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-01 02:20:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-01 02:20:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-01 02:20:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-01 02:20:57 --> Final output sent to browser
DEBUG - 2018-07-01 02:20:57 --> Total execution time: 0.0321
INFO - 2018-07-01 02:34:49 --> Config Class Initialized
INFO - 2018-07-01 02:34:49 --> Hooks Class Initialized
DEBUG - 2018-07-01 02:34:49 --> UTF-8 Support Enabled
INFO - 2018-07-01 02:34:49 --> Utf8 Class Initialized
INFO - 2018-07-01 02:34:49 --> URI Class Initialized
INFO - 2018-07-01 02:34:49 --> Router Class Initialized
INFO - 2018-07-01 02:34:49 --> Output Class Initialized
INFO - 2018-07-01 02:34:49 --> Security Class Initialized
DEBUG - 2018-07-01 02:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-01 02:34:49 --> CSRF cookie sent
INFO - 2018-07-01 02:34:49 --> Input Class Initialized
INFO - 2018-07-01 02:34:49 --> Language Class Initialized
ERROR - 2018-07-01 02:34:49 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-01 02:34:49 --> Config Class Initialized
INFO - 2018-07-01 02:34:49 --> Hooks Class Initialized
DEBUG - 2018-07-01 02:34:49 --> UTF-8 Support Enabled
INFO - 2018-07-01 02:34:49 --> Utf8 Class Initialized
INFO - 2018-07-01 02:34:49 --> URI Class Initialized
DEBUG - 2018-07-01 02:34:49 --> No URI present. Default controller set.
INFO - 2018-07-01 02:34:49 --> Router Class Initialized
INFO - 2018-07-01 02:34:49 --> Output Class Initialized
INFO - 2018-07-01 02:34:49 --> Security Class Initialized
DEBUG - 2018-07-01 02:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-01 02:34:49 --> CSRF cookie sent
INFO - 2018-07-01 02:34:49 --> Input Class Initialized
INFO - 2018-07-01 02:34:49 --> Language Class Initialized
INFO - 2018-07-01 02:34:49 --> Loader Class Initialized
INFO - 2018-07-01 02:34:49 --> Helper loaded: url_helper
INFO - 2018-07-01 02:34:49 --> Helper loaded: form_helper
INFO - 2018-07-01 02:34:49 --> Helper loaded: language_helper
DEBUG - 2018-07-01 02:34:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-01 02:34:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-01 02:34:49 --> User Agent Class Initialized
INFO - 2018-07-01 02:34:49 --> Controller Class Initialized
INFO - 2018-07-01 02:34:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-01 02:34:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-01 02:34:49 --> Pixel_Model class loaded
INFO - 2018-07-01 02:34:49 --> Database Driver Class Initialized
INFO - 2018-07-01 02:34:49 --> Model "QuestionsModel" initialized
INFO - 2018-07-01 02:34:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-01 02:34:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-01 02:34:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-01 02:34:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-01 02:34:49 --> Final output sent to browser
DEBUG - 2018-07-01 02:34:49 --> Total execution time: 0.0332
INFO - 2018-07-01 07:19:27 --> Config Class Initialized
INFO - 2018-07-01 07:19:27 --> Hooks Class Initialized
DEBUG - 2018-07-01 07:19:27 --> UTF-8 Support Enabled
INFO - 2018-07-01 07:19:27 --> Utf8 Class Initialized
INFO - 2018-07-01 07:19:27 --> URI Class Initialized
INFO - 2018-07-01 07:19:27 --> Router Class Initialized
INFO - 2018-07-01 07:19:27 --> Output Class Initialized
INFO - 2018-07-01 07:19:27 --> Security Class Initialized
DEBUG - 2018-07-01 07:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-01 07:19:27 --> CSRF cookie sent
INFO - 2018-07-01 07:19:27 --> Input Class Initialized
INFO - 2018-07-01 07:19:27 --> Language Class Initialized
INFO - 2018-07-01 07:19:27 --> Loader Class Initialized
INFO - 2018-07-01 07:19:27 --> Helper loaded: url_helper
INFO - 2018-07-01 07:19:27 --> Helper loaded: form_helper
INFO - 2018-07-01 07:19:27 --> Helper loaded: language_helper
DEBUG - 2018-07-01 07:19:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-01 07:19:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-01 07:19:27 --> User Agent Class Initialized
INFO - 2018-07-01 07:19:27 --> Controller Class Initialized
INFO - 2018-07-01 07:19:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-01 07:19:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-01 07:19:27 --> Pixel_Model class loaded
INFO - 2018-07-01 07:19:27 --> Database Driver Class Initialized
INFO - 2018-07-01 07:19:27 --> Model "QuestionsModel" initialized
INFO - 2018-07-01 07:19:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-01 07:19:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-01 07:19:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-01 07:19:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-01 07:19:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/buy_gift.php
INFO - 2018-07-01 07:19:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-01 07:19:27 --> Final output sent to browser
DEBUG - 2018-07-01 07:19:27 --> Total execution time: 0.0359
INFO - 2018-07-01 08:40:38 --> Config Class Initialized
INFO - 2018-07-01 08:40:38 --> Hooks Class Initialized
DEBUG - 2018-07-01 08:40:38 --> UTF-8 Support Enabled
INFO - 2018-07-01 08:40:38 --> Utf8 Class Initialized
INFO - 2018-07-01 08:40:38 --> URI Class Initialized
INFO - 2018-07-01 08:40:38 --> Router Class Initialized
INFO - 2018-07-01 08:40:38 --> Output Class Initialized
INFO - 2018-07-01 08:40:38 --> Security Class Initialized
DEBUG - 2018-07-01 08:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-01 08:40:38 --> CSRF cookie sent
INFO - 2018-07-01 08:40:38 --> Input Class Initialized
INFO - 2018-07-01 08:40:38 --> Language Class Initialized
ERROR - 2018-07-01 08:40:38 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-01 08:40:38 --> Config Class Initialized
INFO - 2018-07-01 08:40:38 --> Hooks Class Initialized
DEBUG - 2018-07-01 08:40:38 --> UTF-8 Support Enabled
INFO - 2018-07-01 08:40:38 --> Utf8 Class Initialized
INFO - 2018-07-01 08:40:38 --> URI Class Initialized
DEBUG - 2018-07-01 08:40:38 --> No URI present. Default controller set.
INFO - 2018-07-01 08:40:38 --> Router Class Initialized
INFO - 2018-07-01 08:40:38 --> Output Class Initialized
INFO - 2018-07-01 08:40:38 --> Security Class Initialized
DEBUG - 2018-07-01 08:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-01 08:40:38 --> CSRF cookie sent
INFO - 2018-07-01 08:40:38 --> Input Class Initialized
INFO - 2018-07-01 08:40:38 --> Language Class Initialized
INFO - 2018-07-01 08:40:38 --> Loader Class Initialized
INFO - 2018-07-01 08:40:38 --> Helper loaded: url_helper
INFO - 2018-07-01 08:40:38 --> Helper loaded: form_helper
INFO - 2018-07-01 08:40:38 --> Helper loaded: language_helper
DEBUG - 2018-07-01 08:40:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-01 08:40:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-01 08:40:38 --> User Agent Class Initialized
INFO - 2018-07-01 08:40:38 --> Controller Class Initialized
INFO - 2018-07-01 08:40:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-01 08:40:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-01 08:40:38 --> Pixel_Model class loaded
INFO - 2018-07-01 08:40:38 --> Database Driver Class Initialized
INFO - 2018-07-01 08:40:38 --> Model "QuestionsModel" initialized
INFO - 2018-07-01 08:40:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-01 08:40:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-01 08:40:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-01 08:40:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-01 08:40:38 --> Final output sent to browser
DEBUG - 2018-07-01 08:40:38 --> Total execution time: 0.0317
INFO - 2018-07-01 10:36:43 --> Config Class Initialized
INFO - 2018-07-01 10:36:43 --> Hooks Class Initialized
DEBUG - 2018-07-01 10:36:43 --> UTF-8 Support Enabled
INFO - 2018-07-01 10:36:43 --> Utf8 Class Initialized
INFO - 2018-07-01 10:36:43 --> URI Class Initialized
INFO - 2018-07-01 10:36:43 --> Router Class Initialized
INFO - 2018-07-01 10:36:43 --> Output Class Initialized
INFO - 2018-07-01 10:36:43 --> Security Class Initialized
DEBUG - 2018-07-01 10:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-01 10:36:43 --> CSRF cookie sent
INFO - 2018-07-01 10:36:43 --> Input Class Initialized
INFO - 2018-07-01 10:36:43 --> Language Class Initialized
INFO - 2018-07-01 10:36:43 --> Loader Class Initialized
INFO - 2018-07-01 10:36:43 --> Helper loaded: url_helper
INFO - 2018-07-01 10:36:43 --> Helper loaded: form_helper
INFO - 2018-07-01 10:36:43 --> Helper loaded: language_helper
DEBUG - 2018-07-01 10:36:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-01 10:36:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-01 10:36:43 --> User Agent Class Initialized
INFO - 2018-07-01 10:36:43 --> Controller Class Initialized
INFO - 2018-07-01 10:36:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-01 10:36:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-01 10:36:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-01 10:36:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-01 10:36:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-01 10:36:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-01 10:36:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-07-01 10:36:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-01 10:36:43 --> Final output sent to browser
DEBUG - 2018-07-01 10:36:43 --> Total execution time: 0.0218
INFO - 2018-07-01 10:55:20 --> Config Class Initialized
INFO - 2018-07-01 10:55:20 --> Hooks Class Initialized
DEBUG - 2018-07-01 10:55:20 --> UTF-8 Support Enabled
INFO - 2018-07-01 10:55:20 --> Utf8 Class Initialized
INFO - 2018-07-01 10:55:20 --> URI Class Initialized
INFO - 2018-07-01 10:55:20 --> Router Class Initialized
INFO - 2018-07-01 10:55:20 --> Output Class Initialized
INFO - 2018-07-01 10:55:20 --> Security Class Initialized
DEBUG - 2018-07-01 10:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-01 10:55:20 --> CSRF cookie sent
INFO - 2018-07-01 10:55:20 --> Input Class Initialized
INFO - 2018-07-01 10:55:20 --> Language Class Initialized
INFO - 2018-07-01 10:55:20 --> Loader Class Initialized
INFO - 2018-07-01 10:55:20 --> Helper loaded: url_helper
INFO - 2018-07-01 10:55:20 --> Helper loaded: form_helper
INFO - 2018-07-01 10:55:20 --> Helper loaded: language_helper
DEBUG - 2018-07-01 10:55:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-01 10:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-01 10:55:20 --> User Agent Class Initialized
INFO - 2018-07-01 10:55:20 --> Controller Class Initialized
INFO - 2018-07-01 10:55:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-01 10:55:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-01 10:55:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-01 10:55:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-01 10:55:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-01 10:55:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-01 10:55:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-07-01 10:55:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-01 10:55:20 --> Final output sent to browser
DEBUG - 2018-07-01 10:55:20 --> Total execution time: 0.0217
INFO - 2018-07-01 14:01:46 --> Config Class Initialized
INFO - 2018-07-01 14:01:46 --> Hooks Class Initialized
DEBUG - 2018-07-01 14:01:46 --> UTF-8 Support Enabled
INFO - 2018-07-01 14:01:46 --> Utf8 Class Initialized
INFO - 2018-07-01 14:01:46 --> URI Class Initialized
DEBUG - 2018-07-01 14:01:46 --> No URI present. Default controller set.
INFO - 2018-07-01 14:01:46 --> Router Class Initialized
INFO - 2018-07-01 14:01:46 --> Output Class Initialized
INFO - 2018-07-01 14:01:46 --> Security Class Initialized
DEBUG - 2018-07-01 14:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-01 14:01:46 --> CSRF cookie sent
INFO - 2018-07-01 14:01:46 --> Input Class Initialized
INFO - 2018-07-01 14:01:46 --> Language Class Initialized
INFO - 2018-07-01 14:01:46 --> Loader Class Initialized
INFO - 2018-07-01 14:01:46 --> Helper loaded: url_helper
INFO - 2018-07-01 14:01:46 --> Helper loaded: form_helper
INFO - 2018-07-01 14:01:46 --> Helper loaded: language_helper
DEBUG - 2018-07-01 14:01:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-01 14:01:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-01 14:01:46 --> User Agent Class Initialized
INFO - 2018-07-01 14:01:46 --> Controller Class Initialized
INFO - 2018-07-01 14:01:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-01 14:01:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-01 14:01:46 --> Pixel_Model class loaded
INFO - 2018-07-01 14:01:46 --> Database Driver Class Initialized
INFO - 2018-07-01 14:01:46 --> Model "QuestionsModel" initialized
INFO - 2018-07-01 14:01:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-01 14:01:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-01 14:01:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-01 14:01:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-01 14:01:46 --> Final output sent to browser
DEBUG - 2018-07-01 14:01:46 --> Total execution time: 0.0376
INFO - 2018-07-01 15:07:06 --> Config Class Initialized
INFO - 2018-07-01 15:07:06 --> Hooks Class Initialized
DEBUG - 2018-07-01 15:07:06 --> UTF-8 Support Enabled
INFO - 2018-07-01 15:07:06 --> Utf8 Class Initialized
INFO - 2018-07-01 15:07:06 --> URI Class Initialized
INFO - 2018-07-01 15:07:06 --> Router Class Initialized
INFO - 2018-07-01 15:07:06 --> Output Class Initialized
INFO - 2018-07-01 15:07:06 --> Security Class Initialized
DEBUG - 2018-07-01 15:07:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-01 15:07:06 --> CSRF cookie sent
INFO - 2018-07-01 15:07:06 --> Input Class Initialized
INFO - 2018-07-01 15:07:06 --> Language Class Initialized
ERROR - 2018-07-01 15:07:06 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-01 15:07:06 --> Config Class Initialized
INFO - 2018-07-01 15:07:06 --> Hooks Class Initialized
DEBUG - 2018-07-01 15:07:06 --> UTF-8 Support Enabled
INFO - 2018-07-01 15:07:06 --> Utf8 Class Initialized
INFO - 2018-07-01 15:07:06 --> URI Class Initialized
INFO - 2018-07-01 15:07:06 --> Router Class Initialized
INFO - 2018-07-01 15:07:06 --> Output Class Initialized
INFO - 2018-07-01 15:07:06 --> Security Class Initialized
DEBUG - 2018-07-01 15:07:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-01 15:07:06 --> CSRF cookie sent
INFO - 2018-07-01 15:07:06 --> Input Class Initialized
INFO - 2018-07-01 15:07:06 --> Language Class Initialized
INFO - 2018-07-01 15:07:06 --> Loader Class Initialized
INFO - 2018-07-01 15:07:06 --> Helper loaded: url_helper
INFO - 2018-07-01 15:07:06 --> Helper loaded: form_helper
INFO - 2018-07-01 15:07:06 --> Helper loaded: language_helper
DEBUG - 2018-07-01 15:07:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-01 15:07:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-01 15:07:06 --> User Agent Class Initialized
INFO - 2018-07-01 15:07:06 --> Controller Class Initialized
INFO - 2018-07-01 15:07:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-01 15:07:06 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-01 15:07:06 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-01 15:07:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-01 15:07:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-01 15:07:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-01 15:07:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-01 15:07:06 --> Could not find the language line "req_email"
INFO - 2018-07-01 15:07:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-01 15:07:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-01 15:07:06 --> Final output sent to browser
DEBUG - 2018-07-01 15:07:06 --> Total execution time: 0.0205
INFO - 2018-07-01 16:01:03 --> Config Class Initialized
INFO - 2018-07-01 16:01:03 --> Hooks Class Initialized
DEBUG - 2018-07-01 16:01:03 --> UTF-8 Support Enabled
INFO - 2018-07-01 16:01:03 --> Utf8 Class Initialized
INFO - 2018-07-01 16:01:03 --> URI Class Initialized
INFO - 2018-07-01 16:01:03 --> Router Class Initialized
INFO - 2018-07-01 16:01:03 --> Output Class Initialized
INFO - 2018-07-01 16:01:03 --> Security Class Initialized
DEBUG - 2018-07-01 16:01:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-01 16:01:03 --> CSRF cookie sent
INFO - 2018-07-01 16:01:03 --> Input Class Initialized
INFO - 2018-07-01 16:01:03 --> Language Class Initialized
INFO - 2018-07-01 16:01:03 --> Loader Class Initialized
INFO - 2018-07-01 16:01:03 --> Helper loaded: url_helper
INFO - 2018-07-01 16:01:03 --> Helper loaded: form_helper
INFO - 2018-07-01 16:01:03 --> Helper loaded: language_helper
DEBUG - 2018-07-01 16:01:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-01 16:01:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-01 16:01:03 --> User Agent Class Initialized
INFO - 2018-07-01 16:01:03 --> Controller Class Initialized
INFO - 2018-07-01 16:01:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-01 16:01:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-01 16:01:03 --> Pixel_Model class loaded
INFO - 2018-07-01 16:01:03 --> Database Driver Class Initialized
INFO - 2018-07-01 16:01:03 --> Model "QuestionsModel" initialized
INFO - 2018-07-01 16:01:06 --> Config Class Initialized
INFO - 2018-07-01 16:01:06 --> Hooks Class Initialized
DEBUG - 2018-07-01 16:01:06 --> UTF-8 Support Enabled
INFO - 2018-07-01 16:01:06 --> Utf8 Class Initialized
INFO - 2018-07-01 16:01:06 --> URI Class Initialized
INFO - 2018-07-01 16:01:06 --> Router Class Initialized
INFO - 2018-07-01 16:01:06 --> Output Class Initialized
INFO - 2018-07-01 16:01:06 --> Security Class Initialized
DEBUG - 2018-07-01 16:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-01 16:01:06 --> CSRF cookie sent
INFO - 2018-07-01 16:01:06 --> Input Class Initialized
INFO - 2018-07-01 16:01:06 --> Language Class Initialized
INFO - 2018-07-01 16:01:06 --> Loader Class Initialized
INFO - 2018-07-01 16:01:06 --> Helper loaded: url_helper
INFO - 2018-07-01 16:01:06 --> Helper loaded: form_helper
INFO - 2018-07-01 16:01:06 --> Helper loaded: language_helper
DEBUG - 2018-07-01 16:01:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-01 16:01:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-01 16:01:06 --> User Agent Class Initialized
INFO - 2018-07-01 16:01:06 --> Controller Class Initialized
INFO - 2018-07-01 16:01:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-01 16:01:06 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-01 16:01:06 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-01 16:01:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-01 16:01:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-01 16:01:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-01 16:01:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-01 16:01:06 --> Could not find the language line "req_email"
INFO - 2018-07-01 16:01:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-01 16:01:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-01 16:01:06 --> Final output sent to browser
DEBUG - 2018-07-01 16:01:06 --> Total execution time: 0.0252
INFO - 2018-07-01 16:58:40 --> Config Class Initialized
INFO - 2018-07-01 16:58:40 --> Hooks Class Initialized
DEBUG - 2018-07-01 16:58:40 --> UTF-8 Support Enabled
INFO - 2018-07-01 16:58:40 --> Utf8 Class Initialized
INFO - 2018-07-01 16:58:40 --> URI Class Initialized
INFO - 2018-07-01 16:58:40 --> Router Class Initialized
INFO - 2018-07-01 16:58:40 --> Output Class Initialized
INFO - 2018-07-01 16:58:40 --> Security Class Initialized
DEBUG - 2018-07-01 16:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-01 16:58:40 --> CSRF cookie sent
INFO - 2018-07-01 16:58:40 --> Input Class Initialized
INFO - 2018-07-01 16:58:40 --> Language Class Initialized
ERROR - 2018-07-01 16:58:40 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-01 17:27:58 --> Config Class Initialized
INFO - 2018-07-01 17:27:58 --> Hooks Class Initialized
DEBUG - 2018-07-01 17:27:58 --> UTF-8 Support Enabled
INFO - 2018-07-01 17:27:58 --> Utf8 Class Initialized
INFO - 2018-07-01 17:27:58 --> URI Class Initialized
INFO - 2018-07-01 17:27:58 --> Router Class Initialized
INFO - 2018-07-01 17:27:58 --> Output Class Initialized
INFO - 2018-07-01 17:27:58 --> Security Class Initialized
DEBUG - 2018-07-01 17:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-01 17:27:58 --> CSRF cookie sent
INFO - 2018-07-01 17:27:58 --> Input Class Initialized
INFO - 2018-07-01 17:27:58 --> Language Class Initialized
ERROR - 2018-07-01 17:27:58 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-01 17:36:03 --> Config Class Initialized
INFO - 2018-07-01 17:36:03 --> Hooks Class Initialized
DEBUG - 2018-07-01 17:36:03 --> UTF-8 Support Enabled
INFO - 2018-07-01 17:36:03 --> Utf8 Class Initialized
INFO - 2018-07-01 17:36:03 --> URI Class Initialized
DEBUG - 2018-07-01 17:36:03 --> No URI present. Default controller set.
INFO - 2018-07-01 17:36:03 --> Router Class Initialized
INFO - 2018-07-01 17:36:03 --> Output Class Initialized
INFO - 2018-07-01 17:36:03 --> Security Class Initialized
DEBUG - 2018-07-01 17:36:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-01 17:36:03 --> CSRF cookie sent
INFO - 2018-07-01 17:36:03 --> Input Class Initialized
INFO - 2018-07-01 17:36:03 --> Language Class Initialized
INFO - 2018-07-01 17:36:03 --> Loader Class Initialized
INFO - 2018-07-01 17:36:03 --> Helper loaded: url_helper
INFO - 2018-07-01 17:36:03 --> Helper loaded: form_helper
INFO - 2018-07-01 17:36:03 --> Helper loaded: language_helper
DEBUG - 2018-07-01 17:36:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-01 17:36:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-01 17:36:03 --> User Agent Class Initialized
INFO - 2018-07-01 17:36:03 --> Controller Class Initialized
INFO - 2018-07-01 17:36:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-01 17:36:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-01 17:36:03 --> Pixel_Model class loaded
INFO - 2018-07-01 17:36:03 --> Database Driver Class Initialized
INFO - 2018-07-01 17:36:03 --> Model "QuestionsModel" initialized
INFO - 2018-07-01 17:36:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-01 17:36:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-01 17:36:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-01 17:36:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-01 17:36:03 --> Final output sent to browser
DEBUG - 2018-07-01 17:36:03 --> Total execution time: 0.0312
INFO - 2018-07-01 17:49:32 --> Config Class Initialized
INFO - 2018-07-01 17:49:32 --> Hooks Class Initialized
DEBUG - 2018-07-01 17:49:32 --> UTF-8 Support Enabled
INFO - 2018-07-01 17:49:32 --> Utf8 Class Initialized
INFO - 2018-07-01 17:49:32 --> URI Class Initialized
INFO - 2018-07-01 17:49:32 --> Router Class Initialized
INFO - 2018-07-01 17:49:32 --> Output Class Initialized
INFO - 2018-07-01 17:49:32 --> Security Class Initialized
DEBUG - 2018-07-01 17:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-01 17:49:32 --> CSRF cookie sent
INFO - 2018-07-01 17:49:32 --> Input Class Initialized
INFO - 2018-07-01 17:49:32 --> Language Class Initialized
INFO - 2018-07-01 17:49:32 --> Loader Class Initialized
INFO - 2018-07-01 17:49:32 --> Helper loaded: url_helper
INFO - 2018-07-01 17:49:32 --> Helper loaded: form_helper
INFO - 2018-07-01 17:49:32 --> Helper loaded: language_helper
DEBUG - 2018-07-01 17:49:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-01 17:49:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-01 17:49:32 --> User Agent Class Initialized
INFO - 2018-07-01 17:49:32 --> Controller Class Initialized
INFO - 2018-07-01 17:49:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-01 17:49:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-01 17:49:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-01 17:49:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-01 17:49:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-01 17:49:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-01 17:49:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-07-01 17:49:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-01 17:49:32 --> Final output sent to browser
DEBUG - 2018-07-01 17:49:32 --> Total execution time: 0.0304
INFO - 2018-07-01 17:54:40 --> Config Class Initialized
INFO - 2018-07-01 17:54:40 --> Hooks Class Initialized
DEBUG - 2018-07-01 17:54:40 --> UTF-8 Support Enabled
INFO - 2018-07-01 17:54:40 --> Utf8 Class Initialized
INFO - 2018-07-01 17:54:40 --> URI Class Initialized
DEBUG - 2018-07-01 17:54:40 --> No URI present. Default controller set.
INFO - 2018-07-01 17:54:40 --> Router Class Initialized
INFO - 2018-07-01 17:54:40 --> Output Class Initialized
INFO - 2018-07-01 17:54:40 --> Security Class Initialized
DEBUG - 2018-07-01 17:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-01 17:54:40 --> CSRF cookie sent
INFO - 2018-07-01 17:54:40 --> Input Class Initialized
INFO - 2018-07-01 17:54:40 --> Language Class Initialized
INFO - 2018-07-01 17:54:40 --> Loader Class Initialized
INFO - 2018-07-01 17:54:40 --> Helper loaded: url_helper
INFO - 2018-07-01 17:54:41 --> Helper loaded: form_helper
INFO - 2018-07-01 17:54:41 --> Helper loaded: language_helper
DEBUG - 2018-07-01 17:54:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-01 17:54:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-01 17:54:41 --> User Agent Class Initialized
INFO - 2018-07-01 17:54:41 --> Controller Class Initialized
INFO - 2018-07-01 17:54:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-01 17:54:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-01 17:54:41 --> Pixel_Model class loaded
INFO - 2018-07-01 17:54:41 --> Database Driver Class Initialized
INFO - 2018-07-01 17:54:41 --> Model "QuestionsModel" initialized
INFO - 2018-07-01 17:54:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-01 17:54:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-01 17:54:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-01 17:54:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-01 17:54:41 --> Final output sent to browser
DEBUG - 2018-07-01 17:54:41 --> Total execution time: 0.0479
INFO - 2018-07-01 17:54:41 --> Config Class Initialized
INFO - 2018-07-01 17:54:41 --> Hooks Class Initialized
DEBUG - 2018-07-01 17:54:41 --> UTF-8 Support Enabled
INFO - 2018-07-01 17:54:41 --> Utf8 Class Initialized
INFO - 2018-07-01 17:54:41 --> URI Class Initialized
DEBUG - 2018-07-01 17:54:41 --> No URI present. Default controller set.
INFO - 2018-07-01 17:54:41 --> Router Class Initialized
INFO - 2018-07-01 17:54:41 --> Output Class Initialized
INFO - 2018-07-01 17:54:41 --> Security Class Initialized
DEBUG - 2018-07-01 17:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-01 17:54:41 --> CSRF cookie sent
INFO - 2018-07-01 17:54:41 --> Input Class Initialized
INFO - 2018-07-01 17:54:41 --> Language Class Initialized
INFO - 2018-07-01 17:54:41 --> Loader Class Initialized
INFO - 2018-07-01 17:54:41 --> Helper loaded: url_helper
INFO - 2018-07-01 17:54:41 --> Helper loaded: form_helper
INFO - 2018-07-01 17:54:41 --> Helper loaded: language_helper
DEBUG - 2018-07-01 17:54:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-01 17:54:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-01 17:54:41 --> User Agent Class Initialized
INFO - 2018-07-01 17:54:41 --> Controller Class Initialized
INFO - 2018-07-01 17:54:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-01 17:54:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-01 17:54:41 --> Pixel_Model class loaded
INFO - 2018-07-01 17:54:41 --> Database Driver Class Initialized
INFO - 2018-07-01 17:54:41 --> Model "QuestionsModel" initialized
INFO - 2018-07-01 17:54:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-01 17:54:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-01 17:54:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-01 17:54:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-01 17:54:41 --> Final output sent to browser
DEBUG - 2018-07-01 17:54:41 --> Total execution time: 0.0260
INFO - 2018-07-01 17:54:42 --> Config Class Initialized
INFO - 2018-07-01 17:54:42 --> Hooks Class Initialized
DEBUG - 2018-07-01 17:54:42 --> UTF-8 Support Enabled
INFO - 2018-07-01 17:54:42 --> Utf8 Class Initialized
INFO - 2018-07-01 17:54:42 --> URI Class Initialized
DEBUG - 2018-07-01 17:54:42 --> No URI present. Default controller set.
INFO - 2018-07-01 17:54:42 --> Router Class Initialized
INFO - 2018-07-01 17:54:42 --> Output Class Initialized
INFO - 2018-07-01 17:54:42 --> Security Class Initialized
DEBUG - 2018-07-01 17:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-01 17:54:42 --> CSRF cookie sent
INFO - 2018-07-01 17:54:42 --> Input Class Initialized
INFO - 2018-07-01 17:54:42 --> Language Class Initialized
INFO - 2018-07-01 17:54:42 --> Loader Class Initialized
INFO - 2018-07-01 17:54:42 --> Helper loaded: url_helper
INFO - 2018-07-01 17:54:42 --> Helper loaded: form_helper
INFO - 2018-07-01 17:54:42 --> Helper loaded: language_helper
DEBUG - 2018-07-01 17:54:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-01 17:54:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-01 17:54:42 --> User Agent Class Initialized
INFO - 2018-07-01 17:54:42 --> Controller Class Initialized
INFO - 2018-07-01 17:54:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-01 17:54:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-01 17:54:42 --> Pixel_Model class loaded
INFO - 2018-07-01 17:54:42 --> Database Driver Class Initialized
INFO - 2018-07-01 17:54:42 --> Model "QuestionsModel" initialized
INFO - 2018-07-01 17:54:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-01 17:54:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-01 17:54:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-01 17:54:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-01 17:54:42 --> Final output sent to browser
DEBUG - 2018-07-01 17:54:42 --> Total execution time: 0.0285
INFO - 2018-07-01 17:54:43 --> Config Class Initialized
INFO - 2018-07-01 17:54:43 --> Hooks Class Initialized
DEBUG - 2018-07-01 17:54:43 --> UTF-8 Support Enabled
INFO - 2018-07-01 17:54:43 --> Utf8 Class Initialized
INFO - 2018-07-01 17:54:43 --> URI Class Initialized
INFO - 2018-07-01 17:54:43 --> Router Class Initialized
INFO - 2018-07-01 17:54:43 --> Output Class Initialized
INFO - 2018-07-01 17:54:43 --> Security Class Initialized
DEBUG - 2018-07-01 17:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-01 17:54:43 --> CSRF cookie sent
INFO - 2018-07-01 17:54:43 --> Input Class Initialized
INFO - 2018-07-01 17:54:43 --> Language Class Initialized
ERROR - 2018-07-01 17:54:43 --> 404 Page Not Found: 405shtml/index
INFO - 2018-07-01 17:54:49 --> Config Class Initialized
INFO - 2018-07-01 17:54:49 --> Hooks Class Initialized
DEBUG - 2018-07-01 17:54:49 --> UTF-8 Support Enabled
INFO - 2018-07-01 17:54:49 --> Utf8 Class Initialized
INFO - 2018-07-01 17:54:49 --> URI Class Initialized
DEBUG - 2018-07-01 17:54:49 --> No URI present. Default controller set.
INFO - 2018-07-01 17:54:49 --> Router Class Initialized
INFO - 2018-07-01 17:54:49 --> Output Class Initialized
INFO - 2018-07-01 17:54:49 --> Security Class Initialized
DEBUG - 2018-07-01 17:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-01 17:54:49 --> CSRF cookie sent
INFO - 2018-07-01 17:54:49 --> Input Class Initialized
INFO - 2018-07-01 17:54:49 --> Language Class Initialized
INFO - 2018-07-01 17:54:49 --> Loader Class Initialized
INFO - 2018-07-01 17:54:49 --> Helper loaded: url_helper
INFO - 2018-07-01 17:54:49 --> Helper loaded: form_helper
INFO - 2018-07-01 17:54:49 --> Helper loaded: language_helper
DEBUG - 2018-07-01 17:54:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-01 17:54:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-01 17:54:49 --> User Agent Class Initialized
INFO - 2018-07-01 17:54:49 --> Controller Class Initialized
INFO - 2018-07-01 17:54:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-01 17:54:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-01 17:54:49 --> Pixel_Model class loaded
INFO - 2018-07-01 17:54:49 --> Database Driver Class Initialized
INFO - 2018-07-01 17:54:49 --> Model "QuestionsModel" initialized
INFO - 2018-07-01 17:54:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-01 17:54:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-01 17:54:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-01 17:54:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-01 17:54:49 --> Final output sent to browser
DEBUG - 2018-07-01 17:54:49 --> Total execution time: 0.0402
INFO - 2018-07-01 17:54:49 --> Config Class Initialized
INFO - 2018-07-01 17:54:49 --> Hooks Class Initialized
DEBUG - 2018-07-01 17:54:49 --> UTF-8 Support Enabled
INFO - 2018-07-01 17:54:49 --> Utf8 Class Initialized
INFO - 2018-07-01 17:54:49 --> URI Class Initialized
INFO - 2018-07-01 17:54:49 --> Router Class Initialized
INFO - 2018-07-01 17:54:49 --> Output Class Initialized
INFO - 2018-07-01 17:54:49 --> Security Class Initialized
DEBUG - 2018-07-01 17:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-01 17:54:49 --> CSRF cookie sent
INFO - 2018-07-01 17:54:49 --> Input Class Initialized
INFO - 2018-07-01 17:54:49 --> Language Class Initialized
ERROR - 2018-07-01 17:54:49 --> 404 Page Not Found: 404testpage4525d2fdc/index
INFO - 2018-07-01 17:54:50 --> Config Class Initialized
INFO - 2018-07-01 17:54:50 --> Hooks Class Initialized
DEBUG - 2018-07-01 17:54:50 --> UTF-8 Support Enabled
INFO - 2018-07-01 17:54:50 --> Utf8 Class Initialized
INFO - 2018-07-01 17:54:50 --> URI Class Initialized
INFO - 2018-07-01 17:54:50 --> Router Class Initialized
INFO - 2018-07-01 17:54:50 --> Output Class Initialized
INFO - 2018-07-01 17:54:50 --> Security Class Initialized
DEBUG - 2018-07-01 17:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-01 17:54:50 --> CSRF cookie sent
INFO - 2018-07-01 17:54:50 --> Input Class Initialized
INFO - 2018-07-01 17:54:50 --> Language Class Initialized
ERROR - 2018-07-01 17:54:50 --> 404 Page Not Found: 404javascriptjs/index
INFO - 2018-07-01 17:54:50 --> Config Class Initialized
INFO - 2018-07-01 17:54:50 --> Hooks Class Initialized
DEBUG - 2018-07-01 17:54:50 --> UTF-8 Support Enabled
INFO - 2018-07-01 17:54:50 --> Utf8 Class Initialized
INFO - 2018-07-01 17:54:50 --> URI Class Initialized
INFO - 2018-07-01 17:54:50 --> Router Class Initialized
INFO - 2018-07-01 17:54:50 --> Output Class Initialized
INFO - 2018-07-01 17:54:50 --> Security Class Initialized
DEBUG - 2018-07-01 17:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-01 17:54:50 --> CSRF cookie sent
INFO - 2018-07-01 17:54:50 --> Input Class Initialized
INFO - 2018-07-01 17:54:50 --> Language Class Initialized
INFO - 2018-07-01 17:54:50 --> Loader Class Initialized
INFO - 2018-07-01 17:54:50 --> Helper loaded: url_helper
INFO - 2018-07-01 17:54:50 --> Helper loaded: form_helper
INFO - 2018-07-01 17:54:50 --> Helper loaded: language_helper
DEBUG - 2018-07-01 17:54:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-01 17:54:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-01 17:54:50 --> User Agent Class Initialized
INFO - 2018-07-01 17:54:50 --> Controller Class Initialized
INFO - 2018-07-01 17:54:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-01 17:54:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-01 17:54:50 --> Pixel_Model class loaded
INFO - 2018-07-01 17:54:50 --> Database Driver Class Initialized
INFO - 2018-07-01 17:54:50 --> Model "QuestionsModel" initialized
INFO - 2018-07-01 17:54:50 --> Config Class Initialized
INFO - 2018-07-01 17:54:50 --> Hooks Class Initialized
DEBUG - 2018-07-01 17:54:50 --> UTF-8 Support Enabled
INFO - 2018-07-01 17:54:50 --> Utf8 Class Initialized
INFO - 2018-07-01 17:54:50 --> URI Class Initialized
INFO - 2018-07-01 17:54:50 --> Router Class Initialized
INFO - 2018-07-01 17:54:50 --> Output Class Initialized
INFO - 2018-07-01 17:54:50 --> Security Class Initialized
DEBUG - 2018-07-01 17:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-01 17:54:50 --> CSRF cookie sent
INFO - 2018-07-01 17:54:50 --> Input Class Initialized
INFO - 2018-07-01 17:54:50 --> Language Class Initialized
INFO - 2018-07-01 17:54:50 --> Loader Class Initialized
INFO - 2018-07-01 17:54:50 --> Helper loaded: url_helper
INFO - 2018-07-01 17:54:50 --> Helper loaded: form_helper
INFO - 2018-07-01 17:54:50 --> Helper loaded: language_helper
DEBUG - 2018-07-01 17:54:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-01 17:54:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-01 17:54:50 --> User Agent Class Initialized
INFO - 2018-07-01 17:54:50 --> Controller Class Initialized
INFO - 2018-07-01 17:54:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-01 17:54:50 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-01 17:54:50 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-01 17:54:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-01 17:54:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-01 17:54:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-01 17:54:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-01 17:54:50 --> Could not find the language line "req_email"
INFO - 2018-07-01 17:54:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-01 17:54:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-01 17:54:50 --> Final output sent to browser
DEBUG - 2018-07-01 17:54:50 --> Total execution time: 0.0315
INFO - 2018-07-01 17:54:50 --> Config Class Initialized
INFO - 2018-07-01 17:54:50 --> Hooks Class Initialized
DEBUG - 2018-07-01 17:54:50 --> UTF-8 Support Enabled
INFO - 2018-07-01 17:54:50 --> Utf8 Class Initialized
INFO - 2018-07-01 17:54:50 --> URI Class Initialized
INFO - 2018-07-01 17:54:50 --> Router Class Initialized
INFO - 2018-07-01 17:54:50 --> Output Class Initialized
INFO - 2018-07-01 17:54:50 --> Security Class Initialized
DEBUG - 2018-07-01 17:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-01 17:54:50 --> CSRF cookie sent
INFO - 2018-07-01 17:54:50 --> Input Class Initialized
INFO - 2018-07-01 17:54:50 --> Language Class Initialized
INFO - 2018-07-01 17:54:50 --> Loader Class Initialized
INFO - 2018-07-01 17:54:50 --> Helper loaded: url_helper
INFO - 2018-07-01 17:54:50 --> Helper loaded: form_helper
INFO - 2018-07-01 17:54:50 --> Helper loaded: language_helper
DEBUG - 2018-07-01 17:54:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-01 17:54:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-01 17:54:50 --> User Agent Class Initialized
INFO - 2018-07-01 17:54:50 --> Controller Class Initialized
INFO - 2018-07-01 17:54:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-01 17:54:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-01 17:54:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-01 17:54:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-01 17:54:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-01 17:54:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-01 17:54:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-07-01 17:54:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-01 17:54:50 --> Final output sent to browser
DEBUG - 2018-07-01 17:54:50 --> Total execution time: 0.0249
INFO - 2018-07-01 17:54:51 --> Config Class Initialized
INFO - 2018-07-01 17:54:51 --> Hooks Class Initialized
DEBUG - 2018-07-01 17:54:51 --> UTF-8 Support Enabled
INFO - 2018-07-01 17:54:51 --> Utf8 Class Initialized
INFO - 2018-07-01 17:54:51 --> URI Class Initialized
INFO - 2018-07-01 17:54:51 --> Router Class Initialized
INFO - 2018-07-01 17:54:51 --> Output Class Initialized
INFO - 2018-07-01 17:54:51 --> Security Class Initialized
DEBUG - 2018-07-01 17:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-01 17:54:51 --> CSRF cookie sent
INFO - 2018-07-01 17:54:51 --> Input Class Initialized
INFO - 2018-07-01 17:54:51 --> Language Class Initialized
INFO - 2018-07-01 17:54:51 --> Loader Class Initialized
INFO - 2018-07-01 17:54:51 --> Helper loaded: url_helper
INFO - 2018-07-01 17:54:51 --> Helper loaded: form_helper
INFO - 2018-07-01 17:54:51 --> Helper loaded: language_helper
DEBUG - 2018-07-01 17:54:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-01 17:54:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-01 17:54:51 --> User Agent Class Initialized
INFO - 2018-07-01 17:54:51 --> Controller Class Initialized
INFO - 2018-07-01 17:54:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-01 17:54:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-01 17:54:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-01 17:54:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-01 17:54:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-01 17:54:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-01 17:54:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-07-01 17:54:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-01 17:54:51 --> Final output sent to browser
DEBUG - 2018-07-01 17:54:51 --> Total execution time: 0.0306
INFO - 2018-07-01 17:54:51 --> Config Class Initialized
INFO - 2018-07-01 17:54:51 --> Hooks Class Initialized
DEBUG - 2018-07-01 17:54:51 --> UTF-8 Support Enabled
INFO - 2018-07-01 17:54:51 --> Utf8 Class Initialized
INFO - 2018-07-01 17:54:51 --> URI Class Initialized
INFO - 2018-07-01 17:54:51 --> Router Class Initialized
INFO - 2018-07-01 17:54:51 --> Output Class Initialized
INFO - 2018-07-01 17:54:51 --> Security Class Initialized
DEBUG - 2018-07-01 17:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-01 17:54:51 --> CSRF cookie sent
INFO - 2018-07-01 17:54:51 --> Input Class Initialized
INFO - 2018-07-01 17:54:51 --> Language Class Initialized
INFO - 2018-07-01 17:54:51 --> Loader Class Initialized
INFO - 2018-07-01 17:54:51 --> Helper loaded: url_helper
INFO - 2018-07-01 17:54:51 --> Helper loaded: form_helper
INFO - 2018-07-01 17:54:51 --> Helper loaded: language_helper
DEBUG - 2018-07-01 17:54:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-01 17:54:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-01 17:54:51 --> User Agent Class Initialized
INFO - 2018-07-01 17:54:51 --> Controller Class Initialized
INFO - 2018-07-01 17:54:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-01 17:54:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-01 17:54:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-01 17:54:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-01 17:54:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-01 17:54:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-01 17:54:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-07-01 17:54:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-01 17:54:51 --> Final output sent to browser
DEBUG - 2018-07-01 17:54:51 --> Total execution time: 0.0224
INFO - 2018-07-01 17:54:51 --> Config Class Initialized
INFO - 2018-07-01 17:54:51 --> Hooks Class Initialized
DEBUG - 2018-07-01 17:54:51 --> UTF-8 Support Enabled
INFO - 2018-07-01 17:54:51 --> Utf8 Class Initialized
INFO - 2018-07-01 17:54:51 --> URI Class Initialized
INFO - 2018-07-01 17:54:51 --> Router Class Initialized
INFO - 2018-07-01 17:54:51 --> Output Class Initialized
INFO - 2018-07-01 17:54:51 --> Security Class Initialized
DEBUG - 2018-07-01 17:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-01 17:54:51 --> CSRF cookie sent
INFO - 2018-07-01 17:54:51 --> Input Class Initialized
INFO - 2018-07-01 17:54:51 --> Language Class Initialized
INFO - 2018-07-01 17:54:51 --> Loader Class Initialized
INFO - 2018-07-01 17:54:51 --> Helper loaded: url_helper
INFO - 2018-07-01 17:54:51 --> Helper loaded: form_helper
INFO - 2018-07-01 17:54:51 --> Helper loaded: language_helper
DEBUG - 2018-07-01 17:54:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-01 17:54:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-01 17:54:51 --> User Agent Class Initialized
INFO - 2018-07-01 17:54:51 --> Controller Class Initialized
INFO - 2018-07-01 17:54:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-01 17:54:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-01 17:54:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-01 17:54:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-01 17:54:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-01 17:54:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-01 17:54:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-07-01 17:54:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-01 17:54:51 --> Final output sent to browser
DEBUG - 2018-07-01 17:54:51 --> Total execution time: 0.0305
INFO - 2018-07-01 17:54:52 --> Config Class Initialized
INFO - 2018-07-01 17:54:52 --> Hooks Class Initialized
DEBUG - 2018-07-01 17:54:52 --> UTF-8 Support Enabled
INFO - 2018-07-01 17:54:52 --> Utf8 Class Initialized
INFO - 2018-07-01 17:54:52 --> URI Class Initialized
INFO - 2018-07-01 17:54:52 --> Router Class Initialized
INFO - 2018-07-01 17:54:52 --> Output Class Initialized
INFO - 2018-07-01 17:54:52 --> Security Class Initialized
DEBUG - 2018-07-01 17:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-01 17:54:52 --> CSRF cookie sent
INFO - 2018-07-01 17:54:52 --> Input Class Initialized
INFO - 2018-07-01 17:54:52 --> Language Class Initialized
INFO - 2018-07-01 17:54:52 --> Loader Class Initialized
INFO - 2018-07-01 17:54:52 --> Helper loaded: url_helper
INFO - 2018-07-01 17:54:52 --> Helper loaded: form_helper
INFO - 2018-07-01 17:54:52 --> Helper loaded: language_helper
DEBUG - 2018-07-01 17:54:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-01 17:54:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-01 17:54:52 --> User Agent Class Initialized
INFO - 2018-07-01 17:54:52 --> Controller Class Initialized
INFO - 2018-07-01 17:54:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-01 17:54:52 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-01 17:54:52 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-01 17:54:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-01 17:54:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-01 17:54:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-01 17:54:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-01 17:54:52 --> Could not find the language line "req_email"
INFO - 2018-07-01 17:54:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-01 17:54:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-01 17:54:52 --> Final output sent to browser
DEBUG - 2018-07-01 17:54:52 --> Total execution time: 0.0239
INFO - 2018-07-01 17:54:52 --> Config Class Initialized
INFO - 2018-07-01 17:54:52 --> Hooks Class Initialized
DEBUG - 2018-07-01 17:54:52 --> UTF-8 Support Enabled
INFO - 2018-07-01 17:54:52 --> Utf8 Class Initialized
INFO - 2018-07-01 17:54:52 --> URI Class Initialized
INFO - 2018-07-01 17:54:52 --> Router Class Initialized
INFO - 2018-07-01 17:54:52 --> Output Class Initialized
INFO - 2018-07-01 17:54:52 --> Security Class Initialized
DEBUG - 2018-07-01 17:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-01 17:54:52 --> CSRF cookie sent
INFO - 2018-07-01 17:54:52 --> Input Class Initialized
INFO - 2018-07-01 17:54:52 --> Language Class Initialized
INFO - 2018-07-01 17:54:52 --> Loader Class Initialized
INFO - 2018-07-01 17:54:52 --> Helper loaded: url_helper
INFO - 2018-07-01 17:54:52 --> Helper loaded: form_helper
INFO - 2018-07-01 17:54:52 --> Helper loaded: language_helper
DEBUG - 2018-07-01 17:54:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-01 17:54:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-01 17:54:52 --> User Agent Class Initialized
INFO - 2018-07-01 17:54:52 --> Controller Class Initialized
INFO - 2018-07-01 17:54:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-01 17:54:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-01 17:54:52 --> Pixel_Model class loaded
INFO - 2018-07-01 17:54:52 --> Database Driver Class Initialized
INFO - 2018-07-01 17:54:52 --> Model "QuestionsModel" initialized
INFO - 2018-07-01 17:54:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-01 17:54:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-01 17:54:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-01 17:54:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-01 17:54:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/buy_gift.php
INFO - 2018-07-01 17:54:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-01 17:54:52 --> Final output sent to browser
DEBUG - 2018-07-01 17:54:52 --> Total execution time: 0.0325
INFO - 2018-07-01 18:04:23 --> Config Class Initialized
INFO - 2018-07-01 18:04:23 --> Hooks Class Initialized
DEBUG - 2018-07-01 18:04:23 --> UTF-8 Support Enabled
INFO - 2018-07-01 18:04:23 --> Utf8 Class Initialized
INFO - 2018-07-01 18:04:23 --> URI Class Initialized
DEBUG - 2018-07-01 18:04:23 --> No URI present. Default controller set.
INFO - 2018-07-01 18:04:23 --> Router Class Initialized
INFO - 2018-07-01 18:04:23 --> Output Class Initialized
INFO - 2018-07-01 18:04:23 --> Security Class Initialized
DEBUG - 2018-07-01 18:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-01 18:04:23 --> CSRF cookie sent
INFO - 2018-07-01 18:04:23 --> Input Class Initialized
INFO - 2018-07-01 18:04:23 --> Language Class Initialized
INFO - 2018-07-01 18:04:23 --> Loader Class Initialized
INFO - 2018-07-01 18:04:23 --> Helper loaded: url_helper
INFO - 2018-07-01 18:04:23 --> Helper loaded: form_helper
INFO - 2018-07-01 18:04:23 --> Helper loaded: language_helper
DEBUG - 2018-07-01 18:04:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-01 18:04:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-01 18:04:23 --> User Agent Class Initialized
INFO - 2018-07-01 18:04:23 --> Controller Class Initialized
INFO - 2018-07-01 18:04:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-01 18:04:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-01 18:04:23 --> Pixel_Model class loaded
INFO - 2018-07-01 18:04:23 --> Database Driver Class Initialized
INFO - 2018-07-01 18:04:23 --> Model "QuestionsModel" initialized
INFO - 2018-07-01 18:04:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-01 18:04:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-01 18:04:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-01 18:04:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-01 18:04:23 --> Final output sent to browser
DEBUG - 2018-07-01 18:04:23 --> Total execution time: 0.0363
INFO - 2018-07-01 18:04:40 --> Config Class Initialized
INFO - 2018-07-01 18:04:40 --> Hooks Class Initialized
DEBUG - 2018-07-01 18:04:40 --> UTF-8 Support Enabled
INFO - 2018-07-01 18:04:40 --> Utf8 Class Initialized
INFO - 2018-07-01 18:04:40 --> URI Class Initialized
INFO - 2018-07-01 18:04:40 --> Router Class Initialized
INFO - 2018-07-01 18:04:40 --> Output Class Initialized
INFO - 2018-07-01 18:04:40 --> Security Class Initialized
DEBUG - 2018-07-01 18:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-01 18:04:40 --> CSRF cookie sent
INFO - 2018-07-01 18:04:40 --> Input Class Initialized
INFO - 2018-07-01 18:04:40 --> Language Class Initialized
ERROR - 2018-07-01 18:04:40 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-01 18:04:41 --> Config Class Initialized
INFO - 2018-07-01 18:04:41 --> Hooks Class Initialized
DEBUG - 2018-07-01 18:04:41 --> UTF-8 Support Enabled
INFO - 2018-07-01 18:04:41 --> Utf8 Class Initialized
INFO - 2018-07-01 18:04:41 --> URI Class Initialized
DEBUG - 2018-07-01 18:04:41 --> No URI present. Default controller set.
INFO - 2018-07-01 18:04:41 --> Router Class Initialized
INFO - 2018-07-01 18:04:41 --> Output Class Initialized
INFO - 2018-07-01 18:04:41 --> Security Class Initialized
DEBUG - 2018-07-01 18:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-01 18:04:41 --> CSRF cookie sent
INFO - 2018-07-01 18:04:41 --> Input Class Initialized
INFO - 2018-07-01 18:04:41 --> Language Class Initialized
INFO - 2018-07-01 18:04:41 --> Loader Class Initialized
INFO - 2018-07-01 18:04:41 --> Helper loaded: url_helper
INFO - 2018-07-01 18:04:41 --> Helper loaded: form_helper
INFO - 2018-07-01 18:04:41 --> Helper loaded: language_helper
DEBUG - 2018-07-01 18:04:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-01 18:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-01 18:04:41 --> User Agent Class Initialized
INFO - 2018-07-01 18:04:41 --> Controller Class Initialized
INFO - 2018-07-01 18:04:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-01 18:04:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-01 18:04:41 --> Pixel_Model class loaded
INFO - 2018-07-01 18:04:41 --> Database Driver Class Initialized
INFO - 2018-07-01 18:04:41 --> Model "QuestionsModel" initialized
INFO - 2018-07-01 18:04:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-01 18:04:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-01 18:04:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-01 18:04:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-01 18:04:41 --> Final output sent to browser
DEBUG - 2018-07-01 18:04:41 --> Total execution time: 0.0362
INFO - 2018-07-01 20:47:28 --> Config Class Initialized
INFO - 2018-07-01 20:47:28 --> Hooks Class Initialized
DEBUG - 2018-07-01 20:47:28 --> UTF-8 Support Enabled
INFO - 2018-07-01 20:47:28 --> Utf8 Class Initialized
INFO - 2018-07-01 20:47:28 --> URI Class Initialized
DEBUG - 2018-07-01 20:47:28 --> No URI present. Default controller set.
INFO - 2018-07-01 20:47:28 --> Router Class Initialized
INFO - 2018-07-01 20:47:28 --> Output Class Initialized
INFO - 2018-07-01 20:47:28 --> Security Class Initialized
DEBUG - 2018-07-01 20:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-01 20:47:28 --> CSRF cookie sent
INFO - 2018-07-01 20:47:28 --> Input Class Initialized
INFO - 2018-07-01 20:47:28 --> Language Class Initialized
INFO - 2018-07-01 20:47:28 --> Loader Class Initialized
INFO - 2018-07-01 20:47:28 --> Helper loaded: url_helper
INFO - 2018-07-01 20:47:28 --> Helper loaded: form_helper
INFO - 2018-07-01 20:47:28 --> Helper loaded: language_helper
DEBUG - 2018-07-01 20:47:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-01 20:47:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-01 20:47:28 --> User Agent Class Initialized
INFO - 2018-07-01 20:47:28 --> Controller Class Initialized
INFO - 2018-07-01 20:47:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-01 20:47:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-01 20:47:28 --> Pixel_Model class loaded
INFO - 2018-07-01 20:47:28 --> Database Driver Class Initialized
INFO - 2018-07-01 20:47:28 --> Model "QuestionsModel" initialized
INFO - 2018-07-01 20:47:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-01 20:47:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-01 20:47:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-01 20:47:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-01 20:47:28 --> Final output sent to browser
DEBUG - 2018-07-01 20:47:28 --> Total execution time: 0.0368
INFO - 2018-07-01 20:47:29 --> Config Class Initialized
INFO - 2018-07-01 20:47:29 --> Hooks Class Initialized
DEBUG - 2018-07-01 20:47:29 --> UTF-8 Support Enabled
INFO - 2018-07-01 20:47:29 --> Utf8 Class Initialized
INFO - 2018-07-01 20:47:29 --> URI Class Initialized
INFO - 2018-07-01 20:47:29 --> Router Class Initialized
INFO - 2018-07-01 20:47:29 --> Output Class Initialized
INFO - 2018-07-01 20:47:29 --> Security Class Initialized
DEBUG - 2018-07-01 20:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-01 20:47:29 --> CSRF cookie sent
INFO - 2018-07-01 20:47:29 --> Input Class Initialized
INFO - 2018-07-01 20:47:29 --> Language Class Initialized
ERROR - 2018-07-01 20:47:29 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-01 21:01:15 --> Config Class Initialized
INFO - 2018-07-01 21:01:15 --> Hooks Class Initialized
DEBUG - 2018-07-01 21:01:15 --> UTF-8 Support Enabled
INFO - 2018-07-01 21:01:15 --> Utf8 Class Initialized
INFO - 2018-07-01 21:01:15 --> URI Class Initialized
INFO - 2018-07-01 21:01:15 --> Router Class Initialized
INFO - 2018-07-01 21:01:15 --> Output Class Initialized
INFO - 2018-07-01 21:01:15 --> Security Class Initialized
DEBUG - 2018-07-01 21:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-01 21:01:15 --> CSRF cookie sent
INFO - 2018-07-01 21:01:15 --> Input Class Initialized
INFO - 2018-07-01 21:01:15 --> Language Class Initialized
ERROR - 2018-07-01 21:01:15 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-01 21:01:18 --> Config Class Initialized
INFO - 2018-07-01 21:01:18 --> Hooks Class Initialized
DEBUG - 2018-07-01 21:01:18 --> UTF-8 Support Enabled
INFO - 2018-07-01 21:01:18 --> Utf8 Class Initialized
INFO - 2018-07-01 21:01:18 --> URI Class Initialized
INFO - 2018-07-01 21:01:18 --> Router Class Initialized
INFO - 2018-07-01 21:01:18 --> Output Class Initialized
INFO - 2018-07-01 21:01:18 --> Security Class Initialized
DEBUG - 2018-07-01 21:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-01 21:01:18 --> CSRF cookie sent
INFO - 2018-07-01 21:01:18 --> Input Class Initialized
INFO - 2018-07-01 21:01:18 --> Language Class Initialized
INFO - 2018-07-01 21:01:18 --> Loader Class Initialized
INFO - 2018-07-01 21:01:18 --> Helper loaded: url_helper
INFO - 2018-07-01 21:01:18 --> Helper loaded: form_helper
INFO - 2018-07-01 21:01:18 --> Helper loaded: language_helper
DEBUG - 2018-07-01 21:01:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-01 21:01:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-01 21:01:18 --> User Agent Class Initialized
INFO - 2018-07-01 21:01:18 --> Controller Class Initialized
INFO - 2018-07-01 21:01:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-01 21:01:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-01 21:01:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-01 21:01:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-01 21:01:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-01 21:01:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-01 21:01:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/finance.php
INFO - 2018-07-01 21:01:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-01 21:01:18 --> Final output sent to browser
DEBUG - 2018-07-01 21:01:18 --> Total execution time: 0.0240
INFO - 2018-07-01 22:41:52 --> Config Class Initialized
INFO - 2018-07-01 22:41:52 --> Hooks Class Initialized
DEBUG - 2018-07-01 22:41:52 --> UTF-8 Support Enabled
INFO - 2018-07-01 22:41:52 --> Utf8 Class Initialized
INFO - 2018-07-01 22:41:52 --> URI Class Initialized
INFO - 2018-07-01 22:41:52 --> Router Class Initialized
INFO - 2018-07-01 22:41:52 --> Output Class Initialized
INFO - 2018-07-01 22:41:52 --> Security Class Initialized
DEBUG - 2018-07-01 22:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-01 22:41:52 --> CSRF cookie sent
INFO - 2018-07-01 22:41:52 --> Input Class Initialized
INFO - 2018-07-01 22:41:52 --> Language Class Initialized
INFO - 2018-07-01 22:41:52 --> Loader Class Initialized
INFO - 2018-07-01 22:41:52 --> Helper loaded: url_helper
INFO - 2018-07-01 22:41:52 --> Helper loaded: form_helper
INFO - 2018-07-01 22:41:52 --> Helper loaded: language_helper
DEBUG - 2018-07-01 22:41:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-01 22:41:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-01 22:41:52 --> User Agent Class Initialized
INFO - 2018-07-01 22:41:52 --> Controller Class Initialized
INFO - 2018-07-01 22:41:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-01 22:41:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-01 22:41:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-01 22:41:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-01 22:41:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-01 22:41:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-01 22:41:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/911.php
INFO - 2018-07-01 22:41:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-01 22:41:52 --> Final output sent to browser
DEBUG - 2018-07-01 22:41:52 --> Total execution time: 0.0218

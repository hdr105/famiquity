<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-07-06 00:18:08 --> Config Class Initialized
INFO - 2018-07-06 00:18:08 --> Hooks Class Initialized
DEBUG - 2018-07-06 00:18:08 --> UTF-8 Support Enabled
INFO - 2018-07-06 00:18:08 --> Utf8 Class Initialized
INFO - 2018-07-06 00:18:08 --> URI Class Initialized
INFO - 2018-07-06 00:18:08 --> Router Class Initialized
INFO - 2018-07-06 00:18:08 --> Output Class Initialized
INFO - 2018-07-06 00:18:08 --> Security Class Initialized
DEBUG - 2018-07-06 00:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-06 00:18:08 --> CSRF cookie sent
INFO - 2018-07-06 00:18:08 --> Input Class Initialized
INFO - 2018-07-06 00:18:08 --> Language Class Initialized
ERROR - 2018-07-06 00:18:08 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-06 00:18:08 --> Config Class Initialized
INFO - 2018-07-06 00:18:08 --> Hooks Class Initialized
DEBUG - 2018-07-06 00:18:08 --> UTF-8 Support Enabled
INFO - 2018-07-06 00:18:08 --> Utf8 Class Initialized
INFO - 2018-07-06 00:18:08 --> URI Class Initialized
INFO - 2018-07-06 00:18:08 --> Router Class Initialized
INFO - 2018-07-06 00:18:08 --> Output Class Initialized
INFO - 2018-07-06 00:18:08 --> Security Class Initialized
DEBUG - 2018-07-06 00:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-06 00:18:08 --> CSRF cookie sent
INFO - 2018-07-06 00:18:08 --> Input Class Initialized
INFO - 2018-07-06 00:18:08 --> Language Class Initialized
ERROR - 2018-07-06 00:18:08 --> 404 Page Not Found: Well-known/assetlinks.json
INFO - 2018-07-06 01:29:27 --> Config Class Initialized
INFO - 2018-07-06 01:29:27 --> Hooks Class Initialized
DEBUG - 2018-07-06 01:29:27 --> UTF-8 Support Enabled
INFO - 2018-07-06 01:29:27 --> Utf8 Class Initialized
INFO - 2018-07-06 01:29:27 --> URI Class Initialized
INFO - 2018-07-06 01:29:27 --> Router Class Initialized
INFO - 2018-07-06 01:29:27 --> Output Class Initialized
INFO - 2018-07-06 01:29:27 --> Security Class Initialized
DEBUG - 2018-07-06 01:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-06 01:29:27 --> CSRF cookie sent
INFO - 2018-07-06 01:29:27 --> Input Class Initialized
INFO - 2018-07-06 01:29:27 --> Language Class Initialized
INFO - 2018-07-06 01:29:27 --> Loader Class Initialized
INFO - 2018-07-06 01:29:27 --> Helper loaded: url_helper
INFO - 2018-07-06 01:29:27 --> Helper loaded: form_helper
INFO - 2018-07-06 01:29:27 --> Helper loaded: language_helper
DEBUG - 2018-07-06 01:29:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-06 01:29:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-06 01:29:27 --> User Agent Class Initialized
INFO - 2018-07-06 01:29:27 --> Controller Class Initialized
INFO - 2018-07-06 01:29:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-06 01:29:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-06 01:29:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-06 01:29:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-06 01:29:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-06 01:29:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-06 01:29:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-07-06 01:29:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-06 01:29:27 --> Final output sent to browser
DEBUG - 2018-07-06 01:29:27 --> Total execution time: 0.0237
INFO - 2018-07-06 02:57:47 --> Config Class Initialized
INFO - 2018-07-06 02:57:47 --> Hooks Class Initialized
DEBUG - 2018-07-06 02:57:47 --> UTF-8 Support Enabled
INFO - 2018-07-06 02:57:47 --> Utf8 Class Initialized
INFO - 2018-07-06 02:57:47 --> URI Class Initialized
DEBUG - 2018-07-06 02:57:47 --> No URI present. Default controller set.
INFO - 2018-07-06 02:57:47 --> Router Class Initialized
INFO - 2018-07-06 02:57:47 --> Output Class Initialized
INFO - 2018-07-06 02:57:47 --> Security Class Initialized
DEBUG - 2018-07-06 02:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-06 02:57:47 --> CSRF cookie sent
INFO - 2018-07-06 02:57:47 --> Input Class Initialized
INFO - 2018-07-06 02:57:47 --> Language Class Initialized
INFO - 2018-07-06 02:57:47 --> Loader Class Initialized
INFO - 2018-07-06 02:57:47 --> Helper loaded: url_helper
INFO - 2018-07-06 02:57:47 --> Helper loaded: form_helper
INFO - 2018-07-06 02:57:47 --> Helper loaded: language_helper
DEBUG - 2018-07-06 02:57:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-06 02:57:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-06 02:57:47 --> User Agent Class Initialized
INFO - 2018-07-06 02:57:47 --> Controller Class Initialized
INFO - 2018-07-06 02:57:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-06 02:57:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-06 02:57:47 --> Pixel_Model class loaded
INFO - 2018-07-06 02:57:47 --> Database Driver Class Initialized
INFO - 2018-07-06 02:57:47 --> Model "QuestionsModel" initialized
INFO - 2018-07-06 02:57:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-06 02:57:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-06 02:57:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-06 02:57:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-06 02:57:47 --> Final output sent to browser
DEBUG - 2018-07-06 02:57:47 --> Total execution time: 0.0329
INFO - 2018-07-06 03:46:29 --> Config Class Initialized
INFO - 2018-07-06 03:46:29 --> Hooks Class Initialized
DEBUG - 2018-07-06 03:46:29 --> UTF-8 Support Enabled
INFO - 2018-07-06 03:46:29 --> Utf8 Class Initialized
INFO - 2018-07-06 03:46:29 --> URI Class Initialized
INFO - 2018-07-06 03:46:29 --> Router Class Initialized
INFO - 2018-07-06 03:46:29 --> Output Class Initialized
INFO - 2018-07-06 03:46:29 --> Security Class Initialized
DEBUG - 2018-07-06 03:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-06 03:46:29 --> CSRF cookie sent
INFO - 2018-07-06 03:46:29 --> Input Class Initialized
INFO - 2018-07-06 03:46:29 --> Language Class Initialized
INFO - 2018-07-06 03:46:29 --> Loader Class Initialized
INFO - 2018-07-06 03:46:29 --> Helper loaded: url_helper
INFO - 2018-07-06 03:46:29 --> Helper loaded: form_helper
INFO - 2018-07-06 03:46:29 --> Helper loaded: language_helper
DEBUG - 2018-07-06 03:46:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-06 03:46:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-06 03:46:29 --> User Agent Class Initialized
INFO - 2018-07-06 03:46:29 --> Controller Class Initialized
INFO - 2018-07-06 03:46:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-06 03:46:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-06 03:46:29 --> Pixel_Model class loaded
INFO - 2018-07-06 03:46:29 --> Database Driver Class Initialized
INFO - 2018-07-06 03:46:29 --> Model "QuestionsModel" initialized
INFO - 2018-07-06 03:46:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-06 03:46:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-06 03:46:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-06 03:46:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-06 03:46:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/buy_gift.php
INFO - 2018-07-06 03:46:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-06 03:46:29 --> Final output sent to browser
DEBUG - 2018-07-06 03:46:29 --> Total execution time: 0.0340
INFO - 2018-07-06 04:57:50 --> Config Class Initialized
INFO - 2018-07-06 04:57:50 --> Hooks Class Initialized
DEBUG - 2018-07-06 04:57:50 --> UTF-8 Support Enabled
INFO - 2018-07-06 04:57:50 --> Utf8 Class Initialized
INFO - 2018-07-06 04:57:50 --> URI Class Initialized
INFO - 2018-07-06 04:57:50 --> Router Class Initialized
INFO - 2018-07-06 04:57:50 --> Output Class Initialized
INFO - 2018-07-06 04:57:50 --> Security Class Initialized
DEBUG - 2018-07-06 04:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-06 04:57:50 --> CSRF cookie sent
INFO - 2018-07-06 04:57:50 --> Input Class Initialized
INFO - 2018-07-06 04:57:50 --> Language Class Initialized
ERROR - 2018-07-06 04:57:50 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-06 04:57:51 --> Config Class Initialized
INFO - 2018-07-06 04:57:51 --> Hooks Class Initialized
DEBUG - 2018-07-06 04:57:51 --> UTF-8 Support Enabled
INFO - 2018-07-06 04:57:51 --> Utf8 Class Initialized
INFO - 2018-07-06 04:57:51 --> URI Class Initialized
DEBUG - 2018-07-06 04:57:51 --> No URI present. Default controller set.
INFO - 2018-07-06 04:57:51 --> Router Class Initialized
INFO - 2018-07-06 04:57:51 --> Output Class Initialized
INFO - 2018-07-06 04:57:51 --> Security Class Initialized
DEBUG - 2018-07-06 04:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-06 04:57:51 --> CSRF cookie sent
INFO - 2018-07-06 04:57:51 --> Input Class Initialized
INFO - 2018-07-06 04:57:51 --> Language Class Initialized
INFO - 2018-07-06 04:57:51 --> Loader Class Initialized
INFO - 2018-07-06 04:57:51 --> Helper loaded: url_helper
INFO - 2018-07-06 04:57:51 --> Helper loaded: form_helper
INFO - 2018-07-06 04:57:51 --> Helper loaded: language_helper
DEBUG - 2018-07-06 04:57:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-06 04:57:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-06 04:57:51 --> User Agent Class Initialized
INFO - 2018-07-06 04:57:51 --> Controller Class Initialized
INFO - 2018-07-06 04:57:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-06 04:57:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-06 04:57:51 --> Pixel_Model class loaded
INFO - 2018-07-06 04:57:51 --> Database Driver Class Initialized
INFO - 2018-07-06 04:57:51 --> Model "QuestionsModel" initialized
INFO - 2018-07-06 04:57:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-06 04:57:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-06 04:57:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-06 04:57:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-06 04:57:51 --> Final output sent to browser
DEBUG - 2018-07-06 04:57:51 --> Total execution time: 0.0304
INFO - 2018-07-06 06:14:41 --> Config Class Initialized
INFO - 2018-07-06 06:14:41 --> Hooks Class Initialized
DEBUG - 2018-07-06 06:14:41 --> UTF-8 Support Enabled
INFO - 2018-07-06 06:14:41 --> Utf8 Class Initialized
INFO - 2018-07-06 06:14:41 --> URI Class Initialized
DEBUG - 2018-07-06 06:14:41 --> No URI present. Default controller set.
INFO - 2018-07-06 06:14:41 --> Router Class Initialized
INFO - 2018-07-06 06:14:41 --> Output Class Initialized
INFO - 2018-07-06 06:14:41 --> Security Class Initialized
DEBUG - 2018-07-06 06:14:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-06 06:14:41 --> CSRF cookie sent
INFO - 2018-07-06 06:14:41 --> Input Class Initialized
INFO - 2018-07-06 06:14:41 --> Language Class Initialized
INFO - 2018-07-06 06:14:41 --> Loader Class Initialized
INFO - 2018-07-06 06:14:41 --> Helper loaded: url_helper
INFO - 2018-07-06 06:14:41 --> Helper loaded: form_helper
INFO - 2018-07-06 06:14:41 --> Helper loaded: language_helper
DEBUG - 2018-07-06 06:14:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-06 06:14:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-06 06:14:41 --> User Agent Class Initialized
INFO - 2018-07-06 06:14:41 --> Controller Class Initialized
INFO - 2018-07-06 06:14:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-06 06:14:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-06 06:14:41 --> Pixel_Model class loaded
INFO - 2018-07-06 06:14:41 --> Database Driver Class Initialized
INFO - 2018-07-06 06:14:41 --> Model "QuestionsModel" initialized
INFO - 2018-07-06 06:14:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-06 06:14:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-06 06:14:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-06 06:14:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-06 06:14:41 --> Final output sent to browser
DEBUG - 2018-07-06 06:14:41 --> Total execution time: 0.0347
INFO - 2018-07-06 09:01:06 --> Config Class Initialized
INFO - 2018-07-06 09:01:06 --> Hooks Class Initialized
DEBUG - 2018-07-06 09:01:06 --> UTF-8 Support Enabled
INFO - 2018-07-06 09:01:06 --> Utf8 Class Initialized
INFO - 2018-07-06 09:01:06 --> URI Class Initialized
DEBUG - 2018-07-06 09:01:06 --> No URI present. Default controller set.
INFO - 2018-07-06 09:01:06 --> Router Class Initialized
INFO - 2018-07-06 09:01:06 --> Output Class Initialized
INFO - 2018-07-06 09:01:06 --> Security Class Initialized
DEBUG - 2018-07-06 09:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-06 09:01:06 --> CSRF cookie sent
INFO - 2018-07-06 09:01:06 --> Input Class Initialized
INFO - 2018-07-06 09:01:06 --> Language Class Initialized
INFO - 2018-07-06 09:01:06 --> Loader Class Initialized
INFO - 2018-07-06 09:01:06 --> Helper loaded: url_helper
INFO - 2018-07-06 09:01:06 --> Helper loaded: form_helper
INFO - 2018-07-06 09:01:06 --> Helper loaded: language_helper
DEBUG - 2018-07-06 09:01:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-06 09:01:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-06 09:01:06 --> User Agent Class Initialized
INFO - 2018-07-06 09:01:06 --> Controller Class Initialized
INFO - 2018-07-06 09:01:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-06 09:01:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-06 09:01:06 --> Pixel_Model class loaded
INFO - 2018-07-06 09:01:06 --> Database Driver Class Initialized
INFO - 2018-07-06 09:01:06 --> Model "QuestionsModel" initialized
INFO - 2018-07-06 09:01:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-06 09:01:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-06 09:01:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-06 09:01:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-06 09:01:06 --> Final output sent to browser
DEBUG - 2018-07-06 09:01:06 --> Total execution time: 0.0348
INFO - 2018-07-06 09:48:51 --> Config Class Initialized
INFO - 2018-07-06 09:48:51 --> Hooks Class Initialized
DEBUG - 2018-07-06 09:48:51 --> UTF-8 Support Enabled
INFO - 2018-07-06 09:48:51 --> Utf8 Class Initialized
INFO - 2018-07-06 09:48:51 --> URI Class Initialized
DEBUG - 2018-07-06 09:48:51 --> No URI present. Default controller set.
INFO - 2018-07-06 09:48:51 --> Router Class Initialized
INFO - 2018-07-06 09:48:51 --> Output Class Initialized
INFO - 2018-07-06 09:48:51 --> Security Class Initialized
DEBUG - 2018-07-06 09:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-06 09:48:51 --> CSRF cookie sent
INFO - 2018-07-06 09:48:51 --> Input Class Initialized
INFO - 2018-07-06 09:48:51 --> Language Class Initialized
INFO - 2018-07-06 09:48:51 --> Loader Class Initialized
INFO - 2018-07-06 09:48:51 --> Helper loaded: url_helper
INFO - 2018-07-06 09:48:51 --> Helper loaded: form_helper
INFO - 2018-07-06 09:48:51 --> Helper loaded: language_helper
DEBUG - 2018-07-06 09:48:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-06 09:48:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-06 09:48:51 --> User Agent Class Initialized
INFO - 2018-07-06 09:48:51 --> Controller Class Initialized
INFO - 2018-07-06 09:48:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-06 09:48:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-06 09:48:51 --> Pixel_Model class loaded
INFO - 2018-07-06 09:48:51 --> Database Driver Class Initialized
INFO - 2018-07-06 09:48:51 --> Model "QuestionsModel" initialized
INFO - 2018-07-06 09:48:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-06 09:48:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-06 09:48:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-06 09:48:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-06 09:48:51 --> Final output sent to browser
DEBUG - 2018-07-06 09:48:51 --> Total execution time: 0.0358
INFO - 2018-07-06 09:54:22 --> Config Class Initialized
INFO - 2018-07-06 09:54:22 --> Hooks Class Initialized
DEBUG - 2018-07-06 09:54:22 --> UTF-8 Support Enabled
INFO - 2018-07-06 09:54:22 --> Utf8 Class Initialized
INFO - 2018-07-06 09:54:22 --> URI Class Initialized
INFO - 2018-07-06 09:54:22 --> Router Class Initialized
INFO - 2018-07-06 09:54:22 --> Output Class Initialized
INFO - 2018-07-06 09:54:22 --> Security Class Initialized
DEBUG - 2018-07-06 09:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-06 09:54:22 --> CSRF cookie sent
INFO - 2018-07-06 09:54:22 --> Input Class Initialized
INFO - 2018-07-06 09:54:22 --> Language Class Initialized
ERROR - 2018-07-06 09:54:22 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-06 09:54:25 --> Config Class Initialized
INFO - 2018-07-06 09:54:25 --> Hooks Class Initialized
DEBUG - 2018-07-06 09:54:25 --> UTF-8 Support Enabled
INFO - 2018-07-06 09:54:25 --> Utf8 Class Initialized
INFO - 2018-07-06 09:54:25 --> URI Class Initialized
INFO - 2018-07-06 09:54:25 --> Router Class Initialized
INFO - 2018-07-06 09:54:25 --> Output Class Initialized
INFO - 2018-07-06 09:54:25 --> Security Class Initialized
DEBUG - 2018-07-06 09:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-06 09:54:25 --> CSRF cookie sent
INFO - 2018-07-06 09:54:25 --> Input Class Initialized
INFO - 2018-07-06 09:54:25 --> Language Class Initialized
INFO - 2018-07-06 09:54:25 --> Loader Class Initialized
INFO - 2018-07-06 09:54:25 --> Helper loaded: url_helper
INFO - 2018-07-06 09:54:26 --> Helper loaded: form_helper
INFO - 2018-07-06 09:54:26 --> Helper loaded: language_helper
DEBUG - 2018-07-06 09:54:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-06 09:54:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-06 09:54:26 --> User Agent Class Initialized
INFO - 2018-07-06 09:54:26 --> Controller Class Initialized
INFO - 2018-07-06 09:54:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-06 09:54:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-06 09:54:26 --> Pixel_Model class loaded
INFO - 2018-07-06 09:54:26 --> Database Driver Class Initialized
INFO - 2018-07-06 09:54:26 --> Model "RegistrationModel" initialized
DEBUG - 2018-07-06 09:54:26 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-06 09:54:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-06 09:54:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-06 09:54:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-06 09:54:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-06 09:54:26 --> Could not find the language line "req_email"
INFO - 2018-07-06 09:54:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup_fa.php
INFO - 2018-07-06 09:54:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-06 09:54:26 --> Final output sent to browser
DEBUG - 2018-07-06 09:54:26 --> Total execution time: 0.0351
INFO - 2018-07-06 10:19:03 --> Config Class Initialized
INFO - 2018-07-06 10:19:03 --> Hooks Class Initialized
DEBUG - 2018-07-06 10:19:03 --> UTF-8 Support Enabled
INFO - 2018-07-06 10:19:03 --> Utf8 Class Initialized
INFO - 2018-07-06 10:19:03 --> URI Class Initialized
INFO - 2018-07-06 10:19:03 --> Router Class Initialized
INFO - 2018-07-06 10:19:03 --> Output Class Initialized
INFO - 2018-07-06 10:19:03 --> Security Class Initialized
DEBUG - 2018-07-06 10:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-06 10:19:03 --> CSRF cookie sent
INFO - 2018-07-06 10:19:03 --> Input Class Initialized
INFO - 2018-07-06 10:19:03 --> Language Class Initialized
INFO - 2018-07-06 10:19:03 --> Loader Class Initialized
INFO - 2018-07-06 10:19:03 --> Helper loaded: url_helper
INFO - 2018-07-06 10:19:03 --> Helper loaded: form_helper
INFO - 2018-07-06 10:19:03 --> Helper loaded: language_helper
DEBUG - 2018-07-06 10:19:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-06 10:19:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-06 10:19:03 --> User Agent Class Initialized
INFO - 2018-07-06 10:19:03 --> Controller Class Initialized
INFO - 2018-07-06 10:19:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-06 10:19:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-06 10:19:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-06 10:19:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-06 10:19:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-06 10:19:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-06 10:19:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-07-06 10:19:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-06 10:19:03 --> Final output sent to browser
DEBUG - 2018-07-06 10:19:03 --> Total execution time: 0.0214
INFO - 2018-07-06 11:03:08 --> Config Class Initialized
INFO - 2018-07-06 11:03:08 --> Hooks Class Initialized
DEBUG - 2018-07-06 11:03:08 --> UTF-8 Support Enabled
INFO - 2018-07-06 11:03:08 --> Utf8 Class Initialized
INFO - 2018-07-06 11:03:08 --> URI Class Initialized
DEBUG - 2018-07-06 11:03:08 --> No URI present. Default controller set.
INFO - 2018-07-06 11:03:08 --> Router Class Initialized
INFO - 2018-07-06 11:03:08 --> Output Class Initialized
INFO - 2018-07-06 11:03:08 --> Security Class Initialized
DEBUG - 2018-07-06 11:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-06 11:03:08 --> CSRF cookie sent
INFO - 2018-07-06 11:03:08 --> Input Class Initialized
INFO - 2018-07-06 11:03:08 --> Language Class Initialized
INFO - 2018-07-06 11:03:08 --> Loader Class Initialized
INFO - 2018-07-06 11:03:08 --> Helper loaded: url_helper
INFO - 2018-07-06 11:03:08 --> Helper loaded: form_helper
INFO - 2018-07-06 11:03:08 --> Helper loaded: language_helper
DEBUG - 2018-07-06 11:03:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-06 11:03:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-06 11:03:08 --> User Agent Class Initialized
INFO - 2018-07-06 11:03:08 --> Controller Class Initialized
INFO - 2018-07-06 11:03:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-06 11:03:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-06 11:03:08 --> Pixel_Model class loaded
INFO - 2018-07-06 11:03:08 --> Database Driver Class Initialized
INFO - 2018-07-06 11:03:08 --> Model "QuestionsModel" initialized
INFO - 2018-07-06 11:03:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-06 11:03:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-06 11:03:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-06 11:03:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-06 11:03:08 --> Final output sent to browser
DEBUG - 2018-07-06 11:03:08 --> Total execution time: 0.0329
INFO - 2018-07-06 11:32:44 --> Config Class Initialized
INFO - 2018-07-06 11:32:44 --> Hooks Class Initialized
DEBUG - 2018-07-06 11:32:44 --> UTF-8 Support Enabled
INFO - 2018-07-06 11:32:44 --> Utf8 Class Initialized
INFO - 2018-07-06 11:32:44 --> URI Class Initialized
DEBUG - 2018-07-06 11:32:44 --> No URI present. Default controller set.
INFO - 2018-07-06 11:32:44 --> Router Class Initialized
INFO - 2018-07-06 11:32:44 --> Output Class Initialized
INFO - 2018-07-06 11:32:44 --> Security Class Initialized
DEBUG - 2018-07-06 11:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-06 11:32:44 --> CSRF cookie sent
INFO - 2018-07-06 11:32:44 --> Input Class Initialized
INFO - 2018-07-06 11:32:44 --> Language Class Initialized
INFO - 2018-07-06 11:32:44 --> Loader Class Initialized
INFO - 2018-07-06 11:32:44 --> Helper loaded: url_helper
INFO - 2018-07-06 11:32:44 --> Helper loaded: form_helper
INFO - 2018-07-06 11:32:44 --> Helper loaded: language_helper
DEBUG - 2018-07-06 11:32:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-06 11:32:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-06 11:32:44 --> User Agent Class Initialized
INFO - 2018-07-06 11:32:44 --> Controller Class Initialized
INFO - 2018-07-06 11:32:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-06 11:32:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-06 11:32:44 --> Pixel_Model class loaded
INFO - 2018-07-06 11:32:44 --> Database Driver Class Initialized
INFO - 2018-07-06 11:32:44 --> Model "QuestionsModel" initialized
INFO - 2018-07-06 11:32:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-06 11:32:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-06 11:32:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-06 11:32:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-06 11:32:44 --> Final output sent to browser
DEBUG - 2018-07-06 11:32:44 --> Total execution time: 0.0295
INFO - 2018-07-06 12:13:56 --> Config Class Initialized
INFO - 2018-07-06 12:13:56 --> Hooks Class Initialized
DEBUG - 2018-07-06 12:13:56 --> UTF-8 Support Enabled
INFO - 2018-07-06 12:13:56 --> Utf8 Class Initialized
INFO - 2018-07-06 12:13:56 --> URI Class Initialized
DEBUG - 2018-07-06 12:13:56 --> No URI present. Default controller set.
INFO - 2018-07-06 12:13:56 --> Router Class Initialized
INFO - 2018-07-06 12:13:56 --> Output Class Initialized
INFO - 2018-07-06 12:13:56 --> Security Class Initialized
DEBUG - 2018-07-06 12:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-06 12:13:56 --> CSRF cookie sent
INFO - 2018-07-06 12:13:56 --> Input Class Initialized
INFO - 2018-07-06 12:13:56 --> Language Class Initialized
INFO - 2018-07-06 12:13:56 --> Loader Class Initialized
INFO - 2018-07-06 12:13:56 --> Helper loaded: url_helper
INFO - 2018-07-06 12:13:56 --> Helper loaded: form_helper
INFO - 2018-07-06 12:13:56 --> Helper loaded: language_helper
DEBUG - 2018-07-06 12:13:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-06 12:13:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-06 12:13:56 --> User Agent Class Initialized
INFO - 2018-07-06 12:13:56 --> Controller Class Initialized
INFO - 2018-07-06 12:13:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-06 12:13:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-06 12:13:56 --> Pixel_Model class loaded
INFO - 2018-07-06 12:13:56 --> Database Driver Class Initialized
INFO - 2018-07-06 12:13:56 --> Model "QuestionsModel" initialized
INFO - 2018-07-06 12:13:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-06 12:13:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-06 12:13:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-06 12:13:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-06 12:13:56 --> Final output sent to browser
DEBUG - 2018-07-06 12:13:56 --> Total execution time: 0.0471
INFO - 2018-07-06 12:45:47 --> Config Class Initialized
INFO - 2018-07-06 12:45:47 --> Hooks Class Initialized
DEBUG - 2018-07-06 12:45:47 --> UTF-8 Support Enabled
INFO - 2018-07-06 12:45:47 --> Utf8 Class Initialized
INFO - 2018-07-06 12:45:47 --> URI Class Initialized
INFO - 2018-07-06 12:45:47 --> Router Class Initialized
INFO - 2018-07-06 12:45:47 --> Output Class Initialized
INFO - 2018-07-06 12:45:47 --> Security Class Initialized
DEBUG - 2018-07-06 12:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-06 12:45:47 --> CSRF cookie sent
INFO - 2018-07-06 12:45:47 --> Input Class Initialized
INFO - 2018-07-06 12:45:47 --> Language Class Initialized
ERROR - 2018-07-06 12:45:47 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-06 12:45:51 --> Config Class Initialized
INFO - 2018-07-06 12:45:51 --> Hooks Class Initialized
DEBUG - 2018-07-06 12:45:51 --> UTF-8 Support Enabled
INFO - 2018-07-06 12:45:51 --> Utf8 Class Initialized
INFO - 2018-07-06 12:45:51 --> URI Class Initialized
INFO - 2018-07-06 12:45:51 --> Router Class Initialized
INFO - 2018-07-06 12:45:51 --> Output Class Initialized
INFO - 2018-07-06 12:45:51 --> Security Class Initialized
DEBUG - 2018-07-06 12:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-06 12:45:51 --> CSRF cookie sent
INFO - 2018-07-06 12:45:51 --> Input Class Initialized
INFO - 2018-07-06 12:45:51 --> Language Class Initialized
INFO - 2018-07-06 12:45:51 --> Loader Class Initialized
INFO - 2018-07-06 12:45:51 --> Helper loaded: url_helper
INFO - 2018-07-06 12:45:51 --> Helper loaded: form_helper
INFO - 2018-07-06 12:45:51 --> Helper loaded: language_helper
DEBUG - 2018-07-06 12:45:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-06 12:45:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-06 12:45:51 --> User Agent Class Initialized
INFO - 2018-07-06 12:45:51 --> Controller Class Initialized
INFO - 2018-07-06 12:45:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-06 12:45:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-06 12:45:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-06 12:45:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-06 12:45:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-06 12:45:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-06 12:45:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-07-06 12:45:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-06 12:45:51 --> Final output sent to browser
DEBUG - 2018-07-06 12:45:51 --> Total execution time: 0.0247
INFO - 2018-07-06 13:20:07 --> Config Class Initialized
INFO - 2018-07-06 13:20:07 --> Hooks Class Initialized
DEBUG - 2018-07-06 13:20:07 --> UTF-8 Support Enabled
INFO - 2018-07-06 13:20:07 --> Utf8 Class Initialized
INFO - 2018-07-06 13:20:07 --> URI Class Initialized
INFO - 2018-07-06 13:20:07 --> Router Class Initialized
INFO - 2018-07-06 13:20:07 --> Output Class Initialized
INFO - 2018-07-06 13:20:07 --> Security Class Initialized
DEBUG - 2018-07-06 13:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-06 13:20:07 --> CSRF cookie sent
INFO - 2018-07-06 13:20:07 --> Input Class Initialized
INFO - 2018-07-06 13:20:07 --> Language Class Initialized
ERROR - 2018-07-06 13:20:07 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-06 13:20:08 --> Config Class Initialized
INFO - 2018-07-06 13:20:08 --> Hooks Class Initialized
DEBUG - 2018-07-06 13:20:08 --> UTF-8 Support Enabled
INFO - 2018-07-06 13:20:08 --> Utf8 Class Initialized
INFO - 2018-07-06 13:20:08 --> URI Class Initialized
DEBUG - 2018-07-06 13:20:08 --> No URI present. Default controller set.
INFO - 2018-07-06 13:20:08 --> Router Class Initialized
INFO - 2018-07-06 13:20:08 --> Output Class Initialized
INFO - 2018-07-06 13:20:08 --> Security Class Initialized
DEBUG - 2018-07-06 13:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-06 13:20:08 --> CSRF cookie sent
INFO - 2018-07-06 13:20:08 --> Input Class Initialized
INFO - 2018-07-06 13:20:08 --> Language Class Initialized
INFO - 2018-07-06 13:20:08 --> Loader Class Initialized
INFO - 2018-07-06 13:20:08 --> Helper loaded: url_helper
INFO - 2018-07-06 13:20:08 --> Helper loaded: form_helper
INFO - 2018-07-06 13:20:08 --> Helper loaded: language_helper
DEBUG - 2018-07-06 13:20:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-06 13:20:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-06 13:20:08 --> User Agent Class Initialized
INFO - 2018-07-06 13:20:08 --> Controller Class Initialized
INFO - 2018-07-06 13:20:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-06 13:20:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-06 13:20:08 --> Pixel_Model class loaded
INFO - 2018-07-06 13:20:08 --> Database Driver Class Initialized
INFO - 2018-07-06 13:20:08 --> Model "QuestionsModel" initialized
INFO - 2018-07-06 13:20:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-06 13:20:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-06 13:20:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-06 13:20:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-06 13:20:08 --> Final output sent to browser
DEBUG - 2018-07-06 13:20:08 --> Total execution time: 0.0356
INFO - 2018-07-06 14:57:50 --> Config Class Initialized
INFO - 2018-07-06 14:57:50 --> Hooks Class Initialized
DEBUG - 2018-07-06 14:57:50 --> UTF-8 Support Enabled
INFO - 2018-07-06 14:57:50 --> Utf8 Class Initialized
INFO - 2018-07-06 14:57:50 --> URI Class Initialized
INFO - 2018-07-06 14:57:50 --> Router Class Initialized
INFO - 2018-07-06 14:57:50 --> Output Class Initialized
INFO - 2018-07-06 14:57:50 --> Security Class Initialized
DEBUG - 2018-07-06 14:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-06 14:57:50 --> CSRF cookie sent
INFO - 2018-07-06 14:57:50 --> Input Class Initialized
INFO - 2018-07-06 14:57:50 --> Language Class Initialized
INFO - 2018-07-06 14:57:50 --> Loader Class Initialized
INFO - 2018-07-06 14:57:50 --> Helper loaded: url_helper
INFO - 2018-07-06 14:57:50 --> Helper loaded: form_helper
INFO - 2018-07-06 14:57:50 --> Helper loaded: language_helper
DEBUG - 2018-07-06 14:57:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-06 14:57:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-06 14:57:50 --> User Agent Class Initialized
INFO - 2018-07-06 14:57:50 --> Controller Class Initialized
INFO - 2018-07-06 14:57:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-06 14:57:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-06 14:57:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-06 14:57:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-06 14:57:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-06 14:57:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-06 14:57:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/911.php
INFO - 2018-07-06 14:57:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-06 14:57:50 --> Final output sent to browser
DEBUG - 2018-07-06 14:57:50 --> Total execution time: 0.0234
INFO - 2018-07-06 15:06:55 --> Config Class Initialized
INFO - 2018-07-06 15:06:55 --> Hooks Class Initialized
DEBUG - 2018-07-06 15:06:55 --> UTF-8 Support Enabled
INFO - 2018-07-06 15:06:55 --> Utf8 Class Initialized
INFO - 2018-07-06 15:06:55 --> URI Class Initialized
DEBUG - 2018-07-06 15:06:55 --> No URI present. Default controller set.
INFO - 2018-07-06 15:06:55 --> Router Class Initialized
INFO - 2018-07-06 15:06:55 --> Output Class Initialized
INFO - 2018-07-06 15:06:55 --> Security Class Initialized
DEBUG - 2018-07-06 15:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-06 15:06:55 --> CSRF cookie sent
INFO - 2018-07-06 15:06:55 --> Input Class Initialized
INFO - 2018-07-06 15:06:55 --> Language Class Initialized
INFO - 2018-07-06 15:06:55 --> Loader Class Initialized
INFO - 2018-07-06 15:06:55 --> Helper loaded: url_helper
INFO - 2018-07-06 15:06:55 --> Helper loaded: form_helper
INFO - 2018-07-06 15:06:55 --> Helper loaded: language_helper
DEBUG - 2018-07-06 15:06:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-06 15:06:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-06 15:06:55 --> User Agent Class Initialized
INFO - 2018-07-06 15:06:55 --> Controller Class Initialized
INFO - 2018-07-06 15:06:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-06 15:06:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-06 15:06:55 --> Pixel_Model class loaded
INFO - 2018-07-06 15:06:55 --> Database Driver Class Initialized
INFO - 2018-07-06 15:06:55 --> Model "QuestionsModel" initialized
INFO - 2018-07-06 15:06:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-06 15:06:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-06 15:06:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-06 15:06:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-06 15:06:55 --> Final output sent to browser
DEBUG - 2018-07-06 15:06:55 --> Total execution time: 0.0366
INFO - 2018-07-06 15:40:56 --> Config Class Initialized
INFO - 2018-07-06 15:40:56 --> Hooks Class Initialized
DEBUG - 2018-07-06 15:40:56 --> UTF-8 Support Enabled
INFO - 2018-07-06 15:40:56 --> Utf8 Class Initialized
INFO - 2018-07-06 15:40:56 --> URI Class Initialized
INFO - 2018-07-06 15:40:56 --> Router Class Initialized
INFO - 2018-07-06 15:40:56 --> Output Class Initialized
INFO - 2018-07-06 15:40:56 --> Security Class Initialized
DEBUG - 2018-07-06 15:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-06 15:40:56 --> CSRF cookie sent
INFO - 2018-07-06 15:40:56 --> Input Class Initialized
INFO - 2018-07-06 15:40:56 --> Language Class Initialized
ERROR - 2018-07-06 15:40:56 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-06 15:40:59 --> Config Class Initialized
INFO - 2018-07-06 15:40:59 --> Hooks Class Initialized
DEBUG - 2018-07-06 15:40:59 --> UTF-8 Support Enabled
INFO - 2018-07-06 15:40:59 --> Utf8 Class Initialized
INFO - 2018-07-06 15:40:59 --> URI Class Initialized
INFO - 2018-07-06 15:40:59 --> Router Class Initialized
INFO - 2018-07-06 15:40:59 --> Output Class Initialized
INFO - 2018-07-06 15:40:59 --> Security Class Initialized
DEBUG - 2018-07-06 15:40:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-06 15:40:59 --> CSRF cookie sent
INFO - 2018-07-06 15:40:59 --> Input Class Initialized
INFO - 2018-07-06 15:40:59 --> Language Class Initialized
INFO - 2018-07-06 15:40:59 --> Loader Class Initialized
INFO - 2018-07-06 15:40:59 --> Helper loaded: url_helper
INFO - 2018-07-06 15:40:59 --> Helper loaded: form_helper
INFO - 2018-07-06 15:40:59 --> Helper loaded: language_helper
DEBUG - 2018-07-06 15:40:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-06 15:40:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-06 15:40:59 --> User Agent Class Initialized
INFO - 2018-07-06 15:40:59 --> Controller Class Initialized
INFO - 2018-07-06 15:40:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-06 15:40:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-06 15:40:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-06 15:40:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-06 15:40:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-06 15:40:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-06 15:40:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-07-06 15:40:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-06 15:40:59 --> Final output sent to browser
DEBUG - 2018-07-06 15:40:59 --> Total execution time: 0.0268
INFO - 2018-07-06 16:59:30 --> Config Class Initialized
INFO - 2018-07-06 16:59:30 --> Hooks Class Initialized
DEBUG - 2018-07-06 16:59:30 --> UTF-8 Support Enabled
INFO - 2018-07-06 16:59:30 --> Utf8 Class Initialized
INFO - 2018-07-06 16:59:30 --> URI Class Initialized
INFO - 2018-07-06 16:59:30 --> Router Class Initialized
INFO - 2018-07-06 16:59:30 --> Output Class Initialized
INFO - 2018-07-06 16:59:30 --> Security Class Initialized
DEBUG - 2018-07-06 16:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-06 16:59:30 --> CSRF cookie sent
INFO - 2018-07-06 16:59:30 --> Input Class Initialized
INFO - 2018-07-06 16:59:30 --> Language Class Initialized
ERROR - 2018-07-06 16:59:30 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-06 17:28:37 --> Config Class Initialized
INFO - 2018-07-06 17:28:37 --> Hooks Class Initialized
DEBUG - 2018-07-06 17:28:37 --> UTF-8 Support Enabled
INFO - 2018-07-06 17:28:37 --> Utf8 Class Initialized
INFO - 2018-07-06 17:28:37 --> URI Class Initialized
INFO - 2018-07-06 17:28:37 --> Router Class Initialized
INFO - 2018-07-06 17:28:37 --> Output Class Initialized
INFO - 2018-07-06 17:28:37 --> Security Class Initialized
DEBUG - 2018-07-06 17:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-06 17:28:37 --> CSRF cookie sent
INFO - 2018-07-06 17:28:37 --> Input Class Initialized
INFO - 2018-07-06 17:28:37 --> Language Class Initialized
ERROR - 2018-07-06 17:28:37 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-06 17:49:19 --> Config Class Initialized
INFO - 2018-07-06 17:49:19 --> Hooks Class Initialized
DEBUG - 2018-07-06 17:49:19 --> UTF-8 Support Enabled
INFO - 2018-07-06 17:49:19 --> Utf8 Class Initialized
INFO - 2018-07-06 17:49:19 --> URI Class Initialized
DEBUG - 2018-07-06 17:49:19 --> No URI present. Default controller set.
INFO - 2018-07-06 17:49:19 --> Router Class Initialized
INFO - 2018-07-06 17:49:19 --> Output Class Initialized
INFO - 2018-07-06 17:49:19 --> Security Class Initialized
DEBUG - 2018-07-06 17:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-06 17:49:19 --> CSRF cookie sent
INFO - 2018-07-06 17:49:19 --> Input Class Initialized
INFO - 2018-07-06 17:49:19 --> Language Class Initialized
INFO - 2018-07-06 17:49:19 --> Loader Class Initialized
INFO - 2018-07-06 17:49:19 --> Helper loaded: url_helper
INFO - 2018-07-06 17:49:19 --> Helper loaded: form_helper
INFO - 2018-07-06 17:49:19 --> Helper loaded: language_helper
DEBUG - 2018-07-06 17:49:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-06 17:49:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-06 17:49:19 --> User Agent Class Initialized
INFO - 2018-07-06 17:49:19 --> Controller Class Initialized
INFO - 2018-07-06 17:49:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-06 17:49:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-06 17:49:19 --> Pixel_Model class loaded
INFO - 2018-07-06 17:49:19 --> Database Driver Class Initialized
INFO - 2018-07-06 17:49:19 --> Model "QuestionsModel" initialized
INFO - 2018-07-06 17:49:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-06 17:49:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-06 17:49:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-06 17:49:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-06 17:49:19 --> Final output sent to browser
DEBUG - 2018-07-06 17:49:19 --> Total execution time: 0.0372
INFO - 2018-07-06 18:00:03 --> Config Class Initialized
INFO - 2018-07-06 18:00:03 --> Hooks Class Initialized
DEBUG - 2018-07-06 18:00:03 --> UTF-8 Support Enabled
INFO - 2018-07-06 18:00:03 --> Utf8 Class Initialized
INFO - 2018-07-06 18:00:03 --> URI Class Initialized
DEBUG - 2018-07-06 18:00:03 --> No URI present. Default controller set.
INFO - 2018-07-06 18:00:03 --> Router Class Initialized
INFO - 2018-07-06 18:00:03 --> Output Class Initialized
INFO - 2018-07-06 18:00:03 --> Security Class Initialized
DEBUG - 2018-07-06 18:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-06 18:00:03 --> CSRF cookie sent
INFO - 2018-07-06 18:00:03 --> Input Class Initialized
INFO - 2018-07-06 18:00:03 --> Language Class Initialized
INFO - 2018-07-06 18:00:03 --> Loader Class Initialized
INFO - 2018-07-06 18:00:03 --> Helper loaded: url_helper
INFO - 2018-07-06 18:00:03 --> Helper loaded: form_helper
INFO - 2018-07-06 18:00:03 --> Helper loaded: language_helper
DEBUG - 2018-07-06 18:00:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-06 18:00:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-06 18:00:03 --> User Agent Class Initialized
INFO - 2018-07-06 18:00:03 --> Controller Class Initialized
INFO - 2018-07-06 18:00:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-06 18:00:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-06 18:00:03 --> Pixel_Model class loaded
INFO - 2018-07-06 18:00:03 --> Database Driver Class Initialized
INFO - 2018-07-06 18:00:03 --> Model "QuestionsModel" initialized
INFO - 2018-07-06 18:00:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-06 18:00:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-06 18:00:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-06 18:00:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-06 18:00:03 --> Final output sent to browser
DEBUG - 2018-07-06 18:00:03 --> Total execution time: 0.0506
INFO - 2018-07-06 18:16:38 --> Config Class Initialized
INFO - 2018-07-06 18:16:38 --> Hooks Class Initialized
DEBUG - 2018-07-06 18:16:38 --> UTF-8 Support Enabled
INFO - 2018-07-06 18:16:38 --> Utf8 Class Initialized
INFO - 2018-07-06 18:16:38 --> URI Class Initialized
DEBUG - 2018-07-06 18:16:38 --> No URI present. Default controller set.
INFO - 2018-07-06 18:16:38 --> Router Class Initialized
INFO - 2018-07-06 18:16:38 --> Output Class Initialized
INFO - 2018-07-06 18:16:38 --> Security Class Initialized
DEBUG - 2018-07-06 18:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-06 18:16:38 --> CSRF cookie sent
INFO - 2018-07-06 18:16:38 --> Input Class Initialized
INFO - 2018-07-06 18:16:38 --> Language Class Initialized
INFO - 2018-07-06 18:16:38 --> Loader Class Initialized
INFO - 2018-07-06 18:16:38 --> Helper loaded: url_helper
INFO - 2018-07-06 18:16:38 --> Helper loaded: form_helper
INFO - 2018-07-06 18:16:38 --> Helper loaded: language_helper
DEBUG - 2018-07-06 18:16:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-06 18:16:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-06 18:16:38 --> User Agent Class Initialized
INFO - 2018-07-06 18:16:38 --> Controller Class Initialized
INFO - 2018-07-06 18:16:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-06 18:16:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-06 18:16:38 --> Pixel_Model class loaded
INFO - 2018-07-06 18:16:38 --> Database Driver Class Initialized
INFO - 2018-07-06 18:16:38 --> Model "QuestionsModel" initialized
INFO - 2018-07-06 18:16:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-06 18:16:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-06 18:16:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-06 18:16:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-06 18:16:38 --> Final output sent to browser
DEBUG - 2018-07-06 18:16:38 --> Total execution time: 0.0381
INFO - 2018-07-06 18:16:39 --> Config Class Initialized
INFO - 2018-07-06 18:16:39 --> Hooks Class Initialized
DEBUG - 2018-07-06 18:16:39 --> UTF-8 Support Enabled
INFO - 2018-07-06 18:16:39 --> Utf8 Class Initialized
INFO - 2018-07-06 18:16:39 --> URI Class Initialized
DEBUG - 2018-07-06 18:16:39 --> No URI present. Default controller set.
INFO - 2018-07-06 18:16:39 --> Router Class Initialized
INFO - 2018-07-06 18:16:39 --> Output Class Initialized
INFO - 2018-07-06 18:16:39 --> Security Class Initialized
DEBUG - 2018-07-06 18:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-06 18:16:39 --> CSRF cookie sent
INFO - 2018-07-06 18:16:39 --> Input Class Initialized
INFO - 2018-07-06 18:16:39 --> Language Class Initialized
INFO - 2018-07-06 18:16:39 --> Loader Class Initialized
INFO - 2018-07-06 18:16:39 --> Helper loaded: url_helper
INFO - 2018-07-06 18:16:39 --> Helper loaded: form_helper
INFO - 2018-07-06 18:16:39 --> Helper loaded: language_helper
DEBUG - 2018-07-06 18:16:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-06 18:16:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-06 18:16:39 --> User Agent Class Initialized
INFO - 2018-07-06 18:16:39 --> Controller Class Initialized
INFO - 2018-07-06 18:16:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-06 18:16:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-06 18:16:39 --> Pixel_Model class loaded
INFO - 2018-07-06 18:16:39 --> Database Driver Class Initialized
INFO - 2018-07-06 18:16:39 --> Model "QuestionsModel" initialized
INFO - 2018-07-06 18:16:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-06 18:16:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-06 18:16:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-06 18:16:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-06 18:16:39 --> Final output sent to browser
DEBUG - 2018-07-06 18:16:39 --> Total execution time: 0.0382
INFO - 2018-07-06 18:16:39 --> Config Class Initialized
INFO - 2018-07-06 18:16:39 --> Hooks Class Initialized
DEBUG - 2018-07-06 18:16:39 --> UTF-8 Support Enabled
INFO - 2018-07-06 18:16:39 --> Utf8 Class Initialized
INFO - 2018-07-06 18:16:39 --> URI Class Initialized
DEBUG - 2018-07-06 18:16:39 --> No URI present. Default controller set.
INFO - 2018-07-06 18:16:39 --> Router Class Initialized
INFO - 2018-07-06 18:16:39 --> Output Class Initialized
INFO - 2018-07-06 18:16:39 --> Security Class Initialized
DEBUG - 2018-07-06 18:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-06 18:16:39 --> CSRF cookie sent
INFO - 2018-07-06 18:16:39 --> Input Class Initialized
INFO - 2018-07-06 18:16:39 --> Language Class Initialized
INFO - 2018-07-06 18:16:39 --> Loader Class Initialized
INFO - 2018-07-06 18:16:39 --> Helper loaded: url_helper
INFO - 2018-07-06 18:16:39 --> Helper loaded: form_helper
INFO - 2018-07-06 18:16:39 --> Helper loaded: language_helper
DEBUG - 2018-07-06 18:16:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-06 18:16:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-06 18:16:39 --> User Agent Class Initialized
INFO - 2018-07-06 18:16:39 --> Controller Class Initialized
INFO - 2018-07-06 18:16:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-06 18:16:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-06 18:16:39 --> Pixel_Model class loaded
INFO - 2018-07-06 18:16:39 --> Database Driver Class Initialized
INFO - 2018-07-06 18:16:39 --> Model "QuestionsModel" initialized
INFO - 2018-07-06 18:16:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-06 18:16:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-06 18:16:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-06 18:16:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-06 18:16:39 --> Final output sent to browser
DEBUG - 2018-07-06 18:16:39 --> Total execution time: 0.0311
INFO - 2018-07-06 18:16:40 --> Config Class Initialized
INFO - 2018-07-06 18:16:40 --> Hooks Class Initialized
DEBUG - 2018-07-06 18:16:40 --> UTF-8 Support Enabled
INFO - 2018-07-06 18:16:40 --> Utf8 Class Initialized
INFO - 2018-07-06 18:16:40 --> URI Class Initialized
INFO - 2018-07-06 18:16:40 --> Router Class Initialized
INFO - 2018-07-06 18:16:40 --> Output Class Initialized
INFO - 2018-07-06 18:16:40 --> Security Class Initialized
DEBUG - 2018-07-06 18:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-06 18:16:40 --> CSRF cookie sent
INFO - 2018-07-06 18:16:40 --> Input Class Initialized
INFO - 2018-07-06 18:16:40 --> Language Class Initialized
ERROR - 2018-07-06 18:16:40 --> 404 Page Not Found: 405shtml/index
INFO - 2018-07-06 18:16:48 --> Config Class Initialized
INFO - 2018-07-06 18:16:48 --> Hooks Class Initialized
DEBUG - 2018-07-06 18:16:48 --> UTF-8 Support Enabled
INFO - 2018-07-06 18:16:48 --> Utf8 Class Initialized
INFO - 2018-07-06 18:16:48 --> URI Class Initialized
DEBUG - 2018-07-06 18:16:48 --> No URI present. Default controller set.
INFO - 2018-07-06 18:16:48 --> Router Class Initialized
INFO - 2018-07-06 18:16:48 --> Output Class Initialized
INFO - 2018-07-06 18:16:48 --> Security Class Initialized
DEBUG - 2018-07-06 18:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-06 18:16:48 --> CSRF cookie sent
INFO - 2018-07-06 18:16:48 --> Input Class Initialized
INFO - 2018-07-06 18:16:48 --> Language Class Initialized
INFO - 2018-07-06 18:16:48 --> Loader Class Initialized
INFO - 2018-07-06 18:16:48 --> Helper loaded: url_helper
INFO - 2018-07-06 18:16:48 --> Helper loaded: form_helper
INFO - 2018-07-06 18:16:48 --> Helper loaded: language_helper
DEBUG - 2018-07-06 18:16:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-06 18:16:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-06 18:16:48 --> User Agent Class Initialized
INFO - 2018-07-06 18:16:48 --> Controller Class Initialized
INFO - 2018-07-06 18:16:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-06 18:16:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-06 18:16:48 --> Pixel_Model class loaded
INFO - 2018-07-06 18:16:48 --> Database Driver Class Initialized
INFO - 2018-07-06 18:16:48 --> Model "QuestionsModel" initialized
INFO - 2018-07-06 18:16:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-06 18:16:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-06 18:16:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-06 18:16:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-06 18:16:48 --> Final output sent to browser
DEBUG - 2018-07-06 18:16:48 --> Total execution time: 0.0358
INFO - 2018-07-06 18:16:48 --> Config Class Initialized
INFO - 2018-07-06 18:16:48 --> Hooks Class Initialized
DEBUG - 2018-07-06 18:16:48 --> UTF-8 Support Enabled
INFO - 2018-07-06 18:16:48 --> Utf8 Class Initialized
INFO - 2018-07-06 18:16:48 --> URI Class Initialized
INFO - 2018-07-06 18:16:48 --> Router Class Initialized
INFO - 2018-07-06 18:16:48 --> Output Class Initialized
INFO - 2018-07-06 18:16:48 --> Security Class Initialized
DEBUG - 2018-07-06 18:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-06 18:16:48 --> CSRF cookie sent
INFO - 2018-07-06 18:16:48 --> Input Class Initialized
INFO - 2018-07-06 18:16:48 --> Language Class Initialized
ERROR - 2018-07-06 18:16:48 --> 404 Page Not Found: 404testpage4525d2fdc/index
INFO - 2018-07-06 18:16:48 --> Config Class Initialized
INFO - 2018-07-06 18:16:48 --> Hooks Class Initialized
DEBUG - 2018-07-06 18:16:48 --> UTF-8 Support Enabled
INFO - 2018-07-06 18:16:48 --> Utf8 Class Initialized
INFO - 2018-07-06 18:16:48 --> URI Class Initialized
INFO - 2018-07-06 18:16:48 --> Router Class Initialized
INFO - 2018-07-06 18:16:48 --> Output Class Initialized
INFO - 2018-07-06 18:16:48 --> Security Class Initialized
DEBUG - 2018-07-06 18:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-06 18:16:48 --> CSRF cookie sent
INFO - 2018-07-06 18:16:48 --> Input Class Initialized
INFO - 2018-07-06 18:16:48 --> Language Class Initialized
ERROR - 2018-07-06 18:16:48 --> 404 Page Not Found: 404javascriptjs/index
INFO - 2018-07-06 18:16:49 --> Config Class Initialized
INFO - 2018-07-06 18:16:49 --> Hooks Class Initialized
DEBUG - 2018-07-06 18:16:49 --> UTF-8 Support Enabled
INFO - 2018-07-06 18:16:49 --> Utf8 Class Initialized
INFO - 2018-07-06 18:16:49 --> URI Class Initialized
INFO - 2018-07-06 18:16:49 --> Router Class Initialized
INFO - 2018-07-06 18:16:49 --> Output Class Initialized
INFO - 2018-07-06 18:16:49 --> Security Class Initialized
DEBUG - 2018-07-06 18:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-06 18:16:49 --> CSRF cookie sent
INFO - 2018-07-06 18:16:49 --> Input Class Initialized
INFO - 2018-07-06 18:16:49 --> Language Class Initialized
INFO - 2018-07-06 18:16:49 --> Loader Class Initialized
INFO - 2018-07-06 18:16:49 --> Helper loaded: url_helper
INFO - 2018-07-06 18:16:49 --> Helper loaded: form_helper
INFO - 2018-07-06 18:16:49 --> Helper loaded: language_helper
DEBUG - 2018-07-06 18:16:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-06 18:16:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-06 18:16:49 --> User Agent Class Initialized
INFO - 2018-07-06 18:16:49 --> Controller Class Initialized
INFO - 2018-07-06 18:16:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-06 18:16:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-06 18:16:49 --> Pixel_Model class loaded
INFO - 2018-07-06 18:16:49 --> Database Driver Class Initialized
INFO - 2018-07-06 18:16:49 --> Model "QuestionsModel" initialized
INFO - 2018-07-06 18:16:49 --> Config Class Initialized
INFO - 2018-07-06 18:16:49 --> Hooks Class Initialized
DEBUG - 2018-07-06 18:16:49 --> UTF-8 Support Enabled
INFO - 2018-07-06 18:16:49 --> Utf8 Class Initialized
INFO - 2018-07-06 18:16:49 --> URI Class Initialized
INFO - 2018-07-06 18:16:49 --> Router Class Initialized
INFO - 2018-07-06 18:16:49 --> Output Class Initialized
INFO - 2018-07-06 18:16:49 --> Security Class Initialized
DEBUG - 2018-07-06 18:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-06 18:16:49 --> CSRF cookie sent
INFO - 2018-07-06 18:16:49 --> Input Class Initialized
INFO - 2018-07-06 18:16:49 --> Language Class Initialized
INFO - 2018-07-06 18:16:49 --> Loader Class Initialized
INFO - 2018-07-06 18:16:49 --> Helper loaded: url_helper
INFO - 2018-07-06 18:16:49 --> Helper loaded: form_helper
INFO - 2018-07-06 18:16:49 --> Helper loaded: language_helper
DEBUG - 2018-07-06 18:16:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-06 18:16:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-06 18:16:49 --> User Agent Class Initialized
INFO - 2018-07-06 18:16:49 --> Controller Class Initialized
INFO - 2018-07-06 18:16:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-06 18:16:49 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-06 18:16:49 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-06 18:16:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-06 18:16:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-06 18:16:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-06 18:16:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-06 18:16:49 --> Could not find the language line "req_email"
INFO - 2018-07-06 18:16:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-06 18:16:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-06 18:16:49 --> Final output sent to browser
DEBUG - 2018-07-06 18:16:49 --> Total execution time: 0.0294
INFO - 2018-07-06 18:16:49 --> Config Class Initialized
INFO - 2018-07-06 18:16:49 --> Hooks Class Initialized
DEBUG - 2018-07-06 18:16:49 --> UTF-8 Support Enabled
INFO - 2018-07-06 18:16:49 --> Utf8 Class Initialized
INFO - 2018-07-06 18:16:49 --> URI Class Initialized
INFO - 2018-07-06 18:16:49 --> Router Class Initialized
INFO - 2018-07-06 18:16:49 --> Output Class Initialized
INFO - 2018-07-06 18:16:49 --> Security Class Initialized
DEBUG - 2018-07-06 18:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-06 18:16:49 --> CSRF cookie sent
INFO - 2018-07-06 18:16:49 --> Input Class Initialized
INFO - 2018-07-06 18:16:49 --> Language Class Initialized
INFO - 2018-07-06 18:16:49 --> Loader Class Initialized
INFO - 2018-07-06 18:16:49 --> Helper loaded: url_helper
INFO - 2018-07-06 18:16:49 --> Helper loaded: form_helper
INFO - 2018-07-06 18:16:49 --> Helper loaded: language_helper
DEBUG - 2018-07-06 18:16:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-06 18:16:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-06 18:16:49 --> User Agent Class Initialized
INFO - 2018-07-06 18:16:49 --> Controller Class Initialized
INFO - 2018-07-06 18:16:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-06 18:16:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-06 18:16:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-06 18:16:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-06 18:16:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-06 18:16:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-06 18:16:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-07-06 18:16:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-06 18:16:49 --> Final output sent to browser
DEBUG - 2018-07-06 18:16:49 --> Total execution time: 0.0221
INFO - 2018-07-06 18:16:49 --> Config Class Initialized
INFO - 2018-07-06 18:16:49 --> Hooks Class Initialized
DEBUG - 2018-07-06 18:16:49 --> UTF-8 Support Enabled
INFO - 2018-07-06 18:16:49 --> Utf8 Class Initialized
INFO - 2018-07-06 18:16:49 --> URI Class Initialized
INFO - 2018-07-06 18:16:49 --> Router Class Initialized
INFO - 2018-07-06 18:16:49 --> Output Class Initialized
INFO - 2018-07-06 18:16:49 --> Security Class Initialized
DEBUG - 2018-07-06 18:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-06 18:16:49 --> CSRF cookie sent
INFO - 2018-07-06 18:16:49 --> Input Class Initialized
INFO - 2018-07-06 18:16:49 --> Language Class Initialized
INFO - 2018-07-06 18:16:49 --> Loader Class Initialized
INFO - 2018-07-06 18:16:49 --> Helper loaded: url_helper
INFO - 2018-07-06 18:16:49 --> Helper loaded: form_helper
INFO - 2018-07-06 18:16:49 --> Helper loaded: language_helper
DEBUG - 2018-07-06 18:16:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-06 18:16:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-06 18:16:49 --> User Agent Class Initialized
INFO - 2018-07-06 18:16:49 --> Controller Class Initialized
INFO - 2018-07-06 18:16:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-06 18:16:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-06 18:16:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-06 18:16:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-06 18:16:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-06 18:16:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-06 18:16:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-07-06 18:16:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-06 18:16:49 --> Final output sent to browser
DEBUG - 2018-07-06 18:16:49 --> Total execution time: 0.0214
INFO - 2018-07-06 18:16:50 --> Config Class Initialized
INFO - 2018-07-06 18:16:50 --> Hooks Class Initialized
DEBUG - 2018-07-06 18:16:50 --> UTF-8 Support Enabled
INFO - 2018-07-06 18:16:50 --> Utf8 Class Initialized
INFO - 2018-07-06 18:16:50 --> URI Class Initialized
INFO - 2018-07-06 18:16:50 --> Router Class Initialized
INFO - 2018-07-06 18:16:50 --> Output Class Initialized
INFO - 2018-07-06 18:16:50 --> Security Class Initialized
DEBUG - 2018-07-06 18:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-06 18:16:50 --> CSRF cookie sent
INFO - 2018-07-06 18:16:50 --> Input Class Initialized
INFO - 2018-07-06 18:16:50 --> Language Class Initialized
INFO - 2018-07-06 18:16:50 --> Loader Class Initialized
INFO - 2018-07-06 18:16:50 --> Helper loaded: url_helper
INFO - 2018-07-06 18:16:50 --> Helper loaded: form_helper
INFO - 2018-07-06 18:16:50 --> Helper loaded: language_helper
DEBUG - 2018-07-06 18:16:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-06 18:16:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-06 18:16:50 --> User Agent Class Initialized
INFO - 2018-07-06 18:16:50 --> Controller Class Initialized
INFO - 2018-07-06 18:16:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-06 18:16:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-06 18:16:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-06 18:16:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-06 18:16:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-06 18:16:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-06 18:16:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-07-06 18:16:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-06 18:16:50 --> Final output sent to browser
DEBUG - 2018-07-06 18:16:50 --> Total execution time: 0.0213
INFO - 2018-07-06 18:16:50 --> Config Class Initialized
INFO - 2018-07-06 18:16:50 --> Hooks Class Initialized
DEBUG - 2018-07-06 18:16:50 --> UTF-8 Support Enabled
INFO - 2018-07-06 18:16:50 --> Utf8 Class Initialized
INFO - 2018-07-06 18:16:50 --> URI Class Initialized
INFO - 2018-07-06 18:16:50 --> Router Class Initialized
INFO - 2018-07-06 18:16:50 --> Output Class Initialized
INFO - 2018-07-06 18:16:50 --> Security Class Initialized
DEBUG - 2018-07-06 18:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-06 18:16:50 --> CSRF cookie sent
INFO - 2018-07-06 18:16:50 --> Input Class Initialized
INFO - 2018-07-06 18:16:50 --> Language Class Initialized
INFO - 2018-07-06 18:16:50 --> Loader Class Initialized
INFO - 2018-07-06 18:16:50 --> Helper loaded: url_helper
INFO - 2018-07-06 18:16:50 --> Helper loaded: form_helper
INFO - 2018-07-06 18:16:50 --> Helper loaded: language_helper
DEBUG - 2018-07-06 18:16:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-06 18:16:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-06 18:16:50 --> User Agent Class Initialized
INFO - 2018-07-06 18:16:50 --> Controller Class Initialized
INFO - 2018-07-06 18:16:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-06 18:16:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-06 18:16:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-06 18:16:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-06 18:16:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-06 18:16:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-06 18:16:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-07-06 18:16:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-06 18:16:50 --> Final output sent to browser
DEBUG - 2018-07-06 18:16:50 --> Total execution time: 0.0216
INFO - 2018-07-06 18:16:50 --> Config Class Initialized
INFO - 2018-07-06 18:16:50 --> Hooks Class Initialized
DEBUG - 2018-07-06 18:16:50 --> UTF-8 Support Enabled
INFO - 2018-07-06 18:16:50 --> Utf8 Class Initialized
INFO - 2018-07-06 18:16:50 --> URI Class Initialized
INFO - 2018-07-06 18:16:50 --> Router Class Initialized
INFO - 2018-07-06 18:16:50 --> Output Class Initialized
INFO - 2018-07-06 18:16:50 --> Security Class Initialized
DEBUG - 2018-07-06 18:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-06 18:16:50 --> CSRF cookie sent
INFO - 2018-07-06 18:16:50 --> Input Class Initialized
INFO - 2018-07-06 18:16:50 --> Language Class Initialized
INFO - 2018-07-06 18:16:50 --> Loader Class Initialized
INFO - 2018-07-06 18:16:50 --> Helper loaded: url_helper
INFO - 2018-07-06 18:16:50 --> Helper loaded: form_helper
INFO - 2018-07-06 18:16:50 --> Helper loaded: language_helper
DEBUG - 2018-07-06 18:16:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-06 18:16:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-06 18:16:50 --> User Agent Class Initialized
INFO - 2018-07-06 18:16:50 --> Controller Class Initialized
INFO - 2018-07-06 18:16:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-06 18:16:50 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-06 18:16:50 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-06 18:16:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-06 18:16:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-06 18:16:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-06 18:16:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-06 18:16:50 --> Could not find the language line "req_email"
INFO - 2018-07-06 18:16:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-06 18:16:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-06 18:16:50 --> Final output sent to browser
DEBUG - 2018-07-06 18:16:50 --> Total execution time: 0.0216
INFO - 2018-07-06 18:16:51 --> Config Class Initialized
INFO - 2018-07-06 18:16:51 --> Hooks Class Initialized
DEBUG - 2018-07-06 18:16:51 --> UTF-8 Support Enabled
INFO - 2018-07-06 18:16:51 --> Utf8 Class Initialized
INFO - 2018-07-06 18:16:51 --> URI Class Initialized
INFO - 2018-07-06 18:16:51 --> Router Class Initialized
INFO - 2018-07-06 18:16:51 --> Output Class Initialized
INFO - 2018-07-06 18:16:51 --> Security Class Initialized
DEBUG - 2018-07-06 18:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-06 18:16:51 --> CSRF cookie sent
INFO - 2018-07-06 18:16:51 --> Input Class Initialized
INFO - 2018-07-06 18:16:51 --> Language Class Initialized
INFO - 2018-07-06 18:16:51 --> Loader Class Initialized
INFO - 2018-07-06 18:16:51 --> Helper loaded: url_helper
INFO - 2018-07-06 18:16:51 --> Helper loaded: form_helper
INFO - 2018-07-06 18:16:51 --> Helper loaded: language_helper
DEBUG - 2018-07-06 18:16:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-06 18:16:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-06 18:16:51 --> User Agent Class Initialized
INFO - 2018-07-06 18:16:51 --> Controller Class Initialized
INFO - 2018-07-06 18:16:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-06 18:16:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-06 18:16:51 --> Pixel_Model class loaded
INFO - 2018-07-06 18:16:51 --> Database Driver Class Initialized
INFO - 2018-07-06 18:16:51 --> Model "QuestionsModel" initialized
INFO - 2018-07-06 18:16:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-06 18:16:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-06 18:16:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-06 18:16:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-06 18:16:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/buy_gift.php
INFO - 2018-07-06 18:16:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-06 18:16:51 --> Final output sent to browser
DEBUG - 2018-07-06 18:16:51 --> Total execution time: 0.0336
INFO - 2018-07-06 18:35:04 --> Config Class Initialized
INFO - 2018-07-06 18:35:04 --> Hooks Class Initialized
DEBUG - 2018-07-06 18:35:04 --> UTF-8 Support Enabled
INFO - 2018-07-06 18:35:04 --> Utf8 Class Initialized
INFO - 2018-07-06 18:35:04 --> URI Class Initialized
DEBUG - 2018-07-06 18:35:04 --> No URI present. Default controller set.
INFO - 2018-07-06 18:35:04 --> Router Class Initialized
INFO - 2018-07-06 18:35:04 --> Output Class Initialized
INFO - 2018-07-06 18:35:04 --> Security Class Initialized
DEBUG - 2018-07-06 18:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-06 18:35:04 --> CSRF cookie sent
INFO - 2018-07-06 18:35:04 --> Input Class Initialized
INFO - 2018-07-06 18:35:04 --> Language Class Initialized
INFO - 2018-07-06 18:35:04 --> Loader Class Initialized
INFO - 2018-07-06 18:35:04 --> Helper loaded: url_helper
INFO - 2018-07-06 18:35:04 --> Helper loaded: form_helper
INFO - 2018-07-06 18:35:04 --> Helper loaded: language_helper
DEBUG - 2018-07-06 18:35:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-06 18:35:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-06 18:35:04 --> User Agent Class Initialized
INFO - 2018-07-06 18:35:04 --> Controller Class Initialized
INFO - 2018-07-06 18:35:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-06 18:35:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-06 18:35:04 --> Pixel_Model class loaded
INFO - 2018-07-06 18:35:04 --> Database Driver Class Initialized
INFO - 2018-07-06 18:35:04 --> Model "QuestionsModel" initialized
INFO - 2018-07-06 18:35:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-06 18:35:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-06 18:35:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-06 18:35:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-06 18:35:04 --> Final output sent to browser
DEBUG - 2018-07-06 18:35:04 --> Total execution time: 0.0347
INFO - 2018-07-06 19:20:53 --> Config Class Initialized
INFO - 2018-07-06 19:20:53 --> Hooks Class Initialized
DEBUG - 2018-07-06 19:20:53 --> UTF-8 Support Enabled
INFO - 2018-07-06 19:20:53 --> Utf8 Class Initialized
INFO - 2018-07-06 19:20:53 --> URI Class Initialized
INFO - 2018-07-06 19:20:53 --> Router Class Initialized
INFO - 2018-07-06 19:20:53 --> Output Class Initialized
INFO - 2018-07-06 19:20:53 --> Security Class Initialized
DEBUG - 2018-07-06 19:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-06 19:20:53 --> CSRF cookie sent
INFO - 2018-07-06 19:20:53 --> Input Class Initialized
INFO - 2018-07-06 19:20:53 --> Language Class Initialized
ERROR - 2018-07-06 19:20:53 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-06 19:20:54 --> Config Class Initialized
INFO - 2018-07-06 19:20:54 --> Hooks Class Initialized
DEBUG - 2018-07-06 19:20:54 --> UTF-8 Support Enabled
INFO - 2018-07-06 19:20:54 --> Utf8 Class Initialized
INFO - 2018-07-06 19:20:54 --> URI Class Initialized
DEBUG - 2018-07-06 19:20:54 --> No URI present. Default controller set.
INFO - 2018-07-06 19:20:54 --> Router Class Initialized
INFO - 2018-07-06 19:20:54 --> Output Class Initialized
INFO - 2018-07-06 19:20:54 --> Security Class Initialized
DEBUG - 2018-07-06 19:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-06 19:20:54 --> CSRF cookie sent
INFO - 2018-07-06 19:20:54 --> Input Class Initialized
INFO - 2018-07-06 19:20:54 --> Language Class Initialized
INFO - 2018-07-06 19:20:54 --> Loader Class Initialized
INFO - 2018-07-06 19:20:54 --> Helper loaded: url_helper
INFO - 2018-07-06 19:20:54 --> Helper loaded: form_helper
INFO - 2018-07-06 19:20:54 --> Helper loaded: language_helper
DEBUG - 2018-07-06 19:20:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-06 19:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-06 19:20:54 --> User Agent Class Initialized
INFO - 2018-07-06 19:20:54 --> Controller Class Initialized
INFO - 2018-07-06 19:20:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-06 19:20:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-06 19:20:54 --> Pixel_Model class loaded
INFO - 2018-07-06 19:20:54 --> Database Driver Class Initialized
INFO - 2018-07-06 19:20:54 --> Model "QuestionsModel" initialized
INFO - 2018-07-06 19:20:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-06 19:20:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-06 19:20:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-06 19:20:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-06 19:20:54 --> Final output sent to browser
DEBUG - 2018-07-06 19:20:54 --> Total execution time: 0.0336
INFO - 2018-07-06 19:51:47 --> Config Class Initialized
INFO - 2018-07-06 19:51:47 --> Hooks Class Initialized
DEBUG - 2018-07-06 19:51:47 --> UTF-8 Support Enabled
INFO - 2018-07-06 19:51:47 --> Utf8 Class Initialized
INFO - 2018-07-06 19:51:47 --> URI Class Initialized
DEBUG - 2018-07-06 19:51:47 --> No URI present. Default controller set.
INFO - 2018-07-06 19:51:47 --> Router Class Initialized
INFO - 2018-07-06 19:51:47 --> Output Class Initialized
INFO - 2018-07-06 19:51:47 --> Security Class Initialized
DEBUG - 2018-07-06 19:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-06 19:51:47 --> CSRF cookie sent
INFO - 2018-07-06 19:51:47 --> Input Class Initialized
INFO - 2018-07-06 19:51:47 --> Language Class Initialized
INFO - 2018-07-06 19:51:47 --> Loader Class Initialized
INFO - 2018-07-06 19:51:47 --> Helper loaded: url_helper
INFO - 2018-07-06 19:51:47 --> Helper loaded: form_helper
INFO - 2018-07-06 19:51:47 --> Helper loaded: language_helper
DEBUG - 2018-07-06 19:51:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-06 19:51:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-06 19:51:47 --> User Agent Class Initialized
INFO - 2018-07-06 19:51:47 --> Controller Class Initialized
INFO - 2018-07-06 19:51:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-06 19:51:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-06 19:51:47 --> Pixel_Model class loaded
INFO - 2018-07-06 19:51:47 --> Database Driver Class Initialized
INFO - 2018-07-06 19:51:47 --> Model "QuestionsModel" initialized
INFO - 2018-07-06 19:51:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-06 19:51:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-06 19:51:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-06 19:51:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-06 19:51:47 --> Final output sent to browser
DEBUG - 2018-07-06 19:51:47 --> Total execution time: 0.0308
INFO - 2018-07-06 20:37:36 --> Config Class Initialized
INFO - 2018-07-06 20:37:36 --> Hooks Class Initialized
DEBUG - 2018-07-06 20:37:36 --> UTF-8 Support Enabled
INFO - 2018-07-06 20:37:36 --> Utf8 Class Initialized
INFO - 2018-07-06 20:37:36 --> URI Class Initialized
DEBUG - 2018-07-06 20:37:36 --> No URI present. Default controller set.
INFO - 2018-07-06 20:37:36 --> Router Class Initialized
INFO - 2018-07-06 20:37:36 --> Output Class Initialized
INFO - 2018-07-06 20:37:36 --> Security Class Initialized
DEBUG - 2018-07-06 20:37:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-06 20:37:36 --> CSRF cookie sent
INFO - 2018-07-06 20:37:36 --> Input Class Initialized
INFO - 2018-07-06 20:37:36 --> Language Class Initialized
INFO - 2018-07-06 20:37:36 --> Loader Class Initialized
INFO - 2018-07-06 20:37:36 --> Helper loaded: url_helper
INFO - 2018-07-06 20:37:36 --> Helper loaded: form_helper
INFO - 2018-07-06 20:37:36 --> Helper loaded: language_helper
DEBUG - 2018-07-06 20:37:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-06 20:37:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-06 20:37:36 --> User Agent Class Initialized
INFO - 2018-07-06 20:37:36 --> Controller Class Initialized
INFO - 2018-07-06 20:37:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-06 20:37:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-06 20:37:36 --> Pixel_Model class loaded
INFO - 2018-07-06 20:37:36 --> Database Driver Class Initialized
INFO - 2018-07-06 20:37:36 --> Model "QuestionsModel" initialized
INFO - 2018-07-06 20:37:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-06 20:37:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-06 20:37:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-06 20:37:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-06 20:37:36 --> Final output sent to browser
DEBUG - 2018-07-06 20:37:36 --> Total execution time: 0.0336
INFO - 2018-07-06 21:25:30 --> Config Class Initialized
INFO - 2018-07-06 21:25:30 --> Hooks Class Initialized
DEBUG - 2018-07-06 21:25:30 --> UTF-8 Support Enabled
INFO - 2018-07-06 21:25:30 --> Utf8 Class Initialized
INFO - 2018-07-06 21:25:30 --> URI Class Initialized
INFO - 2018-07-06 21:25:30 --> Router Class Initialized
INFO - 2018-07-06 21:25:30 --> Output Class Initialized
INFO - 2018-07-06 21:25:30 --> Security Class Initialized
DEBUG - 2018-07-06 21:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-06 21:25:30 --> CSRF cookie sent
INFO - 2018-07-06 21:25:30 --> Input Class Initialized
INFO - 2018-07-06 21:25:30 --> Language Class Initialized
ERROR - 2018-07-06 21:25:30 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-06 22:04:04 --> Config Class Initialized
INFO - 2018-07-06 22:04:04 --> Hooks Class Initialized
DEBUG - 2018-07-06 22:04:04 --> UTF-8 Support Enabled
INFO - 2018-07-06 22:04:04 --> Utf8 Class Initialized
INFO - 2018-07-06 22:04:04 --> URI Class Initialized
DEBUG - 2018-07-06 22:04:04 --> No URI present. Default controller set.
INFO - 2018-07-06 22:04:04 --> Router Class Initialized
INFO - 2018-07-06 22:04:04 --> Output Class Initialized
INFO - 2018-07-06 22:04:04 --> Security Class Initialized
DEBUG - 2018-07-06 22:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-06 22:04:04 --> CSRF cookie sent
INFO - 2018-07-06 22:04:04 --> Input Class Initialized
INFO - 2018-07-06 22:04:04 --> Language Class Initialized
INFO - 2018-07-06 22:04:04 --> Loader Class Initialized
INFO - 2018-07-06 22:04:04 --> Helper loaded: url_helper
INFO - 2018-07-06 22:04:04 --> Helper loaded: form_helper
INFO - 2018-07-06 22:04:04 --> Helper loaded: language_helper
DEBUG - 2018-07-06 22:04:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-06 22:04:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-06 22:04:04 --> User Agent Class Initialized
INFO - 2018-07-06 22:04:04 --> Controller Class Initialized
INFO - 2018-07-06 22:04:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-06 22:04:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-06 22:04:04 --> Pixel_Model class loaded
INFO - 2018-07-06 22:04:04 --> Database Driver Class Initialized
INFO - 2018-07-06 22:04:04 --> Model "QuestionsModel" initialized
INFO - 2018-07-06 22:04:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-06 22:04:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-06 22:04:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-06 22:04:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-06 22:04:04 --> Final output sent to browser
DEBUG - 2018-07-06 22:04:04 --> Total execution time: 0.0327

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-07-07 00:52:23 --> Config Class Initialized
INFO - 2018-07-07 00:52:23 --> Hooks Class Initialized
DEBUG - 2018-07-07 00:52:23 --> UTF-8 Support Enabled
INFO - 2018-07-07 00:52:23 --> Utf8 Class Initialized
INFO - 2018-07-07 00:52:23 --> URI Class Initialized
DEBUG - 2018-07-07 00:52:23 --> No URI present. Default controller set.
INFO - 2018-07-07 00:52:23 --> Router Class Initialized
INFO - 2018-07-07 00:52:23 --> Output Class Initialized
INFO - 2018-07-07 00:52:23 --> Security Class Initialized
DEBUG - 2018-07-07 00:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-07 00:52:23 --> CSRF cookie sent
INFO - 2018-07-07 00:52:23 --> Input Class Initialized
INFO - 2018-07-07 00:52:23 --> Language Class Initialized
INFO - 2018-07-07 00:52:23 --> Loader Class Initialized
INFO - 2018-07-07 00:52:23 --> Helper loaded: url_helper
INFO - 2018-07-07 00:52:23 --> Helper loaded: form_helper
INFO - 2018-07-07 00:52:23 --> Helper loaded: language_helper
DEBUG - 2018-07-07 00:52:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-07 00:52:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-07 00:52:23 --> User Agent Class Initialized
INFO - 2018-07-07 00:52:23 --> Controller Class Initialized
INFO - 2018-07-07 00:52:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-07 00:52:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-07 00:52:23 --> Pixel_Model class loaded
INFO - 2018-07-07 00:52:23 --> Database Driver Class Initialized
INFO - 2018-07-07 00:52:23 --> Model "QuestionsModel" initialized
INFO - 2018-07-07 00:52:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-07 00:52:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-07 00:52:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-07 00:52:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-07 00:52:23 --> Final output sent to browser
DEBUG - 2018-07-07 00:52:23 --> Total execution time: 0.0367
INFO - 2018-07-07 01:51:03 --> Config Class Initialized
INFO - 2018-07-07 01:51:03 --> Hooks Class Initialized
DEBUG - 2018-07-07 01:51:03 --> UTF-8 Support Enabled
INFO - 2018-07-07 01:51:03 --> Utf8 Class Initialized
INFO - 2018-07-07 01:51:03 --> URI Class Initialized
DEBUG - 2018-07-07 01:51:03 --> No URI present. Default controller set.
INFO - 2018-07-07 01:51:03 --> Router Class Initialized
INFO - 2018-07-07 01:51:03 --> Output Class Initialized
INFO - 2018-07-07 01:51:03 --> Security Class Initialized
DEBUG - 2018-07-07 01:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-07 01:51:03 --> CSRF cookie sent
INFO - 2018-07-07 01:51:03 --> Input Class Initialized
INFO - 2018-07-07 01:51:03 --> Language Class Initialized
INFO - 2018-07-07 01:51:03 --> Loader Class Initialized
INFO - 2018-07-07 01:51:03 --> Helper loaded: url_helper
INFO - 2018-07-07 01:51:03 --> Helper loaded: form_helper
INFO - 2018-07-07 01:51:03 --> Helper loaded: language_helper
DEBUG - 2018-07-07 01:51:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-07 01:51:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-07 01:51:03 --> User Agent Class Initialized
INFO - 2018-07-07 01:51:03 --> Controller Class Initialized
INFO - 2018-07-07 01:51:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-07 01:51:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-07 01:51:03 --> Pixel_Model class loaded
INFO - 2018-07-07 01:51:03 --> Database Driver Class Initialized
INFO - 2018-07-07 01:51:03 --> Model "QuestionsModel" initialized
INFO - 2018-07-07 01:51:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-07 01:51:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-07 01:51:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-07 01:51:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-07 01:51:03 --> Final output sent to browser
DEBUG - 2018-07-07 01:51:03 --> Total execution time: 0.0339
INFO - 2018-07-07 01:58:26 --> Config Class Initialized
INFO - 2018-07-07 01:58:26 --> Hooks Class Initialized
DEBUG - 2018-07-07 01:58:26 --> UTF-8 Support Enabled
INFO - 2018-07-07 01:58:26 --> Utf8 Class Initialized
INFO - 2018-07-07 01:58:26 --> URI Class Initialized
INFO - 2018-07-07 01:58:26 --> Router Class Initialized
INFO - 2018-07-07 01:58:26 --> Output Class Initialized
INFO - 2018-07-07 01:58:26 --> Security Class Initialized
DEBUG - 2018-07-07 01:58:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-07 01:58:26 --> CSRF cookie sent
INFO - 2018-07-07 01:58:26 --> Input Class Initialized
INFO - 2018-07-07 01:58:26 --> Language Class Initialized
INFO - 2018-07-07 01:58:26 --> Loader Class Initialized
INFO - 2018-07-07 01:58:26 --> Helper loaded: url_helper
INFO - 2018-07-07 01:58:26 --> Helper loaded: form_helper
INFO - 2018-07-07 01:58:26 --> Helper loaded: language_helper
DEBUG - 2018-07-07 01:58:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-07 01:58:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-07 01:58:26 --> User Agent Class Initialized
INFO - 2018-07-07 01:58:26 --> Controller Class Initialized
INFO - 2018-07-07 01:58:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-07 01:58:26 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-07 01:58:26 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-07 01:58:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-07 01:58:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-07 01:58:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-07 01:58:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-07 01:58:26 --> Could not find the language line "req_email"
INFO - 2018-07-07 01:58:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-07 01:58:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-07 01:58:26 --> Final output sent to browser
DEBUG - 2018-07-07 01:58:26 --> Total execution time: 0.0241
INFO - 2018-07-07 03:07:08 --> Config Class Initialized
INFO - 2018-07-07 03:07:08 --> Hooks Class Initialized
DEBUG - 2018-07-07 03:07:08 --> UTF-8 Support Enabled
INFO - 2018-07-07 03:07:08 --> Utf8 Class Initialized
INFO - 2018-07-07 03:07:08 --> URI Class Initialized
INFO - 2018-07-07 03:07:08 --> Router Class Initialized
INFO - 2018-07-07 03:07:08 --> Output Class Initialized
INFO - 2018-07-07 03:07:08 --> Security Class Initialized
DEBUG - 2018-07-07 03:07:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-07 03:07:08 --> CSRF cookie sent
INFO - 2018-07-07 03:07:08 --> Input Class Initialized
INFO - 2018-07-07 03:07:08 --> Language Class Initialized
ERROR - 2018-07-07 03:07:08 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-07 03:07:08 --> Config Class Initialized
INFO - 2018-07-07 03:07:08 --> Hooks Class Initialized
DEBUG - 2018-07-07 03:07:08 --> UTF-8 Support Enabled
INFO - 2018-07-07 03:07:08 --> Utf8 Class Initialized
INFO - 2018-07-07 03:07:08 --> URI Class Initialized
DEBUG - 2018-07-07 03:07:08 --> No URI present. Default controller set.
INFO - 2018-07-07 03:07:08 --> Router Class Initialized
INFO - 2018-07-07 03:07:08 --> Output Class Initialized
INFO - 2018-07-07 03:07:08 --> Security Class Initialized
DEBUG - 2018-07-07 03:07:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-07 03:07:08 --> CSRF cookie sent
INFO - 2018-07-07 03:07:08 --> Input Class Initialized
INFO - 2018-07-07 03:07:08 --> Language Class Initialized
INFO - 2018-07-07 03:07:08 --> Loader Class Initialized
INFO - 2018-07-07 03:07:08 --> Helper loaded: url_helper
INFO - 2018-07-07 03:07:08 --> Helper loaded: form_helper
INFO - 2018-07-07 03:07:08 --> Helper loaded: language_helper
DEBUG - 2018-07-07 03:07:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-07 03:07:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-07 03:07:08 --> User Agent Class Initialized
INFO - 2018-07-07 03:07:08 --> Controller Class Initialized
INFO - 2018-07-07 03:07:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-07 03:07:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-07 03:07:08 --> Pixel_Model class loaded
INFO - 2018-07-07 03:07:08 --> Database Driver Class Initialized
INFO - 2018-07-07 03:07:08 --> Model "QuestionsModel" initialized
INFO - 2018-07-07 03:07:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-07 03:07:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-07 03:07:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-07 03:07:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-07 03:07:08 --> Final output sent to browser
DEBUG - 2018-07-07 03:07:08 --> Total execution time: 0.0303
INFO - 2018-07-07 04:39:51 --> Config Class Initialized
INFO - 2018-07-07 04:39:51 --> Hooks Class Initialized
DEBUG - 2018-07-07 04:39:51 --> UTF-8 Support Enabled
INFO - 2018-07-07 04:39:51 --> Utf8 Class Initialized
INFO - 2018-07-07 04:39:51 --> URI Class Initialized
INFO - 2018-07-07 04:39:51 --> Router Class Initialized
INFO - 2018-07-07 04:39:51 --> Output Class Initialized
INFO - 2018-07-07 04:39:51 --> Security Class Initialized
DEBUG - 2018-07-07 04:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-07 04:39:51 --> CSRF cookie sent
INFO - 2018-07-07 04:39:51 --> Input Class Initialized
INFO - 2018-07-07 04:39:51 --> Language Class Initialized
ERROR - 2018-07-07 04:39:51 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-07 04:39:54 --> Config Class Initialized
INFO - 2018-07-07 04:39:54 --> Hooks Class Initialized
DEBUG - 2018-07-07 04:39:54 --> UTF-8 Support Enabled
INFO - 2018-07-07 04:39:54 --> Utf8 Class Initialized
INFO - 2018-07-07 04:39:54 --> URI Class Initialized
DEBUG - 2018-07-07 04:39:54 --> No URI present. Default controller set.
INFO - 2018-07-07 04:39:54 --> Router Class Initialized
INFO - 2018-07-07 04:39:54 --> Output Class Initialized
INFO - 2018-07-07 04:39:54 --> Security Class Initialized
DEBUG - 2018-07-07 04:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-07 04:39:54 --> CSRF cookie sent
INFO - 2018-07-07 04:39:54 --> Input Class Initialized
INFO - 2018-07-07 04:39:54 --> Language Class Initialized
INFO - 2018-07-07 04:39:54 --> Loader Class Initialized
INFO - 2018-07-07 04:39:54 --> Helper loaded: url_helper
INFO - 2018-07-07 04:39:54 --> Helper loaded: form_helper
INFO - 2018-07-07 04:39:54 --> Helper loaded: language_helper
DEBUG - 2018-07-07 04:39:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-07 04:39:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-07 04:39:54 --> User Agent Class Initialized
INFO - 2018-07-07 04:39:54 --> Controller Class Initialized
INFO - 2018-07-07 04:39:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-07 04:39:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-07 04:39:54 --> Pixel_Model class loaded
INFO - 2018-07-07 04:39:54 --> Database Driver Class Initialized
INFO - 2018-07-07 04:39:54 --> Model "QuestionsModel" initialized
INFO - 2018-07-07 04:39:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-07 04:39:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-07 04:39:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-07 04:39:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-07 04:39:54 --> Final output sent to browser
DEBUG - 2018-07-07 04:39:54 --> Total execution time: 0.0330
INFO - 2018-07-07 04:41:18 --> Config Class Initialized
INFO - 2018-07-07 04:41:18 --> Hooks Class Initialized
DEBUG - 2018-07-07 04:41:18 --> UTF-8 Support Enabled
INFO - 2018-07-07 04:41:18 --> Utf8 Class Initialized
INFO - 2018-07-07 04:41:18 --> URI Class Initialized
INFO - 2018-07-07 04:41:18 --> Router Class Initialized
INFO - 2018-07-07 04:41:18 --> Output Class Initialized
INFO - 2018-07-07 04:41:18 --> Security Class Initialized
DEBUG - 2018-07-07 04:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-07 04:41:18 --> CSRF cookie sent
INFO - 2018-07-07 04:41:18 --> Input Class Initialized
INFO - 2018-07-07 04:41:18 --> Language Class Initialized
INFO - 2018-07-07 04:41:18 --> Loader Class Initialized
INFO - 2018-07-07 04:41:18 --> Helper loaded: url_helper
INFO - 2018-07-07 04:41:18 --> Helper loaded: form_helper
INFO - 2018-07-07 04:41:18 --> Helper loaded: language_helper
DEBUG - 2018-07-07 04:41:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-07 04:41:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-07 04:41:18 --> User Agent Class Initialized
INFO - 2018-07-07 04:41:18 --> Controller Class Initialized
INFO - 2018-07-07 04:41:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-07 04:41:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-07 04:41:18 --> Pixel_Model class loaded
INFO - 2018-07-07 04:41:18 --> Database Driver Class Initialized
INFO - 2018-07-07 04:41:18 --> Model "QuestionsModel" initialized
INFO - 2018-07-07 04:41:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-07 04:41:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-07 04:41:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-07 04:41:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-07 04:41:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/buy_gift.php
INFO - 2018-07-07 04:41:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-07 04:41:18 --> Final output sent to browser
DEBUG - 2018-07-07 04:41:18 --> Total execution time: 0.0342
INFO - 2018-07-07 04:59:22 --> Config Class Initialized
INFO - 2018-07-07 04:59:22 --> Hooks Class Initialized
DEBUG - 2018-07-07 04:59:22 --> UTF-8 Support Enabled
INFO - 2018-07-07 04:59:22 --> Utf8 Class Initialized
INFO - 2018-07-07 04:59:22 --> URI Class Initialized
DEBUG - 2018-07-07 04:59:22 --> No URI present. Default controller set.
INFO - 2018-07-07 04:59:22 --> Router Class Initialized
INFO - 2018-07-07 04:59:22 --> Output Class Initialized
INFO - 2018-07-07 04:59:22 --> Security Class Initialized
DEBUG - 2018-07-07 04:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-07 04:59:22 --> CSRF cookie sent
INFO - 2018-07-07 04:59:22 --> Input Class Initialized
INFO - 2018-07-07 04:59:22 --> Language Class Initialized
INFO - 2018-07-07 04:59:22 --> Loader Class Initialized
INFO - 2018-07-07 04:59:22 --> Helper loaded: url_helper
INFO - 2018-07-07 04:59:22 --> Helper loaded: form_helper
INFO - 2018-07-07 04:59:22 --> Helper loaded: language_helper
DEBUG - 2018-07-07 04:59:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-07 04:59:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-07 04:59:22 --> User Agent Class Initialized
INFO - 2018-07-07 04:59:22 --> Controller Class Initialized
INFO - 2018-07-07 04:59:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-07 04:59:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-07 04:59:22 --> Pixel_Model class loaded
INFO - 2018-07-07 04:59:22 --> Database Driver Class Initialized
INFO - 2018-07-07 04:59:22 --> Model "QuestionsModel" initialized
INFO - 2018-07-07 04:59:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-07 04:59:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-07 04:59:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-07 04:59:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-07 04:59:22 --> Final output sent to browser
DEBUG - 2018-07-07 04:59:22 --> Total execution time: 0.0378
INFO - 2018-07-07 06:00:26 --> Config Class Initialized
INFO - 2018-07-07 06:00:26 --> Hooks Class Initialized
DEBUG - 2018-07-07 06:00:26 --> UTF-8 Support Enabled
INFO - 2018-07-07 06:00:26 --> Utf8 Class Initialized
INFO - 2018-07-07 06:00:26 --> URI Class Initialized
DEBUG - 2018-07-07 06:00:26 --> No URI present. Default controller set.
INFO - 2018-07-07 06:00:26 --> Router Class Initialized
INFO - 2018-07-07 06:00:26 --> Output Class Initialized
INFO - 2018-07-07 06:00:26 --> Security Class Initialized
DEBUG - 2018-07-07 06:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-07 06:00:26 --> CSRF cookie sent
INFO - 2018-07-07 06:00:26 --> Input Class Initialized
INFO - 2018-07-07 06:00:26 --> Language Class Initialized
INFO - 2018-07-07 06:00:26 --> Loader Class Initialized
INFO - 2018-07-07 06:00:26 --> Helper loaded: url_helper
INFO - 2018-07-07 06:00:26 --> Helper loaded: form_helper
INFO - 2018-07-07 06:00:26 --> Helper loaded: language_helper
DEBUG - 2018-07-07 06:00:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-07 06:00:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-07 06:00:26 --> User Agent Class Initialized
INFO - 2018-07-07 06:00:26 --> Controller Class Initialized
INFO - 2018-07-07 06:00:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-07 06:00:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-07 06:00:26 --> Pixel_Model class loaded
INFO - 2018-07-07 06:00:26 --> Database Driver Class Initialized
INFO - 2018-07-07 06:00:26 --> Model "QuestionsModel" initialized
INFO - 2018-07-07 06:00:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-07 06:00:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-07 06:00:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-07 06:00:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-07 06:00:26 --> Final output sent to browser
DEBUG - 2018-07-07 06:00:26 --> Total execution time: 0.0331
INFO - 2018-07-07 06:41:05 --> Config Class Initialized
INFO - 2018-07-07 06:41:05 --> Hooks Class Initialized
DEBUG - 2018-07-07 06:41:05 --> UTF-8 Support Enabled
INFO - 2018-07-07 06:41:05 --> Utf8 Class Initialized
INFO - 2018-07-07 06:41:05 --> URI Class Initialized
DEBUG - 2018-07-07 06:41:05 --> No URI present. Default controller set.
INFO - 2018-07-07 06:41:05 --> Router Class Initialized
INFO - 2018-07-07 06:41:05 --> Output Class Initialized
INFO - 2018-07-07 06:41:05 --> Security Class Initialized
DEBUG - 2018-07-07 06:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-07 06:41:05 --> CSRF cookie sent
INFO - 2018-07-07 06:41:05 --> Input Class Initialized
INFO - 2018-07-07 06:41:05 --> Language Class Initialized
INFO - 2018-07-07 06:41:05 --> Loader Class Initialized
INFO - 2018-07-07 06:41:05 --> Helper loaded: url_helper
INFO - 2018-07-07 06:41:05 --> Helper loaded: form_helper
INFO - 2018-07-07 06:41:05 --> Helper loaded: language_helper
DEBUG - 2018-07-07 06:41:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-07 06:41:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-07 06:41:05 --> User Agent Class Initialized
INFO - 2018-07-07 06:41:05 --> Controller Class Initialized
INFO - 2018-07-07 06:41:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-07 06:41:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-07 06:41:05 --> Pixel_Model class loaded
INFO - 2018-07-07 06:41:05 --> Database Driver Class Initialized
INFO - 2018-07-07 06:41:05 --> Model "QuestionsModel" initialized
INFO - 2018-07-07 06:41:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-07 06:41:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-07 06:41:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-07 06:41:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-07 06:41:05 --> Final output sent to browser
DEBUG - 2018-07-07 06:41:05 --> Total execution time: 0.0320
INFO - 2018-07-07 08:08:21 --> Config Class Initialized
INFO - 2018-07-07 08:08:21 --> Hooks Class Initialized
DEBUG - 2018-07-07 08:08:21 --> UTF-8 Support Enabled
INFO - 2018-07-07 08:08:21 --> Utf8 Class Initialized
INFO - 2018-07-07 08:08:21 --> URI Class Initialized
DEBUG - 2018-07-07 08:08:21 --> No URI present. Default controller set.
INFO - 2018-07-07 08:08:21 --> Router Class Initialized
INFO - 2018-07-07 08:08:21 --> Output Class Initialized
INFO - 2018-07-07 08:08:21 --> Security Class Initialized
DEBUG - 2018-07-07 08:08:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-07 08:08:21 --> CSRF cookie sent
INFO - 2018-07-07 08:08:21 --> Input Class Initialized
INFO - 2018-07-07 08:08:21 --> Language Class Initialized
INFO - 2018-07-07 08:08:21 --> Loader Class Initialized
INFO - 2018-07-07 08:08:21 --> Helper loaded: url_helper
INFO - 2018-07-07 08:08:21 --> Helper loaded: form_helper
INFO - 2018-07-07 08:08:21 --> Helper loaded: language_helper
DEBUG - 2018-07-07 08:08:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-07 08:08:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-07 08:08:21 --> User Agent Class Initialized
INFO - 2018-07-07 08:08:21 --> Controller Class Initialized
INFO - 2018-07-07 08:08:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-07 08:08:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-07 08:08:21 --> Pixel_Model class loaded
INFO - 2018-07-07 08:08:21 --> Database Driver Class Initialized
INFO - 2018-07-07 08:08:21 --> Model "QuestionsModel" initialized
INFO - 2018-07-07 08:08:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-07 08:08:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-07 08:08:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-07 08:08:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-07 08:08:21 --> Final output sent to browser
DEBUG - 2018-07-07 08:08:21 --> Total execution time: 0.0401
INFO - 2018-07-07 09:50:12 --> Config Class Initialized
INFO - 2018-07-07 09:50:12 --> Hooks Class Initialized
DEBUG - 2018-07-07 09:50:12 --> UTF-8 Support Enabled
INFO - 2018-07-07 09:50:12 --> Utf8 Class Initialized
INFO - 2018-07-07 09:50:12 --> URI Class Initialized
DEBUG - 2018-07-07 09:50:12 --> No URI present. Default controller set.
INFO - 2018-07-07 09:50:12 --> Router Class Initialized
INFO - 2018-07-07 09:50:12 --> Output Class Initialized
INFO - 2018-07-07 09:50:12 --> Security Class Initialized
DEBUG - 2018-07-07 09:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-07 09:50:12 --> CSRF cookie sent
INFO - 2018-07-07 09:50:12 --> Input Class Initialized
INFO - 2018-07-07 09:50:12 --> Language Class Initialized
INFO - 2018-07-07 09:50:12 --> Loader Class Initialized
INFO - 2018-07-07 09:50:12 --> Helper loaded: url_helper
INFO - 2018-07-07 09:50:12 --> Helper loaded: form_helper
INFO - 2018-07-07 09:50:12 --> Helper loaded: language_helper
DEBUG - 2018-07-07 09:50:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-07 09:50:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-07 09:50:12 --> User Agent Class Initialized
INFO - 2018-07-07 09:50:12 --> Controller Class Initialized
INFO - 2018-07-07 09:50:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-07 09:50:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-07 09:50:12 --> Pixel_Model class loaded
INFO - 2018-07-07 09:50:12 --> Database Driver Class Initialized
INFO - 2018-07-07 09:50:12 --> Model "QuestionsModel" initialized
INFO - 2018-07-07 09:50:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-07 09:50:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-07 09:50:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-07 09:50:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-07 09:50:12 --> Final output sent to browser
DEBUG - 2018-07-07 09:50:12 --> Total execution time: 0.0332
INFO - 2018-07-07 13:16:12 --> Config Class Initialized
INFO - 2018-07-07 13:16:12 --> Hooks Class Initialized
DEBUG - 2018-07-07 13:16:12 --> UTF-8 Support Enabled
INFO - 2018-07-07 13:16:12 --> Utf8 Class Initialized
INFO - 2018-07-07 13:16:12 --> URI Class Initialized
DEBUG - 2018-07-07 13:16:12 --> No URI present. Default controller set.
INFO - 2018-07-07 13:16:12 --> Router Class Initialized
INFO - 2018-07-07 13:16:12 --> Output Class Initialized
INFO - 2018-07-07 13:16:12 --> Security Class Initialized
DEBUG - 2018-07-07 13:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-07 13:16:12 --> CSRF cookie sent
INFO - 2018-07-07 13:16:12 --> Input Class Initialized
INFO - 2018-07-07 13:16:12 --> Language Class Initialized
INFO - 2018-07-07 13:16:12 --> Loader Class Initialized
INFO - 2018-07-07 13:16:12 --> Helper loaded: url_helper
INFO - 2018-07-07 13:16:12 --> Helper loaded: form_helper
INFO - 2018-07-07 13:16:12 --> Helper loaded: language_helper
DEBUG - 2018-07-07 13:16:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-07 13:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-07 13:16:12 --> User Agent Class Initialized
INFO - 2018-07-07 13:16:12 --> Controller Class Initialized
INFO - 2018-07-07 13:16:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-07 13:16:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-07 13:16:12 --> Pixel_Model class loaded
INFO - 2018-07-07 13:16:12 --> Database Driver Class Initialized
INFO - 2018-07-07 13:16:12 --> Model "QuestionsModel" initialized
INFO - 2018-07-07 13:16:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-07 13:16:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-07 13:16:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-07 13:16:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-07 13:16:12 --> Final output sent to browser
DEBUG - 2018-07-07 13:16:12 --> Total execution time: 0.0359
INFO - 2018-07-07 13:16:21 --> Config Class Initialized
INFO - 2018-07-07 13:16:21 --> Hooks Class Initialized
DEBUG - 2018-07-07 13:16:21 --> UTF-8 Support Enabled
INFO - 2018-07-07 13:16:21 --> Utf8 Class Initialized
INFO - 2018-07-07 13:16:21 --> URI Class Initialized
INFO - 2018-07-07 13:16:21 --> Router Class Initialized
INFO - 2018-07-07 13:16:21 --> Output Class Initialized
INFO - 2018-07-07 13:16:21 --> Security Class Initialized
DEBUG - 2018-07-07 13:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-07 13:16:21 --> CSRF cookie sent
INFO - 2018-07-07 13:16:21 --> Input Class Initialized
INFO - 2018-07-07 13:16:21 --> Language Class Initialized
ERROR - 2018-07-07 13:16:21 --> 404 Page Not Found: Apple-touch-icon-120x120-precomposedpng/index
INFO - 2018-07-07 13:16:21 --> Config Class Initialized
INFO - 2018-07-07 13:16:21 --> Hooks Class Initialized
DEBUG - 2018-07-07 13:16:21 --> UTF-8 Support Enabled
INFO - 2018-07-07 13:16:21 --> Utf8 Class Initialized
INFO - 2018-07-07 13:16:21 --> URI Class Initialized
INFO - 2018-07-07 13:16:21 --> Router Class Initialized
INFO - 2018-07-07 13:16:21 --> Output Class Initialized
INFO - 2018-07-07 13:16:21 --> Security Class Initialized
DEBUG - 2018-07-07 13:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-07 13:16:21 --> CSRF cookie sent
INFO - 2018-07-07 13:16:21 --> Input Class Initialized
INFO - 2018-07-07 13:16:21 --> Language Class Initialized
ERROR - 2018-07-07 13:16:21 --> 404 Page Not Found: Apple-touch-icon-120x120png/index
INFO - 2018-07-07 13:16:21 --> Config Class Initialized
INFO - 2018-07-07 13:16:21 --> Hooks Class Initialized
DEBUG - 2018-07-07 13:16:21 --> UTF-8 Support Enabled
INFO - 2018-07-07 13:16:21 --> Utf8 Class Initialized
INFO - 2018-07-07 13:16:21 --> URI Class Initialized
INFO - 2018-07-07 13:16:21 --> Router Class Initialized
INFO - 2018-07-07 13:16:21 --> Output Class Initialized
INFO - 2018-07-07 13:16:21 --> Security Class Initialized
DEBUG - 2018-07-07 13:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-07 13:16:21 --> CSRF cookie sent
INFO - 2018-07-07 13:16:21 --> Input Class Initialized
INFO - 2018-07-07 13:16:21 --> Language Class Initialized
ERROR - 2018-07-07 13:16:21 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
INFO - 2018-07-07 13:16:21 --> Config Class Initialized
INFO - 2018-07-07 13:16:21 --> Hooks Class Initialized
DEBUG - 2018-07-07 13:16:21 --> UTF-8 Support Enabled
INFO - 2018-07-07 13:16:21 --> Utf8 Class Initialized
INFO - 2018-07-07 13:16:21 --> URI Class Initialized
INFO - 2018-07-07 13:16:21 --> Router Class Initialized
INFO - 2018-07-07 13:16:21 --> Output Class Initialized
INFO - 2018-07-07 13:16:21 --> Security Class Initialized
DEBUG - 2018-07-07 13:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-07 13:16:21 --> CSRF cookie sent
INFO - 2018-07-07 13:16:21 --> Input Class Initialized
INFO - 2018-07-07 13:16:21 --> Language Class Initialized
ERROR - 2018-07-07 13:16:21 --> 404 Page Not Found: Apple-touch-iconpng/index
INFO - 2018-07-07 13:16:37 --> Config Class Initialized
INFO - 2018-07-07 13:16:37 --> Hooks Class Initialized
DEBUG - 2018-07-07 13:16:37 --> UTF-8 Support Enabled
INFO - 2018-07-07 13:16:37 --> Utf8 Class Initialized
INFO - 2018-07-07 13:16:37 --> URI Class Initialized
INFO - 2018-07-07 13:16:37 --> Router Class Initialized
INFO - 2018-07-07 13:16:37 --> Output Class Initialized
INFO - 2018-07-07 13:16:37 --> Security Class Initialized
DEBUG - 2018-07-07 13:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-07 13:16:37 --> CSRF cookie sent
INFO - 2018-07-07 13:16:37 --> CSRF token verified
INFO - 2018-07-07 13:16:37 --> Input Class Initialized
INFO - 2018-07-07 13:16:37 --> Language Class Initialized
INFO - 2018-07-07 13:16:37 --> Loader Class Initialized
INFO - 2018-07-07 13:16:37 --> Helper loaded: url_helper
INFO - 2018-07-07 13:16:37 --> Helper loaded: form_helper
INFO - 2018-07-07 13:16:37 --> Helper loaded: language_helper
DEBUG - 2018-07-07 13:16:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-07 13:16:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-07 13:16:37 --> User Agent Class Initialized
INFO - 2018-07-07 13:16:37 --> Controller Class Initialized
INFO - 2018-07-07 13:16:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-07 13:16:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-07 13:16:37 --> Pixel_Model class loaded
INFO - 2018-07-07 13:16:37 --> Database Driver Class Initialized
INFO - 2018-07-07 13:16:37 --> Model "QuestionsModel" initialized
INFO - 2018-07-07 13:16:37 --> Config Class Initialized
INFO - 2018-07-07 13:16:37 --> Hooks Class Initialized
DEBUG - 2018-07-07 13:16:37 --> UTF-8 Support Enabled
INFO - 2018-07-07 13:16:37 --> Utf8 Class Initialized
INFO - 2018-07-07 13:16:37 --> URI Class Initialized
INFO - 2018-07-07 13:16:37 --> Router Class Initialized
INFO - 2018-07-07 13:16:37 --> Output Class Initialized
INFO - 2018-07-07 13:16:37 --> Security Class Initialized
DEBUG - 2018-07-07 13:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-07 13:16:37 --> CSRF cookie sent
INFO - 2018-07-07 13:16:37 --> Input Class Initialized
INFO - 2018-07-07 13:16:37 --> Language Class Initialized
INFO - 2018-07-07 13:16:37 --> Loader Class Initialized
INFO - 2018-07-07 13:16:37 --> Helper loaded: url_helper
INFO - 2018-07-07 13:16:37 --> Helper loaded: form_helper
INFO - 2018-07-07 13:16:37 --> Helper loaded: language_helper
DEBUG - 2018-07-07 13:16:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-07 13:16:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-07 13:16:37 --> User Agent Class Initialized
INFO - 2018-07-07 13:16:37 --> Controller Class Initialized
INFO - 2018-07-07 13:16:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-07 13:16:37 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-07 13:16:37 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-07 13:16:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-07 13:16:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-07 13:16:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-07 13:16:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-07 13:16:37 --> Could not find the language line "req_email"
INFO - 2018-07-07 13:16:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-07 13:16:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-07 13:16:37 --> Final output sent to browser
DEBUG - 2018-07-07 13:16:37 --> Total execution time: 0.0238
INFO - 2018-07-07 17:29:43 --> Config Class Initialized
INFO - 2018-07-07 17:29:43 --> Hooks Class Initialized
DEBUG - 2018-07-07 17:29:43 --> UTF-8 Support Enabled
INFO - 2018-07-07 17:29:43 --> Utf8 Class Initialized
INFO - 2018-07-07 17:29:43 --> URI Class Initialized
INFO - 2018-07-07 17:29:43 --> Router Class Initialized
INFO - 2018-07-07 17:29:43 --> Output Class Initialized
INFO - 2018-07-07 17:29:43 --> Security Class Initialized
DEBUG - 2018-07-07 17:29:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-07 17:29:43 --> CSRF cookie sent
INFO - 2018-07-07 17:29:43 --> Input Class Initialized
INFO - 2018-07-07 17:29:43 --> Language Class Initialized
ERROR - 2018-07-07 17:29:43 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-07 17:50:41 --> Config Class Initialized
INFO - 2018-07-07 17:50:41 --> Hooks Class Initialized
DEBUG - 2018-07-07 17:50:41 --> UTF-8 Support Enabled
INFO - 2018-07-07 17:50:41 --> Utf8 Class Initialized
INFO - 2018-07-07 17:50:41 --> URI Class Initialized
DEBUG - 2018-07-07 17:50:41 --> No URI present. Default controller set.
INFO - 2018-07-07 17:50:41 --> Router Class Initialized
INFO - 2018-07-07 17:50:41 --> Output Class Initialized
INFO - 2018-07-07 17:50:41 --> Security Class Initialized
DEBUG - 2018-07-07 17:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-07 17:50:41 --> CSRF cookie sent
INFO - 2018-07-07 17:50:41 --> Input Class Initialized
INFO - 2018-07-07 17:50:41 --> Language Class Initialized
INFO - 2018-07-07 17:50:41 --> Loader Class Initialized
INFO - 2018-07-07 17:50:41 --> Helper loaded: url_helper
INFO - 2018-07-07 17:50:41 --> Helper loaded: form_helper
INFO - 2018-07-07 17:50:41 --> Helper loaded: language_helper
DEBUG - 2018-07-07 17:50:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-07 17:50:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-07 17:50:41 --> User Agent Class Initialized
INFO - 2018-07-07 17:50:41 --> Controller Class Initialized
INFO - 2018-07-07 17:50:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-07 17:50:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-07 17:50:41 --> Pixel_Model class loaded
INFO - 2018-07-07 17:50:41 --> Database Driver Class Initialized
INFO - 2018-07-07 17:50:41 --> Model "QuestionsModel" initialized
INFO - 2018-07-07 17:50:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-07 17:50:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-07 17:50:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-07 17:50:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-07 17:50:41 --> Final output sent to browser
DEBUG - 2018-07-07 17:50:41 --> Total execution time: 0.0323
INFO - 2018-07-07 18:04:48 --> Config Class Initialized
INFO - 2018-07-07 18:04:48 --> Hooks Class Initialized
DEBUG - 2018-07-07 18:04:48 --> UTF-8 Support Enabled
INFO - 2018-07-07 18:04:48 --> Utf8 Class Initialized
INFO - 2018-07-07 18:04:48 --> URI Class Initialized
DEBUG - 2018-07-07 18:04:48 --> No URI present. Default controller set.
INFO - 2018-07-07 18:04:48 --> Router Class Initialized
INFO - 2018-07-07 18:04:48 --> Output Class Initialized
INFO - 2018-07-07 18:04:48 --> Security Class Initialized
DEBUG - 2018-07-07 18:04:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-07 18:04:48 --> CSRF cookie sent
INFO - 2018-07-07 18:04:48 --> Input Class Initialized
INFO - 2018-07-07 18:04:48 --> Language Class Initialized
INFO - 2018-07-07 18:04:48 --> Loader Class Initialized
INFO - 2018-07-07 18:04:48 --> Helper loaded: url_helper
INFO - 2018-07-07 18:04:48 --> Helper loaded: form_helper
INFO - 2018-07-07 18:04:48 --> Helper loaded: language_helper
DEBUG - 2018-07-07 18:04:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-07 18:04:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-07 18:04:48 --> User Agent Class Initialized
INFO - 2018-07-07 18:04:48 --> Controller Class Initialized
INFO - 2018-07-07 18:04:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-07 18:04:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-07 18:04:48 --> Pixel_Model class loaded
INFO - 2018-07-07 18:04:48 --> Database Driver Class Initialized
INFO - 2018-07-07 18:04:48 --> Model "QuestionsModel" initialized
INFO - 2018-07-07 18:04:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-07 18:04:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-07 18:04:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-07 18:04:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-07 18:04:48 --> Final output sent to browser
DEBUG - 2018-07-07 18:04:48 --> Total execution time: 0.0325
INFO - 2018-07-07 18:19:23 --> Config Class Initialized
INFO - 2018-07-07 18:19:23 --> Hooks Class Initialized
DEBUG - 2018-07-07 18:19:23 --> UTF-8 Support Enabled
INFO - 2018-07-07 18:19:23 --> Utf8 Class Initialized
INFO - 2018-07-07 18:19:23 --> URI Class Initialized
DEBUG - 2018-07-07 18:19:23 --> No URI present. Default controller set.
INFO - 2018-07-07 18:19:23 --> Router Class Initialized
INFO - 2018-07-07 18:19:23 --> Output Class Initialized
INFO - 2018-07-07 18:19:23 --> Security Class Initialized
DEBUG - 2018-07-07 18:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-07 18:19:23 --> CSRF cookie sent
INFO - 2018-07-07 18:19:23 --> Input Class Initialized
INFO - 2018-07-07 18:19:23 --> Language Class Initialized
INFO - 2018-07-07 18:19:23 --> Loader Class Initialized
INFO - 2018-07-07 18:19:23 --> Helper loaded: url_helper
INFO - 2018-07-07 18:19:23 --> Helper loaded: form_helper
INFO - 2018-07-07 18:19:23 --> Helper loaded: language_helper
DEBUG - 2018-07-07 18:19:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-07 18:19:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-07 18:19:23 --> User Agent Class Initialized
INFO - 2018-07-07 18:19:23 --> Controller Class Initialized
INFO - 2018-07-07 18:19:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-07 18:19:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-07 18:19:23 --> Pixel_Model class loaded
INFO - 2018-07-07 18:19:23 --> Database Driver Class Initialized
INFO - 2018-07-07 18:19:23 --> Model "QuestionsModel" initialized
INFO - 2018-07-07 18:19:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-07 18:19:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-07 18:19:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-07 18:19:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-07 18:19:23 --> Final output sent to browser
DEBUG - 2018-07-07 18:19:23 --> Total execution time: 0.0474
INFO - 2018-07-07 18:19:23 --> Config Class Initialized
INFO - 2018-07-07 18:19:23 --> Hooks Class Initialized
DEBUG - 2018-07-07 18:19:23 --> UTF-8 Support Enabled
INFO - 2018-07-07 18:19:23 --> Utf8 Class Initialized
INFO - 2018-07-07 18:19:23 --> URI Class Initialized
DEBUG - 2018-07-07 18:19:23 --> No URI present. Default controller set.
INFO - 2018-07-07 18:19:23 --> Router Class Initialized
INFO - 2018-07-07 18:19:23 --> Output Class Initialized
INFO - 2018-07-07 18:19:23 --> Security Class Initialized
DEBUG - 2018-07-07 18:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-07 18:19:23 --> CSRF cookie sent
INFO - 2018-07-07 18:19:23 --> Input Class Initialized
INFO - 2018-07-07 18:19:23 --> Language Class Initialized
INFO - 2018-07-07 18:19:23 --> Loader Class Initialized
INFO - 2018-07-07 18:19:23 --> Helper loaded: url_helper
INFO - 2018-07-07 18:19:23 --> Helper loaded: form_helper
INFO - 2018-07-07 18:19:23 --> Helper loaded: language_helper
DEBUG - 2018-07-07 18:19:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-07 18:19:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-07 18:19:23 --> User Agent Class Initialized
INFO - 2018-07-07 18:19:23 --> Controller Class Initialized
INFO - 2018-07-07 18:19:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-07 18:19:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-07 18:19:23 --> Pixel_Model class loaded
INFO - 2018-07-07 18:19:23 --> Database Driver Class Initialized
INFO - 2018-07-07 18:19:23 --> Model "QuestionsModel" initialized
INFO - 2018-07-07 18:19:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-07 18:19:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-07 18:19:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-07 18:19:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-07 18:19:23 --> Final output sent to browser
DEBUG - 2018-07-07 18:19:23 --> Total execution time: 0.0313
INFO - 2018-07-07 18:19:24 --> Config Class Initialized
INFO - 2018-07-07 18:19:24 --> Hooks Class Initialized
DEBUG - 2018-07-07 18:19:24 --> UTF-8 Support Enabled
INFO - 2018-07-07 18:19:24 --> Utf8 Class Initialized
INFO - 2018-07-07 18:19:24 --> URI Class Initialized
DEBUG - 2018-07-07 18:19:24 --> No URI present. Default controller set.
INFO - 2018-07-07 18:19:24 --> Router Class Initialized
INFO - 2018-07-07 18:19:24 --> Output Class Initialized
INFO - 2018-07-07 18:19:24 --> Security Class Initialized
DEBUG - 2018-07-07 18:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-07 18:19:24 --> CSRF cookie sent
INFO - 2018-07-07 18:19:24 --> Input Class Initialized
INFO - 2018-07-07 18:19:24 --> Language Class Initialized
INFO - 2018-07-07 18:19:24 --> Loader Class Initialized
INFO - 2018-07-07 18:19:24 --> Helper loaded: url_helper
INFO - 2018-07-07 18:19:24 --> Helper loaded: form_helper
INFO - 2018-07-07 18:19:24 --> Helper loaded: language_helper
DEBUG - 2018-07-07 18:19:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-07 18:19:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-07 18:19:24 --> User Agent Class Initialized
INFO - 2018-07-07 18:19:24 --> Controller Class Initialized
INFO - 2018-07-07 18:19:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-07 18:19:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-07 18:19:24 --> Pixel_Model class loaded
INFO - 2018-07-07 18:19:24 --> Database Driver Class Initialized
INFO - 2018-07-07 18:19:24 --> Model "QuestionsModel" initialized
INFO - 2018-07-07 18:19:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-07 18:19:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-07 18:19:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-07 18:19:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-07 18:19:24 --> Final output sent to browser
DEBUG - 2018-07-07 18:19:24 --> Total execution time: 0.0320
INFO - 2018-07-07 18:19:25 --> Config Class Initialized
INFO - 2018-07-07 18:19:25 --> Hooks Class Initialized
DEBUG - 2018-07-07 18:19:25 --> UTF-8 Support Enabled
INFO - 2018-07-07 18:19:25 --> Utf8 Class Initialized
INFO - 2018-07-07 18:19:25 --> URI Class Initialized
INFO - 2018-07-07 18:19:25 --> Router Class Initialized
INFO - 2018-07-07 18:19:25 --> Output Class Initialized
INFO - 2018-07-07 18:19:25 --> Security Class Initialized
DEBUG - 2018-07-07 18:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-07 18:19:25 --> CSRF cookie sent
INFO - 2018-07-07 18:19:25 --> Input Class Initialized
INFO - 2018-07-07 18:19:25 --> Language Class Initialized
ERROR - 2018-07-07 18:19:25 --> 404 Page Not Found: 405shtml/index
INFO - 2018-07-07 18:19:32 --> Config Class Initialized
INFO - 2018-07-07 18:19:32 --> Hooks Class Initialized
DEBUG - 2018-07-07 18:19:32 --> UTF-8 Support Enabled
INFO - 2018-07-07 18:19:32 --> Utf8 Class Initialized
INFO - 2018-07-07 18:19:32 --> URI Class Initialized
DEBUG - 2018-07-07 18:19:32 --> No URI present. Default controller set.
INFO - 2018-07-07 18:19:32 --> Router Class Initialized
INFO - 2018-07-07 18:19:32 --> Output Class Initialized
INFO - 2018-07-07 18:19:32 --> Security Class Initialized
DEBUG - 2018-07-07 18:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-07 18:19:32 --> CSRF cookie sent
INFO - 2018-07-07 18:19:32 --> Input Class Initialized
INFO - 2018-07-07 18:19:32 --> Language Class Initialized
INFO - 2018-07-07 18:19:32 --> Loader Class Initialized
INFO - 2018-07-07 18:19:32 --> Helper loaded: url_helper
INFO - 2018-07-07 18:19:32 --> Helper loaded: form_helper
INFO - 2018-07-07 18:19:32 --> Helper loaded: language_helper
DEBUG - 2018-07-07 18:19:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-07 18:19:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-07 18:19:32 --> User Agent Class Initialized
INFO - 2018-07-07 18:19:32 --> Controller Class Initialized
INFO - 2018-07-07 18:19:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-07 18:19:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-07 18:19:32 --> Pixel_Model class loaded
INFO - 2018-07-07 18:19:32 --> Database Driver Class Initialized
INFO - 2018-07-07 18:19:32 --> Model "QuestionsModel" initialized
INFO - 2018-07-07 18:19:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-07 18:19:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-07 18:19:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-07 18:19:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-07 18:19:32 --> Final output sent to browser
DEBUG - 2018-07-07 18:19:32 --> Total execution time: 0.0359
INFO - 2018-07-07 18:19:32 --> Config Class Initialized
INFO - 2018-07-07 18:19:32 --> Hooks Class Initialized
DEBUG - 2018-07-07 18:19:32 --> UTF-8 Support Enabled
INFO - 2018-07-07 18:19:32 --> Utf8 Class Initialized
INFO - 2018-07-07 18:19:32 --> URI Class Initialized
INFO - 2018-07-07 18:19:32 --> Router Class Initialized
INFO - 2018-07-07 18:19:32 --> Output Class Initialized
INFO - 2018-07-07 18:19:32 --> Security Class Initialized
DEBUG - 2018-07-07 18:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-07 18:19:32 --> CSRF cookie sent
INFO - 2018-07-07 18:19:32 --> Input Class Initialized
INFO - 2018-07-07 18:19:32 --> Language Class Initialized
ERROR - 2018-07-07 18:19:32 --> 404 Page Not Found: 404testpage4525d2fdc/index
INFO - 2018-07-07 18:19:32 --> Config Class Initialized
INFO - 2018-07-07 18:19:32 --> Hooks Class Initialized
DEBUG - 2018-07-07 18:19:32 --> UTF-8 Support Enabled
INFO - 2018-07-07 18:19:32 --> Utf8 Class Initialized
INFO - 2018-07-07 18:19:32 --> URI Class Initialized
INFO - 2018-07-07 18:19:32 --> Router Class Initialized
INFO - 2018-07-07 18:19:32 --> Output Class Initialized
INFO - 2018-07-07 18:19:32 --> Security Class Initialized
DEBUG - 2018-07-07 18:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-07 18:19:32 --> CSRF cookie sent
INFO - 2018-07-07 18:19:32 --> Input Class Initialized
INFO - 2018-07-07 18:19:32 --> Language Class Initialized
ERROR - 2018-07-07 18:19:32 --> 404 Page Not Found: 404javascriptjs/index
INFO - 2018-07-07 18:19:33 --> Config Class Initialized
INFO - 2018-07-07 18:19:33 --> Hooks Class Initialized
DEBUG - 2018-07-07 18:19:33 --> UTF-8 Support Enabled
INFO - 2018-07-07 18:19:33 --> Utf8 Class Initialized
INFO - 2018-07-07 18:19:33 --> URI Class Initialized
INFO - 2018-07-07 18:19:33 --> Router Class Initialized
INFO - 2018-07-07 18:19:33 --> Output Class Initialized
INFO - 2018-07-07 18:19:33 --> Security Class Initialized
DEBUG - 2018-07-07 18:19:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-07 18:19:33 --> CSRF cookie sent
INFO - 2018-07-07 18:19:33 --> Input Class Initialized
INFO - 2018-07-07 18:19:33 --> Language Class Initialized
INFO - 2018-07-07 18:19:33 --> Loader Class Initialized
INFO - 2018-07-07 18:19:33 --> Helper loaded: url_helper
INFO - 2018-07-07 18:19:33 --> Helper loaded: form_helper
INFO - 2018-07-07 18:19:33 --> Helper loaded: language_helper
DEBUG - 2018-07-07 18:19:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-07 18:19:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-07 18:19:33 --> User Agent Class Initialized
INFO - 2018-07-07 18:19:33 --> Controller Class Initialized
INFO - 2018-07-07 18:19:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-07 18:19:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-07 18:19:33 --> Pixel_Model class loaded
INFO - 2018-07-07 18:19:33 --> Database Driver Class Initialized
INFO - 2018-07-07 18:19:33 --> Model "QuestionsModel" initialized
INFO - 2018-07-07 18:19:33 --> Config Class Initialized
INFO - 2018-07-07 18:19:33 --> Hooks Class Initialized
DEBUG - 2018-07-07 18:19:33 --> UTF-8 Support Enabled
INFO - 2018-07-07 18:19:33 --> Utf8 Class Initialized
INFO - 2018-07-07 18:19:33 --> URI Class Initialized
INFO - 2018-07-07 18:19:33 --> Router Class Initialized
INFO - 2018-07-07 18:19:33 --> Output Class Initialized
INFO - 2018-07-07 18:19:33 --> Security Class Initialized
DEBUG - 2018-07-07 18:19:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-07 18:19:33 --> CSRF cookie sent
INFO - 2018-07-07 18:19:33 --> Input Class Initialized
INFO - 2018-07-07 18:19:33 --> Language Class Initialized
INFO - 2018-07-07 18:19:33 --> Loader Class Initialized
INFO - 2018-07-07 18:19:33 --> Helper loaded: url_helper
INFO - 2018-07-07 18:19:33 --> Helper loaded: form_helper
INFO - 2018-07-07 18:19:33 --> Helper loaded: language_helper
DEBUG - 2018-07-07 18:19:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-07 18:19:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-07 18:19:33 --> User Agent Class Initialized
INFO - 2018-07-07 18:19:33 --> Controller Class Initialized
INFO - 2018-07-07 18:19:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-07 18:19:33 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-07 18:19:33 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-07 18:19:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-07 18:19:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-07 18:19:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-07 18:19:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-07 18:19:33 --> Could not find the language line "req_email"
INFO - 2018-07-07 18:19:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-07 18:19:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-07 18:19:33 --> Final output sent to browser
DEBUG - 2018-07-07 18:19:33 --> Total execution time: 0.0226
INFO - 2018-07-07 18:19:33 --> Config Class Initialized
INFO - 2018-07-07 18:19:33 --> Hooks Class Initialized
DEBUG - 2018-07-07 18:19:33 --> UTF-8 Support Enabled
INFO - 2018-07-07 18:19:33 --> Utf8 Class Initialized
INFO - 2018-07-07 18:19:33 --> URI Class Initialized
INFO - 2018-07-07 18:19:33 --> Router Class Initialized
INFO - 2018-07-07 18:19:33 --> Output Class Initialized
INFO - 2018-07-07 18:19:33 --> Security Class Initialized
DEBUG - 2018-07-07 18:19:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-07 18:19:33 --> CSRF cookie sent
INFO - 2018-07-07 18:19:33 --> Input Class Initialized
INFO - 2018-07-07 18:19:33 --> Language Class Initialized
INFO - 2018-07-07 18:19:33 --> Loader Class Initialized
INFO - 2018-07-07 18:19:33 --> Helper loaded: url_helper
INFO - 2018-07-07 18:19:33 --> Helper loaded: form_helper
INFO - 2018-07-07 18:19:33 --> Helper loaded: language_helper
DEBUG - 2018-07-07 18:19:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-07 18:19:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-07 18:19:33 --> User Agent Class Initialized
INFO - 2018-07-07 18:19:33 --> Controller Class Initialized
INFO - 2018-07-07 18:19:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-07 18:19:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-07 18:19:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-07 18:19:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-07 18:19:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-07 18:19:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-07 18:19:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-07-07 18:19:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-07 18:19:33 --> Final output sent to browser
DEBUG - 2018-07-07 18:19:33 --> Total execution time: 0.0296
INFO - 2018-07-07 18:19:33 --> Config Class Initialized
INFO - 2018-07-07 18:19:33 --> Hooks Class Initialized
DEBUG - 2018-07-07 18:19:33 --> UTF-8 Support Enabled
INFO - 2018-07-07 18:19:33 --> Utf8 Class Initialized
INFO - 2018-07-07 18:19:33 --> URI Class Initialized
INFO - 2018-07-07 18:19:33 --> Router Class Initialized
INFO - 2018-07-07 18:19:33 --> Output Class Initialized
INFO - 2018-07-07 18:19:33 --> Security Class Initialized
DEBUG - 2018-07-07 18:19:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-07 18:19:33 --> CSRF cookie sent
INFO - 2018-07-07 18:19:33 --> Input Class Initialized
INFO - 2018-07-07 18:19:33 --> Language Class Initialized
INFO - 2018-07-07 18:19:33 --> Loader Class Initialized
INFO - 2018-07-07 18:19:33 --> Helper loaded: url_helper
INFO - 2018-07-07 18:19:33 --> Helper loaded: form_helper
INFO - 2018-07-07 18:19:33 --> Helper loaded: language_helper
DEBUG - 2018-07-07 18:19:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-07 18:19:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-07 18:19:33 --> User Agent Class Initialized
INFO - 2018-07-07 18:19:33 --> Controller Class Initialized
INFO - 2018-07-07 18:19:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-07 18:19:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-07 18:19:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-07 18:19:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-07 18:19:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-07 18:19:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-07 18:19:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-07-07 18:19:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-07 18:19:33 --> Final output sent to browser
DEBUG - 2018-07-07 18:19:33 --> Total execution time: 0.0237
INFO - 2018-07-07 18:19:34 --> Config Class Initialized
INFO - 2018-07-07 18:19:34 --> Hooks Class Initialized
DEBUG - 2018-07-07 18:19:34 --> UTF-8 Support Enabled
INFO - 2018-07-07 18:19:34 --> Utf8 Class Initialized
INFO - 2018-07-07 18:19:34 --> URI Class Initialized
INFO - 2018-07-07 18:19:34 --> Router Class Initialized
INFO - 2018-07-07 18:19:34 --> Output Class Initialized
INFO - 2018-07-07 18:19:34 --> Security Class Initialized
DEBUG - 2018-07-07 18:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-07 18:19:34 --> CSRF cookie sent
INFO - 2018-07-07 18:19:34 --> Input Class Initialized
INFO - 2018-07-07 18:19:34 --> Language Class Initialized
INFO - 2018-07-07 18:19:34 --> Loader Class Initialized
INFO - 2018-07-07 18:19:34 --> Helper loaded: url_helper
INFO - 2018-07-07 18:19:34 --> Helper loaded: form_helper
INFO - 2018-07-07 18:19:34 --> Helper loaded: language_helper
DEBUG - 2018-07-07 18:19:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-07 18:19:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-07 18:19:34 --> User Agent Class Initialized
INFO - 2018-07-07 18:19:34 --> Controller Class Initialized
INFO - 2018-07-07 18:19:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-07 18:19:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-07 18:19:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-07 18:19:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-07 18:19:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-07 18:19:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-07 18:19:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-07-07 18:19:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-07 18:19:34 --> Final output sent to browser
DEBUG - 2018-07-07 18:19:34 --> Total execution time: 0.0205
INFO - 2018-07-07 18:19:34 --> Config Class Initialized
INFO - 2018-07-07 18:19:34 --> Hooks Class Initialized
DEBUG - 2018-07-07 18:19:34 --> UTF-8 Support Enabled
INFO - 2018-07-07 18:19:34 --> Utf8 Class Initialized
INFO - 2018-07-07 18:19:34 --> URI Class Initialized
INFO - 2018-07-07 18:19:34 --> Router Class Initialized
INFO - 2018-07-07 18:19:34 --> Output Class Initialized
INFO - 2018-07-07 18:19:34 --> Security Class Initialized
DEBUG - 2018-07-07 18:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-07 18:19:34 --> CSRF cookie sent
INFO - 2018-07-07 18:19:34 --> Input Class Initialized
INFO - 2018-07-07 18:19:34 --> Language Class Initialized
INFO - 2018-07-07 18:19:34 --> Loader Class Initialized
INFO - 2018-07-07 18:19:34 --> Helper loaded: url_helper
INFO - 2018-07-07 18:19:34 --> Helper loaded: form_helper
INFO - 2018-07-07 18:19:34 --> Helper loaded: language_helper
DEBUG - 2018-07-07 18:19:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-07 18:19:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-07 18:19:34 --> User Agent Class Initialized
INFO - 2018-07-07 18:19:34 --> Controller Class Initialized
INFO - 2018-07-07 18:19:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-07 18:19:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-07 18:19:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-07 18:19:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-07 18:19:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-07 18:19:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-07 18:19:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-07-07 18:19:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-07 18:19:34 --> Final output sent to browser
DEBUG - 2018-07-07 18:19:34 --> Total execution time: 0.0215
INFO - 2018-07-07 18:19:34 --> Config Class Initialized
INFO - 2018-07-07 18:19:34 --> Hooks Class Initialized
DEBUG - 2018-07-07 18:19:34 --> UTF-8 Support Enabled
INFO - 2018-07-07 18:19:34 --> Utf8 Class Initialized
INFO - 2018-07-07 18:19:34 --> URI Class Initialized
INFO - 2018-07-07 18:19:34 --> Router Class Initialized
INFO - 2018-07-07 18:19:34 --> Output Class Initialized
INFO - 2018-07-07 18:19:34 --> Security Class Initialized
DEBUG - 2018-07-07 18:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-07 18:19:34 --> CSRF cookie sent
INFO - 2018-07-07 18:19:34 --> Input Class Initialized
INFO - 2018-07-07 18:19:34 --> Language Class Initialized
INFO - 2018-07-07 18:19:34 --> Loader Class Initialized
INFO - 2018-07-07 18:19:34 --> Helper loaded: url_helper
INFO - 2018-07-07 18:19:34 --> Helper loaded: form_helper
INFO - 2018-07-07 18:19:34 --> Helper loaded: language_helper
DEBUG - 2018-07-07 18:19:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-07 18:19:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-07 18:19:34 --> User Agent Class Initialized
INFO - 2018-07-07 18:19:34 --> Controller Class Initialized
INFO - 2018-07-07 18:19:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-07 18:19:34 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-07 18:19:34 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-07 18:19:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-07 18:19:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-07 18:19:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-07 18:19:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-07 18:19:34 --> Could not find the language line "req_email"
INFO - 2018-07-07 18:19:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-07 18:19:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-07 18:19:34 --> Final output sent to browser
DEBUG - 2018-07-07 18:19:34 --> Total execution time: 0.0205
INFO - 2018-07-07 18:19:35 --> Config Class Initialized
INFO - 2018-07-07 18:19:35 --> Hooks Class Initialized
DEBUG - 2018-07-07 18:19:35 --> UTF-8 Support Enabled
INFO - 2018-07-07 18:19:35 --> Utf8 Class Initialized
INFO - 2018-07-07 18:19:35 --> URI Class Initialized
INFO - 2018-07-07 18:19:35 --> Router Class Initialized
INFO - 2018-07-07 18:19:35 --> Output Class Initialized
INFO - 2018-07-07 18:19:35 --> Security Class Initialized
DEBUG - 2018-07-07 18:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-07 18:19:35 --> CSRF cookie sent
INFO - 2018-07-07 18:19:35 --> Input Class Initialized
INFO - 2018-07-07 18:19:35 --> Language Class Initialized
INFO - 2018-07-07 18:19:35 --> Loader Class Initialized
INFO - 2018-07-07 18:19:35 --> Helper loaded: url_helper
INFO - 2018-07-07 18:19:35 --> Helper loaded: form_helper
INFO - 2018-07-07 18:19:35 --> Helper loaded: language_helper
DEBUG - 2018-07-07 18:19:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-07 18:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-07 18:19:35 --> User Agent Class Initialized
INFO - 2018-07-07 18:19:35 --> Controller Class Initialized
INFO - 2018-07-07 18:19:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-07 18:19:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-07 18:19:35 --> Pixel_Model class loaded
INFO - 2018-07-07 18:19:35 --> Database Driver Class Initialized
INFO - 2018-07-07 18:19:35 --> Model "QuestionsModel" initialized
INFO - 2018-07-07 18:19:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-07 18:19:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-07 18:19:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-07 18:19:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-07 18:19:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/buy_gift.php
INFO - 2018-07-07 18:19:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-07 18:19:35 --> Final output sent to browser
DEBUG - 2018-07-07 18:19:35 --> Total execution time: 0.0344
INFO - 2018-07-07 20:47:30 --> Config Class Initialized
INFO - 2018-07-07 20:47:30 --> Hooks Class Initialized
DEBUG - 2018-07-07 20:47:30 --> UTF-8 Support Enabled
INFO - 2018-07-07 20:47:30 --> Utf8 Class Initialized
INFO - 2018-07-07 20:47:30 --> URI Class Initialized
INFO - 2018-07-07 20:47:30 --> Router Class Initialized
INFO - 2018-07-07 20:47:30 --> Output Class Initialized
INFO - 2018-07-07 20:47:30 --> Security Class Initialized
DEBUG - 2018-07-07 20:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-07 20:47:30 --> CSRF cookie sent
INFO - 2018-07-07 20:47:30 --> Input Class Initialized
INFO - 2018-07-07 20:47:30 --> Language Class Initialized
ERROR - 2018-07-07 20:47:30 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-07 20:47:30 --> Config Class Initialized
INFO - 2018-07-07 20:47:30 --> Hooks Class Initialized
DEBUG - 2018-07-07 20:47:30 --> UTF-8 Support Enabled
INFO - 2018-07-07 20:47:30 --> Utf8 Class Initialized
INFO - 2018-07-07 20:47:30 --> URI Class Initialized
DEBUG - 2018-07-07 20:47:30 --> No URI present. Default controller set.
INFO - 2018-07-07 20:47:30 --> Router Class Initialized
INFO - 2018-07-07 20:47:30 --> Output Class Initialized
INFO - 2018-07-07 20:47:30 --> Security Class Initialized
DEBUG - 2018-07-07 20:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-07 20:47:30 --> CSRF cookie sent
INFO - 2018-07-07 20:47:30 --> Input Class Initialized
INFO - 2018-07-07 20:47:30 --> Language Class Initialized
INFO - 2018-07-07 20:47:30 --> Loader Class Initialized
INFO - 2018-07-07 20:47:30 --> Helper loaded: url_helper
INFO - 2018-07-07 20:47:30 --> Helper loaded: form_helper
INFO - 2018-07-07 20:47:30 --> Helper loaded: language_helper
DEBUG - 2018-07-07 20:47:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-07 20:47:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-07 20:47:30 --> User Agent Class Initialized
INFO - 2018-07-07 20:47:30 --> Controller Class Initialized
INFO - 2018-07-07 20:47:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-07 20:47:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-07 20:47:30 --> Pixel_Model class loaded
INFO - 2018-07-07 20:47:30 --> Database Driver Class Initialized
INFO - 2018-07-07 20:47:30 --> Model "QuestionsModel" initialized
INFO - 2018-07-07 20:47:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-07 20:47:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-07 20:47:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-07 20:47:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-07 20:47:30 --> Final output sent to browser
DEBUG - 2018-07-07 20:47:30 --> Total execution time: 0.0319
INFO - 2018-07-07 20:47:39 --> Config Class Initialized
INFO - 2018-07-07 20:47:39 --> Hooks Class Initialized
DEBUG - 2018-07-07 20:47:39 --> UTF-8 Support Enabled
INFO - 2018-07-07 20:47:39 --> Utf8 Class Initialized
INFO - 2018-07-07 20:47:39 --> URI Class Initialized
INFO - 2018-07-07 20:47:39 --> Router Class Initialized
INFO - 2018-07-07 20:47:39 --> Output Class Initialized
INFO - 2018-07-07 20:47:39 --> Security Class Initialized
DEBUG - 2018-07-07 20:47:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-07 20:47:39 --> CSRF cookie sent
INFO - 2018-07-07 20:47:39 --> Input Class Initialized
INFO - 2018-07-07 20:47:39 --> Language Class Initialized
ERROR - 2018-07-07 20:47:39 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-07 21:17:59 --> Config Class Initialized
INFO - 2018-07-07 21:17:59 --> Hooks Class Initialized
DEBUG - 2018-07-07 21:17:59 --> UTF-8 Support Enabled
INFO - 2018-07-07 21:17:59 --> Utf8 Class Initialized
INFO - 2018-07-07 21:17:59 --> URI Class Initialized
DEBUG - 2018-07-07 21:17:59 --> No URI present. Default controller set.
INFO - 2018-07-07 21:17:59 --> Router Class Initialized
INFO - 2018-07-07 21:17:59 --> Output Class Initialized
INFO - 2018-07-07 21:17:59 --> Security Class Initialized
DEBUG - 2018-07-07 21:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-07 21:17:59 --> CSRF cookie sent
INFO - 2018-07-07 21:17:59 --> Input Class Initialized
INFO - 2018-07-07 21:17:59 --> Language Class Initialized
INFO - 2018-07-07 21:17:59 --> Loader Class Initialized
INFO - 2018-07-07 21:17:59 --> Helper loaded: url_helper
INFO - 2018-07-07 21:17:59 --> Helper loaded: form_helper
INFO - 2018-07-07 21:17:59 --> Helper loaded: language_helper
DEBUG - 2018-07-07 21:17:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-07 21:17:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-07 21:17:59 --> User Agent Class Initialized
INFO - 2018-07-07 21:17:59 --> Controller Class Initialized
INFO - 2018-07-07 21:17:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-07 21:17:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-07 21:17:59 --> Pixel_Model class loaded
INFO - 2018-07-07 21:17:59 --> Database Driver Class Initialized
INFO - 2018-07-07 21:17:59 --> Model "QuestionsModel" initialized
INFO - 2018-07-07 21:17:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-07 21:17:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-07 21:17:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-07 21:17:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-07 21:17:59 --> Final output sent to browser
DEBUG - 2018-07-07 21:17:59 --> Total execution time: 0.0362
INFO - 2018-07-07 23:48:11 --> Config Class Initialized
INFO - 2018-07-07 23:48:11 --> Hooks Class Initialized
DEBUG - 2018-07-07 23:48:11 --> UTF-8 Support Enabled
INFO - 2018-07-07 23:48:11 --> Utf8 Class Initialized
INFO - 2018-07-07 23:48:11 --> URI Class Initialized
INFO - 2018-07-07 23:48:11 --> Router Class Initialized
INFO - 2018-07-07 23:48:11 --> Output Class Initialized
INFO - 2018-07-07 23:48:11 --> Security Class Initialized
DEBUG - 2018-07-07 23:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-07 23:48:11 --> CSRF cookie sent
INFO - 2018-07-07 23:48:11 --> Input Class Initialized
INFO - 2018-07-07 23:48:11 --> Language Class Initialized
ERROR - 2018-07-07 23:48:11 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-07 23:48:14 --> Config Class Initialized
INFO - 2018-07-07 23:48:14 --> Hooks Class Initialized
DEBUG - 2018-07-07 23:48:14 --> UTF-8 Support Enabled
INFO - 2018-07-07 23:48:14 --> Utf8 Class Initialized
INFO - 2018-07-07 23:48:14 --> URI Class Initialized
INFO - 2018-07-07 23:48:14 --> Router Class Initialized
INFO - 2018-07-07 23:48:14 --> Output Class Initialized
INFO - 2018-07-07 23:48:14 --> Security Class Initialized
DEBUG - 2018-07-07 23:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-07 23:48:14 --> CSRF cookie sent
INFO - 2018-07-07 23:48:14 --> Input Class Initialized
INFO - 2018-07-07 23:48:14 --> Language Class Initialized
INFO - 2018-07-07 23:48:14 --> Loader Class Initialized
INFO - 2018-07-07 23:48:14 --> Helper loaded: url_helper
INFO - 2018-07-07 23:48:14 --> Helper loaded: form_helper
INFO - 2018-07-07 23:48:14 --> Helper loaded: language_helper
DEBUG - 2018-07-07 23:48:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-07 23:48:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-07 23:48:14 --> User Agent Class Initialized
INFO - 2018-07-07 23:48:14 --> Controller Class Initialized
INFO - 2018-07-07 23:48:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-07 23:48:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-07 23:48:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-07 23:48:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-07 23:48:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-07 23:48:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-07 23:48:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-07-07 23:48:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-07 23:48:14 --> Final output sent to browser
DEBUG - 2018-07-07 23:48:14 --> Total execution time: 0.0202

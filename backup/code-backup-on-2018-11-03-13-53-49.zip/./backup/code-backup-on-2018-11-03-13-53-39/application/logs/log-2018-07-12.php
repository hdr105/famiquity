<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-07-12 00:00:35 --> Config Class Initialized
INFO - 2018-07-12 00:00:35 --> Hooks Class Initialized
DEBUG - 2018-07-12 00:00:35 --> UTF-8 Support Enabled
INFO - 2018-07-12 00:00:35 --> Utf8 Class Initialized
INFO - 2018-07-12 00:00:35 --> URI Class Initialized
DEBUG - 2018-07-12 00:00:35 --> No URI present. Default controller set.
INFO - 2018-07-12 00:00:35 --> Router Class Initialized
INFO - 2018-07-12 00:00:35 --> Output Class Initialized
INFO - 2018-07-12 00:00:35 --> Security Class Initialized
DEBUG - 2018-07-12 00:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-12 00:00:35 --> CSRF cookie sent
INFO - 2018-07-12 00:00:35 --> Input Class Initialized
INFO - 2018-07-12 00:00:35 --> Language Class Initialized
INFO - 2018-07-12 00:00:35 --> Loader Class Initialized
INFO - 2018-07-12 00:00:35 --> Helper loaded: url_helper
INFO - 2018-07-12 00:00:35 --> Helper loaded: form_helper
INFO - 2018-07-12 00:00:35 --> Helper loaded: language_helper
DEBUG - 2018-07-12 00:00:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-12 00:00:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-12 00:00:35 --> User Agent Class Initialized
INFO - 2018-07-12 00:00:35 --> Controller Class Initialized
INFO - 2018-07-12 00:00:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-12 00:00:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-12 00:00:35 --> Pixel_Model class loaded
INFO - 2018-07-12 00:00:35 --> Database Driver Class Initialized
INFO - 2018-07-12 00:00:35 --> Model "QuestionsModel" initialized
INFO - 2018-07-12 00:00:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-12 00:00:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-12 00:00:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-12 00:00:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-12 00:00:35 --> Final output sent to browser
DEBUG - 2018-07-12 00:00:35 --> Total execution time: 0.0318
INFO - 2018-07-12 00:48:12 --> Config Class Initialized
INFO - 2018-07-12 00:48:12 --> Hooks Class Initialized
DEBUG - 2018-07-12 00:48:12 --> UTF-8 Support Enabled
INFO - 2018-07-12 00:48:12 --> Utf8 Class Initialized
INFO - 2018-07-12 00:48:12 --> URI Class Initialized
INFO - 2018-07-12 00:48:12 --> Router Class Initialized
INFO - 2018-07-12 00:48:12 --> Output Class Initialized
INFO - 2018-07-12 00:48:12 --> Security Class Initialized
DEBUG - 2018-07-12 00:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-12 00:48:12 --> CSRF cookie sent
INFO - 2018-07-12 00:48:12 --> Input Class Initialized
INFO - 2018-07-12 00:48:12 --> Language Class Initialized
INFO - 2018-07-12 00:48:12 --> Loader Class Initialized
INFO - 2018-07-12 00:48:12 --> Helper loaded: url_helper
INFO - 2018-07-12 00:48:12 --> Helper loaded: form_helper
INFO - 2018-07-12 00:48:12 --> Helper loaded: language_helper
DEBUG - 2018-07-12 00:48:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-12 00:48:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-12 00:48:12 --> User Agent Class Initialized
INFO - 2018-07-12 00:48:12 --> Controller Class Initialized
INFO - 2018-07-12 00:48:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-12 00:48:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-12 00:48:12 --> Pixel_Model class loaded
INFO - 2018-07-12 00:48:12 --> Database Driver Class Initialized
INFO - 2018-07-12 00:48:12 --> Model "RegistrationModel" initialized
DEBUG - 2018-07-12 00:48:12 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-12 00:48:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-12 00:48:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-12 00:48:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-12 00:48:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-12 00:48:12 --> Could not find the language line "req_email"
INFO - 2018-07-12 00:48:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup.php
INFO - 2018-07-12 00:48:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-12 00:48:12 --> Final output sent to browser
DEBUG - 2018-07-12 00:48:12 --> Total execution time: 0.0355
INFO - 2018-07-12 01:26:31 --> Config Class Initialized
INFO - 2018-07-12 01:26:31 --> Hooks Class Initialized
DEBUG - 2018-07-12 01:26:31 --> UTF-8 Support Enabled
INFO - 2018-07-12 01:26:31 --> Utf8 Class Initialized
INFO - 2018-07-12 01:26:31 --> URI Class Initialized
INFO - 2018-07-12 01:26:31 --> Router Class Initialized
INFO - 2018-07-12 01:26:31 --> Output Class Initialized
INFO - 2018-07-12 01:26:31 --> Security Class Initialized
DEBUG - 2018-07-12 01:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-12 01:26:31 --> CSRF cookie sent
INFO - 2018-07-12 01:26:31 --> Input Class Initialized
INFO - 2018-07-12 01:26:31 --> Language Class Initialized
ERROR - 2018-07-12 01:26:31 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-12 01:26:35 --> Config Class Initialized
INFO - 2018-07-12 01:26:35 --> Hooks Class Initialized
DEBUG - 2018-07-12 01:26:35 --> UTF-8 Support Enabled
INFO - 2018-07-12 01:26:35 --> Utf8 Class Initialized
INFO - 2018-07-12 01:26:35 --> URI Class Initialized
DEBUG - 2018-07-12 01:26:35 --> No URI present. Default controller set.
INFO - 2018-07-12 01:26:35 --> Router Class Initialized
INFO - 2018-07-12 01:26:35 --> Output Class Initialized
INFO - 2018-07-12 01:26:35 --> Security Class Initialized
DEBUG - 2018-07-12 01:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-12 01:26:35 --> CSRF cookie sent
INFO - 2018-07-12 01:26:35 --> Input Class Initialized
INFO - 2018-07-12 01:26:35 --> Language Class Initialized
INFO - 2018-07-12 01:26:35 --> Loader Class Initialized
INFO - 2018-07-12 01:26:35 --> Helper loaded: url_helper
INFO - 2018-07-12 01:26:35 --> Helper loaded: form_helper
INFO - 2018-07-12 01:26:35 --> Helper loaded: language_helper
DEBUG - 2018-07-12 01:26:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-12 01:26:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-12 01:26:35 --> User Agent Class Initialized
INFO - 2018-07-12 01:26:35 --> Controller Class Initialized
INFO - 2018-07-12 01:26:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-12 01:26:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-12 01:26:35 --> Pixel_Model class loaded
INFO - 2018-07-12 01:26:35 --> Database Driver Class Initialized
INFO - 2018-07-12 01:26:35 --> Model "QuestionsModel" initialized
INFO - 2018-07-12 01:26:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-12 01:26:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-12 01:26:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-12 01:26:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-12 01:26:35 --> Final output sent to browser
DEBUG - 2018-07-12 01:26:35 --> Total execution time: 0.0370
INFO - 2018-07-12 01:51:44 --> Config Class Initialized
INFO - 2018-07-12 01:51:44 --> Hooks Class Initialized
DEBUG - 2018-07-12 01:51:44 --> UTF-8 Support Enabled
INFO - 2018-07-12 01:51:44 --> Utf8 Class Initialized
INFO - 2018-07-12 01:51:44 --> URI Class Initialized
DEBUG - 2018-07-12 01:51:44 --> No URI present. Default controller set.
INFO - 2018-07-12 01:51:44 --> Router Class Initialized
INFO - 2018-07-12 01:51:44 --> Output Class Initialized
INFO - 2018-07-12 01:51:44 --> Security Class Initialized
DEBUG - 2018-07-12 01:51:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-12 01:51:44 --> CSRF cookie sent
INFO - 2018-07-12 01:51:44 --> Input Class Initialized
INFO - 2018-07-12 01:51:44 --> Language Class Initialized
INFO - 2018-07-12 01:51:44 --> Loader Class Initialized
INFO - 2018-07-12 01:51:44 --> Helper loaded: url_helper
INFO - 2018-07-12 01:51:44 --> Helper loaded: form_helper
INFO - 2018-07-12 01:51:44 --> Helper loaded: language_helper
DEBUG - 2018-07-12 01:51:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-12 01:51:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-12 01:51:44 --> User Agent Class Initialized
INFO - 2018-07-12 01:51:44 --> Controller Class Initialized
INFO - 2018-07-12 01:51:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-12 01:51:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-12 01:51:44 --> Pixel_Model class loaded
INFO - 2018-07-12 01:51:44 --> Database Driver Class Initialized
INFO - 2018-07-12 01:51:44 --> Model "QuestionsModel" initialized
INFO - 2018-07-12 01:51:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-12 01:51:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-12 01:51:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-12 01:51:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-12 01:51:44 --> Final output sent to browser
DEBUG - 2018-07-12 01:51:44 --> Total execution time: 0.0501
INFO - 2018-07-12 03:51:18 --> Config Class Initialized
INFO - 2018-07-12 03:51:18 --> Hooks Class Initialized
DEBUG - 2018-07-12 03:51:18 --> UTF-8 Support Enabled
INFO - 2018-07-12 03:51:18 --> Utf8 Class Initialized
INFO - 2018-07-12 03:51:18 --> URI Class Initialized
INFO - 2018-07-12 03:51:18 --> Router Class Initialized
INFO - 2018-07-12 03:51:18 --> Output Class Initialized
INFO - 2018-07-12 03:51:18 --> Security Class Initialized
DEBUG - 2018-07-12 03:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-12 03:51:18 --> CSRF cookie sent
INFO - 2018-07-12 03:51:18 --> Input Class Initialized
INFO - 2018-07-12 03:51:18 --> Language Class Initialized
ERROR - 2018-07-12 03:51:18 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-12 03:51:21 --> Config Class Initialized
INFO - 2018-07-12 03:51:21 --> Hooks Class Initialized
DEBUG - 2018-07-12 03:51:21 --> UTF-8 Support Enabled
INFO - 2018-07-12 03:51:21 --> Utf8 Class Initialized
INFO - 2018-07-12 03:51:21 --> URI Class Initialized
INFO - 2018-07-12 03:51:21 --> Router Class Initialized
INFO - 2018-07-12 03:51:21 --> Output Class Initialized
INFO - 2018-07-12 03:51:21 --> Security Class Initialized
DEBUG - 2018-07-12 03:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-12 03:51:21 --> CSRF cookie sent
INFO - 2018-07-12 03:51:21 --> Input Class Initialized
INFO - 2018-07-12 03:51:21 --> Language Class Initialized
INFO - 2018-07-12 03:51:21 --> Loader Class Initialized
INFO - 2018-07-12 03:51:21 --> Helper loaded: url_helper
INFO - 2018-07-12 03:51:21 --> Helper loaded: form_helper
INFO - 2018-07-12 03:51:21 --> Helper loaded: language_helper
DEBUG - 2018-07-12 03:51:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-12 03:51:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-12 03:51:21 --> User Agent Class Initialized
INFO - 2018-07-12 03:51:21 --> Controller Class Initialized
INFO - 2018-07-12 03:51:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-12 03:51:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-12 03:51:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-12 03:51:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-12 03:51:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-12 03:51:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-12 03:51:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-07-12 03:51:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-12 03:51:21 --> Final output sent to browser
DEBUG - 2018-07-12 03:51:21 --> Total execution time: 0.0312
INFO - 2018-07-12 09:44:30 --> Config Class Initialized
INFO - 2018-07-12 09:44:30 --> Hooks Class Initialized
DEBUG - 2018-07-12 09:44:30 --> UTF-8 Support Enabled
INFO - 2018-07-12 09:44:30 --> Utf8 Class Initialized
INFO - 2018-07-12 09:44:30 --> URI Class Initialized
INFO - 2018-07-12 09:44:30 --> Router Class Initialized
INFO - 2018-07-12 09:44:30 --> Output Class Initialized
INFO - 2018-07-12 09:44:30 --> Security Class Initialized
DEBUG - 2018-07-12 09:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-12 09:44:30 --> CSRF cookie sent
INFO - 2018-07-12 09:44:30 --> Input Class Initialized
INFO - 2018-07-12 09:44:30 --> Language Class Initialized
ERROR - 2018-07-12 09:44:30 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-12 09:44:32 --> Config Class Initialized
INFO - 2018-07-12 09:44:32 --> Hooks Class Initialized
DEBUG - 2018-07-12 09:44:32 --> UTF-8 Support Enabled
INFO - 2018-07-12 09:44:32 --> Utf8 Class Initialized
INFO - 2018-07-12 09:44:32 --> URI Class Initialized
DEBUG - 2018-07-12 09:44:32 --> No URI present. Default controller set.
INFO - 2018-07-12 09:44:32 --> Router Class Initialized
INFO - 2018-07-12 09:44:32 --> Output Class Initialized
INFO - 2018-07-12 09:44:32 --> Security Class Initialized
DEBUG - 2018-07-12 09:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-12 09:44:32 --> CSRF cookie sent
INFO - 2018-07-12 09:44:32 --> Input Class Initialized
INFO - 2018-07-12 09:44:32 --> Language Class Initialized
INFO - 2018-07-12 09:44:32 --> Loader Class Initialized
INFO - 2018-07-12 09:44:32 --> Helper loaded: url_helper
INFO - 2018-07-12 09:44:32 --> Helper loaded: form_helper
INFO - 2018-07-12 09:44:32 --> Helper loaded: language_helper
DEBUG - 2018-07-12 09:44:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-12 09:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-12 09:44:32 --> User Agent Class Initialized
INFO - 2018-07-12 09:44:32 --> Controller Class Initialized
INFO - 2018-07-12 09:44:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-12 09:44:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-12 09:44:32 --> Pixel_Model class loaded
INFO - 2018-07-12 09:44:32 --> Database Driver Class Initialized
INFO - 2018-07-12 09:44:32 --> Model "QuestionsModel" initialized
INFO - 2018-07-12 09:44:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-12 09:44:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-12 09:44:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-12 09:44:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-12 09:44:32 --> Final output sent to browser
DEBUG - 2018-07-12 09:44:32 --> Total execution time: 0.0403
INFO - 2018-07-12 09:44:34 --> Config Class Initialized
INFO - 2018-07-12 09:44:34 --> Hooks Class Initialized
DEBUG - 2018-07-12 09:44:34 --> UTF-8 Support Enabled
INFO - 2018-07-12 09:44:34 --> Utf8 Class Initialized
INFO - 2018-07-12 09:44:34 --> URI Class Initialized
DEBUG - 2018-07-12 09:44:34 --> No URI present. Default controller set.
INFO - 2018-07-12 09:44:34 --> Router Class Initialized
INFO - 2018-07-12 09:44:34 --> Output Class Initialized
INFO - 2018-07-12 09:44:34 --> Security Class Initialized
DEBUG - 2018-07-12 09:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-12 09:44:34 --> CSRF cookie sent
INFO - 2018-07-12 09:44:34 --> Input Class Initialized
INFO - 2018-07-12 09:44:34 --> Language Class Initialized
INFO - 2018-07-12 09:44:34 --> Loader Class Initialized
INFO - 2018-07-12 09:44:34 --> Helper loaded: url_helper
INFO - 2018-07-12 09:44:34 --> Helper loaded: form_helper
INFO - 2018-07-12 09:44:34 --> Helper loaded: language_helper
DEBUG - 2018-07-12 09:44:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-12 09:44:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-12 09:44:34 --> User Agent Class Initialized
INFO - 2018-07-12 09:44:34 --> Controller Class Initialized
INFO - 2018-07-12 09:44:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-12 09:44:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-12 09:44:34 --> Pixel_Model class loaded
INFO - 2018-07-12 09:44:34 --> Database Driver Class Initialized
INFO - 2018-07-12 09:44:34 --> Model "QuestionsModel" initialized
INFO - 2018-07-12 09:44:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-12 09:44:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-12 09:44:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-12 09:44:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-12 09:44:34 --> Final output sent to browser
DEBUG - 2018-07-12 09:44:34 --> Total execution time: 0.0324
INFO - 2018-07-12 09:44:35 --> Config Class Initialized
INFO - 2018-07-12 09:44:35 --> Hooks Class Initialized
DEBUG - 2018-07-12 09:44:35 --> UTF-8 Support Enabled
INFO - 2018-07-12 09:44:35 --> Utf8 Class Initialized
INFO - 2018-07-12 09:44:35 --> URI Class Initialized
INFO - 2018-07-12 09:44:35 --> Router Class Initialized
INFO - 2018-07-12 09:44:35 --> Output Class Initialized
INFO - 2018-07-12 09:44:35 --> Security Class Initialized
DEBUG - 2018-07-12 09:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-12 09:44:35 --> CSRF cookie sent
INFO - 2018-07-12 09:44:35 --> Input Class Initialized
INFO - 2018-07-12 09:44:35 --> Language Class Initialized
INFO - 2018-07-12 09:44:36 --> Loader Class Initialized
INFO - 2018-07-12 09:44:36 --> Helper loaded: url_helper
INFO - 2018-07-12 09:44:36 --> Helper loaded: form_helper
INFO - 2018-07-12 09:44:36 --> Helper loaded: language_helper
DEBUG - 2018-07-12 09:44:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-12 09:44:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-12 09:44:36 --> User Agent Class Initialized
INFO - 2018-07-12 09:44:36 --> Controller Class Initialized
INFO - 2018-07-12 09:44:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-12 09:44:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-12 09:44:36 --> Pixel_Model class loaded
INFO - 2018-07-12 09:44:36 --> Database Driver Class Initialized
INFO - 2018-07-12 09:44:36 --> Model "QuestionsModel" initialized
INFO - 2018-07-12 09:44:37 --> Config Class Initialized
INFO - 2018-07-12 09:44:37 --> Hooks Class Initialized
DEBUG - 2018-07-12 09:44:37 --> UTF-8 Support Enabled
INFO - 2018-07-12 09:44:37 --> Utf8 Class Initialized
INFO - 2018-07-12 09:44:37 --> URI Class Initialized
INFO - 2018-07-12 09:44:37 --> Router Class Initialized
INFO - 2018-07-12 09:44:37 --> Output Class Initialized
INFO - 2018-07-12 09:44:37 --> Security Class Initialized
DEBUG - 2018-07-12 09:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-12 09:44:37 --> CSRF cookie sent
INFO - 2018-07-12 09:44:37 --> Input Class Initialized
INFO - 2018-07-12 09:44:37 --> Language Class Initialized
INFO - 2018-07-12 09:44:37 --> Loader Class Initialized
INFO - 2018-07-12 09:44:37 --> Helper loaded: url_helper
INFO - 2018-07-12 09:44:37 --> Helper loaded: form_helper
INFO - 2018-07-12 09:44:37 --> Helper loaded: language_helper
DEBUG - 2018-07-12 09:44:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-12 09:44:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-12 09:44:37 --> User Agent Class Initialized
INFO - 2018-07-12 09:44:37 --> Controller Class Initialized
INFO - 2018-07-12 09:44:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-12 09:44:37 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-12 09:44:37 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-12 09:44:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-12 09:44:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-12 09:44:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-12 09:44:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-12 09:44:37 --> Could not find the language line "req_email"
INFO - 2018-07-12 09:44:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-12 09:44:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-12 09:44:37 --> Final output sent to browser
DEBUG - 2018-07-12 09:44:37 --> Total execution time: 0.0291
INFO - 2018-07-12 10:05:31 --> Config Class Initialized
INFO - 2018-07-12 10:05:31 --> Hooks Class Initialized
DEBUG - 2018-07-12 10:05:31 --> UTF-8 Support Enabled
INFO - 2018-07-12 10:05:31 --> Utf8 Class Initialized
INFO - 2018-07-12 10:05:31 --> URI Class Initialized
DEBUG - 2018-07-12 10:05:31 --> No URI present. Default controller set.
INFO - 2018-07-12 10:05:31 --> Router Class Initialized
INFO - 2018-07-12 10:05:31 --> Output Class Initialized
INFO - 2018-07-12 10:05:31 --> Security Class Initialized
DEBUG - 2018-07-12 10:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-12 10:05:31 --> CSRF cookie sent
INFO - 2018-07-12 10:05:31 --> Input Class Initialized
INFO - 2018-07-12 10:05:31 --> Language Class Initialized
INFO - 2018-07-12 10:05:31 --> Loader Class Initialized
INFO - 2018-07-12 10:05:31 --> Helper loaded: url_helper
INFO - 2018-07-12 10:05:31 --> Helper loaded: form_helper
INFO - 2018-07-12 10:05:31 --> Helper loaded: language_helper
DEBUG - 2018-07-12 10:05:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-12 10:05:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-12 10:05:31 --> User Agent Class Initialized
INFO - 2018-07-12 10:05:31 --> Controller Class Initialized
INFO - 2018-07-12 10:05:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-12 10:05:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-12 10:05:31 --> Pixel_Model class loaded
INFO - 2018-07-12 10:05:31 --> Database Driver Class Initialized
INFO - 2018-07-12 10:05:31 --> Model "QuestionsModel" initialized
INFO - 2018-07-12 10:05:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-12 10:05:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-12 10:05:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-12 10:05:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-12 10:05:31 --> Final output sent to browser
DEBUG - 2018-07-12 10:05:31 --> Total execution time: 0.0329
INFO - 2018-07-12 10:30:52 --> Config Class Initialized
INFO - 2018-07-12 10:30:52 --> Hooks Class Initialized
DEBUG - 2018-07-12 10:30:52 --> UTF-8 Support Enabled
INFO - 2018-07-12 10:30:52 --> Utf8 Class Initialized
INFO - 2018-07-12 10:30:52 --> URI Class Initialized
INFO - 2018-07-12 10:30:52 --> Router Class Initialized
INFO - 2018-07-12 10:30:52 --> Output Class Initialized
INFO - 2018-07-12 10:30:52 --> Security Class Initialized
DEBUG - 2018-07-12 10:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-12 10:30:52 --> CSRF cookie sent
INFO - 2018-07-12 10:30:52 --> Input Class Initialized
INFO - 2018-07-12 10:30:52 --> Language Class Initialized
ERROR - 2018-07-12 10:30:52 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-12 10:30:55 --> Config Class Initialized
INFO - 2018-07-12 10:30:55 --> Hooks Class Initialized
DEBUG - 2018-07-12 10:30:55 --> UTF-8 Support Enabled
INFO - 2018-07-12 10:30:55 --> Utf8 Class Initialized
INFO - 2018-07-12 10:30:55 --> URI Class Initialized
INFO - 2018-07-12 10:30:55 --> Router Class Initialized
INFO - 2018-07-12 10:30:55 --> Output Class Initialized
INFO - 2018-07-12 10:30:55 --> Security Class Initialized
DEBUG - 2018-07-12 10:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-12 10:30:55 --> CSRF cookie sent
INFO - 2018-07-12 10:30:55 --> Input Class Initialized
INFO - 2018-07-12 10:30:55 --> Language Class Initialized
INFO - 2018-07-12 10:30:55 --> Loader Class Initialized
INFO - 2018-07-12 10:30:55 --> Helper loaded: url_helper
INFO - 2018-07-12 10:30:55 --> Helper loaded: form_helper
INFO - 2018-07-12 10:30:55 --> Helper loaded: language_helper
DEBUG - 2018-07-12 10:30:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-12 10:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-12 10:30:55 --> User Agent Class Initialized
INFO - 2018-07-12 10:30:55 --> Controller Class Initialized
INFO - 2018-07-12 10:30:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-12 10:30:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-12 10:30:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-12 10:30:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-12 10:30:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-12 10:30:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-12 10:30:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-07-12 10:30:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-12 10:30:55 --> Final output sent to browser
DEBUG - 2018-07-12 10:30:55 --> Total execution time: 0.0338
INFO - 2018-07-12 10:30:57 --> Config Class Initialized
INFO - 2018-07-12 10:30:57 --> Hooks Class Initialized
DEBUG - 2018-07-12 10:30:57 --> UTF-8 Support Enabled
INFO - 2018-07-12 10:30:57 --> Utf8 Class Initialized
INFO - 2018-07-12 10:30:57 --> URI Class Initialized
INFO - 2018-07-12 10:30:57 --> Router Class Initialized
INFO - 2018-07-12 10:30:57 --> Output Class Initialized
INFO - 2018-07-12 10:30:57 --> Security Class Initialized
DEBUG - 2018-07-12 10:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-12 10:30:57 --> CSRF cookie sent
INFO - 2018-07-12 10:30:57 --> Input Class Initialized
INFO - 2018-07-12 10:30:57 --> Language Class Initialized
INFO - 2018-07-12 10:30:57 --> Loader Class Initialized
INFO - 2018-07-12 10:30:57 --> Helper loaded: url_helper
INFO - 2018-07-12 10:30:57 --> Helper loaded: form_helper
INFO - 2018-07-12 10:30:57 --> Helper loaded: language_helper
DEBUG - 2018-07-12 10:30:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-12 10:30:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-12 10:30:57 --> User Agent Class Initialized
INFO - 2018-07-12 10:30:57 --> Controller Class Initialized
INFO - 2018-07-12 10:30:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-12 10:30:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-12 10:30:57 --> Pixel_Model class loaded
INFO - 2018-07-12 10:30:57 --> Database Driver Class Initialized
INFO - 2018-07-12 10:30:57 --> Model "QuestionsModel" initialized
INFO - 2018-07-12 10:30:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-12 10:30:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-12 10:30:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-12 10:30:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-12 10:30:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/buy_gift.php
INFO - 2018-07-12 10:30:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-12 10:30:57 --> Final output sent to browser
DEBUG - 2018-07-12 10:30:57 --> Total execution time: 0.0388
INFO - 2018-07-12 10:30:59 --> Config Class Initialized
INFO - 2018-07-12 10:30:59 --> Hooks Class Initialized
DEBUG - 2018-07-12 10:30:59 --> UTF-8 Support Enabled
INFO - 2018-07-12 10:30:59 --> Utf8 Class Initialized
INFO - 2018-07-12 10:30:59 --> URI Class Initialized
INFO - 2018-07-12 10:30:59 --> Router Class Initialized
INFO - 2018-07-12 10:30:59 --> Output Class Initialized
INFO - 2018-07-12 10:30:59 --> Security Class Initialized
DEBUG - 2018-07-12 10:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-12 10:30:59 --> CSRF cookie sent
INFO - 2018-07-12 10:30:59 --> Input Class Initialized
INFO - 2018-07-12 10:30:59 --> Language Class Initialized
INFO - 2018-07-12 10:30:59 --> Loader Class Initialized
INFO - 2018-07-12 10:30:59 --> Helper loaded: url_helper
INFO - 2018-07-12 10:30:59 --> Helper loaded: form_helper
INFO - 2018-07-12 10:30:59 --> Helper loaded: language_helper
DEBUG - 2018-07-12 10:30:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-12 10:30:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-12 10:30:59 --> User Agent Class Initialized
INFO - 2018-07-12 10:30:59 --> Controller Class Initialized
INFO - 2018-07-12 10:30:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-12 10:30:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-12 10:30:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-12 10:30:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-12 10:30:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-12 10:30:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-12 10:30:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-07-12 10:30:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-12 10:30:59 --> Final output sent to browser
DEBUG - 2018-07-12 10:30:59 --> Total execution time: 0.0212
INFO - 2018-07-12 10:31:00 --> Config Class Initialized
INFO - 2018-07-12 10:31:00 --> Hooks Class Initialized
DEBUG - 2018-07-12 10:31:00 --> UTF-8 Support Enabled
INFO - 2018-07-12 10:31:00 --> Utf8 Class Initialized
INFO - 2018-07-12 10:31:00 --> URI Class Initialized
INFO - 2018-07-12 10:31:00 --> Router Class Initialized
INFO - 2018-07-12 10:31:00 --> Output Class Initialized
INFO - 2018-07-12 10:31:00 --> Security Class Initialized
DEBUG - 2018-07-12 10:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-12 10:31:00 --> CSRF cookie sent
INFO - 2018-07-12 10:31:00 --> Input Class Initialized
INFO - 2018-07-12 10:31:00 --> Language Class Initialized
INFO - 2018-07-12 10:31:00 --> Loader Class Initialized
INFO - 2018-07-12 10:31:00 --> Helper loaded: url_helper
INFO - 2018-07-12 10:31:00 --> Helper loaded: form_helper
INFO - 2018-07-12 10:31:00 --> Helper loaded: language_helper
DEBUG - 2018-07-12 10:31:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-12 10:31:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-12 10:31:00 --> User Agent Class Initialized
INFO - 2018-07-12 10:31:00 --> Controller Class Initialized
INFO - 2018-07-12 10:31:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-12 10:31:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-12 10:31:00 --> Pixel_Model class loaded
INFO - 2018-07-12 10:31:00 --> Database Driver Class Initialized
INFO - 2018-07-12 10:31:00 --> Model "QuestionsModel" initialized
INFO - 2018-07-12 10:31:02 --> Config Class Initialized
INFO - 2018-07-12 10:31:02 --> Hooks Class Initialized
DEBUG - 2018-07-12 10:31:02 --> UTF-8 Support Enabled
INFO - 2018-07-12 10:31:02 --> Utf8 Class Initialized
INFO - 2018-07-12 10:31:02 --> URI Class Initialized
INFO - 2018-07-12 10:31:02 --> Router Class Initialized
INFO - 2018-07-12 10:31:02 --> Output Class Initialized
INFO - 2018-07-12 10:31:02 --> Security Class Initialized
DEBUG - 2018-07-12 10:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-12 10:31:02 --> CSRF cookie sent
INFO - 2018-07-12 10:31:02 --> Input Class Initialized
INFO - 2018-07-12 10:31:02 --> Language Class Initialized
INFO - 2018-07-12 10:31:02 --> Loader Class Initialized
INFO - 2018-07-12 10:31:02 --> Helper loaded: url_helper
INFO - 2018-07-12 10:31:02 --> Helper loaded: form_helper
INFO - 2018-07-12 10:31:02 --> Helper loaded: language_helper
DEBUG - 2018-07-12 10:31:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-12 10:31:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-12 10:31:02 --> User Agent Class Initialized
INFO - 2018-07-12 10:31:02 --> Controller Class Initialized
INFO - 2018-07-12 10:31:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-12 10:31:02 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-12 10:31:02 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-12 10:31:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-12 10:31:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-12 10:31:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-12 10:31:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-12 10:31:02 --> Could not find the language line "req_email"
INFO - 2018-07-12 10:31:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-12 10:31:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-12 10:31:02 --> Final output sent to browser
DEBUG - 2018-07-12 10:31:02 --> Total execution time: 0.0204
INFO - 2018-07-12 10:31:03 --> Config Class Initialized
INFO - 2018-07-12 10:31:03 --> Hooks Class Initialized
DEBUG - 2018-07-12 10:31:03 --> UTF-8 Support Enabled
INFO - 2018-07-12 10:31:03 --> Utf8 Class Initialized
INFO - 2018-07-12 10:31:03 --> URI Class Initialized
INFO - 2018-07-12 10:31:03 --> Router Class Initialized
INFO - 2018-07-12 10:31:03 --> Output Class Initialized
INFO - 2018-07-12 10:31:03 --> Security Class Initialized
DEBUG - 2018-07-12 10:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-12 10:31:03 --> CSRF cookie sent
INFO - 2018-07-12 10:31:03 --> Input Class Initialized
INFO - 2018-07-12 10:31:03 --> Language Class Initialized
INFO - 2018-07-12 10:31:03 --> Loader Class Initialized
INFO - 2018-07-12 10:31:03 --> Helper loaded: url_helper
INFO - 2018-07-12 10:31:03 --> Helper loaded: form_helper
INFO - 2018-07-12 10:31:03 --> Helper loaded: language_helper
DEBUG - 2018-07-12 10:31:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-12 10:31:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-12 10:31:03 --> User Agent Class Initialized
INFO - 2018-07-12 10:31:03 --> Controller Class Initialized
INFO - 2018-07-12 10:31:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-12 10:31:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-12 10:31:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-12 10:31:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-12 10:31:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-12 10:31:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-12 10:31:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-07-12 10:31:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-12 10:31:03 --> Final output sent to browser
DEBUG - 2018-07-12 10:31:03 --> Total execution time: 0.0210
INFO - 2018-07-12 10:31:05 --> Config Class Initialized
INFO - 2018-07-12 10:31:05 --> Hooks Class Initialized
DEBUG - 2018-07-12 10:31:05 --> UTF-8 Support Enabled
INFO - 2018-07-12 10:31:05 --> Utf8 Class Initialized
INFO - 2018-07-12 10:31:05 --> URI Class Initialized
INFO - 2018-07-12 10:31:05 --> Router Class Initialized
INFO - 2018-07-12 10:31:05 --> Output Class Initialized
INFO - 2018-07-12 10:31:05 --> Security Class Initialized
DEBUG - 2018-07-12 10:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-12 10:31:05 --> CSRF cookie sent
INFO - 2018-07-12 10:31:05 --> Input Class Initialized
INFO - 2018-07-12 10:31:05 --> Language Class Initialized
INFO - 2018-07-12 10:31:05 --> Loader Class Initialized
INFO - 2018-07-12 10:31:05 --> Helper loaded: url_helper
INFO - 2018-07-12 10:31:05 --> Helper loaded: form_helper
INFO - 2018-07-12 10:31:05 --> Helper loaded: language_helper
DEBUG - 2018-07-12 10:31:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-12 10:31:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-12 10:31:05 --> User Agent Class Initialized
INFO - 2018-07-12 10:31:05 --> Controller Class Initialized
INFO - 2018-07-12 10:31:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-12 10:31:05 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-12 10:31:05 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-12 10:31:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-12 10:31:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-12 10:31:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-12 10:31:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-12 10:31:05 --> Could not find the language line "req_email"
INFO - 2018-07-12 10:31:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-12 10:31:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-12 10:31:05 --> Final output sent to browser
DEBUG - 2018-07-12 10:31:05 --> Total execution time: 0.0236
INFO - 2018-07-12 10:31:07 --> Config Class Initialized
INFO - 2018-07-12 10:31:07 --> Hooks Class Initialized
DEBUG - 2018-07-12 10:31:07 --> UTF-8 Support Enabled
INFO - 2018-07-12 10:31:07 --> Utf8 Class Initialized
INFO - 2018-07-12 10:31:07 --> URI Class Initialized
INFO - 2018-07-12 10:31:07 --> Router Class Initialized
INFO - 2018-07-12 10:31:07 --> Output Class Initialized
INFO - 2018-07-12 10:31:07 --> Security Class Initialized
DEBUG - 2018-07-12 10:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-12 10:31:07 --> CSRF cookie sent
INFO - 2018-07-12 10:31:07 --> Input Class Initialized
INFO - 2018-07-12 10:31:07 --> Language Class Initialized
INFO - 2018-07-12 10:31:07 --> Loader Class Initialized
INFO - 2018-07-12 10:31:07 --> Helper loaded: url_helper
INFO - 2018-07-12 10:31:07 --> Helper loaded: form_helper
INFO - 2018-07-12 10:31:07 --> Helper loaded: language_helper
DEBUG - 2018-07-12 10:31:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-12 10:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-12 10:31:07 --> User Agent Class Initialized
INFO - 2018-07-12 10:31:07 --> Controller Class Initialized
INFO - 2018-07-12 10:31:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-12 10:31:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-12 10:31:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-12 10:31:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-12 10:31:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-12 10:31:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-12 10:31:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-07-12 10:31:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-12 10:31:07 --> Final output sent to browser
DEBUG - 2018-07-12 10:31:07 --> Total execution time: 0.0202
INFO - 2018-07-12 14:22:08 --> Config Class Initialized
INFO - 2018-07-12 14:22:08 --> Hooks Class Initialized
DEBUG - 2018-07-12 14:22:08 --> UTF-8 Support Enabled
INFO - 2018-07-12 14:22:08 --> Utf8 Class Initialized
INFO - 2018-07-12 14:22:08 --> URI Class Initialized
DEBUG - 2018-07-12 14:22:08 --> No URI present. Default controller set.
INFO - 2018-07-12 14:22:08 --> Router Class Initialized
INFO - 2018-07-12 14:22:08 --> Output Class Initialized
INFO - 2018-07-12 14:22:08 --> Security Class Initialized
DEBUG - 2018-07-12 14:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-12 14:22:08 --> CSRF cookie sent
INFO - 2018-07-12 14:22:08 --> Input Class Initialized
INFO - 2018-07-12 14:22:08 --> Language Class Initialized
INFO - 2018-07-12 14:22:08 --> Loader Class Initialized
INFO - 2018-07-12 14:22:08 --> Helper loaded: url_helper
INFO - 2018-07-12 14:22:08 --> Helper loaded: form_helper
INFO - 2018-07-12 14:22:08 --> Helper loaded: language_helper
DEBUG - 2018-07-12 14:22:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-12 14:22:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-12 14:22:08 --> User Agent Class Initialized
INFO - 2018-07-12 14:22:08 --> Controller Class Initialized
INFO - 2018-07-12 14:22:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-12 14:22:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-12 14:22:08 --> Pixel_Model class loaded
INFO - 2018-07-12 14:22:08 --> Database Driver Class Initialized
INFO - 2018-07-12 14:22:08 --> Model "QuestionsModel" initialized
INFO - 2018-07-12 14:22:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-12 14:22:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-12 14:22:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-12 14:22:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-12 14:22:08 --> Final output sent to browser
DEBUG - 2018-07-12 14:22:08 --> Total execution time: 0.0362
INFO - 2018-07-12 16:17:24 --> Config Class Initialized
INFO - 2018-07-12 16:17:24 --> Hooks Class Initialized
DEBUG - 2018-07-12 16:17:24 --> UTF-8 Support Enabled
INFO - 2018-07-12 16:17:24 --> Utf8 Class Initialized
INFO - 2018-07-12 16:17:24 --> URI Class Initialized
DEBUG - 2018-07-12 16:17:24 --> No URI present. Default controller set.
INFO - 2018-07-12 16:17:24 --> Router Class Initialized
INFO - 2018-07-12 16:17:24 --> Output Class Initialized
INFO - 2018-07-12 16:17:24 --> Security Class Initialized
DEBUG - 2018-07-12 16:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-12 16:17:24 --> CSRF cookie sent
INFO - 2018-07-12 16:17:24 --> Input Class Initialized
INFO - 2018-07-12 16:17:24 --> Language Class Initialized
INFO - 2018-07-12 16:17:24 --> Loader Class Initialized
INFO - 2018-07-12 16:17:24 --> Helper loaded: url_helper
INFO - 2018-07-12 16:17:24 --> Helper loaded: form_helper
INFO - 2018-07-12 16:17:24 --> Helper loaded: language_helper
DEBUG - 2018-07-12 16:17:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-12 16:17:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-12 16:17:24 --> User Agent Class Initialized
INFO - 2018-07-12 16:17:24 --> Controller Class Initialized
INFO - 2018-07-12 16:17:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-12 16:17:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-12 16:17:24 --> Pixel_Model class loaded
INFO - 2018-07-12 16:17:24 --> Database Driver Class Initialized
INFO - 2018-07-12 16:17:24 --> Model "QuestionsModel" initialized
INFO - 2018-07-12 16:17:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-12 16:17:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-12 16:17:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-12 16:17:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-12 16:17:24 --> Final output sent to browser
DEBUG - 2018-07-12 16:17:24 --> Total execution time: 0.0373
INFO - 2018-07-12 16:17:25 --> Config Class Initialized
INFO - 2018-07-12 16:17:25 --> Hooks Class Initialized
DEBUG - 2018-07-12 16:17:25 --> UTF-8 Support Enabled
INFO - 2018-07-12 16:17:25 --> Utf8 Class Initialized
INFO - 2018-07-12 16:17:25 --> URI Class Initialized
DEBUG - 2018-07-12 16:17:25 --> No URI present. Default controller set.
INFO - 2018-07-12 16:17:25 --> Router Class Initialized
INFO - 2018-07-12 16:17:25 --> Output Class Initialized
INFO - 2018-07-12 16:17:25 --> Security Class Initialized
DEBUG - 2018-07-12 16:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-12 16:17:25 --> CSRF cookie sent
INFO - 2018-07-12 16:17:25 --> Input Class Initialized
INFO - 2018-07-12 16:17:25 --> Language Class Initialized
INFO - 2018-07-12 16:17:25 --> Loader Class Initialized
INFO - 2018-07-12 16:17:25 --> Helper loaded: url_helper
INFO - 2018-07-12 16:17:25 --> Helper loaded: form_helper
INFO - 2018-07-12 16:17:25 --> Helper loaded: language_helper
DEBUG - 2018-07-12 16:17:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-12 16:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-12 16:17:25 --> User Agent Class Initialized
INFO - 2018-07-12 16:17:25 --> Controller Class Initialized
INFO - 2018-07-12 16:17:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-12 16:17:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-12 16:17:25 --> Pixel_Model class loaded
INFO - 2018-07-12 16:17:25 --> Database Driver Class Initialized
INFO - 2018-07-12 16:17:25 --> Model "QuestionsModel" initialized
INFO - 2018-07-12 16:17:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-12 16:17:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-12 16:17:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-12 16:17:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-12 16:17:25 --> Final output sent to browser
DEBUG - 2018-07-12 16:17:25 --> Total execution time: 0.0341
INFO - 2018-07-12 16:17:26 --> Config Class Initialized
INFO - 2018-07-12 16:17:26 --> Hooks Class Initialized
DEBUG - 2018-07-12 16:17:26 --> UTF-8 Support Enabled
INFO - 2018-07-12 16:17:26 --> Utf8 Class Initialized
INFO - 2018-07-12 16:17:26 --> URI Class Initialized
DEBUG - 2018-07-12 16:17:26 --> No URI present. Default controller set.
INFO - 2018-07-12 16:17:26 --> Router Class Initialized
INFO - 2018-07-12 16:17:26 --> Output Class Initialized
INFO - 2018-07-12 16:17:26 --> Security Class Initialized
DEBUG - 2018-07-12 16:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-12 16:17:26 --> CSRF cookie sent
INFO - 2018-07-12 16:17:26 --> Input Class Initialized
INFO - 2018-07-12 16:17:26 --> Language Class Initialized
INFO - 2018-07-12 16:17:26 --> Loader Class Initialized
INFO - 2018-07-12 16:17:26 --> Helper loaded: url_helper
INFO - 2018-07-12 16:17:26 --> Helper loaded: form_helper
INFO - 2018-07-12 16:17:26 --> Helper loaded: language_helper
DEBUG - 2018-07-12 16:17:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-12 16:17:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-12 16:17:26 --> User Agent Class Initialized
INFO - 2018-07-12 16:17:26 --> Controller Class Initialized
INFO - 2018-07-12 16:17:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-12 16:17:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-12 16:17:26 --> Pixel_Model class loaded
INFO - 2018-07-12 16:17:26 --> Database Driver Class Initialized
INFO - 2018-07-12 16:17:26 --> Model "QuestionsModel" initialized
INFO - 2018-07-12 16:17:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-12 16:17:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-12 16:17:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-12 16:17:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-12 16:17:26 --> Final output sent to browser
DEBUG - 2018-07-12 16:17:26 --> Total execution time: 0.0455
INFO - 2018-07-12 16:17:26 --> Config Class Initialized
INFO - 2018-07-12 16:17:26 --> Hooks Class Initialized
DEBUG - 2018-07-12 16:17:26 --> UTF-8 Support Enabled
INFO - 2018-07-12 16:17:26 --> Utf8 Class Initialized
INFO - 2018-07-12 16:17:26 --> URI Class Initialized
INFO - 2018-07-12 16:17:26 --> Router Class Initialized
INFO - 2018-07-12 16:17:26 --> Output Class Initialized
INFO - 2018-07-12 16:17:26 --> Security Class Initialized
DEBUG - 2018-07-12 16:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-12 16:17:26 --> CSRF cookie sent
INFO - 2018-07-12 16:17:26 --> Input Class Initialized
INFO - 2018-07-12 16:17:26 --> Language Class Initialized
ERROR - 2018-07-12 16:17:26 --> 404 Page Not Found: 405shtml/index
INFO - 2018-07-12 16:17:34 --> Config Class Initialized
INFO - 2018-07-12 16:17:34 --> Hooks Class Initialized
DEBUG - 2018-07-12 16:17:34 --> UTF-8 Support Enabled
INFO - 2018-07-12 16:17:34 --> Utf8 Class Initialized
INFO - 2018-07-12 16:17:34 --> URI Class Initialized
DEBUG - 2018-07-12 16:17:34 --> No URI present. Default controller set.
INFO - 2018-07-12 16:17:34 --> Router Class Initialized
INFO - 2018-07-12 16:17:34 --> Output Class Initialized
INFO - 2018-07-12 16:17:34 --> Security Class Initialized
DEBUG - 2018-07-12 16:17:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-12 16:17:34 --> CSRF cookie sent
INFO - 2018-07-12 16:17:34 --> Input Class Initialized
INFO - 2018-07-12 16:17:34 --> Language Class Initialized
INFO - 2018-07-12 16:17:34 --> Loader Class Initialized
INFO - 2018-07-12 16:17:34 --> Helper loaded: url_helper
INFO - 2018-07-12 16:17:34 --> Helper loaded: form_helper
INFO - 2018-07-12 16:17:34 --> Helper loaded: language_helper
DEBUG - 2018-07-12 16:17:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-12 16:17:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-12 16:17:34 --> User Agent Class Initialized
INFO - 2018-07-12 16:17:34 --> Controller Class Initialized
INFO - 2018-07-12 16:17:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-12 16:17:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-12 16:17:34 --> Pixel_Model class loaded
INFO - 2018-07-12 16:17:34 --> Database Driver Class Initialized
INFO - 2018-07-12 16:17:34 --> Model "QuestionsModel" initialized
INFO - 2018-07-12 16:17:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-12 16:17:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-12 16:17:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-12 16:17:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-12 16:17:34 --> Final output sent to browser
DEBUG - 2018-07-12 16:17:34 --> Total execution time: 0.0520
INFO - 2018-07-12 16:17:34 --> Config Class Initialized
INFO - 2018-07-12 16:17:34 --> Hooks Class Initialized
DEBUG - 2018-07-12 16:17:34 --> UTF-8 Support Enabled
INFO - 2018-07-12 16:17:34 --> Utf8 Class Initialized
INFO - 2018-07-12 16:17:34 --> URI Class Initialized
INFO - 2018-07-12 16:17:34 --> Router Class Initialized
INFO - 2018-07-12 16:17:34 --> Output Class Initialized
INFO - 2018-07-12 16:17:34 --> Security Class Initialized
DEBUG - 2018-07-12 16:17:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-12 16:17:34 --> CSRF cookie sent
INFO - 2018-07-12 16:17:34 --> Input Class Initialized
INFO - 2018-07-12 16:17:34 --> Language Class Initialized
ERROR - 2018-07-12 16:17:34 --> 404 Page Not Found: 404testpage4525d2fdc/index
INFO - 2018-07-12 16:17:34 --> Config Class Initialized
INFO - 2018-07-12 16:17:34 --> Hooks Class Initialized
DEBUG - 2018-07-12 16:17:34 --> UTF-8 Support Enabled
INFO - 2018-07-12 16:17:34 --> Utf8 Class Initialized
INFO - 2018-07-12 16:17:34 --> URI Class Initialized
INFO - 2018-07-12 16:17:34 --> Router Class Initialized
INFO - 2018-07-12 16:17:34 --> Output Class Initialized
INFO - 2018-07-12 16:17:34 --> Security Class Initialized
DEBUG - 2018-07-12 16:17:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-12 16:17:34 --> CSRF cookie sent
INFO - 2018-07-12 16:17:34 --> Input Class Initialized
INFO - 2018-07-12 16:17:34 --> Language Class Initialized
ERROR - 2018-07-12 16:17:34 --> 404 Page Not Found: 404javascriptjs/index
INFO - 2018-07-12 16:17:35 --> Config Class Initialized
INFO - 2018-07-12 16:17:35 --> Hooks Class Initialized
DEBUG - 2018-07-12 16:17:35 --> UTF-8 Support Enabled
INFO - 2018-07-12 16:17:35 --> Utf8 Class Initialized
INFO - 2018-07-12 16:17:35 --> URI Class Initialized
INFO - 2018-07-12 16:17:35 --> Router Class Initialized
INFO - 2018-07-12 16:17:35 --> Output Class Initialized
INFO - 2018-07-12 16:17:35 --> Security Class Initialized
DEBUG - 2018-07-12 16:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-12 16:17:35 --> CSRF cookie sent
INFO - 2018-07-12 16:17:35 --> Input Class Initialized
INFO - 2018-07-12 16:17:35 --> Language Class Initialized
INFO - 2018-07-12 16:17:35 --> Loader Class Initialized
INFO - 2018-07-12 16:17:35 --> Helper loaded: url_helper
INFO - 2018-07-12 16:17:35 --> Helper loaded: form_helper
INFO - 2018-07-12 16:17:35 --> Helper loaded: language_helper
DEBUG - 2018-07-12 16:17:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-12 16:17:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-12 16:17:35 --> User Agent Class Initialized
INFO - 2018-07-12 16:17:35 --> Controller Class Initialized
INFO - 2018-07-12 16:17:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-12 16:17:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-12 16:17:35 --> Pixel_Model class loaded
INFO - 2018-07-12 16:17:35 --> Database Driver Class Initialized
INFO - 2018-07-12 16:17:35 --> Model "QuestionsModel" initialized
INFO - 2018-07-12 16:17:35 --> Config Class Initialized
INFO - 2018-07-12 16:17:35 --> Hooks Class Initialized
DEBUG - 2018-07-12 16:17:35 --> UTF-8 Support Enabled
INFO - 2018-07-12 16:17:35 --> Utf8 Class Initialized
INFO - 2018-07-12 16:17:35 --> URI Class Initialized
INFO - 2018-07-12 16:17:35 --> Router Class Initialized
INFO - 2018-07-12 16:17:35 --> Output Class Initialized
INFO - 2018-07-12 16:17:35 --> Security Class Initialized
DEBUG - 2018-07-12 16:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-12 16:17:35 --> CSRF cookie sent
INFO - 2018-07-12 16:17:35 --> Input Class Initialized
INFO - 2018-07-12 16:17:35 --> Language Class Initialized
INFO - 2018-07-12 16:17:35 --> Loader Class Initialized
INFO - 2018-07-12 16:17:35 --> Helper loaded: url_helper
INFO - 2018-07-12 16:17:35 --> Helper loaded: form_helper
INFO - 2018-07-12 16:17:35 --> Helper loaded: language_helper
DEBUG - 2018-07-12 16:17:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-12 16:17:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-12 16:17:35 --> User Agent Class Initialized
INFO - 2018-07-12 16:17:35 --> Controller Class Initialized
INFO - 2018-07-12 16:17:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-12 16:17:35 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-12 16:17:35 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-12 16:17:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-12 16:17:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-12 16:17:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-12 16:17:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-12 16:17:35 --> Could not find the language line "req_email"
INFO - 2018-07-12 16:17:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-12 16:17:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-12 16:17:35 --> Final output sent to browser
DEBUG - 2018-07-12 16:17:35 --> Total execution time: 0.0210
INFO - 2018-07-12 16:17:35 --> Config Class Initialized
INFO - 2018-07-12 16:17:35 --> Hooks Class Initialized
DEBUG - 2018-07-12 16:17:35 --> UTF-8 Support Enabled
INFO - 2018-07-12 16:17:35 --> Utf8 Class Initialized
INFO - 2018-07-12 16:17:35 --> URI Class Initialized
INFO - 2018-07-12 16:17:35 --> Router Class Initialized
INFO - 2018-07-12 16:17:35 --> Output Class Initialized
INFO - 2018-07-12 16:17:35 --> Security Class Initialized
DEBUG - 2018-07-12 16:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-12 16:17:35 --> CSRF cookie sent
INFO - 2018-07-12 16:17:35 --> Input Class Initialized
INFO - 2018-07-12 16:17:35 --> Language Class Initialized
INFO - 2018-07-12 16:17:35 --> Loader Class Initialized
INFO - 2018-07-12 16:17:35 --> Helper loaded: url_helper
INFO - 2018-07-12 16:17:35 --> Helper loaded: form_helper
INFO - 2018-07-12 16:17:35 --> Helper loaded: language_helper
DEBUG - 2018-07-12 16:17:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-12 16:17:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-12 16:17:35 --> User Agent Class Initialized
INFO - 2018-07-12 16:17:35 --> Controller Class Initialized
INFO - 2018-07-12 16:17:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-12 16:17:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-12 16:17:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-12 16:17:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-12 16:17:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-12 16:17:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-12 16:17:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-07-12 16:17:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-12 16:17:35 --> Final output sent to browser
DEBUG - 2018-07-12 16:17:35 --> Total execution time: 0.0219
INFO - 2018-07-12 16:17:36 --> Config Class Initialized
INFO - 2018-07-12 16:17:36 --> Hooks Class Initialized
DEBUG - 2018-07-12 16:17:36 --> UTF-8 Support Enabled
INFO - 2018-07-12 16:17:36 --> Utf8 Class Initialized
INFO - 2018-07-12 16:17:36 --> URI Class Initialized
INFO - 2018-07-12 16:17:36 --> Router Class Initialized
INFO - 2018-07-12 16:17:36 --> Output Class Initialized
INFO - 2018-07-12 16:17:36 --> Security Class Initialized
DEBUG - 2018-07-12 16:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-12 16:17:36 --> CSRF cookie sent
INFO - 2018-07-12 16:17:36 --> Input Class Initialized
INFO - 2018-07-12 16:17:36 --> Language Class Initialized
INFO - 2018-07-12 16:17:36 --> Loader Class Initialized
INFO - 2018-07-12 16:17:36 --> Helper loaded: url_helper
INFO - 2018-07-12 16:17:36 --> Helper loaded: form_helper
INFO - 2018-07-12 16:17:36 --> Helper loaded: language_helper
DEBUG - 2018-07-12 16:17:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-12 16:17:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-12 16:17:36 --> User Agent Class Initialized
INFO - 2018-07-12 16:17:36 --> Controller Class Initialized
INFO - 2018-07-12 16:17:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-12 16:17:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-12 16:17:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-12 16:17:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-12 16:17:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-12 16:17:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-12 16:17:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-07-12 16:17:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-12 16:17:36 --> Final output sent to browser
DEBUG - 2018-07-12 16:17:36 --> Total execution time: 0.0224
INFO - 2018-07-12 16:17:36 --> Config Class Initialized
INFO - 2018-07-12 16:17:36 --> Hooks Class Initialized
DEBUG - 2018-07-12 16:17:36 --> UTF-8 Support Enabled
INFO - 2018-07-12 16:17:36 --> Utf8 Class Initialized
INFO - 2018-07-12 16:17:36 --> URI Class Initialized
INFO - 2018-07-12 16:17:36 --> Router Class Initialized
INFO - 2018-07-12 16:17:36 --> Output Class Initialized
INFO - 2018-07-12 16:17:36 --> Security Class Initialized
DEBUG - 2018-07-12 16:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-12 16:17:36 --> CSRF cookie sent
INFO - 2018-07-12 16:17:36 --> Input Class Initialized
INFO - 2018-07-12 16:17:36 --> Language Class Initialized
INFO - 2018-07-12 16:17:36 --> Loader Class Initialized
INFO - 2018-07-12 16:17:36 --> Helper loaded: url_helper
INFO - 2018-07-12 16:17:36 --> Helper loaded: form_helper
INFO - 2018-07-12 16:17:36 --> Helper loaded: language_helper
DEBUG - 2018-07-12 16:17:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-12 16:17:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-12 16:17:36 --> User Agent Class Initialized
INFO - 2018-07-12 16:17:36 --> Controller Class Initialized
INFO - 2018-07-12 16:17:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-12 16:17:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-12 16:17:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-12 16:17:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-12 16:17:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-12 16:17:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-12 16:17:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-07-12 16:17:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-12 16:17:36 --> Final output sent to browser
DEBUG - 2018-07-12 16:17:36 --> Total execution time: 0.0207
INFO - 2018-07-12 16:17:36 --> Config Class Initialized
INFO - 2018-07-12 16:17:36 --> Hooks Class Initialized
DEBUG - 2018-07-12 16:17:36 --> UTF-8 Support Enabled
INFO - 2018-07-12 16:17:36 --> Utf8 Class Initialized
INFO - 2018-07-12 16:17:36 --> URI Class Initialized
INFO - 2018-07-12 16:17:36 --> Router Class Initialized
INFO - 2018-07-12 16:17:36 --> Output Class Initialized
INFO - 2018-07-12 16:17:36 --> Security Class Initialized
DEBUG - 2018-07-12 16:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-12 16:17:36 --> CSRF cookie sent
INFO - 2018-07-12 16:17:36 --> Input Class Initialized
INFO - 2018-07-12 16:17:36 --> Language Class Initialized
INFO - 2018-07-12 16:17:36 --> Loader Class Initialized
INFO - 2018-07-12 16:17:36 --> Helper loaded: url_helper
INFO - 2018-07-12 16:17:36 --> Helper loaded: form_helper
INFO - 2018-07-12 16:17:36 --> Helper loaded: language_helper
DEBUG - 2018-07-12 16:17:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-12 16:17:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-12 16:17:36 --> User Agent Class Initialized
INFO - 2018-07-12 16:17:36 --> Controller Class Initialized
INFO - 2018-07-12 16:17:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-12 16:17:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-12 16:17:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-12 16:17:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-12 16:17:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-12 16:17:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-12 16:17:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-07-12 16:17:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-12 16:17:36 --> Final output sent to browser
DEBUG - 2018-07-12 16:17:36 --> Total execution time: 0.0215
INFO - 2018-07-12 16:17:37 --> Config Class Initialized
INFO - 2018-07-12 16:17:37 --> Hooks Class Initialized
DEBUG - 2018-07-12 16:17:37 --> UTF-8 Support Enabled
INFO - 2018-07-12 16:17:37 --> Utf8 Class Initialized
INFO - 2018-07-12 16:17:37 --> URI Class Initialized
INFO - 2018-07-12 16:17:37 --> Router Class Initialized
INFO - 2018-07-12 16:17:37 --> Output Class Initialized
INFO - 2018-07-12 16:17:37 --> Security Class Initialized
DEBUG - 2018-07-12 16:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-12 16:17:37 --> CSRF cookie sent
INFO - 2018-07-12 16:17:37 --> Input Class Initialized
INFO - 2018-07-12 16:17:37 --> Language Class Initialized
INFO - 2018-07-12 16:17:37 --> Loader Class Initialized
INFO - 2018-07-12 16:17:37 --> Helper loaded: url_helper
INFO - 2018-07-12 16:17:37 --> Helper loaded: form_helper
INFO - 2018-07-12 16:17:37 --> Helper loaded: language_helper
DEBUG - 2018-07-12 16:17:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-12 16:17:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-12 16:17:37 --> User Agent Class Initialized
INFO - 2018-07-12 16:17:37 --> Controller Class Initialized
INFO - 2018-07-12 16:17:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-12 16:17:37 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-12 16:17:37 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-12 16:17:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-12 16:17:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-12 16:17:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-12 16:17:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-12 16:17:37 --> Could not find the language line "req_email"
INFO - 2018-07-12 16:17:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-12 16:17:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-12 16:17:37 --> Final output sent to browser
DEBUG - 2018-07-12 16:17:37 --> Total execution time: 0.0320
INFO - 2018-07-12 16:17:37 --> Config Class Initialized
INFO - 2018-07-12 16:17:37 --> Hooks Class Initialized
DEBUG - 2018-07-12 16:17:37 --> UTF-8 Support Enabled
INFO - 2018-07-12 16:17:37 --> Utf8 Class Initialized
INFO - 2018-07-12 16:17:37 --> URI Class Initialized
INFO - 2018-07-12 16:17:37 --> Router Class Initialized
INFO - 2018-07-12 16:17:37 --> Output Class Initialized
INFO - 2018-07-12 16:17:37 --> Security Class Initialized
DEBUG - 2018-07-12 16:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-12 16:17:37 --> CSRF cookie sent
INFO - 2018-07-12 16:17:37 --> Input Class Initialized
INFO - 2018-07-12 16:17:37 --> Language Class Initialized
INFO - 2018-07-12 16:17:37 --> Loader Class Initialized
INFO - 2018-07-12 16:17:37 --> Helper loaded: url_helper
INFO - 2018-07-12 16:17:37 --> Helper loaded: form_helper
INFO - 2018-07-12 16:17:37 --> Helper loaded: language_helper
DEBUG - 2018-07-12 16:17:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-12 16:17:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-12 16:17:37 --> User Agent Class Initialized
INFO - 2018-07-12 16:17:37 --> Controller Class Initialized
INFO - 2018-07-12 16:17:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-12 16:17:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-12 16:17:37 --> Pixel_Model class loaded
INFO - 2018-07-12 16:17:37 --> Database Driver Class Initialized
INFO - 2018-07-12 16:17:37 --> Model "QuestionsModel" initialized
INFO - 2018-07-12 16:17:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-12 16:17:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-12 16:17:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-12 16:17:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-12 16:17:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/buy_gift.php
INFO - 2018-07-12 16:17:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-12 16:17:37 --> Final output sent to browser
DEBUG - 2018-07-12 16:17:37 --> Total execution time: 0.0329
INFO - 2018-07-12 17:03:40 --> Config Class Initialized
INFO - 2018-07-12 17:03:40 --> Hooks Class Initialized
DEBUG - 2018-07-12 17:03:40 --> UTF-8 Support Enabled
INFO - 2018-07-12 17:03:40 --> Utf8 Class Initialized
INFO - 2018-07-12 17:03:40 --> URI Class Initialized
DEBUG - 2018-07-12 17:03:40 --> No URI present. Default controller set.
INFO - 2018-07-12 17:03:40 --> Router Class Initialized
INFO - 2018-07-12 17:03:40 --> Output Class Initialized
INFO - 2018-07-12 17:03:40 --> Security Class Initialized
DEBUG - 2018-07-12 17:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-12 17:03:40 --> CSRF cookie sent
INFO - 2018-07-12 17:03:40 --> Input Class Initialized
INFO - 2018-07-12 17:03:40 --> Language Class Initialized
INFO - 2018-07-12 17:03:40 --> Loader Class Initialized
INFO - 2018-07-12 17:03:40 --> Helper loaded: url_helper
INFO - 2018-07-12 17:03:40 --> Helper loaded: form_helper
INFO - 2018-07-12 17:03:40 --> Helper loaded: language_helper
DEBUG - 2018-07-12 17:03:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-12 17:03:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-12 17:03:40 --> User Agent Class Initialized
INFO - 2018-07-12 17:03:40 --> Controller Class Initialized
INFO - 2018-07-12 17:03:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-12 17:03:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-12 17:03:40 --> Pixel_Model class loaded
INFO - 2018-07-12 17:03:40 --> Database Driver Class Initialized
INFO - 2018-07-12 17:03:40 --> Model "QuestionsModel" initialized
INFO - 2018-07-12 17:03:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-12 17:03:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-12 17:03:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-12 17:03:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-12 17:03:40 --> Final output sent to browser
DEBUG - 2018-07-12 17:03:40 --> Total execution time: 0.0341
INFO - 2018-07-12 17:36:07 --> Config Class Initialized
INFO - 2018-07-12 17:36:07 --> Hooks Class Initialized
DEBUG - 2018-07-12 17:36:07 --> UTF-8 Support Enabled
INFO - 2018-07-12 17:36:07 --> Utf8 Class Initialized
INFO - 2018-07-12 17:36:07 --> URI Class Initialized
INFO - 2018-07-12 17:36:07 --> Router Class Initialized
INFO - 2018-07-12 17:36:07 --> Output Class Initialized
INFO - 2018-07-12 17:36:07 --> Security Class Initialized
DEBUG - 2018-07-12 17:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-12 17:36:07 --> CSRF cookie sent
INFO - 2018-07-12 17:36:07 --> Input Class Initialized
INFO - 2018-07-12 17:36:07 --> Language Class Initialized
ERROR - 2018-07-12 17:36:07 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-12 17:51:39 --> Config Class Initialized
INFO - 2018-07-12 17:51:39 --> Hooks Class Initialized
DEBUG - 2018-07-12 17:51:39 --> UTF-8 Support Enabled
INFO - 2018-07-12 17:51:39 --> Utf8 Class Initialized
INFO - 2018-07-12 17:51:39 --> URI Class Initialized
INFO - 2018-07-12 17:51:39 --> Router Class Initialized
INFO - 2018-07-12 17:51:39 --> Output Class Initialized
INFO - 2018-07-12 17:51:39 --> Security Class Initialized
DEBUG - 2018-07-12 17:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-12 17:51:39 --> CSRF cookie sent
INFO - 2018-07-12 17:51:39 --> Input Class Initialized
INFO - 2018-07-12 17:51:39 --> Language Class Initialized
ERROR - 2018-07-12 17:51:39 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-12 17:51:39 --> Config Class Initialized
INFO - 2018-07-12 17:51:39 --> Hooks Class Initialized
DEBUG - 2018-07-12 17:51:39 --> UTF-8 Support Enabled
INFO - 2018-07-12 17:51:39 --> Utf8 Class Initialized
INFO - 2018-07-12 17:51:39 --> URI Class Initialized
DEBUG - 2018-07-12 17:51:39 --> No URI present. Default controller set.
INFO - 2018-07-12 17:51:39 --> Router Class Initialized
INFO - 2018-07-12 17:51:39 --> Output Class Initialized
INFO - 2018-07-12 17:51:39 --> Security Class Initialized
DEBUG - 2018-07-12 17:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-12 17:51:39 --> CSRF cookie sent
INFO - 2018-07-12 17:51:39 --> Input Class Initialized
INFO - 2018-07-12 17:51:39 --> Language Class Initialized
INFO - 2018-07-12 17:51:39 --> Loader Class Initialized
INFO - 2018-07-12 17:51:39 --> Helper loaded: url_helper
INFO - 2018-07-12 17:51:39 --> Helper loaded: form_helper
INFO - 2018-07-12 17:51:39 --> Helper loaded: language_helper
DEBUG - 2018-07-12 17:51:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-12 17:51:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-12 17:51:39 --> User Agent Class Initialized
INFO - 2018-07-12 17:51:39 --> Controller Class Initialized
INFO - 2018-07-12 17:51:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-12 17:51:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-12 17:51:39 --> Pixel_Model class loaded
INFO - 2018-07-12 17:51:39 --> Database Driver Class Initialized
INFO - 2018-07-12 17:51:39 --> Model "QuestionsModel" initialized
INFO - 2018-07-12 17:51:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-12 17:51:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-12 17:51:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-12 17:51:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-12 17:51:39 --> Final output sent to browser
DEBUG - 2018-07-12 17:51:39 --> Total execution time: 0.0327
INFO - 2018-07-12 17:51:41 --> Config Class Initialized
INFO - 2018-07-12 17:51:41 --> Hooks Class Initialized
DEBUG - 2018-07-12 17:51:41 --> UTF-8 Support Enabled
INFO - 2018-07-12 17:51:41 --> Utf8 Class Initialized
INFO - 2018-07-12 17:51:41 --> URI Class Initialized
INFO - 2018-07-12 17:51:41 --> Router Class Initialized
INFO - 2018-07-12 17:51:41 --> Output Class Initialized
INFO - 2018-07-12 17:51:41 --> Security Class Initialized
DEBUG - 2018-07-12 17:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-12 17:51:41 --> CSRF cookie sent
INFO - 2018-07-12 17:51:41 --> Input Class Initialized
INFO - 2018-07-12 17:51:41 --> Language Class Initialized
INFO - 2018-07-12 17:51:41 --> Loader Class Initialized
INFO - 2018-07-12 17:51:41 --> Helper loaded: url_helper
INFO - 2018-07-12 17:51:41 --> Helper loaded: form_helper
INFO - 2018-07-12 17:51:41 --> Helper loaded: language_helper
DEBUG - 2018-07-12 17:51:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-12 17:51:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-12 17:51:41 --> User Agent Class Initialized
INFO - 2018-07-12 17:51:41 --> Controller Class Initialized
INFO - 2018-07-12 17:51:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-12 17:51:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-12 17:51:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-12 17:51:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-12 17:51:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-12 17:51:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-12 17:51:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/911.php
INFO - 2018-07-12 17:51:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-12 17:51:41 --> Final output sent to browser
DEBUG - 2018-07-12 17:51:41 --> Total execution time: 0.0255
INFO - 2018-07-12 17:51:47 --> Config Class Initialized
INFO - 2018-07-12 17:51:47 --> Hooks Class Initialized
DEBUG - 2018-07-12 17:51:47 --> UTF-8 Support Enabled
INFO - 2018-07-12 17:51:47 --> Utf8 Class Initialized
INFO - 2018-07-12 17:51:47 --> URI Class Initialized
INFO - 2018-07-12 17:51:47 --> Router Class Initialized
INFO - 2018-07-12 17:51:47 --> Output Class Initialized
INFO - 2018-07-12 17:51:47 --> Security Class Initialized
DEBUG - 2018-07-12 17:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-12 17:51:47 --> CSRF cookie sent
INFO - 2018-07-12 17:51:47 --> Input Class Initialized
INFO - 2018-07-12 17:51:47 --> Language Class Initialized
INFO - 2018-07-12 17:51:47 --> Loader Class Initialized
INFO - 2018-07-12 17:51:47 --> Helper loaded: url_helper
INFO - 2018-07-12 17:51:47 --> Helper loaded: form_helper
INFO - 2018-07-12 17:51:47 --> Helper loaded: language_helper
DEBUG - 2018-07-12 17:51:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-12 17:51:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-12 17:51:47 --> User Agent Class Initialized
INFO - 2018-07-12 17:51:47 --> Controller Class Initialized
INFO - 2018-07-12 17:51:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-12 17:51:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-12 17:51:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-12 17:51:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-12 17:51:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-12 17:51:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-12 17:51:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/consultant.php
INFO - 2018-07-12 17:51:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-12 17:51:47 --> Final output sent to browser
DEBUG - 2018-07-12 17:51:47 --> Total execution time: 0.0234
INFO - 2018-07-12 17:51:49 --> Config Class Initialized
INFO - 2018-07-12 17:51:49 --> Hooks Class Initialized
DEBUG - 2018-07-12 17:51:49 --> UTF-8 Support Enabled
INFO - 2018-07-12 17:51:49 --> Utf8 Class Initialized
INFO - 2018-07-12 17:51:49 --> URI Class Initialized
INFO - 2018-07-12 17:51:49 --> Router Class Initialized
INFO - 2018-07-12 17:51:49 --> Output Class Initialized
INFO - 2018-07-12 17:51:49 --> Security Class Initialized
DEBUG - 2018-07-12 17:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-12 17:51:49 --> CSRF cookie sent
INFO - 2018-07-12 17:51:49 --> Input Class Initialized
INFO - 2018-07-12 17:51:49 --> Language Class Initialized
INFO - 2018-07-12 17:51:49 --> Loader Class Initialized
INFO - 2018-07-12 17:51:49 --> Helper loaded: url_helper
INFO - 2018-07-12 17:51:49 --> Helper loaded: form_helper
INFO - 2018-07-12 17:51:49 --> Helper loaded: language_helper
DEBUG - 2018-07-12 17:51:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-12 17:51:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-12 17:51:49 --> User Agent Class Initialized
INFO - 2018-07-12 17:51:49 --> Controller Class Initialized
INFO - 2018-07-12 17:51:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-12 17:51:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-12 17:51:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-12 17:51:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-12 17:51:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-12 17:51:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-12 17:51:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/executive.php
INFO - 2018-07-12 17:51:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-12 17:51:49 --> Final output sent to browser
DEBUG - 2018-07-12 17:51:49 --> Total execution time: 0.0226
INFO - 2018-07-12 17:51:53 --> Config Class Initialized
INFO - 2018-07-12 17:51:53 --> Hooks Class Initialized
DEBUG - 2018-07-12 17:51:53 --> UTF-8 Support Enabled
INFO - 2018-07-12 17:51:53 --> Utf8 Class Initialized
INFO - 2018-07-12 17:51:53 --> URI Class Initialized
INFO - 2018-07-12 17:51:53 --> Router Class Initialized
INFO - 2018-07-12 17:51:53 --> Output Class Initialized
INFO - 2018-07-12 17:51:53 --> Security Class Initialized
DEBUG - 2018-07-12 17:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-12 17:51:53 --> CSRF cookie sent
INFO - 2018-07-12 17:51:53 --> Input Class Initialized
INFO - 2018-07-12 17:51:53 --> Language Class Initialized
INFO - 2018-07-12 17:51:53 --> Loader Class Initialized
INFO - 2018-07-12 17:51:53 --> Helper loaded: url_helper
INFO - 2018-07-12 17:51:53 --> Helper loaded: form_helper
INFO - 2018-07-12 17:51:53 --> Helper loaded: language_helper
DEBUG - 2018-07-12 17:51:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-12 17:51:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-12 17:51:53 --> User Agent Class Initialized
INFO - 2018-07-12 17:51:53 --> Controller Class Initialized
INFO - 2018-07-12 17:51:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-12 17:51:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-12 17:51:53 --> Pixel_Model class loaded
INFO - 2018-07-12 17:51:53 --> Database Driver Class Initialized
INFO - 2018-07-12 17:51:53 --> Model "RegistrationModel" initialized
DEBUG - 2018-07-12 17:51:53 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-12 17:51:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-12 17:51:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-12 17:51:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-12 17:51:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-12 17:51:53 --> Could not find the language line "req_email"
INFO - 2018-07-12 17:51:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup_fa.php
INFO - 2018-07-12 17:51:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-12 17:51:53 --> Final output sent to browser
DEBUG - 2018-07-12 17:51:53 --> Total execution time: 0.0325
INFO - 2018-07-12 17:51:56 --> Config Class Initialized
INFO - 2018-07-12 17:51:56 --> Hooks Class Initialized
DEBUG - 2018-07-12 17:51:56 --> UTF-8 Support Enabled
INFO - 2018-07-12 17:51:56 --> Utf8 Class Initialized
INFO - 2018-07-12 17:51:56 --> URI Class Initialized
INFO - 2018-07-12 17:51:56 --> Router Class Initialized
INFO - 2018-07-12 17:51:56 --> Output Class Initialized
INFO - 2018-07-12 17:51:56 --> Security Class Initialized
DEBUG - 2018-07-12 17:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-12 17:51:56 --> CSRF cookie sent
INFO - 2018-07-12 17:51:56 --> Input Class Initialized
INFO - 2018-07-12 17:51:56 --> Language Class Initialized
INFO - 2018-07-12 17:51:56 --> Loader Class Initialized
INFO - 2018-07-12 17:51:56 --> Helper loaded: url_helper
INFO - 2018-07-12 17:51:56 --> Helper loaded: form_helper
INFO - 2018-07-12 17:51:56 --> Helper loaded: language_helper
DEBUG - 2018-07-12 17:51:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-12 17:51:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-12 17:51:56 --> User Agent Class Initialized
INFO - 2018-07-12 17:51:56 --> Controller Class Initialized
INFO - 2018-07-12 17:51:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-12 17:51:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-12 17:51:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-12 17:51:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-12 17:51:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-12 17:51:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-12 17:51:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/faqs.php
INFO - 2018-07-12 17:51:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-12 17:51:56 --> Final output sent to browser
DEBUG - 2018-07-12 17:51:56 --> Total execution time: 0.0325
INFO - 2018-07-12 17:52:05 --> Config Class Initialized
INFO - 2018-07-12 17:52:05 --> Hooks Class Initialized
DEBUG - 2018-07-12 17:52:05 --> UTF-8 Support Enabled
INFO - 2018-07-12 17:52:05 --> Utf8 Class Initialized
INFO - 2018-07-12 17:52:05 --> URI Class Initialized
INFO - 2018-07-12 17:52:05 --> Router Class Initialized
INFO - 2018-07-12 17:52:05 --> Output Class Initialized
INFO - 2018-07-12 17:52:05 --> Security Class Initialized
DEBUG - 2018-07-12 17:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-12 17:52:05 --> CSRF cookie sent
INFO - 2018-07-12 17:52:05 --> Input Class Initialized
INFO - 2018-07-12 17:52:05 --> Language Class Initialized
INFO - 2018-07-12 17:52:05 --> Loader Class Initialized
INFO - 2018-07-12 17:52:05 --> Helper loaded: url_helper
INFO - 2018-07-12 17:52:05 --> Helper loaded: form_helper
INFO - 2018-07-12 17:52:05 --> Helper loaded: language_helper
DEBUG - 2018-07-12 17:52:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-12 17:52:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-12 17:52:05 --> User Agent Class Initialized
INFO - 2018-07-12 17:52:05 --> Controller Class Initialized
INFO - 2018-07-12 17:52:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-12 17:52:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-12 17:52:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-12 17:52:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-12 17:52:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-12 17:52:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-12 17:52:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/finance.php
INFO - 2018-07-12 17:52:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-12 17:52:05 --> Final output sent to browser
DEBUG - 2018-07-12 17:52:05 --> Total execution time: 0.0325
INFO - 2018-07-12 17:52:09 --> Config Class Initialized
INFO - 2018-07-12 17:52:09 --> Hooks Class Initialized
DEBUG - 2018-07-12 17:52:09 --> UTF-8 Support Enabled
INFO - 2018-07-12 17:52:09 --> Utf8 Class Initialized
INFO - 2018-07-12 17:52:09 --> URI Class Initialized
INFO - 2018-07-12 17:52:09 --> Router Class Initialized
INFO - 2018-07-12 17:52:09 --> Output Class Initialized
INFO - 2018-07-12 17:52:09 --> Security Class Initialized
DEBUG - 2018-07-12 17:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-12 17:52:09 --> CSRF cookie sent
INFO - 2018-07-12 17:52:09 --> Input Class Initialized
INFO - 2018-07-12 17:52:09 --> Language Class Initialized
INFO - 2018-07-12 17:52:09 --> Loader Class Initialized
INFO - 2018-07-12 17:52:09 --> Helper loaded: url_helper
INFO - 2018-07-12 17:52:09 --> Helper loaded: form_helper
INFO - 2018-07-12 17:52:09 --> Helper loaded: language_helper
DEBUG - 2018-07-12 17:52:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-12 17:52:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-12 17:52:09 --> User Agent Class Initialized
INFO - 2018-07-12 17:52:09 --> Controller Class Initialized
INFO - 2018-07-12 17:52:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-12 17:52:09 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-12 17:52:09 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-12 17:52:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-12 17:52:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-12 17:52:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-12 17:52:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-12 17:52:09 --> Could not find the language line "req_email"
INFO - 2018-07-12 17:52:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/forgot_password.php
INFO - 2018-07-12 17:52:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-12 17:52:09 --> Final output sent to browser
DEBUG - 2018-07-12 17:52:09 --> Total execution time: 0.0291
INFO - 2018-07-12 17:52:13 --> Config Class Initialized
INFO - 2018-07-12 17:52:13 --> Hooks Class Initialized
DEBUG - 2018-07-12 17:52:13 --> UTF-8 Support Enabled
INFO - 2018-07-12 17:52:13 --> Utf8 Class Initialized
INFO - 2018-07-12 17:52:13 --> URI Class Initialized
INFO - 2018-07-12 17:52:13 --> Router Class Initialized
INFO - 2018-07-12 17:52:13 --> Output Class Initialized
INFO - 2018-07-12 17:52:13 --> Security Class Initialized
DEBUG - 2018-07-12 17:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-12 17:52:13 --> CSRF cookie sent
INFO - 2018-07-12 17:52:13 --> Input Class Initialized
INFO - 2018-07-12 17:52:13 --> Language Class Initialized
INFO - 2018-07-12 17:52:13 --> Loader Class Initialized
INFO - 2018-07-12 17:52:13 --> Helper loaded: url_helper
INFO - 2018-07-12 17:52:13 --> Helper loaded: form_helper
INFO - 2018-07-12 17:52:13 --> Helper loaded: language_helper
DEBUG - 2018-07-12 17:52:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-12 17:52:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-12 17:52:13 --> User Agent Class Initialized
INFO - 2018-07-12 17:52:13 --> Controller Class Initialized
INFO - 2018-07-12 17:52:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-12 17:52:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-12 17:52:15 --> Config Class Initialized
INFO - 2018-07-12 17:52:15 --> Hooks Class Initialized
DEBUG - 2018-07-12 17:52:15 --> UTF-8 Support Enabled
INFO - 2018-07-12 17:52:15 --> Utf8 Class Initialized
INFO - 2018-07-12 17:52:15 --> URI Class Initialized
INFO - 2018-07-12 17:52:15 --> Router Class Initialized
INFO - 2018-07-12 17:52:15 --> Output Class Initialized
INFO - 2018-07-12 17:52:15 --> Security Class Initialized
DEBUG - 2018-07-12 17:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-12 17:52:15 --> CSRF cookie sent
INFO - 2018-07-12 17:52:15 --> Input Class Initialized
INFO - 2018-07-12 17:52:15 --> Language Class Initialized
INFO - 2018-07-12 17:52:15 --> Loader Class Initialized
INFO - 2018-07-12 17:52:15 --> Helper loaded: url_helper
INFO - 2018-07-12 17:52:15 --> Helper loaded: form_helper
INFO - 2018-07-12 17:52:15 --> Helper loaded: language_helper
DEBUG - 2018-07-12 17:52:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-12 17:52:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-12 17:52:15 --> User Agent Class Initialized
INFO - 2018-07-12 17:52:15 --> Controller Class Initialized
INFO - 2018-07-12 17:52:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-12 17:52:15 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-12 17:52:15 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-12 17:52:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-12 17:52:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-12 17:52:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-12 17:52:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-12 17:52:15 --> Could not find the language line "req_email"
INFO - 2018-07-12 17:52:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-12 17:52:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-12 17:52:15 --> Final output sent to browser
DEBUG - 2018-07-12 17:52:15 --> Total execution time: 0.0235
INFO - 2018-07-12 17:52:18 --> Config Class Initialized
INFO - 2018-07-12 17:52:18 --> Hooks Class Initialized
DEBUG - 2018-07-12 17:52:18 --> UTF-8 Support Enabled
INFO - 2018-07-12 17:52:18 --> Utf8 Class Initialized
INFO - 2018-07-12 17:52:18 --> URI Class Initialized
INFO - 2018-07-12 17:52:18 --> Router Class Initialized
INFO - 2018-07-12 17:52:18 --> Output Class Initialized
INFO - 2018-07-12 17:52:18 --> Security Class Initialized
DEBUG - 2018-07-12 17:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-12 17:52:18 --> CSRF cookie sent
INFO - 2018-07-12 17:52:18 --> Input Class Initialized
INFO - 2018-07-12 17:52:18 --> Language Class Initialized
INFO - 2018-07-12 17:52:18 --> Loader Class Initialized
INFO - 2018-07-12 17:52:18 --> Helper loaded: url_helper
INFO - 2018-07-12 17:52:18 --> Helper loaded: form_helper
INFO - 2018-07-12 17:52:18 --> Helper loaded: language_helper
DEBUG - 2018-07-12 17:52:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-12 17:52:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-12 17:52:18 --> User Agent Class Initialized
INFO - 2018-07-12 17:52:18 --> Controller Class Initialized
INFO - 2018-07-12 17:52:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-12 17:52:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-12 17:52:18 --> Pixel_Model class loaded
INFO - 2018-07-12 17:52:18 --> Database Driver Class Initialized
INFO - 2018-07-12 17:52:18 --> Model "RegistrationModel" initialized
DEBUG - 2018-07-12 17:52:18 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-12 17:52:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-12 17:52:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-12 17:52:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-12 17:52:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-12 17:52:18 --> Could not find the language line "req_email"
INFO - 2018-07-12 17:52:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup_lawyer.php
INFO - 2018-07-12 17:52:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-12 17:52:18 --> Final output sent to browser
DEBUG - 2018-07-12 17:52:18 --> Total execution time: 0.0329
INFO - 2018-07-12 17:52:23 --> Config Class Initialized
INFO - 2018-07-12 17:52:23 --> Hooks Class Initialized
DEBUG - 2018-07-12 17:52:23 --> UTF-8 Support Enabled
INFO - 2018-07-12 17:52:23 --> Utf8 Class Initialized
INFO - 2018-07-12 17:52:23 --> URI Class Initialized
INFO - 2018-07-12 17:52:23 --> Router Class Initialized
INFO - 2018-07-12 17:52:23 --> Output Class Initialized
INFO - 2018-07-12 17:52:23 --> Security Class Initialized
DEBUG - 2018-07-12 17:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-12 17:52:23 --> CSRF cookie sent
INFO - 2018-07-12 17:52:23 --> Input Class Initialized
INFO - 2018-07-12 17:52:23 --> Language Class Initialized
INFO - 2018-07-12 17:52:23 --> Loader Class Initialized
INFO - 2018-07-12 17:52:23 --> Helper loaded: url_helper
INFO - 2018-07-12 17:52:23 --> Helper loaded: form_helper
INFO - 2018-07-12 17:52:23 --> Helper loaded: language_helper
DEBUG - 2018-07-12 17:52:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-12 17:52:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-12 17:52:23 --> User Agent Class Initialized
INFO - 2018-07-12 17:52:23 --> Controller Class Initialized
INFO - 2018-07-12 17:52:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-12 17:52:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-12 17:52:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-12 17:52:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-12 17:52:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-12 17:52:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-12 17:52:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/medical.php
INFO - 2018-07-12 17:52:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-12 17:52:23 --> Final output sent to browser
DEBUG - 2018-07-12 17:52:23 --> Total execution time: 0.0228
INFO - 2018-07-12 17:52:26 --> Config Class Initialized
INFO - 2018-07-12 17:52:26 --> Hooks Class Initialized
DEBUG - 2018-07-12 17:52:26 --> UTF-8 Support Enabled
INFO - 2018-07-12 17:52:26 --> Utf8 Class Initialized
INFO - 2018-07-12 17:52:26 --> URI Class Initialized
INFO - 2018-07-12 17:52:26 --> Router Class Initialized
INFO - 2018-07-12 17:52:26 --> Output Class Initialized
INFO - 2018-07-12 17:52:26 --> Security Class Initialized
DEBUG - 2018-07-12 17:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-12 17:52:26 --> CSRF cookie sent
INFO - 2018-07-12 17:52:26 --> Input Class Initialized
INFO - 2018-07-12 17:52:26 --> Language Class Initialized
INFO - 2018-07-12 17:52:26 --> Loader Class Initialized
INFO - 2018-07-12 17:52:26 --> Helper loaded: url_helper
INFO - 2018-07-12 17:52:26 --> Helper loaded: form_helper
INFO - 2018-07-12 17:52:26 --> Helper loaded: language_helper
DEBUG - 2018-07-12 17:52:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-12 17:52:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-12 17:52:26 --> User Agent Class Initialized
INFO - 2018-07-12 17:52:26 --> Controller Class Initialized
INFO - 2018-07-12 17:52:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-12 17:52:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-12 17:52:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-12 17:52:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-12 17:52:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-12 17:52:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-12 17:52:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/preview.php
INFO - 2018-07-12 17:52:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-12 17:52:26 --> Final output sent to browser
DEBUG - 2018-07-12 17:52:26 --> Total execution time: 0.0290
INFO - 2018-07-12 17:52:28 --> Config Class Initialized
INFO - 2018-07-12 17:52:28 --> Hooks Class Initialized
DEBUG - 2018-07-12 17:52:28 --> UTF-8 Support Enabled
INFO - 2018-07-12 17:52:28 --> Utf8 Class Initialized
INFO - 2018-07-12 17:52:28 --> URI Class Initialized
INFO - 2018-07-12 17:52:28 --> Router Class Initialized
INFO - 2018-07-12 17:52:28 --> Output Class Initialized
INFO - 2018-07-12 17:52:28 --> Security Class Initialized
DEBUG - 2018-07-12 17:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-12 17:52:28 --> CSRF cookie sent
INFO - 2018-07-12 17:52:28 --> Input Class Initialized
INFO - 2018-07-12 17:52:28 --> Language Class Initialized
INFO - 2018-07-12 17:52:28 --> Loader Class Initialized
INFO - 2018-07-12 17:52:28 --> Helper loaded: url_helper
INFO - 2018-07-12 17:52:28 --> Helper loaded: form_helper
INFO - 2018-07-12 17:52:28 --> Helper loaded: language_helper
DEBUG - 2018-07-12 17:52:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-12 17:52:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-12 17:52:28 --> User Agent Class Initialized
INFO - 2018-07-12 17:52:28 --> Controller Class Initialized
INFO - 2018-07-12 17:52:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-12 17:52:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-12 17:52:28 --> Pixel_Model class loaded
INFO - 2018-07-12 17:52:28 --> Database Driver Class Initialized
INFO - 2018-07-12 17:52:28 --> Model "RegistrationModel" initialized
DEBUG - 2018-07-12 17:52:28 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-12 17:52:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-12 17:52:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-12 17:52:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-12 17:52:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-12 17:52:28 --> Could not find the language line "req_email"
INFO - 2018-07-12 17:52:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup.php
INFO - 2018-07-12 17:52:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-12 17:52:28 --> Final output sent to browser
DEBUG - 2018-07-12 17:52:28 --> Total execution time: 0.0371
INFO - 2018-07-12 17:52:31 --> Config Class Initialized
INFO - 2018-07-12 17:52:31 --> Hooks Class Initialized
DEBUG - 2018-07-12 17:52:31 --> UTF-8 Support Enabled
INFO - 2018-07-12 17:52:31 --> Utf8 Class Initialized
INFO - 2018-07-12 17:52:31 --> URI Class Initialized
INFO - 2018-07-12 17:52:31 --> Router Class Initialized
INFO - 2018-07-12 17:52:31 --> Output Class Initialized
INFO - 2018-07-12 17:52:31 --> Security Class Initialized
DEBUG - 2018-07-12 17:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-12 17:52:31 --> CSRF cookie sent
INFO - 2018-07-12 17:52:31 --> Input Class Initialized
INFO - 2018-07-12 17:52:31 --> Language Class Initialized
INFO - 2018-07-12 17:52:31 --> Loader Class Initialized
INFO - 2018-07-12 17:52:31 --> Helper loaded: url_helper
INFO - 2018-07-12 17:52:31 --> Helper loaded: form_helper
INFO - 2018-07-12 17:52:31 --> Helper loaded: language_helper
DEBUG - 2018-07-12 17:52:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-12 17:52:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-12 17:52:31 --> User Agent Class Initialized
INFO - 2018-07-12 17:52:31 --> Controller Class Initialized
INFO - 2018-07-12 17:52:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-12 17:52:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-12 17:52:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-12 17:52:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-12 17:52:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-12 17:52:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-12 17:52:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/teacher.php
INFO - 2018-07-12 17:52:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-12 17:52:31 --> Final output sent to browser
DEBUG - 2018-07-12 17:52:31 --> Total execution time: 0.0216
INFO - 2018-07-12 18:05:30 --> Config Class Initialized
INFO - 2018-07-12 18:05:30 --> Hooks Class Initialized
DEBUG - 2018-07-12 18:05:30 --> UTF-8 Support Enabled
INFO - 2018-07-12 18:05:30 --> Utf8 Class Initialized
INFO - 2018-07-12 18:05:30 --> URI Class Initialized
DEBUG - 2018-07-12 18:05:30 --> No URI present. Default controller set.
INFO - 2018-07-12 18:05:30 --> Router Class Initialized
INFO - 2018-07-12 18:05:30 --> Output Class Initialized
INFO - 2018-07-12 18:05:30 --> Security Class Initialized
DEBUG - 2018-07-12 18:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-12 18:05:30 --> CSRF cookie sent
INFO - 2018-07-12 18:05:30 --> Input Class Initialized
INFO - 2018-07-12 18:05:30 --> Language Class Initialized
INFO - 2018-07-12 18:05:30 --> Loader Class Initialized
INFO - 2018-07-12 18:05:30 --> Helper loaded: url_helper
INFO - 2018-07-12 18:05:30 --> Helper loaded: form_helper
INFO - 2018-07-12 18:05:30 --> Helper loaded: language_helper
DEBUG - 2018-07-12 18:05:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-12 18:05:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-12 18:05:30 --> User Agent Class Initialized
INFO - 2018-07-12 18:05:30 --> Controller Class Initialized
INFO - 2018-07-12 18:05:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-12 18:05:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-12 18:05:30 --> Pixel_Model class loaded
INFO - 2018-07-12 18:05:30 --> Database Driver Class Initialized
INFO - 2018-07-12 18:05:30 --> Model "QuestionsModel" initialized
INFO - 2018-07-12 18:05:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-12 18:05:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-12 18:05:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-12 18:05:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-12 18:05:30 --> Final output sent to browser
DEBUG - 2018-07-12 18:05:30 --> Total execution time: 0.0336
INFO - 2018-07-12 18:06:28 --> Config Class Initialized
INFO - 2018-07-12 18:06:28 --> Hooks Class Initialized
DEBUG - 2018-07-12 18:06:28 --> UTF-8 Support Enabled
INFO - 2018-07-12 18:06:28 --> Utf8 Class Initialized
INFO - 2018-07-12 18:06:28 --> URI Class Initialized
INFO - 2018-07-12 18:06:28 --> Router Class Initialized
INFO - 2018-07-12 18:06:28 --> Output Class Initialized
INFO - 2018-07-12 18:06:28 --> Security Class Initialized
DEBUG - 2018-07-12 18:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-12 18:06:28 --> CSRF cookie sent
INFO - 2018-07-12 18:06:28 --> Input Class Initialized
INFO - 2018-07-12 18:06:28 --> Language Class Initialized
ERROR - 2018-07-12 18:06:28 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-12 18:29:47 --> Config Class Initialized
INFO - 2018-07-12 18:29:47 --> Hooks Class Initialized
DEBUG - 2018-07-12 18:29:47 --> UTF-8 Support Enabled
INFO - 2018-07-12 18:29:47 --> Utf8 Class Initialized
INFO - 2018-07-12 18:29:47 --> URI Class Initialized
DEBUG - 2018-07-12 18:29:47 --> No URI present. Default controller set.
INFO - 2018-07-12 18:29:47 --> Router Class Initialized
INFO - 2018-07-12 18:29:47 --> Output Class Initialized
INFO - 2018-07-12 18:29:47 --> Security Class Initialized
DEBUG - 2018-07-12 18:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-12 18:29:47 --> CSRF cookie sent
INFO - 2018-07-12 18:29:47 --> Input Class Initialized
INFO - 2018-07-12 18:29:47 --> Language Class Initialized
INFO - 2018-07-12 18:29:47 --> Loader Class Initialized
INFO - 2018-07-12 18:29:47 --> Helper loaded: url_helper
INFO - 2018-07-12 18:29:47 --> Helper loaded: form_helper
INFO - 2018-07-12 18:29:47 --> Helper loaded: language_helper
DEBUG - 2018-07-12 18:29:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-12 18:29:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-12 18:29:47 --> User Agent Class Initialized
INFO - 2018-07-12 18:29:47 --> Controller Class Initialized
INFO - 2018-07-12 18:29:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-12 18:29:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-12 18:29:47 --> Pixel_Model class loaded
INFO - 2018-07-12 18:29:47 --> Database Driver Class Initialized
INFO - 2018-07-12 18:29:47 --> Model "QuestionsModel" initialized
INFO - 2018-07-12 18:29:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-12 18:29:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-12 18:29:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-12 18:29:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-12 18:29:47 --> Final output sent to browser
DEBUG - 2018-07-12 18:29:47 --> Total execution time: 0.0318
INFO - 2018-07-12 20:47:40 --> Config Class Initialized
INFO - 2018-07-12 20:47:40 --> Hooks Class Initialized
DEBUG - 2018-07-12 20:47:40 --> UTF-8 Support Enabled
INFO - 2018-07-12 20:47:40 --> Utf8 Class Initialized
INFO - 2018-07-12 20:47:40 --> URI Class Initialized
DEBUG - 2018-07-12 20:47:40 --> No URI present. Default controller set.
INFO - 2018-07-12 20:47:40 --> Router Class Initialized
INFO - 2018-07-12 20:47:40 --> Output Class Initialized
INFO - 2018-07-12 20:47:40 --> Security Class Initialized
DEBUG - 2018-07-12 20:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-12 20:47:40 --> CSRF cookie sent
INFO - 2018-07-12 20:47:40 --> Input Class Initialized
INFO - 2018-07-12 20:47:40 --> Language Class Initialized
INFO - 2018-07-12 20:47:40 --> Loader Class Initialized
INFO - 2018-07-12 20:47:40 --> Helper loaded: url_helper
INFO - 2018-07-12 20:47:40 --> Helper loaded: form_helper
INFO - 2018-07-12 20:47:40 --> Helper loaded: language_helper
DEBUG - 2018-07-12 20:47:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-12 20:47:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-12 20:47:40 --> User Agent Class Initialized
INFO - 2018-07-12 20:47:40 --> Controller Class Initialized
INFO - 2018-07-12 20:47:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-12 20:47:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-12 20:47:40 --> Pixel_Model class loaded
INFO - 2018-07-12 20:47:40 --> Database Driver Class Initialized
INFO - 2018-07-12 20:47:40 --> Model "QuestionsModel" initialized
INFO - 2018-07-12 20:47:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-12 20:47:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-12 20:47:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-12 20:47:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-12 20:47:40 --> Final output sent to browser
DEBUG - 2018-07-12 20:47:40 --> Total execution time: 0.0336
INFO - 2018-07-12 21:03:10 --> Config Class Initialized
INFO - 2018-07-12 21:03:10 --> Hooks Class Initialized
DEBUG - 2018-07-12 21:03:10 --> UTF-8 Support Enabled
INFO - 2018-07-12 21:03:10 --> Utf8 Class Initialized
INFO - 2018-07-12 21:03:10 --> URI Class Initialized
INFO - 2018-07-12 21:03:10 --> Router Class Initialized
INFO - 2018-07-12 21:03:10 --> Output Class Initialized
INFO - 2018-07-12 21:03:10 --> Security Class Initialized
DEBUG - 2018-07-12 21:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-12 21:03:10 --> CSRF cookie sent
INFO - 2018-07-12 21:03:10 --> Input Class Initialized
INFO - 2018-07-12 21:03:10 --> Language Class Initialized
ERROR - 2018-07-12 21:03:10 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-12 21:03:14 --> Config Class Initialized
INFO - 2018-07-12 21:03:14 --> Hooks Class Initialized
DEBUG - 2018-07-12 21:03:14 --> UTF-8 Support Enabled
INFO - 2018-07-12 21:03:14 --> Utf8 Class Initialized
INFO - 2018-07-12 21:03:14 --> URI Class Initialized
INFO - 2018-07-12 21:03:14 --> Router Class Initialized
INFO - 2018-07-12 21:03:14 --> Output Class Initialized
INFO - 2018-07-12 21:03:14 --> Security Class Initialized
DEBUG - 2018-07-12 21:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-12 21:03:14 --> CSRF cookie sent
INFO - 2018-07-12 21:03:14 --> Input Class Initialized
INFO - 2018-07-12 21:03:14 --> Language Class Initialized
INFO - 2018-07-12 21:03:14 --> Loader Class Initialized
INFO - 2018-07-12 21:03:14 --> Helper loaded: url_helper
INFO - 2018-07-12 21:03:14 --> Helper loaded: form_helper
INFO - 2018-07-12 21:03:14 --> Helper loaded: language_helper
DEBUG - 2018-07-12 21:03:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-12 21:03:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-12 21:03:14 --> User Agent Class Initialized
INFO - 2018-07-12 21:03:14 --> Controller Class Initialized
INFO - 2018-07-12 21:03:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-12 21:03:14 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-12 21:03:14 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-12 21:03:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-12 21:03:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-12 21:03:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-12 21:03:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-12 21:03:14 --> Could not find the language line "req_email"
INFO - 2018-07-12 21:03:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-12 21:03:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-12 21:03:14 --> Final output sent to browser
DEBUG - 2018-07-12 21:03:14 --> Total execution time: 0.0311
INFO - 2018-07-12 23:46:51 --> Config Class Initialized
INFO - 2018-07-12 23:46:51 --> Hooks Class Initialized
DEBUG - 2018-07-12 23:46:51 --> UTF-8 Support Enabled
INFO - 2018-07-12 23:46:51 --> Utf8 Class Initialized
INFO - 2018-07-12 23:46:51 --> URI Class Initialized
INFO - 2018-07-12 23:46:51 --> Router Class Initialized
INFO - 2018-07-12 23:46:51 --> Output Class Initialized
INFO - 2018-07-12 23:46:51 --> Security Class Initialized
DEBUG - 2018-07-12 23:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-12 23:46:51 --> CSRF cookie sent
INFO - 2018-07-12 23:46:51 --> Input Class Initialized
INFO - 2018-07-12 23:46:51 --> Language Class Initialized
ERROR - 2018-07-12 23:46:51 --> 404 Page Not Found: Robotstxt/index

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-07-14 00:43:42 --> Config Class Initialized
INFO - 2018-07-14 00:43:42 --> Hooks Class Initialized
DEBUG - 2018-07-14 00:43:42 --> UTF-8 Support Enabled
INFO - 2018-07-14 00:43:42 --> Utf8 Class Initialized
INFO - 2018-07-14 00:43:42 --> URI Class Initialized
INFO - 2018-07-14 00:43:42 --> Router Class Initialized
INFO - 2018-07-14 00:43:42 --> Output Class Initialized
INFO - 2018-07-14 00:43:42 --> Security Class Initialized
DEBUG - 2018-07-14 00:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 00:43:42 --> CSRF cookie sent
INFO - 2018-07-14 00:43:42 --> Input Class Initialized
INFO - 2018-07-14 00:43:42 --> Language Class Initialized
ERROR - 2018-07-14 00:43:42 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-14 00:43:45 --> Config Class Initialized
INFO - 2018-07-14 00:43:45 --> Hooks Class Initialized
DEBUG - 2018-07-14 00:43:45 --> UTF-8 Support Enabled
INFO - 2018-07-14 00:43:45 --> Utf8 Class Initialized
INFO - 2018-07-14 00:43:45 --> URI Class Initialized
INFO - 2018-07-14 00:43:45 --> Router Class Initialized
INFO - 2018-07-14 00:43:45 --> Output Class Initialized
INFO - 2018-07-14 00:43:45 --> Security Class Initialized
DEBUG - 2018-07-14 00:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 00:43:45 --> CSRF cookie sent
INFO - 2018-07-14 00:43:45 --> Input Class Initialized
INFO - 2018-07-14 00:43:45 --> Language Class Initialized
INFO - 2018-07-14 00:43:45 --> Loader Class Initialized
INFO - 2018-07-14 00:43:45 --> Helper loaded: url_helper
INFO - 2018-07-14 00:43:45 --> Helper loaded: form_helper
INFO - 2018-07-14 00:43:45 --> Helper loaded: language_helper
DEBUG - 2018-07-14 00:43:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 00:43:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 00:43:45 --> User Agent Class Initialized
INFO - 2018-07-14 00:43:45 --> Controller Class Initialized
INFO - 2018-07-14 00:43:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-14 00:43:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-14 00:43:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-14 00:43:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-14 00:43:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-14 00:43:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-14 00:43:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-07-14 00:43:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-14 00:43:45 --> Final output sent to browser
DEBUG - 2018-07-14 00:43:45 --> Total execution time: 0.0221
INFO - 2018-07-14 00:49:45 --> Config Class Initialized
INFO - 2018-07-14 00:49:45 --> Hooks Class Initialized
DEBUG - 2018-07-14 00:49:45 --> UTF-8 Support Enabled
INFO - 2018-07-14 00:49:45 --> Utf8 Class Initialized
INFO - 2018-07-14 00:49:45 --> URI Class Initialized
DEBUG - 2018-07-14 00:49:45 --> No URI present. Default controller set.
INFO - 2018-07-14 00:49:45 --> Router Class Initialized
INFO - 2018-07-14 00:49:45 --> Output Class Initialized
INFO - 2018-07-14 00:49:45 --> Security Class Initialized
DEBUG - 2018-07-14 00:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 00:49:45 --> CSRF cookie sent
INFO - 2018-07-14 00:49:45 --> Input Class Initialized
INFO - 2018-07-14 00:49:45 --> Language Class Initialized
INFO - 2018-07-14 00:49:45 --> Loader Class Initialized
INFO - 2018-07-14 00:49:45 --> Helper loaded: url_helper
INFO - 2018-07-14 00:49:45 --> Helper loaded: form_helper
INFO - 2018-07-14 00:49:45 --> Helper loaded: language_helper
DEBUG - 2018-07-14 00:49:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 00:49:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 00:49:45 --> User Agent Class Initialized
INFO - 2018-07-14 00:49:45 --> Controller Class Initialized
INFO - 2018-07-14 00:49:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-14 00:49:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-14 00:49:45 --> Pixel_Model class loaded
INFO - 2018-07-14 00:49:45 --> Database Driver Class Initialized
INFO - 2018-07-14 00:49:45 --> Model "QuestionsModel" initialized
INFO - 2018-07-14 00:49:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-14 00:49:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-14 00:49:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-14 00:49:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-14 00:49:45 --> Final output sent to browser
DEBUG - 2018-07-14 00:49:45 --> Total execution time: 0.0365
INFO - 2018-07-14 00:49:50 --> Config Class Initialized
INFO - 2018-07-14 00:49:50 --> Hooks Class Initialized
DEBUG - 2018-07-14 00:49:50 --> UTF-8 Support Enabled
INFO - 2018-07-14 00:49:50 --> Utf8 Class Initialized
INFO - 2018-07-14 00:49:50 --> URI Class Initialized
INFO - 2018-07-14 00:49:50 --> Router Class Initialized
INFO - 2018-07-14 00:49:50 --> Output Class Initialized
INFO - 2018-07-14 00:49:50 --> Security Class Initialized
DEBUG - 2018-07-14 00:49:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 00:49:50 --> CSRF cookie sent
INFO - 2018-07-14 00:49:50 --> CSRF token verified
INFO - 2018-07-14 00:49:50 --> Input Class Initialized
INFO - 2018-07-14 00:49:50 --> Language Class Initialized
INFO - 2018-07-14 00:49:50 --> Loader Class Initialized
INFO - 2018-07-14 00:49:50 --> Helper loaded: url_helper
INFO - 2018-07-14 00:49:50 --> Helper loaded: form_helper
INFO - 2018-07-14 00:49:50 --> Helper loaded: language_helper
DEBUG - 2018-07-14 00:49:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 00:49:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 00:49:50 --> User Agent Class Initialized
INFO - 2018-07-14 00:49:50 --> Controller Class Initialized
INFO - 2018-07-14 00:49:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-14 00:49:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-14 00:49:50 --> Pixel_Model class loaded
INFO - 2018-07-14 00:49:50 --> Database Driver Class Initialized
INFO - 2018-07-14 00:49:50 --> Model "QuestionsModel" initialized
INFO - 2018-07-14 00:49:50 --> Config Class Initialized
INFO - 2018-07-14 00:49:50 --> Hooks Class Initialized
DEBUG - 2018-07-14 00:49:50 --> UTF-8 Support Enabled
INFO - 2018-07-14 00:49:50 --> Utf8 Class Initialized
INFO - 2018-07-14 00:49:50 --> URI Class Initialized
INFO - 2018-07-14 00:49:50 --> Router Class Initialized
INFO - 2018-07-14 00:49:50 --> Output Class Initialized
INFO - 2018-07-14 00:49:50 --> Security Class Initialized
DEBUG - 2018-07-14 00:49:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 00:49:50 --> CSRF cookie sent
INFO - 2018-07-14 00:49:50 --> Input Class Initialized
INFO - 2018-07-14 00:49:50 --> Language Class Initialized
INFO - 2018-07-14 00:49:50 --> Loader Class Initialized
INFO - 2018-07-14 00:49:50 --> Helper loaded: url_helper
INFO - 2018-07-14 00:49:50 --> Helper loaded: form_helper
INFO - 2018-07-14 00:49:50 --> Helper loaded: language_helper
DEBUG - 2018-07-14 00:49:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 00:49:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 00:49:50 --> User Agent Class Initialized
INFO - 2018-07-14 00:49:50 --> Controller Class Initialized
INFO - 2018-07-14 00:49:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-14 00:49:50 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-14 00:49:50 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-14 00:49:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-14 00:49:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-14 00:49:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-14 00:49:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-14 00:49:50 --> Could not find the language line "req_email"
INFO - 2018-07-14 00:49:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-14 00:49:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-14 00:49:50 --> Final output sent to browser
DEBUG - 2018-07-14 00:49:50 --> Total execution time: 0.0227
INFO - 2018-07-14 01:53:44 --> Config Class Initialized
INFO - 2018-07-14 01:53:44 --> Hooks Class Initialized
DEBUG - 2018-07-14 01:53:44 --> UTF-8 Support Enabled
INFO - 2018-07-14 01:53:44 --> Utf8 Class Initialized
INFO - 2018-07-14 01:53:44 --> URI Class Initialized
DEBUG - 2018-07-14 01:53:44 --> No URI present. Default controller set.
INFO - 2018-07-14 01:53:44 --> Router Class Initialized
INFO - 2018-07-14 01:53:44 --> Output Class Initialized
INFO - 2018-07-14 01:53:44 --> Security Class Initialized
DEBUG - 2018-07-14 01:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 01:53:44 --> CSRF cookie sent
INFO - 2018-07-14 01:53:44 --> Input Class Initialized
INFO - 2018-07-14 01:53:44 --> Language Class Initialized
INFO - 2018-07-14 01:53:44 --> Loader Class Initialized
INFO - 2018-07-14 01:53:44 --> Helper loaded: url_helper
INFO - 2018-07-14 01:53:44 --> Helper loaded: form_helper
INFO - 2018-07-14 01:53:44 --> Helper loaded: language_helper
DEBUG - 2018-07-14 01:53:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 01:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 01:53:44 --> User Agent Class Initialized
INFO - 2018-07-14 01:53:44 --> Controller Class Initialized
INFO - 2018-07-14 01:53:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-14 01:53:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-14 01:53:44 --> Pixel_Model class loaded
INFO - 2018-07-14 01:53:44 --> Database Driver Class Initialized
INFO - 2018-07-14 01:53:44 --> Model "QuestionsModel" initialized
INFO - 2018-07-14 01:53:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-14 01:53:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-14 01:53:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-14 01:53:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-14 01:53:44 --> Final output sent to browser
DEBUG - 2018-07-14 01:53:44 --> Total execution time: 0.0310
INFO - 2018-07-14 09:52:13 --> Config Class Initialized
INFO - 2018-07-14 09:52:13 --> Hooks Class Initialized
DEBUG - 2018-07-14 09:52:13 --> UTF-8 Support Enabled
INFO - 2018-07-14 09:52:13 --> Utf8 Class Initialized
INFO - 2018-07-14 09:52:13 --> URI Class Initialized
DEBUG - 2018-07-14 09:52:13 --> No URI present. Default controller set.
INFO - 2018-07-14 09:52:13 --> Router Class Initialized
INFO - 2018-07-14 09:52:13 --> Output Class Initialized
INFO - 2018-07-14 09:52:13 --> Security Class Initialized
DEBUG - 2018-07-14 09:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 09:52:13 --> CSRF cookie sent
INFO - 2018-07-14 09:52:13 --> Input Class Initialized
INFO - 2018-07-14 09:52:13 --> Language Class Initialized
INFO - 2018-07-14 09:52:13 --> Loader Class Initialized
INFO - 2018-07-14 09:52:13 --> Helper loaded: url_helper
INFO - 2018-07-14 09:52:13 --> Helper loaded: form_helper
INFO - 2018-07-14 09:52:13 --> Helper loaded: language_helper
DEBUG - 2018-07-14 09:52:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 09:52:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 09:52:13 --> User Agent Class Initialized
INFO - 2018-07-14 09:52:13 --> Controller Class Initialized
INFO - 2018-07-14 09:52:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-14 09:52:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-14 09:52:13 --> Pixel_Model class loaded
INFO - 2018-07-14 09:52:13 --> Database Driver Class Initialized
INFO - 2018-07-14 09:52:13 --> Model "QuestionsModel" initialized
INFO - 2018-07-14 09:52:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-14 09:52:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-14 09:52:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-14 09:52:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-14 09:52:13 --> Final output sent to browser
DEBUG - 2018-07-14 09:52:13 --> Total execution time: 0.0339
INFO - 2018-07-14 13:14:04 --> Config Class Initialized
INFO - 2018-07-14 13:14:04 --> Hooks Class Initialized
DEBUG - 2018-07-14 13:14:04 --> UTF-8 Support Enabled
INFO - 2018-07-14 13:14:04 --> Utf8 Class Initialized
INFO - 2018-07-14 13:14:04 --> URI Class Initialized
INFO - 2018-07-14 13:14:04 --> Router Class Initialized
INFO - 2018-07-14 13:14:04 --> Output Class Initialized
INFO - 2018-07-14 13:14:04 --> Security Class Initialized
DEBUG - 2018-07-14 13:14:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 13:14:04 --> CSRF cookie sent
INFO - 2018-07-14 13:14:04 --> Input Class Initialized
INFO - 2018-07-14 13:14:04 --> Language Class Initialized
ERROR - 2018-07-14 13:14:04 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-14 13:14:07 --> Config Class Initialized
INFO - 2018-07-14 13:14:07 --> Hooks Class Initialized
DEBUG - 2018-07-14 13:14:07 --> UTF-8 Support Enabled
INFO - 2018-07-14 13:14:07 --> Utf8 Class Initialized
INFO - 2018-07-14 13:14:07 --> URI Class Initialized
INFO - 2018-07-14 13:14:07 --> Router Class Initialized
INFO - 2018-07-14 13:14:07 --> Output Class Initialized
INFO - 2018-07-14 13:14:07 --> Security Class Initialized
DEBUG - 2018-07-14 13:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 13:14:07 --> CSRF cookie sent
INFO - 2018-07-14 13:14:07 --> Input Class Initialized
INFO - 2018-07-14 13:14:07 --> Language Class Initialized
INFO - 2018-07-14 13:14:07 --> Loader Class Initialized
INFO - 2018-07-14 13:14:07 --> Helper loaded: url_helper
INFO - 2018-07-14 13:14:07 --> Helper loaded: form_helper
INFO - 2018-07-14 13:14:07 --> Helper loaded: language_helper
DEBUG - 2018-07-14 13:14:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 13:14:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 13:14:07 --> User Agent Class Initialized
INFO - 2018-07-14 13:14:07 --> Controller Class Initialized
INFO - 2018-07-14 13:14:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-14 13:14:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-14 13:14:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-14 13:14:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-14 13:14:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-14 13:14:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-14 13:14:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-07-14 13:14:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-14 13:14:07 --> Final output sent to browser
DEBUG - 2018-07-14 13:14:07 --> Total execution time: 0.0212
INFO - 2018-07-14 13:51:10 --> Config Class Initialized
INFO - 2018-07-14 13:51:10 --> Hooks Class Initialized
DEBUG - 2018-07-14 13:51:10 --> UTF-8 Support Enabled
INFO - 2018-07-14 13:51:10 --> Utf8 Class Initialized
INFO - 2018-07-14 13:51:10 --> URI Class Initialized
INFO - 2018-07-14 13:51:10 --> Router Class Initialized
INFO - 2018-07-14 13:51:10 --> Output Class Initialized
INFO - 2018-07-14 13:51:10 --> Security Class Initialized
DEBUG - 2018-07-14 13:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 13:51:10 --> CSRF cookie sent
INFO - 2018-07-14 13:51:10 --> Input Class Initialized
INFO - 2018-07-14 13:51:10 --> Language Class Initialized
ERROR - 2018-07-14 13:51:10 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-14 13:51:10 --> Config Class Initialized
INFO - 2018-07-14 13:51:10 --> Hooks Class Initialized
DEBUG - 2018-07-14 13:51:10 --> UTF-8 Support Enabled
INFO - 2018-07-14 13:51:10 --> Utf8 Class Initialized
INFO - 2018-07-14 13:51:10 --> URI Class Initialized
INFO - 2018-07-14 13:51:10 --> Router Class Initialized
INFO - 2018-07-14 13:51:10 --> Output Class Initialized
INFO - 2018-07-14 13:51:10 --> Security Class Initialized
DEBUG - 2018-07-14 13:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 13:51:10 --> CSRF cookie sent
INFO - 2018-07-14 13:51:10 --> Input Class Initialized
INFO - 2018-07-14 13:51:10 --> Language Class Initialized
ERROR - 2018-07-14 13:51:10 --> 404 Page Not Found: Well-known/assetlinks.json
INFO - 2018-07-14 14:41:18 --> Config Class Initialized
INFO - 2018-07-14 14:41:18 --> Hooks Class Initialized
DEBUG - 2018-07-14 14:41:18 --> UTF-8 Support Enabled
INFO - 2018-07-14 14:41:18 --> Utf8 Class Initialized
INFO - 2018-07-14 14:41:18 --> URI Class Initialized
DEBUG - 2018-07-14 14:41:18 --> No URI present. Default controller set.
INFO - 2018-07-14 14:41:18 --> Router Class Initialized
INFO - 2018-07-14 14:41:18 --> Output Class Initialized
INFO - 2018-07-14 14:41:18 --> Security Class Initialized
DEBUG - 2018-07-14 14:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 14:41:18 --> CSRF cookie sent
INFO - 2018-07-14 14:41:18 --> Input Class Initialized
INFO - 2018-07-14 14:41:18 --> Language Class Initialized
INFO - 2018-07-14 14:41:18 --> Loader Class Initialized
INFO - 2018-07-14 14:41:18 --> Helper loaded: url_helper
INFO - 2018-07-14 14:41:18 --> Helper loaded: form_helper
INFO - 2018-07-14 14:41:18 --> Helper loaded: language_helper
DEBUG - 2018-07-14 14:41:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 14:41:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 14:41:18 --> User Agent Class Initialized
INFO - 2018-07-14 14:41:18 --> Controller Class Initialized
INFO - 2018-07-14 14:41:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-14 14:41:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-14 14:41:18 --> Pixel_Model class loaded
INFO - 2018-07-14 14:41:18 --> Database Driver Class Initialized
INFO - 2018-07-14 14:41:18 --> Model "QuestionsModel" initialized
INFO - 2018-07-14 14:41:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-14 14:41:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-14 14:41:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-14 14:41:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-14 14:41:18 --> Final output sent to browser
DEBUG - 2018-07-14 14:41:18 --> Total execution time: 0.0325
INFO - 2018-07-14 16:02:21 --> Config Class Initialized
INFO - 2018-07-14 16:02:21 --> Hooks Class Initialized
DEBUG - 2018-07-14 16:02:21 --> UTF-8 Support Enabled
INFO - 2018-07-14 16:02:21 --> Utf8 Class Initialized
INFO - 2018-07-14 16:02:21 --> URI Class Initialized
INFO - 2018-07-14 16:02:21 --> Router Class Initialized
INFO - 2018-07-14 16:02:21 --> Output Class Initialized
INFO - 2018-07-14 16:02:21 --> Security Class Initialized
DEBUG - 2018-07-14 16:02:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 16:02:21 --> CSRF cookie sent
INFO - 2018-07-14 16:02:21 --> Input Class Initialized
INFO - 2018-07-14 16:02:21 --> Language Class Initialized
ERROR - 2018-07-14 16:02:21 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-14 16:02:24 --> Config Class Initialized
INFO - 2018-07-14 16:02:24 --> Hooks Class Initialized
DEBUG - 2018-07-14 16:02:24 --> UTF-8 Support Enabled
INFO - 2018-07-14 16:02:24 --> Utf8 Class Initialized
INFO - 2018-07-14 16:02:24 --> URI Class Initialized
INFO - 2018-07-14 16:02:24 --> Router Class Initialized
INFO - 2018-07-14 16:02:24 --> Output Class Initialized
INFO - 2018-07-14 16:02:24 --> Security Class Initialized
DEBUG - 2018-07-14 16:02:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 16:02:24 --> CSRF cookie sent
INFO - 2018-07-14 16:02:24 --> Input Class Initialized
INFO - 2018-07-14 16:02:24 --> Language Class Initialized
ERROR - 2018-07-14 16:02:24 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-14 16:02:24 --> Config Class Initialized
INFO - 2018-07-14 16:02:24 --> Hooks Class Initialized
DEBUG - 2018-07-14 16:02:24 --> UTF-8 Support Enabled
INFO - 2018-07-14 16:02:24 --> Utf8 Class Initialized
INFO - 2018-07-14 16:02:24 --> URI Class Initialized
INFO - 2018-07-14 16:02:24 --> Router Class Initialized
INFO - 2018-07-14 16:02:24 --> Output Class Initialized
INFO - 2018-07-14 16:02:24 --> Security Class Initialized
DEBUG - 2018-07-14 16:02:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 16:02:24 --> CSRF cookie sent
INFO - 2018-07-14 16:02:24 --> Input Class Initialized
INFO - 2018-07-14 16:02:24 --> Language Class Initialized
INFO - 2018-07-14 16:02:24 --> Loader Class Initialized
INFO - 2018-07-14 16:02:24 --> Helper loaded: url_helper
INFO - 2018-07-14 16:02:24 --> Helper loaded: form_helper
INFO - 2018-07-14 16:02:24 --> Helper loaded: language_helper
DEBUG - 2018-07-14 16:02:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 16:02:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 16:02:24 --> Config Class Initialized
INFO - 2018-07-14 16:02:24 --> User Agent Class Initialized
INFO - 2018-07-14 16:02:24 --> Hooks Class Initialized
DEBUG - 2018-07-14 16:02:24 --> UTF-8 Support Enabled
INFO - 2018-07-14 16:02:24 --> Utf8 Class Initialized
INFO - 2018-07-14 16:02:24 --> Controller Class Initialized
INFO - 2018-07-14 16:02:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-14 16:02:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-14 16:02:24 --> URI Class Initialized
DEBUG - 2018-07-14 16:02:24 --> No URI present. Default controller set.
INFO - 2018-07-14 16:02:24 --> Router Class Initialized
INFO - 2018-07-14 16:02:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-14 16:02:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-14 16:02:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-14 16:02:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-14 16:02:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/preview.php
INFO - 2018-07-14 16:02:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-14 16:02:24 --> Output Class Initialized
INFO - 2018-07-14 16:02:24 --> Final output sent to browser
DEBUG - 2018-07-14 16:02:24 --> Total execution time: 0.0263
INFO - 2018-07-14 16:02:24 --> Security Class Initialized
DEBUG - 2018-07-14 16:02:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 16:02:24 --> CSRF cookie sent
INFO - 2018-07-14 16:02:24 --> Input Class Initialized
INFO - 2018-07-14 16:02:24 --> Language Class Initialized
INFO - 2018-07-14 16:02:24 --> Loader Class Initialized
INFO - 2018-07-14 16:02:24 --> Helper loaded: url_helper
INFO - 2018-07-14 16:02:24 --> Helper loaded: form_helper
INFO - 2018-07-14 16:02:24 --> Helper loaded: language_helper
DEBUG - 2018-07-14 16:02:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 16:02:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 16:02:24 --> User Agent Class Initialized
INFO - 2018-07-14 16:02:24 --> Controller Class Initialized
INFO - 2018-07-14 16:02:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-14 16:02:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-14 16:02:24 --> Pixel_Model class loaded
INFO - 2018-07-14 16:02:24 --> Database Driver Class Initialized
INFO - 2018-07-14 16:02:24 --> Model "QuestionsModel" initialized
INFO - 2018-07-14 16:02:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-14 16:02:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-14 16:02:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-14 16:02:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-14 16:02:24 --> Final output sent to browser
DEBUG - 2018-07-14 16:02:24 --> Total execution time: 0.0298
INFO - 2018-07-14 16:34:25 --> Config Class Initialized
INFO - 2018-07-14 16:34:25 --> Hooks Class Initialized
DEBUG - 2018-07-14 16:34:25 --> UTF-8 Support Enabled
INFO - 2018-07-14 16:34:25 --> Utf8 Class Initialized
INFO - 2018-07-14 16:34:25 --> URI Class Initialized
DEBUG - 2018-07-14 16:34:25 --> No URI present. Default controller set.
INFO - 2018-07-14 16:34:25 --> Router Class Initialized
INFO - 2018-07-14 16:34:25 --> Output Class Initialized
INFO - 2018-07-14 16:34:25 --> Security Class Initialized
DEBUG - 2018-07-14 16:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 16:34:25 --> CSRF cookie sent
INFO - 2018-07-14 16:34:25 --> Input Class Initialized
INFO - 2018-07-14 16:34:25 --> Language Class Initialized
INFO - 2018-07-14 16:34:25 --> Loader Class Initialized
INFO - 2018-07-14 16:34:25 --> Helper loaded: url_helper
INFO - 2018-07-14 16:34:25 --> Helper loaded: form_helper
INFO - 2018-07-14 16:34:25 --> Helper loaded: language_helper
DEBUG - 2018-07-14 16:34:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 16:34:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 16:34:25 --> User Agent Class Initialized
INFO - 2018-07-14 16:34:25 --> Controller Class Initialized
INFO - 2018-07-14 16:34:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-14 16:34:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-14 16:34:25 --> Pixel_Model class loaded
INFO - 2018-07-14 16:34:25 --> Database Driver Class Initialized
INFO - 2018-07-14 16:34:25 --> Model "QuestionsModel" initialized
INFO - 2018-07-14 16:34:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-14 16:34:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-14 16:34:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-14 16:34:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-14 16:34:25 --> Final output sent to browser
DEBUG - 2018-07-14 16:34:25 --> Total execution time: 0.0342
INFO - 2018-07-14 16:34:25 --> Config Class Initialized
INFO - 2018-07-14 16:34:25 --> Hooks Class Initialized
DEBUG - 2018-07-14 16:34:25 --> UTF-8 Support Enabled
INFO - 2018-07-14 16:34:25 --> Utf8 Class Initialized
INFO - 2018-07-14 16:34:25 --> URI Class Initialized
DEBUG - 2018-07-14 16:34:25 --> No URI present. Default controller set.
INFO - 2018-07-14 16:34:25 --> Router Class Initialized
INFO - 2018-07-14 16:34:25 --> Output Class Initialized
INFO - 2018-07-14 16:34:25 --> Security Class Initialized
DEBUG - 2018-07-14 16:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 16:34:25 --> CSRF cookie sent
INFO - 2018-07-14 16:34:25 --> Input Class Initialized
INFO - 2018-07-14 16:34:25 --> Language Class Initialized
INFO - 2018-07-14 16:34:25 --> Loader Class Initialized
INFO - 2018-07-14 16:34:25 --> Helper loaded: url_helper
INFO - 2018-07-14 16:34:25 --> Helper loaded: form_helper
INFO - 2018-07-14 16:34:25 --> Helper loaded: language_helper
DEBUG - 2018-07-14 16:34:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 16:34:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 16:34:25 --> User Agent Class Initialized
INFO - 2018-07-14 16:34:25 --> Controller Class Initialized
INFO - 2018-07-14 16:34:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-14 16:34:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-14 16:34:25 --> Pixel_Model class loaded
INFO - 2018-07-14 16:34:25 --> Database Driver Class Initialized
INFO - 2018-07-14 16:34:25 --> Model "QuestionsModel" initialized
INFO - 2018-07-14 16:34:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-14 16:34:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-14 16:34:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-14 16:34:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-14 16:34:25 --> Final output sent to browser
DEBUG - 2018-07-14 16:34:25 --> Total execution time: 0.0356
INFO - 2018-07-14 16:34:26 --> Config Class Initialized
INFO - 2018-07-14 16:34:26 --> Hooks Class Initialized
DEBUG - 2018-07-14 16:34:26 --> UTF-8 Support Enabled
INFO - 2018-07-14 16:34:26 --> Utf8 Class Initialized
INFO - 2018-07-14 16:34:26 --> URI Class Initialized
DEBUG - 2018-07-14 16:34:26 --> No URI present. Default controller set.
INFO - 2018-07-14 16:34:26 --> Router Class Initialized
INFO - 2018-07-14 16:34:26 --> Output Class Initialized
INFO - 2018-07-14 16:34:26 --> Security Class Initialized
DEBUG - 2018-07-14 16:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 16:34:26 --> CSRF cookie sent
INFO - 2018-07-14 16:34:26 --> Input Class Initialized
INFO - 2018-07-14 16:34:26 --> Language Class Initialized
INFO - 2018-07-14 16:34:26 --> Loader Class Initialized
INFO - 2018-07-14 16:34:26 --> Helper loaded: url_helper
INFO - 2018-07-14 16:34:26 --> Helper loaded: form_helper
INFO - 2018-07-14 16:34:26 --> Helper loaded: language_helper
DEBUG - 2018-07-14 16:34:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 16:34:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 16:34:26 --> User Agent Class Initialized
INFO - 2018-07-14 16:34:26 --> Controller Class Initialized
INFO - 2018-07-14 16:34:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-14 16:34:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-14 16:34:26 --> Pixel_Model class loaded
INFO - 2018-07-14 16:34:26 --> Database Driver Class Initialized
INFO - 2018-07-14 16:34:26 --> Model "QuestionsModel" initialized
INFO - 2018-07-14 16:34:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-14 16:34:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-14 16:34:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-14 16:34:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-14 16:34:26 --> Final output sent to browser
DEBUG - 2018-07-14 16:34:26 --> Total execution time: 0.0331
INFO - 2018-07-14 16:34:27 --> Config Class Initialized
INFO - 2018-07-14 16:34:27 --> Hooks Class Initialized
DEBUG - 2018-07-14 16:34:27 --> UTF-8 Support Enabled
INFO - 2018-07-14 16:34:27 --> Utf8 Class Initialized
INFO - 2018-07-14 16:34:27 --> URI Class Initialized
INFO - 2018-07-14 16:34:27 --> Router Class Initialized
INFO - 2018-07-14 16:34:27 --> Output Class Initialized
INFO - 2018-07-14 16:34:27 --> Security Class Initialized
DEBUG - 2018-07-14 16:34:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 16:34:27 --> CSRF cookie sent
INFO - 2018-07-14 16:34:27 --> Input Class Initialized
INFO - 2018-07-14 16:34:27 --> Language Class Initialized
ERROR - 2018-07-14 16:34:27 --> 404 Page Not Found: 405shtml/index
INFO - 2018-07-14 16:34:34 --> Config Class Initialized
INFO - 2018-07-14 16:34:34 --> Hooks Class Initialized
DEBUG - 2018-07-14 16:34:34 --> UTF-8 Support Enabled
INFO - 2018-07-14 16:34:34 --> Utf8 Class Initialized
INFO - 2018-07-14 16:34:34 --> URI Class Initialized
DEBUG - 2018-07-14 16:34:34 --> No URI present. Default controller set.
INFO - 2018-07-14 16:34:34 --> Router Class Initialized
INFO - 2018-07-14 16:34:34 --> Output Class Initialized
INFO - 2018-07-14 16:34:34 --> Security Class Initialized
DEBUG - 2018-07-14 16:34:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 16:34:34 --> CSRF cookie sent
INFO - 2018-07-14 16:34:34 --> Input Class Initialized
INFO - 2018-07-14 16:34:34 --> Language Class Initialized
INFO - 2018-07-14 16:34:34 --> Loader Class Initialized
INFO - 2018-07-14 16:34:34 --> Helper loaded: url_helper
INFO - 2018-07-14 16:34:34 --> Helper loaded: form_helper
INFO - 2018-07-14 16:34:34 --> Helper loaded: language_helper
DEBUG - 2018-07-14 16:34:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 16:34:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 16:34:34 --> User Agent Class Initialized
INFO - 2018-07-14 16:34:34 --> Controller Class Initialized
INFO - 2018-07-14 16:34:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-14 16:34:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-14 16:34:34 --> Pixel_Model class loaded
INFO - 2018-07-14 16:34:34 --> Database Driver Class Initialized
INFO - 2018-07-14 16:34:34 --> Model "QuestionsModel" initialized
INFO - 2018-07-14 16:34:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-14 16:34:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-14 16:34:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-14 16:34:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-14 16:34:34 --> Final output sent to browser
DEBUG - 2018-07-14 16:34:34 --> Total execution time: 0.0347
INFO - 2018-07-14 16:34:34 --> Config Class Initialized
INFO - 2018-07-14 16:34:34 --> Hooks Class Initialized
DEBUG - 2018-07-14 16:34:34 --> UTF-8 Support Enabled
INFO - 2018-07-14 16:34:34 --> Utf8 Class Initialized
INFO - 2018-07-14 16:34:34 --> URI Class Initialized
INFO - 2018-07-14 16:34:34 --> Router Class Initialized
INFO - 2018-07-14 16:34:34 --> Output Class Initialized
INFO - 2018-07-14 16:34:34 --> Security Class Initialized
DEBUG - 2018-07-14 16:34:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 16:34:34 --> CSRF cookie sent
INFO - 2018-07-14 16:34:34 --> Input Class Initialized
INFO - 2018-07-14 16:34:34 --> Language Class Initialized
ERROR - 2018-07-14 16:34:34 --> 404 Page Not Found: 404testpage4525d2fdc/index
INFO - 2018-07-14 16:34:35 --> Config Class Initialized
INFO - 2018-07-14 16:34:35 --> Hooks Class Initialized
DEBUG - 2018-07-14 16:34:35 --> UTF-8 Support Enabled
INFO - 2018-07-14 16:34:35 --> Utf8 Class Initialized
INFO - 2018-07-14 16:34:35 --> URI Class Initialized
INFO - 2018-07-14 16:34:35 --> Router Class Initialized
INFO - 2018-07-14 16:34:35 --> Output Class Initialized
INFO - 2018-07-14 16:34:35 --> Security Class Initialized
DEBUG - 2018-07-14 16:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 16:34:35 --> CSRF cookie sent
INFO - 2018-07-14 16:34:35 --> Input Class Initialized
INFO - 2018-07-14 16:34:35 --> Language Class Initialized
ERROR - 2018-07-14 16:34:35 --> 404 Page Not Found: 404javascriptjs/index
INFO - 2018-07-14 16:34:35 --> Config Class Initialized
INFO - 2018-07-14 16:34:35 --> Hooks Class Initialized
DEBUG - 2018-07-14 16:34:35 --> UTF-8 Support Enabled
INFO - 2018-07-14 16:34:35 --> Utf8 Class Initialized
INFO - 2018-07-14 16:34:35 --> URI Class Initialized
INFO - 2018-07-14 16:34:35 --> Router Class Initialized
INFO - 2018-07-14 16:34:35 --> Output Class Initialized
INFO - 2018-07-14 16:34:35 --> Security Class Initialized
DEBUG - 2018-07-14 16:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 16:34:35 --> CSRF cookie sent
INFO - 2018-07-14 16:34:35 --> Input Class Initialized
INFO - 2018-07-14 16:34:35 --> Language Class Initialized
INFO - 2018-07-14 16:34:35 --> Loader Class Initialized
INFO - 2018-07-14 16:34:35 --> Helper loaded: url_helper
INFO - 2018-07-14 16:34:35 --> Helper loaded: form_helper
INFO - 2018-07-14 16:34:35 --> Helper loaded: language_helper
DEBUG - 2018-07-14 16:34:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 16:34:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 16:34:35 --> User Agent Class Initialized
INFO - 2018-07-14 16:34:35 --> Controller Class Initialized
INFO - 2018-07-14 16:34:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-14 16:34:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-14 16:34:35 --> Pixel_Model class loaded
INFO - 2018-07-14 16:34:35 --> Database Driver Class Initialized
INFO - 2018-07-14 16:34:35 --> Model "QuestionsModel" initialized
INFO - 2018-07-14 16:34:35 --> Config Class Initialized
INFO - 2018-07-14 16:34:35 --> Hooks Class Initialized
DEBUG - 2018-07-14 16:34:35 --> UTF-8 Support Enabled
INFO - 2018-07-14 16:34:35 --> Utf8 Class Initialized
INFO - 2018-07-14 16:34:35 --> URI Class Initialized
INFO - 2018-07-14 16:34:35 --> Router Class Initialized
INFO - 2018-07-14 16:34:35 --> Output Class Initialized
INFO - 2018-07-14 16:34:35 --> Security Class Initialized
DEBUG - 2018-07-14 16:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 16:34:35 --> CSRF cookie sent
INFO - 2018-07-14 16:34:35 --> Input Class Initialized
INFO - 2018-07-14 16:34:35 --> Language Class Initialized
INFO - 2018-07-14 16:34:35 --> Loader Class Initialized
INFO - 2018-07-14 16:34:35 --> Helper loaded: url_helper
INFO - 2018-07-14 16:34:35 --> Helper loaded: form_helper
INFO - 2018-07-14 16:34:35 --> Helper loaded: language_helper
DEBUG - 2018-07-14 16:34:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 16:34:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 16:34:35 --> User Agent Class Initialized
INFO - 2018-07-14 16:34:35 --> Controller Class Initialized
INFO - 2018-07-14 16:34:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-14 16:34:35 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-14 16:34:35 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-14 16:34:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-14 16:34:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-14 16:34:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-14 16:34:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-14 16:34:35 --> Could not find the language line "req_email"
INFO - 2018-07-14 16:34:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-14 16:34:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-14 16:34:35 --> Final output sent to browser
DEBUG - 2018-07-14 16:34:35 --> Total execution time: 0.0261
INFO - 2018-07-14 16:34:35 --> Config Class Initialized
INFO - 2018-07-14 16:34:35 --> Hooks Class Initialized
DEBUG - 2018-07-14 16:34:35 --> UTF-8 Support Enabled
INFO - 2018-07-14 16:34:35 --> Utf8 Class Initialized
INFO - 2018-07-14 16:34:35 --> URI Class Initialized
INFO - 2018-07-14 16:34:35 --> Router Class Initialized
INFO - 2018-07-14 16:34:35 --> Output Class Initialized
INFO - 2018-07-14 16:34:35 --> Security Class Initialized
DEBUG - 2018-07-14 16:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 16:34:35 --> CSRF cookie sent
INFO - 2018-07-14 16:34:35 --> Input Class Initialized
INFO - 2018-07-14 16:34:35 --> Language Class Initialized
INFO - 2018-07-14 16:34:35 --> Loader Class Initialized
INFO - 2018-07-14 16:34:35 --> Helper loaded: url_helper
INFO - 2018-07-14 16:34:35 --> Helper loaded: form_helper
INFO - 2018-07-14 16:34:35 --> Helper loaded: language_helper
DEBUG - 2018-07-14 16:34:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 16:34:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 16:34:35 --> User Agent Class Initialized
INFO - 2018-07-14 16:34:35 --> Controller Class Initialized
INFO - 2018-07-14 16:34:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-14 16:34:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-14 16:34:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-14 16:34:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-14 16:34:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-14 16:34:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-14 16:34:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-07-14 16:34:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-14 16:34:35 --> Final output sent to browser
DEBUG - 2018-07-14 16:34:35 --> Total execution time: 0.0223
INFO - 2018-07-14 16:34:36 --> Config Class Initialized
INFO - 2018-07-14 16:34:36 --> Hooks Class Initialized
DEBUG - 2018-07-14 16:34:36 --> UTF-8 Support Enabled
INFO - 2018-07-14 16:34:36 --> Utf8 Class Initialized
INFO - 2018-07-14 16:34:36 --> URI Class Initialized
INFO - 2018-07-14 16:34:36 --> Router Class Initialized
INFO - 2018-07-14 16:34:36 --> Output Class Initialized
INFO - 2018-07-14 16:34:36 --> Security Class Initialized
DEBUG - 2018-07-14 16:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 16:34:36 --> CSRF cookie sent
INFO - 2018-07-14 16:34:36 --> Input Class Initialized
INFO - 2018-07-14 16:34:36 --> Language Class Initialized
INFO - 2018-07-14 16:34:36 --> Loader Class Initialized
INFO - 2018-07-14 16:34:36 --> Helper loaded: url_helper
INFO - 2018-07-14 16:34:36 --> Helper loaded: form_helper
INFO - 2018-07-14 16:34:36 --> Helper loaded: language_helper
DEBUG - 2018-07-14 16:34:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 16:34:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 16:34:36 --> User Agent Class Initialized
INFO - 2018-07-14 16:34:36 --> Controller Class Initialized
INFO - 2018-07-14 16:34:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-14 16:34:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-14 16:34:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-14 16:34:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-14 16:34:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-14 16:34:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-14 16:34:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-07-14 16:34:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-14 16:34:36 --> Final output sent to browser
DEBUG - 2018-07-14 16:34:36 --> Total execution time: 0.0214
INFO - 2018-07-14 16:34:36 --> Config Class Initialized
INFO - 2018-07-14 16:34:36 --> Hooks Class Initialized
DEBUG - 2018-07-14 16:34:36 --> UTF-8 Support Enabled
INFO - 2018-07-14 16:34:36 --> Utf8 Class Initialized
INFO - 2018-07-14 16:34:36 --> URI Class Initialized
INFO - 2018-07-14 16:34:36 --> Router Class Initialized
INFO - 2018-07-14 16:34:36 --> Output Class Initialized
INFO - 2018-07-14 16:34:36 --> Security Class Initialized
DEBUG - 2018-07-14 16:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 16:34:36 --> CSRF cookie sent
INFO - 2018-07-14 16:34:36 --> Input Class Initialized
INFO - 2018-07-14 16:34:36 --> Language Class Initialized
INFO - 2018-07-14 16:34:36 --> Loader Class Initialized
INFO - 2018-07-14 16:34:36 --> Helper loaded: url_helper
INFO - 2018-07-14 16:34:36 --> Helper loaded: form_helper
INFO - 2018-07-14 16:34:36 --> Helper loaded: language_helper
DEBUG - 2018-07-14 16:34:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 16:34:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 16:34:36 --> User Agent Class Initialized
INFO - 2018-07-14 16:34:36 --> Controller Class Initialized
INFO - 2018-07-14 16:34:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-14 16:34:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-14 16:34:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-14 16:34:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-14 16:34:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-14 16:34:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-14 16:34:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-07-14 16:34:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-14 16:34:36 --> Final output sent to browser
DEBUG - 2018-07-14 16:34:36 --> Total execution time: 0.0229
INFO - 2018-07-14 16:34:36 --> Config Class Initialized
INFO - 2018-07-14 16:34:36 --> Hooks Class Initialized
DEBUG - 2018-07-14 16:34:36 --> UTF-8 Support Enabled
INFO - 2018-07-14 16:34:36 --> Utf8 Class Initialized
INFO - 2018-07-14 16:34:36 --> URI Class Initialized
INFO - 2018-07-14 16:34:36 --> Router Class Initialized
INFO - 2018-07-14 16:34:36 --> Output Class Initialized
INFO - 2018-07-14 16:34:36 --> Security Class Initialized
DEBUG - 2018-07-14 16:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 16:34:36 --> CSRF cookie sent
INFO - 2018-07-14 16:34:36 --> Input Class Initialized
INFO - 2018-07-14 16:34:36 --> Language Class Initialized
INFO - 2018-07-14 16:34:36 --> Loader Class Initialized
INFO - 2018-07-14 16:34:36 --> Helper loaded: url_helper
INFO - 2018-07-14 16:34:36 --> Helper loaded: form_helper
INFO - 2018-07-14 16:34:36 --> Helper loaded: language_helper
DEBUG - 2018-07-14 16:34:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 16:34:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 16:34:36 --> User Agent Class Initialized
INFO - 2018-07-14 16:34:36 --> Controller Class Initialized
INFO - 2018-07-14 16:34:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-14 16:34:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-14 16:34:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-14 16:34:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-14 16:34:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-14 16:34:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-14 16:34:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-07-14 16:34:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-14 16:34:36 --> Final output sent to browser
DEBUG - 2018-07-14 16:34:36 --> Total execution time: 0.0241
INFO - 2018-07-14 16:34:37 --> Config Class Initialized
INFO - 2018-07-14 16:34:37 --> Hooks Class Initialized
DEBUG - 2018-07-14 16:34:37 --> UTF-8 Support Enabled
INFO - 2018-07-14 16:34:37 --> Utf8 Class Initialized
INFO - 2018-07-14 16:34:37 --> URI Class Initialized
INFO - 2018-07-14 16:34:37 --> Router Class Initialized
INFO - 2018-07-14 16:34:37 --> Output Class Initialized
INFO - 2018-07-14 16:34:37 --> Security Class Initialized
DEBUG - 2018-07-14 16:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 16:34:37 --> CSRF cookie sent
INFO - 2018-07-14 16:34:37 --> Input Class Initialized
INFO - 2018-07-14 16:34:37 --> Language Class Initialized
INFO - 2018-07-14 16:34:37 --> Loader Class Initialized
INFO - 2018-07-14 16:34:37 --> Helper loaded: url_helper
INFO - 2018-07-14 16:34:37 --> Helper loaded: form_helper
INFO - 2018-07-14 16:34:37 --> Helper loaded: language_helper
DEBUG - 2018-07-14 16:34:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 16:34:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 16:34:37 --> User Agent Class Initialized
INFO - 2018-07-14 16:34:37 --> Controller Class Initialized
INFO - 2018-07-14 16:34:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-14 16:34:37 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-14 16:34:37 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-14 16:34:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-14 16:34:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-14 16:34:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-14 16:34:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-14 16:34:37 --> Could not find the language line "req_email"
INFO - 2018-07-14 16:34:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-14 16:34:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-14 16:34:37 --> Final output sent to browser
DEBUG - 2018-07-14 16:34:37 --> Total execution time: 0.0229
INFO - 2018-07-14 16:34:37 --> Config Class Initialized
INFO - 2018-07-14 16:34:37 --> Hooks Class Initialized
DEBUG - 2018-07-14 16:34:37 --> UTF-8 Support Enabled
INFO - 2018-07-14 16:34:37 --> Utf8 Class Initialized
INFO - 2018-07-14 16:34:37 --> URI Class Initialized
INFO - 2018-07-14 16:34:37 --> Router Class Initialized
INFO - 2018-07-14 16:34:37 --> Output Class Initialized
INFO - 2018-07-14 16:34:37 --> Security Class Initialized
DEBUG - 2018-07-14 16:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 16:34:37 --> CSRF cookie sent
INFO - 2018-07-14 16:34:37 --> Input Class Initialized
INFO - 2018-07-14 16:34:37 --> Language Class Initialized
INFO - 2018-07-14 16:34:37 --> Loader Class Initialized
INFO - 2018-07-14 16:34:37 --> Helper loaded: url_helper
INFO - 2018-07-14 16:34:37 --> Helper loaded: form_helper
INFO - 2018-07-14 16:34:37 --> Helper loaded: language_helper
DEBUG - 2018-07-14 16:34:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 16:34:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 16:34:37 --> User Agent Class Initialized
INFO - 2018-07-14 16:34:37 --> Controller Class Initialized
INFO - 2018-07-14 16:34:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-14 16:34:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-14 16:34:37 --> Pixel_Model class loaded
INFO - 2018-07-14 16:34:37 --> Database Driver Class Initialized
INFO - 2018-07-14 16:34:37 --> Model "QuestionsModel" initialized
INFO - 2018-07-14 16:34:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-14 16:34:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-14 16:34:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-14 16:34:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-14 16:34:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/buy_gift.php
INFO - 2018-07-14 16:34:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-14 16:34:37 --> Final output sent to browser
DEBUG - 2018-07-14 16:34:37 --> Total execution time: 0.0351
INFO - 2018-07-14 16:47:38 --> Config Class Initialized
INFO - 2018-07-14 16:47:38 --> Hooks Class Initialized
DEBUG - 2018-07-14 16:47:38 --> UTF-8 Support Enabled
INFO - 2018-07-14 16:47:38 --> Utf8 Class Initialized
INFO - 2018-07-14 16:47:38 --> URI Class Initialized
DEBUG - 2018-07-14 16:47:38 --> No URI present. Default controller set.
INFO - 2018-07-14 16:47:38 --> Router Class Initialized
INFO - 2018-07-14 16:47:38 --> Output Class Initialized
INFO - 2018-07-14 16:47:38 --> Security Class Initialized
DEBUG - 2018-07-14 16:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 16:47:38 --> CSRF cookie sent
INFO - 2018-07-14 16:47:38 --> Input Class Initialized
INFO - 2018-07-14 16:47:38 --> Language Class Initialized
INFO - 2018-07-14 16:47:38 --> Loader Class Initialized
INFO - 2018-07-14 16:47:38 --> Helper loaded: url_helper
INFO - 2018-07-14 16:47:38 --> Helper loaded: form_helper
INFO - 2018-07-14 16:47:38 --> Helper loaded: language_helper
DEBUG - 2018-07-14 16:47:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 16:47:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 16:47:38 --> User Agent Class Initialized
INFO - 2018-07-14 16:47:38 --> Controller Class Initialized
INFO - 2018-07-14 16:47:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-14 16:47:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-14 16:47:38 --> Pixel_Model class loaded
INFO - 2018-07-14 16:47:38 --> Database Driver Class Initialized
INFO - 2018-07-14 16:47:38 --> Model "QuestionsModel" initialized
INFO - 2018-07-14 16:47:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-14 16:47:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-14 16:47:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-14 16:47:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-14 16:47:38 --> Final output sent to browser
DEBUG - 2018-07-14 16:47:38 --> Total execution time: 0.0325
INFO - 2018-07-14 16:59:32 --> Config Class Initialized
INFO - 2018-07-14 16:59:32 --> Hooks Class Initialized
DEBUG - 2018-07-14 16:59:32 --> UTF-8 Support Enabled
INFO - 2018-07-14 16:59:32 --> Utf8 Class Initialized
INFO - 2018-07-14 16:59:32 --> URI Class Initialized
INFO - 2018-07-14 16:59:32 --> Router Class Initialized
INFO - 2018-07-14 16:59:32 --> Output Class Initialized
INFO - 2018-07-14 16:59:32 --> Security Class Initialized
DEBUG - 2018-07-14 16:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 16:59:32 --> CSRF cookie sent
INFO - 2018-07-14 16:59:32 --> Input Class Initialized
INFO - 2018-07-14 16:59:32 --> Language Class Initialized
ERROR - 2018-07-14 16:59:32 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-14 17:09:35 --> Config Class Initialized
INFO - 2018-07-14 17:09:35 --> Hooks Class Initialized
DEBUG - 2018-07-14 17:09:35 --> UTF-8 Support Enabled
INFO - 2018-07-14 17:09:35 --> Utf8 Class Initialized
INFO - 2018-07-14 17:09:35 --> URI Class Initialized
DEBUG - 2018-07-14 17:09:35 --> No URI present. Default controller set.
INFO - 2018-07-14 17:09:35 --> Router Class Initialized
INFO - 2018-07-14 17:09:35 --> Output Class Initialized
INFO - 2018-07-14 17:09:35 --> Security Class Initialized
DEBUG - 2018-07-14 17:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 17:09:35 --> CSRF cookie sent
INFO - 2018-07-14 17:09:35 --> Input Class Initialized
INFO - 2018-07-14 17:09:35 --> Language Class Initialized
INFO - 2018-07-14 17:09:35 --> Loader Class Initialized
INFO - 2018-07-14 17:09:35 --> Helper loaded: url_helper
INFO - 2018-07-14 17:09:35 --> Helper loaded: form_helper
INFO - 2018-07-14 17:09:35 --> Helper loaded: language_helper
DEBUG - 2018-07-14 17:09:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 17:09:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 17:09:35 --> User Agent Class Initialized
INFO - 2018-07-14 17:09:35 --> Controller Class Initialized
INFO - 2018-07-14 17:09:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-14 17:09:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-14 17:09:35 --> Pixel_Model class loaded
INFO - 2018-07-14 17:09:35 --> Database Driver Class Initialized
INFO - 2018-07-14 17:09:35 --> Model "QuestionsModel" initialized
INFO - 2018-07-14 17:09:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-14 17:09:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-14 17:09:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-14 17:09:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-14 17:09:35 --> Final output sent to browser
DEBUG - 2018-07-14 17:09:35 --> Total execution time: 0.0343
INFO - 2018-07-14 17:12:29 --> Config Class Initialized
INFO - 2018-07-14 17:12:29 --> Hooks Class Initialized
DEBUG - 2018-07-14 17:12:29 --> UTF-8 Support Enabled
INFO - 2018-07-14 17:12:29 --> Utf8 Class Initialized
INFO - 2018-07-14 17:12:29 --> URI Class Initialized
DEBUG - 2018-07-14 17:12:29 --> No URI present. Default controller set.
INFO - 2018-07-14 17:12:29 --> Router Class Initialized
INFO - 2018-07-14 17:12:29 --> Output Class Initialized
INFO - 2018-07-14 17:12:29 --> Security Class Initialized
DEBUG - 2018-07-14 17:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 17:12:29 --> CSRF cookie sent
INFO - 2018-07-14 17:12:29 --> Input Class Initialized
INFO - 2018-07-14 17:12:29 --> Language Class Initialized
INFO - 2018-07-14 17:12:29 --> Loader Class Initialized
INFO - 2018-07-14 17:12:29 --> Helper loaded: url_helper
INFO - 2018-07-14 17:12:29 --> Helper loaded: form_helper
INFO - 2018-07-14 17:12:29 --> Helper loaded: language_helper
DEBUG - 2018-07-14 17:12:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 17:12:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 17:12:29 --> User Agent Class Initialized
INFO - 2018-07-14 17:12:29 --> Controller Class Initialized
INFO - 2018-07-14 17:12:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-14 17:12:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-14 17:12:29 --> Pixel_Model class loaded
INFO - 2018-07-14 17:12:29 --> Database Driver Class Initialized
INFO - 2018-07-14 17:12:29 --> Model "QuestionsModel" initialized
INFO - 2018-07-14 17:12:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-14 17:12:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-14 17:12:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-14 17:12:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-14 17:12:29 --> Final output sent to browser
DEBUG - 2018-07-14 17:12:29 --> Total execution time: 0.0327
INFO - 2018-07-14 17:12:34 --> Config Class Initialized
INFO - 2018-07-14 17:12:34 --> Hooks Class Initialized
DEBUG - 2018-07-14 17:12:34 --> UTF-8 Support Enabled
INFO - 2018-07-14 17:12:34 --> Utf8 Class Initialized
INFO - 2018-07-14 17:12:34 --> URI Class Initialized
INFO - 2018-07-14 17:12:34 --> Router Class Initialized
INFO - 2018-07-14 17:12:34 --> Output Class Initialized
INFO - 2018-07-14 17:12:34 --> Security Class Initialized
DEBUG - 2018-07-14 17:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 17:12:34 --> CSRF cookie sent
INFO - 2018-07-14 17:12:34 --> CSRF token verified
INFO - 2018-07-14 17:12:34 --> Input Class Initialized
INFO - 2018-07-14 17:12:34 --> Language Class Initialized
INFO - 2018-07-14 17:12:34 --> Loader Class Initialized
INFO - 2018-07-14 17:12:34 --> Helper loaded: url_helper
INFO - 2018-07-14 17:12:34 --> Helper loaded: form_helper
INFO - 2018-07-14 17:12:34 --> Helper loaded: language_helper
DEBUG - 2018-07-14 17:12:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 17:12:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 17:12:34 --> User Agent Class Initialized
INFO - 2018-07-14 17:12:34 --> Controller Class Initialized
INFO - 2018-07-14 17:12:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-14 17:12:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-14 17:12:34 --> Pixel_Model class loaded
INFO - 2018-07-14 17:12:34 --> Database Driver Class Initialized
INFO - 2018-07-14 17:12:34 --> Model "QuestionsModel" initialized
INFO - 2018-07-14 17:12:34 --> Config Class Initialized
INFO - 2018-07-14 17:12:34 --> Hooks Class Initialized
DEBUG - 2018-07-14 17:12:34 --> UTF-8 Support Enabled
INFO - 2018-07-14 17:12:34 --> Utf8 Class Initialized
INFO - 2018-07-14 17:12:34 --> URI Class Initialized
INFO - 2018-07-14 17:12:34 --> Router Class Initialized
INFO - 2018-07-14 17:12:34 --> Output Class Initialized
INFO - 2018-07-14 17:12:34 --> Security Class Initialized
DEBUG - 2018-07-14 17:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 17:12:34 --> CSRF cookie sent
INFO - 2018-07-14 17:12:34 --> Input Class Initialized
INFO - 2018-07-14 17:12:34 --> Language Class Initialized
INFO - 2018-07-14 17:12:34 --> Loader Class Initialized
INFO - 2018-07-14 17:12:34 --> Helper loaded: url_helper
INFO - 2018-07-14 17:12:34 --> Helper loaded: form_helper
INFO - 2018-07-14 17:12:34 --> Helper loaded: language_helper
DEBUG - 2018-07-14 17:12:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 17:12:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 17:12:34 --> User Agent Class Initialized
INFO - 2018-07-14 17:12:34 --> Controller Class Initialized
INFO - 2018-07-14 17:12:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-14 17:12:34 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-14 17:12:34 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-14 17:12:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-14 17:12:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-14 17:12:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-14 17:12:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-14 17:12:34 --> Could not find the language line "req_email"
INFO - 2018-07-14 17:12:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-14 17:12:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-14 17:12:34 --> Final output sent to browser
DEBUG - 2018-07-14 17:12:34 --> Total execution time: 0.0191
INFO - 2018-07-14 17:28:35 --> Config Class Initialized
INFO - 2018-07-14 17:28:35 --> Hooks Class Initialized
DEBUG - 2018-07-14 17:28:35 --> UTF-8 Support Enabled
INFO - 2018-07-14 17:28:35 --> Utf8 Class Initialized
INFO - 2018-07-14 17:28:35 --> URI Class Initialized
INFO - 2018-07-14 17:28:35 --> Router Class Initialized
INFO - 2018-07-14 17:28:35 --> Output Class Initialized
INFO - 2018-07-14 17:28:35 --> Security Class Initialized
DEBUG - 2018-07-14 17:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 17:28:35 --> CSRF cookie sent
INFO - 2018-07-14 17:28:35 --> Input Class Initialized
INFO - 2018-07-14 17:28:35 --> Language Class Initialized
ERROR - 2018-07-14 17:28:35 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-14 17:53:05 --> Config Class Initialized
INFO - 2018-07-14 17:53:05 --> Hooks Class Initialized
DEBUG - 2018-07-14 17:53:05 --> UTF-8 Support Enabled
INFO - 2018-07-14 17:53:05 --> Utf8 Class Initialized
INFO - 2018-07-14 17:53:05 --> URI Class Initialized
DEBUG - 2018-07-14 17:53:05 --> No URI present. Default controller set.
INFO - 2018-07-14 17:53:05 --> Router Class Initialized
INFO - 2018-07-14 17:53:05 --> Output Class Initialized
INFO - 2018-07-14 17:53:05 --> Security Class Initialized
DEBUG - 2018-07-14 17:53:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 17:53:05 --> CSRF cookie sent
INFO - 2018-07-14 17:53:05 --> Input Class Initialized
INFO - 2018-07-14 17:53:05 --> Language Class Initialized
INFO - 2018-07-14 17:53:05 --> Loader Class Initialized
INFO - 2018-07-14 17:53:05 --> Helper loaded: url_helper
INFO - 2018-07-14 17:53:05 --> Helper loaded: form_helper
INFO - 2018-07-14 17:53:05 --> Helper loaded: language_helper
DEBUG - 2018-07-14 17:53:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 17:53:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 17:53:05 --> User Agent Class Initialized
INFO - 2018-07-14 17:53:05 --> Controller Class Initialized
INFO - 2018-07-14 17:53:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-14 17:53:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-14 17:53:05 --> Pixel_Model class loaded
INFO - 2018-07-14 17:53:05 --> Database Driver Class Initialized
INFO - 2018-07-14 17:53:05 --> Model "QuestionsModel" initialized
INFO - 2018-07-14 17:53:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-14 17:53:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-14 17:53:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-14 17:53:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-14 17:53:05 --> Final output sent to browser
DEBUG - 2018-07-14 17:53:05 --> Total execution time: 0.0335
INFO - 2018-07-14 18:39:47 --> Config Class Initialized
INFO - 2018-07-14 18:39:47 --> Hooks Class Initialized
DEBUG - 2018-07-14 18:39:47 --> UTF-8 Support Enabled
INFO - 2018-07-14 18:39:47 --> Utf8 Class Initialized
INFO - 2018-07-14 18:39:47 --> URI Class Initialized
DEBUG - 2018-07-14 18:39:47 --> No URI present. Default controller set.
INFO - 2018-07-14 18:39:47 --> Router Class Initialized
INFO - 2018-07-14 18:39:47 --> Output Class Initialized
INFO - 2018-07-14 18:39:47 --> Security Class Initialized
DEBUG - 2018-07-14 18:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 18:39:47 --> CSRF cookie sent
INFO - 2018-07-14 18:39:47 --> Input Class Initialized
INFO - 2018-07-14 18:39:47 --> Language Class Initialized
INFO - 2018-07-14 18:39:47 --> Loader Class Initialized
INFO - 2018-07-14 18:39:47 --> Helper loaded: url_helper
INFO - 2018-07-14 18:39:47 --> Helper loaded: form_helper
INFO - 2018-07-14 18:39:47 --> Helper loaded: language_helper
DEBUG - 2018-07-14 18:39:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 18:39:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 18:39:47 --> User Agent Class Initialized
INFO - 2018-07-14 18:39:47 --> Controller Class Initialized
INFO - 2018-07-14 18:39:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-14 18:39:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-14 18:39:47 --> Pixel_Model class loaded
INFO - 2018-07-14 18:39:47 --> Database Driver Class Initialized
INFO - 2018-07-14 18:39:47 --> Model "QuestionsModel" initialized
INFO - 2018-07-14 18:39:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-14 18:39:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-14 18:39:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-14 18:39:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-14 18:39:47 --> Final output sent to browser
DEBUG - 2018-07-14 18:39:47 --> Total execution time: 0.0385

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-07-18 01:52:55 --> Config Class Initialized
INFO - 2018-07-18 01:52:55 --> Hooks Class Initialized
DEBUG - 2018-07-18 01:52:55 --> UTF-8 Support Enabled
INFO - 2018-07-18 01:52:55 --> Utf8 Class Initialized
INFO - 2018-07-18 01:52:55 --> URI Class Initialized
DEBUG - 2018-07-18 01:52:55 --> No URI present. Default controller set.
INFO - 2018-07-18 01:52:55 --> Router Class Initialized
INFO - 2018-07-18 01:52:55 --> Output Class Initialized
INFO - 2018-07-18 01:52:55 --> Security Class Initialized
DEBUG - 2018-07-18 01:52:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-18 01:52:55 --> CSRF cookie sent
INFO - 2018-07-18 01:52:55 --> Input Class Initialized
INFO - 2018-07-18 01:52:55 --> Language Class Initialized
INFO - 2018-07-18 01:52:55 --> Loader Class Initialized
INFO - 2018-07-18 01:52:55 --> Helper loaded: url_helper
INFO - 2018-07-18 01:52:55 --> Helper loaded: form_helper
INFO - 2018-07-18 01:52:55 --> Helper loaded: language_helper
DEBUG - 2018-07-18 01:52:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-18 01:52:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-18 01:52:55 --> User Agent Class Initialized
INFO - 2018-07-18 01:52:55 --> Controller Class Initialized
INFO - 2018-07-18 01:52:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-18 01:52:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-18 01:52:55 --> Pixel_Model class loaded
INFO - 2018-07-18 01:52:55 --> Database Driver Class Initialized
INFO - 2018-07-18 01:52:55 --> Model "QuestionsModel" initialized
INFO - 2018-07-18 01:52:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-18 01:52:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-18 01:52:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-18 01:52:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-18 01:52:55 --> Final output sent to browser
DEBUG - 2018-07-18 01:52:55 --> Total execution time: 0.0326
INFO - 2018-07-18 01:59:37 --> Config Class Initialized
INFO - 2018-07-18 01:59:37 --> Hooks Class Initialized
DEBUG - 2018-07-18 01:59:37 --> UTF-8 Support Enabled
INFO - 2018-07-18 01:59:37 --> Utf8 Class Initialized
INFO - 2018-07-18 01:59:37 --> URI Class Initialized
DEBUG - 2018-07-18 01:59:37 --> No URI present. Default controller set.
INFO - 2018-07-18 01:59:37 --> Router Class Initialized
INFO - 2018-07-18 01:59:37 --> Output Class Initialized
INFO - 2018-07-18 01:59:37 --> Security Class Initialized
DEBUG - 2018-07-18 01:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-18 01:59:37 --> CSRF cookie sent
INFO - 2018-07-18 01:59:37 --> Input Class Initialized
INFO - 2018-07-18 01:59:37 --> Language Class Initialized
INFO - 2018-07-18 01:59:37 --> Loader Class Initialized
INFO - 2018-07-18 01:59:37 --> Helper loaded: url_helper
INFO - 2018-07-18 01:59:37 --> Helper loaded: form_helper
INFO - 2018-07-18 01:59:37 --> Helper loaded: language_helper
DEBUG - 2018-07-18 01:59:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-18 01:59:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-18 01:59:37 --> User Agent Class Initialized
INFO - 2018-07-18 01:59:37 --> Controller Class Initialized
INFO - 2018-07-18 01:59:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-18 01:59:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-18 01:59:37 --> Pixel_Model class loaded
INFO - 2018-07-18 01:59:37 --> Database Driver Class Initialized
INFO - 2018-07-18 01:59:37 --> Model "QuestionsModel" initialized
INFO - 2018-07-18 01:59:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-18 01:59:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-18 01:59:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-18 01:59:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-18 01:59:37 --> Final output sent to browser
DEBUG - 2018-07-18 01:59:37 --> Total execution time: 0.0360
INFO - 2018-07-18 02:14:36 --> Config Class Initialized
INFO - 2018-07-18 02:14:36 --> Hooks Class Initialized
DEBUG - 2018-07-18 02:14:36 --> UTF-8 Support Enabled
INFO - 2018-07-18 02:14:36 --> Utf8 Class Initialized
INFO - 2018-07-18 02:14:36 --> URI Class Initialized
DEBUG - 2018-07-18 02:14:36 --> No URI present. Default controller set.
INFO - 2018-07-18 02:14:36 --> Router Class Initialized
INFO - 2018-07-18 02:14:36 --> Output Class Initialized
INFO - 2018-07-18 02:14:36 --> Security Class Initialized
DEBUG - 2018-07-18 02:14:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-18 02:14:36 --> CSRF cookie sent
INFO - 2018-07-18 02:14:36 --> Input Class Initialized
INFO - 2018-07-18 02:14:36 --> Language Class Initialized
INFO - 2018-07-18 02:14:36 --> Loader Class Initialized
INFO - 2018-07-18 02:14:36 --> Helper loaded: url_helper
INFO - 2018-07-18 02:14:36 --> Helper loaded: form_helper
INFO - 2018-07-18 02:14:36 --> Helper loaded: language_helper
DEBUG - 2018-07-18 02:14:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-18 02:14:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-18 02:14:36 --> User Agent Class Initialized
INFO - 2018-07-18 02:14:36 --> Controller Class Initialized
INFO - 2018-07-18 02:14:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-18 02:14:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-18 02:14:36 --> Pixel_Model class loaded
INFO - 2018-07-18 02:14:36 --> Database Driver Class Initialized
INFO - 2018-07-18 02:14:36 --> Model "QuestionsModel" initialized
INFO - 2018-07-18 02:14:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-18 02:14:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-18 02:14:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-18 02:14:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-18 02:14:36 --> Final output sent to browser
DEBUG - 2018-07-18 02:14:36 --> Total execution time: 0.0444
INFO - 2018-07-18 03:15:59 --> Config Class Initialized
INFO - 2018-07-18 03:15:59 --> Hooks Class Initialized
DEBUG - 2018-07-18 03:15:59 --> UTF-8 Support Enabled
INFO - 2018-07-18 03:15:59 --> Utf8 Class Initialized
INFO - 2018-07-18 03:15:59 --> URI Class Initialized
DEBUG - 2018-07-18 03:15:59 --> No URI present. Default controller set.
INFO - 2018-07-18 03:15:59 --> Router Class Initialized
INFO - 2018-07-18 03:15:59 --> Output Class Initialized
INFO - 2018-07-18 03:15:59 --> Security Class Initialized
DEBUG - 2018-07-18 03:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-18 03:15:59 --> CSRF cookie sent
INFO - 2018-07-18 03:15:59 --> Input Class Initialized
INFO - 2018-07-18 03:15:59 --> Language Class Initialized
INFO - 2018-07-18 03:15:59 --> Loader Class Initialized
INFO - 2018-07-18 03:15:59 --> Helper loaded: url_helper
INFO - 2018-07-18 03:15:59 --> Helper loaded: form_helper
INFO - 2018-07-18 03:15:59 --> Helper loaded: language_helper
DEBUG - 2018-07-18 03:15:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-18 03:15:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-18 03:15:59 --> User Agent Class Initialized
INFO - 2018-07-18 03:15:59 --> Controller Class Initialized
INFO - 2018-07-18 03:15:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-18 03:15:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-18 03:15:59 --> Pixel_Model class loaded
INFO - 2018-07-18 03:15:59 --> Database Driver Class Initialized
INFO - 2018-07-18 03:15:59 --> Model "QuestionsModel" initialized
INFO - 2018-07-18 03:15:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-18 03:15:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-18 03:15:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-18 03:15:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-18 03:15:59 --> Final output sent to browser
DEBUG - 2018-07-18 03:15:59 --> Total execution time: 0.0402
INFO - 2018-07-18 03:37:35 --> Config Class Initialized
INFO - 2018-07-18 03:37:35 --> Hooks Class Initialized
DEBUG - 2018-07-18 03:37:35 --> UTF-8 Support Enabled
INFO - 2018-07-18 03:37:35 --> Utf8 Class Initialized
INFO - 2018-07-18 03:37:35 --> URI Class Initialized
DEBUG - 2018-07-18 03:37:35 --> No URI present. Default controller set.
INFO - 2018-07-18 03:37:35 --> Router Class Initialized
INFO - 2018-07-18 03:37:35 --> Output Class Initialized
INFO - 2018-07-18 03:37:35 --> Security Class Initialized
DEBUG - 2018-07-18 03:37:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-18 03:37:35 --> CSRF cookie sent
INFO - 2018-07-18 03:37:35 --> Input Class Initialized
INFO - 2018-07-18 03:37:35 --> Language Class Initialized
INFO - 2018-07-18 03:37:35 --> Loader Class Initialized
INFO - 2018-07-18 03:37:35 --> Helper loaded: url_helper
INFO - 2018-07-18 03:37:35 --> Helper loaded: form_helper
INFO - 2018-07-18 03:37:35 --> Helper loaded: language_helper
DEBUG - 2018-07-18 03:37:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-18 03:37:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-18 03:37:35 --> User Agent Class Initialized
INFO - 2018-07-18 03:37:35 --> Controller Class Initialized
INFO - 2018-07-18 03:37:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-18 03:37:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-18 03:37:35 --> Pixel_Model class loaded
INFO - 2018-07-18 03:37:35 --> Database Driver Class Initialized
INFO - 2018-07-18 03:37:35 --> Model "QuestionsModel" initialized
INFO - 2018-07-18 03:37:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-18 03:37:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-18 03:37:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-18 03:37:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-18 03:37:35 --> Final output sent to browser
DEBUG - 2018-07-18 03:37:35 --> Total execution time: 0.0312
INFO - 2018-07-18 04:22:27 --> Config Class Initialized
INFO - 2018-07-18 04:22:27 --> Hooks Class Initialized
DEBUG - 2018-07-18 04:22:27 --> UTF-8 Support Enabled
INFO - 2018-07-18 04:22:27 --> Utf8 Class Initialized
INFO - 2018-07-18 04:22:27 --> URI Class Initialized
DEBUG - 2018-07-18 04:22:27 --> No URI present. Default controller set.
INFO - 2018-07-18 04:22:27 --> Router Class Initialized
INFO - 2018-07-18 04:22:27 --> Output Class Initialized
INFO - 2018-07-18 04:22:27 --> Security Class Initialized
DEBUG - 2018-07-18 04:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-18 04:22:27 --> CSRF cookie sent
INFO - 2018-07-18 04:22:27 --> Input Class Initialized
INFO - 2018-07-18 04:22:27 --> Language Class Initialized
INFO - 2018-07-18 04:22:27 --> Loader Class Initialized
INFO - 2018-07-18 04:22:27 --> Helper loaded: url_helper
INFO - 2018-07-18 04:22:27 --> Helper loaded: form_helper
INFO - 2018-07-18 04:22:27 --> Helper loaded: language_helper
DEBUG - 2018-07-18 04:22:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-18 04:22:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-18 04:22:27 --> User Agent Class Initialized
INFO - 2018-07-18 04:22:27 --> Controller Class Initialized
INFO - 2018-07-18 04:22:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-18 04:22:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-18 04:22:27 --> Pixel_Model class loaded
INFO - 2018-07-18 04:22:27 --> Database Driver Class Initialized
INFO - 2018-07-18 04:22:27 --> Model "QuestionsModel" initialized
INFO - 2018-07-18 04:22:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-18 04:22:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-18 04:22:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-18 04:22:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-18 04:22:27 --> Final output sent to browser
DEBUG - 2018-07-18 04:22:27 --> Total execution time: 0.0328
INFO - 2018-07-18 05:26:34 --> Config Class Initialized
INFO - 2018-07-18 05:26:34 --> Hooks Class Initialized
DEBUG - 2018-07-18 05:26:34 --> UTF-8 Support Enabled
INFO - 2018-07-18 05:26:34 --> Utf8 Class Initialized
INFO - 2018-07-18 05:26:34 --> URI Class Initialized
INFO - 2018-07-18 05:26:34 --> Router Class Initialized
INFO - 2018-07-18 05:26:34 --> Output Class Initialized
INFO - 2018-07-18 05:26:34 --> Security Class Initialized
DEBUG - 2018-07-18 05:26:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-18 05:26:34 --> CSRF cookie sent
INFO - 2018-07-18 05:26:34 --> Input Class Initialized
INFO - 2018-07-18 05:26:34 --> Language Class Initialized
ERROR - 2018-07-18 05:26:34 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-18 05:26:37 --> Config Class Initialized
INFO - 2018-07-18 05:26:37 --> Hooks Class Initialized
DEBUG - 2018-07-18 05:26:37 --> UTF-8 Support Enabled
INFO - 2018-07-18 05:26:37 --> Utf8 Class Initialized
INFO - 2018-07-18 05:26:37 --> URI Class Initialized
INFO - 2018-07-18 05:26:37 --> Router Class Initialized
INFO - 2018-07-18 05:26:37 --> Output Class Initialized
INFO - 2018-07-18 05:26:37 --> Security Class Initialized
DEBUG - 2018-07-18 05:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-18 05:26:37 --> CSRF cookie sent
INFO - 2018-07-18 05:26:37 --> Input Class Initialized
INFO - 2018-07-18 05:26:37 --> Language Class Initialized
INFO - 2018-07-18 05:26:37 --> Loader Class Initialized
INFO - 2018-07-18 05:26:37 --> Helper loaded: url_helper
INFO - 2018-07-18 05:26:37 --> Helper loaded: form_helper
INFO - 2018-07-18 05:26:37 --> Helper loaded: language_helper
DEBUG - 2018-07-18 05:26:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-18 05:26:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-18 05:26:37 --> User Agent Class Initialized
INFO - 2018-07-18 05:26:37 --> Controller Class Initialized
INFO - 2018-07-18 05:26:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-18 05:26:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-18 05:26:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-18 05:26:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-18 05:26:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-18 05:26:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-18 05:26:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-07-18 05:26:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-18 05:26:37 --> Final output sent to browser
DEBUG - 2018-07-18 05:26:37 --> Total execution time: 0.0345
INFO - 2018-07-18 06:09:29 --> Config Class Initialized
INFO - 2018-07-18 06:09:29 --> Hooks Class Initialized
DEBUG - 2018-07-18 06:09:29 --> UTF-8 Support Enabled
INFO - 2018-07-18 06:09:29 --> Utf8 Class Initialized
INFO - 2018-07-18 06:09:29 --> URI Class Initialized
DEBUG - 2018-07-18 06:09:29 --> No URI present. Default controller set.
INFO - 2018-07-18 06:09:29 --> Router Class Initialized
INFO - 2018-07-18 06:09:29 --> Output Class Initialized
INFO - 2018-07-18 06:09:29 --> Security Class Initialized
DEBUG - 2018-07-18 06:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-18 06:09:29 --> CSRF cookie sent
INFO - 2018-07-18 06:09:29 --> Input Class Initialized
INFO - 2018-07-18 06:09:29 --> Language Class Initialized
INFO - 2018-07-18 06:09:29 --> Loader Class Initialized
INFO - 2018-07-18 06:09:29 --> Helper loaded: url_helper
INFO - 2018-07-18 06:09:29 --> Helper loaded: form_helper
INFO - 2018-07-18 06:09:29 --> Helper loaded: language_helper
DEBUG - 2018-07-18 06:09:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-18 06:09:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-18 06:09:29 --> User Agent Class Initialized
INFO - 2018-07-18 06:09:29 --> Controller Class Initialized
INFO - 2018-07-18 06:09:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-18 06:09:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-18 06:09:29 --> Pixel_Model class loaded
INFO - 2018-07-18 06:09:29 --> Database Driver Class Initialized
INFO - 2018-07-18 06:09:29 --> Model "QuestionsModel" initialized
INFO - 2018-07-18 06:09:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-18 06:09:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-18 06:09:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-18 06:09:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-18 06:09:29 --> Final output sent to browser
DEBUG - 2018-07-18 06:09:29 --> Total execution time: 0.0336
INFO - 2018-07-18 07:24:28 --> Config Class Initialized
INFO - 2018-07-18 07:24:28 --> Hooks Class Initialized
DEBUG - 2018-07-18 07:24:28 --> UTF-8 Support Enabled
INFO - 2018-07-18 07:24:28 --> Utf8 Class Initialized
INFO - 2018-07-18 07:24:28 --> URI Class Initialized
INFO - 2018-07-18 07:24:28 --> Router Class Initialized
INFO - 2018-07-18 07:24:28 --> Output Class Initialized
INFO - 2018-07-18 07:24:28 --> Security Class Initialized
DEBUG - 2018-07-18 07:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-18 07:24:28 --> CSRF cookie sent
INFO - 2018-07-18 07:24:28 --> Input Class Initialized
INFO - 2018-07-18 07:24:28 --> Language Class Initialized
ERROR - 2018-07-18 07:24:28 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-18 09:24:36 --> Config Class Initialized
INFO - 2018-07-18 09:24:36 --> Hooks Class Initialized
DEBUG - 2018-07-18 09:24:36 --> UTF-8 Support Enabled
INFO - 2018-07-18 09:24:36 --> Utf8 Class Initialized
INFO - 2018-07-18 09:24:36 --> URI Class Initialized
DEBUG - 2018-07-18 09:24:36 --> No URI present. Default controller set.
INFO - 2018-07-18 09:24:36 --> Router Class Initialized
INFO - 2018-07-18 09:24:36 --> Output Class Initialized
INFO - 2018-07-18 09:24:36 --> Security Class Initialized
DEBUG - 2018-07-18 09:24:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-18 09:24:36 --> CSRF cookie sent
INFO - 2018-07-18 09:24:36 --> Input Class Initialized
INFO - 2018-07-18 09:24:36 --> Language Class Initialized
INFO - 2018-07-18 09:24:36 --> Loader Class Initialized
INFO - 2018-07-18 09:24:36 --> Helper loaded: url_helper
INFO - 2018-07-18 09:24:36 --> Helper loaded: form_helper
INFO - 2018-07-18 09:24:36 --> Helper loaded: language_helper
DEBUG - 2018-07-18 09:24:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-18 09:24:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-18 09:24:36 --> User Agent Class Initialized
INFO - 2018-07-18 09:24:36 --> Controller Class Initialized
INFO - 2018-07-18 09:24:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-18 09:24:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-18 09:24:36 --> Pixel_Model class loaded
INFO - 2018-07-18 09:24:36 --> Database Driver Class Initialized
INFO - 2018-07-18 09:24:36 --> Model "QuestionsModel" initialized
INFO - 2018-07-18 09:24:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-18 09:24:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-18 09:24:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-18 09:24:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-18 09:24:36 --> Final output sent to browser
DEBUG - 2018-07-18 09:24:36 --> Total execution time: 0.0368
INFO - 2018-07-18 09:24:36 --> Config Class Initialized
INFO - 2018-07-18 09:24:36 --> Hooks Class Initialized
DEBUG - 2018-07-18 09:24:36 --> UTF-8 Support Enabled
INFO - 2018-07-18 09:24:36 --> Utf8 Class Initialized
INFO - 2018-07-18 09:24:36 --> URI Class Initialized
DEBUG - 2018-07-18 09:24:36 --> No URI present. Default controller set.
INFO - 2018-07-18 09:24:36 --> Router Class Initialized
INFO - 2018-07-18 09:24:36 --> Output Class Initialized
INFO - 2018-07-18 09:24:36 --> Security Class Initialized
DEBUG - 2018-07-18 09:24:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-18 09:24:36 --> CSRF cookie sent
INFO - 2018-07-18 09:24:36 --> Input Class Initialized
INFO - 2018-07-18 09:24:36 --> Language Class Initialized
INFO - 2018-07-18 09:24:36 --> Loader Class Initialized
INFO - 2018-07-18 09:24:36 --> Helper loaded: url_helper
INFO - 2018-07-18 09:24:36 --> Helper loaded: form_helper
INFO - 2018-07-18 09:24:36 --> Helper loaded: language_helper
DEBUG - 2018-07-18 09:24:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-18 09:24:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-18 09:24:36 --> User Agent Class Initialized
INFO - 2018-07-18 09:24:36 --> Controller Class Initialized
INFO - 2018-07-18 09:24:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-18 09:24:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-18 09:24:36 --> Pixel_Model class loaded
INFO - 2018-07-18 09:24:36 --> Database Driver Class Initialized
INFO - 2018-07-18 09:24:36 --> Model "QuestionsModel" initialized
INFO - 2018-07-18 09:24:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-18 09:24:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-18 09:24:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-18 09:24:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-18 09:24:36 --> Final output sent to browser
DEBUG - 2018-07-18 09:24:36 --> Total execution time: 0.0423
INFO - 2018-07-18 09:53:01 --> Config Class Initialized
INFO - 2018-07-18 09:53:01 --> Hooks Class Initialized
DEBUG - 2018-07-18 09:53:01 --> UTF-8 Support Enabled
INFO - 2018-07-18 09:53:01 --> Utf8 Class Initialized
INFO - 2018-07-18 09:53:01 --> URI Class Initialized
DEBUG - 2018-07-18 09:53:01 --> No URI present. Default controller set.
INFO - 2018-07-18 09:53:01 --> Router Class Initialized
INFO - 2018-07-18 09:53:01 --> Output Class Initialized
INFO - 2018-07-18 09:53:01 --> Security Class Initialized
DEBUG - 2018-07-18 09:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-18 09:53:01 --> CSRF cookie sent
INFO - 2018-07-18 09:53:01 --> Input Class Initialized
INFO - 2018-07-18 09:53:01 --> Language Class Initialized
INFO - 2018-07-18 09:53:01 --> Loader Class Initialized
INFO - 2018-07-18 09:53:01 --> Helper loaded: url_helper
INFO - 2018-07-18 09:53:01 --> Helper loaded: form_helper
INFO - 2018-07-18 09:53:01 --> Helper loaded: language_helper
DEBUG - 2018-07-18 09:53:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-18 09:53:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-18 09:53:01 --> User Agent Class Initialized
INFO - 2018-07-18 09:53:01 --> Controller Class Initialized
INFO - 2018-07-18 09:53:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-18 09:53:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-18 09:53:01 --> Pixel_Model class loaded
INFO - 2018-07-18 09:53:01 --> Database Driver Class Initialized
INFO - 2018-07-18 09:53:01 --> Model "QuestionsModel" initialized
INFO - 2018-07-18 09:53:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-18 09:53:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-18 09:53:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-18 09:53:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-18 09:53:01 --> Final output sent to browser
DEBUG - 2018-07-18 09:53:01 --> Total execution time: 0.0478
INFO - 2018-07-18 11:09:33 --> Config Class Initialized
INFO - 2018-07-18 11:09:33 --> Hooks Class Initialized
DEBUG - 2018-07-18 11:09:33 --> UTF-8 Support Enabled
INFO - 2018-07-18 11:09:33 --> Utf8 Class Initialized
INFO - 2018-07-18 11:09:33 --> URI Class Initialized
DEBUG - 2018-07-18 11:09:33 --> No URI present. Default controller set.
INFO - 2018-07-18 11:09:33 --> Router Class Initialized
INFO - 2018-07-18 11:09:33 --> Output Class Initialized
INFO - 2018-07-18 11:09:33 --> Security Class Initialized
DEBUG - 2018-07-18 11:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-18 11:09:33 --> CSRF cookie sent
INFO - 2018-07-18 11:09:33 --> Input Class Initialized
INFO - 2018-07-18 11:09:33 --> Language Class Initialized
INFO - 2018-07-18 11:09:33 --> Loader Class Initialized
INFO - 2018-07-18 11:09:33 --> Helper loaded: url_helper
INFO - 2018-07-18 11:09:33 --> Helper loaded: form_helper
INFO - 2018-07-18 11:09:33 --> Helper loaded: language_helper
DEBUG - 2018-07-18 11:09:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-18 11:09:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-18 11:09:33 --> User Agent Class Initialized
INFO - 2018-07-18 11:09:33 --> Controller Class Initialized
INFO - 2018-07-18 11:09:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-18 11:09:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-18 11:09:33 --> Pixel_Model class loaded
INFO - 2018-07-18 11:09:33 --> Database Driver Class Initialized
INFO - 2018-07-18 11:09:33 --> Model "QuestionsModel" initialized
INFO - 2018-07-18 11:09:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-18 11:09:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-18 11:09:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-18 11:09:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-18 11:09:33 --> Final output sent to browser
DEBUG - 2018-07-18 11:09:33 --> Total execution time: 0.0351
INFO - 2018-07-18 11:09:52 --> Config Class Initialized
INFO - 2018-07-18 11:09:52 --> Hooks Class Initialized
DEBUG - 2018-07-18 11:09:52 --> UTF-8 Support Enabled
INFO - 2018-07-18 11:09:52 --> Utf8 Class Initialized
INFO - 2018-07-18 11:09:52 --> URI Class Initialized
INFO - 2018-07-18 11:09:52 --> Router Class Initialized
INFO - 2018-07-18 11:09:52 --> Output Class Initialized
INFO - 2018-07-18 11:09:52 --> Security Class Initialized
DEBUG - 2018-07-18 11:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-18 11:09:52 --> CSRF cookie sent
INFO - 2018-07-18 11:09:52 --> CSRF token verified
INFO - 2018-07-18 11:09:52 --> Input Class Initialized
INFO - 2018-07-18 11:09:52 --> Language Class Initialized
INFO - 2018-07-18 11:09:52 --> Loader Class Initialized
INFO - 2018-07-18 11:09:52 --> Helper loaded: url_helper
INFO - 2018-07-18 11:09:52 --> Helper loaded: form_helper
INFO - 2018-07-18 11:09:52 --> Helper loaded: language_helper
DEBUG - 2018-07-18 11:09:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-18 11:09:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-18 11:09:52 --> User Agent Class Initialized
INFO - 2018-07-18 11:09:52 --> Controller Class Initialized
INFO - 2018-07-18 11:09:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-18 11:09:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-18 11:09:52 --> Pixel_Model class loaded
INFO - 2018-07-18 11:09:52 --> Database Driver Class Initialized
INFO - 2018-07-18 11:09:52 --> Model "QuestionsModel" initialized
INFO - 2018-07-18 11:09:52 --> Config Class Initialized
INFO - 2018-07-18 11:09:52 --> Hooks Class Initialized
DEBUG - 2018-07-18 11:09:52 --> UTF-8 Support Enabled
INFO - 2018-07-18 11:09:52 --> Utf8 Class Initialized
INFO - 2018-07-18 11:09:52 --> URI Class Initialized
INFO - 2018-07-18 11:09:52 --> Router Class Initialized
INFO - 2018-07-18 11:09:52 --> Output Class Initialized
INFO - 2018-07-18 11:09:52 --> Security Class Initialized
DEBUG - 2018-07-18 11:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-18 11:09:52 --> CSRF cookie sent
INFO - 2018-07-18 11:09:52 --> Input Class Initialized
INFO - 2018-07-18 11:09:52 --> Language Class Initialized
INFO - 2018-07-18 11:09:52 --> Loader Class Initialized
INFO - 2018-07-18 11:09:52 --> Helper loaded: url_helper
INFO - 2018-07-18 11:09:52 --> Helper loaded: form_helper
INFO - 2018-07-18 11:09:52 --> Helper loaded: language_helper
DEBUG - 2018-07-18 11:09:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-18 11:09:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-18 11:09:52 --> User Agent Class Initialized
INFO - 2018-07-18 11:09:52 --> Controller Class Initialized
INFO - 2018-07-18 11:09:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-18 11:09:52 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-18 11:09:52 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-18 11:09:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-18 11:09:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-18 11:09:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-18 11:09:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-18 11:09:52 --> Could not find the language line "req_email"
INFO - 2018-07-18 11:09:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-18 11:09:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-18 11:09:52 --> Final output sent to browser
DEBUG - 2018-07-18 11:09:52 --> Total execution time: 0.0502
INFO - 2018-07-18 12:12:21 --> Config Class Initialized
INFO - 2018-07-18 12:12:21 --> Hooks Class Initialized
DEBUG - 2018-07-18 12:12:21 --> UTF-8 Support Enabled
INFO - 2018-07-18 12:12:21 --> Utf8 Class Initialized
INFO - 2018-07-18 12:12:21 --> URI Class Initialized
INFO - 2018-07-18 12:12:21 --> Router Class Initialized
INFO - 2018-07-18 12:12:21 --> Output Class Initialized
INFO - 2018-07-18 12:12:21 --> Security Class Initialized
DEBUG - 2018-07-18 12:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-18 12:12:21 --> CSRF cookie sent
INFO - 2018-07-18 12:12:21 --> Input Class Initialized
INFO - 2018-07-18 12:12:21 --> Language Class Initialized
ERROR - 2018-07-18 12:12:21 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-18 12:12:21 --> Config Class Initialized
INFO - 2018-07-18 12:12:21 --> Hooks Class Initialized
DEBUG - 2018-07-18 12:12:21 --> UTF-8 Support Enabled
INFO - 2018-07-18 12:12:21 --> Utf8 Class Initialized
INFO - 2018-07-18 12:12:21 --> URI Class Initialized
DEBUG - 2018-07-18 12:12:21 --> No URI present. Default controller set.
INFO - 2018-07-18 12:12:21 --> Router Class Initialized
INFO - 2018-07-18 12:12:21 --> Output Class Initialized
INFO - 2018-07-18 12:12:21 --> Security Class Initialized
DEBUG - 2018-07-18 12:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-18 12:12:21 --> CSRF cookie sent
INFO - 2018-07-18 12:12:21 --> Input Class Initialized
INFO - 2018-07-18 12:12:21 --> Language Class Initialized
INFO - 2018-07-18 12:12:21 --> Loader Class Initialized
INFO - 2018-07-18 12:12:21 --> Helper loaded: url_helper
INFO - 2018-07-18 12:12:21 --> Helper loaded: form_helper
INFO - 2018-07-18 12:12:21 --> Helper loaded: language_helper
DEBUG - 2018-07-18 12:12:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-18 12:12:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-18 12:12:21 --> User Agent Class Initialized
INFO - 2018-07-18 12:12:21 --> Controller Class Initialized
INFO - 2018-07-18 12:12:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-18 12:12:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-18 12:12:21 --> Pixel_Model class loaded
INFO - 2018-07-18 12:12:21 --> Database Driver Class Initialized
INFO - 2018-07-18 12:12:21 --> Model "QuestionsModel" initialized
INFO - 2018-07-18 12:12:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-18 12:12:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-18 12:12:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-18 12:12:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-18 12:12:21 --> Final output sent to browser
DEBUG - 2018-07-18 12:12:21 --> Total execution time: 0.0344
INFO - 2018-07-18 17:00:35 --> Config Class Initialized
INFO - 2018-07-18 17:00:35 --> Hooks Class Initialized
DEBUG - 2018-07-18 17:00:35 --> UTF-8 Support Enabled
INFO - 2018-07-18 17:00:35 --> Utf8 Class Initialized
INFO - 2018-07-18 17:00:35 --> URI Class Initialized
INFO - 2018-07-18 17:00:36 --> Router Class Initialized
INFO - 2018-07-18 17:00:36 --> Output Class Initialized
INFO - 2018-07-18 17:00:36 --> Security Class Initialized
DEBUG - 2018-07-18 17:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-18 17:00:36 --> CSRF cookie sent
INFO - 2018-07-18 17:00:36 --> Input Class Initialized
INFO - 2018-07-18 17:00:36 --> Language Class Initialized
ERROR - 2018-07-18 17:00:36 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-18 17:30:19 --> Config Class Initialized
INFO - 2018-07-18 17:30:19 --> Hooks Class Initialized
DEBUG - 2018-07-18 17:30:19 --> UTF-8 Support Enabled
INFO - 2018-07-18 17:30:19 --> Utf8 Class Initialized
INFO - 2018-07-18 17:30:19 --> URI Class Initialized
INFO - 2018-07-18 17:30:19 --> Router Class Initialized
INFO - 2018-07-18 17:30:19 --> Output Class Initialized
INFO - 2018-07-18 17:30:19 --> Security Class Initialized
DEBUG - 2018-07-18 17:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-18 17:30:19 --> CSRF cookie sent
INFO - 2018-07-18 17:30:19 --> Input Class Initialized
INFO - 2018-07-18 17:30:19 --> Language Class Initialized
ERROR - 2018-07-18 17:30:19 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-18 17:41:21 --> Config Class Initialized
INFO - 2018-07-18 17:41:21 --> Hooks Class Initialized
DEBUG - 2018-07-18 17:41:21 --> UTF-8 Support Enabled
INFO - 2018-07-18 17:41:21 --> Utf8 Class Initialized
INFO - 2018-07-18 17:41:21 --> URI Class Initialized
DEBUG - 2018-07-18 17:41:21 --> No URI present. Default controller set.
INFO - 2018-07-18 17:41:21 --> Router Class Initialized
INFO - 2018-07-18 17:41:21 --> Output Class Initialized
INFO - 2018-07-18 17:41:21 --> Security Class Initialized
DEBUG - 2018-07-18 17:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-18 17:41:21 --> CSRF cookie sent
INFO - 2018-07-18 17:41:21 --> Input Class Initialized
INFO - 2018-07-18 17:41:21 --> Language Class Initialized
INFO - 2018-07-18 17:41:21 --> Loader Class Initialized
INFO - 2018-07-18 17:41:21 --> Helper loaded: url_helper
INFO - 2018-07-18 17:41:21 --> Helper loaded: form_helper
INFO - 2018-07-18 17:41:21 --> Helper loaded: language_helper
DEBUG - 2018-07-18 17:41:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-18 17:41:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-18 17:41:21 --> User Agent Class Initialized
INFO - 2018-07-18 17:41:21 --> Controller Class Initialized
INFO - 2018-07-18 17:41:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-18 17:41:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-18 17:41:21 --> Pixel_Model class loaded
INFO - 2018-07-18 17:41:21 --> Database Driver Class Initialized
INFO - 2018-07-18 17:41:21 --> Model "QuestionsModel" initialized
INFO - 2018-07-18 17:41:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-18 17:41:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-18 17:41:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-18 17:41:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-18 17:41:21 --> Final output sent to browser
DEBUG - 2018-07-18 17:41:21 --> Total execution time: 0.0339
INFO - 2018-07-18 17:41:22 --> Config Class Initialized
INFO - 2018-07-18 17:41:22 --> Hooks Class Initialized
DEBUG - 2018-07-18 17:41:23 --> UTF-8 Support Enabled
INFO - 2018-07-18 17:41:23 --> Utf8 Class Initialized
INFO - 2018-07-18 17:41:23 --> URI Class Initialized
DEBUG - 2018-07-18 17:41:23 --> No URI present. Default controller set.
INFO - 2018-07-18 17:41:23 --> Router Class Initialized
INFO - 2018-07-18 17:41:23 --> Output Class Initialized
INFO - 2018-07-18 17:41:23 --> Security Class Initialized
DEBUG - 2018-07-18 17:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-18 17:41:23 --> CSRF cookie sent
INFO - 2018-07-18 17:41:23 --> Input Class Initialized
INFO - 2018-07-18 17:41:23 --> Language Class Initialized
INFO - 2018-07-18 17:41:23 --> Loader Class Initialized
INFO - 2018-07-18 17:41:23 --> Helper loaded: url_helper
INFO - 2018-07-18 17:41:23 --> Helper loaded: form_helper
INFO - 2018-07-18 17:41:23 --> Helper loaded: language_helper
DEBUG - 2018-07-18 17:41:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-18 17:41:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-18 17:41:23 --> User Agent Class Initialized
INFO - 2018-07-18 17:41:23 --> Controller Class Initialized
INFO - 2018-07-18 17:41:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-18 17:41:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-18 17:41:23 --> Pixel_Model class loaded
INFO - 2018-07-18 17:41:23 --> Database Driver Class Initialized
INFO - 2018-07-18 17:41:23 --> Model "QuestionsModel" initialized
INFO - 2018-07-18 17:41:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-18 17:41:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-18 17:41:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-18 17:41:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-18 17:41:23 --> Final output sent to browser
DEBUG - 2018-07-18 17:41:23 --> Total execution time: 0.0465
INFO - 2018-07-18 17:41:23 --> Config Class Initialized
INFO - 2018-07-18 17:41:23 --> Hooks Class Initialized
DEBUG - 2018-07-18 17:41:23 --> UTF-8 Support Enabled
INFO - 2018-07-18 17:41:23 --> Utf8 Class Initialized
INFO - 2018-07-18 17:41:23 --> URI Class Initialized
DEBUG - 2018-07-18 17:41:23 --> No URI present. Default controller set.
INFO - 2018-07-18 17:41:23 --> Router Class Initialized
INFO - 2018-07-18 17:41:23 --> Output Class Initialized
INFO - 2018-07-18 17:41:23 --> Security Class Initialized
DEBUG - 2018-07-18 17:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-18 17:41:23 --> CSRF cookie sent
INFO - 2018-07-18 17:41:23 --> Input Class Initialized
INFO - 2018-07-18 17:41:23 --> Language Class Initialized
INFO - 2018-07-18 17:41:23 --> Loader Class Initialized
INFO - 2018-07-18 17:41:23 --> Helper loaded: url_helper
INFO - 2018-07-18 17:41:23 --> Helper loaded: form_helper
INFO - 2018-07-18 17:41:23 --> Helper loaded: language_helper
DEBUG - 2018-07-18 17:41:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-18 17:41:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-18 17:41:23 --> User Agent Class Initialized
INFO - 2018-07-18 17:41:23 --> Controller Class Initialized
INFO - 2018-07-18 17:41:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-18 17:41:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-18 17:41:23 --> Pixel_Model class loaded
INFO - 2018-07-18 17:41:23 --> Database Driver Class Initialized
INFO - 2018-07-18 17:41:23 --> Model "QuestionsModel" initialized
INFO - 2018-07-18 17:41:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-18 17:41:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-18 17:41:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-18 17:41:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-18 17:41:23 --> Final output sent to browser
DEBUG - 2018-07-18 17:41:23 --> Total execution time: 0.0374
INFO - 2018-07-18 17:41:24 --> Config Class Initialized
INFO - 2018-07-18 17:41:24 --> Hooks Class Initialized
DEBUG - 2018-07-18 17:41:24 --> UTF-8 Support Enabled
INFO - 2018-07-18 17:41:24 --> Utf8 Class Initialized
INFO - 2018-07-18 17:41:24 --> URI Class Initialized
INFO - 2018-07-18 17:41:24 --> Router Class Initialized
INFO - 2018-07-18 17:41:24 --> Output Class Initialized
INFO - 2018-07-18 17:41:24 --> Security Class Initialized
DEBUG - 2018-07-18 17:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-18 17:41:24 --> CSRF cookie sent
INFO - 2018-07-18 17:41:24 --> Input Class Initialized
INFO - 2018-07-18 17:41:24 --> Language Class Initialized
ERROR - 2018-07-18 17:41:24 --> 404 Page Not Found: 405shtml/index
INFO - 2018-07-18 17:41:34 --> Config Class Initialized
INFO - 2018-07-18 17:41:34 --> Hooks Class Initialized
DEBUG - 2018-07-18 17:41:34 --> UTF-8 Support Enabled
INFO - 2018-07-18 17:41:34 --> Utf8 Class Initialized
INFO - 2018-07-18 17:41:34 --> URI Class Initialized
DEBUG - 2018-07-18 17:41:34 --> No URI present. Default controller set.
INFO - 2018-07-18 17:41:34 --> Router Class Initialized
INFO - 2018-07-18 17:41:34 --> Output Class Initialized
INFO - 2018-07-18 17:41:34 --> Security Class Initialized
DEBUG - 2018-07-18 17:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-18 17:41:34 --> CSRF cookie sent
INFO - 2018-07-18 17:41:34 --> Input Class Initialized
INFO - 2018-07-18 17:41:34 --> Language Class Initialized
INFO - 2018-07-18 17:41:34 --> Loader Class Initialized
INFO - 2018-07-18 17:41:34 --> Helper loaded: url_helper
INFO - 2018-07-18 17:41:34 --> Helper loaded: form_helper
INFO - 2018-07-18 17:41:34 --> Helper loaded: language_helper
DEBUG - 2018-07-18 17:41:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-18 17:41:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-18 17:41:34 --> User Agent Class Initialized
INFO - 2018-07-18 17:41:34 --> Controller Class Initialized
INFO - 2018-07-18 17:41:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-18 17:41:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-18 17:41:34 --> Pixel_Model class loaded
INFO - 2018-07-18 17:41:34 --> Database Driver Class Initialized
INFO - 2018-07-18 17:41:34 --> Model "QuestionsModel" initialized
INFO - 2018-07-18 17:41:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-18 17:41:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-18 17:41:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-18 17:41:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-18 17:41:34 --> Final output sent to browser
DEBUG - 2018-07-18 17:41:34 --> Total execution time: 0.0341
INFO - 2018-07-18 17:41:35 --> Config Class Initialized
INFO - 2018-07-18 17:41:35 --> Hooks Class Initialized
DEBUG - 2018-07-18 17:41:35 --> UTF-8 Support Enabled
INFO - 2018-07-18 17:41:35 --> Utf8 Class Initialized
INFO - 2018-07-18 17:41:35 --> URI Class Initialized
INFO - 2018-07-18 17:41:35 --> Router Class Initialized
INFO - 2018-07-18 17:41:35 --> Output Class Initialized
INFO - 2018-07-18 17:41:35 --> Security Class Initialized
DEBUG - 2018-07-18 17:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-18 17:41:35 --> CSRF cookie sent
INFO - 2018-07-18 17:41:35 --> Input Class Initialized
INFO - 2018-07-18 17:41:35 --> Language Class Initialized
ERROR - 2018-07-18 17:41:35 --> 404 Page Not Found: 404testpage4525d2fdc/index
INFO - 2018-07-18 17:41:35 --> Config Class Initialized
INFO - 2018-07-18 17:41:35 --> Hooks Class Initialized
DEBUG - 2018-07-18 17:41:35 --> UTF-8 Support Enabled
INFO - 2018-07-18 17:41:35 --> Utf8 Class Initialized
INFO - 2018-07-18 17:41:35 --> URI Class Initialized
INFO - 2018-07-18 17:41:35 --> Router Class Initialized
INFO - 2018-07-18 17:41:35 --> Output Class Initialized
INFO - 2018-07-18 17:41:35 --> Security Class Initialized
DEBUG - 2018-07-18 17:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-18 17:41:35 --> CSRF cookie sent
INFO - 2018-07-18 17:41:35 --> Input Class Initialized
INFO - 2018-07-18 17:41:35 --> Language Class Initialized
ERROR - 2018-07-18 17:41:35 --> 404 Page Not Found: 404javascriptjs/index
INFO - 2018-07-18 17:41:36 --> Config Class Initialized
INFO - 2018-07-18 17:41:36 --> Hooks Class Initialized
DEBUG - 2018-07-18 17:41:36 --> UTF-8 Support Enabled
INFO - 2018-07-18 17:41:36 --> Utf8 Class Initialized
INFO - 2018-07-18 17:41:36 --> URI Class Initialized
INFO - 2018-07-18 17:41:36 --> Router Class Initialized
INFO - 2018-07-18 17:41:36 --> Output Class Initialized
INFO - 2018-07-18 17:41:36 --> Security Class Initialized
DEBUG - 2018-07-18 17:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-18 17:41:36 --> CSRF cookie sent
INFO - 2018-07-18 17:41:36 --> Input Class Initialized
INFO - 2018-07-18 17:41:36 --> Language Class Initialized
INFO - 2018-07-18 17:41:36 --> Loader Class Initialized
INFO - 2018-07-18 17:41:36 --> Helper loaded: url_helper
INFO - 2018-07-18 17:41:36 --> Helper loaded: form_helper
INFO - 2018-07-18 17:41:36 --> Helper loaded: language_helper
DEBUG - 2018-07-18 17:41:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-18 17:41:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-18 17:41:36 --> User Agent Class Initialized
INFO - 2018-07-18 17:41:36 --> Controller Class Initialized
INFO - 2018-07-18 17:41:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-18 17:41:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-18 17:41:36 --> Pixel_Model class loaded
INFO - 2018-07-18 17:41:36 --> Database Driver Class Initialized
INFO - 2018-07-18 17:41:36 --> Model "QuestionsModel" initialized
INFO - 2018-07-18 17:41:36 --> Config Class Initialized
INFO - 2018-07-18 17:41:36 --> Hooks Class Initialized
DEBUG - 2018-07-18 17:41:36 --> UTF-8 Support Enabled
INFO - 2018-07-18 17:41:36 --> Utf8 Class Initialized
INFO - 2018-07-18 17:41:36 --> URI Class Initialized
INFO - 2018-07-18 17:41:36 --> Router Class Initialized
INFO - 2018-07-18 17:41:36 --> Output Class Initialized
INFO - 2018-07-18 17:41:36 --> Security Class Initialized
DEBUG - 2018-07-18 17:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-18 17:41:36 --> CSRF cookie sent
INFO - 2018-07-18 17:41:36 --> Input Class Initialized
INFO - 2018-07-18 17:41:36 --> Language Class Initialized
INFO - 2018-07-18 17:41:36 --> Loader Class Initialized
INFO - 2018-07-18 17:41:36 --> Helper loaded: url_helper
INFO - 2018-07-18 17:41:36 --> Helper loaded: form_helper
INFO - 2018-07-18 17:41:36 --> Helper loaded: language_helper
DEBUG - 2018-07-18 17:41:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-18 17:41:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-18 17:41:36 --> User Agent Class Initialized
INFO - 2018-07-18 17:41:36 --> Controller Class Initialized
INFO - 2018-07-18 17:41:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-18 17:41:36 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-18 17:41:36 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-18 17:41:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-18 17:41:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-18 17:41:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-18 17:41:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-18 17:41:36 --> Could not find the language line "req_email"
INFO - 2018-07-18 17:41:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-18 17:41:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-18 17:41:36 --> Final output sent to browser
DEBUG - 2018-07-18 17:41:36 --> Total execution time: 0.0210
INFO - 2018-07-18 17:41:36 --> Config Class Initialized
INFO - 2018-07-18 17:41:36 --> Hooks Class Initialized
DEBUG - 2018-07-18 17:41:36 --> UTF-8 Support Enabled
INFO - 2018-07-18 17:41:36 --> Utf8 Class Initialized
INFO - 2018-07-18 17:41:36 --> URI Class Initialized
INFO - 2018-07-18 17:41:36 --> Router Class Initialized
INFO - 2018-07-18 17:41:36 --> Output Class Initialized
INFO - 2018-07-18 17:41:36 --> Security Class Initialized
DEBUG - 2018-07-18 17:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-18 17:41:36 --> CSRF cookie sent
INFO - 2018-07-18 17:41:36 --> Input Class Initialized
INFO - 2018-07-18 17:41:36 --> Language Class Initialized
INFO - 2018-07-18 17:41:36 --> Loader Class Initialized
INFO - 2018-07-18 17:41:36 --> Helper loaded: url_helper
INFO - 2018-07-18 17:41:36 --> Helper loaded: form_helper
INFO - 2018-07-18 17:41:36 --> Helper loaded: language_helper
DEBUG - 2018-07-18 17:41:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-18 17:41:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-18 17:41:36 --> User Agent Class Initialized
INFO - 2018-07-18 17:41:36 --> Controller Class Initialized
INFO - 2018-07-18 17:41:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-18 17:41:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-18 17:41:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-18 17:41:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-18 17:41:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-18 17:41:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-18 17:41:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-07-18 17:41:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-18 17:41:36 --> Final output sent to browser
DEBUG - 2018-07-18 17:41:36 --> Total execution time: 0.0285
INFO - 2018-07-18 17:41:37 --> Config Class Initialized
INFO - 2018-07-18 17:41:37 --> Hooks Class Initialized
DEBUG - 2018-07-18 17:41:37 --> UTF-8 Support Enabled
INFO - 2018-07-18 17:41:37 --> Utf8 Class Initialized
INFO - 2018-07-18 17:41:37 --> URI Class Initialized
INFO - 2018-07-18 17:41:37 --> Router Class Initialized
INFO - 2018-07-18 17:41:37 --> Output Class Initialized
INFO - 2018-07-18 17:41:37 --> Security Class Initialized
DEBUG - 2018-07-18 17:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-18 17:41:37 --> CSRF cookie sent
INFO - 2018-07-18 17:41:37 --> Input Class Initialized
INFO - 2018-07-18 17:41:37 --> Language Class Initialized
INFO - 2018-07-18 17:41:37 --> Loader Class Initialized
INFO - 2018-07-18 17:41:37 --> Helper loaded: url_helper
INFO - 2018-07-18 17:41:37 --> Helper loaded: form_helper
INFO - 2018-07-18 17:41:37 --> Helper loaded: language_helper
DEBUG - 2018-07-18 17:41:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-18 17:41:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-18 17:41:37 --> User Agent Class Initialized
INFO - 2018-07-18 17:41:37 --> Controller Class Initialized
INFO - 2018-07-18 17:41:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-18 17:41:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-18 17:41:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-18 17:41:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-18 17:41:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-18 17:41:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-18 17:41:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-07-18 17:41:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-18 17:41:37 --> Final output sent to browser
DEBUG - 2018-07-18 17:41:37 --> Total execution time: 0.0414
INFO - 2018-07-18 17:41:38 --> Config Class Initialized
INFO - 2018-07-18 17:41:38 --> Hooks Class Initialized
DEBUG - 2018-07-18 17:41:38 --> UTF-8 Support Enabled
INFO - 2018-07-18 17:41:38 --> Utf8 Class Initialized
INFO - 2018-07-18 17:41:38 --> URI Class Initialized
INFO - 2018-07-18 17:41:38 --> Router Class Initialized
INFO - 2018-07-18 17:41:38 --> Output Class Initialized
INFO - 2018-07-18 17:41:38 --> Security Class Initialized
DEBUG - 2018-07-18 17:41:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-18 17:41:38 --> CSRF cookie sent
INFO - 2018-07-18 17:41:38 --> Input Class Initialized
INFO - 2018-07-18 17:41:38 --> Language Class Initialized
INFO - 2018-07-18 17:41:38 --> Loader Class Initialized
INFO - 2018-07-18 17:41:38 --> Helper loaded: url_helper
INFO - 2018-07-18 17:41:38 --> Helper loaded: form_helper
INFO - 2018-07-18 17:41:38 --> Helper loaded: language_helper
DEBUG - 2018-07-18 17:41:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-18 17:41:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-18 17:41:38 --> User Agent Class Initialized
INFO - 2018-07-18 17:41:38 --> Controller Class Initialized
INFO - 2018-07-18 17:41:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-18 17:41:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-18 17:41:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-18 17:41:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-18 17:41:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-18 17:41:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-18 17:41:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-07-18 17:41:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-18 17:41:38 --> Final output sent to browser
DEBUG - 2018-07-18 17:41:38 --> Total execution time: 0.0247
INFO - 2018-07-18 17:41:38 --> Config Class Initialized
INFO - 2018-07-18 17:41:38 --> Hooks Class Initialized
DEBUG - 2018-07-18 17:41:38 --> UTF-8 Support Enabled
INFO - 2018-07-18 17:41:38 --> Utf8 Class Initialized
INFO - 2018-07-18 17:41:38 --> URI Class Initialized
INFO - 2018-07-18 17:41:38 --> Router Class Initialized
INFO - 2018-07-18 17:41:38 --> Output Class Initialized
INFO - 2018-07-18 17:41:38 --> Security Class Initialized
DEBUG - 2018-07-18 17:41:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-18 17:41:38 --> CSRF cookie sent
INFO - 2018-07-18 17:41:38 --> Input Class Initialized
INFO - 2018-07-18 17:41:38 --> Language Class Initialized
INFO - 2018-07-18 17:41:38 --> Loader Class Initialized
INFO - 2018-07-18 17:41:38 --> Helper loaded: url_helper
INFO - 2018-07-18 17:41:38 --> Helper loaded: form_helper
INFO - 2018-07-18 17:41:38 --> Helper loaded: language_helper
DEBUG - 2018-07-18 17:41:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-18 17:41:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-18 17:41:38 --> User Agent Class Initialized
INFO - 2018-07-18 17:41:38 --> Controller Class Initialized
INFO - 2018-07-18 17:41:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-18 17:41:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-18 17:41:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-18 17:41:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-18 17:41:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-18 17:41:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-18 17:41:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-07-18 17:41:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-18 17:41:38 --> Final output sent to browser
DEBUG - 2018-07-18 17:41:38 --> Total execution time: 0.0261
INFO - 2018-07-18 17:41:39 --> Config Class Initialized
INFO - 2018-07-18 17:41:39 --> Hooks Class Initialized
DEBUG - 2018-07-18 17:41:39 --> UTF-8 Support Enabled
INFO - 2018-07-18 17:41:39 --> Utf8 Class Initialized
INFO - 2018-07-18 17:41:39 --> URI Class Initialized
INFO - 2018-07-18 17:41:39 --> Router Class Initialized
INFO - 2018-07-18 17:41:39 --> Output Class Initialized
INFO - 2018-07-18 17:41:39 --> Security Class Initialized
DEBUG - 2018-07-18 17:41:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-18 17:41:39 --> CSRF cookie sent
INFO - 2018-07-18 17:41:39 --> Input Class Initialized
INFO - 2018-07-18 17:41:39 --> Language Class Initialized
INFO - 2018-07-18 17:41:39 --> Loader Class Initialized
INFO - 2018-07-18 17:41:39 --> Helper loaded: url_helper
INFO - 2018-07-18 17:41:39 --> Helper loaded: form_helper
INFO - 2018-07-18 17:41:39 --> Helper loaded: language_helper
DEBUG - 2018-07-18 17:41:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-18 17:41:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-18 17:41:39 --> User Agent Class Initialized
INFO - 2018-07-18 17:41:39 --> Controller Class Initialized
INFO - 2018-07-18 17:41:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-18 17:41:39 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-18 17:41:39 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-18 17:41:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-18 17:41:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-18 17:41:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-18 17:41:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-18 17:41:39 --> Could not find the language line "req_email"
INFO - 2018-07-18 17:41:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-18 17:41:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-18 17:41:39 --> Final output sent to browser
DEBUG - 2018-07-18 17:41:39 --> Total execution time: 0.0274
INFO - 2018-07-18 17:41:39 --> Config Class Initialized
INFO - 2018-07-18 17:41:39 --> Hooks Class Initialized
DEBUG - 2018-07-18 17:41:39 --> UTF-8 Support Enabled
INFO - 2018-07-18 17:41:39 --> Utf8 Class Initialized
INFO - 2018-07-18 17:41:39 --> URI Class Initialized
INFO - 2018-07-18 17:41:39 --> Router Class Initialized
INFO - 2018-07-18 17:41:39 --> Output Class Initialized
INFO - 2018-07-18 17:41:39 --> Security Class Initialized
DEBUG - 2018-07-18 17:41:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-18 17:41:39 --> CSRF cookie sent
INFO - 2018-07-18 17:41:39 --> Input Class Initialized
INFO - 2018-07-18 17:41:39 --> Language Class Initialized
INFO - 2018-07-18 17:41:39 --> Loader Class Initialized
INFO - 2018-07-18 17:41:39 --> Helper loaded: url_helper
INFO - 2018-07-18 17:41:39 --> Helper loaded: form_helper
INFO - 2018-07-18 17:41:39 --> Helper loaded: language_helper
DEBUG - 2018-07-18 17:41:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-18 17:41:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-18 17:41:39 --> User Agent Class Initialized
INFO - 2018-07-18 17:41:39 --> Controller Class Initialized
INFO - 2018-07-18 17:41:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-18 17:41:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-18 17:41:39 --> Pixel_Model class loaded
INFO - 2018-07-18 17:41:39 --> Database Driver Class Initialized
INFO - 2018-07-18 17:41:39 --> Model "QuestionsModel" initialized
INFO - 2018-07-18 17:41:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-18 17:41:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-18 17:41:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-18 17:41:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-18 17:41:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/buy_gift.php
INFO - 2018-07-18 17:41:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-18 17:41:39 --> Final output sent to browser
DEBUG - 2018-07-18 17:41:39 --> Total execution time: 0.0422
INFO - 2018-07-18 17:52:55 --> Config Class Initialized
INFO - 2018-07-18 17:52:55 --> Hooks Class Initialized
DEBUG - 2018-07-18 17:52:55 --> UTF-8 Support Enabled
INFO - 2018-07-18 17:52:55 --> Utf8 Class Initialized
INFO - 2018-07-18 17:52:55 --> URI Class Initialized
DEBUG - 2018-07-18 17:52:55 --> No URI present. Default controller set.
INFO - 2018-07-18 17:52:55 --> Router Class Initialized
INFO - 2018-07-18 17:52:55 --> Output Class Initialized
INFO - 2018-07-18 17:52:55 --> Security Class Initialized
DEBUG - 2018-07-18 17:52:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-18 17:52:55 --> CSRF cookie sent
INFO - 2018-07-18 17:52:55 --> Input Class Initialized
INFO - 2018-07-18 17:52:55 --> Language Class Initialized
INFO - 2018-07-18 17:52:55 --> Loader Class Initialized
INFO - 2018-07-18 17:52:55 --> Helper loaded: url_helper
INFO - 2018-07-18 17:52:55 --> Helper loaded: form_helper
INFO - 2018-07-18 17:52:55 --> Helper loaded: language_helper
DEBUG - 2018-07-18 17:52:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-18 17:52:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-18 17:52:55 --> User Agent Class Initialized
INFO - 2018-07-18 17:52:55 --> Controller Class Initialized
INFO - 2018-07-18 17:52:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-18 17:52:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-18 17:52:55 --> Pixel_Model class loaded
INFO - 2018-07-18 17:52:55 --> Database Driver Class Initialized
INFO - 2018-07-18 17:52:55 --> Model "QuestionsModel" initialized
INFO - 2018-07-18 17:52:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-18 17:52:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-18 17:52:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-18 17:52:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-18 17:52:55 --> Final output sent to browser
DEBUG - 2018-07-18 17:52:55 --> Total execution time: 0.0344
INFO - 2018-07-18 18:10:00 --> Config Class Initialized
INFO - 2018-07-18 18:10:00 --> Hooks Class Initialized
DEBUG - 2018-07-18 18:10:00 --> UTF-8 Support Enabled
INFO - 2018-07-18 18:10:00 --> Utf8 Class Initialized
INFO - 2018-07-18 18:10:00 --> URI Class Initialized
DEBUG - 2018-07-18 18:10:00 --> No URI present. Default controller set.
INFO - 2018-07-18 18:10:00 --> Router Class Initialized
INFO - 2018-07-18 18:10:00 --> Output Class Initialized
INFO - 2018-07-18 18:10:00 --> Security Class Initialized
DEBUG - 2018-07-18 18:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-18 18:10:00 --> CSRF cookie sent
INFO - 2018-07-18 18:10:00 --> Input Class Initialized
INFO - 2018-07-18 18:10:00 --> Language Class Initialized
INFO - 2018-07-18 18:10:00 --> Loader Class Initialized
INFO - 2018-07-18 18:10:00 --> Helper loaded: url_helper
INFO - 2018-07-18 18:10:00 --> Helper loaded: form_helper
INFO - 2018-07-18 18:10:00 --> Helper loaded: language_helper
DEBUG - 2018-07-18 18:10:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-18 18:10:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-18 18:10:00 --> User Agent Class Initialized
INFO - 2018-07-18 18:10:00 --> Controller Class Initialized
INFO - 2018-07-18 18:10:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-18 18:10:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-18 18:10:00 --> Pixel_Model class loaded
INFO - 2018-07-18 18:10:00 --> Database Driver Class Initialized
INFO - 2018-07-18 18:10:00 --> Model "QuestionsModel" initialized
INFO - 2018-07-18 18:10:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-18 18:10:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-18 18:10:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-18 18:10:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-18 18:10:00 --> Final output sent to browser
DEBUG - 2018-07-18 18:10:00 --> Total execution time: 0.0328
INFO - 2018-07-18 18:38:41 --> Config Class Initialized
INFO - 2018-07-18 18:38:41 --> Hooks Class Initialized
DEBUG - 2018-07-18 18:38:41 --> UTF-8 Support Enabled
INFO - 2018-07-18 18:38:41 --> Utf8 Class Initialized
INFO - 2018-07-18 18:38:41 --> URI Class Initialized
DEBUG - 2018-07-18 18:38:41 --> No URI present. Default controller set.
INFO - 2018-07-18 18:38:41 --> Router Class Initialized
INFO - 2018-07-18 18:38:41 --> Output Class Initialized
INFO - 2018-07-18 18:38:41 --> Security Class Initialized
DEBUG - 2018-07-18 18:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-18 18:38:41 --> CSRF cookie sent
INFO - 2018-07-18 18:38:41 --> Input Class Initialized
INFO - 2018-07-18 18:38:41 --> Language Class Initialized
INFO - 2018-07-18 18:38:41 --> Loader Class Initialized
INFO - 2018-07-18 18:38:41 --> Helper loaded: url_helper
INFO - 2018-07-18 18:38:41 --> Helper loaded: form_helper
INFO - 2018-07-18 18:38:41 --> Helper loaded: language_helper
DEBUG - 2018-07-18 18:38:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-18 18:38:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-18 18:38:41 --> User Agent Class Initialized
INFO - 2018-07-18 18:38:42 --> Controller Class Initialized
INFO - 2018-07-18 18:38:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-18 18:38:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-18 18:38:42 --> Pixel_Model class loaded
INFO - 2018-07-18 18:38:42 --> Database Driver Class Initialized
INFO - 2018-07-18 18:38:42 --> Model "QuestionsModel" initialized
INFO - 2018-07-18 18:38:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-18 18:38:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-18 18:38:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-18 18:38:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-18 18:38:42 --> Final output sent to browser
DEBUG - 2018-07-18 18:38:42 --> Total execution time: 0.0356
INFO - 2018-07-18 18:38:56 --> Config Class Initialized
INFO - 2018-07-18 18:38:56 --> Hooks Class Initialized
DEBUG - 2018-07-18 18:38:56 --> UTF-8 Support Enabled
INFO - 2018-07-18 18:38:56 --> Utf8 Class Initialized
INFO - 2018-07-18 18:38:56 --> URI Class Initialized
DEBUG - 2018-07-18 18:38:56 --> No URI present. Default controller set.
INFO - 2018-07-18 18:38:56 --> Router Class Initialized
INFO - 2018-07-18 18:38:56 --> Output Class Initialized
INFO - 2018-07-18 18:38:56 --> Security Class Initialized
DEBUG - 2018-07-18 18:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-18 18:38:56 --> CSRF cookie sent
INFO - 2018-07-18 18:38:56 --> Input Class Initialized
INFO - 2018-07-18 18:38:56 --> Language Class Initialized
INFO - 2018-07-18 18:38:56 --> Loader Class Initialized
INFO - 2018-07-18 18:38:56 --> Helper loaded: url_helper
INFO - 2018-07-18 18:38:56 --> Helper loaded: form_helper
INFO - 2018-07-18 18:38:56 --> Helper loaded: language_helper
DEBUG - 2018-07-18 18:38:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-18 18:38:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-18 18:38:56 --> User Agent Class Initialized
INFO - 2018-07-18 18:38:56 --> Controller Class Initialized
INFO - 2018-07-18 18:38:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-18 18:38:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-18 18:38:56 --> Pixel_Model class loaded
INFO - 2018-07-18 18:38:56 --> Database Driver Class Initialized
INFO - 2018-07-18 18:38:56 --> Model "QuestionsModel" initialized
INFO - 2018-07-18 18:38:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-18 18:38:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-18 18:38:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-18 18:38:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-18 18:38:56 --> Final output sent to browser
DEBUG - 2018-07-18 18:38:56 --> Total execution time: 0.0387
INFO - 2018-07-18 18:39:02 --> Config Class Initialized
INFO - 2018-07-18 18:39:02 --> Hooks Class Initialized
DEBUG - 2018-07-18 18:39:02 --> UTF-8 Support Enabled
INFO - 2018-07-18 18:39:02 --> Utf8 Class Initialized
INFO - 2018-07-18 18:39:02 --> URI Class Initialized
INFO - 2018-07-18 18:39:02 --> Router Class Initialized
INFO - 2018-07-18 18:39:02 --> Output Class Initialized
INFO - 2018-07-18 18:39:02 --> Security Class Initialized
DEBUG - 2018-07-18 18:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-18 18:39:02 --> CSRF cookie sent
INFO - 2018-07-18 18:39:02 --> CSRF token verified
INFO - 2018-07-18 18:39:02 --> Input Class Initialized
INFO - 2018-07-18 18:39:02 --> Language Class Initialized
INFO - 2018-07-18 18:39:02 --> Loader Class Initialized
INFO - 2018-07-18 18:39:02 --> Helper loaded: url_helper
INFO - 2018-07-18 18:39:02 --> Helper loaded: form_helper
INFO - 2018-07-18 18:39:02 --> Helper loaded: language_helper
DEBUG - 2018-07-18 18:39:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-18 18:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-18 18:39:02 --> User Agent Class Initialized
INFO - 2018-07-18 18:39:02 --> Controller Class Initialized
INFO - 2018-07-18 18:39:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-18 18:39:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-18 18:39:02 --> Pixel_Model class loaded
INFO - 2018-07-18 18:39:02 --> Database Driver Class Initialized
INFO - 2018-07-18 18:39:02 --> Model "QuestionsModel" initialized
INFO - 2018-07-18 18:39:02 --> Config Class Initialized
INFO - 2018-07-18 18:39:02 --> Hooks Class Initialized
DEBUG - 2018-07-18 18:39:02 --> UTF-8 Support Enabled
INFO - 2018-07-18 18:39:02 --> Utf8 Class Initialized
INFO - 2018-07-18 18:39:02 --> URI Class Initialized
INFO - 2018-07-18 18:39:02 --> Router Class Initialized
INFO - 2018-07-18 18:39:02 --> Output Class Initialized
INFO - 2018-07-18 18:39:02 --> Security Class Initialized
DEBUG - 2018-07-18 18:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-18 18:39:02 --> CSRF cookie sent
INFO - 2018-07-18 18:39:02 --> Input Class Initialized
INFO - 2018-07-18 18:39:02 --> Language Class Initialized
INFO - 2018-07-18 18:39:02 --> Loader Class Initialized
INFO - 2018-07-18 18:39:02 --> Helper loaded: url_helper
INFO - 2018-07-18 18:39:02 --> Helper loaded: form_helper
INFO - 2018-07-18 18:39:02 --> Helper loaded: language_helper
DEBUG - 2018-07-18 18:39:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-18 18:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-18 18:39:02 --> User Agent Class Initialized
INFO - 2018-07-18 18:39:02 --> Controller Class Initialized
INFO - 2018-07-18 18:39:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-18 18:39:02 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-18 18:39:02 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-18 18:39:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-18 18:39:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-18 18:39:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-18 18:39:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-18 18:39:02 --> Could not find the language line "req_email"
INFO - 2018-07-18 18:39:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-18 18:39:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-18 18:39:02 --> Final output sent to browser
DEBUG - 2018-07-18 18:39:02 --> Total execution time: 0.0223
INFO - 2018-07-18 18:42:41 --> Config Class Initialized
INFO - 2018-07-18 18:42:41 --> Hooks Class Initialized
DEBUG - 2018-07-18 18:42:41 --> UTF-8 Support Enabled
INFO - 2018-07-18 18:42:41 --> Utf8 Class Initialized
INFO - 2018-07-18 18:42:41 --> URI Class Initialized
DEBUG - 2018-07-18 18:42:41 --> No URI present. Default controller set.
INFO - 2018-07-18 18:42:41 --> Router Class Initialized
INFO - 2018-07-18 18:42:41 --> Output Class Initialized
INFO - 2018-07-18 18:42:41 --> Security Class Initialized
DEBUG - 2018-07-18 18:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-18 18:42:41 --> CSRF cookie sent
INFO - 2018-07-18 18:42:41 --> Input Class Initialized
INFO - 2018-07-18 18:42:41 --> Language Class Initialized
INFO - 2018-07-18 18:42:41 --> Loader Class Initialized
INFO - 2018-07-18 18:42:41 --> Helper loaded: url_helper
INFO - 2018-07-18 18:42:41 --> Helper loaded: form_helper
INFO - 2018-07-18 18:42:41 --> Helper loaded: language_helper
DEBUG - 2018-07-18 18:42:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-18 18:42:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-18 18:42:41 --> User Agent Class Initialized
INFO - 2018-07-18 18:42:41 --> Controller Class Initialized
INFO - 2018-07-18 18:42:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-18 18:42:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-18 18:42:41 --> Config Class Initialized
INFO - 2018-07-18 18:42:41 --> Hooks Class Initialized
INFO - 2018-07-18 18:42:41 --> Pixel_Model class loaded
DEBUG - 2018-07-18 18:42:41 --> UTF-8 Support Enabled
INFO - 2018-07-18 18:42:41 --> Utf8 Class Initialized
INFO - 2018-07-18 18:42:41 --> URI Class Initialized
DEBUG - 2018-07-18 18:42:41 --> No URI present. Default controller set.
INFO - 2018-07-18 18:42:41 --> Router Class Initialized
INFO - 2018-07-18 18:42:41 --> Database Driver Class Initialized
INFO - 2018-07-18 18:42:41 --> Output Class Initialized
INFO - 2018-07-18 18:42:41 --> Security Class Initialized
DEBUG - 2018-07-18 18:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-18 18:42:41 --> CSRF cookie sent
INFO - 2018-07-18 18:42:41 --> Input Class Initialized
INFO - 2018-07-18 18:42:41 --> Language Class Initialized
INFO - 2018-07-18 18:42:41 --> Model "QuestionsModel" initialized
INFO - 2018-07-18 18:42:41 --> Loader Class Initialized
INFO - 2018-07-18 18:42:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-18 18:42:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-18 18:42:41 --> Helper loaded: url_helper
INFO - 2018-07-18 18:42:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-18 18:42:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-18 18:42:41 --> Final output sent to browser
DEBUG - 2018-07-18 18:42:41 --> Total execution time: 0.0355
INFO - 2018-07-18 18:42:41 --> Helper loaded: form_helper
INFO - 2018-07-18 18:42:41 --> Helper loaded: language_helper
DEBUG - 2018-07-18 18:42:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-18 18:42:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-18 18:42:41 --> User Agent Class Initialized
INFO - 2018-07-18 18:42:41 --> Controller Class Initialized
INFO - 2018-07-18 18:42:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-18 18:42:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-18 18:42:41 --> Pixel_Model class loaded
INFO - 2018-07-18 18:42:41 --> Database Driver Class Initialized
INFO - 2018-07-18 18:42:41 --> Model "QuestionsModel" initialized
INFO - 2018-07-18 18:42:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-18 18:42:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-18 18:42:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-18 18:42:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-18 18:42:41 --> Final output sent to browser
DEBUG - 2018-07-18 18:42:41 --> Total execution time: 0.0372
INFO - 2018-07-18 18:49:10 --> Config Class Initialized
INFO - 2018-07-18 18:49:10 --> Hooks Class Initialized
DEBUG - 2018-07-18 18:49:10 --> UTF-8 Support Enabled
INFO - 2018-07-18 18:49:10 --> Utf8 Class Initialized
INFO - 2018-07-18 18:49:10 --> URI Class Initialized
INFO - 2018-07-18 18:49:10 --> Router Class Initialized
INFO - 2018-07-18 18:49:10 --> Output Class Initialized
INFO - 2018-07-18 18:49:10 --> Security Class Initialized
DEBUG - 2018-07-18 18:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-18 18:49:10 --> CSRF cookie sent
INFO - 2018-07-18 18:49:10 --> Input Class Initialized
INFO - 2018-07-18 18:49:10 --> Language Class Initialized
INFO - 2018-07-18 18:49:10 --> Loader Class Initialized
INFO - 2018-07-18 18:49:10 --> Helper loaded: url_helper
INFO - 2018-07-18 18:49:10 --> Helper loaded: form_helper
INFO - 2018-07-18 18:49:10 --> Helper loaded: language_helper
DEBUG - 2018-07-18 18:49:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-18 18:49:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-18 18:49:10 --> User Agent Class Initialized
INFO - 2018-07-18 18:49:10 --> Controller Class Initialized
INFO - 2018-07-18 18:49:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-18 18:49:10 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-18 18:49:10 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-18 18:49:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-18 18:49:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-18 18:49:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-18 18:49:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-18 18:49:10 --> Could not find the language line "req_email"
INFO - 2018-07-18 18:49:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-18 18:49:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-18 18:49:10 --> Final output sent to browser
DEBUG - 2018-07-18 18:49:10 --> Total execution time: 0.0318
INFO - 2018-07-18 19:00:00 --> Config Class Initialized
INFO - 2018-07-18 19:00:00 --> Hooks Class Initialized
DEBUG - 2018-07-18 19:00:00 --> UTF-8 Support Enabled
INFO - 2018-07-18 19:00:00 --> Utf8 Class Initialized
INFO - 2018-07-18 19:00:00 --> URI Class Initialized
DEBUG - 2018-07-18 19:00:00 --> No URI present. Default controller set.
INFO - 2018-07-18 19:00:00 --> Router Class Initialized
INFO - 2018-07-18 19:00:00 --> Output Class Initialized
INFO - 2018-07-18 19:00:00 --> Security Class Initialized
DEBUG - 2018-07-18 19:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-18 19:00:00 --> CSRF cookie sent
INFO - 2018-07-18 19:00:00 --> Input Class Initialized
INFO - 2018-07-18 19:00:00 --> Language Class Initialized
INFO - 2018-07-18 19:00:00 --> Loader Class Initialized
INFO - 2018-07-18 19:00:00 --> Helper loaded: url_helper
INFO - 2018-07-18 19:00:00 --> Helper loaded: form_helper
INFO - 2018-07-18 19:00:00 --> Helper loaded: language_helper
DEBUG - 2018-07-18 19:00:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-18 19:00:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-18 19:00:00 --> User Agent Class Initialized
INFO - 2018-07-18 19:00:00 --> Controller Class Initialized
INFO - 2018-07-18 19:00:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-18 19:00:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-18 19:00:00 --> Pixel_Model class loaded
INFO - 2018-07-18 19:00:00 --> Database Driver Class Initialized
INFO - 2018-07-18 19:00:00 --> Model "QuestionsModel" initialized
INFO - 2018-07-18 19:00:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-18 19:00:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-18 19:00:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-18 19:00:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-18 19:00:00 --> Final output sent to browser
DEBUG - 2018-07-18 19:00:00 --> Total execution time: 0.0359
INFO - 2018-07-18 20:40:58 --> Config Class Initialized
INFO - 2018-07-18 20:40:58 --> Hooks Class Initialized
DEBUG - 2018-07-18 20:40:58 --> UTF-8 Support Enabled
INFO - 2018-07-18 20:40:58 --> Utf8 Class Initialized
INFO - 2018-07-18 20:40:58 --> URI Class Initialized
DEBUG - 2018-07-18 20:40:58 --> No URI present. Default controller set.
INFO - 2018-07-18 20:40:58 --> Router Class Initialized
INFO - 2018-07-18 20:40:58 --> Output Class Initialized
INFO - 2018-07-18 20:40:58 --> Security Class Initialized
DEBUG - 2018-07-18 20:40:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-18 20:40:58 --> CSRF cookie sent
INFO - 2018-07-18 20:40:58 --> Input Class Initialized
INFO - 2018-07-18 20:40:58 --> Language Class Initialized
INFO - 2018-07-18 20:40:58 --> Loader Class Initialized
INFO - 2018-07-18 20:40:58 --> Helper loaded: url_helper
INFO - 2018-07-18 20:40:58 --> Helper loaded: form_helper
INFO - 2018-07-18 20:40:58 --> Helper loaded: language_helper
DEBUG - 2018-07-18 20:40:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-18 20:40:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-18 20:40:58 --> User Agent Class Initialized
INFO - 2018-07-18 20:40:58 --> Controller Class Initialized
INFO - 2018-07-18 20:40:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-18 20:40:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-18 20:40:58 --> Pixel_Model class loaded
INFO - 2018-07-18 20:40:58 --> Database Driver Class Initialized
INFO - 2018-07-18 20:40:58 --> Model "QuestionsModel" initialized
INFO - 2018-07-18 20:40:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-18 20:40:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-18 20:40:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-18 20:40:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-18 20:40:58 --> Final output sent to browser
DEBUG - 2018-07-18 20:40:58 --> Total execution time: 0.0475
INFO - 2018-07-18 21:20:44 --> Config Class Initialized
INFO - 2018-07-18 21:20:44 --> Hooks Class Initialized
DEBUG - 2018-07-18 21:20:44 --> UTF-8 Support Enabled
INFO - 2018-07-18 21:20:44 --> Utf8 Class Initialized
INFO - 2018-07-18 21:20:44 --> URI Class Initialized
INFO - 2018-07-18 21:20:44 --> Router Class Initialized
INFO - 2018-07-18 21:20:44 --> Output Class Initialized
INFO - 2018-07-18 21:20:44 --> Security Class Initialized
DEBUG - 2018-07-18 21:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-18 21:20:44 --> CSRF cookie sent
INFO - 2018-07-18 21:20:44 --> Input Class Initialized
INFO - 2018-07-18 21:20:44 --> Language Class Initialized
ERROR - 2018-07-18 21:20:44 --> 404 Page Not Found: Admin/images

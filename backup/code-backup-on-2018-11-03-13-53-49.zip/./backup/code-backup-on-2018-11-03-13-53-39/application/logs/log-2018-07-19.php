<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-07-19 00:34:43 --> Config Class Initialized
INFO - 2018-07-19 00:34:43 --> Hooks Class Initialized
DEBUG - 2018-07-19 00:34:43 --> UTF-8 Support Enabled
INFO - 2018-07-19 00:34:43 --> Utf8 Class Initialized
INFO - 2018-07-19 00:34:43 --> URI Class Initialized
INFO - 2018-07-19 00:34:43 --> Router Class Initialized
INFO - 2018-07-19 00:34:43 --> Output Class Initialized
INFO - 2018-07-19 00:34:43 --> Security Class Initialized
DEBUG - 2018-07-19 00:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 00:34:43 --> CSRF cookie sent
INFO - 2018-07-19 00:34:43 --> Input Class Initialized
INFO - 2018-07-19 00:34:43 --> Language Class Initialized
ERROR - 2018-07-19 00:34:43 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-19 01:40:19 --> Config Class Initialized
INFO - 2018-07-19 01:40:19 --> Hooks Class Initialized
DEBUG - 2018-07-19 01:40:19 --> UTF-8 Support Enabled
INFO - 2018-07-19 01:40:19 --> Utf8 Class Initialized
INFO - 2018-07-19 01:40:19 --> URI Class Initialized
INFO - 2018-07-19 01:40:19 --> Router Class Initialized
INFO - 2018-07-19 01:40:19 --> Output Class Initialized
INFO - 2018-07-19 01:40:19 --> Security Class Initialized
DEBUG - 2018-07-19 01:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 01:40:19 --> CSRF cookie sent
INFO - 2018-07-19 01:40:19 --> Input Class Initialized
INFO - 2018-07-19 01:40:19 --> Language Class Initialized
ERROR - 2018-07-19 01:40:19 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-19 01:40:19 --> Config Class Initialized
INFO - 2018-07-19 01:40:19 --> Hooks Class Initialized
DEBUG - 2018-07-19 01:40:19 --> UTF-8 Support Enabled
INFO - 2018-07-19 01:40:19 --> Utf8 Class Initialized
INFO - 2018-07-19 01:40:19 --> URI Class Initialized
DEBUG - 2018-07-19 01:40:19 --> No URI present. Default controller set.
INFO - 2018-07-19 01:40:19 --> Router Class Initialized
INFO - 2018-07-19 01:40:19 --> Output Class Initialized
INFO - 2018-07-19 01:40:19 --> Security Class Initialized
DEBUG - 2018-07-19 01:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 01:40:19 --> CSRF cookie sent
INFO - 2018-07-19 01:40:19 --> Input Class Initialized
INFO - 2018-07-19 01:40:19 --> Language Class Initialized
INFO - 2018-07-19 01:40:19 --> Loader Class Initialized
INFO - 2018-07-19 01:40:19 --> Helper loaded: url_helper
INFO - 2018-07-19 01:40:19 --> Helper loaded: form_helper
INFO - 2018-07-19 01:40:19 --> Helper loaded: language_helper
DEBUG - 2018-07-19 01:40:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-19 01:40:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-19 01:40:19 --> User Agent Class Initialized
INFO - 2018-07-19 01:40:19 --> Controller Class Initialized
INFO - 2018-07-19 01:40:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-19 01:40:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-19 01:40:19 --> Pixel_Model class loaded
INFO - 2018-07-19 01:40:19 --> Database Driver Class Initialized
INFO - 2018-07-19 01:40:19 --> Model "QuestionsModel" initialized
INFO - 2018-07-19 01:40:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-19 01:40:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-19 01:40:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-19 01:40:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-19 01:40:19 --> Final output sent to browser
DEBUG - 2018-07-19 01:40:19 --> Total execution time: 0.0343
INFO - 2018-07-19 01:51:22 --> Config Class Initialized
INFO - 2018-07-19 01:51:22 --> Hooks Class Initialized
DEBUG - 2018-07-19 01:51:22 --> UTF-8 Support Enabled
INFO - 2018-07-19 01:51:22 --> Utf8 Class Initialized
INFO - 2018-07-19 01:51:22 --> URI Class Initialized
DEBUG - 2018-07-19 01:51:22 --> No URI present. Default controller set.
INFO - 2018-07-19 01:51:22 --> Router Class Initialized
INFO - 2018-07-19 01:51:22 --> Output Class Initialized
INFO - 2018-07-19 01:51:22 --> Security Class Initialized
DEBUG - 2018-07-19 01:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 01:51:22 --> CSRF cookie sent
INFO - 2018-07-19 01:51:22 --> Input Class Initialized
INFO - 2018-07-19 01:51:22 --> Language Class Initialized
INFO - 2018-07-19 01:51:22 --> Loader Class Initialized
INFO - 2018-07-19 01:51:22 --> Helper loaded: url_helper
INFO - 2018-07-19 01:51:22 --> Helper loaded: form_helper
INFO - 2018-07-19 01:51:22 --> Helper loaded: language_helper
DEBUG - 2018-07-19 01:51:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-19 01:51:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-19 01:51:22 --> User Agent Class Initialized
INFO - 2018-07-19 01:51:22 --> Controller Class Initialized
INFO - 2018-07-19 01:51:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-19 01:51:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-19 01:51:22 --> Pixel_Model class loaded
INFO - 2018-07-19 01:51:22 --> Database Driver Class Initialized
INFO - 2018-07-19 01:51:22 --> Model "QuestionsModel" initialized
INFO - 2018-07-19 01:51:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-19 01:51:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-19 01:51:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-19 01:51:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-19 01:51:22 --> Final output sent to browser
DEBUG - 2018-07-19 01:51:22 --> Total execution time: 0.0354
INFO - 2018-07-19 02:20:21 --> Config Class Initialized
INFO - 2018-07-19 02:20:21 --> Hooks Class Initialized
DEBUG - 2018-07-19 02:20:21 --> UTF-8 Support Enabled
INFO - 2018-07-19 02:20:21 --> Utf8 Class Initialized
INFO - 2018-07-19 02:20:21 --> URI Class Initialized
INFO - 2018-07-19 02:20:21 --> Router Class Initialized
INFO - 2018-07-19 02:20:21 --> Output Class Initialized
INFO - 2018-07-19 02:20:21 --> Security Class Initialized
DEBUG - 2018-07-19 02:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 02:20:21 --> CSRF cookie sent
INFO - 2018-07-19 02:20:21 --> Input Class Initialized
INFO - 2018-07-19 02:20:21 --> Language Class Initialized
ERROR - 2018-07-19 02:20:21 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-19 02:20:24 --> Config Class Initialized
INFO - 2018-07-19 02:20:24 --> Hooks Class Initialized
DEBUG - 2018-07-19 02:20:24 --> UTF-8 Support Enabled
INFO - 2018-07-19 02:20:24 --> Utf8 Class Initialized
INFO - 2018-07-19 02:20:24 --> URI Class Initialized
DEBUG - 2018-07-19 02:20:24 --> No URI present. Default controller set.
INFO - 2018-07-19 02:20:24 --> Router Class Initialized
INFO - 2018-07-19 02:20:24 --> Output Class Initialized
INFO - 2018-07-19 02:20:24 --> Security Class Initialized
DEBUG - 2018-07-19 02:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 02:20:24 --> CSRF cookie sent
INFO - 2018-07-19 02:20:24 --> Input Class Initialized
INFO - 2018-07-19 02:20:24 --> Language Class Initialized
INFO - 2018-07-19 02:20:24 --> Loader Class Initialized
INFO - 2018-07-19 02:20:24 --> Helper loaded: url_helper
INFO - 2018-07-19 02:20:24 --> Helper loaded: form_helper
INFO - 2018-07-19 02:20:24 --> Helper loaded: language_helper
DEBUG - 2018-07-19 02:20:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-19 02:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-19 02:20:24 --> User Agent Class Initialized
INFO - 2018-07-19 02:20:24 --> Controller Class Initialized
INFO - 2018-07-19 02:20:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-19 02:20:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-19 02:20:24 --> Pixel_Model class loaded
INFO - 2018-07-19 02:20:24 --> Database Driver Class Initialized
INFO - 2018-07-19 02:20:24 --> Model "QuestionsModel" initialized
INFO - 2018-07-19 02:20:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-19 02:20:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-19 02:20:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-19 02:20:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-19 02:20:24 --> Final output sent to browser
DEBUG - 2018-07-19 02:20:24 --> Total execution time: 0.0408
INFO - 2018-07-19 05:50:58 --> Config Class Initialized
INFO - 2018-07-19 05:50:58 --> Hooks Class Initialized
DEBUG - 2018-07-19 05:50:58 --> UTF-8 Support Enabled
INFO - 2018-07-19 05:50:58 --> Utf8 Class Initialized
INFO - 2018-07-19 05:50:58 --> URI Class Initialized
INFO - 2018-07-19 05:50:58 --> Router Class Initialized
INFO - 2018-07-19 05:50:58 --> Output Class Initialized
INFO - 2018-07-19 05:50:58 --> Security Class Initialized
DEBUG - 2018-07-19 05:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 05:50:58 --> CSRF cookie sent
INFO - 2018-07-19 05:50:58 --> Input Class Initialized
INFO - 2018-07-19 05:50:58 --> Language Class Initialized
ERROR - 2018-07-19 05:50:58 --> 404 Page Not Found: Admin/images
INFO - 2018-07-19 05:51:00 --> Config Class Initialized
INFO - 2018-07-19 05:51:00 --> Hooks Class Initialized
DEBUG - 2018-07-19 05:51:00 --> UTF-8 Support Enabled
INFO - 2018-07-19 05:51:00 --> Utf8 Class Initialized
INFO - 2018-07-19 05:51:00 --> URI Class Initialized
INFO - 2018-07-19 05:51:00 --> Router Class Initialized
INFO - 2018-07-19 05:51:00 --> Output Class Initialized
INFO - 2018-07-19 05:51:00 --> Security Class Initialized
DEBUG - 2018-07-19 05:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 05:51:00 --> CSRF cookie sent
INFO - 2018-07-19 05:51:00 --> Input Class Initialized
INFO - 2018-07-19 05:51:00 --> Language Class Initialized
ERROR - 2018-07-19 05:51:00 --> 404 Page Not Found: Admin/login.php
INFO - 2018-07-19 05:51:02 --> Config Class Initialized
INFO - 2018-07-19 05:51:02 --> Hooks Class Initialized
DEBUG - 2018-07-19 05:51:02 --> UTF-8 Support Enabled
INFO - 2018-07-19 05:51:02 --> Utf8 Class Initialized
INFO - 2018-07-19 05:51:02 --> URI Class Initialized
INFO - 2018-07-19 05:51:02 --> Router Class Initialized
INFO - 2018-07-19 05:51:02 --> Output Class Initialized
INFO - 2018-07-19 05:51:02 --> Security Class Initialized
DEBUG - 2018-07-19 05:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 05:51:02 --> CSRF cookie sent
INFO - 2018-07-19 05:51:02 --> Input Class Initialized
INFO - 2018-07-19 05:51:02 --> Language Class Initialized
ERROR - 2018-07-19 05:51:02 --> 404 Page Not Found: Templates/system
INFO - 2018-07-19 05:51:10 --> Config Class Initialized
INFO - 2018-07-19 05:51:10 --> Hooks Class Initialized
DEBUG - 2018-07-19 05:51:10 --> UTF-8 Support Enabled
INFO - 2018-07-19 05:51:10 --> Utf8 Class Initialized
INFO - 2018-07-19 05:51:10 --> URI Class Initialized
DEBUG - 2018-07-19 05:51:10 --> No URI present. Default controller set.
INFO - 2018-07-19 05:51:10 --> Router Class Initialized
INFO - 2018-07-19 05:51:10 --> Output Class Initialized
INFO - 2018-07-19 05:51:10 --> Security Class Initialized
DEBUG - 2018-07-19 05:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 05:51:10 --> CSRF cookie sent
INFO - 2018-07-19 05:51:10 --> Input Class Initialized
INFO - 2018-07-19 05:51:10 --> Language Class Initialized
INFO - 2018-07-19 05:51:10 --> Loader Class Initialized
INFO - 2018-07-19 05:51:10 --> Helper loaded: url_helper
INFO - 2018-07-19 05:51:10 --> Helper loaded: form_helper
INFO - 2018-07-19 05:51:10 --> Helper loaded: language_helper
DEBUG - 2018-07-19 05:51:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-19 05:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-19 05:51:10 --> User Agent Class Initialized
INFO - 2018-07-19 05:51:10 --> Controller Class Initialized
INFO - 2018-07-19 05:51:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-19 05:51:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-19 05:51:10 --> Pixel_Model class loaded
INFO - 2018-07-19 05:51:10 --> Database Driver Class Initialized
INFO - 2018-07-19 05:51:10 --> Model "QuestionsModel" initialized
INFO - 2018-07-19 05:51:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-19 05:51:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-19 05:51:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-19 05:51:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-19 05:51:10 --> Final output sent to browser
DEBUG - 2018-07-19 05:51:10 --> Total execution time: 0.0347
INFO - 2018-07-19 05:51:14 --> Config Class Initialized
INFO - 2018-07-19 05:51:14 --> Hooks Class Initialized
DEBUG - 2018-07-19 05:51:14 --> UTF-8 Support Enabled
INFO - 2018-07-19 05:51:14 --> Utf8 Class Initialized
INFO - 2018-07-19 05:51:14 --> URI Class Initialized
INFO - 2018-07-19 05:51:14 --> Router Class Initialized
INFO - 2018-07-19 05:51:14 --> Output Class Initialized
INFO - 2018-07-19 05:51:14 --> Security Class Initialized
DEBUG - 2018-07-19 05:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 05:51:14 --> CSRF cookie sent
INFO - 2018-07-19 05:51:14 --> Input Class Initialized
INFO - 2018-07-19 05:51:14 --> Language Class Initialized
ERROR - 2018-07-19 05:51:14 --> 404 Page Not Found: Fckeditor/editor
INFO - 2018-07-19 08:59:24 --> Config Class Initialized
INFO - 2018-07-19 08:59:24 --> Hooks Class Initialized
DEBUG - 2018-07-19 08:59:24 --> UTF-8 Support Enabled
INFO - 2018-07-19 08:59:24 --> Utf8 Class Initialized
INFO - 2018-07-19 08:59:24 --> URI Class Initialized
INFO - 2018-07-19 08:59:24 --> Router Class Initialized
INFO - 2018-07-19 08:59:24 --> Output Class Initialized
INFO - 2018-07-19 08:59:24 --> Security Class Initialized
DEBUG - 2018-07-19 08:59:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 08:59:24 --> CSRF cookie sent
INFO - 2018-07-19 08:59:24 --> Input Class Initialized
INFO - 2018-07-19 08:59:24 --> Language Class Initialized
ERROR - 2018-07-19 08:59:24 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-19 08:59:26 --> Config Class Initialized
INFO - 2018-07-19 08:59:26 --> Hooks Class Initialized
DEBUG - 2018-07-19 08:59:26 --> UTF-8 Support Enabled
INFO - 2018-07-19 08:59:26 --> Utf8 Class Initialized
INFO - 2018-07-19 08:59:26 --> URI Class Initialized
DEBUG - 2018-07-19 08:59:26 --> No URI present. Default controller set.
INFO - 2018-07-19 08:59:26 --> Router Class Initialized
INFO - 2018-07-19 08:59:26 --> Output Class Initialized
INFO - 2018-07-19 08:59:26 --> Security Class Initialized
DEBUG - 2018-07-19 08:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 08:59:26 --> CSRF cookie sent
INFO - 2018-07-19 08:59:26 --> Input Class Initialized
INFO - 2018-07-19 08:59:26 --> Language Class Initialized
INFO - 2018-07-19 08:59:27 --> Loader Class Initialized
INFO - 2018-07-19 08:59:27 --> Helper loaded: url_helper
INFO - 2018-07-19 08:59:27 --> Helper loaded: form_helper
INFO - 2018-07-19 08:59:27 --> Helper loaded: language_helper
DEBUG - 2018-07-19 08:59:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-19 08:59:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-19 08:59:27 --> User Agent Class Initialized
INFO - 2018-07-19 08:59:27 --> Controller Class Initialized
INFO - 2018-07-19 08:59:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-19 08:59:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-19 08:59:27 --> Pixel_Model class loaded
INFO - 2018-07-19 08:59:27 --> Database Driver Class Initialized
INFO - 2018-07-19 08:59:27 --> Model "QuestionsModel" initialized
INFO - 2018-07-19 08:59:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-19 08:59:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-19 08:59:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-19 08:59:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-19 08:59:27 --> Final output sent to browser
DEBUG - 2018-07-19 08:59:27 --> Total execution time: 0.0323
INFO - 2018-07-19 09:01:33 --> Config Class Initialized
INFO - 2018-07-19 09:01:33 --> Hooks Class Initialized
DEBUG - 2018-07-19 09:01:33 --> UTF-8 Support Enabled
INFO - 2018-07-19 09:01:33 --> Utf8 Class Initialized
INFO - 2018-07-19 09:01:33 --> URI Class Initialized
INFO - 2018-07-19 09:01:33 --> Router Class Initialized
INFO - 2018-07-19 09:01:33 --> Output Class Initialized
INFO - 2018-07-19 09:01:33 --> Security Class Initialized
DEBUG - 2018-07-19 09:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 09:01:33 --> CSRF cookie sent
INFO - 2018-07-19 09:01:33 --> Input Class Initialized
INFO - 2018-07-19 09:01:33 --> Language Class Initialized
INFO - 2018-07-19 09:01:33 --> Loader Class Initialized
INFO - 2018-07-19 09:01:33 --> Helper loaded: url_helper
INFO - 2018-07-19 09:01:33 --> Helper loaded: form_helper
INFO - 2018-07-19 09:01:33 --> Helper loaded: language_helper
DEBUG - 2018-07-19 09:01:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-19 09:01:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-19 09:01:33 --> User Agent Class Initialized
INFO - 2018-07-19 09:01:33 --> Controller Class Initialized
INFO - 2018-07-19 09:01:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-19 09:01:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-19 09:01:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-19 09:01:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-19 09:01:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-19 09:01:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-19 09:01:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-07-19 09:01:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-19 09:01:33 --> Final output sent to browser
DEBUG - 2018-07-19 09:01:33 --> Total execution time: 0.0224
INFO - 2018-07-19 09:51:31 --> Config Class Initialized
INFO - 2018-07-19 09:51:31 --> Hooks Class Initialized
DEBUG - 2018-07-19 09:51:31 --> UTF-8 Support Enabled
INFO - 2018-07-19 09:51:31 --> Utf8 Class Initialized
INFO - 2018-07-19 09:51:31 --> URI Class Initialized
DEBUG - 2018-07-19 09:51:31 --> No URI present. Default controller set.
INFO - 2018-07-19 09:51:31 --> Router Class Initialized
INFO - 2018-07-19 09:51:31 --> Output Class Initialized
INFO - 2018-07-19 09:51:31 --> Security Class Initialized
DEBUG - 2018-07-19 09:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 09:51:31 --> CSRF cookie sent
INFO - 2018-07-19 09:51:31 --> Input Class Initialized
INFO - 2018-07-19 09:51:31 --> Language Class Initialized
INFO - 2018-07-19 09:51:31 --> Loader Class Initialized
INFO - 2018-07-19 09:51:31 --> Helper loaded: url_helper
INFO - 2018-07-19 09:51:31 --> Helper loaded: form_helper
INFO - 2018-07-19 09:51:31 --> Helper loaded: language_helper
DEBUG - 2018-07-19 09:51:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-19 09:51:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-19 09:51:31 --> User Agent Class Initialized
INFO - 2018-07-19 09:51:31 --> Controller Class Initialized
INFO - 2018-07-19 09:51:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-19 09:51:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-19 09:51:31 --> Pixel_Model class loaded
INFO - 2018-07-19 09:51:31 --> Database Driver Class Initialized
INFO - 2018-07-19 09:51:31 --> Model "QuestionsModel" initialized
INFO - 2018-07-19 09:51:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-19 09:51:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-19 09:51:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-19 09:51:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-19 09:51:31 --> Final output sent to browser
DEBUG - 2018-07-19 09:51:31 --> Total execution time: 0.0353
INFO - 2018-07-19 10:29:00 --> Config Class Initialized
INFO - 2018-07-19 10:29:00 --> Hooks Class Initialized
DEBUG - 2018-07-19 10:29:00 --> UTF-8 Support Enabled
INFO - 2018-07-19 10:29:00 --> Utf8 Class Initialized
INFO - 2018-07-19 10:29:00 --> URI Class Initialized
DEBUG - 2018-07-19 10:29:00 --> No URI present. Default controller set.
INFO - 2018-07-19 10:29:00 --> Router Class Initialized
INFO - 2018-07-19 10:29:00 --> Output Class Initialized
INFO - 2018-07-19 10:29:00 --> Security Class Initialized
DEBUG - 2018-07-19 10:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 10:29:00 --> CSRF cookie sent
INFO - 2018-07-19 10:29:00 --> Input Class Initialized
INFO - 2018-07-19 10:29:00 --> Language Class Initialized
INFO - 2018-07-19 10:29:00 --> Loader Class Initialized
INFO - 2018-07-19 10:29:00 --> Helper loaded: url_helper
INFO - 2018-07-19 10:29:00 --> Helper loaded: form_helper
INFO - 2018-07-19 10:29:00 --> Helper loaded: language_helper
DEBUG - 2018-07-19 10:29:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-19 10:29:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-19 10:29:00 --> User Agent Class Initialized
INFO - 2018-07-19 10:29:00 --> Controller Class Initialized
INFO - 2018-07-19 10:29:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-19 10:29:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-19 10:29:00 --> Pixel_Model class loaded
INFO - 2018-07-19 10:29:00 --> Database Driver Class Initialized
INFO - 2018-07-19 10:29:00 --> Model "QuestionsModel" initialized
INFO - 2018-07-19 10:29:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-19 10:29:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-19 10:29:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-19 10:29:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-19 10:29:00 --> Final output sent to browser
DEBUG - 2018-07-19 10:29:00 --> Total execution time: 0.0434
INFO - 2018-07-19 12:46:10 --> Config Class Initialized
INFO - 2018-07-19 12:46:10 --> Hooks Class Initialized
DEBUG - 2018-07-19 12:46:10 --> UTF-8 Support Enabled
INFO - 2018-07-19 12:46:10 --> Utf8 Class Initialized
INFO - 2018-07-19 12:46:10 --> URI Class Initialized
INFO - 2018-07-19 12:46:10 --> Router Class Initialized
INFO - 2018-07-19 12:46:10 --> Output Class Initialized
INFO - 2018-07-19 12:46:10 --> Security Class Initialized
DEBUG - 2018-07-19 12:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 12:46:10 --> CSRF cookie sent
INFO - 2018-07-19 12:46:10 --> Input Class Initialized
INFO - 2018-07-19 12:46:10 --> Language Class Initialized
ERROR - 2018-07-19 12:46:10 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-19 12:46:13 --> Config Class Initialized
INFO - 2018-07-19 12:46:13 --> Hooks Class Initialized
DEBUG - 2018-07-19 12:46:13 --> UTF-8 Support Enabled
INFO - 2018-07-19 12:46:13 --> Utf8 Class Initialized
INFO - 2018-07-19 12:46:13 --> URI Class Initialized
INFO - 2018-07-19 12:46:13 --> Router Class Initialized
INFO - 2018-07-19 12:46:13 --> Output Class Initialized
INFO - 2018-07-19 12:46:13 --> Security Class Initialized
DEBUG - 2018-07-19 12:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 12:46:13 --> CSRF cookie sent
INFO - 2018-07-19 12:46:13 --> Input Class Initialized
INFO - 2018-07-19 12:46:13 --> Language Class Initialized
INFO - 2018-07-19 12:46:13 --> Loader Class Initialized
INFO - 2018-07-19 12:46:13 --> Helper loaded: url_helper
INFO - 2018-07-19 12:46:13 --> Helper loaded: form_helper
INFO - 2018-07-19 12:46:13 --> Helper loaded: language_helper
DEBUG - 2018-07-19 12:46:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-19 12:46:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-19 12:46:13 --> User Agent Class Initialized
INFO - 2018-07-19 12:46:13 --> Controller Class Initialized
INFO - 2018-07-19 12:46:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-19 12:46:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-19 12:46:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-19 12:46:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-19 12:46:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-19 12:46:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-19 12:46:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-07-19 12:46:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-19 12:46:13 --> Final output sent to browser
DEBUG - 2018-07-19 12:46:13 --> Total execution time: 0.0256
INFO - 2018-07-19 13:44:44 --> Config Class Initialized
INFO - 2018-07-19 13:44:44 --> Hooks Class Initialized
DEBUG - 2018-07-19 13:44:44 --> UTF-8 Support Enabled
INFO - 2018-07-19 13:44:44 --> Utf8 Class Initialized
INFO - 2018-07-19 13:44:44 --> URI Class Initialized
DEBUG - 2018-07-19 13:44:44 --> No URI present. Default controller set.
INFO - 2018-07-19 13:44:44 --> Router Class Initialized
INFO - 2018-07-19 13:44:44 --> Output Class Initialized
INFO - 2018-07-19 13:44:44 --> Security Class Initialized
DEBUG - 2018-07-19 13:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 13:44:44 --> CSRF cookie sent
INFO - 2018-07-19 13:44:44 --> Input Class Initialized
INFO - 2018-07-19 13:44:44 --> Language Class Initialized
INFO - 2018-07-19 13:44:44 --> Loader Class Initialized
INFO - 2018-07-19 13:44:44 --> Helper loaded: url_helper
INFO - 2018-07-19 13:44:44 --> Helper loaded: form_helper
INFO - 2018-07-19 13:44:44 --> Helper loaded: language_helper
DEBUG - 2018-07-19 13:44:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-19 13:44:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-19 13:44:44 --> User Agent Class Initialized
INFO - 2018-07-19 13:44:44 --> Controller Class Initialized
INFO - 2018-07-19 13:44:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-19 13:44:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-19 13:44:44 --> Pixel_Model class loaded
INFO - 2018-07-19 13:44:44 --> Database Driver Class Initialized
INFO - 2018-07-19 13:44:44 --> Model "QuestionsModel" initialized
INFO - 2018-07-19 13:44:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-19 13:44:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-19 13:44:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-19 13:44:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-19 13:44:44 --> Final output sent to browser
DEBUG - 2018-07-19 13:44:44 --> Total execution time: 0.0357
INFO - 2018-07-19 16:42:44 --> Config Class Initialized
INFO - 2018-07-19 16:42:44 --> Hooks Class Initialized
DEBUG - 2018-07-19 16:42:44 --> UTF-8 Support Enabled
INFO - 2018-07-19 16:42:44 --> Utf8 Class Initialized
INFO - 2018-07-19 16:42:44 --> URI Class Initialized
DEBUG - 2018-07-19 16:42:44 --> No URI present. Default controller set.
INFO - 2018-07-19 16:42:44 --> Router Class Initialized
INFO - 2018-07-19 16:42:44 --> Output Class Initialized
INFO - 2018-07-19 16:42:44 --> Security Class Initialized
DEBUG - 2018-07-19 16:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 16:42:44 --> CSRF cookie sent
INFO - 2018-07-19 16:42:44 --> Input Class Initialized
INFO - 2018-07-19 16:42:44 --> Language Class Initialized
INFO - 2018-07-19 16:42:44 --> Loader Class Initialized
INFO - 2018-07-19 16:42:44 --> Helper loaded: url_helper
INFO - 2018-07-19 16:42:44 --> Helper loaded: form_helper
INFO - 2018-07-19 16:42:44 --> Helper loaded: language_helper
DEBUG - 2018-07-19 16:42:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-19 16:42:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-19 16:42:44 --> User Agent Class Initialized
INFO - 2018-07-19 16:42:44 --> Controller Class Initialized
INFO - 2018-07-19 16:42:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-19 16:42:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-19 16:42:44 --> Pixel_Model class loaded
INFO - 2018-07-19 16:42:44 --> Database Driver Class Initialized
INFO - 2018-07-19 16:42:44 --> Model "QuestionsModel" initialized
INFO - 2018-07-19 16:42:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-19 16:42:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-19 16:42:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-19 16:42:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-19 16:42:44 --> Final output sent to browser
DEBUG - 2018-07-19 16:42:44 --> Total execution time: 0.0422
INFO - 2018-07-19 16:42:46 --> Config Class Initialized
INFO - 2018-07-19 16:42:46 --> Hooks Class Initialized
DEBUG - 2018-07-19 16:42:46 --> UTF-8 Support Enabled
INFO - 2018-07-19 16:42:46 --> Utf8 Class Initialized
INFO - 2018-07-19 16:42:46 --> URI Class Initialized
INFO - 2018-07-19 16:42:46 --> Router Class Initialized
INFO - 2018-07-19 16:42:46 --> Output Class Initialized
INFO - 2018-07-19 16:42:46 --> Security Class Initialized
DEBUG - 2018-07-19 16:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 16:42:46 --> CSRF cookie sent
INFO - 2018-07-19 16:42:46 --> Input Class Initialized
INFO - 2018-07-19 16:42:46 --> Language Class Initialized
ERROR - 2018-07-19 16:42:46 --> 404 Page Not Found: Apple-touch-icon-120x120-precomposedpng/index
INFO - 2018-07-19 16:42:46 --> Config Class Initialized
INFO - 2018-07-19 16:42:46 --> Hooks Class Initialized
DEBUG - 2018-07-19 16:42:46 --> UTF-8 Support Enabled
INFO - 2018-07-19 16:42:46 --> Utf8 Class Initialized
INFO - 2018-07-19 16:42:46 --> URI Class Initialized
INFO - 2018-07-19 16:42:46 --> Router Class Initialized
INFO - 2018-07-19 16:42:46 --> Output Class Initialized
INFO - 2018-07-19 16:42:46 --> Security Class Initialized
DEBUG - 2018-07-19 16:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 16:42:46 --> CSRF cookie sent
INFO - 2018-07-19 16:42:46 --> Input Class Initialized
INFO - 2018-07-19 16:42:46 --> Language Class Initialized
ERROR - 2018-07-19 16:42:46 --> 404 Page Not Found: Apple-touch-icon-120x120png/index
INFO - 2018-07-19 16:42:46 --> Config Class Initialized
INFO - 2018-07-19 16:42:46 --> Hooks Class Initialized
DEBUG - 2018-07-19 16:42:46 --> UTF-8 Support Enabled
INFO - 2018-07-19 16:42:46 --> Utf8 Class Initialized
INFO - 2018-07-19 16:42:46 --> URI Class Initialized
INFO - 2018-07-19 16:42:46 --> Router Class Initialized
INFO - 2018-07-19 16:42:46 --> Output Class Initialized
INFO - 2018-07-19 16:42:46 --> Security Class Initialized
DEBUG - 2018-07-19 16:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 16:42:46 --> CSRF cookie sent
INFO - 2018-07-19 16:42:46 --> Input Class Initialized
INFO - 2018-07-19 16:42:46 --> Language Class Initialized
ERROR - 2018-07-19 16:42:46 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
INFO - 2018-07-19 16:42:46 --> Config Class Initialized
INFO - 2018-07-19 16:42:46 --> Hooks Class Initialized
DEBUG - 2018-07-19 16:42:46 --> UTF-8 Support Enabled
INFO - 2018-07-19 16:42:46 --> Utf8 Class Initialized
INFO - 2018-07-19 16:42:46 --> URI Class Initialized
INFO - 2018-07-19 16:42:46 --> Router Class Initialized
INFO - 2018-07-19 16:42:46 --> Output Class Initialized
INFO - 2018-07-19 16:42:46 --> Security Class Initialized
DEBUG - 2018-07-19 16:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 16:42:46 --> CSRF cookie sent
INFO - 2018-07-19 16:42:46 --> Input Class Initialized
INFO - 2018-07-19 16:42:46 --> Language Class Initialized
ERROR - 2018-07-19 16:42:46 --> 404 Page Not Found: Apple-touch-iconpng/index
INFO - 2018-07-19 16:42:49 --> Config Class Initialized
INFO - 2018-07-19 16:42:49 --> Hooks Class Initialized
DEBUG - 2018-07-19 16:42:49 --> UTF-8 Support Enabled
INFO - 2018-07-19 16:42:49 --> Utf8 Class Initialized
INFO - 2018-07-19 16:42:49 --> URI Class Initialized
INFO - 2018-07-19 16:42:49 --> Router Class Initialized
INFO - 2018-07-19 16:42:49 --> Output Class Initialized
INFO - 2018-07-19 16:42:49 --> Security Class Initialized
DEBUG - 2018-07-19 16:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 16:42:49 --> CSRF cookie sent
INFO - 2018-07-19 16:42:49 --> CSRF token verified
INFO - 2018-07-19 16:42:49 --> Input Class Initialized
INFO - 2018-07-19 16:42:49 --> Language Class Initialized
INFO - 2018-07-19 16:42:49 --> Loader Class Initialized
INFO - 2018-07-19 16:42:49 --> Helper loaded: url_helper
INFO - 2018-07-19 16:42:49 --> Helper loaded: form_helper
INFO - 2018-07-19 16:42:49 --> Helper loaded: language_helper
DEBUG - 2018-07-19 16:42:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-19 16:42:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-19 16:42:49 --> User Agent Class Initialized
INFO - 2018-07-19 16:42:49 --> Controller Class Initialized
INFO - 2018-07-19 16:42:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-19 16:42:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-19 16:42:49 --> Pixel_Model class loaded
INFO - 2018-07-19 16:42:49 --> Database Driver Class Initialized
INFO - 2018-07-19 16:42:49 --> Model "QuestionsModel" initialized
INFO - 2018-07-19 16:42:49 --> Config Class Initialized
INFO - 2018-07-19 16:42:49 --> Hooks Class Initialized
DEBUG - 2018-07-19 16:42:49 --> UTF-8 Support Enabled
INFO - 2018-07-19 16:42:49 --> Utf8 Class Initialized
INFO - 2018-07-19 16:42:49 --> URI Class Initialized
INFO - 2018-07-19 16:42:49 --> Router Class Initialized
INFO - 2018-07-19 16:42:49 --> Output Class Initialized
INFO - 2018-07-19 16:42:49 --> Security Class Initialized
DEBUG - 2018-07-19 16:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 16:42:49 --> CSRF cookie sent
INFO - 2018-07-19 16:42:49 --> Input Class Initialized
INFO - 2018-07-19 16:42:49 --> Language Class Initialized
INFO - 2018-07-19 16:42:49 --> Loader Class Initialized
INFO - 2018-07-19 16:42:49 --> Helper loaded: url_helper
INFO - 2018-07-19 16:42:49 --> Helper loaded: form_helper
INFO - 2018-07-19 16:42:49 --> Helper loaded: language_helper
DEBUG - 2018-07-19 16:42:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-19 16:42:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-19 16:42:49 --> User Agent Class Initialized
INFO - 2018-07-19 16:42:49 --> Controller Class Initialized
INFO - 2018-07-19 16:42:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-19 16:42:49 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-19 16:42:49 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-19 16:42:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-19 16:42:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-19 16:42:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-19 16:42:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-19 16:42:49 --> Could not find the language line "req_email"
INFO - 2018-07-19 16:42:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-19 16:42:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-19 16:42:49 --> Final output sent to browser
DEBUG - 2018-07-19 16:42:49 --> Total execution time: 0.0234
INFO - 2018-07-19 16:58:45 --> Config Class Initialized
INFO - 2018-07-19 16:58:45 --> Hooks Class Initialized
DEBUG - 2018-07-19 16:58:45 --> UTF-8 Support Enabled
INFO - 2018-07-19 16:58:45 --> Utf8 Class Initialized
INFO - 2018-07-19 16:58:45 --> URI Class Initialized
INFO - 2018-07-19 16:58:45 --> Router Class Initialized
INFO - 2018-07-19 16:58:45 --> Output Class Initialized
INFO - 2018-07-19 16:58:45 --> Security Class Initialized
DEBUG - 2018-07-19 16:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 16:58:45 --> CSRF cookie sent
INFO - 2018-07-19 16:58:45 --> Input Class Initialized
INFO - 2018-07-19 16:58:45 --> Language Class Initialized
ERROR - 2018-07-19 16:58:45 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-19 17:27:55 --> Config Class Initialized
INFO - 2018-07-19 17:27:55 --> Hooks Class Initialized
DEBUG - 2018-07-19 17:27:55 --> UTF-8 Support Enabled
INFO - 2018-07-19 17:27:55 --> Utf8 Class Initialized
INFO - 2018-07-19 17:27:55 --> URI Class Initialized
INFO - 2018-07-19 17:27:55 --> Router Class Initialized
INFO - 2018-07-19 17:27:55 --> Output Class Initialized
INFO - 2018-07-19 17:27:55 --> Security Class Initialized
DEBUG - 2018-07-19 17:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 17:27:55 --> CSRF cookie sent
INFO - 2018-07-19 17:27:55 --> Input Class Initialized
INFO - 2018-07-19 17:27:55 --> Language Class Initialized
ERROR - 2018-07-19 17:27:55 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-19 17:52:05 --> Config Class Initialized
INFO - 2018-07-19 17:52:05 --> Hooks Class Initialized
DEBUG - 2018-07-19 17:52:05 --> UTF-8 Support Enabled
INFO - 2018-07-19 17:52:05 --> Utf8 Class Initialized
INFO - 2018-07-19 17:52:05 --> URI Class Initialized
DEBUG - 2018-07-19 17:52:05 --> No URI present. Default controller set.
INFO - 2018-07-19 17:52:05 --> Router Class Initialized
INFO - 2018-07-19 17:52:05 --> Output Class Initialized
INFO - 2018-07-19 17:52:05 --> Security Class Initialized
DEBUG - 2018-07-19 17:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 17:52:05 --> CSRF cookie sent
INFO - 2018-07-19 17:52:05 --> Input Class Initialized
INFO - 2018-07-19 17:52:05 --> Language Class Initialized
INFO - 2018-07-19 17:52:05 --> Loader Class Initialized
INFO - 2018-07-19 17:52:05 --> Helper loaded: url_helper
INFO - 2018-07-19 17:52:05 --> Helper loaded: form_helper
INFO - 2018-07-19 17:52:05 --> Helper loaded: language_helper
DEBUG - 2018-07-19 17:52:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-19 17:52:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-19 17:52:05 --> User Agent Class Initialized
INFO - 2018-07-19 17:52:05 --> Controller Class Initialized
INFO - 2018-07-19 17:52:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-19 17:52:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-19 17:52:05 --> Pixel_Model class loaded
INFO - 2018-07-19 17:52:05 --> Database Driver Class Initialized
INFO - 2018-07-19 17:52:05 --> Model "QuestionsModel" initialized
INFO - 2018-07-19 17:52:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-19 17:52:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-19 17:52:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-19 17:52:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-19 17:52:05 --> Final output sent to browser
DEBUG - 2018-07-19 17:52:05 --> Total execution time: 0.0364
INFO - 2018-07-19 17:52:05 --> Config Class Initialized
INFO - 2018-07-19 17:52:05 --> Hooks Class Initialized
DEBUG - 2018-07-19 17:52:05 --> UTF-8 Support Enabled
INFO - 2018-07-19 17:52:05 --> Utf8 Class Initialized
INFO - 2018-07-19 17:52:05 --> URI Class Initialized
DEBUG - 2018-07-19 17:52:05 --> No URI present. Default controller set.
INFO - 2018-07-19 17:52:05 --> Router Class Initialized
INFO - 2018-07-19 17:52:05 --> Output Class Initialized
INFO - 2018-07-19 17:52:05 --> Security Class Initialized
DEBUG - 2018-07-19 17:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 17:52:05 --> CSRF cookie sent
INFO - 2018-07-19 17:52:05 --> Input Class Initialized
INFO - 2018-07-19 17:52:05 --> Language Class Initialized
INFO - 2018-07-19 17:52:05 --> Loader Class Initialized
INFO - 2018-07-19 17:52:05 --> Helper loaded: url_helper
INFO - 2018-07-19 17:52:05 --> Helper loaded: form_helper
INFO - 2018-07-19 17:52:05 --> Helper loaded: language_helper
DEBUG - 2018-07-19 17:52:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-19 17:52:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-19 17:52:05 --> User Agent Class Initialized
INFO - 2018-07-19 17:52:05 --> Controller Class Initialized
INFO - 2018-07-19 17:52:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-19 17:52:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-19 17:52:05 --> Pixel_Model class loaded
INFO - 2018-07-19 17:52:05 --> Database Driver Class Initialized
INFO - 2018-07-19 17:52:05 --> Model "QuestionsModel" initialized
INFO - 2018-07-19 17:52:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-19 17:52:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-19 17:52:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-19 17:52:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-19 17:52:05 --> Final output sent to browser
DEBUG - 2018-07-19 17:52:05 --> Total execution time: 0.0263
INFO - 2018-07-19 17:52:06 --> Config Class Initialized
INFO - 2018-07-19 17:52:06 --> Hooks Class Initialized
DEBUG - 2018-07-19 17:52:06 --> UTF-8 Support Enabled
INFO - 2018-07-19 17:52:06 --> Utf8 Class Initialized
INFO - 2018-07-19 17:52:06 --> URI Class Initialized
DEBUG - 2018-07-19 17:52:06 --> No URI present. Default controller set.
INFO - 2018-07-19 17:52:06 --> Router Class Initialized
INFO - 2018-07-19 17:52:06 --> Output Class Initialized
INFO - 2018-07-19 17:52:06 --> Security Class Initialized
DEBUG - 2018-07-19 17:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 17:52:06 --> CSRF cookie sent
INFO - 2018-07-19 17:52:06 --> Input Class Initialized
INFO - 2018-07-19 17:52:06 --> Language Class Initialized
INFO - 2018-07-19 17:52:06 --> Loader Class Initialized
INFO - 2018-07-19 17:52:06 --> Helper loaded: url_helper
INFO - 2018-07-19 17:52:06 --> Helper loaded: form_helper
INFO - 2018-07-19 17:52:06 --> Helper loaded: language_helper
DEBUG - 2018-07-19 17:52:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-19 17:52:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-19 17:52:06 --> User Agent Class Initialized
INFO - 2018-07-19 17:52:06 --> Controller Class Initialized
INFO - 2018-07-19 17:52:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-19 17:52:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-19 17:52:06 --> Pixel_Model class loaded
INFO - 2018-07-19 17:52:06 --> Database Driver Class Initialized
INFO - 2018-07-19 17:52:06 --> Model "QuestionsModel" initialized
INFO - 2018-07-19 17:52:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-19 17:52:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-19 17:52:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-19 17:52:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-19 17:52:06 --> Final output sent to browser
DEBUG - 2018-07-19 17:52:06 --> Total execution time: 0.0351
INFO - 2018-07-19 17:52:06 --> Config Class Initialized
INFO - 2018-07-19 17:52:06 --> Hooks Class Initialized
DEBUG - 2018-07-19 17:52:06 --> UTF-8 Support Enabled
INFO - 2018-07-19 17:52:06 --> Utf8 Class Initialized
INFO - 2018-07-19 17:52:06 --> URI Class Initialized
INFO - 2018-07-19 17:52:06 --> Router Class Initialized
INFO - 2018-07-19 17:52:06 --> Output Class Initialized
INFO - 2018-07-19 17:52:06 --> Security Class Initialized
DEBUG - 2018-07-19 17:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 17:52:06 --> CSRF cookie sent
INFO - 2018-07-19 17:52:06 --> Input Class Initialized
INFO - 2018-07-19 17:52:06 --> Language Class Initialized
ERROR - 2018-07-19 17:52:06 --> 404 Page Not Found: 405shtml/index
INFO - 2018-07-19 17:52:13 --> Config Class Initialized
INFO - 2018-07-19 17:52:13 --> Hooks Class Initialized
DEBUG - 2018-07-19 17:52:13 --> UTF-8 Support Enabled
INFO - 2018-07-19 17:52:13 --> Utf8 Class Initialized
INFO - 2018-07-19 17:52:13 --> URI Class Initialized
DEBUG - 2018-07-19 17:52:13 --> No URI present. Default controller set.
INFO - 2018-07-19 17:52:13 --> Router Class Initialized
INFO - 2018-07-19 17:52:13 --> Output Class Initialized
INFO - 2018-07-19 17:52:13 --> Security Class Initialized
DEBUG - 2018-07-19 17:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 17:52:13 --> CSRF cookie sent
INFO - 2018-07-19 17:52:13 --> Input Class Initialized
INFO - 2018-07-19 17:52:13 --> Language Class Initialized
INFO - 2018-07-19 17:52:13 --> Loader Class Initialized
INFO - 2018-07-19 17:52:13 --> Helper loaded: url_helper
INFO - 2018-07-19 17:52:13 --> Helper loaded: form_helper
INFO - 2018-07-19 17:52:13 --> Helper loaded: language_helper
DEBUG - 2018-07-19 17:52:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-19 17:52:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-19 17:52:13 --> User Agent Class Initialized
INFO - 2018-07-19 17:52:13 --> Controller Class Initialized
INFO - 2018-07-19 17:52:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-19 17:52:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-19 17:52:13 --> Pixel_Model class loaded
INFO - 2018-07-19 17:52:13 --> Database Driver Class Initialized
INFO - 2018-07-19 17:52:13 --> Model "QuestionsModel" initialized
INFO - 2018-07-19 17:52:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-19 17:52:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-19 17:52:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-19 17:52:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-19 17:52:13 --> Final output sent to browser
DEBUG - 2018-07-19 17:52:13 --> Total execution time: 0.0382
INFO - 2018-07-19 17:52:13 --> Config Class Initialized
INFO - 2018-07-19 17:52:13 --> Hooks Class Initialized
DEBUG - 2018-07-19 17:52:13 --> UTF-8 Support Enabled
INFO - 2018-07-19 17:52:13 --> Utf8 Class Initialized
INFO - 2018-07-19 17:52:13 --> URI Class Initialized
INFO - 2018-07-19 17:52:13 --> Router Class Initialized
INFO - 2018-07-19 17:52:13 --> Output Class Initialized
INFO - 2018-07-19 17:52:13 --> Security Class Initialized
DEBUG - 2018-07-19 17:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 17:52:13 --> CSRF cookie sent
INFO - 2018-07-19 17:52:13 --> Input Class Initialized
INFO - 2018-07-19 17:52:13 --> Language Class Initialized
ERROR - 2018-07-19 17:52:13 --> 404 Page Not Found: 404testpage4525d2fdc/index
INFO - 2018-07-19 17:52:14 --> Config Class Initialized
INFO - 2018-07-19 17:52:14 --> Hooks Class Initialized
DEBUG - 2018-07-19 17:52:14 --> UTF-8 Support Enabled
INFO - 2018-07-19 17:52:14 --> Utf8 Class Initialized
INFO - 2018-07-19 17:52:14 --> URI Class Initialized
INFO - 2018-07-19 17:52:14 --> Router Class Initialized
INFO - 2018-07-19 17:52:14 --> Output Class Initialized
INFO - 2018-07-19 17:52:14 --> Security Class Initialized
DEBUG - 2018-07-19 17:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 17:52:14 --> CSRF cookie sent
INFO - 2018-07-19 17:52:14 --> Input Class Initialized
INFO - 2018-07-19 17:52:14 --> Language Class Initialized
ERROR - 2018-07-19 17:52:14 --> 404 Page Not Found: 404javascriptjs/index
INFO - 2018-07-19 17:52:14 --> Config Class Initialized
INFO - 2018-07-19 17:52:14 --> Hooks Class Initialized
DEBUG - 2018-07-19 17:52:14 --> UTF-8 Support Enabled
INFO - 2018-07-19 17:52:14 --> Utf8 Class Initialized
INFO - 2018-07-19 17:52:14 --> URI Class Initialized
INFO - 2018-07-19 17:52:14 --> Router Class Initialized
INFO - 2018-07-19 17:52:14 --> Output Class Initialized
INFO - 2018-07-19 17:52:14 --> Security Class Initialized
DEBUG - 2018-07-19 17:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 17:52:14 --> CSRF cookie sent
INFO - 2018-07-19 17:52:14 --> Input Class Initialized
INFO - 2018-07-19 17:52:14 --> Language Class Initialized
INFO - 2018-07-19 17:52:14 --> Loader Class Initialized
INFO - 2018-07-19 17:52:14 --> Helper loaded: url_helper
INFO - 2018-07-19 17:52:14 --> Helper loaded: form_helper
INFO - 2018-07-19 17:52:14 --> Helper loaded: language_helper
DEBUG - 2018-07-19 17:52:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-19 17:52:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-19 17:52:14 --> User Agent Class Initialized
INFO - 2018-07-19 17:52:14 --> Controller Class Initialized
INFO - 2018-07-19 17:52:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-19 17:52:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-19 17:52:14 --> Pixel_Model class loaded
INFO - 2018-07-19 17:52:14 --> Database Driver Class Initialized
INFO - 2018-07-19 17:52:14 --> Model "QuestionsModel" initialized
INFO - 2018-07-19 17:52:14 --> Config Class Initialized
INFO - 2018-07-19 17:52:14 --> Hooks Class Initialized
DEBUG - 2018-07-19 17:52:14 --> UTF-8 Support Enabled
INFO - 2018-07-19 17:52:14 --> Utf8 Class Initialized
INFO - 2018-07-19 17:52:14 --> URI Class Initialized
INFO - 2018-07-19 17:52:14 --> Router Class Initialized
INFO - 2018-07-19 17:52:14 --> Output Class Initialized
INFO - 2018-07-19 17:52:14 --> Security Class Initialized
DEBUG - 2018-07-19 17:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 17:52:14 --> CSRF cookie sent
INFO - 2018-07-19 17:52:14 --> Input Class Initialized
INFO - 2018-07-19 17:52:14 --> Language Class Initialized
INFO - 2018-07-19 17:52:14 --> Loader Class Initialized
INFO - 2018-07-19 17:52:14 --> Helper loaded: url_helper
INFO - 2018-07-19 17:52:14 --> Helper loaded: form_helper
INFO - 2018-07-19 17:52:14 --> Helper loaded: language_helper
DEBUG - 2018-07-19 17:52:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-19 17:52:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-19 17:52:14 --> User Agent Class Initialized
INFO - 2018-07-19 17:52:14 --> Controller Class Initialized
INFO - 2018-07-19 17:52:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-19 17:52:14 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-19 17:52:14 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-19 17:52:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-19 17:52:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-19 17:52:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-19 17:52:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-19 17:52:14 --> Could not find the language line "req_email"
INFO - 2018-07-19 17:52:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-19 17:52:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-19 17:52:14 --> Final output sent to browser
DEBUG - 2018-07-19 17:52:14 --> Total execution time: 0.0227
INFO - 2018-07-19 17:52:14 --> Config Class Initialized
INFO - 2018-07-19 17:52:14 --> Hooks Class Initialized
DEBUG - 2018-07-19 17:52:14 --> UTF-8 Support Enabled
INFO - 2018-07-19 17:52:14 --> Utf8 Class Initialized
INFO - 2018-07-19 17:52:14 --> URI Class Initialized
INFO - 2018-07-19 17:52:14 --> Router Class Initialized
INFO - 2018-07-19 17:52:14 --> Output Class Initialized
INFO - 2018-07-19 17:52:14 --> Security Class Initialized
DEBUG - 2018-07-19 17:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 17:52:14 --> CSRF cookie sent
INFO - 2018-07-19 17:52:14 --> Input Class Initialized
INFO - 2018-07-19 17:52:14 --> Language Class Initialized
INFO - 2018-07-19 17:52:14 --> Loader Class Initialized
INFO - 2018-07-19 17:52:14 --> Helper loaded: url_helper
INFO - 2018-07-19 17:52:14 --> Helper loaded: form_helper
INFO - 2018-07-19 17:52:14 --> Helper loaded: language_helper
DEBUG - 2018-07-19 17:52:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-19 17:52:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-19 17:52:14 --> User Agent Class Initialized
INFO - 2018-07-19 17:52:14 --> Controller Class Initialized
INFO - 2018-07-19 17:52:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-19 17:52:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-19 17:52:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-19 17:52:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-19 17:52:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-19 17:52:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-19 17:52:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-07-19 17:52:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-19 17:52:14 --> Final output sent to browser
DEBUG - 2018-07-19 17:52:14 --> Total execution time: 0.0242
INFO - 2018-07-19 17:52:15 --> Config Class Initialized
INFO - 2018-07-19 17:52:15 --> Hooks Class Initialized
DEBUG - 2018-07-19 17:52:15 --> UTF-8 Support Enabled
INFO - 2018-07-19 17:52:15 --> Utf8 Class Initialized
INFO - 2018-07-19 17:52:15 --> URI Class Initialized
INFO - 2018-07-19 17:52:15 --> Router Class Initialized
INFO - 2018-07-19 17:52:15 --> Output Class Initialized
INFO - 2018-07-19 17:52:15 --> Security Class Initialized
DEBUG - 2018-07-19 17:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 17:52:15 --> CSRF cookie sent
INFO - 2018-07-19 17:52:15 --> Input Class Initialized
INFO - 2018-07-19 17:52:15 --> Language Class Initialized
INFO - 2018-07-19 17:52:15 --> Loader Class Initialized
INFO - 2018-07-19 17:52:15 --> Helper loaded: url_helper
INFO - 2018-07-19 17:52:15 --> Helper loaded: form_helper
INFO - 2018-07-19 17:52:15 --> Helper loaded: language_helper
DEBUG - 2018-07-19 17:52:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-19 17:52:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-19 17:52:15 --> User Agent Class Initialized
INFO - 2018-07-19 17:52:15 --> Controller Class Initialized
INFO - 2018-07-19 17:52:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-19 17:52:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-19 17:52:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-19 17:52:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-19 17:52:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-19 17:52:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-19 17:52:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-07-19 17:52:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-19 17:52:15 --> Final output sent to browser
DEBUG - 2018-07-19 17:52:15 --> Total execution time: 0.0211
INFO - 2018-07-19 17:52:15 --> Config Class Initialized
INFO - 2018-07-19 17:52:15 --> Hooks Class Initialized
DEBUG - 2018-07-19 17:52:15 --> UTF-8 Support Enabled
INFO - 2018-07-19 17:52:15 --> Utf8 Class Initialized
INFO - 2018-07-19 17:52:15 --> URI Class Initialized
INFO - 2018-07-19 17:52:15 --> Router Class Initialized
INFO - 2018-07-19 17:52:15 --> Output Class Initialized
INFO - 2018-07-19 17:52:15 --> Security Class Initialized
DEBUG - 2018-07-19 17:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 17:52:15 --> CSRF cookie sent
INFO - 2018-07-19 17:52:15 --> Input Class Initialized
INFO - 2018-07-19 17:52:15 --> Language Class Initialized
INFO - 2018-07-19 17:52:15 --> Loader Class Initialized
INFO - 2018-07-19 17:52:15 --> Helper loaded: url_helper
INFO - 2018-07-19 17:52:15 --> Helper loaded: form_helper
INFO - 2018-07-19 17:52:15 --> Helper loaded: language_helper
DEBUG - 2018-07-19 17:52:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-19 17:52:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-19 17:52:15 --> User Agent Class Initialized
INFO - 2018-07-19 17:52:15 --> Controller Class Initialized
INFO - 2018-07-19 17:52:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-19 17:52:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-19 17:52:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-19 17:52:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-19 17:52:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-19 17:52:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-19 17:52:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-07-19 17:52:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-19 17:52:15 --> Final output sent to browser
DEBUG - 2018-07-19 17:52:15 --> Total execution time: 0.0352
INFO - 2018-07-19 17:52:15 --> Config Class Initialized
INFO - 2018-07-19 17:52:15 --> Hooks Class Initialized
DEBUG - 2018-07-19 17:52:15 --> UTF-8 Support Enabled
INFO - 2018-07-19 17:52:15 --> Utf8 Class Initialized
INFO - 2018-07-19 17:52:15 --> URI Class Initialized
INFO - 2018-07-19 17:52:15 --> Router Class Initialized
INFO - 2018-07-19 17:52:15 --> Output Class Initialized
INFO - 2018-07-19 17:52:15 --> Security Class Initialized
DEBUG - 2018-07-19 17:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 17:52:15 --> CSRF cookie sent
INFO - 2018-07-19 17:52:15 --> Input Class Initialized
INFO - 2018-07-19 17:52:15 --> Language Class Initialized
INFO - 2018-07-19 17:52:15 --> Loader Class Initialized
INFO - 2018-07-19 17:52:15 --> Helper loaded: url_helper
INFO - 2018-07-19 17:52:15 --> Helper loaded: form_helper
INFO - 2018-07-19 17:52:15 --> Helper loaded: language_helper
DEBUG - 2018-07-19 17:52:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-19 17:52:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-19 17:52:15 --> User Agent Class Initialized
INFO - 2018-07-19 17:52:15 --> Controller Class Initialized
INFO - 2018-07-19 17:52:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-19 17:52:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-19 17:52:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-19 17:52:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-19 17:52:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-19 17:52:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-19 17:52:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-07-19 17:52:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-19 17:52:15 --> Final output sent to browser
DEBUG - 2018-07-19 17:52:15 --> Total execution time: 0.0223
INFO - 2018-07-19 17:52:16 --> Config Class Initialized
INFO - 2018-07-19 17:52:16 --> Hooks Class Initialized
DEBUG - 2018-07-19 17:52:16 --> UTF-8 Support Enabled
INFO - 2018-07-19 17:52:16 --> Utf8 Class Initialized
INFO - 2018-07-19 17:52:16 --> URI Class Initialized
INFO - 2018-07-19 17:52:16 --> Router Class Initialized
INFO - 2018-07-19 17:52:16 --> Output Class Initialized
INFO - 2018-07-19 17:52:16 --> Security Class Initialized
DEBUG - 2018-07-19 17:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 17:52:16 --> CSRF cookie sent
INFO - 2018-07-19 17:52:16 --> Input Class Initialized
INFO - 2018-07-19 17:52:16 --> Language Class Initialized
INFO - 2018-07-19 17:52:16 --> Loader Class Initialized
INFO - 2018-07-19 17:52:16 --> Helper loaded: url_helper
INFO - 2018-07-19 17:52:16 --> Helper loaded: form_helper
INFO - 2018-07-19 17:52:16 --> Helper loaded: language_helper
DEBUG - 2018-07-19 17:52:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-19 17:52:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-19 17:52:16 --> User Agent Class Initialized
INFO - 2018-07-19 17:52:16 --> Controller Class Initialized
INFO - 2018-07-19 17:52:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-19 17:52:16 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-19 17:52:16 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-19 17:52:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-19 17:52:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-19 17:52:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-19 17:52:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-19 17:52:16 --> Could not find the language line "req_email"
INFO - 2018-07-19 17:52:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-19 17:52:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-19 17:52:16 --> Final output sent to browser
DEBUG - 2018-07-19 17:52:16 --> Total execution time: 0.0222
INFO - 2018-07-19 17:52:16 --> Config Class Initialized
INFO - 2018-07-19 17:52:16 --> Hooks Class Initialized
DEBUG - 2018-07-19 17:52:16 --> UTF-8 Support Enabled
INFO - 2018-07-19 17:52:16 --> Utf8 Class Initialized
INFO - 2018-07-19 17:52:16 --> URI Class Initialized
INFO - 2018-07-19 17:52:16 --> Router Class Initialized
INFO - 2018-07-19 17:52:16 --> Output Class Initialized
INFO - 2018-07-19 17:52:16 --> Security Class Initialized
DEBUG - 2018-07-19 17:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 17:52:16 --> CSRF cookie sent
INFO - 2018-07-19 17:52:16 --> Input Class Initialized
INFO - 2018-07-19 17:52:16 --> Language Class Initialized
INFO - 2018-07-19 17:52:16 --> Loader Class Initialized
INFO - 2018-07-19 17:52:16 --> Helper loaded: url_helper
INFO - 2018-07-19 17:52:16 --> Helper loaded: form_helper
INFO - 2018-07-19 17:52:16 --> Helper loaded: language_helper
DEBUG - 2018-07-19 17:52:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-19 17:52:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-19 17:52:16 --> User Agent Class Initialized
INFO - 2018-07-19 17:52:16 --> Controller Class Initialized
INFO - 2018-07-19 17:52:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-19 17:52:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-19 17:52:16 --> Pixel_Model class loaded
INFO - 2018-07-19 17:52:16 --> Database Driver Class Initialized
INFO - 2018-07-19 17:52:16 --> Model "QuestionsModel" initialized
INFO - 2018-07-19 17:52:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-19 17:52:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-19 17:52:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-19 17:52:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-19 17:52:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/buy_gift.php
INFO - 2018-07-19 17:52:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-19 17:52:16 --> Final output sent to browser
DEBUG - 2018-07-19 17:52:16 --> Total execution time: 0.0334
INFO - 2018-07-19 17:52:42 --> Config Class Initialized
INFO - 2018-07-19 17:52:42 --> Hooks Class Initialized
DEBUG - 2018-07-19 17:52:42 --> UTF-8 Support Enabled
INFO - 2018-07-19 17:52:42 --> Utf8 Class Initialized
INFO - 2018-07-19 17:52:42 --> URI Class Initialized
DEBUG - 2018-07-19 17:52:42 --> No URI present. Default controller set.
INFO - 2018-07-19 17:52:42 --> Router Class Initialized
INFO - 2018-07-19 17:52:42 --> Output Class Initialized
INFO - 2018-07-19 17:52:42 --> Security Class Initialized
DEBUG - 2018-07-19 17:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 17:52:42 --> CSRF cookie sent
INFO - 2018-07-19 17:52:42 --> Input Class Initialized
INFO - 2018-07-19 17:52:42 --> Language Class Initialized
INFO - 2018-07-19 17:52:42 --> Loader Class Initialized
INFO - 2018-07-19 17:52:42 --> Helper loaded: url_helper
INFO - 2018-07-19 17:52:42 --> Helper loaded: form_helper
INFO - 2018-07-19 17:52:42 --> Helper loaded: language_helper
DEBUG - 2018-07-19 17:52:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-19 17:52:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-19 17:52:42 --> User Agent Class Initialized
INFO - 2018-07-19 17:52:42 --> Controller Class Initialized
INFO - 2018-07-19 17:52:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-19 17:52:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-19 17:52:42 --> Pixel_Model class loaded
INFO - 2018-07-19 17:52:42 --> Database Driver Class Initialized
INFO - 2018-07-19 17:52:42 --> Model "QuestionsModel" initialized
INFO - 2018-07-19 17:52:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-19 17:52:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-19 17:52:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-19 17:52:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-19 17:52:42 --> Final output sent to browser
DEBUG - 2018-07-19 17:52:42 --> Total execution time: 0.0326
INFO - 2018-07-19 18:00:27 --> Config Class Initialized
INFO - 2018-07-19 18:00:27 --> Hooks Class Initialized
DEBUG - 2018-07-19 18:00:27 --> UTF-8 Support Enabled
INFO - 2018-07-19 18:00:27 --> Utf8 Class Initialized
INFO - 2018-07-19 18:00:27 --> URI Class Initialized
INFO - 2018-07-19 18:00:27 --> Router Class Initialized
INFO - 2018-07-19 18:00:27 --> Output Class Initialized
INFO - 2018-07-19 18:00:27 --> Security Class Initialized
DEBUG - 2018-07-19 18:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 18:00:27 --> CSRF cookie sent
INFO - 2018-07-19 18:00:27 --> Input Class Initialized
INFO - 2018-07-19 18:00:27 --> Language Class Initialized
ERROR - 2018-07-19 18:00:27 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-19 18:00:30 --> Config Class Initialized
INFO - 2018-07-19 18:00:30 --> Hooks Class Initialized
DEBUG - 2018-07-19 18:00:30 --> UTF-8 Support Enabled
INFO - 2018-07-19 18:00:30 --> Utf8 Class Initialized
INFO - 2018-07-19 18:00:30 --> URI Class Initialized
INFO - 2018-07-19 18:00:30 --> Router Class Initialized
INFO - 2018-07-19 18:00:30 --> Output Class Initialized
INFO - 2018-07-19 18:00:30 --> Security Class Initialized
DEBUG - 2018-07-19 18:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 18:00:30 --> CSRF cookie sent
INFO - 2018-07-19 18:00:30 --> Input Class Initialized
INFO - 2018-07-19 18:00:30 --> Language Class Initialized
INFO - 2018-07-19 18:00:30 --> Loader Class Initialized
INFO - 2018-07-19 18:00:30 --> Helper loaded: url_helper
INFO - 2018-07-19 18:00:30 --> Helper loaded: form_helper
INFO - 2018-07-19 18:00:30 --> Helper loaded: language_helper
DEBUG - 2018-07-19 18:00:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-19 18:00:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-19 18:00:30 --> User Agent Class Initialized
INFO - 2018-07-19 18:00:30 --> Controller Class Initialized
INFO - 2018-07-19 18:00:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-19 18:00:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-19 18:00:30 --> Pixel_Model class loaded
INFO - 2018-07-19 18:00:30 --> Database Driver Class Initialized
INFO - 2018-07-19 18:00:30 --> Model "QuestionsModel" initialized
INFO - 2018-07-19 18:00:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-19 18:00:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-19 18:00:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-19 18:00:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-19 18:00:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/buy_gift.php
INFO - 2018-07-19 18:00:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-19 18:00:30 --> Final output sent to browser
DEBUG - 2018-07-19 18:00:30 --> Total execution time: 0.0403
INFO - 2018-07-19 18:48:16 --> Config Class Initialized
INFO - 2018-07-19 18:48:16 --> Hooks Class Initialized
DEBUG - 2018-07-19 18:48:16 --> UTF-8 Support Enabled
INFO - 2018-07-19 18:48:16 --> Utf8 Class Initialized
INFO - 2018-07-19 18:48:16 --> URI Class Initialized
DEBUG - 2018-07-19 18:48:16 --> No URI present. Default controller set.
INFO - 2018-07-19 18:48:16 --> Router Class Initialized
INFO - 2018-07-19 18:48:16 --> Output Class Initialized
INFO - 2018-07-19 18:48:16 --> Security Class Initialized
DEBUG - 2018-07-19 18:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 18:48:16 --> CSRF cookie sent
INFO - 2018-07-19 18:48:16 --> Input Class Initialized
INFO - 2018-07-19 18:48:16 --> Language Class Initialized
INFO - 2018-07-19 18:48:16 --> Loader Class Initialized
INFO - 2018-07-19 18:48:16 --> Helper loaded: url_helper
INFO - 2018-07-19 18:48:16 --> Helper loaded: form_helper
INFO - 2018-07-19 18:48:16 --> Helper loaded: language_helper
DEBUG - 2018-07-19 18:48:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-19 18:48:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-19 18:48:16 --> User Agent Class Initialized
INFO - 2018-07-19 18:48:16 --> Controller Class Initialized
INFO - 2018-07-19 18:48:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-19 18:48:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-19 18:48:16 --> Pixel_Model class loaded
INFO - 2018-07-19 18:48:16 --> Database Driver Class Initialized
INFO - 2018-07-19 18:48:16 --> Model "QuestionsModel" initialized
INFO - 2018-07-19 18:48:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-19 18:48:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-19 18:48:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-19 18:48:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-19 18:48:16 --> Final output sent to browser
DEBUG - 2018-07-19 18:48:16 --> Total execution time: 0.0509
INFO - 2018-07-19 19:04:25 --> Config Class Initialized
INFO - 2018-07-19 19:04:25 --> Hooks Class Initialized
DEBUG - 2018-07-19 19:04:25 --> UTF-8 Support Enabled
INFO - 2018-07-19 19:04:25 --> Utf8 Class Initialized
INFO - 2018-07-19 19:04:25 --> URI Class Initialized
DEBUG - 2018-07-19 19:04:25 --> No URI present. Default controller set.
INFO - 2018-07-19 19:04:25 --> Router Class Initialized
INFO - 2018-07-19 19:04:25 --> Output Class Initialized
INFO - 2018-07-19 19:04:25 --> Security Class Initialized
DEBUG - 2018-07-19 19:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 19:04:25 --> CSRF cookie sent
INFO - 2018-07-19 19:04:25 --> Input Class Initialized
INFO - 2018-07-19 19:04:25 --> Language Class Initialized
INFO - 2018-07-19 19:04:25 --> Loader Class Initialized
INFO - 2018-07-19 19:04:25 --> Helper loaded: url_helper
INFO - 2018-07-19 19:04:25 --> Helper loaded: form_helper
INFO - 2018-07-19 19:04:25 --> Helper loaded: language_helper
DEBUG - 2018-07-19 19:04:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-19 19:04:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-19 19:04:25 --> User Agent Class Initialized
INFO - 2018-07-19 19:04:25 --> Controller Class Initialized
INFO - 2018-07-19 19:04:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-19 19:04:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-19 19:04:25 --> Pixel_Model class loaded
INFO - 2018-07-19 19:04:25 --> Database Driver Class Initialized
INFO - 2018-07-19 19:04:25 --> Model "QuestionsModel" initialized
INFO - 2018-07-19 19:04:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-19 19:04:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-19 19:04:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-19 19:04:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-19 19:04:25 --> Final output sent to browser
DEBUG - 2018-07-19 19:04:25 --> Total execution time: 0.0320
INFO - 2018-07-19 19:04:50 --> Config Class Initialized
INFO - 2018-07-19 19:04:50 --> Hooks Class Initialized
DEBUG - 2018-07-19 19:04:50 --> UTF-8 Support Enabled
INFO - 2018-07-19 19:04:50 --> Utf8 Class Initialized
INFO - 2018-07-19 19:04:50 --> URI Class Initialized
DEBUG - 2018-07-19 19:04:50 --> No URI present. Default controller set.
INFO - 2018-07-19 19:04:50 --> Router Class Initialized
INFO - 2018-07-19 19:04:50 --> Output Class Initialized
INFO - 2018-07-19 19:04:50 --> Security Class Initialized
DEBUG - 2018-07-19 19:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 19:04:50 --> CSRF cookie sent
INFO - 2018-07-19 19:04:50 --> Input Class Initialized
INFO - 2018-07-19 19:04:50 --> Language Class Initialized
INFO - 2018-07-19 19:04:50 --> Loader Class Initialized
INFO - 2018-07-19 19:04:50 --> Helper loaded: url_helper
INFO - 2018-07-19 19:04:50 --> Helper loaded: form_helper
INFO - 2018-07-19 19:04:50 --> Helper loaded: language_helper
DEBUG - 2018-07-19 19:04:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-19 19:04:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-19 19:04:50 --> User Agent Class Initialized
INFO - 2018-07-19 19:04:50 --> Controller Class Initialized
INFO - 2018-07-19 19:04:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-19 19:04:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-19 19:04:50 --> Pixel_Model class loaded
INFO - 2018-07-19 19:04:50 --> Database Driver Class Initialized
INFO - 2018-07-19 19:04:50 --> Model "QuestionsModel" initialized
INFO - 2018-07-19 19:04:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-19 19:04:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-19 19:04:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-19 19:04:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-19 19:04:50 --> Final output sent to browser
DEBUG - 2018-07-19 19:04:50 --> Total execution time: 0.0351

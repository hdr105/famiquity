<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-07-22 01:18:46 --> Config Class Initialized
INFO - 2018-07-22 01:18:46 --> Hooks Class Initialized
DEBUG - 2018-07-22 01:18:46 --> UTF-8 Support Enabled
INFO - 2018-07-22 01:18:46 --> Utf8 Class Initialized
INFO - 2018-07-22 01:18:46 --> URI Class Initialized
INFO - 2018-07-22 01:18:46 --> Router Class Initialized
INFO - 2018-07-22 01:18:46 --> Output Class Initialized
INFO - 2018-07-22 01:18:46 --> Security Class Initialized
DEBUG - 2018-07-22 01:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-22 01:18:46 --> CSRF cookie sent
INFO - 2018-07-22 01:18:46 --> Input Class Initialized
INFO - 2018-07-22 01:18:46 --> Language Class Initialized
ERROR - 2018-07-22 01:18:46 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-22 01:18:49 --> Config Class Initialized
INFO - 2018-07-22 01:18:49 --> Hooks Class Initialized
DEBUG - 2018-07-22 01:18:49 --> UTF-8 Support Enabled
INFO - 2018-07-22 01:18:49 --> Utf8 Class Initialized
INFO - 2018-07-22 01:18:49 --> URI Class Initialized
INFO - 2018-07-22 01:18:49 --> Router Class Initialized
INFO - 2018-07-22 01:18:49 --> Output Class Initialized
INFO - 2018-07-22 01:18:49 --> Security Class Initialized
DEBUG - 2018-07-22 01:18:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-22 01:18:49 --> CSRF cookie sent
INFO - 2018-07-22 01:18:49 --> Input Class Initialized
INFO - 2018-07-22 01:18:49 --> Language Class Initialized
INFO - 2018-07-22 01:18:49 --> Loader Class Initialized
INFO - 2018-07-22 01:18:49 --> Helper loaded: url_helper
INFO - 2018-07-22 01:18:49 --> Helper loaded: form_helper
INFO - 2018-07-22 01:18:49 --> Helper loaded: language_helper
DEBUG - 2018-07-22 01:18:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-22 01:18:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-22 01:18:49 --> User Agent Class Initialized
INFO - 2018-07-22 01:18:49 --> Controller Class Initialized
INFO - 2018-07-22 01:18:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-22 01:18:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-22 01:18:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-22 01:18:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-22 01:18:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-22 01:18:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-22 01:18:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/preview.php
INFO - 2018-07-22 01:18:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-22 01:18:49 --> Final output sent to browser
DEBUG - 2018-07-22 01:18:49 --> Total execution time: 0.0281
INFO - 2018-07-22 01:22:09 --> Config Class Initialized
INFO - 2018-07-22 01:22:09 --> Hooks Class Initialized
DEBUG - 2018-07-22 01:22:09 --> UTF-8 Support Enabled
INFO - 2018-07-22 01:22:09 --> Utf8 Class Initialized
INFO - 2018-07-22 01:22:09 --> URI Class Initialized
INFO - 2018-07-22 01:22:09 --> Router Class Initialized
INFO - 2018-07-22 01:22:09 --> Output Class Initialized
INFO - 2018-07-22 01:22:09 --> Security Class Initialized
DEBUG - 2018-07-22 01:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-22 01:22:09 --> CSRF cookie sent
INFO - 2018-07-22 01:22:09 --> Input Class Initialized
INFO - 2018-07-22 01:22:09 --> Language Class Initialized
ERROR - 2018-07-22 01:22:09 --> 404 Page Not Found: Faviconico/index
INFO - 2018-07-22 01:53:59 --> Config Class Initialized
INFO - 2018-07-22 01:53:59 --> Hooks Class Initialized
DEBUG - 2018-07-22 01:53:59 --> UTF-8 Support Enabled
INFO - 2018-07-22 01:53:59 --> Utf8 Class Initialized
INFO - 2018-07-22 01:53:59 --> URI Class Initialized
DEBUG - 2018-07-22 01:53:59 --> No URI present. Default controller set.
INFO - 2018-07-22 01:53:59 --> Router Class Initialized
INFO - 2018-07-22 01:53:59 --> Output Class Initialized
INFO - 2018-07-22 01:53:59 --> Security Class Initialized
DEBUG - 2018-07-22 01:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-22 01:53:59 --> CSRF cookie sent
INFO - 2018-07-22 01:53:59 --> Input Class Initialized
INFO - 2018-07-22 01:53:59 --> Language Class Initialized
INFO - 2018-07-22 01:53:59 --> Loader Class Initialized
INFO - 2018-07-22 01:53:59 --> Helper loaded: url_helper
INFO - 2018-07-22 01:53:59 --> Helper loaded: form_helper
INFO - 2018-07-22 01:53:59 --> Helper loaded: language_helper
DEBUG - 2018-07-22 01:53:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-22 01:53:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-22 01:53:59 --> User Agent Class Initialized
INFO - 2018-07-22 01:53:59 --> Controller Class Initialized
INFO - 2018-07-22 01:53:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-22 01:53:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-22 01:53:59 --> Pixel_Model class loaded
INFO - 2018-07-22 01:53:59 --> Database Driver Class Initialized
INFO - 2018-07-22 01:53:59 --> Model "QuestionsModel" initialized
INFO - 2018-07-22 01:53:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-22 01:53:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-22 01:53:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-22 01:53:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-22 01:53:59 --> Final output sent to browser
DEBUG - 2018-07-22 01:53:59 --> Total execution time: 0.0364
INFO - 2018-07-22 05:14:51 --> Config Class Initialized
INFO - 2018-07-22 05:14:51 --> Hooks Class Initialized
DEBUG - 2018-07-22 05:14:51 --> UTF-8 Support Enabled
INFO - 2018-07-22 05:14:51 --> Utf8 Class Initialized
INFO - 2018-07-22 05:14:51 --> URI Class Initialized
INFO - 2018-07-22 05:14:51 --> Router Class Initialized
INFO - 2018-07-22 05:14:51 --> Output Class Initialized
INFO - 2018-07-22 05:14:51 --> Security Class Initialized
DEBUG - 2018-07-22 05:14:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-22 05:14:51 --> CSRF cookie sent
INFO - 2018-07-22 05:14:51 --> Input Class Initialized
INFO - 2018-07-22 05:14:51 --> Language Class Initialized
ERROR - 2018-07-22 05:14:51 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-22 05:14:54 --> Config Class Initialized
INFO - 2018-07-22 05:14:54 --> Hooks Class Initialized
DEBUG - 2018-07-22 05:14:54 --> UTF-8 Support Enabled
INFO - 2018-07-22 05:14:54 --> Utf8 Class Initialized
INFO - 2018-07-22 05:14:54 --> URI Class Initialized
INFO - 2018-07-22 05:14:54 --> Router Class Initialized
INFO - 2018-07-22 05:14:54 --> Output Class Initialized
INFO - 2018-07-22 05:14:54 --> Security Class Initialized
DEBUG - 2018-07-22 05:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-22 05:14:54 --> CSRF cookie sent
INFO - 2018-07-22 05:14:54 --> Input Class Initialized
INFO - 2018-07-22 05:14:54 --> Language Class Initialized
INFO - 2018-07-22 05:14:54 --> Loader Class Initialized
INFO - 2018-07-22 05:14:54 --> Helper loaded: url_helper
INFO - 2018-07-22 05:14:54 --> Helper loaded: form_helper
INFO - 2018-07-22 05:14:54 --> Helper loaded: language_helper
DEBUG - 2018-07-22 05:14:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-22 05:14:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-22 05:14:54 --> User Agent Class Initialized
INFO - 2018-07-22 05:14:54 --> Controller Class Initialized
INFO - 2018-07-22 05:14:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-22 05:14:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-22 05:14:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-22 05:14:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-22 05:14:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-22 05:14:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-22 05:14:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-07-22 05:14:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-22 05:14:54 --> Final output sent to browser
DEBUG - 2018-07-22 05:14:54 --> Total execution time: 0.0243
INFO - 2018-07-22 09:53:47 --> Config Class Initialized
INFO - 2018-07-22 09:53:47 --> Hooks Class Initialized
DEBUG - 2018-07-22 09:53:47 --> UTF-8 Support Enabled
INFO - 2018-07-22 09:53:47 --> Utf8 Class Initialized
INFO - 2018-07-22 09:53:47 --> URI Class Initialized
DEBUG - 2018-07-22 09:53:47 --> No URI present. Default controller set.
INFO - 2018-07-22 09:53:47 --> Router Class Initialized
INFO - 2018-07-22 09:53:47 --> Output Class Initialized
INFO - 2018-07-22 09:53:47 --> Security Class Initialized
DEBUG - 2018-07-22 09:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-22 09:53:47 --> CSRF cookie sent
INFO - 2018-07-22 09:53:47 --> Input Class Initialized
INFO - 2018-07-22 09:53:47 --> Language Class Initialized
INFO - 2018-07-22 09:53:47 --> Loader Class Initialized
INFO - 2018-07-22 09:53:47 --> Helper loaded: url_helper
INFO - 2018-07-22 09:53:47 --> Helper loaded: form_helper
INFO - 2018-07-22 09:53:47 --> Helper loaded: language_helper
DEBUG - 2018-07-22 09:53:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-22 09:53:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-22 09:53:47 --> User Agent Class Initialized
INFO - 2018-07-22 09:53:47 --> Controller Class Initialized
INFO - 2018-07-22 09:53:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-22 09:53:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-22 09:53:47 --> Pixel_Model class loaded
INFO - 2018-07-22 09:53:47 --> Database Driver Class Initialized
INFO - 2018-07-22 09:53:47 --> Model "QuestionsModel" initialized
INFO - 2018-07-22 09:53:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-22 09:53:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-22 09:53:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-22 09:53:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-22 09:53:47 --> Final output sent to browser
DEBUG - 2018-07-22 09:53:47 --> Total execution time: 0.0361
INFO - 2018-07-22 10:28:25 --> Config Class Initialized
INFO - 2018-07-22 10:28:25 --> Hooks Class Initialized
DEBUG - 2018-07-22 10:28:25 --> UTF-8 Support Enabled
INFO - 2018-07-22 10:28:25 --> Utf8 Class Initialized
INFO - 2018-07-22 10:28:25 --> URI Class Initialized
DEBUG - 2018-07-22 10:28:25 --> No URI present. Default controller set.
INFO - 2018-07-22 10:28:25 --> Router Class Initialized
INFO - 2018-07-22 10:28:25 --> Output Class Initialized
INFO - 2018-07-22 10:28:25 --> Security Class Initialized
DEBUG - 2018-07-22 10:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-22 10:28:25 --> CSRF cookie sent
INFO - 2018-07-22 10:28:25 --> Input Class Initialized
INFO - 2018-07-22 10:28:25 --> Language Class Initialized
INFO - 2018-07-22 10:28:25 --> Loader Class Initialized
INFO - 2018-07-22 10:28:25 --> Helper loaded: url_helper
INFO - 2018-07-22 10:28:25 --> Helper loaded: form_helper
INFO - 2018-07-22 10:28:25 --> Helper loaded: language_helper
DEBUG - 2018-07-22 10:28:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-22 10:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-22 10:28:25 --> User Agent Class Initialized
INFO - 2018-07-22 10:28:25 --> Controller Class Initialized
INFO - 2018-07-22 10:28:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-22 10:28:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-22 10:28:25 --> Pixel_Model class loaded
INFO - 2018-07-22 10:28:25 --> Database Driver Class Initialized
INFO - 2018-07-22 10:28:25 --> Model "QuestionsModel" initialized
INFO - 2018-07-22 10:28:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-22 10:28:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-22 10:28:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-22 10:28:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-22 10:28:25 --> Final output sent to browser
DEBUG - 2018-07-22 10:28:25 --> Total execution time: 0.0388
INFO - 2018-07-22 10:28:26 --> Config Class Initialized
INFO - 2018-07-22 10:28:26 --> Hooks Class Initialized
DEBUG - 2018-07-22 10:28:26 --> UTF-8 Support Enabled
INFO - 2018-07-22 10:28:26 --> Utf8 Class Initialized
INFO - 2018-07-22 10:28:26 --> URI Class Initialized
DEBUG - 2018-07-22 10:28:26 --> No URI present. Default controller set.
INFO - 2018-07-22 10:28:26 --> Router Class Initialized
INFO - 2018-07-22 10:28:26 --> Output Class Initialized
INFO - 2018-07-22 10:28:26 --> Security Class Initialized
DEBUG - 2018-07-22 10:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-22 10:28:26 --> CSRF cookie sent
INFO - 2018-07-22 10:28:26 --> Input Class Initialized
INFO - 2018-07-22 10:28:26 --> Language Class Initialized
INFO - 2018-07-22 10:28:26 --> Loader Class Initialized
INFO - 2018-07-22 10:28:26 --> Helper loaded: url_helper
INFO - 2018-07-22 10:28:26 --> Helper loaded: form_helper
INFO - 2018-07-22 10:28:26 --> Helper loaded: language_helper
DEBUG - 2018-07-22 10:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-22 10:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-22 10:28:26 --> User Agent Class Initialized
INFO - 2018-07-22 10:28:26 --> Controller Class Initialized
INFO - 2018-07-22 10:28:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-22 10:28:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-22 10:28:26 --> Pixel_Model class loaded
INFO - 2018-07-22 10:28:26 --> Database Driver Class Initialized
INFO - 2018-07-22 10:28:26 --> Model "QuestionsModel" initialized
INFO - 2018-07-22 10:28:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-22 10:28:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-22 10:28:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-22 10:28:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-22 10:28:26 --> Final output sent to browser
DEBUG - 2018-07-22 10:28:26 --> Total execution time: 0.0311
INFO - 2018-07-22 10:28:26 --> Config Class Initialized
INFO - 2018-07-22 10:28:26 --> Hooks Class Initialized
DEBUG - 2018-07-22 10:28:26 --> UTF-8 Support Enabled
INFO - 2018-07-22 10:28:26 --> Utf8 Class Initialized
INFO - 2018-07-22 10:28:26 --> URI Class Initialized
DEBUG - 2018-07-22 10:28:26 --> No URI present. Default controller set.
INFO - 2018-07-22 10:28:26 --> Router Class Initialized
INFO - 2018-07-22 10:28:26 --> Output Class Initialized
INFO - 2018-07-22 10:28:26 --> Security Class Initialized
DEBUG - 2018-07-22 10:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-22 10:28:26 --> CSRF cookie sent
INFO - 2018-07-22 10:28:26 --> Input Class Initialized
INFO - 2018-07-22 10:28:26 --> Language Class Initialized
INFO - 2018-07-22 10:28:26 --> Loader Class Initialized
INFO - 2018-07-22 10:28:26 --> Helper loaded: url_helper
INFO - 2018-07-22 10:28:26 --> Helper loaded: form_helper
INFO - 2018-07-22 10:28:26 --> Helper loaded: language_helper
DEBUG - 2018-07-22 10:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-22 10:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-22 10:28:26 --> User Agent Class Initialized
INFO - 2018-07-22 10:28:26 --> Controller Class Initialized
INFO - 2018-07-22 10:28:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-22 10:28:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-22 10:28:26 --> Pixel_Model class loaded
INFO - 2018-07-22 10:28:26 --> Database Driver Class Initialized
INFO - 2018-07-22 10:28:26 --> Model "QuestionsModel" initialized
INFO - 2018-07-22 10:28:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-22 10:28:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-22 10:28:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-22 10:28:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-22 10:28:26 --> Final output sent to browser
DEBUG - 2018-07-22 10:28:26 --> Total execution time: 0.0333
INFO - 2018-07-22 10:28:26 --> Config Class Initialized
INFO - 2018-07-22 10:28:26 --> Hooks Class Initialized
DEBUG - 2018-07-22 10:28:26 --> UTF-8 Support Enabled
INFO - 2018-07-22 10:28:26 --> Utf8 Class Initialized
INFO - 2018-07-22 10:28:26 --> URI Class Initialized
DEBUG - 2018-07-22 10:28:26 --> No URI present. Default controller set.
INFO - 2018-07-22 10:28:26 --> Router Class Initialized
INFO - 2018-07-22 10:28:26 --> Output Class Initialized
INFO - 2018-07-22 10:28:26 --> Security Class Initialized
DEBUG - 2018-07-22 10:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-22 10:28:26 --> CSRF cookie sent
INFO - 2018-07-22 10:28:26 --> Input Class Initialized
INFO - 2018-07-22 10:28:26 --> Language Class Initialized
INFO - 2018-07-22 10:28:26 --> Loader Class Initialized
INFO - 2018-07-22 10:28:26 --> Helper loaded: url_helper
INFO - 2018-07-22 10:28:26 --> Helper loaded: form_helper
INFO - 2018-07-22 10:28:26 --> Helper loaded: language_helper
DEBUG - 2018-07-22 10:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-22 10:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-22 10:28:26 --> User Agent Class Initialized
INFO - 2018-07-22 10:28:26 --> Controller Class Initialized
INFO - 2018-07-22 10:28:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-22 10:28:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-22 10:28:26 --> Pixel_Model class loaded
INFO - 2018-07-22 10:28:26 --> Database Driver Class Initialized
INFO - 2018-07-22 10:28:26 --> Model "QuestionsModel" initialized
INFO - 2018-07-22 10:28:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-22 10:28:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-22 10:28:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-22 10:28:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-22 10:28:26 --> Final output sent to browser
DEBUG - 2018-07-22 10:28:26 --> Total execution time: 0.0357
INFO - 2018-07-22 10:30:12 --> Config Class Initialized
INFO - 2018-07-22 10:30:12 --> Hooks Class Initialized
DEBUG - 2018-07-22 10:30:12 --> UTF-8 Support Enabled
INFO - 2018-07-22 10:30:12 --> Utf8 Class Initialized
INFO - 2018-07-22 10:30:12 --> URI Class Initialized
DEBUG - 2018-07-22 10:30:12 --> No URI present. Default controller set.
INFO - 2018-07-22 10:30:12 --> Router Class Initialized
INFO - 2018-07-22 10:30:12 --> Output Class Initialized
INFO - 2018-07-22 10:30:12 --> Security Class Initialized
DEBUG - 2018-07-22 10:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-22 10:30:12 --> CSRF cookie sent
INFO - 2018-07-22 10:30:12 --> Input Class Initialized
INFO - 2018-07-22 10:30:12 --> Language Class Initialized
INFO - 2018-07-22 10:30:12 --> Loader Class Initialized
INFO - 2018-07-22 10:30:12 --> Helper loaded: url_helper
INFO - 2018-07-22 10:30:12 --> Helper loaded: form_helper
INFO - 2018-07-22 10:30:12 --> Helper loaded: language_helper
DEBUG - 2018-07-22 10:30:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-22 10:30:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-22 10:30:12 --> User Agent Class Initialized
INFO - 2018-07-22 10:30:12 --> Controller Class Initialized
INFO - 2018-07-22 10:30:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-22 10:30:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-22 10:30:12 --> Pixel_Model class loaded
INFO - 2018-07-22 10:30:12 --> Database Driver Class Initialized
INFO - 2018-07-22 10:30:12 --> Model "QuestionsModel" initialized
INFO - 2018-07-22 10:30:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-22 10:30:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-22 10:30:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-22 10:30:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-22 10:30:12 --> Final output sent to browser
DEBUG - 2018-07-22 10:30:12 --> Total execution time: 0.0334
INFO - 2018-07-22 13:45:47 --> Config Class Initialized
INFO - 2018-07-22 13:45:47 --> Hooks Class Initialized
DEBUG - 2018-07-22 13:45:47 --> UTF-8 Support Enabled
INFO - 2018-07-22 13:45:47 --> Utf8 Class Initialized
INFO - 2018-07-22 13:45:47 --> URI Class Initialized
INFO - 2018-07-22 13:45:47 --> Router Class Initialized
INFO - 2018-07-22 13:45:47 --> Output Class Initialized
INFO - 2018-07-22 13:45:47 --> Security Class Initialized
DEBUG - 2018-07-22 13:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-22 13:45:47 --> CSRF cookie sent
INFO - 2018-07-22 13:45:47 --> Input Class Initialized
INFO - 2018-07-22 13:45:47 --> Language Class Initialized
ERROR - 2018-07-22 13:45:47 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-22 13:45:50 --> Config Class Initialized
INFO - 2018-07-22 13:45:50 --> Hooks Class Initialized
DEBUG - 2018-07-22 13:45:50 --> UTF-8 Support Enabled
INFO - 2018-07-22 13:45:50 --> Utf8 Class Initialized
INFO - 2018-07-22 13:45:50 --> URI Class Initialized
INFO - 2018-07-22 13:45:50 --> Router Class Initialized
INFO - 2018-07-22 13:45:50 --> Output Class Initialized
INFO - 2018-07-22 13:45:50 --> Security Class Initialized
DEBUG - 2018-07-22 13:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-22 13:45:50 --> CSRF cookie sent
INFO - 2018-07-22 13:45:50 --> Input Class Initialized
INFO - 2018-07-22 13:45:50 --> Language Class Initialized
INFO - 2018-07-22 13:45:50 --> Loader Class Initialized
INFO - 2018-07-22 13:45:50 --> Helper loaded: url_helper
INFO - 2018-07-22 13:45:50 --> Helper loaded: form_helper
INFO - 2018-07-22 13:45:50 --> Helper loaded: language_helper
DEBUG - 2018-07-22 13:45:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-22 13:45:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-22 13:45:50 --> User Agent Class Initialized
INFO - 2018-07-22 13:45:50 --> Controller Class Initialized
INFO - 2018-07-22 13:45:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-22 13:45:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-22 13:45:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-22 13:45:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-22 13:45:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-22 13:45:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-22 13:45:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/preview.php
INFO - 2018-07-22 13:45:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-22 13:45:50 --> Final output sent to browser
DEBUG - 2018-07-22 13:45:50 --> Total execution time: 0.0240
INFO - 2018-07-22 17:18:29 --> Config Class Initialized
INFO - 2018-07-22 17:18:29 --> Hooks Class Initialized
DEBUG - 2018-07-22 17:18:29 --> UTF-8 Support Enabled
INFO - 2018-07-22 17:18:29 --> Utf8 Class Initialized
INFO - 2018-07-22 17:18:29 --> URI Class Initialized
INFO - 2018-07-22 17:18:29 --> Router Class Initialized
INFO - 2018-07-22 17:18:29 --> Output Class Initialized
INFO - 2018-07-22 17:18:29 --> Security Class Initialized
DEBUG - 2018-07-22 17:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-22 17:18:29 --> CSRF cookie sent
INFO - 2018-07-22 17:18:29 --> Input Class Initialized
INFO - 2018-07-22 17:18:29 --> Language Class Initialized
ERROR - 2018-07-22 17:18:29 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-22 17:53:57 --> Config Class Initialized
INFO - 2018-07-22 17:53:57 --> Hooks Class Initialized
DEBUG - 2018-07-22 17:53:57 --> UTF-8 Support Enabled
INFO - 2018-07-22 17:53:57 --> Utf8 Class Initialized
INFO - 2018-07-22 17:53:57 --> URI Class Initialized
DEBUG - 2018-07-22 17:53:57 --> No URI present. Default controller set.
INFO - 2018-07-22 17:53:57 --> Router Class Initialized
INFO - 2018-07-22 17:53:57 --> Output Class Initialized
INFO - 2018-07-22 17:53:57 --> Security Class Initialized
DEBUG - 2018-07-22 17:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-22 17:53:57 --> CSRF cookie sent
INFO - 2018-07-22 17:53:57 --> Input Class Initialized
INFO - 2018-07-22 17:53:57 --> Language Class Initialized
INFO - 2018-07-22 17:53:57 --> Loader Class Initialized
INFO - 2018-07-22 17:53:57 --> Helper loaded: url_helper
INFO - 2018-07-22 17:53:57 --> Helper loaded: form_helper
INFO - 2018-07-22 17:53:57 --> Helper loaded: language_helper
DEBUG - 2018-07-22 17:53:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-22 17:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-22 17:53:57 --> User Agent Class Initialized
INFO - 2018-07-22 17:53:57 --> Controller Class Initialized
INFO - 2018-07-22 17:53:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-22 17:53:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-22 17:53:57 --> Pixel_Model class loaded
INFO - 2018-07-22 17:53:57 --> Database Driver Class Initialized
INFO - 2018-07-22 17:53:57 --> Model "QuestionsModel" initialized
INFO - 2018-07-22 17:53:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-22 17:53:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-22 17:53:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-22 17:53:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-22 17:53:57 --> Final output sent to browser
DEBUG - 2018-07-22 17:53:57 --> Total execution time: 0.0403
INFO - 2018-07-22 18:08:19 --> Config Class Initialized
INFO - 2018-07-22 18:08:19 --> Hooks Class Initialized
DEBUG - 2018-07-22 18:08:19 --> UTF-8 Support Enabled
INFO - 2018-07-22 18:08:19 --> Utf8 Class Initialized
INFO - 2018-07-22 18:08:19 --> URI Class Initialized
INFO - 2018-07-22 18:08:19 --> Router Class Initialized
INFO - 2018-07-22 18:08:19 --> Output Class Initialized
INFO - 2018-07-22 18:08:19 --> Security Class Initialized
DEBUG - 2018-07-22 18:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-22 18:08:19 --> CSRF cookie sent
INFO - 2018-07-22 18:08:19 --> Input Class Initialized
INFO - 2018-07-22 18:08:19 --> Language Class Initialized
ERROR - 2018-07-22 18:08:19 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-22 18:34:43 --> Config Class Initialized
INFO - 2018-07-22 18:34:43 --> Hooks Class Initialized
DEBUG - 2018-07-22 18:34:43 --> UTF-8 Support Enabled
INFO - 2018-07-22 18:34:43 --> Utf8 Class Initialized
INFO - 2018-07-22 18:34:43 --> URI Class Initialized
DEBUG - 2018-07-22 18:34:43 --> No URI present. Default controller set.
INFO - 2018-07-22 18:34:43 --> Router Class Initialized
INFO - 2018-07-22 18:34:43 --> Output Class Initialized
INFO - 2018-07-22 18:34:43 --> Security Class Initialized
DEBUG - 2018-07-22 18:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-22 18:34:43 --> CSRF cookie sent
INFO - 2018-07-22 18:34:43 --> Input Class Initialized
INFO - 2018-07-22 18:34:43 --> Language Class Initialized
INFO - 2018-07-22 18:34:43 --> Loader Class Initialized
INFO - 2018-07-22 18:34:43 --> Helper loaded: url_helper
INFO - 2018-07-22 18:34:43 --> Helper loaded: form_helper
INFO - 2018-07-22 18:34:43 --> Helper loaded: language_helper
DEBUG - 2018-07-22 18:34:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-22 18:34:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-22 18:34:43 --> User Agent Class Initialized
INFO - 2018-07-22 18:34:43 --> Controller Class Initialized
INFO - 2018-07-22 18:34:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-22 18:34:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-22 18:34:43 --> Pixel_Model class loaded
INFO - 2018-07-22 18:34:43 --> Database Driver Class Initialized
INFO - 2018-07-22 18:34:43 --> Model "QuestionsModel" initialized
INFO - 2018-07-22 18:34:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-22 18:34:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-22 18:34:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-22 18:34:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-22 18:34:43 --> Final output sent to browser
DEBUG - 2018-07-22 18:34:43 --> Total execution time: 0.0369
INFO - 2018-07-22 18:34:44 --> Config Class Initialized
INFO - 2018-07-22 18:34:44 --> Hooks Class Initialized
DEBUG - 2018-07-22 18:34:44 --> UTF-8 Support Enabled
INFO - 2018-07-22 18:34:44 --> Utf8 Class Initialized
INFO - 2018-07-22 18:34:44 --> URI Class Initialized
DEBUG - 2018-07-22 18:34:44 --> No URI present. Default controller set.
INFO - 2018-07-22 18:34:44 --> Router Class Initialized
INFO - 2018-07-22 18:34:44 --> Output Class Initialized
INFO - 2018-07-22 18:34:44 --> Security Class Initialized
DEBUG - 2018-07-22 18:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-22 18:34:44 --> CSRF cookie sent
INFO - 2018-07-22 18:34:44 --> Input Class Initialized
INFO - 2018-07-22 18:34:44 --> Language Class Initialized
INFO - 2018-07-22 18:34:44 --> Loader Class Initialized
INFO - 2018-07-22 18:34:44 --> Helper loaded: url_helper
INFO - 2018-07-22 18:34:44 --> Helper loaded: form_helper
INFO - 2018-07-22 18:34:44 --> Helper loaded: language_helper
DEBUG - 2018-07-22 18:34:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-22 18:34:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-22 18:34:44 --> User Agent Class Initialized
INFO - 2018-07-22 18:34:44 --> Controller Class Initialized
INFO - 2018-07-22 18:34:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-22 18:34:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-22 18:34:44 --> Pixel_Model class loaded
INFO - 2018-07-22 18:34:44 --> Database Driver Class Initialized
INFO - 2018-07-22 18:34:44 --> Model "QuestionsModel" initialized
INFO - 2018-07-22 18:34:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-22 18:34:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-22 18:34:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-22 18:34:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-22 18:34:44 --> Final output sent to browser
DEBUG - 2018-07-22 18:34:44 --> Total execution time: 0.0355
INFO - 2018-07-22 18:34:44 --> Config Class Initialized
INFO - 2018-07-22 18:34:44 --> Hooks Class Initialized
DEBUG - 2018-07-22 18:34:44 --> UTF-8 Support Enabled
INFO - 2018-07-22 18:34:44 --> Utf8 Class Initialized
INFO - 2018-07-22 18:34:44 --> URI Class Initialized
DEBUG - 2018-07-22 18:34:44 --> No URI present. Default controller set.
INFO - 2018-07-22 18:34:44 --> Router Class Initialized
INFO - 2018-07-22 18:34:44 --> Output Class Initialized
INFO - 2018-07-22 18:34:44 --> Security Class Initialized
DEBUG - 2018-07-22 18:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-22 18:34:44 --> CSRF cookie sent
INFO - 2018-07-22 18:34:44 --> Input Class Initialized
INFO - 2018-07-22 18:34:44 --> Language Class Initialized
INFO - 2018-07-22 18:34:44 --> Loader Class Initialized
INFO - 2018-07-22 18:34:44 --> Helper loaded: url_helper
INFO - 2018-07-22 18:34:44 --> Helper loaded: form_helper
INFO - 2018-07-22 18:34:44 --> Helper loaded: language_helper
DEBUG - 2018-07-22 18:34:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-22 18:34:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-22 18:34:44 --> User Agent Class Initialized
INFO - 2018-07-22 18:34:44 --> Controller Class Initialized
INFO - 2018-07-22 18:34:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-22 18:34:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-22 18:34:44 --> Pixel_Model class loaded
INFO - 2018-07-22 18:34:44 --> Database Driver Class Initialized
INFO - 2018-07-22 18:34:44 --> Model "QuestionsModel" initialized
INFO - 2018-07-22 18:34:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-22 18:34:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-22 18:34:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-22 18:34:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-22 18:34:44 --> Final output sent to browser
DEBUG - 2018-07-22 18:34:44 --> Total execution time: 0.0329
INFO - 2018-07-22 18:34:45 --> Config Class Initialized
INFO - 2018-07-22 18:34:45 --> Hooks Class Initialized
DEBUG - 2018-07-22 18:34:45 --> UTF-8 Support Enabled
INFO - 2018-07-22 18:34:45 --> Utf8 Class Initialized
INFO - 2018-07-22 18:34:45 --> URI Class Initialized
INFO - 2018-07-22 18:34:45 --> Router Class Initialized
INFO - 2018-07-22 18:34:45 --> Output Class Initialized
INFO - 2018-07-22 18:34:45 --> Security Class Initialized
DEBUG - 2018-07-22 18:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-22 18:34:45 --> CSRF cookie sent
INFO - 2018-07-22 18:34:45 --> Input Class Initialized
INFO - 2018-07-22 18:34:45 --> Language Class Initialized
ERROR - 2018-07-22 18:34:45 --> 404 Page Not Found: 405shtml/index
INFO - 2018-07-22 18:34:52 --> Config Class Initialized
INFO - 2018-07-22 18:34:52 --> Hooks Class Initialized
DEBUG - 2018-07-22 18:34:52 --> UTF-8 Support Enabled
INFO - 2018-07-22 18:34:52 --> Utf8 Class Initialized
INFO - 2018-07-22 18:34:52 --> URI Class Initialized
DEBUG - 2018-07-22 18:34:52 --> No URI present. Default controller set.
INFO - 2018-07-22 18:34:52 --> Router Class Initialized
INFO - 2018-07-22 18:34:52 --> Output Class Initialized
INFO - 2018-07-22 18:34:52 --> Security Class Initialized
DEBUG - 2018-07-22 18:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-22 18:34:52 --> CSRF cookie sent
INFO - 2018-07-22 18:34:52 --> Input Class Initialized
INFO - 2018-07-22 18:34:52 --> Language Class Initialized
INFO - 2018-07-22 18:34:52 --> Loader Class Initialized
INFO - 2018-07-22 18:34:52 --> Helper loaded: url_helper
INFO - 2018-07-22 18:34:52 --> Helper loaded: form_helper
INFO - 2018-07-22 18:34:52 --> Helper loaded: language_helper
DEBUG - 2018-07-22 18:34:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-22 18:34:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-22 18:34:52 --> User Agent Class Initialized
INFO - 2018-07-22 18:34:52 --> Controller Class Initialized
INFO - 2018-07-22 18:34:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-22 18:34:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-22 18:34:52 --> Pixel_Model class loaded
INFO - 2018-07-22 18:34:52 --> Database Driver Class Initialized
INFO - 2018-07-22 18:34:52 --> Model "QuestionsModel" initialized
INFO - 2018-07-22 18:34:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-22 18:34:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-22 18:34:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-22 18:34:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-22 18:34:52 --> Final output sent to browser
DEBUG - 2018-07-22 18:34:52 --> Total execution time: 0.0372
INFO - 2018-07-22 18:34:52 --> Config Class Initialized
INFO - 2018-07-22 18:34:52 --> Hooks Class Initialized
DEBUG - 2018-07-22 18:34:52 --> UTF-8 Support Enabled
INFO - 2018-07-22 18:34:52 --> Utf8 Class Initialized
INFO - 2018-07-22 18:34:52 --> URI Class Initialized
INFO - 2018-07-22 18:34:52 --> Router Class Initialized
INFO - 2018-07-22 18:34:52 --> Output Class Initialized
INFO - 2018-07-22 18:34:52 --> Security Class Initialized
DEBUG - 2018-07-22 18:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-22 18:34:52 --> CSRF cookie sent
INFO - 2018-07-22 18:34:52 --> Input Class Initialized
INFO - 2018-07-22 18:34:52 --> Language Class Initialized
ERROR - 2018-07-22 18:34:52 --> 404 Page Not Found: 404testpage4525d2fdc/index
INFO - 2018-07-22 18:34:53 --> Config Class Initialized
INFO - 2018-07-22 18:34:53 --> Hooks Class Initialized
DEBUG - 2018-07-22 18:34:53 --> UTF-8 Support Enabled
INFO - 2018-07-22 18:34:53 --> Utf8 Class Initialized
INFO - 2018-07-22 18:34:53 --> URI Class Initialized
INFO - 2018-07-22 18:34:53 --> Router Class Initialized
INFO - 2018-07-22 18:34:53 --> Output Class Initialized
INFO - 2018-07-22 18:34:53 --> Security Class Initialized
DEBUG - 2018-07-22 18:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-22 18:34:53 --> CSRF cookie sent
INFO - 2018-07-22 18:34:53 --> Input Class Initialized
INFO - 2018-07-22 18:34:53 --> Language Class Initialized
ERROR - 2018-07-22 18:34:53 --> 404 Page Not Found: 404javascriptjs/index
INFO - 2018-07-22 18:34:53 --> Config Class Initialized
INFO - 2018-07-22 18:34:53 --> Hooks Class Initialized
DEBUG - 2018-07-22 18:34:53 --> UTF-8 Support Enabled
INFO - 2018-07-22 18:34:53 --> Utf8 Class Initialized
INFO - 2018-07-22 18:34:53 --> URI Class Initialized
INFO - 2018-07-22 18:34:53 --> Router Class Initialized
INFO - 2018-07-22 18:34:53 --> Output Class Initialized
INFO - 2018-07-22 18:34:53 --> Security Class Initialized
DEBUG - 2018-07-22 18:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-22 18:34:53 --> CSRF cookie sent
INFO - 2018-07-22 18:34:53 --> Input Class Initialized
INFO - 2018-07-22 18:34:53 --> Language Class Initialized
INFO - 2018-07-22 18:34:53 --> Loader Class Initialized
INFO - 2018-07-22 18:34:53 --> Helper loaded: url_helper
INFO - 2018-07-22 18:34:53 --> Helper loaded: form_helper
INFO - 2018-07-22 18:34:53 --> Helper loaded: language_helper
DEBUG - 2018-07-22 18:34:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-22 18:34:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-22 18:34:53 --> User Agent Class Initialized
INFO - 2018-07-22 18:34:53 --> Controller Class Initialized
INFO - 2018-07-22 18:34:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-22 18:34:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-22 18:34:53 --> Pixel_Model class loaded
INFO - 2018-07-22 18:34:53 --> Database Driver Class Initialized
INFO - 2018-07-22 18:34:53 --> Model "QuestionsModel" initialized
INFO - 2018-07-22 18:34:53 --> Config Class Initialized
INFO - 2018-07-22 18:34:53 --> Hooks Class Initialized
DEBUG - 2018-07-22 18:34:53 --> UTF-8 Support Enabled
INFO - 2018-07-22 18:34:53 --> Utf8 Class Initialized
INFO - 2018-07-22 18:34:53 --> URI Class Initialized
INFO - 2018-07-22 18:34:53 --> Router Class Initialized
INFO - 2018-07-22 18:34:53 --> Output Class Initialized
INFO - 2018-07-22 18:34:53 --> Security Class Initialized
DEBUG - 2018-07-22 18:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-22 18:34:53 --> CSRF cookie sent
INFO - 2018-07-22 18:34:53 --> Input Class Initialized
INFO - 2018-07-22 18:34:53 --> Language Class Initialized
INFO - 2018-07-22 18:34:53 --> Loader Class Initialized
INFO - 2018-07-22 18:34:53 --> Helper loaded: url_helper
INFO - 2018-07-22 18:34:53 --> Helper loaded: form_helper
INFO - 2018-07-22 18:34:53 --> Helper loaded: language_helper
DEBUG - 2018-07-22 18:34:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-22 18:34:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-22 18:34:53 --> User Agent Class Initialized
INFO - 2018-07-22 18:34:53 --> Controller Class Initialized
INFO - 2018-07-22 18:34:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-22 18:34:53 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-22 18:34:53 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-22 18:34:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-22 18:34:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-22 18:34:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-22 18:34:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-22 18:34:53 --> Could not find the language line "req_email"
INFO - 2018-07-22 18:34:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-22 18:34:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-22 18:34:53 --> Final output sent to browser
DEBUG - 2018-07-22 18:34:53 --> Total execution time: 0.0237
INFO - 2018-07-22 18:34:53 --> Config Class Initialized
INFO - 2018-07-22 18:34:53 --> Hooks Class Initialized
DEBUG - 2018-07-22 18:34:53 --> UTF-8 Support Enabled
INFO - 2018-07-22 18:34:53 --> Utf8 Class Initialized
INFO - 2018-07-22 18:34:53 --> URI Class Initialized
INFO - 2018-07-22 18:34:53 --> Router Class Initialized
INFO - 2018-07-22 18:34:53 --> Output Class Initialized
INFO - 2018-07-22 18:34:53 --> Security Class Initialized
DEBUG - 2018-07-22 18:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-22 18:34:53 --> CSRF cookie sent
INFO - 2018-07-22 18:34:53 --> Input Class Initialized
INFO - 2018-07-22 18:34:53 --> Language Class Initialized
INFO - 2018-07-22 18:34:53 --> Loader Class Initialized
INFO - 2018-07-22 18:34:53 --> Helper loaded: url_helper
INFO - 2018-07-22 18:34:53 --> Helper loaded: form_helper
INFO - 2018-07-22 18:34:53 --> Helper loaded: language_helper
DEBUG - 2018-07-22 18:34:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-22 18:34:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-22 18:34:53 --> User Agent Class Initialized
INFO - 2018-07-22 18:34:53 --> Controller Class Initialized
INFO - 2018-07-22 18:34:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-22 18:34:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-22 18:34:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-22 18:34:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-22 18:34:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-22 18:34:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-22 18:34:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-07-22 18:34:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-22 18:34:53 --> Final output sent to browser
DEBUG - 2018-07-22 18:34:53 --> Total execution time: 0.0237
INFO - 2018-07-22 18:34:54 --> Config Class Initialized
INFO - 2018-07-22 18:34:54 --> Hooks Class Initialized
DEBUG - 2018-07-22 18:34:54 --> UTF-8 Support Enabled
INFO - 2018-07-22 18:34:54 --> Utf8 Class Initialized
INFO - 2018-07-22 18:34:54 --> URI Class Initialized
INFO - 2018-07-22 18:34:54 --> Router Class Initialized
INFO - 2018-07-22 18:34:54 --> Output Class Initialized
INFO - 2018-07-22 18:34:54 --> Security Class Initialized
DEBUG - 2018-07-22 18:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-22 18:34:54 --> CSRF cookie sent
INFO - 2018-07-22 18:34:54 --> Input Class Initialized
INFO - 2018-07-22 18:34:54 --> Language Class Initialized
INFO - 2018-07-22 18:34:54 --> Loader Class Initialized
INFO - 2018-07-22 18:34:54 --> Helper loaded: url_helper
INFO - 2018-07-22 18:34:54 --> Helper loaded: form_helper
INFO - 2018-07-22 18:34:54 --> Helper loaded: language_helper
DEBUG - 2018-07-22 18:34:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-22 18:34:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-22 18:34:54 --> User Agent Class Initialized
INFO - 2018-07-22 18:34:54 --> Controller Class Initialized
INFO - 2018-07-22 18:34:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-22 18:34:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-22 18:34:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-22 18:34:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-22 18:34:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-22 18:34:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-22 18:34:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-07-22 18:34:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-22 18:34:54 --> Final output sent to browser
DEBUG - 2018-07-22 18:34:54 --> Total execution time: 0.0208
INFO - 2018-07-22 18:34:54 --> Config Class Initialized
INFO - 2018-07-22 18:34:54 --> Hooks Class Initialized
DEBUG - 2018-07-22 18:34:54 --> UTF-8 Support Enabled
INFO - 2018-07-22 18:34:54 --> Utf8 Class Initialized
INFO - 2018-07-22 18:34:54 --> URI Class Initialized
INFO - 2018-07-22 18:34:54 --> Router Class Initialized
INFO - 2018-07-22 18:34:54 --> Output Class Initialized
INFO - 2018-07-22 18:34:54 --> Security Class Initialized
DEBUG - 2018-07-22 18:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-22 18:34:54 --> CSRF cookie sent
INFO - 2018-07-22 18:34:54 --> Input Class Initialized
INFO - 2018-07-22 18:34:54 --> Language Class Initialized
INFO - 2018-07-22 18:34:54 --> Loader Class Initialized
INFO - 2018-07-22 18:34:54 --> Helper loaded: url_helper
INFO - 2018-07-22 18:34:54 --> Helper loaded: form_helper
INFO - 2018-07-22 18:34:54 --> Helper loaded: language_helper
DEBUG - 2018-07-22 18:34:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-22 18:34:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-22 18:34:54 --> User Agent Class Initialized
INFO - 2018-07-22 18:34:54 --> Controller Class Initialized
INFO - 2018-07-22 18:34:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-22 18:34:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-22 18:34:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-22 18:34:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-22 18:34:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-22 18:34:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-22 18:34:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-07-22 18:34:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-22 18:34:54 --> Final output sent to browser
DEBUG - 2018-07-22 18:34:54 --> Total execution time: 0.0215
INFO - 2018-07-22 18:34:54 --> Config Class Initialized
INFO - 2018-07-22 18:34:54 --> Hooks Class Initialized
DEBUG - 2018-07-22 18:34:54 --> UTF-8 Support Enabled
INFO - 2018-07-22 18:34:54 --> Utf8 Class Initialized
INFO - 2018-07-22 18:34:54 --> URI Class Initialized
INFO - 2018-07-22 18:34:54 --> Router Class Initialized
INFO - 2018-07-22 18:34:54 --> Output Class Initialized
INFO - 2018-07-22 18:34:54 --> Security Class Initialized
DEBUG - 2018-07-22 18:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-22 18:34:54 --> CSRF cookie sent
INFO - 2018-07-22 18:34:54 --> Input Class Initialized
INFO - 2018-07-22 18:34:54 --> Language Class Initialized
INFO - 2018-07-22 18:34:54 --> Loader Class Initialized
INFO - 2018-07-22 18:34:54 --> Helper loaded: url_helper
INFO - 2018-07-22 18:34:54 --> Helper loaded: form_helper
INFO - 2018-07-22 18:34:54 --> Helper loaded: language_helper
DEBUG - 2018-07-22 18:34:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-22 18:34:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-22 18:34:54 --> User Agent Class Initialized
INFO - 2018-07-22 18:34:54 --> Controller Class Initialized
INFO - 2018-07-22 18:34:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-22 18:34:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-22 18:34:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-22 18:34:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-22 18:34:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-22 18:34:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-22 18:34:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-07-22 18:34:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-22 18:34:54 --> Final output sent to browser
DEBUG - 2018-07-22 18:34:54 --> Total execution time: 0.0230
INFO - 2018-07-22 18:34:55 --> Config Class Initialized
INFO - 2018-07-22 18:34:55 --> Hooks Class Initialized
DEBUG - 2018-07-22 18:34:55 --> UTF-8 Support Enabled
INFO - 2018-07-22 18:34:55 --> Utf8 Class Initialized
INFO - 2018-07-22 18:34:55 --> URI Class Initialized
INFO - 2018-07-22 18:34:55 --> Router Class Initialized
INFO - 2018-07-22 18:34:55 --> Output Class Initialized
INFO - 2018-07-22 18:34:55 --> Security Class Initialized
DEBUG - 2018-07-22 18:34:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-22 18:34:55 --> CSRF cookie sent
INFO - 2018-07-22 18:34:55 --> Input Class Initialized
INFO - 2018-07-22 18:34:55 --> Language Class Initialized
INFO - 2018-07-22 18:34:55 --> Loader Class Initialized
INFO - 2018-07-22 18:34:55 --> Helper loaded: url_helper
INFO - 2018-07-22 18:34:55 --> Helper loaded: form_helper
INFO - 2018-07-22 18:34:55 --> Helper loaded: language_helper
DEBUG - 2018-07-22 18:34:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-22 18:34:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-22 18:34:55 --> User Agent Class Initialized
INFO - 2018-07-22 18:34:55 --> Controller Class Initialized
INFO - 2018-07-22 18:34:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-22 18:34:55 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-22 18:34:55 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-22 18:34:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-22 18:34:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-22 18:34:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-22 18:34:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-22 18:34:55 --> Could not find the language line "req_email"
INFO - 2018-07-22 18:34:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-22 18:34:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-22 18:34:55 --> Final output sent to browser
DEBUG - 2018-07-22 18:34:55 --> Total execution time: 0.0229
INFO - 2018-07-22 18:34:55 --> Config Class Initialized
INFO - 2018-07-22 18:34:55 --> Hooks Class Initialized
DEBUG - 2018-07-22 18:34:55 --> UTF-8 Support Enabled
INFO - 2018-07-22 18:34:55 --> Utf8 Class Initialized
INFO - 2018-07-22 18:34:55 --> URI Class Initialized
INFO - 2018-07-22 18:34:55 --> Router Class Initialized
INFO - 2018-07-22 18:34:55 --> Output Class Initialized
INFO - 2018-07-22 18:34:55 --> Security Class Initialized
DEBUG - 2018-07-22 18:34:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-22 18:34:55 --> CSRF cookie sent
INFO - 2018-07-22 18:34:55 --> Input Class Initialized
INFO - 2018-07-22 18:34:55 --> Language Class Initialized
INFO - 2018-07-22 18:34:55 --> Loader Class Initialized
INFO - 2018-07-22 18:34:55 --> Helper loaded: url_helper
INFO - 2018-07-22 18:34:55 --> Helper loaded: form_helper
INFO - 2018-07-22 18:34:55 --> Helper loaded: language_helper
DEBUG - 2018-07-22 18:34:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-22 18:34:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-22 18:34:55 --> User Agent Class Initialized
INFO - 2018-07-22 18:34:55 --> Controller Class Initialized
INFO - 2018-07-22 18:34:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-22 18:34:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-22 18:34:55 --> Pixel_Model class loaded
INFO - 2018-07-22 18:34:55 --> Database Driver Class Initialized
INFO - 2018-07-22 18:34:55 --> Model "QuestionsModel" initialized
INFO - 2018-07-22 18:34:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-22 18:34:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-22 18:34:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-22 18:34:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-22 18:34:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/buy_gift.php
INFO - 2018-07-22 18:34:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-22 18:34:55 --> Final output sent to browser
DEBUG - 2018-07-22 18:34:55 --> Total execution time: 0.0350
INFO - 2018-07-22 19:19:38 --> Config Class Initialized
INFO - 2018-07-22 19:19:38 --> Hooks Class Initialized
DEBUG - 2018-07-22 19:19:38 --> UTF-8 Support Enabled
INFO - 2018-07-22 19:19:38 --> Utf8 Class Initialized
INFO - 2018-07-22 19:19:38 --> URI Class Initialized
DEBUG - 2018-07-22 19:19:38 --> No URI present. Default controller set.
INFO - 2018-07-22 19:19:38 --> Router Class Initialized
INFO - 2018-07-22 19:19:38 --> Output Class Initialized
INFO - 2018-07-22 19:19:38 --> Security Class Initialized
DEBUG - 2018-07-22 19:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-22 19:19:38 --> CSRF cookie sent
INFO - 2018-07-22 19:19:38 --> Input Class Initialized
INFO - 2018-07-22 19:19:38 --> Language Class Initialized
INFO - 2018-07-22 19:19:38 --> Loader Class Initialized
INFO - 2018-07-22 19:19:38 --> Helper loaded: url_helper
INFO - 2018-07-22 19:19:38 --> Helper loaded: form_helper
INFO - 2018-07-22 19:19:38 --> Helper loaded: language_helper
DEBUG - 2018-07-22 19:19:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-22 19:19:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-22 19:19:38 --> User Agent Class Initialized
INFO - 2018-07-22 19:19:38 --> Controller Class Initialized
INFO - 2018-07-22 19:19:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-22 19:19:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-22 19:19:38 --> Pixel_Model class loaded
INFO - 2018-07-22 19:19:38 --> Database Driver Class Initialized
INFO - 2018-07-22 19:19:38 --> Model "QuestionsModel" initialized
INFO - 2018-07-22 19:19:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-22 19:19:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-22 19:19:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-22 19:19:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-22 19:19:38 --> Final output sent to browser
DEBUG - 2018-07-22 19:19:38 --> Total execution time: 0.0324
INFO - 2018-07-22 19:21:26 --> Config Class Initialized
INFO - 2018-07-22 19:21:26 --> Hooks Class Initialized
DEBUG - 2018-07-22 19:21:26 --> UTF-8 Support Enabled
INFO - 2018-07-22 19:21:26 --> Utf8 Class Initialized
INFO - 2018-07-22 19:21:26 --> URI Class Initialized
INFO - 2018-07-22 19:21:26 --> Router Class Initialized
INFO - 2018-07-22 19:21:26 --> Output Class Initialized
INFO - 2018-07-22 19:21:26 --> Security Class Initialized
DEBUG - 2018-07-22 19:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-22 19:21:26 --> CSRF cookie sent
INFO - 2018-07-22 19:21:26 --> Input Class Initialized
INFO - 2018-07-22 19:21:26 --> Language Class Initialized
ERROR - 2018-07-22 19:21:26 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-22 20:17:52 --> Config Class Initialized
INFO - 2018-07-22 20:17:52 --> Hooks Class Initialized
DEBUG - 2018-07-22 20:17:52 --> UTF-8 Support Enabled
INFO - 2018-07-22 20:17:52 --> Utf8 Class Initialized
INFO - 2018-07-22 20:17:52 --> URI Class Initialized
INFO - 2018-07-22 20:17:52 --> Router Class Initialized
INFO - 2018-07-22 20:17:52 --> Output Class Initialized
INFO - 2018-07-22 20:17:52 --> Security Class Initialized
DEBUG - 2018-07-22 20:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-22 20:17:52 --> CSRF cookie sent
INFO - 2018-07-22 20:17:52 --> Input Class Initialized
INFO - 2018-07-22 20:17:52 --> Language Class Initialized
ERROR - 2018-07-22 20:17:52 --> 404 Page Not Found: Js/mage
INFO - 2018-07-22 20:17:55 --> Config Class Initialized
INFO - 2018-07-22 20:17:55 --> Hooks Class Initialized
DEBUG - 2018-07-22 20:17:55 --> UTF-8 Support Enabled
INFO - 2018-07-22 20:17:55 --> Utf8 Class Initialized
INFO - 2018-07-22 20:17:55 --> URI Class Initialized
INFO - 2018-07-22 20:17:55 --> Router Class Initialized
INFO - 2018-07-22 20:17:55 --> Output Class Initialized
INFO - 2018-07-22 20:17:55 --> Security Class Initialized
DEBUG - 2018-07-22 20:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-22 20:17:55 --> CSRF cookie sent
INFO - 2018-07-22 20:17:55 --> Input Class Initialized
INFO - 2018-07-22 20:17:55 --> Language Class Initialized
ERROR - 2018-07-22 20:17:55 --> 404 Page Not Found: Js/mage

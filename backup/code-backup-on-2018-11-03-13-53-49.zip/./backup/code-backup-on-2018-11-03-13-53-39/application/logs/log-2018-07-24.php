<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-07-24 01:24:12 --> Config Class Initialized
INFO - 2018-07-24 01:24:12 --> Hooks Class Initialized
DEBUG - 2018-07-24 01:24:12 --> UTF-8 Support Enabled
INFO - 2018-07-24 01:24:12 --> Utf8 Class Initialized
INFO - 2018-07-24 01:24:12 --> URI Class Initialized
INFO - 2018-07-24 01:24:12 --> Router Class Initialized
INFO - 2018-07-24 01:24:12 --> Output Class Initialized
INFO - 2018-07-24 01:24:12 --> Security Class Initialized
DEBUG - 2018-07-24 01:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 01:24:12 --> CSRF cookie sent
INFO - 2018-07-24 01:24:12 --> Input Class Initialized
INFO - 2018-07-24 01:24:12 --> Language Class Initialized
ERROR - 2018-07-24 01:24:12 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-24 01:24:15 --> Config Class Initialized
INFO - 2018-07-24 01:24:15 --> Hooks Class Initialized
DEBUG - 2018-07-24 01:24:15 --> UTF-8 Support Enabled
INFO - 2018-07-24 01:24:15 --> Utf8 Class Initialized
INFO - 2018-07-24 01:24:15 --> URI Class Initialized
DEBUG - 2018-07-24 01:24:15 --> No URI present. Default controller set.
INFO - 2018-07-24 01:24:15 --> Router Class Initialized
INFO - 2018-07-24 01:24:15 --> Output Class Initialized
INFO - 2018-07-24 01:24:15 --> Security Class Initialized
DEBUG - 2018-07-24 01:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 01:24:15 --> CSRF cookie sent
INFO - 2018-07-24 01:24:15 --> Input Class Initialized
INFO - 2018-07-24 01:24:15 --> Language Class Initialized
INFO - 2018-07-24 01:24:15 --> Loader Class Initialized
INFO - 2018-07-24 01:24:15 --> Helper loaded: url_helper
INFO - 2018-07-24 01:24:15 --> Helper loaded: form_helper
INFO - 2018-07-24 01:24:15 --> Helper loaded: language_helper
DEBUG - 2018-07-24 01:24:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 01:24:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 01:24:15 --> User Agent Class Initialized
INFO - 2018-07-24 01:24:15 --> Controller Class Initialized
INFO - 2018-07-24 01:24:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 01:24:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-24 01:24:15 --> Pixel_Model class loaded
INFO - 2018-07-24 01:24:15 --> Database Driver Class Initialized
INFO - 2018-07-24 01:24:15 --> Model "QuestionsModel" initialized
INFO - 2018-07-24 01:24:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-24 01:24:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-24 01:24:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-24 01:24:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-24 01:24:15 --> Final output sent to browser
DEBUG - 2018-07-24 01:24:15 --> Total execution time: 0.0332
INFO - 2018-07-24 01:30:59 --> Config Class Initialized
INFO - 2018-07-24 01:30:59 --> Hooks Class Initialized
DEBUG - 2018-07-24 01:30:59 --> UTF-8 Support Enabled
INFO - 2018-07-24 01:30:59 --> Utf8 Class Initialized
INFO - 2018-07-24 01:30:59 --> URI Class Initialized
INFO - 2018-07-24 01:30:59 --> Router Class Initialized
INFO - 2018-07-24 01:30:59 --> Output Class Initialized
INFO - 2018-07-24 01:30:59 --> Security Class Initialized
DEBUG - 2018-07-24 01:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 01:30:59 --> CSRF cookie sent
INFO - 2018-07-24 01:30:59 --> Input Class Initialized
INFO - 2018-07-24 01:30:59 --> Language Class Initialized
INFO - 2018-07-24 01:30:59 --> Loader Class Initialized
INFO - 2018-07-24 01:30:59 --> Helper loaded: url_helper
INFO - 2018-07-24 01:30:59 --> Helper loaded: form_helper
INFO - 2018-07-24 01:30:59 --> Helper loaded: language_helper
DEBUG - 2018-07-24 01:30:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 01:30:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 01:30:59 --> User Agent Class Initialized
INFO - 2018-07-24 01:30:59 --> Controller Class Initialized
INFO - 2018-07-24 01:30:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 01:30:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-24 01:30:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-24 01:30:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-24 01:30:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-24 01:30:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-24 01:30:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-07-24 01:30:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-24 01:30:59 --> Final output sent to browser
DEBUG - 2018-07-24 01:30:59 --> Total execution time: 0.0260
INFO - 2018-07-24 03:25:17 --> Config Class Initialized
INFO - 2018-07-24 03:25:17 --> Hooks Class Initialized
DEBUG - 2018-07-24 03:25:17 --> UTF-8 Support Enabled
INFO - 2018-07-24 03:25:17 --> Utf8 Class Initialized
INFO - 2018-07-24 03:25:17 --> URI Class Initialized
INFO - 2018-07-24 03:25:17 --> Router Class Initialized
INFO - 2018-07-24 03:25:17 --> Output Class Initialized
INFO - 2018-07-24 03:25:17 --> Security Class Initialized
DEBUG - 2018-07-24 03:25:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 03:25:17 --> CSRF cookie sent
INFO - 2018-07-24 03:25:17 --> Input Class Initialized
INFO - 2018-07-24 03:25:17 --> Language Class Initialized
ERROR - 2018-07-24 03:25:17 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-24 03:25:17 --> Config Class Initialized
INFO - 2018-07-24 03:25:17 --> Hooks Class Initialized
DEBUG - 2018-07-24 03:25:17 --> UTF-8 Support Enabled
INFO - 2018-07-24 03:25:17 --> Utf8 Class Initialized
INFO - 2018-07-24 03:25:17 --> URI Class Initialized
DEBUG - 2018-07-24 03:25:17 --> No URI present. Default controller set.
INFO - 2018-07-24 03:25:17 --> Router Class Initialized
INFO - 2018-07-24 03:25:17 --> Output Class Initialized
INFO - 2018-07-24 03:25:17 --> Security Class Initialized
DEBUG - 2018-07-24 03:25:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 03:25:17 --> CSRF cookie sent
INFO - 2018-07-24 03:25:17 --> Input Class Initialized
INFO - 2018-07-24 03:25:17 --> Language Class Initialized
INFO - 2018-07-24 03:25:17 --> Loader Class Initialized
INFO - 2018-07-24 03:25:17 --> Helper loaded: url_helper
INFO - 2018-07-24 03:25:17 --> Helper loaded: form_helper
INFO - 2018-07-24 03:25:17 --> Helper loaded: language_helper
DEBUG - 2018-07-24 03:25:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 03:25:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 03:25:17 --> User Agent Class Initialized
INFO - 2018-07-24 03:25:17 --> Controller Class Initialized
INFO - 2018-07-24 03:25:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 03:25:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-24 03:25:17 --> Pixel_Model class loaded
INFO - 2018-07-24 03:25:17 --> Database Driver Class Initialized
INFO - 2018-07-24 03:25:17 --> Model "QuestionsModel" initialized
INFO - 2018-07-24 03:25:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-24 03:25:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-24 03:25:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-24 03:25:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-24 03:25:17 --> Final output sent to browser
DEBUG - 2018-07-24 03:25:17 --> Total execution time: 0.0308
INFO - 2018-07-24 03:25:18 --> Config Class Initialized
INFO - 2018-07-24 03:25:18 --> Hooks Class Initialized
DEBUG - 2018-07-24 03:25:18 --> UTF-8 Support Enabled
INFO - 2018-07-24 03:25:18 --> Utf8 Class Initialized
INFO - 2018-07-24 03:25:18 --> URI Class Initialized
INFO - 2018-07-24 03:25:18 --> Router Class Initialized
INFO - 2018-07-24 03:25:18 --> Output Class Initialized
INFO - 2018-07-24 03:25:18 --> Security Class Initialized
DEBUG - 2018-07-24 03:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 03:25:18 --> CSRF cookie sent
INFO - 2018-07-24 03:25:18 --> Input Class Initialized
INFO - 2018-07-24 03:25:18 --> Language Class Initialized
ERROR - 2018-07-24 03:25:18 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-24 03:25:20 --> Config Class Initialized
INFO - 2018-07-24 03:25:20 --> Hooks Class Initialized
DEBUG - 2018-07-24 03:25:20 --> UTF-8 Support Enabled
INFO - 2018-07-24 03:25:20 --> Utf8 Class Initialized
INFO - 2018-07-24 03:25:20 --> URI Class Initialized
INFO - 2018-07-24 03:25:20 --> Router Class Initialized
INFO - 2018-07-24 03:25:20 --> Output Class Initialized
INFO - 2018-07-24 03:25:20 --> Security Class Initialized
DEBUG - 2018-07-24 03:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 03:25:20 --> CSRF cookie sent
INFO - 2018-07-24 03:25:20 --> Input Class Initialized
INFO - 2018-07-24 03:25:20 --> Language Class Initialized
INFO - 2018-07-24 03:25:20 --> Loader Class Initialized
INFO - 2018-07-24 03:25:20 --> Helper loaded: url_helper
INFO - 2018-07-24 03:25:20 --> Helper loaded: form_helper
INFO - 2018-07-24 03:25:20 --> Helper loaded: language_helper
DEBUG - 2018-07-24 03:25:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 03:25:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 03:25:20 --> User Agent Class Initialized
INFO - 2018-07-24 03:25:20 --> Controller Class Initialized
INFO - 2018-07-24 03:25:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 03:25:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-24 03:25:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-24 03:25:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-24 03:25:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-24 03:25:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-24 03:25:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-07-24 03:25:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-24 03:25:20 --> Final output sent to browser
DEBUG - 2018-07-24 03:25:20 --> Total execution time: 0.0276
INFO - 2018-07-24 03:25:25 --> Config Class Initialized
INFO - 2018-07-24 03:25:25 --> Hooks Class Initialized
DEBUG - 2018-07-24 03:25:25 --> UTF-8 Support Enabled
INFO - 2018-07-24 03:25:25 --> Utf8 Class Initialized
INFO - 2018-07-24 03:25:25 --> URI Class Initialized
INFO - 2018-07-24 03:25:25 --> Router Class Initialized
INFO - 2018-07-24 03:25:25 --> Output Class Initialized
INFO - 2018-07-24 03:25:25 --> Security Class Initialized
DEBUG - 2018-07-24 03:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 03:25:25 --> CSRF cookie sent
INFO - 2018-07-24 03:25:25 --> Input Class Initialized
INFO - 2018-07-24 03:25:25 --> Language Class Initialized
ERROR - 2018-07-24 03:25:25 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-24 03:25:25 --> Config Class Initialized
INFO - 2018-07-24 03:25:25 --> Hooks Class Initialized
DEBUG - 2018-07-24 03:25:25 --> UTF-8 Support Enabled
INFO - 2018-07-24 03:25:25 --> Utf8 Class Initialized
INFO - 2018-07-24 03:25:25 --> URI Class Initialized
INFO - 2018-07-24 03:25:25 --> Router Class Initialized
INFO - 2018-07-24 03:25:25 --> Output Class Initialized
INFO - 2018-07-24 03:25:25 --> Security Class Initialized
DEBUG - 2018-07-24 03:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 03:25:25 --> CSRF cookie sent
INFO - 2018-07-24 03:25:25 --> Input Class Initialized
INFO - 2018-07-24 03:25:25 --> Language Class Initialized
INFO - 2018-07-24 03:25:25 --> Loader Class Initialized
INFO - 2018-07-24 03:25:25 --> Helper loaded: url_helper
INFO - 2018-07-24 03:25:25 --> Helper loaded: form_helper
INFO - 2018-07-24 03:25:25 --> Helper loaded: language_helper
DEBUG - 2018-07-24 03:25:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 03:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 03:25:25 --> User Agent Class Initialized
INFO - 2018-07-24 03:25:25 --> Controller Class Initialized
INFO - 2018-07-24 03:25:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 03:25:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-24 03:25:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-24 03:25:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-24 03:25:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-24 03:25:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-24 03:25:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-07-24 03:25:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-24 03:25:25 --> Final output sent to browser
DEBUG - 2018-07-24 03:25:25 --> Total execution time: 0.0207
INFO - 2018-07-24 03:25:27 --> Config Class Initialized
INFO - 2018-07-24 03:25:27 --> Hooks Class Initialized
DEBUG - 2018-07-24 03:25:27 --> UTF-8 Support Enabled
INFO - 2018-07-24 03:25:27 --> Utf8 Class Initialized
INFO - 2018-07-24 03:25:27 --> URI Class Initialized
INFO - 2018-07-24 03:25:27 --> Router Class Initialized
INFO - 2018-07-24 03:25:27 --> Output Class Initialized
INFO - 2018-07-24 03:25:27 --> Security Class Initialized
DEBUG - 2018-07-24 03:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 03:25:27 --> CSRF cookie sent
INFO - 2018-07-24 03:25:27 --> Input Class Initialized
INFO - 2018-07-24 03:25:27 --> Language Class Initialized
INFO - 2018-07-24 03:25:27 --> Loader Class Initialized
INFO - 2018-07-24 03:25:27 --> Helper loaded: url_helper
INFO - 2018-07-24 03:25:27 --> Helper loaded: form_helper
INFO - 2018-07-24 03:25:27 --> Helper loaded: language_helper
DEBUG - 2018-07-24 03:25:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 03:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 03:25:27 --> User Agent Class Initialized
INFO - 2018-07-24 03:25:27 --> Controller Class Initialized
INFO - 2018-07-24 03:25:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 03:25:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-24 03:25:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-24 03:25:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-24 03:25:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-24 03:25:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-24 03:25:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/faqs.php
INFO - 2018-07-24 03:25:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-24 03:25:27 --> Final output sent to browser
DEBUG - 2018-07-24 03:25:27 --> Total execution time: 0.0324
INFO - 2018-07-24 03:25:29 --> Config Class Initialized
INFO - 2018-07-24 03:25:29 --> Hooks Class Initialized
DEBUG - 2018-07-24 03:25:29 --> UTF-8 Support Enabled
INFO - 2018-07-24 03:25:29 --> Utf8 Class Initialized
INFO - 2018-07-24 03:25:29 --> URI Class Initialized
DEBUG - 2018-07-24 03:25:29 --> No URI present. Default controller set.
INFO - 2018-07-24 03:25:29 --> Router Class Initialized
INFO - 2018-07-24 03:25:29 --> Output Class Initialized
INFO - 2018-07-24 03:25:29 --> Security Class Initialized
DEBUG - 2018-07-24 03:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 03:25:29 --> CSRF cookie sent
INFO - 2018-07-24 03:25:29 --> Input Class Initialized
INFO - 2018-07-24 03:25:29 --> Language Class Initialized
INFO - 2018-07-24 03:25:29 --> Loader Class Initialized
INFO - 2018-07-24 03:25:29 --> Helper loaded: url_helper
INFO - 2018-07-24 03:25:29 --> Helper loaded: form_helper
INFO - 2018-07-24 03:25:29 --> Helper loaded: language_helper
DEBUG - 2018-07-24 03:25:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 03:25:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 03:25:29 --> User Agent Class Initialized
INFO - 2018-07-24 03:25:29 --> Controller Class Initialized
INFO - 2018-07-24 03:25:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 03:25:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-24 03:25:29 --> Pixel_Model class loaded
INFO - 2018-07-24 03:25:29 --> Database Driver Class Initialized
INFO - 2018-07-24 03:25:29 --> Model "QuestionsModel" initialized
INFO - 2018-07-24 03:25:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-24 03:25:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-24 03:25:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-24 03:25:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-24 03:25:29 --> Final output sent to browser
DEBUG - 2018-07-24 03:25:29 --> Total execution time: 0.0325
INFO - 2018-07-24 03:25:31 --> Config Class Initialized
INFO - 2018-07-24 03:25:31 --> Hooks Class Initialized
DEBUG - 2018-07-24 03:25:31 --> UTF-8 Support Enabled
INFO - 2018-07-24 03:25:31 --> Utf8 Class Initialized
INFO - 2018-07-24 03:25:31 --> URI Class Initialized
INFO - 2018-07-24 03:25:31 --> Router Class Initialized
INFO - 2018-07-24 03:25:31 --> Output Class Initialized
INFO - 2018-07-24 03:25:31 --> Security Class Initialized
DEBUG - 2018-07-24 03:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 03:25:31 --> CSRF cookie sent
INFO - 2018-07-24 03:25:31 --> Input Class Initialized
INFO - 2018-07-24 03:25:31 --> Language Class Initialized
INFO - 2018-07-24 03:25:31 --> Loader Class Initialized
INFO - 2018-07-24 03:25:31 --> Helper loaded: url_helper
INFO - 2018-07-24 03:25:31 --> Helper loaded: form_helper
INFO - 2018-07-24 03:25:31 --> Helper loaded: language_helper
DEBUG - 2018-07-24 03:25:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 03:25:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 03:25:31 --> User Agent Class Initialized
INFO - 2018-07-24 03:25:31 --> Controller Class Initialized
INFO - 2018-07-24 03:25:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 03:25:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-24 03:25:31 --> Pixel_Model class loaded
INFO - 2018-07-24 03:25:31 --> Database Driver Class Initialized
INFO - 2018-07-24 03:25:31 --> Model "QuestionsModel" initialized
INFO - 2018-07-24 03:25:32 --> Config Class Initialized
INFO - 2018-07-24 03:25:32 --> Hooks Class Initialized
DEBUG - 2018-07-24 03:25:32 --> UTF-8 Support Enabled
INFO - 2018-07-24 03:25:32 --> Utf8 Class Initialized
INFO - 2018-07-24 03:25:32 --> URI Class Initialized
INFO - 2018-07-24 03:25:32 --> Router Class Initialized
INFO - 2018-07-24 03:25:32 --> Output Class Initialized
INFO - 2018-07-24 03:25:32 --> Security Class Initialized
DEBUG - 2018-07-24 03:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 03:25:32 --> CSRF cookie sent
INFO - 2018-07-24 03:25:32 --> Input Class Initialized
INFO - 2018-07-24 03:25:32 --> Language Class Initialized
INFO - 2018-07-24 03:25:32 --> Loader Class Initialized
INFO - 2018-07-24 03:25:32 --> Helper loaded: url_helper
INFO - 2018-07-24 03:25:32 --> Helper loaded: form_helper
INFO - 2018-07-24 03:25:32 --> Helper loaded: language_helper
DEBUG - 2018-07-24 03:25:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 03:25:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 03:25:32 --> User Agent Class Initialized
INFO - 2018-07-24 03:25:32 --> Controller Class Initialized
INFO - 2018-07-24 03:25:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 03:25:32 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-24 03:25:32 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-24 03:25:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-24 03:25:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-24 03:25:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-24 03:25:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-24 03:25:32 --> Could not find the language line "req_email"
INFO - 2018-07-24 03:25:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-24 03:25:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-24 03:25:32 --> Final output sent to browser
DEBUG - 2018-07-24 03:25:32 --> Total execution time: 0.0311
INFO - 2018-07-24 03:25:34 --> Config Class Initialized
INFO - 2018-07-24 03:25:34 --> Hooks Class Initialized
DEBUG - 2018-07-24 03:25:34 --> UTF-8 Support Enabled
INFO - 2018-07-24 03:25:34 --> Utf8 Class Initialized
INFO - 2018-07-24 03:25:34 --> URI Class Initialized
INFO - 2018-07-24 03:25:34 --> Router Class Initialized
INFO - 2018-07-24 03:25:34 --> Output Class Initialized
INFO - 2018-07-24 03:25:34 --> Security Class Initialized
DEBUG - 2018-07-24 03:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 03:25:34 --> CSRF cookie sent
INFO - 2018-07-24 03:25:34 --> Input Class Initialized
INFO - 2018-07-24 03:25:34 --> Language Class Initialized
INFO - 2018-07-24 03:25:34 --> Loader Class Initialized
INFO - 2018-07-24 03:25:34 --> Helper loaded: url_helper
INFO - 2018-07-24 03:25:34 --> Helper loaded: form_helper
INFO - 2018-07-24 03:25:34 --> Helper loaded: language_helper
DEBUG - 2018-07-24 03:25:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 03:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 03:25:34 --> User Agent Class Initialized
INFO - 2018-07-24 03:25:34 --> Controller Class Initialized
INFO - 2018-07-24 03:25:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 03:25:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-24 03:25:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-24 03:25:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-24 03:25:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-24 03:25:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-24 03:25:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-07-24 03:25:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-24 03:25:34 --> Final output sent to browser
DEBUG - 2018-07-24 03:25:34 --> Total execution time: 0.0271
INFO - 2018-07-24 03:25:36 --> Config Class Initialized
INFO - 2018-07-24 03:25:36 --> Hooks Class Initialized
DEBUG - 2018-07-24 03:25:36 --> UTF-8 Support Enabled
INFO - 2018-07-24 03:25:36 --> Utf8 Class Initialized
INFO - 2018-07-24 03:25:36 --> URI Class Initialized
INFO - 2018-07-24 03:25:36 --> Router Class Initialized
INFO - 2018-07-24 03:25:36 --> Output Class Initialized
INFO - 2018-07-24 03:25:36 --> Security Class Initialized
DEBUG - 2018-07-24 03:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 03:25:36 --> CSRF cookie sent
INFO - 2018-07-24 03:25:36 --> Input Class Initialized
INFO - 2018-07-24 03:25:36 --> Language Class Initialized
INFO - 2018-07-24 03:25:36 --> Loader Class Initialized
INFO - 2018-07-24 03:25:36 --> Helper loaded: url_helper
INFO - 2018-07-24 03:25:36 --> Helper loaded: form_helper
INFO - 2018-07-24 03:25:36 --> Helper loaded: language_helper
DEBUG - 2018-07-24 03:25:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 03:25:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 03:25:36 --> User Agent Class Initialized
INFO - 2018-07-24 03:25:36 --> Controller Class Initialized
INFO - 2018-07-24 03:25:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 03:25:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-24 03:25:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-24 03:25:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-24 03:25:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-24 03:25:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-24 03:25:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-07-24 03:25:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-24 03:25:36 --> Final output sent to browser
DEBUG - 2018-07-24 03:25:36 --> Total execution time: 0.0236
INFO - 2018-07-24 03:25:39 --> Config Class Initialized
INFO - 2018-07-24 03:25:39 --> Hooks Class Initialized
DEBUG - 2018-07-24 03:25:39 --> UTF-8 Support Enabled
INFO - 2018-07-24 03:25:39 --> Utf8 Class Initialized
INFO - 2018-07-24 03:25:39 --> URI Class Initialized
INFO - 2018-07-24 03:25:39 --> Router Class Initialized
INFO - 2018-07-24 03:25:39 --> Output Class Initialized
INFO - 2018-07-24 03:25:39 --> Security Class Initialized
DEBUG - 2018-07-24 03:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 03:25:39 --> CSRF cookie sent
INFO - 2018-07-24 03:25:39 --> Input Class Initialized
INFO - 2018-07-24 03:25:39 --> Language Class Initialized
INFO - 2018-07-24 03:25:39 --> Loader Class Initialized
INFO - 2018-07-24 03:25:39 --> Helper loaded: url_helper
INFO - 2018-07-24 03:25:39 --> Helper loaded: form_helper
INFO - 2018-07-24 03:25:39 --> Helper loaded: language_helper
DEBUG - 2018-07-24 03:25:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 03:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 03:25:39 --> User Agent Class Initialized
INFO - 2018-07-24 03:25:39 --> Controller Class Initialized
INFO - 2018-07-24 03:25:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 03:25:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-24 03:25:39 --> Pixel_Model class loaded
INFO - 2018-07-24 03:25:39 --> Database Driver Class Initialized
INFO - 2018-07-24 03:25:39 --> Model "QuestionsModel" initialized
INFO - 2018-07-24 03:25:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-24 03:25:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-24 03:25:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-24 03:25:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-24 03:25:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/buy_gift.php
INFO - 2018-07-24 03:25:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-24 03:25:39 --> Final output sent to browser
DEBUG - 2018-07-24 03:25:39 --> Total execution time: 0.0340
INFO - 2018-07-24 03:25:41 --> Config Class Initialized
INFO - 2018-07-24 03:25:41 --> Hooks Class Initialized
DEBUG - 2018-07-24 03:25:41 --> UTF-8 Support Enabled
INFO - 2018-07-24 03:25:41 --> Utf8 Class Initialized
INFO - 2018-07-24 03:25:41 --> URI Class Initialized
INFO - 2018-07-24 03:25:41 --> Router Class Initialized
INFO - 2018-07-24 03:25:41 --> Output Class Initialized
INFO - 2018-07-24 03:25:41 --> Security Class Initialized
DEBUG - 2018-07-24 03:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 03:25:41 --> CSRF cookie sent
INFO - 2018-07-24 03:25:41 --> Input Class Initialized
INFO - 2018-07-24 03:25:41 --> Language Class Initialized
INFO - 2018-07-24 03:25:41 --> Loader Class Initialized
INFO - 2018-07-24 03:25:41 --> Helper loaded: url_helper
INFO - 2018-07-24 03:25:41 --> Helper loaded: form_helper
INFO - 2018-07-24 03:25:41 --> Helper loaded: language_helper
DEBUG - 2018-07-24 03:25:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 03:25:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 03:25:41 --> User Agent Class Initialized
INFO - 2018-07-24 03:25:41 --> Controller Class Initialized
INFO - 2018-07-24 03:25:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 03:25:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-24 03:25:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-24 03:25:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-24 03:25:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-24 03:25:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-24 03:25:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/executive.php
INFO - 2018-07-24 03:25:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-24 03:25:41 --> Final output sent to browser
DEBUG - 2018-07-24 03:25:41 --> Total execution time: 0.0214
INFO - 2018-07-24 03:25:43 --> Config Class Initialized
INFO - 2018-07-24 03:25:43 --> Hooks Class Initialized
DEBUG - 2018-07-24 03:25:43 --> UTF-8 Support Enabled
INFO - 2018-07-24 03:25:43 --> Utf8 Class Initialized
INFO - 2018-07-24 03:25:43 --> URI Class Initialized
INFO - 2018-07-24 03:25:43 --> Router Class Initialized
INFO - 2018-07-24 03:25:43 --> Output Class Initialized
INFO - 2018-07-24 03:25:43 --> Security Class Initialized
DEBUG - 2018-07-24 03:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 03:25:43 --> CSRF cookie sent
INFO - 2018-07-24 03:25:43 --> Input Class Initialized
INFO - 2018-07-24 03:25:43 --> Language Class Initialized
INFO - 2018-07-24 03:25:43 --> Loader Class Initialized
INFO - 2018-07-24 03:25:43 --> Helper loaded: url_helper
INFO - 2018-07-24 03:25:43 --> Helper loaded: form_helper
INFO - 2018-07-24 03:25:43 --> Helper loaded: language_helper
DEBUG - 2018-07-24 03:25:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 03:25:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 03:25:43 --> User Agent Class Initialized
INFO - 2018-07-24 03:25:43 --> Controller Class Initialized
INFO - 2018-07-24 03:25:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 03:25:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-24 03:25:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-24 03:25:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-24 03:25:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-24 03:25:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-24 03:25:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/preview.php
INFO - 2018-07-24 03:25:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-24 03:25:43 --> Final output sent to browser
DEBUG - 2018-07-24 03:25:43 --> Total execution time: 0.0256
INFO - 2018-07-24 03:25:45 --> Config Class Initialized
INFO - 2018-07-24 03:25:45 --> Hooks Class Initialized
DEBUG - 2018-07-24 03:25:45 --> UTF-8 Support Enabled
INFO - 2018-07-24 03:25:45 --> Utf8 Class Initialized
INFO - 2018-07-24 03:25:45 --> URI Class Initialized
INFO - 2018-07-24 03:25:45 --> Router Class Initialized
INFO - 2018-07-24 03:25:45 --> Output Class Initialized
INFO - 2018-07-24 03:25:45 --> Security Class Initialized
DEBUG - 2018-07-24 03:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 03:25:45 --> CSRF cookie sent
INFO - 2018-07-24 03:25:45 --> Input Class Initialized
INFO - 2018-07-24 03:25:45 --> Language Class Initialized
ERROR - 2018-07-24 03:25:45 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-24 03:25:46 --> Config Class Initialized
INFO - 2018-07-24 03:25:46 --> Hooks Class Initialized
DEBUG - 2018-07-24 03:25:46 --> UTF-8 Support Enabled
INFO - 2018-07-24 03:25:46 --> Utf8 Class Initialized
INFO - 2018-07-24 03:25:46 --> URI Class Initialized
INFO - 2018-07-24 03:25:46 --> Router Class Initialized
INFO - 2018-07-24 03:25:46 --> Output Class Initialized
INFO - 2018-07-24 03:25:46 --> Security Class Initialized
DEBUG - 2018-07-24 03:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 03:25:46 --> CSRF cookie sent
INFO - 2018-07-24 03:25:46 --> Input Class Initialized
INFO - 2018-07-24 03:25:46 --> Language Class Initialized
INFO - 2018-07-24 03:25:46 --> Loader Class Initialized
INFO - 2018-07-24 03:25:46 --> Helper loaded: url_helper
INFO - 2018-07-24 03:25:46 --> Helper loaded: form_helper
INFO - 2018-07-24 03:25:46 --> Helper loaded: language_helper
DEBUG - 2018-07-24 03:25:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 03:25:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 03:25:46 --> User Agent Class Initialized
INFO - 2018-07-24 03:25:46 --> Controller Class Initialized
INFO - 2018-07-24 03:25:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 03:25:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-24 03:25:47 --> Config Class Initialized
INFO - 2018-07-24 03:25:47 --> Hooks Class Initialized
DEBUG - 2018-07-24 03:25:47 --> UTF-8 Support Enabled
INFO - 2018-07-24 03:25:47 --> Utf8 Class Initialized
INFO - 2018-07-24 03:25:47 --> URI Class Initialized
INFO - 2018-07-24 03:25:47 --> Router Class Initialized
INFO - 2018-07-24 03:25:47 --> Output Class Initialized
INFO - 2018-07-24 03:25:47 --> Security Class Initialized
DEBUG - 2018-07-24 03:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 03:25:47 --> CSRF cookie sent
INFO - 2018-07-24 03:25:47 --> Input Class Initialized
INFO - 2018-07-24 03:25:47 --> Language Class Initialized
INFO - 2018-07-24 03:25:47 --> Loader Class Initialized
INFO - 2018-07-24 03:25:47 --> Helper loaded: url_helper
INFO - 2018-07-24 03:25:47 --> Helper loaded: form_helper
INFO - 2018-07-24 03:25:47 --> Helper loaded: language_helper
DEBUG - 2018-07-24 03:25:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 03:25:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 03:25:47 --> User Agent Class Initialized
INFO - 2018-07-24 03:25:47 --> Controller Class Initialized
INFO - 2018-07-24 03:25:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 03:25:47 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-24 03:25:47 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-24 03:25:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-24 03:25:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-24 03:25:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-24 03:25:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-24 03:25:47 --> Could not find the language line "req_email"
INFO - 2018-07-24 03:25:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-24 03:25:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-24 03:25:47 --> Final output sent to browser
DEBUG - 2018-07-24 03:25:47 --> Total execution time: 0.0227
INFO - 2018-07-24 03:25:49 --> Config Class Initialized
INFO - 2018-07-24 03:25:49 --> Hooks Class Initialized
DEBUG - 2018-07-24 03:25:49 --> UTF-8 Support Enabled
INFO - 2018-07-24 03:25:49 --> Utf8 Class Initialized
INFO - 2018-07-24 03:25:49 --> URI Class Initialized
INFO - 2018-07-24 03:25:49 --> Router Class Initialized
INFO - 2018-07-24 03:25:49 --> Output Class Initialized
INFO - 2018-07-24 03:25:49 --> Security Class Initialized
DEBUG - 2018-07-24 03:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 03:25:49 --> CSRF cookie sent
INFO - 2018-07-24 03:25:49 --> Input Class Initialized
INFO - 2018-07-24 03:25:49 --> Language Class Initialized
INFO - 2018-07-24 03:25:49 --> Loader Class Initialized
INFO - 2018-07-24 03:25:49 --> Helper loaded: url_helper
INFO - 2018-07-24 03:25:49 --> Helper loaded: form_helper
INFO - 2018-07-24 03:25:49 --> Helper loaded: language_helper
DEBUG - 2018-07-24 03:25:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 03:25:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 03:25:49 --> User Agent Class Initialized
INFO - 2018-07-24 03:25:49 --> Controller Class Initialized
INFO - 2018-07-24 03:25:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 03:25:49 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-24 03:25:49 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-24 03:25:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-24 03:25:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-24 03:25:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-24 03:25:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-24 03:25:49 --> Could not find the language line "req_email"
INFO - 2018-07-24 03:25:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/forgot_password.php
INFO - 2018-07-24 03:25:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-24 03:25:49 --> Final output sent to browser
DEBUG - 2018-07-24 03:25:49 --> Total execution time: 0.0322
INFO - 2018-07-24 03:25:51 --> Config Class Initialized
INFO - 2018-07-24 03:25:51 --> Hooks Class Initialized
DEBUG - 2018-07-24 03:25:51 --> UTF-8 Support Enabled
INFO - 2018-07-24 03:25:51 --> Utf8 Class Initialized
INFO - 2018-07-24 03:25:51 --> URI Class Initialized
INFO - 2018-07-24 03:25:51 --> Router Class Initialized
INFO - 2018-07-24 03:25:51 --> Output Class Initialized
INFO - 2018-07-24 03:25:51 --> Security Class Initialized
DEBUG - 2018-07-24 03:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 03:25:51 --> CSRF cookie sent
INFO - 2018-07-24 03:25:51 --> Input Class Initialized
INFO - 2018-07-24 03:25:51 --> Language Class Initialized
INFO - 2018-07-24 03:25:51 --> Loader Class Initialized
INFO - 2018-07-24 03:25:51 --> Helper loaded: url_helper
INFO - 2018-07-24 03:25:51 --> Helper loaded: form_helper
INFO - 2018-07-24 03:25:51 --> Helper loaded: language_helper
DEBUG - 2018-07-24 03:25:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 03:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 03:25:51 --> User Agent Class Initialized
INFO - 2018-07-24 03:25:51 --> Controller Class Initialized
INFO - 2018-07-24 03:25:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 03:25:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-24 03:25:51 --> Pixel_Model class loaded
INFO - 2018-07-24 03:25:51 --> Database Driver Class Initialized
INFO - 2018-07-24 03:25:51 --> Model "RegistrationModel" initialized
DEBUG - 2018-07-24 03:25:51 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-24 03:25:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-24 03:25:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-24 03:25:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-24 03:25:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-24 03:25:51 --> Could not find the language line "req_email"
INFO - 2018-07-24 03:25:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup.php
INFO - 2018-07-24 03:25:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-24 03:25:51 --> Final output sent to browser
DEBUG - 2018-07-24 03:25:51 --> Total execution time: 0.0607
INFO - 2018-07-24 03:25:51 --> Config Class Initialized
INFO - 2018-07-24 03:25:51 --> Hooks Class Initialized
DEBUG - 2018-07-24 03:25:51 --> UTF-8 Support Enabled
INFO - 2018-07-24 03:25:51 --> Utf8 Class Initialized
INFO - 2018-07-24 03:25:51 --> URI Class Initialized
INFO - 2018-07-24 03:25:51 --> Router Class Initialized
INFO - 2018-07-24 03:25:51 --> Output Class Initialized
INFO - 2018-07-24 03:25:51 --> Security Class Initialized
DEBUG - 2018-07-24 03:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 03:25:51 --> CSRF cookie sent
INFO - 2018-07-24 03:25:51 --> Input Class Initialized
INFO - 2018-07-24 03:25:51 --> Language Class Initialized
ERROR - 2018-07-24 03:25:51 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-24 05:13:57 --> Config Class Initialized
INFO - 2018-07-24 05:13:57 --> Hooks Class Initialized
DEBUG - 2018-07-24 05:13:57 --> UTF-8 Support Enabled
INFO - 2018-07-24 05:13:57 --> Utf8 Class Initialized
INFO - 2018-07-24 05:13:57 --> URI Class Initialized
INFO - 2018-07-24 05:13:57 --> Router Class Initialized
INFO - 2018-07-24 05:13:57 --> Output Class Initialized
INFO - 2018-07-24 05:13:57 --> Security Class Initialized
DEBUG - 2018-07-24 05:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 05:13:57 --> CSRF cookie sent
INFO - 2018-07-24 05:13:57 --> Input Class Initialized
INFO - 2018-07-24 05:13:57 --> Language Class Initialized
ERROR - 2018-07-24 05:13:57 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-24 05:14:00 --> Config Class Initialized
INFO - 2018-07-24 05:14:00 --> Hooks Class Initialized
DEBUG - 2018-07-24 05:14:00 --> UTF-8 Support Enabled
INFO - 2018-07-24 05:14:00 --> Utf8 Class Initialized
INFO - 2018-07-24 05:14:00 --> URI Class Initialized
INFO - 2018-07-24 05:14:00 --> Router Class Initialized
INFO - 2018-07-24 05:14:00 --> Output Class Initialized
INFO - 2018-07-24 05:14:00 --> Security Class Initialized
DEBUG - 2018-07-24 05:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 05:14:00 --> CSRF cookie sent
INFO - 2018-07-24 05:14:00 --> Input Class Initialized
INFO - 2018-07-24 05:14:00 --> Language Class Initialized
INFO - 2018-07-24 05:14:00 --> Loader Class Initialized
INFO - 2018-07-24 05:14:00 --> Helper loaded: url_helper
INFO - 2018-07-24 05:14:00 --> Helper loaded: form_helper
INFO - 2018-07-24 05:14:00 --> Helper loaded: language_helper
DEBUG - 2018-07-24 05:14:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 05:14:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 05:14:00 --> User Agent Class Initialized
INFO - 2018-07-24 05:14:00 --> Controller Class Initialized
INFO - 2018-07-24 05:14:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 05:14:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-24 05:14:00 --> Pixel_Model class loaded
INFO - 2018-07-24 05:14:00 --> Database Driver Class Initialized
INFO - 2018-07-24 05:14:00 --> Model "QuestionsModel" initialized
INFO - 2018-07-24 05:14:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-24 05:14:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-24 05:14:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-24 05:14:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-24 05:14:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/buy_gift.php
INFO - 2018-07-24 05:14:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-24 05:14:00 --> Final output sent to browser
DEBUG - 2018-07-24 05:14:00 --> Total execution time: 0.0352
INFO - 2018-07-24 06:32:34 --> Config Class Initialized
INFO - 2018-07-24 06:32:34 --> Hooks Class Initialized
DEBUG - 2018-07-24 06:32:34 --> UTF-8 Support Enabled
INFO - 2018-07-24 06:32:34 --> Utf8 Class Initialized
INFO - 2018-07-24 06:32:34 --> URI Class Initialized
INFO - 2018-07-24 06:32:34 --> Router Class Initialized
INFO - 2018-07-24 06:32:34 --> Output Class Initialized
INFO - 2018-07-24 06:32:34 --> Security Class Initialized
DEBUG - 2018-07-24 06:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 06:32:34 --> CSRF cookie sent
INFO - 2018-07-24 06:32:34 --> Input Class Initialized
INFO - 2018-07-24 06:32:34 --> Language Class Initialized
ERROR - 2018-07-24 06:32:34 --> 404 Page Not Found: Connectors/system
INFO - 2018-07-24 09:03:41 --> Config Class Initialized
INFO - 2018-07-24 09:03:41 --> Hooks Class Initialized
DEBUG - 2018-07-24 09:03:41 --> UTF-8 Support Enabled
INFO - 2018-07-24 09:03:41 --> Utf8 Class Initialized
INFO - 2018-07-24 09:03:41 --> URI Class Initialized
DEBUG - 2018-07-24 09:03:41 --> No URI present. Default controller set.
INFO - 2018-07-24 09:03:41 --> Router Class Initialized
INFO - 2018-07-24 09:03:41 --> Output Class Initialized
INFO - 2018-07-24 09:03:41 --> Security Class Initialized
DEBUG - 2018-07-24 09:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 09:03:41 --> CSRF cookie sent
INFO - 2018-07-24 09:03:41 --> Input Class Initialized
INFO - 2018-07-24 09:03:41 --> Language Class Initialized
INFO - 2018-07-24 09:03:41 --> Loader Class Initialized
INFO - 2018-07-24 09:03:41 --> Helper loaded: url_helper
INFO - 2018-07-24 09:03:41 --> Helper loaded: form_helper
INFO - 2018-07-24 09:03:41 --> Helper loaded: language_helper
DEBUG - 2018-07-24 09:03:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 09:03:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 09:03:41 --> User Agent Class Initialized
INFO - 2018-07-24 09:03:41 --> Controller Class Initialized
INFO - 2018-07-24 09:03:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 09:03:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-24 09:03:41 --> Pixel_Model class loaded
INFO - 2018-07-24 09:03:41 --> Database Driver Class Initialized
INFO - 2018-07-24 09:03:41 --> Model "QuestionsModel" initialized
INFO - 2018-07-24 09:03:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-24 09:03:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-24 09:03:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-24 09:03:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-24 09:03:41 --> Final output sent to browser
DEBUG - 2018-07-24 09:03:41 --> Total execution time: 0.0464
INFO - 2018-07-24 10:02:46 --> Config Class Initialized
INFO - 2018-07-24 10:02:46 --> Hooks Class Initialized
DEBUG - 2018-07-24 10:02:46 --> UTF-8 Support Enabled
INFO - 2018-07-24 10:02:46 --> Utf8 Class Initialized
INFO - 2018-07-24 10:02:46 --> URI Class Initialized
INFO - 2018-07-24 10:02:46 --> Router Class Initialized
INFO - 2018-07-24 10:02:46 --> Output Class Initialized
INFO - 2018-07-24 10:02:46 --> Security Class Initialized
DEBUG - 2018-07-24 10:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 10:02:46 --> CSRF cookie sent
INFO - 2018-07-24 10:02:46 --> Input Class Initialized
INFO - 2018-07-24 10:02:46 --> Language Class Initialized
ERROR - 2018-07-24 10:02:46 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-24 10:02:46 --> Config Class Initialized
INFO - 2018-07-24 10:02:46 --> Hooks Class Initialized
DEBUG - 2018-07-24 10:02:46 --> UTF-8 Support Enabled
INFO - 2018-07-24 10:02:46 --> Utf8 Class Initialized
INFO - 2018-07-24 10:02:46 --> URI Class Initialized
INFO - 2018-07-24 10:02:46 --> Router Class Initialized
INFO - 2018-07-24 10:02:46 --> Output Class Initialized
INFO - 2018-07-24 10:02:46 --> Security Class Initialized
DEBUG - 2018-07-24 10:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 10:02:46 --> CSRF cookie sent
INFO - 2018-07-24 10:02:46 --> Input Class Initialized
INFO - 2018-07-24 10:02:46 --> Language Class Initialized
ERROR - 2018-07-24 10:02:46 --> 404 Page Not Found: Well-known/assetlinks.json
INFO - 2018-07-24 10:22:46 --> Config Class Initialized
INFO - 2018-07-24 10:22:46 --> Hooks Class Initialized
DEBUG - 2018-07-24 10:22:46 --> UTF-8 Support Enabled
INFO - 2018-07-24 10:22:46 --> Utf8 Class Initialized
INFO - 2018-07-24 10:22:46 --> URI Class Initialized
DEBUG - 2018-07-24 10:22:46 --> No URI present. Default controller set.
INFO - 2018-07-24 10:22:46 --> Router Class Initialized
INFO - 2018-07-24 10:22:46 --> Output Class Initialized
INFO - 2018-07-24 10:22:46 --> Security Class Initialized
DEBUG - 2018-07-24 10:22:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 10:22:46 --> CSRF cookie sent
INFO - 2018-07-24 10:22:46 --> Input Class Initialized
INFO - 2018-07-24 10:22:46 --> Language Class Initialized
INFO - 2018-07-24 10:22:46 --> Loader Class Initialized
INFO - 2018-07-24 10:22:46 --> Helper loaded: url_helper
INFO - 2018-07-24 10:22:46 --> Helper loaded: form_helper
INFO - 2018-07-24 10:22:46 --> Helper loaded: language_helper
DEBUG - 2018-07-24 10:22:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 10:22:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 10:22:46 --> User Agent Class Initialized
INFO - 2018-07-24 10:22:46 --> Controller Class Initialized
INFO - 2018-07-24 10:22:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 10:22:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-24 10:22:46 --> Pixel_Model class loaded
INFO - 2018-07-24 10:22:46 --> Database Driver Class Initialized
INFO - 2018-07-24 10:22:46 --> Model "QuestionsModel" initialized
INFO - 2018-07-24 10:22:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-24 10:22:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-24 10:22:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-24 10:22:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-24 10:22:46 --> Final output sent to browser
DEBUG - 2018-07-24 10:22:46 --> Total execution time: 0.0471
INFO - 2018-07-24 10:28:37 --> Config Class Initialized
INFO - 2018-07-24 10:28:37 --> Hooks Class Initialized
DEBUG - 2018-07-24 10:28:37 --> UTF-8 Support Enabled
INFO - 2018-07-24 10:28:37 --> Utf8 Class Initialized
INFO - 2018-07-24 10:28:37 --> URI Class Initialized
DEBUG - 2018-07-24 10:28:37 --> No URI present. Default controller set.
INFO - 2018-07-24 10:28:37 --> Router Class Initialized
INFO - 2018-07-24 10:28:37 --> Output Class Initialized
INFO - 2018-07-24 10:28:37 --> Security Class Initialized
DEBUG - 2018-07-24 10:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 10:28:37 --> CSRF cookie sent
INFO - 2018-07-24 10:28:37 --> Input Class Initialized
INFO - 2018-07-24 10:28:37 --> Language Class Initialized
INFO - 2018-07-24 10:28:37 --> Loader Class Initialized
INFO - 2018-07-24 10:28:37 --> Helper loaded: url_helper
INFO - 2018-07-24 10:28:37 --> Helper loaded: form_helper
INFO - 2018-07-24 10:28:37 --> Helper loaded: language_helper
DEBUG - 2018-07-24 10:28:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 10:28:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 10:28:37 --> User Agent Class Initialized
INFO - 2018-07-24 10:28:37 --> Controller Class Initialized
INFO - 2018-07-24 10:28:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 10:28:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-24 10:28:37 --> Pixel_Model class loaded
INFO - 2018-07-24 10:28:37 --> Database Driver Class Initialized
INFO - 2018-07-24 10:28:37 --> Model "QuestionsModel" initialized
INFO - 2018-07-24 10:28:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-24 10:28:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-24 10:28:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-24 10:28:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-24 10:28:37 --> Final output sent to browser
DEBUG - 2018-07-24 10:28:37 --> Total execution time: 0.0328
INFO - 2018-07-24 11:42:11 --> Config Class Initialized
INFO - 2018-07-24 11:42:11 --> Hooks Class Initialized
DEBUG - 2018-07-24 11:42:11 --> UTF-8 Support Enabled
INFO - 2018-07-24 11:42:11 --> Utf8 Class Initialized
INFO - 2018-07-24 11:42:11 --> URI Class Initialized
INFO - 2018-07-24 11:42:11 --> Router Class Initialized
INFO - 2018-07-24 11:42:11 --> Output Class Initialized
INFO - 2018-07-24 11:42:11 --> Security Class Initialized
DEBUG - 2018-07-24 11:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 11:42:11 --> CSRF cookie sent
INFO - 2018-07-24 11:42:11 --> Input Class Initialized
INFO - 2018-07-24 11:42:11 --> Language Class Initialized
ERROR - 2018-07-24 11:42:11 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-24 11:42:14 --> Config Class Initialized
INFO - 2018-07-24 11:42:14 --> Hooks Class Initialized
DEBUG - 2018-07-24 11:42:14 --> UTF-8 Support Enabled
INFO - 2018-07-24 11:42:14 --> Utf8 Class Initialized
INFO - 2018-07-24 11:42:14 --> URI Class Initialized
INFO - 2018-07-24 11:42:14 --> Router Class Initialized
INFO - 2018-07-24 11:42:14 --> Output Class Initialized
INFO - 2018-07-24 11:42:14 --> Security Class Initialized
DEBUG - 2018-07-24 11:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 11:42:14 --> CSRF cookie sent
INFO - 2018-07-24 11:42:14 --> Input Class Initialized
INFO - 2018-07-24 11:42:14 --> Language Class Initialized
INFO - 2018-07-24 11:42:14 --> Loader Class Initialized
INFO - 2018-07-24 11:42:14 --> Helper loaded: url_helper
INFO - 2018-07-24 11:42:14 --> Helper loaded: form_helper
INFO - 2018-07-24 11:42:14 --> Helper loaded: language_helper
DEBUG - 2018-07-24 11:42:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 11:42:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 11:42:14 --> User Agent Class Initialized
INFO - 2018-07-24 11:42:14 --> Controller Class Initialized
INFO - 2018-07-24 11:42:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 11:42:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-24 11:42:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-24 11:42:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-24 11:42:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-24 11:42:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-24 11:42:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-07-24 11:42:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-24 11:42:14 --> Final output sent to browser
DEBUG - 2018-07-24 11:42:14 --> Total execution time: 0.0237
INFO - 2018-07-24 12:56:27 --> Config Class Initialized
INFO - 2018-07-24 12:56:27 --> Hooks Class Initialized
DEBUG - 2018-07-24 12:56:27 --> UTF-8 Support Enabled
INFO - 2018-07-24 12:56:27 --> Utf8 Class Initialized
INFO - 2018-07-24 12:56:27 --> URI Class Initialized
INFO - 2018-07-24 12:56:27 --> Router Class Initialized
INFO - 2018-07-24 12:56:27 --> Output Class Initialized
INFO - 2018-07-24 12:56:27 --> Security Class Initialized
DEBUG - 2018-07-24 12:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 12:56:27 --> CSRF cookie sent
INFO - 2018-07-24 12:56:27 --> Input Class Initialized
INFO - 2018-07-24 12:56:27 --> Language Class Initialized
ERROR - 2018-07-24 12:56:27 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-24 12:56:27 --> Config Class Initialized
INFO - 2018-07-24 12:56:27 --> Hooks Class Initialized
DEBUG - 2018-07-24 12:56:27 --> UTF-8 Support Enabled
INFO - 2018-07-24 12:56:27 --> Utf8 Class Initialized
INFO - 2018-07-24 12:56:27 --> URI Class Initialized
DEBUG - 2018-07-24 12:56:27 --> No URI present. Default controller set.
INFO - 2018-07-24 12:56:27 --> Router Class Initialized
INFO - 2018-07-24 12:56:27 --> Output Class Initialized
INFO - 2018-07-24 12:56:27 --> Security Class Initialized
DEBUG - 2018-07-24 12:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 12:56:27 --> CSRF cookie sent
INFO - 2018-07-24 12:56:27 --> Input Class Initialized
INFO - 2018-07-24 12:56:27 --> Language Class Initialized
INFO - 2018-07-24 12:56:27 --> Loader Class Initialized
INFO - 2018-07-24 12:56:27 --> Helper loaded: url_helper
INFO - 2018-07-24 12:56:27 --> Helper loaded: form_helper
INFO - 2018-07-24 12:56:27 --> Helper loaded: language_helper
DEBUG - 2018-07-24 12:56:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 12:56:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 12:56:27 --> User Agent Class Initialized
INFO - 2018-07-24 12:56:27 --> Controller Class Initialized
INFO - 2018-07-24 12:56:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 12:56:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-24 12:56:27 --> Pixel_Model class loaded
INFO - 2018-07-24 12:56:27 --> Database Driver Class Initialized
INFO - 2018-07-24 12:56:27 --> Model "QuestionsModel" initialized
INFO - 2018-07-24 12:56:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-24 12:56:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-24 12:56:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-24 12:56:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-24 12:56:27 --> Final output sent to browser
DEBUG - 2018-07-24 12:56:27 --> Total execution time: 0.0453
INFO - 2018-07-24 12:58:58 --> Config Class Initialized
INFO - 2018-07-24 12:58:58 --> Hooks Class Initialized
DEBUG - 2018-07-24 12:58:58 --> UTF-8 Support Enabled
INFO - 2018-07-24 12:58:58 --> Utf8 Class Initialized
INFO - 2018-07-24 12:58:58 --> URI Class Initialized
DEBUG - 2018-07-24 12:58:58 --> No URI present. Default controller set.
INFO - 2018-07-24 12:58:58 --> Router Class Initialized
INFO - 2018-07-24 12:58:58 --> Output Class Initialized
INFO - 2018-07-24 12:58:58 --> Security Class Initialized
DEBUG - 2018-07-24 12:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 12:58:58 --> CSRF cookie sent
INFO - 2018-07-24 12:58:58 --> Input Class Initialized
INFO - 2018-07-24 12:58:58 --> Language Class Initialized
INFO - 2018-07-24 12:58:58 --> Loader Class Initialized
INFO - 2018-07-24 12:58:58 --> Helper loaded: url_helper
INFO - 2018-07-24 12:58:58 --> Helper loaded: form_helper
INFO - 2018-07-24 12:58:58 --> Helper loaded: language_helper
DEBUG - 2018-07-24 12:58:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 12:58:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 12:58:58 --> User Agent Class Initialized
INFO - 2018-07-24 12:58:58 --> Controller Class Initialized
INFO - 2018-07-24 12:58:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 12:58:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-24 12:58:58 --> Pixel_Model class loaded
INFO - 2018-07-24 12:58:58 --> Database Driver Class Initialized
INFO - 2018-07-24 12:58:58 --> Model "QuestionsModel" initialized
INFO - 2018-07-24 12:58:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-24 12:58:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-24 12:58:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-24 12:58:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-24 12:58:58 --> Final output sent to browser
DEBUG - 2018-07-24 12:58:58 --> Total execution time: 0.0432
INFO - 2018-07-24 12:59:06 --> Config Class Initialized
INFO - 2018-07-24 12:59:06 --> Hooks Class Initialized
DEBUG - 2018-07-24 12:59:06 --> UTF-8 Support Enabled
INFO - 2018-07-24 12:59:06 --> Utf8 Class Initialized
INFO - 2018-07-24 12:59:06 --> URI Class Initialized
DEBUG - 2018-07-24 12:59:06 --> No URI present. Default controller set.
INFO - 2018-07-24 12:59:06 --> Router Class Initialized
INFO - 2018-07-24 12:59:06 --> Output Class Initialized
INFO - 2018-07-24 12:59:06 --> Security Class Initialized
DEBUG - 2018-07-24 12:59:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 12:59:06 --> CSRF cookie sent
INFO - 2018-07-24 12:59:06 --> Input Class Initialized
INFO - 2018-07-24 12:59:06 --> Language Class Initialized
INFO - 2018-07-24 12:59:06 --> Loader Class Initialized
INFO - 2018-07-24 12:59:06 --> Helper loaded: url_helper
INFO - 2018-07-24 12:59:06 --> Helper loaded: form_helper
INFO - 2018-07-24 12:59:06 --> Helper loaded: language_helper
DEBUG - 2018-07-24 12:59:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 12:59:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 12:59:06 --> User Agent Class Initialized
INFO - 2018-07-24 12:59:06 --> Controller Class Initialized
INFO - 2018-07-24 12:59:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 12:59:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-24 12:59:06 --> Pixel_Model class loaded
INFO - 2018-07-24 12:59:06 --> Database Driver Class Initialized
INFO - 2018-07-24 12:59:06 --> Model "QuestionsModel" initialized
INFO - 2018-07-24 12:59:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-24 12:59:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-24 12:59:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-24 12:59:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-24 12:59:06 --> Final output sent to browser
DEBUG - 2018-07-24 12:59:06 --> Total execution time: 0.0437
INFO - 2018-07-24 12:59:15 --> Config Class Initialized
INFO - 2018-07-24 12:59:15 --> Hooks Class Initialized
DEBUG - 2018-07-24 12:59:15 --> UTF-8 Support Enabled
INFO - 2018-07-24 12:59:15 --> Utf8 Class Initialized
INFO - 2018-07-24 12:59:15 --> URI Class Initialized
INFO - 2018-07-24 12:59:15 --> Router Class Initialized
INFO - 2018-07-24 12:59:15 --> Output Class Initialized
INFO - 2018-07-24 12:59:15 --> Security Class Initialized
DEBUG - 2018-07-24 12:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 12:59:15 --> CSRF cookie sent
INFO - 2018-07-24 12:59:15 --> CSRF token verified
INFO - 2018-07-24 12:59:15 --> Input Class Initialized
INFO - 2018-07-24 12:59:15 --> Language Class Initialized
INFO - 2018-07-24 12:59:15 --> Loader Class Initialized
INFO - 2018-07-24 12:59:15 --> Helper loaded: url_helper
INFO - 2018-07-24 12:59:15 --> Helper loaded: form_helper
INFO - 2018-07-24 12:59:15 --> Helper loaded: language_helper
DEBUG - 2018-07-24 12:59:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 12:59:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 12:59:15 --> User Agent Class Initialized
INFO - 2018-07-24 12:59:15 --> Controller Class Initialized
INFO - 2018-07-24 12:59:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 12:59:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-24 12:59:15 --> Pixel_Model class loaded
INFO - 2018-07-24 12:59:15 --> Database Driver Class Initialized
INFO - 2018-07-24 12:59:15 --> Model "QuestionsModel" initialized
INFO - 2018-07-24 12:59:15 --> Config Class Initialized
INFO - 2018-07-24 12:59:15 --> Hooks Class Initialized
DEBUG - 2018-07-24 12:59:15 --> UTF-8 Support Enabled
INFO - 2018-07-24 12:59:15 --> Utf8 Class Initialized
INFO - 2018-07-24 12:59:15 --> URI Class Initialized
INFO - 2018-07-24 12:59:15 --> Router Class Initialized
INFO - 2018-07-24 12:59:15 --> Output Class Initialized
INFO - 2018-07-24 12:59:15 --> Security Class Initialized
DEBUG - 2018-07-24 12:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 12:59:15 --> CSRF cookie sent
INFO - 2018-07-24 12:59:15 --> Input Class Initialized
INFO - 2018-07-24 12:59:15 --> Language Class Initialized
INFO - 2018-07-24 12:59:15 --> Loader Class Initialized
INFO - 2018-07-24 12:59:15 --> Helper loaded: url_helper
INFO - 2018-07-24 12:59:15 --> Helper loaded: form_helper
INFO - 2018-07-24 12:59:15 --> Helper loaded: language_helper
DEBUG - 2018-07-24 12:59:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 12:59:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 12:59:15 --> User Agent Class Initialized
INFO - 2018-07-24 12:59:15 --> Controller Class Initialized
INFO - 2018-07-24 12:59:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 12:59:15 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-24 12:59:15 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-24 12:59:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-24 12:59:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-24 12:59:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-24 12:59:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-24 12:59:15 --> Could not find the language line "req_email"
INFO - 2018-07-24 12:59:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-24 12:59:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-24 12:59:15 --> Final output sent to browser
DEBUG - 2018-07-24 12:59:15 --> Total execution time: 0.0230
INFO - 2018-07-24 12:59:19 --> Config Class Initialized
INFO - 2018-07-24 12:59:19 --> Hooks Class Initialized
DEBUG - 2018-07-24 12:59:19 --> UTF-8 Support Enabled
INFO - 2018-07-24 12:59:19 --> Utf8 Class Initialized
INFO - 2018-07-24 12:59:19 --> URI Class Initialized
INFO - 2018-07-24 12:59:19 --> Router Class Initialized
INFO - 2018-07-24 12:59:19 --> Output Class Initialized
INFO - 2018-07-24 12:59:19 --> Security Class Initialized
DEBUG - 2018-07-24 12:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 12:59:19 --> CSRF cookie sent
INFO - 2018-07-24 12:59:19 --> Input Class Initialized
INFO - 2018-07-24 12:59:19 --> Language Class Initialized
INFO - 2018-07-24 12:59:19 --> Loader Class Initialized
INFO - 2018-07-24 12:59:19 --> Helper loaded: url_helper
INFO - 2018-07-24 12:59:19 --> Helper loaded: form_helper
INFO - 2018-07-24 12:59:19 --> Helper loaded: language_helper
DEBUG - 2018-07-24 12:59:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 12:59:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 12:59:19 --> User Agent Class Initialized
INFO - 2018-07-24 12:59:19 --> Controller Class Initialized
INFO - 2018-07-24 12:59:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 12:59:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-24 12:59:19 --> Pixel_Model class loaded
INFO - 2018-07-24 12:59:19 --> Database Driver Class Initialized
INFO - 2018-07-24 12:59:19 --> Model "QuestionsModel" initialized
INFO - 2018-07-24 12:59:19 --> Config Class Initialized
INFO - 2018-07-24 12:59:19 --> Hooks Class Initialized
DEBUG - 2018-07-24 12:59:19 --> UTF-8 Support Enabled
INFO - 2018-07-24 12:59:19 --> Utf8 Class Initialized
INFO - 2018-07-24 12:59:19 --> URI Class Initialized
INFO - 2018-07-24 12:59:19 --> Router Class Initialized
INFO - 2018-07-24 12:59:19 --> Output Class Initialized
INFO - 2018-07-24 12:59:19 --> Security Class Initialized
DEBUG - 2018-07-24 12:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 12:59:19 --> CSRF cookie sent
INFO - 2018-07-24 12:59:19 --> Input Class Initialized
INFO - 2018-07-24 12:59:19 --> Language Class Initialized
INFO - 2018-07-24 12:59:19 --> Loader Class Initialized
INFO - 2018-07-24 12:59:19 --> Helper loaded: url_helper
INFO - 2018-07-24 12:59:19 --> Helper loaded: form_helper
INFO - 2018-07-24 12:59:19 --> Helper loaded: language_helper
DEBUG - 2018-07-24 12:59:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 12:59:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 12:59:19 --> User Agent Class Initialized
INFO - 2018-07-24 12:59:19 --> Controller Class Initialized
INFO - 2018-07-24 12:59:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 12:59:19 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-24 12:59:19 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-24 12:59:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-24 12:59:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-24 12:59:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-24 12:59:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-24 12:59:19 --> Could not find the language line "req_email"
INFO - 2018-07-24 12:59:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-24 12:59:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-24 12:59:19 --> Final output sent to browser
DEBUG - 2018-07-24 12:59:19 --> Total execution time: 0.0304
INFO - 2018-07-24 12:59:21 --> Config Class Initialized
INFO - 2018-07-24 12:59:21 --> Hooks Class Initialized
DEBUG - 2018-07-24 12:59:21 --> UTF-8 Support Enabled
INFO - 2018-07-24 12:59:21 --> Utf8 Class Initialized
INFO - 2018-07-24 12:59:21 --> URI Class Initialized
INFO - 2018-07-24 12:59:21 --> Router Class Initialized
INFO - 2018-07-24 12:59:21 --> Output Class Initialized
INFO - 2018-07-24 12:59:21 --> Security Class Initialized
DEBUG - 2018-07-24 12:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 12:59:21 --> CSRF cookie sent
INFO - 2018-07-24 12:59:21 --> Input Class Initialized
INFO - 2018-07-24 12:59:21 --> Language Class Initialized
INFO - 2018-07-24 12:59:21 --> Loader Class Initialized
INFO - 2018-07-24 12:59:21 --> Helper loaded: url_helper
INFO - 2018-07-24 12:59:21 --> Helper loaded: form_helper
INFO - 2018-07-24 12:59:21 --> Helper loaded: language_helper
DEBUG - 2018-07-24 12:59:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 12:59:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 12:59:21 --> User Agent Class Initialized
INFO - 2018-07-24 12:59:21 --> Controller Class Initialized
INFO - 2018-07-24 12:59:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 12:59:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-24 12:59:21 --> Pixel_Model class loaded
INFO - 2018-07-24 12:59:21 --> Database Driver Class Initialized
INFO - 2018-07-24 12:59:21 --> Model "QuestionsModel" initialized
INFO - 2018-07-24 12:59:21 --> Config Class Initialized
INFO - 2018-07-24 12:59:21 --> Hooks Class Initialized
DEBUG - 2018-07-24 12:59:21 --> UTF-8 Support Enabled
INFO - 2018-07-24 12:59:21 --> Utf8 Class Initialized
INFO - 2018-07-24 12:59:21 --> URI Class Initialized
INFO - 2018-07-24 12:59:21 --> Router Class Initialized
INFO - 2018-07-24 12:59:21 --> Output Class Initialized
INFO - 2018-07-24 12:59:21 --> Security Class Initialized
DEBUG - 2018-07-24 12:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 12:59:21 --> CSRF cookie sent
INFO - 2018-07-24 12:59:21 --> Input Class Initialized
INFO - 2018-07-24 12:59:21 --> Language Class Initialized
INFO - 2018-07-24 12:59:21 --> Loader Class Initialized
INFO - 2018-07-24 12:59:21 --> Helper loaded: url_helper
INFO - 2018-07-24 12:59:21 --> Helper loaded: form_helper
INFO - 2018-07-24 12:59:21 --> Helper loaded: language_helper
DEBUG - 2018-07-24 12:59:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 12:59:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 12:59:21 --> User Agent Class Initialized
INFO - 2018-07-24 12:59:21 --> Controller Class Initialized
INFO - 2018-07-24 12:59:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 12:59:21 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-24 12:59:21 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-24 12:59:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-24 12:59:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-24 12:59:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-24 12:59:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-24 12:59:21 --> Could not find the language line "req_email"
INFO - 2018-07-24 12:59:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-24 12:59:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-24 12:59:21 --> Final output sent to browser
DEBUG - 2018-07-24 12:59:21 --> Total execution time: 0.0304
INFO - 2018-07-24 12:59:22 --> Config Class Initialized
INFO - 2018-07-24 12:59:22 --> Hooks Class Initialized
DEBUG - 2018-07-24 12:59:22 --> UTF-8 Support Enabled
INFO - 2018-07-24 12:59:22 --> Utf8 Class Initialized
INFO - 2018-07-24 12:59:22 --> URI Class Initialized
INFO - 2018-07-24 12:59:22 --> Router Class Initialized
INFO - 2018-07-24 12:59:22 --> Output Class Initialized
INFO - 2018-07-24 12:59:22 --> Security Class Initialized
DEBUG - 2018-07-24 12:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 12:59:22 --> CSRF cookie sent
INFO - 2018-07-24 12:59:22 --> Input Class Initialized
INFO - 2018-07-24 12:59:22 --> Language Class Initialized
INFO - 2018-07-24 12:59:22 --> Loader Class Initialized
INFO - 2018-07-24 12:59:22 --> Helper loaded: url_helper
INFO - 2018-07-24 12:59:22 --> Helper loaded: form_helper
INFO - 2018-07-24 12:59:22 --> Helper loaded: language_helper
DEBUG - 2018-07-24 12:59:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 12:59:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 12:59:22 --> User Agent Class Initialized
INFO - 2018-07-24 12:59:22 --> Controller Class Initialized
INFO - 2018-07-24 12:59:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 12:59:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-24 12:59:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-24 12:59:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-24 12:59:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-24 12:59:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-24 12:59:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-07-24 12:59:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-24 12:59:22 --> Final output sent to browser
DEBUG - 2018-07-24 12:59:22 --> Total execution time: 0.0227
INFO - 2018-07-24 12:59:26 --> Config Class Initialized
INFO - 2018-07-24 12:59:26 --> Hooks Class Initialized
DEBUG - 2018-07-24 12:59:26 --> UTF-8 Support Enabled
INFO - 2018-07-24 12:59:26 --> Utf8 Class Initialized
INFO - 2018-07-24 12:59:26 --> URI Class Initialized
INFO - 2018-07-24 12:59:26 --> Router Class Initialized
INFO - 2018-07-24 12:59:26 --> Output Class Initialized
INFO - 2018-07-24 12:59:26 --> Security Class Initialized
DEBUG - 2018-07-24 12:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 12:59:26 --> CSRF cookie sent
INFO - 2018-07-24 12:59:26 --> Input Class Initialized
INFO - 2018-07-24 12:59:26 --> Language Class Initialized
INFO - 2018-07-24 12:59:26 --> Loader Class Initialized
INFO - 2018-07-24 12:59:26 --> Helper loaded: url_helper
INFO - 2018-07-24 12:59:27 --> Helper loaded: form_helper
INFO - 2018-07-24 12:59:27 --> Helper loaded: language_helper
DEBUG - 2018-07-24 12:59:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 12:59:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 12:59:27 --> User Agent Class Initialized
INFO - 2018-07-24 12:59:27 --> Controller Class Initialized
INFO - 2018-07-24 12:59:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 12:59:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-24 12:59:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-24 12:59:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-24 12:59:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-24 12:59:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-24 12:59:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-07-24 12:59:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-24 12:59:27 --> Final output sent to browser
DEBUG - 2018-07-24 12:59:27 --> Total execution time: 0.0211
INFO - 2018-07-24 12:59:33 --> Config Class Initialized
INFO - 2018-07-24 12:59:33 --> Hooks Class Initialized
DEBUG - 2018-07-24 12:59:33 --> UTF-8 Support Enabled
INFO - 2018-07-24 12:59:33 --> Utf8 Class Initialized
INFO - 2018-07-24 12:59:33 --> URI Class Initialized
INFO - 2018-07-24 12:59:33 --> Router Class Initialized
INFO - 2018-07-24 12:59:33 --> Output Class Initialized
INFO - 2018-07-24 12:59:33 --> Security Class Initialized
DEBUG - 2018-07-24 12:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 12:59:33 --> CSRF cookie sent
INFO - 2018-07-24 12:59:33 --> Input Class Initialized
INFO - 2018-07-24 12:59:33 --> Language Class Initialized
INFO - 2018-07-24 12:59:33 --> Loader Class Initialized
INFO - 2018-07-24 12:59:33 --> Helper loaded: url_helper
INFO - 2018-07-24 12:59:33 --> Helper loaded: form_helper
INFO - 2018-07-24 12:59:33 --> Helper loaded: language_helper
DEBUG - 2018-07-24 12:59:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 12:59:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 12:59:33 --> User Agent Class Initialized
INFO - 2018-07-24 12:59:33 --> Controller Class Initialized
INFO - 2018-07-24 12:59:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 12:59:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-24 12:59:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-24 12:59:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-24 12:59:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-24 12:59:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-24 12:59:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-07-24 12:59:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-24 12:59:33 --> Final output sent to browser
DEBUG - 2018-07-24 12:59:33 --> Total execution time: 0.0215
INFO - 2018-07-24 13:09:25 --> Config Class Initialized
INFO - 2018-07-24 13:09:25 --> Hooks Class Initialized
DEBUG - 2018-07-24 13:09:25 --> UTF-8 Support Enabled
INFO - 2018-07-24 13:09:25 --> Utf8 Class Initialized
INFO - 2018-07-24 13:09:25 --> URI Class Initialized
DEBUG - 2018-07-24 13:09:25 --> No URI present. Default controller set.
INFO - 2018-07-24 13:09:25 --> Router Class Initialized
INFO - 2018-07-24 13:09:25 --> Output Class Initialized
INFO - 2018-07-24 13:09:25 --> Security Class Initialized
DEBUG - 2018-07-24 13:09:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 13:09:25 --> CSRF cookie sent
INFO - 2018-07-24 13:09:25 --> Input Class Initialized
INFO - 2018-07-24 13:09:25 --> Language Class Initialized
INFO - 2018-07-24 13:09:25 --> Loader Class Initialized
INFO - 2018-07-24 13:09:25 --> Helper loaded: url_helper
INFO - 2018-07-24 13:09:25 --> Helper loaded: form_helper
INFO - 2018-07-24 13:09:25 --> Helper loaded: language_helper
DEBUG - 2018-07-24 13:09:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 13:09:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 13:09:25 --> User Agent Class Initialized
INFO - 2018-07-24 13:09:25 --> Controller Class Initialized
INFO - 2018-07-24 13:09:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 13:09:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-24 13:09:25 --> Pixel_Model class loaded
INFO - 2018-07-24 13:09:25 --> Database Driver Class Initialized
INFO - 2018-07-24 13:09:25 --> Model "QuestionsModel" initialized
INFO - 2018-07-24 13:09:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-24 13:09:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-24 13:09:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-24 13:09:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-24 13:09:25 --> Final output sent to browser
DEBUG - 2018-07-24 13:09:25 --> Total execution time: 0.0359
INFO - 2018-07-24 13:09:47 --> Config Class Initialized
INFO - 2018-07-24 13:09:47 --> Hooks Class Initialized
DEBUG - 2018-07-24 13:09:47 --> UTF-8 Support Enabled
INFO - 2018-07-24 13:09:47 --> Utf8 Class Initialized
INFO - 2018-07-24 13:09:47 --> URI Class Initialized
INFO - 2018-07-24 13:09:47 --> Router Class Initialized
INFO - 2018-07-24 13:09:47 --> Output Class Initialized
INFO - 2018-07-24 13:09:47 --> Security Class Initialized
DEBUG - 2018-07-24 13:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 13:09:47 --> CSRF cookie sent
INFO - 2018-07-24 13:09:47 --> Input Class Initialized
INFO - 2018-07-24 13:09:47 --> Language Class Initialized
INFO - 2018-07-24 13:09:47 --> Loader Class Initialized
INFO - 2018-07-24 13:09:47 --> Helper loaded: url_helper
INFO - 2018-07-24 13:09:47 --> Helper loaded: form_helper
INFO - 2018-07-24 13:09:47 --> Helper loaded: language_helper
DEBUG - 2018-07-24 13:09:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 13:09:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 13:09:47 --> User Agent Class Initialized
INFO - 2018-07-24 13:09:47 --> Controller Class Initialized
INFO - 2018-07-24 13:09:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 13:09:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-24 13:09:47 --> Pixel_Model class loaded
INFO - 2018-07-24 13:09:47 --> Database Driver Class Initialized
INFO - 2018-07-24 13:09:47 --> Model "QuestionsModel" initialized
INFO - 2018-07-24 13:09:47 --> Config Class Initialized
INFO - 2018-07-24 13:09:47 --> Hooks Class Initialized
DEBUG - 2018-07-24 13:09:47 --> UTF-8 Support Enabled
INFO - 2018-07-24 13:09:47 --> Utf8 Class Initialized
INFO - 2018-07-24 13:09:47 --> URI Class Initialized
INFO - 2018-07-24 13:09:47 --> Router Class Initialized
INFO - 2018-07-24 13:09:47 --> Output Class Initialized
INFO - 2018-07-24 13:09:47 --> Security Class Initialized
DEBUG - 2018-07-24 13:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 13:09:47 --> CSRF cookie sent
INFO - 2018-07-24 13:09:47 --> Input Class Initialized
INFO - 2018-07-24 13:09:47 --> Language Class Initialized
INFO - 2018-07-24 13:09:47 --> Loader Class Initialized
INFO - 2018-07-24 13:09:47 --> Helper loaded: url_helper
INFO - 2018-07-24 13:09:47 --> Helper loaded: form_helper
INFO - 2018-07-24 13:09:47 --> Helper loaded: language_helper
DEBUG - 2018-07-24 13:09:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 13:09:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 13:09:47 --> User Agent Class Initialized
INFO - 2018-07-24 13:09:47 --> Controller Class Initialized
INFO - 2018-07-24 13:09:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 13:09:47 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-24 13:09:47 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-24 13:09:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-24 13:09:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-24 13:09:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-24 13:09:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-24 13:09:47 --> Could not find the language line "req_email"
INFO - 2018-07-24 13:09:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-24 13:09:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-24 13:09:47 --> Final output sent to browser
DEBUG - 2018-07-24 13:09:47 --> Total execution time: 0.0266
INFO - 2018-07-24 13:09:51 --> Config Class Initialized
INFO - 2018-07-24 13:09:51 --> Hooks Class Initialized
DEBUG - 2018-07-24 13:09:51 --> UTF-8 Support Enabled
INFO - 2018-07-24 13:09:51 --> Utf8 Class Initialized
INFO - 2018-07-24 13:09:51 --> URI Class Initialized
INFO - 2018-07-24 13:09:51 --> Router Class Initialized
INFO - 2018-07-24 13:09:51 --> Output Class Initialized
INFO - 2018-07-24 13:09:51 --> Security Class Initialized
DEBUG - 2018-07-24 13:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 13:09:51 --> CSRF cookie sent
INFO - 2018-07-24 13:09:51 --> Input Class Initialized
INFO - 2018-07-24 13:09:51 --> Language Class Initialized
INFO - 2018-07-24 13:09:51 --> Loader Class Initialized
INFO - 2018-07-24 13:09:51 --> Helper loaded: url_helper
INFO - 2018-07-24 13:09:51 --> Helper loaded: form_helper
INFO - 2018-07-24 13:09:51 --> Helper loaded: language_helper
DEBUG - 2018-07-24 13:09:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 13:09:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 13:09:51 --> User Agent Class Initialized
INFO - 2018-07-24 13:09:51 --> Controller Class Initialized
INFO - 2018-07-24 13:09:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 13:09:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-24 13:09:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-24 13:09:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-24 13:09:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-24 13:09:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-24 13:09:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-07-24 13:09:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-24 13:09:51 --> Final output sent to browser
DEBUG - 2018-07-24 13:09:51 --> Total execution time: 0.0230
INFO - 2018-07-24 13:09:55 --> Config Class Initialized
INFO - 2018-07-24 13:09:55 --> Hooks Class Initialized
DEBUG - 2018-07-24 13:09:55 --> UTF-8 Support Enabled
INFO - 2018-07-24 13:09:55 --> Utf8 Class Initialized
INFO - 2018-07-24 13:09:55 --> URI Class Initialized
INFO - 2018-07-24 13:09:55 --> Router Class Initialized
INFO - 2018-07-24 13:09:55 --> Output Class Initialized
INFO - 2018-07-24 13:09:55 --> Security Class Initialized
DEBUG - 2018-07-24 13:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 13:09:55 --> CSRF cookie sent
INFO - 2018-07-24 13:09:55 --> Input Class Initialized
INFO - 2018-07-24 13:09:55 --> Language Class Initialized
INFO - 2018-07-24 13:09:55 --> Loader Class Initialized
INFO - 2018-07-24 13:09:55 --> Helper loaded: url_helper
INFO - 2018-07-24 13:09:55 --> Helper loaded: form_helper
INFO - 2018-07-24 13:09:55 --> Helper loaded: language_helper
DEBUG - 2018-07-24 13:09:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 13:09:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 13:09:55 --> User Agent Class Initialized
INFO - 2018-07-24 13:09:55 --> Controller Class Initialized
INFO - 2018-07-24 13:09:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 13:09:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-24 13:09:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-24 13:09:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-24 13:09:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-24 13:09:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-24 13:09:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-07-24 13:09:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-24 13:09:55 --> Final output sent to browser
DEBUG - 2018-07-24 13:09:55 --> Total execution time: 0.0233
INFO - 2018-07-24 13:21:15 --> Config Class Initialized
INFO - 2018-07-24 13:21:15 --> Hooks Class Initialized
DEBUG - 2018-07-24 13:21:15 --> UTF-8 Support Enabled
INFO - 2018-07-24 13:21:15 --> Utf8 Class Initialized
INFO - 2018-07-24 13:21:15 --> URI Class Initialized
DEBUG - 2018-07-24 13:21:15 --> No URI present. Default controller set.
INFO - 2018-07-24 13:21:15 --> Router Class Initialized
INFO - 2018-07-24 13:21:15 --> Output Class Initialized
INFO - 2018-07-24 13:21:15 --> Security Class Initialized
DEBUG - 2018-07-24 13:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 13:21:15 --> CSRF cookie sent
INFO - 2018-07-24 13:21:15 --> Input Class Initialized
INFO - 2018-07-24 13:21:15 --> Language Class Initialized
INFO - 2018-07-24 13:21:15 --> Loader Class Initialized
INFO - 2018-07-24 13:21:15 --> Helper loaded: url_helper
INFO - 2018-07-24 13:21:15 --> Helper loaded: form_helper
INFO - 2018-07-24 13:21:15 --> Helper loaded: language_helper
DEBUG - 2018-07-24 13:21:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 13:21:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 13:21:15 --> User Agent Class Initialized
INFO - 2018-07-24 13:21:15 --> Controller Class Initialized
INFO - 2018-07-24 13:21:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 13:21:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-24 13:21:15 --> Pixel_Model class loaded
INFO - 2018-07-24 13:21:15 --> Database Driver Class Initialized
INFO - 2018-07-24 13:21:15 --> Model "QuestionsModel" initialized
INFO - 2018-07-24 13:21:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-24 13:21:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-24 13:21:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-24 13:21:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-24 13:21:15 --> Final output sent to browser
DEBUG - 2018-07-24 13:21:15 --> Total execution time: 0.0340
INFO - 2018-07-24 13:32:56 --> Config Class Initialized
INFO - 2018-07-24 13:32:56 --> Hooks Class Initialized
DEBUG - 2018-07-24 13:32:56 --> UTF-8 Support Enabled
INFO - 2018-07-24 13:32:56 --> Utf8 Class Initialized
INFO - 2018-07-24 13:32:56 --> URI Class Initialized
DEBUG - 2018-07-24 13:32:56 --> No URI present. Default controller set.
INFO - 2018-07-24 13:32:56 --> Router Class Initialized
INFO - 2018-07-24 13:32:56 --> Output Class Initialized
INFO - 2018-07-24 13:32:56 --> Security Class Initialized
DEBUG - 2018-07-24 13:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 13:32:56 --> CSRF cookie sent
INFO - 2018-07-24 13:32:56 --> Input Class Initialized
INFO - 2018-07-24 13:32:56 --> Language Class Initialized
INFO - 2018-07-24 13:32:56 --> Loader Class Initialized
INFO - 2018-07-24 13:32:56 --> Helper loaded: url_helper
INFO - 2018-07-24 13:32:56 --> Helper loaded: form_helper
INFO - 2018-07-24 13:32:56 --> Helper loaded: language_helper
DEBUG - 2018-07-24 13:32:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 13:32:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 13:32:56 --> User Agent Class Initialized
INFO - 2018-07-24 13:32:56 --> Controller Class Initialized
INFO - 2018-07-24 13:32:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 13:32:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-24 13:32:56 --> Pixel_Model class loaded
INFO - 2018-07-24 13:32:56 --> Database Driver Class Initialized
INFO - 2018-07-24 13:32:56 --> Model "QuestionsModel" initialized
INFO - 2018-07-24 13:32:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-24 13:32:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-24 13:32:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-24 13:32:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-24 13:32:56 --> Final output sent to browser
DEBUG - 2018-07-24 13:32:56 --> Total execution time: 0.0369
INFO - 2018-07-24 13:32:57 --> Config Class Initialized
INFO - 2018-07-24 13:32:57 --> Hooks Class Initialized
DEBUG - 2018-07-24 13:32:57 --> UTF-8 Support Enabled
INFO - 2018-07-24 13:32:57 --> Utf8 Class Initialized
INFO - 2018-07-24 13:32:57 --> URI Class Initialized
DEBUG - 2018-07-24 13:32:57 --> No URI present. Default controller set.
INFO - 2018-07-24 13:32:57 --> Router Class Initialized
INFO - 2018-07-24 13:32:57 --> Output Class Initialized
INFO - 2018-07-24 13:32:57 --> Security Class Initialized
DEBUG - 2018-07-24 13:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 13:32:57 --> CSRF cookie sent
INFO - 2018-07-24 13:32:57 --> Input Class Initialized
INFO - 2018-07-24 13:32:57 --> Language Class Initialized
INFO - 2018-07-24 13:32:57 --> Loader Class Initialized
INFO - 2018-07-24 13:32:57 --> Helper loaded: url_helper
INFO - 2018-07-24 13:32:57 --> Helper loaded: form_helper
INFO - 2018-07-24 13:32:57 --> Helper loaded: language_helper
DEBUG - 2018-07-24 13:32:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 13:32:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 13:32:57 --> User Agent Class Initialized
INFO - 2018-07-24 13:32:57 --> Controller Class Initialized
INFO - 2018-07-24 13:32:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 13:32:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-24 13:32:57 --> Pixel_Model class loaded
INFO - 2018-07-24 13:32:57 --> Database Driver Class Initialized
INFO - 2018-07-24 13:32:57 --> Model "QuestionsModel" initialized
INFO - 2018-07-24 13:32:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-24 13:32:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-24 13:32:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-24 13:32:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-24 13:32:57 --> Final output sent to browser
DEBUG - 2018-07-24 13:32:57 --> Total execution time: 0.0404
INFO - 2018-07-24 14:30:01 --> Config Class Initialized
INFO - 2018-07-24 14:30:01 --> Hooks Class Initialized
DEBUG - 2018-07-24 14:30:01 --> UTF-8 Support Enabled
INFO - 2018-07-24 14:30:01 --> Utf8 Class Initialized
INFO - 2018-07-24 14:30:01 --> URI Class Initialized
DEBUG - 2018-07-24 14:30:01 --> No URI present. Default controller set.
INFO - 2018-07-24 14:30:01 --> Router Class Initialized
INFO - 2018-07-24 14:30:01 --> Output Class Initialized
INFO - 2018-07-24 14:30:01 --> Security Class Initialized
DEBUG - 2018-07-24 14:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 14:30:01 --> CSRF cookie sent
INFO - 2018-07-24 14:30:01 --> Input Class Initialized
INFO - 2018-07-24 14:30:01 --> Language Class Initialized
INFO - 2018-07-24 14:30:01 --> Loader Class Initialized
INFO - 2018-07-24 14:30:01 --> Helper loaded: url_helper
INFO - 2018-07-24 14:30:01 --> Helper loaded: form_helper
INFO - 2018-07-24 14:30:01 --> Helper loaded: language_helper
DEBUG - 2018-07-24 14:30:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 14:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 14:30:01 --> User Agent Class Initialized
INFO - 2018-07-24 14:30:01 --> Controller Class Initialized
INFO - 2018-07-24 14:30:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 14:30:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-24 14:30:01 --> Pixel_Model class loaded
INFO - 2018-07-24 14:30:01 --> Database Driver Class Initialized
INFO - 2018-07-24 14:30:01 --> Model "QuestionsModel" initialized
INFO - 2018-07-24 14:30:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-24 14:30:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-24 14:30:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-24 14:30:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-24 14:30:01 --> Final output sent to browser
DEBUG - 2018-07-24 14:30:01 --> Total execution time: 0.0826
INFO - 2018-07-24 14:38:58 --> Config Class Initialized
INFO - 2018-07-24 14:38:58 --> Hooks Class Initialized
DEBUG - 2018-07-24 14:38:58 --> UTF-8 Support Enabled
INFO - 2018-07-24 14:38:58 --> Utf8 Class Initialized
INFO - 2018-07-24 14:38:58 --> URI Class Initialized
INFO - 2018-07-24 14:38:58 --> Router Class Initialized
INFO - 2018-07-24 14:38:58 --> Output Class Initialized
INFO - 2018-07-24 14:38:58 --> Security Class Initialized
DEBUG - 2018-07-24 14:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 14:38:58 --> CSRF cookie sent
INFO - 2018-07-24 14:38:58 --> Input Class Initialized
INFO - 2018-07-24 14:38:58 --> Language Class Initialized
INFO - 2018-07-24 14:38:58 --> Loader Class Initialized
INFO - 2018-07-24 14:38:58 --> Helper loaded: url_helper
INFO - 2018-07-24 14:38:58 --> Helper loaded: form_helper
INFO - 2018-07-24 14:38:58 --> Helper loaded: language_helper
DEBUG - 2018-07-24 14:38:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 14:38:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 14:38:58 --> User Agent Class Initialized
INFO - 2018-07-24 14:38:58 --> Controller Class Initialized
INFO - 2018-07-24 14:38:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 14:38:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-24 14:38:58 --> Pixel_Model class loaded
INFO - 2018-07-24 14:38:58 --> Database Driver Class Initialized
INFO - 2018-07-24 14:38:58 --> Model "QuestionsModel" initialized
INFO - 2018-07-24 14:38:58 --> Config Class Initialized
INFO - 2018-07-24 14:38:58 --> Hooks Class Initialized
DEBUG - 2018-07-24 14:38:58 --> UTF-8 Support Enabled
INFO - 2018-07-24 14:38:58 --> Utf8 Class Initialized
INFO - 2018-07-24 14:38:58 --> URI Class Initialized
INFO - 2018-07-24 14:38:58 --> Router Class Initialized
INFO - 2018-07-24 14:38:58 --> Output Class Initialized
INFO - 2018-07-24 14:38:58 --> Security Class Initialized
DEBUG - 2018-07-24 14:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 14:38:58 --> CSRF cookie sent
INFO - 2018-07-24 14:38:58 --> Input Class Initialized
INFO - 2018-07-24 14:38:58 --> Language Class Initialized
INFO - 2018-07-24 14:38:58 --> Loader Class Initialized
INFO - 2018-07-24 14:38:58 --> Helper loaded: url_helper
INFO - 2018-07-24 14:38:58 --> Helper loaded: form_helper
INFO - 2018-07-24 14:38:58 --> Helper loaded: language_helper
DEBUG - 2018-07-24 14:38:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 14:38:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 14:38:58 --> User Agent Class Initialized
INFO - 2018-07-24 14:38:58 --> Controller Class Initialized
INFO - 2018-07-24 14:38:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 14:38:58 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-24 14:38:58 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-24 14:38:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-24 14:38:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-24 14:38:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-24 14:38:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-24 14:38:58 --> Could not find the language line "req_email"
INFO - 2018-07-24 14:38:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-24 14:38:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-24 14:38:58 --> Final output sent to browser
DEBUG - 2018-07-24 14:38:58 --> Total execution time: 0.0215
INFO - 2018-07-24 14:39:03 --> Config Class Initialized
INFO - 2018-07-24 14:39:03 --> Hooks Class Initialized
DEBUG - 2018-07-24 14:39:03 --> UTF-8 Support Enabled
INFO - 2018-07-24 14:39:03 --> Utf8 Class Initialized
INFO - 2018-07-24 14:39:03 --> URI Class Initialized
DEBUG - 2018-07-24 14:39:03 --> No URI present. Default controller set.
INFO - 2018-07-24 14:39:03 --> Router Class Initialized
INFO - 2018-07-24 14:39:03 --> Output Class Initialized
INFO - 2018-07-24 14:39:03 --> Security Class Initialized
DEBUG - 2018-07-24 14:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 14:39:03 --> CSRF cookie sent
INFO - 2018-07-24 14:39:03 --> Input Class Initialized
INFO - 2018-07-24 14:39:03 --> Language Class Initialized
INFO - 2018-07-24 14:39:03 --> Loader Class Initialized
INFO - 2018-07-24 14:39:03 --> Helper loaded: url_helper
INFO - 2018-07-24 14:39:03 --> Helper loaded: form_helper
INFO - 2018-07-24 14:39:03 --> Helper loaded: language_helper
DEBUG - 2018-07-24 14:39:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 14:39:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 14:39:03 --> User Agent Class Initialized
INFO - 2018-07-24 14:39:03 --> Controller Class Initialized
INFO - 2018-07-24 14:39:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 14:39:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-24 14:39:03 --> Pixel_Model class loaded
INFO - 2018-07-24 14:39:03 --> Database Driver Class Initialized
INFO - 2018-07-24 14:39:03 --> Model "QuestionsModel" initialized
INFO - 2018-07-24 14:39:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-24 14:39:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-24 14:39:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-24 14:39:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-24 14:39:03 --> Final output sent to browser
DEBUG - 2018-07-24 14:39:03 --> Total execution time: 0.0337
INFO - 2018-07-24 14:39:25 --> Config Class Initialized
INFO - 2018-07-24 14:39:25 --> Hooks Class Initialized
DEBUG - 2018-07-24 14:39:25 --> UTF-8 Support Enabled
INFO - 2018-07-24 14:39:25 --> Utf8 Class Initialized
INFO - 2018-07-24 14:39:25 --> URI Class Initialized
INFO - 2018-07-24 14:39:25 --> Router Class Initialized
INFO - 2018-07-24 14:39:25 --> Output Class Initialized
INFO - 2018-07-24 14:39:25 --> Security Class Initialized
DEBUG - 2018-07-24 14:39:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 14:39:25 --> CSRF cookie sent
INFO - 2018-07-24 14:39:25 --> CSRF token verified
INFO - 2018-07-24 14:39:25 --> Input Class Initialized
INFO - 2018-07-24 14:39:25 --> Language Class Initialized
INFO - 2018-07-24 14:39:25 --> Loader Class Initialized
INFO - 2018-07-24 14:39:25 --> Helper loaded: url_helper
INFO - 2018-07-24 14:39:25 --> Helper loaded: form_helper
INFO - 2018-07-24 14:39:25 --> Helper loaded: language_helper
DEBUG - 2018-07-24 14:39:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 14:39:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 14:39:25 --> User Agent Class Initialized
INFO - 2018-07-24 14:39:25 --> Controller Class Initialized
INFO - 2018-07-24 14:39:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 14:39:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-24 14:39:25 --> Pixel_Model class loaded
INFO - 2018-07-24 14:39:25 --> Database Driver Class Initialized
INFO - 2018-07-24 14:39:25 --> Model "QuestionsModel" initialized
INFO - 2018-07-24 14:39:25 --> Config Class Initialized
INFO - 2018-07-24 14:39:25 --> Hooks Class Initialized
DEBUG - 2018-07-24 14:39:25 --> UTF-8 Support Enabled
INFO - 2018-07-24 14:39:25 --> Utf8 Class Initialized
INFO - 2018-07-24 14:39:25 --> URI Class Initialized
INFO - 2018-07-24 14:39:25 --> Router Class Initialized
INFO - 2018-07-24 14:39:25 --> Output Class Initialized
INFO - 2018-07-24 14:39:25 --> Security Class Initialized
DEBUG - 2018-07-24 14:39:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 14:39:25 --> CSRF cookie sent
INFO - 2018-07-24 14:39:25 --> Input Class Initialized
INFO - 2018-07-24 14:39:25 --> Language Class Initialized
INFO - 2018-07-24 14:39:25 --> Loader Class Initialized
INFO - 2018-07-24 14:39:25 --> Helper loaded: url_helper
INFO - 2018-07-24 14:39:25 --> Helper loaded: form_helper
INFO - 2018-07-24 14:39:25 --> Helper loaded: language_helper
DEBUG - 2018-07-24 14:39:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 14:39:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 14:39:25 --> User Agent Class Initialized
INFO - 2018-07-24 14:39:25 --> Controller Class Initialized
INFO - 2018-07-24 14:39:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 14:39:25 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-24 14:39:25 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-24 14:39:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-24 14:39:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-24 14:39:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-24 14:39:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-24 14:39:25 --> Could not find the language line "req_email"
INFO - 2018-07-24 14:39:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-24 14:39:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-24 14:39:25 --> Final output sent to browser
DEBUG - 2018-07-24 14:39:25 --> Total execution time: 0.0245
INFO - 2018-07-24 14:39:28 --> Config Class Initialized
INFO - 2018-07-24 14:39:28 --> Hooks Class Initialized
DEBUG - 2018-07-24 14:39:28 --> UTF-8 Support Enabled
INFO - 2018-07-24 14:39:28 --> Utf8 Class Initialized
INFO - 2018-07-24 14:39:28 --> URI Class Initialized
INFO - 2018-07-24 14:39:28 --> Router Class Initialized
INFO - 2018-07-24 14:39:28 --> Output Class Initialized
INFO - 2018-07-24 14:39:28 --> Security Class Initialized
DEBUG - 2018-07-24 14:39:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 14:39:28 --> CSRF cookie sent
INFO - 2018-07-24 14:39:28 --> Input Class Initialized
INFO - 2018-07-24 14:39:28 --> Language Class Initialized
INFO - 2018-07-24 14:39:28 --> Loader Class Initialized
INFO - 2018-07-24 14:39:28 --> Helper loaded: url_helper
INFO - 2018-07-24 14:39:28 --> Helper loaded: form_helper
INFO - 2018-07-24 14:39:28 --> Helper loaded: language_helper
DEBUG - 2018-07-24 14:39:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 14:39:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 14:39:28 --> User Agent Class Initialized
INFO - 2018-07-24 14:39:28 --> Controller Class Initialized
INFO - 2018-07-24 14:39:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 14:39:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-24 14:39:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-24 14:39:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-24 14:39:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-24 14:39:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-24 14:39:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-07-24 14:39:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-24 14:39:28 --> Final output sent to browser
DEBUG - 2018-07-24 14:39:28 --> Total execution time: 0.0217
INFO - 2018-07-24 14:39:29 --> Config Class Initialized
INFO - 2018-07-24 14:39:29 --> Hooks Class Initialized
DEBUG - 2018-07-24 14:39:29 --> UTF-8 Support Enabled
INFO - 2018-07-24 14:39:29 --> Utf8 Class Initialized
INFO - 2018-07-24 14:39:29 --> URI Class Initialized
INFO - 2018-07-24 14:39:29 --> Router Class Initialized
INFO - 2018-07-24 14:39:29 --> Output Class Initialized
INFO - 2018-07-24 14:39:29 --> Security Class Initialized
DEBUG - 2018-07-24 14:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 14:39:29 --> CSRF cookie sent
INFO - 2018-07-24 14:39:29 --> Input Class Initialized
INFO - 2018-07-24 14:39:29 --> Language Class Initialized
INFO - 2018-07-24 14:39:29 --> Loader Class Initialized
INFO - 2018-07-24 14:39:30 --> Helper loaded: url_helper
INFO - 2018-07-24 14:39:30 --> Helper loaded: form_helper
INFO - 2018-07-24 14:39:30 --> Helper loaded: language_helper
DEBUG - 2018-07-24 14:39:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 14:39:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 14:39:30 --> User Agent Class Initialized
INFO - 2018-07-24 14:39:30 --> Controller Class Initialized
INFO - 2018-07-24 14:39:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 14:39:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-24 14:39:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-24 14:39:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-24 14:39:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-24 14:39:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-24 14:39:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-07-24 14:39:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-24 14:39:30 --> Final output sent to browser
DEBUG - 2018-07-24 14:39:30 --> Total execution time: 0.0217
INFO - 2018-07-24 14:39:32 --> Config Class Initialized
INFO - 2018-07-24 14:39:32 --> Hooks Class Initialized
DEBUG - 2018-07-24 14:39:32 --> UTF-8 Support Enabled
INFO - 2018-07-24 14:39:32 --> Utf8 Class Initialized
INFO - 2018-07-24 14:39:32 --> URI Class Initialized
INFO - 2018-07-24 14:39:32 --> Router Class Initialized
INFO - 2018-07-24 14:39:32 --> Output Class Initialized
INFO - 2018-07-24 14:39:32 --> Security Class Initialized
DEBUG - 2018-07-24 14:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 14:39:32 --> CSRF cookie sent
INFO - 2018-07-24 14:39:32 --> Input Class Initialized
INFO - 2018-07-24 14:39:32 --> Language Class Initialized
INFO - 2018-07-24 14:39:32 --> Loader Class Initialized
INFO - 2018-07-24 14:39:32 --> Helper loaded: url_helper
INFO - 2018-07-24 14:39:32 --> Helper loaded: form_helper
INFO - 2018-07-24 14:39:32 --> Helper loaded: language_helper
DEBUG - 2018-07-24 14:39:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 14:39:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 14:39:32 --> User Agent Class Initialized
INFO - 2018-07-24 14:39:32 --> Controller Class Initialized
INFO - 2018-07-24 14:39:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 14:39:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-24 14:39:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-24 14:39:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-24 14:39:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-24 14:39:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-24 14:39:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-07-24 14:39:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-24 14:39:32 --> Final output sent to browser
DEBUG - 2018-07-24 14:39:32 --> Total execution time: 0.0218
INFO - 2018-07-24 14:39:43 --> Config Class Initialized
INFO - 2018-07-24 14:39:43 --> Hooks Class Initialized
DEBUG - 2018-07-24 14:39:43 --> UTF-8 Support Enabled
INFO - 2018-07-24 14:39:43 --> Utf8 Class Initialized
INFO - 2018-07-24 14:39:43 --> URI Class Initialized
INFO - 2018-07-24 14:39:43 --> Router Class Initialized
INFO - 2018-07-24 14:39:43 --> Output Class Initialized
INFO - 2018-07-24 14:39:43 --> Security Class Initialized
DEBUG - 2018-07-24 14:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 14:39:43 --> CSRF cookie sent
INFO - 2018-07-24 14:39:43 --> Input Class Initialized
INFO - 2018-07-24 14:39:43 --> Language Class Initialized
INFO - 2018-07-24 14:39:43 --> Loader Class Initialized
INFO - 2018-07-24 14:39:43 --> Helper loaded: url_helper
INFO - 2018-07-24 14:39:43 --> Helper loaded: form_helper
INFO - 2018-07-24 14:39:43 --> Helper loaded: language_helper
DEBUG - 2018-07-24 14:39:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 14:39:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 14:39:43 --> User Agent Class Initialized
INFO - 2018-07-24 14:39:43 --> Controller Class Initialized
INFO - 2018-07-24 14:39:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 14:39:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-24 14:39:43 --> Pixel_Model class loaded
INFO - 2018-07-24 14:39:43 --> Database Driver Class Initialized
INFO - 2018-07-24 14:39:43 --> Model "QuestionsModel" initialized
INFO - 2018-07-24 14:39:43 --> Config Class Initialized
INFO - 2018-07-24 14:39:43 --> Hooks Class Initialized
DEBUG - 2018-07-24 14:39:43 --> UTF-8 Support Enabled
INFO - 2018-07-24 14:39:43 --> Utf8 Class Initialized
INFO - 2018-07-24 14:39:43 --> URI Class Initialized
INFO - 2018-07-24 14:39:43 --> Router Class Initialized
INFO - 2018-07-24 14:39:43 --> Output Class Initialized
INFO - 2018-07-24 14:39:43 --> Security Class Initialized
DEBUG - 2018-07-24 14:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 14:39:43 --> CSRF cookie sent
INFO - 2018-07-24 14:39:43 --> Input Class Initialized
INFO - 2018-07-24 14:39:43 --> Language Class Initialized
INFO - 2018-07-24 14:39:43 --> Loader Class Initialized
INFO - 2018-07-24 14:39:43 --> Helper loaded: url_helper
INFO - 2018-07-24 14:39:43 --> Helper loaded: form_helper
INFO - 2018-07-24 14:39:43 --> Helper loaded: language_helper
DEBUG - 2018-07-24 14:39:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 14:39:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 14:39:43 --> User Agent Class Initialized
INFO - 2018-07-24 14:39:43 --> Controller Class Initialized
INFO - 2018-07-24 14:39:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 14:39:43 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-24 14:39:43 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-24 14:39:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-24 14:39:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-24 14:39:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-24 14:39:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-24 14:39:43 --> Could not find the language line "req_email"
INFO - 2018-07-24 14:39:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-24 14:39:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-24 14:39:43 --> Final output sent to browser
DEBUG - 2018-07-24 14:39:43 --> Total execution time: 0.0225
INFO - 2018-07-24 14:39:43 --> Config Class Initialized
INFO - 2018-07-24 14:39:43 --> Hooks Class Initialized
DEBUG - 2018-07-24 14:39:43 --> UTF-8 Support Enabled
INFO - 2018-07-24 14:39:43 --> Utf8 Class Initialized
INFO - 2018-07-24 14:39:43 --> URI Class Initialized
INFO - 2018-07-24 14:39:44 --> Router Class Initialized
INFO - 2018-07-24 14:39:44 --> Output Class Initialized
INFO - 2018-07-24 14:39:44 --> Security Class Initialized
DEBUG - 2018-07-24 14:39:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 14:39:44 --> CSRF cookie sent
INFO - 2018-07-24 14:39:44 --> Input Class Initialized
INFO - 2018-07-24 14:39:44 --> Language Class Initialized
INFO - 2018-07-24 14:39:44 --> Loader Class Initialized
INFO - 2018-07-24 14:39:44 --> Helper loaded: url_helper
INFO - 2018-07-24 14:39:44 --> Helper loaded: form_helper
INFO - 2018-07-24 14:39:44 --> Helper loaded: language_helper
DEBUG - 2018-07-24 14:39:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 14:39:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 14:39:44 --> User Agent Class Initialized
INFO - 2018-07-24 14:39:44 --> Controller Class Initialized
INFO - 2018-07-24 14:39:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 14:39:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-24 14:39:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-24 14:39:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-24 14:39:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-24 14:39:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-24 14:39:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-07-24 14:39:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-24 14:39:44 --> Final output sent to browser
DEBUG - 2018-07-24 14:39:44 --> Total execution time: 0.0236
INFO - 2018-07-24 15:30:34 --> Config Class Initialized
INFO - 2018-07-24 15:30:34 --> Hooks Class Initialized
DEBUG - 2018-07-24 15:30:34 --> UTF-8 Support Enabled
INFO - 2018-07-24 15:30:34 --> Utf8 Class Initialized
INFO - 2018-07-24 15:30:34 --> URI Class Initialized
DEBUG - 2018-07-24 15:30:34 --> No URI present. Default controller set.
INFO - 2018-07-24 15:30:34 --> Router Class Initialized
INFO - 2018-07-24 15:30:34 --> Output Class Initialized
INFO - 2018-07-24 15:30:34 --> Security Class Initialized
DEBUG - 2018-07-24 15:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 15:30:34 --> CSRF cookie sent
INFO - 2018-07-24 15:30:34 --> Input Class Initialized
INFO - 2018-07-24 15:30:34 --> Language Class Initialized
INFO - 2018-07-24 15:30:34 --> Loader Class Initialized
INFO - 2018-07-24 15:30:34 --> Helper loaded: url_helper
INFO - 2018-07-24 15:30:34 --> Helper loaded: form_helper
INFO - 2018-07-24 15:30:34 --> Helper loaded: language_helper
DEBUG - 2018-07-24 15:30:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 15:30:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 15:30:34 --> User Agent Class Initialized
INFO - 2018-07-24 15:30:34 --> Controller Class Initialized
INFO - 2018-07-24 15:30:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 15:30:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-24 15:30:34 --> Pixel_Model class loaded
INFO - 2018-07-24 15:30:34 --> Database Driver Class Initialized
INFO - 2018-07-24 15:30:34 --> Model "QuestionsModel" initialized
INFO - 2018-07-24 15:30:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-24 15:30:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-24 15:30:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-24 15:30:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-24 15:30:34 --> Final output sent to browser
DEBUG - 2018-07-24 15:30:34 --> Total execution time: 0.0443
INFO - 2018-07-24 15:30:35 --> Config Class Initialized
INFO - 2018-07-24 15:30:35 --> Hooks Class Initialized
DEBUG - 2018-07-24 15:30:35 --> UTF-8 Support Enabled
INFO - 2018-07-24 15:30:35 --> Utf8 Class Initialized
INFO - 2018-07-24 15:30:35 --> URI Class Initialized
DEBUG - 2018-07-24 15:30:35 --> No URI present. Default controller set.
INFO - 2018-07-24 15:30:35 --> Router Class Initialized
INFO - 2018-07-24 15:30:35 --> Output Class Initialized
INFO - 2018-07-24 15:30:35 --> Security Class Initialized
DEBUG - 2018-07-24 15:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 15:30:35 --> CSRF cookie sent
INFO - 2018-07-24 15:30:35 --> Input Class Initialized
INFO - 2018-07-24 15:30:35 --> Language Class Initialized
INFO - 2018-07-24 15:30:35 --> Loader Class Initialized
INFO - 2018-07-24 15:30:35 --> Helper loaded: url_helper
INFO - 2018-07-24 15:30:35 --> Helper loaded: form_helper
INFO - 2018-07-24 15:30:35 --> Helper loaded: language_helper
DEBUG - 2018-07-24 15:30:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 15:30:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 15:30:35 --> User Agent Class Initialized
INFO - 2018-07-24 15:30:35 --> Controller Class Initialized
INFO - 2018-07-24 15:30:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 15:30:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-24 15:30:35 --> Pixel_Model class loaded
INFO - 2018-07-24 15:30:35 --> Database Driver Class Initialized
INFO - 2018-07-24 15:30:35 --> Model "QuestionsModel" initialized
INFO - 2018-07-24 15:30:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-24 15:30:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-24 15:30:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-24 15:30:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-24 15:30:35 --> Final output sent to browser
DEBUG - 2018-07-24 15:30:35 --> Total execution time: 0.0357
INFO - 2018-07-24 15:30:38 --> Config Class Initialized
INFO - 2018-07-24 15:30:38 --> Hooks Class Initialized
DEBUG - 2018-07-24 15:30:38 --> UTF-8 Support Enabled
INFO - 2018-07-24 15:30:38 --> Utf8 Class Initialized
INFO - 2018-07-24 15:30:38 --> URI Class Initialized
INFO - 2018-07-24 15:30:38 --> Router Class Initialized
INFO - 2018-07-24 15:30:38 --> Output Class Initialized
INFO - 2018-07-24 15:30:38 --> Security Class Initialized
DEBUG - 2018-07-24 15:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 15:30:38 --> CSRF cookie sent
INFO - 2018-07-24 15:30:38 --> Input Class Initialized
INFO - 2018-07-24 15:30:38 --> Language Class Initialized
INFO - 2018-07-24 15:30:38 --> Loader Class Initialized
INFO - 2018-07-24 15:30:38 --> Helper loaded: url_helper
INFO - 2018-07-24 15:30:38 --> Helper loaded: form_helper
INFO - 2018-07-24 15:30:38 --> Helper loaded: language_helper
DEBUG - 2018-07-24 15:30:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 15:30:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 15:30:38 --> User Agent Class Initialized
INFO - 2018-07-24 15:30:38 --> Controller Class Initialized
INFO - 2018-07-24 15:30:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 15:30:38 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-24 15:30:38 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-24 15:30:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-24 15:30:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-24 15:30:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-24 15:30:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-24 15:30:38 --> Could not find the language line "req_email"
INFO - 2018-07-24 15:30:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-24 15:30:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-24 15:30:38 --> Final output sent to browser
DEBUG - 2018-07-24 15:30:38 --> Total execution time: 0.0245
INFO - 2018-07-24 15:30:41 --> Config Class Initialized
INFO - 2018-07-24 15:30:41 --> Hooks Class Initialized
DEBUG - 2018-07-24 15:30:41 --> UTF-8 Support Enabled
INFO - 2018-07-24 15:30:41 --> Utf8 Class Initialized
INFO - 2018-07-24 15:30:41 --> URI Class Initialized
INFO - 2018-07-24 15:30:41 --> Router Class Initialized
INFO - 2018-07-24 15:30:41 --> Output Class Initialized
INFO - 2018-07-24 15:30:41 --> Security Class Initialized
DEBUG - 2018-07-24 15:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 15:30:41 --> CSRF cookie sent
INFO - 2018-07-24 15:30:41 --> Input Class Initialized
INFO - 2018-07-24 15:30:41 --> Language Class Initialized
INFO - 2018-07-24 15:30:41 --> Loader Class Initialized
INFO - 2018-07-24 15:30:41 --> Helper loaded: url_helper
INFO - 2018-07-24 15:30:41 --> Helper loaded: form_helper
INFO - 2018-07-24 15:30:41 --> Helper loaded: language_helper
DEBUG - 2018-07-24 15:30:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 15:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 15:30:41 --> User Agent Class Initialized
INFO - 2018-07-24 15:30:41 --> Controller Class Initialized
INFO - 2018-07-24 15:30:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 15:30:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-24 15:30:41 --> Pixel_Model class loaded
INFO - 2018-07-24 15:30:41 --> Database Driver Class Initialized
INFO - 2018-07-24 15:30:41 --> Model "RegistrationModel" initialized
DEBUG - 2018-07-24 15:30:41 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-24 15:30:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-24 15:30:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-24 15:30:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-24 15:30:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-24 15:30:41 --> Could not find the language line "req_email"
INFO - 2018-07-24 15:30:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup.php
INFO - 2018-07-24 15:30:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-24 15:30:41 --> Final output sent to browser
DEBUG - 2018-07-24 15:30:41 --> Total execution time: 0.0357
INFO - 2018-07-24 15:39:19 --> Config Class Initialized
INFO - 2018-07-24 15:39:19 --> Hooks Class Initialized
DEBUG - 2018-07-24 15:39:19 --> UTF-8 Support Enabled
INFO - 2018-07-24 15:39:19 --> Utf8 Class Initialized
INFO - 2018-07-24 15:39:19 --> URI Class Initialized
INFO - 2018-07-24 15:39:19 --> Router Class Initialized
INFO - 2018-07-24 15:39:19 --> Output Class Initialized
INFO - 2018-07-24 15:39:19 --> Security Class Initialized
DEBUG - 2018-07-24 15:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 15:39:19 --> CSRF cookie sent
INFO - 2018-07-24 15:39:19 --> CSRF token verified
INFO - 2018-07-24 15:39:19 --> Input Class Initialized
INFO - 2018-07-24 15:39:19 --> Language Class Initialized
INFO - 2018-07-24 15:39:19 --> Loader Class Initialized
INFO - 2018-07-24 15:39:19 --> Helper loaded: url_helper
INFO - 2018-07-24 15:39:19 --> Helper loaded: form_helper
INFO - 2018-07-24 15:39:19 --> Helper loaded: language_helper
DEBUG - 2018-07-24 15:39:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 15:39:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 15:39:19 --> User Agent Class Initialized
INFO - 2018-07-24 15:39:19 --> Controller Class Initialized
INFO - 2018-07-24 15:39:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 15:39:19 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-24 15:39:19 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-24 15:39:19 --> Form Validation Class Initialized
INFO - 2018-07-24 15:39:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-07-24 15:39:19 --> Pixel_Model class loaded
INFO - 2018-07-24 15:39:19 --> Database Driver Class Initialized
INFO - 2018-07-24 15:39:19 --> Model "RegistrationModel" initialized
INFO - 2018-07-24 15:39:19 --> Helper loaded: string_helper
INFO - 2018-07-24 15:39:19 --> Language file loaded: language/en/notifications_lang.php
INFO - 2018-07-24 15:39:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/emails/_buttons.php
INFO - 2018-07-24 15:39:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/emails/header.php
INFO - 2018-07-24 15:39:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/emails/footer.php
INFO - 2018-07-24 15:39:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/emails/generic.php
INFO - 2018-07-24 15:39:20 --> Email Class Initialized
INFO - 2018-07-24 15:39:20 --> Language file loaded: language/english/email_lang.php
INFO - 2018-07-24 15:39:20 --> Config Class Initialized
INFO - 2018-07-24 15:39:20 --> Hooks Class Initialized
DEBUG - 2018-07-24 15:39:20 --> UTF-8 Support Enabled
INFO - 2018-07-24 15:39:20 --> Utf8 Class Initialized
INFO - 2018-07-24 15:39:20 --> URI Class Initialized
INFO - 2018-07-24 15:39:20 --> Router Class Initialized
INFO - 2018-07-24 15:39:20 --> Output Class Initialized
INFO - 2018-07-24 15:39:20 --> Security Class Initialized
DEBUG - 2018-07-24 15:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 15:39:20 --> CSRF cookie sent
INFO - 2018-07-24 15:39:20 --> Input Class Initialized
INFO - 2018-07-24 15:39:20 --> Language Class Initialized
INFO - 2018-07-24 15:39:20 --> Loader Class Initialized
INFO - 2018-07-24 15:39:20 --> Helper loaded: url_helper
INFO - 2018-07-24 15:39:20 --> Helper loaded: form_helper
INFO - 2018-07-24 15:39:20 --> Helper loaded: language_helper
DEBUG - 2018-07-24 15:39:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 15:39:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 15:39:20 --> User Agent Class Initialized
INFO - 2018-07-24 15:39:20 --> Controller Class Initialized
INFO - 2018-07-24 15:39:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 15:39:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-24 15:39:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-24 15:39:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-24 15:39:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-07-24 15:39:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-24 15:39:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/thanks.php
INFO - 2018-07-24 15:39:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-24 15:39:20 --> Final output sent to browser
DEBUG - 2018-07-24 15:39:20 --> Total execution time: 0.0353
INFO - 2018-07-24 15:39:48 --> Config Class Initialized
INFO - 2018-07-24 15:39:48 --> Hooks Class Initialized
DEBUG - 2018-07-24 15:39:48 --> UTF-8 Support Enabled
INFO - 2018-07-24 15:39:48 --> Utf8 Class Initialized
INFO - 2018-07-24 15:39:48 --> URI Class Initialized
DEBUG - 2018-07-24 15:39:48 --> No URI present. Default controller set.
INFO - 2018-07-24 15:39:48 --> Router Class Initialized
INFO - 2018-07-24 15:39:48 --> Output Class Initialized
INFO - 2018-07-24 15:39:48 --> Security Class Initialized
DEBUG - 2018-07-24 15:39:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 15:39:48 --> CSRF cookie sent
INFO - 2018-07-24 15:39:48 --> Input Class Initialized
INFO - 2018-07-24 15:39:48 --> Language Class Initialized
INFO - 2018-07-24 15:39:48 --> Loader Class Initialized
INFO - 2018-07-24 15:39:48 --> Helper loaded: url_helper
INFO - 2018-07-24 15:39:48 --> Helper loaded: form_helper
INFO - 2018-07-24 15:39:48 --> Helper loaded: language_helper
DEBUG - 2018-07-24 15:39:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 15:39:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 15:39:48 --> User Agent Class Initialized
INFO - 2018-07-24 15:39:48 --> Controller Class Initialized
INFO - 2018-07-24 15:39:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 15:39:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-24 15:39:48 --> Pixel_Model class loaded
INFO - 2018-07-24 15:39:48 --> Database Driver Class Initialized
INFO - 2018-07-24 15:39:48 --> Model "QuestionsModel" initialized
INFO - 2018-07-24 15:39:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-24 15:39:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-24 15:39:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-24 15:39:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-24 15:39:48 --> Final output sent to browser
DEBUG - 2018-07-24 15:39:48 --> Total execution time: 0.0378
INFO - 2018-07-24 15:48:19 --> Config Class Initialized
INFO - 2018-07-24 15:48:19 --> Hooks Class Initialized
DEBUG - 2018-07-24 15:48:19 --> UTF-8 Support Enabled
INFO - 2018-07-24 15:48:19 --> Utf8 Class Initialized
INFO - 2018-07-24 15:48:19 --> URI Class Initialized
INFO - 2018-07-24 15:48:19 --> Router Class Initialized
INFO - 2018-07-24 15:48:19 --> Output Class Initialized
INFO - 2018-07-24 15:48:19 --> Security Class Initialized
DEBUG - 2018-07-24 15:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 15:48:19 --> CSRF cookie sent
INFO - 2018-07-24 15:48:19 --> Input Class Initialized
INFO - 2018-07-24 15:48:19 --> Language Class Initialized
INFO - 2018-07-24 15:48:19 --> Loader Class Initialized
INFO - 2018-07-24 15:48:19 --> Helper loaded: url_helper
INFO - 2018-07-24 15:48:19 --> Helper loaded: form_helper
INFO - 2018-07-24 15:48:19 --> Helper loaded: language_helper
DEBUG - 2018-07-24 15:48:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 15:48:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 15:48:19 --> User Agent Class Initialized
INFO - 2018-07-24 15:48:19 --> Controller Class Initialized
INFO - 2018-07-24 15:48:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 15:48:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-24 15:48:19 --> Pixel_Model class loaded
INFO - 2018-07-24 15:48:19 --> Database Driver Class Initialized
INFO - 2018-07-24 15:48:19 --> Model "RegistrationModel" initialized
DEBUG - 2018-07-24 15:48:19 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-24 15:48:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-24 15:48:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-24 15:48:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-24 15:48:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-24 15:48:19 --> Could not find the language line "req_email"
INFO - 2018-07-24 15:48:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup.php
INFO - 2018-07-24 15:48:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-24 15:48:19 --> Final output sent to browser
DEBUG - 2018-07-24 15:48:19 --> Total execution time: 0.0360
INFO - 2018-07-24 15:48:22 --> Config Class Initialized
INFO - 2018-07-24 15:48:22 --> Hooks Class Initialized
DEBUG - 2018-07-24 15:48:22 --> UTF-8 Support Enabled
INFO - 2018-07-24 15:48:22 --> Utf8 Class Initialized
INFO - 2018-07-24 15:48:22 --> URI Class Initialized
INFO - 2018-07-24 15:48:22 --> Router Class Initialized
INFO - 2018-07-24 15:48:22 --> Output Class Initialized
INFO - 2018-07-24 15:48:22 --> Security Class Initialized
DEBUG - 2018-07-24 15:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 15:48:22 --> CSRF cookie sent
INFO - 2018-07-24 15:48:22 --> Input Class Initialized
INFO - 2018-07-24 15:48:22 --> Language Class Initialized
INFO - 2018-07-24 15:48:22 --> Loader Class Initialized
INFO - 2018-07-24 15:48:22 --> Helper loaded: url_helper
INFO - 2018-07-24 15:48:22 --> Helper loaded: form_helper
INFO - 2018-07-24 15:48:22 --> Helper loaded: language_helper
DEBUG - 2018-07-24 15:48:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 15:48:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 15:48:22 --> User Agent Class Initialized
INFO - 2018-07-24 15:48:22 --> Controller Class Initialized
INFO - 2018-07-24 15:48:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 15:48:22 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-24 15:48:22 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-24 15:48:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-24 15:48:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-24 15:48:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-24 15:48:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-24 15:48:22 --> Could not find the language line "req_email"
INFO - 2018-07-24 15:48:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-24 15:48:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-24 15:48:22 --> Final output sent to browser
DEBUG - 2018-07-24 15:48:22 --> Total execution time: 0.0228
INFO - 2018-07-24 15:48:32 --> Config Class Initialized
INFO - 2018-07-24 15:48:32 --> Hooks Class Initialized
DEBUG - 2018-07-24 15:48:32 --> UTF-8 Support Enabled
INFO - 2018-07-24 15:48:32 --> Utf8 Class Initialized
INFO - 2018-07-24 15:48:32 --> URI Class Initialized
INFO - 2018-07-24 15:48:32 --> Router Class Initialized
INFO - 2018-07-24 15:48:32 --> Output Class Initialized
INFO - 2018-07-24 15:48:32 --> Security Class Initialized
DEBUG - 2018-07-24 15:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 15:48:32 --> CSRF cookie sent
INFO - 2018-07-24 15:48:32 --> Input Class Initialized
INFO - 2018-07-24 15:48:32 --> Language Class Initialized
INFO - 2018-07-24 15:48:32 --> Loader Class Initialized
INFO - 2018-07-24 15:48:32 --> Helper loaded: url_helper
INFO - 2018-07-24 15:48:32 --> Helper loaded: form_helper
INFO - 2018-07-24 15:48:32 --> Helper loaded: language_helper
DEBUG - 2018-07-24 15:48:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 15:48:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 15:48:32 --> User Agent Class Initialized
INFO - 2018-07-24 15:48:32 --> Controller Class Initialized
INFO - 2018-07-24 15:48:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 15:48:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-24 15:48:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-24 15:48:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-24 15:48:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-07-24 15:48:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-24 15:48:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/thanks.php
INFO - 2018-07-24 15:48:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-24 15:48:32 --> Final output sent to browser
DEBUG - 2018-07-24 15:48:32 --> Total execution time: 0.0328
INFO - 2018-07-24 17:53:49 --> Config Class Initialized
INFO - 2018-07-24 17:53:49 --> Hooks Class Initialized
DEBUG - 2018-07-24 17:53:49 --> UTF-8 Support Enabled
INFO - 2018-07-24 17:53:49 --> Utf8 Class Initialized
INFO - 2018-07-24 17:53:49 --> URI Class Initialized
DEBUG - 2018-07-24 17:53:49 --> No URI present. Default controller set.
INFO - 2018-07-24 17:53:49 --> Router Class Initialized
INFO - 2018-07-24 17:53:49 --> Output Class Initialized
INFO - 2018-07-24 17:53:49 --> Security Class Initialized
DEBUG - 2018-07-24 17:53:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 17:53:49 --> CSRF cookie sent
INFO - 2018-07-24 17:53:49 --> Input Class Initialized
INFO - 2018-07-24 17:53:49 --> Language Class Initialized
INFO - 2018-07-24 17:53:49 --> Loader Class Initialized
INFO - 2018-07-24 17:53:49 --> Helper loaded: url_helper
INFO - 2018-07-24 17:53:49 --> Helper loaded: form_helper
INFO - 2018-07-24 17:53:49 --> Helper loaded: language_helper
DEBUG - 2018-07-24 17:53:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 17:53:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 17:53:49 --> User Agent Class Initialized
INFO - 2018-07-24 17:53:49 --> Controller Class Initialized
INFO - 2018-07-24 17:53:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 17:53:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-24 17:53:49 --> Pixel_Model class loaded
INFO - 2018-07-24 17:53:49 --> Database Driver Class Initialized
INFO - 2018-07-24 17:53:49 --> Model "QuestionsModel" initialized
INFO - 2018-07-24 17:53:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-24 17:53:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-24 17:53:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-24 17:53:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-24 17:53:49 --> Final output sent to browser
DEBUG - 2018-07-24 17:53:49 --> Total execution time: 0.0408
INFO - 2018-07-24 18:00:37 --> Config Class Initialized
INFO - 2018-07-24 18:00:37 --> Hooks Class Initialized
DEBUG - 2018-07-24 18:00:37 --> UTF-8 Support Enabled
INFO - 2018-07-24 18:00:37 --> Utf8 Class Initialized
INFO - 2018-07-24 18:00:37 --> URI Class Initialized
DEBUG - 2018-07-24 18:00:37 --> No URI present. Default controller set.
INFO - 2018-07-24 18:00:37 --> Router Class Initialized
INFO - 2018-07-24 18:00:37 --> Output Class Initialized
INFO - 2018-07-24 18:00:37 --> Security Class Initialized
DEBUG - 2018-07-24 18:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 18:00:37 --> CSRF cookie sent
INFO - 2018-07-24 18:00:37 --> Input Class Initialized
INFO - 2018-07-24 18:00:37 --> Language Class Initialized
INFO - 2018-07-24 18:00:37 --> Loader Class Initialized
INFO - 2018-07-24 18:00:37 --> Helper loaded: url_helper
INFO - 2018-07-24 18:00:37 --> Helper loaded: form_helper
INFO - 2018-07-24 18:00:37 --> Helper loaded: language_helper
DEBUG - 2018-07-24 18:00:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 18:00:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 18:00:37 --> User Agent Class Initialized
INFO - 2018-07-24 18:00:37 --> Controller Class Initialized
INFO - 2018-07-24 18:00:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 18:00:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-24 18:00:37 --> Pixel_Model class loaded
INFO - 2018-07-24 18:00:37 --> Database Driver Class Initialized
INFO - 2018-07-24 18:00:37 --> Model "QuestionsModel" initialized
INFO - 2018-07-24 18:00:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-24 18:00:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-24 18:00:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-24 18:00:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-24 18:00:37 --> Final output sent to browser
DEBUG - 2018-07-24 18:00:37 --> Total execution time: 0.0376
INFO - 2018-07-24 18:00:37 --> Config Class Initialized
INFO - 2018-07-24 18:00:37 --> Hooks Class Initialized
DEBUG - 2018-07-24 18:00:37 --> UTF-8 Support Enabled
INFO - 2018-07-24 18:00:37 --> Utf8 Class Initialized
INFO - 2018-07-24 18:00:37 --> URI Class Initialized
DEBUG - 2018-07-24 18:00:37 --> No URI present. Default controller set.
INFO - 2018-07-24 18:00:37 --> Router Class Initialized
INFO - 2018-07-24 18:00:37 --> Output Class Initialized
INFO - 2018-07-24 18:00:37 --> Security Class Initialized
DEBUG - 2018-07-24 18:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 18:00:37 --> CSRF cookie sent
INFO - 2018-07-24 18:00:37 --> Input Class Initialized
INFO - 2018-07-24 18:00:37 --> Language Class Initialized
INFO - 2018-07-24 18:00:37 --> Loader Class Initialized
INFO - 2018-07-24 18:00:37 --> Helper loaded: url_helper
INFO - 2018-07-24 18:00:37 --> Helper loaded: form_helper
INFO - 2018-07-24 18:00:37 --> Helper loaded: language_helper
DEBUG - 2018-07-24 18:00:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 18:00:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 18:00:37 --> User Agent Class Initialized
INFO - 2018-07-24 18:00:37 --> Controller Class Initialized
INFO - 2018-07-24 18:00:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 18:00:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-24 18:00:37 --> Pixel_Model class loaded
INFO - 2018-07-24 18:00:37 --> Database Driver Class Initialized
INFO - 2018-07-24 18:00:37 --> Model "QuestionsModel" initialized
INFO - 2018-07-24 18:00:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-24 18:00:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-24 18:00:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-24 18:00:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-24 18:00:37 --> Final output sent to browser
DEBUG - 2018-07-24 18:00:37 --> Total execution time: 0.0333
INFO - 2018-07-24 18:00:49 --> Config Class Initialized
INFO - 2018-07-24 18:00:49 --> Hooks Class Initialized
DEBUG - 2018-07-24 18:00:49 --> UTF-8 Support Enabled
INFO - 2018-07-24 18:00:49 --> Utf8 Class Initialized
INFO - 2018-07-24 18:00:49 --> URI Class Initialized
DEBUG - 2018-07-24 18:00:49 --> No URI present. Default controller set.
INFO - 2018-07-24 18:00:49 --> Router Class Initialized
INFO - 2018-07-24 18:00:49 --> Output Class Initialized
INFO - 2018-07-24 18:00:49 --> Security Class Initialized
DEBUG - 2018-07-24 18:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 18:00:49 --> CSRF cookie sent
INFO - 2018-07-24 18:00:49 --> Input Class Initialized
INFO - 2018-07-24 18:00:49 --> Language Class Initialized
INFO - 2018-07-24 18:00:49 --> Loader Class Initialized
INFO - 2018-07-24 18:00:49 --> Helper loaded: url_helper
INFO - 2018-07-24 18:00:49 --> Helper loaded: form_helper
INFO - 2018-07-24 18:00:49 --> Helper loaded: language_helper
DEBUG - 2018-07-24 18:00:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 18:00:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 18:00:49 --> User Agent Class Initialized
INFO - 2018-07-24 18:00:49 --> Controller Class Initialized
INFO - 2018-07-24 18:00:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 18:00:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-24 18:00:49 --> Pixel_Model class loaded
INFO - 2018-07-24 18:00:49 --> Database Driver Class Initialized
INFO - 2018-07-24 18:00:49 --> Model "QuestionsModel" initialized
INFO - 2018-07-24 18:00:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-24 18:00:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-24 18:00:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-24 18:00:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-24 18:00:49 --> Final output sent to browser
DEBUG - 2018-07-24 18:00:49 --> Total execution time: 0.0337
INFO - 2018-07-24 18:01:03 --> Config Class Initialized
INFO - 2018-07-24 18:01:03 --> Hooks Class Initialized
DEBUG - 2018-07-24 18:01:03 --> UTF-8 Support Enabled
INFO - 2018-07-24 18:01:03 --> Utf8 Class Initialized
INFO - 2018-07-24 18:01:03 --> URI Class Initialized
INFO - 2018-07-24 18:01:03 --> Router Class Initialized
INFO - 2018-07-24 18:01:03 --> Output Class Initialized
INFO - 2018-07-24 18:01:03 --> Security Class Initialized
DEBUG - 2018-07-24 18:01:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 18:01:03 --> CSRF cookie sent
INFO - 2018-07-24 18:01:03 --> Input Class Initialized
INFO - 2018-07-24 18:01:03 --> Language Class Initialized
INFO - 2018-07-24 18:01:03 --> Loader Class Initialized
INFO - 2018-07-24 18:01:03 --> Helper loaded: url_helper
INFO - 2018-07-24 18:01:03 --> Helper loaded: form_helper
INFO - 2018-07-24 18:01:03 --> Helper loaded: language_helper
DEBUG - 2018-07-24 18:01:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 18:01:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 18:01:03 --> User Agent Class Initialized
INFO - 2018-07-24 18:01:03 --> Controller Class Initialized
INFO - 2018-07-24 18:01:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 18:01:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-24 18:01:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-24 18:01:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-24 18:01:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-24 18:01:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-24 18:01:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-07-24 18:01:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-24 18:01:03 --> Final output sent to browser
DEBUG - 2018-07-24 18:01:03 --> Total execution time: 0.0201
INFO - 2018-07-24 18:01:21 --> Config Class Initialized
INFO - 2018-07-24 18:01:21 --> Hooks Class Initialized
DEBUG - 2018-07-24 18:01:21 --> UTF-8 Support Enabled
INFO - 2018-07-24 18:01:21 --> Utf8 Class Initialized
INFO - 2018-07-24 18:01:21 --> URI Class Initialized
DEBUG - 2018-07-24 18:01:21 --> No URI present. Default controller set.
INFO - 2018-07-24 18:01:21 --> Router Class Initialized
INFO - 2018-07-24 18:01:21 --> Output Class Initialized
INFO - 2018-07-24 18:01:21 --> Security Class Initialized
DEBUG - 2018-07-24 18:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 18:01:21 --> CSRF cookie sent
INFO - 2018-07-24 18:01:21 --> Input Class Initialized
INFO - 2018-07-24 18:01:21 --> Language Class Initialized
INFO - 2018-07-24 18:01:21 --> Loader Class Initialized
INFO - 2018-07-24 18:01:21 --> Helper loaded: url_helper
INFO - 2018-07-24 18:01:21 --> Helper loaded: form_helper
INFO - 2018-07-24 18:01:21 --> Helper loaded: language_helper
DEBUG - 2018-07-24 18:01:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 18:01:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 18:01:21 --> User Agent Class Initialized
INFO - 2018-07-24 18:01:21 --> Controller Class Initialized
INFO - 2018-07-24 18:01:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 18:01:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-24 18:01:21 --> Pixel_Model class loaded
INFO - 2018-07-24 18:01:21 --> Database Driver Class Initialized
INFO - 2018-07-24 18:01:21 --> Model "QuestionsModel" initialized
INFO - 2018-07-24 18:01:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-24 18:01:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-24 18:01:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-24 18:01:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-24 18:01:21 --> Final output sent to browser
DEBUG - 2018-07-24 18:01:21 --> Total execution time: 0.0338
INFO - 2018-07-24 18:01:35 --> Config Class Initialized
INFO - 2018-07-24 18:01:35 --> Hooks Class Initialized
DEBUG - 2018-07-24 18:01:35 --> UTF-8 Support Enabled
INFO - 2018-07-24 18:01:35 --> Utf8 Class Initialized
INFO - 2018-07-24 18:01:35 --> URI Class Initialized
INFO - 2018-07-24 18:01:35 --> Router Class Initialized
INFO - 2018-07-24 18:01:35 --> Output Class Initialized
INFO - 2018-07-24 18:01:35 --> Security Class Initialized
DEBUG - 2018-07-24 18:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 18:01:35 --> CSRF cookie sent
INFO - 2018-07-24 18:01:35 --> Input Class Initialized
INFO - 2018-07-24 18:01:35 --> Language Class Initialized
INFO - 2018-07-24 18:01:35 --> Loader Class Initialized
INFO - 2018-07-24 18:01:35 --> Helper loaded: url_helper
INFO - 2018-07-24 18:01:35 --> Helper loaded: form_helper
INFO - 2018-07-24 18:01:35 --> Helper loaded: language_helper
DEBUG - 2018-07-24 18:01:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 18:01:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 18:01:35 --> User Agent Class Initialized
INFO - 2018-07-24 18:01:35 --> Controller Class Initialized
INFO - 2018-07-24 18:01:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 18:01:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-24 18:01:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-24 18:01:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-24 18:01:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-24 18:01:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-24 18:01:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-07-24 18:01:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-24 18:01:35 --> Final output sent to browser
DEBUG - 2018-07-24 18:01:35 --> Total execution time: 0.0235
INFO - 2018-07-24 18:52:30 --> Config Class Initialized
INFO - 2018-07-24 18:52:30 --> Hooks Class Initialized
DEBUG - 2018-07-24 18:52:30 --> UTF-8 Support Enabled
INFO - 2018-07-24 18:52:30 --> Utf8 Class Initialized
INFO - 2018-07-24 18:52:30 --> URI Class Initialized
DEBUG - 2018-07-24 18:52:30 --> No URI present. Default controller set.
INFO - 2018-07-24 18:52:30 --> Router Class Initialized
INFO - 2018-07-24 18:52:30 --> Output Class Initialized
INFO - 2018-07-24 18:52:30 --> Security Class Initialized
DEBUG - 2018-07-24 18:52:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 18:52:30 --> CSRF cookie sent
INFO - 2018-07-24 18:52:30 --> Input Class Initialized
INFO - 2018-07-24 18:52:30 --> Language Class Initialized
INFO - 2018-07-24 18:52:30 --> Loader Class Initialized
INFO - 2018-07-24 18:52:30 --> Helper loaded: url_helper
INFO - 2018-07-24 18:52:30 --> Helper loaded: form_helper
INFO - 2018-07-24 18:52:30 --> Helper loaded: language_helper
DEBUG - 2018-07-24 18:52:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 18:52:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 18:52:30 --> User Agent Class Initialized
INFO - 2018-07-24 18:52:30 --> Controller Class Initialized
INFO - 2018-07-24 18:52:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 18:52:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-24 18:52:30 --> Pixel_Model class loaded
INFO - 2018-07-24 18:52:30 --> Database Driver Class Initialized
INFO - 2018-07-24 18:52:30 --> Model "QuestionsModel" initialized
INFO - 2018-07-24 18:52:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-24 18:52:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-24 18:52:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-24 18:52:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-24 18:52:30 --> Final output sent to browser
DEBUG - 2018-07-24 18:52:30 --> Total execution time: 0.0333
INFO - 2018-07-24 19:07:38 --> Config Class Initialized
INFO - 2018-07-24 19:07:38 --> Hooks Class Initialized
DEBUG - 2018-07-24 19:07:38 --> UTF-8 Support Enabled
INFO - 2018-07-24 19:07:38 --> Utf8 Class Initialized
INFO - 2018-07-24 19:07:38 --> URI Class Initialized
DEBUG - 2018-07-24 19:07:38 --> No URI present. Default controller set.
INFO - 2018-07-24 19:07:38 --> Router Class Initialized
INFO - 2018-07-24 19:07:38 --> Output Class Initialized
INFO - 2018-07-24 19:07:38 --> Security Class Initialized
DEBUG - 2018-07-24 19:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 19:07:38 --> CSRF cookie sent
INFO - 2018-07-24 19:07:38 --> Input Class Initialized
INFO - 2018-07-24 19:07:38 --> Language Class Initialized
INFO - 2018-07-24 19:07:38 --> Loader Class Initialized
INFO - 2018-07-24 19:07:38 --> Helper loaded: url_helper
INFO - 2018-07-24 19:07:38 --> Helper loaded: form_helper
INFO - 2018-07-24 19:07:38 --> Helper loaded: language_helper
DEBUG - 2018-07-24 19:07:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 19:07:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 19:07:38 --> User Agent Class Initialized
INFO - 2018-07-24 19:07:38 --> Controller Class Initialized
INFO - 2018-07-24 19:07:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 19:07:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-24 19:07:38 --> Pixel_Model class loaded
INFO - 2018-07-24 19:07:38 --> Database Driver Class Initialized
INFO - 2018-07-24 19:07:38 --> Model "QuestionsModel" initialized
INFO - 2018-07-24 19:07:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-24 19:07:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-24 19:07:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-24 19:07:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-24 19:07:38 --> Final output sent to browser
DEBUG - 2018-07-24 19:07:38 --> Total execution time: 0.0400
INFO - 2018-07-24 19:07:39 --> Config Class Initialized
INFO - 2018-07-24 19:07:39 --> Hooks Class Initialized
DEBUG - 2018-07-24 19:07:39 --> UTF-8 Support Enabled
INFO - 2018-07-24 19:07:39 --> Utf8 Class Initialized
INFO - 2018-07-24 19:07:39 --> URI Class Initialized
DEBUG - 2018-07-24 19:07:39 --> No URI present. Default controller set.
INFO - 2018-07-24 19:07:39 --> Router Class Initialized
INFO - 2018-07-24 19:07:39 --> Output Class Initialized
INFO - 2018-07-24 19:07:39 --> Security Class Initialized
DEBUG - 2018-07-24 19:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 19:07:39 --> CSRF cookie sent
INFO - 2018-07-24 19:07:39 --> Input Class Initialized
INFO - 2018-07-24 19:07:39 --> Language Class Initialized
INFO - 2018-07-24 19:07:39 --> Loader Class Initialized
INFO - 2018-07-24 19:07:39 --> Helper loaded: url_helper
INFO - 2018-07-24 19:07:39 --> Helper loaded: form_helper
INFO - 2018-07-24 19:07:39 --> Helper loaded: language_helper
DEBUG - 2018-07-24 19:07:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 19:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 19:07:39 --> User Agent Class Initialized
INFO - 2018-07-24 19:07:39 --> Controller Class Initialized
INFO - 2018-07-24 19:07:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 19:07:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-24 19:07:39 --> Pixel_Model class loaded
INFO - 2018-07-24 19:07:39 --> Database Driver Class Initialized
INFO - 2018-07-24 19:07:39 --> Model "QuestionsModel" initialized
INFO - 2018-07-24 19:07:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-24 19:07:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-24 19:07:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-24 19:07:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-24 19:07:39 --> Final output sent to browser
DEBUG - 2018-07-24 19:07:39 --> Total execution time: 0.0352
INFO - 2018-07-24 19:07:40 --> Config Class Initialized
INFO - 2018-07-24 19:07:40 --> Hooks Class Initialized
DEBUG - 2018-07-24 19:07:40 --> UTF-8 Support Enabled
INFO - 2018-07-24 19:07:40 --> Utf8 Class Initialized
INFO - 2018-07-24 19:07:40 --> URI Class Initialized
DEBUG - 2018-07-24 19:07:40 --> No URI present. Default controller set.
INFO - 2018-07-24 19:07:40 --> Router Class Initialized
INFO - 2018-07-24 19:07:40 --> Output Class Initialized
INFO - 2018-07-24 19:07:40 --> Security Class Initialized
DEBUG - 2018-07-24 19:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 19:07:40 --> CSRF cookie sent
INFO - 2018-07-24 19:07:40 --> Input Class Initialized
INFO - 2018-07-24 19:07:40 --> Language Class Initialized
INFO - 2018-07-24 19:07:40 --> Loader Class Initialized
INFO - 2018-07-24 19:07:40 --> Helper loaded: url_helper
INFO - 2018-07-24 19:07:40 --> Helper loaded: form_helper
INFO - 2018-07-24 19:07:40 --> Helper loaded: language_helper
DEBUG - 2018-07-24 19:07:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 19:07:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 19:07:40 --> User Agent Class Initialized
INFO - 2018-07-24 19:07:40 --> Controller Class Initialized
INFO - 2018-07-24 19:07:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 19:07:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-24 19:07:40 --> Pixel_Model class loaded
INFO - 2018-07-24 19:07:40 --> Database Driver Class Initialized
INFO - 2018-07-24 19:07:40 --> Model "QuestionsModel" initialized
INFO - 2018-07-24 19:07:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-24 19:07:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-24 19:07:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-24 19:07:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-24 19:07:40 --> Final output sent to browser
DEBUG - 2018-07-24 19:07:40 --> Total execution time: 0.0476
INFO - 2018-07-24 19:07:40 --> Config Class Initialized
INFO - 2018-07-24 19:07:40 --> Hooks Class Initialized
DEBUG - 2018-07-24 19:07:40 --> UTF-8 Support Enabled
INFO - 2018-07-24 19:07:40 --> Utf8 Class Initialized
INFO - 2018-07-24 19:07:40 --> URI Class Initialized
INFO - 2018-07-24 19:07:40 --> Router Class Initialized
INFO - 2018-07-24 19:07:40 --> Output Class Initialized
INFO - 2018-07-24 19:07:40 --> Security Class Initialized
DEBUG - 2018-07-24 19:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 19:07:40 --> CSRF cookie sent
INFO - 2018-07-24 19:07:40 --> Input Class Initialized
INFO - 2018-07-24 19:07:40 --> Language Class Initialized
ERROR - 2018-07-24 19:07:40 --> 404 Page Not Found: 405shtml/index
INFO - 2018-07-24 19:07:47 --> Config Class Initialized
INFO - 2018-07-24 19:07:47 --> Hooks Class Initialized
DEBUG - 2018-07-24 19:07:47 --> UTF-8 Support Enabled
INFO - 2018-07-24 19:07:47 --> Utf8 Class Initialized
INFO - 2018-07-24 19:07:47 --> URI Class Initialized
DEBUG - 2018-07-24 19:07:47 --> No URI present. Default controller set.
INFO - 2018-07-24 19:07:47 --> Router Class Initialized
INFO - 2018-07-24 19:07:47 --> Output Class Initialized
INFO - 2018-07-24 19:07:47 --> Security Class Initialized
DEBUG - 2018-07-24 19:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 19:07:47 --> CSRF cookie sent
INFO - 2018-07-24 19:07:47 --> Input Class Initialized
INFO - 2018-07-24 19:07:47 --> Language Class Initialized
INFO - 2018-07-24 19:07:47 --> Loader Class Initialized
INFO - 2018-07-24 19:07:47 --> Helper loaded: url_helper
INFO - 2018-07-24 19:07:47 --> Helper loaded: form_helper
INFO - 2018-07-24 19:07:47 --> Helper loaded: language_helper
DEBUG - 2018-07-24 19:07:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 19:07:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 19:07:47 --> User Agent Class Initialized
INFO - 2018-07-24 19:07:47 --> Controller Class Initialized
INFO - 2018-07-24 19:07:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 19:07:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-24 19:07:47 --> Pixel_Model class loaded
INFO - 2018-07-24 19:07:47 --> Database Driver Class Initialized
INFO - 2018-07-24 19:07:47 --> Model "QuestionsModel" initialized
INFO - 2018-07-24 19:07:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-24 19:07:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-24 19:07:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-24 19:07:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-24 19:07:47 --> Final output sent to browser
DEBUG - 2018-07-24 19:07:47 --> Total execution time: 0.0639
INFO - 2018-07-24 19:07:47 --> Config Class Initialized
INFO - 2018-07-24 19:07:47 --> Hooks Class Initialized
DEBUG - 2018-07-24 19:07:47 --> UTF-8 Support Enabled
INFO - 2018-07-24 19:07:47 --> Utf8 Class Initialized
INFO - 2018-07-24 19:07:47 --> URI Class Initialized
INFO - 2018-07-24 19:07:47 --> Router Class Initialized
INFO - 2018-07-24 19:07:47 --> Output Class Initialized
INFO - 2018-07-24 19:07:47 --> Security Class Initialized
DEBUG - 2018-07-24 19:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 19:07:47 --> CSRF cookie sent
INFO - 2018-07-24 19:07:47 --> Input Class Initialized
INFO - 2018-07-24 19:07:47 --> Language Class Initialized
ERROR - 2018-07-24 19:07:47 --> 404 Page Not Found: 404testpage4525d2fdc/index
INFO - 2018-07-24 19:07:47 --> Config Class Initialized
INFO - 2018-07-24 19:07:47 --> Hooks Class Initialized
DEBUG - 2018-07-24 19:07:47 --> UTF-8 Support Enabled
INFO - 2018-07-24 19:07:47 --> Utf8 Class Initialized
INFO - 2018-07-24 19:07:47 --> URI Class Initialized
INFO - 2018-07-24 19:07:47 --> Router Class Initialized
INFO - 2018-07-24 19:07:47 --> Output Class Initialized
INFO - 2018-07-24 19:07:47 --> Security Class Initialized
DEBUG - 2018-07-24 19:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 19:07:47 --> CSRF cookie sent
INFO - 2018-07-24 19:07:47 --> Input Class Initialized
INFO - 2018-07-24 19:07:47 --> Language Class Initialized
ERROR - 2018-07-24 19:07:47 --> 404 Page Not Found: 404javascriptjs/index
INFO - 2018-07-24 19:07:48 --> Config Class Initialized
INFO - 2018-07-24 19:07:48 --> Hooks Class Initialized
DEBUG - 2018-07-24 19:07:48 --> UTF-8 Support Enabled
INFO - 2018-07-24 19:07:48 --> Utf8 Class Initialized
INFO - 2018-07-24 19:07:48 --> URI Class Initialized
INFO - 2018-07-24 19:07:48 --> Router Class Initialized
INFO - 2018-07-24 19:07:48 --> Output Class Initialized
INFO - 2018-07-24 19:07:48 --> Security Class Initialized
DEBUG - 2018-07-24 19:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 19:07:48 --> CSRF cookie sent
INFO - 2018-07-24 19:07:48 --> Input Class Initialized
INFO - 2018-07-24 19:07:48 --> Language Class Initialized
INFO - 2018-07-24 19:07:48 --> Loader Class Initialized
INFO - 2018-07-24 19:07:48 --> Helper loaded: url_helper
INFO - 2018-07-24 19:07:48 --> Helper loaded: form_helper
INFO - 2018-07-24 19:07:48 --> Helper loaded: language_helper
DEBUG - 2018-07-24 19:07:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 19:07:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 19:07:48 --> User Agent Class Initialized
INFO - 2018-07-24 19:07:48 --> Controller Class Initialized
INFO - 2018-07-24 19:07:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 19:07:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-24 19:07:48 --> Pixel_Model class loaded
INFO - 2018-07-24 19:07:48 --> Database Driver Class Initialized
INFO - 2018-07-24 19:07:48 --> Model "QuestionsModel" initialized
INFO - 2018-07-24 19:07:48 --> Config Class Initialized
INFO - 2018-07-24 19:07:48 --> Hooks Class Initialized
DEBUG - 2018-07-24 19:07:48 --> UTF-8 Support Enabled
INFO - 2018-07-24 19:07:48 --> Utf8 Class Initialized
INFO - 2018-07-24 19:07:48 --> URI Class Initialized
INFO - 2018-07-24 19:07:48 --> Router Class Initialized
INFO - 2018-07-24 19:07:48 --> Output Class Initialized
INFO - 2018-07-24 19:07:48 --> Security Class Initialized
DEBUG - 2018-07-24 19:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 19:07:48 --> CSRF cookie sent
INFO - 2018-07-24 19:07:48 --> Input Class Initialized
INFO - 2018-07-24 19:07:48 --> Language Class Initialized
INFO - 2018-07-24 19:07:48 --> Loader Class Initialized
INFO - 2018-07-24 19:07:48 --> Helper loaded: url_helper
INFO - 2018-07-24 19:07:48 --> Helper loaded: form_helper
INFO - 2018-07-24 19:07:48 --> Helper loaded: language_helper
DEBUG - 2018-07-24 19:07:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 19:07:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 19:07:48 --> User Agent Class Initialized
INFO - 2018-07-24 19:07:48 --> Controller Class Initialized
INFO - 2018-07-24 19:07:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 19:07:48 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-24 19:07:48 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-24 19:07:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-24 19:07:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-24 19:07:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-24 19:07:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-24 19:07:48 --> Could not find the language line "req_email"
INFO - 2018-07-24 19:07:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-24 19:07:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-24 19:07:48 --> Final output sent to browser
DEBUG - 2018-07-24 19:07:48 --> Total execution time: 0.0282
INFO - 2018-07-24 19:07:48 --> Config Class Initialized
INFO - 2018-07-24 19:07:48 --> Hooks Class Initialized
DEBUG - 2018-07-24 19:07:48 --> UTF-8 Support Enabled
INFO - 2018-07-24 19:07:48 --> Utf8 Class Initialized
INFO - 2018-07-24 19:07:48 --> URI Class Initialized
INFO - 2018-07-24 19:07:48 --> Router Class Initialized
INFO - 2018-07-24 19:07:48 --> Output Class Initialized
INFO - 2018-07-24 19:07:48 --> Security Class Initialized
DEBUG - 2018-07-24 19:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 19:07:48 --> CSRF cookie sent
INFO - 2018-07-24 19:07:48 --> Input Class Initialized
INFO - 2018-07-24 19:07:48 --> Language Class Initialized
INFO - 2018-07-24 19:07:48 --> Loader Class Initialized
INFO - 2018-07-24 19:07:48 --> Helper loaded: url_helper
INFO - 2018-07-24 19:07:48 --> Helper loaded: form_helper
INFO - 2018-07-24 19:07:48 --> Helper loaded: language_helper
DEBUG - 2018-07-24 19:07:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 19:07:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 19:07:48 --> User Agent Class Initialized
INFO - 2018-07-24 19:07:48 --> Controller Class Initialized
INFO - 2018-07-24 19:07:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 19:07:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-24 19:07:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-24 19:07:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-24 19:07:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-24 19:07:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-24 19:07:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-07-24 19:07:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-24 19:07:48 --> Final output sent to browser
DEBUG - 2018-07-24 19:07:48 --> Total execution time: 0.0217
INFO - 2018-07-24 19:07:49 --> Config Class Initialized
INFO - 2018-07-24 19:07:49 --> Hooks Class Initialized
DEBUG - 2018-07-24 19:07:49 --> UTF-8 Support Enabled
INFO - 2018-07-24 19:07:49 --> Utf8 Class Initialized
INFO - 2018-07-24 19:07:49 --> URI Class Initialized
INFO - 2018-07-24 19:07:49 --> Router Class Initialized
INFO - 2018-07-24 19:07:49 --> Output Class Initialized
INFO - 2018-07-24 19:07:49 --> Security Class Initialized
DEBUG - 2018-07-24 19:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 19:07:49 --> CSRF cookie sent
INFO - 2018-07-24 19:07:49 --> Input Class Initialized
INFO - 2018-07-24 19:07:49 --> Language Class Initialized
INFO - 2018-07-24 19:07:49 --> Loader Class Initialized
INFO - 2018-07-24 19:07:49 --> Helper loaded: url_helper
INFO - 2018-07-24 19:07:49 --> Helper loaded: form_helper
INFO - 2018-07-24 19:07:49 --> Helper loaded: language_helper
DEBUG - 2018-07-24 19:07:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 19:07:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 19:07:49 --> User Agent Class Initialized
INFO - 2018-07-24 19:07:49 --> Controller Class Initialized
INFO - 2018-07-24 19:07:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 19:07:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-24 19:07:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-24 19:07:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-24 19:07:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-24 19:07:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-24 19:07:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-07-24 19:07:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-24 19:07:49 --> Final output sent to browser
DEBUG - 2018-07-24 19:07:49 --> Total execution time: 0.0209
INFO - 2018-07-24 19:07:49 --> Config Class Initialized
INFO - 2018-07-24 19:07:49 --> Hooks Class Initialized
DEBUG - 2018-07-24 19:07:49 --> UTF-8 Support Enabled
INFO - 2018-07-24 19:07:49 --> Utf8 Class Initialized
INFO - 2018-07-24 19:07:49 --> URI Class Initialized
INFO - 2018-07-24 19:07:49 --> Router Class Initialized
INFO - 2018-07-24 19:07:49 --> Output Class Initialized
INFO - 2018-07-24 19:07:49 --> Security Class Initialized
DEBUG - 2018-07-24 19:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 19:07:49 --> CSRF cookie sent
INFO - 2018-07-24 19:07:49 --> Input Class Initialized
INFO - 2018-07-24 19:07:49 --> Language Class Initialized
INFO - 2018-07-24 19:07:49 --> Loader Class Initialized
INFO - 2018-07-24 19:07:49 --> Helper loaded: url_helper
INFO - 2018-07-24 19:07:49 --> Helper loaded: form_helper
INFO - 2018-07-24 19:07:49 --> Helper loaded: language_helper
DEBUG - 2018-07-24 19:07:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 19:07:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 19:07:49 --> User Agent Class Initialized
INFO - 2018-07-24 19:07:49 --> Controller Class Initialized
INFO - 2018-07-24 19:07:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 19:07:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-24 19:07:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-24 19:07:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-24 19:07:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-24 19:07:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-24 19:07:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-07-24 19:07:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-24 19:07:49 --> Final output sent to browser
DEBUG - 2018-07-24 19:07:49 --> Total execution time: 0.0228
INFO - 2018-07-24 19:07:49 --> Config Class Initialized
INFO - 2018-07-24 19:07:49 --> Hooks Class Initialized
DEBUG - 2018-07-24 19:07:49 --> UTF-8 Support Enabled
INFO - 2018-07-24 19:07:49 --> Utf8 Class Initialized
INFO - 2018-07-24 19:07:49 --> URI Class Initialized
INFO - 2018-07-24 19:07:49 --> Router Class Initialized
INFO - 2018-07-24 19:07:49 --> Output Class Initialized
INFO - 2018-07-24 19:07:49 --> Security Class Initialized
DEBUG - 2018-07-24 19:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 19:07:49 --> CSRF cookie sent
INFO - 2018-07-24 19:07:49 --> Input Class Initialized
INFO - 2018-07-24 19:07:49 --> Language Class Initialized
INFO - 2018-07-24 19:07:49 --> Loader Class Initialized
INFO - 2018-07-24 19:07:49 --> Helper loaded: url_helper
INFO - 2018-07-24 19:07:49 --> Helper loaded: form_helper
INFO - 2018-07-24 19:07:49 --> Helper loaded: language_helper
DEBUG - 2018-07-24 19:07:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 19:07:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 19:07:49 --> User Agent Class Initialized
INFO - 2018-07-24 19:07:49 --> Controller Class Initialized
INFO - 2018-07-24 19:07:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 19:07:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-24 19:07:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-24 19:07:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-24 19:07:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-24 19:07:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-24 19:07:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-07-24 19:07:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-24 19:07:49 --> Final output sent to browser
DEBUG - 2018-07-24 19:07:49 --> Total execution time: 0.0242
INFO - 2018-07-24 19:07:50 --> Config Class Initialized
INFO - 2018-07-24 19:07:50 --> Hooks Class Initialized
DEBUG - 2018-07-24 19:07:50 --> UTF-8 Support Enabled
INFO - 2018-07-24 19:07:50 --> Utf8 Class Initialized
INFO - 2018-07-24 19:07:50 --> URI Class Initialized
INFO - 2018-07-24 19:07:50 --> Router Class Initialized
INFO - 2018-07-24 19:07:50 --> Output Class Initialized
INFO - 2018-07-24 19:07:50 --> Security Class Initialized
DEBUG - 2018-07-24 19:07:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 19:07:50 --> CSRF cookie sent
INFO - 2018-07-24 19:07:50 --> Input Class Initialized
INFO - 2018-07-24 19:07:50 --> Language Class Initialized
INFO - 2018-07-24 19:07:50 --> Loader Class Initialized
INFO - 2018-07-24 19:07:50 --> Helper loaded: url_helper
INFO - 2018-07-24 19:07:50 --> Helper loaded: form_helper
INFO - 2018-07-24 19:07:50 --> Helper loaded: language_helper
DEBUG - 2018-07-24 19:07:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 19:07:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 19:07:50 --> User Agent Class Initialized
INFO - 2018-07-24 19:07:50 --> Controller Class Initialized
INFO - 2018-07-24 19:07:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 19:07:50 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-24 19:07:50 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-24 19:07:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-24 19:07:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-24 19:07:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-24 19:07:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-24 19:07:50 --> Could not find the language line "req_email"
INFO - 2018-07-24 19:07:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-24 19:07:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-24 19:07:50 --> Final output sent to browser
DEBUG - 2018-07-24 19:07:50 --> Total execution time: 0.0245
INFO - 2018-07-24 19:07:50 --> Config Class Initialized
INFO - 2018-07-24 19:07:50 --> Hooks Class Initialized
DEBUG - 2018-07-24 19:07:50 --> UTF-8 Support Enabled
INFO - 2018-07-24 19:07:50 --> Utf8 Class Initialized
INFO - 2018-07-24 19:07:50 --> URI Class Initialized
INFO - 2018-07-24 19:07:50 --> Router Class Initialized
INFO - 2018-07-24 19:07:50 --> Output Class Initialized
INFO - 2018-07-24 19:07:50 --> Security Class Initialized
DEBUG - 2018-07-24 19:07:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 19:07:50 --> CSRF cookie sent
INFO - 2018-07-24 19:07:50 --> Input Class Initialized
INFO - 2018-07-24 19:07:50 --> Language Class Initialized
INFO - 2018-07-24 19:07:50 --> Loader Class Initialized
INFO - 2018-07-24 19:07:50 --> Helper loaded: url_helper
INFO - 2018-07-24 19:07:50 --> Helper loaded: form_helper
INFO - 2018-07-24 19:07:50 --> Helper loaded: language_helper
DEBUG - 2018-07-24 19:07:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 19:07:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 19:07:50 --> User Agent Class Initialized
INFO - 2018-07-24 19:07:50 --> Controller Class Initialized
INFO - 2018-07-24 19:07:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 19:07:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-24 19:07:50 --> Pixel_Model class loaded
INFO - 2018-07-24 19:07:50 --> Database Driver Class Initialized
INFO - 2018-07-24 19:07:50 --> Model "QuestionsModel" initialized
INFO - 2018-07-24 19:07:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-24 19:07:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-24 19:07:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-24 19:07:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-24 19:07:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/buy_gift.php
INFO - 2018-07-24 19:07:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-24 19:07:50 --> Final output sent to browser
DEBUG - 2018-07-24 19:07:50 --> Total execution time: 0.0348
INFO - 2018-07-24 19:26:34 --> Config Class Initialized
INFO - 2018-07-24 19:26:34 --> Hooks Class Initialized
DEBUG - 2018-07-24 19:26:34 --> UTF-8 Support Enabled
INFO - 2018-07-24 19:26:34 --> Utf8 Class Initialized
INFO - 2018-07-24 19:26:34 --> URI Class Initialized
DEBUG - 2018-07-24 19:26:34 --> No URI present. Default controller set.
INFO - 2018-07-24 19:26:34 --> Router Class Initialized
INFO - 2018-07-24 19:26:34 --> Output Class Initialized
INFO - 2018-07-24 19:26:34 --> Security Class Initialized
DEBUG - 2018-07-24 19:26:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 19:26:34 --> CSRF cookie sent
INFO - 2018-07-24 19:26:34 --> Input Class Initialized
INFO - 2018-07-24 19:26:34 --> Language Class Initialized
INFO - 2018-07-24 19:26:34 --> Loader Class Initialized
INFO - 2018-07-24 19:26:34 --> Helper loaded: url_helper
INFO - 2018-07-24 19:26:34 --> Helper loaded: form_helper
INFO - 2018-07-24 19:26:34 --> Helper loaded: language_helper
DEBUG - 2018-07-24 19:26:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 19:26:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 19:26:34 --> User Agent Class Initialized
INFO - 2018-07-24 19:26:34 --> Controller Class Initialized
INFO - 2018-07-24 19:26:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-24 19:26:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-24 19:26:34 --> Pixel_Model class loaded
INFO - 2018-07-24 19:26:34 --> Database Driver Class Initialized
INFO - 2018-07-24 19:26:34 --> Model "QuestionsModel" initialized
INFO - 2018-07-24 19:26:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-24 19:26:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-24 19:26:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-24 19:26:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-24 19:26:34 --> Final output sent to browser
DEBUG - 2018-07-24 19:26:34 --> Total execution time: 0.0344
INFO - 2018-07-24 20:19:23 --> Config Class Initialized
INFO - 2018-07-24 20:19:23 --> Hooks Class Initialized
DEBUG - 2018-07-24 20:19:23 --> UTF-8 Support Enabled
INFO - 2018-07-24 20:19:23 --> Utf8 Class Initialized
INFO - 2018-07-24 20:19:23 --> URI Class Initialized
INFO - 2018-07-24 20:19:23 --> Router Class Initialized
INFO - 2018-07-24 20:19:23 --> Output Class Initialized
INFO - 2018-07-24 20:19:23 --> Security Class Initialized
DEBUG - 2018-07-24 20:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 20:19:23 --> CSRF cookie sent
INFO - 2018-07-24 20:19:23 --> Input Class Initialized
INFO - 2018-07-24 20:19:23 --> Language Class Initialized
ERROR - 2018-07-24 20:19:23 --> 404 Page Not Found: Assets/js

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-07-26 00:36:01 --> Config Class Initialized
INFO - 2018-07-26 00:36:01 --> Hooks Class Initialized
DEBUG - 2018-07-26 00:36:01 --> UTF-8 Support Enabled
INFO - 2018-07-26 00:36:01 --> Utf8 Class Initialized
INFO - 2018-07-26 00:36:01 --> URI Class Initialized
INFO - 2018-07-26 00:36:01 --> Router Class Initialized
INFO - 2018-07-26 00:36:01 --> Output Class Initialized
INFO - 2018-07-26 00:36:01 --> Security Class Initialized
DEBUG - 2018-07-26 00:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 00:36:01 --> CSRF cookie sent
INFO - 2018-07-26 00:36:01 --> Input Class Initialized
INFO - 2018-07-26 00:36:01 --> Language Class Initialized
ERROR - 2018-07-26 00:36:01 --> 404 Page Not Found: Assets/js
INFO - 2018-07-26 01:51:48 --> Config Class Initialized
INFO - 2018-07-26 01:51:48 --> Hooks Class Initialized
DEBUG - 2018-07-26 01:51:48 --> UTF-8 Support Enabled
INFO - 2018-07-26 01:51:48 --> Utf8 Class Initialized
INFO - 2018-07-26 01:51:48 --> URI Class Initialized
INFO - 2018-07-26 01:51:48 --> Router Class Initialized
INFO - 2018-07-26 01:51:48 --> Output Class Initialized
INFO - 2018-07-26 01:51:48 --> Security Class Initialized
DEBUG - 2018-07-26 01:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 01:51:48 --> CSRF cookie sent
INFO - 2018-07-26 01:51:48 --> Input Class Initialized
INFO - 2018-07-26 01:51:48 --> Language Class Initialized
INFO - 2018-07-26 01:51:48 --> Loader Class Initialized
INFO - 2018-07-26 01:51:48 --> Helper loaded: url_helper
INFO - 2018-07-26 01:51:48 --> Helper loaded: form_helper
INFO - 2018-07-26 01:51:48 --> Helper loaded: language_helper
DEBUG - 2018-07-26 01:51:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 01:51:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 01:51:48 --> User Agent Class Initialized
INFO - 2018-07-26 01:51:48 --> Controller Class Initialized
INFO - 2018-07-26 01:51:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-26 01:51:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-26 01:51:48 --> Pixel_Model class loaded
INFO - 2018-07-26 01:51:48 --> Database Driver Class Initialized
INFO - 2018-07-26 01:51:48 --> Model "RegistrationModel" initialized
DEBUG - 2018-07-26 01:51:48 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-26 01:51:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-26 01:51:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-26 01:51:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-26 01:51:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-26 01:51:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/temp.php
INFO - 2018-07-26 01:51:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-26 01:51:48 --> Final output sent to browser
DEBUG - 2018-07-26 01:51:48 --> Total execution time: 0.0400
INFO - 2018-07-26 01:52:01 --> Config Class Initialized
INFO - 2018-07-26 01:52:01 --> Hooks Class Initialized
DEBUG - 2018-07-26 01:52:01 --> UTF-8 Support Enabled
INFO - 2018-07-26 01:52:01 --> Utf8 Class Initialized
INFO - 2018-07-26 01:52:01 --> URI Class Initialized
DEBUG - 2018-07-26 01:52:01 --> No URI present. Default controller set.
INFO - 2018-07-26 01:52:01 --> Router Class Initialized
INFO - 2018-07-26 01:52:01 --> Output Class Initialized
INFO - 2018-07-26 01:52:01 --> Security Class Initialized
DEBUG - 2018-07-26 01:52:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 01:52:01 --> CSRF cookie sent
INFO - 2018-07-26 01:52:01 --> Input Class Initialized
INFO - 2018-07-26 01:52:01 --> Language Class Initialized
INFO - 2018-07-26 01:52:01 --> Loader Class Initialized
INFO - 2018-07-26 01:52:01 --> Helper loaded: url_helper
INFO - 2018-07-26 01:52:01 --> Helper loaded: form_helper
INFO - 2018-07-26 01:52:01 --> Helper loaded: language_helper
DEBUG - 2018-07-26 01:52:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 01:52:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 01:52:01 --> User Agent Class Initialized
INFO - 2018-07-26 01:52:01 --> Controller Class Initialized
INFO - 2018-07-26 01:52:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-26 01:52:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-26 01:52:01 --> Pixel_Model class loaded
INFO - 2018-07-26 01:52:01 --> Database Driver Class Initialized
INFO - 2018-07-26 01:52:01 --> Model "QuestionsModel" initialized
INFO - 2018-07-26 01:52:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-26 01:52:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-26 01:52:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-26 01:52:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-26 01:52:01 --> Final output sent to browser
DEBUG - 2018-07-26 01:52:01 --> Total execution time: 0.0405
INFO - 2018-07-26 02:35:02 --> Config Class Initialized
INFO - 2018-07-26 02:35:02 --> Hooks Class Initialized
DEBUG - 2018-07-26 02:35:02 --> UTF-8 Support Enabled
INFO - 2018-07-26 02:35:02 --> Utf8 Class Initialized
INFO - 2018-07-26 02:35:02 --> URI Class Initialized
INFO - 2018-07-26 02:35:02 --> Router Class Initialized
INFO - 2018-07-26 02:35:02 --> Output Class Initialized
INFO - 2018-07-26 02:35:02 --> Security Class Initialized
DEBUG - 2018-07-26 02:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 02:35:02 --> CSRF cookie sent
INFO - 2018-07-26 02:35:02 --> Input Class Initialized
INFO - 2018-07-26 02:35:02 --> Language Class Initialized
ERROR - 2018-07-26 02:35:02 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-26 02:35:05 --> Config Class Initialized
INFO - 2018-07-26 02:35:05 --> Hooks Class Initialized
DEBUG - 2018-07-26 02:35:05 --> UTF-8 Support Enabled
INFO - 2018-07-26 02:35:05 --> Utf8 Class Initialized
INFO - 2018-07-26 02:35:05 --> URI Class Initialized
DEBUG - 2018-07-26 02:35:05 --> No URI present. Default controller set.
INFO - 2018-07-26 02:35:05 --> Router Class Initialized
INFO - 2018-07-26 02:35:05 --> Output Class Initialized
INFO - 2018-07-26 02:35:05 --> Security Class Initialized
DEBUG - 2018-07-26 02:35:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 02:35:05 --> CSRF cookie sent
INFO - 2018-07-26 02:35:05 --> Input Class Initialized
INFO - 2018-07-26 02:35:05 --> Language Class Initialized
INFO - 2018-07-26 02:35:05 --> Loader Class Initialized
INFO - 2018-07-26 02:35:05 --> Helper loaded: url_helper
INFO - 2018-07-26 02:35:05 --> Helper loaded: form_helper
INFO - 2018-07-26 02:35:05 --> Helper loaded: language_helper
DEBUG - 2018-07-26 02:35:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 02:35:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 02:35:05 --> User Agent Class Initialized
INFO - 2018-07-26 02:35:05 --> Controller Class Initialized
INFO - 2018-07-26 02:35:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-26 02:35:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-26 02:35:05 --> Pixel_Model class loaded
INFO - 2018-07-26 02:35:05 --> Database Driver Class Initialized
INFO - 2018-07-26 02:35:05 --> Model "QuestionsModel" initialized
INFO - 2018-07-26 02:35:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-26 02:35:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-26 02:35:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-26 02:35:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-26 02:35:05 --> Final output sent to browser
DEBUG - 2018-07-26 02:35:05 --> Total execution time: 0.0351
INFO - 2018-07-26 03:07:34 --> Config Class Initialized
INFO - 2018-07-26 03:07:34 --> Hooks Class Initialized
DEBUG - 2018-07-26 03:07:34 --> UTF-8 Support Enabled
INFO - 2018-07-26 03:07:34 --> Utf8 Class Initialized
INFO - 2018-07-26 03:07:34 --> URI Class Initialized
INFO - 2018-07-26 03:07:34 --> Router Class Initialized
INFO - 2018-07-26 03:07:34 --> Output Class Initialized
INFO - 2018-07-26 03:07:34 --> Security Class Initialized
DEBUG - 2018-07-26 03:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 03:07:34 --> CSRF cookie sent
INFO - 2018-07-26 03:07:34 --> Input Class Initialized
INFO - 2018-07-26 03:07:34 --> Language Class Initialized
INFO - 2018-07-26 03:07:34 --> Loader Class Initialized
INFO - 2018-07-26 03:07:34 --> Helper loaded: url_helper
INFO - 2018-07-26 03:07:34 --> Helper loaded: form_helper
INFO - 2018-07-26 03:07:34 --> Helper loaded: language_helper
DEBUG - 2018-07-26 03:07:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 03:07:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 03:07:34 --> User Agent Class Initialized
INFO - 2018-07-26 03:07:34 --> Controller Class Initialized
INFO - 2018-07-26 03:07:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-26 03:07:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-26 03:07:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-26 03:07:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-26 03:07:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-26 03:07:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-26 03:07:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/911.php
INFO - 2018-07-26 03:07:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-26 03:07:34 --> Final output sent to browser
DEBUG - 2018-07-26 03:07:34 --> Total execution time: 0.0427
INFO - 2018-07-26 04:23:22 --> Config Class Initialized
INFO - 2018-07-26 04:23:22 --> Hooks Class Initialized
DEBUG - 2018-07-26 04:23:22 --> UTF-8 Support Enabled
INFO - 2018-07-26 04:23:22 --> Utf8 Class Initialized
INFO - 2018-07-26 04:23:22 --> URI Class Initialized
INFO - 2018-07-26 04:23:22 --> Router Class Initialized
INFO - 2018-07-26 04:23:22 --> Output Class Initialized
INFO - 2018-07-26 04:23:22 --> Security Class Initialized
DEBUG - 2018-07-26 04:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 04:23:22 --> CSRF cookie sent
INFO - 2018-07-26 04:23:22 --> Input Class Initialized
INFO - 2018-07-26 04:23:22 --> Language Class Initialized
INFO - 2018-07-26 04:23:22 --> Loader Class Initialized
INFO - 2018-07-26 04:23:22 --> Helper loaded: url_helper
INFO - 2018-07-26 04:23:22 --> Helper loaded: form_helper
INFO - 2018-07-26 04:23:22 --> Helper loaded: language_helper
DEBUG - 2018-07-26 04:23:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 04:23:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 04:23:22 --> User Agent Class Initialized
INFO - 2018-07-26 04:23:22 --> Controller Class Initialized
INFO - 2018-07-26 04:23:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-26 04:23:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-26 04:23:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-26 04:23:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-26 04:23:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-26 04:23:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-26 04:23:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/finance.php
INFO - 2018-07-26 04:23:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-26 04:23:22 --> Final output sent to browser
DEBUG - 2018-07-26 04:23:22 --> Total execution time: 0.0243
INFO - 2018-07-26 05:39:09 --> Config Class Initialized
INFO - 2018-07-26 05:39:09 --> Hooks Class Initialized
DEBUG - 2018-07-26 05:39:09 --> UTF-8 Support Enabled
INFO - 2018-07-26 05:39:09 --> Utf8 Class Initialized
INFO - 2018-07-26 05:39:09 --> URI Class Initialized
INFO - 2018-07-26 05:39:09 --> Router Class Initialized
INFO - 2018-07-26 05:39:09 --> Output Class Initialized
INFO - 2018-07-26 05:39:09 --> Security Class Initialized
DEBUG - 2018-07-26 05:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 05:39:09 --> CSRF cookie sent
INFO - 2018-07-26 05:39:09 --> Input Class Initialized
INFO - 2018-07-26 05:39:09 --> Language Class Initialized
INFO - 2018-07-26 05:39:09 --> Loader Class Initialized
INFO - 2018-07-26 05:39:09 --> Helper loaded: url_helper
INFO - 2018-07-26 05:39:09 --> Helper loaded: form_helper
INFO - 2018-07-26 05:39:09 --> Helper loaded: language_helper
DEBUG - 2018-07-26 05:39:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 05:39:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 05:39:09 --> User Agent Class Initialized
INFO - 2018-07-26 05:39:09 --> Controller Class Initialized
INFO - 2018-07-26 05:39:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-26 05:39:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-26 05:39:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-26 05:39:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-26 05:39:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-26 05:39:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-26 05:39:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/teacher.php
INFO - 2018-07-26 05:39:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-26 05:39:09 --> Final output sent to browser
DEBUG - 2018-07-26 05:39:09 --> Total execution time: 0.0235
INFO - 2018-07-26 06:55:05 --> Config Class Initialized
INFO - 2018-07-26 06:55:05 --> Hooks Class Initialized
DEBUG - 2018-07-26 06:55:05 --> UTF-8 Support Enabled
INFO - 2018-07-26 06:55:05 --> Utf8 Class Initialized
INFO - 2018-07-26 06:55:05 --> URI Class Initialized
INFO - 2018-07-26 06:55:05 --> Router Class Initialized
INFO - 2018-07-26 06:55:05 --> Output Class Initialized
INFO - 2018-07-26 06:55:05 --> Security Class Initialized
DEBUG - 2018-07-26 06:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 06:55:05 --> CSRF cookie sent
INFO - 2018-07-26 06:55:05 --> Input Class Initialized
INFO - 2018-07-26 06:55:05 --> Language Class Initialized
INFO - 2018-07-26 06:55:05 --> Loader Class Initialized
INFO - 2018-07-26 06:55:05 --> Helper loaded: url_helper
INFO - 2018-07-26 06:55:05 --> Helper loaded: form_helper
INFO - 2018-07-26 06:55:05 --> Helper loaded: language_helper
DEBUG - 2018-07-26 06:55:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 06:55:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 06:55:05 --> User Agent Class Initialized
INFO - 2018-07-26 06:55:05 --> Controller Class Initialized
INFO - 2018-07-26 06:55:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-26 06:55:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-26 06:55:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-26 06:55:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-26 06:55:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-26 06:55:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-26 06:55:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/medical.php
INFO - 2018-07-26 06:55:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-26 06:55:05 --> Final output sent to browser
DEBUG - 2018-07-26 06:55:05 --> Total execution time: 0.0207
INFO - 2018-07-26 08:10:43 --> Config Class Initialized
INFO - 2018-07-26 08:10:43 --> Hooks Class Initialized
DEBUG - 2018-07-26 08:10:43 --> UTF-8 Support Enabled
INFO - 2018-07-26 08:10:43 --> Utf8 Class Initialized
INFO - 2018-07-26 08:10:43 --> URI Class Initialized
INFO - 2018-07-26 08:10:43 --> Router Class Initialized
INFO - 2018-07-26 08:10:43 --> Output Class Initialized
INFO - 2018-07-26 08:10:43 --> Security Class Initialized
DEBUG - 2018-07-26 08:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 08:10:43 --> CSRF cookie sent
INFO - 2018-07-26 08:10:43 --> Input Class Initialized
INFO - 2018-07-26 08:10:43 --> Language Class Initialized
INFO - 2018-07-26 08:10:43 --> Loader Class Initialized
INFO - 2018-07-26 08:10:43 --> Helper loaded: url_helper
INFO - 2018-07-26 08:10:43 --> Helper loaded: form_helper
INFO - 2018-07-26 08:10:43 --> Helper loaded: language_helper
DEBUG - 2018-07-26 08:10:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 08:10:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 08:10:43 --> User Agent Class Initialized
INFO - 2018-07-26 08:10:43 --> Controller Class Initialized
INFO - 2018-07-26 08:10:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-26 08:10:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-26 08:10:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-26 08:10:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-26 08:10:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-26 08:10:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-26 08:10:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/executive.php
INFO - 2018-07-26 08:10:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-26 08:10:43 --> Final output sent to browser
DEBUG - 2018-07-26 08:10:43 --> Total execution time: 0.0241
INFO - 2018-07-26 09:11:40 --> Config Class Initialized
INFO - 2018-07-26 09:11:40 --> Hooks Class Initialized
DEBUG - 2018-07-26 09:11:40 --> UTF-8 Support Enabled
INFO - 2018-07-26 09:11:40 --> Utf8 Class Initialized
INFO - 2018-07-26 09:11:40 --> URI Class Initialized
DEBUG - 2018-07-26 09:11:40 --> No URI present. Default controller set.
INFO - 2018-07-26 09:11:40 --> Router Class Initialized
INFO - 2018-07-26 09:11:40 --> Output Class Initialized
INFO - 2018-07-26 09:11:40 --> Security Class Initialized
DEBUG - 2018-07-26 09:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 09:11:40 --> CSRF cookie sent
INFO - 2018-07-26 09:11:40 --> Input Class Initialized
INFO - 2018-07-26 09:11:40 --> Language Class Initialized
INFO - 2018-07-26 09:11:40 --> Loader Class Initialized
INFO - 2018-07-26 09:11:40 --> Helper loaded: url_helper
INFO - 2018-07-26 09:11:40 --> Helper loaded: form_helper
INFO - 2018-07-26 09:11:40 --> Helper loaded: language_helper
DEBUG - 2018-07-26 09:11:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 09:11:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 09:11:40 --> User Agent Class Initialized
INFO - 2018-07-26 09:11:40 --> Controller Class Initialized
INFO - 2018-07-26 09:11:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-26 09:11:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-26 09:11:40 --> Pixel_Model class loaded
INFO - 2018-07-26 09:11:40 --> Database Driver Class Initialized
INFO - 2018-07-26 09:11:40 --> Model "QuestionsModel" initialized
INFO - 2018-07-26 09:11:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-26 09:11:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-26 09:11:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-26 09:11:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-26 09:11:40 --> Final output sent to browser
DEBUG - 2018-07-26 09:11:40 --> Total execution time: 0.0367
INFO - 2018-07-26 09:26:29 --> Config Class Initialized
INFO - 2018-07-26 09:26:29 --> Hooks Class Initialized
DEBUG - 2018-07-26 09:26:29 --> UTF-8 Support Enabled
INFO - 2018-07-26 09:26:29 --> Utf8 Class Initialized
INFO - 2018-07-26 09:26:29 --> URI Class Initialized
INFO - 2018-07-26 09:26:29 --> Router Class Initialized
INFO - 2018-07-26 09:26:29 --> Output Class Initialized
INFO - 2018-07-26 09:26:29 --> Security Class Initialized
DEBUG - 2018-07-26 09:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 09:26:29 --> CSRF cookie sent
INFO - 2018-07-26 09:26:29 --> Input Class Initialized
INFO - 2018-07-26 09:26:29 --> Language Class Initialized
ERROR - 2018-07-26 09:26:29 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-26 09:26:29 --> Config Class Initialized
INFO - 2018-07-26 09:26:29 --> Hooks Class Initialized
DEBUG - 2018-07-26 09:26:29 --> UTF-8 Support Enabled
INFO - 2018-07-26 09:26:29 --> Utf8 Class Initialized
INFO - 2018-07-26 09:26:29 --> URI Class Initialized
INFO - 2018-07-26 09:26:29 --> Router Class Initialized
INFO - 2018-07-26 09:26:29 --> Output Class Initialized
INFO - 2018-07-26 09:26:29 --> Security Class Initialized
DEBUG - 2018-07-26 09:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 09:26:29 --> CSRF cookie sent
INFO - 2018-07-26 09:26:29 --> Input Class Initialized
INFO - 2018-07-26 09:26:29 --> Language Class Initialized
INFO - 2018-07-26 09:26:29 --> Loader Class Initialized
INFO - 2018-07-26 09:26:29 --> Helper loaded: url_helper
INFO - 2018-07-26 09:26:29 --> Helper loaded: form_helper
INFO - 2018-07-26 09:26:29 --> Helper loaded: language_helper
DEBUG - 2018-07-26 09:26:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 09:26:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 09:26:29 --> User Agent Class Initialized
INFO - 2018-07-26 09:26:29 --> Controller Class Initialized
INFO - 2018-07-26 09:26:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-26 09:26:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-26 09:26:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-26 09:26:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-26 09:26:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-26 09:26:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-26 09:26:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/consultant.php
INFO - 2018-07-26 09:26:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-26 09:26:29 --> Final output sent to browser
DEBUG - 2018-07-26 09:26:29 --> Total execution time: 0.0368
INFO - 2018-07-26 09:58:28 --> Config Class Initialized
INFO - 2018-07-26 09:58:28 --> Hooks Class Initialized
DEBUG - 2018-07-26 09:58:28 --> UTF-8 Support Enabled
INFO - 2018-07-26 09:58:28 --> Utf8 Class Initialized
INFO - 2018-07-26 09:58:28 --> URI Class Initialized
DEBUG - 2018-07-26 09:58:28 --> No URI present. Default controller set.
INFO - 2018-07-26 09:58:28 --> Router Class Initialized
INFO - 2018-07-26 09:58:28 --> Output Class Initialized
INFO - 2018-07-26 09:58:28 --> Security Class Initialized
DEBUG - 2018-07-26 09:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 09:58:28 --> CSRF cookie sent
INFO - 2018-07-26 09:58:28 --> Input Class Initialized
INFO - 2018-07-26 09:58:28 --> Language Class Initialized
INFO - 2018-07-26 09:58:28 --> Loader Class Initialized
INFO - 2018-07-26 09:58:28 --> Helper loaded: url_helper
INFO - 2018-07-26 09:58:28 --> Helper loaded: form_helper
INFO - 2018-07-26 09:58:28 --> Helper loaded: language_helper
DEBUG - 2018-07-26 09:58:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 09:58:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 09:58:28 --> User Agent Class Initialized
INFO - 2018-07-26 09:58:28 --> Controller Class Initialized
INFO - 2018-07-26 09:58:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-26 09:58:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-26 09:58:28 --> Pixel_Model class loaded
INFO - 2018-07-26 09:58:28 --> Database Driver Class Initialized
INFO - 2018-07-26 09:58:28 --> Model "QuestionsModel" initialized
INFO - 2018-07-26 09:58:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-26 09:58:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-26 09:58:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-26 09:58:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-26 09:58:28 --> Final output sent to browser
DEBUG - 2018-07-26 09:58:28 --> Total execution time: 0.0386
INFO - 2018-07-26 10:08:30 --> Config Class Initialized
INFO - 2018-07-26 10:08:30 --> Hooks Class Initialized
DEBUG - 2018-07-26 10:08:30 --> UTF-8 Support Enabled
INFO - 2018-07-26 10:08:30 --> Utf8 Class Initialized
INFO - 2018-07-26 10:08:30 --> URI Class Initialized
DEBUG - 2018-07-26 10:08:30 --> No URI present. Default controller set.
INFO - 2018-07-26 10:08:30 --> Router Class Initialized
INFO - 2018-07-26 10:08:30 --> Output Class Initialized
INFO - 2018-07-26 10:08:30 --> Security Class Initialized
DEBUG - 2018-07-26 10:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 10:08:30 --> CSRF cookie sent
INFO - 2018-07-26 10:08:30 --> Input Class Initialized
INFO - 2018-07-26 10:08:30 --> Language Class Initialized
INFO - 2018-07-26 10:08:30 --> Loader Class Initialized
INFO - 2018-07-26 10:08:30 --> Helper loaded: url_helper
INFO - 2018-07-26 10:08:30 --> Helper loaded: form_helper
INFO - 2018-07-26 10:08:30 --> Helper loaded: language_helper
DEBUG - 2018-07-26 10:08:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 10:08:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 10:08:30 --> User Agent Class Initialized
INFO - 2018-07-26 10:08:30 --> Controller Class Initialized
INFO - 2018-07-26 10:08:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-26 10:08:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-26 10:08:30 --> Pixel_Model class loaded
INFO - 2018-07-26 10:08:30 --> Database Driver Class Initialized
INFO - 2018-07-26 10:08:30 --> Model "QuestionsModel" initialized
INFO - 2018-07-26 10:08:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-26 10:08:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-26 10:08:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-26 10:08:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-26 10:08:30 --> Final output sent to browser
DEBUG - 2018-07-26 10:08:30 --> Total execution time: 0.0451
INFO - 2018-07-26 10:11:04 --> Config Class Initialized
INFO - 2018-07-26 10:11:04 --> Hooks Class Initialized
DEBUG - 2018-07-26 10:11:04 --> UTF-8 Support Enabled
INFO - 2018-07-26 10:11:04 --> Utf8 Class Initialized
INFO - 2018-07-26 10:11:04 --> URI Class Initialized
INFO - 2018-07-26 10:11:04 --> Router Class Initialized
INFO - 2018-07-26 10:11:04 --> Output Class Initialized
INFO - 2018-07-26 10:11:04 --> Security Class Initialized
DEBUG - 2018-07-26 10:11:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 10:11:04 --> CSRF cookie sent
INFO - 2018-07-26 10:11:04 --> Input Class Initialized
INFO - 2018-07-26 10:11:04 --> Language Class Initialized
INFO - 2018-07-26 10:11:04 --> Loader Class Initialized
INFO - 2018-07-26 10:11:04 --> Helper loaded: url_helper
INFO - 2018-07-26 10:11:04 --> Helper loaded: form_helper
INFO - 2018-07-26 10:11:04 --> Helper loaded: language_helper
DEBUG - 2018-07-26 10:11:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 10:11:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 10:11:04 --> User Agent Class Initialized
INFO - 2018-07-26 10:11:04 --> Controller Class Initialized
INFO - 2018-07-26 10:11:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-26 10:11:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-26 10:11:04 --> Pixel_Model class loaded
INFO - 2018-07-26 10:11:04 --> Database Driver Class Initialized
INFO - 2018-07-26 10:11:04 --> Model "QuestionsModel" initialized
INFO - 2018-07-26 10:11:04 --> Config Class Initialized
INFO - 2018-07-26 10:11:04 --> Hooks Class Initialized
DEBUG - 2018-07-26 10:11:04 --> UTF-8 Support Enabled
INFO - 2018-07-26 10:11:04 --> Utf8 Class Initialized
INFO - 2018-07-26 10:11:04 --> URI Class Initialized
INFO - 2018-07-26 10:11:04 --> Router Class Initialized
INFO - 2018-07-26 10:11:04 --> Output Class Initialized
INFO - 2018-07-26 10:11:04 --> Security Class Initialized
DEBUG - 2018-07-26 10:11:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 10:11:04 --> CSRF cookie sent
INFO - 2018-07-26 10:11:04 --> Input Class Initialized
INFO - 2018-07-26 10:11:04 --> Language Class Initialized
INFO - 2018-07-26 10:11:04 --> Loader Class Initialized
INFO - 2018-07-26 10:11:04 --> Helper loaded: url_helper
INFO - 2018-07-26 10:11:04 --> Helper loaded: form_helper
INFO - 2018-07-26 10:11:04 --> Helper loaded: language_helper
DEBUG - 2018-07-26 10:11:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 10:11:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 10:11:04 --> User Agent Class Initialized
INFO - 2018-07-26 10:11:04 --> Controller Class Initialized
INFO - 2018-07-26 10:11:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-26 10:11:04 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-26 10:11:04 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-26 10:11:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-26 10:11:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-26 10:11:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-26 10:11:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-26 10:11:04 --> Could not find the language line "req_email"
INFO - 2018-07-26 10:11:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-26 10:11:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-26 10:11:04 --> Final output sent to browser
DEBUG - 2018-07-26 10:11:04 --> Total execution time: 0.0198
INFO - 2018-07-26 10:11:12 --> Config Class Initialized
INFO - 2018-07-26 10:11:12 --> Hooks Class Initialized
DEBUG - 2018-07-26 10:11:12 --> UTF-8 Support Enabled
INFO - 2018-07-26 10:11:12 --> Utf8 Class Initialized
INFO - 2018-07-26 10:11:12 --> URI Class Initialized
INFO - 2018-07-26 10:11:12 --> Router Class Initialized
INFO - 2018-07-26 10:11:12 --> Output Class Initialized
INFO - 2018-07-26 10:11:12 --> Security Class Initialized
DEBUG - 2018-07-26 10:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 10:11:12 --> CSRF cookie sent
INFO - 2018-07-26 10:11:12 --> Input Class Initialized
INFO - 2018-07-26 10:11:12 --> Language Class Initialized
ERROR - 2018-07-26 10:11:12 --> 404 Page Not Found: Faviconico/index
INFO - 2018-07-26 10:11:28 --> Config Class Initialized
INFO - 2018-07-26 10:11:28 --> Hooks Class Initialized
DEBUG - 2018-07-26 10:11:28 --> UTF-8 Support Enabled
INFO - 2018-07-26 10:11:28 --> Utf8 Class Initialized
INFO - 2018-07-26 10:11:28 --> URI Class Initialized
INFO - 2018-07-26 10:11:28 --> Router Class Initialized
INFO - 2018-07-26 10:11:28 --> Output Class Initialized
INFO - 2018-07-26 10:11:28 --> Security Class Initialized
DEBUG - 2018-07-26 10:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 10:11:28 --> CSRF cookie sent
INFO - 2018-07-26 10:11:28 --> Input Class Initialized
INFO - 2018-07-26 10:11:28 --> Language Class Initialized
INFO - 2018-07-26 10:11:28 --> Loader Class Initialized
INFO - 2018-07-26 10:11:28 --> Helper loaded: url_helper
INFO - 2018-07-26 10:11:28 --> Helper loaded: form_helper
INFO - 2018-07-26 10:11:28 --> Helper loaded: language_helper
DEBUG - 2018-07-26 10:11:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 10:11:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 10:11:28 --> User Agent Class Initialized
INFO - 2018-07-26 10:11:28 --> Controller Class Initialized
INFO - 2018-07-26 10:11:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-26 10:11:28 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-26 10:11:28 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-26 10:11:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-26 10:11:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-26 10:11:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-26 10:11:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-26 10:11:28 --> Could not find the language line "req_email"
INFO - 2018-07-26 10:11:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-26 10:11:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-26 10:11:28 --> Final output sent to browser
DEBUG - 2018-07-26 10:11:28 --> Total execution time: 0.0247
INFO - 2018-07-26 10:11:33 --> Config Class Initialized
INFO - 2018-07-26 10:11:33 --> Hooks Class Initialized
DEBUG - 2018-07-26 10:11:33 --> UTF-8 Support Enabled
INFO - 2018-07-26 10:11:33 --> Utf8 Class Initialized
INFO - 2018-07-26 10:11:33 --> URI Class Initialized
DEBUG - 2018-07-26 10:11:33 --> No URI present. Default controller set.
INFO - 2018-07-26 10:11:33 --> Router Class Initialized
INFO - 2018-07-26 10:11:33 --> Output Class Initialized
INFO - 2018-07-26 10:11:33 --> Security Class Initialized
DEBUG - 2018-07-26 10:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 10:11:33 --> CSRF cookie sent
INFO - 2018-07-26 10:11:33 --> Input Class Initialized
INFO - 2018-07-26 10:11:33 --> Language Class Initialized
INFO - 2018-07-26 10:11:33 --> Loader Class Initialized
INFO - 2018-07-26 10:11:33 --> Helper loaded: url_helper
INFO - 2018-07-26 10:11:33 --> Helper loaded: form_helper
INFO - 2018-07-26 10:11:33 --> Helper loaded: language_helper
DEBUG - 2018-07-26 10:11:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 10:11:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 10:11:33 --> User Agent Class Initialized
INFO - 2018-07-26 10:11:33 --> Controller Class Initialized
INFO - 2018-07-26 10:11:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-26 10:11:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-26 10:11:33 --> Pixel_Model class loaded
INFO - 2018-07-26 10:11:33 --> Database Driver Class Initialized
INFO - 2018-07-26 10:11:33 --> Model "QuestionsModel" initialized
INFO - 2018-07-26 10:11:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-26 10:11:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-26 10:11:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-26 10:11:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-26 10:11:33 --> Final output sent to browser
DEBUG - 2018-07-26 10:11:33 --> Total execution time: 0.0300
INFO - 2018-07-26 10:13:46 --> Config Class Initialized
INFO - 2018-07-26 10:13:46 --> Hooks Class Initialized
DEBUG - 2018-07-26 10:13:46 --> UTF-8 Support Enabled
INFO - 2018-07-26 10:13:46 --> Utf8 Class Initialized
INFO - 2018-07-26 10:13:46 --> URI Class Initialized
INFO - 2018-07-26 10:13:46 --> Router Class Initialized
INFO - 2018-07-26 10:13:46 --> Output Class Initialized
INFO - 2018-07-26 10:13:46 --> Security Class Initialized
DEBUG - 2018-07-26 10:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 10:13:46 --> CSRF cookie sent
INFO - 2018-07-26 10:13:46 --> CSRF token verified
INFO - 2018-07-26 10:13:46 --> Input Class Initialized
INFO - 2018-07-26 10:13:46 --> Language Class Initialized
INFO - 2018-07-26 10:13:46 --> Loader Class Initialized
INFO - 2018-07-26 10:13:46 --> Helper loaded: url_helper
INFO - 2018-07-26 10:13:46 --> Helper loaded: form_helper
INFO - 2018-07-26 10:13:46 --> Helper loaded: language_helper
DEBUG - 2018-07-26 10:13:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 10:13:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 10:13:46 --> User Agent Class Initialized
INFO - 2018-07-26 10:13:46 --> Controller Class Initialized
INFO - 2018-07-26 10:13:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-26 10:13:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-26 10:13:46 --> Pixel_Model class loaded
INFO - 2018-07-26 10:13:46 --> Database Driver Class Initialized
INFO - 2018-07-26 10:13:46 --> Model "QuestionsModel" initialized
INFO - 2018-07-26 10:13:47 --> Config Class Initialized
INFO - 2018-07-26 10:13:47 --> Hooks Class Initialized
DEBUG - 2018-07-26 10:13:47 --> UTF-8 Support Enabled
INFO - 2018-07-26 10:13:47 --> Utf8 Class Initialized
INFO - 2018-07-26 10:13:47 --> URI Class Initialized
INFO - 2018-07-26 10:13:47 --> Router Class Initialized
INFO - 2018-07-26 10:13:47 --> Output Class Initialized
INFO - 2018-07-26 10:13:47 --> Security Class Initialized
DEBUG - 2018-07-26 10:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 10:13:47 --> CSRF cookie sent
INFO - 2018-07-26 10:13:47 --> Input Class Initialized
INFO - 2018-07-26 10:13:47 --> Language Class Initialized
INFO - 2018-07-26 10:13:47 --> Loader Class Initialized
INFO - 2018-07-26 10:13:47 --> Helper loaded: url_helper
INFO - 2018-07-26 10:13:47 --> Helper loaded: form_helper
INFO - 2018-07-26 10:13:47 --> Helper loaded: language_helper
DEBUG - 2018-07-26 10:13:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 10:13:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 10:13:47 --> User Agent Class Initialized
INFO - 2018-07-26 10:13:47 --> Controller Class Initialized
INFO - 2018-07-26 10:13:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-26 10:13:47 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-26 10:13:47 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-26 10:13:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-26 10:13:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-26 10:13:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-26 10:13:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-26 10:13:47 --> Could not find the language line "req_email"
INFO - 2018-07-26 10:13:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-26 10:13:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-26 10:13:47 --> Final output sent to browser
DEBUG - 2018-07-26 10:13:47 --> Total execution time: 0.0209
INFO - 2018-07-26 10:14:28 --> Config Class Initialized
INFO - 2018-07-26 10:14:28 --> Hooks Class Initialized
DEBUG - 2018-07-26 10:14:28 --> UTF-8 Support Enabled
INFO - 2018-07-26 10:14:28 --> Utf8 Class Initialized
INFO - 2018-07-26 10:14:28 --> URI Class Initialized
INFO - 2018-07-26 10:14:28 --> Router Class Initialized
INFO - 2018-07-26 10:14:28 --> Output Class Initialized
INFO - 2018-07-26 10:14:28 --> Security Class Initialized
DEBUG - 2018-07-26 10:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 10:14:28 --> CSRF cookie sent
INFO - 2018-07-26 10:14:28 --> Input Class Initialized
INFO - 2018-07-26 10:14:28 --> Language Class Initialized
INFO - 2018-07-26 10:14:28 --> Loader Class Initialized
INFO - 2018-07-26 10:14:28 --> Helper loaded: url_helper
INFO - 2018-07-26 10:14:28 --> Helper loaded: form_helper
INFO - 2018-07-26 10:14:28 --> Helper loaded: language_helper
DEBUG - 2018-07-26 10:14:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 10:14:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 10:14:28 --> User Agent Class Initialized
INFO - 2018-07-26 10:14:28 --> Controller Class Initialized
INFO - 2018-07-26 10:14:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-26 10:14:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-26 10:14:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-26 10:14:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-26 10:14:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-26 10:14:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-26 10:14:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-07-26 10:14:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-26 10:14:28 --> Final output sent to browser
DEBUG - 2018-07-26 10:14:28 --> Total execution time: 0.0318
INFO - 2018-07-26 10:14:36 --> Config Class Initialized
INFO - 2018-07-26 10:14:36 --> Hooks Class Initialized
DEBUG - 2018-07-26 10:14:36 --> UTF-8 Support Enabled
INFO - 2018-07-26 10:14:36 --> Utf8 Class Initialized
INFO - 2018-07-26 10:14:36 --> URI Class Initialized
INFO - 2018-07-26 10:14:36 --> Router Class Initialized
INFO - 2018-07-26 10:14:36 --> Output Class Initialized
INFO - 2018-07-26 10:14:36 --> Security Class Initialized
DEBUG - 2018-07-26 10:14:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 10:14:36 --> CSRF cookie sent
INFO - 2018-07-26 10:14:36 --> Input Class Initialized
INFO - 2018-07-26 10:14:36 --> Language Class Initialized
INFO - 2018-07-26 10:14:36 --> Loader Class Initialized
INFO - 2018-07-26 10:14:36 --> Helper loaded: url_helper
INFO - 2018-07-26 10:14:36 --> Helper loaded: form_helper
INFO - 2018-07-26 10:14:36 --> Helper loaded: language_helper
DEBUG - 2018-07-26 10:14:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 10:14:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 10:14:36 --> User Agent Class Initialized
INFO - 2018-07-26 10:14:36 --> Controller Class Initialized
INFO - 2018-07-26 10:14:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-26 10:14:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-26 10:14:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-26 10:14:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-26 10:14:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-26 10:14:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-26 10:14:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-07-26 10:14:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-26 10:14:36 --> Final output sent to browser
DEBUG - 2018-07-26 10:14:36 --> Total execution time: 0.0336
INFO - 2018-07-26 10:14:40 --> Config Class Initialized
INFO - 2018-07-26 10:14:40 --> Hooks Class Initialized
DEBUG - 2018-07-26 10:14:40 --> UTF-8 Support Enabled
INFO - 2018-07-26 10:14:40 --> Utf8 Class Initialized
INFO - 2018-07-26 10:14:40 --> URI Class Initialized
DEBUG - 2018-07-26 10:14:40 --> No URI present. Default controller set.
INFO - 2018-07-26 10:14:40 --> Router Class Initialized
INFO - 2018-07-26 10:14:40 --> Output Class Initialized
INFO - 2018-07-26 10:14:40 --> Security Class Initialized
DEBUG - 2018-07-26 10:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 10:14:40 --> CSRF cookie sent
INFO - 2018-07-26 10:14:40 --> Input Class Initialized
INFO - 2018-07-26 10:14:40 --> Language Class Initialized
INFO - 2018-07-26 10:14:40 --> Loader Class Initialized
INFO - 2018-07-26 10:14:40 --> Helper loaded: url_helper
INFO - 2018-07-26 10:14:40 --> Helper loaded: form_helper
INFO - 2018-07-26 10:14:40 --> Helper loaded: language_helper
DEBUG - 2018-07-26 10:14:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 10:14:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 10:14:40 --> User Agent Class Initialized
INFO - 2018-07-26 10:14:40 --> Controller Class Initialized
INFO - 2018-07-26 10:14:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-26 10:14:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-26 10:14:40 --> Pixel_Model class loaded
INFO - 2018-07-26 10:14:40 --> Database Driver Class Initialized
INFO - 2018-07-26 10:14:40 --> Model "QuestionsModel" initialized
INFO - 2018-07-26 10:14:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-26 10:14:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-26 10:14:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-26 10:14:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-26 10:14:40 --> Final output sent to browser
DEBUG - 2018-07-26 10:14:40 --> Total execution time: 0.0359
INFO - 2018-07-26 10:15:53 --> Config Class Initialized
INFO - 2018-07-26 10:15:53 --> Hooks Class Initialized
DEBUG - 2018-07-26 10:15:53 --> UTF-8 Support Enabled
INFO - 2018-07-26 10:15:53 --> Utf8 Class Initialized
INFO - 2018-07-26 10:15:53 --> URI Class Initialized
INFO - 2018-07-26 10:15:53 --> Router Class Initialized
INFO - 2018-07-26 10:15:53 --> Output Class Initialized
INFO - 2018-07-26 10:15:53 --> Security Class Initialized
DEBUG - 2018-07-26 10:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 10:15:53 --> CSRF cookie sent
INFO - 2018-07-26 10:15:53 --> Input Class Initialized
INFO - 2018-07-26 10:15:53 --> Language Class Initialized
INFO - 2018-07-26 10:15:53 --> Loader Class Initialized
INFO - 2018-07-26 10:15:53 --> Helper loaded: url_helper
INFO - 2018-07-26 10:15:53 --> Helper loaded: form_helper
INFO - 2018-07-26 10:15:53 --> Helper loaded: language_helper
DEBUG - 2018-07-26 10:15:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 10:15:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 10:15:53 --> User Agent Class Initialized
INFO - 2018-07-26 10:15:53 --> Controller Class Initialized
INFO - 2018-07-26 10:15:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-26 10:15:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-26 10:15:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-26 10:15:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-26 10:15:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-26 10:15:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-26 10:15:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-07-26 10:15:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-26 10:15:53 --> Final output sent to browser
DEBUG - 2018-07-26 10:15:53 --> Total execution time: 0.0240
INFO - 2018-07-26 10:15:56 --> Config Class Initialized
INFO - 2018-07-26 10:15:56 --> Hooks Class Initialized
DEBUG - 2018-07-26 10:15:56 --> UTF-8 Support Enabled
INFO - 2018-07-26 10:15:56 --> Utf8 Class Initialized
INFO - 2018-07-26 10:15:56 --> URI Class Initialized
INFO - 2018-07-26 10:15:56 --> Router Class Initialized
INFO - 2018-07-26 10:15:56 --> Output Class Initialized
INFO - 2018-07-26 10:15:56 --> Security Class Initialized
DEBUG - 2018-07-26 10:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 10:15:56 --> CSRF cookie sent
INFO - 2018-07-26 10:15:56 --> Input Class Initialized
INFO - 2018-07-26 10:15:56 --> Language Class Initialized
INFO - 2018-07-26 10:15:56 --> Loader Class Initialized
INFO - 2018-07-26 10:15:56 --> Helper loaded: url_helper
INFO - 2018-07-26 10:15:56 --> Helper loaded: form_helper
INFO - 2018-07-26 10:15:56 --> Helper loaded: language_helper
DEBUG - 2018-07-26 10:15:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 10:15:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 10:15:56 --> User Agent Class Initialized
INFO - 2018-07-26 10:15:56 --> Controller Class Initialized
INFO - 2018-07-26 10:15:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-26 10:15:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-26 10:15:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-26 10:15:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-26 10:15:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-26 10:15:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-26 10:15:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-07-26 10:15:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-26 10:15:56 --> Final output sent to browser
DEBUG - 2018-07-26 10:15:56 --> Total execution time: 0.0323
INFO - 2018-07-26 10:16:03 --> Config Class Initialized
INFO - 2018-07-26 10:16:03 --> Hooks Class Initialized
DEBUG - 2018-07-26 10:16:03 --> UTF-8 Support Enabled
INFO - 2018-07-26 10:16:03 --> Utf8 Class Initialized
INFO - 2018-07-26 10:16:03 --> URI Class Initialized
INFO - 2018-07-26 10:16:03 --> Router Class Initialized
INFO - 2018-07-26 10:16:03 --> Output Class Initialized
INFO - 2018-07-26 10:16:03 --> Security Class Initialized
DEBUG - 2018-07-26 10:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 10:16:03 --> CSRF cookie sent
INFO - 2018-07-26 10:16:03 --> Input Class Initialized
INFO - 2018-07-26 10:16:03 --> Language Class Initialized
INFO - 2018-07-26 10:16:03 --> Loader Class Initialized
INFO - 2018-07-26 10:16:03 --> Helper loaded: url_helper
INFO - 2018-07-26 10:16:03 --> Helper loaded: form_helper
INFO - 2018-07-26 10:16:03 --> Helper loaded: language_helper
DEBUG - 2018-07-26 10:16:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 10:16:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 10:16:03 --> User Agent Class Initialized
INFO - 2018-07-26 10:16:03 --> Controller Class Initialized
INFO - 2018-07-26 10:16:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-26 10:16:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-26 10:16:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-26 10:16:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-26 10:16:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-26 10:16:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-26 10:16:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-07-26 10:16:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-26 10:16:03 --> Final output sent to browser
DEBUG - 2018-07-26 10:16:03 --> Total execution time: 0.0203
INFO - 2018-07-26 10:31:40 --> Config Class Initialized
INFO - 2018-07-26 10:31:40 --> Hooks Class Initialized
DEBUG - 2018-07-26 10:31:40 --> UTF-8 Support Enabled
INFO - 2018-07-26 10:31:40 --> Utf8 Class Initialized
INFO - 2018-07-26 10:31:40 --> URI Class Initialized
INFO - 2018-07-26 10:31:40 --> Router Class Initialized
INFO - 2018-07-26 10:31:40 --> Output Class Initialized
INFO - 2018-07-26 10:31:40 --> Security Class Initialized
DEBUG - 2018-07-26 10:31:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 10:31:40 --> CSRF cookie sent
INFO - 2018-07-26 10:31:40 --> Input Class Initialized
INFO - 2018-07-26 10:31:40 --> Language Class Initialized
ERROR - 2018-07-26 10:31:40 --> 404 Page Not Found: Media/system
INFO - 2018-07-26 10:42:20 --> Config Class Initialized
INFO - 2018-07-26 10:42:20 --> Hooks Class Initialized
DEBUG - 2018-07-26 10:42:20 --> UTF-8 Support Enabled
INFO - 2018-07-26 10:42:20 --> Utf8 Class Initialized
INFO - 2018-07-26 10:42:20 --> URI Class Initialized
INFO - 2018-07-26 10:42:20 --> Router Class Initialized
INFO - 2018-07-26 10:42:20 --> Output Class Initialized
INFO - 2018-07-26 10:42:20 --> Security Class Initialized
DEBUG - 2018-07-26 10:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 10:42:20 --> CSRF cookie sent
INFO - 2018-07-26 10:42:20 --> Input Class Initialized
INFO - 2018-07-26 10:42:20 --> Language Class Initialized
INFO - 2018-07-26 10:42:20 --> Loader Class Initialized
INFO - 2018-07-26 10:42:20 --> Helper loaded: url_helper
INFO - 2018-07-26 10:42:20 --> Helper loaded: form_helper
INFO - 2018-07-26 10:42:20 --> Helper loaded: language_helper
DEBUG - 2018-07-26 10:42:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 10:42:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 10:42:20 --> User Agent Class Initialized
INFO - 2018-07-26 10:42:20 --> Controller Class Initialized
INFO - 2018-07-26 10:42:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-26 10:42:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-26 10:42:20 --> Pixel_Model class loaded
INFO - 2018-07-26 10:42:20 --> Database Driver Class Initialized
INFO - 2018-07-26 10:42:20 --> Model "RegistrationModel" initialized
DEBUG - 2018-07-26 10:42:20 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-26 10:42:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-26 10:42:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-26 10:42:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-26 10:42:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-26 10:42:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/temp.php
INFO - 2018-07-26 10:42:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-26 10:42:20 --> Final output sent to browser
DEBUG - 2018-07-26 10:42:20 --> Total execution time: 0.0674
INFO - 2018-07-26 11:58:12 --> Config Class Initialized
INFO - 2018-07-26 11:58:12 --> Hooks Class Initialized
DEBUG - 2018-07-26 11:58:12 --> UTF-8 Support Enabled
INFO - 2018-07-26 11:58:12 --> Utf8 Class Initialized
INFO - 2018-07-26 11:58:12 --> URI Class Initialized
INFO - 2018-07-26 11:58:12 --> Router Class Initialized
INFO - 2018-07-26 11:58:12 --> Output Class Initialized
INFO - 2018-07-26 11:58:12 --> Security Class Initialized
DEBUG - 2018-07-26 11:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 11:58:12 --> CSRF cookie sent
INFO - 2018-07-26 11:58:12 --> Input Class Initialized
INFO - 2018-07-26 11:58:12 --> Language Class Initialized
INFO - 2018-07-26 11:58:12 --> Loader Class Initialized
INFO - 2018-07-26 11:58:12 --> Helper loaded: url_helper
INFO - 2018-07-26 11:58:12 --> Helper loaded: form_helper
INFO - 2018-07-26 11:58:12 --> Helper loaded: language_helper
DEBUG - 2018-07-26 11:58:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 11:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 11:58:12 --> User Agent Class Initialized
INFO - 2018-07-26 11:58:12 --> Controller Class Initialized
INFO - 2018-07-26 11:58:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-26 11:58:12 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-26 11:58:12 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-26 11:58:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-26 11:58:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-26 11:58:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-26 11:58:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-26 11:58:12 --> Could not find the language line "req_email"
INFO - 2018-07-26 11:58:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/forgot_password.php
INFO - 2018-07-26 11:58:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-26 11:58:12 --> Final output sent to browser
DEBUG - 2018-07-26 11:58:12 --> Total execution time: 0.0263
INFO - 2018-07-26 13:45:04 --> Config Class Initialized
INFO - 2018-07-26 13:45:04 --> Hooks Class Initialized
DEBUG - 2018-07-26 13:45:04 --> UTF-8 Support Enabled
INFO - 2018-07-26 13:45:04 --> Utf8 Class Initialized
INFO - 2018-07-26 13:45:04 --> URI Class Initialized
DEBUG - 2018-07-26 13:45:04 --> No URI present. Default controller set.
INFO - 2018-07-26 13:45:04 --> Router Class Initialized
INFO - 2018-07-26 13:45:04 --> Output Class Initialized
INFO - 2018-07-26 13:45:04 --> Security Class Initialized
DEBUG - 2018-07-26 13:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 13:45:04 --> CSRF cookie sent
INFO - 2018-07-26 13:45:04 --> Input Class Initialized
INFO - 2018-07-26 13:45:04 --> Language Class Initialized
INFO - 2018-07-26 13:45:04 --> Loader Class Initialized
INFO - 2018-07-26 13:45:04 --> Helper loaded: url_helper
INFO - 2018-07-26 13:45:04 --> Helper loaded: form_helper
INFO - 2018-07-26 13:45:04 --> Helper loaded: language_helper
DEBUG - 2018-07-26 13:45:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 13:45:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 13:45:04 --> User Agent Class Initialized
INFO - 2018-07-26 13:45:04 --> Controller Class Initialized
INFO - 2018-07-26 13:45:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-26 13:45:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-26 13:45:04 --> Pixel_Model class loaded
INFO - 2018-07-26 13:45:04 --> Database Driver Class Initialized
INFO - 2018-07-26 13:45:04 --> Model "QuestionsModel" initialized
INFO - 2018-07-26 13:45:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-26 13:45:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-26 13:45:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-26 13:45:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-26 13:45:04 --> Final output sent to browser
DEBUG - 2018-07-26 13:45:04 --> Total execution time: 0.0433
INFO - 2018-07-26 13:45:05 --> Config Class Initialized
INFO - 2018-07-26 13:45:05 --> Hooks Class Initialized
DEBUG - 2018-07-26 13:45:05 --> UTF-8 Support Enabled
INFO - 2018-07-26 13:45:05 --> Utf8 Class Initialized
INFO - 2018-07-26 13:45:05 --> URI Class Initialized
DEBUG - 2018-07-26 13:45:05 --> No URI present. Default controller set.
INFO - 2018-07-26 13:45:05 --> Router Class Initialized
INFO - 2018-07-26 13:45:05 --> Output Class Initialized
INFO - 2018-07-26 13:45:05 --> Security Class Initialized
DEBUG - 2018-07-26 13:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 13:45:05 --> CSRF cookie sent
INFO - 2018-07-26 13:45:05 --> Input Class Initialized
INFO - 2018-07-26 13:45:05 --> Language Class Initialized
INFO - 2018-07-26 13:45:05 --> Loader Class Initialized
INFO - 2018-07-26 13:45:05 --> Helper loaded: url_helper
INFO - 2018-07-26 13:45:05 --> Helper loaded: form_helper
INFO - 2018-07-26 13:45:05 --> Helper loaded: language_helper
DEBUG - 2018-07-26 13:45:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 13:45:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 13:45:05 --> User Agent Class Initialized
INFO - 2018-07-26 13:45:05 --> Controller Class Initialized
INFO - 2018-07-26 13:45:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-26 13:45:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-26 13:45:05 --> Pixel_Model class loaded
INFO - 2018-07-26 13:45:05 --> Database Driver Class Initialized
INFO - 2018-07-26 13:45:05 --> Model "QuestionsModel" initialized
INFO - 2018-07-26 13:45:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-26 13:45:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-26 13:45:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-26 13:45:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-26 13:45:05 --> Final output sent to browser
DEBUG - 2018-07-26 13:45:05 --> Total execution time: 0.0350
INFO - 2018-07-26 13:45:19 --> Config Class Initialized
INFO - 2018-07-26 13:45:19 --> Hooks Class Initialized
DEBUG - 2018-07-26 13:45:19 --> UTF-8 Support Enabled
INFO - 2018-07-26 13:45:19 --> Utf8 Class Initialized
INFO - 2018-07-26 13:45:19 --> URI Class Initialized
INFO - 2018-07-26 13:45:19 --> Router Class Initialized
INFO - 2018-07-26 13:45:19 --> Output Class Initialized
INFO - 2018-07-26 13:45:19 --> Security Class Initialized
DEBUG - 2018-07-26 13:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 13:45:19 --> CSRF cookie sent
INFO - 2018-07-26 13:45:19 --> Input Class Initialized
INFO - 2018-07-26 13:45:19 --> Language Class Initialized
INFO - 2018-07-26 13:45:19 --> Loader Class Initialized
INFO - 2018-07-26 13:45:19 --> Helper loaded: url_helper
INFO - 2018-07-26 13:45:19 --> Helper loaded: form_helper
INFO - 2018-07-26 13:45:19 --> Helper loaded: language_helper
DEBUG - 2018-07-26 13:45:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 13:45:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 13:45:19 --> User Agent Class Initialized
INFO - 2018-07-26 13:45:19 --> Controller Class Initialized
INFO - 2018-07-26 13:45:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-26 13:45:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-26 13:45:19 --> Pixel_Model class loaded
INFO - 2018-07-26 13:45:19 --> Database Driver Class Initialized
INFO - 2018-07-26 13:45:19 --> Model "QuestionsModel" initialized
INFO - 2018-07-26 13:45:20 --> Config Class Initialized
INFO - 2018-07-26 13:45:20 --> Hooks Class Initialized
DEBUG - 2018-07-26 13:45:20 --> UTF-8 Support Enabled
INFO - 2018-07-26 13:45:20 --> Utf8 Class Initialized
INFO - 2018-07-26 13:45:20 --> URI Class Initialized
INFO - 2018-07-26 13:45:20 --> Router Class Initialized
INFO - 2018-07-26 13:45:20 --> Output Class Initialized
INFO - 2018-07-26 13:45:20 --> Security Class Initialized
DEBUG - 2018-07-26 13:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 13:45:20 --> CSRF cookie sent
INFO - 2018-07-26 13:45:20 --> Input Class Initialized
INFO - 2018-07-26 13:45:20 --> Language Class Initialized
INFO - 2018-07-26 13:45:20 --> Loader Class Initialized
INFO - 2018-07-26 13:45:20 --> Helper loaded: url_helper
INFO - 2018-07-26 13:45:20 --> Helper loaded: form_helper
INFO - 2018-07-26 13:45:20 --> Helper loaded: language_helper
DEBUG - 2018-07-26 13:45:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 13:45:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 13:45:20 --> User Agent Class Initialized
INFO - 2018-07-26 13:45:20 --> Controller Class Initialized
INFO - 2018-07-26 13:45:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-26 13:45:20 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-26 13:45:20 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-26 13:45:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-26 13:45:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-26 13:45:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-26 13:45:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-26 13:45:20 --> Could not find the language line "req_email"
INFO - 2018-07-26 13:45:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-26 13:45:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-26 13:45:20 --> Final output sent to browser
DEBUG - 2018-07-26 13:45:20 --> Total execution time: 0.0336
INFO - 2018-07-26 13:45:24 --> Config Class Initialized
INFO - 2018-07-26 13:45:24 --> Hooks Class Initialized
DEBUG - 2018-07-26 13:45:24 --> UTF-8 Support Enabled
INFO - 2018-07-26 13:45:24 --> Utf8 Class Initialized
INFO - 2018-07-26 13:45:24 --> URI Class Initialized
DEBUG - 2018-07-26 13:45:24 --> No URI present. Default controller set.
INFO - 2018-07-26 13:45:24 --> Router Class Initialized
INFO - 2018-07-26 13:45:24 --> Output Class Initialized
INFO - 2018-07-26 13:45:24 --> Security Class Initialized
DEBUG - 2018-07-26 13:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 13:45:24 --> CSRF cookie sent
INFO - 2018-07-26 13:45:24 --> Input Class Initialized
INFO - 2018-07-26 13:45:24 --> Language Class Initialized
INFO - 2018-07-26 13:45:24 --> Loader Class Initialized
INFO - 2018-07-26 13:45:24 --> Helper loaded: url_helper
INFO - 2018-07-26 13:45:24 --> Helper loaded: form_helper
INFO - 2018-07-26 13:45:24 --> Helper loaded: language_helper
DEBUG - 2018-07-26 13:45:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 13:45:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 13:45:24 --> User Agent Class Initialized
INFO - 2018-07-26 13:45:24 --> Controller Class Initialized
INFO - 2018-07-26 13:45:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-26 13:45:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-26 13:45:24 --> Pixel_Model class loaded
INFO - 2018-07-26 13:45:24 --> Database Driver Class Initialized
INFO - 2018-07-26 13:45:24 --> Model "QuestionsModel" initialized
INFO - 2018-07-26 13:45:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-26 13:45:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-26 13:45:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-26 13:45:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-26 13:45:24 --> Final output sent to browser
DEBUG - 2018-07-26 13:45:24 --> Total execution time: 0.0481
INFO - 2018-07-26 13:45:27 --> Config Class Initialized
INFO - 2018-07-26 13:45:27 --> Hooks Class Initialized
DEBUG - 2018-07-26 13:45:27 --> UTF-8 Support Enabled
INFO - 2018-07-26 13:45:27 --> Utf8 Class Initialized
INFO - 2018-07-26 13:45:27 --> URI Class Initialized
INFO - 2018-07-26 13:45:27 --> Router Class Initialized
INFO - 2018-07-26 13:45:27 --> Output Class Initialized
INFO - 2018-07-26 13:45:27 --> Security Class Initialized
DEBUG - 2018-07-26 13:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 13:45:27 --> CSRF cookie sent
INFO - 2018-07-26 13:45:27 --> Input Class Initialized
INFO - 2018-07-26 13:45:27 --> Language Class Initialized
INFO - 2018-07-26 13:45:27 --> Loader Class Initialized
INFO - 2018-07-26 13:45:27 --> Helper loaded: url_helper
INFO - 2018-07-26 13:45:27 --> Helper loaded: form_helper
INFO - 2018-07-26 13:45:27 --> Helper loaded: language_helper
DEBUG - 2018-07-26 13:45:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 13:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 13:45:27 --> User Agent Class Initialized
INFO - 2018-07-26 13:45:27 --> Controller Class Initialized
INFO - 2018-07-26 13:45:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-26 13:45:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-26 13:45:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-26 13:45:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-26 13:45:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-26 13:45:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-26 13:45:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-07-26 13:45:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-26 13:45:27 --> Final output sent to browser
DEBUG - 2018-07-26 13:45:27 --> Total execution time: 0.0261
INFO - 2018-07-26 13:45:34 --> Config Class Initialized
INFO - 2018-07-26 13:45:34 --> Hooks Class Initialized
DEBUG - 2018-07-26 13:45:34 --> UTF-8 Support Enabled
INFO - 2018-07-26 13:45:34 --> Utf8 Class Initialized
INFO - 2018-07-26 13:45:34 --> URI Class Initialized
DEBUG - 2018-07-26 13:45:34 --> No URI present. Default controller set.
INFO - 2018-07-26 13:45:34 --> Router Class Initialized
INFO - 2018-07-26 13:45:34 --> Output Class Initialized
INFO - 2018-07-26 13:45:34 --> Security Class Initialized
DEBUG - 2018-07-26 13:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 13:45:34 --> CSRF cookie sent
INFO - 2018-07-26 13:45:34 --> Input Class Initialized
INFO - 2018-07-26 13:45:34 --> Language Class Initialized
INFO - 2018-07-26 13:45:34 --> Loader Class Initialized
INFO - 2018-07-26 13:45:34 --> Helper loaded: url_helper
INFO - 2018-07-26 13:45:34 --> Helper loaded: form_helper
INFO - 2018-07-26 13:45:34 --> Helper loaded: language_helper
DEBUG - 2018-07-26 13:45:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 13:45:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 13:45:34 --> User Agent Class Initialized
INFO - 2018-07-26 13:45:34 --> Controller Class Initialized
INFO - 2018-07-26 13:45:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-26 13:45:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-26 13:45:34 --> Pixel_Model class loaded
INFO - 2018-07-26 13:45:34 --> Database Driver Class Initialized
INFO - 2018-07-26 13:45:34 --> Model "QuestionsModel" initialized
INFO - 2018-07-26 13:45:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-26 13:45:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-26 13:45:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-26 13:45:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-26 13:45:34 --> Final output sent to browser
DEBUG - 2018-07-26 13:45:34 --> Total execution time: 0.0379
INFO - 2018-07-26 13:48:58 --> Config Class Initialized
INFO - 2018-07-26 13:48:58 --> Hooks Class Initialized
DEBUG - 2018-07-26 13:48:58 --> UTF-8 Support Enabled
INFO - 2018-07-26 13:48:58 --> Utf8 Class Initialized
INFO - 2018-07-26 13:48:58 --> URI Class Initialized
INFO - 2018-07-26 13:48:58 --> Router Class Initialized
INFO - 2018-07-26 13:48:58 --> Output Class Initialized
INFO - 2018-07-26 13:48:58 --> Security Class Initialized
DEBUG - 2018-07-26 13:48:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 13:48:58 --> CSRF cookie sent
INFO - 2018-07-26 13:48:58 --> CSRF token verified
INFO - 2018-07-26 13:48:58 --> Input Class Initialized
INFO - 2018-07-26 13:48:58 --> Language Class Initialized
INFO - 2018-07-26 13:48:58 --> Loader Class Initialized
INFO - 2018-07-26 13:48:58 --> Helper loaded: url_helper
INFO - 2018-07-26 13:48:58 --> Helper loaded: form_helper
INFO - 2018-07-26 13:48:58 --> Helper loaded: language_helper
DEBUG - 2018-07-26 13:48:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 13:48:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 13:48:58 --> User Agent Class Initialized
INFO - 2018-07-26 13:48:58 --> Controller Class Initialized
INFO - 2018-07-26 13:48:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-26 13:48:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-26 13:48:58 --> Pixel_Model class loaded
INFO - 2018-07-26 13:48:58 --> Database Driver Class Initialized
INFO - 2018-07-26 13:48:58 --> Model "QuestionsModel" initialized
INFO - 2018-07-26 13:48:58 --> Config Class Initialized
INFO - 2018-07-26 13:48:58 --> Hooks Class Initialized
DEBUG - 2018-07-26 13:48:58 --> UTF-8 Support Enabled
INFO - 2018-07-26 13:48:58 --> Utf8 Class Initialized
INFO - 2018-07-26 13:48:58 --> URI Class Initialized
INFO - 2018-07-26 13:48:58 --> Router Class Initialized
INFO - 2018-07-26 13:48:58 --> Output Class Initialized
INFO - 2018-07-26 13:48:58 --> Security Class Initialized
DEBUG - 2018-07-26 13:48:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 13:48:58 --> CSRF cookie sent
INFO - 2018-07-26 13:48:58 --> Input Class Initialized
INFO - 2018-07-26 13:48:58 --> Language Class Initialized
INFO - 2018-07-26 13:48:58 --> Loader Class Initialized
INFO - 2018-07-26 13:48:58 --> Helper loaded: url_helper
INFO - 2018-07-26 13:48:58 --> Helper loaded: form_helper
INFO - 2018-07-26 13:48:58 --> Helper loaded: language_helper
DEBUG - 2018-07-26 13:48:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 13:48:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 13:48:58 --> User Agent Class Initialized
INFO - 2018-07-26 13:48:58 --> Controller Class Initialized
INFO - 2018-07-26 13:48:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-26 13:48:58 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-26 13:48:58 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-26 13:48:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-26 13:48:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-26 13:48:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-26 13:48:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-26 13:48:58 --> Could not find the language line "req_email"
INFO - 2018-07-26 13:48:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-26 13:48:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-26 13:48:58 --> Final output sent to browser
DEBUG - 2018-07-26 13:48:58 --> Total execution time: 0.0479
INFO - 2018-07-26 13:49:27 --> Config Class Initialized
INFO - 2018-07-26 13:49:27 --> Hooks Class Initialized
DEBUG - 2018-07-26 13:49:27 --> UTF-8 Support Enabled
INFO - 2018-07-26 13:49:27 --> Utf8 Class Initialized
INFO - 2018-07-26 13:49:27 --> URI Class Initialized
DEBUG - 2018-07-26 13:49:27 --> No URI present. Default controller set.
INFO - 2018-07-26 13:49:27 --> Router Class Initialized
INFO - 2018-07-26 13:49:27 --> Output Class Initialized
INFO - 2018-07-26 13:49:27 --> Security Class Initialized
DEBUG - 2018-07-26 13:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 13:49:27 --> CSRF cookie sent
INFO - 2018-07-26 13:49:27 --> Input Class Initialized
INFO - 2018-07-26 13:49:27 --> Language Class Initialized
INFO - 2018-07-26 13:49:27 --> Loader Class Initialized
INFO - 2018-07-26 13:49:27 --> Helper loaded: url_helper
INFO - 2018-07-26 13:49:27 --> Helper loaded: form_helper
INFO - 2018-07-26 13:49:27 --> Helper loaded: language_helper
DEBUG - 2018-07-26 13:49:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 13:49:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 13:49:27 --> User Agent Class Initialized
INFO - 2018-07-26 13:49:27 --> Controller Class Initialized
INFO - 2018-07-26 13:49:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-26 13:49:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-26 13:49:27 --> Pixel_Model class loaded
INFO - 2018-07-26 13:49:27 --> Database Driver Class Initialized
INFO - 2018-07-26 13:49:27 --> Model "QuestionsModel" initialized
INFO - 2018-07-26 13:49:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-26 13:49:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-26 13:49:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-26 13:49:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-26 13:49:27 --> Final output sent to browser
DEBUG - 2018-07-26 13:49:27 --> Total execution time: 0.0364
INFO - 2018-07-26 17:52:29 --> Config Class Initialized
INFO - 2018-07-26 17:52:29 --> Hooks Class Initialized
DEBUG - 2018-07-26 17:52:29 --> UTF-8 Support Enabled
INFO - 2018-07-26 17:52:29 --> Utf8 Class Initialized
INFO - 2018-07-26 17:52:29 --> URI Class Initialized
DEBUG - 2018-07-26 17:52:29 --> No URI present. Default controller set.
INFO - 2018-07-26 17:52:29 --> Router Class Initialized
INFO - 2018-07-26 17:52:29 --> Output Class Initialized
INFO - 2018-07-26 17:52:29 --> Security Class Initialized
DEBUG - 2018-07-26 17:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 17:52:29 --> CSRF cookie sent
INFO - 2018-07-26 17:52:29 --> Input Class Initialized
INFO - 2018-07-26 17:52:29 --> Language Class Initialized
INFO - 2018-07-26 17:52:29 --> Loader Class Initialized
INFO - 2018-07-26 17:52:29 --> Helper loaded: url_helper
INFO - 2018-07-26 17:52:29 --> Helper loaded: form_helper
INFO - 2018-07-26 17:52:29 --> Helper loaded: language_helper
DEBUG - 2018-07-26 17:52:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 17:52:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 17:52:29 --> User Agent Class Initialized
INFO - 2018-07-26 17:52:29 --> Controller Class Initialized
INFO - 2018-07-26 17:52:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-26 17:52:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-26 17:52:29 --> Pixel_Model class loaded
INFO - 2018-07-26 17:52:29 --> Database Driver Class Initialized
INFO - 2018-07-26 17:52:29 --> Model "QuestionsModel" initialized
INFO - 2018-07-26 17:52:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-26 17:52:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-26 17:52:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-26 17:52:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-26 17:52:29 --> Final output sent to browser
DEBUG - 2018-07-26 17:52:29 --> Total execution time: 0.0315
INFO - 2018-07-26 18:27:26 --> Config Class Initialized
INFO - 2018-07-26 18:27:26 --> Hooks Class Initialized
DEBUG - 2018-07-26 18:27:26 --> UTF-8 Support Enabled
INFO - 2018-07-26 18:27:26 --> Utf8 Class Initialized
INFO - 2018-07-26 18:27:26 --> URI Class Initialized
DEBUG - 2018-07-26 18:27:26 --> No URI present. Default controller set.
INFO - 2018-07-26 18:27:26 --> Router Class Initialized
INFO - 2018-07-26 18:27:26 --> Output Class Initialized
INFO - 2018-07-26 18:27:26 --> Security Class Initialized
DEBUG - 2018-07-26 18:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 18:27:26 --> CSRF cookie sent
INFO - 2018-07-26 18:27:26 --> Input Class Initialized
INFO - 2018-07-26 18:27:26 --> Language Class Initialized
INFO - 2018-07-26 18:27:26 --> Loader Class Initialized
INFO - 2018-07-26 18:27:26 --> Helper loaded: url_helper
INFO - 2018-07-26 18:27:26 --> Helper loaded: form_helper
INFO - 2018-07-26 18:27:26 --> Helper loaded: language_helper
DEBUG - 2018-07-26 18:27:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 18:27:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 18:27:26 --> User Agent Class Initialized
INFO - 2018-07-26 18:27:26 --> Controller Class Initialized
INFO - 2018-07-26 18:27:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-26 18:27:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-26 18:27:26 --> Pixel_Model class loaded
INFO - 2018-07-26 18:27:26 --> Database Driver Class Initialized
INFO - 2018-07-26 18:27:26 --> Model "QuestionsModel" initialized
INFO - 2018-07-26 18:27:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-26 18:27:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-26 18:27:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-26 18:27:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-26 18:27:26 --> Final output sent to browser
DEBUG - 2018-07-26 18:27:26 --> Total execution time: 0.0312
INFO - 2018-07-26 18:33:59 --> Config Class Initialized
INFO - 2018-07-26 18:33:59 --> Hooks Class Initialized
DEBUG - 2018-07-26 18:33:59 --> UTF-8 Support Enabled
INFO - 2018-07-26 18:33:59 --> Utf8 Class Initialized
INFO - 2018-07-26 18:33:59 --> URI Class Initialized
INFO - 2018-07-26 18:33:59 --> Router Class Initialized
INFO - 2018-07-26 18:33:59 --> Output Class Initialized
INFO - 2018-07-26 18:33:59 --> Security Class Initialized
DEBUG - 2018-07-26 18:33:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 18:33:59 --> CSRF cookie sent
INFO - 2018-07-26 18:33:59 --> Input Class Initialized
INFO - 2018-07-26 18:33:59 --> Language Class Initialized
ERROR - 2018-07-26 18:33:59 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-26 18:47:59 --> Config Class Initialized
INFO - 2018-07-26 18:47:59 --> Hooks Class Initialized
DEBUG - 2018-07-26 18:47:59 --> UTF-8 Support Enabled
INFO - 2018-07-26 18:47:59 --> Utf8 Class Initialized
INFO - 2018-07-26 18:47:59 --> URI Class Initialized
DEBUG - 2018-07-26 18:47:59 --> No URI present. Default controller set.
INFO - 2018-07-26 18:47:59 --> Router Class Initialized
INFO - 2018-07-26 18:47:59 --> Output Class Initialized
INFO - 2018-07-26 18:47:59 --> Security Class Initialized
DEBUG - 2018-07-26 18:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 18:47:59 --> CSRF cookie sent
INFO - 2018-07-26 18:47:59 --> Input Class Initialized
INFO - 2018-07-26 18:47:59 --> Language Class Initialized
INFO - 2018-07-26 18:47:59 --> Loader Class Initialized
INFO - 2018-07-26 18:47:59 --> Helper loaded: url_helper
INFO - 2018-07-26 18:47:59 --> Helper loaded: form_helper
INFO - 2018-07-26 18:47:59 --> Helper loaded: language_helper
DEBUG - 2018-07-26 18:47:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 18:47:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 18:47:59 --> User Agent Class Initialized
INFO - 2018-07-26 18:47:59 --> Controller Class Initialized
INFO - 2018-07-26 18:47:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-26 18:47:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-26 18:47:59 --> Pixel_Model class loaded
INFO - 2018-07-26 18:47:59 --> Database Driver Class Initialized
INFO - 2018-07-26 18:47:59 --> Model "QuestionsModel" initialized
INFO - 2018-07-26 18:47:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-26 18:47:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-26 18:47:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-26 18:47:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-26 18:47:59 --> Final output sent to browser
DEBUG - 2018-07-26 18:47:59 --> Total execution time: 0.0415
INFO - 2018-07-26 19:36:34 --> Config Class Initialized
INFO - 2018-07-26 19:36:34 --> Hooks Class Initialized
DEBUG - 2018-07-26 19:36:34 --> UTF-8 Support Enabled
INFO - 2018-07-26 19:36:34 --> Utf8 Class Initialized
INFO - 2018-07-26 19:36:34 --> URI Class Initialized
DEBUG - 2018-07-26 19:36:34 --> No URI present. Default controller set.
INFO - 2018-07-26 19:36:34 --> Router Class Initialized
INFO - 2018-07-26 19:36:34 --> Output Class Initialized
INFO - 2018-07-26 19:36:34 --> Security Class Initialized
DEBUG - 2018-07-26 19:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 19:36:34 --> CSRF cookie sent
INFO - 2018-07-26 19:36:34 --> Input Class Initialized
INFO - 2018-07-26 19:36:34 --> Language Class Initialized
INFO - 2018-07-26 19:36:34 --> Loader Class Initialized
INFO - 2018-07-26 19:36:34 --> Helper loaded: url_helper
INFO - 2018-07-26 19:36:34 --> Helper loaded: form_helper
INFO - 2018-07-26 19:36:34 --> Helper loaded: language_helper
DEBUG - 2018-07-26 19:36:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 19:36:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 19:36:34 --> User Agent Class Initialized
INFO - 2018-07-26 19:36:34 --> Controller Class Initialized
INFO - 2018-07-26 19:36:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-26 19:36:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-26 19:36:34 --> Pixel_Model class loaded
INFO - 2018-07-26 19:36:34 --> Database Driver Class Initialized
INFO - 2018-07-26 19:36:34 --> Model "QuestionsModel" initialized
INFO - 2018-07-26 19:36:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-26 19:36:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-26 19:36:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-26 19:36:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-26 19:36:34 --> Final output sent to browser
DEBUG - 2018-07-26 19:36:34 --> Total execution time: 0.0314
INFO - 2018-07-26 20:01:57 --> Config Class Initialized
INFO - 2018-07-26 20:01:57 --> Hooks Class Initialized
DEBUG - 2018-07-26 20:01:57 --> UTF-8 Support Enabled
INFO - 2018-07-26 20:01:57 --> Utf8 Class Initialized
INFO - 2018-07-26 20:01:57 --> URI Class Initialized
DEBUG - 2018-07-26 20:01:57 --> No URI present. Default controller set.
INFO - 2018-07-26 20:01:57 --> Router Class Initialized
INFO - 2018-07-26 20:01:57 --> Output Class Initialized
INFO - 2018-07-26 20:01:57 --> Security Class Initialized
DEBUG - 2018-07-26 20:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 20:01:57 --> CSRF cookie sent
INFO - 2018-07-26 20:01:57 --> Input Class Initialized
INFO - 2018-07-26 20:01:57 --> Language Class Initialized
INFO - 2018-07-26 20:01:57 --> Loader Class Initialized
INFO - 2018-07-26 20:01:57 --> Helper loaded: url_helper
INFO - 2018-07-26 20:01:57 --> Helper loaded: form_helper
INFO - 2018-07-26 20:01:57 --> Helper loaded: language_helper
DEBUG - 2018-07-26 20:01:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 20:01:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 20:01:57 --> User Agent Class Initialized
INFO - 2018-07-26 20:01:57 --> Controller Class Initialized
INFO - 2018-07-26 20:01:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-26 20:01:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-26 20:01:57 --> Pixel_Model class loaded
INFO - 2018-07-26 20:01:57 --> Database Driver Class Initialized
INFO - 2018-07-26 20:01:57 --> Model "QuestionsModel" initialized
INFO - 2018-07-26 20:01:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-26 20:01:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-26 20:01:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-26 20:01:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-26 20:01:57 --> Final output sent to browser
DEBUG - 2018-07-26 20:01:57 --> Total execution time: 0.0357
INFO - 2018-07-26 22:22:08 --> Config Class Initialized
INFO - 2018-07-26 22:22:08 --> Hooks Class Initialized
DEBUG - 2018-07-26 22:22:08 --> UTF-8 Support Enabled
INFO - 2018-07-26 22:22:08 --> Utf8 Class Initialized
INFO - 2018-07-26 22:22:08 --> URI Class Initialized
DEBUG - 2018-07-26 22:22:08 --> No URI present. Default controller set.
INFO - 2018-07-26 22:22:08 --> Router Class Initialized
INFO - 2018-07-26 22:22:08 --> Output Class Initialized
INFO - 2018-07-26 22:22:08 --> Security Class Initialized
DEBUG - 2018-07-26 22:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 22:22:08 --> CSRF cookie sent
INFO - 2018-07-26 22:22:08 --> Input Class Initialized
INFO - 2018-07-26 22:22:08 --> Language Class Initialized
INFO - 2018-07-26 22:22:08 --> Loader Class Initialized
INFO - 2018-07-26 22:22:08 --> Helper loaded: url_helper
INFO - 2018-07-26 22:22:08 --> Helper loaded: form_helper
INFO - 2018-07-26 22:22:08 --> Helper loaded: language_helper
DEBUG - 2018-07-26 22:22:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 22:22:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 22:22:08 --> User Agent Class Initialized
INFO - 2018-07-26 22:22:08 --> Controller Class Initialized
INFO - 2018-07-26 22:22:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-26 22:22:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-26 22:22:08 --> Pixel_Model class loaded
INFO - 2018-07-26 22:22:08 --> Database Driver Class Initialized
INFO - 2018-07-26 22:22:08 --> Model "QuestionsModel" initialized
INFO - 2018-07-26 22:22:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-26 22:22:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-26 22:22:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-26 22:22:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-26 22:22:08 --> Final output sent to browser
DEBUG - 2018-07-26 22:22:08 --> Total execution time: 0.0346
INFO - 2018-07-26 22:22:09 --> Config Class Initialized
INFO - 2018-07-26 22:22:09 --> Hooks Class Initialized
DEBUG - 2018-07-26 22:22:09 --> UTF-8 Support Enabled
INFO - 2018-07-26 22:22:09 --> Utf8 Class Initialized
INFO - 2018-07-26 22:22:09 --> URI Class Initialized
DEBUG - 2018-07-26 22:22:09 --> No URI present. Default controller set.
INFO - 2018-07-26 22:22:09 --> Router Class Initialized
INFO - 2018-07-26 22:22:09 --> Output Class Initialized
INFO - 2018-07-26 22:22:09 --> Security Class Initialized
DEBUG - 2018-07-26 22:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 22:22:09 --> CSRF cookie sent
INFO - 2018-07-26 22:22:09 --> Input Class Initialized
INFO - 2018-07-26 22:22:09 --> Language Class Initialized
INFO - 2018-07-26 22:22:09 --> Loader Class Initialized
INFO - 2018-07-26 22:22:09 --> Helper loaded: url_helper
INFO - 2018-07-26 22:22:09 --> Helper loaded: form_helper
INFO - 2018-07-26 22:22:09 --> Helper loaded: language_helper
DEBUG - 2018-07-26 22:22:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 22:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 22:22:09 --> User Agent Class Initialized
INFO - 2018-07-26 22:22:09 --> Controller Class Initialized
INFO - 2018-07-26 22:22:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-26 22:22:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-26 22:22:09 --> Pixel_Model class loaded
INFO - 2018-07-26 22:22:09 --> Database Driver Class Initialized
INFO - 2018-07-26 22:22:09 --> Model "QuestionsModel" initialized
INFO - 2018-07-26 22:22:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-26 22:22:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-26 22:22:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-26 22:22:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-26 22:22:09 --> Final output sent to browser
DEBUG - 2018-07-26 22:22:09 --> Total execution time: 0.0340
INFO - 2018-07-26 22:22:09 --> Config Class Initialized
INFO - 2018-07-26 22:22:09 --> Hooks Class Initialized
DEBUG - 2018-07-26 22:22:09 --> UTF-8 Support Enabled
INFO - 2018-07-26 22:22:09 --> Utf8 Class Initialized
INFO - 2018-07-26 22:22:09 --> URI Class Initialized
DEBUG - 2018-07-26 22:22:09 --> No URI present. Default controller set.
INFO - 2018-07-26 22:22:09 --> Router Class Initialized
INFO - 2018-07-26 22:22:09 --> Output Class Initialized
INFO - 2018-07-26 22:22:09 --> Security Class Initialized
DEBUG - 2018-07-26 22:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 22:22:09 --> CSRF cookie sent
INFO - 2018-07-26 22:22:09 --> Input Class Initialized
INFO - 2018-07-26 22:22:09 --> Language Class Initialized
INFO - 2018-07-26 22:22:09 --> Loader Class Initialized
INFO - 2018-07-26 22:22:09 --> Helper loaded: url_helper
INFO - 2018-07-26 22:22:09 --> Helper loaded: form_helper
INFO - 2018-07-26 22:22:09 --> Helper loaded: language_helper
DEBUG - 2018-07-26 22:22:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 22:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 22:22:09 --> User Agent Class Initialized
INFO - 2018-07-26 22:22:09 --> Controller Class Initialized
INFO - 2018-07-26 22:22:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-26 22:22:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-26 22:22:09 --> Pixel_Model class loaded
INFO - 2018-07-26 22:22:09 --> Database Driver Class Initialized
INFO - 2018-07-26 22:22:09 --> Model "QuestionsModel" initialized
INFO - 2018-07-26 22:22:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-26 22:22:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-26 22:22:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-26 22:22:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-26 22:22:09 --> Final output sent to browser
DEBUG - 2018-07-26 22:22:09 --> Total execution time: 0.0348
INFO - 2018-07-26 22:22:10 --> Config Class Initialized
INFO - 2018-07-26 22:22:10 --> Hooks Class Initialized
DEBUG - 2018-07-26 22:22:10 --> UTF-8 Support Enabled
INFO - 2018-07-26 22:22:10 --> Utf8 Class Initialized
INFO - 2018-07-26 22:22:10 --> URI Class Initialized
INFO - 2018-07-26 22:22:10 --> Router Class Initialized
INFO - 2018-07-26 22:22:10 --> Output Class Initialized
INFO - 2018-07-26 22:22:10 --> Security Class Initialized
DEBUG - 2018-07-26 22:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 22:22:10 --> CSRF cookie sent
INFO - 2018-07-26 22:22:10 --> Input Class Initialized
INFO - 2018-07-26 22:22:10 --> Language Class Initialized
ERROR - 2018-07-26 22:22:10 --> 404 Page Not Found: 405shtml/index
INFO - 2018-07-26 22:22:18 --> Config Class Initialized
INFO - 2018-07-26 22:22:18 --> Hooks Class Initialized
DEBUG - 2018-07-26 22:22:18 --> UTF-8 Support Enabled
INFO - 2018-07-26 22:22:18 --> Utf8 Class Initialized
INFO - 2018-07-26 22:22:18 --> URI Class Initialized
DEBUG - 2018-07-26 22:22:18 --> No URI present. Default controller set.
INFO - 2018-07-26 22:22:18 --> Router Class Initialized
INFO - 2018-07-26 22:22:18 --> Output Class Initialized
INFO - 2018-07-26 22:22:18 --> Security Class Initialized
DEBUG - 2018-07-26 22:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 22:22:18 --> CSRF cookie sent
INFO - 2018-07-26 22:22:18 --> Input Class Initialized
INFO - 2018-07-26 22:22:18 --> Language Class Initialized
INFO - 2018-07-26 22:22:18 --> Loader Class Initialized
INFO - 2018-07-26 22:22:18 --> Helper loaded: url_helper
INFO - 2018-07-26 22:22:18 --> Helper loaded: form_helper
INFO - 2018-07-26 22:22:18 --> Helper loaded: language_helper
DEBUG - 2018-07-26 22:22:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 22:22:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 22:22:18 --> User Agent Class Initialized
INFO - 2018-07-26 22:22:18 --> Controller Class Initialized
INFO - 2018-07-26 22:22:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-26 22:22:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-26 22:22:18 --> Pixel_Model class loaded
INFO - 2018-07-26 22:22:18 --> Database Driver Class Initialized
INFO - 2018-07-26 22:22:18 --> Model "QuestionsModel" initialized
INFO - 2018-07-26 22:22:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-26 22:22:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-26 22:22:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-26 22:22:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-26 22:22:18 --> Final output sent to browser
DEBUG - 2018-07-26 22:22:18 --> Total execution time: 0.0389
INFO - 2018-07-26 22:22:18 --> Config Class Initialized
INFO - 2018-07-26 22:22:18 --> Hooks Class Initialized
DEBUG - 2018-07-26 22:22:18 --> UTF-8 Support Enabled
INFO - 2018-07-26 22:22:18 --> Utf8 Class Initialized
INFO - 2018-07-26 22:22:18 --> URI Class Initialized
INFO - 2018-07-26 22:22:18 --> Router Class Initialized
INFO - 2018-07-26 22:22:18 --> Output Class Initialized
INFO - 2018-07-26 22:22:18 --> Security Class Initialized
DEBUG - 2018-07-26 22:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 22:22:18 --> CSRF cookie sent
INFO - 2018-07-26 22:22:18 --> Input Class Initialized
INFO - 2018-07-26 22:22:18 --> Language Class Initialized
ERROR - 2018-07-26 22:22:18 --> 404 Page Not Found: 404testpage4525d2fdc/index
INFO - 2018-07-26 22:22:18 --> Config Class Initialized
INFO - 2018-07-26 22:22:18 --> Hooks Class Initialized
DEBUG - 2018-07-26 22:22:18 --> UTF-8 Support Enabled
INFO - 2018-07-26 22:22:18 --> Utf8 Class Initialized
INFO - 2018-07-26 22:22:18 --> URI Class Initialized
INFO - 2018-07-26 22:22:18 --> Router Class Initialized
INFO - 2018-07-26 22:22:18 --> Output Class Initialized
INFO - 2018-07-26 22:22:18 --> Security Class Initialized
DEBUG - 2018-07-26 22:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 22:22:18 --> CSRF cookie sent
INFO - 2018-07-26 22:22:18 --> Input Class Initialized
INFO - 2018-07-26 22:22:18 --> Language Class Initialized
ERROR - 2018-07-26 22:22:18 --> 404 Page Not Found: 404javascriptjs/index
INFO - 2018-07-26 22:22:19 --> Config Class Initialized
INFO - 2018-07-26 22:22:19 --> Hooks Class Initialized
DEBUG - 2018-07-26 22:22:19 --> UTF-8 Support Enabled
INFO - 2018-07-26 22:22:19 --> Utf8 Class Initialized
INFO - 2018-07-26 22:22:19 --> URI Class Initialized
INFO - 2018-07-26 22:22:19 --> Router Class Initialized
INFO - 2018-07-26 22:22:19 --> Output Class Initialized
INFO - 2018-07-26 22:22:19 --> Security Class Initialized
DEBUG - 2018-07-26 22:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 22:22:19 --> CSRF cookie sent
INFO - 2018-07-26 22:22:19 --> Input Class Initialized
INFO - 2018-07-26 22:22:19 --> Language Class Initialized
INFO - 2018-07-26 22:22:19 --> Loader Class Initialized
INFO - 2018-07-26 22:22:19 --> Helper loaded: url_helper
INFO - 2018-07-26 22:22:19 --> Helper loaded: form_helper
INFO - 2018-07-26 22:22:19 --> Helper loaded: language_helper
DEBUG - 2018-07-26 22:22:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 22:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 22:22:19 --> User Agent Class Initialized
INFO - 2018-07-26 22:22:19 --> Controller Class Initialized
INFO - 2018-07-26 22:22:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-26 22:22:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-26 22:22:19 --> Pixel_Model class loaded
INFO - 2018-07-26 22:22:19 --> Database Driver Class Initialized
INFO - 2018-07-26 22:22:19 --> Model "QuestionsModel" initialized
INFO - 2018-07-26 22:22:19 --> Config Class Initialized
INFO - 2018-07-26 22:22:19 --> Hooks Class Initialized
DEBUG - 2018-07-26 22:22:19 --> UTF-8 Support Enabled
INFO - 2018-07-26 22:22:19 --> Utf8 Class Initialized
INFO - 2018-07-26 22:22:19 --> URI Class Initialized
INFO - 2018-07-26 22:22:19 --> Router Class Initialized
INFO - 2018-07-26 22:22:19 --> Output Class Initialized
INFO - 2018-07-26 22:22:19 --> Security Class Initialized
DEBUG - 2018-07-26 22:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 22:22:19 --> CSRF cookie sent
INFO - 2018-07-26 22:22:19 --> Input Class Initialized
INFO - 2018-07-26 22:22:19 --> Language Class Initialized
INFO - 2018-07-26 22:22:19 --> Loader Class Initialized
INFO - 2018-07-26 22:22:19 --> Helper loaded: url_helper
INFO - 2018-07-26 22:22:19 --> Helper loaded: form_helper
INFO - 2018-07-26 22:22:19 --> Helper loaded: language_helper
DEBUG - 2018-07-26 22:22:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 22:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 22:22:19 --> User Agent Class Initialized
INFO - 2018-07-26 22:22:19 --> Controller Class Initialized
INFO - 2018-07-26 22:22:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-26 22:22:19 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-26 22:22:19 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-26 22:22:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-26 22:22:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-26 22:22:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-26 22:22:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-26 22:22:19 --> Could not find the language line "req_email"
INFO - 2018-07-26 22:22:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-26 22:22:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-26 22:22:19 --> Final output sent to browser
DEBUG - 2018-07-26 22:22:19 --> Total execution time: 0.0201
INFO - 2018-07-26 22:22:19 --> Config Class Initialized
INFO - 2018-07-26 22:22:19 --> Hooks Class Initialized
DEBUG - 2018-07-26 22:22:19 --> UTF-8 Support Enabled
INFO - 2018-07-26 22:22:19 --> Utf8 Class Initialized
INFO - 2018-07-26 22:22:19 --> URI Class Initialized
INFO - 2018-07-26 22:22:19 --> Router Class Initialized
INFO - 2018-07-26 22:22:19 --> Output Class Initialized
INFO - 2018-07-26 22:22:19 --> Security Class Initialized
DEBUG - 2018-07-26 22:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 22:22:19 --> CSRF cookie sent
INFO - 2018-07-26 22:22:19 --> Input Class Initialized
INFO - 2018-07-26 22:22:19 --> Language Class Initialized
INFO - 2018-07-26 22:22:19 --> Loader Class Initialized
INFO - 2018-07-26 22:22:19 --> Helper loaded: url_helper
INFO - 2018-07-26 22:22:19 --> Helper loaded: form_helper
INFO - 2018-07-26 22:22:19 --> Helper loaded: language_helper
DEBUG - 2018-07-26 22:22:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 22:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 22:22:19 --> User Agent Class Initialized
INFO - 2018-07-26 22:22:19 --> Controller Class Initialized
INFO - 2018-07-26 22:22:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-26 22:22:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-26 22:22:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-26 22:22:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-26 22:22:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-26 22:22:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-26 22:22:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-07-26 22:22:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-26 22:22:19 --> Final output sent to browser
DEBUG - 2018-07-26 22:22:19 --> Total execution time: 0.0224
INFO - 2018-07-26 22:22:20 --> Config Class Initialized
INFO - 2018-07-26 22:22:20 --> Hooks Class Initialized
DEBUG - 2018-07-26 22:22:20 --> UTF-8 Support Enabled
INFO - 2018-07-26 22:22:20 --> Utf8 Class Initialized
INFO - 2018-07-26 22:22:20 --> URI Class Initialized
INFO - 2018-07-26 22:22:20 --> Router Class Initialized
INFO - 2018-07-26 22:22:20 --> Output Class Initialized
INFO - 2018-07-26 22:22:20 --> Security Class Initialized
DEBUG - 2018-07-26 22:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 22:22:20 --> CSRF cookie sent
INFO - 2018-07-26 22:22:20 --> Input Class Initialized
INFO - 2018-07-26 22:22:20 --> Language Class Initialized
INFO - 2018-07-26 22:22:20 --> Loader Class Initialized
INFO - 2018-07-26 22:22:20 --> Helper loaded: url_helper
INFO - 2018-07-26 22:22:20 --> Helper loaded: form_helper
INFO - 2018-07-26 22:22:20 --> Helper loaded: language_helper
DEBUG - 2018-07-26 22:22:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 22:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 22:22:20 --> User Agent Class Initialized
INFO - 2018-07-26 22:22:20 --> Controller Class Initialized
INFO - 2018-07-26 22:22:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-26 22:22:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-26 22:22:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-26 22:22:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-26 22:22:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-26 22:22:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-26 22:22:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-07-26 22:22:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-26 22:22:20 --> Final output sent to browser
DEBUG - 2018-07-26 22:22:20 --> Total execution time: 0.0274
INFO - 2018-07-26 22:22:20 --> Config Class Initialized
INFO - 2018-07-26 22:22:20 --> Hooks Class Initialized
DEBUG - 2018-07-26 22:22:20 --> UTF-8 Support Enabled
INFO - 2018-07-26 22:22:20 --> Utf8 Class Initialized
INFO - 2018-07-26 22:22:20 --> URI Class Initialized
INFO - 2018-07-26 22:22:20 --> Router Class Initialized
INFO - 2018-07-26 22:22:20 --> Output Class Initialized
INFO - 2018-07-26 22:22:20 --> Security Class Initialized
DEBUG - 2018-07-26 22:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 22:22:20 --> CSRF cookie sent
INFO - 2018-07-26 22:22:20 --> Input Class Initialized
INFO - 2018-07-26 22:22:20 --> Language Class Initialized
INFO - 2018-07-26 22:22:20 --> Loader Class Initialized
INFO - 2018-07-26 22:22:20 --> Helper loaded: url_helper
INFO - 2018-07-26 22:22:20 --> Helper loaded: form_helper
INFO - 2018-07-26 22:22:20 --> Helper loaded: language_helper
DEBUG - 2018-07-26 22:22:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 22:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 22:22:20 --> User Agent Class Initialized
INFO - 2018-07-26 22:22:20 --> Controller Class Initialized
INFO - 2018-07-26 22:22:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-26 22:22:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-26 22:22:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-26 22:22:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-26 22:22:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-26 22:22:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-26 22:22:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-07-26 22:22:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-26 22:22:20 --> Final output sent to browser
DEBUG - 2018-07-26 22:22:20 --> Total execution time: 0.0216
INFO - 2018-07-26 22:22:20 --> Config Class Initialized
INFO - 2018-07-26 22:22:20 --> Hooks Class Initialized
DEBUG - 2018-07-26 22:22:20 --> UTF-8 Support Enabled
INFO - 2018-07-26 22:22:20 --> Utf8 Class Initialized
INFO - 2018-07-26 22:22:20 --> URI Class Initialized
INFO - 2018-07-26 22:22:20 --> Router Class Initialized
INFO - 2018-07-26 22:22:20 --> Output Class Initialized
INFO - 2018-07-26 22:22:20 --> Security Class Initialized
DEBUG - 2018-07-26 22:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 22:22:20 --> CSRF cookie sent
INFO - 2018-07-26 22:22:20 --> Input Class Initialized
INFO - 2018-07-26 22:22:20 --> Language Class Initialized
INFO - 2018-07-26 22:22:20 --> Loader Class Initialized
INFO - 2018-07-26 22:22:20 --> Helper loaded: url_helper
INFO - 2018-07-26 22:22:20 --> Helper loaded: form_helper
INFO - 2018-07-26 22:22:20 --> Helper loaded: language_helper
DEBUG - 2018-07-26 22:22:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 22:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 22:22:20 --> User Agent Class Initialized
INFO - 2018-07-26 22:22:20 --> Controller Class Initialized
INFO - 2018-07-26 22:22:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-26 22:22:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-26 22:22:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-26 22:22:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-26 22:22:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-26 22:22:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-26 22:22:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-07-26 22:22:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-26 22:22:20 --> Final output sent to browser
DEBUG - 2018-07-26 22:22:20 --> Total execution time: 0.0232
INFO - 2018-07-26 22:22:21 --> Config Class Initialized
INFO - 2018-07-26 22:22:21 --> Hooks Class Initialized
DEBUG - 2018-07-26 22:22:21 --> UTF-8 Support Enabled
INFO - 2018-07-26 22:22:21 --> Utf8 Class Initialized
INFO - 2018-07-26 22:22:21 --> URI Class Initialized
INFO - 2018-07-26 22:22:21 --> Router Class Initialized
INFO - 2018-07-26 22:22:21 --> Output Class Initialized
INFO - 2018-07-26 22:22:21 --> Security Class Initialized
DEBUG - 2018-07-26 22:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 22:22:21 --> CSRF cookie sent
INFO - 2018-07-26 22:22:21 --> Input Class Initialized
INFO - 2018-07-26 22:22:21 --> Language Class Initialized
INFO - 2018-07-26 22:22:21 --> Loader Class Initialized
INFO - 2018-07-26 22:22:21 --> Helper loaded: url_helper
INFO - 2018-07-26 22:22:21 --> Helper loaded: form_helper
INFO - 2018-07-26 22:22:21 --> Helper loaded: language_helper
DEBUG - 2018-07-26 22:22:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 22:22:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 22:22:21 --> User Agent Class Initialized
INFO - 2018-07-26 22:22:21 --> Controller Class Initialized
INFO - 2018-07-26 22:22:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-26 22:22:21 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-26 22:22:21 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-26 22:22:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-26 22:22:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-26 22:22:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-26 22:22:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-26 22:22:21 --> Could not find the language line "req_email"
INFO - 2018-07-26 22:22:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-26 22:22:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-26 22:22:21 --> Final output sent to browser
DEBUG - 2018-07-26 22:22:21 --> Total execution time: 0.0293
INFO - 2018-07-26 22:22:21 --> Config Class Initialized
INFO - 2018-07-26 22:22:21 --> Hooks Class Initialized
DEBUG - 2018-07-26 22:22:21 --> UTF-8 Support Enabled
INFO - 2018-07-26 22:22:21 --> Utf8 Class Initialized
INFO - 2018-07-26 22:22:21 --> URI Class Initialized
INFO - 2018-07-26 22:22:21 --> Router Class Initialized
INFO - 2018-07-26 22:22:21 --> Output Class Initialized
INFO - 2018-07-26 22:22:21 --> Security Class Initialized
DEBUG - 2018-07-26 22:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 22:22:21 --> CSRF cookie sent
INFO - 2018-07-26 22:22:21 --> Input Class Initialized
INFO - 2018-07-26 22:22:21 --> Language Class Initialized
INFO - 2018-07-26 22:22:21 --> Loader Class Initialized
INFO - 2018-07-26 22:22:21 --> Helper loaded: url_helper
INFO - 2018-07-26 22:22:21 --> Helper loaded: form_helper
INFO - 2018-07-26 22:22:21 --> Helper loaded: language_helper
DEBUG - 2018-07-26 22:22:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 22:22:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 22:22:21 --> User Agent Class Initialized
INFO - 2018-07-26 22:22:21 --> Controller Class Initialized
INFO - 2018-07-26 22:22:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-26 22:22:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-26 22:22:21 --> Pixel_Model class loaded
INFO - 2018-07-26 22:22:21 --> Database Driver Class Initialized
INFO - 2018-07-26 22:22:21 --> Model "QuestionsModel" initialized
INFO - 2018-07-26 22:22:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-26 22:22:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-26 22:22:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-26 22:22:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-26 22:22:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/buy_gift.php
INFO - 2018-07-26 22:22:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-26 22:22:21 --> Final output sent to browser
DEBUG - 2018-07-26 22:22:21 --> Total execution time: 0.0351

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-07-28 00:02:12 --> Config Class Initialized
INFO - 2018-07-28 00:02:12 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:02:12 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:02:12 --> Utf8 Class Initialized
INFO - 2018-07-28 00:02:12 --> URI Class Initialized
DEBUG - 2018-07-28 00:02:12 --> No URI present. Default controller set.
INFO - 2018-07-28 00:02:12 --> Router Class Initialized
INFO - 2018-07-28 00:02:12 --> Output Class Initialized
INFO - 2018-07-28 00:02:12 --> Security Class Initialized
DEBUG - 2018-07-28 00:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:02:12 --> CSRF cookie sent
INFO - 2018-07-28 00:02:12 --> Input Class Initialized
INFO - 2018-07-28 00:02:12 --> Language Class Initialized
INFO - 2018-07-28 00:02:12 --> Loader Class Initialized
INFO - 2018-07-28 00:02:12 --> Helper loaded: url_helper
INFO - 2018-07-28 00:02:12 --> Helper loaded: form_helper
INFO - 2018-07-28 00:02:12 --> Helper loaded: language_helper
DEBUG - 2018-07-28 00:02:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 00:02:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 00:02:12 --> User Agent Class Initialized
INFO - 2018-07-28 00:02:12 --> Controller Class Initialized
INFO - 2018-07-28 00:02:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-28 00:02:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-28 00:02:12 --> Pixel_Model class loaded
INFO - 2018-07-28 00:02:12 --> Database Driver Class Initialized
INFO - 2018-07-28 00:02:12 --> Model "QuestionsModel" initialized
INFO - 2018-07-28 00:02:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-28 00:02:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-28 00:02:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-28 00:02:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-28 00:02:12 --> Final output sent to browser
DEBUG - 2018-07-28 00:02:12 --> Total execution time: 0.0363
INFO - 2018-07-28 01:32:24 --> Config Class Initialized
INFO - 2018-07-28 01:32:24 --> Hooks Class Initialized
DEBUG - 2018-07-28 01:32:24 --> UTF-8 Support Enabled
INFO - 2018-07-28 01:32:24 --> Utf8 Class Initialized
INFO - 2018-07-28 01:32:24 --> URI Class Initialized
DEBUG - 2018-07-28 01:32:24 --> No URI present. Default controller set.
INFO - 2018-07-28 01:32:24 --> Router Class Initialized
INFO - 2018-07-28 01:32:24 --> Output Class Initialized
INFO - 2018-07-28 01:32:24 --> Security Class Initialized
DEBUG - 2018-07-28 01:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 01:32:24 --> CSRF cookie sent
INFO - 2018-07-28 01:32:24 --> Input Class Initialized
INFO - 2018-07-28 01:32:24 --> Language Class Initialized
INFO - 2018-07-28 01:32:24 --> Loader Class Initialized
INFO - 2018-07-28 01:32:24 --> Helper loaded: url_helper
INFO - 2018-07-28 01:32:24 --> Helper loaded: form_helper
INFO - 2018-07-28 01:32:24 --> Helper loaded: language_helper
DEBUG - 2018-07-28 01:32:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 01:32:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 01:32:24 --> User Agent Class Initialized
INFO - 2018-07-28 01:32:24 --> Controller Class Initialized
INFO - 2018-07-28 01:32:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-28 01:32:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-28 01:32:24 --> Pixel_Model class loaded
INFO - 2018-07-28 01:32:24 --> Database Driver Class Initialized
INFO - 2018-07-28 01:32:24 --> Model "QuestionsModel" initialized
INFO - 2018-07-28 01:32:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-28 01:32:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-28 01:32:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-28 01:32:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-28 01:32:24 --> Final output sent to browser
DEBUG - 2018-07-28 01:32:24 --> Total execution time: 0.0303
INFO - 2018-07-28 01:50:13 --> Config Class Initialized
INFO - 2018-07-28 01:50:13 --> Hooks Class Initialized
DEBUG - 2018-07-28 01:50:13 --> UTF-8 Support Enabled
INFO - 2018-07-28 01:50:13 --> Utf8 Class Initialized
INFO - 2018-07-28 01:50:13 --> URI Class Initialized
DEBUG - 2018-07-28 01:50:13 --> No URI present. Default controller set.
INFO - 2018-07-28 01:50:13 --> Router Class Initialized
INFO - 2018-07-28 01:50:13 --> Output Class Initialized
INFO - 2018-07-28 01:50:13 --> Security Class Initialized
DEBUG - 2018-07-28 01:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 01:50:13 --> CSRF cookie sent
INFO - 2018-07-28 01:50:13 --> Input Class Initialized
INFO - 2018-07-28 01:50:13 --> Language Class Initialized
INFO - 2018-07-28 01:50:13 --> Loader Class Initialized
INFO - 2018-07-28 01:50:13 --> Helper loaded: url_helper
INFO - 2018-07-28 01:50:13 --> Helper loaded: form_helper
INFO - 2018-07-28 01:50:13 --> Helper loaded: language_helper
DEBUG - 2018-07-28 01:50:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 01:50:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 01:50:13 --> User Agent Class Initialized
INFO - 2018-07-28 01:50:13 --> Controller Class Initialized
INFO - 2018-07-28 01:50:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-28 01:50:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-28 01:50:13 --> Pixel_Model class loaded
INFO - 2018-07-28 01:50:13 --> Database Driver Class Initialized
INFO - 2018-07-28 01:50:13 --> Model "QuestionsModel" initialized
INFO - 2018-07-28 01:50:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-28 01:50:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-28 01:50:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-28 01:50:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-28 01:50:13 --> Final output sent to browser
DEBUG - 2018-07-28 01:50:13 --> Total execution time: 0.0375
INFO - 2018-07-28 02:08:30 --> Config Class Initialized
INFO - 2018-07-28 02:08:30 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:08:30 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:08:30 --> Utf8 Class Initialized
INFO - 2018-07-28 02:08:30 --> URI Class Initialized
INFO - 2018-07-28 02:08:30 --> Router Class Initialized
INFO - 2018-07-28 02:08:30 --> Output Class Initialized
INFO - 2018-07-28 02:08:30 --> Security Class Initialized
DEBUG - 2018-07-28 02:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:08:30 --> CSRF cookie sent
INFO - 2018-07-28 02:08:30 --> Input Class Initialized
INFO - 2018-07-28 02:08:30 --> Language Class Initialized
INFO - 2018-07-28 02:08:30 --> Loader Class Initialized
INFO - 2018-07-28 02:08:30 --> Helper loaded: url_helper
INFO - 2018-07-28 02:08:30 --> Helper loaded: form_helper
INFO - 2018-07-28 02:08:30 --> Helper loaded: language_helper
DEBUG - 2018-07-28 02:08:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 02:08:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 02:08:30 --> User Agent Class Initialized
INFO - 2018-07-28 02:08:30 --> Controller Class Initialized
INFO - 2018-07-28 02:08:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-28 02:08:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-28 02:08:30 --> Config Class Initialized
INFO - 2018-07-28 02:08:30 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:08:30 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:08:30 --> Utf8 Class Initialized
INFO - 2018-07-28 02:08:30 --> URI Class Initialized
DEBUG - 2018-07-28 02:08:30 --> No URI present. Default controller set.
INFO - 2018-07-28 02:08:30 --> Router Class Initialized
INFO - 2018-07-28 02:08:30 --> Output Class Initialized
INFO - 2018-07-28 02:08:30 --> Security Class Initialized
DEBUG - 2018-07-28 02:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:08:30 --> CSRF cookie sent
INFO - 2018-07-28 02:08:30 --> Input Class Initialized
INFO - 2018-07-28 02:08:30 --> Language Class Initialized
INFO - 2018-07-28 02:08:30 --> Loader Class Initialized
INFO - 2018-07-28 02:08:30 --> Helper loaded: url_helper
INFO - 2018-07-28 02:08:30 --> Helper loaded: form_helper
INFO - 2018-07-28 02:08:30 --> Helper loaded: language_helper
DEBUG - 2018-07-28 02:08:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 02:08:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 02:08:30 --> User Agent Class Initialized
INFO - 2018-07-28 02:08:30 --> Controller Class Initialized
INFO - 2018-07-28 02:08:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-28 02:08:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-28 02:08:30 --> Pixel_Model class loaded
INFO - 2018-07-28 02:08:30 --> Database Driver Class Initialized
INFO - 2018-07-28 02:08:30 --> Model "QuestionsModel" initialized
INFO - 2018-07-28 02:08:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-28 02:08:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-28 02:08:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-28 02:08:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-28 02:08:30 --> Final output sent to browser
DEBUG - 2018-07-28 02:08:30 --> Total execution time: 0.0358
INFO - 2018-07-28 09:49:46 --> Config Class Initialized
INFO - 2018-07-28 09:49:46 --> Hooks Class Initialized
DEBUG - 2018-07-28 09:49:46 --> UTF-8 Support Enabled
INFO - 2018-07-28 09:49:46 --> Utf8 Class Initialized
INFO - 2018-07-28 09:49:46 --> URI Class Initialized
DEBUG - 2018-07-28 09:49:46 --> No URI present. Default controller set.
INFO - 2018-07-28 09:49:46 --> Router Class Initialized
INFO - 2018-07-28 09:49:46 --> Output Class Initialized
INFO - 2018-07-28 09:49:46 --> Security Class Initialized
DEBUG - 2018-07-28 09:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 09:49:46 --> CSRF cookie sent
INFO - 2018-07-28 09:49:46 --> Input Class Initialized
INFO - 2018-07-28 09:49:46 --> Language Class Initialized
INFO - 2018-07-28 09:49:46 --> Loader Class Initialized
INFO - 2018-07-28 09:49:46 --> Helper loaded: url_helper
INFO - 2018-07-28 09:49:46 --> Helper loaded: form_helper
INFO - 2018-07-28 09:49:46 --> Helper loaded: language_helper
DEBUG - 2018-07-28 09:49:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 09:49:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 09:49:46 --> User Agent Class Initialized
INFO - 2018-07-28 09:49:46 --> Controller Class Initialized
INFO - 2018-07-28 09:49:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-28 09:49:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-28 09:49:46 --> Pixel_Model class loaded
INFO - 2018-07-28 09:49:46 --> Database Driver Class Initialized
INFO - 2018-07-28 09:49:46 --> Model "QuestionsModel" initialized
INFO - 2018-07-28 09:49:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-28 09:49:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-28 09:49:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-28 09:49:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-28 09:49:46 --> Final output sent to browser
DEBUG - 2018-07-28 09:49:46 --> Total execution time: 0.0327
INFO - 2018-07-28 10:33:44 --> Config Class Initialized
INFO - 2018-07-28 10:33:44 --> Hooks Class Initialized
DEBUG - 2018-07-28 10:33:44 --> UTF-8 Support Enabled
INFO - 2018-07-28 10:33:44 --> Utf8 Class Initialized
INFO - 2018-07-28 10:33:44 --> URI Class Initialized
DEBUG - 2018-07-28 10:33:44 --> No URI present. Default controller set.
INFO - 2018-07-28 10:33:44 --> Router Class Initialized
INFO - 2018-07-28 10:33:44 --> Output Class Initialized
INFO - 2018-07-28 10:33:44 --> Security Class Initialized
DEBUG - 2018-07-28 10:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 10:33:44 --> CSRF cookie sent
INFO - 2018-07-28 10:33:44 --> Input Class Initialized
INFO - 2018-07-28 10:33:44 --> Language Class Initialized
INFO - 2018-07-28 10:33:44 --> Loader Class Initialized
INFO - 2018-07-28 10:33:44 --> Helper loaded: url_helper
INFO - 2018-07-28 10:33:44 --> Helper loaded: form_helper
INFO - 2018-07-28 10:33:44 --> Helper loaded: language_helper
DEBUG - 2018-07-28 10:33:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 10:33:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 10:33:44 --> User Agent Class Initialized
INFO - 2018-07-28 10:33:44 --> Controller Class Initialized
INFO - 2018-07-28 10:33:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-28 10:33:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-28 10:33:44 --> Pixel_Model class loaded
INFO - 2018-07-28 10:33:44 --> Database Driver Class Initialized
INFO - 2018-07-28 10:33:44 --> Model "QuestionsModel" initialized
INFO - 2018-07-28 10:33:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-28 10:33:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-28 10:33:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-28 10:33:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-28 10:33:44 --> Final output sent to browser
DEBUG - 2018-07-28 10:33:44 --> Total execution time: 0.0405
INFO - 2018-07-28 11:11:14 --> Config Class Initialized
INFO - 2018-07-28 11:11:14 --> Hooks Class Initialized
DEBUG - 2018-07-28 11:11:14 --> UTF-8 Support Enabled
INFO - 2018-07-28 11:11:14 --> Utf8 Class Initialized
INFO - 2018-07-28 11:11:14 --> URI Class Initialized
DEBUG - 2018-07-28 11:11:14 --> No URI present. Default controller set.
INFO - 2018-07-28 11:11:14 --> Router Class Initialized
INFO - 2018-07-28 11:11:14 --> Output Class Initialized
INFO - 2018-07-28 11:11:14 --> Security Class Initialized
DEBUG - 2018-07-28 11:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 11:11:14 --> CSRF cookie sent
INFO - 2018-07-28 11:11:14 --> Input Class Initialized
INFO - 2018-07-28 11:11:14 --> Language Class Initialized
INFO - 2018-07-28 11:11:14 --> Loader Class Initialized
INFO - 2018-07-28 11:11:14 --> Helper loaded: url_helper
INFO - 2018-07-28 11:11:14 --> Helper loaded: form_helper
INFO - 2018-07-28 11:11:14 --> Helper loaded: language_helper
DEBUG - 2018-07-28 11:11:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 11:11:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 11:11:14 --> User Agent Class Initialized
INFO - 2018-07-28 11:11:14 --> Controller Class Initialized
INFO - 2018-07-28 11:11:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-28 11:11:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-28 11:11:14 --> Pixel_Model class loaded
INFO - 2018-07-28 11:11:14 --> Database Driver Class Initialized
INFO - 2018-07-28 11:11:14 --> Model "QuestionsModel" initialized
INFO - 2018-07-28 11:11:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-28 11:11:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-28 11:11:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-28 11:11:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-28 11:11:14 --> Final output sent to browser
DEBUG - 2018-07-28 11:11:14 --> Total execution time: 0.0361
INFO - 2018-07-28 11:11:19 --> Config Class Initialized
INFO - 2018-07-28 11:11:19 --> Hooks Class Initialized
DEBUG - 2018-07-28 11:11:19 --> UTF-8 Support Enabled
INFO - 2018-07-28 11:11:19 --> Utf8 Class Initialized
INFO - 2018-07-28 11:11:19 --> URI Class Initialized
INFO - 2018-07-28 11:11:19 --> Router Class Initialized
INFO - 2018-07-28 11:11:19 --> Output Class Initialized
INFO - 2018-07-28 11:11:19 --> Security Class Initialized
DEBUG - 2018-07-28 11:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 11:11:19 --> CSRF cookie sent
INFO - 2018-07-28 11:11:19 --> Input Class Initialized
INFO - 2018-07-28 11:11:19 --> Language Class Initialized
ERROR - 2018-07-28 11:11:19 --> 404 Page Not Found: Apple-touch-icon-120x120-precomposedpng/index
INFO - 2018-07-28 11:11:19 --> Config Class Initialized
INFO - 2018-07-28 11:11:19 --> Hooks Class Initialized
DEBUG - 2018-07-28 11:11:19 --> UTF-8 Support Enabled
INFO - 2018-07-28 11:11:19 --> Utf8 Class Initialized
INFO - 2018-07-28 11:11:19 --> URI Class Initialized
INFO - 2018-07-28 11:11:19 --> Router Class Initialized
INFO - 2018-07-28 11:11:19 --> Output Class Initialized
INFO - 2018-07-28 11:11:19 --> Security Class Initialized
DEBUG - 2018-07-28 11:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 11:11:19 --> CSRF cookie sent
INFO - 2018-07-28 11:11:19 --> Input Class Initialized
INFO - 2018-07-28 11:11:19 --> Language Class Initialized
ERROR - 2018-07-28 11:11:19 --> 404 Page Not Found: Apple-touch-icon-120x120png/index
INFO - 2018-07-28 11:11:19 --> Config Class Initialized
INFO - 2018-07-28 11:11:19 --> Hooks Class Initialized
DEBUG - 2018-07-28 11:11:19 --> UTF-8 Support Enabled
INFO - 2018-07-28 11:11:19 --> Utf8 Class Initialized
INFO - 2018-07-28 11:11:19 --> URI Class Initialized
INFO - 2018-07-28 11:11:19 --> Router Class Initialized
INFO - 2018-07-28 11:11:19 --> Output Class Initialized
INFO - 2018-07-28 11:11:19 --> Security Class Initialized
DEBUG - 2018-07-28 11:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 11:11:19 --> CSRF cookie sent
INFO - 2018-07-28 11:11:19 --> Input Class Initialized
INFO - 2018-07-28 11:11:19 --> Language Class Initialized
ERROR - 2018-07-28 11:11:19 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
INFO - 2018-07-28 11:11:20 --> Config Class Initialized
INFO - 2018-07-28 11:11:20 --> Hooks Class Initialized
DEBUG - 2018-07-28 11:11:20 --> UTF-8 Support Enabled
INFO - 2018-07-28 11:11:20 --> Utf8 Class Initialized
INFO - 2018-07-28 11:11:20 --> URI Class Initialized
INFO - 2018-07-28 11:11:20 --> Router Class Initialized
INFO - 2018-07-28 11:11:20 --> Output Class Initialized
INFO - 2018-07-28 11:11:20 --> Security Class Initialized
DEBUG - 2018-07-28 11:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 11:11:20 --> CSRF cookie sent
INFO - 2018-07-28 11:11:20 --> Input Class Initialized
INFO - 2018-07-28 11:11:20 --> Language Class Initialized
ERROR - 2018-07-28 11:11:20 --> 404 Page Not Found: Apple-touch-iconpng/index
INFO - 2018-07-28 11:11:30 --> Config Class Initialized
INFO - 2018-07-28 11:11:30 --> Hooks Class Initialized
DEBUG - 2018-07-28 11:11:30 --> UTF-8 Support Enabled
INFO - 2018-07-28 11:11:30 --> Utf8 Class Initialized
INFO - 2018-07-28 11:11:30 --> URI Class Initialized
INFO - 2018-07-28 11:11:30 --> Router Class Initialized
INFO - 2018-07-28 11:11:30 --> Output Class Initialized
INFO - 2018-07-28 11:11:30 --> Security Class Initialized
DEBUG - 2018-07-28 11:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 11:11:30 --> CSRF cookie sent
INFO - 2018-07-28 11:11:30 --> CSRF token verified
INFO - 2018-07-28 11:11:30 --> Input Class Initialized
INFO - 2018-07-28 11:11:30 --> Language Class Initialized
INFO - 2018-07-28 11:11:30 --> Loader Class Initialized
INFO - 2018-07-28 11:11:30 --> Helper loaded: url_helper
INFO - 2018-07-28 11:11:30 --> Helper loaded: form_helper
INFO - 2018-07-28 11:11:30 --> Helper loaded: language_helper
DEBUG - 2018-07-28 11:11:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 11:11:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 11:11:30 --> User Agent Class Initialized
INFO - 2018-07-28 11:11:30 --> Controller Class Initialized
INFO - 2018-07-28 11:11:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-28 11:11:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-28 11:11:30 --> Pixel_Model class loaded
INFO - 2018-07-28 11:11:30 --> Database Driver Class Initialized
INFO - 2018-07-28 11:11:30 --> Model "QuestionsModel" initialized
INFO - 2018-07-28 11:11:30 --> Config Class Initialized
INFO - 2018-07-28 11:11:30 --> Hooks Class Initialized
DEBUG - 2018-07-28 11:11:30 --> UTF-8 Support Enabled
INFO - 2018-07-28 11:11:30 --> Utf8 Class Initialized
INFO - 2018-07-28 11:11:30 --> URI Class Initialized
INFO - 2018-07-28 11:11:30 --> Router Class Initialized
INFO - 2018-07-28 11:11:30 --> Output Class Initialized
INFO - 2018-07-28 11:11:30 --> Security Class Initialized
DEBUG - 2018-07-28 11:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 11:11:30 --> CSRF cookie sent
INFO - 2018-07-28 11:11:30 --> Input Class Initialized
INFO - 2018-07-28 11:11:30 --> Language Class Initialized
INFO - 2018-07-28 11:11:30 --> Loader Class Initialized
INFO - 2018-07-28 11:11:30 --> Helper loaded: url_helper
INFO - 2018-07-28 11:11:30 --> Helper loaded: form_helper
INFO - 2018-07-28 11:11:30 --> Helper loaded: language_helper
DEBUG - 2018-07-28 11:11:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 11:11:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 11:11:30 --> User Agent Class Initialized
INFO - 2018-07-28 11:11:30 --> Controller Class Initialized
INFO - 2018-07-28 11:11:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-28 11:11:30 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-28 11:11:30 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-28 11:11:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-28 11:11:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-28 11:11:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-28 11:11:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-28 11:11:30 --> Could not find the language line "req_email"
INFO - 2018-07-28 11:11:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-28 11:11:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-28 11:11:30 --> Final output sent to browser
DEBUG - 2018-07-28 11:11:30 --> Total execution time: 0.0272
INFO - 2018-07-28 11:11:41 --> Config Class Initialized
INFO - 2018-07-28 11:11:41 --> Hooks Class Initialized
DEBUG - 2018-07-28 11:11:41 --> UTF-8 Support Enabled
INFO - 2018-07-28 11:11:41 --> Utf8 Class Initialized
INFO - 2018-07-28 11:11:41 --> URI Class Initialized
INFO - 2018-07-28 11:11:41 --> Router Class Initialized
INFO - 2018-07-28 11:11:41 --> Output Class Initialized
INFO - 2018-07-28 11:11:41 --> Security Class Initialized
DEBUG - 2018-07-28 11:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 11:11:41 --> CSRF cookie sent
INFO - 2018-07-28 11:11:41 --> Input Class Initialized
INFO - 2018-07-28 11:11:41 --> Language Class Initialized
INFO - 2018-07-28 11:11:41 --> Loader Class Initialized
INFO - 2018-07-28 11:11:41 --> Helper loaded: url_helper
INFO - 2018-07-28 11:11:41 --> Helper loaded: form_helper
INFO - 2018-07-28 11:11:41 --> Helper loaded: language_helper
DEBUG - 2018-07-28 11:11:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 11:11:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 11:11:41 --> User Agent Class Initialized
INFO - 2018-07-28 11:11:41 --> Controller Class Initialized
INFO - 2018-07-28 11:11:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-28 11:11:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-28 11:11:41 --> Pixel_Model class loaded
INFO - 2018-07-28 11:11:41 --> Database Driver Class Initialized
INFO - 2018-07-28 11:11:41 --> Model "QuestionsModel" initialized
INFO - 2018-07-28 11:11:41 --> Config Class Initialized
INFO - 2018-07-28 11:11:41 --> Hooks Class Initialized
DEBUG - 2018-07-28 11:11:41 --> UTF-8 Support Enabled
INFO - 2018-07-28 11:11:41 --> Utf8 Class Initialized
INFO - 2018-07-28 11:11:41 --> URI Class Initialized
INFO - 2018-07-28 11:11:41 --> Router Class Initialized
INFO - 2018-07-28 11:11:41 --> Output Class Initialized
INFO - 2018-07-28 11:11:41 --> Security Class Initialized
DEBUG - 2018-07-28 11:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 11:11:41 --> CSRF cookie sent
INFO - 2018-07-28 11:11:41 --> Input Class Initialized
INFO - 2018-07-28 11:11:41 --> Language Class Initialized
INFO - 2018-07-28 11:11:41 --> Loader Class Initialized
INFO - 2018-07-28 11:11:41 --> Helper loaded: url_helper
INFO - 2018-07-28 11:11:41 --> Helper loaded: form_helper
INFO - 2018-07-28 11:11:41 --> Helper loaded: language_helper
DEBUG - 2018-07-28 11:11:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 11:11:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 11:11:41 --> User Agent Class Initialized
INFO - 2018-07-28 11:11:41 --> Controller Class Initialized
INFO - 2018-07-28 11:11:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-28 11:11:41 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-28 11:11:41 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-28 11:11:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-28 11:11:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-28 11:11:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-28 11:11:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-28 11:11:41 --> Could not find the language line "req_email"
INFO - 2018-07-28 11:11:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-28 11:11:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-28 11:11:41 --> Final output sent to browser
DEBUG - 2018-07-28 11:11:41 --> Total execution time: 0.0216
INFO - 2018-07-28 11:11:49 --> Config Class Initialized
INFO - 2018-07-28 11:11:49 --> Hooks Class Initialized
DEBUG - 2018-07-28 11:11:49 --> UTF-8 Support Enabled
INFO - 2018-07-28 11:11:49 --> Utf8 Class Initialized
INFO - 2018-07-28 11:11:49 --> URI Class Initialized
INFO - 2018-07-28 11:11:49 --> Router Class Initialized
INFO - 2018-07-28 11:11:49 --> Output Class Initialized
INFO - 2018-07-28 11:11:49 --> Security Class Initialized
DEBUG - 2018-07-28 11:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 11:11:49 --> CSRF cookie sent
INFO - 2018-07-28 11:11:49 --> Input Class Initialized
INFO - 2018-07-28 11:11:49 --> Language Class Initialized
INFO - 2018-07-28 11:11:49 --> Loader Class Initialized
INFO - 2018-07-28 11:11:49 --> Helper loaded: url_helper
INFO - 2018-07-28 11:11:49 --> Helper loaded: form_helper
INFO - 2018-07-28 11:11:49 --> Helper loaded: language_helper
DEBUG - 2018-07-28 11:11:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 11:11:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 11:11:49 --> User Agent Class Initialized
INFO - 2018-07-28 11:11:49 --> Controller Class Initialized
INFO - 2018-07-28 11:11:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-28 11:11:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-28 11:11:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-28 11:11:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-28 11:11:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-28 11:11:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-28 11:11:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-07-28 11:11:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-28 11:11:49 --> Final output sent to browser
DEBUG - 2018-07-28 11:11:49 --> Total execution time: 0.0230
INFO - 2018-07-28 15:22:38 --> Config Class Initialized
INFO - 2018-07-28 15:22:38 --> Hooks Class Initialized
DEBUG - 2018-07-28 15:22:38 --> UTF-8 Support Enabled
INFO - 2018-07-28 15:22:38 --> Utf8 Class Initialized
INFO - 2018-07-28 15:22:38 --> URI Class Initialized
INFO - 2018-07-28 15:22:38 --> Router Class Initialized
INFO - 2018-07-28 15:22:38 --> Output Class Initialized
INFO - 2018-07-28 15:22:38 --> Security Class Initialized
DEBUG - 2018-07-28 15:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 15:22:38 --> CSRF cookie sent
INFO - 2018-07-28 15:22:38 --> Input Class Initialized
INFO - 2018-07-28 15:22:38 --> Language Class Initialized
ERROR - 2018-07-28 15:22:38 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-28 15:22:38 --> Config Class Initialized
INFO - 2018-07-28 15:22:38 --> Hooks Class Initialized
DEBUG - 2018-07-28 15:22:38 --> UTF-8 Support Enabled
INFO - 2018-07-28 15:22:38 --> Utf8 Class Initialized
INFO - 2018-07-28 15:22:38 --> URI Class Initialized
DEBUG - 2018-07-28 15:22:38 --> No URI present. Default controller set.
INFO - 2018-07-28 15:22:38 --> Router Class Initialized
INFO - 2018-07-28 15:22:38 --> Output Class Initialized
INFO - 2018-07-28 15:22:38 --> Security Class Initialized
DEBUG - 2018-07-28 15:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 15:22:38 --> CSRF cookie sent
INFO - 2018-07-28 15:22:38 --> Input Class Initialized
INFO - 2018-07-28 15:22:38 --> Language Class Initialized
INFO - 2018-07-28 15:22:38 --> Loader Class Initialized
INFO - 2018-07-28 15:22:38 --> Helper loaded: url_helper
INFO - 2018-07-28 15:22:38 --> Helper loaded: form_helper
INFO - 2018-07-28 15:22:38 --> Helper loaded: language_helper
DEBUG - 2018-07-28 15:22:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 15:22:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 15:22:38 --> User Agent Class Initialized
INFO - 2018-07-28 15:22:38 --> Controller Class Initialized
INFO - 2018-07-28 15:22:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-28 15:22:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-28 15:22:38 --> Pixel_Model class loaded
INFO - 2018-07-28 15:22:38 --> Database Driver Class Initialized
INFO - 2018-07-28 15:22:38 --> Model "QuestionsModel" initialized
INFO - 2018-07-28 15:22:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-28 15:22:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-28 15:22:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-28 15:22:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-28 15:22:38 --> Final output sent to browser
DEBUG - 2018-07-28 15:22:38 --> Total execution time: 0.0330
INFO - 2018-07-28 15:22:38 --> Config Class Initialized
INFO - 2018-07-28 15:22:38 --> Hooks Class Initialized
DEBUG - 2018-07-28 15:22:38 --> UTF-8 Support Enabled
INFO - 2018-07-28 15:22:38 --> Utf8 Class Initialized
INFO - 2018-07-28 15:22:38 --> URI Class Initialized
DEBUG - 2018-07-28 15:22:38 --> No URI present. Default controller set.
INFO - 2018-07-28 15:22:38 --> Router Class Initialized
INFO - 2018-07-28 15:22:38 --> Output Class Initialized
INFO - 2018-07-28 15:22:38 --> Security Class Initialized
DEBUG - 2018-07-28 15:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 15:22:38 --> CSRF cookie sent
INFO - 2018-07-28 15:22:38 --> Input Class Initialized
INFO - 2018-07-28 15:22:38 --> Language Class Initialized
INFO - 2018-07-28 15:22:38 --> Loader Class Initialized
INFO - 2018-07-28 15:22:38 --> Helper loaded: url_helper
INFO - 2018-07-28 15:22:38 --> Helper loaded: form_helper
INFO - 2018-07-28 15:22:38 --> Helper loaded: language_helper
DEBUG - 2018-07-28 15:22:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 15:22:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 15:22:38 --> User Agent Class Initialized
INFO - 2018-07-28 15:22:38 --> Controller Class Initialized
INFO - 2018-07-28 15:22:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-28 15:22:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-28 15:22:38 --> Pixel_Model class loaded
INFO - 2018-07-28 15:22:38 --> Database Driver Class Initialized
INFO - 2018-07-28 15:22:38 --> Model "QuestionsModel" initialized
INFO - 2018-07-28 15:22:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-28 15:22:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-28 15:22:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-28 15:22:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-28 15:22:38 --> Final output sent to browser
DEBUG - 2018-07-28 15:22:38 --> Total execution time: 0.0250
INFO - 2018-07-28 17:50:20 --> Config Class Initialized
INFO - 2018-07-28 17:50:20 --> Hooks Class Initialized
DEBUG - 2018-07-28 17:50:20 --> UTF-8 Support Enabled
INFO - 2018-07-28 17:50:20 --> Utf8 Class Initialized
INFO - 2018-07-28 17:50:20 --> URI Class Initialized
DEBUG - 2018-07-28 17:50:20 --> No URI present. Default controller set.
INFO - 2018-07-28 17:50:20 --> Router Class Initialized
INFO - 2018-07-28 17:50:20 --> Output Class Initialized
INFO - 2018-07-28 17:50:20 --> Security Class Initialized
DEBUG - 2018-07-28 17:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 17:50:20 --> CSRF cookie sent
INFO - 2018-07-28 17:50:20 --> Input Class Initialized
INFO - 2018-07-28 17:50:20 --> Language Class Initialized
INFO - 2018-07-28 17:50:20 --> Loader Class Initialized
INFO - 2018-07-28 17:50:20 --> Helper loaded: url_helper
INFO - 2018-07-28 17:50:20 --> Helper loaded: form_helper
INFO - 2018-07-28 17:50:20 --> Helper loaded: language_helper
DEBUG - 2018-07-28 17:50:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 17:50:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 17:50:20 --> User Agent Class Initialized
INFO - 2018-07-28 17:50:20 --> Controller Class Initialized
INFO - 2018-07-28 17:50:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-28 17:50:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-28 17:50:20 --> Pixel_Model class loaded
INFO - 2018-07-28 17:50:20 --> Database Driver Class Initialized
INFO - 2018-07-28 17:50:20 --> Model "QuestionsModel" initialized
INFO - 2018-07-28 17:50:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-28 17:50:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-28 17:50:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-28 17:50:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-28 17:50:20 --> Final output sent to browser
DEBUG - 2018-07-28 17:50:20 --> Total execution time: 0.0344
INFO - 2018-07-28 18:15:31 --> Config Class Initialized
INFO - 2018-07-28 18:15:31 --> Hooks Class Initialized
DEBUG - 2018-07-28 18:15:31 --> UTF-8 Support Enabled
INFO - 2018-07-28 18:15:31 --> Utf8 Class Initialized
INFO - 2018-07-28 18:15:31 --> URI Class Initialized
INFO - 2018-07-28 18:15:31 --> Router Class Initialized
INFO - 2018-07-28 18:15:31 --> Output Class Initialized
INFO - 2018-07-28 18:15:31 --> Security Class Initialized
DEBUG - 2018-07-28 18:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 18:15:31 --> CSRF cookie sent
INFO - 2018-07-28 18:15:31 --> Input Class Initialized
INFO - 2018-07-28 18:15:31 --> Language Class Initialized
ERROR - 2018-07-28 18:15:31 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-28 19:46:35 --> Config Class Initialized
INFO - 2018-07-28 19:46:35 --> Hooks Class Initialized
DEBUG - 2018-07-28 19:46:35 --> UTF-8 Support Enabled
INFO - 2018-07-28 19:46:35 --> Utf8 Class Initialized
INFO - 2018-07-28 19:46:35 --> URI Class Initialized
DEBUG - 2018-07-28 19:46:35 --> No URI present. Default controller set.
INFO - 2018-07-28 19:46:35 --> Router Class Initialized
INFO - 2018-07-28 19:46:35 --> Output Class Initialized
INFO - 2018-07-28 19:46:35 --> Security Class Initialized
DEBUG - 2018-07-28 19:46:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 19:46:35 --> CSRF cookie sent
INFO - 2018-07-28 19:46:35 --> Input Class Initialized
INFO - 2018-07-28 19:46:35 --> Language Class Initialized
INFO - 2018-07-28 19:46:35 --> Loader Class Initialized
INFO - 2018-07-28 19:46:35 --> Helper loaded: url_helper
INFO - 2018-07-28 19:46:35 --> Helper loaded: form_helper
INFO - 2018-07-28 19:46:35 --> Helper loaded: language_helper
DEBUG - 2018-07-28 19:46:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 19:46:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 19:46:35 --> User Agent Class Initialized
INFO - 2018-07-28 19:46:35 --> Controller Class Initialized
INFO - 2018-07-28 19:46:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-28 19:46:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-28 19:46:35 --> Pixel_Model class loaded
INFO - 2018-07-28 19:46:35 --> Database Driver Class Initialized
INFO - 2018-07-28 19:46:35 --> Model "QuestionsModel" initialized
INFO - 2018-07-28 19:46:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-28 19:46:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-28 19:46:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-28 19:46:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-28 19:46:35 --> Final output sent to browser
DEBUG - 2018-07-28 19:46:35 --> Total execution time: 0.0336
INFO - 2018-07-28 19:58:24 --> Config Class Initialized
INFO - 2018-07-28 19:58:24 --> Hooks Class Initialized
DEBUG - 2018-07-28 19:58:24 --> UTF-8 Support Enabled
INFO - 2018-07-28 19:58:24 --> Utf8 Class Initialized
INFO - 2018-07-28 19:58:24 --> URI Class Initialized
DEBUG - 2018-07-28 19:58:24 --> No URI present. Default controller set.
INFO - 2018-07-28 19:58:24 --> Router Class Initialized
INFO - 2018-07-28 19:58:24 --> Output Class Initialized
INFO - 2018-07-28 19:58:24 --> Security Class Initialized
DEBUG - 2018-07-28 19:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 19:58:24 --> CSRF cookie sent
INFO - 2018-07-28 19:58:24 --> Input Class Initialized
INFO - 2018-07-28 19:58:24 --> Language Class Initialized
INFO - 2018-07-28 19:58:24 --> Loader Class Initialized
INFO - 2018-07-28 19:58:24 --> Helper loaded: url_helper
INFO - 2018-07-28 19:58:24 --> Helper loaded: form_helper
INFO - 2018-07-28 19:58:24 --> Helper loaded: language_helper
DEBUG - 2018-07-28 19:58:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 19:58:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 19:58:24 --> User Agent Class Initialized
INFO - 2018-07-28 19:58:24 --> Controller Class Initialized
INFO - 2018-07-28 19:58:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-28 19:58:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-28 19:58:24 --> Pixel_Model class loaded
INFO - 2018-07-28 19:58:24 --> Database Driver Class Initialized
INFO - 2018-07-28 19:58:24 --> Model "QuestionsModel" initialized
INFO - 2018-07-28 19:58:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-28 19:58:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-28 19:58:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-28 19:58:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-28 19:58:24 --> Final output sent to browser
DEBUG - 2018-07-28 19:58:24 --> Total execution time: 0.0354
INFO - 2018-07-28 22:56:47 --> Config Class Initialized
INFO - 2018-07-28 22:56:47 --> Hooks Class Initialized
DEBUG - 2018-07-28 22:56:47 --> UTF-8 Support Enabled
INFO - 2018-07-28 22:56:47 --> Utf8 Class Initialized
INFO - 2018-07-28 22:56:47 --> URI Class Initialized
DEBUG - 2018-07-28 22:56:47 --> No URI present. Default controller set.
INFO - 2018-07-28 22:56:47 --> Router Class Initialized
INFO - 2018-07-28 22:56:47 --> Output Class Initialized
INFO - 2018-07-28 22:56:47 --> Security Class Initialized
DEBUG - 2018-07-28 22:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 22:56:47 --> CSRF cookie sent
INFO - 2018-07-28 22:56:47 --> Input Class Initialized
INFO - 2018-07-28 22:56:47 --> Language Class Initialized
INFO - 2018-07-28 22:56:47 --> Loader Class Initialized
INFO - 2018-07-28 22:56:47 --> Helper loaded: url_helper
INFO - 2018-07-28 22:56:47 --> Helper loaded: form_helper
INFO - 2018-07-28 22:56:47 --> Helper loaded: language_helper
DEBUG - 2018-07-28 22:56:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 22:56:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 22:56:47 --> User Agent Class Initialized
INFO - 2018-07-28 22:56:47 --> Controller Class Initialized
INFO - 2018-07-28 22:56:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-28 22:56:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-28 22:56:47 --> Pixel_Model class loaded
INFO - 2018-07-28 22:56:47 --> Database Driver Class Initialized
INFO - 2018-07-28 22:56:47 --> Model "QuestionsModel" initialized
INFO - 2018-07-28 22:56:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-28 22:56:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-28 22:56:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-28 22:56:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-28 22:56:47 --> Final output sent to browser
DEBUG - 2018-07-28 22:56:47 --> Total execution time: 0.0338
INFO - 2018-07-28 22:56:48 --> Config Class Initialized
INFO - 2018-07-28 22:56:48 --> Hooks Class Initialized
DEBUG - 2018-07-28 22:56:48 --> UTF-8 Support Enabled
INFO - 2018-07-28 22:56:48 --> Utf8 Class Initialized
INFO - 2018-07-28 22:56:48 --> URI Class Initialized
DEBUG - 2018-07-28 22:56:48 --> No URI present. Default controller set.
INFO - 2018-07-28 22:56:48 --> Router Class Initialized
INFO - 2018-07-28 22:56:48 --> Output Class Initialized
INFO - 2018-07-28 22:56:48 --> Security Class Initialized
DEBUG - 2018-07-28 22:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 22:56:48 --> CSRF cookie sent
INFO - 2018-07-28 22:56:48 --> Input Class Initialized
INFO - 2018-07-28 22:56:48 --> Language Class Initialized
INFO - 2018-07-28 22:56:48 --> Loader Class Initialized
INFO - 2018-07-28 22:56:48 --> Helper loaded: url_helper
INFO - 2018-07-28 22:56:48 --> Helper loaded: form_helper
INFO - 2018-07-28 22:56:48 --> Helper loaded: language_helper
DEBUG - 2018-07-28 22:56:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 22:56:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 22:56:48 --> User Agent Class Initialized
INFO - 2018-07-28 22:56:48 --> Controller Class Initialized
INFO - 2018-07-28 22:56:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-28 22:56:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-28 22:56:48 --> Pixel_Model class loaded
INFO - 2018-07-28 22:56:48 --> Database Driver Class Initialized
INFO - 2018-07-28 22:56:48 --> Model "QuestionsModel" initialized
INFO - 2018-07-28 22:56:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-28 22:56:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-28 22:56:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-28 22:56:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-28 22:56:48 --> Final output sent to browser
DEBUG - 2018-07-28 22:56:48 --> Total execution time: 0.0283
INFO - 2018-07-28 22:56:49 --> Config Class Initialized
INFO - 2018-07-28 22:56:49 --> Hooks Class Initialized
DEBUG - 2018-07-28 22:56:49 --> UTF-8 Support Enabled
INFO - 2018-07-28 22:56:49 --> Utf8 Class Initialized
INFO - 2018-07-28 22:56:49 --> URI Class Initialized
DEBUG - 2018-07-28 22:56:49 --> No URI present. Default controller set.
INFO - 2018-07-28 22:56:49 --> Router Class Initialized
INFO - 2018-07-28 22:56:49 --> Output Class Initialized
INFO - 2018-07-28 22:56:49 --> Security Class Initialized
DEBUG - 2018-07-28 22:56:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 22:56:49 --> CSRF cookie sent
INFO - 2018-07-28 22:56:49 --> Input Class Initialized
INFO - 2018-07-28 22:56:49 --> Language Class Initialized
INFO - 2018-07-28 22:56:49 --> Loader Class Initialized
INFO - 2018-07-28 22:56:49 --> Helper loaded: url_helper
INFO - 2018-07-28 22:56:49 --> Helper loaded: form_helper
INFO - 2018-07-28 22:56:49 --> Helper loaded: language_helper
DEBUG - 2018-07-28 22:56:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 22:56:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 22:56:49 --> User Agent Class Initialized
INFO - 2018-07-28 22:56:49 --> Controller Class Initialized
INFO - 2018-07-28 22:56:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-28 22:56:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-28 22:56:49 --> Pixel_Model class loaded
INFO - 2018-07-28 22:56:49 --> Database Driver Class Initialized
INFO - 2018-07-28 22:56:49 --> Model "QuestionsModel" initialized
INFO - 2018-07-28 22:56:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-28 22:56:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-28 22:56:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-28 22:56:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-28 22:56:49 --> Final output sent to browser
DEBUG - 2018-07-28 22:56:49 --> Total execution time: 0.0341
INFO - 2018-07-28 22:56:49 --> Config Class Initialized
INFO - 2018-07-28 22:56:49 --> Hooks Class Initialized
DEBUG - 2018-07-28 22:56:49 --> UTF-8 Support Enabled
INFO - 2018-07-28 22:56:49 --> Utf8 Class Initialized
INFO - 2018-07-28 22:56:49 --> URI Class Initialized
INFO - 2018-07-28 22:56:49 --> Router Class Initialized
INFO - 2018-07-28 22:56:49 --> Output Class Initialized
INFO - 2018-07-28 22:56:49 --> Security Class Initialized
DEBUG - 2018-07-28 22:56:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 22:56:49 --> CSRF cookie sent
INFO - 2018-07-28 22:56:49 --> Input Class Initialized
INFO - 2018-07-28 22:56:49 --> Language Class Initialized
ERROR - 2018-07-28 22:56:49 --> 404 Page Not Found: 405shtml/index
INFO - 2018-07-28 22:56:57 --> Config Class Initialized
INFO - 2018-07-28 22:56:57 --> Hooks Class Initialized
DEBUG - 2018-07-28 22:56:57 --> UTF-8 Support Enabled
INFO - 2018-07-28 22:56:57 --> Utf8 Class Initialized
INFO - 2018-07-28 22:56:57 --> URI Class Initialized
DEBUG - 2018-07-28 22:56:57 --> No URI present. Default controller set.
INFO - 2018-07-28 22:56:57 --> Router Class Initialized
INFO - 2018-07-28 22:56:57 --> Output Class Initialized
INFO - 2018-07-28 22:56:57 --> Security Class Initialized
DEBUG - 2018-07-28 22:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 22:56:57 --> CSRF cookie sent
INFO - 2018-07-28 22:56:57 --> Input Class Initialized
INFO - 2018-07-28 22:56:57 --> Language Class Initialized
INFO - 2018-07-28 22:56:57 --> Loader Class Initialized
INFO - 2018-07-28 22:56:57 --> Helper loaded: url_helper
INFO - 2018-07-28 22:56:57 --> Helper loaded: form_helper
INFO - 2018-07-28 22:56:57 --> Helper loaded: language_helper
DEBUG - 2018-07-28 22:56:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 22:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 22:56:57 --> User Agent Class Initialized
INFO - 2018-07-28 22:56:57 --> Controller Class Initialized
INFO - 2018-07-28 22:56:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-28 22:56:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-28 22:56:57 --> Pixel_Model class loaded
INFO - 2018-07-28 22:56:57 --> Database Driver Class Initialized
INFO - 2018-07-28 22:56:57 --> Model "QuestionsModel" initialized
INFO - 2018-07-28 22:56:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-28 22:56:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-28 22:56:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-28 22:56:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-28 22:56:57 --> Final output sent to browser
DEBUG - 2018-07-28 22:56:57 --> Total execution time: 0.0345
INFO - 2018-07-28 22:56:57 --> Config Class Initialized
INFO - 2018-07-28 22:56:57 --> Hooks Class Initialized
DEBUG - 2018-07-28 22:56:57 --> UTF-8 Support Enabled
INFO - 2018-07-28 22:56:57 --> Utf8 Class Initialized
INFO - 2018-07-28 22:56:57 --> URI Class Initialized
INFO - 2018-07-28 22:56:57 --> Router Class Initialized
INFO - 2018-07-28 22:56:57 --> Output Class Initialized
INFO - 2018-07-28 22:56:57 --> Security Class Initialized
DEBUG - 2018-07-28 22:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 22:56:57 --> CSRF cookie sent
INFO - 2018-07-28 22:56:57 --> Input Class Initialized
INFO - 2018-07-28 22:56:57 --> Language Class Initialized
ERROR - 2018-07-28 22:56:57 --> 404 Page Not Found: 404testpage4525d2fdc/index
INFO - 2018-07-28 22:56:57 --> Config Class Initialized
INFO - 2018-07-28 22:56:57 --> Hooks Class Initialized
DEBUG - 2018-07-28 22:56:57 --> UTF-8 Support Enabled
INFO - 2018-07-28 22:56:57 --> Utf8 Class Initialized
INFO - 2018-07-28 22:56:57 --> URI Class Initialized
INFO - 2018-07-28 22:56:57 --> Router Class Initialized
INFO - 2018-07-28 22:56:57 --> Output Class Initialized
INFO - 2018-07-28 22:56:57 --> Security Class Initialized
DEBUG - 2018-07-28 22:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 22:56:58 --> CSRF cookie sent
INFO - 2018-07-28 22:56:58 --> Input Class Initialized
INFO - 2018-07-28 22:56:58 --> Language Class Initialized
ERROR - 2018-07-28 22:56:58 --> 404 Page Not Found: 404javascriptjs/index
INFO - 2018-07-28 22:56:58 --> Config Class Initialized
INFO - 2018-07-28 22:56:58 --> Hooks Class Initialized
DEBUG - 2018-07-28 22:56:58 --> UTF-8 Support Enabled
INFO - 2018-07-28 22:56:58 --> Utf8 Class Initialized
INFO - 2018-07-28 22:56:58 --> URI Class Initialized
INFO - 2018-07-28 22:56:58 --> Router Class Initialized
INFO - 2018-07-28 22:56:58 --> Output Class Initialized
INFO - 2018-07-28 22:56:58 --> Security Class Initialized
DEBUG - 2018-07-28 22:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 22:56:58 --> CSRF cookie sent
INFO - 2018-07-28 22:56:58 --> Input Class Initialized
INFO - 2018-07-28 22:56:58 --> Language Class Initialized
INFO - 2018-07-28 22:56:58 --> Loader Class Initialized
INFO - 2018-07-28 22:56:58 --> Helper loaded: url_helper
INFO - 2018-07-28 22:56:58 --> Helper loaded: form_helper
INFO - 2018-07-28 22:56:58 --> Helper loaded: language_helper
DEBUG - 2018-07-28 22:56:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 22:56:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 22:56:58 --> User Agent Class Initialized
INFO - 2018-07-28 22:56:58 --> Controller Class Initialized
INFO - 2018-07-28 22:56:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-28 22:56:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-28 22:56:58 --> Pixel_Model class loaded
INFO - 2018-07-28 22:56:58 --> Database Driver Class Initialized
INFO - 2018-07-28 22:56:58 --> Model "QuestionsModel" initialized
INFO - 2018-07-28 22:56:58 --> Config Class Initialized
INFO - 2018-07-28 22:56:58 --> Hooks Class Initialized
DEBUG - 2018-07-28 22:56:58 --> UTF-8 Support Enabled
INFO - 2018-07-28 22:56:58 --> Utf8 Class Initialized
INFO - 2018-07-28 22:56:58 --> URI Class Initialized
INFO - 2018-07-28 22:56:58 --> Router Class Initialized
INFO - 2018-07-28 22:56:58 --> Output Class Initialized
INFO - 2018-07-28 22:56:58 --> Security Class Initialized
DEBUG - 2018-07-28 22:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 22:56:58 --> CSRF cookie sent
INFO - 2018-07-28 22:56:58 --> Input Class Initialized
INFO - 2018-07-28 22:56:58 --> Language Class Initialized
INFO - 2018-07-28 22:56:58 --> Loader Class Initialized
INFO - 2018-07-28 22:56:58 --> Helper loaded: url_helper
INFO - 2018-07-28 22:56:58 --> Helper loaded: form_helper
INFO - 2018-07-28 22:56:58 --> Helper loaded: language_helper
DEBUG - 2018-07-28 22:56:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 22:56:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 22:56:58 --> User Agent Class Initialized
INFO - 2018-07-28 22:56:58 --> Controller Class Initialized
INFO - 2018-07-28 22:56:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-28 22:56:58 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-28 22:56:58 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-28 22:56:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-28 22:56:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-28 22:56:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-28 22:56:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-28 22:56:58 --> Could not find the language line "req_email"
INFO - 2018-07-28 22:56:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-28 22:56:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-28 22:56:58 --> Final output sent to browser
DEBUG - 2018-07-28 22:56:58 --> Total execution time: 0.0218
INFO - 2018-07-28 22:56:58 --> Config Class Initialized
INFO - 2018-07-28 22:56:58 --> Hooks Class Initialized
DEBUG - 2018-07-28 22:56:58 --> UTF-8 Support Enabled
INFO - 2018-07-28 22:56:58 --> Utf8 Class Initialized
INFO - 2018-07-28 22:56:58 --> URI Class Initialized
INFO - 2018-07-28 22:56:58 --> Router Class Initialized
INFO - 2018-07-28 22:56:58 --> Output Class Initialized
INFO - 2018-07-28 22:56:58 --> Security Class Initialized
DEBUG - 2018-07-28 22:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 22:56:58 --> CSRF cookie sent
INFO - 2018-07-28 22:56:58 --> Input Class Initialized
INFO - 2018-07-28 22:56:58 --> Language Class Initialized
INFO - 2018-07-28 22:56:58 --> Loader Class Initialized
INFO - 2018-07-28 22:56:58 --> Helper loaded: url_helper
INFO - 2018-07-28 22:56:58 --> Helper loaded: form_helper
INFO - 2018-07-28 22:56:58 --> Helper loaded: language_helper
DEBUG - 2018-07-28 22:56:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 22:56:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 22:56:58 --> User Agent Class Initialized
INFO - 2018-07-28 22:56:58 --> Controller Class Initialized
INFO - 2018-07-28 22:56:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-28 22:56:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-28 22:56:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-28 22:56:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-28 22:56:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-28 22:56:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-28 22:56:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-07-28 22:56:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-28 22:56:58 --> Final output sent to browser
DEBUG - 2018-07-28 22:56:58 --> Total execution time: 0.0209
INFO - 2018-07-28 22:56:59 --> Config Class Initialized
INFO - 2018-07-28 22:56:59 --> Hooks Class Initialized
DEBUG - 2018-07-28 22:56:59 --> UTF-8 Support Enabled
INFO - 2018-07-28 22:56:59 --> Utf8 Class Initialized
INFO - 2018-07-28 22:56:59 --> URI Class Initialized
INFO - 2018-07-28 22:56:59 --> Router Class Initialized
INFO - 2018-07-28 22:56:59 --> Output Class Initialized
INFO - 2018-07-28 22:56:59 --> Security Class Initialized
DEBUG - 2018-07-28 22:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 22:56:59 --> CSRF cookie sent
INFO - 2018-07-28 22:56:59 --> Input Class Initialized
INFO - 2018-07-28 22:56:59 --> Language Class Initialized
INFO - 2018-07-28 22:56:59 --> Loader Class Initialized
INFO - 2018-07-28 22:56:59 --> Helper loaded: url_helper
INFO - 2018-07-28 22:56:59 --> Helper loaded: form_helper
INFO - 2018-07-28 22:56:59 --> Helper loaded: language_helper
DEBUG - 2018-07-28 22:56:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 22:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 22:56:59 --> User Agent Class Initialized
INFO - 2018-07-28 22:56:59 --> Controller Class Initialized
INFO - 2018-07-28 22:56:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-28 22:56:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-28 22:56:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-28 22:56:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-28 22:56:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-28 22:56:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-28 22:56:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-07-28 22:56:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-28 22:56:59 --> Final output sent to browser
DEBUG - 2018-07-28 22:56:59 --> Total execution time: 0.0209
INFO - 2018-07-28 22:56:59 --> Config Class Initialized
INFO - 2018-07-28 22:56:59 --> Hooks Class Initialized
DEBUG - 2018-07-28 22:56:59 --> UTF-8 Support Enabled
INFO - 2018-07-28 22:56:59 --> Utf8 Class Initialized
INFO - 2018-07-28 22:56:59 --> URI Class Initialized
INFO - 2018-07-28 22:56:59 --> Router Class Initialized
INFO - 2018-07-28 22:56:59 --> Output Class Initialized
INFO - 2018-07-28 22:56:59 --> Security Class Initialized
DEBUG - 2018-07-28 22:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 22:56:59 --> CSRF cookie sent
INFO - 2018-07-28 22:56:59 --> Input Class Initialized
INFO - 2018-07-28 22:56:59 --> Language Class Initialized
INFO - 2018-07-28 22:56:59 --> Loader Class Initialized
INFO - 2018-07-28 22:56:59 --> Helper loaded: url_helper
INFO - 2018-07-28 22:56:59 --> Helper loaded: form_helper
INFO - 2018-07-28 22:56:59 --> Helper loaded: language_helper
DEBUG - 2018-07-28 22:56:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 22:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 22:56:59 --> User Agent Class Initialized
INFO - 2018-07-28 22:56:59 --> Controller Class Initialized
INFO - 2018-07-28 22:56:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-28 22:56:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-28 22:56:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-28 22:56:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-28 22:56:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-28 22:56:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-28 22:56:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-07-28 22:56:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-28 22:56:59 --> Final output sent to browser
DEBUG - 2018-07-28 22:56:59 --> Total execution time: 0.0218
INFO - 2018-07-28 22:57:00 --> Config Class Initialized
INFO - 2018-07-28 22:57:00 --> Hooks Class Initialized
DEBUG - 2018-07-28 22:57:00 --> UTF-8 Support Enabled
INFO - 2018-07-28 22:57:00 --> Utf8 Class Initialized
INFO - 2018-07-28 22:57:00 --> URI Class Initialized
INFO - 2018-07-28 22:57:00 --> Router Class Initialized
INFO - 2018-07-28 22:57:00 --> Output Class Initialized
INFO - 2018-07-28 22:57:00 --> Security Class Initialized
DEBUG - 2018-07-28 22:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 22:57:00 --> CSRF cookie sent
INFO - 2018-07-28 22:57:00 --> Input Class Initialized
INFO - 2018-07-28 22:57:00 --> Language Class Initialized
INFO - 2018-07-28 22:57:00 --> Loader Class Initialized
INFO - 2018-07-28 22:57:00 --> Helper loaded: url_helper
INFO - 2018-07-28 22:57:00 --> Helper loaded: form_helper
INFO - 2018-07-28 22:57:00 --> Helper loaded: language_helper
DEBUG - 2018-07-28 22:57:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 22:57:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 22:57:00 --> User Agent Class Initialized
INFO - 2018-07-28 22:57:00 --> Controller Class Initialized
INFO - 2018-07-28 22:57:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-28 22:57:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-28 22:57:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-28 22:57:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-28 22:57:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-28 22:57:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-28 22:57:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-07-28 22:57:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-28 22:57:00 --> Final output sent to browser
DEBUG - 2018-07-28 22:57:00 --> Total execution time: 0.0232
INFO - 2018-07-28 22:57:00 --> Config Class Initialized
INFO - 2018-07-28 22:57:00 --> Hooks Class Initialized
DEBUG - 2018-07-28 22:57:00 --> UTF-8 Support Enabled
INFO - 2018-07-28 22:57:00 --> Utf8 Class Initialized
INFO - 2018-07-28 22:57:00 --> URI Class Initialized
INFO - 2018-07-28 22:57:00 --> Router Class Initialized
INFO - 2018-07-28 22:57:00 --> Output Class Initialized
INFO - 2018-07-28 22:57:00 --> Security Class Initialized
DEBUG - 2018-07-28 22:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 22:57:00 --> CSRF cookie sent
INFO - 2018-07-28 22:57:00 --> Input Class Initialized
INFO - 2018-07-28 22:57:00 --> Language Class Initialized
INFO - 2018-07-28 22:57:00 --> Loader Class Initialized
INFO - 2018-07-28 22:57:00 --> Helper loaded: url_helper
INFO - 2018-07-28 22:57:00 --> Helper loaded: form_helper
INFO - 2018-07-28 22:57:00 --> Helper loaded: language_helper
DEBUG - 2018-07-28 22:57:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 22:57:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 22:57:00 --> User Agent Class Initialized
INFO - 2018-07-28 22:57:00 --> Controller Class Initialized
INFO - 2018-07-28 22:57:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-28 22:57:00 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-28 22:57:00 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-28 22:57:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-28 22:57:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-28 22:57:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-28 22:57:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-28 22:57:00 --> Could not find the language line "req_email"
INFO - 2018-07-28 22:57:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-28 22:57:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-28 22:57:00 --> Final output sent to browser
DEBUG - 2018-07-28 22:57:00 --> Total execution time: 0.0242
INFO - 2018-07-28 22:57:00 --> Config Class Initialized
INFO - 2018-07-28 22:57:00 --> Hooks Class Initialized
DEBUG - 2018-07-28 22:57:00 --> UTF-8 Support Enabled
INFO - 2018-07-28 22:57:00 --> Utf8 Class Initialized
INFO - 2018-07-28 22:57:00 --> URI Class Initialized
INFO - 2018-07-28 22:57:00 --> Router Class Initialized
INFO - 2018-07-28 22:57:00 --> Output Class Initialized
INFO - 2018-07-28 22:57:00 --> Security Class Initialized
DEBUG - 2018-07-28 22:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 22:57:00 --> CSRF cookie sent
INFO - 2018-07-28 22:57:00 --> Input Class Initialized
INFO - 2018-07-28 22:57:00 --> Language Class Initialized
INFO - 2018-07-28 22:57:00 --> Loader Class Initialized
INFO - 2018-07-28 22:57:00 --> Helper loaded: url_helper
INFO - 2018-07-28 22:57:00 --> Helper loaded: form_helper
INFO - 2018-07-28 22:57:00 --> Helper loaded: language_helper
DEBUG - 2018-07-28 22:57:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 22:57:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 22:57:00 --> User Agent Class Initialized
INFO - 2018-07-28 22:57:00 --> Controller Class Initialized
INFO - 2018-07-28 22:57:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-28 22:57:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-28 22:57:00 --> Pixel_Model class loaded
INFO - 2018-07-28 22:57:00 --> Database Driver Class Initialized
INFO - 2018-07-28 22:57:00 --> Model "QuestionsModel" initialized
INFO - 2018-07-28 22:57:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-28 22:57:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-28 22:57:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-28 22:57:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-28 22:57:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/buy_gift.php
INFO - 2018-07-28 22:57:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-28 22:57:00 --> Final output sent to browser
DEBUG - 2018-07-28 22:57:00 --> Total execution time: 0.0312

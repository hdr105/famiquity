<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-07-31 00:41:10 --> Config Class Initialized
INFO - 2018-07-31 00:41:10 --> Hooks Class Initialized
DEBUG - 2018-07-31 00:41:10 --> UTF-8 Support Enabled
INFO - 2018-07-31 00:41:10 --> Utf8 Class Initialized
INFO - 2018-07-31 00:41:10 --> URI Class Initialized
INFO - 2018-07-31 00:41:10 --> Router Class Initialized
INFO - 2018-07-31 00:41:10 --> Output Class Initialized
INFO - 2018-07-31 00:41:10 --> Security Class Initialized
DEBUG - 2018-07-31 00:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 00:41:10 --> CSRF cookie sent
INFO - 2018-07-31 00:41:10 --> Input Class Initialized
INFO - 2018-07-31 00:41:10 --> Language Class Initialized
INFO - 2018-07-31 00:41:10 --> Loader Class Initialized
INFO - 2018-07-31 00:41:10 --> Helper loaded: url_helper
INFO - 2018-07-31 00:41:10 --> Helper loaded: form_helper
INFO - 2018-07-31 00:41:10 --> Helper loaded: language_helper
DEBUG - 2018-07-31 00:41:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 00:41:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 00:41:10 --> User Agent Class Initialized
INFO - 2018-07-31 00:41:10 --> Controller Class Initialized
INFO - 2018-07-31 00:41:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 00:41:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 00:41:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 00:41:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 00:41:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 00:41:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 00:41:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/preview.php
INFO - 2018-07-31 00:41:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 00:41:10 --> Final output sent to browser
DEBUG - 2018-07-31 00:41:10 --> Total execution time: 0.0246
INFO - 2018-07-31 02:01:35 --> Config Class Initialized
INFO - 2018-07-31 02:01:35 --> Hooks Class Initialized
DEBUG - 2018-07-31 02:01:35 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:01:35 --> Utf8 Class Initialized
INFO - 2018-07-31 02:01:35 --> URI Class Initialized
INFO - 2018-07-31 02:01:35 --> Router Class Initialized
INFO - 2018-07-31 02:01:35 --> Output Class Initialized
INFO - 2018-07-31 02:01:35 --> Security Class Initialized
DEBUG - 2018-07-31 02:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:01:35 --> CSRF cookie sent
INFO - 2018-07-31 02:01:35 --> Input Class Initialized
INFO - 2018-07-31 02:01:35 --> Language Class Initialized
ERROR - 2018-07-31 02:01:35 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-31 02:01:38 --> Config Class Initialized
INFO - 2018-07-31 02:01:38 --> Hooks Class Initialized
DEBUG - 2018-07-31 02:01:38 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:01:38 --> Utf8 Class Initialized
INFO - 2018-07-31 02:01:38 --> URI Class Initialized
INFO - 2018-07-31 02:01:38 --> Router Class Initialized
INFO - 2018-07-31 02:01:38 --> Output Class Initialized
INFO - 2018-07-31 02:01:38 --> Security Class Initialized
DEBUG - 2018-07-31 02:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:01:38 --> CSRF cookie sent
INFO - 2018-07-31 02:01:38 --> Input Class Initialized
INFO - 2018-07-31 02:01:38 --> Language Class Initialized
INFO - 2018-07-31 02:01:38 --> Loader Class Initialized
INFO - 2018-07-31 02:01:38 --> Helper loaded: url_helper
INFO - 2018-07-31 02:01:38 --> Helper loaded: form_helper
INFO - 2018-07-31 02:01:38 --> Helper loaded: language_helper
DEBUG - 2018-07-31 02:01:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 02:01:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 02:01:38 --> User Agent Class Initialized
INFO - 2018-07-31 02:01:38 --> Controller Class Initialized
INFO - 2018-07-31 02:01:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 02:01:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 02:01:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 02:01:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 02:01:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 02:01:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 02:01:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-07-31 02:01:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 02:01:38 --> Final output sent to browser
DEBUG - 2018-07-31 02:01:38 --> Total execution time: 0.0337
INFO - 2018-07-31 02:58:16 --> Config Class Initialized
INFO - 2018-07-31 02:58:16 --> Hooks Class Initialized
DEBUG - 2018-07-31 02:58:16 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:58:16 --> Utf8 Class Initialized
INFO - 2018-07-31 02:58:16 --> URI Class Initialized
INFO - 2018-07-31 02:58:16 --> Router Class Initialized
INFO - 2018-07-31 02:58:16 --> Output Class Initialized
INFO - 2018-07-31 02:58:16 --> Security Class Initialized
DEBUG - 2018-07-31 02:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:58:16 --> CSRF cookie sent
INFO - 2018-07-31 02:58:16 --> Input Class Initialized
INFO - 2018-07-31 02:58:16 --> Language Class Initialized
INFO - 2018-07-31 02:58:16 --> Loader Class Initialized
INFO - 2018-07-31 02:58:16 --> Helper loaded: url_helper
INFO - 2018-07-31 02:58:16 --> Helper loaded: form_helper
INFO - 2018-07-31 02:58:16 --> Helper loaded: language_helper
DEBUG - 2018-07-31 02:58:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 02:58:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 02:58:16 --> User Agent Class Initialized
INFO - 2018-07-31 02:58:16 --> Controller Class Initialized
INFO - 2018-07-31 02:58:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 02:58:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 02:58:16 --> Pixel_Model class loaded
INFO - 2018-07-31 02:58:16 --> Database Driver Class Initialized
INFO - 2018-07-31 02:58:16 --> Model "RegistrationModel" initialized
DEBUG - 2018-07-31 02:58:16 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-31 02:58:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 02:58:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 02:58:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 02:58:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 02:58:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/temp.php
INFO - 2018-07-31 02:58:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 02:58:16 --> Final output sent to browser
DEBUG - 2018-07-31 02:58:16 --> Total execution time: 0.0606
INFO - 2018-07-31 04:51:33 --> Config Class Initialized
INFO - 2018-07-31 04:51:33 --> Hooks Class Initialized
DEBUG - 2018-07-31 04:51:33 --> UTF-8 Support Enabled
INFO - 2018-07-31 04:51:33 --> Utf8 Class Initialized
INFO - 2018-07-31 04:51:33 --> URI Class Initialized
DEBUG - 2018-07-31 04:51:33 --> No URI present. Default controller set.
INFO - 2018-07-31 04:51:33 --> Router Class Initialized
INFO - 2018-07-31 04:51:33 --> Output Class Initialized
INFO - 2018-07-31 04:51:33 --> Security Class Initialized
DEBUG - 2018-07-31 04:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 04:51:33 --> CSRF cookie sent
INFO - 2018-07-31 04:51:33 --> Input Class Initialized
INFO - 2018-07-31 04:51:33 --> Language Class Initialized
INFO - 2018-07-31 04:51:33 --> Loader Class Initialized
INFO - 2018-07-31 04:51:33 --> Helper loaded: url_helper
INFO - 2018-07-31 04:51:33 --> Helper loaded: form_helper
INFO - 2018-07-31 04:51:33 --> Helper loaded: language_helper
DEBUG - 2018-07-31 04:51:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 04:51:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 04:51:33 --> User Agent Class Initialized
INFO - 2018-07-31 04:51:33 --> Controller Class Initialized
INFO - 2018-07-31 04:51:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 04:51:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 04:51:33 --> Pixel_Model class loaded
INFO - 2018-07-31 04:51:33 --> Database Driver Class Initialized
INFO - 2018-07-31 04:51:33 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 04:51:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 04:51:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 04:51:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-31 04:51:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 04:51:33 --> Final output sent to browser
DEBUG - 2018-07-31 04:51:33 --> Total execution time: 0.2937
INFO - 2018-07-31 05:28:16 --> Config Class Initialized
INFO - 2018-07-31 05:28:16 --> Hooks Class Initialized
DEBUG - 2018-07-31 05:28:16 --> UTF-8 Support Enabled
INFO - 2018-07-31 05:28:16 --> Utf8 Class Initialized
INFO - 2018-07-31 05:28:16 --> URI Class Initialized
INFO - 2018-07-31 05:28:16 --> Router Class Initialized
INFO - 2018-07-31 05:28:16 --> Output Class Initialized
INFO - 2018-07-31 05:28:16 --> Security Class Initialized
DEBUG - 2018-07-31 05:28:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 05:28:16 --> CSRF cookie sent
INFO - 2018-07-31 05:28:16 --> Input Class Initialized
INFO - 2018-07-31 05:28:16 --> Language Class Initialized
ERROR - 2018-07-31 05:28:16 --> 404 Page Not Found: Robotstxt/index
INFO - 2018-07-31 05:57:24 --> Config Class Initialized
INFO - 2018-07-31 05:57:24 --> Hooks Class Initialized
DEBUG - 2018-07-31 05:57:24 --> UTF-8 Support Enabled
INFO - 2018-07-31 05:57:24 --> Utf8 Class Initialized
INFO - 2018-07-31 05:57:24 --> URI Class Initialized
INFO - 2018-07-31 05:57:24 --> Router Class Initialized
INFO - 2018-07-31 05:57:24 --> Output Class Initialized
INFO - 2018-07-31 05:57:24 --> Security Class Initialized
DEBUG - 2018-07-31 05:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 05:57:24 --> CSRF cookie sent
INFO - 2018-07-31 05:57:24 --> Input Class Initialized
INFO - 2018-07-31 05:57:24 --> Language Class Initialized
INFO - 2018-07-31 05:57:24 --> Loader Class Initialized
INFO - 2018-07-31 05:57:24 --> Helper loaded: url_helper
INFO - 2018-07-31 05:57:24 --> Helper loaded: form_helper
INFO - 2018-07-31 05:57:24 --> Helper loaded: language_helper
DEBUG - 2018-07-31 05:57:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 05:57:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 05:57:24 --> User Agent Class Initialized
INFO - 2018-07-31 05:57:24 --> Controller Class Initialized
INFO - 2018-07-31 05:57:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 05:57:24 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-31 05:57:24 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-31 05:57:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 05:57:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 05:57:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 05:57:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-31 05:57:24 --> Could not find the language line "req_email"
INFO - 2018-07-31 05:57:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/forgot_password.php
INFO - 2018-07-31 05:57:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 05:57:24 --> Final output sent to browser
DEBUG - 2018-07-31 05:57:24 --> Total execution time: 0.0628
INFO - 2018-07-31 07:39:35 --> Config Class Initialized
INFO - 2018-07-31 07:39:35 --> Hooks Class Initialized
DEBUG - 2018-07-31 07:39:35 --> UTF-8 Support Enabled
INFO - 2018-07-31 07:39:35 --> Utf8 Class Initialized
INFO - 2018-07-31 07:39:35 --> URI Class Initialized
DEBUG - 2018-07-31 07:39:35 --> No URI present. Default controller set.
INFO - 2018-07-31 07:39:35 --> Router Class Initialized
INFO - 2018-07-31 07:39:35 --> Output Class Initialized
INFO - 2018-07-31 07:39:35 --> Security Class Initialized
DEBUG - 2018-07-31 07:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 07:39:35 --> CSRF cookie sent
INFO - 2018-07-31 07:39:35 --> Input Class Initialized
INFO - 2018-07-31 07:39:35 --> Language Class Initialized
INFO - 2018-07-31 07:39:35 --> Loader Class Initialized
INFO - 2018-07-31 07:39:35 --> Helper loaded: url_helper
INFO - 2018-07-31 07:39:35 --> Helper loaded: form_helper
INFO - 2018-07-31 07:39:35 --> Helper loaded: language_helper
DEBUG - 2018-07-31 07:39:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 07:39:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 07:39:35 --> User Agent Class Initialized
INFO - 2018-07-31 07:39:35 --> Controller Class Initialized
INFO - 2018-07-31 07:39:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 07:39:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 07:39:35 --> Pixel_Model class loaded
INFO - 2018-07-31 07:39:35 --> Database Driver Class Initialized
INFO - 2018-07-31 07:39:35 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 07:39:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 07:39:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 07:39:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-31 07:39:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 07:39:35 --> Final output sent to browser
DEBUG - 2018-07-31 07:39:35 --> Total execution time: 0.0373
INFO - 2018-07-31 09:52:44 --> Config Class Initialized
INFO - 2018-07-31 09:52:44 --> Hooks Class Initialized
DEBUG - 2018-07-31 09:52:44 --> UTF-8 Support Enabled
INFO - 2018-07-31 09:52:44 --> Utf8 Class Initialized
INFO - 2018-07-31 09:52:44 --> URI Class Initialized
DEBUG - 2018-07-31 09:52:44 --> No URI present. Default controller set.
INFO - 2018-07-31 09:52:44 --> Router Class Initialized
INFO - 2018-07-31 09:52:44 --> Output Class Initialized
INFO - 2018-07-31 09:52:44 --> Security Class Initialized
DEBUG - 2018-07-31 09:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 09:52:44 --> CSRF cookie sent
INFO - 2018-07-31 09:52:44 --> Input Class Initialized
INFO - 2018-07-31 09:52:44 --> Language Class Initialized
INFO - 2018-07-31 09:52:44 --> Loader Class Initialized
INFO - 2018-07-31 09:52:44 --> Helper loaded: url_helper
INFO - 2018-07-31 09:52:44 --> Helper loaded: form_helper
INFO - 2018-07-31 09:52:44 --> Helper loaded: language_helper
DEBUG - 2018-07-31 09:52:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 09:52:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 09:52:44 --> User Agent Class Initialized
INFO - 2018-07-31 09:52:44 --> Controller Class Initialized
INFO - 2018-07-31 09:52:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 09:52:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 09:52:44 --> Pixel_Model class loaded
INFO - 2018-07-31 09:52:44 --> Database Driver Class Initialized
INFO - 2018-07-31 09:52:44 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 09:52:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 09:52:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 09:52:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-31 09:52:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 09:52:44 --> Final output sent to browser
DEBUG - 2018-07-31 09:52:44 --> Total execution time: 0.0328
INFO - 2018-07-31 10:40:31 --> Config Class Initialized
INFO - 2018-07-31 10:40:31 --> Hooks Class Initialized
DEBUG - 2018-07-31 10:40:31 --> UTF-8 Support Enabled
INFO - 2018-07-31 10:40:31 --> Utf8 Class Initialized
INFO - 2018-07-31 10:40:31 --> URI Class Initialized
DEBUG - 2018-07-31 10:40:31 --> No URI present. Default controller set.
INFO - 2018-07-31 10:40:31 --> Router Class Initialized
INFO - 2018-07-31 10:40:31 --> Output Class Initialized
INFO - 2018-07-31 10:40:31 --> Security Class Initialized
DEBUG - 2018-07-31 10:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 10:40:31 --> CSRF cookie sent
INFO - 2018-07-31 10:40:31 --> Input Class Initialized
INFO - 2018-07-31 10:40:31 --> Language Class Initialized
INFO - 2018-07-31 10:40:31 --> Loader Class Initialized
INFO - 2018-07-31 10:40:31 --> Helper loaded: url_helper
INFO - 2018-07-31 10:40:31 --> Helper loaded: form_helper
INFO - 2018-07-31 10:40:31 --> Helper loaded: language_helper
DEBUG - 2018-07-31 10:40:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 10:40:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 10:40:31 --> User Agent Class Initialized
INFO - 2018-07-31 10:40:31 --> Controller Class Initialized
INFO - 2018-07-31 10:40:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 10:40:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 10:40:31 --> Pixel_Model class loaded
INFO - 2018-07-31 10:40:31 --> Database Driver Class Initialized
INFO - 2018-07-31 10:40:31 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 10:40:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 10:40:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 10:40:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-31 10:40:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 10:40:31 --> Final output sent to browser
DEBUG - 2018-07-31 10:40:31 --> Total execution time: 0.0450
INFO - 2018-07-31 13:31:08 --> Config Class Initialized
INFO - 2018-07-31 13:31:08 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:31:08 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:31:08 --> Utf8 Class Initialized
INFO - 2018-07-31 13:31:08 --> URI Class Initialized
DEBUG - 2018-07-31 13:31:08 --> No URI present. Default controller set.
INFO - 2018-07-31 13:31:08 --> Router Class Initialized
INFO - 2018-07-31 13:31:08 --> Output Class Initialized
INFO - 2018-07-31 13:31:08 --> Security Class Initialized
DEBUG - 2018-07-31 13:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:31:08 --> CSRF cookie sent
INFO - 2018-07-31 13:31:08 --> Input Class Initialized
INFO - 2018-07-31 13:31:08 --> Language Class Initialized
INFO - 2018-07-31 13:31:08 --> Loader Class Initialized
INFO - 2018-07-31 13:31:08 --> Helper loaded: url_helper
INFO - 2018-07-31 13:31:08 --> Helper loaded: form_helper
INFO - 2018-07-31 13:31:08 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:31:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:31:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:31:08 --> User Agent Class Initialized
INFO - 2018-07-31 13:31:08 --> Controller Class Initialized
INFO - 2018-07-31 13:31:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:31:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:31:08 --> Pixel_Model class loaded
INFO - 2018-07-31 13:31:08 --> Database Driver Class Initialized
INFO - 2018-07-31 13:31:08 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:31:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:31:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:31:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-31 13:31:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:31:08 --> Final output sent to browser
DEBUG - 2018-07-31 13:31:08 --> Total execution time: 0.0457
INFO - 2018-07-31 13:33:24 --> Config Class Initialized
INFO - 2018-07-31 13:33:24 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:33:24 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:33:24 --> Utf8 Class Initialized
INFO - 2018-07-31 13:33:24 --> URI Class Initialized
DEBUG - 2018-07-31 13:33:24 --> No URI present. Default controller set.
INFO - 2018-07-31 13:33:24 --> Router Class Initialized
INFO - 2018-07-31 13:33:24 --> Output Class Initialized
INFO - 2018-07-31 13:33:24 --> Security Class Initialized
DEBUG - 2018-07-31 13:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:33:24 --> CSRF cookie sent
INFO - 2018-07-31 13:33:24 --> Input Class Initialized
INFO - 2018-07-31 13:33:24 --> Language Class Initialized
INFO - 2018-07-31 13:33:24 --> Loader Class Initialized
INFO - 2018-07-31 13:33:24 --> Helper loaded: url_helper
INFO - 2018-07-31 13:33:24 --> Helper loaded: form_helper
INFO - 2018-07-31 13:33:24 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:33:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:33:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:33:24 --> User Agent Class Initialized
INFO - 2018-07-31 13:33:24 --> Controller Class Initialized
INFO - 2018-07-31 13:33:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:33:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:33:24 --> Pixel_Model class loaded
INFO - 2018-07-31 13:33:24 --> Database Driver Class Initialized
INFO - 2018-07-31 13:33:24 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:33:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:33:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:33:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-31 13:33:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:33:24 --> Final output sent to browser
DEBUG - 2018-07-31 13:33:24 --> Total execution time: 0.0460
INFO - 2018-07-31 13:33:40 --> Config Class Initialized
INFO - 2018-07-31 13:33:40 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:33:40 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:33:40 --> Utf8 Class Initialized
INFO - 2018-07-31 13:33:40 --> URI Class Initialized
INFO - 2018-07-31 13:33:40 --> Router Class Initialized
INFO - 2018-07-31 13:33:40 --> Output Class Initialized
INFO - 2018-07-31 13:33:40 --> Security Class Initialized
DEBUG - 2018-07-31 13:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:33:40 --> CSRF cookie sent
INFO - 2018-07-31 13:33:40 --> Input Class Initialized
INFO - 2018-07-31 13:33:40 --> Language Class Initialized
INFO - 2018-07-31 13:33:40 --> Loader Class Initialized
INFO - 2018-07-31 13:33:40 --> Helper loaded: url_helper
INFO - 2018-07-31 13:33:40 --> Helper loaded: form_helper
INFO - 2018-07-31 13:33:40 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:33:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:33:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:33:40 --> User Agent Class Initialized
INFO - 2018-07-31 13:33:40 --> Controller Class Initialized
INFO - 2018-07-31 13:33:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:33:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:33:40 --> Pixel_Model class loaded
INFO - 2018-07-31 13:33:40 --> Database Driver Class Initialized
INFO - 2018-07-31 13:33:40 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:33:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:33:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:33:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:33:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:33:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:33:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:33:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-07-31 13:33:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:33:40 --> Final output sent to browser
DEBUG - 2018-07-31 13:33:40 --> Total execution time: 0.0713
INFO - 2018-07-31 13:33:50 --> Config Class Initialized
INFO - 2018-07-31 13:33:50 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:33:50 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:33:50 --> Utf8 Class Initialized
INFO - 2018-07-31 13:33:50 --> URI Class Initialized
INFO - 2018-07-31 13:33:50 --> Router Class Initialized
INFO - 2018-07-31 13:33:50 --> Output Class Initialized
INFO - 2018-07-31 13:33:50 --> Security Class Initialized
DEBUG - 2018-07-31 13:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:33:50 --> CSRF cookie sent
INFO - 2018-07-31 13:33:50 --> Input Class Initialized
INFO - 2018-07-31 13:33:50 --> Language Class Initialized
INFO - 2018-07-31 13:33:50 --> Loader Class Initialized
INFO - 2018-07-31 13:33:50 --> Helper loaded: url_helper
INFO - 2018-07-31 13:33:50 --> Helper loaded: form_helper
INFO - 2018-07-31 13:33:50 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:33:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:33:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:33:50 --> User Agent Class Initialized
INFO - 2018-07-31 13:33:50 --> Controller Class Initialized
INFO - 2018-07-31 13:33:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:33:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:33:50 --> Pixel_Model class loaded
INFO - 2018-07-31 13:33:50 --> Database Driver Class Initialized
INFO - 2018-07-31 13:33:50 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:33:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:33:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:33:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:33:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:33:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:33:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:33:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-07-31 13:33:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:33:50 --> Final output sent to browser
DEBUG - 2018-07-31 13:33:50 --> Total execution time: 0.0379
INFO - 2018-07-31 13:34:01 --> Config Class Initialized
INFO - 2018-07-31 13:34:01 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:34:01 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:34:01 --> Utf8 Class Initialized
INFO - 2018-07-31 13:34:01 --> URI Class Initialized
INFO - 2018-07-31 13:34:01 --> Router Class Initialized
INFO - 2018-07-31 13:34:01 --> Output Class Initialized
INFO - 2018-07-31 13:34:01 --> Security Class Initialized
DEBUG - 2018-07-31 13:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:34:01 --> CSRF cookie sent
INFO - 2018-07-31 13:34:01 --> Input Class Initialized
INFO - 2018-07-31 13:34:01 --> Language Class Initialized
INFO - 2018-07-31 13:34:01 --> Loader Class Initialized
INFO - 2018-07-31 13:34:01 --> Helper loaded: url_helper
INFO - 2018-07-31 13:34:01 --> Helper loaded: form_helper
INFO - 2018-07-31 13:34:01 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:34:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:34:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:34:01 --> User Agent Class Initialized
INFO - 2018-07-31 13:34:01 --> Controller Class Initialized
INFO - 2018-07-31 13:34:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:34:01 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-31 13:34:01 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-31 13:34:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:34:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:34:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:34:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-31 13:34:01 --> Could not find the language line "req_email"
INFO - 2018-07-31 13:34:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-31 13:34:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:34:01 --> Final output sent to browser
DEBUG - 2018-07-31 13:34:01 --> Total execution time: 0.0437
INFO - 2018-07-31 13:34:05 --> Config Class Initialized
INFO - 2018-07-31 13:34:05 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:34:05 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:34:05 --> Utf8 Class Initialized
INFO - 2018-07-31 13:34:05 --> URI Class Initialized
INFO - 2018-07-31 13:34:05 --> Router Class Initialized
INFO - 2018-07-31 13:34:05 --> Output Class Initialized
INFO - 2018-07-31 13:34:05 --> Security Class Initialized
DEBUG - 2018-07-31 13:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:34:05 --> CSRF cookie sent
INFO - 2018-07-31 13:34:05 --> Input Class Initialized
INFO - 2018-07-31 13:34:05 --> Language Class Initialized
INFO - 2018-07-31 13:34:05 --> Loader Class Initialized
INFO - 2018-07-31 13:34:05 --> Helper loaded: url_helper
INFO - 2018-07-31 13:34:05 --> Helper loaded: form_helper
INFO - 2018-07-31 13:34:05 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:34:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:34:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:34:05 --> User Agent Class Initialized
INFO - 2018-07-31 13:34:05 --> Controller Class Initialized
INFO - 2018-07-31 13:34:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:34:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:34:05 --> Pixel_Model class loaded
INFO - 2018-07-31 13:34:05 --> Database Driver Class Initialized
INFO - 2018-07-31 13:34:05 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:34:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:34:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:34:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:34:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:34:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:34:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:34:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-07-31 13:34:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:34:05 --> Final output sent to browser
DEBUG - 2018-07-31 13:34:05 --> Total execution time: 0.0478
INFO - 2018-07-31 13:34:19 --> Config Class Initialized
INFO - 2018-07-31 13:34:19 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:34:19 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:34:19 --> Utf8 Class Initialized
INFO - 2018-07-31 13:34:19 --> URI Class Initialized
DEBUG - 2018-07-31 13:34:19 --> No URI present. Default controller set.
INFO - 2018-07-31 13:34:19 --> Router Class Initialized
INFO - 2018-07-31 13:34:19 --> Output Class Initialized
INFO - 2018-07-31 13:34:19 --> Security Class Initialized
DEBUG - 2018-07-31 13:34:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:34:19 --> CSRF cookie sent
INFO - 2018-07-31 13:34:19 --> Input Class Initialized
INFO - 2018-07-31 13:34:19 --> Language Class Initialized
INFO - 2018-07-31 13:34:19 --> Loader Class Initialized
INFO - 2018-07-31 13:34:19 --> Helper loaded: url_helper
INFO - 2018-07-31 13:34:19 --> Helper loaded: form_helper
INFO - 2018-07-31 13:34:19 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:34:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:34:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:34:19 --> User Agent Class Initialized
INFO - 2018-07-31 13:34:19 --> Controller Class Initialized
INFO - 2018-07-31 13:34:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:34:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:34:19 --> Pixel_Model class loaded
INFO - 2018-07-31 13:34:19 --> Database Driver Class Initialized
INFO - 2018-07-31 13:34:19 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:34:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:34:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:34:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-31 13:34:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:34:19 --> Final output sent to browser
DEBUG - 2018-07-31 13:34:19 --> Total execution time: 0.0332
INFO - 2018-07-31 13:34:26 --> Config Class Initialized
INFO - 2018-07-31 13:34:26 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:34:26 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:34:26 --> Utf8 Class Initialized
INFO - 2018-07-31 13:34:26 --> URI Class Initialized
DEBUG - 2018-07-31 13:34:26 --> No URI present. Default controller set.
INFO - 2018-07-31 13:34:26 --> Router Class Initialized
INFO - 2018-07-31 13:34:26 --> Output Class Initialized
INFO - 2018-07-31 13:34:26 --> Security Class Initialized
DEBUG - 2018-07-31 13:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:34:26 --> CSRF cookie sent
INFO - 2018-07-31 13:34:26 --> Input Class Initialized
INFO - 2018-07-31 13:34:26 --> Language Class Initialized
INFO - 2018-07-31 13:34:26 --> Loader Class Initialized
INFO - 2018-07-31 13:34:26 --> Helper loaded: url_helper
INFO - 2018-07-31 13:34:26 --> Helper loaded: form_helper
INFO - 2018-07-31 13:34:26 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:34:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:34:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:34:26 --> User Agent Class Initialized
INFO - 2018-07-31 13:34:26 --> Controller Class Initialized
INFO - 2018-07-31 13:34:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:34:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:34:26 --> Pixel_Model class loaded
INFO - 2018-07-31 13:34:26 --> Database Driver Class Initialized
INFO - 2018-07-31 13:34:26 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:34:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:34:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:34:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-31 13:34:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:34:26 --> Final output sent to browser
DEBUG - 2018-07-31 13:34:26 --> Total execution time: 0.0352
INFO - 2018-07-31 13:34:45 --> Config Class Initialized
INFO - 2018-07-31 13:34:45 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:34:45 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:34:45 --> Utf8 Class Initialized
INFO - 2018-07-31 13:34:45 --> URI Class Initialized
INFO - 2018-07-31 13:34:45 --> Router Class Initialized
INFO - 2018-07-31 13:34:45 --> Output Class Initialized
INFO - 2018-07-31 13:34:45 --> Security Class Initialized
DEBUG - 2018-07-31 13:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:34:45 --> CSRF cookie sent
INFO - 2018-07-31 13:34:45 --> Input Class Initialized
INFO - 2018-07-31 13:34:45 --> Language Class Initialized
INFO - 2018-07-31 13:34:46 --> Loader Class Initialized
INFO - 2018-07-31 13:34:46 --> Helper loaded: url_helper
INFO - 2018-07-31 13:34:46 --> Helper loaded: form_helper
INFO - 2018-07-31 13:34:46 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:34:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:34:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:34:46 --> User Agent Class Initialized
INFO - 2018-07-31 13:34:46 --> Controller Class Initialized
INFO - 2018-07-31 13:34:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:34:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:34:46 --> Pixel_Model class loaded
INFO - 2018-07-31 13:34:46 --> Database Driver Class Initialized
INFO - 2018-07-31 13:34:46 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:34:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:34:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:34:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:34:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:34:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:34:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:34:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-07-31 13:34:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:34:46 --> Final output sent to browser
DEBUG - 2018-07-31 13:34:46 --> Total execution time: 0.0352
INFO - 2018-07-31 13:34:48 --> Config Class Initialized
INFO - 2018-07-31 13:34:48 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:34:48 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:34:48 --> Utf8 Class Initialized
INFO - 2018-07-31 13:34:48 --> URI Class Initialized
DEBUG - 2018-07-31 13:34:48 --> No URI present. Default controller set.
INFO - 2018-07-31 13:34:48 --> Router Class Initialized
INFO - 2018-07-31 13:34:48 --> Output Class Initialized
INFO - 2018-07-31 13:34:48 --> Security Class Initialized
DEBUG - 2018-07-31 13:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:34:48 --> CSRF cookie sent
INFO - 2018-07-31 13:34:48 --> Input Class Initialized
INFO - 2018-07-31 13:34:48 --> Language Class Initialized
INFO - 2018-07-31 13:34:48 --> Loader Class Initialized
INFO - 2018-07-31 13:34:48 --> Helper loaded: url_helper
INFO - 2018-07-31 13:34:48 --> Helper loaded: form_helper
INFO - 2018-07-31 13:34:48 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:34:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:34:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:34:48 --> User Agent Class Initialized
INFO - 2018-07-31 13:34:48 --> Controller Class Initialized
INFO - 2018-07-31 13:34:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:34:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:34:48 --> Pixel_Model class loaded
INFO - 2018-07-31 13:34:48 --> Database Driver Class Initialized
INFO - 2018-07-31 13:34:48 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:34:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:34:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:34:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-31 13:34:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:34:48 --> Final output sent to browser
DEBUG - 2018-07-31 13:34:48 --> Total execution time: 0.0401
INFO - 2018-07-31 13:34:52 --> Config Class Initialized
INFO - 2018-07-31 13:34:52 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:34:52 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:34:52 --> Utf8 Class Initialized
INFO - 2018-07-31 13:34:52 --> URI Class Initialized
INFO - 2018-07-31 13:34:52 --> Router Class Initialized
INFO - 2018-07-31 13:34:52 --> Output Class Initialized
INFO - 2018-07-31 13:34:52 --> Security Class Initialized
DEBUG - 2018-07-31 13:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:34:52 --> CSRF cookie sent
INFO - 2018-07-31 13:34:52 --> Input Class Initialized
INFO - 2018-07-31 13:34:52 --> Language Class Initialized
INFO - 2018-07-31 13:34:52 --> Loader Class Initialized
INFO - 2018-07-31 13:34:52 --> Helper loaded: url_helper
INFO - 2018-07-31 13:34:52 --> Helper loaded: form_helper
INFO - 2018-07-31 13:34:52 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:34:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:34:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:34:52 --> User Agent Class Initialized
INFO - 2018-07-31 13:34:52 --> Controller Class Initialized
INFO - 2018-07-31 13:34:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:34:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:34:52 --> Pixel_Model class loaded
INFO - 2018-07-31 13:34:52 --> Database Driver Class Initialized
INFO - 2018-07-31 13:34:52 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:34:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:34:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:34:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:34:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:34:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:34:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:34:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-07-31 13:34:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:34:52 --> Final output sent to browser
DEBUG - 2018-07-31 13:34:52 --> Total execution time: 0.0360
INFO - 2018-07-31 13:35:07 --> Config Class Initialized
INFO - 2018-07-31 13:35:07 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:35:07 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:35:07 --> Utf8 Class Initialized
INFO - 2018-07-31 13:35:07 --> URI Class Initialized
INFO - 2018-07-31 13:35:07 --> Router Class Initialized
INFO - 2018-07-31 13:35:07 --> Output Class Initialized
INFO - 2018-07-31 13:35:07 --> Security Class Initialized
DEBUG - 2018-07-31 13:35:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:35:07 --> CSRF cookie sent
INFO - 2018-07-31 13:35:07 --> Input Class Initialized
INFO - 2018-07-31 13:35:07 --> Language Class Initialized
INFO - 2018-07-31 13:35:07 --> Loader Class Initialized
INFO - 2018-07-31 13:35:07 --> Helper loaded: url_helper
INFO - 2018-07-31 13:35:07 --> Helper loaded: form_helper
INFO - 2018-07-31 13:35:07 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:35:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:35:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:35:07 --> User Agent Class Initialized
INFO - 2018-07-31 13:35:07 --> Controller Class Initialized
INFO - 2018-07-31 13:35:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:35:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:35:07 --> Pixel_Model class loaded
INFO - 2018-07-31 13:35:07 --> Database Driver Class Initialized
INFO - 2018-07-31 13:35:07 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:35:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:35:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:35:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:35:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:35:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:35:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:35:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-07-31 13:35:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:35:07 --> Final output sent to browser
DEBUG - 2018-07-31 13:35:07 --> Total execution time: 0.0352
INFO - 2018-07-31 13:35:11 --> Config Class Initialized
INFO - 2018-07-31 13:35:11 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:35:11 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:35:11 --> Utf8 Class Initialized
INFO - 2018-07-31 13:35:11 --> URI Class Initialized
INFO - 2018-07-31 13:35:11 --> Router Class Initialized
INFO - 2018-07-31 13:35:11 --> Output Class Initialized
INFO - 2018-07-31 13:35:11 --> Security Class Initialized
DEBUG - 2018-07-31 13:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:35:11 --> CSRF cookie sent
INFO - 2018-07-31 13:35:11 --> CSRF token verified
INFO - 2018-07-31 13:35:11 --> Input Class Initialized
INFO - 2018-07-31 13:35:11 --> Language Class Initialized
INFO - 2018-07-31 13:35:11 --> Loader Class Initialized
INFO - 2018-07-31 13:35:11 --> Helper loaded: url_helper
INFO - 2018-07-31 13:35:11 --> Helper loaded: form_helper
INFO - 2018-07-31 13:35:11 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:35:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:35:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:35:11 --> User Agent Class Initialized
INFO - 2018-07-31 13:35:11 --> Controller Class Initialized
INFO - 2018-07-31 13:35:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:35:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:35:11 --> Pixel_Model class loaded
INFO - 2018-07-31 13:35:11 --> Database Driver Class Initialized
INFO - 2018-07-31 13:35:11 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:35:11 --> Database Driver Class Initialized
INFO - 2018-07-31 13:35:11 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:35:11 --> Config Class Initialized
INFO - 2018-07-31 13:35:11 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:35:11 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:35:11 --> Utf8 Class Initialized
INFO - 2018-07-31 13:35:11 --> URI Class Initialized
INFO - 2018-07-31 13:35:11 --> Router Class Initialized
INFO - 2018-07-31 13:35:11 --> Output Class Initialized
INFO - 2018-07-31 13:35:11 --> Security Class Initialized
DEBUG - 2018-07-31 13:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:35:11 --> CSRF cookie sent
INFO - 2018-07-31 13:35:11 --> Input Class Initialized
INFO - 2018-07-31 13:35:11 --> Language Class Initialized
INFO - 2018-07-31 13:35:11 --> Loader Class Initialized
INFO - 2018-07-31 13:35:11 --> Helper loaded: url_helper
INFO - 2018-07-31 13:35:11 --> Helper loaded: form_helper
INFO - 2018-07-31 13:35:11 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:35:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:35:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:35:11 --> User Agent Class Initialized
INFO - 2018-07-31 13:35:11 --> Controller Class Initialized
INFO - 2018-07-31 13:35:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:35:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:35:11 --> Pixel_Model class loaded
INFO - 2018-07-31 13:35:11 --> Database Driver Class Initialized
INFO - 2018-07-31 13:35:11 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:35:11 --> Database Driver Class Initialized
INFO - 2018-07-31 13:35:11 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:35:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:35:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:35:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:35:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:35:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:35:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:35:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-07-31 13:35:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:35:11 --> Final output sent to browser
DEBUG - 2018-07-31 13:35:11 --> Total execution time: 0.0614
INFO - 2018-07-31 13:35:22 --> Config Class Initialized
INFO - 2018-07-31 13:35:22 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:35:22 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:35:22 --> Utf8 Class Initialized
INFO - 2018-07-31 13:35:22 --> URI Class Initialized
INFO - 2018-07-31 13:35:22 --> Router Class Initialized
INFO - 2018-07-31 13:35:22 --> Output Class Initialized
INFO - 2018-07-31 13:35:22 --> Security Class Initialized
DEBUG - 2018-07-31 13:35:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:35:22 --> CSRF cookie sent
INFO - 2018-07-31 13:35:22 --> Input Class Initialized
INFO - 2018-07-31 13:35:22 --> Language Class Initialized
INFO - 2018-07-31 13:35:22 --> Loader Class Initialized
INFO - 2018-07-31 13:35:22 --> Helper loaded: url_helper
INFO - 2018-07-31 13:35:22 --> Helper loaded: form_helper
INFO - 2018-07-31 13:35:22 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:35:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:35:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:35:22 --> User Agent Class Initialized
INFO - 2018-07-31 13:35:22 --> Controller Class Initialized
INFO - 2018-07-31 13:35:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:35:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:35:22 --> Pixel_Model class loaded
INFO - 2018-07-31 13:35:22 --> Database Driver Class Initialized
INFO - 2018-07-31 13:35:22 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:35:22 --> Config Class Initialized
INFO - 2018-07-31 13:35:22 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:35:22 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:35:22 --> Utf8 Class Initialized
INFO - 2018-07-31 13:35:22 --> URI Class Initialized
INFO - 2018-07-31 13:35:22 --> Router Class Initialized
INFO - 2018-07-31 13:35:22 --> Output Class Initialized
INFO - 2018-07-31 13:35:22 --> Security Class Initialized
DEBUG - 2018-07-31 13:35:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:35:22 --> CSRF cookie sent
INFO - 2018-07-31 13:35:22 --> Input Class Initialized
INFO - 2018-07-31 13:35:22 --> Language Class Initialized
INFO - 2018-07-31 13:35:22 --> Loader Class Initialized
INFO - 2018-07-31 13:35:22 --> Helper loaded: url_helper
INFO - 2018-07-31 13:35:22 --> Helper loaded: form_helper
INFO - 2018-07-31 13:35:22 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:35:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:35:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:35:22 --> User Agent Class Initialized
INFO - 2018-07-31 13:35:22 --> Controller Class Initialized
INFO - 2018-07-31 13:35:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:35:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:35:22 --> Pixel_Model class loaded
INFO - 2018-07-31 13:35:22 --> Database Driver Class Initialized
INFO - 2018-07-31 13:35:22 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:35:22 --> Database Driver Class Initialized
INFO - 2018-07-31 13:35:22 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:35:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:35:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:35:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-07-31 13:35:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:35:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:35:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:35:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:35:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-07-31 13:35:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:35:22 --> Final output sent to browser
DEBUG - 2018-07-31 13:35:22 --> Total execution time: 0.0602
INFO - 2018-07-31 13:35:30 --> Config Class Initialized
INFO - 2018-07-31 13:35:30 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:35:30 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:35:30 --> Utf8 Class Initialized
INFO - 2018-07-31 13:35:30 --> URI Class Initialized
INFO - 2018-07-31 13:35:30 --> Router Class Initialized
INFO - 2018-07-31 13:35:30 --> Output Class Initialized
INFO - 2018-07-31 13:35:30 --> Security Class Initialized
DEBUG - 2018-07-31 13:35:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:35:30 --> CSRF cookie sent
INFO - 2018-07-31 13:35:30 --> CSRF token verified
INFO - 2018-07-31 13:35:30 --> Input Class Initialized
INFO - 2018-07-31 13:35:30 --> Language Class Initialized
INFO - 2018-07-31 13:35:30 --> Loader Class Initialized
INFO - 2018-07-31 13:35:30 --> Helper loaded: url_helper
INFO - 2018-07-31 13:35:30 --> Helper loaded: form_helper
INFO - 2018-07-31 13:35:30 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:35:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:35:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:35:30 --> User Agent Class Initialized
INFO - 2018-07-31 13:35:30 --> Controller Class Initialized
INFO - 2018-07-31 13:35:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:35:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:35:30 --> Pixel_Model class loaded
INFO - 2018-07-31 13:35:30 --> Database Driver Class Initialized
INFO - 2018-07-31 13:35:30 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:35:30 --> Form Validation Class Initialized
INFO - 2018-07-31 13:35:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-07-31 13:35:30 --> Database Driver Class Initialized
INFO - 2018-07-31 13:35:30 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:35:30 --> Config Class Initialized
INFO - 2018-07-31 13:35:30 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:35:30 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:35:30 --> Utf8 Class Initialized
INFO - 2018-07-31 13:35:30 --> URI Class Initialized
INFO - 2018-07-31 13:35:30 --> Router Class Initialized
INFO - 2018-07-31 13:35:30 --> Output Class Initialized
INFO - 2018-07-31 13:35:30 --> Security Class Initialized
DEBUG - 2018-07-31 13:35:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:35:30 --> CSRF cookie sent
INFO - 2018-07-31 13:35:30 --> Input Class Initialized
INFO - 2018-07-31 13:35:30 --> Language Class Initialized
INFO - 2018-07-31 13:35:30 --> Loader Class Initialized
INFO - 2018-07-31 13:35:30 --> Helper loaded: url_helper
INFO - 2018-07-31 13:35:30 --> Helper loaded: form_helper
INFO - 2018-07-31 13:35:30 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:35:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:35:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:35:30 --> User Agent Class Initialized
INFO - 2018-07-31 13:35:30 --> Controller Class Initialized
INFO - 2018-07-31 13:35:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:35:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:35:30 --> Pixel_Model class loaded
INFO - 2018-07-31 13:35:30 --> Database Driver Class Initialized
INFO - 2018-07-31 13:35:30 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:35:30 --> Database Driver Class Initialized
INFO - 2018-07-31 13:35:30 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:35:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:35:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:35:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:35:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:35:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:35:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:35:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-07-31 13:35:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:35:30 --> Final output sent to browser
DEBUG - 2018-07-31 13:35:30 --> Total execution time: 0.0499
INFO - 2018-07-31 13:36:17 --> Config Class Initialized
INFO - 2018-07-31 13:36:17 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:36:17 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:36:17 --> Utf8 Class Initialized
INFO - 2018-07-31 13:36:17 --> URI Class Initialized
INFO - 2018-07-31 13:36:17 --> Router Class Initialized
INFO - 2018-07-31 13:36:17 --> Output Class Initialized
INFO - 2018-07-31 13:36:17 --> Security Class Initialized
DEBUG - 2018-07-31 13:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:36:17 --> CSRF cookie sent
INFO - 2018-07-31 13:36:17 --> Input Class Initialized
INFO - 2018-07-31 13:36:17 --> Language Class Initialized
INFO - 2018-07-31 13:36:17 --> Loader Class Initialized
INFO - 2018-07-31 13:36:17 --> Helper loaded: url_helper
INFO - 2018-07-31 13:36:17 --> Helper loaded: form_helper
INFO - 2018-07-31 13:36:17 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:36:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:36:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:36:17 --> User Agent Class Initialized
INFO - 2018-07-31 13:36:17 --> Controller Class Initialized
INFO - 2018-07-31 13:36:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:36:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:36:17 --> Pixel_Model class loaded
INFO - 2018-07-31 13:36:17 --> Database Driver Class Initialized
INFO - 2018-07-31 13:36:17 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:36:17 --> Database Driver Class Initialized
INFO - 2018-07-31 13:36:17 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:36:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:36:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:36:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-07-31 13:36:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:36:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:36:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:36:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:36:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-07-31 13:36:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:36:17 --> Final output sent to browser
DEBUG - 2018-07-31 13:36:17 --> Total execution time: 0.0478
INFO - 2018-07-31 13:36:26 --> Config Class Initialized
INFO - 2018-07-31 13:36:26 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:36:26 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:36:26 --> Utf8 Class Initialized
INFO - 2018-07-31 13:36:26 --> URI Class Initialized
DEBUG - 2018-07-31 13:36:26 --> No URI present. Default controller set.
INFO - 2018-07-31 13:36:26 --> Router Class Initialized
INFO - 2018-07-31 13:36:26 --> Output Class Initialized
INFO - 2018-07-31 13:36:26 --> Security Class Initialized
DEBUG - 2018-07-31 13:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:36:26 --> CSRF cookie sent
INFO - 2018-07-31 13:36:26 --> Input Class Initialized
INFO - 2018-07-31 13:36:26 --> Language Class Initialized
INFO - 2018-07-31 13:36:26 --> Loader Class Initialized
INFO - 2018-07-31 13:36:26 --> Helper loaded: url_helper
INFO - 2018-07-31 13:36:26 --> Helper loaded: form_helper
INFO - 2018-07-31 13:36:26 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:36:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:36:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:36:26 --> User Agent Class Initialized
INFO - 2018-07-31 13:36:26 --> Controller Class Initialized
INFO - 2018-07-31 13:36:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:36:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:36:26 --> Pixel_Model class loaded
INFO - 2018-07-31 13:36:26 --> Database Driver Class Initialized
INFO - 2018-07-31 13:36:26 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:36:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:36:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:36:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-31 13:36:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:36:26 --> Final output sent to browser
DEBUG - 2018-07-31 13:36:26 --> Total execution time: 0.0387
INFO - 2018-07-31 13:36:36 --> Config Class Initialized
INFO - 2018-07-31 13:36:36 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:36:36 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:36:36 --> Utf8 Class Initialized
INFO - 2018-07-31 13:36:36 --> URI Class Initialized
INFO - 2018-07-31 13:36:36 --> Router Class Initialized
INFO - 2018-07-31 13:36:36 --> Output Class Initialized
INFO - 2018-07-31 13:36:36 --> Security Class Initialized
DEBUG - 2018-07-31 13:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:36:36 --> CSRF cookie sent
INFO - 2018-07-31 13:36:36 --> CSRF token verified
INFO - 2018-07-31 13:36:36 --> Input Class Initialized
INFO - 2018-07-31 13:36:36 --> Language Class Initialized
INFO - 2018-07-31 13:36:36 --> Loader Class Initialized
INFO - 2018-07-31 13:36:36 --> Helper loaded: url_helper
INFO - 2018-07-31 13:36:36 --> Helper loaded: form_helper
INFO - 2018-07-31 13:36:36 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:36:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:36:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:36:36 --> User Agent Class Initialized
INFO - 2018-07-31 13:36:36 --> Controller Class Initialized
INFO - 2018-07-31 13:36:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:36:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:36:36 --> Pixel_Model class loaded
INFO - 2018-07-31 13:36:36 --> Database Driver Class Initialized
INFO - 2018-07-31 13:36:36 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:36:36 --> Database Driver Class Initialized
INFO - 2018-07-31 13:36:36 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:36:36 --> Config Class Initialized
INFO - 2018-07-31 13:36:36 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:36:36 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:36:36 --> Utf8 Class Initialized
INFO - 2018-07-31 13:36:36 --> URI Class Initialized
INFO - 2018-07-31 13:36:36 --> Router Class Initialized
INFO - 2018-07-31 13:36:36 --> Output Class Initialized
INFO - 2018-07-31 13:36:36 --> Security Class Initialized
DEBUG - 2018-07-31 13:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:36:36 --> CSRF cookie sent
INFO - 2018-07-31 13:36:36 --> Input Class Initialized
INFO - 2018-07-31 13:36:36 --> Language Class Initialized
INFO - 2018-07-31 13:36:36 --> Loader Class Initialized
INFO - 2018-07-31 13:36:36 --> Helper loaded: url_helper
INFO - 2018-07-31 13:36:36 --> Helper loaded: form_helper
INFO - 2018-07-31 13:36:36 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:36:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:36:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:36:36 --> User Agent Class Initialized
INFO - 2018-07-31 13:36:36 --> Controller Class Initialized
INFO - 2018-07-31 13:36:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:36:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:36:36 --> Pixel_Model class loaded
INFO - 2018-07-31 13:36:36 --> Database Driver Class Initialized
INFO - 2018-07-31 13:36:36 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:36:36 --> Database Driver Class Initialized
INFO - 2018-07-31 13:36:36 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:36:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:36:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:36:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:36:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:36:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:36:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:36:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-07-31 13:36:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:36:36 --> Final output sent to browser
DEBUG - 2018-07-31 13:36:36 --> Total execution time: 0.0529
INFO - 2018-07-31 13:36:39 --> Config Class Initialized
INFO - 2018-07-31 13:36:39 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:36:39 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:36:39 --> Utf8 Class Initialized
INFO - 2018-07-31 13:36:39 --> URI Class Initialized
INFO - 2018-07-31 13:36:39 --> Router Class Initialized
INFO - 2018-07-31 13:36:39 --> Output Class Initialized
INFO - 2018-07-31 13:36:39 --> Security Class Initialized
DEBUG - 2018-07-31 13:36:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:36:39 --> CSRF cookie sent
INFO - 2018-07-31 13:36:39 --> CSRF token verified
INFO - 2018-07-31 13:36:39 --> Input Class Initialized
INFO - 2018-07-31 13:36:39 --> Language Class Initialized
INFO - 2018-07-31 13:36:39 --> Loader Class Initialized
INFO - 2018-07-31 13:36:39 --> Helper loaded: url_helper
INFO - 2018-07-31 13:36:39 --> Helper loaded: form_helper
INFO - 2018-07-31 13:36:39 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:36:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:36:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:36:39 --> User Agent Class Initialized
INFO - 2018-07-31 13:36:39 --> Controller Class Initialized
INFO - 2018-07-31 13:36:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:36:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:36:39 --> Pixel_Model class loaded
INFO - 2018-07-31 13:36:39 --> Database Driver Class Initialized
INFO - 2018-07-31 13:36:39 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:36:39 --> Form Validation Class Initialized
INFO - 2018-07-31 13:36:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-07-31 13:36:39 --> Database Driver Class Initialized
INFO - 2018-07-31 13:36:39 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:36:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:36:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:36:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:36:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:36:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:36:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_errors.php
INFO - 2018-07-31 13:36:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:36:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-07-31 13:36:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:36:39 --> Final output sent to browser
DEBUG - 2018-07-31 13:36:39 --> Total execution time: 0.0558
INFO - 2018-07-31 13:36:42 --> Config Class Initialized
INFO - 2018-07-31 13:36:42 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:36:42 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:36:42 --> Utf8 Class Initialized
INFO - 2018-07-31 13:36:42 --> URI Class Initialized
INFO - 2018-07-31 13:36:42 --> Router Class Initialized
INFO - 2018-07-31 13:36:42 --> Output Class Initialized
INFO - 2018-07-31 13:36:42 --> Security Class Initialized
DEBUG - 2018-07-31 13:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:36:42 --> CSRF cookie sent
INFO - 2018-07-31 13:36:42 --> CSRF token verified
INFO - 2018-07-31 13:36:42 --> Input Class Initialized
INFO - 2018-07-31 13:36:42 --> Language Class Initialized
INFO - 2018-07-31 13:36:42 --> Loader Class Initialized
INFO - 2018-07-31 13:36:42 --> Helper loaded: url_helper
INFO - 2018-07-31 13:36:42 --> Helper loaded: form_helper
INFO - 2018-07-31 13:36:42 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:36:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:36:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:36:42 --> User Agent Class Initialized
INFO - 2018-07-31 13:36:42 --> Controller Class Initialized
INFO - 2018-07-31 13:36:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:36:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:36:42 --> Pixel_Model class loaded
INFO - 2018-07-31 13:36:42 --> Database Driver Class Initialized
INFO - 2018-07-31 13:36:42 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:36:42 --> Form Validation Class Initialized
INFO - 2018-07-31 13:36:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-07-31 13:36:42 --> Database Driver Class Initialized
INFO - 2018-07-31 13:36:42 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:36:42 --> Config Class Initialized
INFO - 2018-07-31 13:36:42 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:36:42 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:36:42 --> Utf8 Class Initialized
INFO - 2018-07-31 13:36:42 --> URI Class Initialized
INFO - 2018-07-31 13:36:42 --> Router Class Initialized
INFO - 2018-07-31 13:36:42 --> Output Class Initialized
INFO - 2018-07-31 13:36:42 --> Security Class Initialized
DEBUG - 2018-07-31 13:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:36:42 --> CSRF cookie sent
INFO - 2018-07-31 13:36:42 --> Input Class Initialized
INFO - 2018-07-31 13:36:42 --> Language Class Initialized
INFO - 2018-07-31 13:36:42 --> Loader Class Initialized
INFO - 2018-07-31 13:36:42 --> Helper loaded: url_helper
INFO - 2018-07-31 13:36:42 --> Helper loaded: form_helper
INFO - 2018-07-31 13:36:42 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:36:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:36:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:36:42 --> User Agent Class Initialized
INFO - 2018-07-31 13:36:42 --> Controller Class Initialized
INFO - 2018-07-31 13:36:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:36:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:36:42 --> Pixel_Model class loaded
INFO - 2018-07-31 13:36:42 --> Database Driver Class Initialized
INFO - 2018-07-31 13:36:42 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:36:42 --> Database Driver Class Initialized
INFO - 2018-07-31 13:36:42 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:36:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:36:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:36:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:36:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:36:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:36:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:36:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-07-31 13:36:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:36:42 --> Final output sent to browser
DEBUG - 2018-07-31 13:36:42 --> Total execution time: 0.0601
INFO - 2018-07-31 13:36:44 --> Config Class Initialized
INFO - 2018-07-31 13:36:44 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:36:44 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:36:44 --> Utf8 Class Initialized
INFO - 2018-07-31 13:36:44 --> URI Class Initialized
INFO - 2018-07-31 13:36:44 --> Router Class Initialized
INFO - 2018-07-31 13:36:44 --> Output Class Initialized
INFO - 2018-07-31 13:36:44 --> Security Class Initialized
DEBUG - 2018-07-31 13:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:36:44 --> CSRF cookie sent
INFO - 2018-07-31 13:36:44 --> CSRF token verified
INFO - 2018-07-31 13:36:44 --> Input Class Initialized
INFO - 2018-07-31 13:36:44 --> Language Class Initialized
INFO - 2018-07-31 13:36:44 --> Loader Class Initialized
INFO - 2018-07-31 13:36:44 --> Helper loaded: url_helper
INFO - 2018-07-31 13:36:44 --> Helper loaded: form_helper
INFO - 2018-07-31 13:36:44 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:36:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:36:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:36:44 --> User Agent Class Initialized
INFO - 2018-07-31 13:36:44 --> Controller Class Initialized
INFO - 2018-07-31 13:36:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:36:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:36:44 --> Pixel_Model class loaded
INFO - 2018-07-31 13:36:44 --> Database Driver Class Initialized
INFO - 2018-07-31 13:36:44 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:36:44 --> Form Validation Class Initialized
INFO - 2018-07-31 13:36:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-07-31 13:36:44 --> Database Driver Class Initialized
INFO - 2018-07-31 13:36:44 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:36:44 --> Config Class Initialized
INFO - 2018-07-31 13:36:44 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:36:44 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:36:44 --> Utf8 Class Initialized
INFO - 2018-07-31 13:36:44 --> URI Class Initialized
INFO - 2018-07-31 13:36:44 --> Router Class Initialized
INFO - 2018-07-31 13:36:44 --> Output Class Initialized
INFO - 2018-07-31 13:36:44 --> Security Class Initialized
DEBUG - 2018-07-31 13:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:36:44 --> CSRF cookie sent
INFO - 2018-07-31 13:36:44 --> Input Class Initialized
INFO - 2018-07-31 13:36:44 --> Language Class Initialized
INFO - 2018-07-31 13:36:44 --> Loader Class Initialized
INFO - 2018-07-31 13:36:44 --> Helper loaded: url_helper
INFO - 2018-07-31 13:36:44 --> Helper loaded: form_helper
INFO - 2018-07-31 13:36:44 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:36:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:36:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:36:44 --> User Agent Class Initialized
INFO - 2018-07-31 13:36:44 --> Controller Class Initialized
INFO - 2018-07-31 13:36:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:36:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:36:44 --> Pixel_Model class loaded
INFO - 2018-07-31 13:36:44 --> Database Driver Class Initialized
INFO - 2018-07-31 13:36:44 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:36:44 --> Database Driver Class Initialized
INFO - 2018-07-31 13:36:44 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:36:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:36:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:36:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-07-31 13:36:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:36:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:36:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:36:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:36:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-07-31 13:36:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:36:44 --> Final output sent to browser
DEBUG - 2018-07-31 13:36:44 --> Total execution time: 0.0390
INFO - 2018-07-31 13:36:47 --> Config Class Initialized
INFO - 2018-07-31 13:36:47 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:36:47 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:36:47 --> Utf8 Class Initialized
INFO - 2018-07-31 13:36:47 --> URI Class Initialized
DEBUG - 2018-07-31 13:36:47 --> No URI present. Default controller set.
INFO - 2018-07-31 13:36:47 --> Router Class Initialized
INFO - 2018-07-31 13:36:47 --> Output Class Initialized
INFO - 2018-07-31 13:36:47 --> Security Class Initialized
DEBUG - 2018-07-31 13:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:36:47 --> CSRF cookie sent
INFO - 2018-07-31 13:36:47 --> Input Class Initialized
INFO - 2018-07-31 13:36:47 --> Language Class Initialized
INFO - 2018-07-31 13:36:47 --> Loader Class Initialized
INFO - 2018-07-31 13:36:47 --> Helper loaded: url_helper
INFO - 2018-07-31 13:36:47 --> Helper loaded: form_helper
INFO - 2018-07-31 13:36:47 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:36:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:36:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:36:47 --> User Agent Class Initialized
INFO - 2018-07-31 13:36:47 --> Controller Class Initialized
INFO - 2018-07-31 13:36:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:36:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:36:47 --> Pixel_Model class loaded
INFO - 2018-07-31 13:36:47 --> Database Driver Class Initialized
INFO - 2018-07-31 13:36:47 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:36:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:36:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:36:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-31 13:36:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:36:47 --> Final output sent to browser
DEBUG - 2018-07-31 13:36:47 --> Total execution time: 0.0358
INFO - 2018-07-31 13:36:56 --> Config Class Initialized
INFO - 2018-07-31 13:36:56 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:36:56 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:36:56 --> Utf8 Class Initialized
INFO - 2018-07-31 13:36:56 --> URI Class Initialized
INFO - 2018-07-31 13:36:56 --> Router Class Initialized
INFO - 2018-07-31 13:36:56 --> Output Class Initialized
INFO - 2018-07-31 13:36:56 --> Security Class Initialized
DEBUG - 2018-07-31 13:36:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:36:56 --> CSRF cookie sent
INFO - 2018-07-31 13:36:56 --> Input Class Initialized
INFO - 2018-07-31 13:36:56 --> Language Class Initialized
INFO - 2018-07-31 13:36:56 --> Loader Class Initialized
INFO - 2018-07-31 13:36:56 --> Helper loaded: url_helper
INFO - 2018-07-31 13:36:56 --> Helper loaded: form_helper
INFO - 2018-07-31 13:36:56 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:36:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:36:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:36:56 --> User Agent Class Initialized
INFO - 2018-07-31 13:36:56 --> Controller Class Initialized
INFO - 2018-07-31 13:36:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:36:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:36:56 --> Pixel_Model class loaded
INFO - 2018-07-31 13:36:56 --> Database Driver Class Initialized
INFO - 2018-07-31 13:36:56 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:36:56 --> Config Class Initialized
INFO - 2018-07-31 13:36:56 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:36:56 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:36:56 --> Utf8 Class Initialized
INFO - 2018-07-31 13:36:56 --> URI Class Initialized
INFO - 2018-07-31 13:36:56 --> Router Class Initialized
INFO - 2018-07-31 13:36:56 --> Output Class Initialized
INFO - 2018-07-31 13:36:56 --> Security Class Initialized
DEBUG - 2018-07-31 13:36:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:36:56 --> CSRF cookie sent
INFO - 2018-07-31 13:36:56 --> Input Class Initialized
INFO - 2018-07-31 13:36:56 --> Language Class Initialized
INFO - 2018-07-31 13:36:56 --> Loader Class Initialized
INFO - 2018-07-31 13:36:56 --> Helper loaded: url_helper
INFO - 2018-07-31 13:36:56 --> Helper loaded: form_helper
INFO - 2018-07-31 13:36:56 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:36:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:36:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:36:56 --> User Agent Class Initialized
INFO - 2018-07-31 13:36:56 --> Controller Class Initialized
INFO - 2018-07-31 13:36:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:36:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:36:56 --> Pixel_Model class loaded
INFO - 2018-07-31 13:36:56 --> Database Driver Class Initialized
INFO - 2018-07-31 13:36:56 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:36:56 --> Database Driver Class Initialized
INFO - 2018-07-31 13:36:56 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:36:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:36:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:36:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:36:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:36:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:36:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:36:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-07-31 13:36:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:36:56 --> Final output sent to browser
DEBUG - 2018-07-31 13:36:56 --> Total execution time: 0.0396
INFO - 2018-07-31 13:36:58 --> Config Class Initialized
INFO - 2018-07-31 13:36:58 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:36:58 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:36:58 --> Utf8 Class Initialized
INFO - 2018-07-31 13:36:58 --> URI Class Initialized
INFO - 2018-07-31 13:36:58 --> Router Class Initialized
INFO - 2018-07-31 13:36:58 --> Output Class Initialized
INFO - 2018-07-31 13:36:58 --> Security Class Initialized
DEBUG - 2018-07-31 13:36:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:36:58 --> CSRF cookie sent
INFO - 2018-07-31 13:36:58 --> Input Class Initialized
INFO - 2018-07-31 13:36:58 --> Language Class Initialized
INFO - 2018-07-31 13:36:58 --> Loader Class Initialized
INFO - 2018-07-31 13:36:58 --> Helper loaded: url_helper
INFO - 2018-07-31 13:36:58 --> Helper loaded: form_helper
INFO - 2018-07-31 13:36:58 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:36:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:36:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:36:58 --> User Agent Class Initialized
INFO - 2018-07-31 13:36:58 --> Controller Class Initialized
INFO - 2018-07-31 13:36:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:36:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:36:58 --> Pixel_Model class loaded
INFO - 2018-07-31 13:36:58 --> Database Driver Class Initialized
INFO - 2018-07-31 13:36:58 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:36:58 --> Config Class Initialized
INFO - 2018-07-31 13:36:58 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:36:58 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:36:58 --> Utf8 Class Initialized
INFO - 2018-07-31 13:36:58 --> URI Class Initialized
INFO - 2018-07-31 13:36:58 --> Router Class Initialized
INFO - 2018-07-31 13:36:58 --> Output Class Initialized
INFO - 2018-07-31 13:36:58 --> Security Class Initialized
DEBUG - 2018-07-31 13:36:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:36:58 --> CSRF cookie sent
INFO - 2018-07-31 13:36:58 --> Input Class Initialized
INFO - 2018-07-31 13:36:58 --> Language Class Initialized
INFO - 2018-07-31 13:36:58 --> Loader Class Initialized
INFO - 2018-07-31 13:36:58 --> Helper loaded: url_helper
INFO - 2018-07-31 13:36:58 --> Helper loaded: form_helper
INFO - 2018-07-31 13:36:58 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:36:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:36:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:36:58 --> User Agent Class Initialized
INFO - 2018-07-31 13:36:58 --> Controller Class Initialized
INFO - 2018-07-31 13:36:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:36:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:36:58 --> Pixel_Model class loaded
INFO - 2018-07-31 13:36:58 --> Database Driver Class Initialized
INFO - 2018-07-31 13:36:58 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:36:58 --> Database Driver Class Initialized
INFO - 2018-07-31 13:36:58 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:36:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:36:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:36:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-07-31 13:36:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:36:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:36:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:36:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:36:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-07-31 13:36:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:36:58 --> Final output sent to browser
DEBUG - 2018-07-31 13:36:58 --> Total execution time: 0.0373
INFO - 2018-07-31 13:37:04 --> Config Class Initialized
INFO - 2018-07-31 13:37:04 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:37:04 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:37:04 --> Utf8 Class Initialized
INFO - 2018-07-31 13:37:04 --> URI Class Initialized
DEBUG - 2018-07-31 13:37:04 --> No URI present. Default controller set.
INFO - 2018-07-31 13:37:04 --> Router Class Initialized
INFO - 2018-07-31 13:37:04 --> Output Class Initialized
INFO - 2018-07-31 13:37:04 --> Security Class Initialized
DEBUG - 2018-07-31 13:37:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:37:04 --> CSRF cookie sent
INFO - 2018-07-31 13:37:04 --> Input Class Initialized
INFO - 2018-07-31 13:37:04 --> Language Class Initialized
INFO - 2018-07-31 13:37:04 --> Loader Class Initialized
INFO - 2018-07-31 13:37:04 --> Helper loaded: url_helper
INFO - 2018-07-31 13:37:04 --> Helper loaded: form_helper
INFO - 2018-07-31 13:37:04 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:37:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:37:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:37:04 --> User Agent Class Initialized
INFO - 2018-07-31 13:37:04 --> Controller Class Initialized
INFO - 2018-07-31 13:37:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:37:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:37:04 --> Pixel_Model class loaded
INFO - 2018-07-31 13:37:04 --> Database Driver Class Initialized
INFO - 2018-07-31 13:37:04 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:37:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:37:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:37:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-31 13:37:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:37:04 --> Final output sent to browser
DEBUG - 2018-07-31 13:37:04 --> Total execution time: 0.0347
INFO - 2018-07-31 13:37:09 --> Config Class Initialized
INFO - 2018-07-31 13:37:09 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:37:09 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:37:09 --> Utf8 Class Initialized
INFO - 2018-07-31 13:37:09 --> URI Class Initialized
INFO - 2018-07-31 13:37:09 --> Router Class Initialized
INFO - 2018-07-31 13:37:09 --> Output Class Initialized
INFO - 2018-07-31 13:37:09 --> Security Class Initialized
DEBUG - 2018-07-31 13:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:37:09 --> CSRF cookie sent
INFO - 2018-07-31 13:37:09 --> Input Class Initialized
INFO - 2018-07-31 13:37:09 --> Language Class Initialized
INFO - 2018-07-31 13:37:09 --> Loader Class Initialized
INFO - 2018-07-31 13:37:09 --> Helper loaded: url_helper
INFO - 2018-07-31 13:37:09 --> Helper loaded: form_helper
INFO - 2018-07-31 13:37:09 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:37:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:37:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:37:09 --> User Agent Class Initialized
INFO - 2018-07-31 13:37:09 --> Controller Class Initialized
INFO - 2018-07-31 13:37:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:37:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:37:09 --> Pixel_Model class loaded
INFO - 2018-07-31 13:37:09 --> Database Driver Class Initialized
INFO - 2018-07-31 13:37:09 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:37:09 --> Config Class Initialized
INFO - 2018-07-31 13:37:09 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:37:09 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:37:09 --> Utf8 Class Initialized
INFO - 2018-07-31 13:37:09 --> URI Class Initialized
INFO - 2018-07-31 13:37:09 --> Router Class Initialized
INFO - 2018-07-31 13:37:09 --> Output Class Initialized
INFO - 2018-07-31 13:37:09 --> Security Class Initialized
DEBUG - 2018-07-31 13:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:37:09 --> CSRF cookie sent
INFO - 2018-07-31 13:37:09 --> Input Class Initialized
INFO - 2018-07-31 13:37:09 --> Language Class Initialized
INFO - 2018-07-31 13:37:09 --> Loader Class Initialized
INFO - 2018-07-31 13:37:09 --> Helper loaded: url_helper
INFO - 2018-07-31 13:37:09 --> Helper loaded: form_helper
INFO - 2018-07-31 13:37:09 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:37:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:37:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:37:09 --> User Agent Class Initialized
INFO - 2018-07-31 13:37:09 --> Controller Class Initialized
INFO - 2018-07-31 13:37:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:37:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:37:09 --> Pixel_Model class loaded
INFO - 2018-07-31 13:37:09 --> Database Driver Class Initialized
INFO - 2018-07-31 13:37:09 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:37:09 --> Database Driver Class Initialized
INFO - 2018-07-31 13:37:09 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:37:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:37:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:37:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:37:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:37:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:37:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:37:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-07-31 13:37:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:37:09 --> Final output sent to browser
DEBUG - 2018-07-31 13:37:09 --> Total execution time: 0.0438
INFO - 2018-07-31 13:37:24 --> Config Class Initialized
INFO - 2018-07-31 13:37:24 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:37:24 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:37:24 --> Utf8 Class Initialized
INFO - 2018-07-31 13:37:24 --> URI Class Initialized
INFO - 2018-07-31 13:37:24 --> Router Class Initialized
INFO - 2018-07-31 13:37:24 --> Output Class Initialized
INFO - 2018-07-31 13:37:24 --> Security Class Initialized
DEBUG - 2018-07-31 13:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:37:24 --> CSRF cookie sent
INFO - 2018-07-31 13:37:24 --> CSRF token verified
INFO - 2018-07-31 13:37:24 --> Input Class Initialized
INFO - 2018-07-31 13:37:24 --> Language Class Initialized
INFO - 2018-07-31 13:37:24 --> Loader Class Initialized
INFO - 2018-07-31 13:37:24 --> Helper loaded: url_helper
INFO - 2018-07-31 13:37:24 --> Helper loaded: form_helper
INFO - 2018-07-31 13:37:24 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:37:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:37:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:37:24 --> User Agent Class Initialized
INFO - 2018-07-31 13:37:24 --> Controller Class Initialized
INFO - 2018-07-31 13:37:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:37:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:37:24 --> Pixel_Model class loaded
INFO - 2018-07-31 13:37:24 --> Database Driver Class Initialized
INFO - 2018-07-31 13:37:24 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:37:24 --> Form Validation Class Initialized
INFO - 2018-07-31 13:37:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-07-31 13:37:24 --> Database Driver Class Initialized
INFO - 2018-07-31 13:37:24 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:37:24 --> Config Class Initialized
INFO - 2018-07-31 13:37:24 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:37:24 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:37:24 --> Utf8 Class Initialized
INFO - 2018-07-31 13:37:24 --> URI Class Initialized
INFO - 2018-07-31 13:37:24 --> Router Class Initialized
INFO - 2018-07-31 13:37:24 --> Output Class Initialized
INFO - 2018-07-31 13:37:24 --> Security Class Initialized
DEBUG - 2018-07-31 13:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:37:24 --> CSRF cookie sent
INFO - 2018-07-31 13:37:24 --> Input Class Initialized
INFO - 2018-07-31 13:37:24 --> Language Class Initialized
INFO - 2018-07-31 13:37:24 --> Loader Class Initialized
INFO - 2018-07-31 13:37:24 --> Helper loaded: url_helper
INFO - 2018-07-31 13:37:24 --> Helper loaded: form_helper
INFO - 2018-07-31 13:37:24 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:37:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:37:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:37:24 --> User Agent Class Initialized
INFO - 2018-07-31 13:37:24 --> Controller Class Initialized
INFO - 2018-07-31 13:37:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:37:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:37:24 --> Pixel_Model class loaded
INFO - 2018-07-31 13:37:24 --> Database Driver Class Initialized
INFO - 2018-07-31 13:37:24 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:37:24 --> Database Driver Class Initialized
INFO - 2018-07-31 13:37:24 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:37:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:37:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:37:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:37:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:37:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:37:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:37:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-07-31 13:37:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:37:24 --> Final output sent to browser
DEBUG - 2018-07-31 13:37:24 --> Total execution time: 0.0418
INFO - 2018-07-31 13:37:39 --> Config Class Initialized
INFO - 2018-07-31 13:37:39 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:37:39 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:37:39 --> Utf8 Class Initialized
INFO - 2018-07-31 13:37:39 --> URI Class Initialized
INFO - 2018-07-31 13:37:39 --> Router Class Initialized
INFO - 2018-07-31 13:37:39 --> Output Class Initialized
INFO - 2018-07-31 13:37:39 --> Security Class Initialized
DEBUG - 2018-07-31 13:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:37:39 --> CSRF cookie sent
INFO - 2018-07-31 13:37:39 --> CSRF token verified
INFO - 2018-07-31 13:37:39 --> Input Class Initialized
INFO - 2018-07-31 13:37:39 --> Language Class Initialized
INFO - 2018-07-31 13:37:39 --> Loader Class Initialized
INFO - 2018-07-31 13:37:39 --> Helper loaded: url_helper
INFO - 2018-07-31 13:37:39 --> Helper loaded: form_helper
INFO - 2018-07-31 13:37:39 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:37:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:37:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:37:39 --> User Agent Class Initialized
INFO - 2018-07-31 13:37:39 --> Controller Class Initialized
INFO - 2018-07-31 13:37:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:37:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:37:39 --> Pixel_Model class loaded
INFO - 2018-07-31 13:37:39 --> Database Driver Class Initialized
INFO - 2018-07-31 13:37:39 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:37:39 --> Form Validation Class Initialized
INFO - 2018-07-31 13:37:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-07-31 13:37:39 --> Database Driver Class Initialized
INFO - 2018-07-31 13:37:39 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:37:39 --> Config Class Initialized
INFO - 2018-07-31 13:37:39 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:37:39 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:37:39 --> Utf8 Class Initialized
INFO - 2018-07-31 13:37:39 --> URI Class Initialized
INFO - 2018-07-31 13:37:39 --> Router Class Initialized
INFO - 2018-07-31 13:37:39 --> Output Class Initialized
INFO - 2018-07-31 13:37:39 --> Security Class Initialized
DEBUG - 2018-07-31 13:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:37:39 --> CSRF cookie sent
INFO - 2018-07-31 13:37:39 --> Input Class Initialized
INFO - 2018-07-31 13:37:39 --> Language Class Initialized
INFO - 2018-07-31 13:37:39 --> Loader Class Initialized
INFO - 2018-07-31 13:37:39 --> Helper loaded: url_helper
INFO - 2018-07-31 13:37:39 --> Helper loaded: form_helper
INFO - 2018-07-31 13:37:39 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:37:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:37:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:37:39 --> User Agent Class Initialized
INFO - 2018-07-31 13:37:39 --> Controller Class Initialized
INFO - 2018-07-31 13:37:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:37:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:37:39 --> Pixel_Model class loaded
INFO - 2018-07-31 13:37:39 --> Database Driver Class Initialized
INFO - 2018-07-31 13:37:39 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:37:39 --> Database Driver Class Initialized
INFO - 2018-07-31 13:37:39 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:37:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:37:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:37:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:37:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:37:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:37:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:37:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-07-31 13:37:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:37:39 --> Final output sent to browser
DEBUG - 2018-07-31 13:37:39 --> Total execution time: 0.0616
INFO - 2018-07-31 13:37:43 --> Config Class Initialized
INFO - 2018-07-31 13:37:43 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:37:43 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:37:43 --> Utf8 Class Initialized
INFO - 2018-07-31 13:37:43 --> URI Class Initialized
INFO - 2018-07-31 13:37:43 --> Router Class Initialized
INFO - 2018-07-31 13:37:43 --> Output Class Initialized
INFO - 2018-07-31 13:37:43 --> Security Class Initialized
DEBUG - 2018-07-31 13:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:37:43 --> CSRF cookie sent
INFO - 2018-07-31 13:37:43 --> Input Class Initialized
INFO - 2018-07-31 13:37:43 --> Language Class Initialized
INFO - 2018-07-31 13:37:43 --> Loader Class Initialized
INFO - 2018-07-31 13:37:43 --> Helper loaded: url_helper
INFO - 2018-07-31 13:37:43 --> Helper loaded: form_helper
INFO - 2018-07-31 13:37:43 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:37:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:37:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:37:43 --> User Agent Class Initialized
INFO - 2018-07-31 13:37:43 --> Controller Class Initialized
INFO - 2018-07-31 13:37:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:37:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:37:43 --> Pixel_Model class loaded
INFO - 2018-07-31 13:37:43 --> Database Driver Class Initialized
INFO - 2018-07-31 13:37:43 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:37:43 --> Database Driver Class Initialized
INFO - 2018-07-31 13:37:43 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:37:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:37:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:37:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:37:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:37:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:37:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:37:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-07-31 13:37:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:37:43 --> Final output sent to browser
DEBUG - 2018-07-31 13:37:43 --> Total execution time: 0.0379
INFO - 2018-07-31 13:37:59 --> Config Class Initialized
INFO - 2018-07-31 13:37:59 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:37:59 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:37:59 --> Utf8 Class Initialized
INFO - 2018-07-31 13:37:59 --> URI Class Initialized
INFO - 2018-07-31 13:37:59 --> Router Class Initialized
INFO - 2018-07-31 13:37:59 --> Output Class Initialized
INFO - 2018-07-31 13:37:59 --> Security Class Initialized
DEBUG - 2018-07-31 13:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:37:59 --> CSRF cookie sent
INFO - 2018-07-31 13:37:59 --> CSRF token verified
INFO - 2018-07-31 13:37:59 --> Input Class Initialized
INFO - 2018-07-31 13:37:59 --> Language Class Initialized
INFO - 2018-07-31 13:37:59 --> Loader Class Initialized
INFO - 2018-07-31 13:37:59 --> Helper loaded: url_helper
INFO - 2018-07-31 13:37:59 --> Helper loaded: form_helper
INFO - 2018-07-31 13:37:59 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:37:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:37:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:37:59 --> User Agent Class Initialized
INFO - 2018-07-31 13:37:59 --> Controller Class Initialized
INFO - 2018-07-31 13:37:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:37:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:37:59 --> Pixel_Model class loaded
INFO - 2018-07-31 13:37:59 --> Database Driver Class Initialized
INFO - 2018-07-31 13:37:59 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:37:59 --> Form Validation Class Initialized
INFO - 2018-07-31 13:37:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-07-31 13:37:59 --> Database Driver Class Initialized
INFO - 2018-07-31 13:37:59 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:37:59 --> Config Class Initialized
INFO - 2018-07-31 13:37:59 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:37:59 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:37:59 --> Utf8 Class Initialized
INFO - 2018-07-31 13:37:59 --> URI Class Initialized
INFO - 2018-07-31 13:37:59 --> Router Class Initialized
INFO - 2018-07-31 13:37:59 --> Output Class Initialized
INFO - 2018-07-31 13:37:59 --> Security Class Initialized
DEBUG - 2018-07-31 13:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:37:59 --> CSRF cookie sent
INFO - 2018-07-31 13:37:59 --> Input Class Initialized
INFO - 2018-07-31 13:37:59 --> Language Class Initialized
INFO - 2018-07-31 13:37:59 --> Loader Class Initialized
INFO - 2018-07-31 13:37:59 --> Helper loaded: url_helper
INFO - 2018-07-31 13:37:59 --> Helper loaded: form_helper
INFO - 2018-07-31 13:37:59 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:37:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:37:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:37:59 --> User Agent Class Initialized
INFO - 2018-07-31 13:37:59 --> Controller Class Initialized
INFO - 2018-07-31 13:37:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:37:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:37:59 --> Pixel_Model class loaded
INFO - 2018-07-31 13:37:59 --> Database Driver Class Initialized
INFO - 2018-07-31 13:37:59 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:37:59 --> Database Driver Class Initialized
INFO - 2018-07-31 13:37:59 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:37:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:37:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:37:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:37:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:37:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:37:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:37:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-07-31 13:37:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:37:59 --> Final output sent to browser
DEBUG - 2018-07-31 13:37:59 --> Total execution time: 0.0500
INFO - 2018-07-31 13:38:20 --> Config Class Initialized
INFO - 2018-07-31 13:38:20 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:38:20 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:38:20 --> Utf8 Class Initialized
INFO - 2018-07-31 13:38:20 --> URI Class Initialized
INFO - 2018-07-31 13:38:20 --> Router Class Initialized
INFO - 2018-07-31 13:38:20 --> Output Class Initialized
INFO - 2018-07-31 13:38:20 --> Security Class Initialized
DEBUG - 2018-07-31 13:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:38:20 --> CSRF cookie sent
INFO - 2018-07-31 13:38:20 --> Input Class Initialized
INFO - 2018-07-31 13:38:20 --> Language Class Initialized
INFO - 2018-07-31 13:38:20 --> Loader Class Initialized
INFO - 2018-07-31 13:38:20 --> Helper loaded: url_helper
INFO - 2018-07-31 13:38:20 --> Helper loaded: form_helper
INFO - 2018-07-31 13:38:20 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:38:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:38:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:38:20 --> User Agent Class Initialized
INFO - 2018-07-31 13:38:20 --> Controller Class Initialized
INFO - 2018-07-31 13:38:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:38:20 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-31 13:38:20 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-31 13:38:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:38:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:38:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:38:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-31 13:38:20 --> Could not find the language line "req_email"
INFO - 2018-07-31 13:38:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-31 13:38:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:38:20 --> Final output sent to browser
DEBUG - 2018-07-31 13:38:20 --> Total execution time: 0.0236
INFO - 2018-07-31 13:38:37 --> Config Class Initialized
INFO - 2018-07-31 13:38:37 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:38:37 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:38:37 --> Utf8 Class Initialized
INFO - 2018-07-31 13:38:37 --> URI Class Initialized
INFO - 2018-07-31 13:38:37 --> Router Class Initialized
INFO - 2018-07-31 13:38:37 --> Output Class Initialized
INFO - 2018-07-31 13:38:37 --> Security Class Initialized
DEBUG - 2018-07-31 13:38:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:38:37 --> CSRF cookie sent
INFO - 2018-07-31 13:38:37 --> CSRF token verified
INFO - 2018-07-31 13:38:37 --> Input Class Initialized
INFO - 2018-07-31 13:38:37 --> Language Class Initialized
INFO - 2018-07-31 13:38:37 --> Loader Class Initialized
INFO - 2018-07-31 13:38:37 --> Helper loaded: url_helper
INFO - 2018-07-31 13:38:37 --> Helper loaded: form_helper
INFO - 2018-07-31 13:38:37 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:38:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:38:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:38:37 --> User Agent Class Initialized
INFO - 2018-07-31 13:38:37 --> Controller Class Initialized
INFO - 2018-07-31 13:38:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:38:37 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-31 13:38:37 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-31 13:38:38 --> Form Validation Class Initialized
INFO - 2018-07-31 13:38:38 --> Pixel_Model class loaded
INFO - 2018-07-31 13:38:38 --> Database Driver Class Initialized
INFO - 2018-07-31 13:38:38 --> Model "AuthenticationModel" initialized
INFO - 2018-07-31 13:38:38 --> Config Class Initialized
INFO - 2018-07-31 13:38:38 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:38:38 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:38:38 --> Utf8 Class Initialized
INFO - 2018-07-31 13:38:38 --> URI Class Initialized
INFO - 2018-07-31 13:38:38 --> Router Class Initialized
INFO - 2018-07-31 13:38:38 --> Output Class Initialized
INFO - 2018-07-31 13:38:38 --> Security Class Initialized
DEBUG - 2018-07-31 13:38:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:38:38 --> CSRF cookie sent
INFO - 2018-07-31 13:38:38 --> Input Class Initialized
INFO - 2018-07-31 13:38:38 --> Language Class Initialized
INFO - 2018-07-31 13:38:38 --> Loader Class Initialized
INFO - 2018-07-31 13:38:38 --> Helper loaded: url_helper
INFO - 2018-07-31 13:38:38 --> Helper loaded: form_helper
INFO - 2018-07-31 13:38:38 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:38:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:38:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:38:38 --> User Agent Class Initialized
INFO - 2018-07-31 13:38:38 --> Controller Class Initialized
INFO - 2018-07-31 13:38:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:38:38 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-31 13:38:38 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-31 13:38:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:38:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:38:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:38:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:38:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_soft_error.php
ERROR - 2018-07-31 13:38:38 --> Could not find the language line "req_email"
INFO - 2018-07-31 13:38:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-31 13:38:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:38:38 --> Final output sent to browser
DEBUG - 2018-07-31 13:38:38 --> Total execution time: 0.0332
INFO - 2018-07-31 13:38:55 --> Config Class Initialized
INFO - 2018-07-31 13:38:55 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:38:55 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:38:55 --> Utf8 Class Initialized
INFO - 2018-07-31 13:38:55 --> URI Class Initialized
INFO - 2018-07-31 13:38:55 --> Router Class Initialized
INFO - 2018-07-31 13:38:55 --> Output Class Initialized
INFO - 2018-07-31 13:38:55 --> Security Class Initialized
DEBUG - 2018-07-31 13:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:38:55 --> CSRF cookie sent
INFO - 2018-07-31 13:38:55 --> CSRF token verified
INFO - 2018-07-31 13:38:55 --> Input Class Initialized
INFO - 2018-07-31 13:38:55 --> Language Class Initialized
INFO - 2018-07-31 13:38:55 --> Loader Class Initialized
INFO - 2018-07-31 13:38:55 --> Helper loaded: url_helper
INFO - 2018-07-31 13:38:55 --> Helper loaded: form_helper
INFO - 2018-07-31 13:38:55 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:38:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:38:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:38:55 --> User Agent Class Initialized
INFO - 2018-07-31 13:38:55 --> Controller Class Initialized
INFO - 2018-07-31 13:38:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:38:55 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-31 13:38:55 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-31 13:38:55 --> Form Validation Class Initialized
INFO - 2018-07-31 13:38:55 --> Pixel_Model class loaded
INFO - 2018-07-31 13:38:55 --> Database Driver Class Initialized
INFO - 2018-07-31 13:38:55 --> Model "AuthenticationModel" initialized
INFO - 2018-07-31 13:38:55 --> Database Driver Class Initialized
INFO - 2018-07-31 13:38:55 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:38:55 --> Config Class Initialized
INFO - 2018-07-31 13:38:55 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:38:55 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:38:55 --> Utf8 Class Initialized
INFO - 2018-07-31 13:38:55 --> URI Class Initialized
INFO - 2018-07-31 13:38:55 --> Router Class Initialized
INFO - 2018-07-31 13:38:55 --> Output Class Initialized
INFO - 2018-07-31 13:38:55 --> Security Class Initialized
DEBUG - 2018-07-31 13:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:38:55 --> CSRF cookie sent
INFO - 2018-07-31 13:38:55 --> Input Class Initialized
INFO - 2018-07-31 13:38:55 --> Language Class Initialized
INFO - 2018-07-31 13:38:55 --> Loader Class Initialized
INFO - 2018-07-31 13:38:55 --> Helper loaded: url_helper
INFO - 2018-07-31 13:38:55 --> Helper loaded: form_helper
INFO - 2018-07-31 13:38:55 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:38:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:38:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:38:55 --> User Agent Class Initialized
INFO - 2018-07-31 13:38:55 --> Controller Class Initialized
INFO - 2018-07-31 13:38:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:38:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:38:55 --> Pixel_Model class loaded
INFO - 2018-07-31 13:38:55 --> Database Driver Class Initialized
INFO - 2018-07-31 13:38:55 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:38:55 --> Database Driver Class Initialized
INFO - 2018-07-31 13:38:55 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:38:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:38:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:38:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:38:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:38:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:38:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:38:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:38:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-07-31 13:38:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:38:55 --> Final output sent to browser
DEBUG - 2018-07-31 13:38:55 --> Total execution time: 0.0477
INFO - 2018-07-31 13:39:01 --> Config Class Initialized
INFO - 2018-07-31 13:39:01 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:39:01 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:39:01 --> Utf8 Class Initialized
INFO - 2018-07-31 13:39:01 --> URI Class Initialized
INFO - 2018-07-31 13:39:01 --> Router Class Initialized
INFO - 2018-07-31 13:39:01 --> Output Class Initialized
INFO - 2018-07-31 13:39:01 --> Security Class Initialized
DEBUG - 2018-07-31 13:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:39:01 --> CSRF cookie sent
INFO - 2018-07-31 13:39:01 --> Input Class Initialized
INFO - 2018-07-31 13:39:01 --> Language Class Initialized
INFO - 2018-07-31 13:39:01 --> Loader Class Initialized
INFO - 2018-07-31 13:39:01 --> Helper loaded: url_helper
INFO - 2018-07-31 13:39:01 --> Helper loaded: form_helper
INFO - 2018-07-31 13:39:01 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:39:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:39:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:39:01 --> User Agent Class Initialized
INFO - 2018-07-31 13:39:01 --> Controller Class Initialized
INFO - 2018-07-31 13:39:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:39:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:39:01 --> Pixel_Model class loaded
INFO - 2018-07-31 13:39:01 --> Database Driver Class Initialized
INFO - 2018-07-31 13:39:01 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:39:01 --> Database Driver Class Initialized
INFO - 2018-07-31 13:39:01 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:39:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:39:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:39:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:39:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:39:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:39:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-07-31 13:39:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:39:01 --> Final output sent to browser
DEBUG - 2018-07-31 13:39:01 --> Total execution time: 0.1489
INFO - 2018-07-31 13:39:09 --> Config Class Initialized
INFO - 2018-07-31 13:39:09 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:39:09 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:39:09 --> Utf8 Class Initialized
INFO - 2018-07-31 13:39:09 --> URI Class Initialized
INFO - 2018-07-31 13:39:09 --> Router Class Initialized
INFO - 2018-07-31 13:39:09 --> Output Class Initialized
INFO - 2018-07-31 13:39:09 --> Security Class Initialized
DEBUG - 2018-07-31 13:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:39:09 --> CSRF cookie sent
INFO - 2018-07-31 13:39:09 --> Input Class Initialized
INFO - 2018-07-31 13:39:09 --> Language Class Initialized
INFO - 2018-07-31 13:39:09 --> Loader Class Initialized
INFO - 2018-07-31 13:39:09 --> Helper loaded: url_helper
INFO - 2018-07-31 13:39:09 --> Helper loaded: form_helper
INFO - 2018-07-31 13:39:09 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:39:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:39:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:39:09 --> User Agent Class Initialized
INFO - 2018-07-31 13:39:09 --> Controller Class Initialized
INFO - 2018-07-31 13:39:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:39:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:39:09 --> Pixel_Model class loaded
INFO - 2018-07-31 13:39:09 --> Database Driver Class Initialized
INFO - 2018-07-31 13:39:09 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:39:09 --> Database Driver Class Initialized
INFO - 2018-07-31 13:39:09 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:39:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:39:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:39:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:39:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:39:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:39:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:39:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:39:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-07-31 13:39:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:39:09 --> Final output sent to browser
DEBUG - 2018-07-31 13:39:09 --> Total execution time: 0.0430
INFO - 2018-07-31 13:39:11 --> Config Class Initialized
INFO - 2018-07-31 13:39:11 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:39:11 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:39:11 --> Utf8 Class Initialized
INFO - 2018-07-31 13:39:11 --> URI Class Initialized
INFO - 2018-07-31 13:39:11 --> Router Class Initialized
INFO - 2018-07-31 13:39:11 --> Output Class Initialized
INFO - 2018-07-31 13:39:11 --> Security Class Initialized
DEBUG - 2018-07-31 13:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:39:11 --> CSRF cookie sent
INFO - 2018-07-31 13:39:11 --> Input Class Initialized
INFO - 2018-07-31 13:39:11 --> Language Class Initialized
INFO - 2018-07-31 13:39:11 --> Loader Class Initialized
INFO - 2018-07-31 13:39:11 --> Helper loaded: url_helper
INFO - 2018-07-31 13:39:11 --> Helper loaded: form_helper
INFO - 2018-07-31 13:39:11 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:39:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:39:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:39:11 --> User Agent Class Initialized
INFO - 2018-07-31 13:39:11 --> Controller Class Initialized
INFO - 2018-07-31 13:39:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:39:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:39:11 --> Pixel_Model class loaded
INFO - 2018-07-31 13:39:11 --> Database Driver Class Initialized
INFO - 2018-07-31 13:39:11 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:39:11 --> Database Driver Class Initialized
INFO - 2018-07-31 13:39:11 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:39:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:39:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:39:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:39:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:39:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:39:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:39:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:39:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-07-31 13:39:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:39:11 --> Final output sent to browser
DEBUG - 2018-07-31 13:39:11 --> Total execution time: 0.1342
INFO - 2018-07-31 13:39:12 --> Config Class Initialized
INFO - 2018-07-31 13:39:12 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:39:12 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:39:12 --> Utf8 Class Initialized
INFO - 2018-07-31 13:39:12 --> URI Class Initialized
INFO - 2018-07-31 13:39:12 --> Router Class Initialized
INFO - 2018-07-31 13:39:12 --> Output Class Initialized
INFO - 2018-07-31 13:39:12 --> Security Class Initialized
DEBUG - 2018-07-31 13:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:39:12 --> CSRF cookie sent
INFO - 2018-07-31 13:39:12 --> Input Class Initialized
INFO - 2018-07-31 13:39:12 --> Language Class Initialized
INFO - 2018-07-31 13:39:12 --> Loader Class Initialized
INFO - 2018-07-31 13:39:12 --> Helper loaded: url_helper
INFO - 2018-07-31 13:39:12 --> Helper loaded: form_helper
INFO - 2018-07-31 13:39:12 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:39:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:39:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:39:12 --> User Agent Class Initialized
INFO - 2018-07-31 13:39:12 --> Controller Class Initialized
INFO - 2018-07-31 13:39:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:39:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:39:12 --> Pixel_Model class loaded
INFO - 2018-07-31 13:39:12 --> Database Driver Class Initialized
INFO - 2018-07-31 13:39:12 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:39:12 --> Database Driver Class Initialized
INFO - 2018-07-31 13:39:12 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:39:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:39:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:39:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:39:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:39:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:39:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:39:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:39:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-07-31 13:39:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:39:12 --> Final output sent to browser
DEBUG - 2018-07-31 13:39:12 --> Total execution time: 0.0436
INFO - 2018-07-31 13:39:13 --> Config Class Initialized
INFO - 2018-07-31 13:39:13 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:39:13 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:39:13 --> Utf8 Class Initialized
INFO - 2018-07-31 13:39:13 --> URI Class Initialized
INFO - 2018-07-31 13:39:13 --> Router Class Initialized
INFO - 2018-07-31 13:39:13 --> Output Class Initialized
INFO - 2018-07-31 13:39:13 --> Security Class Initialized
DEBUG - 2018-07-31 13:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:39:13 --> CSRF cookie sent
INFO - 2018-07-31 13:39:13 --> Input Class Initialized
INFO - 2018-07-31 13:39:13 --> Language Class Initialized
INFO - 2018-07-31 13:39:13 --> Loader Class Initialized
INFO - 2018-07-31 13:39:13 --> Helper loaded: url_helper
INFO - 2018-07-31 13:39:13 --> Helper loaded: form_helper
INFO - 2018-07-31 13:39:13 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:39:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:39:13 --> User Agent Class Initialized
INFO - 2018-07-31 13:39:13 --> Controller Class Initialized
INFO - 2018-07-31 13:39:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:39:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:39:13 --> Pixel_Model class loaded
INFO - 2018-07-31 13:39:13 --> Database Driver Class Initialized
INFO - 2018-07-31 13:39:13 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:39:13 --> Database Driver Class Initialized
INFO - 2018-07-31 13:39:13 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:39:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:39:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:39:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:39:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:39:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:39:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:39:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:39:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_title.php
INFO - 2018-07-31 13:39:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:39:13 --> Final output sent to browser
DEBUG - 2018-07-31 13:39:13 --> Total execution time: 0.0631
INFO - 2018-07-31 13:39:15 --> Config Class Initialized
INFO - 2018-07-31 13:39:15 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:39:15 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:39:15 --> Utf8 Class Initialized
INFO - 2018-07-31 13:39:15 --> URI Class Initialized
INFO - 2018-07-31 13:39:15 --> Router Class Initialized
INFO - 2018-07-31 13:39:15 --> Output Class Initialized
INFO - 2018-07-31 13:39:15 --> Security Class Initialized
DEBUG - 2018-07-31 13:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:39:15 --> CSRF cookie sent
INFO - 2018-07-31 13:39:15 --> Input Class Initialized
INFO - 2018-07-31 13:39:15 --> Language Class Initialized
INFO - 2018-07-31 13:39:15 --> Loader Class Initialized
INFO - 2018-07-31 13:39:15 --> Helper loaded: url_helper
INFO - 2018-07-31 13:39:15 --> Helper loaded: form_helper
INFO - 2018-07-31 13:39:15 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:39:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:39:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:39:15 --> User Agent Class Initialized
INFO - 2018-07-31 13:39:15 --> Controller Class Initialized
INFO - 2018-07-31 13:39:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:39:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:39:15 --> Pixel_Model class loaded
INFO - 2018-07-31 13:39:15 --> Database Driver Class Initialized
INFO - 2018-07-31 13:39:15 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:39:15 --> Database Driver Class Initialized
INFO - 2018-07-31 13:39:15 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:39:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:39:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:39:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:39:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:39:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:39:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:39:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:39:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-07-31 13:39:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:39:15 --> Final output sent to browser
DEBUG - 2018-07-31 13:39:15 --> Total execution time: 0.0556
INFO - 2018-07-31 13:39:16 --> Config Class Initialized
INFO - 2018-07-31 13:39:16 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:39:16 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:39:16 --> Utf8 Class Initialized
INFO - 2018-07-31 13:39:16 --> URI Class Initialized
INFO - 2018-07-31 13:39:16 --> Router Class Initialized
INFO - 2018-07-31 13:39:16 --> Output Class Initialized
INFO - 2018-07-31 13:39:16 --> Security Class Initialized
DEBUG - 2018-07-31 13:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:39:16 --> CSRF cookie sent
INFO - 2018-07-31 13:39:16 --> Input Class Initialized
INFO - 2018-07-31 13:39:16 --> Language Class Initialized
INFO - 2018-07-31 13:39:16 --> Loader Class Initialized
INFO - 2018-07-31 13:39:16 --> Helper loaded: url_helper
INFO - 2018-07-31 13:39:16 --> Helper loaded: form_helper
INFO - 2018-07-31 13:39:16 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:39:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:39:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:39:16 --> User Agent Class Initialized
INFO - 2018-07-31 13:39:16 --> Controller Class Initialized
INFO - 2018-07-31 13:39:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:39:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:39:16 --> Pixel_Model class loaded
INFO - 2018-07-31 13:39:16 --> Database Driver Class Initialized
INFO - 2018-07-31 13:39:16 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:39:16 --> Database Driver Class Initialized
INFO - 2018-07-31 13:39:16 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:39:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:39:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:39:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:39:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:39:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:39:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:39:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:39:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-07-31 13:39:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:39:16 --> Final output sent to browser
DEBUG - 2018-07-31 13:39:16 --> Total execution time: 0.0412
INFO - 2018-07-31 13:39:18 --> Config Class Initialized
INFO - 2018-07-31 13:39:18 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:39:18 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:39:18 --> Utf8 Class Initialized
INFO - 2018-07-31 13:39:18 --> URI Class Initialized
INFO - 2018-07-31 13:39:18 --> Router Class Initialized
INFO - 2018-07-31 13:39:18 --> Output Class Initialized
INFO - 2018-07-31 13:39:18 --> Security Class Initialized
DEBUG - 2018-07-31 13:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:39:18 --> CSRF cookie sent
INFO - 2018-07-31 13:39:18 --> Input Class Initialized
INFO - 2018-07-31 13:39:18 --> Language Class Initialized
INFO - 2018-07-31 13:39:18 --> Loader Class Initialized
INFO - 2018-07-31 13:39:18 --> Helper loaded: url_helper
INFO - 2018-07-31 13:39:18 --> Helper loaded: form_helper
INFO - 2018-07-31 13:39:18 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:39:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:39:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:39:18 --> User Agent Class Initialized
INFO - 2018-07-31 13:39:18 --> Controller Class Initialized
INFO - 2018-07-31 13:39:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:39:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:39:18 --> Pixel_Model class loaded
INFO - 2018-07-31 13:39:18 --> Database Driver Class Initialized
INFO - 2018-07-31 13:39:18 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:39:18 --> Database Driver Class Initialized
INFO - 2018-07-31 13:39:18 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:39:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:39:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:39:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:39:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:39:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:39:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:39:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:39:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/spouse_info.php
INFO - 2018-07-31 13:39:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:39:18 --> Final output sent to browser
DEBUG - 2018-07-31 13:39:18 --> Total execution time: 0.0540
INFO - 2018-07-31 13:39:19 --> Config Class Initialized
INFO - 2018-07-31 13:39:19 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:39:19 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:39:19 --> Utf8 Class Initialized
INFO - 2018-07-31 13:39:19 --> URI Class Initialized
INFO - 2018-07-31 13:39:19 --> Router Class Initialized
INFO - 2018-07-31 13:39:19 --> Output Class Initialized
INFO - 2018-07-31 13:39:19 --> Security Class Initialized
DEBUG - 2018-07-31 13:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:39:19 --> CSRF cookie sent
INFO - 2018-07-31 13:39:19 --> Input Class Initialized
INFO - 2018-07-31 13:39:19 --> Language Class Initialized
INFO - 2018-07-31 13:39:19 --> Loader Class Initialized
INFO - 2018-07-31 13:39:19 --> Helper loaded: url_helper
INFO - 2018-07-31 13:39:19 --> Helper loaded: form_helper
INFO - 2018-07-31 13:39:19 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:39:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:39:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:39:19 --> User Agent Class Initialized
INFO - 2018-07-31 13:39:19 --> Controller Class Initialized
INFO - 2018-07-31 13:39:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:39:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:39:19 --> Pixel_Model class loaded
INFO - 2018-07-31 13:39:19 --> Database Driver Class Initialized
INFO - 2018-07-31 13:39:19 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:39:19 --> Database Driver Class Initialized
INFO - 2018-07-31 13:39:19 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:39:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:39:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:39:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:39:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:39:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:39:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:39:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:39:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/spouse_job.php
INFO - 2018-07-31 13:39:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:39:19 --> Final output sent to browser
DEBUG - 2018-07-31 13:39:19 --> Total execution time: 0.0461
INFO - 2018-07-31 13:39:20 --> Config Class Initialized
INFO - 2018-07-31 13:39:20 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:39:20 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:39:20 --> Utf8 Class Initialized
INFO - 2018-07-31 13:39:20 --> URI Class Initialized
INFO - 2018-07-31 13:39:20 --> Router Class Initialized
INFO - 2018-07-31 13:39:20 --> Output Class Initialized
INFO - 2018-07-31 13:39:20 --> Security Class Initialized
DEBUG - 2018-07-31 13:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:39:20 --> CSRF cookie sent
INFO - 2018-07-31 13:39:20 --> Input Class Initialized
INFO - 2018-07-31 13:39:20 --> Language Class Initialized
INFO - 2018-07-31 13:39:20 --> Loader Class Initialized
INFO - 2018-07-31 13:39:20 --> Helper loaded: url_helper
INFO - 2018-07-31 13:39:20 --> Helper loaded: form_helper
INFO - 2018-07-31 13:39:20 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:39:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:39:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:39:20 --> User Agent Class Initialized
INFO - 2018-07-31 13:39:20 --> Controller Class Initialized
INFO - 2018-07-31 13:39:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:39:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:39:20 --> Pixel_Model class loaded
INFO - 2018-07-31 13:39:20 --> Database Driver Class Initialized
INFO - 2018-07-31 13:39:20 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:39:20 --> Database Driver Class Initialized
INFO - 2018-07-31 13:39:20 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:39:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:39:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:39:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:39:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:39:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:39:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:39:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:39:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/affectionate_salutation.php
INFO - 2018-07-31 13:39:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:39:20 --> Final output sent to browser
DEBUG - 2018-07-31 13:39:20 --> Total execution time: 0.0703
INFO - 2018-07-31 13:39:21 --> Config Class Initialized
INFO - 2018-07-31 13:39:21 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:39:21 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:39:21 --> Utf8 Class Initialized
INFO - 2018-07-31 13:39:21 --> URI Class Initialized
INFO - 2018-07-31 13:39:21 --> Router Class Initialized
INFO - 2018-07-31 13:39:21 --> Output Class Initialized
INFO - 2018-07-31 13:39:21 --> Security Class Initialized
DEBUG - 2018-07-31 13:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:39:21 --> CSRF cookie sent
INFO - 2018-07-31 13:39:21 --> Input Class Initialized
INFO - 2018-07-31 13:39:21 --> Language Class Initialized
INFO - 2018-07-31 13:39:21 --> Loader Class Initialized
INFO - 2018-07-31 13:39:21 --> Helper loaded: url_helper
INFO - 2018-07-31 13:39:21 --> Helper loaded: form_helper
INFO - 2018-07-31 13:39:21 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:39:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:39:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:39:21 --> User Agent Class Initialized
INFO - 2018-07-31 13:39:21 --> Controller Class Initialized
INFO - 2018-07-31 13:39:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:39:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:39:21 --> Pixel_Model class loaded
INFO - 2018-07-31 13:39:21 --> Database Driver Class Initialized
INFO - 2018-07-31 13:39:21 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:39:21 --> Database Driver Class Initialized
INFO - 2018-07-31 13:39:21 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:39:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:39:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:39:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:39:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:39:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:39:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:39:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:39:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/business_tax_info.php
INFO - 2018-07-31 13:39:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:39:21 --> Final output sent to browser
DEBUG - 2018-07-31 13:39:21 --> Total execution time: 0.0492
INFO - 2018-07-31 13:39:33 --> Config Class Initialized
INFO - 2018-07-31 13:39:33 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:39:33 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:39:33 --> Utf8 Class Initialized
INFO - 2018-07-31 13:39:33 --> URI Class Initialized
INFO - 2018-07-31 13:39:33 --> Router Class Initialized
INFO - 2018-07-31 13:39:33 --> Output Class Initialized
INFO - 2018-07-31 13:39:33 --> Security Class Initialized
DEBUG - 2018-07-31 13:39:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:39:33 --> CSRF cookie sent
INFO - 2018-07-31 13:39:33 --> Input Class Initialized
INFO - 2018-07-31 13:39:33 --> Language Class Initialized
INFO - 2018-07-31 13:39:33 --> Loader Class Initialized
INFO - 2018-07-31 13:39:33 --> Helper loaded: url_helper
INFO - 2018-07-31 13:39:33 --> Helper loaded: form_helper
INFO - 2018-07-31 13:39:33 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:39:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:39:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:39:33 --> User Agent Class Initialized
INFO - 2018-07-31 13:39:33 --> Controller Class Initialized
INFO - 2018-07-31 13:39:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:39:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:39:33 --> Pixel_Model class loaded
INFO - 2018-07-31 13:39:33 --> Database Driver Class Initialized
INFO - 2018-07-31 13:39:33 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:39:33 --> Database Driver Class Initialized
INFO - 2018-07-31 13:39:33 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:39:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:39:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:39:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:39:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:39:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:39:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:39:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:39:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/trust_info.php
INFO - 2018-07-31 13:39:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:39:33 --> Final output sent to browser
DEBUG - 2018-07-31 13:39:33 --> Total execution time: 0.0497
INFO - 2018-07-31 13:39:34 --> Config Class Initialized
INFO - 2018-07-31 13:39:34 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:39:34 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:39:34 --> Utf8 Class Initialized
INFO - 2018-07-31 13:39:34 --> URI Class Initialized
INFO - 2018-07-31 13:39:34 --> Router Class Initialized
INFO - 2018-07-31 13:39:34 --> Output Class Initialized
INFO - 2018-07-31 13:39:34 --> Security Class Initialized
DEBUG - 2018-07-31 13:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:39:34 --> CSRF cookie sent
INFO - 2018-07-31 13:39:34 --> Input Class Initialized
INFO - 2018-07-31 13:39:34 --> Language Class Initialized
INFO - 2018-07-31 13:39:34 --> Loader Class Initialized
INFO - 2018-07-31 13:39:34 --> Helper loaded: url_helper
INFO - 2018-07-31 13:39:34 --> Helper loaded: form_helper
INFO - 2018-07-31 13:39:34 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:39:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:39:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:39:34 --> User Agent Class Initialized
INFO - 2018-07-31 13:39:34 --> Controller Class Initialized
INFO - 2018-07-31 13:39:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:39:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:39:34 --> Pixel_Model class loaded
INFO - 2018-07-31 13:39:34 --> Database Driver Class Initialized
INFO - 2018-07-31 13:39:34 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:39:34 --> Database Driver Class Initialized
INFO - 2018-07-31 13:39:34 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:39:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:39:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:39:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:39:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:39:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:39:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:39:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:39:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inherited_income.php
INFO - 2018-07-31 13:39:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:39:34 --> Final output sent to browser
DEBUG - 2018-07-31 13:39:34 --> Total execution time: 0.0523
INFO - 2018-07-31 13:39:36 --> Config Class Initialized
INFO - 2018-07-31 13:39:36 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:39:36 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:39:36 --> Utf8 Class Initialized
INFO - 2018-07-31 13:39:36 --> URI Class Initialized
INFO - 2018-07-31 13:39:36 --> Router Class Initialized
INFO - 2018-07-31 13:39:36 --> Output Class Initialized
INFO - 2018-07-31 13:39:36 --> Security Class Initialized
DEBUG - 2018-07-31 13:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:39:36 --> CSRF cookie sent
INFO - 2018-07-31 13:39:36 --> Input Class Initialized
INFO - 2018-07-31 13:39:36 --> Language Class Initialized
INFO - 2018-07-31 13:39:36 --> Loader Class Initialized
INFO - 2018-07-31 13:39:36 --> Helper loaded: url_helper
INFO - 2018-07-31 13:39:36 --> Helper loaded: form_helper
INFO - 2018-07-31 13:39:36 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:39:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:39:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:39:36 --> User Agent Class Initialized
INFO - 2018-07-31 13:39:36 --> Controller Class Initialized
INFO - 2018-07-31 13:39:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:39:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:39:36 --> Pixel_Model class loaded
INFO - 2018-07-31 13:39:36 --> Database Driver Class Initialized
INFO - 2018-07-31 13:39:36 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:39:36 --> Database Driver Class Initialized
INFO - 2018-07-31 13:39:36 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:39:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:39:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:39:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:39:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:39:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:39:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:39:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:39:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/shift_work.php
INFO - 2018-07-31 13:39:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:39:36 --> Final output sent to browser
DEBUG - 2018-07-31 13:39:36 --> Total execution time: 0.0527
INFO - 2018-07-31 13:39:37 --> Config Class Initialized
INFO - 2018-07-31 13:39:37 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:39:37 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:39:37 --> Utf8 Class Initialized
INFO - 2018-07-31 13:39:37 --> URI Class Initialized
INFO - 2018-07-31 13:39:37 --> Router Class Initialized
INFO - 2018-07-31 13:39:37 --> Output Class Initialized
INFO - 2018-07-31 13:39:37 --> Security Class Initialized
DEBUG - 2018-07-31 13:39:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:39:37 --> CSRF cookie sent
INFO - 2018-07-31 13:39:37 --> Input Class Initialized
INFO - 2018-07-31 13:39:37 --> Language Class Initialized
INFO - 2018-07-31 13:39:37 --> Loader Class Initialized
INFO - 2018-07-31 13:39:37 --> Helper loaded: url_helper
INFO - 2018-07-31 13:39:37 --> Helper loaded: form_helper
INFO - 2018-07-31 13:39:37 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:39:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:39:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:39:37 --> User Agent Class Initialized
INFO - 2018-07-31 13:39:37 --> Controller Class Initialized
INFO - 2018-07-31 13:39:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:39:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:39:37 --> Pixel_Model class loaded
INFO - 2018-07-31 13:39:37 --> Database Driver Class Initialized
INFO - 2018-07-31 13:39:37 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:39:37 --> Database Driver Class Initialized
INFO - 2018-07-31 13:39:37 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:39:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:39:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:39:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:39:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:39:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:39:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:39:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:39:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/night_without_s.php
INFO - 2018-07-31 13:39:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:39:37 --> Final output sent to browser
DEBUG - 2018-07-31 13:39:37 --> Total execution time: 0.0446
INFO - 2018-07-31 13:39:39 --> Config Class Initialized
INFO - 2018-07-31 13:39:39 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:39:39 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:39:39 --> Utf8 Class Initialized
INFO - 2018-07-31 13:39:39 --> URI Class Initialized
INFO - 2018-07-31 13:39:39 --> Router Class Initialized
INFO - 2018-07-31 13:39:39 --> Output Class Initialized
INFO - 2018-07-31 13:39:39 --> Security Class Initialized
DEBUG - 2018-07-31 13:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:39:39 --> CSRF cookie sent
INFO - 2018-07-31 13:39:39 --> Input Class Initialized
INFO - 2018-07-31 13:39:39 --> Language Class Initialized
INFO - 2018-07-31 13:39:39 --> Loader Class Initialized
INFO - 2018-07-31 13:39:39 --> Helper loaded: url_helper
INFO - 2018-07-31 13:39:39 --> Helper loaded: form_helper
INFO - 2018-07-31 13:39:39 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:39:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:39:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:39:39 --> User Agent Class Initialized
INFO - 2018-07-31 13:39:39 --> Controller Class Initialized
INFO - 2018-07-31 13:39:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:39:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:39:39 --> Pixel_Model class loaded
INFO - 2018-07-31 13:39:39 --> Database Driver Class Initialized
INFO - 2018-07-31 13:39:39 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:39:39 --> Database Driver Class Initialized
INFO - 2018-07-31 13:39:39 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:39:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:39:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:39:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:39:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:39:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:39:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:39:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:39:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/have_date.php
INFO - 2018-07-31 13:39:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:39:39 --> Final output sent to browser
DEBUG - 2018-07-31 13:39:39 --> Total execution time: 0.0498
INFO - 2018-07-31 13:39:39 --> Config Class Initialized
INFO - 2018-07-31 13:39:39 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:39:39 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:39:39 --> Utf8 Class Initialized
INFO - 2018-07-31 13:39:39 --> URI Class Initialized
INFO - 2018-07-31 13:39:39 --> Router Class Initialized
INFO - 2018-07-31 13:39:39 --> Output Class Initialized
INFO - 2018-07-31 13:39:39 --> Security Class Initialized
DEBUG - 2018-07-31 13:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:39:39 --> CSRF cookie sent
INFO - 2018-07-31 13:39:39 --> CSRF token verified
INFO - 2018-07-31 13:39:39 --> Input Class Initialized
INFO - 2018-07-31 13:39:39 --> Language Class Initialized
INFO - 2018-07-31 13:39:39 --> Loader Class Initialized
INFO - 2018-07-31 13:39:39 --> Helper loaded: url_helper
INFO - 2018-07-31 13:39:39 --> Helper loaded: form_helper
INFO - 2018-07-31 13:39:39 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:39:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:39:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:39:39 --> User Agent Class Initialized
INFO - 2018-07-31 13:39:39 --> Controller Class Initialized
INFO - 2018-07-31 13:39:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:39:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:39:39 --> Pixel_Model class loaded
INFO - 2018-07-31 13:39:39 --> Database Driver Class Initialized
INFO - 2018-07-31 13:39:39 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:39:39 --> Form Validation Class Initialized
INFO - 2018-07-31 13:39:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-07-31 13:39:39 --> Database Driver Class Initialized
INFO - 2018-07-31 13:39:39 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:39:40 --> Config Class Initialized
INFO - 2018-07-31 13:39:40 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:39:40 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:39:40 --> Utf8 Class Initialized
INFO - 2018-07-31 13:39:40 --> URI Class Initialized
INFO - 2018-07-31 13:39:40 --> Router Class Initialized
INFO - 2018-07-31 13:39:40 --> Output Class Initialized
INFO - 2018-07-31 13:39:40 --> Security Class Initialized
DEBUG - 2018-07-31 13:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:39:40 --> CSRF cookie sent
INFO - 2018-07-31 13:39:40 --> Input Class Initialized
INFO - 2018-07-31 13:39:40 --> Language Class Initialized
INFO - 2018-07-31 13:39:40 --> Loader Class Initialized
INFO - 2018-07-31 13:39:40 --> Helper loaded: url_helper
INFO - 2018-07-31 13:39:40 --> Helper loaded: form_helper
INFO - 2018-07-31 13:39:40 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:39:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:39:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:39:40 --> User Agent Class Initialized
INFO - 2018-07-31 13:39:40 --> Controller Class Initialized
INFO - 2018-07-31 13:39:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:39:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:39:40 --> Pixel_Model class loaded
INFO - 2018-07-31 13:39:40 --> Database Driver Class Initialized
INFO - 2018-07-31 13:39:40 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:39:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:39:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:39:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:39:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:39:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:39:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/cohabitation.php
INFO - 2018-07-31 13:39:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:39:40 --> Final output sent to browser
DEBUG - 2018-07-31 13:39:40 --> Total execution time: 0.0437
INFO - 2018-07-31 13:39:40 --> Config Class Initialized
INFO - 2018-07-31 13:39:40 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:39:40 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:39:40 --> Utf8 Class Initialized
INFO - 2018-07-31 13:39:40 --> URI Class Initialized
INFO - 2018-07-31 13:39:40 --> Router Class Initialized
INFO - 2018-07-31 13:39:40 --> Output Class Initialized
INFO - 2018-07-31 13:39:40 --> Security Class Initialized
DEBUG - 2018-07-31 13:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:39:40 --> CSRF cookie sent
INFO - 2018-07-31 13:39:40 --> Input Class Initialized
INFO - 2018-07-31 13:39:40 --> Language Class Initialized
INFO - 2018-07-31 13:39:40 --> Loader Class Initialized
INFO - 2018-07-31 13:39:40 --> Helper loaded: url_helper
INFO - 2018-07-31 13:39:40 --> Helper loaded: form_helper
INFO - 2018-07-31 13:39:40 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:39:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:39:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:39:40 --> User Agent Class Initialized
INFO - 2018-07-31 13:39:40 --> Controller Class Initialized
INFO - 2018-07-31 13:39:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:39:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:39:40 --> Pixel_Model class loaded
INFO - 2018-07-31 13:39:40 --> Database Driver Class Initialized
INFO - 2018-07-31 13:39:40 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:39:40 --> Database Driver Class Initialized
INFO - 2018-07-31 13:39:40 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:39:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:39:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:39:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:39:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:39:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:39:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:39:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:39:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/nights_not_home.php
INFO - 2018-07-31 13:39:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:39:40 --> Final output sent to browser
DEBUG - 2018-07-31 13:39:40 --> Total execution time: 0.0619
INFO - 2018-07-31 13:40:10 --> Config Class Initialized
INFO - 2018-07-31 13:40:10 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:40:10 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:40:10 --> Utf8 Class Initialized
INFO - 2018-07-31 13:40:10 --> URI Class Initialized
INFO - 2018-07-31 13:40:10 --> Router Class Initialized
INFO - 2018-07-31 13:40:10 --> Output Class Initialized
INFO - 2018-07-31 13:40:10 --> Security Class Initialized
DEBUG - 2018-07-31 13:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:40:10 --> CSRF cookie sent
INFO - 2018-07-31 13:40:10 --> Input Class Initialized
INFO - 2018-07-31 13:40:10 --> Language Class Initialized
INFO - 2018-07-31 13:40:10 --> Loader Class Initialized
INFO - 2018-07-31 13:40:10 --> Helper loaded: url_helper
INFO - 2018-07-31 13:40:10 --> Helper loaded: form_helper
INFO - 2018-07-31 13:40:10 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:40:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:40:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:40:10 --> User Agent Class Initialized
INFO - 2018-07-31 13:40:10 --> Controller Class Initialized
INFO - 2018-07-31 13:40:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:40:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:40:10 --> Pixel_Model class loaded
INFO - 2018-07-31 13:40:10 --> Database Driver Class Initialized
INFO - 2018-07-31 13:40:10 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:40:10 --> Database Driver Class Initialized
INFO - 2018-07-31 13:40:10 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:40:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:40:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:40:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:40:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:40:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:40:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:40:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:40:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/have_date.php
INFO - 2018-07-31 13:40:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:40:10 --> Final output sent to browser
DEBUG - 2018-07-31 13:40:10 --> Total execution time: 0.0511
INFO - 2018-07-31 13:40:13 --> Config Class Initialized
INFO - 2018-07-31 13:40:13 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:40:13 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:40:13 --> Utf8 Class Initialized
INFO - 2018-07-31 13:40:13 --> URI Class Initialized
INFO - 2018-07-31 13:40:14 --> Router Class Initialized
INFO - 2018-07-31 13:40:14 --> Output Class Initialized
INFO - 2018-07-31 13:40:14 --> Security Class Initialized
DEBUG - 2018-07-31 13:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:40:14 --> CSRF cookie sent
INFO - 2018-07-31 13:40:14 --> Input Class Initialized
INFO - 2018-07-31 13:40:14 --> Language Class Initialized
INFO - 2018-07-31 13:40:14 --> Loader Class Initialized
INFO - 2018-07-31 13:40:14 --> Helper loaded: url_helper
INFO - 2018-07-31 13:40:14 --> Helper loaded: form_helper
INFO - 2018-07-31 13:40:14 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:40:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:40:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:40:14 --> User Agent Class Initialized
INFO - 2018-07-31 13:40:14 --> Controller Class Initialized
INFO - 2018-07-31 13:40:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:40:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:40:14 --> Pixel_Model class loaded
INFO - 2018-07-31 13:40:14 --> Database Driver Class Initialized
INFO - 2018-07-31 13:40:14 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:40:14 --> Database Driver Class Initialized
INFO - 2018-07-31 13:40:14 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:40:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:40:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:40:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:40:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:40:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:40:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:40:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:40:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/night_without_s.php
INFO - 2018-07-31 13:40:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:40:14 --> Final output sent to browser
DEBUG - 2018-07-31 13:40:14 --> Total execution time: 0.0528
INFO - 2018-07-31 13:40:15 --> Config Class Initialized
INFO - 2018-07-31 13:40:15 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:40:15 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:40:15 --> Utf8 Class Initialized
INFO - 2018-07-31 13:40:15 --> URI Class Initialized
INFO - 2018-07-31 13:40:15 --> Router Class Initialized
INFO - 2018-07-31 13:40:15 --> Output Class Initialized
INFO - 2018-07-31 13:40:15 --> Security Class Initialized
DEBUG - 2018-07-31 13:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:40:15 --> CSRF cookie sent
INFO - 2018-07-31 13:40:15 --> Input Class Initialized
INFO - 2018-07-31 13:40:15 --> Language Class Initialized
INFO - 2018-07-31 13:40:15 --> Loader Class Initialized
INFO - 2018-07-31 13:40:15 --> Helper loaded: url_helper
INFO - 2018-07-31 13:40:15 --> Helper loaded: form_helper
INFO - 2018-07-31 13:40:15 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:40:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:40:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:40:15 --> User Agent Class Initialized
INFO - 2018-07-31 13:40:15 --> Controller Class Initialized
INFO - 2018-07-31 13:40:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:40:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:40:15 --> Pixel_Model class loaded
INFO - 2018-07-31 13:40:15 --> Database Driver Class Initialized
INFO - 2018-07-31 13:40:15 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:40:15 --> Database Driver Class Initialized
INFO - 2018-07-31 13:40:15 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:40:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:40:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:40:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:40:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:40:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:40:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:40:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:40:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/shift_work.php
INFO - 2018-07-31 13:40:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:40:15 --> Final output sent to browser
DEBUG - 2018-07-31 13:40:15 --> Total execution time: 0.0433
INFO - 2018-07-31 13:40:16 --> Config Class Initialized
INFO - 2018-07-31 13:40:16 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:40:16 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:40:16 --> Utf8 Class Initialized
INFO - 2018-07-31 13:40:16 --> URI Class Initialized
INFO - 2018-07-31 13:40:16 --> Router Class Initialized
INFO - 2018-07-31 13:40:16 --> Output Class Initialized
INFO - 2018-07-31 13:40:16 --> Security Class Initialized
DEBUG - 2018-07-31 13:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:40:16 --> CSRF cookie sent
INFO - 2018-07-31 13:40:16 --> Input Class Initialized
INFO - 2018-07-31 13:40:16 --> Language Class Initialized
INFO - 2018-07-31 13:40:16 --> Loader Class Initialized
INFO - 2018-07-31 13:40:16 --> Helper loaded: url_helper
INFO - 2018-07-31 13:40:16 --> Helper loaded: form_helper
INFO - 2018-07-31 13:40:16 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:40:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:40:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:40:16 --> User Agent Class Initialized
INFO - 2018-07-31 13:40:16 --> Controller Class Initialized
INFO - 2018-07-31 13:40:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:40:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:40:16 --> Pixel_Model class loaded
INFO - 2018-07-31 13:40:16 --> Database Driver Class Initialized
INFO - 2018-07-31 13:40:16 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:40:16 --> Database Driver Class Initialized
INFO - 2018-07-31 13:40:16 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:40:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:40:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:40:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:40:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:40:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:40:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:40:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:40:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inherited_income.php
INFO - 2018-07-31 13:40:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:40:16 --> Final output sent to browser
DEBUG - 2018-07-31 13:40:16 --> Total execution time: 0.0509
INFO - 2018-07-31 13:40:18 --> Config Class Initialized
INFO - 2018-07-31 13:40:18 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:40:18 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:40:18 --> Utf8 Class Initialized
INFO - 2018-07-31 13:40:18 --> URI Class Initialized
INFO - 2018-07-31 13:40:18 --> Router Class Initialized
INFO - 2018-07-31 13:40:18 --> Output Class Initialized
INFO - 2018-07-31 13:40:18 --> Security Class Initialized
DEBUG - 2018-07-31 13:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:40:18 --> CSRF cookie sent
INFO - 2018-07-31 13:40:18 --> Input Class Initialized
INFO - 2018-07-31 13:40:18 --> Language Class Initialized
INFO - 2018-07-31 13:40:18 --> Loader Class Initialized
INFO - 2018-07-31 13:40:18 --> Helper loaded: url_helper
INFO - 2018-07-31 13:40:18 --> Helper loaded: form_helper
INFO - 2018-07-31 13:40:18 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:40:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:40:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:40:18 --> User Agent Class Initialized
INFO - 2018-07-31 13:40:18 --> Controller Class Initialized
INFO - 2018-07-31 13:40:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:40:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:40:18 --> Pixel_Model class loaded
INFO - 2018-07-31 13:40:18 --> Database Driver Class Initialized
INFO - 2018-07-31 13:40:18 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:40:18 --> Database Driver Class Initialized
INFO - 2018-07-31 13:40:18 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:40:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:40:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:40:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:40:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:40:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:40:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:40:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:40:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/trust_info.php
INFO - 2018-07-31 13:40:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:40:18 --> Final output sent to browser
DEBUG - 2018-07-31 13:40:18 --> Total execution time: 0.0432
INFO - 2018-07-31 13:40:22 --> Config Class Initialized
INFO - 2018-07-31 13:40:22 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:40:22 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:40:22 --> Utf8 Class Initialized
INFO - 2018-07-31 13:40:22 --> URI Class Initialized
INFO - 2018-07-31 13:40:22 --> Router Class Initialized
INFO - 2018-07-31 13:40:22 --> Output Class Initialized
INFO - 2018-07-31 13:40:22 --> Security Class Initialized
DEBUG - 2018-07-31 13:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:40:22 --> CSRF cookie sent
INFO - 2018-07-31 13:40:22 --> Input Class Initialized
INFO - 2018-07-31 13:40:22 --> Language Class Initialized
INFO - 2018-07-31 13:40:22 --> Loader Class Initialized
INFO - 2018-07-31 13:40:22 --> Helper loaded: url_helper
INFO - 2018-07-31 13:40:22 --> Helper loaded: form_helper
INFO - 2018-07-31 13:40:22 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:40:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:40:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:40:22 --> User Agent Class Initialized
INFO - 2018-07-31 13:40:22 --> Controller Class Initialized
INFO - 2018-07-31 13:40:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:40:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:40:22 --> Pixel_Model class loaded
INFO - 2018-07-31 13:40:22 --> Database Driver Class Initialized
INFO - 2018-07-31 13:40:22 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:40:22 --> Database Driver Class Initialized
INFO - 2018-07-31 13:40:22 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:40:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:40:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:40:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:40:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:40:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:40:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:40:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:40:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/business_tax_info.php
INFO - 2018-07-31 13:40:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:40:22 --> Final output sent to browser
DEBUG - 2018-07-31 13:40:22 --> Total execution time: 0.0420
INFO - 2018-07-31 13:40:24 --> Config Class Initialized
INFO - 2018-07-31 13:40:24 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:40:24 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:40:24 --> Utf8 Class Initialized
INFO - 2018-07-31 13:40:24 --> URI Class Initialized
INFO - 2018-07-31 13:40:24 --> Router Class Initialized
INFO - 2018-07-31 13:40:24 --> Output Class Initialized
INFO - 2018-07-31 13:40:24 --> Security Class Initialized
DEBUG - 2018-07-31 13:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:40:24 --> CSRF cookie sent
INFO - 2018-07-31 13:40:24 --> Input Class Initialized
INFO - 2018-07-31 13:40:24 --> Language Class Initialized
INFO - 2018-07-31 13:40:24 --> Loader Class Initialized
INFO - 2018-07-31 13:40:24 --> Helper loaded: url_helper
INFO - 2018-07-31 13:40:24 --> Helper loaded: form_helper
INFO - 2018-07-31 13:40:24 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:40:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:40:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:40:24 --> User Agent Class Initialized
INFO - 2018-07-31 13:40:24 --> Controller Class Initialized
INFO - 2018-07-31 13:40:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:40:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:40:24 --> Pixel_Model class loaded
INFO - 2018-07-31 13:40:24 --> Database Driver Class Initialized
INFO - 2018-07-31 13:40:24 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:40:24 --> Database Driver Class Initialized
INFO - 2018-07-31 13:40:24 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:40:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:40:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:40:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:40:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:40:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:40:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:40:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:40:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/affectionate_salutation.php
INFO - 2018-07-31 13:40:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:40:24 --> Final output sent to browser
DEBUG - 2018-07-31 13:40:24 --> Total execution time: 0.0450
INFO - 2018-07-31 13:40:26 --> Config Class Initialized
INFO - 2018-07-31 13:40:26 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:40:26 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:40:26 --> Utf8 Class Initialized
INFO - 2018-07-31 13:40:26 --> URI Class Initialized
INFO - 2018-07-31 13:40:26 --> Router Class Initialized
INFO - 2018-07-31 13:40:26 --> Output Class Initialized
INFO - 2018-07-31 13:40:26 --> Security Class Initialized
DEBUG - 2018-07-31 13:40:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:40:26 --> CSRF cookie sent
INFO - 2018-07-31 13:40:26 --> Input Class Initialized
INFO - 2018-07-31 13:40:26 --> Language Class Initialized
INFO - 2018-07-31 13:40:26 --> Loader Class Initialized
INFO - 2018-07-31 13:40:26 --> Helper loaded: url_helper
INFO - 2018-07-31 13:40:26 --> Helper loaded: form_helper
INFO - 2018-07-31 13:40:26 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:40:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:40:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:40:26 --> User Agent Class Initialized
INFO - 2018-07-31 13:40:26 --> Controller Class Initialized
INFO - 2018-07-31 13:40:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:40:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:40:26 --> Pixel_Model class loaded
INFO - 2018-07-31 13:40:26 --> Database Driver Class Initialized
INFO - 2018-07-31 13:40:26 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:40:26 --> Database Driver Class Initialized
INFO - 2018-07-31 13:40:26 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:40:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:40:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:40:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:40:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:40:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:40:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:40:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:40:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/spouse_job.php
INFO - 2018-07-31 13:40:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:40:26 --> Final output sent to browser
DEBUG - 2018-07-31 13:40:26 --> Total execution time: 0.0445
INFO - 2018-07-31 13:40:29 --> Config Class Initialized
INFO - 2018-07-31 13:40:29 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:40:29 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:40:29 --> Utf8 Class Initialized
INFO - 2018-07-31 13:40:29 --> URI Class Initialized
INFO - 2018-07-31 13:40:29 --> Router Class Initialized
INFO - 2018-07-31 13:40:29 --> Output Class Initialized
INFO - 2018-07-31 13:40:29 --> Security Class Initialized
DEBUG - 2018-07-31 13:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:40:29 --> CSRF cookie sent
INFO - 2018-07-31 13:40:29 --> Input Class Initialized
INFO - 2018-07-31 13:40:29 --> Language Class Initialized
INFO - 2018-07-31 13:40:29 --> Loader Class Initialized
INFO - 2018-07-31 13:40:29 --> Helper loaded: url_helper
INFO - 2018-07-31 13:40:29 --> Helper loaded: form_helper
INFO - 2018-07-31 13:40:29 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:40:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:40:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:40:29 --> User Agent Class Initialized
INFO - 2018-07-31 13:40:29 --> Controller Class Initialized
INFO - 2018-07-31 13:40:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:40:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:40:29 --> Pixel_Model class loaded
INFO - 2018-07-31 13:40:29 --> Database Driver Class Initialized
INFO - 2018-07-31 13:40:29 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:40:29 --> Database Driver Class Initialized
INFO - 2018-07-31 13:40:29 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:40:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:40:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:40:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:40:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:40:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:40:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:40:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:40:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/spouse_info.php
INFO - 2018-07-31 13:40:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:40:29 --> Final output sent to browser
DEBUG - 2018-07-31 13:40:29 --> Total execution time: 0.0468
INFO - 2018-07-31 13:40:30 --> Config Class Initialized
INFO - 2018-07-31 13:40:30 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:40:30 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:40:30 --> Utf8 Class Initialized
INFO - 2018-07-31 13:40:30 --> URI Class Initialized
INFO - 2018-07-31 13:40:30 --> Router Class Initialized
INFO - 2018-07-31 13:40:30 --> Output Class Initialized
INFO - 2018-07-31 13:40:30 --> Security Class Initialized
DEBUG - 2018-07-31 13:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:40:30 --> CSRF cookie sent
INFO - 2018-07-31 13:40:30 --> Input Class Initialized
INFO - 2018-07-31 13:40:30 --> Language Class Initialized
INFO - 2018-07-31 13:40:30 --> Loader Class Initialized
INFO - 2018-07-31 13:40:30 --> Helper loaded: url_helper
INFO - 2018-07-31 13:40:30 --> Helper loaded: form_helper
INFO - 2018-07-31 13:40:30 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:40:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:40:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:40:30 --> User Agent Class Initialized
INFO - 2018-07-31 13:40:30 --> Controller Class Initialized
INFO - 2018-07-31 13:40:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:40:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:40:30 --> Pixel_Model class loaded
INFO - 2018-07-31 13:40:30 --> Database Driver Class Initialized
INFO - 2018-07-31 13:40:30 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:40:30 --> Database Driver Class Initialized
INFO - 2018-07-31 13:40:30 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:40:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:40:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:40:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:40:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:40:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:40:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:40:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:40:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids_help_complaint.php
INFO - 2018-07-31 13:40:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:40:30 --> Final output sent to browser
DEBUG - 2018-07-31 13:40:30 --> Total execution time: 0.0577
INFO - 2018-07-31 13:40:32 --> Config Class Initialized
INFO - 2018-07-31 13:40:32 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:40:32 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:40:32 --> Utf8 Class Initialized
INFO - 2018-07-31 13:40:32 --> URI Class Initialized
INFO - 2018-07-31 13:40:32 --> Router Class Initialized
INFO - 2018-07-31 13:40:32 --> Output Class Initialized
INFO - 2018-07-31 13:40:32 --> Security Class Initialized
DEBUG - 2018-07-31 13:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:40:32 --> CSRF cookie sent
INFO - 2018-07-31 13:40:32 --> Input Class Initialized
INFO - 2018-07-31 13:40:32 --> Language Class Initialized
INFO - 2018-07-31 13:40:32 --> Loader Class Initialized
INFO - 2018-07-31 13:40:32 --> Helper loaded: url_helper
INFO - 2018-07-31 13:40:32 --> Helper loaded: form_helper
INFO - 2018-07-31 13:40:32 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:40:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:40:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:40:32 --> User Agent Class Initialized
INFO - 2018-07-31 13:40:32 --> Controller Class Initialized
INFO - 2018-07-31 13:40:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:40:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:40:32 --> Pixel_Model class loaded
INFO - 2018-07-31 13:40:32 --> Database Driver Class Initialized
INFO - 2018-07-31 13:40:32 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:40:32 --> Database Driver Class Initialized
INFO - 2018-07-31 13:40:32 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:40:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:40:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:40:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:40:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:40:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:40:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:40:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:40:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids_doctor.php
INFO - 2018-07-31 13:40:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:40:32 --> Final output sent to browser
DEBUG - 2018-07-31 13:40:32 --> Total execution time: 0.0550
INFO - 2018-07-31 13:40:33 --> Config Class Initialized
INFO - 2018-07-31 13:40:33 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:40:33 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:40:33 --> Utf8 Class Initialized
INFO - 2018-07-31 13:40:33 --> URI Class Initialized
INFO - 2018-07-31 13:40:33 --> Router Class Initialized
INFO - 2018-07-31 13:40:33 --> Output Class Initialized
INFO - 2018-07-31 13:40:33 --> Security Class Initialized
DEBUG - 2018-07-31 13:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:40:33 --> CSRF cookie sent
INFO - 2018-07-31 13:40:33 --> Input Class Initialized
INFO - 2018-07-31 13:40:33 --> Language Class Initialized
INFO - 2018-07-31 13:40:33 --> Loader Class Initialized
INFO - 2018-07-31 13:40:33 --> Helper loaded: url_helper
INFO - 2018-07-31 13:40:33 --> Helper loaded: form_helper
INFO - 2018-07-31 13:40:33 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:40:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:40:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:40:33 --> User Agent Class Initialized
INFO - 2018-07-31 13:40:33 --> Controller Class Initialized
INFO - 2018-07-31 13:40:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:40:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:40:33 --> Pixel_Model class loaded
INFO - 2018-07-31 13:40:33 --> Database Driver Class Initialized
INFO - 2018-07-31 13:40:33 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:40:33 --> Database Driver Class Initialized
INFO - 2018-07-31 13:40:33 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:40:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:40:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:40:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:40:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:40:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:40:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:40:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:40:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids_homework.php
INFO - 2018-07-31 13:40:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:40:34 --> Final output sent to browser
DEBUG - 2018-07-31 13:40:34 --> Total execution time: 0.0460
INFO - 2018-07-31 13:40:35 --> Config Class Initialized
INFO - 2018-07-31 13:40:35 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:40:35 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:40:35 --> Utf8 Class Initialized
INFO - 2018-07-31 13:40:35 --> URI Class Initialized
INFO - 2018-07-31 13:40:35 --> Router Class Initialized
INFO - 2018-07-31 13:40:35 --> Output Class Initialized
INFO - 2018-07-31 13:40:35 --> Security Class Initialized
DEBUG - 2018-07-31 13:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:40:35 --> CSRF cookie sent
INFO - 2018-07-31 13:40:35 --> Input Class Initialized
INFO - 2018-07-31 13:40:35 --> Language Class Initialized
INFO - 2018-07-31 13:40:35 --> Loader Class Initialized
INFO - 2018-07-31 13:40:35 --> Helper loaded: url_helper
INFO - 2018-07-31 13:40:35 --> Helper loaded: form_helper
INFO - 2018-07-31 13:40:35 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:40:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:40:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:40:35 --> User Agent Class Initialized
INFO - 2018-07-31 13:40:35 --> Controller Class Initialized
INFO - 2018-07-31 13:40:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:40:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:40:35 --> Pixel_Model class loaded
INFO - 2018-07-31 13:40:35 --> Database Driver Class Initialized
INFO - 2018-07-31 13:40:35 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:40:35 --> Database Driver Class Initialized
INFO - 2018-07-31 13:40:35 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:40:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:40:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:40:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:40:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:40:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:40:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:40:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:40:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids_dinner.php
INFO - 2018-07-31 13:40:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:40:35 --> Final output sent to browser
DEBUG - 2018-07-31 13:40:35 --> Total execution time: 0.0538
INFO - 2018-07-31 13:40:36 --> Config Class Initialized
INFO - 2018-07-31 13:40:36 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:40:36 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:40:36 --> Utf8 Class Initialized
INFO - 2018-07-31 13:40:36 --> URI Class Initialized
INFO - 2018-07-31 13:40:36 --> Router Class Initialized
INFO - 2018-07-31 13:40:36 --> Output Class Initialized
INFO - 2018-07-31 13:40:36 --> Security Class Initialized
DEBUG - 2018-07-31 13:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:40:36 --> CSRF cookie sent
INFO - 2018-07-31 13:40:36 --> Input Class Initialized
INFO - 2018-07-31 13:40:36 --> Language Class Initialized
INFO - 2018-07-31 13:40:36 --> Loader Class Initialized
INFO - 2018-07-31 13:40:36 --> Helper loaded: url_helper
INFO - 2018-07-31 13:40:36 --> Helper loaded: form_helper
INFO - 2018-07-31 13:40:36 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:40:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:40:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:40:36 --> User Agent Class Initialized
INFO - 2018-07-31 13:40:36 --> Controller Class Initialized
INFO - 2018-07-31 13:40:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:40:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:40:36 --> Pixel_Model class loaded
INFO - 2018-07-31 13:40:36 --> Database Driver Class Initialized
INFO - 2018-07-31 13:40:36 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:40:36 --> Database Driver Class Initialized
INFO - 2018-07-31 13:40:36 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:40:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:40:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:40:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:40:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:40:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:40:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:40:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:40:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids_communicate.php
INFO - 2018-07-31 13:40:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:40:36 --> Final output sent to browser
DEBUG - 2018-07-31 13:40:36 --> Total execution time: 0.0653
INFO - 2018-07-31 13:40:37 --> Config Class Initialized
INFO - 2018-07-31 13:40:37 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:40:37 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:40:37 --> Utf8 Class Initialized
INFO - 2018-07-31 13:40:37 --> URI Class Initialized
INFO - 2018-07-31 13:40:37 --> Router Class Initialized
INFO - 2018-07-31 13:40:37 --> Output Class Initialized
INFO - 2018-07-31 13:40:37 --> Security Class Initialized
DEBUG - 2018-07-31 13:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:40:37 --> CSRF cookie sent
INFO - 2018-07-31 13:40:37 --> Input Class Initialized
INFO - 2018-07-31 13:40:37 --> Language Class Initialized
INFO - 2018-07-31 13:40:37 --> Loader Class Initialized
INFO - 2018-07-31 13:40:37 --> Helper loaded: url_helper
INFO - 2018-07-31 13:40:37 --> Helper loaded: form_helper
INFO - 2018-07-31 13:40:37 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:40:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:40:37 --> User Agent Class Initialized
INFO - 2018-07-31 13:40:37 --> Controller Class Initialized
INFO - 2018-07-31 13:40:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:40:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:40:37 --> Pixel_Model class loaded
INFO - 2018-07-31 13:40:37 --> Database Driver Class Initialized
INFO - 2018-07-31 13:40:37 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:40:37 --> Database Driver Class Initialized
INFO - 2018-07-31 13:40:37 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:40:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:40:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:40:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:40:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:40:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:40:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:40:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:40:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids_activities.php
INFO - 2018-07-31 13:40:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:40:37 --> Final output sent to browser
DEBUG - 2018-07-31 13:40:37 --> Total execution time: 0.0500
INFO - 2018-07-31 13:40:41 --> Config Class Initialized
INFO - 2018-07-31 13:40:41 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:40:41 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:40:41 --> Utf8 Class Initialized
INFO - 2018-07-31 13:40:41 --> URI Class Initialized
INFO - 2018-07-31 13:40:41 --> Router Class Initialized
INFO - 2018-07-31 13:40:41 --> Output Class Initialized
INFO - 2018-07-31 13:40:41 --> Security Class Initialized
DEBUG - 2018-07-31 13:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:40:41 --> CSRF cookie sent
INFO - 2018-07-31 13:40:41 --> Input Class Initialized
INFO - 2018-07-31 13:40:41 --> Language Class Initialized
INFO - 2018-07-31 13:40:41 --> Loader Class Initialized
INFO - 2018-07-31 13:40:41 --> Helper loaded: url_helper
INFO - 2018-07-31 13:40:41 --> Helper loaded: form_helper
INFO - 2018-07-31 13:40:41 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:40:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:40:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:40:41 --> User Agent Class Initialized
INFO - 2018-07-31 13:40:41 --> Controller Class Initialized
INFO - 2018-07-31 13:40:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:40:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:40:41 --> Pixel_Model class loaded
INFO - 2018-07-31 13:40:41 --> Database Driver Class Initialized
INFO - 2018-07-31 13:40:41 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:40:41 --> Database Driver Class Initialized
INFO - 2018-07-31 13:40:41 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:40:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:40:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:40:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:40:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:40:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:40:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:40:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:40:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/other_kids.php
INFO - 2018-07-31 13:40:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:40:41 --> Final output sent to browser
DEBUG - 2018-07-31 13:40:41 --> Total execution time: 0.0439
INFO - 2018-07-31 13:40:49 --> Config Class Initialized
INFO - 2018-07-31 13:40:49 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:40:49 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:40:49 --> Utf8 Class Initialized
INFO - 2018-07-31 13:40:49 --> URI Class Initialized
INFO - 2018-07-31 13:40:49 --> Router Class Initialized
INFO - 2018-07-31 13:40:49 --> Output Class Initialized
INFO - 2018-07-31 13:40:49 --> Security Class Initialized
DEBUG - 2018-07-31 13:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:40:49 --> CSRF cookie sent
INFO - 2018-07-31 13:40:49 --> Input Class Initialized
INFO - 2018-07-31 13:40:49 --> Language Class Initialized
INFO - 2018-07-31 13:40:49 --> Loader Class Initialized
INFO - 2018-07-31 13:40:49 --> Helper loaded: url_helper
INFO - 2018-07-31 13:40:49 --> Helper loaded: form_helper
INFO - 2018-07-31 13:40:49 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:40:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:40:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:40:49 --> User Agent Class Initialized
INFO - 2018-07-31 13:40:49 --> Controller Class Initialized
INFO - 2018-07-31 13:40:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:40:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:40:49 --> Pixel_Model class loaded
INFO - 2018-07-31 13:40:49 --> Database Driver Class Initialized
INFO - 2018-07-31 13:40:49 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:40:49 --> Database Driver Class Initialized
INFO - 2018-07-31 13:40:49 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:40:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:40:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:40:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:40:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:40:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:40:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:40:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:40:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids_info.php
INFO - 2018-07-31 13:40:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:40:49 --> Final output sent to browser
DEBUG - 2018-07-31 13:40:49 --> Total execution time: 0.0498
INFO - 2018-07-31 13:40:50 --> Config Class Initialized
INFO - 2018-07-31 13:40:50 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:40:50 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:40:50 --> Utf8 Class Initialized
INFO - 2018-07-31 13:40:50 --> URI Class Initialized
INFO - 2018-07-31 13:40:50 --> Router Class Initialized
INFO - 2018-07-31 13:40:50 --> Output Class Initialized
INFO - 2018-07-31 13:40:50 --> Security Class Initialized
DEBUG - 2018-07-31 13:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:40:50 --> CSRF cookie sent
INFO - 2018-07-31 13:40:50 --> Input Class Initialized
INFO - 2018-07-31 13:40:50 --> Language Class Initialized
INFO - 2018-07-31 13:40:50 --> Loader Class Initialized
INFO - 2018-07-31 13:40:50 --> Helper loaded: url_helper
INFO - 2018-07-31 13:40:50 --> Helper loaded: form_helper
INFO - 2018-07-31 13:40:50 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:40:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:40:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:40:50 --> User Agent Class Initialized
INFO - 2018-07-31 13:40:50 --> Controller Class Initialized
INFO - 2018-07-31 13:40:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:40:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:40:50 --> Pixel_Model class loaded
INFO - 2018-07-31 13:40:50 --> Database Driver Class Initialized
INFO - 2018-07-31 13:40:50 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:40:50 --> Database Driver Class Initialized
INFO - 2018-07-31 13:40:50 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:40:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:40:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:40:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:40:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:40:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:40:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:40:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:40:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-07-31 13:40:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:40:50 --> Final output sent to browser
DEBUG - 2018-07-31 13:40:50 --> Total execution time: 0.0358
INFO - 2018-07-31 13:41:00 --> Config Class Initialized
INFO - 2018-07-31 13:41:00 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:41:00 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:41:00 --> Utf8 Class Initialized
INFO - 2018-07-31 13:41:00 --> URI Class Initialized
INFO - 2018-07-31 13:41:00 --> Router Class Initialized
INFO - 2018-07-31 13:41:00 --> Output Class Initialized
INFO - 2018-07-31 13:41:00 --> Security Class Initialized
DEBUG - 2018-07-31 13:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:41:00 --> CSRF cookie sent
INFO - 2018-07-31 13:41:00 --> Input Class Initialized
INFO - 2018-07-31 13:41:00 --> Language Class Initialized
INFO - 2018-07-31 13:41:00 --> Loader Class Initialized
INFO - 2018-07-31 13:41:00 --> Helper loaded: url_helper
INFO - 2018-07-31 13:41:00 --> Helper loaded: form_helper
INFO - 2018-07-31 13:41:00 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:41:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:41:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:41:00 --> User Agent Class Initialized
INFO - 2018-07-31 13:41:00 --> Controller Class Initialized
INFO - 2018-07-31 13:41:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:41:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:41:00 --> Pixel_Model class loaded
INFO - 2018-07-31 13:41:00 --> Database Driver Class Initialized
INFO - 2018-07-31 13:41:00 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:41:00 --> Database Driver Class Initialized
INFO - 2018-07-31 13:41:00 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:41:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:41:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:41:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:41:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:41:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:41:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:41:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:41:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-07-31 13:41:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:41:00 --> Final output sent to browser
DEBUG - 2018-07-31 13:41:00 --> Total execution time: 0.0868
INFO - 2018-07-31 13:41:02 --> Config Class Initialized
INFO - 2018-07-31 13:41:02 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:41:02 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:41:02 --> Utf8 Class Initialized
INFO - 2018-07-31 13:41:02 --> URI Class Initialized
INFO - 2018-07-31 13:41:02 --> Router Class Initialized
INFO - 2018-07-31 13:41:02 --> Output Class Initialized
INFO - 2018-07-31 13:41:02 --> Security Class Initialized
DEBUG - 2018-07-31 13:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:41:02 --> CSRF cookie sent
INFO - 2018-07-31 13:41:02 --> Input Class Initialized
INFO - 2018-07-31 13:41:02 --> Language Class Initialized
INFO - 2018-07-31 13:41:02 --> Loader Class Initialized
INFO - 2018-07-31 13:41:02 --> Helper loaded: url_helper
INFO - 2018-07-31 13:41:02 --> Helper loaded: form_helper
INFO - 2018-07-31 13:41:02 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:41:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:41:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:41:02 --> User Agent Class Initialized
INFO - 2018-07-31 13:41:02 --> Controller Class Initialized
INFO - 2018-07-31 13:41:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:41:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:41:02 --> Pixel_Model class loaded
INFO - 2018-07-31 13:41:02 --> Database Driver Class Initialized
INFO - 2018-07-31 13:41:02 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:41:02 --> Database Driver Class Initialized
INFO - 2018-07-31 13:41:02 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:41:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:41:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:41:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:41:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:41:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:41:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:41:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:41:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_title.php
INFO - 2018-07-31 13:41:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:41:02 --> Final output sent to browser
DEBUG - 2018-07-31 13:41:02 --> Total execution time: 0.0457
INFO - 2018-07-31 13:41:03 --> Config Class Initialized
INFO - 2018-07-31 13:41:03 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:41:03 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:41:03 --> Utf8 Class Initialized
INFO - 2018-07-31 13:41:03 --> URI Class Initialized
INFO - 2018-07-31 13:41:03 --> Router Class Initialized
INFO - 2018-07-31 13:41:03 --> Output Class Initialized
INFO - 2018-07-31 13:41:03 --> Security Class Initialized
DEBUG - 2018-07-31 13:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:41:03 --> CSRF cookie sent
INFO - 2018-07-31 13:41:03 --> Input Class Initialized
INFO - 2018-07-31 13:41:03 --> Language Class Initialized
INFO - 2018-07-31 13:41:03 --> Loader Class Initialized
INFO - 2018-07-31 13:41:03 --> Helper loaded: url_helper
INFO - 2018-07-31 13:41:03 --> Helper loaded: form_helper
INFO - 2018-07-31 13:41:03 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:41:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:41:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:41:03 --> User Agent Class Initialized
INFO - 2018-07-31 13:41:03 --> Controller Class Initialized
INFO - 2018-07-31 13:41:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:41:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:41:03 --> Pixel_Model class loaded
INFO - 2018-07-31 13:41:03 --> Database Driver Class Initialized
INFO - 2018-07-31 13:41:03 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:41:03 --> Database Driver Class Initialized
INFO - 2018-07-31 13:41:03 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:41:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:41:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:41:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:41:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:41:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:41:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:41:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:41:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-07-31 13:41:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:41:03 --> Final output sent to browser
DEBUG - 2018-07-31 13:41:03 --> Total execution time: 0.0660
INFO - 2018-07-31 13:41:04 --> Config Class Initialized
INFO - 2018-07-31 13:41:04 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:41:04 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:41:04 --> Utf8 Class Initialized
INFO - 2018-07-31 13:41:04 --> URI Class Initialized
INFO - 2018-07-31 13:41:04 --> Router Class Initialized
INFO - 2018-07-31 13:41:04 --> Output Class Initialized
INFO - 2018-07-31 13:41:04 --> Security Class Initialized
DEBUG - 2018-07-31 13:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:41:04 --> CSRF cookie sent
INFO - 2018-07-31 13:41:04 --> Input Class Initialized
INFO - 2018-07-31 13:41:04 --> Language Class Initialized
INFO - 2018-07-31 13:41:04 --> Loader Class Initialized
INFO - 2018-07-31 13:41:04 --> Helper loaded: url_helper
INFO - 2018-07-31 13:41:04 --> Helper loaded: form_helper
INFO - 2018-07-31 13:41:04 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:41:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:41:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:41:04 --> User Agent Class Initialized
INFO - 2018-07-31 13:41:04 --> Controller Class Initialized
INFO - 2018-07-31 13:41:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:41:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:41:04 --> Pixel_Model class loaded
INFO - 2018-07-31 13:41:04 --> Database Driver Class Initialized
INFO - 2018-07-31 13:41:04 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:41:04 --> Database Driver Class Initialized
INFO - 2018-07-31 13:41:04 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:41:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:41:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:41:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:41:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:41:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:41:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:41:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:41:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-07-31 13:41:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:41:04 --> Final output sent to browser
DEBUG - 2018-07-31 13:41:04 --> Total execution time: 0.0492
INFO - 2018-07-31 13:41:05 --> Config Class Initialized
INFO - 2018-07-31 13:41:05 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:41:05 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:41:05 --> Utf8 Class Initialized
INFO - 2018-07-31 13:41:05 --> URI Class Initialized
INFO - 2018-07-31 13:41:05 --> Router Class Initialized
INFO - 2018-07-31 13:41:05 --> Output Class Initialized
INFO - 2018-07-31 13:41:05 --> Security Class Initialized
DEBUG - 2018-07-31 13:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:41:05 --> CSRF cookie sent
INFO - 2018-07-31 13:41:05 --> Input Class Initialized
INFO - 2018-07-31 13:41:05 --> Language Class Initialized
INFO - 2018-07-31 13:41:05 --> Loader Class Initialized
INFO - 2018-07-31 13:41:05 --> Helper loaded: url_helper
INFO - 2018-07-31 13:41:05 --> Helper loaded: form_helper
INFO - 2018-07-31 13:41:05 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:41:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:41:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:41:05 --> User Agent Class Initialized
INFO - 2018-07-31 13:41:05 --> Controller Class Initialized
INFO - 2018-07-31 13:41:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:41:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:41:05 --> Pixel_Model class loaded
INFO - 2018-07-31 13:41:05 --> Database Driver Class Initialized
INFO - 2018-07-31 13:41:05 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:41:05 --> Database Driver Class Initialized
INFO - 2018-07-31 13:41:05 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:41:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:41:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:41:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:41:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:41:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:41:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:41:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:41:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-07-31 13:41:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:41:05 --> Final output sent to browser
DEBUG - 2018-07-31 13:41:05 --> Total execution time: 0.0475
INFO - 2018-07-31 13:41:07 --> Config Class Initialized
INFO - 2018-07-31 13:41:07 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:41:07 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:41:07 --> Utf8 Class Initialized
INFO - 2018-07-31 13:41:07 --> URI Class Initialized
INFO - 2018-07-31 13:41:07 --> Router Class Initialized
INFO - 2018-07-31 13:41:07 --> Output Class Initialized
INFO - 2018-07-31 13:41:07 --> Security Class Initialized
DEBUG - 2018-07-31 13:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:41:07 --> CSRF cookie sent
INFO - 2018-07-31 13:41:07 --> Input Class Initialized
INFO - 2018-07-31 13:41:07 --> Language Class Initialized
INFO - 2018-07-31 13:41:07 --> Loader Class Initialized
INFO - 2018-07-31 13:41:07 --> Helper loaded: url_helper
INFO - 2018-07-31 13:41:07 --> Helper loaded: form_helper
INFO - 2018-07-31 13:41:07 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:41:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:41:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:41:07 --> User Agent Class Initialized
INFO - 2018-07-31 13:41:07 --> Controller Class Initialized
INFO - 2018-07-31 13:41:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:41:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:41:07 --> Pixel_Model class loaded
INFO - 2018-07-31 13:41:07 --> Database Driver Class Initialized
INFO - 2018-07-31 13:41:07 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:41:07 --> Database Driver Class Initialized
INFO - 2018-07-31 13:41:07 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:41:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:41:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:41:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:41:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:41:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:41:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:41:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:41:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-07-31 13:41:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:41:07 --> Final output sent to browser
DEBUG - 2018-07-31 13:41:07 --> Total execution time: 0.0405
INFO - 2018-07-31 13:41:10 --> Config Class Initialized
INFO - 2018-07-31 13:41:10 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:41:10 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:41:10 --> Utf8 Class Initialized
INFO - 2018-07-31 13:41:10 --> URI Class Initialized
INFO - 2018-07-31 13:41:10 --> Router Class Initialized
INFO - 2018-07-31 13:41:10 --> Output Class Initialized
INFO - 2018-07-31 13:41:10 --> Security Class Initialized
DEBUG - 2018-07-31 13:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:41:10 --> CSRF cookie sent
INFO - 2018-07-31 13:41:10 --> CSRF token verified
INFO - 2018-07-31 13:41:10 --> Input Class Initialized
INFO - 2018-07-31 13:41:10 --> Language Class Initialized
INFO - 2018-07-31 13:41:10 --> Loader Class Initialized
INFO - 2018-07-31 13:41:10 --> Helper loaded: url_helper
INFO - 2018-07-31 13:41:10 --> Helper loaded: form_helper
INFO - 2018-07-31 13:41:10 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:41:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:41:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:41:10 --> User Agent Class Initialized
INFO - 2018-07-31 13:41:10 --> Controller Class Initialized
INFO - 2018-07-31 13:41:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:41:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:41:10 --> Pixel_Model class loaded
INFO - 2018-07-31 13:41:10 --> Database Driver Class Initialized
INFO - 2018-07-31 13:41:10 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:41:10 --> Form Validation Class Initialized
INFO - 2018-07-31 13:41:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-07-31 13:41:10 --> Database Driver Class Initialized
INFO - 2018-07-31 13:41:10 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:41:10 --> Config Class Initialized
INFO - 2018-07-31 13:41:10 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:41:10 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:41:10 --> Utf8 Class Initialized
INFO - 2018-07-31 13:41:10 --> URI Class Initialized
INFO - 2018-07-31 13:41:10 --> Router Class Initialized
INFO - 2018-07-31 13:41:10 --> Output Class Initialized
INFO - 2018-07-31 13:41:10 --> Security Class Initialized
DEBUG - 2018-07-31 13:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:41:10 --> CSRF cookie sent
INFO - 2018-07-31 13:41:10 --> Input Class Initialized
INFO - 2018-07-31 13:41:10 --> Language Class Initialized
INFO - 2018-07-31 13:41:10 --> Loader Class Initialized
INFO - 2018-07-31 13:41:10 --> Helper loaded: url_helper
INFO - 2018-07-31 13:41:10 --> Helper loaded: form_helper
INFO - 2018-07-31 13:41:10 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:41:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:41:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:41:10 --> User Agent Class Initialized
INFO - 2018-07-31 13:41:10 --> Controller Class Initialized
INFO - 2018-07-31 13:41:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:41:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:41:10 --> Pixel_Model class loaded
INFO - 2018-07-31 13:41:10 --> Database Driver Class Initialized
INFO - 2018-07-31 13:41:10 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:41:10 --> Database Driver Class Initialized
INFO - 2018-07-31 13:41:10 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:41:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:41:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:41:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:41:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:41:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:41:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:41:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:41:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-07-31 13:41:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:41:10 --> Final output sent to browser
DEBUG - 2018-07-31 13:41:10 --> Total execution time: 0.0492
INFO - 2018-07-31 13:41:12 --> Config Class Initialized
INFO - 2018-07-31 13:41:12 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:41:12 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:41:12 --> Utf8 Class Initialized
INFO - 2018-07-31 13:41:12 --> URI Class Initialized
INFO - 2018-07-31 13:41:12 --> Router Class Initialized
INFO - 2018-07-31 13:41:12 --> Output Class Initialized
INFO - 2018-07-31 13:41:12 --> Security Class Initialized
DEBUG - 2018-07-31 13:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:41:12 --> CSRF cookie sent
INFO - 2018-07-31 13:41:12 --> Input Class Initialized
INFO - 2018-07-31 13:41:12 --> Language Class Initialized
INFO - 2018-07-31 13:41:12 --> Loader Class Initialized
INFO - 2018-07-31 13:41:12 --> Helper loaded: url_helper
INFO - 2018-07-31 13:41:12 --> Helper loaded: form_helper
INFO - 2018-07-31 13:41:12 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:41:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:41:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:41:12 --> User Agent Class Initialized
INFO - 2018-07-31 13:41:12 --> Controller Class Initialized
INFO - 2018-07-31 13:41:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:41:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:41:12 --> Pixel_Model class loaded
INFO - 2018-07-31 13:41:12 --> Database Driver Class Initialized
INFO - 2018-07-31 13:41:12 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:41:12 --> Database Driver Class Initialized
INFO - 2018-07-31 13:41:12 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:41:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:41:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:41:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:41:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:41:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:41:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:41:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:41:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-07-31 13:41:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:41:12 --> Final output sent to browser
DEBUG - 2018-07-31 13:41:12 --> Total execution time: 0.0442
INFO - 2018-07-31 13:41:12 --> Config Class Initialized
INFO - 2018-07-31 13:41:12 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:41:12 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:41:12 --> Utf8 Class Initialized
INFO - 2018-07-31 13:41:12 --> URI Class Initialized
INFO - 2018-07-31 13:41:12 --> Router Class Initialized
INFO - 2018-07-31 13:41:12 --> Output Class Initialized
INFO - 2018-07-31 13:41:12 --> Security Class Initialized
DEBUG - 2018-07-31 13:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:41:12 --> CSRF cookie sent
INFO - 2018-07-31 13:41:12 --> Input Class Initialized
INFO - 2018-07-31 13:41:12 --> Language Class Initialized
INFO - 2018-07-31 13:41:13 --> Loader Class Initialized
INFO - 2018-07-31 13:41:13 --> Helper loaded: url_helper
INFO - 2018-07-31 13:41:13 --> Helper loaded: form_helper
INFO - 2018-07-31 13:41:13 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:41:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:41:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:41:13 --> User Agent Class Initialized
INFO - 2018-07-31 13:41:13 --> Controller Class Initialized
INFO - 2018-07-31 13:41:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:41:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:41:13 --> Pixel_Model class loaded
INFO - 2018-07-31 13:41:13 --> Database Driver Class Initialized
INFO - 2018-07-31 13:41:13 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:41:13 --> Database Driver Class Initialized
INFO - 2018-07-31 13:41:13 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:41:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:41:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:41:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:41:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:41:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:41:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:41:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:41:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-07-31 13:41:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:41:13 --> Final output sent to browser
DEBUG - 2018-07-31 13:41:13 --> Total execution time: 0.0381
INFO - 2018-07-31 13:41:14 --> Config Class Initialized
INFO - 2018-07-31 13:41:14 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:41:14 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:41:14 --> Utf8 Class Initialized
INFO - 2018-07-31 13:41:14 --> URI Class Initialized
INFO - 2018-07-31 13:41:14 --> Router Class Initialized
INFO - 2018-07-31 13:41:14 --> Output Class Initialized
INFO - 2018-07-31 13:41:14 --> Security Class Initialized
DEBUG - 2018-07-31 13:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:41:14 --> CSRF cookie sent
INFO - 2018-07-31 13:41:14 --> Input Class Initialized
INFO - 2018-07-31 13:41:14 --> Language Class Initialized
INFO - 2018-07-31 13:41:14 --> Loader Class Initialized
INFO - 2018-07-31 13:41:14 --> Helper loaded: url_helper
INFO - 2018-07-31 13:41:14 --> Helper loaded: form_helper
INFO - 2018-07-31 13:41:14 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:41:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:41:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:41:14 --> User Agent Class Initialized
INFO - 2018-07-31 13:41:14 --> Controller Class Initialized
INFO - 2018-07-31 13:41:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:41:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:41:14 --> Pixel_Model class loaded
INFO - 2018-07-31 13:41:14 --> Database Driver Class Initialized
INFO - 2018-07-31 13:41:14 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:41:14 --> Database Driver Class Initialized
INFO - 2018-07-31 13:41:14 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:41:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:41:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:41:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:41:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:41:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:41:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:41:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:41:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_title.php
INFO - 2018-07-31 13:41:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:41:14 --> Final output sent to browser
DEBUG - 2018-07-31 13:41:14 --> Total execution time: 0.0575
INFO - 2018-07-31 13:41:15 --> Config Class Initialized
INFO - 2018-07-31 13:41:15 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:41:15 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:41:15 --> Utf8 Class Initialized
INFO - 2018-07-31 13:41:15 --> URI Class Initialized
INFO - 2018-07-31 13:41:15 --> Router Class Initialized
INFO - 2018-07-31 13:41:15 --> Output Class Initialized
INFO - 2018-07-31 13:41:15 --> Security Class Initialized
DEBUG - 2018-07-31 13:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:41:15 --> CSRF cookie sent
INFO - 2018-07-31 13:41:15 --> Input Class Initialized
INFO - 2018-07-31 13:41:15 --> Language Class Initialized
INFO - 2018-07-31 13:41:15 --> Loader Class Initialized
INFO - 2018-07-31 13:41:15 --> Helper loaded: url_helper
INFO - 2018-07-31 13:41:15 --> Helper loaded: form_helper
INFO - 2018-07-31 13:41:15 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:41:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:41:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:41:15 --> User Agent Class Initialized
INFO - 2018-07-31 13:41:15 --> Controller Class Initialized
INFO - 2018-07-31 13:41:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:41:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:41:15 --> Pixel_Model class loaded
INFO - 2018-07-31 13:41:15 --> Database Driver Class Initialized
INFO - 2018-07-31 13:41:15 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:41:15 --> Database Driver Class Initialized
INFO - 2018-07-31 13:41:15 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:41:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:41:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:41:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:41:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:41:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:41:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:41:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:41:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-07-31 13:41:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:41:15 --> Final output sent to browser
DEBUG - 2018-07-31 13:41:15 --> Total execution time: 0.0449
INFO - 2018-07-31 13:41:16 --> Config Class Initialized
INFO - 2018-07-31 13:41:16 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:41:16 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:41:16 --> Utf8 Class Initialized
INFO - 2018-07-31 13:41:16 --> URI Class Initialized
INFO - 2018-07-31 13:41:16 --> Router Class Initialized
INFO - 2018-07-31 13:41:16 --> Output Class Initialized
INFO - 2018-07-31 13:41:16 --> Security Class Initialized
DEBUG - 2018-07-31 13:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:41:16 --> CSRF cookie sent
INFO - 2018-07-31 13:41:16 --> Input Class Initialized
INFO - 2018-07-31 13:41:16 --> Language Class Initialized
INFO - 2018-07-31 13:41:16 --> Loader Class Initialized
INFO - 2018-07-31 13:41:16 --> Helper loaded: url_helper
INFO - 2018-07-31 13:41:16 --> Helper loaded: form_helper
INFO - 2018-07-31 13:41:16 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:41:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:41:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:41:16 --> User Agent Class Initialized
INFO - 2018-07-31 13:41:16 --> Controller Class Initialized
INFO - 2018-07-31 13:41:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:41:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:41:16 --> Pixel_Model class loaded
INFO - 2018-07-31 13:41:16 --> Database Driver Class Initialized
INFO - 2018-07-31 13:41:16 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:41:16 --> Database Driver Class Initialized
INFO - 2018-07-31 13:41:16 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:41:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:41:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:41:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:41:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:41:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:41:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:41:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:41:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-07-31 13:41:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:41:16 --> Final output sent to browser
DEBUG - 2018-07-31 13:41:16 --> Total execution time: 0.0433
INFO - 2018-07-31 13:41:17 --> Config Class Initialized
INFO - 2018-07-31 13:41:17 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:41:17 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:41:17 --> Utf8 Class Initialized
INFO - 2018-07-31 13:41:17 --> URI Class Initialized
INFO - 2018-07-31 13:41:17 --> Router Class Initialized
INFO - 2018-07-31 13:41:17 --> Output Class Initialized
INFO - 2018-07-31 13:41:17 --> Security Class Initialized
DEBUG - 2018-07-31 13:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:41:17 --> CSRF cookie sent
INFO - 2018-07-31 13:41:17 --> Input Class Initialized
INFO - 2018-07-31 13:41:17 --> Language Class Initialized
INFO - 2018-07-31 13:41:17 --> Loader Class Initialized
INFO - 2018-07-31 13:41:17 --> Helper loaded: url_helper
INFO - 2018-07-31 13:41:17 --> Helper loaded: form_helper
INFO - 2018-07-31 13:41:17 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:41:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:41:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:41:17 --> User Agent Class Initialized
INFO - 2018-07-31 13:41:17 --> Controller Class Initialized
INFO - 2018-07-31 13:41:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:41:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:41:17 --> Pixel_Model class loaded
INFO - 2018-07-31 13:41:17 --> Database Driver Class Initialized
INFO - 2018-07-31 13:41:17 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:41:17 --> Database Driver Class Initialized
INFO - 2018-07-31 13:41:17 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:41:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:41:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:41:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:41:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:41:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:41:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:41:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:41:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/spouse_info.php
INFO - 2018-07-31 13:41:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:41:17 --> Final output sent to browser
DEBUG - 2018-07-31 13:41:17 --> Total execution time: 0.0383
INFO - 2018-07-31 13:41:18 --> Config Class Initialized
INFO - 2018-07-31 13:41:18 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:41:18 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:41:18 --> Utf8 Class Initialized
INFO - 2018-07-31 13:41:18 --> URI Class Initialized
INFO - 2018-07-31 13:41:18 --> Router Class Initialized
INFO - 2018-07-31 13:41:18 --> Output Class Initialized
INFO - 2018-07-31 13:41:18 --> Security Class Initialized
DEBUG - 2018-07-31 13:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:41:18 --> CSRF cookie sent
INFO - 2018-07-31 13:41:18 --> Input Class Initialized
INFO - 2018-07-31 13:41:18 --> Language Class Initialized
INFO - 2018-07-31 13:41:18 --> Loader Class Initialized
INFO - 2018-07-31 13:41:18 --> Helper loaded: url_helper
INFO - 2018-07-31 13:41:18 --> Helper loaded: form_helper
INFO - 2018-07-31 13:41:18 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:41:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:41:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:41:18 --> User Agent Class Initialized
INFO - 2018-07-31 13:41:18 --> Controller Class Initialized
INFO - 2018-07-31 13:41:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:41:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:41:18 --> Pixel_Model class loaded
INFO - 2018-07-31 13:41:18 --> Database Driver Class Initialized
INFO - 2018-07-31 13:41:18 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:41:18 --> Database Driver Class Initialized
INFO - 2018-07-31 13:41:18 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:41:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:41:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:41:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:41:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:41:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:41:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:41:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:41:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/spouse_job.php
INFO - 2018-07-31 13:41:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:41:18 --> Final output sent to browser
DEBUG - 2018-07-31 13:41:18 --> Total execution time: 0.0420
INFO - 2018-07-31 13:41:20 --> Config Class Initialized
INFO - 2018-07-31 13:41:20 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:41:20 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:41:20 --> Utf8 Class Initialized
INFO - 2018-07-31 13:41:20 --> URI Class Initialized
INFO - 2018-07-31 13:41:20 --> Router Class Initialized
INFO - 2018-07-31 13:41:20 --> Output Class Initialized
INFO - 2018-07-31 13:41:20 --> Security Class Initialized
DEBUG - 2018-07-31 13:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:41:20 --> CSRF cookie sent
INFO - 2018-07-31 13:41:20 --> Input Class Initialized
INFO - 2018-07-31 13:41:20 --> Language Class Initialized
INFO - 2018-07-31 13:41:20 --> Loader Class Initialized
INFO - 2018-07-31 13:41:20 --> Helper loaded: url_helper
INFO - 2018-07-31 13:41:20 --> Helper loaded: form_helper
INFO - 2018-07-31 13:41:20 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:41:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:41:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:41:20 --> User Agent Class Initialized
INFO - 2018-07-31 13:41:20 --> Controller Class Initialized
INFO - 2018-07-31 13:41:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:41:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:41:20 --> Pixel_Model class loaded
INFO - 2018-07-31 13:41:20 --> Database Driver Class Initialized
INFO - 2018-07-31 13:41:20 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:41:20 --> Database Driver Class Initialized
INFO - 2018-07-31 13:41:20 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:41:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:41:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:41:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:41:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:41:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:41:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:41:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:41:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/affectionate_salutation.php
INFO - 2018-07-31 13:41:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:41:20 --> Final output sent to browser
DEBUG - 2018-07-31 13:41:20 --> Total execution time: 0.0547
INFO - 2018-07-31 13:41:21 --> Config Class Initialized
INFO - 2018-07-31 13:41:21 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:41:21 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:41:21 --> Utf8 Class Initialized
INFO - 2018-07-31 13:41:21 --> URI Class Initialized
INFO - 2018-07-31 13:41:21 --> Router Class Initialized
INFO - 2018-07-31 13:41:21 --> Output Class Initialized
INFO - 2018-07-31 13:41:21 --> Security Class Initialized
DEBUG - 2018-07-31 13:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:41:21 --> CSRF cookie sent
INFO - 2018-07-31 13:41:21 --> Input Class Initialized
INFO - 2018-07-31 13:41:21 --> Language Class Initialized
INFO - 2018-07-31 13:41:21 --> Loader Class Initialized
INFO - 2018-07-31 13:41:21 --> Helper loaded: url_helper
INFO - 2018-07-31 13:41:21 --> Helper loaded: form_helper
INFO - 2018-07-31 13:41:21 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:41:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:41:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:41:21 --> User Agent Class Initialized
INFO - 2018-07-31 13:41:21 --> Controller Class Initialized
INFO - 2018-07-31 13:41:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:41:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:41:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:41:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:41:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:41:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:41:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-07-31 13:41:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:41:21 --> Final output sent to browser
DEBUG - 2018-07-31 13:41:21 --> Total execution time: 0.0331
INFO - 2018-07-31 13:41:21 --> Config Class Initialized
INFO - 2018-07-31 13:41:21 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:41:21 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:41:21 --> Utf8 Class Initialized
INFO - 2018-07-31 13:41:21 --> URI Class Initialized
INFO - 2018-07-31 13:41:21 --> Router Class Initialized
INFO - 2018-07-31 13:41:21 --> Output Class Initialized
INFO - 2018-07-31 13:41:21 --> Security Class Initialized
DEBUG - 2018-07-31 13:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:41:21 --> CSRF cookie sent
INFO - 2018-07-31 13:41:21 --> Input Class Initialized
INFO - 2018-07-31 13:41:21 --> Language Class Initialized
INFO - 2018-07-31 13:41:21 --> Loader Class Initialized
INFO - 2018-07-31 13:41:21 --> Helper loaded: url_helper
INFO - 2018-07-31 13:41:21 --> Helper loaded: form_helper
INFO - 2018-07-31 13:41:21 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:41:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:41:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:41:21 --> User Agent Class Initialized
INFO - 2018-07-31 13:41:21 --> Controller Class Initialized
INFO - 2018-07-31 13:41:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:41:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:41:21 --> Pixel_Model class loaded
INFO - 2018-07-31 13:41:21 --> Database Driver Class Initialized
INFO - 2018-07-31 13:41:21 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:41:21 --> Database Driver Class Initialized
INFO - 2018-07-31 13:41:21 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:41:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:41:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:41:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:41:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:41:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:41:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:41:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:41:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/business_tax_info.php
INFO - 2018-07-31 13:41:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:41:21 --> Final output sent to browser
DEBUG - 2018-07-31 13:41:21 --> Total execution time: 0.0443
INFO - 2018-07-31 13:41:23 --> Config Class Initialized
INFO - 2018-07-31 13:41:23 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:41:23 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:41:23 --> Utf8 Class Initialized
INFO - 2018-07-31 13:41:23 --> URI Class Initialized
INFO - 2018-07-31 13:41:23 --> Router Class Initialized
INFO - 2018-07-31 13:41:23 --> Output Class Initialized
INFO - 2018-07-31 13:41:23 --> Security Class Initialized
DEBUG - 2018-07-31 13:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:41:23 --> CSRF cookie sent
INFO - 2018-07-31 13:41:23 --> Input Class Initialized
INFO - 2018-07-31 13:41:23 --> Language Class Initialized
INFO - 2018-07-31 13:41:23 --> Loader Class Initialized
INFO - 2018-07-31 13:41:23 --> Helper loaded: url_helper
INFO - 2018-07-31 13:41:23 --> Helper loaded: form_helper
INFO - 2018-07-31 13:41:23 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:41:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:41:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:41:23 --> User Agent Class Initialized
INFO - 2018-07-31 13:41:23 --> Controller Class Initialized
INFO - 2018-07-31 13:41:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:41:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:41:23 --> Pixel_Model class loaded
INFO - 2018-07-31 13:41:23 --> Database Driver Class Initialized
INFO - 2018-07-31 13:41:23 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:41:23 --> Database Driver Class Initialized
INFO - 2018-07-31 13:41:23 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:41:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:41:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:41:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:41:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:41:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:41:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:41:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:41:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/trust_info.php
INFO - 2018-07-31 13:41:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:41:23 --> Final output sent to browser
DEBUG - 2018-07-31 13:41:23 --> Total execution time: 0.0434
INFO - 2018-07-31 13:41:24 --> Config Class Initialized
INFO - 2018-07-31 13:41:24 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:41:24 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:41:24 --> Utf8 Class Initialized
INFO - 2018-07-31 13:41:24 --> URI Class Initialized
INFO - 2018-07-31 13:41:24 --> Router Class Initialized
INFO - 2018-07-31 13:41:24 --> Output Class Initialized
INFO - 2018-07-31 13:41:24 --> Security Class Initialized
DEBUG - 2018-07-31 13:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:41:24 --> CSRF cookie sent
INFO - 2018-07-31 13:41:24 --> Input Class Initialized
INFO - 2018-07-31 13:41:24 --> Language Class Initialized
INFO - 2018-07-31 13:41:24 --> Loader Class Initialized
INFO - 2018-07-31 13:41:24 --> Helper loaded: url_helper
INFO - 2018-07-31 13:41:24 --> Helper loaded: form_helper
INFO - 2018-07-31 13:41:24 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:41:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:41:24 --> User Agent Class Initialized
INFO - 2018-07-31 13:41:24 --> Controller Class Initialized
INFO - 2018-07-31 13:41:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:41:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:41:24 --> Pixel_Model class loaded
INFO - 2018-07-31 13:41:24 --> Database Driver Class Initialized
INFO - 2018-07-31 13:41:24 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:41:24 --> Database Driver Class Initialized
INFO - 2018-07-31 13:41:24 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:41:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:41:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:41:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:41:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:41:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:41:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:41:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:41:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inherited_income.php
INFO - 2018-07-31 13:41:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:41:24 --> Final output sent to browser
DEBUG - 2018-07-31 13:41:24 --> Total execution time: 0.0438
INFO - 2018-07-31 13:41:26 --> Config Class Initialized
INFO - 2018-07-31 13:41:26 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:41:26 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:41:26 --> Utf8 Class Initialized
INFO - 2018-07-31 13:41:26 --> URI Class Initialized
INFO - 2018-07-31 13:41:26 --> Router Class Initialized
INFO - 2018-07-31 13:41:26 --> Output Class Initialized
INFO - 2018-07-31 13:41:26 --> Security Class Initialized
DEBUG - 2018-07-31 13:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:41:26 --> CSRF cookie sent
INFO - 2018-07-31 13:41:26 --> Input Class Initialized
INFO - 2018-07-31 13:41:26 --> Language Class Initialized
INFO - 2018-07-31 13:41:26 --> Loader Class Initialized
INFO - 2018-07-31 13:41:26 --> Helper loaded: url_helper
INFO - 2018-07-31 13:41:26 --> Helper loaded: form_helper
INFO - 2018-07-31 13:41:26 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:41:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:41:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:41:26 --> User Agent Class Initialized
INFO - 2018-07-31 13:41:26 --> Controller Class Initialized
INFO - 2018-07-31 13:41:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:41:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:41:26 --> Pixel_Model class loaded
INFO - 2018-07-31 13:41:26 --> Database Driver Class Initialized
INFO - 2018-07-31 13:41:26 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:41:26 --> Database Driver Class Initialized
INFO - 2018-07-31 13:41:26 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:41:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:41:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:41:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:41:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:41:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:41:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:41:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:41:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/shift_work.php
INFO - 2018-07-31 13:41:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:41:26 --> Final output sent to browser
DEBUG - 2018-07-31 13:41:26 --> Total execution time: 0.0431
INFO - 2018-07-31 13:41:27 --> Config Class Initialized
INFO - 2018-07-31 13:41:27 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:41:27 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:41:27 --> Utf8 Class Initialized
INFO - 2018-07-31 13:41:27 --> URI Class Initialized
INFO - 2018-07-31 13:41:27 --> Router Class Initialized
INFO - 2018-07-31 13:41:27 --> Output Class Initialized
INFO - 2018-07-31 13:41:27 --> Security Class Initialized
DEBUG - 2018-07-31 13:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:41:27 --> CSRF cookie sent
INFO - 2018-07-31 13:41:27 --> Input Class Initialized
INFO - 2018-07-31 13:41:27 --> Language Class Initialized
INFO - 2018-07-31 13:41:27 --> Loader Class Initialized
INFO - 2018-07-31 13:41:27 --> Helper loaded: url_helper
INFO - 2018-07-31 13:41:27 --> Helper loaded: form_helper
INFO - 2018-07-31 13:41:27 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:41:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:41:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:41:27 --> User Agent Class Initialized
INFO - 2018-07-31 13:41:27 --> Controller Class Initialized
INFO - 2018-07-31 13:41:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:41:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:41:27 --> Pixel_Model class loaded
INFO - 2018-07-31 13:41:27 --> Config Class Initialized
INFO - 2018-07-31 13:41:27 --> Hooks Class Initialized
INFO - 2018-07-31 13:41:27 --> Database Driver Class Initialized
DEBUG - 2018-07-31 13:41:27 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:41:27 --> Utf8 Class Initialized
INFO - 2018-07-31 13:41:27 --> URI Class Initialized
INFO - 2018-07-31 13:41:27 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:41:27 --> Router Class Initialized
INFO - 2018-07-31 13:41:27 --> Output Class Initialized
INFO - 2018-07-31 13:41:27 --> Security Class Initialized
INFO - 2018-07-31 13:41:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:41:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
DEBUG - 2018-07-31 13:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:41:27 --> CSRF cookie sent
INFO - 2018-07-31 13:41:27 --> Input Class Initialized
INFO - 2018-07-31 13:41:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:41:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:41:27 --> Language Class Initialized
INFO - 2018-07-31 13:41:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:41:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:41:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-07-31 13:41:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:41:27 --> Final output sent to browser
DEBUG - 2018-07-31 13:41:27 --> Total execution time: 0.0363
INFO - 2018-07-31 13:41:27 --> Loader Class Initialized
INFO - 2018-07-31 13:41:27 --> Helper loaded: url_helper
INFO - 2018-07-31 13:41:27 --> Helper loaded: form_helper
INFO - 2018-07-31 13:41:27 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:41:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:41:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:41:27 --> User Agent Class Initialized
INFO - 2018-07-31 13:41:27 --> Controller Class Initialized
INFO - 2018-07-31 13:41:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:41:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:41:27 --> Pixel_Model class loaded
INFO - 2018-07-31 13:41:27 --> Database Driver Class Initialized
INFO - 2018-07-31 13:41:27 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:41:27 --> Database Driver Class Initialized
INFO - 2018-07-31 13:41:27 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:41:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:41:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:41:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:41:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:41:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:41:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:41:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:41:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/night_without_s.php
INFO - 2018-07-31 13:41:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:41:27 --> Final output sent to browser
DEBUG - 2018-07-31 13:41:27 --> Total execution time: 0.0443
INFO - 2018-07-31 13:41:31 --> Config Class Initialized
INFO - 2018-07-31 13:41:31 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:41:31 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:41:31 --> Utf8 Class Initialized
INFO - 2018-07-31 13:41:31 --> URI Class Initialized
INFO - 2018-07-31 13:41:31 --> Router Class Initialized
INFO - 2018-07-31 13:41:31 --> Output Class Initialized
INFO - 2018-07-31 13:41:31 --> Security Class Initialized
DEBUG - 2018-07-31 13:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:41:31 --> CSRF cookie sent
INFO - 2018-07-31 13:41:31 --> Input Class Initialized
INFO - 2018-07-31 13:41:31 --> Language Class Initialized
INFO - 2018-07-31 13:41:31 --> Loader Class Initialized
INFO - 2018-07-31 13:41:31 --> Helper loaded: url_helper
INFO - 2018-07-31 13:41:31 --> Helper loaded: form_helper
INFO - 2018-07-31 13:41:31 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:41:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:41:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:41:31 --> User Agent Class Initialized
INFO - 2018-07-31 13:41:31 --> Controller Class Initialized
INFO - 2018-07-31 13:41:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:41:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:41:31 --> Pixel_Model class loaded
INFO - 2018-07-31 13:41:31 --> Database Driver Class Initialized
INFO - 2018-07-31 13:41:31 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:41:31 --> Database Driver Class Initialized
INFO - 2018-07-31 13:41:31 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:41:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:41:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:41:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:41:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:41:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:41:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:41:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:41:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/have_date.php
INFO - 2018-07-31 13:41:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:41:31 --> Final output sent to browser
DEBUG - 2018-07-31 13:41:31 --> Total execution time: 0.0456
INFO - 2018-07-31 13:41:32 --> Config Class Initialized
INFO - 2018-07-31 13:41:32 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:41:32 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:41:32 --> Utf8 Class Initialized
INFO - 2018-07-31 13:41:32 --> URI Class Initialized
INFO - 2018-07-31 13:41:32 --> Router Class Initialized
INFO - 2018-07-31 13:41:32 --> Output Class Initialized
INFO - 2018-07-31 13:41:32 --> Security Class Initialized
DEBUG - 2018-07-31 13:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:41:32 --> CSRF cookie sent
INFO - 2018-07-31 13:41:32 --> Input Class Initialized
INFO - 2018-07-31 13:41:32 --> Language Class Initialized
INFO - 2018-07-31 13:41:32 --> Loader Class Initialized
INFO - 2018-07-31 13:41:32 --> Helper loaded: url_helper
INFO - 2018-07-31 13:41:32 --> Helper loaded: form_helper
INFO - 2018-07-31 13:41:32 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:41:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:41:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:41:32 --> User Agent Class Initialized
INFO - 2018-07-31 13:41:32 --> Controller Class Initialized
INFO - 2018-07-31 13:41:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:41:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:41:32 --> Pixel_Model class loaded
INFO - 2018-07-31 13:41:32 --> Database Driver Class Initialized
INFO - 2018-07-31 13:41:32 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:41:32 --> Database Driver Class Initialized
INFO - 2018-07-31 13:41:32 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:41:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:41:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:41:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:41:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:41:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:41:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:41:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:41:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/nights_not_home.php
INFO - 2018-07-31 13:41:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:41:32 --> Final output sent to browser
DEBUG - 2018-07-31 13:41:32 --> Total execution time: 0.0539
INFO - 2018-07-31 13:41:35 --> Config Class Initialized
INFO - 2018-07-31 13:41:35 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:41:35 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:41:35 --> Utf8 Class Initialized
INFO - 2018-07-31 13:41:35 --> URI Class Initialized
INFO - 2018-07-31 13:41:35 --> Router Class Initialized
INFO - 2018-07-31 13:41:35 --> Output Class Initialized
INFO - 2018-07-31 13:41:35 --> Security Class Initialized
DEBUG - 2018-07-31 13:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:41:35 --> CSRF cookie sent
INFO - 2018-07-31 13:41:35 --> Input Class Initialized
INFO - 2018-07-31 13:41:35 --> Language Class Initialized
INFO - 2018-07-31 13:41:35 --> Loader Class Initialized
INFO - 2018-07-31 13:41:35 --> Helper loaded: url_helper
INFO - 2018-07-31 13:41:35 --> Helper loaded: form_helper
INFO - 2018-07-31 13:41:35 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:41:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:41:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:41:35 --> User Agent Class Initialized
INFO - 2018-07-31 13:41:35 --> Controller Class Initialized
INFO - 2018-07-31 13:41:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:41:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:41:35 --> Pixel_Model class loaded
INFO - 2018-07-31 13:41:35 --> Database Driver Class Initialized
INFO - 2018-07-31 13:41:35 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:41:35 --> Database Driver Class Initialized
INFO - 2018-07-31 13:41:35 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:41:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:41:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:41:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:41:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:41:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:41:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:41:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:41:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/s_nights_not_home.php
INFO - 2018-07-31 13:41:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:41:35 --> Final output sent to browser
DEBUG - 2018-07-31 13:41:35 --> Total execution time: 0.0715
INFO - 2018-07-31 13:41:36 --> Config Class Initialized
INFO - 2018-07-31 13:41:36 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:41:36 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:41:36 --> Utf8 Class Initialized
INFO - 2018-07-31 13:41:36 --> URI Class Initialized
INFO - 2018-07-31 13:41:36 --> Router Class Initialized
INFO - 2018-07-31 13:41:36 --> Output Class Initialized
INFO - 2018-07-31 13:41:36 --> Security Class Initialized
DEBUG - 2018-07-31 13:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:41:36 --> CSRF cookie sent
INFO - 2018-07-31 13:41:36 --> Input Class Initialized
INFO - 2018-07-31 13:41:36 --> Language Class Initialized
INFO - 2018-07-31 13:41:36 --> Loader Class Initialized
INFO - 2018-07-31 13:41:36 --> Helper loaded: url_helper
INFO - 2018-07-31 13:41:36 --> Helper loaded: form_helper
INFO - 2018-07-31 13:41:36 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:41:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:41:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:41:36 --> User Agent Class Initialized
INFO - 2018-07-31 13:41:36 --> Controller Class Initialized
INFO - 2018-07-31 13:41:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:41:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:41:36 --> Pixel_Model class loaded
INFO - 2018-07-31 13:41:36 --> Database Driver Class Initialized
INFO - 2018-07-31 13:41:36 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:41:36 --> Database Driver Class Initialized
INFO - 2018-07-31 13:41:36 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:41:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:41:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:41:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:41:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:41:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:41:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:41:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:41:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/s_nights_without_you.php
INFO - 2018-07-31 13:41:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:41:36 --> Final output sent to browser
DEBUG - 2018-07-31 13:41:36 --> Total execution time: 0.0500
INFO - 2018-07-31 13:41:37 --> Config Class Initialized
INFO - 2018-07-31 13:41:37 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:41:37 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:41:37 --> Utf8 Class Initialized
INFO - 2018-07-31 13:41:37 --> URI Class Initialized
INFO - 2018-07-31 13:41:37 --> Router Class Initialized
INFO - 2018-07-31 13:41:37 --> Output Class Initialized
INFO - 2018-07-31 13:41:37 --> Security Class Initialized
DEBUG - 2018-07-31 13:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:41:37 --> CSRF cookie sent
INFO - 2018-07-31 13:41:37 --> Input Class Initialized
INFO - 2018-07-31 13:41:37 --> Language Class Initialized
INFO - 2018-07-31 13:41:38 --> Loader Class Initialized
INFO - 2018-07-31 13:41:38 --> Helper loaded: url_helper
INFO - 2018-07-31 13:41:38 --> Helper loaded: form_helper
INFO - 2018-07-31 13:41:38 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:41:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:41:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:41:38 --> User Agent Class Initialized
INFO - 2018-07-31 13:41:38 --> Controller Class Initialized
INFO - 2018-07-31 13:41:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:41:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:41:38 --> Pixel_Model class loaded
INFO - 2018-07-31 13:41:38 --> Database Driver Class Initialized
INFO - 2018-07-31 13:41:38 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:41:38 --> Database Driver Class Initialized
INFO - 2018-07-31 13:41:38 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:41:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:41:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:41:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:41:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:41:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:41:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:41:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:41:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/alcoholic_drinks_per_week.php
INFO - 2018-07-31 13:41:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:41:38 --> Final output sent to browser
DEBUG - 2018-07-31 13:41:38 --> Total execution time: 0.0499
INFO - 2018-07-31 13:41:44 --> Config Class Initialized
INFO - 2018-07-31 13:41:44 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:41:44 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:41:44 --> Utf8 Class Initialized
INFO - 2018-07-31 13:41:44 --> URI Class Initialized
INFO - 2018-07-31 13:41:44 --> Router Class Initialized
INFO - 2018-07-31 13:41:44 --> Output Class Initialized
INFO - 2018-07-31 13:41:44 --> Security Class Initialized
DEBUG - 2018-07-31 13:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:41:44 --> CSRF cookie sent
INFO - 2018-07-31 13:41:44 --> Input Class Initialized
INFO - 2018-07-31 13:41:44 --> Language Class Initialized
INFO - 2018-07-31 13:41:44 --> Loader Class Initialized
INFO - 2018-07-31 13:41:44 --> Helper loaded: url_helper
INFO - 2018-07-31 13:41:44 --> Helper loaded: form_helper
INFO - 2018-07-31 13:41:44 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:41:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:41:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:41:44 --> User Agent Class Initialized
INFO - 2018-07-31 13:41:44 --> Controller Class Initialized
INFO - 2018-07-31 13:41:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:41:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:41:44 --> Pixel_Model class loaded
INFO - 2018-07-31 13:41:44 --> Database Driver Class Initialized
INFO - 2018-07-31 13:41:44 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:41:44 --> Database Driver Class Initialized
INFO - 2018-07-31 13:41:44 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:41:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:41:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:41:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:41:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:41:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:41:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:41:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:41:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/have_drugs.php
INFO - 2018-07-31 13:41:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:41:44 --> Final output sent to browser
DEBUG - 2018-07-31 13:41:44 --> Total execution time: 0.0703
INFO - 2018-07-31 13:41:46 --> Config Class Initialized
INFO - 2018-07-31 13:41:46 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:41:46 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:41:46 --> Utf8 Class Initialized
INFO - 2018-07-31 13:41:46 --> URI Class Initialized
INFO - 2018-07-31 13:41:46 --> Router Class Initialized
INFO - 2018-07-31 13:41:46 --> Output Class Initialized
INFO - 2018-07-31 13:41:46 --> Security Class Initialized
DEBUG - 2018-07-31 13:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:41:46 --> CSRF cookie sent
INFO - 2018-07-31 13:41:46 --> Input Class Initialized
INFO - 2018-07-31 13:41:46 --> Language Class Initialized
INFO - 2018-07-31 13:41:46 --> Loader Class Initialized
INFO - 2018-07-31 13:41:46 --> Helper loaded: url_helper
INFO - 2018-07-31 13:41:46 --> Helper loaded: form_helper
INFO - 2018-07-31 13:41:46 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:41:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:41:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:41:46 --> User Agent Class Initialized
INFO - 2018-07-31 13:41:46 --> Controller Class Initialized
INFO - 2018-07-31 13:41:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:41:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:41:46 --> Pixel_Model class loaded
INFO - 2018-07-31 13:41:46 --> Database Driver Class Initialized
INFO - 2018-07-31 13:41:46 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:41:46 --> Database Driver Class Initialized
INFO - 2018-07-31 13:41:46 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:41:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:41:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:41:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:41:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:41:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:41:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:41:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:41:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/has_addiction_problem.php
INFO - 2018-07-31 13:41:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:41:46 --> Final output sent to browser
DEBUG - 2018-07-31 13:41:46 --> Total execution time: 0.0646
INFO - 2018-07-31 13:41:49 --> Config Class Initialized
INFO - 2018-07-31 13:41:49 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:41:49 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:41:49 --> Utf8 Class Initialized
INFO - 2018-07-31 13:41:49 --> URI Class Initialized
INFO - 2018-07-31 13:41:49 --> Router Class Initialized
INFO - 2018-07-31 13:41:49 --> Output Class Initialized
INFO - 2018-07-31 13:41:49 --> Security Class Initialized
DEBUG - 2018-07-31 13:41:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:41:49 --> CSRF cookie sent
INFO - 2018-07-31 13:41:49 --> Input Class Initialized
INFO - 2018-07-31 13:41:49 --> Language Class Initialized
INFO - 2018-07-31 13:41:49 --> Loader Class Initialized
INFO - 2018-07-31 13:41:49 --> Helper loaded: url_helper
INFO - 2018-07-31 13:41:49 --> Helper loaded: form_helper
INFO - 2018-07-31 13:41:49 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:41:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:41:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:41:49 --> User Agent Class Initialized
INFO - 2018-07-31 13:41:49 --> Controller Class Initialized
INFO - 2018-07-31 13:41:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:41:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:41:49 --> Pixel_Model class loaded
INFO - 2018-07-31 13:41:49 --> Database Driver Class Initialized
INFO - 2018-07-31 13:41:49 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:41:49 --> Database Driver Class Initialized
INFO - 2018-07-31 13:41:49 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:41:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:41:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:41:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:41:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:41:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:41:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:41:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:41:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/have_hit_s.php
INFO - 2018-07-31 13:41:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:41:49 --> Final output sent to browser
DEBUG - 2018-07-31 13:41:49 --> Total execution time: 0.0464
INFO - 2018-07-31 13:41:54 --> Config Class Initialized
INFO - 2018-07-31 13:41:54 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:41:54 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:41:54 --> Utf8 Class Initialized
INFO - 2018-07-31 13:41:54 --> URI Class Initialized
INFO - 2018-07-31 13:41:54 --> Router Class Initialized
INFO - 2018-07-31 13:41:54 --> Output Class Initialized
INFO - 2018-07-31 13:41:54 --> Security Class Initialized
DEBUG - 2018-07-31 13:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:41:54 --> CSRF cookie sent
INFO - 2018-07-31 13:41:54 --> Input Class Initialized
INFO - 2018-07-31 13:41:54 --> Language Class Initialized
INFO - 2018-07-31 13:41:54 --> Loader Class Initialized
INFO - 2018-07-31 13:41:54 --> Helper loaded: url_helper
INFO - 2018-07-31 13:41:54 --> Helper loaded: form_helper
INFO - 2018-07-31 13:41:54 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:41:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:41:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:41:54 --> User Agent Class Initialized
INFO - 2018-07-31 13:41:54 --> Controller Class Initialized
INFO - 2018-07-31 13:41:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:41:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:41:54 --> Pixel_Model class loaded
INFO - 2018-07-31 13:41:54 --> Database Driver Class Initialized
INFO - 2018-07-31 13:41:54 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:41:54 --> Database Driver Class Initialized
INFO - 2018-07-31 13:41:54 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:41:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:41:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:41:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:41:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:41:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:41:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:41:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:41:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial_control.php
INFO - 2018-07-31 13:41:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:41:54 --> Final output sent to browser
DEBUG - 2018-07-31 13:41:54 --> Total execution time: 0.0604
INFO - 2018-07-31 13:41:56 --> Config Class Initialized
INFO - 2018-07-31 13:41:56 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:41:56 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:41:56 --> Utf8 Class Initialized
INFO - 2018-07-31 13:41:56 --> URI Class Initialized
INFO - 2018-07-31 13:41:56 --> Router Class Initialized
INFO - 2018-07-31 13:41:56 --> Output Class Initialized
INFO - 2018-07-31 13:41:56 --> Security Class Initialized
DEBUG - 2018-07-31 13:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:41:56 --> CSRF cookie sent
INFO - 2018-07-31 13:41:56 --> Input Class Initialized
INFO - 2018-07-31 13:41:56 --> Language Class Initialized
INFO - 2018-07-31 13:41:56 --> Loader Class Initialized
INFO - 2018-07-31 13:41:56 --> Helper loaded: url_helper
INFO - 2018-07-31 13:41:56 --> Helper loaded: form_helper
INFO - 2018-07-31 13:41:56 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:41:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:41:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:41:56 --> User Agent Class Initialized
INFO - 2018-07-31 13:41:56 --> Controller Class Initialized
INFO - 2018-07-31 13:41:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:41:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:41:56 --> Pixel_Model class loaded
INFO - 2018-07-31 13:41:56 --> Database Driver Class Initialized
INFO - 2018-07-31 13:41:56 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:41:56 --> Database Driver Class Initialized
INFO - 2018-07-31 13:41:56 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:41:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:41:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:41:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:41:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:41:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:41:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:41:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:41:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/has_hit_kids.php
INFO - 2018-07-31 13:41:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:41:56 --> Final output sent to browser
DEBUG - 2018-07-31 13:41:56 --> Total execution time: 0.0461
INFO - 2018-07-31 13:41:59 --> Config Class Initialized
INFO - 2018-07-31 13:41:59 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:41:59 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:41:59 --> Utf8 Class Initialized
INFO - 2018-07-31 13:41:59 --> URI Class Initialized
INFO - 2018-07-31 13:41:59 --> Router Class Initialized
INFO - 2018-07-31 13:41:59 --> Output Class Initialized
INFO - 2018-07-31 13:41:59 --> Security Class Initialized
DEBUG - 2018-07-31 13:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:41:59 --> CSRF cookie sent
INFO - 2018-07-31 13:41:59 --> Input Class Initialized
INFO - 2018-07-31 13:41:59 --> Language Class Initialized
INFO - 2018-07-31 13:41:59 --> Loader Class Initialized
INFO - 2018-07-31 13:41:59 --> Helper loaded: url_helper
INFO - 2018-07-31 13:41:59 --> Helper loaded: form_helper
INFO - 2018-07-31 13:41:59 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:41:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:41:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:41:59 --> User Agent Class Initialized
INFO - 2018-07-31 13:41:59 --> Controller Class Initialized
INFO - 2018-07-31 13:41:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:41:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:41:59 --> Pixel_Model class loaded
INFO - 2018-07-31 13:41:59 --> Database Driver Class Initialized
INFO - 2018-07-31 13:41:59 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:41:59 --> Database Driver Class Initialized
INFO - 2018-07-31 13:41:59 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:41:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:41:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:41:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:41:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:41:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:41:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:41:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:41:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/withheld_sex.php
INFO - 2018-07-31 13:41:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:41:59 --> Final output sent to browser
DEBUG - 2018-07-31 13:41:59 --> Total execution time: 0.0550
INFO - 2018-07-31 13:42:02 --> Config Class Initialized
INFO - 2018-07-31 13:42:02 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:42:02 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:42:02 --> Utf8 Class Initialized
INFO - 2018-07-31 13:42:02 --> URI Class Initialized
INFO - 2018-07-31 13:42:02 --> Router Class Initialized
INFO - 2018-07-31 13:42:02 --> Output Class Initialized
INFO - 2018-07-31 13:42:02 --> Security Class Initialized
DEBUG - 2018-07-31 13:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:42:02 --> CSRF cookie sent
INFO - 2018-07-31 13:42:02 --> Input Class Initialized
INFO - 2018-07-31 13:42:02 --> Language Class Initialized
INFO - 2018-07-31 13:42:02 --> Loader Class Initialized
INFO - 2018-07-31 13:42:02 --> Helper loaded: url_helper
INFO - 2018-07-31 13:42:02 --> Helper loaded: form_helper
INFO - 2018-07-31 13:42:02 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:42:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:42:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:42:02 --> User Agent Class Initialized
INFO - 2018-07-31 13:42:02 --> Controller Class Initialized
INFO - 2018-07-31 13:42:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:42:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:42:02 --> Pixel_Model class loaded
INFO - 2018-07-31 13:42:02 --> Database Driver Class Initialized
INFO - 2018-07-31 13:42:02 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:42:02 --> Database Driver Class Initialized
INFO - 2018-07-31 13:42:02 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:42:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:42:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:42:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:42:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:42:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:42:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:42:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:42:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pet_abuse.php
INFO - 2018-07-31 13:42:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:42:02 --> Final output sent to browser
DEBUG - 2018-07-31 13:42:02 --> Total execution time: 0.0459
INFO - 2018-07-31 13:42:04 --> Config Class Initialized
INFO - 2018-07-31 13:42:04 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:42:04 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:42:04 --> Utf8 Class Initialized
INFO - 2018-07-31 13:42:04 --> URI Class Initialized
INFO - 2018-07-31 13:42:04 --> Router Class Initialized
INFO - 2018-07-31 13:42:04 --> Output Class Initialized
INFO - 2018-07-31 13:42:04 --> Security Class Initialized
DEBUG - 2018-07-31 13:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:42:04 --> CSRF cookie sent
INFO - 2018-07-31 13:42:04 --> Input Class Initialized
INFO - 2018-07-31 13:42:04 --> Language Class Initialized
INFO - 2018-07-31 13:42:04 --> Loader Class Initialized
INFO - 2018-07-31 13:42:04 --> Helper loaded: url_helper
INFO - 2018-07-31 13:42:04 --> Helper loaded: form_helper
INFO - 2018-07-31 13:42:04 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:42:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:42:04 --> User Agent Class Initialized
INFO - 2018-07-31 13:42:04 --> Controller Class Initialized
INFO - 2018-07-31 13:42:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:42:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:42:04 --> Pixel_Model class loaded
INFO - 2018-07-31 13:42:04 --> Database Driver Class Initialized
INFO - 2018-07-31 13:42:04 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:42:04 --> Database Driver Class Initialized
INFO - 2018-07-31 13:42:04 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:42:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:42:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:42:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:42:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:42:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:42:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:42:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:42:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/has_dating_profile.php
INFO - 2018-07-31 13:42:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:42:04 --> Final output sent to browser
DEBUG - 2018-07-31 13:42:04 --> Total execution time: 0.0515
INFO - 2018-07-31 13:42:06 --> Config Class Initialized
INFO - 2018-07-31 13:42:06 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:42:06 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:42:06 --> Utf8 Class Initialized
INFO - 2018-07-31 13:42:06 --> URI Class Initialized
INFO - 2018-07-31 13:42:06 --> Router Class Initialized
INFO - 2018-07-31 13:42:06 --> Output Class Initialized
INFO - 2018-07-31 13:42:06 --> Security Class Initialized
DEBUG - 2018-07-31 13:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:42:06 --> CSRF cookie sent
INFO - 2018-07-31 13:42:06 --> Input Class Initialized
INFO - 2018-07-31 13:42:06 --> Language Class Initialized
INFO - 2018-07-31 13:42:06 --> Loader Class Initialized
INFO - 2018-07-31 13:42:06 --> Helper loaded: url_helper
INFO - 2018-07-31 13:42:06 --> Helper loaded: form_helper
INFO - 2018-07-31 13:42:06 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:42:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:42:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:42:06 --> User Agent Class Initialized
INFO - 2018-07-31 13:42:06 --> Controller Class Initialized
INFO - 2018-07-31 13:42:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:42:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:42:06 --> Pixel_Model class loaded
INFO - 2018-07-31 13:42:06 --> Database Driver Class Initialized
INFO - 2018-07-31 13:42:06 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:42:06 --> Database Driver Class Initialized
INFO - 2018-07-31 13:42:06 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:42:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:42:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:42:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:42:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:42:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:42:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:42:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:42:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/times_slept_couch.php
INFO - 2018-07-31 13:42:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:42:06 --> Final output sent to browser
DEBUG - 2018-07-31 13:42:06 --> Total execution time: 0.0665
INFO - 2018-07-31 13:42:08 --> Config Class Initialized
INFO - 2018-07-31 13:42:08 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:42:08 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:42:08 --> Utf8 Class Initialized
INFO - 2018-07-31 13:42:08 --> URI Class Initialized
INFO - 2018-07-31 13:42:08 --> Router Class Initialized
INFO - 2018-07-31 13:42:08 --> Output Class Initialized
INFO - 2018-07-31 13:42:08 --> Security Class Initialized
DEBUG - 2018-07-31 13:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:42:08 --> CSRF cookie sent
INFO - 2018-07-31 13:42:08 --> Input Class Initialized
INFO - 2018-07-31 13:42:08 --> Language Class Initialized
INFO - 2018-07-31 13:42:08 --> Loader Class Initialized
INFO - 2018-07-31 13:42:08 --> Helper loaded: url_helper
INFO - 2018-07-31 13:42:08 --> Helper loaded: form_helper
INFO - 2018-07-31 13:42:08 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:42:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:42:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:42:08 --> User Agent Class Initialized
INFO - 2018-07-31 13:42:08 --> Controller Class Initialized
INFO - 2018-07-31 13:42:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:42:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:42:08 --> Pixel_Model class loaded
INFO - 2018-07-31 13:42:08 --> Database Driver Class Initialized
INFO - 2018-07-31 13:42:08 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:42:08 --> Database Driver Class Initialized
INFO - 2018-07-31 13:42:08 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:42:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:42:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:42:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:42:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:42:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:42:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:42:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:42:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/has_relationship_outside.php
INFO - 2018-07-31 13:42:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:42:08 --> Final output sent to browser
DEBUG - 2018-07-31 13:42:08 --> Total execution time: 0.0502
INFO - 2018-07-31 13:42:11 --> Config Class Initialized
INFO - 2018-07-31 13:42:11 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:42:11 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:42:11 --> Utf8 Class Initialized
INFO - 2018-07-31 13:42:11 --> URI Class Initialized
INFO - 2018-07-31 13:42:11 --> Router Class Initialized
INFO - 2018-07-31 13:42:11 --> Output Class Initialized
INFO - 2018-07-31 13:42:11 --> Security Class Initialized
DEBUG - 2018-07-31 13:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:42:11 --> CSRF cookie sent
INFO - 2018-07-31 13:42:11 --> Input Class Initialized
INFO - 2018-07-31 13:42:11 --> Language Class Initialized
INFO - 2018-07-31 13:42:11 --> Loader Class Initialized
INFO - 2018-07-31 13:42:11 --> Helper loaded: url_helper
INFO - 2018-07-31 13:42:11 --> Helper loaded: form_helper
INFO - 2018-07-31 13:42:11 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:42:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:42:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:42:11 --> User Agent Class Initialized
INFO - 2018-07-31 13:42:11 --> Controller Class Initialized
INFO - 2018-07-31 13:42:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:42:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:42:11 --> Pixel_Model class loaded
INFO - 2018-07-31 13:42:11 --> Database Driver Class Initialized
INFO - 2018-07-31 13:42:11 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:42:11 --> Database Driver Class Initialized
INFO - 2018-07-31 13:42:11 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:42:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:42:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:42:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:42:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:42:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:42:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:42:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:42:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/liens_on_house.php
INFO - 2018-07-31 13:42:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:42:11 --> Final output sent to browser
DEBUG - 2018-07-31 13:42:11 --> Total execution time: 0.0507
INFO - 2018-07-31 13:42:29 --> Config Class Initialized
INFO - 2018-07-31 13:42:29 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:42:29 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:42:29 --> Utf8 Class Initialized
INFO - 2018-07-31 13:42:29 --> URI Class Initialized
INFO - 2018-07-31 13:42:29 --> Router Class Initialized
INFO - 2018-07-31 13:42:29 --> Output Class Initialized
INFO - 2018-07-31 13:42:29 --> Security Class Initialized
DEBUG - 2018-07-31 13:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:42:29 --> CSRF cookie sent
INFO - 2018-07-31 13:42:29 --> CSRF token verified
INFO - 2018-07-31 13:42:29 --> Input Class Initialized
INFO - 2018-07-31 13:42:29 --> Language Class Initialized
INFO - 2018-07-31 13:42:29 --> Loader Class Initialized
INFO - 2018-07-31 13:42:29 --> Helper loaded: url_helper
INFO - 2018-07-31 13:42:29 --> Helper loaded: form_helper
INFO - 2018-07-31 13:42:29 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:42:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:42:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:42:29 --> User Agent Class Initialized
INFO - 2018-07-31 13:42:29 --> Controller Class Initialized
INFO - 2018-07-31 13:42:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:42:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:42:29 --> Pixel_Model class loaded
INFO - 2018-07-31 13:42:29 --> Database Driver Class Initialized
INFO - 2018-07-31 13:42:29 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:42:29 --> Database Driver Class Initialized
INFO - 2018-07-31 13:42:29 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:42:29 --> Config Class Initialized
INFO - 2018-07-31 13:42:29 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:42:29 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:42:29 --> Utf8 Class Initialized
INFO - 2018-07-31 13:42:29 --> URI Class Initialized
INFO - 2018-07-31 13:42:29 --> Router Class Initialized
INFO - 2018-07-31 13:42:29 --> Output Class Initialized
INFO - 2018-07-31 13:42:29 --> Security Class Initialized
DEBUG - 2018-07-31 13:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:42:29 --> CSRF cookie sent
INFO - 2018-07-31 13:42:29 --> Input Class Initialized
INFO - 2018-07-31 13:42:29 --> Language Class Initialized
INFO - 2018-07-31 13:42:29 --> Loader Class Initialized
INFO - 2018-07-31 13:42:29 --> Helper loaded: url_helper
INFO - 2018-07-31 13:42:29 --> Helper loaded: form_helper
INFO - 2018-07-31 13:42:29 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:42:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:42:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:42:29 --> User Agent Class Initialized
INFO - 2018-07-31 13:42:29 --> Controller Class Initialized
INFO - 2018-07-31 13:42:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:42:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:42:29 --> Pixel_Model class loaded
INFO - 2018-07-31 13:42:29 --> Database Driver Class Initialized
INFO - 2018-07-31 13:42:29 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:42:29 --> Database Driver Class Initialized
INFO - 2018-07-31 13:42:29 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:42:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:42:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:42:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:42:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:42:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:42:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:42:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-07-31 13:42:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:42:29 --> Final output sent to browser
DEBUG - 2018-07-31 13:42:29 --> Total execution time: 0.0446
INFO - 2018-07-31 13:42:43 --> Config Class Initialized
INFO - 2018-07-31 13:42:43 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:42:43 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:42:43 --> Utf8 Class Initialized
INFO - 2018-07-31 13:42:43 --> URI Class Initialized
INFO - 2018-07-31 13:42:43 --> Router Class Initialized
INFO - 2018-07-31 13:42:43 --> Output Class Initialized
INFO - 2018-07-31 13:42:43 --> Security Class Initialized
DEBUG - 2018-07-31 13:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:42:43 --> CSRF cookie sent
INFO - 2018-07-31 13:42:43 --> Input Class Initialized
INFO - 2018-07-31 13:42:43 --> Language Class Initialized
INFO - 2018-07-31 13:42:43 --> Loader Class Initialized
INFO - 2018-07-31 13:42:43 --> Helper loaded: url_helper
INFO - 2018-07-31 13:42:43 --> Helper loaded: form_helper
INFO - 2018-07-31 13:42:43 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:42:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:42:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:42:43 --> User Agent Class Initialized
INFO - 2018-07-31 13:42:43 --> Controller Class Initialized
INFO - 2018-07-31 13:42:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:42:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:42:43 --> Pixel_Model class loaded
INFO - 2018-07-31 13:42:43 --> Database Driver Class Initialized
INFO - 2018-07-31 13:42:43 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:42:43 --> Database Driver Class Initialized
INFO - 2018-07-31 13:42:43 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:42:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:42:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:42:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:42:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:42:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:42:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:42:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:42:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/has_relationship_outside.php
INFO - 2018-07-31 13:42:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:42:43 --> Final output sent to browser
DEBUG - 2018-07-31 13:42:43 --> Total execution time: 0.0545
INFO - 2018-07-31 13:42:45 --> Config Class Initialized
INFO - 2018-07-31 13:42:45 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:42:45 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:42:45 --> Utf8 Class Initialized
INFO - 2018-07-31 13:42:45 --> URI Class Initialized
INFO - 2018-07-31 13:42:45 --> Router Class Initialized
INFO - 2018-07-31 13:42:45 --> Output Class Initialized
INFO - 2018-07-31 13:42:45 --> Security Class Initialized
DEBUG - 2018-07-31 13:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:42:45 --> CSRF cookie sent
INFO - 2018-07-31 13:42:45 --> Input Class Initialized
INFO - 2018-07-31 13:42:45 --> Language Class Initialized
INFO - 2018-07-31 13:42:45 --> Loader Class Initialized
INFO - 2018-07-31 13:42:45 --> Helper loaded: url_helper
INFO - 2018-07-31 13:42:45 --> Helper loaded: form_helper
INFO - 2018-07-31 13:42:45 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:42:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:42:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:42:45 --> User Agent Class Initialized
INFO - 2018-07-31 13:42:45 --> Controller Class Initialized
INFO - 2018-07-31 13:42:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:42:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:42:45 --> Pixel_Model class loaded
INFO - 2018-07-31 13:42:45 --> Database Driver Class Initialized
INFO - 2018-07-31 13:42:45 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:42:45 --> Database Driver Class Initialized
INFO - 2018-07-31 13:42:45 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:42:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:42:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:42:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:42:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:42:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:42:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:42:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:42:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/times_slept_couch.php
INFO - 2018-07-31 13:42:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:42:45 --> Final output sent to browser
DEBUG - 2018-07-31 13:42:45 --> Total execution time: 0.0577
INFO - 2018-07-31 13:42:46 --> Config Class Initialized
INFO - 2018-07-31 13:42:46 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:42:46 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:42:46 --> Utf8 Class Initialized
INFO - 2018-07-31 13:42:46 --> URI Class Initialized
INFO - 2018-07-31 13:42:46 --> Router Class Initialized
INFO - 2018-07-31 13:42:46 --> Output Class Initialized
INFO - 2018-07-31 13:42:46 --> Security Class Initialized
DEBUG - 2018-07-31 13:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:42:46 --> CSRF cookie sent
INFO - 2018-07-31 13:42:46 --> Input Class Initialized
INFO - 2018-07-31 13:42:46 --> Language Class Initialized
INFO - 2018-07-31 13:42:46 --> Loader Class Initialized
INFO - 2018-07-31 13:42:46 --> Helper loaded: url_helper
INFO - 2018-07-31 13:42:46 --> Helper loaded: form_helper
INFO - 2018-07-31 13:42:46 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:42:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:42:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:42:46 --> User Agent Class Initialized
INFO - 2018-07-31 13:42:46 --> Controller Class Initialized
INFO - 2018-07-31 13:42:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:42:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:42:46 --> Pixel_Model class loaded
INFO - 2018-07-31 13:42:46 --> Database Driver Class Initialized
INFO - 2018-07-31 13:42:46 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:42:46 --> Database Driver Class Initialized
INFO - 2018-07-31 13:42:46 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:42:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:42:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:42:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:42:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:42:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:42:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:42:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:42:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/has_dating_profile.php
INFO - 2018-07-31 13:42:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:42:46 --> Final output sent to browser
DEBUG - 2018-07-31 13:42:46 --> Total execution time: 0.0476
INFO - 2018-07-31 13:42:47 --> Config Class Initialized
INFO - 2018-07-31 13:42:47 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:42:47 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:42:47 --> Utf8 Class Initialized
INFO - 2018-07-31 13:42:47 --> URI Class Initialized
INFO - 2018-07-31 13:42:47 --> Router Class Initialized
INFO - 2018-07-31 13:42:47 --> Output Class Initialized
INFO - 2018-07-31 13:42:47 --> Security Class Initialized
DEBUG - 2018-07-31 13:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:42:47 --> CSRF cookie sent
INFO - 2018-07-31 13:42:47 --> Input Class Initialized
INFO - 2018-07-31 13:42:47 --> Language Class Initialized
INFO - 2018-07-31 13:42:47 --> Loader Class Initialized
INFO - 2018-07-31 13:42:47 --> Helper loaded: url_helper
INFO - 2018-07-31 13:42:47 --> Helper loaded: form_helper
INFO - 2018-07-31 13:42:47 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:42:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:42:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:42:47 --> User Agent Class Initialized
INFO - 2018-07-31 13:42:47 --> Controller Class Initialized
INFO - 2018-07-31 13:42:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:42:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:42:47 --> Pixel_Model class loaded
INFO - 2018-07-31 13:42:47 --> Database Driver Class Initialized
INFO - 2018-07-31 13:42:47 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:42:47 --> Database Driver Class Initialized
INFO - 2018-07-31 13:42:47 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:42:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:42:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:42:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:42:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:42:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:42:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:42:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:42:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pet_abuse.php
INFO - 2018-07-31 13:42:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:42:47 --> Final output sent to browser
DEBUG - 2018-07-31 13:42:47 --> Total execution time: 0.0437
INFO - 2018-07-31 13:42:48 --> Config Class Initialized
INFO - 2018-07-31 13:42:48 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:42:48 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:42:48 --> Utf8 Class Initialized
INFO - 2018-07-31 13:42:48 --> URI Class Initialized
INFO - 2018-07-31 13:42:48 --> Router Class Initialized
INFO - 2018-07-31 13:42:48 --> Output Class Initialized
INFO - 2018-07-31 13:42:48 --> Security Class Initialized
DEBUG - 2018-07-31 13:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:42:48 --> CSRF cookie sent
INFO - 2018-07-31 13:42:48 --> Input Class Initialized
INFO - 2018-07-31 13:42:48 --> Language Class Initialized
INFO - 2018-07-31 13:42:48 --> Loader Class Initialized
INFO - 2018-07-31 13:42:48 --> Helper loaded: url_helper
INFO - 2018-07-31 13:42:48 --> Helper loaded: form_helper
INFO - 2018-07-31 13:42:48 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:42:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:42:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:42:48 --> User Agent Class Initialized
INFO - 2018-07-31 13:42:48 --> Controller Class Initialized
INFO - 2018-07-31 13:42:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:42:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:42:48 --> Pixel_Model class loaded
INFO - 2018-07-31 13:42:48 --> Database Driver Class Initialized
INFO - 2018-07-31 13:42:48 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:42:48 --> Database Driver Class Initialized
INFO - 2018-07-31 13:42:48 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:42:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:42:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:42:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:42:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:42:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:42:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:42:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:42:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/withheld_sex.php
INFO - 2018-07-31 13:42:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:42:48 --> Final output sent to browser
DEBUG - 2018-07-31 13:42:48 --> Total execution time: 0.0444
INFO - 2018-07-31 13:42:48 --> Config Class Initialized
INFO - 2018-07-31 13:42:48 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:42:48 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:42:48 --> Utf8 Class Initialized
INFO - 2018-07-31 13:42:48 --> URI Class Initialized
INFO - 2018-07-31 13:42:48 --> Router Class Initialized
INFO - 2018-07-31 13:42:48 --> Output Class Initialized
INFO - 2018-07-31 13:42:48 --> Security Class Initialized
DEBUG - 2018-07-31 13:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:42:48 --> CSRF cookie sent
INFO - 2018-07-31 13:42:48 --> Input Class Initialized
INFO - 2018-07-31 13:42:48 --> Language Class Initialized
INFO - 2018-07-31 13:42:48 --> Loader Class Initialized
INFO - 2018-07-31 13:42:48 --> Helper loaded: url_helper
INFO - 2018-07-31 13:42:48 --> Helper loaded: form_helper
INFO - 2018-07-31 13:42:48 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:42:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:42:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:42:48 --> User Agent Class Initialized
INFO - 2018-07-31 13:42:48 --> Controller Class Initialized
INFO - 2018-07-31 13:42:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:42:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:42:48 --> Pixel_Model class loaded
INFO - 2018-07-31 13:42:48 --> Database Driver Class Initialized
INFO - 2018-07-31 13:42:48 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:42:48 --> Database Driver Class Initialized
INFO - 2018-07-31 13:42:48 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:42:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:42:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:42:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:42:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:42:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:42:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:42:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:42:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/has_hit_kids.php
INFO - 2018-07-31 13:42:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:42:48 --> Final output sent to browser
DEBUG - 2018-07-31 13:42:48 --> Total execution time: 0.0628
INFO - 2018-07-31 13:42:49 --> Config Class Initialized
INFO - 2018-07-31 13:42:49 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:42:49 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:42:49 --> Utf8 Class Initialized
INFO - 2018-07-31 13:42:49 --> URI Class Initialized
INFO - 2018-07-31 13:42:49 --> Router Class Initialized
INFO - 2018-07-31 13:42:49 --> Output Class Initialized
INFO - 2018-07-31 13:42:49 --> Security Class Initialized
DEBUG - 2018-07-31 13:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:42:49 --> CSRF cookie sent
INFO - 2018-07-31 13:42:49 --> Input Class Initialized
INFO - 2018-07-31 13:42:49 --> Language Class Initialized
INFO - 2018-07-31 13:42:49 --> Loader Class Initialized
INFO - 2018-07-31 13:42:49 --> Helper loaded: url_helper
INFO - 2018-07-31 13:42:49 --> Helper loaded: form_helper
INFO - 2018-07-31 13:42:49 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:42:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:42:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:42:49 --> User Agent Class Initialized
INFO - 2018-07-31 13:42:49 --> Controller Class Initialized
INFO - 2018-07-31 13:42:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:42:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:42:49 --> Pixel_Model class loaded
INFO - 2018-07-31 13:42:49 --> Database Driver Class Initialized
INFO - 2018-07-31 13:42:49 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:42:49 --> Database Driver Class Initialized
INFO - 2018-07-31 13:42:49 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:42:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:42:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:42:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:42:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:42:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:42:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:42:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:42:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial_control.php
INFO - 2018-07-31 13:42:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:42:49 --> Final output sent to browser
DEBUG - 2018-07-31 13:42:49 --> Total execution time: 0.0528
INFO - 2018-07-31 13:42:49 --> Config Class Initialized
INFO - 2018-07-31 13:42:49 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:42:49 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:42:49 --> Utf8 Class Initialized
INFO - 2018-07-31 13:42:49 --> URI Class Initialized
INFO - 2018-07-31 13:42:49 --> Router Class Initialized
INFO - 2018-07-31 13:42:49 --> Output Class Initialized
INFO - 2018-07-31 13:42:49 --> Security Class Initialized
DEBUG - 2018-07-31 13:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:42:49 --> CSRF cookie sent
INFO - 2018-07-31 13:42:49 --> Input Class Initialized
INFO - 2018-07-31 13:42:49 --> Language Class Initialized
INFO - 2018-07-31 13:42:49 --> Loader Class Initialized
INFO - 2018-07-31 13:42:49 --> Helper loaded: url_helper
INFO - 2018-07-31 13:42:49 --> Helper loaded: form_helper
INFO - 2018-07-31 13:42:49 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:42:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:42:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:42:49 --> User Agent Class Initialized
INFO - 2018-07-31 13:42:49 --> Controller Class Initialized
INFO - 2018-07-31 13:42:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:42:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:42:49 --> Pixel_Model class loaded
INFO - 2018-07-31 13:42:49 --> Database Driver Class Initialized
INFO - 2018-07-31 13:42:49 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:42:49 --> Database Driver Class Initialized
INFO - 2018-07-31 13:42:49 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:42:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:42:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:42:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:42:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:42:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:42:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:42:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:42:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/have_hit_s.php
INFO - 2018-07-31 13:42:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:42:49 --> Final output sent to browser
DEBUG - 2018-07-31 13:42:49 --> Total execution time: 0.0471
INFO - 2018-07-31 13:42:51 --> Config Class Initialized
INFO - 2018-07-31 13:42:51 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:42:51 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:42:51 --> Utf8 Class Initialized
INFO - 2018-07-31 13:42:51 --> URI Class Initialized
INFO - 2018-07-31 13:42:51 --> Router Class Initialized
INFO - 2018-07-31 13:42:51 --> Output Class Initialized
INFO - 2018-07-31 13:42:51 --> Security Class Initialized
DEBUG - 2018-07-31 13:42:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:42:51 --> CSRF cookie sent
INFO - 2018-07-31 13:42:51 --> Input Class Initialized
INFO - 2018-07-31 13:42:51 --> Language Class Initialized
INFO - 2018-07-31 13:42:51 --> Loader Class Initialized
INFO - 2018-07-31 13:42:51 --> Helper loaded: url_helper
INFO - 2018-07-31 13:42:51 --> Helper loaded: form_helper
INFO - 2018-07-31 13:42:51 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:42:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:42:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:42:51 --> User Agent Class Initialized
INFO - 2018-07-31 13:42:51 --> Controller Class Initialized
INFO - 2018-07-31 13:42:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:42:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:42:51 --> Pixel_Model class loaded
INFO - 2018-07-31 13:42:51 --> Database Driver Class Initialized
INFO - 2018-07-31 13:42:51 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:42:51 --> Database Driver Class Initialized
INFO - 2018-07-31 13:42:51 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:42:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:42:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:42:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:42:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:42:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:42:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:42:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:42:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/has_addiction_problem.php
INFO - 2018-07-31 13:42:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:42:51 --> Final output sent to browser
DEBUG - 2018-07-31 13:42:51 --> Total execution time: 0.0491
INFO - 2018-07-31 13:42:52 --> Config Class Initialized
INFO - 2018-07-31 13:42:52 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:42:52 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:42:52 --> Utf8 Class Initialized
INFO - 2018-07-31 13:42:52 --> URI Class Initialized
INFO - 2018-07-31 13:42:52 --> Router Class Initialized
INFO - 2018-07-31 13:42:52 --> Output Class Initialized
INFO - 2018-07-31 13:42:52 --> Security Class Initialized
DEBUG - 2018-07-31 13:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:42:52 --> CSRF cookie sent
INFO - 2018-07-31 13:42:52 --> Input Class Initialized
INFO - 2018-07-31 13:42:52 --> Language Class Initialized
INFO - 2018-07-31 13:42:52 --> Loader Class Initialized
INFO - 2018-07-31 13:42:52 --> Helper loaded: url_helper
INFO - 2018-07-31 13:42:52 --> Helper loaded: form_helper
INFO - 2018-07-31 13:42:52 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:42:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:42:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:42:52 --> User Agent Class Initialized
INFO - 2018-07-31 13:42:52 --> Controller Class Initialized
INFO - 2018-07-31 13:42:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:42:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:42:52 --> Pixel_Model class loaded
INFO - 2018-07-31 13:42:52 --> Database Driver Class Initialized
INFO - 2018-07-31 13:42:52 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:42:52 --> Database Driver Class Initialized
INFO - 2018-07-31 13:42:52 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:42:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:42:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:42:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:42:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:42:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:42:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:42:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:42:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/have_drugs.php
INFO - 2018-07-31 13:42:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:42:52 --> Final output sent to browser
DEBUG - 2018-07-31 13:42:52 --> Total execution time: 0.0453
INFO - 2018-07-31 13:42:53 --> Config Class Initialized
INFO - 2018-07-31 13:42:53 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:42:53 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:42:53 --> Utf8 Class Initialized
INFO - 2018-07-31 13:42:53 --> URI Class Initialized
INFO - 2018-07-31 13:42:53 --> Router Class Initialized
INFO - 2018-07-31 13:42:53 --> Output Class Initialized
INFO - 2018-07-31 13:42:53 --> Security Class Initialized
DEBUG - 2018-07-31 13:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:42:53 --> CSRF cookie sent
INFO - 2018-07-31 13:42:53 --> Input Class Initialized
INFO - 2018-07-31 13:42:53 --> Language Class Initialized
INFO - 2018-07-31 13:42:53 --> Loader Class Initialized
INFO - 2018-07-31 13:42:53 --> Helper loaded: url_helper
INFO - 2018-07-31 13:42:53 --> Helper loaded: form_helper
INFO - 2018-07-31 13:42:53 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:42:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:42:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:42:53 --> User Agent Class Initialized
INFO - 2018-07-31 13:42:53 --> Controller Class Initialized
INFO - 2018-07-31 13:42:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:42:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:42:53 --> Pixel_Model class loaded
INFO - 2018-07-31 13:42:53 --> Database Driver Class Initialized
INFO - 2018-07-31 13:42:53 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:42:53 --> Database Driver Class Initialized
INFO - 2018-07-31 13:42:53 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:42:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:42:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:42:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:42:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:42:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:42:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:42:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:42:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/alcoholic_drinks_per_week.php
INFO - 2018-07-31 13:42:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:42:53 --> Final output sent to browser
DEBUG - 2018-07-31 13:42:53 --> Total execution time: 0.0358
INFO - 2018-07-31 13:42:53 --> Config Class Initialized
INFO - 2018-07-31 13:42:53 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:42:53 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:42:53 --> Utf8 Class Initialized
INFO - 2018-07-31 13:42:53 --> URI Class Initialized
INFO - 2018-07-31 13:42:53 --> Router Class Initialized
INFO - 2018-07-31 13:42:53 --> Output Class Initialized
INFO - 2018-07-31 13:42:53 --> Security Class Initialized
DEBUG - 2018-07-31 13:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:42:53 --> CSRF cookie sent
INFO - 2018-07-31 13:42:53 --> CSRF token verified
INFO - 2018-07-31 13:42:53 --> Input Class Initialized
INFO - 2018-07-31 13:42:53 --> Language Class Initialized
INFO - 2018-07-31 13:42:53 --> Loader Class Initialized
INFO - 2018-07-31 13:42:53 --> Helper loaded: url_helper
INFO - 2018-07-31 13:42:53 --> Helper loaded: form_helper
INFO - 2018-07-31 13:42:53 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:42:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:42:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:42:53 --> User Agent Class Initialized
INFO - 2018-07-31 13:42:53 --> Controller Class Initialized
INFO - 2018-07-31 13:42:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:42:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:42:53 --> Pixel_Model class loaded
INFO - 2018-07-31 13:42:53 --> Database Driver Class Initialized
INFO - 2018-07-31 13:42:53 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:42:53 --> Form Validation Class Initialized
INFO - 2018-07-31 13:42:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-07-31 13:42:53 --> Database Driver Class Initialized
INFO - 2018-07-31 13:42:53 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:42:53 --> Config Class Initialized
INFO - 2018-07-31 13:42:53 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:42:53 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:42:53 --> Utf8 Class Initialized
INFO - 2018-07-31 13:42:53 --> URI Class Initialized
INFO - 2018-07-31 13:42:53 --> Router Class Initialized
INFO - 2018-07-31 13:42:53 --> Output Class Initialized
INFO - 2018-07-31 13:42:53 --> Security Class Initialized
DEBUG - 2018-07-31 13:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:42:53 --> CSRF cookie sent
INFO - 2018-07-31 13:42:53 --> Input Class Initialized
INFO - 2018-07-31 13:42:53 --> Language Class Initialized
INFO - 2018-07-31 13:42:53 --> Loader Class Initialized
INFO - 2018-07-31 13:42:53 --> Helper loaded: url_helper
INFO - 2018-07-31 13:42:53 --> Helper loaded: form_helper
INFO - 2018-07-31 13:42:53 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:42:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:42:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:42:53 --> User Agent Class Initialized
INFO - 2018-07-31 13:42:53 --> Controller Class Initialized
INFO - 2018-07-31 13:42:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:42:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:42:53 --> Pixel_Model class loaded
INFO - 2018-07-31 13:42:53 --> Database Driver Class Initialized
INFO - 2018-07-31 13:42:53 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:42:53 --> Database Driver Class Initialized
INFO - 2018-07-31 13:42:53 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:42:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:42:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:42:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:42:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:42:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:42:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:42:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-07-31 13:42:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:42:53 --> Final output sent to browser
DEBUG - 2018-07-31 13:42:53 --> Total execution time: 0.0512
INFO - 2018-07-31 13:42:54 --> Config Class Initialized
INFO - 2018-07-31 13:42:54 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:42:54 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:42:54 --> Utf8 Class Initialized
INFO - 2018-07-31 13:42:54 --> URI Class Initialized
INFO - 2018-07-31 13:42:54 --> Router Class Initialized
INFO - 2018-07-31 13:42:54 --> Output Class Initialized
INFO - 2018-07-31 13:42:54 --> Security Class Initialized
DEBUG - 2018-07-31 13:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:42:54 --> CSRF cookie sent
INFO - 2018-07-31 13:42:54 --> Input Class Initialized
INFO - 2018-07-31 13:42:54 --> Language Class Initialized
INFO - 2018-07-31 13:42:54 --> Loader Class Initialized
INFO - 2018-07-31 13:42:54 --> Helper loaded: url_helper
INFO - 2018-07-31 13:42:54 --> Helper loaded: form_helper
INFO - 2018-07-31 13:42:54 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:42:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:42:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:42:54 --> User Agent Class Initialized
INFO - 2018-07-31 13:42:54 --> Controller Class Initialized
INFO - 2018-07-31 13:42:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:42:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:42:54 --> Pixel_Model class loaded
INFO - 2018-07-31 13:42:54 --> Database Driver Class Initialized
INFO - 2018-07-31 13:42:54 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:42:54 --> Database Driver Class Initialized
INFO - 2018-07-31 13:42:54 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:42:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:42:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:42:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:42:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:42:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:42:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:42:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:42:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/s_nights_without_you.php
INFO - 2018-07-31 13:42:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:42:54 --> Final output sent to browser
DEBUG - 2018-07-31 13:42:54 --> Total execution time: 0.0365
INFO - 2018-07-31 13:42:55 --> Config Class Initialized
INFO - 2018-07-31 13:42:55 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:42:55 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:42:55 --> Utf8 Class Initialized
INFO - 2018-07-31 13:42:55 --> URI Class Initialized
INFO - 2018-07-31 13:42:55 --> Router Class Initialized
INFO - 2018-07-31 13:42:55 --> Output Class Initialized
INFO - 2018-07-31 13:42:55 --> Security Class Initialized
DEBUG - 2018-07-31 13:42:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:42:55 --> CSRF cookie sent
INFO - 2018-07-31 13:42:55 --> Input Class Initialized
INFO - 2018-07-31 13:42:55 --> Language Class Initialized
INFO - 2018-07-31 13:42:55 --> Loader Class Initialized
INFO - 2018-07-31 13:42:55 --> Helper loaded: url_helper
INFO - 2018-07-31 13:42:55 --> Helper loaded: form_helper
INFO - 2018-07-31 13:42:55 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:42:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:42:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:42:55 --> User Agent Class Initialized
INFO - 2018-07-31 13:42:55 --> Controller Class Initialized
INFO - 2018-07-31 13:42:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:42:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:42:55 --> Pixel_Model class loaded
INFO - 2018-07-31 13:42:55 --> Database Driver Class Initialized
INFO - 2018-07-31 13:42:55 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:42:55 --> Database Driver Class Initialized
INFO - 2018-07-31 13:42:55 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:42:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:42:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:42:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:42:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:42:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:42:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:42:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:42:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/s_nights_not_home.php
INFO - 2018-07-31 13:42:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:42:55 --> Final output sent to browser
DEBUG - 2018-07-31 13:42:55 --> Total execution time: 0.0455
INFO - 2018-07-31 13:42:56 --> Config Class Initialized
INFO - 2018-07-31 13:42:56 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:42:56 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:42:56 --> Utf8 Class Initialized
INFO - 2018-07-31 13:42:56 --> URI Class Initialized
INFO - 2018-07-31 13:42:56 --> Router Class Initialized
INFO - 2018-07-31 13:42:56 --> Output Class Initialized
INFO - 2018-07-31 13:42:56 --> Security Class Initialized
DEBUG - 2018-07-31 13:42:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:42:56 --> CSRF cookie sent
INFO - 2018-07-31 13:42:56 --> Input Class Initialized
INFO - 2018-07-31 13:42:56 --> Language Class Initialized
INFO - 2018-07-31 13:42:56 --> Loader Class Initialized
INFO - 2018-07-31 13:42:56 --> Helper loaded: url_helper
INFO - 2018-07-31 13:42:56 --> Helper loaded: form_helper
INFO - 2018-07-31 13:42:56 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:42:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:42:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:42:56 --> User Agent Class Initialized
INFO - 2018-07-31 13:42:56 --> Controller Class Initialized
INFO - 2018-07-31 13:42:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:42:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:42:56 --> Pixel_Model class loaded
INFO - 2018-07-31 13:42:56 --> Database Driver Class Initialized
INFO - 2018-07-31 13:42:56 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:42:56 --> Database Driver Class Initialized
INFO - 2018-07-31 13:42:56 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:42:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:42:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:42:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:42:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:42:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:42:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:42:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:42:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/nights_not_home.php
INFO - 2018-07-31 13:42:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:42:56 --> Final output sent to browser
DEBUG - 2018-07-31 13:42:56 --> Total execution time: 0.0637
INFO - 2018-07-31 13:42:56 --> Config Class Initialized
INFO - 2018-07-31 13:42:56 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:42:56 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:42:56 --> Utf8 Class Initialized
INFO - 2018-07-31 13:42:56 --> URI Class Initialized
INFO - 2018-07-31 13:42:56 --> Router Class Initialized
INFO - 2018-07-31 13:42:56 --> Output Class Initialized
INFO - 2018-07-31 13:42:56 --> Security Class Initialized
DEBUG - 2018-07-31 13:42:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:42:56 --> CSRF cookie sent
INFO - 2018-07-31 13:42:56 --> Input Class Initialized
INFO - 2018-07-31 13:42:56 --> Language Class Initialized
INFO - 2018-07-31 13:42:56 --> Loader Class Initialized
INFO - 2018-07-31 13:42:56 --> Helper loaded: url_helper
INFO - 2018-07-31 13:42:56 --> Helper loaded: form_helper
INFO - 2018-07-31 13:42:56 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:42:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:42:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:42:56 --> User Agent Class Initialized
INFO - 2018-07-31 13:42:56 --> Controller Class Initialized
INFO - 2018-07-31 13:42:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:42:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:42:56 --> Pixel_Model class loaded
INFO - 2018-07-31 13:42:56 --> Database Driver Class Initialized
INFO - 2018-07-31 13:42:56 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:42:56 --> Database Driver Class Initialized
INFO - 2018-07-31 13:42:56 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:42:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:42:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:42:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:42:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:42:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:42:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:42:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:42:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/have_date.php
INFO - 2018-07-31 13:42:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:42:56 --> Final output sent to browser
DEBUG - 2018-07-31 13:42:56 --> Total execution time: 0.0574
INFO - 2018-07-31 13:42:57 --> Config Class Initialized
INFO - 2018-07-31 13:42:57 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:42:57 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:42:57 --> Utf8 Class Initialized
INFO - 2018-07-31 13:42:57 --> URI Class Initialized
INFO - 2018-07-31 13:42:57 --> Router Class Initialized
INFO - 2018-07-31 13:42:57 --> Output Class Initialized
INFO - 2018-07-31 13:42:57 --> Security Class Initialized
DEBUG - 2018-07-31 13:42:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:42:57 --> CSRF cookie sent
INFO - 2018-07-31 13:42:57 --> Input Class Initialized
INFO - 2018-07-31 13:42:57 --> Language Class Initialized
INFO - 2018-07-31 13:42:57 --> Loader Class Initialized
INFO - 2018-07-31 13:42:57 --> Helper loaded: url_helper
INFO - 2018-07-31 13:42:57 --> Helper loaded: form_helper
INFO - 2018-07-31 13:42:57 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:42:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:42:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:42:57 --> User Agent Class Initialized
INFO - 2018-07-31 13:42:57 --> Controller Class Initialized
INFO - 2018-07-31 13:42:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:42:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:42:57 --> Pixel_Model class loaded
INFO - 2018-07-31 13:42:57 --> Database Driver Class Initialized
INFO - 2018-07-31 13:42:57 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:42:57 --> Database Driver Class Initialized
INFO - 2018-07-31 13:42:57 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:42:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:42:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:42:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:42:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:42:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:42:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:42:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:42:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/night_without_s.php
INFO - 2018-07-31 13:42:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:42:57 --> Final output sent to browser
DEBUG - 2018-07-31 13:42:57 --> Total execution time: 0.0469
INFO - 2018-07-31 13:42:58 --> Config Class Initialized
INFO - 2018-07-31 13:42:58 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:42:58 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:42:58 --> Utf8 Class Initialized
INFO - 2018-07-31 13:42:58 --> URI Class Initialized
INFO - 2018-07-31 13:42:58 --> Router Class Initialized
INFO - 2018-07-31 13:42:58 --> Output Class Initialized
INFO - 2018-07-31 13:42:58 --> Security Class Initialized
DEBUG - 2018-07-31 13:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:42:58 --> CSRF cookie sent
INFO - 2018-07-31 13:42:58 --> Input Class Initialized
INFO - 2018-07-31 13:42:58 --> Language Class Initialized
INFO - 2018-07-31 13:42:58 --> Loader Class Initialized
INFO - 2018-07-31 13:42:58 --> Helper loaded: url_helper
INFO - 2018-07-31 13:42:58 --> Helper loaded: form_helper
INFO - 2018-07-31 13:42:58 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:42:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:42:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:42:58 --> User Agent Class Initialized
INFO - 2018-07-31 13:42:58 --> Controller Class Initialized
INFO - 2018-07-31 13:42:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:42:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:42:58 --> Pixel_Model class loaded
INFO - 2018-07-31 13:42:58 --> Database Driver Class Initialized
INFO - 2018-07-31 13:42:58 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:42:58 --> Database Driver Class Initialized
INFO - 2018-07-31 13:42:58 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:42:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:42:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:42:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:42:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:42:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:42:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:42:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:42:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/shift_work.php
INFO - 2018-07-31 13:42:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:42:58 --> Final output sent to browser
DEBUG - 2018-07-31 13:42:58 --> Total execution time: 0.0451
INFO - 2018-07-31 13:42:58 --> Config Class Initialized
INFO - 2018-07-31 13:42:58 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:42:58 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:42:58 --> Utf8 Class Initialized
INFO - 2018-07-31 13:42:58 --> URI Class Initialized
INFO - 2018-07-31 13:42:58 --> Router Class Initialized
INFO - 2018-07-31 13:42:58 --> Output Class Initialized
INFO - 2018-07-31 13:42:58 --> Security Class Initialized
DEBUG - 2018-07-31 13:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:42:58 --> CSRF cookie sent
INFO - 2018-07-31 13:42:58 --> Input Class Initialized
INFO - 2018-07-31 13:42:58 --> Language Class Initialized
INFO - 2018-07-31 13:42:58 --> Loader Class Initialized
INFO - 2018-07-31 13:42:58 --> Helper loaded: url_helper
INFO - 2018-07-31 13:42:58 --> Helper loaded: form_helper
INFO - 2018-07-31 13:42:58 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:42:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:42:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:42:58 --> User Agent Class Initialized
INFO - 2018-07-31 13:42:58 --> Controller Class Initialized
INFO - 2018-07-31 13:42:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:42:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:42:58 --> Pixel_Model class loaded
INFO - 2018-07-31 13:42:58 --> Database Driver Class Initialized
INFO - 2018-07-31 13:42:58 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:42:58 --> Database Driver Class Initialized
INFO - 2018-07-31 13:42:58 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:42:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:42:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:42:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:42:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:42:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:42:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:42:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:42:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inherited_income.php
INFO - 2018-07-31 13:42:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:42:58 --> Final output sent to browser
DEBUG - 2018-07-31 13:42:58 --> Total execution time: 0.0543
INFO - 2018-07-31 13:43:00 --> Config Class Initialized
INFO - 2018-07-31 13:43:00 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:43:00 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:43:00 --> Utf8 Class Initialized
INFO - 2018-07-31 13:43:00 --> URI Class Initialized
INFO - 2018-07-31 13:43:00 --> Router Class Initialized
INFO - 2018-07-31 13:43:00 --> Output Class Initialized
INFO - 2018-07-31 13:43:00 --> Security Class Initialized
DEBUG - 2018-07-31 13:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:43:00 --> CSRF cookie sent
INFO - 2018-07-31 13:43:00 --> Input Class Initialized
INFO - 2018-07-31 13:43:00 --> Language Class Initialized
INFO - 2018-07-31 13:43:00 --> Loader Class Initialized
INFO - 2018-07-31 13:43:00 --> Helper loaded: url_helper
INFO - 2018-07-31 13:43:00 --> Helper loaded: form_helper
INFO - 2018-07-31 13:43:00 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:43:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:43:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:43:00 --> User Agent Class Initialized
INFO - 2018-07-31 13:43:00 --> Controller Class Initialized
INFO - 2018-07-31 13:43:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:43:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:43:00 --> Pixel_Model class loaded
INFO - 2018-07-31 13:43:00 --> Database Driver Class Initialized
INFO - 2018-07-31 13:43:00 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:43:00 --> Database Driver Class Initialized
INFO - 2018-07-31 13:43:00 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:43:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:43:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:43:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:43:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:43:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:43:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:43:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:43:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/trust_info.php
INFO - 2018-07-31 13:43:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:43:00 --> Final output sent to browser
DEBUG - 2018-07-31 13:43:00 --> Total execution time: 0.0443
INFO - 2018-07-31 13:43:01 --> Config Class Initialized
INFO - 2018-07-31 13:43:01 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:43:01 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:43:01 --> Utf8 Class Initialized
INFO - 2018-07-31 13:43:01 --> URI Class Initialized
INFO - 2018-07-31 13:43:01 --> Router Class Initialized
INFO - 2018-07-31 13:43:01 --> Output Class Initialized
INFO - 2018-07-31 13:43:01 --> Security Class Initialized
DEBUG - 2018-07-31 13:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:43:01 --> CSRF cookie sent
INFO - 2018-07-31 13:43:01 --> Input Class Initialized
INFO - 2018-07-31 13:43:01 --> Language Class Initialized
INFO - 2018-07-31 13:43:01 --> Loader Class Initialized
INFO - 2018-07-31 13:43:01 --> Helper loaded: url_helper
INFO - 2018-07-31 13:43:01 --> Helper loaded: form_helper
INFO - 2018-07-31 13:43:01 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:43:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:43:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:43:01 --> User Agent Class Initialized
INFO - 2018-07-31 13:43:01 --> Controller Class Initialized
INFO - 2018-07-31 13:43:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:43:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:43:01 --> Pixel_Model class loaded
INFO - 2018-07-31 13:43:01 --> Database Driver Class Initialized
INFO - 2018-07-31 13:43:01 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:43:01 --> Database Driver Class Initialized
INFO - 2018-07-31 13:43:01 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:43:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:43:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:43:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:43:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:43:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:43:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:43:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:43:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/business_tax_info.php
INFO - 2018-07-31 13:43:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:43:01 --> Final output sent to browser
DEBUG - 2018-07-31 13:43:01 --> Total execution time: 0.0434
INFO - 2018-07-31 13:43:02 --> Config Class Initialized
INFO - 2018-07-31 13:43:02 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:43:02 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:43:02 --> Utf8 Class Initialized
INFO - 2018-07-31 13:43:02 --> URI Class Initialized
INFO - 2018-07-31 13:43:02 --> Router Class Initialized
INFO - 2018-07-31 13:43:02 --> Output Class Initialized
INFO - 2018-07-31 13:43:02 --> Security Class Initialized
DEBUG - 2018-07-31 13:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:43:02 --> CSRF cookie sent
INFO - 2018-07-31 13:43:02 --> Input Class Initialized
INFO - 2018-07-31 13:43:02 --> Language Class Initialized
INFO - 2018-07-31 13:43:02 --> Loader Class Initialized
INFO - 2018-07-31 13:43:02 --> Helper loaded: url_helper
INFO - 2018-07-31 13:43:02 --> Helper loaded: form_helper
INFO - 2018-07-31 13:43:02 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:43:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:43:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:43:02 --> User Agent Class Initialized
INFO - 2018-07-31 13:43:02 --> Controller Class Initialized
INFO - 2018-07-31 13:43:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:43:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:43:02 --> Pixel_Model class loaded
INFO - 2018-07-31 13:43:02 --> Database Driver Class Initialized
INFO - 2018-07-31 13:43:02 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:43:02 --> Database Driver Class Initialized
INFO - 2018-07-31 13:43:02 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:43:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:43:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:43:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:43:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:43:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:43:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:43:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:43:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/affectionate_salutation.php
INFO - 2018-07-31 13:43:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:43:02 --> Final output sent to browser
DEBUG - 2018-07-31 13:43:02 --> Total execution time: 0.0442
INFO - 2018-07-31 13:43:04 --> Config Class Initialized
INFO - 2018-07-31 13:43:04 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:43:04 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:43:04 --> Utf8 Class Initialized
INFO - 2018-07-31 13:43:04 --> URI Class Initialized
INFO - 2018-07-31 13:43:04 --> Router Class Initialized
INFO - 2018-07-31 13:43:04 --> Output Class Initialized
INFO - 2018-07-31 13:43:04 --> Security Class Initialized
DEBUG - 2018-07-31 13:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:43:04 --> CSRF cookie sent
INFO - 2018-07-31 13:43:04 --> Input Class Initialized
INFO - 2018-07-31 13:43:04 --> Language Class Initialized
INFO - 2018-07-31 13:43:04 --> Loader Class Initialized
INFO - 2018-07-31 13:43:04 --> Helper loaded: url_helper
INFO - 2018-07-31 13:43:04 --> Helper loaded: form_helper
INFO - 2018-07-31 13:43:04 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:43:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:43:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:43:04 --> User Agent Class Initialized
INFO - 2018-07-31 13:43:04 --> Controller Class Initialized
INFO - 2018-07-31 13:43:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:43:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:43:04 --> Pixel_Model class loaded
INFO - 2018-07-31 13:43:04 --> Database Driver Class Initialized
INFO - 2018-07-31 13:43:04 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:43:04 --> Database Driver Class Initialized
INFO - 2018-07-31 13:43:04 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:43:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:43:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:43:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:43:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:43:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:43:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:43:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:43:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/spouse_job.php
INFO - 2018-07-31 13:43:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:43:04 --> Final output sent to browser
DEBUG - 2018-07-31 13:43:04 --> Total execution time: 0.0439
INFO - 2018-07-31 13:43:05 --> Config Class Initialized
INFO - 2018-07-31 13:43:05 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:43:05 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:43:05 --> Utf8 Class Initialized
INFO - 2018-07-31 13:43:05 --> URI Class Initialized
INFO - 2018-07-31 13:43:05 --> Router Class Initialized
INFO - 2018-07-31 13:43:05 --> Output Class Initialized
INFO - 2018-07-31 13:43:05 --> Security Class Initialized
DEBUG - 2018-07-31 13:43:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:43:05 --> CSRF cookie sent
INFO - 2018-07-31 13:43:05 --> Input Class Initialized
INFO - 2018-07-31 13:43:05 --> Language Class Initialized
INFO - 2018-07-31 13:43:05 --> Loader Class Initialized
INFO - 2018-07-31 13:43:05 --> Helper loaded: url_helper
INFO - 2018-07-31 13:43:05 --> Helper loaded: form_helper
INFO - 2018-07-31 13:43:05 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:43:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:43:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:43:05 --> User Agent Class Initialized
INFO - 2018-07-31 13:43:05 --> Controller Class Initialized
INFO - 2018-07-31 13:43:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:43:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:43:05 --> Pixel_Model class loaded
INFO - 2018-07-31 13:43:05 --> Database Driver Class Initialized
INFO - 2018-07-31 13:43:05 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:43:05 --> Database Driver Class Initialized
INFO - 2018-07-31 13:43:05 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:43:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:43:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:43:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:43:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:43:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:43:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:43:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:43:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/spouse_info.php
INFO - 2018-07-31 13:43:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:43:05 --> Final output sent to browser
DEBUG - 2018-07-31 13:43:05 --> Total execution time: 0.0523
INFO - 2018-07-31 13:43:06 --> Config Class Initialized
INFO - 2018-07-31 13:43:06 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:43:06 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:43:06 --> Utf8 Class Initialized
INFO - 2018-07-31 13:43:06 --> URI Class Initialized
INFO - 2018-07-31 13:43:06 --> Router Class Initialized
INFO - 2018-07-31 13:43:06 --> Output Class Initialized
INFO - 2018-07-31 13:43:06 --> Security Class Initialized
DEBUG - 2018-07-31 13:43:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:43:06 --> CSRF cookie sent
INFO - 2018-07-31 13:43:06 --> Input Class Initialized
INFO - 2018-07-31 13:43:06 --> Language Class Initialized
INFO - 2018-07-31 13:43:06 --> Loader Class Initialized
INFO - 2018-07-31 13:43:06 --> Helper loaded: url_helper
INFO - 2018-07-31 13:43:06 --> Helper loaded: form_helper
INFO - 2018-07-31 13:43:06 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:43:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:43:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:43:06 --> User Agent Class Initialized
INFO - 2018-07-31 13:43:06 --> Controller Class Initialized
INFO - 2018-07-31 13:43:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:43:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:43:06 --> Pixel_Model class loaded
INFO - 2018-07-31 13:43:06 --> Database Driver Class Initialized
INFO - 2018-07-31 13:43:06 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:43:06 --> Database Driver Class Initialized
INFO - 2018-07-31 13:43:06 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:43:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:43:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:43:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:43:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:43:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:43:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:43:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:43:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids_help_complaint.php
INFO - 2018-07-31 13:43:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:43:06 --> Final output sent to browser
DEBUG - 2018-07-31 13:43:06 --> Total execution time: 0.0477
INFO - 2018-07-31 13:43:07 --> Config Class Initialized
INFO - 2018-07-31 13:43:07 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:43:07 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:43:07 --> Utf8 Class Initialized
INFO - 2018-07-31 13:43:07 --> URI Class Initialized
INFO - 2018-07-31 13:43:07 --> Router Class Initialized
INFO - 2018-07-31 13:43:07 --> Output Class Initialized
INFO - 2018-07-31 13:43:07 --> Security Class Initialized
DEBUG - 2018-07-31 13:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:43:07 --> CSRF cookie sent
INFO - 2018-07-31 13:43:07 --> Input Class Initialized
INFO - 2018-07-31 13:43:07 --> Language Class Initialized
INFO - 2018-07-31 13:43:07 --> Loader Class Initialized
INFO - 2018-07-31 13:43:07 --> Helper loaded: url_helper
INFO - 2018-07-31 13:43:07 --> Helper loaded: form_helper
INFO - 2018-07-31 13:43:07 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:43:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:43:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:43:07 --> User Agent Class Initialized
INFO - 2018-07-31 13:43:07 --> Controller Class Initialized
INFO - 2018-07-31 13:43:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:43:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:43:07 --> Pixel_Model class loaded
INFO - 2018-07-31 13:43:07 --> Database Driver Class Initialized
INFO - 2018-07-31 13:43:07 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:43:07 --> Database Driver Class Initialized
INFO - 2018-07-31 13:43:07 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:43:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:43:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:43:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:43:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:43:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:43:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:43:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:43:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids_doctor.php
INFO - 2018-07-31 13:43:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:43:07 --> Final output sent to browser
DEBUG - 2018-07-31 13:43:07 --> Total execution time: 0.0591
INFO - 2018-07-31 13:43:08 --> Config Class Initialized
INFO - 2018-07-31 13:43:08 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:43:08 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:43:08 --> Utf8 Class Initialized
INFO - 2018-07-31 13:43:08 --> URI Class Initialized
INFO - 2018-07-31 13:43:08 --> Router Class Initialized
INFO - 2018-07-31 13:43:08 --> Output Class Initialized
INFO - 2018-07-31 13:43:08 --> Security Class Initialized
DEBUG - 2018-07-31 13:43:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:43:08 --> CSRF cookie sent
INFO - 2018-07-31 13:43:08 --> Input Class Initialized
INFO - 2018-07-31 13:43:08 --> Language Class Initialized
INFO - 2018-07-31 13:43:08 --> Loader Class Initialized
INFO - 2018-07-31 13:43:08 --> Helper loaded: url_helper
INFO - 2018-07-31 13:43:08 --> Helper loaded: form_helper
INFO - 2018-07-31 13:43:08 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:43:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:43:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:43:08 --> User Agent Class Initialized
INFO - 2018-07-31 13:43:08 --> Controller Class Initialized
INFO - 2018-07-31 13:43:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:43:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:43:08 --> Pixel_Model class loaded
INFO - 2018-07-31 13:43:08 --> Database Driver Class Initialized
INFO - 2018-07-31 13:43:08 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:43:08 --> Database Driver Class Initialized
INFO - 2018-07-31 13:43:08 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:43:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:43:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:43:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:43:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:43:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:43:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:43:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:43:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids_homework.php
INFO - 2018-07-31 13:43:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:43:08 --> Final output sent to browser
DEBUG - 2018-07-31 13:43:08 --> Total execution time: 0.0463
INFO - 2018-07-31 13:43:08 --> Config Class Initialized
INFO - 2018-07-31 13:43:08 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:43:08 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:43:08 --> Utf8 Class Initialized
INFO - 2018-07-31 13:43:08 --> URI Class Initialized
INFO - 2018-07-31 13:43:08 --> Router Class Initialized
INFO - 2018-07-31 13:43:08 --> Output Class Initialized
INFO - 2018-07-31 13:43:08 --> Security Class Initialized
DEBUG - 2018-07-31 13:43:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:43:08 --> CSRF cookie sent
INFO - 2018-07-31 13:43:08 --> Input Class Initialized
INFO - 2018-07-31 13:43:08 --> Language Class Initialized
INFO - 2018-07-31 13:43:08 --> Loader Class Initialized
INFO - 2018-07-31 13:43:08 --> Helper loaded: url_helper
INFO - 2018-07-31 13:43:08 --> Helper loaded: form_helper
INFO - 2018-07-31 13:43:08 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:43:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:43:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:43:08 --> User Agent Class Initialized
INFO - 2018-07-31 13:43:08 --> Controller Class Initialized
INFO - 2018-07-31 13:43:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:43:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:43:08 --> Pixel_Model class loaded
INFO - 2018-07-31 13:43:08 --> Database Driver Class Initialized
INFO - 2018-07-31 13:43:08 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:43:08 --> Database Driver Class Initialized
INFO - 2018-07-31 13:43:08 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:43:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:43:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:43:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:43:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:43:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:43:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:43:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:43:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids_dinner.php
INFO - 2018-07-31 13:43:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:43:08 --> Final output sent to browser
DEBUG - 2018-07-31 13:43:08 --> Total execution time: 0.0465
INFO - 2018-07-31 13:43:09 --> Config Class Initialized
INFO - 2018-07-31 13:43:09 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:43:09 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:43:09 --> Utf8 Class Initialized
INFO - 2018-07-31 13:43:09 --> URI Class Initialized
INFO - 2018-07-31 13:43:09 --> Router Class Initialized
INFO - 2018-07-31 13:43:09 --> Output Class Initialized
INFO - 2018-07-31 13:43:09 --> Security Class Initialized
DEBUG - 2018-07-31 13:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:43:09 --> CSRF cookie sent
INFO - 2018-07-31 13:43:09 --> Input Class Initialized
INFO - 2018-07-31 13:43:09 --> Language Class Initialized
INFO - 2018-07-31 13:43:09 --> Loader Class Initialized
INFO - 2018-07-31 13:43:09 --> Helper loaded: url_helper
INFO - 2018-07-31 13:43:09 --> Helper loaded: form_helper
INFO - 2018-07-31 13:43:09 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:43:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:43:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:43:09 --> User Agent Class Initialized
INFO - 2018-07-31 13:43:09 --> Controller Class Initialized
INFO - 2018-07-31 13:43:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:43:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:43:09 --> Pixel_Model class loaded
INFO - 2018-07-31 13:43:09 --> Database Driver Class Initialized
INFO - 2018-07-31 13:43:09 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:43:09 --> Database Driver Class Initialized
INFO - 2018-07-31 13:43:09 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:43:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:43:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:43:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:43:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:43:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:43:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:43:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:43:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids_communicate.php
INFO - 2018-07-31 13:43:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:43:09 --> Final output sent to browser
DEBUG - 2018-07-31 13:43:09 --> Total execution time: 0.0533
INFO - 2018-07-31 13:43:10 --> Config Class Initialized
INFO - 2018-07-31 13:43:10 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:43:10 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:43:10 --> Utf8 Class Initialized
INFO - 2018-07-31 13:43:10 --> URI Class Initialized
INFO - 2018-07-31 13:43:10 --> Router Class Initialized
INFO - 2018-07-31 13:43:10 --> Output Class Initialized
INFO - 2018-07-31 13:43:10 --> Security Class Initialized
DEBUG - 2018-07-31 13:43:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:43:10 --> CSRF cookie sent
INFO - 2018-07-31 13:43:10 --> Input Class Initialized
INFO - 2018-07-31 13:43:10 --> Language Class Initialized
INFO - 2018-07-31 13:43:10 --> Loader Class Initialized
INFO - 2018-07-31 13:43:10 --> Helper loaded: url_helper
INFO - 2018-07-31 13:43:10 --> Helper loaded: form_helper
INFO - 2018-07-31 13:43:10 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:43:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:43:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:43:10 --> User Agent Class Initialized
INFO - 2018-07-31 13:43:10 --> Controller Class Initialized
INFO - 2018-07-31 13:43:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:43:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:43:10 --> Pixel_Model class loaded
INFO - 2018-07-31 13:43:10 --> Database Driver Class Initialized
INFO - 2018-07-31 13:43:10 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:43:10 --> Database Driver Class Initialized
INFO - 2018-07-31 13:43:10 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:43:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:43:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:43:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:43:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:43:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:43:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:43:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:43:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids_activities.php
INFO - 2018-07-31 13:43:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:43:10 --> Final output sent to browser
DEBUG - 2018-07-31 13:43:10 --> Total execution time: 0.0529
INFO - 2018-07-31 13:43:12 --> Config Class Initialized
INFO - 2018-07-31 13:43:12 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:43:12 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:43:12 --> Utf8 Class Initialized
INFO - 2018-07-31 13:43:12 --> URI Class Initialized
INFO - 2018-07-31 13:43:12 --> Router Class Initialized
INFO - 2018-07-31 13:43:12 --> Output Class Initialized
INFO - 2018-07-31 13:43:12 --> Security Class Initialized
DEBUG - 2018-07-31 13:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:43:12 --> CSRF cookie sent
INFO - 2018-07-31 13:43:12 --> Input Class Initialized
INFO - 2018-07-31 13:43:12 --> Language Class Initialized
INFO - 2018-07-31 13:43:12 --> Loader Class Initialized
INFO - 2018-07-31 13:43:12 --> Helper loaded: url_helper
INFO - 2018-07-31 13:43:12 --> Helper loaded: form_helper
INFO - 2018-07-31 13:43:12 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:43:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:43:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:43:12 --> User Agent Class Initialized
INFO - 2018-07-31 13:43:12 --> Controller Class Initialized
INFO - 2018-07-31 13:43:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:43:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:43:12 --> Pixel_Model class loaded
INFO - 2018-07-31 13:43:12 --> Database Driver Class Initialized
INFO - 2018-07-31 13:43:12 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:43:12 --> Database Driver Class Initialized
INFO - 2018-07-31 13:43:12 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:43:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:43:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:43:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:43:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:43:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:43:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:43:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:43:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/other_kids.php
INFO - 2018-07-31 13:43:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:43:12 --> Final output sent to browser
DEBUG - 2018-07-31 13:43:12 --> Total execution time: 0.0635
INFO - 2018-07-31 13:43:14 --> Config Class Initialized
INFO - 2018-07-31 13:43:14 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:43:14 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:43:14 --> Utf8 Class Initialized
INFO - 2018-07-31 13:43:14 --> URI Class Initialized
INFO - 2018-07-31 13:43:14 --> Router Class Initialized
INFO - 2018-07-31 13:43:14 --> Output Class Initialized
INFO - 2018-07-31 13:43:14 --> Security Class Initialized
DEBUG - 2018-07-31 13:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:43:14 --> CSRF cookie sent
INFO - 2018-07-31 13:43:14 --> Input Class Initialized
INFO - 2018-07-31 13:43:14 --> Language Class Initialized
INFO - 2018-07-31 13:43:14 --> Loader Class Initialized
INFO - 2018-07-31 13:43:14 --> Helper loaded: url_helper
INFO - 2018-07-31 13:43:14 --> Helper loaded: form_helper
INFO - 2018-07-31 13:43:14 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:43:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:43:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:43:14 --> User Agent Class Initialized
INFO - 2018-07-31 13:43:14 --> Controller Class Initialized
INFO - 2018-07-31 13:43:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:43:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:43:14 --> Pixel_Model class loaded
INFO - 2018-07-31 13:43:14 --> Database Driver Class Initialized
INFO - 2018-07-31 13:43:14 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:43:14 --> Database Driver Class Initialized
INFO - 2018-07-31 13:43:14 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:43:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:43:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:43:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:43:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:43:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:43:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:43:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:43:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids_info.php
INFO - 2018-07-31 13:43:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:43:14 --> Final output sent to browser
DEBUG - 2018-07-31 13:43:14 --> Total execution time: 0.0469
INFO - 2018-07-31 13:43:15 --> Config Class Initialized
INFO - 2018-07-31 13:43:15 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:43:15 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:43:15 --> Utf8 Class Initialized
INFO - 2018-07-31 13:43:15 --> URI Class Initialized
INFO - 2018-07-31 13:43:15 --> Router Class Initialized
INFO - 2018-07-31 13:43:15 --> Output Class Initialized
INFO - 2018-07-31 13:43:15 --> Security Class Initialized
DEBUG - 2018-07-31 13:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:43:15 --> CSRF cookie sent
INFO - 2018-07-31 13:43:15 --> Input Class Initialized
INFO - 2018-07-31 13:43:15 --> Language Class Initialized
INFO - 2018-07-31 13:43:15 --> Loader Class Initialized
INFO - 2018-07-31 13:43:15 --> Helper loaded: url_helper
INFO - 2018-07-31 13:43:15 --> Helper loaded: form_helper
INFO - 2018-07-31 13:43:15 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:43:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:43:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:43:15 --> User Agent Class Initialized
INFO - 2018-07-31 13:43:15 --> Controller Class Initialized
INFO - 2018-07-31 13:43:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:43:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:43:15 --> Pixel_Model class loaded
INFO - 2018-07-31 13:43:15 --> Database Driver Class Initialized
INFO - 2018-07-31 13:43:15 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:43:15 --> Database Driver Class Initialized
INFO - 2018-07-31 13:43:15 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:43:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:43:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:43:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:43:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:43:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:43:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:43:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:43:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/other_kids.php
INFO - 2018-07-31 13:43:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:43:15 --> Final output sent to browser
DEBUG - 2018-07-31 13:43:15 --> Total execution time: 0.0456
INFO - 2018-07-31 13:43:16 --> Config Class Initialized
INFO - 2018-07-31 13:43:16 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:43:16 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:43:16 --> Utf8 Class Initialized
INFO - 2018-07-31 13:43:16 --> URI Class Initialized
INFO - 2018-07-31 13:43:16 --> Router Class Initialized
INFO - 2018-07-31 13:43:16 --> Output Class Initialized
INFO - 2018-07-31 13:43:16 --> Security Class Initialized
DEBUG - 2018-07-31 13:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:43:16 --> CSRF cookie sent
INFO - 2018-07-31 13:43:16 --> Input Class Initialized
INFO - 2018-07-31 13:43:16 --> Language Class Initialized
INFO - 2018-07-31 13:43:16 --> Loader Class Initialized
INFO - 2018-07-31 13:43:16 --> Helper loaded: url_helper
INFO - 2018-07-31 13:43:16 --> Helper loaded: form_helper
INFO - 2018-07-31 13:43:16 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:43:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:43:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:43:16 --> User Agent Class Initialized
INFO - 2018-07-31 13:43:16 --> Controller Class Initialized
INFO - 2018-07-31 13:43:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:43:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:43:16 --> Pixel_Model class loaded
INFO - 2018-07-31 13:43:16 --> Database Driver Class Initialized
INFO - 2018-07-31 13:43:16 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:43:16 --> Database Driver Class Initialized
INFO - 2018-07-31 13:43:16 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:43:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:43:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:43:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:43:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:43:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:43:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:43:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:43:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids_activities.php
INFO - 2018-07-31 13:43:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:43:16 --> Final output sent to browser
DEBUG - 2018-07-31 13:43:16 --> Total execution time: 0.0597
INFO - 2018-07-31 13:43:18 --> Config Class Initialized
INFO - 2018-07-31 13:43:18 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:43:18 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:43:18 --> Utf8 Class Initialized
INFO - 2018-07-31 13:43:18 --> URI Class Initialized
INFO - 2018-07-31 13:43:18 --> Router Class Initialized
INFO - 2018-07-31 13:43:18 --> Output Class Initialized
INFO - 2018-07-31 13:43:18 --> Security Class Initialized
DEBUG - 2018-07-31 13:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:43:18 --> CSRF cookie sent
INFO - 2018-07-31 13:43:18 --> Input Class Initialized
INFO - 2018-07-31 13:43:18 --> Language Class Initialized
INFO - 2018-07-31 13:43:18 --> Loader Class Initialized
INFO - 2018-07-31 13:43:18 --> Helper loaded: url_helper
INFO - 2018-07-31 13:43:18 --> Helper loaded: form_helper
INFO - 2018-07-31 13:43:18 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:43:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:43:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:43:18 --> User Agent Class Initialized
INFO - 2018-07-31 13:43:18 --> Controller Class Initialized
INFO - 2018-07-31 13:43:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:43:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:43:18 --> Pixel_Model class loaded
INFO - 2018-07-31 13:43:18 --> Database Driver Class Initialized
INFO - 2018-07-31 13:43:18 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:43:18 --> Database Driver Class Initialized
INFO - 2018-07-31 13:43:18 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:43:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:43:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:43:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:43:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:43:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:43:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:43:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:43:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids_communicate.php
INFO - 2018-07-31 13:43:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:43:18 --> Final output sent to browser
DEBUG - 2018-07-31 13:43:18 --> Total execution time: 0.0450
INFO - 2018-07-31 13:43:20 --> Config Class Initialized
INFO - 2018-07-31 13:43:20 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:43:20 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:43:20 --> Utf8 Class Initialized
INFO - 2018-07-31 13:43:20 --> URI Class Initialized
INFO - 2018-07-31 13:43:20 --> Router Class Initialized
INFO - 2018-07-31 13:43:20 --> Output Class Initialized
INFO - 2018-07-31 13:43:20 --> Security Class Initialized
DEBUG - 2018-07-31 13:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:43:20 --> CSRF cookie sent
INFO - 2018-07-31 13:43:20 --> Input Class Initialized
INFO - 2018-07-31 13:43:20 --> Language Class Initialized
INFO - 2018-07-31 13:43:20 --> Loader Class Initialized
INFO - 2018-07-31 13:43:20 --> Helper loaded: url_helper
INFO - 2018-07-31 13:43:20 --> Helper loaded: form_helper
INFO - 2018-07-31 13:43:20 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:43:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:43:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:43:20 --> User Agent Class Initialized
INFO - 2018-07-31 13:43:20 --> Controller Class Initialized
INFO - 2018-07-31 13:43:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:43:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:43:20 --> Pixel_Model class loaded
INFO - 2018-07-31 13:43:20 --> Database Driver Class Initialized
INFO - 2018-07-31 13:43:20 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:43:20 --> Database Driver Class Initialized
INFO - 2018-07-31 13:43:20 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:43:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:43:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:43:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:43:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:43:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:43:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:43:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:43:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids_dinner.php
INFO - 2018-07-31 13:43:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:43:20 --> Final output sent to browser
DEBUG - 2018-07-31 13:43:20 --> Total execution time: 0.0499
INFO - 2018-07-31 13:43:20 --> Config Class Initialized
INFO - 2018-07-31 13:43:20 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:43:20 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:43:20 --> Utf8 Class Initialized
INFO - 2018-07-31 13:43:20 --> URI Class Initialized
INFO - 2018-07-31 13:43:20 --> Router Class Initialized
INFO - 2018-07-31 13:43:20 --> Output Class Initialized
INFO - 2018-07-31 13:43:20 --> Security Class Initialized
DEBUG - 2018-07-31 13:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:43:20 --> CSRF cookie sent
INFO - 2018-07-31 13:43:20 --> CSRF token verified
INFO - 2018-07-31 13:43:20 --> Input Class Initialized
INFO - 2018-07-31 13:43:20 --> Language Class Initialized
INFO - 2018-07-31 13:43:20 --> Loader Class Initialized
INFO - 2018-07-31 13:43:20 --> Helper loaded: url_helper
INFO - 2018-07-31 13:43:20 --> Helper loaded: form_helper
INFO - 2018-07-31 13:43:20 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:43:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:43:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:43:20 --> User Agent Class Initialized
INFO - 2018-07-31 13:43:20 --> Controller Class Initialized
INFO - 2018-07-31 13:43:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:43:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:43:20 --> Pixel_Model class loaded
INFO - 2018-07-31 13:43:20 --> Database Driver Class Initialized
INFO - 2018-07-31 13:43:20 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:43:20 --> Form Validation Class Initialized
INFO - 2018-07-31 13:43:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-07-31 13:43:20 --> Database Driver Class Initialized
INFO - 2018-07-31 13:43:20 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:43:20 --> Config Class Initialized
INFO - 2018-07-31 13:43:20 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:43:20 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:43:20 --> Utf8 Class Initialized
INFO - 2018-07-31 13:43:20 --> URI Class Initialized
INFO - 2018-07-31 13:43:20 --> Router Class Initialized
INFO - 2018-07-31 13:43:20 --> Output Class Initialized
INFO - 2018-07-31 13:43:20 --> Security Class Initialized
DEBUG - 2018-07-31 13:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:43:20 --> CSRF cookie sent
INFO - 2018-07-31 13:43:20 --> Input Class Initialized
INFO - 2018-07-31 13:43:20 --> Language Class Initialized
INFO - 2018-07-31 13:43:20 --> Loader Class Initialized
INFO - 2018-07-31 13:43:20 --> Helper loaded: url_helper
INFO - 2018-07-31 13:43:20 --> Helper loaded: form_helper
INFO - 2018-07-31 13:43:20 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:43:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:43:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:43:21 --> User Agent Class Initialized
INFO - 2018-07-31 13:43:21 --> Controller Class Initialized
INFO - 2018-07-31 13:43:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:43:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:43:21 --> Pixel_Model class loaded
INFO - 2018-07-31 13:43:21 --> Database Driver Class Initialized
INFO - 2018-07-31 13:43:21 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:43:21 --> Database Driver Class Initialized
INFO - 2018-07-31 13:43:21 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:43:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:43:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:43:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-07-31 13:43:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:43:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:43:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:43:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:43:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-07-31 13:43:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:43:21 --> Final output sent to browser
DEBUG - 2018-07-31 13:43:21 --> Total execution time: 0.0487
INFO - 2018-07-31 13:43:21 --> Config Class Initialized
INFO - 2018-07-31 13:43:21 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:43:21 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:43:21 --> Utf8 Class Initialized
INFO - 2018-07-31 13:43:21 --> URI Class Initialized
INFO - 2018-07-31 13:43:21 --> Router Class Initialized
INFO - 2018-07-31 13:43:21 --> Output Class Initialized
INFO - 2018-07-31 13:43:21 --> Security Class Initialized
DEBUG - 2018-07-31 13:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:43:21 --> CSRF cookie sent
INFO - 2018-07-31 13:43:21 --> Input Class Initialized
INFO - 2018-07-31 13:43:21 --> Language Class Initialized
INFO - 2018-07-31 13:43:21 --> Loader Class Initialized
INFO - 2018-07-31 13:43:21 --> Helper loaded: url_helper
INFO - 2018-07-31 13:43:21 --> Helper loaded: form_helper
INFO - 2018-07-31 13:43:21 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:43:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:43:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:43:21 --> User Agent Class Initialized
INFO - 2018-07-31 13:43:21 --> Controller Class Initialized
INFO - 2018-07-31 13:43:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:43:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:43:21 --> Pixel_Model class loaded
INFO - 2018-07-31 13:43:21 --> Database Driver Class Initialized
INFO - 2018-07-31 13:43:21 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:43:21 --> Database Driver Class Initialized
INFO - 2018-07-31 13:43:21 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:43:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:43:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:43:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:43:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:43:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:43:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:43:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:43:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids_homework.php
INFO - 2018-07-31 13:43:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:43:21 --> Final output sent to browser
DEBUG - 2018-07-31 13:43:21 --> Total execution time: 0.0378
INFO - 2018-07-31 13:43:22 --> Config Class Initialized
INFO - 2018-07-31 13:43:22 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:43:22 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:43:22 --> Utf8 Class Initialized
INFO - 2018-07-31 13:43:22 --> URI Class Initialized
INFO - 2018-07-31 13:43:22 --> Router Class Initialized
INFO - 2018-07-31 13:43:22 --> Output Class Initialized
INFO - 2018-07-31 13:43:22 --> Security Class Initialized
DEBUG - 2018-07-31 13:43:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:43:22 --> CSRF cookie sent
INFO - 2018-07-31 13:43:22 --> Input Class Initialized
INFO - 2018-07-31 13:43:22 --> Language Class Initialized
INFO - 2018-07-31 13:43:22 --> Loader Class Initialized
INFO - 2018-07-31 13:43:22 --> Helper loaded: url_helper
INFO - 2018-07-31 13:43:22 --> Helper loaded: form_helper
INFO - 2018-07-31 13:43:22 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:43:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:43:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:43:22 --> User Agent Class Initialized
INFO - 2018-07-31 13:43:22 --> Controller Class Initialized
INFO - 2018-07-31 13:43:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:43:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:43:22 --> Pixel_Model class loaded
INFO - 2018-07-31 13:43:22 --> Database Driver Class Initialized
INFO - 2018-07-31 13:43:22 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:43:22 --> Database Driver Class Initialized
INFO - 2018-07-31 13:43:22 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:43:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:43:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:43:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:43:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:43:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:43:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:43:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:43:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids_doctor.php
INFO - 2018-07-31 13:43:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:43:22 --> Final output sent to browser
DEBUG - 2018-07-31 13:43:22 --> Total execution time: 0.0463
INFO - 2018-07-31 13:43:23 --> Config Class Initialized
INFO - 2018-07-31 13:43:23 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:43:23 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:43:23 --> Utf8 Class Initialized
INFO - 2018-07-31 13:43:23 --> URI Class Initialized
INFO - 2018-07-31 13:43:23 --> Router Class Initialized
INFO - 2018-07-31 13:43:23 --> Output Class Initialized
INFO - 2018-07-31 13:43:23 --> Security Class Initialized
DEBUG - 2018-07-31 13:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:43:23 --> CSRF cookie sent
INFO - 2018-07-31 13:43:23 --> Input Class Initialized
INFO - 2018-07-31 13:43:23 --> Language Class Initialized
INFO - 2018-07-31 13:43:23 --> Loader Class Initialized
INFO - 2018-07-31 13:43:23 --> Helper loaded: url_helper
INFO - 2018-07-31 13:43:23 --> Helper loaded: form_helper
INFO - 2018-07-31 13:43:23 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:43:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:43:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:43:23 --> User Agent Class Initialized
INFO - 2018-07-31 13:43:23 --> Controller Class Initialized
INFO - 2018-07-31 13:43:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:43:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:43:23 --> Pixel_Model class loaded
INFO - 2018-07-31 13:43:23 --> Database Driver Class Initialized
INFO - 2018-07-31 13:43:23 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:43:23 --> Database Driver Class Initialized
INFO - 2018-07-31 13:43:23 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:43:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:43:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:43:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:43:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:43:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:43:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:43:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:43:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids_help_complaint.php
INFO - 2018-07-31 13:43:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:43:23 --> Final output sent to browser
DEBUG - 2018-07-31 13:43:23 --> Total execution time: 0.0554
INFO - 2018-07-31 13:43:25 --> Config Class Initialized
INFO - 2018-07-31 13:43:25 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:43:25 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:43:25 --> Utf8 Class Initialized
INFO - 2018-07-31 13:43:25 --> URI Class Initialized
INFO - 2018-07-31 13:43:25 --> Router Class Initialized
INFO - 2018-07-31 13:43:25 --> Output Class Initialized
INFO - 2018-07-31 13:43:25 --> Security Class Initialized
DEBUG - 2018-07-31 13:43:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:43:25 --> CSRF cookie sent
INFO - 2018-07-31 13:43:25 --> Input Class Initialized
INFO - 2018-07-31 13:43:25 --> Language Class Initialized
INFO - 2018-07-31 13:43:25 --> Loader Class Initialized
INFO - 2018-07-31 13:43:25 --> Helper loaded: url_helper
INFO - 2018-07-31 13:43:25 --> Helper loaded: form_helper
INFO - 2018-07-31 13:43:25 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:43:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:43:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:43:25 --> User Agent Class Initialized
INFO - 2018-07-31 13:43:25 --> Controller Class Initialized
INFO - 2018-07-31 13:43:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:43:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:43:25 --> Pixel_Model class loaded
INFO - 2018-07-31 13:43:25 --> Database Driver Class Initialized
INFO - 2018-07-31 13:43:25 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:43:25 --> Database Driver Class Initialized
INFO - 2018-07-31 13:43:25 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:43:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:43:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:43:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:43:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:43:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:43:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:43:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:43:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/spouse_info.php
INFO - 2018-07-31 13:43:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:43:25 --> Final output sent to browser
DEBUG - 2018-07-31 13:43:25 --> Total execution time: 0.0462
INFO - 2018-07-31 13:43:39 --> Config Class Initialized
INFO - 2018-07-31 13:43:39 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:43:39 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:43:39 --> Utf8 Class Initialized
INFO - 2018-07-31 13:43:39 --> URI Class Initialized
INFO - 2018-07-31 13:43:39 --> Router Class Initialized
INFO - 2018-07-31 13:43:39 --> Output Class Initialized
INFO - 2018-07-31 13:43:39 --> Security Class Initialized
DEBUG - 2018-07-31 13:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:43:39 --> CSRF cookie sent
INFO - 2018-07-31 13:43:39 --> CSRF token verified
INFO - 2018-07-31 13:43:39 --> Input Class Initialized
INFO - 2018-07-31 13:43:39 --> Language Class Initialized
INFO - 2018-07-31 13:43:39 --> Loader Class Initialized
INFO - 2018-07-31 13:43:39 --> Helper loaded: url_helper
INFO - 2018-07-31 13:43:39 --> Helper loaded: form_helper
INFO - 2018-07-31 13:43:39 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:43:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:43:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:43:39 --> User Agent Class Initialized
INFO - 2018-07-31 13:43:39 --> Controller Class Initialized
INFO - 2018-07-31 13:43:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:43:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:43:39 --> Pixel_Model class loaded
INFO - 2018-07-31 13:43:39 --> Database Driver Class Initialized
INFO - 2018-07-31 13:43:39 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:43:39 --> Form Validation Class Initialized
INFO - 2018-07-31 13:43:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-07-31 13:43:39 --> Database Driver Class Initialized
INFO - 2018-07-31 13:43:39 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:43:39 --> Config Class Initialized
INFO - 2018-07-31 13:43:39 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:43:39 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:43:39 --> Utf8 Class Initialized
INFO - 2018-07-31 13:43:39 --> URI Class Initialized
INFO - 2018-07-31 13:43:39 --> Router Class Initialized
INFO - 2018-07-31 13:43:39 --> Output Class Initialized
INFO - 2018-07-31 13:43:39 --> Security Class Initialized
DEBUG - 2018-07-31 13:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:43:39 --> CSRF cookie sent
INFO - 2018-07-31 13:43:39 --> Input Class Initialized
INFO - 2018-07-31 13:43:39 --> Language Class Initialized
INFO - 2018-07-31 13:43:39 --> Loader Class Initialized
INFO - 2018-07-31 13:43:39 --> Helper loaded: url_helper
INFO - 2018-07-31 13:43:39 --> Helper loaded: form_helper
INFO - 2018-07-31 13:43:39 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:43:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:43:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:43:39 --> User Agent Class Initialized
INFO - 2018-07-31 13:43:39 --> Controller Class Initialized
INFO - 2018-07-31 13:43:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:43:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:43:39 --> Pixel_Model class loaded
INFO - 2018-07-31 13:43:39 --> Database Driver Class Initialized
INFO - 2018-07-31 13:43:39 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:43:39 --> Database Driver Class Initialized
INFO - 2018-07-31 13:43:39 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:43:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:43:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:43:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:43:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:43:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:43:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:43:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-07-31 13:43:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:43:39 --> Final output sent to browser
DEBUG - 2018-07-31 13:43:39 --> Total execution time: 0.0397
INFO - 2018-07-31 13:44:24 --> Config Class Initialized
INFO - 2018-07-31 13:44:24 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:44:24 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:44:24 --> Utf8 Class Initialized
INFO - 2018-07-31 13:44:24 --> URI Class Initialized
INFO - 2018-07-31 13:44:24 --> Router Class Initialized
INFO - 2018-07-31 13:44:24 --> Output Class Initialized
INFO - 2018-07-31 13:44:24 --> Security Class Initialized
DEBUG - 2018-07-31 13:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:44:24 --> CSRF cookie sent
INFO - 2018-07-31 13:44:24 --> Input Class Initialized
INFO - 2018-07-31 13:44:24 --> Language Class Initialized
INFO - 2018-07-31 13:44:24 --> Loader Class Initialized
INFO - 2018-07-31 13:44:24 --> Helper loaded: url_helper
INFO - 2018-07-31 13:44:24 --> Helper loaded: form_helper
INFO - 2018-07-31 13:44:24 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:44:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:44:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:44:24 --> User Agent Class Initialized
INFO - 2018-07-31 13:44:24 --> Controller Class Initialized
INFO - 2018-07-31 13:44:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:44:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:44:24 --> Pixel_Model class loaded
INFO - 2018-07-31 13:44:24 --> Database Driver Class Initialized
INFO - 2018-07-31 13:44:24 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:44:24 --> Database Driver Class Initialized
INFO - 2018-07-31 13:44:24 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:44:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:44:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:44:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:44:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:44:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:44:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:44:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:44:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/spouse_job.php
INFO - 2018-07-31 13:44:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:44:24 --> Final output sent to browser
DEBUG - 2018-07-31 13:44:24 --> Total execution time: 0.0475
INFO - 2018-07-31 13:44:26 --> Config Class Initialized
INFO - 2018-07-31 13:44:26 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:44:26 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:44:26 --> Utf8 Class Initialized
INFO - 2018-07-31 13:44:26 --> URI Class Initialized
INFO - 2018-07-31 13:44:26 --> Router Class Initialized
INFO - 2018-07-31 13:44:26 --> Output Class Initialized
INFO - 2018-07-31 13:44:26 --> Security Class Initialized
DEBUG - 2018-07-31 13:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:44:26 --> CSRF cookie sent
INFO - 2018-07-31 13:44:26 --> Input Class Initialized
INFO - 2018-07-31 13:44:26 --> Language Class Initialized
INFO - 2018-07-31 13:44:26 --> Loader Class Initialized
INFO - 2018-07-31 13:44:26 --> Helper loaded: url_helper
INFO - 2018-07-31 13:44:26 --> Helper loaded: form_helper
INFO - 2018-07-31 13:44:26 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:44:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:44:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:44:26 --> User Agent Class Initialized
INFO - 2018-07-31 13:44:26 --> Controller Class Initialized
INFO - 2018-07-31 13:44:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:44:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:44:26 --> Pixel_Model class loaded
INFO - 2018-07-31 13:44:26 --> Database Driver Class Initialized
INFO - 2018-07-31 13:44:26 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:44:26 --> Database Driver Class Initialized
INFO - 2018-07-31 13:44:26 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:44:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:44:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:44:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:44:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:44:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:44:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:44:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:44:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/affectionate_salutation.php
INFO - 2018-07-31 13:44:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:44:26 --> Final output sent to browser
DEBUG - 2018-07-31 13:44:26 --> Total execution time: 0.0596
INFO - 2018-07-31 13:44:27 --> Config Class Initialized
INFO - 2018-07-31 13:44:27 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:44:27 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:44:27 --> Utf8 Class Initialized
INFO - 2018-07-31 13:44:27 --> URI Class Initialized
INFO - 2018-07-31 13:44:27 --> Router Class Initialized
INFO - 2018-07-31 13:44:27 --> Output Class Initialized
INFO - 2018-07-31 13:44:27 --> Security Class Initialized
DEBUG - 2018-07-31 13:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:44:27 --> CSRF cookie sent
INFO - 2018-07-31 13:44:27 --> Input Class Initialized
INFO - 2018-07-31 13:44:27 --> Language Class Initialized
INFO - 2018-07-31 13:44:27 --> Loader Class Initialized
INFO - 2018-07-31 13:44:27 --> Helper loaded: url_helper
INFO - 2018-07-31 13:44:27 --> Helper loaded: form_helper
INFO - 2018-07-31 13:44:27 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:44:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:44:27 --> User Agent Class Initialized
INFO - 2018-07-31 13:44:27 --> Controller Class Initialized
INFO - 2018-07-31 13:44:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:44:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:44:27 --> Pixel_Model class loaded
INFO - 2018-07-31 13:44:27 --> Database Driver Class Initialized
INFO - 2018-07-31 13:44:27 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:44:27 --> Database Driver Class Initialized
INFO - 2018-07-31 13:44:27 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:44:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:44:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:44:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:44:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:44:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:44:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:44:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:44:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/business_tax_info.php
INFO - 2018-07-31 13:44:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:44:27 --> Final output sent to browser
DEBUG - 2018-07-31 13:44:27 --> Total execution time: 0.0484
INFO - 2018-07-31 13:44:28 --> Config Class Initialized
INFO - 2018-07-31 13:44:28 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:44:28 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:44:28 --> Utf8 Class Initialized
INFO - 2018-07-31 13:44:28 --> URI Class Initialized
INFO - 2018-07-31 13:44:28 --> Router Class Initialized
INFO - 2018-07-31 13:44:28 --> Output Class Initialized
INFO - 2018-07-31 13:44:28 --> Security Class Initialized
DEBUG - 2018-07-31 13:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:44:28 --> CSRF cookie sent
INFO - 2018-07-31 13:44:28 --> Input Class Initialized
INFO - 2018-07-31 13:44:28 --> Language Class Initialized
INFO - 2018-07-31 13:44:28 --> Loader Class Initialized
INFO - 2018-07-31 13:44:28 --> Helper loaded: url_helper
INFO - 2018-07-31 13:44:28 --> Helper loaded: form_helper
INFO - 2018-07-31 13:44:29 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:44:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:44:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:44:29 --> User Agent Class Initialized
INFO - 2018-07-31 13:44:29 --> Controller Class Initialized
INFO - 2018-07-31 13:44:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:44:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:44:29 --> Pixel_Model class loaded
INFO - 2018-07-31 13:44:29 --> Database Driver Class Initialized
INFO - 2018-07-31 13:44:29 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:44:29 --> Database Driver Class Initialized
INFO - 2018-07-31 13:44:29 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:44:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:44:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:44:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:44:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:44:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:44:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:44:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:44:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/trust_info.php
INFO - 2018-07-31 13:44:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:44:29 --> Final output sent to browser
DEBUG - 2018-07-31 13:44:29 --> Total execution time: 0.0589
INFO - 2018-07-31 13:44:29 --> Config Class Initialized
INFO - 2018-07-31 13:44:29 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:44:29 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:44:29 --> Utf8 Class Initialized
INFO - 2018-07-31 13:44:29 --> URI Class Initialized
INFO - 2018-07-31 13:44:29 --> Router Class Initialized
INFO - 2018-07-31 13:44:29 --> Output Class Initialized
INFO - 2018-07-31 13:44:29 --> Security Class Initialized
DEBUG - 2018-07-31 13:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:44:29 --> CSRF cookie sent
INFO - 2018-07-31 13:44:29 --> Input Class Initialized
INFO - 2018-07-31 13:44:29 --> Language Class Initialized
INFO - 2018-07-31 13:44:30 --> Loader Class Initialized
INFO - 2018-07-31 13:44:30 --> Helper loaded: url_helper
INFO - 2018-07-31 13:44:30 --> Helper loaded: form_helper
INFO - 2018-07-31 13:44:30 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:44:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:44:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:44:30 --> User Agent Class Initialized
INFO - 2018-07-31 13:44:30 --> Controller Class Initialized
INFO - 2018-07-31 13:44:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:44:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:44:30 --> Pixel_Model class loaded
INFO - 2018-07-31 13:44:30 --> Database Driver Class Initialized
INFO - 2018-07-31 13:44:30 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:44:30 --> Database Driver Class Initialized
INFO - 2018-07-31 13:44:30 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:44:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:44:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:44:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:44:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:44:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:44:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:44:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:44:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inherited_income.php
INFO - 2018-07-31 13:44:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:44:30 --> Final output sent to browser
DEBUG - 2018-07-31 13:44:30 --> Total execution time: 0.0573
INFO - 2018-07-31 13:44:30 --> Config Class Initialized
INFO - 2018-07-31 13:44:30 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:44:30 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:44:30 --> Utf8 Class Initialized
INFO - 2018-07-31 13:44:30 --> URI Class Initialized
INFO - 2018-07-31 13:44:30 --> Router Class Initialized
INFO - 2018-07-31 13:44:30 --> Output Class Initialized
INFO - 2018-07-31 13:44:30 --> Security Class Initialized
DEBUG - 2018-07-31 13:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:44:30 --> CSRF cookie sent
INFO - 2018-07-31 13:44:30 --> Input Class Initialized
INFO - 2018-07-31 13:44:30 --> Language Class Initialized
INFO - 2018-07-31 13:44:30 --> Loader Class Initialized
INFO - 2018-07-31 13:44:30 --> Helper loaded: url_helper
INFO - 2018-07-31 13:44:30 --> Helper loaded: form_helper
INFO - 2018-07-31 13:44:30 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:44:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:44:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:44:30 --> User Agent Class Initialized
INFO - 2018-07-31 13:44:30 --> Controller Class Initialized
INFO - 2018-07-31 13:44:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:44:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:44:30 --> Pixel_Model class loaded
INFO - 2018-07-31 13:44:30 --> Database Driver Class Initialized
INFO - 2018-07-31 13:44:30 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:44:30 --> Database Driver Class Initialized
INFO - 2018-07-31 13:44:30 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:44:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:44:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:44:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:44:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:44:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:44:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:44:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:44:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/shift_work.php
INFO - 2018-07-31 13:44:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:44:30 --> Final output sent to browser
DEBUG - 2018-07-31 13:44:30 --> Total execution time: 0.0652
INFO - 2018-07-31 13:44:32 --> Config Class Initialized
INFO - 2018-07-31 13:44:32 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:44:32 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:44:32 --> Utf8 Class Initialized
INFO - 2018-07-31 13:44:32 --> URI Class Initialized
INFO - 2018-07-31 13:44:32 --> Router Class Initialized
INFO - 2018-07-31 13:44:32 --> Output Class Initialized
INFO - 2018-07-31 13:44:32 --> Security Class Initialized
DEBUG - 2018-07-31 13:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:44:32 --> CSRF cookie sent
INFO - 2018-07-31 13:44:32 --> Input Class Initialized
INFO - 2018-07-31 13:44:32 --> Language Class Initialized
INFO - 2018-07-31 13:44:32 --> Loader Class Initialized
INFO - 2018-07-31 13:44:32 --> Helper loaded: url_helper
INFO - 2018-07-31 13:44:32 --> Helper loaded: form_helper
INFO - 2018-07-31 13:44:32 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:44:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:44:32 --> User Agent Class Initialized
INFO - 2018-07-31 13:44:32 --> Controller Class Initialized
INFO - 2018-07-31 13:44:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:44:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:44:32 --> Pixel_Model class loaded
INFO - 2018-07-31 13:44:32 --> Database Driver Class Initialized
INFO - 2018-07-31 13:44:32 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:44:32 --> Database Driver Class Initialized
INFO - 2018-07-31 13:44:32 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:44:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:44:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:44:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:44:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:44:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:44:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:44:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:44:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/night_without_s.php
INFO - 2018-07-31 13:44:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:44:32 --> Final output sent to browser
DEBUG - 2018-07-31 13:44:32 --> Total execution time: 0.0434
INFO - 2018-07-31 13:44:33 --> Config Class Initialized
INFO - 2018-07-31 13:44:33 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:44:33 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:44:33 --> Utf8 Class Initialized
INFO - 2018-07-31 13:44:33 --> URI Class Initialized
INFO - 2018-07-31 13:44:33 --> Router Class Initialized
INFO - 2018-07-31 13:44:33 --> Output Class Initialized
INFO - 2018-07-31 13:44:33 --> Security Class Initialized
DEBUG - 2018-07-31 13:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:44:33 --> CSRF cookie sent
INFO - 2018-07-31 13:44:33 --> Input Class Initialized
INFO - 2018-07-31 13:44:33 --> Language Class Initialized
INFO - 2018-07-31 13:44:33 --> Loader Class Initialized
INFO - 2018-07-31 13:44:33 --> Helper loaded: url_helper
INFO - 2018-07-31 13:44:33 --> Helper loaded: form_helper
INFO - 2018-07-31 13:44:33 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:44:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:44:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:44:33 --> User Agent Class Initialized
INFO - 2018-07-31 13:44:33 --> Controller Class Initialized
INFO - 2018-07-31 13:44:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:44:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:44:33 --> Pixel_Model class loaded
INFO - 2018-07-31 13:44:33 --> Database Driver Class Initialized
INFO - 2018-07-31 13:44:33 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:44:33 --> Database Driver Class Initialized
INFO - 2018-07-31 13:44:33 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:44:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:44:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:44:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:44:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:44:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:44:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:44:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:44:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/have_date.php
INFO - 2018-07-31 13:44:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:44:33 --> Final output sent to browser
DEBUG - 2018-07-31 13:44:33 --> Total execution time: 0.0459
INFO - 2018-07-31 13:44:34 --> Config Class Initialized
INFO - 2018-07-31 13:44:34 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:44:34 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:44:34 --> Utf8 Class Initialized
INFO - 2018-07-31 13:44:34 --> URI Class Initialized
INFO - 2018-07-31 13:44:34 --> Router Class Initialized
INFO - 2018-07-31 13:44:34 --> Output Class Initialized
INFO - 2018-07-31 13:44:34 --> Security Class Initialized
DEBUG - 2018-07-31 13:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:44:34 --> CSRF cookie sent
INFO - 2018-07-31 13:44:34 --> Input Class Initialized
INFO - 2018-07-31 13:44:34 --> Language Class Initialized
INFO - 2018-07-31 13:44:34 --> Loader Class Initialized
INFO - 2018-07-31 13:44:34 --> Helper loaded: url_helper
INFO - 2018-07-31 13:44:34 --> Helper loaded: form_helper
INFO - 2018-07-31 13:44:34 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:44:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:44:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:44:34 --> User Agent Class Initialized
INFO - 2018-07-31 13:44:34 --> Controller Class Initialized
INFO - 2018-07-31 13:44:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:44:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:44:34 --> Pixel_Model class loaded
INFO - 2018-07-31 13:44:34 --> Database Driver Class Initialized
INFO - 2018-07-31 13:44:34 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:44:34 --> Database Driver Class Initialized
INFO - 2018-07-31 13:44:34 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:44:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:44:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:44:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:44:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:44:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:44:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:44:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:44:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/nights_not_home.php
INFO - 2018-07-31 13:44:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:44:34 --> Final output sent to browser
DEBUG - 2018-07-31 13:44:34 --> Total execution time: 0.0493
INFO - 2018-07-31 13:44:35 --> Config Class Initialized
INFO - 2018-07-31 13:44:35 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:44:35 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:44:35 --> Utf8 Class Initialized
INFO - 2018-07-31 13:44:35 --> URI Class Initialized
INFO - 2018-07-31 13:44:35 --> Router Class Initialized
INFO - 2018-07-31 13:44:35 --> Output Class Initialized
INFO - 2018-07-31 13:44:35 --> Security Class Initialized
DEBUG - 2018-07-31 13:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:44:35 --> CSRF cookie sent
INFO - 2018-07-31 13:44:35 --> Input Class Initialized
INFO - 2018-07-31 13:44:35 --> Language Class Initialized
INFO - 2018-07-31 13:44:35 --> Loader Class Initialized
INFO - 2018-07-31 13:44:35 --> Helper loaded: url_helper
INFO - 2018-07-31 13:44:35 --> Helper loaded: form_helper
INFO - 2018-07-31 13:44:35 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:44:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:44:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:44:35 --> User Agent Class Initialized
INFO - 2018-07-31 13:44:35 --> Controller Class Initialized
INFO - 2018-07-31 13:44:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:44:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:44:35 --> Pixel_Model class loaded
INFO - 2018-07-31 13:44:35 --> Database Driver Class Initialized
INFO - 2018-07-31 13:44:35 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:44:35 --> Database Driver Class Initialized
INFO - 2018-07-31 13:44:35 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:44:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:44:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:44:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:44:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:44:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:44:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:44:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:44:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/s_nights_not_home.php
INFO - 2018-07-31 13:44:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:44:35 --> Final output sent to browser
DEBUG - 2018-07-31 13:44:35 --> Total execution time: 0.0496
INFO - 2018-07-31 13:44:35 --> Config Class Initialized
INFO - 2018-07-31 13:44:35 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:44:35 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:44:35 --> Utf8 Class Initialized
INFO - 2018-07-31 13:44:35 --> URI Class Initialized
INFO - 2018-07-31 13:44:35 --> Router Class Initialized
INFO - 2018-07-31 13:44:35 --> Output Class Initialized
INFO - 2018-07-31 13:44:35 --> Security Class Initialized
DEBUG - 2018-07-31 13:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:44:35 --> CSRF cookie sent
INFO - 2018-07-31 13:44:35 --> Input Class Initialized
INFO - 2018-07-31 13:44:35 --> Language Class Initialized
INFO - 2018-07-31 13:44:35 --> Loader Class Initialized
INFO - 2018-07-31 13:44:35 --> Helper loaded: url_helper
INFO - 2018-07-31 13:44:35 --> Helper loaded: form_helper
INFO - 2018-07-31 13:44:35 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:44:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:44:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:44:35 --> User Agent Class Initialized
INFO - 2018-07-31 13:44:35 --> Controller Class Initialized
INFO - 2018-07-31 13:44:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:44:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:44:35 --> Pixel_Model class loaded
INFO - 2018-07-31 13:44:35 --> Database Driver Class Initialized
INFO - 2018-07-31 13:44:35 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:44:35 --> Database Driver Class Initialized
INFO - 2018-07-31 13:44:35 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:44:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:44:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:44:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:44:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:44:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:44:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:44:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:44:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/s_nights_without_you.php
INFO - 2018-07-31 13:44:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:44:35 --> Final output sent to browser
DEBUG - 2018-07-31 13:44:35 --> Total execution time: 0.0566
INFO - 2018-07-31 13:44:36 --> Config Class Initialized
INFO - 2018-07-31 13:44:36 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:44:36 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:44:36 --> Utf8 Class Initialized
INFO - 2018-07-31 13:44:36 --> URI Class Initialized
INFO - 2018-07-31 13:44:36 --> Router Class Initialized
INFO - 2018-07-31 13:44:36 --> Output Class Initialized
INFO - 2018-07-31 13:44:36 --> Security Class Initialized
DEBUG - 2018-07-31 13:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:44:36 --> CSRF cookie sent
INFO - 2018-07-31 13:44:36 --> Input Class Initialized
INFO - 2018-07-31 13:44:36 --> Language Class Initialized
INFO - 2018-07-31 13:44:36 --> Loader Class Initialized
INFO - 2018-07-31 13:44:36 --> Helper loaded: url_helper
INFO - 2018-07-31 13:44:36 --> Helper loaded: form_helper
INFO - 2018-07-31 13:44:36 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:44:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:44:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:44:36 --> User Agent Class Initialized
INFO - 2018-07-31 13:44:36 --> Controller Class Initialized
INFO - 2018-07-31 13:44:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:44:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:44:36 --> Pixel_Model class loaded
INFO - 2018-07-31 13:44:36 --> Database Driver Class Initialized
INFO - 2018-07-31 13:44:36 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:44:36 --> Database Driver Class Initialized
INFO - 2018-07-31 13:44:36 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:44:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:44:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:44:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:44:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:44:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:44:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:44:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:44:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/alcoholic_drinks_per_week.php
INFO - 2018-07-31 13:44:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:44:36 --> Final output sent to browser
DEBUG - 2018-07-31 13:44:36 --> Total execution time: 0.0366
INFO - 2018-07-31 13:44:37 --> Config Class Initialized
INFO - 2018-07-31 13:44:37 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:44:37 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:44:37 --> Utf8 Class Initialized
INFO - 2018-07-31 13:44:37 --> URI Class Initialized
INFO - 2018-07-31 13:44:37 --> Router Class Initialized
INFO - 2018-07-31 13:44:37 --> Output Class Initialized
INFO - 2018-07-31 13:44:37 --> Security Class Initialized
DEBUG - 2018-07-31 13:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:44:37 --> CSRF cookie sent
INFO - 2018-07-31 13:44:37 --> Input Class Initialized
INFO - 2018-07-31 13:44:37 --> Language Class Initialized
INFO - 2018-07-31 13:44:37 --> Loader Class Initialized
INFO - 2018-07-31 13:44:37 --> Helper loaded: url_helper
INFO - 2018-07-31 13:44:37 --> Helper loaded: form_helper
INFO - 2018-07-31 13:44:37 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:44:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:44:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:44:37 --> User Agent Class Initialized
INFO - 2018-07-31 13:44:37 --> Controller Class Initialized
INFO - 2018-07-31 13:44:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:44:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:44:37 --> Pixel_Model class loaded
INFO - 2018-07-31 13:44:37 --> Database Driver Class Initialized
INFO - 2018-07-31 13:44:37 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:44:37 --> Database Driver Class Initialized
INFO - 2018-07-31 13:44:37 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:44:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:44:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:44:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:44:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:44:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:44:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:44:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:44:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/have_drugs.php
INFO - 2018-07-31 13:44:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:44:37 --> Final output sent to browser
DEBUG - 2018-07-31 13:44:37 --> Total execution time: 0.0516
INFO - 2018-07-31 13:46:31 --> Config Class Initialized
INFO - 2018-07-31 13:46:31 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:46:31 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:46:31 --> Utf8 Class Initialized
INFO - 2018-07-31 13:46:31 --> URI Class Initialized
INFO - 2018-07-31 13:46:31 --> Router Class Initialized
INFO - 2018-07-31 13:46:31 --> Output Class Initialized
INFO - 2018-07-31 13:46:31 --> Security Class Initialized
DEBUG - 2018-07-31 13:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:46:31 --> CSRF cookie sent
INFO - 2018-07-31 13:46:31 --> Input Class Initialized
INFO - 2018-07-31 13:46:31 --> Language Class Initialized
INFO - 2018-07-31 13:46:31 --> Loader Class Initialized
INFO - 2018-07-31 13:46:31 --> Helper loaded: url_helper
INFO - 2018-07-31 13:46:31 --> Helper loaded: form_helper
INFO - 2018-07-31 13:46:31 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:46:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:46:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:46:31 --> User Agent Class Initialized
INFO - 2018-07-31 13:46:31 --> Controller Class Initialized
INFO - 2018-07-31 13:46:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:46:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:46:31 --> Pixel_Model class loaded
INFO - 2018-07-31 13:46:31 --> Database Driver Class Initialized
INFO - 2018-07-31 13:46:31 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:46:31 --> Database Driver Class Initialized
INFO - 2018-07-31 13:46:31 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:46:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:46:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:46:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:46:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:46:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:46:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:46:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:46:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/has_addiction_problem.php
INFO - 2018-07-31 13:46:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:46:31 --> Final output sent to browser
DEBUG - 2018-07-31 13:46:31 --> Total execution time: 0.0544
INFO - 2018-07-31 13:46:32 --> Config Class Initialized
INFO - 2018-07-31 13:46:32 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:46:32 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:46:32 --> Utf8 Class Initialized
INFO - 2018-07-31 13:46:32 --> URI Class Initialized
INFO - 2018-07-31 13:46:32 --> Router Class Initialized
INFO - 2018-07-31 13:46:32 --> Output Class Initialized
INFO - 2018-07-31 13:46:32 --> Security Class Initialized
DEBUG - 2018-07-31 13:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:46:32 --> CSRF cookie sent
INFO - 2018-07-31 13:46:32 --> Input Class Initialized
INFO - 2018-07-31 13:46:32 --> Language Class Initialized
INFO - 2018-07-31 13:46:32 --> Loader Class Initialized
INFO - 2018-07-31 13:46:32 --> Helper loaded: url_helper
INFO - 2018-07-31 13:46:32 --> Helper loaded: form_helper
INFO - 2018-07-31 13:46:32 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:46:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:46:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:46:32 --> User Agent Class Initialized
INFO - 2018-07-31 13:46:32 --> Controller Class Initialized
INFO - 2018-07-31 13:46:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:46:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:46:32 --> Pixel_Model class loaded
INFO - 2018-07-31 13:46:32 --> Database Driver Class Initialized
INFO - 2018-07-31 13:46:32 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:46:32 --> Database Driver Class Initialized
INFO - 2018-07-31 13:46:32 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:46:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:46:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:46:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:46:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:46:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:46:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:46:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:46:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/have_hit_s.php
INFO - 2018-07-31 13:46:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:46:32 --> Final output sent to browser
DEBUG - 2018-07-31 13:46:32 --> Total execution time: 0.0435
INFO - 2018-07-31 13:46:37 --> Config Class Initialized
INFO - 2018-07-31 13:46:37 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:46:37 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:46:37 --> Utf8 Class Initialized
INFO - 2018-07-31 13:46:37 --> URI Class Initialized
INFO - 2018-07-31 13:46:37 --> Router Class Initialized
INFO - 2018-07-31 13:46:37 --> Output Class Initialized
INFO - 2018-07-31 13:46:37 --> Security Class Initialized
DEBUG - 2018-07-31 13:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:46:37 --> CSRF cookie sent
INFO - 2018-07-31 13:46:37 --> Input Class Initialized
INFO - 2018-07-31 13:46:37 --> Language Class Initialized
INFO - 2018-07-31 13:46:37 --> Loader Class Initialized
INFO - 2018-07-31 13:46:37 --> Helper loaded: url_helper
INFO - 2018-07-31 13:46:37 --> Helper loaded: form_helper
INFO - 2018-07-31 13:46:37 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:46:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:46:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:46:37 --> User Agent Class Initialized
INFO - 2018-07-31 13:46:37 --> Controller Class Initialized
INFO - 2018-07-31 13:46:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:46:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:46:37 --> Pixel_Model class loaded
INFO - 2018-07-31 13:46:37 --> Database Driver Class Initialized
INFO - 2018-07-31 13:46:37 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:46:37 --> Database Driver Class Initialized
INFO - 2018-07-31 13:46:37 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:46:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:46:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:46:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:46:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:46:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:46:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:46:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:46:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/has_addiction_problem.php
INFO - 2018-07-31 13:46:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:46:37 --> Final output sent to browser
DEBUG - 2018-07-31 13:46:37 --> Total execution time: 0.0428
INFO - 2018-07-31 13:46:38 --> Config Class Initialized
INFO - 2018-07-31 13:46:38 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:46:38 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:46:38 --> Utf8 Class Initialized
INFO - 2018-07-31 13:46:38 --> URI Class Initialized
INFO - 2018-07-31 13:46:38 --> Router Class Initialized
INFO - 2018-07-31 13:46:38 --> Output Class Initialized
INFO - 2018-07-31 13:46:38 --> Security Class Initialized
DEBUG - 2018-07-31 13:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:46:38 --> CSRF cookie sent
INFO - 2018-07-31 13:46:38 --> Input Class Initialized
INFO - 2018-07-31 13:46:38 --> Language Class Initialized
INFO - 2018-07-31 13:46:38 --> Loader Class Initialized
INFO - 2018-07-31 13:46:38 --> Helper loaded: url_helper
INFO - 2018-07-31 13:46:38 --> Helper loaded: form_helper
INFO - 2018-07-31 13:46:38 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:46:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:46:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:46:38 --> User Agent Class Initialized
INFO - 2018-07-31 13:46:38 --> Controller Class Initialized
INFO - 2018-07-31 13:46:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:46:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:46:38 --> Pixel_Model class loaded
INFO - 2018-07-31 13:46:38 --> Database Driver Class Initialized
INFO - 2018-07-31 13:46:38 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:46:38 --> Database Driver Class Initialized
INFO - 2018-07-31 13:46:38 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:46:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:46:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:46:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:46:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:46:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:46:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:46:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:46:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/have_drugs.php
INFO - 2018-07-31 13:46:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:46:38 --> Final output sent to browser
DEBUG - 2018-07-31 13:46:38 --> Total execution time: 0.0427
INFO - 2018-07-31 13:46:39 --> Config Class Initialized
INFO - 2018-07-31 13:46:39 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:46:39 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:46:39 --> Utf8 Class Initialized
INFO - 2018-07-31 13:46:39 --> URI Class Initialized
INFO - 2018-07-31 13:46:39 --> Router Class Initialized
INFO - 2018-07-31 13:46:39 --> Output Class Initialized
INFO - 2018-07-31 13:46:39 --> Security Class Initialized
DEBUG - 2018-07-31 13:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:46:39 --> CSRF cookie sent
INFO - 2018-07-31 13:46:39 --> Input Class Initialized
INFO - 2018-07-31 13:46:39 --> Language Class Initialized
INFO - 2018-07-31 13:46:39 --> Loader Class Initialized
INFO - 2018-07-31 13:46:39 --> Helper loaded: url_helper
INFO - 2018-07-31 13:46:39 --> Helper loaded: form_helper
INFO - 2018-07-31 13:46:39 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:46:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:46:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:46:39 --> User Agent Class Initialized
INFO - 2018-07-31 13:46:39 --> Controller Class Initialized
INFO - 2018-07-31 13:46:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:46:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:46:39 --> Pixel_Model class loaded
INFO - 2018-07-31 13:46:39 --> Database Driver Class Initialized
INFO - 2018-07-31 13:46:39 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:46:39 --> Database Driver Class Initialized
INFO - 2018-07-31 13:46:39 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:46:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:46:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:46:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:46:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:46:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:46:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:46:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:46:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/alcoholic_drinks_per_week.php
INFO - 2018-07-31 13:46:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:46:39 --> Final output sent to browser
DEBUG - 2018-07-31 13:46:39 --> Total execution time: 0.0450
INFO - 2018-07-31 13:46:39 --> Config Class Initialized
INFO - 2018-07-31 13:46:39 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:46:39 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:46:39 --> Utf8 Class Initialized
INFO - 2018-07-31 13:46:39 --> URI Class Initialized
INFO - 2018-07-31 13:46:39 --> Router Class Initialized
INFO - 2018-07-31 13:46:39 --> Output Class Initialized
INFO - 2018-07-31 13:46:39 --> Security Class Initialized
DEBUG - 2018-07-31 13:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:46:39 --> CSRF cookie sent
INFO - 2018-07-31 13:46:39 --> Input Class Initialized
INFO - 2018-07-31 13:46:39 --> Language Class Initialized
INFO - 2018-07-31 13:46:39 --> Loader Class Initialized
INFO - 2018-07-31 13:46:39 --> Helper loaded: url_helper
INFO - 2018-07-31 13:46:39 --> Helper loaded: form_helper
INFO - 2018-07-31 13:46:39 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:46:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:46:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:46:39 --> User Agent Class Initialized
INFO - 2018-07-31 13:46:39 --> Controller Class Initialized
INFO - 2018-07-31 13:46:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:46:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:46:39 --> Pixel_Model class loaded
INFO - 2018-07-31 13:46:39 --> Database Driver Class Initialized
INFO - 2018-07-31 13:46:39 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:46:39 --> Database Driver Class Initialized
INFO - 2018-07-31 13:46:39 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:46:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:46:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:46:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:46:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:46:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:46:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:46:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:46:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/s_nights_without_you.php
INFO - 2018-07-31 13:46:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:46:39 --> Final output sent to browser
DEBUG - 2018-07-31 13:46:39 --> Total execution time: 0.0525
INFO - 2018-07-31 13:46:40 --> Config Class Initialized
INFO - 2018-07-31 13:46:40 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:46:40 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:46:40 --> Utf8 Class Initialized
INFO - 2018-07-31 13:46:40 --> URI Class Initialized
INFO - 2018-07-31 13:46:40 --> Router Class Initialized
INFO - 2018-07-31 13:46:40 --> Output Class Initialized
INFO - 2018-07-31 13:46:40 --> Security Class Initialized
DEBUG - 2018-07-31 13:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:46:40 --> CSRF cookie sent
INFO - 2018-07-31 13:46:40 --> Input Class Initialized
INFO - 2018-07-31 13:46:40 --> Language Class Initialized
INFO - 2018-07-31 13:46:40 --> Loader Class Initialized
INFO - 2018-07-31 13:46:40 --> Helper loaded: url_helper
INFO - 2018-07-31 13:46:40 --> Helper loaded: form_helper
INFO - 2018-07-31 13:46:40 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:46:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:46:40 --> User Agent Class Initialized
INFO - 2018-07-31 13:46:40 --> Controller Class Initialized
INFO - 2018-07-31 13:46:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:46:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:46:40 --> Pixel_Model class loaded
INFO - 2018-07-31 13:46:40 --> Database Driver Class Initialized
INFO - 2018-07-31 13:46:40 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:46:40 --> Database Driver Class Initialized
INFO - 2018-07-31 13:46:40 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:46:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:46:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:46:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:46:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:46:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:46:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:46:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:46:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/s_nights_not_home.php
INFO - 2018-07-31 13:46:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:46:40 --> Final output sent to browser
DEBUG - 2018-07-31 13:46:40 --> Total execution time: 0.0532
INFO - 2018-07-31 13:46:41 --> Config Class Initialized
INFO - 2018-07-31 13:46:41 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:46:41 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:46:41 --> Utf8 Class Initialized
INFO - 2018-07-31 13:46:41 --> URI Class Initialized
INFO - 2018-07-31 13:46:41 --> Router Class Initialized
INFO - 2018-07-31 13:46:41 --> Output Class Initialized
INFO - 2018-07-31 13:46:41 --> Security Class Initialized
DEBUG - 2018-07-31 13:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:46:41 --> CSRF cookie sent
INFO - 2018-07-31 13:46:41 --> Input Class Initialized
INFO - 2018-07-31 13:46:41 --> Language Class Initialized
INFO - 2018-07-31 13:46:41 --> Loader Class Initialized
INFO - 2018-07-31 13:46:41 --> Helper loaded: url_helper
INFO - 2018-07-31 13:46:41 --> Helper loaded: form_helper
INFO - 2018-07-31 13:46:41 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:46:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:46:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:46:41 --> User Agent Class Initialized
INFO - 2018-07-31 13:46:41 --> Controller Class Initialized
INFO - 2018-07-31 13:46:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:46:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:46:41 --> Pixel_Model class loaded
INFO - 2018-07-31 13:46:41 --> Database Driver Class Initialized
INFO - 2018-07-31 13:46:41 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:46:41 --> Database Driver Class Initialized
INFO - 2018-07-31 13:46:41 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:46:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:46:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:46:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:46:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:46:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:46:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:46:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:46:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/nights_not_home.php
INFO - 2018-07-31 13:46:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:46:41 --> Final output sent to browser
DEBUG - 2018-07-31 13:46:41 --> Total execution time: 0.0473
INFO - 2018-07-31 13:46:42 --> Config Class Initialized
INFO - 2018-07-31 13:46:42 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:46:42 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:46:42 --> Utf8 Class Initialized
INFO - 2018-07-31 13:46:42 --> URI Class Initialized
INFO - 2018-07-31 13:46:42 --> Router Class Initialized
INFO - 2018-07-31 13:46:42 --> Output Class Initialized
INFO - 2018-07-31 13:46:42 --> Security Class Initialized
DEBUG - 2018-07-31 13:46:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:46:42 --> CSRF cookie sent
INFO - 2018-07-31 13:46:42 --> Input Class Initialized
INFO - 2018-07-31 13:46:42 --> Language Class Initialized
INFO - 2018-07-31 13:46:42 --> Loader Class Initialized
INFO - 2018-07-31 13:46:42 --> Helper loaded: url_helper
INFO - 2018-07-31 13:46:42 --> Helper loaded: form_helper
INFO - 2018-07-31 13:46:42 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:46:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:46:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:46:42 --> User Agent Class Initialized
INFO - 2018-07-31 13:46:42 --> Controller Class Initialized
INFO - 2018-07-31 13:46:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:46:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:46:42 --> Pixel_Model class loaded
INFO - 2018-07-31 13:46:42 --> Database Driver Class Initialized
INFO - 2018-07-31 13:46:42 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:46:42 --> Database Driver Class Initialized
INFO - 2018-07-31 13:46:42 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:46:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:46:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:46:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:46:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:46:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:46:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:46:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:46:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/have_date.php
INFO - 2018-07-31 13:46:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:46:42 --> Final output sent to browser
DEBUG - 2018-07-31 13:46:42 --> Total execution time: 0.0450
INFO - 2018-07-31 13:46:42 --> Config Class Initialized
INFO - 2018-07-31 13:46:42 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:46:42 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:46:42 --> Utf8 Class Initialized
INFO - 2018-07-31 13:46:42 --> URI Class Initialized
INFO - 2018-07-31 13:46:42 --> Router Class Initialized
INFO - 2018-07-31 13:46:42 --> Output Class Initialized
INFO - 2018-07-31 13:46:42 --> Security Class Initialized
DEBUG - 2018-07-31 13:46:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:46:42 --> CSRF cookie sent
INFO - 2018-07-31 13:46:42 --> Input Class Initialized
INFO - 2018-07-31 13:46:42 --> Language Class Initialized
INFO - 2018-07-31 13:46:42 --> Loader Class Initialized
INFO - 2018-07-31 13:46:42 --> Helper loaded: url_helper
INFO - 2018-07-31 13:46:42 --> Helper loaded: form_helper
INFO - 2018-07-31 13:46:42 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:46:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:46:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:46:42 --> User Agent Class Initialized
INFO - 2018-07-31 13:46:42 --> Controller Class Initialized
INFO - 2018-07-31 13:46:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:46:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:46:42 --> Pixel_Model class loaded
INFO - 2018-07-31 13:46:42 --> Database Driver Class Initialized
INFO - 2018-07-31 13:46:42 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:46:42 --> Database Driver Class Initialized
INFO - 2018-07-31 13:46:42 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:46:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:46:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:46:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:46:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:46:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:46:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:46:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:46:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/night_without_s.php
INFO - 2018-07-31 13:46:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:46:42 --> Final output sent to browser
DEBUG - 2018-07-31 13:46:42 --> Total execution time: 0.0464
INFO - 2018-07-31 13:46:44 --> Config Class Initialized
INFO - 2018-07-31 13:46:44 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:46:44 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:46:44 --> Utf8 Class Initialized
INFO - 2018-07-31 13:46:44 --> URI Class Initialized
INFO - 2018-07-31 13:46:44 --> Router Class Initialized
INFO - 2018-07-31 13:46:44 --> Output Class Initialized
INFO - 2018-07-31 13:46:44 --> Security Class Initialized
DEBUG - 2018-07-31 13:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:46:44 --> CSRF cookie sent
INFO - 2018-07-31 13:46:44 --> Input Class Initialized
INFO - 2018-07-31 13:46:44 --> Language Class Initialized
INFO - 2018-07-31 13:46:44 --> Loader Class Initialized
INFO - 2018-07-31 13:46:44 --> Helper loaded: url_helper
INFO - 2018-07-31 13:46:44 --> Helper loaded: form_helper
INFO - 2018-07-31 13:46:44 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:46:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:46:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:46:44 --> User Agent Class Initialized
INFO - 2018-07-31 13:46:44 --> Controller Class Initialized
INFO - 2018-07-31 13:46:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:46:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:46:44 --> Pixel_Model class loaded
INFO - 2018-07-31 13:46:44 --> Database Driver Class Initialized
INFO - 2018-07-31 13:46:44 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:46:44 --> Database Driver Class Initialized
INFO - 2018-07-31 13:46:44 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:46:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:46:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:46:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:46:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:46:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:46:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:46:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:46:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/shift_work.php
INFO - 2018-07-31 13:46:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:46:44 --> Final output sent to browser
DEBUG - 2018-07-31 13:46:44 --> Total execution time: 0.0603
INFO - 2018-07-31 13:46:45 --> Config Class Initialized
INFO - 2018-07-31 13:46:45 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:46:45 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:46:45 --> Utf8 Class Initialized
INFO - 2018-07-31 13:46:45 --> URI Class Initialized
INFO - 2018-07-31 13:46:45 --> Router Class Initialized
INFO - 2018-07-31 13:46:45 --> Output Class Initialized
INFO - 2018-07-31 13:46:45 --> Security Class Initialized
DEBUG - 2018-07-31 13:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:46:45 --> CSRF cookie sent
INFO - 2018-07-31 13:46:45 --> Input Class Initialized
INFO - 2018-07-31 13:46:45 --> Language Class Initialized
INFO - 2018-07-31 13:46:45 --> Loader Class Initialized
INFO - 2018-07-31 13:46:45 --> Helper loaded: url_helper
INFO - 2018-07-31 13:46:45 --> Helper loaded: form_helper
INFO - 2018-07-31 13:46:45 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:46:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:46:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:46:45 --> User Agent Class Initialized
INFO - 2018-07-31 13:46:45 --> Controller Class Initialized
INFO - 2018-07-31 13:46:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:46:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:46:45 --> Pixel_Model class loaded
INFO - 2018-07-31 13:46:45 --> Database Driver Class Initialized
INFO - 2018-07-31 13:46:45 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:46:45 --> Database Driver Class Initialized
INFO - 2018-07-31 13:46:45 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:46:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:46:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:46:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:46:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:46:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:46:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:46:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:46:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inherited_income.php
INFO - 2018-07-31 13:46:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:46:45 --> Final output sent to browser
DEBUG - 2018-07-31 13:46:45 --> Total execution time: 0.0636
INFO - 2018-07-31 13:46:47 --> Config Class Initialized
INFO - 2018-07-31 13:46:47 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:46:47 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:46:47 --> Utf8 Class Initialized
INFO - 2018-07-31 13:46:47 --> URI Class Initialized
INFO - 2018-07-31 13:46:47 --> Router Class Initialized
INFO - 2018-07-31 13:46:47 --> Output Class Initialized
INFO - 2018-07-31 13:46:47 --> Security Class Initialized
DEBUG - 2018-07-31 13:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:46:47 --> CSRF cookie sent
INFO - 2018-07-31 13:46:47 --> Input Class Initialized
INFO - 2018-07-31 13:46:47 --> Language Class Initialized
INFO - 2018-07-31 13:46:47 --> Loader Class Initialized
INFO - 2018-07-31 13:46:47 --> Helper loaded: url_helper
INFO - 2018-07-31 13:46:47 --> Helper loaded: form_helper
INFO - 2018-07-31 13:46:47 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:46:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:46:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:46:47 --> User Agent Class Initialized
INFO - 2018-07-31 13:46:47 --> Controller Class Initialized
INFO - 2018-07-31 13:46:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:46:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:46:47 --> Pixel_Model class loaded
INFO - 2018-07-31 13:46:47 --> Database Driver Class Initialized
INFO - 2018-07-31 13:46:47 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:46:47 --> Database Driver Class Initialized
INFO - 2018-07-31 13:46:47 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:46:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:46:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:46:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:46:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:46:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:46:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:46:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:46:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/trust_info.php
INFO - 2018-07-31 13:46:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:46:47 --> Final output sent to browser
DEBUG - 2018-07-31 13:46:47 --> Total execution time: 0.0538
INFO - 2018-07-31 13:46:52 --> Config Class Initialized
INFO - 2018-07-31 13:46:52 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:46:52 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:46:52 --> Utf8 Class Initialized
INFO - 2018-07-31 13:46:52 --> URI Class Initialized
INFO - 2018-07-31 13:46:52 --> Router Class Initialized
INFO - 2018-07-31 13:46:52 --> Output Class Initialized
INFO - 2018-07-31 13:46:52 --> Security Class Initialized
DEBUG - 2018-07-31 13:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:46:52 --> CSRF cookie sent
INFO - 2018-07-31 13:46:52 --> Input Class Initialized
INFO - 2018-07-31 13:46:52 --> Language Class Initialized
INFO - 2018-07-31 13:46:52 --> Loader Class Initialized
INFO - 2018-07-31 13:46:52 --> Helper loaded: url_helper
INFO - 2018-07-31 13:46:52 --> Helper loaded: form_helper
INFO - 2018-07-31 13:46:52 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:46:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:46:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:46:52 --> User Agent Class Initialized
INFO - 2018-07-31 13:46:52 --> Controller Class Initialized
INFO - 2018-07-31 13:46:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:46:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:46:52 --> Pixel_Model class loaded
INFO - 2018-07-31 13:46:52 --> Database Driver Class Initialized
INFO - 2018-07-31 13:46:52 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:46:52 --> Database Driver Class Initialized
INFO - 2018-07-31 13:46:52 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:46:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:46:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:46:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:46:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:46:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:46:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:46:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:46:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/business_tax_info.php
INFO - 2018-07-31 13:46:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:46:52 --> Final output sent to browser
DEBUG - 2018-07-31 13:46:52 --> Total execution time: 0.0450
INFO - 2018-07-31 13:46:54 --> Config Class Initialized
INFO - 2018-07-31 13:46:54 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:46:54 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:46:54 --> Utf8 Class Initialized
INFO - 2018-07-31 13:46:54 --> URI Class Initialized
INFO - 2018-07-31 13:46:54 --> Router Class Initialized
INFO - 2018-07-31 13:46:54 --> Output Class Initialized
INFO - 2018-07-31 13:46:54 --> Security Class Initialized
DEBUG - 2018-07-31 13:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:46:54 --> CSRF cookie sent
INFO - 2018-07-31 13:46:54 --> Input Class Initialized
INFO - 2018-07-31 13:46:54 --> Language Class Initialized
INFO - 2018-07-31 13:46:54 --> Loader Class Initialized
INFO - 2018-07-31 13:46:54 --> Helper loaded: url_helper
INFO - 2018-07-31 13:46:54 --> Helper loaded: form_helper
INFO - 2018-07-31 13:46:54 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:46:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:46:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:46:54 --> User Agent Class Initialized
INFO - 2018-07-31 13:46:54 --> Controller Class Initialized
INFO - 2018-07-31 13:46:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:46:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:46:54 --> Pixel_Model class loaded
INFO - 2018-07-31 13:46:54 --> Database Driver Class Initialized
INFO - 2018-07-31 13:46:54 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:46:54 --> Database Driver Class Initialized
INFO - 2018-07-31 13:46:54 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:46:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:46:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:46:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:46:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:46:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:46:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:46:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:46:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/affectionate_salutation.php
INFO - 2018-07-31 13:46:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:46:54 --> Final output sent to browser
DEBUG - 2018-07-31 13:46:54 --> Total execution time: 0.0455
INFO - 2018-07-31 13:46:57 --> Config Class Initialized
INFO - 2018-07-31 13:46:57 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:46:57 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:46:57 --> Utf8 Class Initialized
INFO - 2018-07-31 13:46:57 --> URI Class Initialized
INFO - 2018-07-31 13:46:57 --> Router Class Initialized
INFO - 2018-07-31 13:46:57 --> Output Class Initialized
INFO - 2018-07-31 13:46:57 --> Security Class Initialized
DEBUG - 2018-07-31 13:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:46:57 --> CSRF cookie sent
INFO - 2018-07-31 13:46:57 --> Input Class Initialized
INFO - 2018-07-31 13:46:57 --> Language Class Initialized
INFO - 2018-07-31 13:46:57 --> Loader Class Initialized
INFO - 2018-07-31 13:46:57 --> Helper loaded: url_helper
INFO - 2018-07-31 13:46:57 --> Helper loaded: form_helper
INFO - 2018-07-31 13:46:57 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:46:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:46:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:46:57 --> User Agent Class Initialized
INFO - 2018-07-31 13:46:57 --> Controller Class Initialized
INFO - 2018-07-31 13:46:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:46:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:46:57 --> Pixel_Model class loaded
INFO - 2018-07-31 13:46:57 --> Database Driver Class Initialized
INFO - 2018-07-31 13:46:57 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:46:57 --> Database Driver Class Initialized
INFO - 2018-07-31 13:46:57 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:46:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:46:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:46:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:46:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:46:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:46:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:46:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:46:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/spouse_job.php
INFO - 2018-07-31 13:46:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:46:57 --> Final output sent to browser
DEBUG - 2018-07-31 13:46:57 --> Total execution time: 0.0486
INFO - 2018-07-31 13:49:23 --> Config Class Initialized
INFO - 2018-07-31 13:49:23 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:49:23 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:49:23 --> Utf8 Class Initialized
INFO - 2018-07-31 13:49:23 --> URI Class Initialized
INFO - 2018-07-31 13:49:23 --> Router Class Initialized
INFO - 2018-07-31 13:49:23 --> Output Class Initialized
INFO - 2018-07-31 13:49:23 --> Security Class Initialized
DEBUG - 2018-07-31 13:49:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:49:23 --> CSRF cookie sent
INFO - 2018-07-31 13:49:23 --> Input Class Initialized
INFO - 2018-07-31 13:49:23 --> Language Class Initialized
INFO - 2018-07-31 13:49:23 --> Loader Class Initialized
INFO - 2018-07-31 13:49:23 --> Helper loaded: url_helper
INFO - 2018-07-31 13:49:23 --> Helper loaded: form_helper
INFO - 2018-07-31 13:49:23 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:49:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:49:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:49:23 --> User Agent Class Initialized
INFO - 2018-07-31 13:49:23 --> Controller Class Initialized
INFO - 2018-07-31 13:49:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:49:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:49:23 --> Pixel_Model class loaded
INFO - 2018-07-31 13:49:23 --> Database Driver Class Initialized
INFO - 2018-07-31 13:49:23 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:49:23 --> Database Driver Class Initialized
INFO - 2018-07-31 13:49:23 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:49:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:49:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:49:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:49:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:49:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:49:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:49:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:49:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/affectionate_salutation.php
INFO - 2018-07-31 13:49:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:49:23 --> Final output sent to browser
DEBUG - 2018-07-31 13:49:23 --> Total execution time: 0.0479
INFO - 2018-07-31 13:49:25 --> Config Class Initialized
INFO - 2018-07-31 13:49:25 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:49:25 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:49:25 --> Utf8 Class Initialized
INFO - 2018-07-31 13:49:25 --> URI Class Initialized
INFO - 2018-07-31 13:49:25 --> Router Class Initialized
INFO - 2018-07-31 13:49:25 --> Output Class Initialized
INFO - 2018-07-31 13:49:25 --> Security Class Initialized
DEBUG - 2018-07-31 13:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:49:25 --> CSRF cookie sent
INFO - 2018-07-31 13:49:25 --> Input Class Initialized
INFO - 2018-07-31 13:49:25 --> Language Class Initialized
INFO - 2018-07-31 13:49:25 --> Loader Class Initialized
INFO - 2018-07-31 13:49:25 --> Helper loaded: url_helper
INFO - 2018-07-31 13:49:25 --> Helper loaded: form_helper
INFO - 2018-07-31 13:49:25 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:49:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:49:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:49:25 --> User Agent Class Initialized
INFO - 2018-07-31 13:49:25 --> Controller Class Initialized
INFO - 2018-07-31 13:49:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:49:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:49:25 --> Pixel_Model class loaded
INFO - 2018-07-31 13:49:25 --> Database Driver Class Initialized
INFO - 2018-07-31 13:49:25 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:49:25 --> Database Driver Class Initialized
INFO - 2018-07-31 13:49:25 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:49:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:49:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:49:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:49:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:49:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:49:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:49:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:49:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/business_tax_info.php
INFO - 2018-07-31 13:49:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:49:25 --> Final output sent to browser
DEBUG - 2018-07-31 13:49:25 --> Total execution time: 0.0431
INFO - 2018-07-31 13:49:27 --> Config Class Initialized
INFO - 2018-07-31 13:49:27 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:49:27 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:49:27 --> Utf8 Class Initialized
INFO - 2018-07-31 13:49:27 --> URI Class Initialized
INFO - 2018-07-31 13:49:27 --> Router Class Initialized
INFO - 2018-07-31 13:49:27 --> Output Class Initialized
INFO - 2018-07-31 13:49:27 --> Security Class Initialized
DEBUG - 2018-07-31 13:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:49:27 --> CSRF cookie sent
INFO - 2018-07-31 13:49:27 --> Input Class Initialized
INFO - 2018-07-31 13:49:27 --> Language Class Initialized
INFO - 2018-07-31 13:49:27 --> Loader Class Initialized
INFO - 2018-07-31 13:49:27 --> Helper loaded: url_helper
INFO - 2018-07-31 13:49:27 --> Helper loaded: form_helper
INFO - 2018-07-31 13:49:27 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:49:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:49:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:49:27 --> User Agent Class Initialized
INFO - 2018-07-31 13:49:27 --> Controller Class Initialized
INFO - 2018-07-31 13:49:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:49:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:49:27 --> Pixel_Model class loaded
INFO - 2018-07-31 13:49:27 --> Database Driver Class Initialized
INFO - 2018-07-31 13:49:27 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:49:27 --> Database Driver Class Initialized
INFO - 2018-07-31 13:49:27 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:49:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:49:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:49:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:49:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:49:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:49:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:49:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:49:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/trust_info.php
INFO - 2018-07-31 13:49:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:49:27 --> Final output sent to browser
DEBUG - 2018-07-31 13:49:27 --> Total execution time: 0.0491
INFO - 2018-07-31 13:49:28 --> Config Class Initialized
INFO - 2018-07-31 13:49:28 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:49:28 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:49:28 --> Utf8 Class Initialized
INFO - 2018-07-31 13:49:28 --> URI Class Initialized
INFO - 2018-07-31 13:49:28 --> Router Class Initialized
INFO - 2018-07-31 13:49:28 --> Output Class Initialized
INFO - 2018-07-31 13:49:28 --> Security Class Initialized
DEBUG - 2018-07-31 13:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:49:28 --> CSRF cookie sent
INFO - 2018-07-31 13:49:28 --> Input Class Initialized
INFO - 2018-07-31 13:49:28 --> Language Class Initialized
INFO - 2018-07-31 13:49:28 --> Loader Class Initialized
INFO - 2018-07-31 13:49:28 --> Helper loaded: url_helper
INFO - 2018-07-31 13:49:28 --> Helper loaded: form_helper
INFO - 2018-07-31 13:49:28 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:49:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:49:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:49:28 --> User Agent Class Initialized
INFO - 2018-07-31 13:49:28 --> Controller Class Initialized
INFO - 2018-07-31 13:49:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:49:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:49:28 --> Pixel_Model class loaded
INFO - 2018-07-31 13:49:28 --> Database Driver Class Initialized
INFO - 2018-07-31 13:49:28 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:49:28 --> Database Driver Class Initialized
INFO - 2018-07-31 13:49:28 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:49:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:49:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:49:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:49:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:49:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:49:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:49:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:49:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inherited_income.php
INFO - 2018-07-31 13:49:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:49:28 --> Final output sent to browser
DEBUG - 2018-07-31 13:49:28 --> Total execution time: 0.0432
INFO - 2018-07-31 13:49:29 --> Config Class Initialized
INFO - 2018-07-31 13:49:29 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:49:29 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:49:29 --> Utf8 Class Initialized
INFO - 2018-07-31 13:49:29 --> URI Class Initialized
INFO - 2018-07-31 13:49:29 --> Router Class Initialized
INFO - 2018-07-31 13:49:29 --> Output Class Initialized
INFO - 2018-07-31 13:49:29 --> Security Class Initialized
DEBUG - 2018-07-31 13:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:49:29 --> CSRF cookie sent
INFO - 2018-07-31 13:49:29 --> Input Class Initialized
INFO - 2018-07-31 13:49:29 --> Language Class Initialized
INFO - 2018-07-31 13:49:29 --> Loader Class Initialized
INFO - 2018-07-31 13:49:29 --> Helper loaded: url_helper
INFO - 2018-07-31 13:49:29 --> Helper loaded: form_helper
INFO - 2018-07-31 13:49:29 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:49:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:49:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:49:29 --> User Agent Class Initialized
INFO - 2018-07-31 13:49:29 --> Controller Class Initialized
INFO - 2018-07-31 13:49:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:49:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:49:29 --> Pixel_Model class loaded
INFO - 2018-07-31 13:49:29 --> Database Driver Class Initialized
INFO - 2018-07-31 13:49:29 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:49:29 --> Database Driver Class Initialized
INFO - 2018-07-31 13:49:29 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:49:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:49:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:49:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:49:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:49:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:49:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:49:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:49:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/shift_work.php
INFO - 2018-07-31 13:49:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:49:29 --> Final output sent to browser
DEBUG - 2018-07-31 13:49:29 --> Total execution time: 0.0423
INFO - 2018-07-31 13:49:31 --> Config Class Initialized
INFO - 2018-07-31 13:49:31 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:49:31 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:49:31 --> Utf8 Class Initialized
INFO - 2018-07-31 13:49:31 --> URI Class Initialized
INFO - 2018-07-31 13:49:31 --> Router Class Initialized
INFO - 2018-07-31 13:49:31 --> Output Class Initialized
INFO - 2018-07-31 13:49:31 --> Security Class Initialized
DEBUG - 2018-07-31 13:49:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:49:31 --> CSRF cookie sent
INFO - 2018-07-31 13:49:31 --> Input Class Initialized
INFO - 2018-07-31 13:49:31 --> Language Class Initialized
INFO - 2018-07-31 13:49:31 --> Loader Class Initialized
INFO - 2018-07-31 13:49:31 --> Helper loaded: url_helper
INFO - 2018-07-31 13:49:31 --> Helper loaded: form_helper
INFO - 2018-07-31 13:49:31 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:49:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:49:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:49:31 --> User Agent Class Initialized
INFO - 2018-07-31 13:49:31 --> Controller Class Initialized
INFO - 2018-07-31 13:49:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:49:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:49:31 --> Pixel_Model class loaded
INFO - 2018-07-31 13:49:31 --> Database Driver Class Initialized
INFO - 2018-07-31 13:49:31 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:49:31 --> Database Driver Class Initialized
INFO - 2018-07-31 13:49:31 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:49:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:49:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:49:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:49:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:49:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:49:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:49:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:49:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/night_without_s.php
INFO - 2018-07-31 13:49:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:49:31 --> Final output sent to browser
DEBUG - 2018-07-31 13:49:31 --> Total execution time: 0.0512
INFO - 2018-07-31 13:49:32 --> Config Class Initialized
INFO - 2018-07-31 13:49:32 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:49:32 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:49:32 --> Utf8 Class Initialized
INFO - 2018-07-31 13:49:32 --> URI Class Initialized
INFO - 2018-07-31 13:49:32 --> Router Class Initialized
INFO - 2018-07-31 13:49:32 --> Output Class Initialized
INFO - 2018-07-31 13:49:32 --> Security Class Initialized
DEBUG - 2018-07-31 13:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:49:32 --> CSRF cookie sent
INFO - 2018-07-31 13:49:32 --> Input Class Initialized
INFO - 2018-07-31 13:49:32 --> Language Class Initialized
INFO - 2018-07-31 13:49:32 --> Loader Class Initialized
INFO - 2018-07-31 13:49:32 --> Helper loaded: url_helper
INFO - 2018-07-31 13:49:32 --> Helper loaded: form_helper
INFO - 2018-07-31 13:49:32 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:49:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:49:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:49:32 --> User Agent Class Initialized
INFO - 2018-07-31 13:49:32 --> Controller Class Initialized
INFO - 2018-07-31 13:49:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:49:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:49:32 --> Pixel_Model class loaded
INFO - 2018-07-31 13:49:32 --> Database Driver Class Initialized
INFO - 2018-07-31 13:49:32 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:49:32 --> Database Driver Class Initialized
INFO - 2018-07-31 13:49:32 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:49:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:49:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:49:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:49:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:49:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:49:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:49:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:49:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/have_date.php
INFO - 2018-07-31 13:49:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:49:32 --> Final output sent to browser
DEBUG - 2018-07-31 13:49:32 --> Total execution time: 0.0355
INFO - 2018-07-31 13:49:32 --> Config Class Initialized
INFO - 2018-07-31 13:49:32 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:49:32 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:49:32 --> Utf8 Class Initialized
INFO - 2018-07-31 13:49:32 --> URI Class Initialized
INFO - 2018-07-31 13:49:32 --> Router Class Initialized
INFO - 2018-07-31 13:49:32 --> Output Class Initialized
INFO - 2018-07-31 13:49:32 --> Security Class Initialized
DEBUG - 2018-07-31 13:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:49:32 --> CSRF cookie sent
INFO - 2018-07-31 13:49:32 --> Input Class Initialized
INFO - 2018-07-31 13:49:32 --> Language Class Initialized
INFO - 2018-07-31 13:49:32 --> Loader Class Initialized
INFO - 2018-07-31 13:49:32 --> Helper loaded: url_helper
INFO - 2018-07-31 13:49:32 --> Helper loaded: form_helper
INFO - 2018-07-31 13:49:32 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:49:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:49:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:49:32 --> User Agent Class Initialized
INFO - 2018-07-31 13:49:32 --> Controller Class Initialized
INFO - 2018-07-31 13:49:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:49:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:49:32 --> Pixel_Model class loaded
INFO - 2018-07-31 13:49:32 --> Database Driver Class Initialized
INFO - 2018-07-31 13:49:32 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:49:32 --> Database Driver Class Initialized
INFO - 2018-07-31 13:49:32 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:49:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:49:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:49:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:49:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:49:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:49:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:49:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:49:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/nights_not_home.php
INFO - 2018-07-31 13:49:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:49:32 --> Final output sent to browser
DEBUG - 2018-07-31 13:49:32 --> Total execution time: 0.0516
INFO - 2018-07-31 13:49:33 --> Config Class Initialized
INFO - 2018-07-31 13:49:33 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:49:33 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:49:33 --> Utf8 Class Initialized
INFO - 2018-07-31 13:49:33 --> URI Class Initialized
INFO - 2018-07-31 13:49:33 --> Router Class Initialized
INFO - 2018-07-31 13:49:33 --> Output Class Initialized
INFO - 2018-07-31 13:49:33 --> Security Class Initialized
DEBUG - 2018-07-31 13:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:49:33 --> CSRF cookie sent
INFO - 2018-07-31 13:49:33 --> Input Class Initialized
INFO - 2018-07-31 13:49:33 --> Language Class Initialized
INFO - 2018-07-31 13:49:33 --> Loader Class Initialized
INFO - 2018-07-31 13:49:33 --> Helper loaded: url_helper
INFO - 2018-07-31 13:49:33 --> Helper loaded: form_helper
INFO - 2018-07-31 13:49:33 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:49:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:49:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:49:33 --> User Agent Class Initialized
INFO - 2018-07-31 13:49:33 --> Controller Class Initialized
INFO - 2018-07-31 13:49:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:49:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:49:33 --> Pixel_Model class loaded
INFO - 2018-07-31 13:49:33 --> Database Driver Class Initialized
INFO - 2018-07-31 13:49:33 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:49:33 --> Database Driver Class Initialized
INFO - 2018-07-31 13:49:33 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:49:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:49:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:49:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:49:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:49:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:49:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:49:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:49:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/s_nights_not_home.php
INFO - 2018-07-31 13:49:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:49:33 --> Final output sent to browser
DEBUG - 2018-07-31 13:49:33 --> Total execution time: 0.0379
INFO - 2018-07-31 13:49:34 --> Config Class Initialized
INFO - 2018-07-31 13:49:34 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:49:34 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:49:34 --> Utf8 Class Initialized
INFO - 2018-07-31 13:49:34 --> URI Class Initialized
INFO - 2018-07-31 13:49:34 --> Router Class Initialized
INFO - 2018-07-31 13:49:34 --> Output Class Initialized
INFO - 2018-07-31 13:49:34 --> Security Class Initialized
DEBUG - 2018-07-31 13:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:49:34 --> CSRF cookie sent
INFO - 2018-07-31 13:49:34 --> Input Class Initialized
INFO - 2018-07-31 13:49:34 --> Language Class Initialized
INFO - 2018-07-31 13:49:34 --> Loader Class Initialized
INFO - 2018-07-31 13:49:34 --> Helper loaded: url_helper
INFO - 2018-07-31 13:49:34 --> Helper loaded: form_helper
INFO - 2018-07-31 13:49:34 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:49:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:49:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:49:34 --> User Agent Class Initialized
INFO - 2018-07-31 13:49:34 --> Controller Class Initialized
INFO - 2018-07-31 13:49:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:49:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:49:34 --> Pixel_Model class loaded
INFO - 2018-07-31 13:49:34 --> Database Driver Class Initialized
INFO - 2018-07-31 13:49:34 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:49:34 --> Database Driver Class Initialized
INFO - 2018-07-31 13:49:34 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:49:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:49:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:49:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:49:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:49:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:49:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:49:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:49:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/s_nights_without_you.php
INFO - 2018-07-31 13:49:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:49:34 --> Final output sent to browser
DEBUG - 2018-07-31 13:49:34 --> Total execution time: 0.0506
INFO - 2018-07-31 13:49:35 --> Config Class Initialized
INFO - 2018-07-31 13:49:35 --> Hooks Class Initialized
DEBUG - 2018-07-31 13:49:35 --> UTF-8 Support Enabled
INFO - 2018-07-31 13:49:35 --> Utf8 Class Initialized
INFO - 2018-07-31 13:49:35 --> URI Class Initialized
INFO - 2018-07-31 13:49:35 --> Router Class Initialized
INFO - 2018-07-31 13:49:35 --> Output Class Initialized
INFO - 2018-07-31 13:49:35 --> Security Class Initialized
DEBUG - 2018-07-31 13:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 13:49:35 --> CSRF cookie sent
INFO - 2018-07-31 13:49:35 --> Input Class Initialized
INFO - 2018-07-31 13:49:35 --> Language Class Initialized
INFO - 2018-07-31 13:49:35 --> Loader Class Initialized
INFO - 2018-07-31 13:49:35 --> Helper loaded: url_helper
INFO - 2018-07-31 13:49:35 --> Helper loaded: form_helper
INFO - 2018-07-31 13:49:35 --> Helper loaded: language_helper
DEBUG - 2018-07-31 13:49:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 13:49:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 13:49:35 --> User Agent Class Initialized
INFO - 2018-07-31 13:49:35 --> Controller Class Initialized
INFO - 2018-07-31 13:49:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 13:49:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 13:49:35 --> Pixel_Model class loaded
INFO - 2018-07-31 13:49:35 --> Database Driver Class Initialized
INFO - 2018-07-31 13:49:35 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:49:35 --> Database Driver Class Initialized
INFO - 2018-07-31 13:49:35 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 13:49:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 13:49:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-07-31 13:49:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 13:49:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 13:49:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 13:49:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 13:49:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 13:49:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/alcoholic_drinks_per_week.php
INFO - 2018-07-31 13:49:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 13:49:35 --> Final output sent to browser
DEBUG - 2018-07-31 13:49:35 --> Total execution time: 0.0519
INFO - 2018-07-31 15:42:43 --> Config Class Initialized
INFO - 2018-07-31 15:42:43 --> Hooks Class Initialized
DEBUG - 2018-07-31 15:42:43 --> UTF-8 Support Enabled
INFO - 2018-07-31 15:42:43 --> Utf8 Class Initialized
INFO - 2018-07-31 15:42:43 --> URI Class Initialized
INFO - 2018-07-31 15:42:43 --> Router Class Initialized
INFO - 2018-07-31 15:42:43 --> Output Class Initialized
INFO - 2018-07-31 15:42:43 --> Security Class Initialized
DEBUG - 2018-07-31 15:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 15:42:43 --> CSRF cookie sent
INFO - 2018-07-31 15:42:43 --> Input Class Initialized
INFO - 2018-07-31 15:42:43 --> Language Class Initialized
INFO - 2018-07-31 15:42:43 --> Loader Class Initialized
INFO - 2018-07-31 15:42:43 --> Helper loaded: url_helper
INFO - 2018-07-31 15:42:43 --> Helper loaded: form_helper
INFO - 2018-07-31 15:42:43 --> Helper loaded: language_helper
DEBUG - 2018-07-31 15:42:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 15:42:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 15:42:43 --> User Agent Class Initialized
INFO - 2018-07-31 15:42:43 --> Controller Class Initialized
INFO - 2018-07-31 15:42:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 15:42:43 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-31 15:42:43 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-31 15:42:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 15:42:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 15:42:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 15:42:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-31 15:42:43 --> Could not find the language line "req_email"
INFO - 2018-07-31 15:42:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-31 15:42:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 15:42:43 --> Final output sent to browser
DEBUG - 2018-07-31 15:42:43 --> Total execution time: 0.0473
INFO - 2018-07-31 16:54:21 --> Config Class Initialized
INFO - 2018-07-31 16:54:21 --> Hooks Class Initialized
DEBUG - 2018-07-31 16:54:21 --> UTF-8 Support Enabled
INFO - 2018-07-31 16:54:21 --> Utf8 Class Initialized
INFO - 2018-07-31 16:54:21 --> URI Class Initialized
DEBUG - 2018-07-31 16:54:21 --> No URI present. Default controller set.
INFO - 2018-07-31 16:54:21 --> Router Class Initialized
INFO - 2018-07-31 16:54:21 --> Output Class Initialized
INFO - 2018-07-31 16:54:21 --> Security Class Initialized
DEBUG - 2018-07-31 16:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 16:54:21 --> CSRF cookie sent
INFO - 2018-07-31 16:54:21 --> Input Class Initialized
INFO - 2018-07-31 16:54:21 --> Language Class Initialized
INFO - 2018-07-31 16:54:21 --> Loader Class Initialized
INFO - 2018-07-31 16:54:21 --> Helper loaded: url_helper
INFO - 2018-07-31 16:54:21 --> Helper loaded: form_helper
INFO - 2018-07-31 16:54:21 --> Helper loaded: language_helper
DEBUG - 2018-07-31 16:54:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 16:54:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 16:54:21 --> User Agent Class Initialized
INFO - 2018-07-31 16:54:21 --> Controller Class Initialized
INFO - 2018-07-31 16:54:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 16:54:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 16:54:21 --> Pixel_Model class loaded
INFO - 2018-07-31 16:54:21 --> Database Driver Class Initialized
INFO - 2018-07-31 16:54:21 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 16:54:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 16:54:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 16:54:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-31 16:54:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 16:54:21 --> Final output sent to browser
DEBUG - 2018-07-31 16:54:21 --> Total execution time: 0.0437
INFO - 2018-07-31 16:54:22 --> Config Class Initialized
INFO - 2018-07-31 16:54:22 --> Hooks Class Initialized
DEBUG - 2018-07-31 16:54:22 --> UTF-8 Support Enabled
INFO - 2018-07-31 16:54:22 --> Utf8 Class Initialized
INFO - 2018-07-31 16:54:22 --> URI Class Initialized
INFO - 2018-07-31 16:54:22 --> Router Class Initialized
INFO - 2018-07-31 16:54:22 --> Output Class Initialized
INFO - 2018-07-31 16:54:22 --> Security Class Initialized
DEBUG - 2018-07-31 16:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 16:54:22 --> CSRF cookie sent
INFO - 2018-07-31 16:54:22 --> Input Class Initialized
INFO - 2018-07-31 16:54:22 --> Language Class Initialized
ERROR - 2018-07-31 16:54:22 --> 404 Page Not Found: Assets/css
INFO - 2018-07-31 16:54:25 --> Config Class Initialized
INFO - 2018-07-31 16:54:25 --> Hooks Class Initialized
DEBUG - 2018-07-31 16:54:25 --> UTF-8 Support Enabled
INFO - 2018-07-31 16:54:25 --> Utf8 Class Initialized
INFO - 2018-07-31 16:54:25 --> URI Class Initialized
INFO - 2018-07-31 16:54:25 --> Router Class Initialized
INFO - 2018-07-31 16:54:25 --> Output Class Initialized
INFO - 2018-07-31 16:54:25 --> Security Class Initialized
DEBUG - 2018-07-31 16:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 16:54:25 --> CSRF cookie sent
INFO - 2018-07-31 16:54:25 --> Input Class Initialized
INFO - 2018-07-31 16:54:25 --> Language Class Initialized
INFO - 2018-07-31 16:54:25 --> Loader Class Initialized
INFO - 2018-07-31 16:54:25 --> Helper loaded: url_helper
INFO - 2018-07-31 16:54:25 --> Helper loaded: form_helper
INFO - 2018-07-31 16:54:25 --> Helper loaded: language_helper
DEBUG - 2018-07-31 16:54:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 16:54:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 16:54:25 --> User Agent Class Initialized
INFO - 2018-07-31 16:54:25 --> Controller Class Initialized
INFO - 2018-07-31 16:54:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 16:54:25 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-31 16:54:25 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-31 16:54:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 16:54:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 16:54:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 16:54:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-31 16:54:25 --> Could not find the language line "req_email"
INFO - 2018-07-31 16:54:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-31 16:54:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 16:54:25 --> Final output sent to browser
DEBUG - 2018-07-31 16:54:25 --> Total execution time: 0.0225
INFO - 2018-07-31 16:54:26 --> Config Class Initialized
INFO - 2018-07-31 16:54:26 --> Hooks Class Initialized
DEBUG - 2018-07-31 16:54:26 --> UTF-8 Support Enabled
INFO - 2018-07-31 16:54:26 --> Utf8 Class Initialized
INFO - 2018-07-31 16:54:26 --> URI Class Initialized
INFO - 2018-07-31 16:54:26 --> Router Class Initialized
INFO - 2018-07-31 16:54:26 --> Output Class Initialized
INFO - 2018-07-31 16:54:26 --> Security Class Initialized
DEBUG - 2018-07-31 16:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 16:54:26 --> CSRF cookie sent
INFO - 2018-07-31 16:54:26 --> Input Class Initialized
INFO - 2018-07-31 16:54:26 --> Language Class Initialized
ERROR - 2018-07-31 16:54:26 --> 404 Page Not Found: Assets/css
INFO - 2018-07-31 16:54:27 --> Config Class Initialized
INFO - 2018-07-31 16:54:27 --> Hooks Class Initialized
DEBUG - 2018-07-31 16:54:27 --> UTF-8 Support Enabled
INFO - 2018-07-31 16:54:27 --> Utf8 Class Initialized
INFO - 2018-07-31 16:54:27 --> URI Class Initialized
INFO - 2018-07-31 16:54:27 --> Router Class Initialized
INFO - 2018-07-31 16:54:27 --> Output Class Initialized
INFO - 2018-07-31 16:54:27 --> Security Class Initialized
DEBUG - 2018-07-31 16:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 16:54:27 --> CSRF cookie sent
INFO - 2018-07-31 16:54:27 --> Input Class Initialized
INFO - 2018-07-31 16:54:27 --> Language Class Initialized
INFO - 2018-07-31 16:54:27 --> Loader Class Initialized
INFO - 2018-07-31 16:54:27 --> Helper loaded: url_helper
INFO - 2018-07-31 16:54:27 --> Helper loaded: form_helper
INFO - 2018-07-31 16:54:27 --> Helper loaded: language_helper
DEBUG - 2018-07-31 16:54:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 16:54:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 16:54:27 --> User Agent Class Initialized
INFO - 2018-07-31 16:54:27 --> Controller Class Initialized
INFO - 2018-07-31 16:54:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 16:54:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 16:54:27 --> Pixel_Model class loaded
INFO - 2018-07-31 16:54:27 --> Database Driver Class Initialized
INFO - 2018-07-31 16:54:27 --> Model "RegistrationModel" initialized
DEBUG - 2018-07-31 16:54:27 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-31 16:54:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 16:54:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 16:54:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 16:54:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 16:54:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/temp.php
INFO - 2018-07-31 16:54:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 16:54:27 --> Final output sent to browser
DEBUG - 2018-07-31 16:54:27 --> Total execution time: 0.0528
INFO - 2018-07-31 16:54:28 --> Config Class Initialized
INFO - 2018-07-31 16:54:28 --> Hooks Class Initialized
DEBUG - 2018-07-31 16:54:28 --> UTF-8 Support Enabled
INFO - 2018-07-31 16:54:28 --> Utf8 Class Initialized
INFO - 2018-07-31 16:54:28 --> URI Class Initialized
INFO - 2018-07-31 16:54:28 --> Router Class Initialized
INFO - 2018-07-31 16:54:28 --> Output Class Initialized
INFO - 2018-07-31 16:54:28 --> Security Class Initialized
DEBUG - 2018-07-31 16:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 16:54:28 --> CSRF cookie sent
INFO - 2018-07-31 16:54:28 --> Input Class Initialized
INFO - 2018-07-31 16:54:28 --> Language Class Initialized
ERROR - 2018-07-31 16:54:28 --> 404 Page Not Found: Assets/css
INFO - 2018-07-31 17:52:55 --> Config Class Initialized
INFO - 2018-07-31 17:52:55 --> Hooks Class Initialized
DEBUG - 2018-07-31 17:52:55 --> UTF-8 Support Enabled
INFO - 2018-07-31 17:52:55 --> Utf8 Class Initialized
INFO - 2018-07-31 17:52:55 --> URI Class Initialized
DEBUG - 2018-07-31 17:52:55 --> No URI present. Default controller set.
INFO - 2018-07-31 17:52:55 --> Router Class Initialized
INFO - 2018-07-31 17:52:55 --> Output Class Initialized
INFO - 2018-07-31 17:52:55 --> Security Class Initialized
DEBUG - 2018-07-31 17:52:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 17:52:55 --> CSRF cookie sent
INFO - 2018-07-31 17:52:55 --> Input Class Initialized
INFO - 2018-07-31 17:52:55 --> Language Class Initialized
INFO - 2018-07-31 17:52:55 --> Loader Class Initialized
INFO - 2018-07-31 17:52:55 --> Helper loaded: url_helper
INFO - 2018-07-31 17:52:55 --> Helper loaded: form_helper
INFO - 2018-07-31 17:52:55 --> Helper loaded: language_helper
DEBUG - 2018-07-31 17:52:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 17:52:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 17:52:55 --> User Agent Class Initialized
INFO - 2018-07-31 17:52:55 --> Controller Class Initialized
INFO - 2018-07-31 17:52:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 17:52:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 17:52:55 --> Pixel_Model class loaded
INFO - 2018-07-31 17:52:55 --> Database Driver Class Initialized
INFO - 2018-07-31 17:52:55 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 17:52:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 17:52:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 17:52:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-31 17:52:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 17:52:55 --> Final output sent to browser
DEBUG - 2018-07-31 17:52:55 --> Total execution time: 0.0400
INFO - 2018-07-31 17:59:52 --> Config Class Initialized
INFO - 2018-07-31 17:59:52 --> Hooks Class Initialized
DEBUG - 2018-07-31 17:59:52 --> UTF-8 Support Enabled
INFO - 2018-07-31 17:59:52 --> Utf8 Class Initialized
INFO - 2018-07-31 17:59:52 --> URI Class Initialized
DEBUG - 2018-07-31 17:59:52 --> No URI present. Default controller set.
INFO - 2018-07-31 17:59:52 --> Router Class Initialized
INFO - 2018-07-31 17:59:52 --> Output Class Initialized
INFO - 2018-07-31 17:59:52 --> Security Class Initialized
DEBUG - 2018-07-31 17:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 17:59:52 --> CSRF cookie sent
INFO - 2018-07-31 17:59:52 --> Input Class Initialized
INFO - 2018-07-31 17:59:52 --> Language Class Initialized
INFO - 2018-07-31 17:59:52 --> Loader Class Initialized
INFO - 2018-07-31 17:59:52 --> Helper loaded: url_helper
INFO - 2018-07-31 17:59:52 --> Helper loaded: form_helper
INFO - 2018-07-31 17:59:52 --> Helper loaded: language_helper
DEBUG - 2018-07-31 17:59:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 17:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 17:59:52 --> User Agent Class Initialized
INFO - 2018-07-31 17:59:52 --> Controller Class Initialized
INFO - 2018-07-31 17:59:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 17:59:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 17:59:52 --> Pixel_Model class loaded
INFO - 2018-07-31 17:59:52 --> Database Driver Class Initialized
INFO - 2018-07-31 17:59:52 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 17:59:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 17:59:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 17:59:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-31 17:59:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 17:59:52 --> Final output sent to browser
DEBUG - 2018-07-31 17:59:52 --> Total execution time: 0.0497
INFO - 2018-07-31 18:00:01 --> Config Class Initialized
INFO - 2018-07-31 18:00:01 --> Hooks Class Initialized
DEBUG - 2018-07-31 18:00:01 --> UTF-8 Support Enabled
INFO - 2018-07-31 18:00:01 --> Utf8 Class Initialized
INFO - 2018-07-31 18:00:01 --> URI Class Initialized
INFO - 2018-07-31 18:00:01 --> Router Class Initialized
INFO - 2018-07-31 18:00:01 --> Output Class Initialized
INFO - 2018-07-31 18:00:01 --> Security Class Initialized
DEBUG - 2018-07-31 18:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 18:00:01 --> CSRF cookie sent
INFO - 2018-07-31 18:00:01 --> CSRF token verified
INFO - 2018-07-31 18:00:01 --> Input Class Initialized
INFO - 2018-07-31 18:00:01 --> Language Class Initialized
INFO - 2018-07-31 18:00:01 --> Loader Class Initialized
INFO - 2018-07-31 18:00:01 --> Helper loaded: url_helper
INFO - 2018-07-31 18:00:01 --> Helper loaded: form_helper
INFO - 2018-07-31 18:00:01 --> Helper loaded: language_helper
DEBUG - 2018-07-31 18:00:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 18:00:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 18:00:01 --> User Agent Class Initialized
INFO - 2018-07-31 18:00:02 --> Controller Class Initialized
INFO - 2018-07-31 18:00:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 18:00:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 18:00:02 --> Pixel_Model class loaded
INFO - 2018-07-31 18:00:02 --> Database Driver Class Initialized
INFO - 2018-07-31 18:00:02 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 18:00:02 --> Database Driver Class Initialized
INFO - 2018-07-31 18:00:02 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 18:00:02 --> Config Class Initialized
INFO - 2018-07-31 18:00:02 --> Hooks Class Initialized
DEBUG - 2018-07-31 18:00:02 --> UTF-8 Support Enabled
INFO - 2018-07-31 18:00:02 --> Utf8 Class Initialized
INFO - 2018-07-31 18:00:02 --> URI Class Initialized
INFO - 2018-07-31 18:00:02 --> Router Class Initialized
INFO - 2018-07-31 18:00:02 --> Output Class Initialized
INFO - 2018-07-31 18:00:02 --> Security Class Initialized
DEBUG - 2018-07-31 18:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 18:00:02 --> CSRF cookie sent
INFO - 2018-07-31 18:00:02 --> Input Class Initialized
INFO - 2018-07-31 18:00:02 --> Language Class Initialized
INFO - 2018-07-31 18:00:02 --> Loader Class Initialized
INFO - 2018-07-31 18:00:02 --> Helper loaded: url_helper
INFO - 2018-07-31 18:00:02 --> Helper loaded: form_helper
INFO - 2018-07-31 18:00:02 --> Helper loaded: language_helper
DEBUG - 2018-07-31 18:00:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 18:00:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 18:00:02 --> User Agent Class Initialized
INFO - 2018-07-31 18:00:02 --> Controller Class Initialized
INFO - 2018-07-31 18:00:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 18:00:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 18:00:02 --> Pixel_Model class loaded
INFO - 2018-07-31 18:00:02 --> Database Driver Class Initialized
INFO - 2018-07-31 18:00:02 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 18:00:02 --> Database Driver Class Initialized
INFO - 2018-07-31 18:00:02 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 18:00:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 18:00:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 18:00:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 18:00:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 18:00:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 18:00:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 18:00:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-07-31 18:00:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 18:00:02 --> Final output sent to browser
DEBUG - 2018-07-31 18:00:02 --> Total execution time: 0.1747
INFO - 2018-07-31 18:00:17 --> Config Class Initialized
INFO - 2018-07-31 18:00:17 --> Hooks Class Initialized
DEBUG - 2018-07-31 18:00:17 --> UTF-8 Support Enabled
INFO - 2018-07-31 18:00:17 --> Utf8 Class Initialized
INFO - 2018-07-31 18:00:17 --> URI Class Initialized
DEBUG - 2018-07-31 18:00:17 --> No URI present. Default controller set.
INFO - 2018-07-31 18:00:17 --> Router Class Initialized
INFO - 2018-07-31 18:00:17 --> Output Class Initialized
INFO - 2018-07-31 18:00:17 --> Security Class Initialized
DEBUG - 2018-07-31 18:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 18:00:17 --> CSRF cookie sent
INFO - 2018-07-31 18:00:17 --> Input Class Initialized
INFO - 2018-07-31 18:00:17 --> Language Class Initialized
INFO - 2018-07-31 18:00:17 --> Loader Class Initialized
INFO - 2018-07-31 18:00:17 --> Helper loaded: url_helper
INFO - 2018-07-31 18:00:17 --> Helper loaded: form_helper
INFO - 2018-07-31 18:00:17 --> Helper loaded: language_helper
DEBUG - 2018-07-31 18:00:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 18:00:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 18:00:17 --> User Agent Class Initialized
INFO - 2018-07-31 18:00:17 --> Controller Class Initialized
INFO - 2018-07-31 18:00:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 18:00:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 18:00:17 --> Pixel_Model class loaded
INFO - 2018-07-31 18:00:17 --> Database Driver Class Initialized
INFO - 2018-07-31 18:00:17 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 18:00:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 18:00:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 18:00:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-31 18:00:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 18:00:17 --> Final output sent to browser
DEBUG - 2018-07-31 18:00:17 --> Total execution time: 0.0330
INFO - 2018-07-31 20:01:35 --> Config Class Initialized
INFO - 2018-07-31 20:01:35 --> Hooks Class Initialized
DEBUG - 2018-07-31 20:01:35 --> UTF-8 Support Enabled
INFO - 2018-07-31 20:01:35 --> Utf8 Class Initialized
INFO - 2018-07-31 20:01:35 --> URI Class Initialized
DEBUG - 2018-07-31 20:01:35 --> No URI present. Default controller set.
INFO - 2018-07-31 20:01:35 --> Router Class Initialized
INFO - 2018-07-31 20:01:35 --> Output Class Initialized
INFO - 2018-07-31 20:01:35 --> Security Class Initialized
DEBUG - 2018-07-31 20:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 20:01:35 --> CSRF cookie sent
INFO - 2018-07-31 20:01:35 --> Input Class Initialized
INFO - 2018-07-31 20:01:35 --> Language Class Initialized
INFO - 2018-07-31 20:01:35 --> Loader Class Initialized
INFO - 2018-07-31 20:01:35 --> Helper loaded: url_helper
INFO - 2018-07-31 20:01:35 --> Helper loaded: form_helper
INFO - 2018-07-31 20:01:35 --> Helper loaded: language_helper
DEBUG - 2018-07-31 20:01:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 20:01:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 20:01:35 --> User Agent Class Initialized
INFO - 2018-07-31 20:01:35 --> Controller Class Initialized
INFO - 2018-07-31 20:01:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 20:01:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 20:01:35 --> Pixel_Model class loaded
INFO - 2018-07-31 20:01:35 --> Database Driver Class Initialized
INFO - 2018-07-31 20:01:35 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 20:01:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 20:01:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 20:01:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-31 20:01:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 20:01:35 --> Final output sent to browser
DEBUG - 2018-07-31 20:01:35 --> Total execution time: 0.0355
INFO - 2018-07-31 20:53:43 --> Config Class Initialized
INFO - 2018-07-31 20:53:43 --> Hooks Class Initialized
DEBUG - 2018-07-31 20:53:43 --> UTF-8 Support Enabled
INFO - 2018-07-31 20:53:43 --> Utf8 Class Initialized
INFO - 2018-07-31 20:53:43 --> URI Class Initialized
DEBUG - 2018-07-31 20:53:43 --> No URI present. Default controller set.
INFO - 2018-07-31 20:53:43 --> Router Class Initialized
INFO - 2018-07-31 20:53:43 --> Output Class Initialized
INFO - 2018-07-31 20:53:43 --> Security Class Initialized
DEBUG - 2018-07-31 20:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 20:53:43 --> CSRF cookie sent
INFO - 2018-07-31 20:53:43 --> Input Class Initialized
INFO - 2018-07-31 20:53:43 --> Language Class Initialized
INFO - 2018-07-31 20:53:43 --> Loader Class Initialized
INFO - 2018-07-31 20:53:43 --> Helper loaded: url_helper
INFO - 2018-07-31 20:53:43 --> Helper loaded: form_helper
INFO - 2018-07-31 20:53:43 --> Helper loaded: language_helper
DEBUG - 2018-07-31 20:53:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 20:53:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 20:53:43 --> User Agent Class Initialized
INFO - 2018-07-31 20:53:43 --> Controller Class Initialized
INFO - 2018-07-31 20:53:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 20:53:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 20:53:43 --> Pixel_Model class loaded
INFO - 2018-07-31 20:53:43 --> Database Driver Class Initialized
INFO - 2018-07-31 20:53:43 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 20:53:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 20:53:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 20:53:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-31 20:53:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 20:53:43 --> Final output sent to browser
DEBUG - 2018-07-31 20:53:43 --> Total execution time: 0.0333
INFO - 2018-07-31 21:13:05 --> Config Class Initialized
INFO - 2018-07-31 21:13:05 --> Hooks Class Initialized
DEBUG - 2018-07-31 21:13:05 --> UTF-8 Support Enabled
INFO - 2018-07-31 21:13:05 --> Utf8 Class Initialized
INFO - 2018-07-31 21:13:05 --> URI Class Initialized
DEBUG - 2018-07-31 21:13:05 --> No URI present. Default controller set.
INFO - 2018-07-31 21:13:05 --> Router Class Initialized
INFO - 2018-07-31 21:13:05 --> Output Class Initialized
INFO - 2018-07-31 21:13:05 --> Security Class Initialized
DEBUG - 2018-07-31 21:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 21:13:05 --> CSRF cookie sent
INFO - 2018-07-31 21:13:05 --> Input Class Initialized
INFO - 2018-07-31 21:13:05 --> Language Class Initialized
INFO - 2018-07-31 21:13:05 --> Loader Class Initialized
INFO - 2018-07-31 21:13:05 --> Helper loaded: url_helper
INFO - 2018-07-31 21:13:05 --> Helper loaded: form_helper
INFO - 2018-07-31 21:13:05 --> Helper loaded: language_helper
DEBUG - 2018-07-31 21:13:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 21:13:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 21:13:05 --> User Agent Class Initialized
INFO - 2018-07-31 21:13:05 --> Controller Class Initialized
INFO - 2018-07-31 21:13:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 21:13:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 21:13:05 --> Pixel_Model class loaded
INFO - 2018-07-31 21:13:05 --> Database Driver Class Initialized
INFO - 2018-07-31 21:13:05 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 21:13:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 21:13:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 21:13:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-31 21:13:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 21:13:05 --> Final output sent to browser
DEBUG - 2018-07-31 21:13:05 --> Total execution time: 0.0336
INFO - 2018-07-31 21:13:20 --> Config Class Initialized
INFO - 2018-07-31 21:13:20 --> Hooks Class Initialized
DEBUG - 2018-07-31 21:13:20 --> UTF-8 Support Enabled
INFO - 2018-07-31 21:13:20 --> Utf8 Class Initialized
INFO - 2018-07-31 21:13:20 --> URI Class Initialized
INFO - 2018-07-31 21:13:20 --> Router Class Initialized
INFO - 2018-07-31 21:13:20 --> Output Class Initialized
INFO - 2018-07-31 21:13:20 --> Security Class Initialized
DEBUG - 2018-07-31 21:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 21:13:20 --> CSRF cookie sent
INFO - 2018-07-31 21:13:20 --> CSRF token verified
INFO - 2018-07-31 21:13:20 --> Input Class Initialized
INFO - 2018-07-31 21:13:20 --> Language Class Initialized
INFO - 2018-07-31 21:13:20 --> Loader Class Initialized
INFO - 2018-07-31 21:13:20 --> Helper loaded: url_helper
INFO - 2018-07-31 21:13:20 --> Helper loaded: form_helper
INFO - 2018-07-31 21:13:20 --> Helper loaded: language_helper
DEBUG - 2018-07-31 21:13:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 21:13:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 21:13:20 --> User Agent Class Initialized
INFO - 2018-07-31 21:13:20 --> Controller Class Initialized
INFO - 2018-07-31 21:13:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 21:13:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 21:13:20 --> Pixel_Model class loaded
INFO - 2018-07-31 21:13:20 --> Database Driver Class Initialized
INFO - 2018-07-31 21:13:20 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 21:13:20 --> Database Driver Class Initialized
INFO - 2018-07-31 21:13:20 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 21:13:20 --> Config Class Initialized
INFO - 2018-07-31 21:13:20 --> Hooks Class Initialized
DEBUG - 2018-07-31 21:13:20 --> UTF-8 Support Enabled
INFO - 2018-07-31 21:13:20 --> Utf8 Class Initialized
INFO - 2018-07-31 21:13:20 --> URI Class Initialized
INFO - 2018-07-31 21:13:20 --> Router Class Initialized
INFO - 2018-07-31 21:13:20 --> Output Class Initialized
INFO - 2018-07-31 21:13:20 --> Security Class Initialized
DEBUG - 2018-07-31 21:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 21:13:20 --> CSRF cookie sent
INFO - 2018-07-31 21:13:20 --> Input Class Initialized
INFO - 2018-07-31 21:13:20 --> Language Class Initialized
INFO - 2018-07-31 21:13:20 --> Loader Class Initialized
INFO - 2018-07-31 21:13:20 --> Helper loaded: url_helper
INFO - 2018-07-31 21:13:20 --> Helper loaded: form_helper
INFO - 2018-07-31 21:13:20 --> Helper loaded: language_helper
DEBUG - 2018-07-31 21:13:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 21:13:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 21:13:20 --> User Agent Class Initialized
INFO - 2018-07-31 21:13:20 --> Controller Class Initialized
INFO - 2018-07-31 21:13:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 21:13:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 21:13:20 --> Pixel_Model class loaded
INFO - 2018-07-31 21:13:20 --> Database Driver Class Initialized
INFO - 2018-07-31 21:13:20 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 21:13:20 --> Database Driver Class Initialized
INFO - 2018-07-31 21:13:20 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 21:13:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 21:13:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 21:13:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 21:13:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 21:13:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 21:13:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 21:13:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-07-31 21:13:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 21:13:20 --> Final output sent to browser
DEBUG - 2018-07-31 21:13:20 --> Total execution time: 0.0583
INFO - 2018-07-31 21:13:33 --> Config Class Initialized
INFO - 2018-07-31 21:13:33 --> Hooks Class Initialized
DEBUG - 2018-07-31 21:13:33 --> UTF-8 Support Enabled
INFO - 2018-07-31 21:13:33 --> Utf8 Class Initialized
INFO - 2018-07-31 21:13:33 --> URI Class Initialized
INFO - 2018-07-31 21:13:33 --> Router Class Initialized
INFO - 2018-07-31 21:13:33 --> Output Class Initialized
INFO - 2018-07-31 21:13:33 --> Security Class Initialized
DEBUG - 2018-07-31 21:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 21:13:33 --> CSRF cookie sent
INFO - 2018-07-31 21:13:33 --> Input Class Initialized
INFO - 2018-07-31 21:13:33 --> Language Class Initialized
INFO - 2018-07-31 21:13:33 --> Loader Class Initialized
INFO - 2018-07-31 21:13:33 --> Helper loaded: url_helper
INFO - 2018-07-31 21:13:33 --> Helper loaded: form_helper
INFO - 2018-07-31 21:13:33 --> Helper loaded: language_helper
DEBUG - 2018-07-31 21:13:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 21:13:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 21:13:33 --> User Agent Class Initialized
INFO - 2018-07-31 21:13:33 --> Controller Class Initialized
INFO - 2018-07-31 21:13:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 21:13:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 21:13:33 --> Pixel_Model class loaded
INFO - 2018-07-31 21:13:33 --> Database Driver Class Initialized
INFO - 2018-07-31 21:13:33 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 21:13:33 --> Config Class Initialized
INFO - 2018-07-31 21:13:33 --> Hooks Class Initialized
DEBUG - 2018-07-31 21:13:33 --> UTF-8 Support Enabled
INFO - 2018-07-31 21:13:33 --> Utf8 Class Initialized
INFO - 2018-07-31 21:13:33 --> URI Class Initialized
INFO - 2018-07-31 21:13:33 --> Router Class Initialized
INFO - 2018-07-31 21:13:33 --> Output Class Initialized
INFO - 2018-07-31 21:13:33 --> Security Class Initialized
DEBUG - 2018-07-31 21:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 21:13:33 --> CSRF cookie sent
INFO - 2018-07-31 21:13:33 --> Input Class Initialized
INFO - 2018-07-31 21:13:33 --> Language Class Initialized
INFO - 2018-07-31 21:13:33 --> Loader Class Initialized
INFO - 2018-07-31 21:13:33 --> Helper loaded: url_helper
INFO - 2018-07-31 21:13:33 --> Helper loaded: form_helper
INFO - 2018-07-31 21:13:33 --> Helper loaded: language_helper
DEBUG - 2018-07-31 21:13:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 21:13:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 21:13:33 --> User Agent Class Initialized
INFO - 2018-07-31 21:13:33 --> Controller Class Initialized
INFO - 2018-07-31 21:13:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 21:13:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 21:13:33 --> Pixel_Model class loaded
INFO - 2018-07-31 21:13:33 --> Database Driver Class Initialized
INFO - 2018-07-31 21:13:33 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 21:13:33 --> Database Driver Class Initialized
INFO - 2018-07-31 21:13:33 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 21:13:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 21:13:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 21:13:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-07-31 21:13:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 21:13:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 21:13:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 21:13:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 21:13:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-07-31 21:13:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 21:13:33 --> Final output sent to browser
DEBUG - 2018-07-31 21:13:33 --> Total execution time: 0.0545
INFO - 2018-07-31 23:45:16 --> Config Class Initialized
INFO - 2018-07-31 23:45:16 --> Hooks Class Initialized
DEBUG - 2018-07-31 23:45:16 --> UTF-8 Support Enabled
INFO - 2018-07-31 23:45:16 --> Utf8 Class Initialized
INFO - 2018-07-31 23:45:16 --> URI Class Initialized
DEBUG - 2018-07-31 23:45:16 --> No URI present. Default controller set.
INFO - 2018-07-31 23:45:16 --> Router Class Initialized
INFO - 2018-07-31 23:45:16 --> Output Class Initialized
INFO - 2018-07-31 23:45:16 --> Security Class Initialized
DEBUG - 2018-07-31 23:45:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 23:45:16 --> CSRF cookie sent
INFO - 2018-07-31 23:45:16 --> Input Class Initialized
INFO - 2018-07-31 23:45:16 --> Language Class Initialized
INFO - 2018-07-31 23:45:16 --> Loader Class Initialized
INFO - 2018-07-31 23:45:16 --> Helper loaded: url_helper
INFO - 2018-07-31 23:45:16 --> Helper loaded: form_helper
INFO - 2018-07-31 23:45:16 --> Helper loaded: language_helper
DEBUG - 2018-07-31 23:45:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 23:45:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 23:45:16 --> User Agent Class Initialized
INFO - 2018-07-31 23:45:16 --> Controller Class Initialized
INFO - 2018-07-31 23:45:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 23:45:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 23:45:16 --> Pixel_Model class loaded
INFO - 2018-07-31 23:45:16 --> Database Driver Class Initialized
INFO - 2018-07-31 23:45:16 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 23:45:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 23:45:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 23:45:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-31 23:45:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 23:45:16 --> Final output sent to browser
DEBUG - 2018-07-31 23:45:16 --> Total execution time: 0.0551
INFO - 2018-07-31 23:45:17 --> Config Class Initialized
INFO - 2018-07-31 23:45:17 --> Hooks Class Initialized
DEBUG - 2018-07-31 23:45:17 --> UTF-8 Support Enabled
INFO - 2018-07-31 23:45:17 --> Utf8 Class Initialized
INFO - 2018-07-31 23:45:17 --> URI Class Initialized
DEBUG - 2018-07-31 23:45:17 --> No URI present. Default controller set.
INFO - 2018-07-31 23:45:17 --> Router Class Initialized
INFO - 2018-07-31 23:45:17 --> Output Class Initialized
INFO - 2018-07-31 23:45:17 --> Security Class Initialized
DEBUG - 2018-07-31 23:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 23:45:17 --> CSRF cookie sent
INFO - 2018-07-31 23:45:17 --> Input Class Initialized
INFO - 2018-07-31 23:45:17 --> Language Class Initialized
INFO - 2018-07-31 23:45:17 --> Loader Class Initialized
INFO - 2018-07-31 23:45:17 --> Helper loaded: url_helper
INFO - 2018-07-31 23:45:17 --> Helper loaded: form_helper
INFO - 2018-07-31 23:45:17 --> Helper loaded: language_helper
DEBUG - 2018-07-31 23:45:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 23:45:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 23:45:17 --> User Agent Class Initialized
INFO - 2018-07-31 23:45:17 --> Controller Class Initialized
INFO - 2018-07-31 23:45:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 23:45:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 23:45:17 --> Pixel_Model class loaded
INFO - 2018-07-31 23:45:17 --> Database Driver Class Initialized
INFO - 2018-07-31 23:45:17 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 23:45:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 23:45:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 23:45:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-31 23:45:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 23:45:17 --> Final output sent to browser
DEBUG - 2018-07-31 23:45:17 --> Total execution time: 0.0359
INFO - 2018-07-31 23:45:18 --> Config Class Initialized
INFO - 2018-07-31 23:45:18 --> Hooks Class Initialized
DEBUG - 2018-07-31 23:45:18 --> UTF-8 Support Enabled
INFO - 2018-07-31 23:45:18 --> Utf8 Class Initialized
INFO - 2018-07-31 23:45:18 --> URI Class Initialized
DEBUG - 2018-07-31 23:45:18 --> No URI present. Default controller set.
INFO - 2018-07-31 23:45:18 --> Router Class Initialized
INFO - 2018-07-31 23:45:18 --> Output Class Initialized
INFO - 2018-07-31 23:45:18 --> Security Class Initialized
DEBUG - 2018-07-31 23:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 23:45:18 --> CSRF cookie sent
INFO - 2018-07-31 23:45:18 --> Input Class Initialized
INFO - 2018-07-31 23:45:18 --> Language Class Initialized
INFO - 2018-07-31 23:45:18 --> Loader Class Initialized
INFO - 2018-07-31 23:45:18 --> Helper loaded: url_helper
INFO - 2018-07-31 23:45:18 --> Helper loaded: form_helper
INFO - 2018-07-31 23:45:18 --> Helper loaded: language_helper
DEBUG - 2018-07-31 23:45:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 23:45:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 23:45:18 --> User Agent Class Initialized
INFO - 2018-07-31 23:45:18 --> Controller Class Initialized
INFO - 2018-07-31 23:45:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 23:45:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 23:45:18 --> Pixel_Model class loaded
INFO - 2018-07-31 23:45:18 --> Database Driver Class Initialized
INFO - 2018-07-31 23:45:18 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 23:45:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 23:45:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 23:45:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-31 23:45:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 23:45:18 --> Final output sent to browser
DEBUG - 2018-07-31 23:45:18 --> Total execution time: 0.0500
INFO - 2018-07-31 23:45:18 --> Config Class Initialized
INFO - 2018-07-31 23:45:18 --> Hooks Class Initialized
DEBUG - 2018-07-31 23:45:18 --> UTF-8 Support Enabled
INFO - 2018-07-31 23:45:18 --> Utf8 Class Initialized
INFO - 2018-07-31 23:45:18 --> URI Class Initialized
INFO - 2018-07-31 23:45:18 --> Router Class Initialized
INFO - 2018-07-31 23:45:18 --> Output Class Initialized
INFO - 2018-07-31 23:45:18 --> Security Class Initialized
DEBUG - 2018-07-31 23:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 23:45:18 --> CSRF cookie sent
INFO - 2018-07-31 23:45:18 --> Input Class Initialized
INFO - 2018-07-31 23:45:18 --> Language Class Initialized
ERROR - 2018-07-31 23:45:18 --> 404 Page Not Found: 405shtml/index
INFO - 2018-07-31 23:45:25 --> Config Class Initialized
INFO - 2018-07-31 23:45:25 --> Hooks Class Initialized
DEBUG - 2018-07-31 23:45:25 --> UTF-8 Support Enabled
INFO - 2018-07-31 23:45:25 --> Utf8 Class Initialized
INFO - 2018-07-31 23:45:25 --> URI Class Initialized
DEBUG - 2018-07-31 23:45:25 --> No URI present. Default controller set.
INFO - 2018-07-31 23:45:25 --> Router Class Initialized
INFO - 2018-07-31 23:45:25 --> Output Class Initialized
INFO - 2018-07-31 23:45:25 --> Security Class Initialized
DEBUG - 2018-07-31 23:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 23:45:25 --> CSRF cookie sent
INFO - 2018-07-31 23:45:25 --> Input Class Initialized
INFO - 2018-07-31 23:45:25 --> Language Class Initialized
INFO - 2018-07-31 23:45:25 --> Loader Class Initialized
INFO - 2018-07-31 23:45:25 --> Helper loaded: url_helper
INFO - 2018-07-31 23:45:25 --> Helper loaded: form_helper
INFO - 2018-07-31 23:45:25 --> Helper loaded: language_helper
DEBUG - 2018-07-31 23:45:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 23:45:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 23:45:26 --> User Agent Class Initialized
INFO - 2018-07-31 23:45:26 --> Controller Class Initialized
INFO - 2018-07-31 23:45:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 23:45:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 23:45:26 --> Pixel_Model class loaded
INFO - 2018-07-31 23:45:26 --> Database Driver Class Initialized
INFO - 2018-07-31 23:45:26 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 23:45:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 23:45:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 23:45:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-07-31 23:45:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 23:45:26 --> Final output sent to browser
DEBUG - 2018-07-31 23:45:26 --> Total execution time: 0.0337
INFO - 2018-07-31 23:45:26 --> Config Class Initialized
INFO - 2018-07-31 23:45:26 --> Hooks Class Initialized
DEBUG - 2018-07-31 23:45:26 --> UTF-8 Support Enabled
INFO - 2018-07-31 23:45:26 --> Utf8 Class Initialized
INFO - 2018-07-31 23:45:26 --> URI Class Initialized
INFO - 2018-07-31 23:45:26 --> Router Class Initialized
INFO - 2018-07-31 23:45:26 --> Output Class Initialized
INFO - 2018-07-31 23:45:26 --> Security Class Initialized
DEBUG - 2018-07-31 23:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 23:45:26 --> CSRF cookie sent
INFO - 2018-07-31 23:45:26 --> Input Class Initialized
INFO - 2018-07-31 23:45:26 --> Language Class Initialized
ERROR - 2018-07-31 23:45:26 --> 404 Page Not Found: 404testpage4525d2fdc/index
INFO - 2018-07-31 23:45:26 --> Config Class Initialized
INFO - 2018-07-31 23:45:26 --> Hooks Class Initialized
DEBUG - 2018-07-31 23:45:26 --> UTF-8 Support Enabled
INFO - 2018-07-31 23:45:26 --> Utf8 Class Initialized
INFO - 2018-07-31 23:45:26 --> URI Class Initialized
INFO - 2018-07-31 23:45:26 --> Router Class Initialized
INFO - 2018-07-31 23:45:26 --> Output Class Initialized
INFO - 2018-07-31 23:45:26 --> Security Class Initialized
DEBUG - 2018-07-31 23:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 23:45:26 --> CSRF cookie sent
INFO - 2018-07-31 23:45:26 --> Input Class Initialized
INFO - 2018-07-31 23:45:26 --> Language Class Initialized
ERROR - 2018-07-31 23:45:26 --> 404 Page Not Found: 404javascriptjs/index
INFO - 2018-07-31 23:45:27 --> Config Class Initialized
INFO - 2018-07-31 23:45:27 --> Hooks Class Initialized
DEBUG - 2018-07-31 23:45:27 --> UTF-8 Support Enabled
INFO - 2018-07-31 23:45:27 --> Utf8 Class Initialized
INFO - 2018-07-31 23:45:27 --> URI Class Initialized
INFO - 2018-07-31 23:45:27 --> Router Class Initialized
INFO - 2018-07-31 23:45:27 --> Output Class Initialized
INFO - 2018-07-31 23:45:27 --> Security Class Initialized
DEBUG - 2018-07-31 23:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 23:45:27 --> CSRF cookie sent
INFO - 2018-07-31 23:45:27 --> Input Class Initialized
INFO - 2018-07-31 23:45:27 --> Language Class Initialized
INFO - 2018-07-31 23:45:27 --> Loader Class Initialized
INFO - 2018-07-31 23:45:27 --> Helper loaded: url_helper
INFO - 2018-07-31 23:45:27 --> Helper loaded: form_helper
INFO - 2018-07-31 23:45:27 --> Helper loaded: language_helper
DEBUG - 2018-07-31 23:45:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 23:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 23:45:27 --> User Agent Class Initialized
INFO - 2018-07-31 23:45:27 --> Controller Class Initialized
INFO - 2018-07-31 23:45:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 23:45:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 23:45:27 --> Pixel_Model class loaded
INFO - 2018-07-31 23:45:27 --> Database Driver Class Initialized
INFO - 2018-07-31 23:45:27 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 23:45:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 23:45:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 23:45:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 23:45:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 23:45:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-07-31 23:45:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-07-31 23:45:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-07-31 23:45:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 23:45:27 --> Final output sent to browser
DEBUG - 2018-07-31 23:45:27 --> Total execution time: 0.0379
INFO - 2018-07-31 23:45:27 --> Config Class Initialized
INFO - 2018-07-31 23:45:27 --> Hooks Class Initialized
DEBUG - 2018-07-31 23:45:27 --> UTF-8 Support Enabled
INFO - 2018-07-31 23:45:27 --> Utf8 Class Initialized
INFO - 2018-07-31 23:45:27 --> URI Class Initialized
INFO - 2018-07-31 23:45:27 --> Router Class Initialized
INFO - 2018-07-31 23:45:27 --> Output Class Initialized
INFO - 2018-07-31 23:45:27 --> Security Class Initialized
DEBUG - 2018-07-31 23:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 23:45:27 --> CSRF cookie sent
INFO - 2018-07-31 23:45:27 --> Input Class Initialized
INFO - 2018-07-31 23:45:27 --> Language Class Initialized
INFO - 2018-07-31 23:45:27 --> Loader Class Initialized
INFO - 2018-07-31 23:45:27 --> Helper loaded: url_helper
INFO - 2018-07-31 23:45:27 --> Helper loaded: form_helper
INFO - 2018-07-31 23:45:27 --> Helper loaded: language_helper
DEBUG - 2018-07-31 23:45:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 23:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 23:45:27 --> User Agent Class Initialized
INFO - 2018-07-31 23:45:27 --> Controller Class Initialized
INFO - 2018-07-31 23:45:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 23:45:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 23:45:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 23:45:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 23:45:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 23:45:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 23:45:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-07-31 23:45:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 23:45:27 --> Final output sent to browser
DEBUG - 2018-07-31 23:45:27 --> Total execution time: 0.0383
INFO - 2018-07-31 23:45:28 --> Config Class Initialized
INFO - 2018-07-31 23:45:28 --> Hooks Class Initialized
DEBUG - 2018-07-31 23:45:28 --> UTF-8 Support Enabled
INFO - 2018-07-31 23:45:28 --> Utf8 Class Initialized
INFO - 2018-07-31 23:45:28 --> URI Class Initialized
INFO - 2018-07-31 23:45:28 --> Router Class Initialized
INFO - 2018-07-31 23:45:28 --> Output Class Initialized
INFO - 2018-07-31 23:45:28 --> Security Class Initialized
DEBUG - 2018-07-31 23:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 23:45:28 --> CSRF cookie sent
INFO - 2018-07-31 23:45:28 --> Input Class Initialized
INFO - 2018-07-31 23:45:28 --> Language Class Initialized
INFO - 2018-07-31 23:45:28 --> Loader Class Initialized
INFO - 2018-07-31 23:45:28 --> Helper loaded: url_helper
INFO - 2018-07-31 23:45:28 --> Helper loaded: form_helper
INFO - 2018-07-31 23:45:28 --> Helper loaded: language_helper
DEBUG - 2018-07-31 23:45:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 23:45:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 23:45:28 --> User Agent Class Initialized
INFO - 2018-07-31 23:45:28 --> Controller Class Initialized
INFO - 2018-07-31 23:45:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 23:45:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 23:45:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 23:45:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 23:45:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 23:45:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 23:45:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-07-31 23:45:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 23:45:28 --> Final output sent to browser
DEBUG - 2018-07-31 23:45:28 --> Total execution time: 0.0253
INFO - 2018-07-31 23:45:28 --> Config Class Initialized
INFO - 2018-07-31 23:45:28 --> Hooks Class Initialized
DEBUG - 2018-07-31 23:45:28 --> UTF-8 Support Enabled
INFO - 2018-07-31 23:45:28 --> Utf8 Class Initialized
INFO - 2018-07-31 23:45:28 --> URI Class Initialized
INFO - 2018-07-31 23:45:28 --> Router Class Initialized
INFO - 2018-07-31 23:45:28 --> Output Class Initialized
INFO - 2018-07-31 23:45:28 --> Security Class Initialized
DEBUG - 2018-07-31 23:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 23:45:28 --> CSRF cookie sent
INFO - 2018-07-31 23:45:28 --> Input Class Initialized
INFO - 2018-07-31 23:45:28 --> Language Class Initialized
INFO - 2018-07-31 23:45:28 --> Loader Class Initialized
INFO - 2018-07-31 23:45:28 --> Helper loaded: url_helper
INFO - 2018-07-31 23:45:28 --> Helper loaded: form_helper
INFO - 2018-07-31 23:45:28 --> Helper loaded: language_helper
DEBUG - 2018-07-31 23:45:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 23:45:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 23:45:28 --> User Agent Class Initialized
INFO - 2018-07-31 23:45:28 --> Controller Class Initialized
INFO - 2018-07-31 23:45:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 23:45:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 23:45:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 23:45:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 23:45:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 23:45:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 23:45:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-07-31 23:45:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 23:45:28 --> Final output sent to browser
DEBUG - 2018-07-31 23:45:28 --> Total execution time: 0.0546
INFO - 2018-07-31 23:45:28 --> Config Class Initialized
INFO - 2018-07-31 23:45:28 --> Hooks Class Initialized
DEBUG - 2018-07-31 23:45:28 --> UTF-8 Support Enabled
INFO - 2018-07-31 23:45:28 --> Utf8 Class Initialized
INFO - 2018-07-31 23:45:28 --> URI Class Initialized
INFO - 2018-07-31 23:45:28 --> Router Class Initialized
INFO - 2018-07-31 23:45:28 --> Output Class Initialized
INFO - 2018-07-31 23:45:28 --> Security Class Initialized
DEBUG - 2018-07-31 23:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 23:45:28 --> CSRF cookie sent
INFO - 2018-07-31 23:45:28 --> Input Class Initialized
INFO - 2018-07-31 23:45:28 --> Language Class Initialized
INFO - 2018-07-31 23:45:28 --> Loader Class Initialized
INFO - 2018-07-31 23:45:28 --> Helper loaded: url_helper
INFO - 2018-07-31 23:45:28 --> Helper loaded: form_helper
INFO - 2018-07-31 23:45:28 --> Helper loaded: language_helper
DEBUG - 2018-07-31 23:45:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 23:45:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 23:45:28 --> User Agent Class Initialized
INFO - 2018-07-31 23:45:28 --> Controller Class Initialized
INFO - 2018-07-31 23:45:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 23:45:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 23:45:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 23:45:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 23:45:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 23:45:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 23:45:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-07-31 23:45:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 23:45:28 --> Final output sent to browser
DEBUG - 2018-07-31 23:45:28 --> Total execution time: 0.0267
INFO - 2018-07-31 23:45:29 --> Config Class Initialized
INFO - 2018-07-31 23:45:29 --> Hooks Class Initialized
DEBUG - 2018-07-31 23:45:29 --> UTF-8 Support Enabled
INFO - 2018-07-31 23:45:29 --> Utf8 Class Initialized
INFO - 2018-07-31 23:45:29 --> URI Class Initialized
INFO - 2018-07-31 23:45:29 --> Router Class Initialized
INFO - 2018-07-31 23:45:29 --> Output Class Initialized
INFO - 2018-07-31 23:45:29 --> Security Class Initialized
DEBUG - 2018-07-31 23:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 23:45:29 --> CSRF cookie sent
INFO - 2018-07-31 23:45:29 --> Input Class Initialized
INFO - 2018-07-31 23:45:29 --> Language Class Initialized
INFO - 2018-07-31 23:45:29 --> Loader Class Initialized
INFO - 2018-07-31 23:45:29 --> Helper loaded: url_helper
INFO - 2018-07-31 23:45:29 --> Helper loaded: form_helper
INFO - 2018-07-31 23:45:29 --> Helper loaded: language_helper
DEBUG - 2018-07-31 23:45:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 23:45:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 23:45:29 --> User Agent Class Initialized
INFO - 2018-07-31 23:45:29 --> Controller Class Initialized
INFO - 2018-07-31 23:45:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 23:45:29 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-07-31 23:45:29 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-07-31 23:45:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 23:45:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 23:45:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 23:45:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-07-31 23:45:29 --> Could not find the language line "req_email"
INFO - 2018-07-31 23:45:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-07-31 23:45:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 23:45:29 --> Final output sent to browser
DEBUG - 2018-07-31 23:45:29 --> Total execution time: 0.0268
INFO - 2018-07-31 23:45:29 --> Config Class Initialized
INFO - 2018-07-31 23:45:29 --> Hooks Class Initialized
DEBUG - 2018-07-31 23:45:29 --> UTF-8 Support Enabled
INFO - 2018-07-31 23:45:29 --> Utf8 Class Initialized
INFO - 2018-07-31 23:45:29 --> URI Class Initialized
INFO - 2018-07-31 23:45:29 --> Router Class Initialized
INFO - 2018-07-31 23:45:29 --> Output Class Initialized
INFO - 2018-07-31 23:45:29 --> Security Class Initialized
DEBUG - 2018-07-31 23:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 23:45:29 --> CSRF cookie sent
INFO - 2018-07-31 23:45:29 --> Input Class Initialized
INFO - 2018-07-31 23:45:29 --> Language Class Initialized
INFO - 2018-07-31 23:45:29 --> Loader Class Initialized
INFO - 2018-07-31 23:45:29 --> Helper loaded: url_helper
INFO - 2018-07-31 23:45:29 --> Helper loaded: form_helper
INFO - 2018-07-31 23:45:29 --> Helper loaded: language_helper
DEBUG - 2018-07-31 23:45:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 23:45:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 23:45:29 --> User Agent Class Initialized
INFO - 2018-07-31 23:45:29 --> Controller Class Initialized
INFO - 2018-07-31 23:45:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-07-31 23:45:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-07-31 23:45:29 --> Pixel_Model class loaded
INFO - 2018-07-31 23:45:29 --> Database Driver Class Initialized
INFO - 2018-07-31 23:45:29 --> Model "QuestionsModel" initialized
INFO - 2018-07-31 23:45:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-07-31 23:45:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-07-31 23:45:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-07-31 23:45:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-07-31 23:45:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/buy_gift.php
INFO - 2018-07-31 23:45:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-07-31 23:45:29 --> Final output sent to browser
DEBUG - 2018-07-31 23:45:29 --> Total execution time: 0.0505

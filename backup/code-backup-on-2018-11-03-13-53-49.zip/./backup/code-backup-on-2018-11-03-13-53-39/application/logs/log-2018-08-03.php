<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-08-03 04:25:30 --> Config Class Initialized
INFO - 2018-08-03 04:25:30 --> Hooks Class Initialized
DEBUG - 2018-08-03 04:25:30 --> UTF-8 Support Enabled
INFO - 2018-08-03 04:25:30 --> Utf8 Class Initialized
INFO - 2018-08-03 04:25:30 --> URI Class Initialized
INFO - 2018-08-03 04:25:30 --> Router Class Initialized
INFO - 2018-08-03 04:25:30 --> Output Class Initialized
INFO - 2018-08-03 04:25:30 --> Security Class Initialized
DEBUG - 2018-08-03 04:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 04:25:30 --> CSRF cookie sent
INFO - 2018-08-03 04:25:30 --> Input Class Initialized
INFO - 2018-08-03 04:25:30 --> Language Class Initialized
ERROR - 2018-08-03 04:25:30 --> 404 Page Not Found: 401shtml/index
INFO - 2018-08-03 16:39:33 --> Config Class Initialized
INFO - 2018-08-03 16:39:33 --> Hooks Class Initialized
DEBUG - 2018-08-03 16:39:33 --> UTF-8 Support Enabled
INFO - 2018-08-03 16:39:33 --> Utf8 Class Initialized
INFO - 2018-08-03 16:39:33 --> URI Class Initialized
INFO - 2018-08-03 16:39:33 --> Router Class Initialized
INFO - 2018-08-03 16:39:33 --> Output Class Initialized
INFO - 2018-08-03 16:39:33 --> Security Class Initialized
DEBUG - 2018-08-03 16:39:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 16:39:33 --> CSRF cookie sent
INFO - 2018-08-03 16:39:33 --> Input Class Initialized
INFO - 2018-08-03 16:39:33 --> Language Class Initialized
ERROR - 2018-08-03 16:39:33 --> 404 Page Not Found: 401shtml/index
INFO - 2018-08-03 16:39:40 --> Config Class Initialized
INFO - 2018-08-03 16:39:40 --> Hooks Class Initialized
DEBUG - 2018-08-03 16:39:40 --> UTF-8 Support Enabled
INFO - 2018-08-03 16:39:40 --> Utf8 Class Initialized
INFO - 2018-08-03 16:39:40 --> URI Class Initialized
DEBUG - 2018-08-03 16:39:40 --> No URI present. Default controller set.
INFO - 2018-08-03 16:39:40 --> Router Class Initialized
INFO - 2018-08-03 16:39:40 --> Output Class Initialized
INFO - 2018-08-03 16:39:40 --> Security Class Initialized
DEBUG - 2018-08-03 16:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 16:39:40 --> CSRF cookie sent
INFO - 2018-08-03 16:39:40 --> Input Class Initialized
INFO - 2018-08-03 16:39:40 --> Language Class Initialized
INFO - 2018-08-03 16:39:40 --> Loader Class Initialized
INFO - 2018-08-03 16:39:40 --> Helper loaded: url_helper
INFO - 2018-08-03 16:39:40 --> Helper loaded: form_helper
INFO - 2018-08-03 16:39:40 --> Helper loaded: language_helper
DEBUG - 2018-08-03 16:39:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 16:39:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 16:39:40 --> User Agent Class Initialized
INFO - 2018-08-03 16:39:40 --> Controller Class Initialized
INFO - 2018-08-03 16:39:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-03 16:39:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-03 16:39:40 --> Pixel_Model class loaded
INFO - 2018-08-03 16:39:40 --> Database Driver Class Initialized
INFO - 2018-08-03 16:39:40 --> Model "QuestionsModel" initialized
INFO - 2018-08-03 16:39:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-03 16:39:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-03 16:39:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-03 16:39:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-03 16:39:40 --> Final output sent to browser
DEBUG - 2018-08-03 16:39:40 --> Total execution time: 0.0413
INFO - 2018-08-03 16:40:07 --> Config Class Initialized
INFO - 2018-08-03 16:40:07 --> Hooks Class Initialized
DEBUG - 2018-08-03 16:40:07 --> UTF-8 Support Enabled
INFO - 2018-08-03 16:40:07 --> Utf8 Class Initialized
INFO - 2018-08-03 16:40:07 --> URI Class Initialized
INFO - 2018-08-03 16:40:07 --> Router Class Initialized
INFO - 2018-08-03 16:40:07 --> Output Class Initialized
INFO - 2018-08-03 16:40:07 --> Security Class Initialized
DEBUG - 2018-08-03 16:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 16:40:07 --> CSRF cookie sent
INFO - 2018-08-03 16:40:07 --> CSRF token verified
INFO - 2018-08-03 16:40:07 --> Input Class Initialized
INFO - 2018-08-03 16:40:07 --> Language Class Initialized
INFO - 2018-08-03 16:40:07 --> Loader Class Initialized
INFO - 2018-08-03 16:40:07 --> Helper loaded: url_helper
INFO - 2018-08-03 16:40:07 --> Helper loaded: form_helper
INFO - 2018-08-03 16:40:07 --> Helper loaded: language_helper
DEBUG - 2018-08-03 16:40:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 16:40:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 16:40:07 --> User Agent Class Initialized
INFO - 2018-08-03 16:40:07 --> Controller Class Initialized
INFO - 2018-08-03 16:40:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-03 16:40:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-03 16:40:07 --> Pixel_Model class loaded
INFO - 2018-08-03 16:40:07 --> Database Driver Class Initialized
INFO - 2018-08-03 16:40:07 --> Model "QuestionsModel" initialized
INFO - 2018-08-03 16:40:07 --> Database Driver Class Initialized
INFO - 2018-08-03 16:40:07 --> Model "QuestionsModel" initialized
INFO - 2018-08-03 16:40:08 --> Config Class Initialized
INFO - 2018-08-03 16:40:08 --> Hooks Class Initialized
DEBUG - 2018-08-03 16:40:08 --> UTF-8 Support Enabled
INFO - 2018-08-03 16:40:08 --> Utf8 Class Initialized
INFO - 2018-08-03 16:40:08 --> URI Class Initialized
INFO - 2018-08-03 16:40:08 --> Router Class Initialized
INFO - 2018-08-03 16:40:08 --> Output Class Initialized
INFO - 2018-08-03 16:40:08 --> Security Class Initialized
DEBUG - 2018-08-03 16:40:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 16:40:08 --> CSRF cookie sent
INFO - 2018-08-03 16:40:08 --> Input Class Initialized
INFO - 2018-08-03 16:40:08 --> Language Class Initialized
INFO - 2018-08-03 16:40:08 --> Loader Class Initialized
INFO - 2018-08-03 16:40:08 --> Helper loaded: url_helper
INFO - 2018-08-03 16:40:08 --> Helper loaded: form_helper
INFO - 2018-08-03 16:40:08 --> Helper loaded: language_helper
DEBUG - 2018-08-03 16:40:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 16:40:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 16:40:08 --> User Agent Class Initialized
INFO - 2018-08-03 16:40:08 --> Controller Class Initialized
INFO - 2018-08-03 16:40:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-03 16:40:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-03 16:40:08 --> Pixel_Model class loaded
INFO - 2018-08-03 16:40:08 --> Database Driver Class Initialized
INFO - 2018-08-03 16:40:08 --> Model "QuestionsModel" initialized
INFO - 2018-08-03 16:40:08 --> Database Driver Class Initialized
INFO - 2018-08-03 16:40:08 --> Model "QuestionsModel" initialized
INFO - 2018-08-03 16:40:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-03 16:40:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-03 16:40:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-03 16:40:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-03 16:40:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-03 16:40:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-03 16:40:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-03 16:40:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-03 16:40:08 --> Final output sent to browser
DEBUG - 2018-08-03 16:40:08 --> Total execution time: 0.0512
INFO - 2018-08-03 20:00:50 --> Config Class Initialized
INFO - 2018-08-03 20:00:50 --> Hooks Class Initialized
DEBUG - 2018-08-03 20:00:50 --> UTF-8 Support Enabled
INFO - 2018-08-03 20:00:50 --> Utf8 Class Initialized
INFO - 2018-08-03 20:00:50 --> URI Class Initialized
INFO - 2018-08-03 20:00:50 --> Router Class Initialized
INFO - 2018-08-03 20:00:50 --> Output Class Initialized
INFO - 2018-08-03 20:00:50 --> Security Class Initialized
DEBUG - 2018-08-03 20:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 20:00:50 --> CSRF cookie sent
INFO - 2018-08-03 20:00:50 --> Input Class Initialized
INFO - 2018-08-03 20:00:50 --> Language Class Initialized
ERROR - 2018-08-03 20:00:50 --> 404 Page Not Found: 401shtml/index
INFO - 2018-08-03 20:00:50 --> Config Class Initialized
INFO - 2018-08-03 20:00:50 --> Hooks Class Initialized
DEBUG - 2018-08-03 20:00:50 --> UTF-8 Support Enabled
INFO - 2018-08-03 20:00:50 --> Utf8 Class Initialized
INFO - 2018-08-03 20:00:50 --> URI Class Initialized
INFO - 2018-08-03 20:00:50 --> Router Class Initialized
INFO - 2018-08-03 20:00:50 --> Output Class Initialized
INFO - 2018-08-03 20:00:50 --> Security Class Initialized
DEBUG - 2018-08-03 20:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 20:00:50 --> CSRF cookie sent
INFO - 2018-08-03 20:00:50 --> Input Class Initialized
INFO - 2018-08-03 20:00:50 --> Language Class Initialized
ERROR - 2018-08-03 20:00:50 --> 404 Page Not Found: Faviconico/index
INFO - 2018-08-03 20:00:54 --> Config Class Initialized
INFO - 2018-08-03 20:00:54 --> Hooks Class Initialized
DEBUG - 2018-08-03 20:00:54 --> UTF-8 Support Enabled
INFO - 2018-08-03 20:00:54 --> Utf8 Class Initialized
INFO - 2018-08-03 20:00:54 --> URI Class Initialized
DEBUG - 2018-08-03 20:00:54 --> No URI present. Default controller set.
INFO - 2018-08-03 20:00:54 --> Router Class Initialized
INFO - 2018-08-03 20:00:54 --> Output Class Initialized
INFO - 2018-08-03 20:00:54 --> Security Class Initialized
DEBUG - 2018-08-03 20:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 20:00:54 --> CSRF cookie sent
INFO - 2018-08-03 20:00:54 --> Input Class Initialized
INFO - 2018-08-03 20:00:54 --> Language Class Initialized
INFO - 2018-08-03 20:00:54 --> Loader Class Initialized
INFO - 2018-08-03 20:00:54 --> Helper loaded: url_helper
INFO - 2018-08-03 20:00:54 --> Helper loaded: form_helper
INFO - 2018-08-03 20:00:54 --> Helper loaded: language_helper
DEBUG - 2018-08-03 20:00:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 20:00:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 20:00:54 --> User Agent Class Initialized
INFO - 2018-08-03 20:00:54 --> Controller Class Initialized
INFO - 2018-08-03 20:00:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-03 20:00:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-03 20:00:54 --> Pixel_Model class loaded
INFO - 2018-08-03 20:00:54 --> Database Driver Class Initialized
INFO - 2018-08-03 20:00:54 --> Model "QuestionsModel" initialized
INFO - 2018-08-03 20:00:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-03 20:00:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-03 20:00:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-03 20:00:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-03 20:00:54 --> Final output sent to browser
DEBUG - 2018-08-03 20:00:54 --> Total execution time: 0.0338
INFO - 2018-08-03 20:01:00 --> Config Class Initialized
INFO - 2018-08-03 20:01:00 --> Hooks Class Initialized
DEBUG - 2018-08-03 20:01:00 --> UTF-8 Support Enabled
INFO - 2018-08-03 20:01:00 --> Utf8 Class Initialized
INFO - 2018-08-03 20:01:00 --> URI Class Initialized
INFO - 2018-08-03 20:01:00 --> Router Class Initialized
INFO - 2018-08-03 20:01:00 --> Output Class Initialized
INFO - 2018-08-03 20:01:00 --> Security Class Initialized
DEBUG - 2018-08-03 20:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 20:01:00 --> CSRF cookie sent
INFO - 2018-08-03 20:01:00 --> Input Class Initialized
INFO - 2018-08-03 20:01:00 --> Language Class Initialized
INFO - 2018-08-03 20:01:00 --> Loader Class Initialized
INFO - 2018-08-03 20:01:00 --> Helper loaded: url_helper
INFO - 2018-08-03 20:01:00 --> Helper loaded: form_helper
INFO - 2018-08-03 20:01:00 --> Helper loaded: language_helper
DEBUG - 2018-08-03 20:01:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 20:01:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 20:01:00 --> User Agent Class Initialized
INFO - 2018-08-03 20:01:00 --> Controller Class Initialized
INFO - 2018-08-03 20:01:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-03 20:01:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-03 20:01:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-03 20:01:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-03 20:01:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-03 20:01:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-03 20:01:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-08-03 20:01:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-03 20:01:00 --> Final output sent to browser
DEBUG - 2018-08-03 20:01:00 --> Total execution time: 0.0227
INFO - 2018-08-03 20:01:02 --> Config Class Initialized
INFO - 2018-08-03 20:01:02 --> Hooks Class Initialized
DEBUG - 2018-08-03 20:01:02 --> UTF-8 Support Enabled
INFO - 2018-08-03 20:01:02 --> Utf8 Class Initialized
INFO - 2018-08-03 20:01:02 --> URI Class Initialized
INFO - 2018-08-03 20:01:02 --> Router Class Initialized
INFO - 2018-08-03 20:01:02 --> Output Class Initialized
INFO - 2018-08-03 20:01:02 --> Security Class Initialized
DEBUG - 2018-08-03 20:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 20:01:02 --> CSRF cookie sent
INFO - 2018-08-03 20:01:02 --> Input Class Initialized
INFO - 2018-08-03 20:01:02 --> Language Class Initialized
INFO - 2018-08-03 20:01:02 --> Loader Class Initialized
INFO - 2018-08-03 20:01:02 --> Helper loaded: url_helper
INFO - 2018-08-03 20:01:02 --> Helper loaded: form_helper
INFO - 2018-08-03 20:01:02 --> Helper loaded: language_helper
DEBUG - 2018-08-03 20:01:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 20:01:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 20:01:02 --> User Agent Class Initialized
INFO - 2018-08-03 20:01:02 --> Controller Class Initialized
INFO - 2018-08-03 20:01:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-03 20:01:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-03 20:01:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-03 20:01:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-03 20:01:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-03 20:01:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-03 20:01:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/faq_lawyer.php
INFO - 2018-08-03 20:01:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-03 20:01:02 --> Final output sent to browser
DEBUG - 2018-08-03 20:01:02 --> Total execution time: 0.0387

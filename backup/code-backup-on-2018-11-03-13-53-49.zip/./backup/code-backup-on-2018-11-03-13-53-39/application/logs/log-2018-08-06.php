<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-08-06 02:55:56 --> Config Class Initialized
INFO - 2018-08-06 02:55:56 --> Hooks Class Initialized
DEBUG - 2018-08-06 02:55:56 --> UTF-8 Support Enabled
INFO - 2018-08-06 02:55:56 --> Utf8 Class Initialized
INFO - 2018-08-06 02:55:56 --> URI Class Initialized
INFO - 2018-08-06 02:55:56 --> Router Class Initialized
INFO - 2018-08-06 02:55:56 --> Output Class Initialized
INFO - 2018-08-06 02:55:56 --> Security Class Initialized
DEBUG - 2018-08-06 02:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 02:55:56 --> CSRF cookie sent
INFO - 2018-08-06 02:55:56 --> Input Class Initialized
INFO - 2018-08-06 02:55:56 --> Language Class Initialized
INFO - 2018-08-06 02:55:56 --> Loader Class Initialized
INFO - 2018-08-06 02:55:56 --> Helper loaded: url_helper
INFO - 2018-08-06 02:55:56 --> Helper loaded: form_helper
INFO - 2018-08-06 02:55:56 --> Helper loaded: language_helper
DEBUG - 2018-08-06 02:55:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 02:55:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 02:55:56 --> User Agent Class Initialized
INFO - 2018-08-06 02:55:56 --> Controller Class Initialized
INFO - 2018-08-06 02:55:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-06 02:55:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-06 02:55:56 --> Pixel_Model class loaded
INFO - 2018-08-06 02:55:56 --> Database Driver Class Initialized
INFO - 2018-08-06 02:55:56 --> Model "QuestionsModel" initialized
INFO - 2018-08-06 02:55:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-06 02:55:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-06 02:55:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-06 02:55:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-06 02:55:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-06 02:55:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-06 02:55:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-08-06 02:55:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-06 02:55:56 --> Final output sent to browser
DEBUG - 2018-08-06 02:55:56 --> Total execution time: 0.0489
INFO - 2018-08-06 02:56:06 --> Config Class Initialized
INFO - 2018-08-06 02:56:06 --> Hooks Class Initialized
DEBUG - 2018-08-06 02:56:06 --> UTF-8 Support Enabled
INFO - 2018-08-06 02:56:06 --> Utf8 Class Initialized
INFO - 2018-08-06 02:56:06 --> URI Class Initialized
INFO - 2018-08-06 02:56:06 --> Router Class Initialized
INFO - 2018-08-06 02:56:06 --> Output Class Initialized
INFO - 2018-08-06 02:56:06 --> Security Class Initialized
DEBUG - 2018-08-06 02:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 02:56:06 --> CSRF cookie sent
INFO - 2018-08-06 02:56:06 --> Input Class Initialized
INFO - 2018-08-06 02:56:06 --> Language Class Initialized
INFO - 2018-08-06 02:56:06 --> Loader Class Initialized
INFO - 2018-08-06 02:56:06 --> Helper loaded: url_helper
INFO - 2018-08-06 02:56:06 --> Helper loaded: form_helper
INFO - 2018-08-06 02:56:06 --> Helper loaded: language_helper
DEBUG - 2018-08-06 02:56:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 02:56:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 02:56:06 --> User Agent Class Initialized
INFO - 2018-08-06 02:56:06 --> Controller Class Initialized
INFO - 2018-08-06 02:56:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-06 02:56:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-06 02:56:06 --> Pixel_Model class loaded
INFO - 2018-08-06 02:56:06 --> Database Driver Class Initialized
INFO - 2018-08-06 02:56:06 --> Model "QuestionsModel" initialized
INFO - 2018-08-06 02:56:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-06 02:56:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-06 02:56:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-06 02:56:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-06 02:56:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-06 02:56:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-06 02:56:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-08-06 02:56:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-06 02:56:06 --> Final output sent to browser
DEBUG - 2018-08-06 02:56:06 --> Total execution time: 0.0354
INFO - 2018-08-06 02:56:08 --> Config Class Initialized
INFO - 2018-08-06 02:56:08 --> Hooks Class Initialized
DEBUG - 2018-08-06 02:56:08 --> UTF-8 Support Enabled
INFO - 2018-08-06 02:56:08 --> Utf8 Class Initialized
INFO - 2018-08-06 02:56:08 --> URI Class Initialized
INFO - 2018-08-06 02:56:08 --> Router Class Initialized
INFO - 2018-08-06 02:56:08 --> Output Class Initialized
INFO - 2018-08-06 02:56:08 --> Security Class Initialized
DEBUG - 2018-08-06 02:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 02:56:08 --> CSRF cookie sent
INFO - 2018-08-06 02:56:08 --> Input Class Initialized
INFO - 2018-08-06 02:56:08 --> Language Class Initialized
INFO - 2018-08-06 02:56:08 --> Loader Class Initialized
INFO - 2018-08-06 02:56:08 --> Helper loaded: url_helper
INFO - 2018-08-06 02:56:08 --> Helper loaded: form_helper
INFO - 2018-08-06 02:56:08 --> Helper loaded: language_helper
DEBUG - 2018-08-06 02:56:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 02:56:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 02:56:08 --> User Agent Class Initialized
INFO - 2018-08-06 02:56:08 --> Controller Class Initialized
INFO - 2018-08-06 02:56:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-06 02:56:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-06 02:56:08 --> Pixel_Model class loaded
INFO - 2018-08-06 02:56:08 --> Database Driver Class Initialized
INFO - 2018-08-06 02:56:08 --> Model "QuestionsModel" initialized
INFO - 2018-08-06 02:56:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-06 02:56:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-06 02:56:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-06 02:56:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-06 02:56:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-06 02:56:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-06 02:56:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-08-06 02:56:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-06 02:56:08 --> Final output sent to browser
DEBUG - 2018-08-06 02:56:08 --> Total execution time: 0.0497
INFO - 2018-08-06 02:56:15 --> Config Class Initialized
INFO - 2018-08-06 02:56:15 --> Hooks Class Initialized
DEBUG - 2018-08-06 02:56:15 --> UTF-8 Support Enabled
INFO - 2018-08-06 02:56:15 --> Utf8 Class Initialized
INFO - 2018-08-06 02:56:15 --> URI Class Initialized
INFO - 2018-08-06 02:56:15 --> Router Class Initialized
INFO - 2018-08-06 02:56:15 --> Output Class Initialized
INFO - 2018-08-06 02:56:15 --> Security Class Initialized
DEBUG - 2018-08-06 02:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 02:56:15 --> CSRF cookie sent
INFO - 2018-08-06 02:56:15 --> Input Class Initialized
INFO - 2018-08-06 02:56:15 --> Language Class Initialized
INFO - 2018-08-06 02:56:15 --> Loader Class Initialized
INFO - 2018-08-06 02:56:15 --> Helper loaded: url_helper
INFO - 2018-08-06 02:56:15 --> Helper loaded: form_helper
INFO - 2018-08-06 02:56:15 --> Helper loaded: language_helper
DEBUG - 2018-08-06 02:56:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 02:56:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 02:56:15 --> User Agent Class Initialized
INFO - 2018-08-06 02:56:15 --> Controller Class Initialized
INFO - 2018-08-06 02:56:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-06 02:56:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-06 02:56:15 --> Pixel_Model class loaded
INFO - 2018-08-06 02:56:15 --> Database Driver Class Initialized
INFO - 2018-08-06 02:56:15 --> Model "QuestionsModel" initialized
INFO - 2018-08-06 02:56:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-06 02:56:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-06 02:56:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-06 02:56:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-06 02:56:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-06 02:56:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-06 02:56:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-08-06 02:56:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-06 02:56:15 --> Final output sent to browser
DEBUG - 2018-08-06 02:56:15 --> Total execution time: 0.0402
INFO - 2018-08-06 02:56:18 --> Config Class Initialized
INFO - 2018-08-06 02:56:18 --> Hooks Class Initialized
DEBUG - 2018-08-06 02:56:18 --> UTF-8 Support Enabled
INFO - 2018-08-06 02:56:18 --> Utf8 Class Initialized
INFO - 2018-08-06 02:56:18 --> URI Class Initialized
INFO - 2018-08-06 02:56:18 --> Router Class Initialized
INFO - 2018-08-06 02:56:18 --> Output Class Initialized
INFO - 2018-08-06 02:56:18 --> Security Class Initialized
DEBUG - 2018-08-06 02:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 02:56:18 --> CSRF cookie sent
INFO - 2018-08-06 02:56:18 --> Input Class Initialized
INFO - 2018-08-06 02:56:18 --> Language Class Initialized
INFO - 2018-08-06 02:56:18 --> Loader Class Initialized
INFO - 2018-08-06 02:56:18 --> Helper loaded: url_helper
INFO - 2018-08-06 02:56:18 --> Helper loaded: form_helper
INFO - 2018-08-06 02:56:18 --> Helper loaded: language_helper
DEBUG - 2018-08-06 02:56:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 02:56:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 02:56:18 --> User Agent Class Initialized
INFO - 2018-08-06 02:56:18 --> Controller Class Initialized
INFO - 2018-08-06 02:56:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-06 02:56:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-06 02:56:18 --> Pixel_Model class loaded
INFO - 2018-08-06 02:56:18 --> Database Driver Class Initialized
INFO - 2018-08-06 02:56:18 --> Model "QuestionsModel" initialized
INFO - 2018-08-06 02:56:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-06 02:56:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-06 02:56:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-06 02:56:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-06 02:56:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-06 02:56:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-06 02:56:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-08-06 02:56:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-06 02:56:18 --> Final output sent to browser
DEBUG - 2018-08-06 02:56:18 --> Total execution time: 0.0447
INFO - 2018-08-06 02:56:22 --> Config Class Initialized
INFO - 2018-08-06 02:56:22 --> Hooks Class Initialized
DEBUG - 2018-08-06 02:56:22 --> UTF-8 Support Enabled
INFO - 2018-08-06 02:56:22 --> Utf8 Class Initialized
INFO - 2018-08-06 02:56:22 --> URI Class Initialized
INFO - 2018-08-06 02:56:22 --> Router Class Initialized
INFO - 2018-08-06 02:56:22 --> Output Class Initialized
INFO - 2018-08-06 02:56:22 --> Security Class Initialized
DEBUG - 2018-08-06 02:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 02:56:22 --> CSRF cookie sent
INFO - 2018-08-06 02:56:22 --> Input Class Initialized
INFO - 2018-08-06 02:56:22 --> Language Class Initialized
INFO - 2018-08-06 02:56:22 --> Loader Class Initialized
INFO - 2018-08-06 02:56:22 --> Helper loaded: url_helper
INFO - 2018-08-06 02:56:22 --> Helper loaded: form_helper
INFO - 2018-08-06 02:56:22 --> Helper loaded: language_helper
DEBUG - 2018-08-06 02:56:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 02:56:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 02:56:22 --> User Agent Class Initialized
INFO - 2018-08-06 02:56:22 --> Controller Class Initialized
INFO - 2018-08-06 02:56:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-06 02:56:22 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-08-06 02:56:22 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-08-06 02:56:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-06 02:56:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-06 02:56:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-06 02:56:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-08-06 02:56:22 --> Could not find the language line "req_email"
INFO - 2018-08-06 02:56:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-08-06 02:56:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-06 02:56:22 --> Final output sent to browser
DEBUG - 2018-08-06 02:56:22 --> Total execution time: 0.0228
INFO - 2018-08-06 02:56:45 --> Config Class Initialized
INFO - 2018-08-06 02:56:45 --> Hooks Class Initialized
DEBUG - 2018-08-06 02:56:45 --> UTF-8 Support Enabled
INFO - 2018-08-06 02:56:45 --> Utf8 Class Initialized
INFO - 2018-08-06 02:56:45 --> URI Class Initialized
INFO - 2018-08-06 02:56:45 --> Router Class Initialized
INFO - 2018-08-06 02:56:45 --> Output Class Initialized
INFO - 2018-08-06 02:56:45 --> Security Class Initialized
DEBUG - 2018-08-06 02:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 02:56:45 --> CSRF cookie sent
INFO - 2018-08-06 02:56:45 --> Input Class Initialized
INFO - 2018-08-06 02:56:45 --> Language Class Initialized
INFO - 2018-08-06 02:56:45 --> Loader Class Initialized
INFO - 2018-08-06 02:56:45 --> Helper loaded: url_helper
INFO - 2018-08-06 02:56:45 --> Helper loaded: form_helper
INFO - 2018-08-06 02:56:45 --> Helper loaded: language_helper
DEBUG - 2018-08-06 02:56:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 02:56:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 02:56:45 --> User Agent Class Initialized
INFO - 2018-08-06 02:56:45 --> Controller Class Initialized
INFO - 2018-08-06 02:56:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-06 02:56:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-06 02:56:45 --> Pixel_Model class loaded
INFO - 2018-08-06 02:56:45 --> Database Driver Class Initialized
INFO - 2018-08-06 02:56:45 --> Model "RegistrationModel" initialized
DEBUG - 2018-08-06 02:56:45 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-08-06 02:56:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-06 02:56:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-06 02:56:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-06 02:56:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-06 02:56:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/temp.php
INFO - 2018-08-06 02:56:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-06 02:56:45 --> Final output sent to browser
DEBUG - 2018-08-06 02:56:45 --> Total execution time: 0.0388
INFO - 2018-08-06 02:56:51 --> Config Class Initialized
INFO - 2018-08-06 02:56:51 --> Hooks Class Initialized
DEBUG - 2018-08-06 02:56:51 --> UTF-8 Support Enabled
INFO - 2018-08-06 02:56:51 --> Utf8 Class Initialized
INFO - 2018-08-06 02:56:51 --> URI Class Initialized
DEBUG - 2018-08-06 02:56:51 --> No URI present. Default controller set.
INFO - 2018-08-06 02:56:51 --> Router Class Initialized
INFO - 2018-08-06 02:56:51 --> Output Class Initialized
INFO - 2018-08-06 02:56:51 --> Security Class Initialized
DEBUG - 2018-08-06 02:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 02:56:51 --> CSRF cookie sent
INFO - 2018-08-06 02:56:51 --> Input Class Initialized
INFO - 2018-08-06 02:56:51 --> Language Class Initialized
INFO - 2018-08-06 02:56:51 --> Loader Class Initialized
INFO - 2018-08-06 02:56:51 --> Helper loaded: url_helper
INFO - 2018-08-06 02:56:51 --> Helper loaded: form_helper
INFO - 2018-08-06 02:56:51 --> Helper loaded: language_helper
DEBUG - 2018-08-06 02:56:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 02:56:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 02:56:51 --> User Agent Class Initialized
INFO - 2018-08-06 02:56:51 --> Controller Class Initialized
INFO - 2018-08-06 02:56:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-06 02:56:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-06 02:56:51 --> Pixel_Model class loaded
INFO - 2018-08-06 02:56:51 --> Database Driver Class Initialized
INFO - 2018-08-06 02:56:51 --> Model "QuestionsModel" initialized
INFO - 2018-08-06 02:56:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-06 02:56:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-06 02:56:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-06 02:56:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-06 02:56:51 --> Final output sent to browser
DEBUG - 2018-08-06 02:56:51 --> Total execution time: 0.0383
INFO - 2018-08-06 02:57:05 --> Config Class Initialized
INFO - 2018-08-06 02:57:05 --> Hooks Class Initialized
DEBUG - 2018-08-06 02:57:05 --> UTF-8 Support Enabled
INFO - 2018-08-06 02:57:05 --> Utf8 Class Initialized
INFO - 2018-08-06 02:57:05 --> URI Class Initialized
INFO - 2018-08-06 02:57:05 --> Router Class Initialized
INFO - 2018-08-06 02:57:05 --> Output Class Initialized
INFO - 2018-08-06 02:57:05 --> Security Class Initialized
DEBUG - 2018-08-06 02:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 02:57:05 --> CSRF cookie sent
INFO - 2018-08-06 02:57:05 --> CSRF token verified
INFO - 2018-08-06 02:57:05 --> Input Class Initialized
INFO - 2018-08-06 02:57:05 --> Language Class Initialized
INFO - 2018-08-06 02:57:05 --> Loader Class Initialized
INFO - 2018-08-06 02:57:05 --> Helper loaded: url_helper
INFO - 2018-08-06 02:57:05 --> Helper loaded: form_helper
INFO - 2018-08-06 02:57:05 --> Helper loaded: language_helper
DEBUG - 2018-08-06 02:57:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 02:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 02:57:05 --> User Agent Class Initialized
INFO - 2018-08-06 02:57:05 --> Controller Class Initialized
INFO - 2018-08-06 02:57:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-06 02:57:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-06 02:57:05 --> Pixel_Model class loaded
INFO - 2018-08-06 02:57:05 --> Database Driver Class Initialized
INFO - 2018-08-06 02:57:05 --> Model "QuestionsModel" initialized
INFO - 2018-08-06 02:57:05 --> Database Driver Class Initialized
INFO - 2018-08-06 02:57:05 --> Model "QuestionsModel" initialized
INFO - 2018-08-06 02:57:05 --> Config Class Initialized
INFO - 2018-08-06 02:57:05 --> Hooks Class Initialized
DEBUG - 2018-08-06 02:57:05 --> UTF-8 Support Enabled
INFO - 2018-08-06 02:57:05 --> Utf8 Class Initialized
INFO - 2018-08-06 02:57:05 --> URI Class Initialized
INFO - 2018-08-06 02:57:05 --> Router Class Initialized
INFO - 2018-08-06 02:57:05 --> Output Class Initialized
INFO - 2018-08-06 02:57:05 --> Security Class Initialized
DEBUG - 2018-08-06 02:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 02:57:05 --> CSRF cookie sent
INFO - 2018-08-06 02:57:05 --> Input Class Initialized
INFO - 2018-08-06 02:57:05 --> Language Class Initialized
INFO - 2018-08-06 02:57:05 --> Loader Class Initialized
INFO - 2018-08-06 02:57:05 --> Helper loaded: url_helper
INFO - 2018-08-06 02:57:05 --> Helper loaded: form_helper
INFO - 2018-08-06 02:57:05 --> Helper loaded: language_helper
DEBUG - 2018-08-06 02:57:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 02:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 02:57:05 --> User Agent Class Initialized
INFO - 2018-08-06 02:57:05 --> Controller Class Initialized
INFO - 2018-08-06 02:57:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-06 02:57:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-06 02:57:05 --> Pixel_Model class loaded
INFO - 2018-08-06 02:57:05 --> Database Driver Class Initialized
INFO - 2018-08-06 02:57:05 --> Model "QuestionsModel" initialized
INFO - 2018-08-06 02:57:05 --> Database Driver Class Initialized
INFO - 2018-08-06 02:57:05 --> Model "QuestionsModel" initialized
INFO - 2018-08-06 02:57:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-06 02:57:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-06 02:57:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-06 02:57:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-06 02:57:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-06 02:57:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-06 02:57:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-06 02:57:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-06 02:57:05 --> Final output sent to browser
DEBUG - 2018-08-06 02:57:05 --> Total execution time: 0.0439
INFO - 2018-08-06 02:57:14 --> Config Class Initialized
INFO - 2018-08-06 02:57:14 --> Hooks Class Initialized
DEBUG - 2018-08-06 02:57:14 --> UTF-8 Support Enabled
INFO - 2018-08-06 02:57:14 --> Utf8 Class Initialized
INFO - 2018-08-06 02:57:14 --> URI Class Initialized
INFO - 2018-08-06 02:57:14 --> Router Class Initialized
INFO - 2018-08-06 02:57:14 --> Output Class Initialized
INFO - 2018-08-06 02:57:14 --> Security Class Initialized
DEBUG - 2018-08-06 02:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 02:57:14 --> CSRF cookie sent
INFO - 2018-08-06 02:57:14 --> CSRF token verified
INFO - 2018-08-06 02:57:14 --> Input Class Initialized
INFO - 2018-08-06 02:57:14 --> Language Class Initialized
INFO - 2018-08-06 02:57:14 --> Loader Class Initialized
INFO - 2018-08-06 02:57:14 --> Helper loaded: url_helper
INFO - 2018-08-06 02:57:14 --> Helper loaded: form_helper
INFO - 2018-08-06 02:57:14 --> Helper loaded: language_helper
DEBUG - 2018-08-06 02:57:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 02:57:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 02:57:14 --> User Agent Class Initialized
INFO - 2018-08-06 02:57:14 --> Controller Class Initialized
INFO - 2018-08-06 02:57:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-06 02:57:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-06 02:57:14 --> Pixel_Model class loaded
INFO - 2018-08-06 02:57:14 --> Database Driver Class Initialized
INFO - 2018-08-06 02:57:14 --> Model "QuestionsModel" initialized
INFO - 2018-08-06 02:57:14 --> Form Validation Class Initialized
INFO - 2018-08-06 02:57:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-06 02:57:14 --> Database Driver Class Initialized
INFO - 2018-08-06 02:57:14 --> Model "QuestionsModel" initialized
INFO - 2018-08-06 02:57:14 --> Config Class Initialized
INFO - 2018-08-06 02:57:14 --> Hooks Class Initialized
DEBUG - 2018-08-06 02:57:15 --> UTF-8 Support Enabled
INFO - 2018-08-06 02:57:15 --> Utf8 Class Initialized
INFO - 2018-08-06 02:57:15 --> URI Class Initialized
INFO - 2018-08-06 02:57:15 --> Router Class Initialized
INFO - 2018-08-06 02:57:15 --> Output Class Initialized
INFO - 2018-08-06 02:57:15 --> Security Class Initialized
DEBUG - 2018-08-06 02:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 02:57:15 --> CSRF cookie sent
INFO - 2018-08-06 02:57:15 --> Input Class Initialized
INFO - 2018-08-06 02:57:15 --> Language Class Initialized
INFO - 2018-08-06 02:57:15 --> Loader Class Initialized
INFO - 2018-08-06 02:57:15 --> Helper loaded: url_helper
INFO - 2018-08-06 02:57:15 --> Helper loaded: form_helper
INFO - 2018-08-06 02:57:15 --> Helper loaded: language_helper
DEBUG - 2018-08-06 02:57:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 02:57:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 02:57:15 --> User Agent Class Initialized
INFO - 2018-08-06 02:57:15 --> Controller Class Initialized
INFO - 2018-08-06 02:57:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-06 02:57:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-06 02:57:15 --> Pixel_Model class loaded
INFO - 2018-08-06 02:57:15 --> Database Driver Class Initialized
INFO - 2018-08-06 02:57:15 --> Model "QuestionsModel" initialized
INFO - 2018-08-06 02:57:15 --> Database Driver Class Initialized
INFO - 2018-08-06 02:57:15 --> Model "QuestionsModel" initialized
INFO - 2018-08-06 02:57:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-06 02:57:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-06 02:57:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-06 02:57:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-06 02:57:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-06 02:57:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-06 02:57:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-08-06 02:57:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-06 02:57:15 --> Final output sent to browser
DEBUG - 2018-08-06 02:57:15 --> Total execution time: 0.0471
INFO - 2018-08-06 02:57:21 --> Config Class Initialized
INFO - 2018-08-06 02:57:21 --> Hooks Class Initialized
DEBUG - 2018-08-06 02:57:21 --> UTF-8 Support Enabled
INFO - 2018-08-06 02:57:21 --> Utf8 Class Initialized
INFO - 2018-08-06 02:57:21 --> URI Class Initialized
INFO - 2018-08-06 02:57:21 --> Router Class Initialized
INFO - 2018-08-06 02:57:21 --> Output Class Initialized
INFO - 2018-08-06 02:57:21 --> Security Class Initialized
DEBUG - 2018-08-06 02:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 02:57:21 --> CSRF cookie sent
INFO - 2018-08-06 02:57:21 --> CSRF token verified
INFO - 2018-08-06 02:57:21 --> Input Class Initialized
INFO - 2018-08-06 02:57:21 --> Language Class Initialized
INFO - 2018-08-06 02:57:21 --> Loader Class Initialized
INFO - 2018-08-06 02:57:21 --> Helper loaded: url_helper
INFO - 2018-08-06 02:57:21 --> Helper loaded: form_helper
INFO - 2018-08-06 02:57:21 --> Helper loaded: language_helper
DEBUG - 2018-08-06 02:57:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 02:57:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 02:57:21 --> User Agent Class Initialized
INFO - 2018-08-06 02:57:21 --> Controller Class Initialized
INFO - 2018-08-06 02:57:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-06 02:57:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-06 02:57:21 --> Pixel_Model class loaded
INFO - 2018-08-06 02:57:21 --> Database Driver Class Initialized
INFO - 2018-08-06 02:57:21 --> Model "QuestionsModel" initialized
INFO - 2018-08-06 02:57:21 --> Form Validation Class Initialized
INFO - 2018-08-06 02:57:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-06 02:57:21 --> Database Driver Class Initialized
INFO - 2018-08-06 02:57:21 --> Model "QuestionsModel" initialized
INFO - 2018-08-06 02:57:21 --> Config Class Initialized
INFO - 2018-08-06 02:57:21 --> Hooks Class Initialized
DEBUG - 2018-08-06 02:57:21 --> UTF-8 Support Enabled
INFO - 2018-08-06 02:57:21 --> Utf8 Class Initialized
INFO - 2018-08-06 02:57:21 --> URI Class Initialized
INFO - 2018-08-06 02:57:21 --> Router Class Initialized
INFO - 2018-08-06 02:57:21 --> Output Class Initialized
INFO - 2018-08-06 02:57:21 --> Security Class Initialized
DEBUG - 2018-08-06 02:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 02:57:21 --> CSRF cookie sent
INFO - 2018-08-06 02:57:21 --> Input Class Initialized
INFO - 2018-08-06 02:57:21 --> Language Class Initialized
INFO - 2018-08-06 02:57:21 --> Loader Class Initialized
INFO - 2018-08-06 02:57:21 --> Helper loaded: url_helper
INFO - 2018-08-06 02:57:21 --> Helper loaded: form_helper
INFO - 2018-08-06 02:57:21 --> Helper loaded: language_helper
DEBUG - 2018-08-06 02:57:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 02:57:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 02:57:21 --> User Agent Class Initialized
INFO - 2018-08-06 02:57:21 --> Controller Class Initialized
INFO - 2018-08-06 02:57:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-06 02:57:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-06 02:57:21 --> Pixel_Model class loaded
INFO - 2018-08-06 02:57:21 --> Database Driver Class Initialized
INFO - 2018-08-06 02:57:21 --> Model "QuestionsModel" initialized
INFO - 2018-08-06 02:57:21 --> Database Driver Class Initialized
INFO - 2018-08-06 02:57:21 --> Model "QuestionsModel" initialized
INFO - 2018-08-06 02:57:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-06 02:57:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-06 02:57:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-08-06 02:57:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-06 02:57:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-06 02:57:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-06 02:57:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-06 02:57:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-08-06 02:57:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-06 02:57:21 --> Final output sent to browser
DEBUG - 2018-08-06 02:57:21 --> Total execution time: 0.0386
INFO - 2018-08-06 02:57:27 --> Config Class Initialized
INFO - 2018-08-06 02:57:27 --> Hooks Class Initialized
DEBUG - 2018-08-06 02:57:27 --> UTF-8 Support Enabled
INFO - 2018-08-06 02:57:27 --> Utf8 Class Initialized
INFO - 2018-08-06 02:57:27 --> URI Class Initialized
INFO - 2018-08-06 02:57:27 --> Router Class Initialized
INFO - 2018-08-06 02:57:27 --> Output Class Initialized
INFO - 2018-08-06 02:57:27 --> Security Class Initialized
DEBUG - 2018-08-06 02:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 02:57:27 --> CSRF cookie sent
INFO - 2018-08-06 02:57:27 --> CSRF token verified
INFO - 2018-08-06 02:57:27 --> Input Class Initialized
INFO - 2018-08-06 02:57:27 --> Language Class Initialized
INFO - 2018-08-06 02:57:27 --> Loader Class Initialized
INFO - 2018-08-06 02:57:27 --> Helper loaded: url_helper
INFO - 2018-08-06 02:57:27 --> Helper loaded: form_helper
INFO - 2018-08-06 02:57:27 --> Helper loaded: language_helper
DEBUG - 2018-08-06 02:57:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 02:57:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 02:57:27 --> User Agent Class Initialized
INFO - 2018-08-06 02:57:27 --> Controller Class Initialized
INFO - 2018-08-06 02:57:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-06 02:57:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-06 02:57:27 --> Pixel_Model class loaded
INFO - 2018-08-06 02:57:27 --> Database Driver Class Initialized
INFO - 2018-08-06 02:57:27 --> Model "QuestionsModel" initialized
INFO - 2018-08-06 02:57:27 --> Form Validation Class Initialized
INFO - 2018-08-06 02:57:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-06 02:57:27 --> Database Driver Class Initialized
INFO - 2018-08-06 02:57:27 --> Model "QuestionsModel" initialized
INFO - 2018-08-06 02:57:27 --> Config Class Initialized
INFO - 2018-08-06 02:57:27 --> Hooks Class Initialized
DEBUG - 2018-08-06 02:57:27 --> UTF-8 Support Enabled
INFO - 2018-08-06 02:57:27 --> Utf8 Class Initialized
INFO - 2018-08-06 02:57:27 --> URI Class Initialized
INFO - 2018-08-06 02:57:27 --> Router Class Initialized
INFO - 2018-08-06 02:57:27 --> Output Class Initialized
INFO - 2018-08-06 02:57:27 --> Security Class Initialized
DEBUG - 2018-08-06 02:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 02:57:27 --> CSRF cookie sent
INFO - 2018-08-06 02:57:27 --> Input Class Initialized
INFO - 2018-08-06 02:57:27 --> Language Class Initialized
INFO - 2018-08-06 02:57:27 --> Loader Class Initialized
INFO - 2018-08-06 02:57:27 --> Helper loaded: url_helper
INFO - 2018-08-06 02:57:27 --> Helper loaded: form_helper
INFO - 2018-08-06 02:57:27 --> Helper loaded: language_helper
DEBUG - 2018-08-06 02:57:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 02:57:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 02:57:27 --> User Agent Class Initialized
INFO - 2018-08-06 02:57:27 --> Controller Class Initialized
INFO - 2018-08-06 02:57:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-06 02:57:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-06 02:57:27 --> Pixel_Model class loaded
INFO - 2018-08-06 02:57:27 --> Database Driver Class Initialized
INFO - 2018-08-06 02:57:27 --> Model "QuestionsModel" initialized
INFO - 2018-08-06 02:57:27 --> Database Driver Class Initialized
INFO - 2018-08-06 02:57:27 --> Model "QuestionsModel" initialized
INFO - 2018-08-06 02:57:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-06 02:57:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-06 02:57:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-06 02:57:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-06 02:57:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-06 02:57:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-06 02:57:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-08-06 02:57:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-06 02:57:27 --> Final output sent to browser
DEBUG - 2018-08-06 02:57:27 --> Total execution time: 0.0444
INFO - 2018-08-06 03:51:15 --> Config Class Initialized
INFO - 2018-08-06 03:51:15 --> Hooks Class Initialized
DEBUG - 2018-08-06 03:51:15 --> UTF-8 Support Enabled
INFO - 2018-08-06 03:51:15 --> Utf8 Class Initialized
INFO - 2018-08-06 03:51:15 --> URI Class Initialized
DEBUG - 2018-08-06 03:51:15 --> No URI present. Default controller set.
INFO - 2018-08-06 03:51:15 --> Router Class Initialized
INFO - 2018-08-06 03:51:15 --> Output Class Initialized
INFO - 2018-08-06 03:51:15 --> Security Class Initialized
DEBUG - 2018-08-06 03:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 03:51:15 --> CSRF cookie sent
INFO - 2018-08-06 03:51:15 --> Input Class Initialized
INFO - 2018-08-06 03:51:15 --> Language Class Initialized
INFO - 2018-08-06 03:51:15 --> Loader Class Initialized
INFO - 2018-08-06 03:51:15 --> Helper loaded: url_helper
INFO - 2018-08-06 03:51:15 --> Helper loaded: form_helper
INFO - 2018-08-06 03:51:15 --> Helper loaded: language_helper
DEBUG - 2018-08-06 03:51:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 03:51:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 03:51:15 --> User Agent Class Initialized
INFO - 2018-08-06 03:51:15 --> Controller Class Initialized
INFO - 2018-08-06 03:51:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-06 03:51:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-06 03:51:15 --> Pixel_Model class loaded
INFO - 2018-08-06 03:51:15 --> Database Driver Class Initialized
INFO - 2018-08-06 03:51:15 --> Model "QuestionsModel" initialized
INFO - 2018-08-06 03:51:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-06 03:51:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-06 03:51:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-06 03:51:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-06 03:51:15 --> Final output sent to browser
DEBUG - 2018-08-06 03:51:15 --> Total execution time: 0.0428
INFO - 2018-08-06 03:51:21 --> Config Class Initialized
INFO - 2018-08-06 03:51:21 --> Hooks Class Initialized
DEBUG - 2018-08-06 03:51:21 --> UTF-8 Support Enabled
INFO - 2018-08-06 03:51:21 --> Utf8 Class Initialized
INFO - 2018-08-06 03:51:21 --> URI Class Initialized
INFO - 2018-08-06 03:51:21 --> Router Class Initialized
INFO - 2018-08-06 03:51:21 --> Output Class Initialized
INFO - 2018-08-06 03:51:21 --> Security Class Initialized
DEBUG - 2018-08-06 03:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 03:51:21 --> CSRF cookie sent
INFO - 2018-08-06 03:51:21 --> CSRF token verified
INFO - 2018-08-06 03:51:21 --> Input Class Initialized
INFO - 2018-08-06 03:51:21 --> Language Class Initialized
INFO - 2018-08-06 03:51:21 --> Loader Class Initialized
INFO - 2018-08-06 03:51:21 --> Helper loaded: url_helper
INFO - 2018-08-06 03:51:21 --> Helper loaded: form_helper
INFO - 2018-08-06 03:51:21 --> Helper loaded: language_helper
DEBUG - 2018-08-06 03:51:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 03:51:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 03:51:21 --> User Agent Class Initialized
INFO - 2018-08-06 03:51:21 --> Controller Class Initialized
INFO - 2018-08-06 03:51:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-06 03:51:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-06 03:51:21 --> Pixel_Model class loaded
INFO - 2018-08-06 03:51:21 --> Database Driver Class Initialized
INFO - 2018-08-06 03:51:21 --> Model "QuestionsModel" initialized
INFO - 2018-08-06 03:51:21 --> Database Driver Class Initialized
INFO - 2018-08-06 03:51:21 --> Model "QuestionsModel" initialized
INFO - 2018-08-06 03:51:21 --> Config Class Initialized
INFO - 2018-08-06 03:51:21 --> Hooks Class Initialized
DEBUG - 2018-08-06 03:51:21 --> UTF-8 Support Enabled
INFO - 2018-08-06 03:51:21 --> Utf8 Class Initialized
INFO - 2018-08-06 03:51:21 --> URI Class Initialized
INFO - 2018-08-06 03:51:21 --> Router Class Initialized
INFO - 2018-08-06 03:51:21 --> Output Class Initialized
INFO - 2018-08-06 03:51:21 --> Security Class Initialized
DEBUG - 2018-08-06 03:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 03:51:21 --> CSRF cookie sent
INFO - 2018-08-06 03:51:21 --> Input Class Initialized
INFO - 2018-08-06 03:51:21 --> Language Class Initialized
INFO - 2018-08-06 03:51:21 --> Loader Class Initialized
INFO - 2018-08-06 03:51:21 --> Helper loaded: url_helper
INFO - 2018-08-06 03:51:21 --> Helper loaded: form_helper
INFO - 2018-08-06 03:51:21 --> Helper loaded: language_helper
DEBUG - 2018-08-06 03:51:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 03:51:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 03:51:21 --> User Agent Class Initialized
INFO - 2018-08-06 03:51:21 --> Controller Class Initialized
INFO - 2018-08-06 03:51:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-06 03:51:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-06 03:51:21 --> Pixel_Model class loaded
INFO - 2018-08-06 03:51:21 --> Database Driver Class Initialized
INFO - 2018-08-06 03:51:21 --> Model "QuestionsModel" initialized
INFO - 2018-08-06 03:51:21 --> Database Driver Class Initialized
INFO - 2018-08-06 03:51:21 --> Model "QuestionsModel" initialized
INFO - 2018-08-06 03:51:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-06 03:51:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-06 03:51:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-06 03:51:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-06 03:51:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-06 03:51:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-06 03:51:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-06 03:51:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-06 03:51:21 --> Final output sent to browser
DEBUG - 2018-08-06 03:51:21 --> Total execution time: 0.0461
INFO - 2018-08-06 03:51:29 --> Config Class Initialized
INFO - 2018-08-06 03:51:29 --> Hooks Class Initialized
DEBUG - 2018-08-06 03:51:29 --> UTF-8 Support Enabled
INFO - 2018-08-06 03:51:29 --> Utf8 Class Initialized
INFO - 2018-08-06 03:51:29 --> URI Class Initialized
INFO - 2018-08-06 03:51:29 --> Router Class Initialized
INFO - 2018-08-06 03:51:29 --> Output Class Initialized
INFO - 2018-08-06 03:51:29 --> Security Class Initialized
DEBUG - 2018-08-06 03:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 03:51:29 --> CSRF cookie sent
INFO - 2018-08-06 03:51:29 --> CSRF token verified
INFO - 2018-08-06 03:51:29 --> Input Class Initialized
INFO - 2018-08-06 03:51:29 --> Language Class Initialized
INFO - 2018-08-06 03:51:29 --> Loader Class Initialized
INFO - 2018-08-06 03:51:29 --> Helper loaded: url_helper
INFO - 2018-08-06 03:51:29 --> Helper loaded: form_helper
INFO - 2018-08-06 03:51:29 --> Helper loaded: language_helper
DEBUG - 2018-08-06 03:51:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 03:51:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 03:51:29 --> User Agent Class Initialized
INFO - 2018-08-06 03:51:29 --> Controller Class Initialized
INFO - 2018-08-06 03:51:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-06 03:51:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-06 03:51:29 --> Pixel_Model class loaded
INFO - 2018-08-06 03:51:29 --> Database Driver Class Initialized
INFO - 2018-08-06 03:51:29 --> Model "QuestionsModel" initialized
INFO - 2018-08-06 03:51:29 --> Form Validation Class Initialized
INFO - 2018-08-06 03:51:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-06 03:51:29 --> Database Driver Class Initialized
INFO - 2018-08-06 03:51:29 --> Model "QuestionsModel" initialized
INFO - 2018-08-06 03:51:29 --> Config Class Initialized
INFO - 2018-08-06 03:51:29 --> Hooks Class Initialized
DEBUG - 2018-08-06 03:51:29 --> UTF-8 Support Enabled
INFO - 2018-08-06 03:51:29 --> Utf8 Class Initialized
INFO - 2018-08-06 03:51:29 --> URI Class Initialized
INFO - 2018-08-06 03:51:29 --> Router Class Initialized
INFO - 2018-08-06 03:51:29 --> Output Class Initialized
INFO - 2018-08-06 03:51:29 --> Security Class Initialized
DEBUG - 2018-08-06 03:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 03:51:29 --> CSRF cookie sent
INFO - 2018-08-06 03:51:29 --> Input Class Initialized
INFO - 2018-08-06 03:51:29 --> Language Class Initialized
INFO - 2018-08-06 03:51:29 --> Loader Class Initialized
INFO - 2018-08-06 03:51:29 --> Helper loaded: url_helper
INFO - 2018-08-06 03:51:29 --> Helper loaded: form_helper
INFO - 2018-08-06 03:51:29 --> Helper loaded: language_helper
DEBUG - 2018-08-06 03:51:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 03:51:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 03:51:29 --> User Agent Class Initialized
INFO - 2018-08-06 03:51:29 --> Controller Class Initialized
INFO - 2018-08-06 03:51:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-06 03:51:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-06 03:51:29 --> Pixel_Model class loaded
INFO - 2018-08-06 03:51:29 --> Database Driver Class Initialized
INFO - 2018-08-06 03:51:29 --> Model "QuestionsModel" initialized
INFO - 2018-08-06 03:51:29 --> Database Driver Class Initialized
INFO - 2018-08-06 03:51:29 --> Model "QuestionsModel" initialized
INFO - 2018-08-06 03:51:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-06 03:51:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-06 03:51:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-06 03:51:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-06 03:51:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-06 03:51:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-06 03:51:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-08-06 03:51:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-06 03:51:29 --> Final output sent to browser
DEBUG - 2018-08-06 03:51:29 --> Total execution time: 0.0583
INFO - 2018-08-06 03:51:32 --> Config Class Initialized
INFO - 2018-08-06 03:51:32 --> Hooks Class Initialized
DEBUG - 2018-08-06 03:51:32 --> UTF-8 Support Enabled
INFO - 2018-08-06 03:51:32 --> Utf8 Class Initialized
INFO - 2018-08-06 03:51:32 --> URI Class Initialized
INFO - 2018-08-06 03:51:32 --> Router Class Initialized
INFO - 2018-08-06 03:51:32 --> Output Class Initialized
INFO - 2018-08-06 03:51:32 --> Security Class Initialized
DEBUG - 2018-08-06 03:51:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 03:51:32 --> CSRF cookie sent
INFO - 2018-08-06 03:51:32 --> CSRF token verified
INFO - 2018-08-06 03:51:32 --> Input Class Initialized
INFO - 2018-08-06 03:51:32 --> Language Class Initialized
INFO - 2018-08-06 03:51:32 --> Loader Class Initialized
INFO - 2018-08-06 03:51:32 --> Helper loaded: url_helper
INFO - 2018-08-06 03:51:32 --> Helper loaded: form_helper
INFO - 2018-08-06 03:51:32 --> Helper loaded: language_helper
DEBUG - 2018-08-06 03:51:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 03:51:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 03:51:32 --> User Agent Class Initialized
INFO - 2018-08-06 03:51:32 --> Controller Class Initialized
INFO - 2018-08-06 03:51:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-06 03:51:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-06 03:51:32 --> Pixel_Model class loaded
INFO - 2018-08-06 03:51:32 --> Database Driver Class Initialized
INFO - 2018-08-06 03:51:32 --> Model "QuestionsModel" initialized
INFO - 2018-08-06 03:51:32 --> Form Validation Class Initialized
INFO - 2018-08-06 03:51:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-06 03:51:32 --> Database Driver Class Initialized
INFO - 2018-08-06 03:51:32 --> Model "QuestionsModel" initialized
INFO - 2018-08-06 03:51:32 --> Config Class Initialized
INFO - 2018-08-06 03:51:32 --> Hooks Class Initialized
DEBUG - 2018-08-06 03:51:32 --> UTF-8 Support Enabled
INFO - 2018-08-06 03:51:32 --> Utf8 Class Initialized
INFO - 2018-08-06 03:51:33 --> URI Class Initialized
INFO - 2018-08-06 03:51:33 --> Router Class Initialized
INFO - 2018-08-06 03:51:33 --> Output Class Initialized
INFO - 2018-08-06 03:51:33 --> Security Class Initialized
DEBUG - 2018-08-06 03:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 03:51:33 --> CSRF cookie sent
INFO - 2018-08-06 03:51:33 --> Input Class Initialized
INFO - 2018-08-06 03:51:33 --> Language Class Initialized
INFO - 2018-08-06 03:51:33 --> Loader Class Initialized
INFO - 2018-08-06 03:51:33 --> Helper loaded: url_helper
INFO - 2018-08-06 03:51:33 --> Helper loaded: form_helper
INFO - 2018-08-06 03:51:33 --> Helper loaded: language_helper
DEBUG - 2018-08-06 03:51:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 03:51:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 03:51:33 --> User Agent Class Initialized
INFO - 2018-08-06 03:51:33 --> Controller Class Initialized
INFO - 2018-08-06 03:51:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-06 03:51:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-06 03:51:33 --> Pixel_Model class loaded
INFO - 2018-08-06 03:51:33 --> Database Driver Class Initialized
INFO - 2018-08-06 03:51:33 --> Model "QuestionsModel" initialized
INFO - 2018-08-06 03:51:33 --> Database Driver Class Initialized
INFO - 2018-08-06 03:51:33 --> Model "QuestionsModel" initialized
INFO - 2018-08-06 03:51:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-06 03:51:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-06 03:51:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-08-06 03:51:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-06 03:51:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-06 03:51:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-06 03:51:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-06 03:51:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-08-06 03:51:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-06 03:51:33 --> Final output sent to browser
DEBUG - 2018-08-06 03:51:33 --> Total execution time: 0.0470
INFO - 2018-08-06 03:51:35 --> Config Class Initialized
INFO - 2018-08-06 03:51:35 --> Hooks Class Initialized
DEBUG - 2018-08-06 03:51:35 --> UTF-8 Support Enabled
INFO - 2018-08-06 03:51:35 --> Utf8 Class Initialized
INFO - 2018-08-06 03:51:35 --> URI Class Initialized
INFO - 2018-08-06 03:51:35 --> Router Class Initialized
INFO - 2018-08-06 03:51:35 --> Output Class Initialized
INFO - 2018-08-06 03:51:35 --> Security Class Initialized
DEBUG - 2018-08-06 03:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 03:51:35 --> CSRF cookie sent
INFO - 2018-08-06 03:51:35 --> CSRF token verified
INFO - 2018-08-06 03:51:35 --> Input Class Initialized
INFO - 2018-08-06 03:51:35 --> Language Class Initialized
INFO - 2018-08-06 03:51:35 --> Loader Class Initialized
INFO - 2018-08-06 03:51:35 --> Helper loaded: url_helper
INFO - 2018-08-06 03:51:35 --> Helper loaded: form_helper
INFO - 2018-08-06 03:51:35 --> Helper loaded: language_helper
DEBUG - 2018-08-06 03:51:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 03:51:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 03:51:35 --> User Agent Class Initialized
INFO - 2018-08-06 03:51:35 --> Controller Class Initialized
INFO - 2018-08-06 03:51:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-06 03:51:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-06 03:51:35 --> Pixel_Model class loaded
INFO - 2018-08-06 03:51:35 --> Database Driver Class Initialized
INFO - 2018-08-06 03:51:35 --> Model "QuestionsModel" initialized
INFO - 2018-08-06 03:51:35 --> Form Validation Class Initialized
INFO - 2018-08-06 03:51:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-06 03:51:35 --> Database Driver Class Initialized
INFO - 2018-08-06 03:51:35 --> Model "QuestionsModel" initialized
INFO - 2018-08-06 03:51:36 --> Config Class Initialized
INFO - 2018-08-06 03:51:36 --> Hooks Class Initialized
DEBUG - 2018-08-06 03:51:36 --> UTF-8 Support Enabled
INFO - 2018-08-06 03:51:36 --> Utf8 Class Initialized
INFO - 2018-08-06 03:51:36 --> URI Class Initialized
INFO - 2018-08-06 03:51:36 --> Router Class Initialized
INFO - 2018-08-06 03:51:36 --> Output Class Initialized
INFO - 2018-08-06 03:51:36 --> Security Class Initialized
DEBUG - 2018-08-06 03:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 03:51:36 --> CSRF cookie sent
INFO - 2018-08-06 03:51:36 --> Input Class Initialized
INFO - 2018-08-06 03:51:36 --> Language Class Initialized
INFO - 2018-08-06 03:51:36 --> Loader Class Initialized
INFO - 2018-08-06 03:51:36 --> Helper loaded: url_helper
INFO - 2018-08-06 03:51:36 --> Helper loaded: form_helper
INFO - 2018-08-06 03:51:36 --> Helper loaded: language_helper
DEBUG - 2018-08-06 03:51:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 03:51:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 03:51:36 --> User Agent Class Initialized
INFO - 2018-08-06 03:51:36 --> Controller Class Initialized
INFO - 2018-08-06 03:51:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-06 03:51:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-06 03:51:36 --> Pixel_Model class loaded
INFO - 2018-08-06 03:51:36 --> Database Driver Class Initialized
INFO - 2018-08-06 03:51:36 --> Model "QuestionsModel" initialized
INFO - 2018-08-06 03:51:36 --> Database Driver Class Initialized
INFO - 2018-08-06 03:51:36 --> Model "QuestionsModel" initialized
INFO - 2018-08-06 03:51:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-06 03:51:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-06 03:51:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-06 03:51:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-06 03:51:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-06 03:51:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-06 03:51:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-08-06 03:51:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-06 03:51:36 --> Final output sent to browser
DEBUG - 2018-08-06 03:51:36 --> Total execution time: 0.0397
INFO - 2018-08-06 03:51:57 --> Config Class Initialized
INFO - 2018-08-06 03:51:57 --> Hooks Class Initialized
DEBUG - 2018-08-06 03:51:57 --> UTF-8 Support Enabled
INFO - 2018-08-06 03:51:57 --> Utf8 Class Initialized
INFO - 2018-08-06 03:51:57 --> URI Class Initialized
INFO - 2018-08-06 03:51:57 --> Router Class Initialized
INFO - 2018-08-06 03:51:57 --> Output Class Initialized
INFO - 2018-08-06 03:51:57 --> Security Class Initialized
DEBUG - 2018-08-06 03:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 03:51:57 --> CSRF cookie sent
INFO - 2018-08-06 03:51:57 --> CSRF token verified
INFO - 2018-08-06 03:51:57 --> Input Class Initialized
INFO - 2018-08-06 03:51:57 --> Language Class Initialized
INFO - 2018-08-06 03:51:57 --> Loader Class Initialized
INFO - 2018-08-06 03:51:57 --> Helper loaded: url_helper
INFO - 2018-08-06 03:51:57 --> Helper loaded: form_helper
INFO - 2018-08-06 03:51:57 --> Helper loaded: language_helper
DEBUG - 2018-08-06 03:51:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 03:51:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 03:51:57 --> User Agent Class Initialized
INFO - 2018-08-06 03:51:57 --> Controller Class Initialized
INFO - 2018-08-06 03:51:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-06 03:51:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-06 03:51:57 --> Pixel_Model class loaded
INFO - 2018-08-06 03:51:57 --> Database Driver Class Initialized
INFO - 2018-08-06 03:51:57 --> Model "QuestionsModel" initialized
INFO - 2018-08-06 03:51:57 --> Form Validation Class Initialized
INFO - 2018-08-06 03:51:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-06 03:51:57 --> Database Driver Class Initialized
INFO - 2018-08-06 03:51:57 --> Model "QuestionsModel" initialized
INFO - 2018-08-06 03:51:58 --> Config Class Initialized
INFO - 2018-08-06 03:51:58 --> Hooks Class Initialized
DEBUG - 2018-08-06 03:51:58 --> UTF-8 Support Enabled
INFO - 2018-08-06 03:51:58 --> Utf8 Class Initialized
INFO - 2018-08-06 03:51:58 --> URI Class Initialized
INFO - 2018-08-06 03:51:58 --> Router Class Initialized
INFO - 2018-08-06 03:51:58 --> Output Class Initialized
INFO - 2018-08-06 03:51:58 --> Security Class Initialized
DEBUG - 2018-08-06 03:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 03:51:58 --> CSRF cookie sent
INFO - 2018-08-06 03:51:58 --> Input Class Initialized
INFO - 2018-08-06 03:51:58 --> Language Class Initialized
INFO - 2018-08-06 03:51:58 --> Loader Class Initialized
INFO - 2018-08-06 03:51:58 --> Helper loaded: url_helper
INFO - 2018-08-06 03:51:58 --> Helper loaded: form_helper
INFO - 2018-08-06 03:51:58 --> Helper loaded: language_helper
DEBUG - 2018-08-06 03:51:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 03:51:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 03:51:58 --> User Agent Class Initialized
INFO - 2018-08-06 03:51:58 --> Controller Class Initialized
INFO - 2018-08-06 03:51:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-06 03:51:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-06 03:51:58 --> Pixel_Model class loaded
INFO - 2018-08-06 03:51:58 --> Database Driver Class Initialized
INFO - 2018-08-06 03:51:58 --> Model "QuestionsModel" initialized
INFO - 2018-08-06 03:51:58 --> Database Driver Class Initialized
INFO - 2018-08-06 03:51:58 --> Model "QuestionsModel" initialized
INFO - 2018-08-06 03:51:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-06 03:51:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-06 03:51:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-06 03:51:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-06 03:51:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-06 03:51:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-06 03:51:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-08-06 03:51:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-06 03:51:58 --> Final output sent to browser
DEBUG - 2018-08-06 03:51:58 --> Total execution time: 0.0525

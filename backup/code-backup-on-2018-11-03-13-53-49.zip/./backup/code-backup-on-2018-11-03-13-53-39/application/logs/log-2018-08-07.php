<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-08-07 13:26:03 --> Config Class Initialized
INFO - 2018-08-07 13:26:03 --> Hooks Class Initialized
DEBUG - 2018-08-07 13:26:03 --> UTF-8 Support Enabled
INFO - 2018-08-07 13:26:03 --> Utf8 Class Initialized
INFO - 2018-08-07 13:26:03 --> URI Class Initialized
INFO - 2018-08-07 13:26:03 --> Router Class Initialized
INFO - 2018-08-07 13:26:03 --> Output Class Initialized
INFO - 2018-08-07 13:26:03 --> Security Class Initialized
DEBUG - 2018-08-07 13:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-07 13:26:03 --> CSRF cookie sent
INFO - 2018-08-07 13:26:03 --> Input Class Initialized
INFO - 2018-08-07 13:26:03 --> Language Class Initialized
ERROR - 2018-08-07 13:26:03 --> 404 Page Not Found: 401shtml/index
INFO - 2018-08-07 13:26:03 --> Config Class Initialized
INFO - 2018-08-07 13:26:03 --> Hooks Class Initialized
DEBUG - 2018-08-07 13:26:03 --> UTF-8 Support Enabled
INFO - 2018-08-07 13:26:03 --> Utf8 Class Initialized
INFO - 2018-08-07 13:26:03 --> URI Class Initialized
INFO - 2018-08-07 13:26:03 --> Router Class Initialized
INFO - 2018-08-07 13:26:03 --> Output Class Initialized
INFO - 2018-08-07 13:26:03 --> Security Class Initialized
DEBUG - 2018-08-07 13:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-07 13:26:03 --> CSRF cookie sent
INFO - 2018-08-07 13:26:03 --> Input Class Initialized
INFO - 2018-08-07 13:26:03 --> Language Class Initialized
ERROR - 2018-08-07 13:26:03 --> 404 Page Not Found: Faviconico/index
INFO - 2018-08-07 13:26:06 --> Config Class Initialized
INFO - 2018-08-07 13:26:06 --> Hooks Class Initialized
DEBUG - 2018-08-07 13:26:06 --> UTF-8 Support Enabled
INFO - 2018-08-07 13:26:06 --> Utf8 Class Initialized
INFO - 2018-08-07 13:26:06 --> URI Class Initialized
DEBUG - 2018-08-07 13:26:06 --> No URI present. Default controller set.
INFO - 2018-08-07 13:26:06 --> Router Class Initialized
INFO - 2018-08-07 13:26:06 --> Output Class Initialized
INFO - 2018-08-07 13:26:06 --> Security Class Initialized
DEBUG - 2018-08-07 13:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-07 13:26:06 --> CSRF cookie sent
INFO - 2018-08-07 13:26:06 --> Input Class Initialized
INFO - 2018-08-07 13:26:06 --> Language Class Initialized
INFO - 2018-08-07 13:26:06 --> Loader Class Initialized
INFO - 2018-08-07 13:26:06 --> Helper loaded: url_helper
INFO - 2018-08-07 13:26:06 --> Helper loaded: form_helper
INFO - 2018-08-07 13:26:06 --> Helper loaded: language_helper
DEBUG - 2018-08-07 13:26:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-07 13:26:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-07 13:26:06 --> User Agent Class Initialized
INFO - 2018-08-07 13:26:06 --> Controller Class Initialized
INFO - 2018-08-07 13:26:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-07 13:26:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-07 13:26:06 --> Pixel_Model class loaded
INFO - 2018-08-07 13:26:06 --> Database Driver Class Initialized
INFO - 2018-08-07 13:26:06 --> Model "QuestionsModel" initialized
INFO - 2018-08-07 13:26:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-07 13:26:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-07 13:26:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-07 13:26:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-07 13:26:06 --> Final output sent to browser
DEBUG - 2018-08-07 13:26:06 --> Total execution time: 0.0341
INFO - 2018-08-07 13:26:11 --> Config Class Initialized
INFO - 2018-08-07 13:26:11 --> Hooks Class Initialized
DEBUG - 2018-08-07 13:26:11 --> UTF-8 Support Enabled
INFO - 2018-08-07 13:26:11 --> Utf8 Class Initialized
INFO - 2018-08-07 13:26:11 --> URI Class Initialized
INFO - 2018-08-07 13:26:11 --> Router Class Initialized
INFO - 2018-08-07 13:26:11 --> Output Class Initialized
INFO - 2018-08-07 13:26:11 --> Security Class Initialized
DEBUG - 2018-08-07 13:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-07 13:26:11 --> CSRF cookie sent
INFO - 2018-08-07 13:26:11 --> Input Class Initialized
INFO - 2018-08-07 13:26:11 --> Language Class Initialized
INFO - 2018-08-07 13:26:11 --> Loader Class Initialized
INFO - 2018-08-07 13:26:11 --> Helper loaded: url_helper
INFO - 2018-08-07 13:26:11 --> Helper loaded: form_helper
INFO - 2018-08-07 13:26:11 --> Helper loaded: language_helper
DEBUG - 2018-08-07 13:26:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-07 13:26:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-07 13:26:11 --> User Agent Class Initialized
INFO - 2018-08-07 13:26:11 --> Controller Class Initialized
INFO - 2018-08-07 13:26:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-07 13:26:11 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-08-07 13:26:11 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-08-07 13:26:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-07 13:26:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-07 13:26:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-07 13:26:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-08-07 13:26:11 --> Could not find the language line "req_email"
INFO - 2018-08-07 13:26:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-08-07 13:26:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-07 13:26:11 --> Final output sent to browser
DEBUG - 2018-08-07 13:26:11 --> Total execution time: 0.0314
INFO - 2018-08-07 13:26:13 --> Config Class Initialized
INFO - 2018-08-07 13:26:13 --> Hooks Class Initialized
DEBUG - 2018-08-07 13:26:13 --> UTF-8 Support Enabled
INFO - 2018-08-07 13:26:13 --> Utf8 Class Initialized
INFO - 2018-08-07 13:26:13 --> URI Class Initialized
INFO - 2018-08-07 13:26:13 --> Router Class Initialized
INFO - 2018-08-07 13:26:13 --> Output Class Initialized
INFO - 2018-08-07 13:26:13 --> Security Class Initialized
DEBUG - 2018-08-07 13:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-07 13:26:13 --> CSRF cookie sent
INFO - 2018-08-07 13:26:13 --> Input Class Initialized
INFO - 2018-08-07 13:26:13 --> Language Class Initialized
INFO - 2018-08-07 13:26:13 --> Loader Class Initialized
INFO - 2018-08-07 13:26:13 --> Helper loaded: url_helper
INFO - 2018-08-07 13:26:13 --> Helper loaded: form_helper
INFO - 2018-08-07 13:26:13 --> Helper loaded: language_helper
DEBUG - 2018-08-07 13:26:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-07 13:26:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-07 13:26:13 --> User Agent Class Initialized
INFO - 2018-08-07 13:26:13 --> Controller Class Initialized
INFO - 2018-08-07 13:26:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-07 13:26:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-07 13:26:13 --> Pixel_Model class loaded
INFO - 2018-08-07 13:26:13 --> Database Driver Class Initialized
INFO - 2018-08-07 13:26:13 --> Model "RegistrationModel" initialized
DEBUG - 2018-08-07 13:26:13 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-08-07 13:26:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-07 13:26:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-07 13:26:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-07 13:26:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-07 13:26:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/temp.php
INFO - 2018-08-07 13:26:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-07 13:26:13 --> Final output sent to browser
DEBUG - 2018-08-07 13:26:13 --> Total execution time: 0.0361
INFO - 2018-08-07 13:27:27 --> Config Class Initialized
INFO - 2018-08-07 13:27:27 --> Hooks Class Initialized
DEBUG - 2018-08-07 13:27:27 --> UTF-8 Support Enabled
INFO - 2018-08-07 13:27:27 --> Utf8 Class Initialized
INFO - 2018-08-07 13:27:27 --> URI Class Initialized
INFO - 2018-08-07 13:27:27 --> Router Class Initialized
INFO - 2018-08-07 13:27:27 --> Output Class Initialized
INFO - 2018-08-07 13:27:27 --> Security Class Initialized
DEBUG - 2018-08-07 13:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-07 13:27:27 --> CSRF cookie sent
INFO - 2018-08-07 13:27:27 --> Input Class Initialized
INFO - 2018-08-07 13:27:27 --> Language Class Initialized
INFO - 2018-08-07 13:27:27 --> Loader Class Initialized
INFO - 2018-08-07 13:27:27 --> Helper loaded: url_helper
INFO - 2018-08-07 13:27:27 --> Helper loaded: form_helper
INFO - 2018-08-07 13:27:27 --> Helper loaded: language_helper
DEBUG - 2018-08-07 13:27:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-07 13:27:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-07 13:27:27 --> User Agent Class Initialized
INFO - 2018-08-07 13:27:27 --> Controller Class Initialized
INFO - 2018-08-07 13:27:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-07 13:27:27 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-08-07 13:27:27 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-08-07 13:27:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-07 13:27:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-07 13:27:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-07 13:27:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-08-07 13:27:27 --> Could not find the language line "req_email"
INFO - 2018-08-07 13:27:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-08-07 13:27:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-07 13:27:27 --> Final output sent to browser
DEBUG - 2018-08-07 13:27:27 --> Total execution time: 0.0403
INFO - 2018-08-07 13:27:30 --> Config Class Initialized
INFO - 2018-08-07 13:27:30 --> Hooks Class Initialized
DEBUG - 2018-08-07 13:27:30 --> UTF-8 Support Enabled
INFO - 2018-08-07 13:27:30 --> Utf8 Class Initialized
INFO - 2018-08-07 13:27:30 --> URI Class Initialized
INFO - 2018-08-07 13:27:30 --> Router Class Initialized
INFO - 2018-08-07 13:27:30 --> Output Class Initialized
INFO - 2018-08-07 13:27:30 --> Security Class Initialized
DEBUG - 2018-08-07 13:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-07 13:27:30 --> CSRF cookie sent
INFO - 2018-08-07 13:27:30 --> Input Class Initialized
INFO - 2018-08-07 13:27:30 --> Language Class Initialized
INFO - 2018-08-07 13:27:30 --> Loader Class Initialized
INFO - 2018-08-07 13:27:30 --> Helper loaded: url_helper
INFO - 2018-08-07 13:27:30 --> Helper loaded: form_helper
INFO - 2018-08-07 13:27:30 --> Helper loaded: language_helper
DEBUG - 2018-08-07 13:27:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-07 13:27:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-07 13:27:30 --> User Agent Class Initialized
INFO - 2018-08-07 13:27:30 --> Controller Class Initialized
INFO - 2018-08-07 13:27:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-07 13:27:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-07 13:27:30 --> Pixel_Model class loaded
INFO - 2018-08-07 13:27:30 --> Database Driver Class Initialized
INFO - 2018-08-07 13:27:30 --> Model "RegistrationModel" initialized
DEBUG - 2018-08-07 13:27:30 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-08-07 13:27:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-07 13:27:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-07 13:27:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-07 13:27:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-07 13:27:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/temp.php
INFO - 2018-08-07 13:27:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-07 13:27:30 --> Final output sent to browser
DEBUG - 2018-08-07 13:27:30 --> Total execution time: 0.0431

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-08-14 00:37:37 --> Config Class Initialized
INFO - 2018-08-14 00:37:37 --> Hooks Class Initialized
DEBUG - 2018-08-14 00:37:37 --> UTF-8 Support Enabled
INFO - 2018-08-14 00:37:37 --> Utf8 Class Initialized
INFO - 2018-08-14 00:37:37 --> URI Class Initialized
INFO - 2018-08-14 00:37:37 --> Router Class Initialized
INFO - 2018-08-14 00:37:37 --> Output Class Initialized
INFO - 2018-08-14 00:37:37 --> Security Class Initialized
DEBUG - 2018-08-14 00:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 00:37:37 --> CSRF cookie sent
INFO - 2018-08-14 00:37:37 --> Input Class Initialized
INFO - 2018-08-14 00:37:37 --> Language Class Initialized
INFO - 2018-08-14 00:37:37 --> Loader Class Initialized
INFO - 2018-08-14 00:37:37 --> Helper loaded: url_helper
INFO - 2018-08-14 00:37:37 --> Helper loaded: form_helper
INFO - 2018-08-14 00:37:37 --> Helper loaded: language_helper
DEBUG - 2018-08-14 00:37:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 00:37:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 00:37:37 --> User Agent Class Initialized
INFO - 2018-08-14 00:37:37 --> Controller Class Initialized
INFO - 2018-08-14 00:37:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 00:37:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 00:37:37 --> Pixel_Model class loaded
INFO - 2018-08-14 00:37:37 --> Database Driver Class Initialized
INFO - 2018-08-14 00:37:37 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 00:37:38 --> Config Class Initialized
INFO - 2018-08-14 00:37:38 --> Hooks Class Initialized
DEBUG - 2018-08-14 00:37:38 --> UTF-8 Support Enabled
INFO - 2018-08-14 00:37:38 --> Utf8 Class Initialized
INFO - 2018-08-14 00:37:38 --> URI Class Initialized
INFO - 2018-08-14 00:37:38 --> Router Class Initialized
INFO - 2018-08-14 00:37:38 --> Output Class Initialized
INFO - 2018-08-14 00:37:38 --> Security Class Initialized
DEBUG - 2018-08-14 00:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 00:37:38 --> CSRF cookie sent
INFO - 2018-08-14 00:37:38 --> Input Class Initialized
INFO - 2018-08-14 00:37:38 --> Language Class Initialized
INFO - 2018-08-14 00:37:38 --> Loader Class Initialized
INFO - 2018-08-14 00:37:38 --> Helper loaded: url_helper
INFO - 2018-08-14 00:37:38 --> Helper loaded: form_helper
INFO - 2018-08-14 00:37:38 --> Helper loaded: language_helper
DEBUG - 2018-08-14 00:37:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 00:37:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 00:37:38 --> User Agent Class Initialized
INFO - 2018-08-14 00:37:38 --> Controller Class Initialized
INFO - 2018-08-14 00:37:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 00:37:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 00:37:38 --> Pixel_Model class loaded
INFO - 2018-08-14 00:37:38 --> Database Driver Class Initialized
INFO - 2018-08-14 00:37:38 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 00:37:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 00:37:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 00:37:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 00:37:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 00:37:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 00:37:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 00:37:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-08-14 00:37:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 00:37:38 --> Final output sent to browser
DEBUG - 2018-08-14 00:37:38 --> Total execution time: 0.0496
INFO - 2018-08-14 00:37:49 --> Config Class Initialized
INFO - 2018-08-14 00:37:49 --> Hooks Class Initialized
DEBUG - 2018-08-14 00:37:49 --> UTF-8 Support Enabled
INFO - 2018-08-14 00:37:49 --> Utf8 Class Initialized
INFO - 2018-08-14 00:37:49 --> URI Class Initialized
INFO - 2018-08-14 00:37:49 --> Router Class Initialized
INFO - 2018-08-14 00:37:49 --> Output Class Initialized
INFO - 2018-08-14 00:37:49 --> Security Class Initialized
DEBUG - 2018-08-14 00:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 00:37:49 --> CSRF cookie sent
INFO - 2018-08-14 00:37:49 --> Input Class Initialized
INFO - 2018-08-14 00:37:49 --> Language Class Initialized
INFO - 2018-08-14 00:37:49 --> Loader Class Initialized
INFO - 2018-08-14 00:37:49 --> Helper loaded: url_helper
INFO - 2018-08-14 00:37:49 --> Helper loaded: form_helper
INFO - 2018-08-14 00:37:49 --> Helper loaded: language_helper
DEBUG - 2018-08-14 00:37:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 00:37:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 00:37:49 --> User Agent Class Initialized
INFO - 2018-08-14 00:37:49 --> Controller Class Initialized
INFO - 2018-08-14 00:37:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 00:37:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 00:37:49 --> Pixel_Model class loaded
INFO - 2018-08-14 00:37:49 --> Database Driver Class Initialized
INFO - 2018-08-14 00:37:49 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 00:37:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 00:37:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 00:37:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 00:37:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 00:37:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 00:37:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 00:37:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-08-14 00:37:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 00:37:49 --> Final output sent to browser
DEBUG - 2018-08-14 00:37:49 --> Total execution time: 0.0389
INFO - 2018-08-14 00:37:52 --> Config Class Initialized
INFO - 2018-08-14 00:37:52 --> Hooks Class Initialized
DEBUG - 2018-08-14 00:37:52 --> UTF-8 Support Enabled
INFO - 2018-08-14 00:37:52 --> Utf8 Class Initialized
INFO - 2018-08-14 00:37:52 --> URI Class Initialized
INFO - 2018-08-14 00:37:52 --> Router Class Initialized
INFO - 2018-08-14 00:37:52 --> Output Class Initialized
INFO - 2018-08-14 00:37:52 --> Security Class Initialized
DEBUG - 2018-08-14 00:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 00:37:52 --> CSRF cookie sent
INFO - 2018-08-14 00:37:52 --> Input Class Initialized
INFO - 2018-08-14 00:37:52 --> Language Class Initialized
INFO - 2018-08-14 00:37:52 --> Loader Class Initialized
INFO - 2018-08-14 00:37:52 --> Helper loaded: url_helper
INFO - 2018-08-14 00:37:52 --> Helper loaded: form_helper
INFO - 2018-08-14 00:37:52 --> Helper loaded: language_helper
DEBUG - 2018-08-14 00:37:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 00:37:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 00:37:52 --> User Agent Class Initialized
INFO - 2018-08-14 00:37:52 --> Controller Class Initialized
INFO - 2018-08-14 00:37:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 00:37:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 00:37:52 --> Pixel_Model class loaded
INFO - 2018-08-14 00:37:52 --> Database Driver Class Initialized
INFO - 2018-08-14 00:37:52 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 00:37:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 00:37:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 00:37:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 00:37:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 00:37:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 00:37:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 00:37:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-08-14 00:37:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 00:37:52 --> Final output sent to browser
DEBUG - 2018-08-14 00:37:52 --> Total execution time: 0.0434
INFO - 2018-08-14 00:38:08 --> Config Class Initialized
INFO - 2018-08-14 00:38:08 --> Hooks Class Initialized
DEBUG - 2018-08-14 00:38:08 --> UTF-8 Support Enabled
INFO - 2018-08-14 00:38:08 --> Utf8 Class Initialized
INFO - 2018-08-14 00:38:08 --> URI Class Initialized
INFO - 2018-08-14 00:38:08 --> Router Class Initialized
INFO - 2018-08-14 00:38:08 --> Output Class Initialized
INFO - 2018-08-14 00:38:08 --> Security Class Initialized
DEBUG - 2018-08-14 00:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 00:38:08 --> CSRF cookie sent
INFO - 2018-08-14 00:38:08 --> CSRF token verified
INFO - 2018-08-14 00:38:08 --> Input Class Initialized
INFO - 2018-08-14 00:38:08 --> Language Class Initialized
INFO - 2018-08-14 00:38:08 --> Loader Class Initialized
INFO - 2018-08-14 00:38:08 --> Helper loaded: url_helper
INFO - 2018-08-14 00:38:08 --> Helper loaded: form_helper
INFO - 2018-08-14 00:38:08 --> Helper loaded: language_helper
DEBUG - 2018-08-14 00:38:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 00:38:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 00:38:08 --> User Agent Class Initialized
INFO - 2018-08-14 00:38:08 --> Controller Class Initialized
INFO - 2018-08-14 00:38:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 00:38:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 00:38:08 --> Pixel_Model class loaded
INFO - 2018-08-14 00:38:08 --> Database Driver Class Initialized
INFO - 2018-08-14 00:38:08 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 00:38:08 --> Database Driver Class Initialized
INFO - 2018-08-14 00:38:08 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 00:38:09 --> Config Class Initialized
INFO - 2018-08-14 00:38:09 --> Hooks Class Initialized
DEBUG - 2018-08-14 00:38:09 --> UTF-8 Support Enabled
INFO - 2018-08-14 00:38:09 --> Utf8 Class Initialized
INFO - 2018-08-14 00:38:09 --> URI Class Initialized
INFO - 2018-08-14 00:38:09 --> Router Class Initialized
INFO - 2018-08-14 00:38:09 --> Output Class Initialized
INFO - 2018-08-14 00:38:09 --> Security Class Initialized
DEBUG - 2018-08-14 00:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 00:38:09 --> CSRF cookie sent
INFO - 2018-08-14 00:38:09 --> Input Class Initialized
INFO - 2018-08-14 00:38:09 --> Language Class Initialized
INFO - 2018-08-14 00:38:09 --> Loader Class Initialized
INFO - 2018-08-14 00:38:09 --> Helper loaded: url_helper
INFO - 2018-08-14 00:38:09 --> Helper loaded: form_helper
INFO - 2018-08-14 00:38:09 --> Helper loaded: language_helper
DEBUG - 2018-08-14 00:38:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 00:38:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 00:38:09 --> User Agent Class Initialized
INFO - 2018-08-14 00:38:09 --> Controller Class Initialized
INFO - 2018-08-14 00:38:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 00:38:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 00:38:09 --> Pixel_Model class loaded
INFO - 2018-08-14 00:38:09 --> Database Driver Class Initialized
INFO - 2018-08-14 00:38:09 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 00:38:09 --> Database Driver Class Initialized
INFO - 2018-08-14 00:38:09 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 00:38:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 00:38:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 00:38:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 00:38:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 00:38:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 00:38:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 00:38:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-14 00:38:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 00:38:09 --> Final output sent to browser
DEBUG - 2018-08-14 00:38:09 --> Total execution time: 0.0605
INFO - 2018-08-14 00:59:08 --> Config Class Initialized
INFO - 2018-08-14 00:59:08 --> Hooks Class Initialized
DEBUG - 2018-08-14 00:59:08 --> UTF-8 Support Enabled
INFO - 2018-08-14 00:59:08 --> Utf8 Class Initialized
INFO - 2018-08-14 00:59:08 --> URI Class Initialized
INFO - 2018-08-14 00:59:08 --> Router Class Initialized
INFO - 2018-08-14 00:59:08 --> Output Class Initialized
INFO - 2018-08-14 00:59:08 --> Security Class Initialized
DEBUG - 2018-08-14 00:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 00:59:08 --> CSRF cookie sent
INFO - 2018-08-14 00:59:08 --> Input Class Initialized
INFO - 2018-08-14 00:59:08 --> Language Class Initialized
ERROR - 2018-08-14 00:59:08 --> 404 Page Not Found: 401shtml/index
INFO - 2018-08-14 00:59:08 --> Config Class Initialized
INFO - 2018-08-14 00:59:08 --> Hooks Class Initialized
DEBUG - 2018-08-14 00:59:08 --> UTF-8 Support Enabled
INFO - 2018-08-14 00:59:08 --> Utf8 Class Initialized
INFO - 2018-08-14 00:59:08 --> URI Class Initialized
INFO - 2018-08-14 00:59:08 --> Router Class Initialized
INFO - 2018-08-14 00:59:08 --> Output Class Initialized
INFO - 2018-08-14 00:59:08 --> Security Class Initialized
DEBUG - 2018-08-14 00:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 00:59:08 --> CSRF cookie sent
INFO - 2018-08-14 00:59:08 --> Input Class Initialized
INFO - 2018-08-14 00:59:08 --> Language Class Initialized
ERROR - 2018-08-14 00:59:08 --> 404 Page Not Found: Faviconico/index
INFO - 2018-08-14 00:59:14 --> Config Class Initialized
INFO - 2018-08-14 00:59:14 --> Hooks Class Initialized
DEBUG - 2018-08-14 00:59:14 --> UTF-8 Support Enabled
INFO - 2018-08-14 00:59:14 --> Utf8 Class Initialized
INFO - 2018-08-14 00:59:14 --> URI Class Initialized
DEBUG - 2018-08-14 00:59:14 --> No URI present. Default controller set.
INFO - 2018-08-14 00:59:14 --> Router Class Initialized
INFO - 2018-08-14 00:59:14 --> Output Class Initialized
INFO - 2018-08-14 00:59:14 --> Security Class Initialized
DEBUG - 2018-08-14 00:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 00:59:14 --> CSRF cookie sent
INFO - 2018-08-14 00:59:14 --> Input Class Initialized
INFO - 2018-08-14 00:59:14 --> Language Class Initialized
INFO - 2018-08-14 00:59:14 --> Loader Class Initialized
INFO - 2018-08-14 00:59:14 --> Helper loaded: url_helper
INFO - 2018-08-14 00:59:14 --> Helper loaded: form_helper
INFO - 2018-08-14 00:59:14 --> Helper loaded: language_helper
DEBUG - 2018-08-14 00:59:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 00:59:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 00:59:14 --> User Agent Class Initialized
INFO - 2018-08-14 00:59:14 --> Controller Class Initialized
INFO - 2018-08-14 00:59:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 00:59:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 00:59:14 --> Pixel_Model class loaded
INFO - 2018-08-14 00:59:14 --> Database Driver Class Initialized
INFO - 2018-08-14 00:59:14 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 00:59:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 00:59:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 00:59:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-14 00:59:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 00:59:14 --> Final output sent to browser
DEBUG - 2018-08-14 00:59:14 --> Total execution time: 0.0345
INFO - 2018-08-14 00:59:19 --> Config Class Initialized
INFO - 2018-08-14 00:59:19 --> Hooks Class Initialized
DEBUG - 2018-08-14 00:59:19 --> UTF-8 Support Enabled
INFO - 2018-08-14 00:59:19 --> Utf8 Class Initialized
INFO - 2018-08-14 00:59:19 --> URI Class Initialized
INFO - 2018-08-14 00:59:19 --> Router Class Initialized
INFO - 2018-08-14 00:59:19 --> Output Class Initialized
INFO - 2018-08-14 00:59:19 --> Security Class Initialized
DEBUG - 2018-08-14 00:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 00:59:19 --> CSRF cookie sent
INFO - 2018-08-14 00:59:19 --> CSRF token verified
INFO - 2018-08-14 00:59:19 --> Input Class Initialized
INFO - 2018-08-14 00:59:19 --> Language Class Initialized
INFO - 2018-08-14 00:59:19 --> Loader Class Initialized
INFO - 2018-08-14 00:59:19 --> Helper loaded: url_helper
INFO - 2018-08-14 00:59:19 --> Helper loaded: form_helper
INFO - 2018-08-14 00:59:19 --> Helper loaded: language_helper
DEBUG - 2018-08-14 00:59:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 00:59:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 00:59:19 --> User Agent Class Initialized
INFO - 2018-08-14 00:59:19 --> Controller Class Initialized
INFO - 2018-08-14 00:59:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 00:59:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 00:59:19 --> Pixel_Model class loaded
INFO - 2018-08-14 00:59:19 --> Database Driver Class Initialized
INFO - 2018-08-14 00:59:19 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 00:59:19 --> Database Driver Class Initialized
INFO - 2018-08-14 00:59:19 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 00:59:19 --> Config Class Initialized
INFO - 2018-08-14 00:59:19 --> Hooks Class Initialized
DEBUG - 2018-08-14 00:59:19 --> UTF-8 Support Enabled
INFO - 2018-08-14 00:59:19 --> Utf8 Class Initialized
INFO - 2018-08-14 00:59:19 --> URI Class Initialized
INFO - 2018-08-14 00:59:19 --> Router Class Initialized
INFO - 2018-08-14 00:59:19 --> Output Class Initialized
INFO - 2018-08-14 00:59:19 --> Security Class Initialized
DEBUG - 2018-08-14 00:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 00:59:19 --> CSRF cookie sent
INFO - 2018-08-14 00:59:19 --> Input Class Initialized
INFO - 2018-08-14 00:59:19 --> Language Class Initialized
INFO - 2018-08-14 00:59:19 --> Loader Class Initialized
INFO - 2018-08-14 00:59:19 --> Helper loaded: url_helper
INFO - 2018-08-14 00:59:19 --> Helper loaded: form_helper
INFO - 2018-08-14 00:59:19 --> Helper loaded: language_helper
DEBUG - 2018-08-14 00:59:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 00:59:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 00:59:19 --> User Agent Class Initialized
INFO - 2018-08-14 00:59:19 --> Controller Class Initialized
INFO - 2018-08-14 00:59:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 00:59:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 00:59:19 --> Pixel_Model class loaded
INFO - 2018-08-14 00:59:19 --> Database Driver Class Initialized
INFO - 2018-08-14 00:59:19 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 00:59:19 --> Database Driver Class Initialized
INFO - 2018-08-14 00:59:19 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 00:59:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 00:59:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 00:59:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 00:59:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 00:59:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 00:59:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 00:59:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-14 00:59:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 00:59:19 --> Final output sent to browser
DEBUG - 2018-08-14 00:59:19 --> Total execution time: 0.0489
INFO - 2018-08-14 00:59:52 --> Config Class Initialized
INFO - 2018-08-14 00:59:52 --> Hooks Class Initialized
DEBUG - 2018-08-14 00:59:52 --> UTF-8 Support Enabled
INFO - 2018-08-14 00:59:52 --> Utf8 Class Initialized
INFO - 2018-08-14 00:59:52 --> URI Class Initialized
DEBUG - 2018-08-14 00:59:52 --> No URI present. Default controller set.
INFO - 2018-08-14 00:59:52 --> Router Class Initialized
INFO - 2018-08-14 00:59:52 --> Output Class Initialized
INFO - 2018-08-14 00:59:52 --> Security Class Initialized
DEBUG - 2018-08-14 00:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 00:59:52 --> CSRF cookie sent
INFO - 2018-08-14 00:59:52 --> Input Class Initialized
INFO - 2018-08-14 00:59:52 --> Language Class Initialized
INFO - 2018-08-14 00:59:52 --> Loader Class Initialized
INFO - 2018-08-14 00:59:52 --> Helper loaded: url_helper
INFO - 2018-08-14 00:59:52 --> Helper loaded: form_helper
INFO - 2018-08-14 00:59:52 --> Helper loaded: language_helper
DEBUG - 2018-08-14 00:59:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 00:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 00:59:52 --> User Agent Class Initialized
INFO - 2018-08-14 00:59:52 --> Controller Class Initialized
INFO - 2018-08-14 00:59:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 00:59:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 00:59:52 --> Pixel_Model class loaded
INFO - 2018-08-14 00:59:52 --> Database Driver Class Initialized
INFO - 2018-08-14 00:59:52 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 00:59:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 00:59:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 00:59:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-14 00:59:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 00:59:52 --> Final output sent to browser
DEBUG - 2018-08-14 00:59:52 --> Total execution time: 0.0341
INFO - 2018-08-14 03:39:11 --> Config Class Initialized
INFO - 2018-08-14 03:39:11 --> Hooks Class Initialized
DEBUG - 2018-08-14 03:39:11 --> UTF-8 Support Enabled
INFO - 2018-08-14 03:39:11 --> Utf8 Class Initialized
INFO - 2018-08-14 03:39:11 --> URI Class Initialized
DEBUG - 2018-08-14 03:39:11 --> No URI present. Default controller set.
INFO - 2018-08-14 03:39:11 --> Router Class Initialized
INFO - 2018-08-14 03:39:11 --> Output Class Initialized
INFO - 2018-08-14 03:39:11 --> Security Class Initialized
DEBUG - 2018-08-14 03:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 03:39:11 --> CSRF cookie sent
INFO - 2018-08-14 03:39:11 --> Input Class Initialized
INFO - 2018-08-14 03:39:11 --> Language Class Initialized
INFO - 2018-08-14 03:39:11 --> Loader Class Initialized
INFO - 2018-08-14 03:39:11 --> Helper loaded: url_helper
INFO - 2018-08-14 03:39:11 --> Helper loaded: form_helper
INFO - 2018-08-14 03:39:11 --> Helper loaded: language_helper
DEBUG - 2018-08-14 03:39:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 03:39:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 03:39:11 --> User Agent Class Initialized
INFO - 2018-08-14 03:39:11 --> Controller Class Initialized
INFO - 2018-08-14 03:39:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 03:39:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 03:39:11 --> Pixel_Model class loaded
INFO - 2018-08-14 03:39:11 --> Database Driver Class Initialized
INFO - 2018-08-14 03:39:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 03:39:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 03:39:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 03:39:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-14 03:39:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 03:39:11 --> Final output sent to browser
DEBUG - 2018-08-14 03:39:11 --> Total execution time: 0.0345
INFO - 2018-08-14 03:39:18 --> Config Class Initialized
INFO - 2018-08-14 03:39:18 --> Hooks Class Initialized
DEBUG - 2018-08-14 03:39:18 --> UTF-8 Support Enabled
INFO - 2018-08-14 03:39:18 --> Utf8 Class Initialized
INFO - 2018-08-14 03:39:18 --> URI Class Initialized
INFO - 2018-08-14 03:39:18 --> Router Class Initialized
INFO - 2018-08-14 03:39:18 --> Output Class Initialized
INFO - 2018-08-14 03:39:18 --> Security Class Initialized
DEBUG - 2018-08-14 03:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 03:39:18 --> CSRF cookie sent
INFO - 2018-08-14 03:39:18 --> CSRF token verified
INFO - 2018-08-14 03:39:18 --> Input Class Initialized
INFO - 2018-08-14 03:39:18 --> Language Class Initialized
INFO - 2018-08-14 03:39:18 --> Loader Class Initialized
INFO - 2018-08-14 03:39:18 --> Helper loaded: url_helper
INFO - 2018-08-14 03:39:18 --> Helper loaded: form_helper
INFO - 2018-08-14 03:39:18 --> Helper loaded: language_helper
DEBUG - 2018-08-14 03:39:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 03:39:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 03:39:18 --> User Agent Class Initialized
INFO - 2018-08-14 03:39:18 --> Controller Class Initialized
INFO - 2018-08-14 03:39:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 03:39:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 03:39:18 --> Pixel_Model class loaded
INFO - 2018-08-14 03:39:18 --> Database Driver Class Initialized
INFO - 2018-08-14 03:39:18 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 03:39:18 --> Database Driver Class Initialized
INFO - 2018-08-14 03:39:18 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 03:39:19 --> Config Class Initialized
INFO - 2018-08-14 03:39:19 --> Hooks Class Initialized
DEBUG - 2018-08-14 03:39:19 --> UTF-8 Support Enabled
INFO - 2018-08-14 03:39:19 --> Utf8 Class Initialized
INFO - 2018-08-14 03:39:19 --> URI Class Initialized
INFO - 2018-08-14 03:39:19 --> Router Class Initialized
INFO - 2018-08-14 03:39:19 --> Output Class Initialized
INFO - 2018-08-14 03:39:19 --> Security Class Initialized
DEBUG - 2018-08-14 03:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 03:39:19 --> CSRF cookie sent
INFO - 2018-08-14 03:39:19 --> Input Class Initialized
INFO - 2018-08-14 03:39:19 --> Language Class Initialized
INFO - 2018-08-14 03:39:19 --> Loader Class Initialized
INFO - 2018-08-14 03:39:19 --> Helper loaded: url_helper
INFO - 2018-08-14 03:39:19 --> Helper loaded: form_helper
INFO - 2018-08-14 03:39:19 --> Helper loaded: language_helper
DEBUG - 2018-08-14 03:39:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 03:39:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 03:39:19 --> User Agent Class Initialized
INFO - 2018-08-14 03:39:19 --> Controller Class Initialized
INFO - 2018-08-14 03:39:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 03:39:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 03:39:19 --> Pixel_Model class loaded
INFO - 2018-08-14 03:39:19 --> Database Driver Class Initialized
INFO - 2018-08-14 03:39:19 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 03:39:19 --> Database Driver Class Initialized
INFO - 2018-08-14 03:39:19 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 03:39:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 03:39:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 03:39:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 03:39:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 03:39:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 03:39:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 03:39:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-14 03:39:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 03:39:19 --> Final output sent to browser
DEBUG - 2018-08-14 03:39:19 --> Total execution time: 0.0522
INFO - 2018-08-14 03:39:32 --> Config Class Initialized
INFO - 2018-08-14 03:39:32 --> Hooks Class Initialized
DEBUG - 2018-08-14 03:39:32 --> UTF-8 Support Enabled
INFO - 2018-08-14 03:39:32 --> Utf8 Class Initialized
INFO - 2018-08-14 03:39:32 --> URI Class Initialized
INFO - 2018-08-14 03:39:32 --> Router Class Initialized
INFO - 2018-08-14 03:39:32 --> Output Class Initialized
INFO - 2018-08-14 03:39:32 --> Security Class Initialized
DEBUG - 2018-08-14 03:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 03:39:32 --> CSRF cookie sent
INFO - 2018-08-14 03:39:32 --> CSRF token verified
INFO - 2018-08-14 03:39:32 --> Input Class Initialized
INFO - 2018-08-14 03:39:32 --> Language Class Initialized
INFO - 2018-08-14 03:39:32 --> Loader Class Initialized
INFO - 2018-08-14 03:39:32 --> Helper loaded: url_helper
INFO - 2018-08-14 03:39:32 --> Helper loaded: form_helper
INFO - 2018-08-14 03:39:32 --> Helper loaded: language_helper
DEBUG - 2018-08-14 03:39:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 03:39:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 03:39:32 --> User Agent Class Initialized
INFO - 2018-08-14 03:39:32 --> Controller Class Initialized
INFO - 2018-08-14 03:39:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 03:39:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 03:39:32 --> Pixel_Model class loaded
INFO - 2018-08-14 03:39:32 --> Database Driver Class Initialized
INFO - 2018-08-14 03:39:32 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 03:39:32 --> Form Validation Class Initialized
INFO - 2018-08-14 03:39:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 03:39:32 --> Database Driver Class Initialized
INFO - 2018-08-14 03:39:32 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 03:39:32 --> Config Class Initialized
INFO - 2018-08-14 03:39:32 --> Hooks Class Initialized
DEBUG - 2018-08-14 03:39:32 --> UTF-8 Support Enabled
INFO - 2018-08-14 03:39:32 --> Utf8 Class Initialized
INFO - 2018-08-14 03:39:32 --> URI Class Initialized
INFO - 2018-08-14 03:39:32 --> Router Class Initialized
INFO - 2018-08-14 03:39:32 --> Output Class Initialized
INFO - 2018-08-14 03:39:32 --> Security Class Initialized
DEBUG - 2018-08-14 03:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 03:39:32 --> CSRF cookie sent
INFO - 2018-08-14 03:39:32 --> Input Class Initialized
INFO - 2018-08-14 03:39:32 --> Language Class Initialized
INFO - 2018-08-14 03:39:32 --> Loader Class Initialized
INFO - 2018-08-14 03:39:32 --> Helper loaded: url_helper
INFO - 2018-08-14 03:39:32 --> Helper loaded: form_helper
INFO - 2018-08-14 03:39:32 --> Helper loaded: language_helper
DEBUG - 2018-08-14 03:39:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 03:39:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 03:39:32 --> User Agent Class Initialized
INFO - 2018-08-14 03:39:32 --> Controller Class Initialized
INFO - 2018-08-14 03:39:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 03:39:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 03:39:32 --> Pixel_Model class loaded
INFO - 2018-08-14 03:39:32 --> Database Driver Class Initialized
INFO - 2018-08-14 03:39:32 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 03:39:32 --> Database Driver Class Initialized
INFO - 2018-08-14 03:39:32 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 03:39:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 03:39:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 03:39:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 03:39:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 03:39:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 03:39:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 03:39:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-08-14 03:39:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 03:39:32 --> Final output sent to browser
DEBUG - 2018-08-14 03:39:32 --> Total execution time: 0.0500
INFO - 2018-08-14 03:39:38 --> Config Class Initialized
INFO - 2018-08-14 03:39:38 --> Hooks Class Initialized
DEBUG - 2018-08-14 03:39:38 --> UTF-8 Support Enabled
INFO - 2018-08-14 03:39:38 --> Utf8 Class Initialized
INFO - 2018-08-14 03:39:38 --> URI Class Initialized
INFO - 2018-08-14 03:39:38 --> Router Class Initialized
INFO - 2018-08-14 03:39:38 --> Output Class Initialized
INFO - 2018-08-14 03:39:38 --> Security Class Initialized
DEBUG - 2018-08-14 03:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 03:39:38 --> CSRF cookie sent
INFO - 2018-08-14 03:39:38 --> CSRF token verified
INFO - 2018-08-14 03:39:38 --> Input Class Initialized
INFO - 2018-08-14 03:39:38 --> Language Class Initialized
INFO - 2018-08-14 03:39:38 --> Loader Class Initialized
INFO - 2018-08-14 03:39:38 --> Helper loaded: url_helper
INFO - 2018-08-14 03:39:38 --> Helper loaded: form_helper
INFO - 2018-08-14 03:39:38 --> Helper loaded: language_helper
DEBUG - 2018-08-14 03:39:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 03:39:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 03:39:38 --> User Agent Class Initialized
INFO - 2018-08-14 03:39:38 --> Controller Class Initialized
INFO - 2018-08-14 03:39:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 03:39:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 03:39:38 --> Pixel_Model class loaded
INFO - 2018-08-14 03:39:38 --> Database Driver Class Initialized
INFO - 2018-08-14 03:39:38 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 03:39:38 --> Form Validation Class Initialized
INFO - 2018-08-14 03:39:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 03:39:38 --> Database Driver Class Initialized
INFO - 2018-08-14 03:39:38 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 03:39:38 --> Config Class Initialized
INFO - 2018-08-14 03:39:38 --> Hooks Class Initialized
DEBUG - 2018-08-14 03:39:38 --> UTF-8 Support Enabled
INFO - 2018-08-14 03:39:38 --> Utf8 Class Initialized
INFO - 2018-08-14 03:39:38 --> URI Class Initialized
INFO - 2018-08-14 03:39:38 --> Router Class Initialized
INFO - 2018-08-14 03:39:38 --> Output Class Initialized
INFO - 2018-08-14 03:39:38 --> Security Class Initialized
DEBUG - 2018-08-14 03:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 03:39:38 --> CSRF cookie sent
INFO - 2018-08-14 03:39:38 --> Input Class Initialized
INFO - 2018-08-14 03:39:38 --> Language Class Initialized
INFO - 2018-08-14 03:39:38 --> Loader Class Initialized
INFO - 2018-08-14 03:39:38 --> Helper loaded: url_helper
INFO - 2018-08-14 03:39:38 --> Helper loaded: form_helper
INFO - 2018-08-14 03:39:38 --> Helper loaded: language_helper
DEBUG - 2018-08-14 03:39:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 03:39:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 03:39:38 --> User Agent Class Initialized
INFO - 2018-08-14 03:39:38 --> Controller Class Initialized
INFO - 2018-08-14 03:39:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 03:39:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 03:39:38 --> Pixel_Model class loaded
INFO - 2018-08-14 03:39:38 --> Database Driver Class Initialized
INFO - 2018-08-14 03:39:38 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 03:39:38 --> Database Driver Class Initialized
INFO - 2018-08-14 03:39:38 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 03:39:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 03:39:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 03:39:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-08-14 03:39:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 03:39:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 03:39:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 03:39:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 03:39:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-08-14 03:39:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 03:39:38 --> Final output sent to browser
DEBUG - 2018-08-14 03:39:38 --> Total execution time: 0.0419
INFO - 2018-08-14 03:39:45 --> Config Class Initialized
INFO - 2018-08-14 03:39:45 --> Hooks Class Initialized
DEBUG - 2018-08-14 03:39:45 --> UTF-8 Support Enabled
INFO - 2018-08-14 03:39:45 --> Utf8 Class Initialized
INFO - 2018-08-14 03:39:45 --> URI Class Initialized
INFO - 2018-08-14 03:39:45 --> Router Class Initialized
INFO - 2018-08-14 03:39:45 --> Output Class Initialized
INFO - 2018-08-14 03:39:45 --> Security Class Initialized
DEBUG - 2018-08-14 03:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 03:39:45 --> CSRF cookie sent
INFO - 2018-08-14 03:39:45 --> CSRF token verified
INFO - 2018-08-14 03:39:45 --> Input Class Initialized
INFO - 2018-08-14 03:39:45 --> Language Class Initialized
INFO - 2018-08-14 03:39:45 --> Loader Class Initialized
INFO - 2018-08-14 03:39:45 --> Helper loaded: url_helper
INFO - 2018-08-14 03:39:45 --> Helper loaded: form_helper
INFO - 2018-08-14 03:39:45 --> Helper loaded: language_helper
DEBUG - 2018-08-14 03:39:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 03:39:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 03:39:45 --> User Agent Class Initialized
INFO - 2018-08-14 03:39:45 --> Controller Class Initialized
INFO - 2018-08-14 03:39:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 03:39:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 03:39:45 --> Pixel_Model class loaded
INFO - 2018-08-14 03:39:45 --> Database Driver Class Initialized
INFO - 2018-08-14 03:39:45 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 03:39:45 --> Form Validation Class Initialized
INFO - 2018-08-14 03:39:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 03:39:45 --> Database Driver Class Initialized
INFO - 2018-08-14 03:39:45 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 03:39:45 --> Config Class Initialized
INFO - 2018-08-14 03:39:45 --> Hooks Class Initialized
DEBUG - 2018-08-14 03:39:45 --> UTF-8 Support Enabled
INFO - 2018-08-14 03:39:45 --> Utf8 Class Initialized
INFO - 2018-08-14 03:39:45 --> URI Class Initialized
INFO - 2018-08-14 03:39:45 --> Router Class Initialized
INFO - 2018-08-14 03:39:45 --> Output Class Initialized
INFO - 2018-08-14 03:39:45 --> Security Class Initialized
DEBUG - 2018-08-14 03:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 03:39:45 --> CSRF cookie sent
INFO - 2018-08-14 03:39:45 --> Input Class Initialized
INFO - 2018-08-14 03:39:45 --> Language Class Initialized
INFO - 2018-08-14 03:39:45 --> Loader Class Initialized
INFO - 2018-08-14 03:39:45 --> Helper loaded: url_helper
INFO - 2018-08-14 03:39:45 --> Helper loaded: form_helper
INFO - 2018-08-14 03:39:45 --> Helper loaded: language_helper
DEBUG - 2018-08-14 03:39:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 03:39:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 03:39:45 --> User Agent Class Initialized
INFO - 2018-08-14 03:39:45 --> Controller Class Initialized
INFO - 2018-08-14 03:39:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 03:39:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 03:39:45 --> Pixel_Model class loaded
INFO - 2018-08-14 03:39:45 --> Database Driver Class Initialized
INFO - 2018-08-14 03:39:45 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 03:39:45 --> Database Driver Class Initialized
INFO - 2018-08-14 03:39:45 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 03:39:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 03:39:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 03:39:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 03:39:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 03:39:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 03:39:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 03:39:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-08-14 03:39:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 03:39:45 --> Final output sent to browser
DEBUG - 2018-08-14 03:39:45 --> Total execution time: 0.0405
INFO - 2018-08-14 03:39:58 --> Config Class Initialized
INFO - 2018-08-14 03:39:58 --> Hooks Class Initialized
DEBUG - 2018-08-14 03:39:58 --> UTF-8 Support Enabled
INFO - 2018-08-14 03:39:58 --> Utf8 Class Initialized
INFO - 2018-08-14 03:39:58 --> URI Class Initialized
INFO - 2018-08-14 03:39:58 --> Router Class Initialized
INFO - 2018-08-14 03:39:58 --> Output Class Initialized
INFO - 2018-08-14 03:39:58 --> Security Class Initialized
DEBUG - 2018-08-14 03:39:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 03:39:58 --> CSRF cookie sent
INFO - 2018-08-14 03:39:58 --> CSRF token verified
INFO - 2018-08-14 03:39:58 --> Input Class Initialized
INFO - 2018-08-14 03:39:58 --> Language Class Initialized
INFO - 2018-08-14 03:39:58 --> Loader Class Initialized
INFO - 2018-08-14 03:39:58 --> Helper loaded: url_helper
INFO - 2018-08-14 03:39:58 --> Helper loaded: form_helper
INFO - 2018-08-14 03:39:58 --> Helper loaded: language_helper
DEBUG - 2018-08-14 03:39:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 03:39:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 03:39:58 --> User Agent Class Initialized
INFO - 2018-08-14 03:39:58 --> Controller Class Initialized
INFO - 2018-08-14 03:39:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 03:39:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 03:39:58 --> Pixel_Model class loaded
INFO - 2018-08-14 03:39:58 --> Database Driver Class Initialized
INFO - 2018-08-14 03:39:58 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 03:39:58 --> Form Validation Class Initialized
INFO - 2018-08-14 03:39:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 03:39:58 --> Database Driver Class Initialized
INFO - 2018-08-14 03:39:58 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 03:39:58 --> Config Class Initialized
INFO - 2018-08-14 03:39:58 --> Hooks Class Initialized
DEBUG - 2018-08-14 03:39:58 --> UTF-8 Support Enabled
INFO - 2018-08-14 03:39:58 --> Utf8 Class Initialized
INFO - 2018-08-14 03:39:58 --> URI Class Initialized
INFO - 2018-08-14 03:39:58 --> Router Class Initialized
INFO - 2018-08-14 03:39:58 --> Output Class Initialized
INFO - 2018-08-14 03:39:58 --> Security Class Initialized
DEBUG - 2018-08-14 03:39:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 03:39:58 --> CSRF cookie sent
INFO - 2018-08-14 03:39:58 --> Input Class Initialized
INFO - 2018-08-14 03:39:58 --> Language Class Initialized
INFO - 2018-08-14 03:39:58 --> Loader Class Initialized
INFO - 2018-08-14 03:39:58 --> Helper loaded: url_helper
INFO - 2018-08-14 03:39:58 --> Helper loaded: form_helper
INFO - 2018-08-14 03:39:58 --> Helper loaded: language_helper
DEBUG - 2018-08-14 03:39:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 03:39:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 03:39:58 --> User Agent Class Initialized
INFO - 2018-08-14 03:39:58 --> Controller Class Initialized
INFO - 2018-08-14 03:39:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 03:39:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 03:39:58 --> Pixel_Model class loaded
INFO - 2018-08-14 03:39:58 --> Database Driver Class Initialized
INFO - 2018-08-14 03:39:58 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 03:39:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 03:39:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 03:39:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 03:39:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 03:39:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 03:39:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/cohabitation.php
INFO - 2018-08-14 03:39:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 03:39:58 --> Final output sent to browser
DEBUG - 2018-08-14 03:39:58 --> Total execution time: 0.0351
INFO - 2018-08-14 03:40:34 --> Config Class Initialized
INFO - 2018-08-14 03:40:34 --> Hooks Class Initialized
DEBUG - 2018-08-14 03:40:34 --> UTF-8 Support Enabled
INFO - 2018-08-14 03:40:34 --> Utf8 Class Initialized
INFO - 2018-08-14 03:40:34 --> URI Class Initialized
INFO - 2018-08-14 03:40:34 --> Router Class Initialized
INFO - 2018-08-14 03:40:34 --> Output Class Initialized
INFO - 2018-08-14 03:40:34 --> Security Class Initialized
DEBUG - 2018-08-14 03:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 03:40:34 --> CSRF cookie sent
INFO - 2018-08-14 03:40:34 --> CSRF token verified
INFO - 2018-08-14 03:40:34 --> Input Class Initialized
INFO - 2018-08-14 03:40:34 --> Language Class Initialized
INFO - 2018-08-14 03:40:34 --> Loader Class Initialized
INFO - 2018-08-14 03:40:34 --> Helper loaded: url_helper
INFO - 2018-08-14 03:40:34 --> Helper loaded: form_helper
INFO - 2018-08-14 03:40:34 --> Helper loaded: language_helper
DEBUG - 2018-08-14 03:40:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 03:40:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 03:40:34 --> User Agent Class Initialized
INFO - 2018-08-14 03:40:34 --> Controller Class Initialized
INFO - 2018-08-14 03:40:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 03:40:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 03:40:34 --> Pixel_Model class loaded
INFO - 2018-08-14 03:40:34 --> Database Driver Class Initialized
INFO - 2018-08-14 03:40:34 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 03:40:34 --> Form Validation Class Initialized
INFO - 2018-08-14 03:40:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 03:40:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 03:40:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 03:40:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 03:40:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 03:40:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_errors.php
INFO - 2018-08-14 03:40:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 03:40:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/cohabitation.php
INFO - 2018-08-14 03:40:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 03:40:34 --> Final output sent to browser
DEBUG - 2018-08-14 03:40:34 --> Total execution time: 0.0384
INFO - 2018-08-14 03:41:01 --> Config Class Initialized
INFO - 2018-08-14 03:41:01 --> Hooks Class Initialized
DEBUG - 2018-08-14 03:41:01 --> UTF-8 Support Enabled
INFO - 2018-08-14 03:41:01 --> Utf8 Class Initialized
INFO - 2018-08-14 03:41:01 --> URI Class Initialized
INFO - 2018-08-14 03:41:01 --> Router Class Initialized
INFO - 2018-08-14 03:41:01 --> Output Class Initialized
INFO - 2018-08-14 03:41:01 --> Security Class Initialized
DEBUG - 2018-08-14 03:41:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 03:41:01 --> CSRF cookie sent
INFO - 2018-08-14 03:41:01 --> CSRF token verified
INFO - 2018-08-14 03:41:01 --> Input Class Initialized
INFO - 2018-08-14 03:41:01 --> Language Class Initialized
INFO - 2018-08-14 03:41:01 --> Loader Class Initialized
INFO - 2018-08-14 03:41:01 --> Helper loaded: url_helper
INFO - 2018-08-14 03:41:01 --> Helper loaded: form_helper
INFO - 2018-08-14 03:41:01 --> Helper loaded: language_helper
DEBUG - 2018-08-14 03:41:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 03:41:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 03:41:01 --> User Agent Class Initialized
INFO - 2018-08-14 03:41:01 --> Controller Class Initialized
INFO - 2018-08-14 03:41:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 03:41:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 03:41:01 --> Pixel_Model class loaded
INFO - 2018-08-14 03:41:01 --> Database Driver Class Initialized
INFO - 2018-08-14 03:41:01 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 03:41:01 --> Form Validation Class Initialized
INFO - 2018-08-14 03:41:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 03:41:01 --> Database Driver Class Initialized
INFO - 2018-08-14 03:41:01 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 03:41:01 --> Config Class Initialized
INFO - 2018-08-14 03:41:01 --> Hooks Class Initialized
DEBUG - 2018-08-14 03:41:01 --> UTF-8 Support Enabled
INFO - 2018-08-14 03:41:01 --> Utf8 Class Initialized
INFO - 2018-08-14 03:41:01 --> URI Class Initialized
INFO - 2018-08-14 03:41:01 --> Router Class Initialized
INFO - 2018-08-14 03:41:01 --> Output Class Initialized
INFO - 2018-08-14 03:41:01 --> Security Class Initialized
DEBUG - 2018-08-14 03:41:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 03:41:01 --> CSRF cookie sent
INFO - 2018-08-14 03:41:01 --> Input Class Initialized
INFO - 2018-08-14 03:41:01 --> Language Class Initialized
INFO - 2018-08-14 03:41:01 --> Loader Class Initialized
INFO - 2018-08-14 03:41:01 --> Helper loaded: url_helper
INFO - 2018-08-14 03:41:01 --> Helper loaded: form_helper
INFO - 2018-08-14 03:41:01 --> Helper loaded: language_helper
DEBUG - 2018-08-14 03:41:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 03:41:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 03:41:01 --> User Agent Class Initialized
INFO - 2018-08-14 03:41:01 --> Controller Class Initialized
INFO - 2018-08-14 03:41:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 03:41:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 03:41:01 --> Pixel_Model class loaded
INFO - 2018-08-14 03:41:01 --> Database Driver Class Initialized
INFO - 2018-08-14 03:41:01 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 03:41:01 --> Database Driver Class Initialized
INFO - 2018-08-14 03:41:01 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 03:41:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 03:41:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 03:41:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 03:41:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 03:41:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 03:41:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 03:41:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-08-14 03:41:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 03:41:01 --> Final output sent to browser
DEBUG - 2018-08-14 03:41:01 --> Total execution time: 0.0410
INFO - 2018-08-14 03:41:05 --> Config Class Initialized
INFO - 2018-08-14 03:41:05 --> Hooks Class Initialized
DEBUG - 2018-08-14 03:41:05 --> UTF-8 Support Enabled
INFO - 2018-08-14 03:41:05 --> Utf8 Class Initialized
INFO - 2018-08-14 03:41:05 --> URI Class Initialized
INFO - 2018-08-14 03:41:05 --> Router Class Initialized
INFO - 2018-08-14 03:41:05 --> Output Class Initialized
INFO - 2018-08-14 03:41:05 --> Security Class Initialized
DEBUG - 2018-08-14 03:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 03:41:05 --> CSRF cookie sent
INFO - 2018-08-14 03:41:05 --> Input Class Initialized
INFO - 2018-08-14 03:41:05 --> Language Class Initialized
INFO - 2018-08-14 03:41:05 --> Loader Class Initialized
INFO - 2018-08-14 03:41:05 --> Helper loaded: url_helper
INFO - 2018-08-14 03:41:05 --> Helper loaded: form_helper
INFO - 2018-08-14 03:41:05 --> Helper loaded: language_helper
DEBUG - 2018-08-14 03:41:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 03:41:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 03:41:05 --> User Agent Class Initialized
INFO - 2018-08-14 03:41:05 --> Controller Class Initialized
INFO - 2018-08-14 03:41:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 03:41:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 03:41:05 --> Pixel_Model class loaded
INFO - 2018-08-14 03:41:05 --> Database Driver Class Initialized
INFO - 2018-08-14 03:41:05 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 03:41:05 --> Database Driver Class Initialized
INFO - 2018-08-14 03:41:05 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 03:41:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 03:41:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 03:41:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 03:41:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 03:41:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 03:41:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 03:41:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-14 03:41:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 03:41:05 --> Final output sent to browser
DEBUG - 2018-08-14 03:41:05 --> Total execution time: 0.0536
INFO - 2018-08-14 03:41:11 --> Config Class Initialized
INFO - 2018-08-14 03:41:11 --> Hooks Class Initialized
DEBUG - 2018-08-14 03:41:11 --> UTF-8 Support Enabled
INFO - 2018-08-14 03:41:11 --> Utf8 Class Initialized
INFO - 2018-08-14 03:41:11 --> URI Class Initialized
INFO - 2018-08-14 03:41:11 --> Router Class Initialized
INFO - 2018-08-14 03:41:11 --> Output Class Initialized
INFO - 2018-08-14 03:41:11 --> Security Class Initialized
DEBUG - 2018-08-14 03:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 03:41:11 --> CSRF cookie sent
INFO - 2018-08-14 03:41:11 --> CSRF token verified
INFO - 2018-08-14 03:41:11 --> Input Class Initialized
INFO - 2018-08-14 03:41:11 --> Language Class Initialized
INFO - 2018-08-14 03:41:11 --> Loader Class Initialized
INFO - 2018-08-14 03:41:11 --> Helper loaded: url_helper
INFO - 2018-08-14 03:41:11 --> Helper loaded: form_helper
INFO - 2018-08-14 03:41:11 --> Helper loaded: language_helper
DEBUG - 2018-08-14 03:41:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 03:41:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 03:41:11 --> User Agent Class Initialized
INFO - 2018-08-14 03:41:11 --> Controller Class Initialized
INFO - 2018-08-14 03:41:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 03:41:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 03:41:11 --> Pixel_Model class loaded
INFO - 2018-08-14 03:41:11 --> Database Driver Class Initialized
INFO - 2018-08-14 03:41:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 03:41:11 --> Form Validation Class Initialized
INFO - 2018-08-14 03:41:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 03:41:11 --> Database Driver Class Initialized
INFO - 2018-08-14 03:41:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 03:41:11 --> Config Class Initialized
INFO - 2018-08-14 03:41:11 --> Hooks Class Initialized
DEBUG - 2018-08-14 03:41:11 --> UTF-8 Support Enabled
INFO - 2018-08-14 03:41:11 --> Utf8 Class Initialized
INFO - 2018-08-14 03:41:11 --> URI Class Initialized
INFO - 2018-08-14 03:41:11 --> Router Class Initialized
INFO - 2018-08-14 03:41:11 --> Output Class Initialized
INFO - 2018-08-14 03:41:11 --> Security Class Initialized
DEBUG - 2018-08-14 03:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 03:41:11 --> CSRF cookie sent
INFO - 2018-08-14 03:41:11 --> Input Class Initialized
INFO - 2018-08-14 03:41:11 --> Language Class Initialized
INFO - 2018-08-14 03:41:11 --> Loader Class Initialized
INFO - 2018-08-14 03:41:11 --> Helper loaded: url_helper
INFO - 2018-08-14 03:41:11 --> Helper loaded: form_helper
INFO - 2018-08-14 03:41:11 --> Helper loaded: language_helper
DEBUG - 2018-08-14 03:41:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 03:41:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 03:41:11 --> User Agent Class Initialized
INFO - 2018-08-14 03:41:11 --> Controller Class Initialized
INFO - 2018-08-14 03:41:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 03:41:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 03:41:11 --> Pixel_Model class loaded
INFO - 2018-08-14 03:41:11 --> Database Driver Class Initialized
INFO - 2018-08-14 03:41:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 03:41:11 --> Database Driver Class Initialized
INFO - 2018-08-14 03:41:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 03:41:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 03:41:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 03:41:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 03:41:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 03:41:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 03:41:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 03:41:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-08-14 03:41:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 03:41:11 --> Final output sent to browser
DEBUG - 2018-08-14 03:41:11 --> Total execution time: 0.0703
INFO - 2018-08-14 03:41:16 --> Config Class Initialized
INFO - 2018-08-14 03:41:16 --> Hooks Class Initialized
DEBUG - 2018-08-14 03:41:16 --> UTF-8 Support Enabled
INFO - 2018-08-14 03:41:16 --> Utf8 Class Initialized
INFO - 2018-08-14 03:41:16 --> URI Class Initialized
INFO - 2018-08-14 03:41:16 --> Router Class Initialized
INFO - 2018-08-14 03:41:16 --> Output Class Initialized
INFO - 2018-08-14 03:41:16 --> Security Class Initialized
DEBUG - 2018-08-14 03:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 03:41:16 --> CSRF cookie sent
INFO - 2018-08-14 03:41:16 --> CSRF token verified
INFO - 2018-08-14 03:41:16 --> Input Class Initialized
INFO - 2018-08-14 03:41:16 --> Language Class Initialized
INFO - 2018-08-14 03:41:16 --> Loader Class Initialized
INFO - 2018-08-14 03:41:16 --> Helper loaded: url_helper
INFO - 2018-08-14 03:41:16 --> Helper loaded: form_helper
INFO - 2018-08-14 03:41:16 --> Helper loaded: language_helper
DEBUG - 2018-08-14 03:41:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 03:41:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 03:41:16 --> User Agent Class Initialized
INFO - 2018-08-14 03:41:16 --> Controller Class Initialized
INFO - 2018-08-14 03:41:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 03:41:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 03:41:16 --> Pixel_Model class loaded
INFO - 2018-08-14 03:41:16 --> Database Driver Class Initialized
INFO - 2018-08-14 03:41:16 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 03:41:16 --> Form Validation Class Initialized
INFO - 2018-08-14 03:41:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 03:41:16 --> Database Driver Class Initialized
INFO - 2018-08-14 03:41:16 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 03:41:16 --> Config Class Initialized
INFO - 2018-08-14 03:41:16 --> Hooks Class Initialized
DEBUG - 2018-08-14 03:41:16 --> UTF-8 Support Enabled
INFO - 2018-08-14 03:41:16 --> Utf8 Class Initialized
INFO - 2018-08-14 03:41:16 --> URI Class Initialized
INFO - 2018-08-14 03:41:16 --> Router Class Initialized
INFO - 2018-08-14 03:41:16 --> Output Class Initialized
INFO - 2018-08-14 03:41:16 --> Security Class Initialized
DEBUG - 2018-08-14 03:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 03:41:16 --> CSRF cookie sent
INFO - 2018-08-14 03:41:16 --> Input Class Initialized
INFO - 2018-08-14 03:41:16 --> Language Class Initialized
INFO - 2018-08-14 03:41:16 --> Loader Class Initialized
INFO - 2018-08-14 03:41:16 --> Helper loaded: url_helper
INFO - 2018-08-14 03:41:16 --> Helper loaded: form_helper
INFO - 2018-08-14 03:41:16 --> Helper loaded: language_helper
DEBUG - 2018-08-14 03:41:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 03:41:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 03:41:16 --> User Agent Class Initialized
INFO - 2018-08-14 03:41:16 --> Controller Class Initialized
INFO - 2018-08-14 03:41:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 03:41:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 03:41:16 --> Pixel_Model class loaded
INFO - 2018-08-14 03:41:16 --> Database Driver Class Initialized
INFO - 2018-08-14 03:41:16 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 03:41:16 --> Database Driver Class Initialized
INFO - 2018-08-14 03:41:16 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 03:41:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 03:41:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 03:41:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-08-14 03:41:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 03:41:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 03:41:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 03:41:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 03:41:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-08-14 03:41:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 03:41:16 --> Final output sent to browser
DEBUG - 2018-08-14 03:41:16 --> Total execution time: 0.0369
INFO - 2018-08-14 03:41:18 --> Config Class Initialized
INFO - 2018-08-14 03:41:18 --> Hooks Class Initialized
DEBUG - 2018-08-14 03:41:18 --> UTF-8 Support Enabled
INFO - 2018-08-14 03:41:18 --> Utf8 Class Initialized
INFO - 2018-08-14 03:41:18 --> URI Class Initialized
INFO - 2018-08-14 03:41:18 --> Router Class Initialized
INFO - 2018-08-14 03:41:18 --> Output Class Initialized
INFO - 2018-08-14 03:41:18 --> Security Class Initialized
DEBUG - 2018-08-14 03:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 03:41:18 --> CSRF cookie sent
INFO - 2018-08-14 03:41:18 --> CSRF token verified
INFO - 2018-08-14 03:41:18 --> Input Class Initialized
INFO - 2018-08-14 03:41:18 --> Language Class Initialized
INFO - 2018-08-14 03:41:18 --> Loader Class Initialized
INFO - 2018-08-14 03:41:18 --> Helper loaded: url_helper
INFO - 2018-08-14 03:41:18 --> Helper loaded: form_helper
INFO - 2018-08-14 03:41:18 --> Helper loaded: language_helper
DEBUG - 2018-08-14 03:41:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 03:41:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 03:41:18 --> User Agent Class Initialized
INFO - 2018-08-14 03:41:18 --> Controller Class Initialized
INFO - 2018-08-14 03:41:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 03:41:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 03:41:18 --> Pixel_Model class loaded
INFO - 2018-08-14 03:41:18 --> Database Driver Class Initialized
INFO - 2018-08-14 03:41:18 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 03:41:18 --> Form Validation Class Initialized
INFO - 2018-08-14 03:41:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 03:41:18 --> Database Driver Class Initialized
INFO - 2018-08-14 03:41:18 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 03:41:18 --> Config Class Initialized
INFO - 2018-08-14 03:41:18 --> Hooks Class Initialized
DEBUG - 2018-08-14 03:41:18 --> UTF-8 Support Enabled
INFO - 2018-08-14 03:41:18 --> Utf8 Class Initialized
INFO - 2018-08-14 03:41:18 --> URI Class Initialized
INFO - 2018-08-14 03:41:18 --> Router Class Initialized
INFO - 2018-08-14 03:41:18 --> Output Class Initialized
INFO - 2018-08-14 03:41:18 --> Security Class Initialized
DEBUG - 2018-08-14 03:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 03:41:18 --> CSRF cookie sent
INFO - 2018-08-14 03:41:18 --> Input Class Initialized
INFO - 2018-08-14 03:41:18 --> Language Class Initialized
INFO - 2018-08-14 03:41:18 --> Loader Class Initialized
INFO - 2018-08-14 03:41:18 --> Helper loaded: url_helper
INFO - 2018-08-14 03:41:18 --> Helper loaded: form_helper
INFO - 2018-08-14 03:41:18 --> Helper loaded: language_helper
DEBUG - 2018-08-14 03:41:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 03:41:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 03:41:18 --> User Agent Class Initialized
INFO - 2018-08-14 03:41:18 --> Controller Class Initialized
INFO - 2018-08-14 03:41:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 03:41:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 03:41:18 --> Pixel_Model class loaded
INFO - 2018-08-14 03:41:18 --> Database Driver Class Initialized
INFO - 2018-08-14 03:41:18 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 03:41:18 --> Database Driver Class Initialized
INFO - 2018-08-14 03:41:18 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 03:41:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 03:41:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 03:41:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 03:41:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 03:41:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 03:41:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 03:41:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-08-14 03:41:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 03:41:18 --> Final output sent to browser
DEBUG - 2018-08-14 03:41:18 --> Total execution time: 0.0359
INFO - 2018-08-14 03:41:21 --> Config Class Initialized
INFO - 2018-08-14 03:41:21 --> Hooks Class Initialized
DEBUG - 2018-08-14 03:41:21 --> UTF-8 Support Enabled
INFO - 2018-08-14 03:41:21 --> Utf8 Class Initialized
INFO - 2018-08-14 03:41:21 --> URI Class Initialized
INFO - 2018-08-14 03:41:21 --> Router Class Initialized
INFO - 2018-08-14 03:41:21 --> Output Class Initialized
INFO - 2018-08-14 03:41:21 --> Security Class Initialized
DEBUG - 2018-08-14 03:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 03:41:21 --> CSRF cookie sent
INFO - 2018-08-14 03:41:21 --> CSRF token verified
INFO - 2018-08-14 03:41:21 --> Input Class Initialized
INFO - 2018-08-14 03:41:21 --> Language Class Initialized
INFO - 2018-08-14 03:41:21 --> Loader Class Initialized
INFO - 2018-08-14 03:41:21 --> Helper loaded: url_helper
INFO - 2018-08-14 03:41:21 --> Helper loaded: form_helper
INFO - 2018-08-14 03:41:21 --> Helper loaded: language_helper
DEBUG - 2018-08-14 03:41:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 03:41:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 03:41:21 --> User Agent Class Initialized
INFO - 2018-08-14 03:41:21 --> Controller Class Initialized
INFO - 2018-08-14 03:41:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 03:41:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 03:41:21 --> Pixel_Model class loaded
INFO - 2018-08-14 03:41:21 --> Database Driver Class Initialized
INFO - 2018-08-14 03:41:21 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 03:41:21 --> Form Validation Class Initialized
INFO - 2018-08-14 03:41:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 03:41:21 --> Database Driver Class Initialized
INFO - 2018-08-14 03:41:21 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 03:41:21 --> Config Class Initialized
INFO - 2018-08-14 03:41:21 --> Hooks Class Initialized
DEBUG - 2018-08-14 03:41:21 --> UTF-8 Support Enabled
INFO - 2018-08-14 03:41:21 --> Utf8 Class Initialized
INFO - 2018-08-14 03:41:21 --> URI Class Initialized
INFO - 2018-08-14 03:41:21 --> Router Class Initialized
INFO - 2018-08-14 03:41:21 --> Output Class Initialized
INFO - 2018-08-14 03:41:21 --> Security Class Initialized
DEBUG - 2018-08-14 03:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 03:41:21 --> CSRF cookie sent
INFO - 2018-08-14 03:41:21 --> Input Class Initialized
INFO - 2018-08-14 03:41:21 --> Language Class Initialized
INFO - 2018-08-14 03:41:21 --> Loader Class Initialized
INFO - 2018-08-14 03:41:21 --> Helper loaded: url_helper
INFO - 2018-08-14 03:41:21 --> Helper loaded: form_helper
INFO - 2018-08-14 03:41:21 --> Helper loaded: language_helper
DEBUG - 2018-08-14 03:41:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 03:41:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 03:41:21 --> User Agent Class Initialized
INFO - 2018-08-14 03:41:21 --> Controller Class Initialized
INFO - 2018-08-14 03:41:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 03:41:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 03:41:21 --> Pixel_Model class loaded
INFO - 2018-08-14 03:41:21 --> Database Driver Class Initialized
INFO - 2018-08-14 03:41:21 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 03:41:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 03:41:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 03:41:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 03:41:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 03:41:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 03:41:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/cohabitation.php
INFO - 2018-08-14 03:41:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 03:41:21 --> Final output sent to browser
DEBUG - 2018-08-14 03:41:21 --> Total execution time: 0.0516
INFO - 2018-08-14 03:41:24 --> Config Class Initialized
INFO - 2018-08-14 03:41:24 --> Hooks Class Initialized
DEBUG - 2018-08-14 03:41:24 --> UTF-8 Support Enabled
INFO - 2018-08-14 03:41:24 --> Utf8 Class Initialized
INFO - 2018-08-14 03:41:24 --> URI Class Initialized
INFO - 2018-08-14 03:41:24 --> Router Class Initialized
INFO - 2018-08-14 03:41:24 --> Output Class Initialized
INFO - 2018-08-14 03:41:24 --> Security Class Initialized
DEBUG - 2018-08-14 03:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 03:41:24 --> CSRF cookie sent
INFO - 2018-08-14 03:41:24 --> CSRF token verified
INFO - 2018-08-14 03:41:24 --> Input Class Initialized
INFO - 2018-08-14 03:41:24 --> Language Class Initialized
INFO - 2018-08-14 03:41:24 --> Loader Class Initialized
INFO - 2018-08-14 03:41:24 --> Helper loaded: url_helper
INFO - 2018-08-14 03:41:24 --> Helper loaded: form_helper
INFO - 2018-08-14 03:41:24 --> Helper loaded: language_helper
DEBUG - 2018-08-14 03:41:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 03:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 03:41:24 --> User Agent Class Initialized
INFO - 2018-08-14 03:41:24 --> Controller Class Initialized
INFO - 2018-08-14 03:41:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 03:41:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 03:41:24 --> Pixel_Model class loaded
INFO - 2018-08-14 03:41:24 --> Database Driver Class Initialized
INFO - 2018-08-14 03:41:24 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 03:41:24 --> Form Validation Class Initialized
INFO - 2018-08-14 03:41:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 03:41:24 --> Database Driver Class Initialized
INFO - 2018-08-14 03:41:24 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 03:41:24 --> Config Class Initialized
INFO - 2018-08-14 03:41:24 --> Hooks Class Initialized
DEBUG - 2018-08-14 03:41:24 --> UTF-8 Support Enabled
INFO - 2018-08-14 03:41:24 --> Utf8 Class Initialized
INFO - 2018-08-14 03:41:24 --> URI Class Initialized
INFO - 2018-08-14 03:41:24 --> Router Class Initialized
INFO - 2018-08-14 03:41:24 --> Output Class Initialized
INFO - 2018-08-14 03:41:24 --> Security Class Initialized
DEBUG - 2018-08-14 03:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 03:41:24 --> CSRF cookie sent
INFO - 2018-08-14 03:41:24 --> Input Class Initialized
INFO - 2018-08-14 03:41:24 --> Language Class Initialized
INFO - 2018-08-14 03:41:24 --> Loader Class Initialized
INFO - 2018-08-14 03:41:24 --> Helper loaded: url_helper
INFO - 2018-08-14 03:41:24 --> Helper loaded: form_helper
INFO - 2018-08-14 03:41:24 --> Helper loaded: language_helper
DEBUG - 2018-08-14 03:41:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 03:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 03:41:24 --> User Agent Class Initialized
INFO - 2018-08-14 03:41:24 --> Controller Class Initialized
INFO - 2018-08-14 03:41:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 03:41:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 03:41:24 --> Pixel_Model class loaded
INFO - 2018-08-14 03:41:24 --> Database Driver Class Initialized
INFO - 2018-08-14 03:41:24 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 03:41:24 --> Database Driver Class Initialized
INFO - 2018-08-14 03:41:24 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 03:41:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 03:41:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 03:41:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 03:41:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 03:41:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 03:41:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 03:41:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-08-14 03:41:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 03:41:24 --> Final output sent to browser
DEBUG - 2018-08-14 03:41:24 --> Total execution time: 0.0471
INFO - 2018-08-14 03:42:23 --> Config Class Initialized
INFO - 2018-08-14 03:42:23 --> Hooks Class Initialized
DEBUG - 2018-08-14 03:42:23 --> UTF-8 Support Enabled
INFO - 2018-08-14 03:42:23 --> Utf8 Class Initialized
INFO - 2018-08-14 03:42:23 --> URI Class Initialized
INFO - 2018-08-14 03:42:23 --> Router Class Initialized
INFO - 2018-08-14 03:42:23 --> Output Class Initialized
INFO - 2018-08-14 03:42:23 --> Security Class Initialized
DEBUG - 2018-08-14 03:42:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 03:42:23 --> CSRF cookie sent
INFO - 2018-08-14 03:42:23 --> CSRF token verified
INFO - 2018-08-14 03:42:23 --> Input Class Initialized
INFO - 2018-08-14 03:42:23 --> Language Class Initialized
INFO - 2018-08-14 03:42:23 --> Loader Class Initialized
INFO - 2018-08-14 03:42:23 --> Helper loaded: url_helper
INFO - 2018-08-14 03:42:23 --> Helper loaded: form_helper
INFO - 2018-08-14 03:42:23 --> Helper loaded: language_helper
DEBUG - 2018-08-14 03:42:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 03:42:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 03:42:23 --> User Agent Class Initialized
INFO - 2018-08-14 03:42:23 --> Controller Class Initialized
INFO - 2018-08-14 03:42:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 03:42:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 03:42:23 --> Pixel_Model class loaded
INFO - 2018-08-14 03:42:23 --> Database Driver Class Initialized
INFO - 2018-08-14 03:42:23 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 03:42:23 --> Form Validation Class Initialized
INFO - 2018-08-14 03:42:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 03:42:23 --> Database Driver Class Initialized
INFO - 2018-08-14 03:42:23 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 03:42:23 --> Config Class Initialized
INFO - 2018-08-14 03:42:23 --> Hooks Class Initialized
DEBUG - 2018-08-14 03:42:23 --> UTF-8 Support Enabled
INFO - 2018-08-14 03:42:23 --> Utf8 Class Initialized
INFO - 2018-08-14 03:42:23 --> URI Class Initialized
INFO - 2018-08-14 03:42:23 --> Router Class Initialized
INFO - 2018-08-14 03:42:23 --> Output Class Initialized
INFO - 2018-08-14 03:42:23 --> Security Class Initialized
DEBUG - 2018-08-14 03:42:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 03:42:23 --> CSRF cookie sent
INFO - 2018-08-14 03:42:23 --> Input Class Initialized
INFO - 2018-08-14 03:42:23 --> Language Class Initialized
INFO - 2018-08-14 03:42:23 --> Loader Class Initialized
INFO - 2018-08-14 03:42:23 --> Helper loaded: url_helper
INFO - 2018-08-14 03:42:23 --> Helper loaded: form_helper
INFO - 2018-08-14 03:42:23 --> Helper loaded: language_helper
DEBUG - 2018-08-14 03:42:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 03:42:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 03:42:23 --> User Agent Class Initialized
INFO - 2018-08-14 03:42:23 --> Controller Class Initialized
INFO - 2018-08-14 03:42:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 03:42:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 03:42:23 --> Pixel_Model class loaded
INFO - 2018-08-14 03:42:23 --> Database Driver Class Initialized
INFO - 2018-08-14 03:42:23 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 03:42:23 --> Database Driver Class Initialized
INFO - 2018-08-14 03:42:23 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 03:42:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 03:42:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 03:42:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 03:42:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 03:42:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 03:42:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 03:42:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-08-14 03:42:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 03:42:23 --> Final output sent to browser
DEBUG - 2018-08-14 03:42:23 --> Total execution time: 0.0548
INFO - 2018-08-14 03:42:37 --> Config Class Initialized
INFO - 2018-08-14 03:42:37 --> Hooks Class Initialized
DEBUG - 2018-08-14 03:42:37 --> UTF-8 Support Enabled
INFO - 2018-08-14 03:42:37 --> Utf8 Class Initialized
INFO - 2018-08-14 03:42:37 --> URI Class Initialized
INFO - 2018-08-14 03:42:38 --> Router Class Initialized
INFO - 2018-08-14 03:42:38 --> Output Class Initialized
INFO - 2018-08-14 03:42:38 --> Security Class Initialized
DEBUG - 2018-08-14 03:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 03:42:38 --> CSRF cookie sent
INFO - 2018-08-14 03:42:38 --> CSRF token verified
INFO - 2018-08-14 03:42:38 --> Input Class Initialized
INFO - 2018-08-14 03:42:38 --> Language Class Initialized
INFO - 2018-08-14 03:42:38 --> Loader Class Initialized
INFO - 2018-08-14 03:42:38 --> Helper loaded: url_helper
INFO - 2018-08-14 03:42:38 --> Helper loaded: form_helper
INFO - 2018-08-14 03:42:38 --> Helper loaded: language_helper
DEBUG - 2018-08-14 03:42:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 03:42:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 03:42:38 --> User Agent Class Initialized
INFO - 2018-08-14 03:42:38 --> Controller Class Initialized
INFO - 2018-08-14 03:42:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 03:42:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 03:42:38 --> Pixel_Model class loaded
INFO - 2018-08-14 03:42:38 --> Database Driver Class Initialized
INFO - 2018-08-14 03:42:38 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 03:42:38 --> Form Validation Class Initialized
INFO - 2018-08-14 03:42:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 03:42:38 --> Database Driver Class Initialized
INFO - 2018-08-14 03:42:38 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 03:42:38 --> Config Class Initialized
INFO - 2018-08-14 03:42:38 --> Hooks Class Initialized
DEBUG - 2018-08-14 03:42:38 --> UTF-8 Support Enabled
INFO - 2018-08-14 03:42:38 --> Utf8 Class Initialized
INFO - 2018-08-14 03:42:38 --> URI Class Initialized
INFO - 2018-08-14 03:42:38 --> Router Class Initialized
INFO - 2018-08-14 03:42:38 --> Output Class Initialized
INFO - 2018-08-14 03:42:38 --> Security Class Initialized
DEBUG - 2018-08-14 03:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 03:42:38 --> CSRF cookie sent
INFO - 2018-08-14 03:42:38 --> Input Class Initialized
INFO - 2018-08-14 03:42:38 --> Language Class Initialized
INFO - 2018-08-14 03:42:38 --> Loader Class Initialized
INFO - 2018-08-14 03:42:38 --> Helper loaded: url_helper
INFO - 2018-08-14 03:42:38 --> Helper loaded: form_helper
INFO - 2018-08-14 03:42:38 --> Helper loaded: language_helper
DEBUG - 2018-08-14 03:42:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 03:42:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 03:42:38 --> User Agent Class Initialized
INFO - 2018-08-14 03:42:38 --> Controller Class Initialized
INFO - 2018-08-14 03:42:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 03:42:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 03:42:38 --> Pixel_Model class loaded
INFO - 2018-08-14 03:42:38 --> Database Driver Class Initialized
INFO - 2018-08-14 03:42:38 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 03:42:38 --> Database Driver Class Initialized
INFO - 2018-08-14 03:42:38 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 03:42:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 03:42:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 03:42:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 03:42:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 03:42:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 03:42:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 03:42:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-08-14 03:42:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 03:42:38 --> Final output sent to browser
DEBUG - 2018-08-14 03:42:38 --> Total execution time: 0.0442
INFO - 2018-08-14 03:42:47 --> Config Class Initialized
INFO - 2018-08-14 03:42:47 --> Hooks Class Initialized
DEBUG - 2018-08-14 03:42:47 --> UTF-8 Support Enabled
INFO - 2018-08-14 03:42:47 --> Utf8 Class Initialized
INFO - 2018-08-14 03:42:47 --> URI Class Initialized
INFO - 2018-08-14 03:42:47 --> Router Class Initialized
INFO - 2018-08-14 03:42:47 --> Output Class Initialized
INFO - 2018-08-14 03:42:47 --> Security Class Initialized
DEBUG - 2018-08-14 03:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 03:42:47 --> CSRF cookie sent
INFO - 2018-08-14 03:42:47 --> CSRF token verified
INFO - 2018-08-14 03:42:47 --> Input Class Initialized
INFO - 2018-08-14 03:42:47 --> Language Class Initialized
INFO - 2018-08-14 03:42:47 --> Loader Class Initialized
INFO - 2018-08-14 03:42:47 --> Helper loaded: url_helper
INFO - 2018-08-14 03:42:47 --> Helper loaded: form_helper
INFO - 2018-08-14 03:42:47 --> Helper loaded: language_helper
DEBUG - 2018-08-14 03:42:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 03:42:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 03:42:47 --> User Agent Class Initialized
INFO - 2018-08-14 03:42:47 --> Controller Class Initialized
INFO - 2018-08-14 03:42:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 03:42:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 03:42:47 --> Pixel_Model class loaded
INFO - 2018-08-14 03:42:47 --> Database Driver Class Initialized
INFO - 2018-08-14 03:42:47 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 03:42:47 --> Form Validation Class Initialized
INFO - 2018-08-14 03:42:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 03:42:47 --> Database Driver Class Initialized
INFO - 2018-08-14 03:42:47 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 03:42:47 --> Config Class Initialized
INFO - 2018-08-14 03:42:47 --> Hooks Class Initialized
DEBUG - 2018-08-14 03:42:47 --> UTF-8 Support Enabled
INFO - 2018-08-14 03:42:47 --> Utf8 Class Initialized
INFO - 2018-08-14 03:42:47 --> URI Class Initialized
INFO - 2018-08-14 03:42:47 --> Router Class Initialized
INFO - 2018-08-14 03:42:47 --> Output Class Initialized
INFO - 2018-08-14 03:42:47 --> Security Class Initialized
DEBUG - 2018-08-14 03:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 03:42:47 --> CSRF cookie sent
INFO - 2018-08-14 03:42:47 --> Input Class Initialized
INFO - 2018-08-14 03:42:47 --> Language Class Initialized
INFO - 2018-08-14 03:42:47 --> Loader Class Initialized
INFO - 2018-08-14 03:42:47 --> Helper loaded: url_helper
INFO - 2018-08-14 03:42:47 --> Helper loaded: form_helper
INFO - 2018-08-14 03:42:47 --> Helper loaded: language_helper
DEBUG - 2018-08-14 03:42:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 03:42:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 03:42:47 --> User Agent Class Initialized
INFO - 2018-08-14 03:42:47 --> Controller Class Initialized
INFO - 2018-08-14 03:42:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 03:42:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 03:42:47 --> Pixel_Model class loaded
INFO - 2018-08-14 03:42:47 --> Database Driver Class Initialized
INFO - 2018-08-14 03:42:47 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 03:42:47 --> Database Driver Class Initialized
INFO - 2018-08-14 03:42:47 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 03:42:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 03:42:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 03:42:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 03:42:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 03:42:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 03:42:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 03:42:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_owner.php
INFO - 2018-08-14 03:42:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 03:42:47 --> Final output sent to browser
DEBUG - 2018-08-14 03:42:47 --> Total execution time: 0.0430
INFO - 2018-08-14 03:42:50 --> Config Class Initialized
INFO - 2018-08-14 03:42:50 --> Hooks Class Initialized
DEBUG - 2018-08-14 03:42:50 --> UTF-8 Support Enabled
INFO - 2018-08-14 03:42:50 --> Utf8 Class Initialized
INFO - 2018-08-14 03:42:50 --> URI Class Initialized
INFO - 2018-08-14 03:42:50 --> Router Class Initialized
INFO - 2018-08-14 03:42:50 --> Output Class Initialized
INFO - 2018-08-14 03:42:50 --> Security Class Initialized
DEBUG - 2018-08-14 03:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 03:42:50 --> CSRF cookie sent
INFO - 2018-08-14 03:42:50 --> CSRF token verified
INFO - 2018-08-14 03:42:50 --> Input Class Initialized
INFO - 2018-08-14 03:42:50 --> Language Class Initialized
INFO - 2018-08-14 03:42:50 --> Loader Class Initialized
INFO - 2018-08-14 03:42:50 --> Helper loaded: url_helper
INFO - 2018-08-14 03:42:50 --> Helper loaded: form_helper
INFO - 2018-08-14 03:42:50 --> Helper loaded: language_helper
DEBUG - 2018-08-14 03:42:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 03:42:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 03:42:50 --> User Agent Class Initialized
INFO - 2018-08-14 03:42:50 --> Controller Class Initialized
INFO - 2018-08-14 03:42:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 03:42:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 03:42:50 --> Pixel_Model class loaded
INFO - 2018-08-14 03:42:50 --> Database Driver Class Initialized
INFO - 2018-08-14 03:42:50 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 03:42:50 --> Form Validation Class Initialized
INFO - 2018-08-14 03:42:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 03:42:50 --> Database Driver Class Initialized
INFO - 2018-08-14 03:42:50 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 03:42:50 --> Config Class Initialized
INFO - 2018-08-14 03:42:50 --> Hooks Class Initialized
DEBUG - 2018-08-14 03:42:50 --> UTF-8 Support Enabled
INFO - 2018-08-14 03:42:50 --> Utf8 Class Initialized
INFO - 2018-08-14 03:42:50 --> URI Class Initialized
INFO - 2018-08-14 03:42:50 --> Router Class Initialized
INFO - 2018-08-14 03:42:50 --> Output Class Initialized
INFO - 2018-08-14 03:42:50 --> Security Class Initialized
DEBUG - 2018-08-14 03:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 03:42:50 --> CSRF cookie sent
INFO - 2018-08-14 03:42:50 --> Input Class Initialized
INFO - 2018-08-14 03:42:50 --> Language Class Initialized
INFO - 2018-08-14 03:42:50 --> Loader Class Initialized
INFO - 2018-08-14 03:42:50 --> Helper loaded: url_helper
INFO - 2018-08-14 03:42:50 --> Helper loaded: form_helper
INFO - 2018-08-14 03:42:50 --> Helper loaded: language_helper
DEBUG - 2018-08-14 03:42:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 03:42:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 03:42:50 --> User Agent Class Initialized
INFO - 2018-08-14 03:42:50 --> Controller Class Initialized
INFO - 2018-08-14 03:42:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 03:42:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 03:42:50 --> Pixel_Model class loaded
INFO - 2018-08-14 03:42:50 --> Database Driver Class Initialized
INFO - 2018-08-14 03:42:50 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 03:42:50 --> Database Driver Class Initialized
INFO - 2018-08-14 03:42:50 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 03:42:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 03:42:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 03:42:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 03:42:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 03:42:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 03:42:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 03:42:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_value.php
INFO - 2018-08-14 03:42:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 03:42:50 --> Final output sent to browser
DEBUG - 2018-08-14 03:42:50 --> Total execution time: 0.0462
INFO - 2018-08-14 03:43:14 --> Config Class Initialized
INFO - 2018-08-14 03:43:14 --> Hooks Class Initialized
DEBUG - 2018-08-14 03:43:14 --> UTF-8 Support Enabled
INFO - 2018-08-14 03:43:14 --> Utf8 Class Initialized
INFO - 2018-08-14 03:43:14 --> URI Class Initialized
INFO - 2018-08-14 03:43:14 --> Router Class Initialized
INFO - 2018-08-14 03:43:14 --> Output Class Initialized
INFO - 2018-08-14 03:43:14 --> Security Class Initialized
DEBUG - 2018-08-14 03:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 03:43:14 --> CSRF cookie sent
INFO - 2018-08-14 03:43:14 --> Input Class Initialized
INFO - 2018-08-14 03:43:14 --> Language Class Initialized
INFO - 2018-08-14 03:43:14 --> Loader Class Initialized
INFO - 2018-08-14 03:43:14 --> Helper loaded: url_helper
INFO - 2018-08-14 03:43:14 --> Helper loaded: form_helper
INFO - 2018-08-14 03:43:14 --> Helper loaded: language_helper
DEBUG - 2018-08-14 03:43:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 03:43:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 03:43:14 --> User Agent Class Initialized
INFO - 2018-08-14 03:43:14 --> Controller Class Initialized
INFO - 2018-08-14 03:43:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 03:43:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 03:43:14 --> Pixel_Model class loaded
INFO - 2018-08-14 03:43:14 --> Database Driver Class Initialized
INFO - 2018-08-14 03:43:14 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 03:43:14 --> Database Driver Class Initialized
INFO - 2018-08-14 03:43:14 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 03:43:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 03:43:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 03:43:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 03:43:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 03:43:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-08-14 03:43:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 03:43:14 --> Final output sent to browser
DEBUG - 2018-08-14 03:43:14 --> Total execution time: 0.0498
INFO - 2018-08-14 11:13:18 --> Config Class Initialized
INFO - 2018-08-14 11:13:18 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:13:18 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:13:18 --> Utf8 Class Initialized
INFO - 2018-08-14 11:13:18 --> URI Class Initialized
INFO - 2018-08-14 11:13:18 --> Router Class Initialized
INFO - 2018-08-14 11:13:18 --> Output Class Initialized
INFO - 2018-08-14 11:13:18 --> Security Class Initialized
DEBUG - 2018-08-14 11:13:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:13:18 --> CSRF cookie sent
INFO - 2018-08-14 11:13:18 --> Input Class Initialized
INFO - 2018-08-14 11:13:18 --> Language Class Initialized
ERROR - 2018-08-14 11:13:18 --> 404 Page Not Found: 401shtml/index
INFO - 2018-08-14 11:13:23 --> Config Class Initialized
INFO - 2018-08-14 11:13:23 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:13:23 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:13:23 --> Utf8 Class Initialized
INFO - 2018-08-14 11:13:23 --> URI Class Initialized
DEBUG - 2018-08-14 11:13:23 --> No URI present. Default controller set.
INFO - 2018-08-14 11:13:23 --> Router Class Initialized
INFO - 2018-08-14 11:13:23 --> Output Class Initialized
INFO - 2018-08-14 11:13:23 --> Security Class Initialized
DEBUG - 2018-08-14 11:13:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:13:23 --> CSRF cookie sent
INFO - 2018-08-14 11:13:23 --> Input Class Initialized
INFO - 2018-08-14 11:13:23 --> Language Class Initialized
INFO - 2018-08-14 11:13:23 --> Loader Class Initialized
INFO - 2018-08-14 11:13:23 --> Helper loaded: url_helper
INFO - 2018-08-14 11:13:23 --> Helper loaded: form_helper
INFO - 2018-08-14 11:13:23 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:13:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:13:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:13:23 --> User Agent Class Initialized
INFO - 2018-08-14 11:13:23 --> Controller Class Initialized
INFO - 2018-08-14 11:13:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:13:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:13:23 --> Pixel_Model class loaded
INFO - 2018-08-14 11:13:23 --> Database Driver Class Initialized
INFO - 2018-08-14 11:13:23 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:13:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:13:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:13:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-14 11:13:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:13:23 --> Final output sent to browser
DEBUG - 2018-08-14 11:13:23 --> Total execution time: 0.0346
INFO - 2018-08-14 11:13:24 --> Config Class Initialized
INFO - 2018-08-14 11:13:24 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:13:24 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:13:24 --> Utf8 Class Initialized
INFO - 2018-08-14 11:13:24 --> URI Class Initialized
DEBUG - 2018-08-14 11:13:24 --> No URI present. Default controller set.
INFO - 2018-08-14 11:13:24 --> Router Class Initialized
INFO - 2018-08-14 11:13:24 --> Output Class Initialized
INFO - 2018-08-14 11:13:24 --> Security Class Initialized
DEBUG - 2018-08-14 11:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:13:24 --> CSRF cookie sent
INFO - 2018-08-14 11:13:24 --> Input Class Initialized
INFO - 2018-08-14 11:13:24 --> Language Class Initialized
INFO - 2018-08-14 11:13:24 --> Loader Class Initialized
INFO - 2018-08-14 11:13:24 --> Helper loaded: url_helper
INFO - 2018-08-14 11:13:24 --> Helper loaded: form_helper
INFO - 2018-08-14 11:13:24 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:13:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:13:24 --> User Agent Class Initialized
INFO - 2018-08-14 11:13:24 --> Controller Class Initialized
INFO - 2018-08-14 11:13:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:13:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:13:24 --> Pixel_Model class loaded
INFO - 2018-08-14 11:13:24 --> Database Driver Class Initialized
INFO - 2018-08-14 11:13:24 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:13:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:13:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:13:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-14 11:13:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:13:24 --> Final output sent to browser
DEBUG - 2018-08-14 11:13:24 --> Total execution time: 0.0352
INFO - 2018-08-14 11:13:34 --> Config Class Initialized
INFO - 2018-08-14 11:13:34 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:13:34 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:13:34 --> Utf8 Class Initialized
INFO - 2018-08-14 11:13:34 --> URI Class Initialized
INFO - 2018-08-14 11:13:34 --> Router Class Initialized
INFO - 2018-08-14 11:13:34 --> Output Class Initialized
INFO - 2018-08-14 11:13:34 --> Security Class Initialized
DEBUG - 2018-08-14 11:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:13:34 --> CSRF cookie sent
INFO - 2018-08-14 11:13:34 --> CSRF token verified
INFO - 2018-08-14 11:13:34 --> Input Class Initialized
INFO - 2018-08-14 11:13:34 --> Language Class Initialized
INFO - 2018-08-14 11:13:34 --> Loader Class Initialized
INFO - 2018-08-14 11:13:34 --> Helper loaded: url_helper
INFO - 2018-08-14 11:13:34 --> Helper loaded: form_helper
INFO - 2018-08-14 11:13:34 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:13:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:13:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:13:34 --> User Agent Class Initialized
INFO - 2018-08-14 11:13:34 --> Controller Class Initialized
INFO - 2018-08-14 11:13:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:13:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:13:34 --> Pixel_Model class loaded
INFO - 2018-08-14 11:13:34 --> Database Driver Class Initialized
INFO - 2018-08-14 11:13:34 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:13:34 --> Database Driver Class Initialized
INFO - 2018-08-14 11:13:34 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:13:34 --> Config Class Initialized
INFO - 2018-08-14 11:13:34 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:13:34 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:13:34 --> Utf8 Class Initialized
INFO - 2018-08-14 11:13:34 --> URI Class Initialized
INFO - 2018-08-14 11:13:34 --> Router Class Initialized
INFO - 2018-08-14 11:13:34 --> Output Class Initialized
INFO - 2018-08-14 11:13:34 --> Security Class Initialized
DEBUG - 2018-08-14 11:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:13:34 --> CSRF cookie sent
INFO - 2018-08-14 11:13:34 --> Input Class Initialized
INFO - 2018-08-14 11:13:34 --> Language Class Initialized
INFO - 2018-08-14 11:13:34 --> Loader Class Initialized
INFO - 2018-08-14 11:13:34 --> Helper loaded: url_helper
INFO - 2018-08-14 11:13:34 --> Helper loaded: form_helper
INFO - 2018-08-14 11:13:34 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:13:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:13:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:13:34 --> User Agent Class Initialized
INFO - 2018-08-14 11:13:34 --> Controller Class Initialized
INFO - 2018-08-14 11:13:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:13:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:13:34 --> Pixel_Model class loaded
INFO - 2018-08-14 11:13:34 --> Database Driver Class Initialized
INFO - 2018-08-14 11:13:34 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:13:34 --> Database Driver Class Initialized
INFO - 2018-08-14 11:13:34 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:13:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:13:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:13:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 11:13:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 11:13:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 11:13:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 11:13:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-14 11:13:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:13:34 --> Final output sent to browser
DEBUG - 2018-08-14 11:13:34 --> Total execution time: 0.0440
INFO - 2018-08-14 11:13:49 --> Config Class Initialized
INFO - 2018-08-14 11:13:49 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:13:49 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:13:49 --> Utf8 Class Initialized
INFO - 2018-08-14 11:13:49 --> URI Class Initialized
INFO - 2018-08-14 11:13:49 --> Router Class Initialized
INFO - 2018-08-14 11:13:49 --> Output Class Initialized
INFO - 2018-08-14 11:13:49 --> Security Class Initialized
DEBUG - 2018-08-14 11:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:13:49 --> CSRF cookie sent
INFO - 2018-08-14 11:13:49 --> CSRF token verified
INFO - 2018-08-14 11:13:49 --> Input Class Initialized
INFO - 2018-08-14 11:13:49 --> Language Class Initialized
INFO - 2018-08-14 11:13:49 --> Loader Class Initialized
INFO - 2018-08-14 11:13:49 --> Helper loaded: url_helper
INFO - 2018-08-14 11:13:49 --> Helper loaded: form_helper
INFO - 2018-08-14 11:13:49 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:13:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:13:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:13:49 --> User Agent Class Initialized
INFO - 2018-08-14 11:13:49 --> Controller Class Initialized
INFO - 2018-08-14 11:13:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:13:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:13:49 --> Pixel_Model class loaded
INFO - 2018-08-14 11:13:49 --> Database Driver Class Initialized
INFO - 2018-08-14 11:13:49 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:13:49 --> Form Validation Class Initialized
INFO - 2018-08-14 11:13:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 11:13:49 --> Database Driver Class Initialized
INFO - 2018-08-14 11:13:49 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:13:49 --> Config Class Initialized
INFO - 2018-08-14 11:13:49 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:13:49 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:13:49 --> Utf8 Class Initialized
INFO - 2018-08-14 11:13:49 --> URI Class Initialized
INFO - 2018-08-14 11:13:49 --> Router Class Initialized
INFO - 2018-08-14 11:13:49 --> Output Class Initialized
INFO - 2018-08-14 11:13:49 --> Security Class Initialized
DEBUG - 2018-08-14 11:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:13:49 --> CSRF cookie sent
INFO - 2018-08-14 11:13:49 --> Input Class Initialized
INFO - 2018-08-14 11:13:49 --> Language Class Initialized
INFO - 2018-08-14 11:13:49 --> Loader Class Initialized
INFO - 2018-08-14 11:13:49 --> Helper loaded: url_helper
INFO - 2018-08-14 11:13:49 --> Helper loaded: form_helper
INFO - 2018-08-14 11:13:49 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:13:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:13:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:13:49 --> User Agent Class Initialized
INFO - 2018-08-14 11:13:49 --> Controller Class Initialized
INFO - 2018-08-14 11:13:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:13:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:13:49 --> Pixel_Model class loaded
INFO - 2018-08-14 11:13:49 --> Database Driver Class Initialized
INFO - 2018-08-14 11:13:49 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:13:49 --> Database Driver Class Initialized
INFO - 2018-08-14 11:13:49 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:13:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:13:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:13:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 11:13:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 11:13:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 11:13:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 11:13:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-08-14 11:13:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:13:49 --> Final output sent to browser
DEBUG - 2018-08-14 11:13:49 --> Total execution time: 0.0505
INFO - 2018-08-14 11:13:57 --> Config Class Initialized
INFO - 2018-08-14 11:13:57 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:13:57 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:13:57 --> Utf8 Class Initialized
INFO - 2018-08-14 11:13:57 --> URI Class Initialized
INFO - 2018-08-14 11:13:57 --> Router Class Initialized
INFO - 2018-08-14 11:13:57 --> Output Class Initialized
INFO - 2018-08-14 11:13:57 --> Security Class Initialized
DEBUG - 2018-08-14 11:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:13:57 --> CSRF cookie sent
INFO - 2018-08-14 11:13:57 --> CSRF token verified
INFO - 2018-08-14 11:13:57 --> Input Class Initialized
INFO - 2018-08-14 11:13:57 --> Language Class Initialized
INFO - 2018-08-14 11:13:57 --> Loader Class Initialized
INFO - 2018-08-14 11:13:57 --> Helper loaded: url_helper
INFO - 2018-08-14 11:13:57 --> Helper loaded: form_helper
INFO - 2018-08-14 11:13:57 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:13:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:13:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:13:57 --> User Agent Class Initialized
INFO - 2018-08-14 11:13:57 --> Controller Class Initialized
INFO - 2018-08-14 11:13:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:13:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:13:57 --> Pixel_Model class loaded
INFO - 2018-08-14 11:13:57 --> Database Driver Class Initialized
INFO - 2018-08-14 11:13:57 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:13:57 --> Form Validation Class Initialized
INFO - 2018-08-14 11:13:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 11:13:57 --> Database Driver Class Initialized
INFO - 2018-08-14 11:13:57 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:13:57 --> Config Class Initialized
INFO - 2018-08-14 11:13:57 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:13:57 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:13:57 --> Utf8 Class Initialized
INFO - 2018-08-14 11:13:57 --> URI Class Initialized
INFO - 2018-08-14 11:13:57 --> Router Class Initialized
INFO - 2018-08-14 11:13:57 --> Output Class Initialized
INFO - 2018-08-14 11:13:57 --> Security Class Initialized
DEBUG - 2018-08-14 11:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:13:57 --> CSRF cookie sent
INFO - 2018-08-14 11:13:57 --> Input Class Initialized
INFO - 2018-08-14 11:13:57 --> Language Class Initialized
INFO - 2018-08-14 11:13:57 --> Loader Class Initialized
INFO - 2018-08-14 11:13:57 --> Helper loaded: url_helper
INFO - 2018-08-14 11:13:57 --> Helper loaded: form_helper
INFO - 2018-08-14 11:13:57 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:13:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:13:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:13:57 --> User Agent Class Initialized
INFO - 2018-08-14 11:13:57 --> Controller Class Initialized
INFO - 2018-08-14 11:13:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:13:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:13:57 --> Pixel_Model class loaded
INFO - 2018-08-14 11:13:57 --> Database Driver Class Initialized
INFO - 2018-08-14 11:13:57 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:13:57 --> Database Driver Class Initialized
INFO - 2018-08-14 11:13:57 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:13:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:13:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:13:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-08-14 11:13:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 11:13:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 11:13:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 11:13:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 11:13:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-08-14 11:13:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:13:57 --> Final output sent to browser
DEBUG - 2018-08-14 11:13:57 --> Total execution time: 0.0379
INFO - 2018-08-14 11:14:01 --> Config Class Initialized
INFO - 2018-08-14 11:14:01 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:14:01 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:14:01 --> Utf8 Class Initialized
INFO - 2018-08-14 11:14:01 --> URI Class Initialized
INFO - 2018-08-14 11:14:01 --> Router Class Initialized
INFO - 2018-08-14 11:14:01 --> Output Class Initialized
INFO - 2018-08-14 11:14:01 --> Security Class Initialized
DEBUG - 2018-08-14 11:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:14:01 --> CSRF cookie sent
INFO - 2018-08-14 11:14:01 --> CSRF token verified
INFO - 2018-08-14 11:14:01 --> Input Class Initialized
INFO - 2018-08-14 11:14:01 --> Language Class Initialized
INFO - 2018-08-14 11:14:01 --> Loader Class Initialized
INFO - 2018-08-14 11:14:01 --> Helper loaded: url_helper
INFO - 2018-08-14 11:14:01 --> Helper loaded: form_helper
INFO - 2018-08-14 11:14:01 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:14:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:14:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:14:01 --> User Agent Class Initialized
INFO - 2018-08-14 11:14:01 --> Controller Class Initialized
INFO - 2018-08-14 11:14:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:14:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:14:01 --> Pixel_Model class loaded
INFO - 2018-08-14 11:14:01 --> Database Driver Class Initialized
INFO - 2018-08-14 11:14:01 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:14:01 --> Form Validation Class Initialized
INFO - 2018-08-14 11:14:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 11:14:01 --> Database Driver Class Initialized
INFO - 2018-08-14 11:14:01 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:14:01 --> Config Class Initialized
INFO - 2018-08-14 11:14:01 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:14:01 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:14:01 --> Utf8 Class Initialized
INFO - 2018-08-14 11:14:01 --> URI Class Initialized
INFO - 2018-08-14 11:14:01 --> Router Class Initialized
INFO - 2018-08-14 11:14:01 --> Output Class Initialized
INFO - 2018-08-14 11:14:01 --> Security Class Initialized
DEBUG - 2018-08-14 11:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:14:01 --> CSRF cookie sent
INFO - 2018-08-14 11:14:01 --> Input Class Initialized
INFO - 2018-08-14 11:14:01 --> Language Class Initialized
INFO - 2018-08-14 11:14:01 --> Loader Class Initialized
INFO - 2018-08-14 11:14:01 --> Helper loaded: url_helper
INFO - 2018-08-14 11:14:01 --> Helper loaded: form_helper
INFO - 2018-08-14 11:14:01 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:14:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:14:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:14:01 --> User Agent Class Initialized
INFO - 2018-08-14 11:14:01 --> Controller Class Initialized
INFO - 2018-08-14 11:14:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:14:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:14:01 --> Pixel_Model class loaded
INFO - 2018-08-14 11:14:01 --> Database Driver Class Initialized
INFO - 2018-08-14 11:14:01 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:14:01 --> Database Driver Class Initialized
INFO - 2018-08-14 11:14:01 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:14:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:14:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:14:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 11:14:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 11:14:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 11:14:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 11:14:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-08-14 11:14:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:14:01 --> Final output sent to browser
DEBUG - 2018-08-14 11:14:01 --> Total execution time: 0.0417
INFO - 2018-08-14 11:14:03 --> Config Class Initialized
INFO - 2018-08-14 11:14:03 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:14:03 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:14:03 --> Utf8 Class Initialized
INFO - 2018-08-14 11:14:03 --> URI Class Initialized
INFO - 2018-08-14 11:14:03 --> Router Class Initialized
INFO - 2018-08-14 11:14:03 --> Output Class Initialized
INFO - 2018-08-14 11:14:03 --> Security Class Initialized
DEBUG - 2018-08-14 11:14:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:14:03 --> CSRF cookie sent
INFO - 2018-08-14 11:14:03 --> Input Class Initialized
INFO - 2018-08-14 11:14:03 --> Language Class Initialized
INFO - 2018-08-14 11:14:03 --> Loader Class Initialized
INFO - 2018-08-14 11:14:03 --> Helper loaded: url_helper
INFO - 2018-08-14 11:14:03 --> Helper loaded: form_helper
INFO - 2018-08-14 11:14:03 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:14:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:14:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:14:03 --> User Agent Class Initialized
INFO - 2018-08-14 11:14:03 --> Controller Class Initialized
INFO - 2018-08-14 11:14:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:14:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:14:03 --> Pixel_Model class loaded
INFO - 2018-08-14 11:14:03 --> Database Driver Class Initialized
INFO - 2018-08-14 11:14:03 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:14:03 --> Database Driver Class Initialized
INFO - 2018-08-14 11:14:03 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:14:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:14:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:14:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 11:14:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 11:14:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 11:14:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 11:14:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-14 11:14:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:14:03 --> Final output sent to browser
DEBUG - 2018-08-14 11:14:03 --> Total execution time: 0.0449
INFO - 2018-08-14 11:14:08 --> Config Class Initialized
INFO - 2018-08-14 11:14:08 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:14:08 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:14:08 --> Utf8 Class Initialized
INFO - 2018-08-14 11:14:08 --> URI Class Initialized
INFO - 2018-08-14 11:14:08 --> Router Class Initialized
INFO - 2018-08-14 11:14:08 --> Output Class Initialized
INFO - 2018-08-14 11:14:08 --> Security Class Initialized
DEBUG - 2018-08-14 11:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:14:08 --> CSRF cookie sent
INFO - 2018-08-14 11:14:08 --> CSRF token verified
INFO - 2018-08-14 11:14:08 --> Input Class Initialized
INFO - 2018-08-14 11:14:08 --> Language Class Initialized
INFO - 2018-08-14 11:14:08 --> Loader Class Initialized
INFO - 2018-08-14 11:14:08 --> Helper loaded: url_helper
INFO - 2018-08-14 11:14:08 --> Helper loaded: form_helper
INFO - 2018-08-14 11:14:08 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:14:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:14:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:14:08 --> User Agent Class Initialized
INFO - 2018-08-14 11:14:08 --> Controller Class Initialized
INFO - 2018-08-14 11:14:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:14:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:14:08 --> Pixel_Model class loaded
INFO - 2018-08-14 11:14:08 --> Database Driver Class Initialized
INFO - 2018-08-14 11:14:08 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:14:08 --> Form Validation Class Initialized
INFO - 2018-08-14 11:14:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 11:14:08 --> Database Driver Class Initialized
INFO - 2018-08-14 11:14:08 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:14:08 --> Config Class Initialized
INFO - 2018-08-14 11:14:08 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:14:08 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:14:08 --> Utf8 Class Initialized
INFO - 2018-08-14 11:14:08 --> URI Class Initialized
INFO - 2018-08-14 11:14:08 --> Router Class Initialized
INFO - 2018-08-14 11:14:08 --> Output Class Initialized
INFO - 2018-08-14 11:14:08 --> Security Class Initialized
DEBUG - 2018-08-14 11:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:14:08 --> CSRF cookie sent
INFO - 2018-08-14 11:14:08 --> Input Class Initialized
INFO - 2018-08-14 11:14:08 --> Language Class Initialized
INFO - 2018-08-14 11:14:08 --> Loader Class Initialized
INFO - 2018-08-14 11:14:08 --> Helper loaded: url_helper
INFO - 2018-08-14 11:14:08 --> Helper loaded: form_helper
INFO - 2018-08-14 11:14:08 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:14:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:14:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:14:08 --> User Agent Class Initialized
INFO - 2018-08-14 11:14:08 --> Controller Class Initialized
INFO - 2018-08-14 11:14:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:14:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:14:08 --> Pixel_Model class loaded
INFO - 2018-08-14 11:14:08 --> Database Driver Class Initialized
INFO - 2018-08-14 11:14:08 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:14:08 --> Database Driver Class Initialized
INFO - 2018-08-14 11:14:08 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:14:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:14:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:14:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 11:14:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 11:14:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 11:14:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 11:14:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-08-14 11:14:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:14:08 --> Final output sent to browser
DEBUG - 2018-08-14 11:14:08 --> Total execution time: 0.0477
INFO - 2018-08-14 11:14:10 --> Config Class Initialized
INFO - 2018-08-14 11:14:10 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:14:10 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:14:10 --> Utf8 Class Initialized
INFO - 2018-08-14 11:14:10 --> URI Class Initialized
INFO - 2018-08-14 11:14:10 --> Router Class Initialized
INFO - 2018-08-14 11:14:10 --> Output Class Initialized
INFO - 2018-08-14 11:14:10 --> Security Class Initialized
DEBUG - 2018-08-14 11:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:14:10 --> CSRF cookie sent
INFO - 2018-08-14 11:14:10 --> CSRF token verified
INFO - 2018-08-14 11:14:10 --> Input Class Initialized
INFO - 2018-08-14 11:14:10 --> Language Class Initialized
INFO - 2018-08-14 11:14:10 --> Loader Class Initialized
INFO - 2018-08-14 11:14:10 --> Helper loaded: url_helper
INFO - 2018-08-14 11:14:10 --> Helper loaded: form_helper
INFO - 2018-08-14 11:14:10 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:14:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:14:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:14:10 --> User Agent Class Initialized
INFO - 2018-08-14 11:14:10 --> Controller Class Initialized
INFO - 2018-08-14 11:14:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:14:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:14:10 --> Pixel_Model class loaded
INFO - 2018-08-14 11:14:10 --> Database Driver Class Initialized
INFO - 2018-08-14 11:14:10 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:14:10 --> Form Validation Class Initialized
INFO - 2018-08-14 11:14:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 11:14:10 --> Database Driver Class Initialized
INFO - 2018-08-14 11:14:10 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:14:10 --> Config Class Initialized
INFO - 2018-08-14 11:14:10 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:14:10 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:14:10 --> Utf8 Class Initialized
INFO - 2018-08-14 11:14:10 --> URI Class Initialized
INFO - 2018-08-14 11:14:10 --> Router Class Initialized
INFO - 2018-08-14 11:14:10 --> Output Class Initialized
INFO - 2018-08-14 11:14:10 --> Security Class Initialized
DEBUG - 2018-08-14 11:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:14:10 --> CSRF cookie sent
INFO - 2018-08-14 11:14:10 --> Input Class Initialized
INFO - 2018-08-14 11:14:10 --> Language Class Initialized
INFO - 2018-08-14 11:14:10 --> Loader Class Initialized
INFO - 2018-08-14 11:14:10 --> Helper loaded: url_helper
INFO - 2018-08-14 11:14:10 --> Helper loaded: form_helper
INFO - 2018-08-14 11:14:10 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:14:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:14:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:14:10 --> User Agent Class Initialized
INFO - 2018-08-14 11:14:10 --> Controller Class Initialized
INFO - 2018-08-14 11:14:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:14:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:14:10 --> Pixel_Model class loaded
INFO - 2018-08-14 11:14:10 --> Database Driver Class Initialized
INFO - 2018-08-14 11:14:10 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:14:10 --> Database Driver Class Initialized
INFO - 2018-08-14 11:14:10 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:14:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:14:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:14:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-08-14 11:14:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 11:14:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 11:14:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 11:14:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 11:14:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-08-14 11:14:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:14:10 --> Final output sent to browser
DEBUG - 2018-08-14 11:14:10 --> Total execution time: 0.0387
INFO - 2018-08-14 11:14:11 --> Config Class Initialized
INFO - 2018-08-14 11:14:11 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:14:11 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:14:11 --> Utf8 Class Initialized
INFO - 2018-08-14 11:14:11 --> URI Class Initialized
INFO - 2018-08-14 11:14:11 --> Router Class Initialized
INFO - 2018-08-14 11:14:11 --> Output Class Initialized
INFO - 2018-08-14 11:14:11 --> Security Class Initialized
DEBUG - 2018-08-14 11:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:14:11 --> CSRF cookie sent
INFO - 2018-08-14 11:14:11 --> CSRF token verified
INFO - 2018-08-14 11:14:11 --> Input Class Initialized
INFO - 2018-08-14 11:14:11 --> Language Class Initialized
INFO - 2018-08-14 11:14:11 --> Loader Class Initialized
INFO - 2018-08-14 11:14:11 --> Helper loaded: url_helper
INFO - 2018-08-14 11:14:11 --> Helper loaded: form_helper
INFO - 2018-08-14 11:14:11 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:14:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:14:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:14:11 --> User Agent Class Initialized
INFO - 2018-08-14 11:14:11 --> Controller Class Initialized
INFO - 2018-08-14 11:14:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:14:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:14:11 --> Pixel_Model class loaded
INFO - 2018-08-14 11:14:11 --> Database Driver Class Initialized
INFO - 2018-08-14 11:14:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:14:11 --> Form Validation Class Initialized
INFO - 2018-08-14 11:14:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 11:14:11 --> Database Driver Class Initialized
INFO - 2018-08-14 11:14:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:14:11 --> Config Class Initialized
INFO - 2018-08-14 11:14:11 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:14:11 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:14:11 --> Utf8 Class Initialized
INFO - 2018-08-14 11:14:11 --> URI Class Initialized
INFO - 2018-08-14 11:14:11 --> Router Class Initialized
INFO - 2018-08-14 11:14:11 --> Output Class Initialized
INFO - 2018-08-14 11:14:11 --> Security Class Initialized
DEBUG - 2018-08-14 11:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:14:11 --> CSRF cookie sent
INFO - 2018-08-14 11:14:11 --> Input Class Initialized
INFO - 2018-08-14 11:14:11 --> Language Class Initialized
INFO - 2018-08-14 11:14:11 --> Loader Class Initialized
INFO - 2018-08-14 11:14:11 --> Helper loaded: url_helper
INFO - 2018-08-14 11:14:11 --> Helper loaded: form_helper
INFO - 2018-08-14 11:14:11 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:14:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:14:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:14:11 --> User Agent Class Initialized
INFO - 2018-08-14 11:14:11 --> Controller Class Initialized
INFO - 2018-08-14 11:14:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:14:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:14:11 --> Pixel_Model class loaded
INFO - 2018-08-14 11:14:11 --> Database Driver Class Initialized
INFO - 2018-08-14 11:14:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:14:11 --> Database Driver Class Initialized
INFO - 2018-08-14 11:14:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:14:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:14:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:14:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 11:14:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 11:14:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 11:14:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 11:14:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-08-14 11:14:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:14:11 --> Final output sent to browser
DEBUG - 2018-08-14 11:14:11 --> Total execution time: 0.0428
INFO - 2018-08-14 11:14:35 --> Config Class Initialized
INFO - 2018-08-14 11:14:35 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:14:35 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:14:35 --> Utf8 Class Initialized
INFO - 2018-08-14 11:14:35 --> URI Class Initialized
INFO - 2018-08-14 11:14:35 --> Router Class Initialized
INFO - 2018-08-14 11:14:35 --> Output Class Initialized
INFO - 2018-08-14 11:14:35 --> Security Class Initialized
DEBUG - 2018-08-14 11:14:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:14:35 --> CSRF cookie sent
INFO - 2018-08-14 11:14:35 --> CSRF token verified
INFO - 2018-08-14 11:14:35 --> Input Class Initialized
INFO - 2018-08-14 11:14:35 --> Language Class Initialized
INFO - 2018-08-14 11:14:35 --> Loader Class Initialized
INFO - 2018-08-14 11:14:35 --> Helper loaded: url_helper
INFO - 2018-08-14 11:14:35 --> Helper loaded: form_helper
INFO - 2018-08-14 11:14:35 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:14:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:14:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:14:35 --> User Agent Class Initialized
INFO - 2018-08-14 11:14:35 --> Controller Class Initialized
INFO - 2018-08-14 11:14:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:14:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:14:35 --> Pixel_Model class loaded
INFO - 2018-08-14 11:14:35 --> Database Driver Class Initialized
INFO - 2018-08-14 11:14:35 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:14:35 --> Form Validation Class Initialized
INFO - 2018-08-14 11:14:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 11:14:35 --> Database Driver Class Initialized
INFO - 2018-08-14 11:14:35 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:14:35 --> Config Class Initialized
INFO - 2018-08-14 11:14:35 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:14:35 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:14:35 --> Utf8 Class Initialized
INFO - 2018-08-14 11:14:35 --> URI Class Initialized
INFO - 2018-08-14 11:14:35 --> Router Class Initialized
INFO - 2018-08-14 11:14:35 --> Output Class Initialized
INFO - 2018-08-14 11:14:35 --> Security Class Initialized
DEBUG - 2018-08-14 11:14:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:14:35 --> CSRF cookie sent
INFO - 2018-08-14 11:14:35 --> Input Class Initialized
INFO - 2018-08-14 11:14:35 --> Language Class Initialized
INFO - 2018-08-14 11:14:35 --> Loader Class Initialized
INFO - 2018-08-14 11:14:35 --> Helper loaded: url_helper
INFO - 2018-08-14 11:14:35 --> Helper loaded: form_helper
INFO - 2018-08-14 11:14:35 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:14:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:14:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:14:35 --> User Agent Class Initialized
INFO - 2018-08-14 11:14:35 --> Controller Class Initialized
INFO - 2018-08-14 11:14:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:14:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:14:35 --> Pixel_Model class loaded
INFO - 2018-08-14 11:14:35 --> Database Driver Class Initialized
INFO - 2018-08-14 11:14:35 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:14:35 --> Database Driver Class Initialized
INFO - 2018-08-14 11:14:35 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:14:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:14:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:14:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 11:14:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 11:14:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 11:14:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 11:14:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-08-14 11:14:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:14:35 --> Final output sent to browser
DEBUG - 2018-08-14 11:14:35 --> Total execution time: 0.0437
INFO - 2018-08-14 11:14:37 --> Config Class Initialized
INFO - 2018-08-14 11:14:37 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:14:37 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:14:37 --> Utf8 Class Initialized
INFO - 2018-08-14 11:14:37 --> URI Class Initialized
INFO - 2018-08-14 11:14:37 --> Router Class Initialized
INFO - 2018-08-14 11:14:37 --> Output Class Initialized
INFO - 2018-08-14 11:14:37 --> Security Class Initialized
DEBUG - 2018-08-14 11:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:14:37 --> CSRF cookie sent
INFO - 2018-08-14 11:14:37 --> Input Class Initialized
INFO - 2018-08-14 11:14:37 --> Language Class Initialized
INFO - 2018-08-14 11:14:37 --> Loader Class Initialized
INFO - 2018-08-14 11:14:37 --> Helper loaded: url_helper
INFO - 2018-08-14 11:14:37 --> Helper loaded: form_helper
INFO - 2018-08-14 11:14:37 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:14:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:14:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:14:37 --> User Agent Class Initialized
INFO - 2018-08-14 11:14:37 --> Controller Class Initialized
INFO - 2018-08-14 11:14:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:14:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:14:37 --> Pixel_Model class loaded
INFO - 2018-08-14 11:14:37 --> Database Driver Class Initialized
INFO - 2018-08-14 11:14:37 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:14:37 --> Database Driver Class Initialized
INFO - 2018-08-14 11:14:37 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:14:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:14:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:14:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 11:14:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 11:14:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 11:14:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 11:14:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-08-14 11:14:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:14:37 --> Final output sent to browser
DEBUG - 2018-08-14 11:14:37 --> Total execution time: 0.0456
INFO - 2018-08-14 11:14:40 --> Config Class Initialized
INFO - 2018-08-14 11:14:40 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:14:40 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:14:40 --> Utf8 Class Initialized
INFO - 2018-08-14 11:14:40 --> URI Class Initialized
INFO - 2018-08-14 11:14:40 --> Router Class Initialized
INFO - 2018-08-14 11:14:40 --> Output Class Initialized
INFO - 2018-08-14 11:14:40 --> Security Class Initialized
DEBUG - 2018-08-14 11:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:14:40 --> CSRF cookie sent
INFO - 2018-08-14 11:14:40 --> CSRF token verified
INFO - 2018-08-14 11:14:40 --> Input Class Initialized
INFO - 2018-08-14 11:14:40 --> Language Class Initialized
INFO - 2018-08-14 11:14:40 --> Loader Class Initialized
INFO - 2018-08-14 11:14:40 --> Helper loaded: url_helper
INFO - 2018-08-14 11:14:40 --> Helper loaded: form_helper
INFO - 2018-08-14 11:14:40 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:14:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:14:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:14:40 --> User Agent Class Initialized
INFO - 2018-08-14 11:14:40 --> Controller Class Initialized
INFO - 2018-08-14 11:14:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:14:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:14:40 --> Pixel_Model class loaded
INFO - 2018-08-14 11:14:40 --> Database Driver Class Initialized
INFO - 2018-08-14 11:14:40 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:14:40 --> Form Validation Class Initialized
INFO - 2018-08-14 11:14:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 11:14:40 --> Database Driver Class Initialized
INFO - 2018-08-14 11:14:40 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:14:40 --> Config Class Initialized
INFO - 2018-08-14 11:14:40 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:14:40 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:14:40 --> Utf8 Class Initialized
INFO - 2018-08-14 11:14:40 --> URI Class Initialized
INFO - 2018-08-14 11:14:40 --> Router Class Initialized
INFO - 2018-08-14 11:14:40 --> Output Class Initialized
INFO - 2018-08-14 11:14:40 --> Security Class Initialized
DEBUG - 2018-08-14 11:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:14:40 --> CSRF cookie sent
INFO - 2018-08-14 11:14:40 --> Input Class Initialized
INFO - 2018-08-14 11:14:40 --> Language Class Initialized
INFO - 2018-08-14 11:14:40 --> Loader Class Initialized
INFO - 2018-08-14 11:14:40 --> Helper loaded: url_helper
INFO - 2018-08-14 11:14:40 --> Helper loaded: form_helper
INFO - 2018-08-14 11:14:40 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:14:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:14:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:14:40 --> User Agent Class Initialized
INFO - 2018-08-14 11:14:40 --> Controller Class Initialized
INFO - 2018-08-14 11:14:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:14:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:14:40 --> Pixel_Model class loaded
INFO - 2018-08-14 11:14:40 --> Database Driver Class Initialized
INFO - 2018-08-14 11:14:40 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:14:40 --> Database Driver Class Initialized
INFO - 2018-08-14 11:14:40 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:14:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:14:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:14:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 11:14:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 11:14:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 11:14:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 11:14:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-08-14 11:14:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:14:40 --> Final output sent to browser
DEBUG - 2018-08-14 11:14:40 --> Total execution time: 0.0433
INFO - 2018-08-14 11:14:53 --> Config Class Initialized
INFO - 2018-08-14 11:14:53 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:14:53 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:14:53 --> Utf8 Class Initialized
INFO - 2018-08-14 11:14:53 --> URI Class Initialized
INFO - 2018-08-14 11:14:53 --> Router Class Initialized
INFO - 2018-08-14 11:14:53 --> Output Class Initialized
INFO - 2018-08-14 11:14:53 --> Security Class Initialized
DEBUG - 2018-08-14 11:14:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:14:53 --> CSRF cookie sent
INFO - 2018-08-14 11:14:53 --> CSRF token verified
INFO - 2018-08-14 11:14:53 --> Input Class Initialized
INFO - 2018-08-14 11:14:53 --> Language Class Initialized
INFO - 2018-08-14 11:14:53 --> Loader Class Initialized
INFO - 2018-08-14 11:14:53 --> Helper loaded: url_helper
INFO - 2018-08-14 11:14:53 --> Helper loaded: form_helper
INFO - 2018-08-14 11:14:53 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:14:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:14:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:14:53 --> User Agent Class Initialized
INFO - 2018-08-14 11:14:53 --> Controller Class Initialized
INFO - 2018-08-14 11:14:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:14:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:14:53 --> Pixel_Model class loaded
INFO - 2018-08-14 11:14:53 --> Database Driver Class Initialized
INFO - 2018-08-14 11:14:53 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:14:53 --> Form Validation Class Initialized
INFO - 2018-08-14 11:14:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 11:14:53 --> Database Driver Class Initialized
INFO - 2018-08-14 11:14:53 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:14:53 --> Config Class Initialized
INFO - 2018-08-14 11:14:53 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:14:53 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:14:53 --> Utf8 Class Initialized
INFO - 2018-08-14 11:14:53 --> URI Class Initialized
INFO - 2018-08-14 11:14:53 --> Router Class Initialized
INFO - 2018-08-14 11:14:53 --> Output Class Initialized
INFO - 2018-08-14 11:14:53 --> Security Class Initialized
DEBUG - 2018-08-14 11:14:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:14:53 --> CSRF cookie sent
INFO - 2018-08-14 11:14:53 --> Input Class Initialized
INFO - 2018-08-14 11:14:53 --> Language Class Initialized
INFO - 2018-08-14 11:14:53 --> Loader Class Initialized
INFO - 2018-08-14 11:14:53 --> Helper loaded: url_helper
INFO - 2018-08-14 11:14:53 --> Helper loaded: form_helper
INFO - 2018-08-14 11:14:53 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:14:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:14:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:14:53 --> User Agent Class Initialized
INFO - 2018-08-14 11:14:53 --> Controller Class Initialized
INFO - 2018-08-14 11:14:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:14:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:14:53 --> Pixel_Model class loaded
INFO - 2018-08-14 11:14:53 --> Database Driver Class Initialized
INFO - 2018-08-14 11:14:53 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:14:53 --> Database Driver Class Initialized
INFO - 2018-08-14 11:14:53 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:14:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:14:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:14:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 11:14:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 11:14:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 11:14:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 11:14:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-08-14 11:14:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:14:53 --> Final output sent to browser
DEBUG - 2018-08-14 11:14:53 --> Total execution time: 0.0466
INFO - 2018-08-14 11:15:12 --> Config Class Initialized
INFO - 2018-08-14 11:15:12 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:15:12 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:15:12 --> Utf8 Class Initialized
INFO - 2018-08-14 11:15:12 --> URI Class Initialized
INFO - 2018-08-14 11:15:12 --> Router Class Initialized
INFO - 2018-08-14 11:15:12 --> Output Class Initialized
INFO - 2018-08-14 11:15:12 --> Security Class Initialized
DEBUG - 2018-08-14 11:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:15:12 --> CSRF cookie sent
INFO - 2018-08-14 11:15:12 --> CSRF token verified
INFO - 2018-08-14 11:15:12 --> Input Class Initialized
INFO - 2018-08-14 11:15:12 --> Language Class Initialized
INFO - 2018-08-14 11:15:12 --> Loader Class Initialized
INFO - 2018-08-14 11:15:12 --> Helper loaded: url_helper
INFO - 2018-08-14 11:15:12 --> Helper loaded: form_helper
INFO - 2018-08-14 11:15:12 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:15:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:15:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:15:12 --> User Agent Class Initialized
INFO - 2018-08-14 11:15:12 --> Controller Class Initialized
INFO - 2018-08-14 11:15:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:15:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:15:12 --> Pixel_Model class loaded
INFO - 2018-08-14 11:15:12 --> Database Driver Class Initialized
INFO - 2018-08-14 11:15:12 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:15:12 --> Form Validation Class Initialized
INFO - 2018-08-14 11:15:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 11:15:12 --> Database Driver Class Initialized
INFO - 2018-08-14 11:15:12 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:15:12 --> Config Class Initialized
INFO - 2018-08-14 11:15:12 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:15:12 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:15:12 --> Utf8 Class Initialized
INFO - 2018-08-14 11:15:12 --> URI Class Initialized
INFO - 2018-08-14 11:15:12 --> Router Class Initialized
INFO - 2018-08-14 11:15:12 --> Output Class Initialized
INFO - 2018-08-14 11:15:12 --> Security Class Initialized
DEBUG - 2018-08-14 11:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:15:12 --> CSRF cookie sent
INFO - 2018-08-14 11:15:12 --> Input Class Initialized
INFO - 2018-08-14 11:15:12 --> Language Class Initialized
INFO - 2018-08-14 11:15:12 --> Loader Class Initialized
INFO - 2018-08-14 11:15:12 --> Helper loaded: url_helper
INFO - 2018-08-14 11:15:12 --> Helper loaded: form_helper
INFO - 2018-08-14 11:15:12 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:15:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:15:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:15:12 --> User Agent Class Initialized
INFO - 2018-08-14 11:15:12 --> Controller Class Initialized
INFO - 2018-08-14 11:15:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:15:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:15:12 --> Pixel_Model class loaded
INFO - 2018-08-14 11:15:12 --> Database Driver Class Initialized
INFO - 2018-08-14 11:15:12 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:15:12 --> Database Driver Class Initialized
INFO - 2018-08-14 11:15:12 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:15:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:15:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:15:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 11:15:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 11:15:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 11:15:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 11:15:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-08-14 11:15:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:15:12 --> Final output sent to browser
DEBUG - 2018-08-14 11:15:12 --> Total execution time: 0.0447
INFO - 2018-08-14 11:15:16 --> Config Class Initialized
INFO - 2018-08-14 11:15:16 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:15:16 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:15:16 --> Utf8 Class Initialized
INFO - 2018-08-14 11:15:16 --> URI Class Initialized
INFO - 2018-08-14 11:15:16 --> Router Class Initialized
INFO - 2018-08-14 11:15:16 --> Output Class Initialized
INFO - 2018-08-14 11:15:16 --> Security Class Initialized
DEBUG - 2018-08-14 11:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:15:16 --> CSRF cookie sent
INFO - 2018-08-14 11:15:16 --> CSRF token verified
INFO - 2018-08-14 11:15:16 --> Input Class Initialized
INFO - 2018-08-14 11:15:16 --> Language Class Initialized
INFO - 2018-08-14 11:15:16 --> Loader Class Initialized
INFO - 2018-08-14 11:15:16 --> Helper loaded: url_helper
INFO - 2018-08-14 11:15:16 --> Helper loaded: form_helper
INFO - 2018-08-14 11:15:16 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:15:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:15:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:15:16 --> User Agent Class Initialized
INFO - 2018-08-14 11:15:16 --> Controller Class Initialized
INFO - 2018-08-14 11:15:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:15:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:15:16 --> Pixel_Model class loaded
INFO - 2018-08-14 11:15:16 --> Database Driver Class Initialized
INFO - 2018-08-14 11:15:16 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:15:16 --> Form Validation Class Initialized
INFO - 2018-08-14 11:15:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 11:15:16 --> Database Driver Class Initialized
INFO - 2018-08-14 11:15:16 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:15:16 --> Config Class Initialized
INFO - 2018-08-14 11:15:16 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:15:16 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:15:16 --> Utf8 Class Initialized
INFO - 2018-08-14 11:15:16 --> URI Class Initialized
INFO - 2018-08-14 11:15:16 --> Router Class Initialized
INFO - 2018-08-14 11:15:16 --> Output Class Initialized
INFO - 2018-08-14 11:15:16 --> Security Class Initialized
DEBUG - 2018-08-14 11:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:15:16 --> CSRF cookie sent
INFO - 2018-08-14 11:15:16 --> Input Class Initialized
INFO - 2018-08-14 11:15:16 --> Language Class Initialized
INFO - 2018-08-14 11:15:16 --> Loader Class Initialized
INFO - 2018-08-14 11:15:16 --> Helper loaded: url_helper
INFO - 2018-08-14 11:15:16 --> Helper loaded: form_helper
INFO - 2018-08-14 11:15:16 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:15:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:15:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:15:16 --> User Agent Class Initialized
INFO - 2018-08-14 11:15:16 --> Controller Class Initialized
INFO - 2018-08-14 11:15:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:15:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:15:16 --> Pixel_Model class loaded
INFO - 2018-08-14 11:15:16 --> Database Driver Class Initialized
INFO - 2018-08-14 11:15:16 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:15:16 --> Database Driver Class Initialized
INFO - 2018-08-14 11:15:16 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:15:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:15:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:15:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 11:15:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 11:15:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 11:15:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 11:15:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_title.php
INFO - 2018-08-14 11:15:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:15:16 --> Final output sent to browser
DEBUG - 2018-08-14 11:15:16 --> Total execution time: 0.0597
INFO - 2018-08-14 11:15:19 --> Config Class Initialized
INFO - 2018-08-14 11:15:19 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:15:19 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:15:19 --> Utf8 Class Initialized
INFO - 2018-08-14 11:15:19 --> URI Class Initialized
INFO - 2018-08-14 11:15:19 --> Router Class Initialized
INFO - 2018-08-14 11:15:19 --> Output Class Initialized
INFO - 2018-08-14 11:15:19 --> Security Class Initialized
DEBUG - 2018-08-14 11:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:15:19 --> CSRF cookie sent
INFO - 2018-08-14 11:15:19 --> CSRF token verified
INFO - 2018-08-14 11:15:19 --> Input Class Initialized
INFO - 2018-08-14 11:15:19 --> Language Class Initialized
INFO - 2018-08-14 11:15:19 --> Loader Class Initialized
INFO - 2018-08-14 11:15:19 --> Helper loaded: url_helper
INFO - 2018-08-14 11:15:19 --> Helper loaded: form_helper
INFO - 2018-08-14 11:15:19 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:15:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:15:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:15:19 --> User Agent Class Initialized
INFO - 2018-08-14 11:15:19 --> Controller Class Initialized
INFO - 2018-08-14 11:15:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:15:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:15:19 --> Pixel_Model class loaded
INFO - 2018-08-14 11:15:19 --> Database Driver Class Initialized
INFO - 2018-08-14 11:15:19 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:15:19 --> Form Validation Class Initialized
INFO - 2018-08-14 11:15:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 11:15:19 --> Database Driver Class Initialized
INFO - 2018-08-14 11:15:19 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:15:19 --> Config Class Initialized
INFO - 2018-08-14 11:15:19 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:15:19 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:15:19 --> Utf8 Class Initialized
INFO - 2018-08-14 11:15:19 --> URI Class Initialized
INFO - 2018-08-14 11:15:19 --> Router Class Initialized
INFO - 2018-08-14 11:15:19 --> Output Class Initialized
INFO - 2018-08-14 11:15:19 --> Security Class Initialized
DEBUG - 2018-08-14 11:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:15:19 --> CSRF cookie sent
INFO - 2018-08-14 11:15:19 --> Input Class Initialized
INFO - 2018-08-14 11:15:19 --> Language Class Initialized
INFO - 2018-08-14 11:15:19 --> Loader Class Initialized
INFO - 2018-08-14 11:15:19 --> Helper loaded: url_helper
INFO - 2018-08-14 11:15:19 --> Helper loaded: form_helper
INFO - 2018-08-14 11:15:19 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:15:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:15:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:15:19 --> User Agent Class Initialized
INFO - 2018-08-14 11:15:19 --> Controller Class Initialized
INFO - 2018-08-14 11:15:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:15:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:15:19 --> Pixel_Model class loaded
INFO - 2018-08-14 11:15:19 --> Database Driver Class Initialized
INFO - 2018-08-14 11:15:19 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:15:19 --> Database Driver Class Initialized
INFO - 2018-08-14 11:15:19 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:15:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:15:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:15:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 11:15:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 11:15:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 11:15:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 11:15:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-08-14 11:15:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:15:19 --> Final output sent to browser
DEBUG - 2018-08-14 11:15:19 --> Total execution time: 0.0649
INFO - 2018-08-14 11:15:23 --> Config Class Initialized
INFO - 2018-08-14 11:15:23 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:15:23 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:15:23 --> Utf8 Class Initialized
INFO - 2018-08-14 11:15:23 --> URI Class Initialized
INFO - 2018-08-14 11:15:23 --> Router Class Initialized
INFO - 2018-08-14 11:15:23 --> Output Class Initialized
INFO - 2018-08-14 11:15:23 --> Security Class Initialized
DEBUG - 2018-08-14 11:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:15:23 --> CSRF cookie sent
INFO - 2018-08-14 11:15:23 --> CSRF token verified
INFO - 2018-08-14 11:15:23 --> Input Class Initialized
INFO - 2018-08-14 11:15:23 --> Language Class Initialized
INFO - 2018-08-14 11:15:23 --> Loader Class Initialized
INFO - 2018-08-14 11:15:23 --> Helper loaded: url_helper
INFO - 2018-08-14 11:15:23 --> Helper loaded: form_helper
INFO - 2018-08-14 11:15:23 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:15:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:15:23 --> User Agent Class Initialized
INFO - 2018-08-14 11:15:23 --> Controller Class Initialized
INFO - 2018-08-14 11:15:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:15:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:15:23 --> Pixel_Model class loaded
INFO - 2018-08-14 11:15:23 --> Database Driver Class Initialized
INFO - 2018-08-14 11:15:23 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:15:23 --> Form Validation Class Initialized
INFO - 2018-08-14 11:15:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 11:15:23 --> Database Driver Class Initialized
INFO - 2018-08-14 11:15:23 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:15:23 --> Config Class Initialized
INFO - 2018-08-14 11:15:23 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:15:23 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:15:23 --> Utf8 Class Initialized
INFO - 2018-08-14 11:15:23 --> URI Class Initialized
INFO - 2018-08-14 11:15:23 --> Router Class Initialized
INFO - 2018-08-14 11:15:23 --> Output Class Initialized
INFO - 2018-08-14 11:15:23 --> Security Class Initialized
DEBUG - 2018-08-14 11:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:15:23 --> CSRF cookie sent
INFO - 2018-08-14 11:15:23 --> Input Class Initialized
INFO - 2018-08-14 11:15:23 --> Language Class Initialized
INFO - 2018-08-14 11:15:23 --> Loader Class Initialized
INFO - 2018-08-14 11:15:23 --> Helper loaded: url_helper
INFO - 2018-08-14 11:15:23 --> Helper loaded: form_helper
INFO - 2018-08-14 11:15:23 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:15:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:15:23 --> User Agent Class Initialized
INFO - 2018-08-14 11:15:23 --> Controller Class Initialized
INFO - 2018-08-14 11:15:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:15:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:15:23 --> Pixel_Model class loaded
INFO - 2018-08-14 11:15:23 --> Database Driver Class Initialized
INFO - 2018-08-14 11:15:23 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:15:23 --> Config Class Initialized
INFO - 2018-08-14 11:15:23 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:15:23 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:15:23 --> Utf8 Class Initialized
INFO - 2018-08-14 11:15:23 --> URI Class Initialized
INFO - 2018-08-14 11:15:23 --> Router Class Initialized
INFO - 2018-08-14 11:15:23 --> Output Class Initialized
INFO - 2018-08-14 11:15:23 --> Security Class Initialized
DEBUG - 2018-08-14 11:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:15:23 --> CSRF cookie sent
INFO - 2018-08-14 11:15:23 --> Input Class Initialized
INFO - 2018-08-14 11:15:23 --> Language Class Initialized
INFO - 2018-08-14 11:15:23 --> Loader Class Initialized
INFO - 2018-08-14 11:15:23 --> Helper loaded: url_helper
INFO - 2018-08-14 11:15:23 --> Helper loaded: form_helper
INFO - 2018-08-14 11:15:23 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:15:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:15:23 --> User Agent Class Initialized
INFO - 2018-08-14 11:15:23 --> Controller Class Initialized
INFO - 2018-08-14 11:15:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:15:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:15:23 --> Pixel_Model class loaded
INFO - 2018-08-14 11:15:23 --> Database Driver Class Initialized
INFO - 2018-08-14 11:15:23 --> Model "RegistrationModel" initialized
DEBUG - 2018-08-14 11:15:23 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-08-14 11:15:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:15:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:15:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 11:15:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 11:15:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/temp.php
INFO - 2018-08-14 11:15:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:15:23 --> Final output sent to browser
DEBUG - 2018-08-14 11:15:23 --> Total execution time: 0.0316
INFO - 2018-08-14 11:15:31 --> Config Class Initialized
INFO - 2018-08-14 11:15:31 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:15:31 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:15:31 --> Utf8 Class Initialized
INFO - 2018-08-14 11:15:31 --> URI Class Initialized
DEBUG - 2018-08-14 11:15:31 --> No URI present. Default controller set.
INFO - 2018-08-14 11:15:31 --> Router Class Initialized
INFO - 2018-08-14 11:15:31 --> Output Class Initialized
INFO - 2018-08-14 11:15:31 --> Security Class Initialized
DEBUG - 2018-08-14 11:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:15:31 --> CSRF cookie sent
INFO - 2018-08-14 11:15:31 --> Input Class Initialized
INFO - 2018-08-14 11:15:31 --> Language Class Initialized
INFO - 2018-08-14 11:15:31 --> Loader Class Initialized
INFO - 2018-08-14 11:15:31 --> Helper loaded: url_helper
INFO - 2018-08-14 11:15:31 --> Helper loaded: form_helper
INFO - 2018-08-14 11:15:31 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:15:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:15:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:15:31 --> User Agent Class Initialized
INFO - 2018-08-14 11:15:31 --> Controller Class Initialized
INFO - 2018-08-14 11:15:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:15:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:15:31 --> Pixel_Model class loaded
INFO - 2018-08-14 11:15:31 --> Database Driver Class Initialized
INFO - 2018-08-14 11:15:31 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:15:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:15:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:15:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-14 11:15:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:15:31 --> Final output sent to browser
DEBUG - 2018-08-14 11:15:31 --> Total execution time: 0.0349
INFO - 2018-08-14 11:22:55 --> Config Class Initialized
INFO - 2018-08-14 11:22:55 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:22:55 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:22:55 --> Utf8 Class Initialized
INFO - 2018-08-14 11:22:55 --> URI Class Initialized
INFO - 2018-08-14 11:22:55 --> Router Class Initialized
INFO - 2018-08-14 11:22:55 --> Output Class Initialized
INFO - 2018-08-14 11:22:55 --> Security Class Initialized
DEBUG - 2018-08-14 11:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:22:55 --> CSRF cookie sent
INFO - 2018-08-14 11:22:55 --> Input Class Initialized
INFO - 2018-08-14 11:22:55 --> Language Class Initialized
INFO - 2018-08-14 11:22:55 --> Loader Class Initialized
INFO - 2018-08-14 11:22:55 --> Helper loaded: url_helper
INFO - 2018-08-14 11:22:55 --> Helper loaded: form_helper
INFO - 2018-08-14 11:22:55 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:22:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:22:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:22:55 --> User Agent Class Initialized
INFO - 2018-08-14 11:22:55 --> Controller Class Initialized
INFO - 2018-08-14 11:22:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:22:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:22:55 --> Pixel_Model class loaded
INFO - 2018-08-14 11:22:55 --> Database Driver Class Initialized
INFO - 2018-08-14 11:22:55 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:22:55 --> Config Class Initialized
INFO - 2018-08-14 11:22:55 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:22:55 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:22:55 --> Utf8 Class Initialized
INFO - 2018-08-14 11:22:55 --> URI Class Initialized
INFO - 2018-08-14 11:22:55 --> Router Class Initialized
INFO - 2018-08-14 11:22:55 --> Output Class Initialized
INFO - 2018-08-14 11:22:55 --> Security Class Initialized
DEBUG - 2018-08-14 11:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:22:55 --> CSRF cookie sent
INFO - 2018-08-14 11:22:55 --> Input Class Initialized
INFO - 2018-08-14 11:22:55 --> Language Class Initialized
INFO - 2018-08-14 11:22:55 --> Loader Class Initialized
INFO - 2018-08-14 11:22:55 --> Helper loaded: url_helper
INFO - 2018-08-14 11:22:55 --> Helper loaded: form_helper
INFO - 2018-08-14 11:22:55 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:22:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:22:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:22:55 --> User Agent Class Initialized
INFO - 2018-08-14 11:22:55 --> Controller Class Initialized
INFO - 2018-08-14 11:22:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:22:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:22:55 --> Pixel_Model class loaded
INFO - 2018-08-14 11:22:55 --> Database Driver Class Initialized
INFO - 2018-08-14 11:22:55 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:22:55 --> Config Class Initialized
INFO - 2018-08-14 11:22:55 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:22:55 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:22:55 --> Utf8 Class Initialized
INFO - 2018-08-14 11:22:55 --> URI Class Initialized
INFO - 2018-08-14 11:22:55 --> Router Class Initialized
INFO - 2018-08-14 11:22:55 --> Output Class Initialized
INFO - 2018-08-14 11:22:55 --> Security Class Initialized
DEBUG - 2018-08-14 11:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:22:55 --> CSRF cookie sent
INFO - 2018-08-14 11:22:55 --> Input Class Initialized
INFO - 2018-08-14 11:22:55 --> Language Class Initialized
INFO - 2018-08-14 11:22:55 --> Loader Class Initialized
INFO - 2018-08-14 11:22:55 --> Helper loaded: url_helper
INFO - 2018-08-14 11:22:55 --> Helper loaded: form_helper
INFO - 2018-08-14 11:22:55 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:22:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:22:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:22:55 --> User Agent Class Initialized
INFO - 2018-08-14 11:22:55 --> Controller Class Initialized
INFO - 2018-08-14 11:22:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:22:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:22:55 --> Pixel_Model class loaded
INFO - 2018-08-14 11:22:55 --> Database Driver Class Initialized
INFO - 2018-08-14 11:22:55 --> Model "RegistrationModel" initialized
DEBUG - 2018-08-14 11:22:55 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-08-14 11:22:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:22:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:22:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 11:22:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 11:22:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/temp.php
INFO - 2018-08-14 11:22:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:22:55 --> Final output sent to browser
DEBUG - 2018-08-14 11:22:55 --> Total execution time: 0.0394
INFO - 2018-08-14 11:23:00 --> Config Class Initialized
INFO - 2018-08-14 11:23:00 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:23:00 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:23:00 --> Utf8 Class Initialized
INFO - 2018-08-14 11:23:00 --> URI Class Initialized
DEBUG - 2018-08-14 11:23:00 --> No URI present. Default controller set.
INFO - 2018-08-14 11:23:00 --> Router Class Initialized
INFO - 2018-08-14 11:23:00 --> Output Class Initialized
INFO - 2018-08-14 11:23:00 --> Security Class Initialized
DEBUG - 2018-08-14 11:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:23:00 --> CSRF cookie sent
INFO - 2018-08-14 11:23:00 --> Input Class Initialized
INFO - 2018-08-14 11:23:00 --> Language Class Initialized
INFO - 2018-08-14 11:23:00 --> Loader Class Initialized
INFO - 2018-08-14 11:23:00 --> Helper loaded: url_helper
INFO - 2018-08-14 11:23:00 --> Helper loaded: form_helper
INFO - 2018-08-14 11:23:00 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:23:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:23:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:23:00 --> User Agent Class Initialized
INFO - 2018-08-14 11:23:00 --> Controller Class Initialized
INFO - 2018-08-14 11:23:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:23:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:23:00 --> Pixel_Model class loaded
INFO - 2018-08-14 11:23:00 --> Database Driver Class Initialized
INFO - 2018-08-14 11:23:00 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:23:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:23:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:23:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-14 11:23:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:23:00 --> Final output sent to browser
DEBUG - 2018-08-14 11:23:00 --> Total execution time: 0.0344
INFO - 2018-08-14 11:23:12 --> Config Class Initialized
INFO - 2018-08-14 11:23:12 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:23:12 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:23:12 --> Utf8 Class Initialized
INFO - 2018-08-14 11:23:12 --> URI Class Initialized
INFO - 2018-08-14 11:23:12 --> Router Class Initialized
INFO - 2018-08-14 11:23:12 --> Output Class Initialized
INFO - 2018-08-14 11:23:12 --> Security Class Initialized
DEBUG - 2018-08-14 11:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:23:12 --> CSRF cookie sent
INFO - 2018-08-14 11:23:12 --> Input Class Initialized
INFO - 2018-08-14 11:23:12 --> Language Class Initialized
INFO - 2018-08-14 11:23:12 --> Loader Class Initialized
INFO - 2018-08-14 11:23:12 --> Helper loaded: url_helper
INFO - 2018-08-14 11:23:12 --> Helper loaded: form_helper
INFO - 2018-08-14 11:23:12 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:23:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:23:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:23:12 --> User Agent Class Initialized
INFO - 2018-08-14 11:23:12 --> Controller Class Initialized
INFO - 2018-08-14 11:23:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:23:12 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-08-14 11:23:12 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-08-14 11:23:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:23:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:23:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 11:23:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-08-14 11:23:12 --> Could not find the language line "req_email"
INFO - 2018-08-14 11:23:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-08-14 11:23:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:23:12 --> Final output sent to browser
DEBUG - 2018-08-14 11:23:12 --> Total execution time: 0.0225
INFO - 2018-08-14 11:23:24 --> Config Class Initialized
INFO - 2018-08-14 11:23:24 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:23:24 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:23:24 --> Utf8 Class Initialized
INFO - 2018-08-14 11:23:24 --> URI Class Initialized
INFO - 2018-08-14 11:23:24 --> Router Class Initialized
INFO - 2018-08-14 11:23:24 --> Output Class Initialized
INFO - 2018-08-14 11:23:24 --> Security Class Initialized
DEBUG - 2018-08-14 11:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:23:24 --> CSRF cookie sent
INFO - 2018-08-14 11:23:24 --> CSRF token verified
INFO - 2018-08-14 11:23:24 --> Input Class Initialized
INFO - 2018-08-14 11:23:24 --> Language Class Initialized
INFO - 2018-08-14 11:23:24 --> Loader Class Initialized
INFO - 2018-08-14 11:23:24 --> Helper loaded: url_helper
INFO - 2018-08-14 11:23:24 --> Helper loaded: form_helper
INFO - 2018-08-14 11:23:24 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:23:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:23:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:23:24 --> User Agent Class Initialized
INFO - 2018-08-14 11:23:24 --> Controller Class Initialized
INFO - 2018-08-14 11:23:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:23:24 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-08-14 11:23:24 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-08-14 11:23:24 --> Form Validation Class Initialized
INFO - 2018-08-14 11:23:24 --> Pixel_Model class loaded
INFO - 2018-08-14 11:23:24 --> Database Driver Class Initialized
INFO - 2018-08-14 11:23:24 --> Model "AuthenticationModel" initialized
INFO - 2018-08-14 11:23:24 --> Database Driver Class Initialized
INFO - 2018-08-14 11:23:24 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:23:24 --> Config Class Initialized
INFO - 2018-08-14 11:23:24 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:23:24 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:23:24 --> Utf8 Class Initialized
INFO - 2018-08-14 11:23:24 --> URI Class Initialized
DEBUG - 2018-08-14 11:23:24 --> No URI present. Default controller set.
INFO - 2018-08-14 11:23:24 --> Router Class Initialized
INFO - 2018-08-14 11:23:24 --> Output Class Initialized
INFO - 2018-08-14 11:23:24 --> Security Class Initialized
DEBUG - 2018-08-14 11:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:23:24 --> CSRF cookie sent
INFO - 2018-08-14 11:23:24 --> Input Class Initialized
INFO - 2018-08-14 11:23:24 --> Language Class Initialized
INFO - 2018-08-14 11:23:24 --> Loader Class Initialized
INFO - 2018-08-14 11:23:24 --> Helper loaded: url_helper
INFO - 2018-08-14 11:23:24 --> Helper loaded: form_helper
INFO - 2018-08-14 11:23:24 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:23:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:23:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:23:24 --> User Agent Class Initialized
INFO - 2018-08-14 11:23:24 --> Controller Class Initialized
INFO - 2018-08-14 11:23:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:23:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:23:24 --> Pixel_Model class loaded
INFO - 2018-08-14 11:23:24 --> Database Driver Class Initialized
INFO - 2018-08-14 11:23:24 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:23:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:23:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-08-14 11:23:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:23:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-14 11:23:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:23:24 --> Final output sent to browser
DEBUG - 2018-08-14 11:23:24 --> Total execution time: 0.0349
INFO - 2018-08-14 11:23:28 --> Config Class Initialized
INFO - 2018-08-14 11:23:28 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:23:28 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:23:28 --> Utf8 Class Initialized
INFO - 2018-08-14 11:23:28 --> URI Class Initialized
INFO - 2018-08-14 11:23:28 --> Router Class Initialized
INFO - 2018-08-14 11:23:28 --> Output Class Initialized
INFO - 2018-08-14 11:23:28 --> Security Class Initialized
DEBUG - 2018-08-14 11:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:23:28 --> CSRF cookie sent
INFO - 2018-08-14 11:23:28 --> CSRF token verified
INFO - 2018-08-14 11:23:28 --> Input Class Initialized
INFO - 2018-08-14 11:23:28 --> Language Class Initialized
INFO - 2018-08-14 11:23:28 --> Loader Class Initialized
INFO - 2018-08-14 11:23:28 --> Helper loaded: url_helper
INFO - 2018-08-14 11:23:28 --> Helper loaded: form_helper
INFO - 2018-08-14 11:23:28 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:23:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:23:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:23:28 --> User Agent Class Initialized
INFO - 2018-08-14 11:23:28 --> Controller Class Initialized
INFO - 2018-08-14 11:23:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:23:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:23:28 --> Pixel_Model class loaded
INFO - 2018-08-14 11:23:28 --> Database Driver Class Initialized
INFO - 2018-08-14 11:23:28 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:23:28 --> Form Validation Class Initialized
INFO - 2018-08-14 11:23:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 11:23:28 --> Database Driver Class Initialized
INFO - 2018-08-14 11:23:28 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:23:28 --> Config Class Initialized
INFO - 2018-08-14 11:23:28 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:23:28 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:23:28 --> Utf8 Class Initialized
INFO - 2018-08-14 11:23:28 --> URI Class Initialized
INFO - 2018-08-14 11:23:28 --> Router Class Initialized
INFO - 2018-08-14 11:23:28 --> Output Class Initialized
INFO - 2018-08-14 11:23:28 --> Security Class Initialized
DEBUG - 2018-08-14 11:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:23:28 --> CSRF cookie sent
INFO - 2018-08-14 11:23:28 --> Input Class Initialized
INFO - 2018-08-14 11:23:28 --> Language Class Initialized
INFO - 2018-08-14 11:23:28 --> Loader Class Initialized
INFO - 2018-08-14 11:23:28 --> Helper loaded: url_helper
INFO - 2018-08-14 11:23:28 --> Helper loaded: form_helper
INFO - 2018-08-14 11:23:28 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:23:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:23:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:23:28 --> User Agent Class Initialized
INFO - 2018-08-14 11:23:28 --> Controller Class Initialized
INFO - 2018-08-14 11:23:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:23:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:23:28 --> Pixel_Model class loaded
INFO - 2018-08-14 11:23:28 --> Database Driver Class Initialized
INFO - 2018-08-14 11:23:28 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:23:28 --> Database Driver Class Initialized
INFO - 2018-08-14 11:23:28 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:23:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:23:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-08-14 11:23:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:23:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 11:23:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 11:23:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 11:23:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 11:23:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-14 11:23:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:23:28 --> Final output sent to browser
DEBUG - 2018-08-14 11:23:28 --> Total execution time: 0.0487
INFO - 2018-08-14 11:23:30 --> Config Class Initialized
INFO - 2018-08-14 11:23:30 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:23:30 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:23:30 --> Utf8 Class Initialized
INFO - 2018-08-14 11:23:30 --> URI Class Initialized
INFO - 2018-08-14 11:23:30 --> Router Class Initialized
INFO - 2018-08-14 11:23:30 --> Output Class Initialized
INFO - 2018-08-14 11:23:30 --> Security Class Initialized
DEBUG - 2018-08-14 11:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:23:30 --> CSRF cookie sent
INFO - 2018-08-14 11:23:30 --> CSRF token verified
INFO - 2018-08-14 11:23:30 --> Input Class Initialized
INFO - 2018-08-14 11:23:30 --> Language Class Initialized
INFO - 2018-08-14 11:23:30 --> Loader Class Initialized
INFO - 2018-08-14 11:23:30 --> Helper loaded: url_helper
INFO - 2018-08-14 11:23:30 --> Helper loaded: form_helper
INFO - 2018-08-14 11:23:30 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:23:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:23:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:23:30 --> User Agent Class Initialized
INFO - 2018-08-14 11:23:30 --> Controller Class Initialized
INFO - 2018-08-14 11:23:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:23:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:23:30 --> Pixel_Model class loaded
INFO - 2018-08-14 11:23:30 --> Database Driver Class Initialized
INFO - 2018-08-14 11:23:30 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:23:30 --> Form Validation Class Initialized
INFO - 2018-08-14 11:23:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 11:23:30 --> Database Driver Class Initialized
INFO - 2018-08-14 11:23:30 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:23:30 --> Config Class Initialized
INFO - 2018-08-14 11:23:30 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:23:30 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:23:30 --> Utf8 Class Initialized
INFO - 2018-08-14 11:23:30 --> URI Class Initialized
INFO - 2018-08-14 11:23:30 --> Router Class Initialized
INFO - 2018-08-14 11:23:30 --> Output Class Initialized
INFO - 2018-08-14 11:23:30 --> Security Class Initialized
DEBUG - 2018-08-14 11:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:23:30 --> CSRF cookie sent
INFO - 2018-08-14 11:23:30 --> Input Class Initialized
INFO - 2018-08-14 11:23:30 --> Language Class Initialized
INFO - 2018-08-14 11:23:30 --> Loader Class Initialized
INFO - 2018-08-14 11:23:30 --> Helper loaded: url_helper
INFO - 2018-08-14 11:23:30 --> Helper loaded: form_helper
INFO - 2018-08-14 11:23:30 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:23:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:23:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:23:30 --> User Agent Class Initialized
INFO - 2018-08-14 11:23:30 --> Controller Class Initialized
INFO - 2018-08-14 11:23:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:23:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:23:30 --> Pixel_Model class loaded
INFO - 2018-08-14 11:23:30 --> Database Driver Class Initialized
INFO - 2018-08-14 11:23:30 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:23:30 --> Database Driver Class Initialized
INFO - 2018-08-14 11:23:30 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:23:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:23:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-08-14 11:23:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:23:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 11:23:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 11:23:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 11:23:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 11:23:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-08-14 11:23:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:23:30 --> Final output sent to browser
DEBUG - 2018-08-14 11:23:30 --> Total execution time: 0.0463
INFO - 2018-08-14 11:23:31 --> Config Class Initialized
INFO - 2018-08-14 11:23:31 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:23:31 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:23:31 --> Utf8 Class Initialized
INFO - 2018-08-14 11:23:31 --> URI Class Initialized
INFO - 2018-08-14 11:23:31 --> Router Class Initialized
INFO - 2018-08-14 11:23:31 --> Output Class Initialized
INFO - 2018-08-14 11:23:31 --> Security Class Initialized
DEBUG - 2018-08-14 11:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:23:31 --> CSRF cookie sent
INFO - 2018-08-14 11:23:31 --> CSRF token verified
INFO - 2018-08-14 11:23:31 --> Input Class Initialized
INFO - 2018-08-14 11:23:31 --> Language Class Initialized
INFO - 2018-08-14 11:23:31 --> Loader Class Initialized
INFO - 2018-08-14 11:23:31 --> Helper loaded: url_helper
INFO - 2018-08-14 11:23:31 --> Helper loaded: form_helper
INFO - 2018-08-14 11:23:31 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:23:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:23:31 --> User Agent Class Initialized
INFO - 2018-08-14 11:23:31 --> Controller Class Initialized
INFO - 2018-08-14 11:23:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:23:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:23:31 --> Pixel_Model class loaded
INFO - 2018-08-14 11:23:31 --> Database Driver Class Initialized
INFO - 2018-08-14 11:23:31 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:23:31 --> Form Validation Class Initialized
INFO - 2018-08-14 11:23:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 11:23:31 --> Database Driver Class Initialized
INFO - 2018-08-14 11:23:31 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:23:31 --> Config Class Initialized
INFO - 2018-08-14 11:23:31 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:23:31 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:23:31 --> Utf8 Class Initialized
INFO - 2018-08-14 11:23:31 --> URI Class Initialized
INFO - 2018-08-14 11:23:31 --> Router Class Initialized
INFO - 2018-08-14 11:23:31 --> Output Class Initialized
INFO - 2018-08-14 11:23:31 --> Security Class Initialized
DEBUG - 2018-08-14 11:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:23:31 --> CSRF cookie sent
INFO - 2018-08-14 11:23:31 --> Input Class Initialized
INFO - 2018-08-14 11:23:31 --> Language Class Initialized
INFO - 2018-08-14 11:23:31 --> Loader Class Initialized
INFO - 2018-08-14 11:23:31 --> Helper loaded: url_helper
INFO - 2018-08-14 11:23:31 --> Helper loaded: form_helper
INFO - 2018-08-14 11:23:31 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:23:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:23:31 --> User Agent Class Initialized
INFO - 2018-08-14 11:23:31 --> Controller Class Initialized
INFO - 2018-08-14 11:23:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:23:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:23:31 --> Pixel_Model class loaded
INFO - 2018-08-14 11:23:32 --> Database Driver Class Initialized
INFO - 2018-08-14 11:23:32 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:23:32 --> Database Driver Class Initialized
INFO - 2018-08-14 11:23:32 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:23:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:23:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-08-14 11:23:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:23:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-08-14 11:23:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 11:23:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 11:23:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 11:23:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 11:23:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-08-14 11:23:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:23:32 --> Final output sent to browser
DEBUG - 2018-08-14 11:23:32 --> Total execution time: 0.0391
INFO - 2018-08-14 11:23:33 --> Config Class Initialized
INFO - 2018-08-14 11:23:33 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:23:33 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:23:33 --> Utf8 Class Initialized
INFO - 2018-08-14 11:23:33 --> URI Class Initialized
INFO - 2018-08-14 11:23:33 --> Router Class Initialized
INFO - 2018-08-14 11:23:33 --> Output Class Initialized
INFO - 2018-08-14 11:23:33 --> Security Class Initialized
DEBUG - 2018-08-14 11:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:23:33 --> CSRF cookie sent
INFO - 2018-08-14 11:23:33 --> CSRF token verified
INFO - 2018-08-14 11:23:33 --> Input Class Initialized
INFO - 2018-08-14 11:23:33 --> Language Class Initialized
INFO - 2018-08-14 11:23:33 --> Loader Class Initialized
INFO - 2018-08-14 11:23:33 --> Helper loaded: url_helper
INFO - 2018-08-14 11:23:33 --> Helper loaded: form_helper
INFO - 2018-08-14 11:23:33 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:23:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:23:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:23:33 --> User Agent Class Initialized
INFO - 2018-08-14 11:23:33 --> Controller Class Initialized
INFO - 2018-08-14 11:23:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:23:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:23:33 --> Pixel_Model class loaded
INFO - 2018-08-14 11:23:33 --> Database Driver Class Initialized
INFO - 2018-08-14 11:23:33 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:23:33 --> Form Validation Class Initialized
INFO - 2018-08-14 11:23:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 11:23:33 --> Database Driver Class Initialized
INFO - 2018-08-14 11:23:33 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:23:33 --> Config Class Initialized
INFO - 2018-08-14 11:23:33 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:23:33 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:23:33 --> Utf8 Class Initialized
INFO - 2018-08-14 11:23:33 --> URI Class Initialized
INFO - 2018-08-14 11:23:33 --> Router Class Initialized
INFO - 2018-08-14 11:23:33 --> Output Class Initialized
INFO - 2018-08-14 11:23:33 --> Security Class Initialized
DEBUG - 2018-08-14 11:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:23:33 --> CSRF cookie sent
INFO - 2018-08-14 11:23:33 --> Input Class Initialized
INFO - 2018-08-14 11:23:33 --> Language Class Initialized
INFO - 2018-08-14 11:23:33 --> Loader Class Initialized
INFO - 2018-08-14 11:23:33 --> Helper loaded: url_helper
INFO - 2018-08-14 11:23:33 --> Helper loaded: form_helper
INFO - 2018-08-14 11:23:33 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:23:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:23:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:23:33 --> User Agent Class Initialized
INFO - 2018-08-14 11:23:33 --> Controller Class Initialized
INFO - 2018-08-14 11:23:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:23:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:23:33 --> Pixel_Model class loaded
INFO - 2018-08-14 11:23:33 --> Database Driver Class Initialized
INFO - 2018-08-14 11:23:33 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:23:33 --> Database Driver Class Initialized
INFO - 2018-08-14 11:23:33 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:23:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:23:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-08-14 11:23:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:23:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 11:23:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 11:23:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 11:23:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 11:23:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-08-14 11:23:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:23:33 --> Final output sent to browser
DEBUG - 2018-08-14 11:23:33 --> Total execution time: 0.0526
INFO - 2018-08-14 11:23:35 --> Config Class Initialized
INFO - 2018-08-14 11:23:35 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:23:35 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:23:35 --> Utf8 Class Initialized
INFO - 2018-08-14 11:23:35 --> URI Class Initialized
INFO - 2018-08-14 11:23:35 --> Router Class Initialized
INFO - 2018-08-14 11:23:35 --> Output Class Initialized
INFO - 2018-08-14 11:23:35 --> Security Class Initialized
DEBUG - 2018-08-14 11:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:23:35 --> CSRF cookie sent
INFO - 2018-08-14 11:23:35 --> CSRF token verified
INFO - 2018-08-14 11:23:35 --> Input Class Initialized
INFO - 2018-08-14 11:23:35 --> Language Class Initialized
INFO - 2018-08-14 11:23:35 --> Loader Class Initialized
INFO - 2018-08-14 11:23:35 --> Helper loaded: url_helper
INFO - 2018-08-14 11:23:35 --> Helper loaded: form_helper
INFO - 2018-08-14 11:23:35 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:23:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:23:35 --> User Agent Class Initialized
INFO - 2018-08-14 11:23:35 --> Controller Class Initialized
INFO - 2018-08-14 11:23:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:23:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:23:35 --> Pixel_Model class loaded
INFO - 2018-08-14 11:23:35 --> Database Driver Class Initialized
INFO - 2018-08-14 11:23:35 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:23:35 --> Form Validation Class Initialized
INFO - 2018-08-14 11:23:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 11:23:35 --> Database Driver Class Initialized
INFO - 2018-08-14 11:23:35 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:23:35 --> Config Class Initialized
INFO - 2018-08-14 11:23:35 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:23:35 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:23:35 --> Utf8 Class Initialized
INFO - 2018-08-14 11:23:35 --> URI Class Initialized
INFO - 2018-08-14 11:23:35 --> Router Class Initialized
INFO - 2018-08-14 11:23:35 --> Output Class Initialized
INFO - 2018-08-14 11:23:35 --> Security Class Initialized
DEBUG - 2018-08-14 11:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:23:35 --> CSRF cookie sent
INFO - 2018-08-14 11:23:35 --> Input Class Initialized
INFO - 2018-08-14 11:23:35 --> Language Class Initialized
INFO - 2018-08-14 11:23:35 --> Loader Class Initialized
INFO - 2018-08-14 11:23:35 --> Helper loaded: url_helper
INFO - 2018-08-14 11:23:35 --> Helper loaded: form_helper
INFO - 2018-08-14 11:23:35 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:23:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:23:35 --> User Agent Class Initialized
INFO - 2018-08-14 11:23:35 --> Controller Class Initialized
INFO - 2018-08-14 11:23:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:23:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:23:35 --> Pixel_Model class loaded
INFO - 2018-08-14 11:23:35 --> Database Driver Class Initialized
INFO - 2018-08-14 11:23:35 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:23:35 --> Database Driver Class Initialized
INFO - 2018-08-14 11:23:35 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:23:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:23:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-08-14 11:23:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:23:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 11:23:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 11:23:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 11:23:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 11:23:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-08-14 11:23:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:23:35 --> Final output sent to browser
DEBUG - 2018-08-14 11:23:35 --> Total execution time: 0.0418
INFO - 2018-08-14 11:23:36 --> Config Class Initialized
INFO - 2018-08-14 11:23:36 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:23:36 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:23:36 --> Utf8 Class Initialized
INFO - 2018-08-14 11:23:36 --> URI Class Initialized
INFO - 2018-08-14 11:23:36 --> Router Class Initialized
INFO - 2018-08-14 11:23:36 --> Output Class Initialized
INFO - 2018-08-14 11:23:36 --> Security Class Initialized
DEBUG - 2018-08-14 11:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:23:36 --> CSRF cookie sent
INFO - 2018-08-14 11:23:36 --> CSRF token verified
INFO - 2018-08-14 11:23:36 --> Input Class Initialized
INFO - 2018-08-14 11:23:36 --> Language Class Initialized
INFO - 2018-08-14 11:23:36 --> Loader Class Initialized
INFO - 2018-08-14 11:23:36 --> Helper loaded: url_helper
INFO - 2018-08-14 11:23:36 --> Helper loaded: form_helper
INFO - 2018-08-14 11:23:36 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:23:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:23:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:23:36 --> User Agent Class Initialized
INFO - 2018-08-14 11:23:36 --> Controller Class Initialized
INFO - 2018-08-14 11:23:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:23:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:23:36 --> Pixel_Model class loaded
INFO - 2018-08-14 11:23:36 --> Database Driver Class Initialized
INFO - 2018-08-14 11:23:36 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:23:36 --> Form Validation Class Initialized
INFO - 2018-08-14 11:23:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 11:23:36 --> Database Driver Class Initialized
INFO - 2018-08-14 11:23:36 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:23:37 --> Config Class Initialized
INFO - 2018-08-14 11:23:37 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:23:37 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:23:37 --> Utf8 Class Initialized
INFO - 2018-08-14 11:23:37 --> URI Class Initialized
INFO - 2018-08-14 11:23:37 --> Router Class Initialized
INFO - 2018-08-14 11:23:37 --> Output Class Initialized
INFO - 2018-08-14 11:23:37 --> Security Class Initialized
DEBUG - 2018-08-14 11:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:23:37 --> CSRF cookie sent
INFO - 2018-08-14 11:23:37 --> Input Class Initialized
INFO - 2018-08-14 11:23:37 --> Language Class Initialized
INFO - 2018-08-14 11:23:37 --> Loader Class Initialized
INFO - 2018-08-14 11:23:37 --> Helper loaded: url_helper
INFO - 2018-08-14 11:23:37 --> Helper loaded: form_helper
INFO - 2018-08-14 11:23:37 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:23:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:23:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:23:37 --> User Agent Class Initialized
INFO - 2018-08-14 11:23:37 --> Controller Class Initialized
INFO - 2018-08-14 11:23:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:23:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:23:37 --> Pixel_Model class loaded
INFO - 2018-08-14 11:23:37 --> Database Driver Class Initialized
INFO - 2018-08-14 11:23:37 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:23:37 --> Database Driver Class Initialized
INFO - 2018-08-14 11:23:37 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:23:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:23:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-08-14 11:23:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:23:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 11:23:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 11:23:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 11:23:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 11:23:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-08-14 11:23:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:23:37 --> Final output sent to browser
DEBUG - 2018-08-14 11:23:37 --> Total execution time: 0.0590
INFO - 2018-08-14 11:23:38 --> Config Class Initialized
INFO - 2018-08-14 11:23:38 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:23:38 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:23:38 --> Utf8 Class Initialized
INFO - 2018-08-14 11:23:38 --> URI Class Initialized
INFO - 2018-08-14 11:23:38 --> Router Class Initialized
INFO - 2018-08-14 11:23:38 --> Output Class Initialized
INFO - 2018-08-14 11:23:38 --> Security Class Initialized
DEBUG - 2018-08-14 11:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:23:38 --> CSRF cookie sent
INFO - 2018-08-14 11:23:38 --> CSRF token verified
INFO - 2018-08-14 11:23:38 --> Input Class Initialized
INFO - 2018-08-14 11:23:38 --> Language Class Initialized
INFO - 2018-08-14 11:23:38 --> Loader Class Initialized
INFO - 2018-08-14 11:23:38 --> Helper loaded: url_helper
INFO - 2018-08-14 11:23:38 --> Helper loaded: form_helper
INFO - 2018-08-14 11:23:38 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:23:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:23:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:23:38 --> User Agent Class Initialized
INFO - 2018-08-14 11:23:38 --> Controller Class Initialized
INFO - 2018-08-14 11:23:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:23:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:23:38 --> Pixel_Model class loaded
INFO - 2018-08-14 11:23:38 --> Database Driver Class Initialized
INFO - 2018-08-14 11:23:38 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:23:38 --> Form Validation Class Initialized
INFO - 2018-08-14 11:23:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 11:23:38 --> Database Driver Class Initialized
INFO - 2018-08-14 11:23:38 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:23:38 --> Config Class Initialized
INFO - 2018-08-14 11:23:38 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:23:38 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:23:38 --> Utf8 Class Initialized
INFO - 2018-08-14 11:23:38 --> URI Class Initialized
INFO - 2018-08-14 11:23:38 --> Router Class Initialized
INFO - 2018-08-14 11:23:38 --> Output Class Initialized
INFO - 2018-08-14 11:23:38 --> Security Class Initialized
DEBUG - 2018-08-14 11:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:23:38 --> CSRF cookie sent
INFO - 2018-08-14 11:23:38 --> Input Class Initialized
INFO - 2018-08-14 11:23:38 --> Language Class Initialized
INFO - 2018-08-14 11:23:38 --> Loader Class Initialized
INFO - 2018-08-14 11:23:38 --> Helper loaded: url_helper
INFO - 2018-08-14 11:23:38 --> Helper loaded: form_helper
INFO - 2018-08-14 11:23:38 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:23:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:23:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:23:38 --> User Agent Class Initialized
INFO - 2018-08-14 11:23:38 --> Controller Class Initialized
INFO - 2018-08-14 11:23:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:23:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:23:38 --> Pixel_Model class loaded
INFO - 2018-08-14 11:23:38 --> Database Driver Class Initialized
INFO - 2018-08-14 11:23:38 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:23:38 --> Database Driver Class Initialized
INFO - 2018-08-14 11:23:38 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:23:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:23:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-08-14 11:23:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:23:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 11:23:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 11:23:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 11:23:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 11:23:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-08-14 11:23:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:23:38 --> Final output sent to browser
DEBUG - 2018-08-14 11:23:38 --> Total execution time: 0.0442
INFO - 2018-08-14 11:23:39 --> Config Class Initialized
INFO - 2018-08-14 11:23:39 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:23:39 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:23:39 --> Utf8 Class Initialized
INFO - 2018-08-14 11:23:39 --> URI Class Initialized
INFO - 2018-08-14 11:23:39 --> Router Class Initialized
INFO - 2018-08-14 11:23:39 --> Output Class Initialized
INFO - 2018-08-14 11:23:39 --> Security Class Initialized
DEBUG - 2018-08-14 11:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:23:39 --> CSRF cookie sent
INFO - 2018-08-14 11:23:39 --> CSRF token verified
INFO - 2018-08-14 11:23:39 --> Input Class Initialized
INFO - 2018-08-14 11:23:39 --> Language Class Initialized
INFO - 2018-08-14 11:23:39 --> Loader Class Initialized
INFO - 2018-08-14 11:23:39 --> Helper loaded: url_helper
INFO - 2018-08-14 11:23:39 --> Helper loaded: form_helper
INFO - 2018-08-14 11:23:39 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:23:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:23:39 --> User Agent Class Initialized
INFO - 2018-08-14 11:23:39 --> Controller Class Initialized
INFO - 2018-08-14 11:23:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:23:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:23:39 --> Pixel_Model class loaded
INFO - 2018-08-14 11:23:39 --> Database Driver Class Initialized
INFO - 2018-08-14 11:23:39 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:23:39 --> Form Validation Class Initialized
INFO - 2018-08-14 11:23:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 11:23:39 --> Database Driver Class Initialized
INFO - 2018-08-14 11:23:39 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:23:39 --> Config Class Initialized
INFO - 2018-08-14 11:23:39 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:23:39 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:23:39 --> Utf8 Class Initialized
INFO - 2018-08-14 11:23:39 --> URI Class Initialized
INFO - 2018-08-14 11:23:39 --> Router Class Initialized
INFO - 2018-08-14 11:23:39 --> Output Class Initialized
INFO - 2018-08-14 11:23:39 --> Security Class Initialized
DEBUG - 2018-08-14 11:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:23:39 --> CSRF cookie sent
INFO - 2018-08-14 11:23:39 --> Input Class Initialized
INFO - 2018-08-14 11:23:39 --> Language Class Initialized
INFO - 2018-08-14 11:23:39 --> Loader Class Initialized
INFO - 2018-08-14 11:23:39 --> Helper loaded: url_helper
INFO - 2018-08-14 11:23:39 --> Helper loaded: form_helper
INFO - 2018-08-14 11:23:39 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:23:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:23:39 --> User Agent Class Initialized
INFO - 2018-08-14 11:23:39 --> Controller Class Initialized
INFO - 2018-08-14 11:23:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:23:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:23:39 --> Pixel_Model class loaded
INFO - 2018-08-14 11:23:39 --> Database Driver Class Initialized
INFO - 2018-08-14 11:23:39 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:23:39 --> Database Driver Class Initialized
INFO - 2018-08-14 11:23:39 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:23:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:23:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-08-14 11:23:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:23:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 11:23:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 11:23:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 11:23:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 11:23:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_title.php
INFO - 2018-08-14 11:23:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:23:39 --> Final output sent to browser
DEBUG - 2018-08-14 11:23:39 --> Total execution time: 0.0594
INFO - 2018-08-14 11:23:41 --> Config Class Initialized
INFO - 2018-08-14 11:23:41 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:23:41 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:23:41 --> Utf8 Class Initialized
INFO - 2018-08-14 11:23:41 --> URI Class Initialized
INFO - 2018-08-14 11:23:41 --> Router Class Initialized
INFO - 2018-08-14 11:23:41 --> Output Class Initialized
INFO - 2018-08-14 11:23:41 --> Security Class Initialized
DEBUG - 2018-08-14 11:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:23:41 --> CSRF cookie sent
INFO - 2018-08-14 11:23:41 --> CSRF token verified
INFO - 2018-08-14 11:23:41 --> Input Class Initialized
INFO - 2018-08-14 11:23:41 --> Language Class Initialized
INFO - 2018-08-14 11:23:41 --> Loader Class Initialized
INFO - 2018-08-14 11:23:41 --> Helper loaded: url_helper
INFO - 2018-08-14 11:23:41 --> Helper loaded: form_helper
INFO - 2018-08-14 11:23:41 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:23:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:23:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:23:41 --> User Agent Class Initialized
INFO - 2018-08-14 11:23:41 --> Controller Class Initialized
INFO - 2018-08-14 11:23:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:23:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:23:41 --> Pixel_Model class loaded
INFO - 2018-08-14 11:23:41 --> Database Driver Class Initialized
INFO - 2018-08-14 11:23:41 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:23:41 --> Form Validation Class Initialized
INFO - 2018-08-14 11:23:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 11:23:41 --> Database Driver Class Initialized
INFO - 2018-08-14 11:23:41 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:23:41 --> Config Class Initialized
INFO - 2018-08-14 11:23:41 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:23:41 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:23:41 --> Utf8 Class Initialized
INFO - 2018-08-14 11:23:41 --> URI Class Initialized
INFO - 2018-08-14 11:23:41 --> Router Class Initialized
INFO - 2018-08-14 11:23:41 --> Output Class Initialized
INFO - 2018-08-14 11:23:41 --> Security Class Initialized
DEBUG - 2018-08-14 11:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:23:41 --> CSRF cookie sent
INFO - 2018-08-14 11:23:41 --> Input Class Initialized
INFO - 2018-08-14 11:23:41 --> Language Class Initialized
INFO - 2018-08-14 11:23:41 --> Loader Class Initialized
INFO - 2018-08-14 11:23:41 --> Helper loaded: url_helper
INFO - 2018-08-14 11:23:41 --> Helper loaded: form_helper
INFO - 2018-08-14 11:23:41 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:23:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:23:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:23:41 --> User Agent Class Initialized
INFO - 2018-08-14 11:23:41 --> Controller Class Initialized
INFO - 2018-08-14 11:23:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:23:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:23:41 --> Pixel_Model class loaded
INFO - 2018-08-14 11:23:41 --> Database Driver Class Initialized
INFO - 2018-08-14 11:23:41 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:23:41 --> Database Driver Class Initialized
INFO - 2018-08-14 11:23:41 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:23:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:23:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-08-14 11:23:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:23:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 11:23:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 11:23:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 11:23:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 11:23:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-08-14 11:23:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:23:41 --> Final output sent to browser
DEBUG - 2018-08-14 11:23:41 --> Total execution time: 0.0464
INFO - 2018-08-14 11:23:43 --> Config Class Initialized
INFO - 2018-08-14 11:23:43 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:23:43 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:23:43 --> Utf8 Class Initialized
INFO - 2018-08-14 11:23:43 --> URI Class Initialized
INFO - 2018-08-14 11:23:43 --> Router Class Initialized
INFO - 2018-08-14 11:23:43 --> Output Class Initialized
INFO - 2018-08-14 11:23:43 --> Security Class Initialized
DEBUG - 2018-08-14 11:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:23:43 --> CSRF cookie sent
INFO - 2018-08-14 11:23:43 --> CSRF token verified
INFO - 2018-08-14 11:23:43 --> Input Class Initialized
INFO - 2018-08-14 11:23:43 --> Language Class Initialized
INFO - 2018-08-14 11:23:43 --> Loader Class Initialized
INFO - 2018-08-14 11:23:43 --> Helper loaded: url_helper
INFO - 2018-08-14 11:23:43 --> Helper loaded: form_helper
INFO - 2018-08-14 11:23:43 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:23:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:23:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:23:43 --> User Agent Class Initialized
INFO - 2018-08-14 11:23:43 --> Controller Class Initialized
INFO - 2018-08-14 11:23:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:23:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:23:43 --> Pixel_Model class loaded
INFO - 2018-08-14 11:23:43 --> Database Driver Class Initialized
INFO - 2018-08-14 11:23:43 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:23:43 --> Form Validation Class Initialized
INFO - 2018-08-14 11:23:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 11:23:43 --> Database Driver Class Initialized
INFO - 2018-08-14 11:23:43 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:23:43 --> Config Class Initialized
INFO - 2018-08-14 11:23:43 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:23:43 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:23:43 --> Utf8 Class Initialized
INFO - 2018-08-14 11:23:43 --> URI Class Initialized
INFO - 2018-08-14 11:23:43 --> Router Class Initialized
INFO - 2018-08-14 11:23:43 --> Output Class Initialized
INFO - 2018-08-14 11:23:43 --> Security Class Initialized
DEBUG - 2018-08-14 11:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:23:43 --> CSRF cookie sent
INFO - 2018-08-14 11:23:43 --> Input Class Initialized
INFO - 2018-08-14 11:23:43 --> Language Class Initialized
INFO - 2018-08-14 11:23:43 --> Loader Class Initialized
INFO - 2018-08-14 11:23:43 --> Helper loaded: url_helper
INFO - 2018-08-14 11:23:43 --> Helper loaded: form_helper
INFO - 2018-08-14 11:23:43 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:23:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:23:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:23:43 --> User Agent Class Initialized
INFO - 2018-08-14 11:23:43 --> Controller Class Initialized
INFO - 2018-08-14 11:23:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:23:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:23:43 --> Pixel_Model class loaded
INFO - 2018-08-14 11:23:43 --> Database Driver Class Initialized
INFO - 2018-08-14 11:23:43 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:23:43 --> Database Driver Class Initialized
INFO - 2018-08-14 11:23:43 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:23:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:23:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-08-14 11:23:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:23:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 11:23:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 11:23:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 11:23:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 11:23:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-08-14 11:23:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:23:43 --> Final output sent to browser
DEBUG - 2018-08-14 11:23:43 --> Total execution time: 0.0422
INFO - 2018-08-14 11:23:45 --> Config Class Initialized
INFO - 2018-08-14 11:23:45 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:23:45 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:23:45 --> Utf8 Class Initialized
INFO - 2018-08-14 11:23:45 --> URI Class Initialized
INFO - 2018-08-14 11:23:45 --> Router Class Initialized
INFO - 2018-08-14 11:23:45 --> Output Class Initialized
INFO - 2018-08-14 11:23:45 --> Security Class Initialized
DEBUG - 2018-08-14 11:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:23:45 --> CSRF cookie sent
INFO - 2018-08-14 11:23:45 --> CSRF token verified
INFO - 2018-08-14 11:23:45 --> Input Class Initialized
INFO - 2018-08-14 11:23:45 --> Language Class Initialized
INFO - 2018-08-14 11:23:45 --> Loader Class Initialized
INFO - 2018-08-14 11:23:45 --> Helper loaded: url_helper
INFO - 2018-08-14 11:23:45 --> Helper loaded: form_helper
INFO - 2018-08-14 11:23:45 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:23:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:23:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:23:45 --> User Agent Class Initialized
INFO - 2018-08-14 11:23:45 --> Controller Class Initialized
INFO - 2018-08-14 11:23:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:23:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:23:45 --> Pixel_Model class loaded
INFO - 2018-08-14 11:23:45 --> Database Driver Class Initialized
INFO - 2018-08-14 11:23:45 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:23:45 --> Form Validation Class Initialized
INFO - 2018-08-14 11:23:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 11:23:45 --> Database Driver Class Initialized
INFO - 2018-08-14 11:23:45 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:23:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:23:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-08-14 11:23:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:23:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 11:23:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 11:23:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 11:23:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_errors.php
INFO - 2018-08-14 11:23:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 11:23:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-08-14 11:23:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:23:45 --> Final output sent to browser
DEBUG - 2018-08-14 11:23:45 --> Total execution time: 0.0439
INFO - 2018-08-14 11:23:54 --> Config Class Initialized
INFO - 2018-08-14 11:23:54 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:23:54 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:23:54 --> Utf8 Class Initialized
INFO - 2018-08-14 11:23:54 --> URI Class Initialized
INFO - 2018-08-14 11:23:54 --> Router Class Initialized
INFO - 2018-08-14 11:23:54 --> Output Class Initialized
INFO - 2018-08-14 11:23:54 --> Security Class Initialized
DEBUG - 2018-08-14 11:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:23:54 --> CSRF cookie sent
INFO - 2018-08-14 11:23:54 --> CSRF token verified
INFO - 2018-08-14 11:23:54 --> Input Class Initialized
INFO - 2018-08-14 11:23:54 --> Language Class Initialized
INFO - 2018-08-14 11:23:54 --> Loader Class Initialized
INFO - 2018-08-14 11:23:54 --> Helper loaded: url_helper
INFO - 2018-08-14 11:23:54 --> Helper loaded: form_helper
INFO - 2018-08-14 11:23:54 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:23:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:23:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:23:54 --> User Agent Class Initialized
INFO - 2018-08-14 11:23:54 --> Controller Class Initialized
INFO - 2018-08-14 11:23:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:23:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:23:54 --> Pixel_Model class loaded
INFO - 2018-08-14 11:23:54 --> Database Driver Class Initialized
INFO - 2018-08-14 11:23:54 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:23:54 --> Form Validation Class Initialized
INFO - 2018-08-14 11:23:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 11:23:54 --> Database Driver Class Initialized
INFO - 2018-08-14 11:23:54 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:23:54 --> Config Class Initialized
INFO - 2018-08-14 11:23:54 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:23:54 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:23:54 --> Utf8 Class Initialized
INFO - 2018-08-14 11:23:54 --> URI Class Initialized
INFO - 2018-08-14 11:23:54 --> Router Class Initialized
INFO - 2018-08-14 11:23:54 --> Output Class Initialized
INFO - 2018-08-14 11:23:54 --> Security Class Initialized
DEBUG - 2018-08-14 11:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:23:54 --> CSRF cookie sent
INFO - 2018-08-14 11:23:54 --> Input Class Initialized
INFO - 2018-08-14 11:23:54 --> Language Class Initialized
INFO - 2018-08-14 11:23:54 --> Loader Class Initialized
INFO - 2018-08-14 11:23:54 --> Helper loaded: url_helper
INFO - 2018-08-14 11:23:54 --> Helper loaded: form_helper
INFO - 2018-08-14 11:23:54 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:23:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:23:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:23:54 --> User Agent Class Initialized
INFO - 2018-08-14 11:23:54 --> Controller Class Initialized
INFO - 2018-08-14 11:23:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:23:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:23:54 --> Pixel_Model class loaded
INFO - 2018-08-14 11:23:54 --> Database Driver Class Initialized
INFO - 2018-08-14 11:23:54 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:23:54 --> Database Driver Class Initialized
INFO - 2018-08-14 11:23:54 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:23:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:23:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-08-14 11:23:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:23:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 11:23:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 11:23:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 11:23:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 11:23:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/spouse_info.php
INFO - 2018-08-14 11:23:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:23:54 --> Final output sent to browser
DEBUG - 2018-08-14 11:23:54 --> Total execution time: 0.0500
INFO - 2018-08-14 11:23:59 --> Config Class Initialized
INFO - 2018-08-14 11:23:59 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:23:59 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:23:59 --> Utf8 Class Initialized
INFO - 2018-08-14 11:23:59 --> URI Class Initialized
INFO - 2018-08-14 11:23:59 --> Router Class Initialized
INFO - 2018-08-14 11:23:59 --> Output Class Initialized
INFO - 2018-08-14 11:23:59 --> Security Class Initialized
DEBUG - 2018-08-14 11:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:23:59 --> CSRF cookie sent
INFO - 2018-08-14 11:23:59 --> CSRF token verified
INFO - 2018-08-14 11:23:59 --> Input Class Initialized
INFO - 2018-08-14 11:23:59 --> Language Class Initialized
INFO - 2018-08-14 11:23:59 --> Loader Class Initialized
INFO - 2018-08-14 11:23:59 --> Helper loaded: url_helper
INFO - 2018-08-14 11:23:59 --> Helper loaded: form_helper
INFO - 2018-08-14 11:23:59 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:23:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:23:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:23:59 --> User Agent Class Initialized
INFO - 2018-08-14 11:23:59 --> Controller Class Initialized
INFO - 2018-08-14 11:23:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:23:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:23:59 --> Pixel_Model class loaded
INFO - 2018-08-14 11:23:59 --> Database Driver Class Initialized
INFO - 2018-08-14 11:23:59 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:23:59 --> Form Validation Class Initialized
INFO - 2018-08-14 11:23:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 11:23:59 --> Database Driver Class Initialized
INFO - 2018-08-14 11:23:59 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:24:00 --> Config Class Initialized
INFO - 2018-08-14 11:24:00 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:24:00 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:24:00 --> Utf8 Class Initialized
INFO - 2018-08-14 11:24:00 --> URI Class Initialized
INFO - 2018-08-14 11:24:00 --> Router Class Initialized
INFO - 2018-08-14 11:24:00 --> Output Class Initialized
INFO - 2018-08-14 11:24:00 --> Security Class Initialized
DEBUG - 2018-08-14 11:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:24:00 --> CSRF cookie sent
INFO - 2018-08-14 11:24:00 --> Input Class Initialized
INFO - 2018-08-14 11:24:00 --> Language Class Initialized
INFO - 2018-08-14 11:24:00 --> Loader Class Initialized
INFO - 2018-08-14 11:24:00 --> Helper loaded: url_helper
INFO - 2018-08-14 11:24:00 --> Helper loaded: form_helper
INFO - 2018-08-14 11:24:00 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:24:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:24:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:24:00 --> User Agent Class Initialized
INFO - 2018-08-14 11:24:00 --> Controller Class Initialized
INFO - 2018-08-14 11:24:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:24:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:24:00 --> Pixel_Model class loaded
INFO - 2018-08-14 11:24:00 --> Database Driver Class Initialized
INFO - 2018-08-14 11:24:00 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:24:00 --> Database Driver Class Initialized
INFO - 2018-08-14 11:24:00 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:24:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:24:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-08-14 11:24:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:24:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 11:24:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 11:24:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 11:24:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 11:24:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/spouse_job.php
INFO - 2018-08-14 11:24:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:24:00 --> Final output sent to browser
DEBUG - 2018-08-14 11:24:00 --> Total execution time: 0.0429
INFO - 2018-08-14 11:24:02 --> Config Class Initialized
INFO - 2018-08-14 11:24:02 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:24:02 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:24:02 --> Utf8 Class Initialized
INFO - 2018-08-14 11:24:02 --> URI Class Initialized
INFO - 2018-08-14 11:24:02 --> Router Class Initialized
INFO - 2018-08-14 11:24:02 --> Output Class Initialized
INFO - 2018-08-14 11:24:02 --> Security Class Initialized
DEBUG - 2018-08-14 11:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:24:02 --> CSRF cookie sent
INFO - 2018-08-14 11:24:02 --> CSRF token verified
INFO - 2018-08-14 11:24:02 --> Input Class Initialized
INFO - 2018-08-14 11:24:02 --> Language Class Initialized
INFO - 2018-08-14 11:24:02 --> Loader Class Initialized
INFO - 2018-08-14 11:24:02 --> Helper loaded: url_helper
INFO - 2018-08-14 11:24:02 --> Helper loaded: form_helper
INFO - 2018-08-14 11:24:02 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:24:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:24:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:24:02 --> User Agent Class Initialized
INFO - 2018-08-14 11:24:02 --> Controller Class Initialized
INFO - 2018-08-14 11:24:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:24:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:24:02 --> Pixel_Model class loaded
INFO - 2018-08-14 11:24:02 --> Database Driver Class Initialized
INFO - 2018-08-14 11:24:02 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:24:02 --> Form Validation Class Initialized
INFO - 2018-08-14 11:24:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 11:24:02 --> Database Driver Class Initialized
INFO - 2018-08-14 11:24:02 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:24:02 --> Config Class Initialized
INFO - 2018-08-14 11:24:02 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:24:02 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:24:02 --> Utf8 Class Initialized
INFO - 2018-08-14 11:24:02 --> URI Class Initialized
INFO - 2018-08-14 11:24:02 --> Router Class Initialized
INFO - 2018-08-14 11:24:02 --> Output Class Initialized
INFO - 2018-08-14 11:24:02 --> Security Class Initialized
DEBUG - 2018-08-14 11:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:24:02 --> CSRF cookie sent
INFO - 2018-08-14 11:24:02 --> Input Class Initialized
INFO - 2018-08-14 11:24:02 --> Language Class Initialized
INFO - 2018-08-14 11:24:02 --> Loader Class Initialized
INFO - 2018-08-14 11:24:02 --> Helper loaded: url_helper
INFO - 2018-08-14 11:24:02 --> Helper loaded: form_helper
INFO - 2018-08-14 11:24:02 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:24:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:24:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:24:02 --> User Agent Class Initialized
INFO - 2018-08-14 11:24:02 --> Controller Class Initialized
INFO - 2018-08-14 11:24:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:24:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:24:02 --> Pixel_Model class loaded
INFO - 2018-08-14 11:24:02 --> Database Driver Class Initialized
INFO - 2018-08-14 11:24:02 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:24:02 --> Database Driver Class Initialized
INFO - 2018-08-14 11:24:02 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:24:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:24:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-08-14 11:24:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:24:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 11:24:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 11:24:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 11:24:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 11:24:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/affectionate_salutation.php
INFO - 2018-08-14 11:24:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:24:02 --> Final output sent to browser
DEBUG - 2018-08-14 11:24:02 --> Total execution time: 0.0450
INFO - 2018-08-14 11:24:06 --> Config Class Initialized
INFO - 2018-08-14 11:24:06 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:24:06 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:24:06 --> Utf8 Class Initialized
INFO - 2018-08-14 11:24:06 --> URI Class Initialized
INFO - 2018-08-14 11:24:06 --> Router Class Initialized
INFO - 2018-08-14 11:24:06 --> Output Class Initialized
INFO - 2018-08-14 11:24:06 --> Security Class Initialized
DEBUG - 2018-08-14 11:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:24:06 --> CSRF cookie sent
INFO - 2018-08-14 11:24:06 --> CSRF token verified
INFO - 2018-08-14 11:24:06 --> Input Class Initialized
INFO - 2018-08-14 11:24:06 --> Language Class Initialized
INFO - 2018-08-14 11:24:06 --> Loader Class Initialized
INFO - 2018-08-14 11:24:06 --> Helper loaded: url_helper
INFO - 2018-08-14 11:24:06 --> Helper loaded: form_helper
INFO - 2018-08-14 11:24:06 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:24:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:24:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:24:06 --> User Agent Class Initialized
INFO - 2018-08-14 11:24:06 --> Controller Class Initialized
INFO - 2018-08-14 11:24:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:24:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:24:06 --> Pixel_Model class loaded
INFO - 2018-08-14 11:24:06 --> Database Driver Class Initialized
INFO - 2018-08-14 11:24:06 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:24:06 --> Form Validation Class Initialized
INFO - 2018-08-14 11:24:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 11:24:06 --> Database Driver Class Initialized
INFO - 2018-08-14 11:24:06 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:24:06 --> Config Class Initialized
INFO - 2018-08-14 11:24:06 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:24:06 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:24:06 --> Utf8 Class Initialized
INFO - 2018-08-14 11:24:06 --> URI Class Initialized
INFO - 2018-08-14 11:24:06 --> Router Class Initialized
INFO - 2018-08-14 11:24:06 --> Output Class Initialized
INFO - 2018-08-14 11:24:06 --> Security Class Initialized
DEBUG - 2018-08-14 11:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:24:06 --> CSRF cookie sent
INFO - 2018-08-14 11:24:06 --> Input Class Initialized
INFO - 2018-08-14 11:24:06 --> Language Class Initialized
INFO - 2018-08-14 11:24:06 --> Loader Class Initialized
INFO - 2018-08-14 11:24:06 --> Helper loaded: url_helper
INFO - 2018-08-14 11:24:06 --> Helper loaded: form_helper
INFO - 2018-08-14 11:24:06 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:24:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:24:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:24:06 --> User Agent Class Initialized
INFO - 2018-08-14 11:24:06 --> Controller Class Initialized
INFO - 2018-08-14 11:24:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:24:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:24:06 --> Pixel_Model class loaded
INFO - 2018-08-14 11:24:06 --> Database Driver Class Initialized
INFO - 2018-08-14 11:24:06 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:24:06 --> Database Driver Class Initialized
INFO - 2018-08-14 11:24:06 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:24:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:24:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-08-14 11:24:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:24:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 11:24:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 11:24:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 11:24:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 11:24:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/business_tax_info.php
INFO - 2018-08-14 11:24:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:24:06 --> Final output sent to browser
DEBUG - 2018-08-14 11:24:06 --> Total execution time: 0.0473
INFO - 2018-08-14 11:24:24 --> Config Class Initialized
INFO - 2018-08-14 11:24:24 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:24:24 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:24:24 --> Utf8 Class Initialized
INFO - 2018-08-14 11:24:24 --> URI Class Initialized
INFO - 2018-08-14 11:24:24 --> Router Class Initialized
INFO - 2018-08-14 11:24:24 --> Output Class Initialized
INFO - 2018-08-14 11:24:24 --> Security Class Initialized
DEBUG - 2018-08-14 11:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:24:24 --> CSRF cookie sent
INFO - 2018-08-14 11:24:24 --> CSRF token verified
INFO - 2018-08-14 11:24:24 --> Input Class Initialized
INFO - 2018-08-14 11:24:24 --> Language Class Initialized
INFO - 2018-08-14 11:24:24 --> Loader Class Initialized
INFO - 2018-08-14 11:24:24 --> Helper loaded: url_helper
INFO - 2018-08-14 11:24:24 --> Helper loaded: form_helper
INFO - 2018-08-14 11:24:24 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:24:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:24:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:24:24 --> User Agent Class Initialized
INFO - 2018-08-14 11:24:24 --> Controller Class Initialized
INFO - 2018-08-14 11:24:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:24:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:24:24 --> Pixel_Model class loaded
INFO - 2018-08-14 11:24:24 --> Database Driver Class Initialized
INFO - 2018-08-14 11:24:24 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:24:24 --> Form Validation Class Initialized
INFO - 2018-08-14 11:24:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 11:24:24 --> Database Driver Class Initialized
INFO - 2018-08-14 11:24:24 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:24:24 --> Config Class Initialized
INFO - 2018-08-14 11:24:24 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:24:24 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:24:24 --> Utf8 Class Initialized
INFO - 2018-08-14 11:24:24 --> URI Class Initialized
INFO - 2018-08-14 11:24:24 --> Router Class Initialized
INFO - 2018-08-14 11:24:24 --> Output Class Initialized
INFO - 2018-08-14 11:24:24 --> Security Class Initialized
DEBUG - 2018-08-14 11:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:24:24 --> CSRF cookie sent
INFO - 2018-08-14 11:24:24 --> Input Class Initialized
INFO - 2018-08-14 11:24:24 --> Language Class Initialized
INFO - 2018-08-14 11:24:24 --> Loader Class Initialized
INFO - 2018-08-14 11:24:24 --> Helper loaded: url_helper
INFO - 2018-08-14 11:24:24 --> Helper loaded: form_helper
INFO - 2018-08-14 11:24:24 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:24:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:24:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:24:24 --> User Agent Class Initialized
INFO - 2018-08-14 11:24:24 --> Controller Class Initialized
INFO - 2018-08-14 11:24:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:24:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:24:24 --> Pixel_Model class loaded
INFO - 2018-08-14 11:24:24 --> Database Driver Class Initialized
INFO - 2018-08-14 11:24:24 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:24:24 --> Database Driver Class Initialized
INFO - 2018-08-14 11:24:24 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:24:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:24:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-08-14 11:24:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:24:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 11:24:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 11:24:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 11:24:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 11:24:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/trust_info.php
INFO - 2018-08-14 11:24:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:24:24 --> Final output sent to browser
DEBUG - 2018-08-14 11:24:24 --> Total execution time: 0.0468
INFO - 2018-08-14 11:24:27 --> Config Class Initialized
INFO - 2018-08-14 11:24:27 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:24:27 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:24:27 --> Utf8 Class Initialized
INFO - 2018-08-14 11:24:27 --> URI Class Initialized
INFO - 2018-08-14 11:24:27 --> Router Class Initialized
INFO - 2018-08-14 11:24:27 --> Output Class Initialized
INFO - 2018-08-14 11:24:27 --> Security Class Initialized
DEBUG - 2018-08-14 11:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:24:27 --> CSRF cookie sent
INFO - 2018-08-14 11:24:27 --> Input Class Initialized
INFO - 2018-08-14 11:24:27 --> Language Class Initialized
INFO - 2018-08-14 11:24:27 --> Loader Class Initialized
INFO - 2018-08-14 11:24:27 --> Helper loaded: url_helper
INFO - 2018-08-14 11:24:27 --> Helper loaded: form_helper
INFO - 2018-08-14 11:24:27 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:24:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:24:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:24:27 --> User Agent Class Initialized
INFO - 2018-08-14 11:24:27 --> Controller Class Initialized
INFO - 2018-08-14 11:24:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:24:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:24:27 --> Pixel_Model class loaded
INFO - 2018-08-14 11:24:27 --> Database Driver Class Initialized
INFO - 2018-08-14 11:24:27 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:24:27 --> Database Driver Class Initialized
INFO - 2018-08-14 11:24:27 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:24:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:24:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-08-14 11:24:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:24:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 11:24:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 11:24:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 11:24:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 11:24:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/business_tax_info.php
INFO - 2018-08-14 11:24:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:24:27 --> Final output sent to browser
DEBUG - 2018-08-14 11:24:27 --> Total execution time: 0.0457
INFO - 2018-08-14 11:25:31 --> Config Class Initialized
INFO - 2018-08-14 11:25:31 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:25:31 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:25:31 --> Utf8 Class Initialized
INFO - 2018-08-14 11:25:31 --> URI Class Initialized
INFO - 2018-08-14 11:25:31 --> Router Class Initialized
INFO - 2018-08-14 11:25:31 --> Output Class Initialized
INFO - 2018-08-14 11:25:31 --> Security Class Initialized
DEBUG - 2018-08-14 11:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:25:31 --> CSRF cookie sent
INFO - 2018-08-14 11:25:31 --> CSRF token verified
INFO - 2018-08-14 11:25:31 --> Input Class Initialized
INFO - 2018-08-14 11:25:31 --> Language Class Initialized
INFO - 2018-08-14 11:25:31 --> Loader Class Initialized
INFO - 2018-08-14 11:25:31 --> Helper loaded: url_helper
INFO - 2018-08-14 11:25:31 --> Helper loaded: form_helper
INFO - 2018-08-14 11:25:31 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:25:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:25:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:25:31 --> User Agent Class Initialized
INFO - 2018-08-14 11:25:31 --> Controller Class Initialized
INFO - 2018-08-14 11:25:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:25:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:25:31 --> Pixel_Model class loaded
INFO - 2018-08-14 11:25:31 --> Database Driver Class Initialized
INFO - 2018-08-14 11:25:31 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:25:31 --> Form Validation Class Initialized
INFO - 2018-08-14 11:25:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 11:25:31 --> Database Driver Class Initialized
INFO - 2018-08-14 11:25:31 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:25:31 --> Config Class Initialized
INFO - 2018-08-14 11:25:31 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:25:31 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:25:31 --> Utf8 Class Initialized
INFO - 2018-08-14 11:25:31 --> URI Class Initialized
INFO - 2018-08-14 11:25:31 --> Router Class Initialized
INFO - 2018-08-14 11:25:31 --> Output Class Initialized
INFO - 2018-08-14 11:25:31 --> Security Class Initialized
DEBUG - 2018-08-14 11:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:25:31 --> CSRF cookie sent
INFO - 2018-08-14 11:25:31 --> Input Class Initialized
INFO - 2018-08-14 11:25:31 --> Language Class Initialized
INFO - 2018-08-14 11:25:31 --> Loader Class Initialized
INFO - 2018-08-14 11:25:31 --> Helper loaded: url_helper
INFO - 2018-08-14 11:25:31 --> Helper loaded: form_helper
INFO - 2018-08-14 11:25:31 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:25:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:25:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:25:31 --> User Agent Class Initialized
INFO - 2018-08-14 11:25:31 --> Controller Class Initialized
INFO - 2018-08-14 11:25:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:25:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:25:31 --> Pixel_Model class loaded
INFO - 2018-08-14 11:25:31 --> Database Driver Class Initialized
INFO - 2018-08-14 11:25:31 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:25:31 --> Database Driver Class Initialized
INFO - 2018-08-14 11:25:31 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:25:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:25:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-08-14 11:25:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:25:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 11:25:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 11:25:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 11:25:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 11:25:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/trust_info.php
INFO - 2018-08-14 11:25:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:25:31 --> Final output sent to browser
DEBUG - 2018-08-14 11:25:31 --> Total execution time: 0.0498
INFO - 2018-08-14 11:25:37 --> Config Class Initialized
INFO - 2018-08-14 11:25:37 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:25:37 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:25:37 --> Utf8 Class Initialized
INFO - 2018-08-14 11:25:37 --> URI Class Initialized
INFO - 2018-08-14 11:25:37 --> Router Class Initialized
INFO - 2018-08-14 11:25:37 --> Output Class Initialized
INFO - 2018-08-14 11:25:37 --> Security Class Initialized
DEBUG - 2018-08-14 11:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:25:37 --> CSRF cookie sent
INFO - 2018-08-14 11:25:37 --> Input Class Initialized
INFO - 2018-08-14 11:25:37 --> Language Class Initialized
INFO - 2018-08-14 11:25:37 --> Loader Class Initialized
INFO - 2018-08-14 11:25:37 --> Helper loaded: url_helper
INFO - 2018-08-14 11:25:37 --> Helper loaded: form_helper
INFO - 2018-08-14 11:25:37 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:25:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:25:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:25:37 --> User Agent Class Initialized
INFO - 2018-08-14 11:25:37 --> Controller Class Initialized
INFO - 2018-08-14 11:25:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:25:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:25:37 --> Pixel_Model class loaded
INFO - 2018-08-14 11:25:37 --> Database Driver Class Initialized
INFO - 2018-08-14 11:25:37 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:25:37 --> Database Driver Class Initialized
INFO - 2018-08-14 11:25:37 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:25:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:25:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-08-14 11:25:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:25:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 11:25:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 11:25:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 11:25:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 11:25:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-14 11:25:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:25:37 --> Final output sent to browser
DEBUG - 2018-08-14 11:25:37 --> Total execution time: 0.0436
INFO - 2018-08-14 11:25:39 --> Config Class Initialized
INFO - 2018-08-14 11:25:39 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:25:39 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:25:39 --> Utf8 Class Initialized
INFO - 2018-08-14 11:25:39 --> URI Class Initialized
INFO - 2018-08-14 11:25:39 --> Router Class Initialized
INFO - 2018-08-14 11:25:39 --> Output Class Initialized
INFO - 2018-08-14 11:25:39 --> Security Class Initialized
DEBUG - 2018-08-14 11:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:25:39 --> CSRF cookie sent
INFO - 2018-08-14 11:25:39 --> CSRF token verified
INFO - 2018-08-14 11:25:39 --> Input Class Initialized
INFO - 2018-08-14 11:25:39 --> Language Class Initialized
INFO - 2018-08-14 11:25:39 --> Loader Class Initialized
INFO - 2018-08-14 11:25:39 --> Helper loaded: url_helper
INFO - 2018-08-14 11:25:39 --> Helper loaded: form_helper
INFO - 2018-08-14 11:25:39 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:25:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:25:39 --> User Agent Class Initialized
INFO - 2018-08-14 11:25:39 --> Controller Class Initialized
INFO - 2018-08-14 11:25:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:25:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:25:39 --> Pixel_Model class loaded
INFO - 2018-08-14 11:25:39 --> Database Driver Class Initialized
INFO - 2018-08-14 11:25:39 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:25:39 --> Form Validation Class Initialized
INFO - 2018-08-14 11:25:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 11:25:39 --> Database Driver Class Initialized
INFO - 2018-08-14 11:25:39 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:25:39 --> Config Class Initialized
INFO - 2018-08-14 11:25:39 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:25:39 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:25:39 --> Utf8 Class Initialized
INFO - 2018-08-14 11:25:39 --> URI Class Initialized
INFO - 2018-08-14 11:25:39 --> Router Class Initialized
INFO - 2018-08-14 11:25:39 --> Output Class Initialized
INFO - 2018-08-14 11:25:39 --> Security Class Initialized
DEBUG - 2018-08-14 11:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:25:39 --> CSRF cookie sent
INFO - 2018-08-14 11:25:39 --> Input Class Initialized
INFO - 2018-08-14 11:25:39 --> Language Class Initialized
INFO - 2018-08-14 11:25:39 --> Loader Class Initialized
INFO - 2018-08-14 11:25:39 --> Helper loaded: url_helper
INFO - 2018-08-14 11:25:39 --> Helper loaded: form_helper
INFO - 2018-08-14 11:25:39 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:25:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:25:39 --> User Agent Class Initialized
INFO - 2018-08-14 11:25:39 --> Controller Class Initialized
INFO - 2018-08-14 11:25:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:25:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:25:39 --> Pixel_Model class loaded
INFO - 2018-08-14 11:25:39 --> Database Driver Class Initialized
INFO - 2018-08-14 11:25:39 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:25:39 --> Database Driver Class Initialized
INFO - 2018-08-14 11:25:39 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:25:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:25:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-08-14 11:25:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:25:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 11:25:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 11:25:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 11:25:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 11:25:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-08-14 11:25:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:25:39 --> Final output sent to browser
DEBUG - 2018-08-14 11:25:39 --> Total execution time: 0.0456
INFO - 2018-08-14 11:25:47 --> Config Class Initialized
INFO - 2018-08-14 11:25:47 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:25:47 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:25:47 --> Utf8 Class Initialized
INFO - 2018-08-14 11:25:47 --> URI Class Initialized
INFO - 2018-08-14 11:25:47 --> Router Class Initialized
INFO - 2018-08-14 11:25:47 --> Output Class Initialized
INFO - 2018-08-14 11:25:47 --> Security Class Initialized
DEBUG - 2018-08-14 11:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:25:47 --> CSRF cookie sent
INFO - 2018-08-14 11:25:47 --> CSRF token verified
INFO - 2018-08-14 11:25:47 --> Input Class Initialized
INFO - 2018-08-14 11:25:47 --> Language Class Initialized
INFO - 2018-08-14 11:25:47 --> Loader Class Initialized
INFO - 2018-08-14 11:25:47 --> Helper loaded: url_helper
INFO - 2018-08-14 11:25:47 --> Helper loaded: form_helper
INFO - 2018-08-14 11:25:47 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:25:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:25:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:25:47 --> User Agent Class Initialized
INFO - 2018-08-14 11:25:47 --> Controller Class Initialized
INFO - 2018-08-14 11:25:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:25:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:25:47 --> Pixel_Model class loaded
INFO - 2018-08-14 11:25:47 --> Database Driver Class Initialized
INFO - 2018-08-14 11:25:47 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:25:47 --> Form Validation Class Initialized
INFO - 2018-08-14 11:25:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 11:25:47 --> Database Driver Class Initialized
INFO - 2018-08-14 11:25:47 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:25:47 --> Config Class Initialized
INFO - 2018-08-14 11:25:47 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:25:47 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:25:47 --> Utf8 Class Initialized
INFO - 2018-08-14 11:25:47 --> URI Class Initialized
INFO - 2018-08-14 11:25:47 --> Router Class Initialized
INFO - 2018-08-14 11:25:47 --> Output Class Initialized
INFO - 2018-08-14 11:25:47 --> Security Class Initialized
DEBUG - 2018-08-14 11:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:25:47 --> CSRF cookie sent
INFO - 2018-08-14 11:25:47 --> Input Class Initialized
INFO - 2018-08-14 11:25:47 --> Language Class Initialized
INFO - 2018-08-14 11:25:47 --> Loader Class Initialized
INFO - 2018-08-14 11:25:47 --> Helper loaded: url_helper
INFO - 2018-08-14 11:25:47 --> Helper loaded: form_helper
INFO - 2018-08-14 11:25:47 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:25:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:25:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:25:47 --> User Agent Class Initialized
INFO - 2018-08-14 11:25:47 --> Controller Class Initialized
INFO - 2018-08-14 11:25:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:25:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:25:47 --> Pixel_Model class loaded
INFO - 2018-08-14 11:25:47 --> Database Driver Class Initialized
INFO - 2018-08-14 11:25:47 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:25:47 --> Database Driver Class Initialized
INFO - 2018-08-14 11:25:47 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:25:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:25:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-08-14 11:25:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:25:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-08-14 11:25:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 11:25:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 11:25:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 11:25:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 11:25:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-08-14 11:25:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:25:47 --> Final output sent to browser
DEBUG - 2018-08-14 11:25:47 --> Total execution time: 0.0450
INFO - 2018-08-14 11:25:48 --> Config Class Initialized
INFO - 2018-08-14 11:25:48 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:25:48 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:25:48 --> Utf8 Class Initialized
INFO - 2018-08-14 11:25:48 --> URI Class Initialized
INFO - 2018-08-14 11:25:48 --> Router Class Initialized
INFO - 2018-08-14 11:25:48 --> Output Class Initialized
INFO - 2018-08-14 11:25:48 --> Security Class Initialized
DEBUG - 2018-08-14 11:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:25:48 --> CSRF cookie sent
INFO - 2018-08-14 11:25:48 --> CSRF token verified
INFO - 2018-08-14 11:25:48 --> Input Class Initialized
INFO - 2018-08-14 11:25:48 --> Language Class Initialized
INFO - 2018-08-14 11:25:48 --> Loader Class Initialized
INFO - 2018-08-14 11:25:48 --> Helper loaded: url_helper
INFO - 2018-08-14 11:25:48 --> Helper loaded: form_helper
INFO - 2018-08-14 11:25:48 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:25:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:25:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:25:48 --> User Agent Class Initialized
INFO - 2018-08-14 11:25:48 --> Controller Class Initialized
INFO - 2018-08-14 11:25:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:25:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:25:48 --> Pixel_Model class loaded
INFO - 2018-08-14 11:25:48 --> Database Driver Class Initialized
INFO - 2018-08-14 11:25:48 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:25:48 --> Form Validation Class Initialized
INFO - 2018-08-14 11:25:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 11:25:48 --> Database Driver Class Initialized
INFO - 2018-08-14 11:25:48 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:25:48 --> Config Class Initialized
INFO - 2018-08-14 11:25:48 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:25:48 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:25:48 --> Utf8 Class Initialized
INFO - 2018-08-14 11:25:48 --> URI Class Initialized
INFO - 2018-08-14 11:25:48 --> Router Class Initialized
INFO - 2018-08-14 11:25:48 --> Output Class Initialized
INFO - 2018-08-14 11:25:48 --> Security Class Initialized
DEBUG - 2018-08-14 11:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:25:48 --> CSRF cookie sent
INFO - 2018-08-14 11:25:48 --> Input Class Initialized
INFO - 2018-08-14 11:25:48 --> Language Class Initialized
INFO - 2018-08-14 11:25:48 --> Loader Class Initialized
INFO - 2018-08-14 11:25:48 --> Helper loaded: url_helper
INFO - 2018-08-14 11:25:48 --> Helper loaded: form_helper
INFO - 2018-08-14 11:25:48 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:25:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:25:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:25:48 --> User Agent Class Initialized
INFO - 2018-08-14 11:25:48 --> Controller Class Initialized
INFO - 2018-08-14 11:25:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:25:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:25:48 --> Pixel_Model class loaded
INFO - 2018-08-14 11:25:48 --> Database Driver Class Initialized
INFO - 2018-08-14 11:25:48 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:25:48 --> Database Driver Class Initialized
INFO - 2018-08-14 11:25:48 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:25:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:25:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-08-14 11:25:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:25:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 11:25:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 11:25:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 11:25:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 11:25:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-08-14 11:25:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:25:48 --> Final output sent to browser
DEBUG - 2018-08-14 11:25:48 --> Total execution time: 0.0404
INFO - 2018-08-14 11:25:49 --> Config Class Initialized
INFO - 2018-08-14 11:25:49 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:25:49 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:25:49 --> Utf8 Class Initialized
INFO - 2018-08-14 11:25:49 --> URI Class Initialized
INFO - 2018-08-14 11:25:49 --> Router Class Initialized
INFO - 2018-08-14 11:25:49 --> Output Class Initialized
INFO - 2018-08-14 11:25:49 --> Security Class Initialized
DEBUG - 2018-08-14 11:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:25:49 --> CSRF cookie sent
INFO - 2018-08-14 11:25:49 --> CSRF token verified
INFO - 2018-08-14 11:25:49 --> Input Class Initialized
INFO - 2018-08-14 11:25:49 --> Language Class Initialized
INFO - 2018-08-14 11:25:49 --> Loader Class Initialized
INFO - 2018-08-14 11:25:49 --> Helper loaded: url_helper
INFO - 2018-08-14 11:25:49 --> Helper loaded: form_helper
INFO - 2018-08-14 11:25:49 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:25:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:25:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:25:49 --> User Agent Class Initialized
INFO - 2018-08-14 11:25:49 --> Controller Class Initialized
INFO - 2018-08-14 11:25:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:25:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:25:49 --> Pixel_Model class loaded
INFO - 2018-08-14 11:25:49 --> Database Driver Class Initialized
INFO - 2018-08-14 11:25:49 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:25:49 --> Form Validation Class Initialized
INFO - 2018-08-14 11:25:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 11:25:49 --> Database Driver Class Initialized
INFO - 2018-08-14 11:25:49 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:25:50 --> Config Class Initialized
INFO - 2018-08-14 11:25:50 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:25:50 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:25:50 --> Utf8 Class Initialized
INFO - 2018-08-14 11:25:50 --> URI Class Initialized
INFO - 2018-08-14 11:25:50 --> Router Class Initialized
INFO - 2018-08-14 11:25:50 --> Output Class Initialized
INFO - 2018-08-14 11:25:50 --> Security Class Initialized
DEBUG - 2018-08-14 11:25:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:25:50 --> CSRF cookie sent
INFO - 2018-08-14 11:25:50 --> Input Class Initialized
INFO - 2018-08-14 11:25:50 --> Language Class Initialized
INFO - 2018-08-14 11:25:50 --> Loader Class Initialized
INFO - 2018-08-14 11:25:50 --> Helper loaded: url_helper
INFO - 2018-08-14 11:25:50 --> Helper loaded: form_helper
INFO - 2018-08-14 11:25:50 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:25:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:25:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:25:50 --> User Agent Class Initialized
INFO - 2018-08-14 11:25:50 --> Controller Class Initialized
INFO - 2018-08-14 11:25:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:25:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:25:50 --> Pixel_Model class loaded
INFO - 2018-08-14 11:25:50 --> Database Driver Class Initialized
INFO - 2018-08-14 11:25:50 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:25:50 --> Database Driver Class Initialized
INFO - 2018-08-14 11:25:50 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:25:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:25:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-08-14 11:25:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:25:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 11:25:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 11:25:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 11:25:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 11:25:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-08-14 11:25:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:25:50 --> Final output sent to browser
DEBUG - 2018-08-14 11:25:50 --> Total execution time: 0.0469
INFO - 2018-08-14 11:25:51 --> Config Class Initialized
INFO - 2018-08-14 11:25:51 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:25:51 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:25:51 --> Utf8 Class Initialized
INFO - 2018-08-14 11:25:51 --> URI Class Initialized
INFO - 2018-08-14 11:25:51 --> Router Class Initialized
INFO - 2018-08-14 11:25:51 --> Output Class Initialized
INFO - 2018-08-14 11:25:51 --> Security Class Initialized
DEBUG - 2018-08-14 11:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:25:51 --> CSRF cookie sent
INFO - 2018-08-14 11:25:51 --> CSRF token verified
INFO - 2018-08-14 11:25:51 --> Input Class Initialized
INFO - 2018-08-14 11:25:51 --> Language Class Initialized
INFO - 2018-08-14 11:25:51 --> Loader Class Initialized
INFO - 2018-08-14 11:25:51 --> Helper loaded: url_helper
INFO - 2018-08-14 11:25:51 --> Helper loaded: form_helper
INFO - 2018-08-14 11:25:51 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:25:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:25:51 --> User Agent Class Initialized
INFO - 2018-08-14 11:25:51 --> Controller Class Initialized
INFO - 2018-08-14 11:25:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:25:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:25:51 --> Pixel_Model class loaded
INFO - 2018-08-14 11:25:51 --> Database Driver Class Initialized
INFO - 2018-08-14 11:25:51 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:25:51 --> Form Validation Class Initialized
INFO - 2018-08-14 11:25:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 11:25:51 --> Database Driver Class Initialized
INFO - 2018-08-14 11:25:51 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:25:51 --> Config Class Initialized
INFO - 2018-08-14 11:25:51 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:25:51 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:25:51 --> Utf8 Class Initialized
INFO - 2018-08-14 11:25:51 --> URI Class Initialized
INFO - 2018-08-14 11:25:51 --> Router Class Initialized
INFO - 2018-08-14 11:25:51 --> Output Class Initialized
INFO - 2018-08-14 11:25:51 --> Security Class Initialized
DEBUG - 2018-08-14 11:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:25:51 --> CSRF cookie sent
INFO - 2018-08-14 11:25:51 --> Input Class Initialized
INFO - 2018-08-14 11:25:51 --> Language Class Initialized
INFO - 2018-08-14 11:25:51 --> Loader Class Initialized
INFO - 2018-08-14 11:25:51 --> Helper loaded: url_helper
INFO - 2018-08-14 11:25:51 --> Helper loaded: form_helper
INFO - 2018-08-14 11:25:51 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:25:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:25:51 --> User Agent Class Initialized
INFO - 2018-08-14 11:25:51 --> Controller Class Initialized
INFO - 2018-08-14 11:25:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:25:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:25:51 --> Pixel_Model class loaded
INFO - 2018-08-14 11:25:51 --> Database Driver Class Initialized
INFO - 2018-08-14 11:25:51 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:25:51 --> Database Driver Class Initialized
INFO - 2018-08-14 11:25:51 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:25:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:25:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-08-14 11:25:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:25:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 11:25:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 11:25:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 11:25:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 11:25:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-08-14 11:25:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:25:51 --> Final output sent to browser
DEBUG - 2018-08-14 11:25:51 --> Total execution time: 0.0469
INFO - 2018-08-14 11:25:52 --> Config Class Initialized
INFO - 2018-08-14 11:25:52 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:25:52 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:25:52 --> Utf8 Class Initialized
INFO - 2018-08-14 11:25:52 --> URI Class Initialized
INFO - 2018-08-14 11:25:52 --> Router Class Initialized
INFO - 2018-08-14 11:25:52 --> Output Class Initialized
INFO - 2018-08-14 11:25:52 --> Security Class Initialized
DEBUG - 2018-08-14 11:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:25:52 --> CSRF cookie sent
INFO - 2018-08-14 11:25:52 --> CSRF token verified
INFO - 2018-08-14 11:25:52 --> Input Class Initialized
INFO - 2018-08-14 11:25:52 --> Language Class Initialized
INFO - 2018-08-14 11:25:52 --> Loader Class Initialized
INFO - 2018-08-14 11:25:52 --> Helper loaded: url_helper
INFO - 2018-08-14 11:25:52 --> Helper loaded: form_helper
INFO - 2018-08-14 11:25:52 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:25:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:25:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:25:52 --> User Agent Class Initialized
INFO - 2018-08-14 11:25:52 --> Controller Class Initialized
INFO - 2018-08-14 11:25:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:25:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:25:52 --> Pixel_Model class loaded
INFO - 2018-08-14 11:25:52 --> Database Driver Class Initialized
INFO - 2018-08-14 11:25:52 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:25:52 --> Form Validation Class Initialized
INFO - 2018-08-14 11:25:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 11:25:52 --> Database Driver Class Initialized
INFO - 2018-08-14 11:25:52 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:25:52 --> Config Class Initialized
INFO - 2018-08-14 11:25:52 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:25:52 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:25:52 --> Utf8 Class Initialized
INFO - 2018-08-14 11:25:52 --> URI Class Initialized
INFO - 2018-08-14 11:25:52 --> Router Class Initialized
INFO - 2018-08-14 11:25:52 --> Output Class Initialized
INFO - 2018-08-14 11:25:52 --> Security Class Initialized
DEBUG - 2018-08-14 11:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:25:52 --> CSRF cookie sent
INFO - 2018-08-14 11:25:52 --> Input Class Initialized
INFO - 2018-08-14 11:25:52 --> Language Class Initialized
INFO - 2018-08-14 11:25:52 --> Loader Class Initialized
INFO - 2018-08-14 11:25:52 --> Helper loaded: url_helper
INFO - 2018-08-14 11:25:52 --> Helper loaded: form_helper
INFO - 2018-08-14 11:25:52 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:25:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:25:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:25:52 --> User Agent Class Initialized
INFO - 2018-08-14 11:25:52 --> Controller Class Initialized
INFO - 2018-08-14 11:25:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:25:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:25:52 --> Pixel_Model class loaded
INFO - 2018-08-14 11:25:52 --> Database Driver Class Initialized
INFO - 2018-08-14 11:25:52 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:25:52 --> Database Driver Class Initialized
INFO - 2018-08-14 11:25:52 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:25:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:25:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-08-14 11:25:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:25:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 11:25:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 11:25:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 11:25:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 11:25:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-08-14 11:25:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:25:52 --> Final output sent to browser
DEBUG - 2018-08-14 11:25:52 --> Total execution time: 0.0444
INFO - 2018-08-14 11:25:53 --> Config Class Initialized
INFO - 2018-08-14 11:25:53 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:25:53 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:25:53 --> Utf8 Class Initialized
INFO - 2018-08-14 11:25:53 --> URI Class Initialized
INFO - 2018-08-14 11:25:53 --> Router Class Initialized
INFO - 2018-08-14 11:25:53 --> Output Class Initialized
INFO - 2018-08-14 11:25:53 --> Security Class Initialized
DEBUG - 2018-08-14 11:25:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:25:53 --> CSRF cookie sent
INFO - 2018-08-14 11:25:53 --> CSRF token verified
INFO - 2018-08-14 11:25:53 --> Input Class Initialized
INFO - 2018-08-14 11:25:53 --> Language Class Initialized
INFO - 2018-08-14 11:25:53 --> Loader Class Initialized
INFO - 2018-08-14 11:25:53 --> Helper loaded: url_helper
INFO - 2018-08-14 11:25:53 --> Helper loaded: form_helper
INFO - 2018-08-14 11:25:53 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:25:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:25:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:25:53 --> User Agent Class Initialized
INFO - 2018-08-14 11:25:53 --> Controller Class Initialized
INFO - 2018-08-14 11:25:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:25:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:25:53 --> Pixel_Model class loaded
INFO - 2018-08-14 11:25:53 --> Database Driver Class Initialized
INFO - 2018-08-14 11:25:53 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:25:53 --> Form Validation Class Initialized
INFO - 2018-08-14 11:25:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 11:25:53 --> Database Driver Class Initialized
INFO - 2018-08-14 11:25:53 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:25:53 --> Config Class Initialized
INFO - 2018-08-14 11:25:53 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:25:53 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:25:53 --> Utf8 Class Initialized
INFO - 2018-08-14 11:25:53 --> URI Class Initialized
INFO - 2018-08-14 11:25:53 --> Router Class Initialized
INFO - 2018-08-14 11:25:53 --> Output Class Initialized
INFO - 2018-08-14 11:25:53 --> Security Class Initialized
DEBUG - 2018-08-14 11:25:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:25:53 --> CSRF cookie sent
INFO - 2018-08-14 11:25:53 --> Input Class Initialized
INFO - 2018-08-14 11:25:53 --> Language Class Initialized
INFO - 2018-08-14 11:25:53 --> Loader Class Initialized
INFO - 2018-08-14 11:25:53 --> Helper loaded: url_helper
INFO - 2018-08-14 11:25:53 --> Helper loaded: form_helper
INFO - 2018-08-14 11:25:53 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:25:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:25:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:25:53 --> User Agent Class Initialized
INFO - 2018-08-14 11:25:53 --> Controller Class Initialized
INFO - 2018-08-14 11:25:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:25:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:25:53 --> Pixel_Model class loaded
INFO - 2018-08-14 11:25:53 --> Database Driver Class Initialized
INFO - 2018-08-14 11:25:53 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:25:53 --> Database Driver Class Initialized
INFO - 2018-08-14 11:25:53 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:25:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:25:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-08-14 11:25:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:25:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 11:25:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 11:25:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 11:25:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 11:25:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_title.php
INFO - 2018-08-14 11:25:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:25:53 --> Final output sent to browser
DEBUG - 2018-08-14 11:25:53 --> Total execution time: 0.0459
INFO - 2018-08-14 11:25:56 --> Config Class Initialized
INFO - 2018-08-14 11:25:56 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:25:56 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:25:56 --> Utf8 Class Initialized
INFO - 2018-08-14 11:25:56 --> URI Class Initialized
INFO - 2018-08-14 11:25:56 --> Router Class Initialized
INFO - 2018-08-14 11:25:56 --> Output Class Initialized
INFO - 2018-08-14 11:25:56 --> Security Class Initialized
DEBUG - 2018-08-14 11:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:25:56 --> CSRF cookie sent
INFO - 2018-08-14 11:25:56 --> CSRF token verified
INFO - 2018-08-14 11:25:56 --> Input Class Initialized
INFO - 2018-08-14 11:25:56 --> Language Class Initialized
INFO - 2018-08-14 11:25:56 --> Loader Class Initialized
INFO - 2018-08-14 11:25:56 --> Helper loaded: url_helper
INFO - 2018-08-14 11:25:56 --> Helper loaded: form_helper
INFO - 2018-08-14 11:25:56 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:25:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:25:56 --> User Agent Class Initialized
INFO - 2018-08-14 11:25:56 --> Controller Class Initialized
INFO - 2018-08-14 11:25:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:25:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:25:56 --> Pixel_Model class loaded
INFO - 2018-08-14 11:25:56 --> Database Driver Class Initialized
INFO - 2018-08-14 11:25:56 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:25:56 --> Form Validation Class Initialized
INFO - 2018-08-14 11:25:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 11:25:56 --> Database Driver Class Initialized
INFO - 2018-08-14 11:25:56 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:25:56 --> Config Class Initialized
INFO - 2018-08-14 11:25:56 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:25:56 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:25:56 --> Utf8 Class Initialized
INFO - 2018-08-14 11:25:56 --> URI Class Initialized
INFO - 2018-08-14 11:25:56 --> Router Class Initialized
INFO - 2018-08-14 11:25:56 --> Output Class Initialized
INFO - 2018-08-14 11:25:56 --> Security Class Initialized
DEBUG - 2018-08-14 11:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:25:56 --> CSRF cookie sent
INFO - 2018-08-14 11:25:56 --> Input Class Initialized
INFO - 2018-08-14 11:25:56 --> Language Class Initialized
INFO - 2018-08-14 11:25:56 --> Loader Class Initialized
INFO - 2018-08-14 11:25:56 --> Helper loaded: url_helper
INFO - 2018-08-14 11:25:56 --> Helper loaded: form_helper
INFO - 2018-08-14 11:25:56 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:25:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:25:56 --> User Agent Class Initialized
INFO - 2018-08-14 11:25:56 --> Controller Class Initialized
INFO - 2018-08-14 11:25:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:25:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:25:56 --> Pixel_Model class loaded
INFO - 2018-08-14 11:25:56 --> Database Driver Class Initialized
INFO - 2018-08-14 11:25:56 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:25:56 --> Database Driver Class Initialized
INFO - 2018-08-14 11:25:56 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:25:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:25:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-08-14 11:25:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:25:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 11:25:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 11:25:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 11:25:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 11:25:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-08-14 11:25:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:25:56 --> Final output sent to browser
DEBUG - 2018-08-14 11:25:56 --> Total execution time: 0.0473
INFO - 2018-08-14 11:25:58 --> Config Class Initialized
INFO - 2018-08-14 11:25:58 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:25:58 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:25:58 --> Utf8 Class Initialized
INFO - 2018-08-14 11:25:58 --> URI Class Initialized
INFO - 2018-08-14 11:25:58 --> Router Class Initialized
INFO - 2018-08-14 11:25:58 --> Output Class Initialized
INFO - 2018-08-14 11:25:58 --> Security Class Initialized
DEBUG - 2018-08-14 11:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:25:58 --> CSRF cookie sent
INFO - 2018-08-14 11:25:58 --> CSRF token verified
INFO - 2018-08-14 11:25:58 --> Input Class Initialized
INFO - 2018-08-14 11:25:58 --> Language Class Initialized
INFO - 2018-08-14 11:25:58 --> Loader Class Initialized
INFO - 2018-08-14 11:25:58 --> Helper loaded: url_helper
INFO - 2018-08-14 11:25:58 --> Helper loaded: form_helper
INFO - 2018-08-14 11:25:58 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:25:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:25:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:25:58 --> User Agent Class Initialized
INFO - 2018-08-14 11:25:58 --> Controller Class Initialized
INFO - 2018-08-14 11:25:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:25:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:25:58 --> Pixel_Model class loaded
INFO - 2018-08-14 11:25:58 --> Database Driver Class Initialized
INFO - 2018-08-14 11:25:58 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:25:58 --> Form Validation Class Initialized
INFO - 2018-08-14 11:25:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 11:25:58 --> Database Driver Class Initialized
INFO - 2018-08-14 11:25:58 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:25:58 --> Config Class Initialized
INFO - 2018-08-14 11:25:58 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:25:58 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:25:58 --> Utf8 Class Initialized
INFO - 2018-08-14 11:25:58 --> URI Class Initialized
INFO - 2018-08-14 11:25:58 --> Router Class Initialized
INFO - 2018-08-14 11:25:58 --> Output Class Initialized
INFO - 2018-08-14 11:25:58 --> Security Class Initialized
DEBUG - 2018-08-14 11:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:25:58 --> CSRF cookie sent
INFO - 2018-08-14 11:25:58 --> Input Class Initialized
INFO - 2018-08-14 11:25:58 --> Language Class Initialized
INFO - 2018-08-14 11:25:58 --> Loader Class Initialized
INFO - 2018-08-14 11:25:58 --> Helper loaded: url_helper
INFO - 2018-08-14 11:25:58 --> Helper loaded: form_helper
INFO - 2018-08-14 11:25:58 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:25:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:25:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:25:58 --> User Agent Class Initialized
INFO - 2018-08-14 11:25:58 --> Controller Class Initialized
INFO - 2018-08-14 11:25:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:25:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:25:58 --> Pixel_Model class loaded
INFO - 2018-08-14 11:25:58 --> Database Driver Class Initialized
INFO - 2018-08-14 11:25:58 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:25:58 --> Database Driver Class Initialized
INFO - 2018-08-14 11:25:58 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:25:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:25:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-08-14 11:25:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:25:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 11:25:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 11:25:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 11:25:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 11:25:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-08-14 11:25:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:25:58 --> Final output sent to browser
DEBUG - 2018-08-14 11:25:58 --> Total execution time: 0.0400
INFO - 2018-08-14 11:26:00 --> Config Class Initialized
INFO - 2018-08-14 11:26:00 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:26:00 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:26:00 --> Utf8 Class Initialized
INFO - 2018-08-14 11:26:00 --> URI Class Initialized
INFO - 2018-08-14 11:26:00 --> Router Class Initialized
INFO - 2018-08-14 11:26:00 --> Output Class Initialized
INFO - 2018-08-14 11:26:00 --> Security Class Initialized
DEBUG - 2018-08-14 11:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:26:00 --> CSRF cookie sent
INFO - 2018-08-14 11:26:00 --> CSRF token verified
INFO - 2018-08-14 11:26:00 --> Input Class Initialized
INFO - 2018-08-14 11:26:00 --> Language Class Initialized
INFO - 2018-08-14 11:26:00 --> Loader Class Initialized
INFO - 2018-08-14 11:26:00 --> Helper loaded: url_helper
INFO - 2018-08-14 11:26:00 --> Helper loaded: form_helper
INFO - 2018-08-14 11:26:00 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:26:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:26:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:26:00 --> User Agent Class Initialized
INFO - 2018-08-14 11:26:00 --> Controller Class Initialized
INFO - 2018-08-14 11:26:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:26:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:26:00 --> Pixel_Model class loaded
INFO - 2018-08-14 11:26:00 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:00 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:00 --> Form Validation Class Initialized
INFO - 2018-08-14 11:26:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 11:26:00 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:00 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:26:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-08-14 11:26:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:26:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 11:26:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 11:26:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 11:26:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_errors.php
INFO - 2018-08-14 11:26:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 11:26:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-08-14 11:26:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:26:00 --> Final output sent to browser
DEBUG - 2018-08-14 11:26:00 --> Total execution time: 0.0402
INFO - 2018-08-14 11:26:04 --> Config Class Initialized
INFO - 2018-08-14 11:26:04 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:26:04 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:26:04 --> Utf8 Class Initialized
INFO - 2018-08-14 11:26:04 --> URI Class Initialized
INFO - 2018-08-14 11:26:04 --> Router Class Initialized
INFO - 2018-08-14 11:26:04 --> Output Class Initialized
INFO - 2018-08-14 11:26:04 --> Security Class Initialized
DEBUG - 2018-08-14 11:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:26:04 --> CSRF cookie sent
INFO - 2018-08-14 11:26:04 --> CSRF token verified
INFO - 2018-08-14 11:26:04 --> Input Class Initialized
INFO - 2018-08-14 11:26:04 --> Language Class Initialized
INFO - 2018-08-14 11:26:04 --> Loader Class Initialized
INFO - 2018-08-14 11:26:04 --> Helper loaded: url_helper
INFO - 2018-08-14 11:26:04 --> Helper loaded: form_helper
INFO - 2018-08-14 11:26:04 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:26:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:26:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:26:04 --> User Agent Class Initialized
INFO - 2018-08-14 11:26:04 --> Controller Class Initialized
INFO - 2018-08-14 11:26:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:26:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:26:04 --> Pixel_Model class loaded
INFO - 2018-08-14 11:26:04 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:04 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:04 --> Form Validation Class Initialized
INFO - 2018-08-14 11:26:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 11:26:04 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:04 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:05 --> Config Class Initialized
INFO - 2018-08-14 11:26:05 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:26:05 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:26:05 --> Utf8 Class Initialized
INFO - 2018-08-14 11:26:05 --> URI Class Initialized
INFO - 2018-08-14 11:26:05 --> Router Class Initialized
INFO - 2018-08-14 11:26:05 --> Output Class Initialized
INFO - 2018-08-14 11:26:05 --> Security Class Initialized
DEBUG - 2018-08-14 11:26:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:26:05 --> CSRF cookie sent
INFO - 2018-08-14 11:26:05 --> Input Class Initialized
INFO - 2018-08-14 11:26:05 --> Language Class Initialized
INFO - 2018-08-14 11:26:05 --> Loader Class Initialized
INFO - 2018-08-14 11:26:05 --> Helper loaded: url_helper
INFO - 2018-08-14 11:26:05 --> Helper loaded: form_helper
INFO - 2018-08-14 11:26:05 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:26:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:26:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:26:05 --> User Agent Class Initialized
INFO - 2018-08-14 11:26:05 --> Controller Class Initialized
INFO - 2018-08-14 11:26:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:26:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:26:05 --> Pixel_Model class loaded
INFO - 2018-08-14 11:26:05 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:05 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:05 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:05 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:26:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-08-14 11:26:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:26:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 11:26:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 11:26:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 11:26:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 11:26:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/spouse_info.php
INFO - 2018-08-14 11:26:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:26:05 --> Final output sent to browser
DEBUG - 2018-08-14 11:26:05 --> Total execution time: 0.0600
INFO - 2018-08-14 11:26:06 --> Config Class Initialized
INFO - 2018-08-14 11:26:06 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:26:06 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:26:06 --> Utf8 Class Initialized
INFO - 2018-08-14 11:26:06 --> URI Class Initialized
INFO - 2018-08-14 11:26:06 --> Router Class Initialized
INFO - 2018-08-14 11:26:06 --> Output Class Initialized
INFO - 2018-08-14 11:26:06 --> Security Class Initialized
DEBUG - 2018-08-14 11:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:26:06 --> CSRF cookie sent
INFO - 2018-08-14 11:26:06 --> CSRF token verified
INFO - 2018-08-14 11:26:06 --> Input Class Initialized
INFO - 2018-08-14 11:26:06 --> Language Class Initialized
INFO - 2018-08-14 11:26:06 --> Loader Class Initialized
INFO - 2018-08-14 11:26:06 --> Helper loaded: url_helper
INFO - 2018-08-14 11:26:06 --> Helper loaded: form_helper
INFO - 2018-08-14 11:26:06 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:26:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:26:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:26:06 --> User Agent Class Initialized
INFO - 2018-08-14 11:26:06 --> Controller Class Initialized
INFO - 2018-08-14 11:26:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:26:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:26:06 --> Pixel_Model class loaded
INFO - 2018-08-14 11:26:06 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:06 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:06 --> Form Validation Class Initialized
INFO - 2018-08-14 11:26:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 11:26:06 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:06 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:06 --> Config Class Initialized
INFO - 2018-08-14 11:26:06 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:26:06 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:26:06 --> Utf8 Class Initialized
INFO - 2018-08-14 11:26:06 --> URI Class Initialized
INFO - 2018-08-14 11:26:06 --> Router Class Initialized
INFO - 2018-08-14 11:26:06 --> Output Class Initialized
INFO - 2018-08-14 11:26:06 --> Security Class Initialized
DEBUG - 2018-08-14 11:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:26:06 --> CSRF cookie sent
INFO - 2018-08-14 11:26:06 --> Input Class Initialized
INFO - 2018-08-14 11:26:06 --> Language Class Initialized
INFO - 2018-08-14 11:26:06 --> Loader Class Initialized
INFO - 2018-08-14 11:26:06 --> Helper loaded: url_helper
INFO - 2018-08-14 11:26:06 --> Helper loaded: form_helper
INFO - 2018-08-14 11:26:06 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:26:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:26:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:26:06 --> User Agent Class Initialized
INFO - 2018-08-14 11:26:06 --> Controller Class Initialized
INFO - 2018-08-14 11:26:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:26:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:26:06 --> Pixel_Model class loaded
INFO - 2018-08-14 11:26:06 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:06 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:06 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:06 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:26:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-08-14 11:26:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:26:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 11:26:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 11:26:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 11:26:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 11:26:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/spouse_job.php
INFO - 2018-08-14 11:26:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:26:06 --> Final output sent to browser
DEBUG - 2018-08-14 11:26:06 --> Total execution time: 0.0470
INFO - 2018-08-14 11:26:08 --> Config Class Initialized
INFO - 2018-08-14 11:26:08 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:26:08 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:26:08 --> Utf8 Class Initialized
INFO - 2018-08-14 11:26:08 --> URI Class Initialized
INFO - 2018-08-14 11:26:08 --> Router Class Initialized
INFO - 2018-08-14 11:26:08 --> Output Class Initialized
INFO - 2018-08-14 11:26:08 --> Security Class Initialized
DEBUG - 2018-08-14 11:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:26:08 --> CSRF cookie sent
INFO - 2018-08-14 11:26:08 --> CSRF token verified
INFO - 2018-08-14 11:26:08 --> Input Class Initialized
INFO - 2018-08-14 11:26:08 --> Language Class Initialized
INFO - 2018-08-14 11:26:08 --> Loader Class Initialized
INFO - 2018-08-14 11:26:08 --> Helper loaded: url_helper
INFO - 2018-08-14 11:26:08 --> Helper loaded: form_helper
INFO - 2018-08-14 11:26:08 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:26:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:26:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:26:08 --> User Agent Class Initialized
INFO - 2018-08-14 11:26:08 --> Controller Class Initialized
INFO - 2018-08-14 11:26:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:26:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:26:08 --> Pixel_Model class loaded
INFO - 2018-08-14 11:26:08 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:08 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:08 --> Form Validation Class Initialized
INFO - 2018-08-14 11:26:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 11:26:08 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:08 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:08 --> Config Class Initialized
INFO - 2018-08-14 11:26:08 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:26:08 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:26:08 --> Utf8 Class Initialized
INFO - 2018-08-14 11:26:08 --> URI Class Initialized
INFO - 2018-08-14 11:26:08 --> Router Class Initialized
INFO - 2018-08-14 11:26:08 --> Output Class Initialized
INFO - 2018-08-14 11:26:08 --> Security Class Initialized
DEBUG - 2018-08-14 11:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:26:08 --> CSRF cookie sent
INFO - 2018-08-14 11:26:08 --> Input Class Initialized
INFO - 2018-08-14 11:26:08 --> Language Class Initialized
INFO - 2018-08-14 11:26:08 --> Loader Class Initialized
INFO - 2018-08-14 11:26:08 --> Helper loaded: url_helper
INFO - 2018-08-14 11:26:08 --> Helper loaded: form_helper
INFO - 2018-08-14 11:26:08 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:26:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:26:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:26:08 --> User Agent Class Initialized
INFO - 2018-08-14 11:26:08 --> Controller Class Initialized
INFO - 2018-08-14 11:26:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:26:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:26:08 --> Pixel_Model class loaded
INFO - 2018-08-14 11:26:08 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:08 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:08 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:08 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:26:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-08-14 11:26:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:26:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 11:26:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 11:26:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 11:26:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 11:26:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/affectionate_salutation.php
INFO - 2018-08-14 11:26:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:26:08 --> Final output sent to browser
DEBUG - 2018-08-14 11:26:08 --> Total execution time: 0.0443
INFO - 2018-08-14 11:26:09 --> Config Class Initialized
INFO - 2018-08-14 11:26:09 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:26:09 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:26:09 --> Utf8 Class Initialized
INFO - 2018-08-14 11:26:09 --> URI Class Initialized
INFO - 2018-08-14 11:26:09 --> Router Class Initialized
INFO - 2018-08-14 11:26:09 --> Output Class Initialized
INFO - 2018-08-14 11:26:09 --> Security Class Initialized
DEBUG - 2018-08-14 11:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:26:09 --> CSRF cookie sent
INFO - 2018-08-14 11:26:09 --> CSRF token verified
INFO - 2018-08-14 11:26:09 --> Input Class Initialized
INFO - 2018-08-14 11:26:09 --> Language Class Initialized
INFO - 2018-08-14 11:26:09 --> Loader Class Initialized
INFO - 2018-08-14 11:26:09 --> Helper loaded: url_helper
INFO - 2018-08-14 11:26:09 --> Helper loaded: form_helper
INFO - 2018-08-14 11:26:09 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:26:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:26:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:26:09 --> User Agent Class Initialized
INFO - 2018-08-14 11:26:09 --> Controller Class Initialized
INFO - 2018-08-14 11:26:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:26:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:26:09 --> Pixel_Model class loaded
INFO - 2018-08-14 11:26:09 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:09 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:09 --> Form Validation Class Initialized
INFO - 2018-08-14 11:26:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 11:26:09 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:09 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:09 --> Config Class Initialized
INFO - 2018-08-14 11:26:09 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:26:09 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:26:09 --> Utf8 Class Initialized
INFO - 2018-08-14 11:26:09 --> URI Class Initialized
INFO - 2018-08-14 11:26:09 --> Router Class Initialized
INFO - 2018-08-14 11:26:09 --> Output Class Initialized
INFO - 2018-08-14 11:26:09 --> Security Class Initialized
DEBUG - 2018-08-14 11:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:26:09 --> CSRF cookie sent
INFO - 2018-08-14 11:26:09 --> Input Class Initialized
INFO - 2018-08-14 11:26:09 --> Language Class Initialized
INFO - 2018-08-14 11:26:09 --> Loader Class Initialized
INFO - 2018-08-14 11:26:09 --> Helper loaded: url_helper
INFO - 2018-08-14 11:26:09 --> Helper loaded: form_helper
INFO - 2018-08-14 11:26:09 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:26:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:26:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:26:09 --> User Agent Class Initialized
INFO - 2018-08-14 11:26:09 --> Controller Class Initialized
INFO - 2018-08-14 11:26:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:26:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:26:09 --> Pixel_Model class loaded
INFO - 2018-08-14 11:26:09 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:09 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:09 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:09 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:26:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-08-14 11:26:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:26:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 11:26:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 11:26:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 11:26:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 11:26:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/business_tax_info.php
INFO - 2018-08-14 11:26:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:26:09 --> Final output sent to browser
DEBUG - 2018-08-14 11:26:09 --> Total execution time: 0.0532
INFO - 2018-08-14 11:26:11 --> Config Class Initialized
INFO - 2018-08-14 11:26:11 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:26:11 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:26:11 --> Utf8 Class Initialized
INFO - 2018-08-14 11:26:11 --> URI Class Initialized
INFO - 2018-08-14 11:26:11 --> Router Class Initialized
INFO - 2018-08-14 11:26:11 --> Output Class Initialized
INFO - 2018-08-14 11:26:11 --> Security Class Initialized
DEBUG - 2018-08-14 11:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:26:11 --> CSRF cookie sent
INFO - 2018-08-14 11:26:11 --> CSRF token verified
INFO - 2018-08-14 11:26:11 --> Input Class Initialized
INFO - 2018-08-14 11:26:11 --> Language Class Initialized
INFO - 2018-08-14 11:26:11 --> Loader Class Initialized
INFO - 2018-08-14 11:26:11 --> Helper loaded: url_helper
INFO - 2018-08-14 11:26:11 --> Helper loaded: form_helper
INFO - 2018-08-14 11:26:11 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:26:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:26:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:26:11 --> User Agent Class Initialized
INFO - 2018-08-14 11:26:11 --> Controller Class Initialized
INFO - 2018-08-14 11:26:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:26:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:26:11 --> Pixel_Model class loaded
INFO - 2018-08-14 11:26:11 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:11 --> Form Validation Class Initialized
INFO - 2018-08-14 11:26:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 11:26:11 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:11 --> Config Class Initialized
INFO - 2018-08-14 11:26:11 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:26:11 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:26:11 --> Utf8 Class Initialized
INFO - 2018-08-14 11:26:11 --> URI Class Initialized
INFO - 2018-08-14 11:26:11 --> Router Class Initialized
INFO - 2018-08-14 11:26:11 --> Output Class Initialized
INFO - 2018-08-14 11:26:11 --> Security Class Initialized
DEBUG - 2018-08-14 11:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:26:11 --> CSRF cookie sent
INFO - 2018-08-14 11:26:11 --> Input Class Initialized
INFO - 2018-08-14 11:26:11 --> Language Class Initialized
INFO - 2018-08-14 11:26:11 --> Loader Class Initialized
INFO - 2018-08-14 11:26:11 --> Helper loaded: url_helper
INFO - 2018-08-14 11:26:11 --> Helper loaded: form_helper
INFO - 2018-08-14 11:26:11 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:26:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:26:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:26:11 --> User Agent Class Initialized
INFO - 2018-08-14 11:26:11 --> Controller Class Initialized
INFO - 2018-08-14 11:26:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:26:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:26:11 --> Pixel_Model class loaded
INFO - 2018-08-14 11:26:11 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:11 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:26:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-08-14 11:26:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:26:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 11:26:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 11:26:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 11:26:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 11:26:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/trust_info.php
INFO - 2018-08-14 11:26:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:26:11 --> Final output sent to browser
DEBUG - 2018-08-14 11:26:11 --> Total execution time: 0.0470
INFO - 2018-08-14 11:26:22 --> Config Class Initialized
INFO - 2018-08-14 11:26:22 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:26:22 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:26:22 --> Utf8 Class Initialized
INFO - 2018-08-14 11:26:22 --> URI Class Initialized
INFO - 2018-08-14 11:26:22 --> Router Class Initialized
INFO - 2018-08-14 11:26:22 --> Output Class Initialized
INFO - 2018-08-14 11:26:22 --> Security Class Initialized
DEBUG - 2018-08-14 11:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:26:22 --> CSRF cookie sent
INFO - 2018-08-14 11:26:22 --> CSRF token verified
INFO - 2018-08-14 11:26:22 --> Input Class Initialized
INFO - 2018-08-14 11:26:22 --> Language Class Initialized
INFO - 2018-08-14 11:26:22 --> Loader Class Initialized
INFO - 2018-08-14 11:26:22 --> Helper loaded: url_helper
INFO - 2018-08-14 11:26:22 --> Helper loaded: form_helper
INFO - 2018-08-14 11:26:22 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:26:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:26:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:26:22 --> User Agent Class Initialized
INFO - 2018-08-14 11:26:22 --> Controller Class Initialized
INFO - 2018-08-14 11:26:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:26:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:26:22 --> Pixel_Model class loaded
INFO - 2018-08-14 11:26:22 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:22 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:22 --> Form Validation Class Initialized
INFO - 2018-08-14 11:26:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 11:26:22 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:22 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:22 --> Config Class Initialized
INFO - 2018-08-14 11:26:22 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:26:22 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:26:22 --> Utf8 Class Initialized
INFO - 2018-08-14 11:26:22 --> URI Class Initialized
INFO - 2018-08-14 11:26:22 --> Router Class Initialized
INFO - 2018-08-14 11:26:22 --> Output Class Initialized
INFO - 2018-08-14 11:26:22 --> Security Class Initialized
DEBUG - 2018-08-14 11:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:26:22 --> CSRF cookie sent
INFO - 2018-08-14 11:26:22 --> Input Class Initialized
INFO - 2018-08-14 11:26:22 --> Language Class Initialized
INFO - 2018-08-14 11:26:22 --> Loader Class Initialized
INFO - 2018-08-14 11:26:22 --> Helper loaded: url_helper
INFO - 2018-08-14 11:26:22 --> Helper loaded: form_helper
INFO - 2018-08-14 11:26:22 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:26:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:26:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:26:22 --> User Agent Class Initialized
INFO - 2018-08-14 11:26:22 --> Controller Class Initialized
INFO - 2018-08-14 11:26:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:26:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:26:22 --> Pixel_Model class loaded
INFO - 2018-08-14 11:26:22 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:22 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:22 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:22 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:26:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-08-14 11:26:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:26:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 11:26:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 11:26:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 11:26:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 11:26:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inherited_income.php
INFO - 2018-08-14 11:26:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:26:23 --> Final output sent to browser
DEBUG - 2018-08-14 11:26:23 --> Total execution time: 0.0614
INFO - 2018-08-14 11:26:26 --> Config Class Initialized
INFO - 2018-08-14 11:26:26 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:26:26 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:26:26 --> Utf8 Class Initialized
INFO - 2018-08-14 11:26:26 --> URI Class Initialized
INFO - 2018-08-14 11:26:26 --> Router Class Initialized
INFO - 2018-08-14 11:26:26 --> Output Class Initialized
INFO - 2018-08-14 11:26:26 --> Security Class Initialized
DEBUG - 2018-08-14 11:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:26:26 --> CSRF cookie sent
INFO - 2018-08-14 11:26:26 --> CSRF token verified
INFO - 2018-08-14 11:26:26 --> Input Class Initialized
INFO - 2018-08-14 11:26:26 --> Language Class Initialized
INFO - 2018-08-14 11:26:26 --> Loader Class Initialized
INFO - 2018-08-14 11:26:26 --> Helper loaded: url_helper
INFO - 2018-08-14 11:26:26 --> Helper loaded: form_helper
INFO - 2018-08-14 11:26:26 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:26:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:26:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:26:26 --> User Agent Class Initialized
INFO - 2018-08-14 11:26:26 --> Controller Class Initialized
INFO - 2018-08-14 11:26:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:26:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:26:26 --> Pixel_Model class loaded
INFO - 2018-08-14 11:26:26 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:26 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:26 --> Form Validation Class Initialized
INFO - 2018-08-14 11:26:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 11:26:26 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:26 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:26 --> Config Class Initialized
INFO - 2018-08-14 11:26:26 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:26:26 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:26:26 --> Utf8 Class Initialized
INFO - 2018-08-14 11:26:26 --> URI Class Initialized
INFO - 2018-08-14 11:26:26 --> Router Class Initialized
INFO - 2018-08-14 11:26:26 --> Output Class Initialized
INFO - 2018-08-14 11:26:26 --> Security Class Initialized
DEBUG - 2018-08-14 11:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:26:26 --> CSRF cookie sent
INFO - 2018-08-14 11:26:26 --> Input Class Initialized
INFO - 2018-08-14 11:26:26 --> Language Class Initialized
INFO - 2018-08-14 11:26:26 --> Loader Class Initialized
INFO - 2018-08-14 11:26:26 --> Helper loaded: url_helper
INFO - 2018-08-14 11:26:26 --> Helper loaded: form_helper
INFO - 2018-08-14 11:26:26 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:26:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:26:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:26:26 --> User Agent Class Initialized
INFO - 2018-08-14 11:26:26 --> Controller Class Initialized
INFO - 2018-08-14 11:26:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:26:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:26:26 --> Pixel_Model class loaded
INFO - 2018-08-14 11:26:26 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:26 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:26 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:26 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:26:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-08-14 11:26:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:26:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 11:26:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 11:26:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 11:26:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 11:26:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/shift_work.php
INFO - 2018-08-14 11:26:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:26:26 --> Final output sent to browser
DEBUG - 2018-08-14 11:26:26 --> Total execution time: 0.0488
INFO - 2018-08-14 11:26:28 --> Config Class Initialized
INFO - 2018-08-14 11:26:28 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:26:28 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:26:28 --> Utf8 Class Initialized
INFO - 2018-08-14 11:26:28 --> URI Class Initialized
INFO - 2018-08-14 11:26:28 --> Router Class Initialized
INFO - 2018-08-14 11:26:28 --> Output Class Initialized
INFO - 2018-08-14 11:26:28 --> Security Class Initialized
DEBUG - 2018-08-14 11:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:26:28 --> CSRF cookie sent
INFO - 2018-08-14 11:26:28 --> CSRF token verified
INFO - 2018-08-14 11:26:28 --> Input Class Initialized
INFO - 2018-08-14 11:26:28 --> Language Class Initialized
INFO - 2018-08-14 11:26:28 --> Loader Class Initialized
INFO - 2018-08-14 11:26:28 --> Helper loaded: url_helper
INFO - 2018-08-14 11:26:28 --> Helper loaded: form_helper
INFO - 2018-08-14 11:26:28 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:26:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:26:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:26:28 --> User Agent Class Initialized
INFO - 2018-08-14 11:26:28 --> Controller Class Initialized
INFO - 2018-08-14 11:26:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:26:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:26:28 --> Pixel_Model class loaded
INFO - 2018-08-14 11:26:28 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:28 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:28 --> Form Validation Class Initialized
INFO - 2018-08-14 11:26:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 11:26:28 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:28 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:28 --> Config Class Initialized
INFO - 2018-08-14 11:26:28 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:26:28 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:26:28 --> Utf8 Class Initialized
INFO - 2018-08-14 11:26:28 --> URI Class Initialized
INFO - 2018-08-14 11:26:28 --> Router Class Initialized
INFO - 2018-08-14 11:26:28 --> Output Class Initialized
INFO - 2018-08-14 11:26:28 --> Security Class Initialized
DEBUG - 2018-08-14 11:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:26:28 --> CSRF cookie sent
INFO - 2018-08-14 11:26:28 --> Input Class Initialized
INFO - 2018-08-14 11:26:28 --> Language Class Initialized
INFO - 2018-08-14 11:26:28 --> Loader Class Initialized
INFO - 2018-08-14 11:26:28 --> Helper loaded: url_helper
INFO - 2018-08-14 11:26:28 --> Helper loaded: form_helper
INFO - 2018-08-14 11:26:28 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:26:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:26:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:26:28 --> User Agent Class Initialized
INFO - 2018-08-14 11:26:28 --> Controller Class Initialized
INFO - 2018-08-14 11:26:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:26:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:26:28 --> Pixel_Model class loaded
INFO - 2018-08-14 11:26:28 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:28 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:28 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:28 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:26:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-08-14 11:26:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:26:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 11:26:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 11:26:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 11:26:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 11:26:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/night_without_s.php
INFO - 2018-08-14 11:26:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:26:28 --> Final output sent to browser
DEBUG - 2018-08-14 11:26:28 --> Total execution time: 0.0481
INFO - 2018-08-14 11:26:30 --> Config Class Initialized
INFO - 2018-08-14 11:26:30 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:26:30 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:26:30 --> Utf8 Class Initialized
INFO - 2018-08-14 11:26:30 --> URI Class Initialized
INFO - 2018-08-14 11:26:30 --> Router Class Initialized
INFO - 2018-08-14 11:26:30 --> Output Class Initialized
INFO - 2018-08-14 11:26:30 --> Security Class Initialized
DEBUG - 2018-08-14 11:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:26:30 --> CSRF cookie sent
INFO - 2018-08-14 11:26:30 --> CSRF token verified
INFO - 2018-08-14 11:26:30 --> Input Class Initialized
INFO - 2018-08-14 11:26:30 --> Language Class Initialized
INFO - 2018-08-14 11:26:30 --> Loader Class Initialized
INFO - 2018-08-14 11:26:30 --> Helper loaded: url_helper
INFO - 2018-08-14 11:26:30 --> Helper loaded: form_helper
INFO - 2018-08-14 11:26:30 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:26:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:26:30 --> User Agent Class Initialized
INFO - 2018-08-14 11:26:30 --> Controller Class Initialized
INFO - 2018-08-14 11:26:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:26:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:26:30 --> Pixel_Model class loaded
INFO - 2018-08-14 11:26:30 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:30 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:30 --> Form Validation Class Initialized
INFO - 2018-08-14 11:26:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 11:26:30 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:30 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:30 --> Config Class Initialized
INFO - 2018-08-14 11:26:30 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:26:30 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:26:30 --> Utf8 Class Initialized
INFO - 2018-08-14 11:26:30 --> URI Class Initialized
INFO - 2018-08-14 11:26:30 --> Router Class Initialized
INFO - 2018-08-14 11:26:30 --> Output Class Initialized
INFO - 2018-08-14 11:26:30 --> Security Class Initialized
DEBUG - 2018-08-14 11:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:26:30 --> CSRF cookie sent
INFO - 2018-08-14 11:26:30 --> Input Class Initialized
INFO - 2018-08-14 11:26:30 --> Language Class Initialized
INFO - 2018-08-14 11:26:30 --> Loader Class Initialized
INFO - 2018-08-14 11:26:30 --> Helper loaded: url_helper
INFO - 2018-08-14 11:26:30 --> Helper loaded: form_helper
INFO - 2018-08-14 11:26:30 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:26:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:26:30 --> User Agent Class Initialized
INFO - 2018-08-14 11:26:30 --> Controller Class Initialized
INFO - 2018-08-14 11:26:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:26:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:26:30 --> Pixel_Model class loaded
INFO - 2018-08-14 11:26:30 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:30 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:30 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:30 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:26:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-08-14 11:26:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:26:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 11:26:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 11:26:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 11:26:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 11:26:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/have_date.php
INFO - 2018-08-14 11:26:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:26:30 --> Final output sent to browser
DEBUG - 2018-08-14 11:26:30 --> Total execution time: 0.0457
INFO - 2018-08-14 11:26:34 --> Config Class Initialized
INFO - 2018-08-14 11:26:34 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:26:34 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:26:34 --> Utf8 Class Initialized
INFO - 2018-08-14 11:26:34 --> URI Class Initialized
INFO - 2018-08-14 11:26:34 --> Router Class Initialized
INFO - 2018-08-14 11:26:34 --> Output Class Initialized
INFO - 2018-08-14 11:26:34 --> Security Class Initialized
DEBUG - 2018-08-14 11:26:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:26:34 --> CSRF cookie sent
INFO - 2018-08-14 11:26:34 --> CSRF token verified
INFO - 2018-08-14 11:26:34 --> Input Class Initialized
INFO - 2018-08-14 11:26:34 --> Language Class Initialized
INFO - 2018-08-14 11:26:34 --> Loader Class Initialized
INFO - 2018-08-14 11:26:34 --> Helper loaded: url_helper
INFO - 2018-08-14 11:26:34 --> Helper loaded: form_helper
INFO - 2018-08-14 11:26:34 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:26:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:26:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:26:34 --> User Agent Class Initialized
INFO - 2018-08-14 11:26:34 --> Controller Class Initialized
INFO - 2018-08-14 11:26:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:26:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:26:34 --> Pixel_Model class loaded
INFO - 2018-08-14 11:26:34 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:34 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:34 --> Form Validation Class Initialized
INFO - 2018-08-14 11:26:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 11:26:34 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:34 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:34 --> Config Class Initialized
INFO - 2018-08-14 11:26:34 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:26:34 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:26:34 --> Utf8 Class Initialized
INFO - 2018-08-14 11:26:34 --> URI Class Initialized
INFO - 2018-08-14 11:26:34 --> Router Class Initialized
INFO - 2018-08-14 11:26:34 --> Output Class Initialized
INFO - 2018-08-14 11:26:34 --> Security Class Initialized
DEBUG - 2018-08-14 11:26:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:26:34 --> CSRF cookie sent
INFO - 2018-08-14 11:26:34 --> Input Class Initialized
INFO - 2018-08-14 11:26:34 --> Language Class Initialized
INFO - 2018-08-14 11:26:34 --> Loader Class Initialized
INFO - 2018-08-14 11:26:34 --> Helper loaded: url_helper
INFO - 2018-08-14 11:26:34 --> Helper loaded: form_helper
INFO - 2018-08-14 11:26:34 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:26:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:26:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:26:34 --> User Agent Class Initialized
INFO - 2018-08-14 11:26:34 --> Controller Class Initialized
INFO - 2018-08-14 11:26:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:26:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:26:34 --> Pixel_Model class loaded
INFO - 2018-08-14 11:26:34 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:34 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:34 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:34 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:26:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-08-14 11:26:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:26:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 11:26:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 11:26:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 11:26:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 11:26:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/nights_not_home.php
INFO - 2018-08-14 11:26:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:26:34 --> Final output sent to browser
DEBUG - 2018-08-14 11:26:34 --> Total execution time: 0.0427
INFO - 2018-08-14 11:26:35 --> Config Class Initialized
INFO - 2018-08-14 11:26:35 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:26:35 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:26:35 --> Utf8 Class Initialized
INFO - 2018-08-14 11:26:35 --> URI Class Initialized
INFO - 2018-08-14 11:26:36 --> Router Class Initialized
INFO - 2018-08-14 11:26:36 --> Output Class Initialized
INFO - 2018-08-14 11:26:36 --> Security Class Initialized
DEBUG - 2018-08-14 11:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:26:36 --> CSRF cookie sent
INFO - 2018-08-14 11:26:36 --> CSRF token verified
INFO - 2018-08-14 11:26:36 --> Input Class Initialized
INFO - 2018-08-14 11:26:36 --> Language Class Initialized
INFO - 2018-08-14 11:26:36 --> Loader Class Initialized
INFO - 2018-08-14 11:26:36 --> Helper loaded: url_helper
INFO - 2018-08-14 11:26:36 --> Helper loaded: form_helper
INFO - 2018-08-14 11:26:36 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:26:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:26:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:26:36 --> User Agent Class Initialized
INFO - 2018-08-14 11:26:36 --> Controller Class Initialized
INFO - 2018-08-14 11:26:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:26:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:26:36 --> Pixel_Model class loaded
INFO - 2018-08-14 11:26:36 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:36 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:36 --> Form Validation Class Initialized
INFO - 2018-08-14 11:26:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 11:26:36 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:36 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:36 --> Config Class Initialized
INFO - 2018-08-14 11:26:36 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:26:36 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:26:36 --> Utf8 Class Initialized
INFO - 2018-08-14 11:26:36 --> URI Class Initialized
INFO - 2018-08-14 11:26:36 --> Router Class Initialized
INFO - 2018-08-14 11:26:36 --> Output Class Initialized
INFO - 2018-08-14 11:26:36 --> Security Class Initialized
DEBUG - 2018-08-14 11:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:26:36 --> CSRF cookie sent
INFO - 2018-08-14 11:26:36 --> Input Class Initialized
INFO - 2018-08-14 11:26:36 --> Language Class Initialized
INFO - 2018-08-14 11:26:36 --> Loader Class Initialized
INFO - 2018-08-14 11:26:36 --> Helper loaded: url_helper
INFO - 2018-08-14 11:26:36 --> Helper loaded: form_helper
INFO - 2018-08-14 11:26:36 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:26:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:26:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:26:36 --> User Agent Class Initialized
INFO - 2018-08-14 11:26:36 --> Controller Class Initialized
INFO - 2018-08-14 11:26:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:26:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:26:36 --> Pixel_Model class loaded
INFO - 2018-08-14 11:26:36 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:36 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:36 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:36 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:26:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-08-14 11:26:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:26:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 11:26:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 11:26:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 11:26:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 11:26:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/s_nights_not_home.php
INFO - 2018-08-14 11:26:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:26:36 --> Final output sent to browser
DEBUG - 2018-08-14 11:26:36 --> Total execution time: 0.0550
INFO - 2018-08-14 11:26:37 --> Config Class Initialized
INFO - 2018-08-14 11:26:37 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:26:37 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:26:37 --> Utf8 Class Initialized
INFO - 2018-08-14 11:26:37 --> URI Class Initialized
INFO - 2018-08-14 11:26:37 --> Router Class Initialized
INFO - 2018-08-14 11:26:37 --> Output Class Initialized
INFO - 2018-08-14 11:26:37 --> Security Class Initialized
DEBUG - 2018-08-14 11:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:26:37 --> CSRF cookie sent
INFO - 2018-08-14 11:26:37 --> CSRF token verified
INFO - 2018-08-14 11:26:37 --> Input Class Initialized
INFO - 2018-08-14 11:26:37 --> Language Class Initialized
INFO - 2018-08-14 11:26:37 --> Loader Class Initialized
INFO - 2018-08-14 11:26:37 --> Helper loaded: url_helper
INFO - 2018-08-14 11:26:37 --> Helper loaded: form_helper
INFO - 2018-08-14 11:26:37 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:26:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:26:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:26:37 --> User Agent Class Initialized
INFO - 2018-08-14 11:26:37 --> Controller Class Initialized
INFO - 2018-08-14 11:26:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:26:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:26:37 --> Pixel_Model class loaded
INFO - 2018-08-14 11:26:37 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:37 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:37 --> Form Validation Class Initialized
INFO - 2018-08-14 11:26:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 11:26:37 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:37 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:37 --> Config Class Initialized
INFO - 2018-08-14 11:26:37 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:26:37 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:26:37 --> Utf8 Class Initialized
INFO - 2018-08-14 11:26:37 --> URI Class Initialized
INFO - 2018-08-14 11:26:37 --> Router Class Initialized
INFO - 2018-08-14 11:26:37 --> Output Class Initialized
INFO - 2018-08-14 11:26:37 --> Security Class Initialized
DEBUG - 2018-08-14 11:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:26:37 --> CSRF cookie sent
INFO - 2018-08-14 11:26:37 --> Input Class Initialized
INFO - 2018-08-14 11:26:37 --> Language Class Initialized
INFO - 2018-08-14 11:26:37 --> Loader Class Initialized
INFO - 2018-08-14 11:26:37 --> Helper loaded: url_helper
INFO - 2018-08-14 11:26:37 --> Helper loaded: form_helper
INFO - 2018-08-14 11:26:37 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:26:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:26:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:26:37 --> User Agent Class Initialized
INFO - 2018-08-14 11:26:37 --> Controller Class Initialized
INFO - 2018-08-14 11:26:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:26:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:26:37 --> Pixel_Model class loaded
INFO - 2018-08-14 11:26:37 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:37 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:37 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:37 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:26:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-08-14 11:26:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:26:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 11:26:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 11:26:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 11:26:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 11:26:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/s_nights_without_you.php
INFO - 2018-08-14 11:26:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:26:37 --> Final output sent to browser
DEBUG - 2018-08-14 11:26:37 --> Total execution time: 0.0443
INFO - 2018-08-14 11:26:39 --> Config Class Initialized
INFO - 2018-08-14 11:26:39 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:26:39 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:26:39 --> Utf8 Class Initialized
INFO - 2018-08-14 11:26:39 --> URI Class Initialized
INFO - 2018-08-14 11:26:39 --> Router Class Initialized
INFO - 2018-08-14 11:26:39 --> Output Class Initialized
INFO - 2018-08-14 11:26:39 --> Security Class Initialized
DEBUG - 2018-08-14 11:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:26:39 --> CSRF cookie sent
INFO - 2018-08-14 11:26:39 --> CSRF token verified
INFO - 2018-08-14 11:26:39 --> Input Class Initialized
INFO - 2018-08-14 11:26:39 --> Language Class Initialized
INFO - 2018-08-14 11:26:39 --> Loader Class Initialized
INFO - 2018-08-14 11:26:39 --> Helper loaded: url_helper
INFO - 2018-08-14 11:26:39 --> Helper loaded: form_helper
INFO - 2018-08-14 11:26:39 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:26:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:26:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:26:39 --> User Agent Class Initialized
INFO - 2018-08-14 11:26:39 --> Controller Class Initialized
INFO - 2018-08-14 11:26:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:26:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:26:39 --> Pixel_Model class loaded
INFO - 2018-08-14 11:26:39 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:39 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:39 --> Form Validation Class Initialized
INFO - 2018-08-14 11:26:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 11:26:39 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:39 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:39 --> Config Class Initialized
INFO - 2018-08-14 11:26:39 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:26:39 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:26:39 --> Utf8 Class Initialized
INFO - 2018-08-14 11:26:39 --> URI Class Initialized
INFO - 2018-08-14 11:26:39 --> Router Class Initialized
INFO - 2018-08-14 11:26:39 --> Output Class Initialized
INFO - 2018-08-14 11:26:39 --> Security Class Initialized
DEBUG - 2018-08-14 11:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:26:39 --> CSRF cookie sent
INFO - 2018-08-14 11:26:39 --> Input Class Initialized
INFO - 2018-08-14 11:26:39 --> Language Class Initialized
INFO - 2018-08-14 11:26:39 --> Loader Class Initialized
INFO - 2018-08-14 11:26:39 --> Helper loaded: url_helper
INFO - 2018-08-14 11:26:39 --> Helper loaded: form_helper
INFO - 2018-08-14 11:26:39 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:26:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:26:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:26:39 --> User Agent Class Initialized
INFO - 2018-08-14 11:26:39 --> Controller Class Initialized
INFO - 2018-08-14 11:26:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:26:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:26:39 --> Pixel_Model class loaded
INFO - 2018-08-14 11:26:39 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:39 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:39 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:39 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:26:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-08-14 11:26:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:26:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 11:26:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 11:26:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 11:26:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 11:26:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/alcoholic_drinks_per_week.php
INFO - 2018-08-14 11:26:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:26:39 --> Final output sent to browser
DEBUG - 2018-08-14 11:26:39 --> Total execution time: 0.0479
INFO - 2018-08-14 11:26:40 --> Config Class Initialized
INFO - 2018-08-14 11:26:40 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:26:40 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:26:40 --> Utf8 Class Initialized
INFO - 2018-08-14 11:26:40 --> URI Class Initialized
INFO - 2018-08-14 11:26:40 --> Router Class Initialized
INFO - 2018-08-14 11:26:40 --> Output Class Initialized
INFO - 2018-08-14 11:26:40 --> Security Class Initialized
DEBUG - 2018-08-14 11:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:26:40 --> CSRF cookie sent
INFO - 2018-08-14 11:26:40 --> CSRF token verified
INFO - 2018-08-14 11:26:40 --> Input Class Initialized
INFO - 2018-08-14 11:26:40 --> Language Class Initialized
INFO - 2018-08-14 11:26:40 --> Loader Class Initialized
INFO - 2018-08-14 11:26:40 --> Helper loaded: url_helper
INFO - 2018-08-14 11:26:40 --> Helper loaded: form_helper
INFO - 2018-08-14 11:26:40 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:26:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:26:40 --> User Agent Class Initialized
INFO - 2018-08-14 11:26:40 --> Controller Class Initialized
INFO - 2018-08-14 11:26:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:26:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:26:40 --> Pixel_Model class loaded
INFO - 2018-08-14 11:26:40 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:40 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:40 --> Form Validation Class Initialized
INFO - 2018-08-14 11:26:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 11:26:40 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:40 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:40 --> Config Class Initialized
INFO - 2018-08-14 11:26:40 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:26:40 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:26:40 --> Utf8 Class Initialized
INFO - 2018-08-14 11:26:40 --> URI Class Initialized
INFO - 2018-08-14 11:26:40 --> Router Class Initialized
INFO - 2018-08-14 11:26:40 --> Output Class Initialized
INFO - 2018-08-14 11:26:40 --> Security Class Initialized
DEBUG - 2018-08-14 11:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:26:40 --> CSRF cookie sent
INFO - 2018-08-14 11:26:40 --> Input Class Initialized
INFO - 2018-08-14 11:26:40 --> Language Class Initialized
INFO - 2018-08-14 11:26:40 --> Loader Class Initialized
INFO - 2018-08-14 11:26:40 --> Helper loaded: url_helper
INFO - 2018-08-14 11:26:40 --> Helper loaded: form_helper
INFO - 2018-08-14 11:26:40 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:26:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:26:40 --> User Agent Class Initialized
INFO - 2018-08-14 11:26:40 --> Controller Class Initialized
INFO - 2018-08-14 11:26:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:26:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:26:40 --> Pixel_Model class loaded
INFO - 2018-08-14 11:26:40 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:40 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:40 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:40 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:26:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-08-14 11:26:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:26:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 11:26:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 11:26:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 11:26:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 11:26:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/have_drugs.php
INFO - 2018-08-14 11:26:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:26:40 --> Final output sent to browser
DEBUG - 2018-08-14 11:26:40 --> Total execution time: 0.0422
INFO - 2018-08-14 11:26:41 --> Config Class Initialized
INFO - 2018-08-14 11:26:41 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:26:41 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:26:41 --> Utf8 Class Initialized
INFO - 2018-08-14 11:26:41 --> URI Class Initialized
INFO - 2018-08-14 11:26:41 --> Router Class Initialized
INFO - 2018-08-14 11:26:41 --> Output Class Initialized
INFO - 2018-08-14 11:26:41 --> Security Class Initialized
DEBUG - 2018-08-14 11:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:26:41 --> CSRF cookie sent
INFO - 2018-08-14 11:26:41 --> CSRF token verified
INFO - 2018-08-14 11:26:41 --> Input Class Initialized
INFO - 2018-08-14 11:26:41 --> Language Class Initialized
INFO - 2018-08-14 11:26:41 --> Loader Class Initialized
INFO - 2018-08-14 11:26:41 --> Helper loaded: url_helper
INFO - 2018-08-14 11:26:41 --> Helper loaded: form_helper
INFO - 2018-08-14 11:26:41 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:26:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:26:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:26:41 --> User Agent Class Initialized
INFO - 2018-08-14 11:26:41 --> Controller Class Initialized
INFO - 2018-08-14 11:26:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:26:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:26:41 --> Pixel_Model class loaded
INFO - 2018-08-14 11:26:41 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:41 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:41 --> Form Validation Class Initialized
INFO - 2018-08-14 11:26:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 11:26:41 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:41 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:41 --> Config Class Initialized
INFO - 2018-08-14 11:26:41 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:26:41 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:26:41 --> Utf8 Class Initialized
INFO - 2018-08-14 11:26:41 --> URI Class Initialized
INFO - 2018-08-14 11:26:41 --> Router Class Initialized
INFO - 2018-08-14 11:26:41 --> Output Class Initialized
INFO - 2018-08-14 11:26:41 --> Security Class Initialized
DEBUG - 2018-08-14 11:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:26:41 --> CSRF cookie sent
INFO - 2018-08-14 11:26:41 --> Input Class Initialized
INFO - 2018-08-14 11:26:41 --> Language Class Initialized
INFO - 2018-08-14 11:26:41 --> Loader Class Initialized
INFO - 2018-08-14 11:26:41 --> Helper loaded: url_helper
INFO - 2018-08-14 11:26:41 --> Helper loaded: form_helper
INFO - 2018-08-14 11:26:41 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:26:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:26:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:26:41 --> User Agent Class Initialized
INFO - 2018-08-14 11:26:41 --> Controller Class Initialized
INFO - 2018-08-14 11:26:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:26:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:26:41 --> Pixel_Model class loaded
INFO - 2018-08-14 11:26:41 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:41 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:41 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:41 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:26:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-08-14 11:26:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:26:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 11:26:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 11:26:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 11:26:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 11:26:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/has_addiction_problem.php
INFO - 2018-08-14 11:26:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:26:41 --> Final output sent to browser
DEBUG - 2018-08-14 11:26:41 --> Total execution time: 0.0455
INFO - 2018-08-14 11:26:42 --> Config Class Initialized
INFO - 2018-08-14 11:26:42 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:26:42 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:26:42 --> Utf8 Class Initialized
INFO - 2018-08-14 11:26:42 --> URI Class Initialized
INFO - 2018-08-14 11:26:42 --> Router Class Initialized
INFO - 2018-08-14 11:26:42 --> Output Class Initialized
INFO - 2018-08-14 11:26:42 --> Security Class Initialized
DEBUG - 2018-08-14 11:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:26:42 --> CSRF cookie sent
INFO - 2018-08-14 11:26:42 --> CSRF token verified
INFO - 2018-08-14 11:26:42 --> Input Class Initialized
INFO - 2018-08-14 11:26:42 --> Language Class Initialized
INFO - 2018-08-14 11:26:42 --> Loader Class Initialized
INFO - 2018-08-14 11:26:42 --> Helper loaded: url_helper
INFO - 2018-08-14 11:26:42 --> Helper loaded: form_helper
INFO - 2018-08-14 11:26:42 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:26:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:26:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:26:42 --> User Agent Class Initialized
INFO - 2018-08-14 11:26:42 --> Controller Class Initialized
INFO - 2018-08-14 11:26:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:26:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:26:42 --> Pixel_Model class loaded
INFO - 2018-08-14 11:26:42 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:42 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:42 --> Form Validation Class Initialized
INFO - 2018-08-14 11:26:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 11:26:42 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:42 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:42 --> Config Class Initialized
INFO - 2018-08-14 11:26:42 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:26:42 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:26:42 --> Utf8 Class Initialized
INFO - 2018-08-14 11:26:42 --> URI Class Initialized
INFO - 2018-08-14 11:26:42 --> Router Class Initialized
INFO - 2018-08-14 11:26:42 --> Output Class Initialized
INFO - 2018-08-14 11:26:42 --> Security Class Initialized
DEBUG - 2018-08-14 11:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:26:42 --> CSRF cookie sent
INFO - 2018-08-14 11:26:42 --> Input Class Initialized
INFO - 2018-08-14 11:26:42 --> Language Class Initialized
INFO - 2018-08-14 11:26:42 --> Loader Class Initialized
INFO - 2018-08-14 11:26:42 --> Helper loaded: url_helper
INFO - 2018-08-14 11:26:42 --> Helper loaded: form_helper
INFO - 2018-08-14 11:26:42 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:26:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:26:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:26:42 --> User Agent Class Initialized
INFO - 2018-08-14 11:26:42 --> Controller Class Initialized
INFO - 2018-08-14 11:26:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:26:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:26:42 --> Pixel_Model class loaded
INFO - 2018-08-14 11:26:42 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:42 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:42 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:42 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:26:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-08-14 11:26:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:26:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 11:26:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 11:26:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 11:26:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 11:26:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/have_hit_s.php
INFO - 2018-08-14 11:26:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:26:42 --> Final output sent to browser
DEBUG - 2018-08-14 11:26:42 --> Total execution time: 0.0432
INFO - 2018-08-14 11:26:44 --> Config Class Initialized
INFO - 2018-08-14 11:26:44 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:26:44 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:26:44 --> Utf8 Class Initialized
INFO - 2018-08-14 11:26:44 --> URI Class Initialized
INFO - 2018-08-14 11:26:44 --> Router Class Initialized
INFO - 2018-08-14 11:26:44 --> Output Class Initialized
INFO - 2018-08-14 11:26:44 --> Security Class Initialized
DEBUG - 2018-08-14 11:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:26:44 --> CSRF cookie sent
INFO - 2018-08-14 11:26:44 --> CSRF token verified
INFO - 2018-08-14 11:26:44 --> Input Class Initialized
INFO - 2018-08-14 11:26:44 --> Language Class Initialized
INFO - 2018-08-14 11:26:44 --> Loader Class Initialized
INFO - 2018-08-14 11:26:44 --> Helper loaded: url_helper
INFO - 2018-08-14 11:26:44 --> Helper loaded: form_helper
INFO - 2018-08-14 11:26:44 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:26:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:26:44 --> User Agent Class Initialized
INFO - 2018-08-14 11:26:44 --> Controller Class Initialized
INFO - 2018-08-14 11:26:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:26:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:26:44 --> Pixel_Model class loaded
INFO - 2018-08-14 11:26:44 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:44 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:44 --> Form Validation Class Initialized
INFO - 2018-08-14 11:26:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 11:26:44 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:44 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:44 --> Config Class Initialized
INFO - 2018-08-14 11:26:44 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:26:44 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:26:44 --> Utf8 Class Initialized
INFO - 2018-08-14 11:26:44 --> URI Class Initialized
INFO - 2018-08-14 11:26:44 --> Router Class Initialized
INFO - 2018-08-14 11:26:44 --> Output Class Initialized
INFO - 2018-08-14 11:26:44 --> Security Class Initialized
DEBUG - 2018-08-14 11:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:26:44 --> CSRF cookie sent
INFO - 2018-08-14 11:26:44 --> Input Class Initialized
INFO - 2018-08-14 11:26:44 --> Language Class Initialized
INFO - 2018-08-14 11:26:44 --> Loader Class Initialized
INFO - 2018-08-14 11:26:44 --> Helper loaded: url_helper
INFO - 2018-08-14 11:26:44 --> Helper loaded: form_helper
INFO - 2018-08-14 11:26:44 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:26:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:26:44 --> User Agent Class Initialized
INFO - 2018-08-14 11:26:44 --> Controller Class Initialized
INFO - 2018-08-14 11:26:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:26:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:26:44 --> Pixel_Model class loaded
INFO - 2018-08-14 11:26:44 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:44 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:44 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:44 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:26:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-08-14 11:26:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:26:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 11:26:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 11:26:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 11:26:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 11:26:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial_control.php
INFO - 2018-08-14 11:26:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:26:44 --> Final output sent to browser
DEBUG - 2018-08-14 11:26:44 --> Total execution time: 0.0441
INFO - 2018-08-14 11:26:45 --> Config Class Initialized
INFO - 2018-08-14 11:26:45 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:26:45 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:26:45 --> Utf8 Class Initialized
INFO - 2018-08-14 11:26:45 --> URI Class Initialized
INFO - 2018-08-14 11:26:45 --> Router Class Initialized
INFO - 2018-08-14 11:26:45 --> Output Class Initialized
INFO - 2018-08-14 11:26:45 --> Security Class Initialized
DEBUG - 2018-08-14 11:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:26:45 --> CSRF cookie sent
INFO - 2018-08-14 11:26:45 --> CSRF token verified
INFO - 2018-08-14 11:26:45 --> Input Class Initialized
INFO - 2018-08-14 11:26:45 --> Language Class Initialized
INFO - 2018-08-14 11:26:45 --> Loader Class Initialized
INFO - 2018-08-14 11:26:45 --> Helper loaded: url_helper
INFO - 2018-08-14 11:26:45 --> Helper loaded: form_helper
INFO - 2018-08-14 11:26:45 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:26:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:26:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:26:45 --> User Agent Class Initialized
INFO - 2018-08-14 11:26:45 --> Controller Class Initialized
INFO - 2018-08-14 11:26:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:26:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:26:45 --> Pixel_Model class loaded
INFO - 2018-08-14 11:26:45 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:45 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:45 --> Form Validation Class Initialized
INFO - 2018-08-14 11:26:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 11:26:45 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:45 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:45 --> Config Class Initialized
INFO - 2018-08-14 11:26:45 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:26:45 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:26:45 --> Utf8 Class Initialized
INFO - 2018-08-14 11:26:45 --> URI Class Initialized
INFO - 2018-08-14 11:26:45 --> Router Class Initialized
INFO - 2018-08-14 11:26:45 --> Output Class Initialized
INFO - 2018-08-14 11:26:45 --> Security Class Initialized
DEBUG - 2018-08-14 11:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:26:45 --> CSRF cookie sent
INFO - 2018-08-14 11:26:45 --> Input Class Initialized
INFO - 2018-08-14 11:26:45 --> Language Class Initialized
INFO - 2018-08-14 11:26:45 --> Loader Class Initialized
INFO - 2018-08-14 11:26:45 --> Helper loaded: url_helper
INFO - 2018-08-14 11:26:45 --> Helper loaded: form_helper
INFO - 2018-08-14 11:26:45 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:26:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:26:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:26:45 --> User Agent Class Initialized
INFO - 2018-08-14 11:26:45 --> Controller Class Initialized
INFO - 2018-08-14 11:26:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:26:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:26:45 --> Pixel_Model class loaded
INFO - 2018-08-14 11:26:45 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:45 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:45 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:45 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:26:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-08-14 11:26:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:26:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 11:26:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 11:26:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 11:26:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 11:26:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/has_hit_kids.php
INFO - 2018-08-14 11:26:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:26:45 --> Final output sent to browser
DEBUG - 2018-08-14 11:26:45 --> Total execution time: 0.0475
INFO - 2018-08-14 11:26:46 --> Config Class Initialized
INFO - 2018-08-14 11:26:46 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:26:46 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:26:46 --> Utf8 Class Initialized
INFO - 2018-08-14 11:26:46 --> URI Class Initialized
INFO - 2018-08-14 11:26:46 --> Router Class Initialized
INFO - 2018-08-14 11:26:46 --> Output Class Initialized
INFO - 2018-08-14 11:26:46 --> Security Class Initialized
DEBUG - 2018-08-14 11:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:26:46 --> CSRF cookie sent
INFO - 2018-08-14 11:26:46 --> CSRF token verified
INFO - 2018-08-14 11:26:46 --> Input Class Initialized
INFO - 2018-08-14 11:26:46 --> Language Class Initialized
INFO - 2018-08-14 11:26:46 --> Loader Class Initialized
INFO - 2018-08-14 11:26:46 --> Helper loaded: url_helper
INFO - 2018-08-14 11:26:46 --> Helper loaded: form_helper
INFO - 2018-08-14 11:26:46 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:26:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:26:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:26:46 --> User Agent Class Initialized
INFO - 2018-08-14 11:26:46 --> Controller Class Initialized
INFO - 2018-08-14 11:26:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:26:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:26:46 --> Pixel_Model class loaded
INFO - 2018-08-14 11:26:46 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:46 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:46 --> Form Validation Class Initialized
INFO - 2018-08-14 11:26:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 11:26:46 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:46 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:46 --> Config Class Initialized
INFO - 2018-08-14 11:26:46 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:26:46 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:26:46 --> Utf8 Class Initialized
INFO - 2018-08-14 11:26:46 --> URI Class Initialized
INFO - 2018-08-14 11:26:46 --> Router Class Initialized
INFO - 2018-08-14 11:26:46 --> Output Class Initialized
INFO - 2018-08-14 11:26:46 --> Security Class Initialized
DEBUG - 2018-08-14 11:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:26:46 --> CSRF cookie sent
INFO - 2018-08-14 11:26:46 --> Input Class Initialized
INFO - 2018-08-14 11:26:46 --> Language Class Initialized
INFO - 2018-08-14 11:26:46 --> Loader Class Initialized
INFO - 2018-08-14 11:26:46 --> Helper loaded: url_helper
INFO - 2018-08-14 11:26:46 --> Helper loaded: form_helper
INFO - 2018-08-14 11:26:46 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:26:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:26:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:26:46 --> User Agent Class Initialized
INFO - 2018-08-14 11:26:46 --> Controller Class Initialized
INFO - 2018-08-14 11:26:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:26:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:26:46 --> Pixel_Model class loaded
INFO - 2018-08-14 11:26:46 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:46 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:46 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:46 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:26:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-08-14 11:26:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:26:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 11:26:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 11:26:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 11:26:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 11:26:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/withheld_sex.php
INFO - 2018-08-14 11:26:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:26:46 --> Final output sent to browser
DEBUG - 2018-08-14 11:26:46 --> Total execution time: 0.0455
INFO - 2018-08-14 11:26:47 --> Config Class Initialized
INFO - 2018-08-14 11:26:47 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:26:47 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:26:47 --> Utf8 Class Initialized
INFO - 2018-08-14 11:26:47 --> URI Class Initialized
INFO - 2018-08-14 11:26:47 --> Router Class Initialized
INFO - 2018-08-14 11:26:47 --> Output Class Initialized
INFO - 2018-08-14 11:26:47 --> Security Class Initialized
DEBUG - 2018-08-14 11:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:26:47 --> CSRF cookie sent
INFO - 2018-08-14 11:26:47 --> CSRF token verified
INFO - 2018-08-14 11:26:47 --> Input Class Initialized
INFO - 2018-08-14 11:26:47 --> Language Class Initialized
INFO - 2018-08-14 11:26:47 --> Loader Class Initialized
INFO - 2018-08-14 11:26:47 --> Helper loaded: url_helper
INFO - 2018-08-14 11:26:47 --> Helper loaded: form_helper
INFO - 2018-08-14 11:26:47 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:26:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:26:47 --> User Agent Class Initialized
INFO - 2018-08-14 11:26:47 --> Controller Class Initialized
INFO - 2018-08-14 11:26:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:26:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:26:47 --> Pixel_Model class loaded
INFO - 2018-08-14 11:26:47 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:47 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:47 --> Form Validation Class Initialized
INFO - 2018-08-14 11:26:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 11:26:47 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:47 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:47 --> Config Class Initialized
INFO - 2018-08-14 11:26:47 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:26:47 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:26:47 --> Utf8 Class Initialized
INFO - 2018-08-14 11:26:47 --> URI Class Initialized
INFO - 2018-08-14 11:26:47 --> Router Class Initialized
INFO - 2018-08-14 11:26:47 --> Output Class Initialized
INFO - 2018-08-14 11:26:47 --> Security Class Initialized
DEBUG - 2018-08-14 11:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:26:47 --> CSRF cookie sent
INFO - 2018-08-14 11:26:47 --> Input Class Initialized
INFO - 2018-08-14 11:26:47 --> Language Class Initialized
INFO - 2018-08-14 11:26:47 --> Loader Class Initialized
INFO - 2018-08-14 11:26:47 --> Helper loaded: url_helper
INFO - 2018-08-14 11:26:47 --> Helper loaded: form_helper
INFO - 2018-08-14 11:26:47 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:26:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:26:47 --> User Agent Class Initialized
INFO - 2018-08-14 11:26:47 --> Controller Class Initialized
INFO - 2018-08-14 11:26:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:26:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:26:47 --> Pixel_Model class loaded
INFO - 2018-08-14 11:26:47 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:47 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:47 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:47 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:26:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-08-14 11:26:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:26:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 11:26:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 11:26:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 11:26:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 11:26:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pet_abuse.php
INFO - 2018-08-14 11:26:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:26:47 --> Final output sent to browser
DEBUG - 2018-08-14 11:26:47 --> Total execution time: 0.0527
INFO - 2018-08-14 11:26:48 --> Config Class Initialized
INFO - 2018-08-14 11:26:48 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:26:48 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:26:48 --> Utf8 Class Initialized
INFO - 2018-08-14 11:26:48 --> URI Class Initialized
INFO - 2018-08-14 11:26:48 --> Router Class Initialized
INFO - 2018-08-14 11:26:48 --> Output Class Initialized
INFO - 2018-08-14 11:26:48 --> Security Class Initialized
DEBUG - 2018-08-14 11:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:26:48 --> CSRF cookie sent
INFO - 2018-08-14 11:26:48 --> CSRF token verified
INFO - 2018-08-14 11:26:48 --> Input Class Initialized
INFO - 2018-08-14 11:26:48 --> Language Class Initialized
INFO - 2018-08-14 11:26:48 --> Loader Class Initialized
INFO - 2018-08-14 11:26:48 --> Helper loaded: url_helper
INFO - 2018-08-14 11:26:48 --> Helper loaded: form_helper
INFO - 2018-08-14 11:26:48 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:26:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:26:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:26:48 --> User Agent Class Initialized
INFO - 2018-08-14 11:26:48 --> Controller Class Initialized
INFO - 2018-08-14 11:26:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:26:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:26:48 --> Pixel_Model class loaded
INFO - 2018-08-14 11:26:48 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:48 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:48 --> Form Validation Class Initialized
INFO - 2018-08-14 11:26:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 11:26:48 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:48 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:48 --> Config Class Initialized
INFO - 2018-08-14 11:26:48 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:26:48 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:26:48 --> Utf8 Class Initialized
INFO - 2018-08-14 11:26:48 --> URI Class Initialized
INFO - 2018-08-14 11:26:48 --> Router Class Initialized
INFO - 2018-08-14 11:26:48 --> Output Class Initialized
INFO - 2018-08-14 11:26:48 --> Security Class Initialized
DEBUG - 2018-08-14 11:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:26:48 --> CSRF cookie sent
INFO - 2018-08-14 11:26:48 --> Input Class Initialized
INFO - 2018-08-14 11:26:48 --> Language Class Initialized
INFO - 2018-08-14 11:26:48 --> Loader Class Initialized
INFO - 2018-08-14 11:26:48 --> Helper loaded: url_helper
INFO - 2018-08-14 11:26:48 --> Helper loaded: form_helper
INFO - 2018-08-14 11:26:48 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:26:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:26:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:26:48 --> User Agent Class Initialized
INFO - 2018-08-14 11:26:48 --> Controller Class Initialized
INFO - 2018-08-14 11:26:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:26:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:26:48 --> Pixel_Model class loaded
INFO - 2018-08-14 11:26:49 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:49 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:49 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:49 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:26:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-08-14 11:26:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:26:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 11:26:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 11:26:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 11:26:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 11:26:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/has_dating_profile.php
INFO - 2018-08-14 11:26:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:26:49 --> Final output sent to browser
DEBUG - 2018-08-14 11:26:49 --> Total execution time: 0.0453
INFO - 2018-08-14 11:26:50 --> Config Class Initialized
INFO - 2018-08-14 11:26:50 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:26:50 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:26:50 --> Utf8 Class Initialized
INFO - 2018-08-14 11:26:50 --> URI Class Initialized
INFO - 2018-08-14 11:26:50 --> Router Class Initialized
INFO - 2018-08-14 11:26:50 --> Output Class Initialized
INFO - 2018-08-14 11:26:50 --> Security Class Initialized
DEBUG - 2018-08-14 11:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:26:50 --> CSRF cookie sent
INFO - 2018-08-14 11:26:50 --> CSRF token verified
INFO - 2018-08-14 11:26:50 --> Input Class Initialized
INFO - 2018-08-14 11:26:50 --> Language Class Initialized
INFO - 2018-08-14 11:26:50 --> Loader Class Initialized
INFO - 2018-08-14 11:26:50 --> Helper loaded: url_helper
INFO - 2018-08-14 11:26:50 --> Helper loaded: form_helper
INFO - 2018-08-14 11:26:50 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:26:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:26:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:26:50 --> User Agent Class Initialized
INFO - 2018-08-14 11:26:50 --> Controller Class Initialized
INFO - 2018-08-14 11:26:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:26:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:26:50 --> Pixel_Model class loaded
INFO - 2018-08-14 11:26:50 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:50 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:50 --> Form Validation Class Initialized
INFO - 2018-08-14 11:26:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 11:26:50 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:50 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:50 --> Config Class Initialized
INFO - 2018-08-14 11:26:50 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:26:50 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:26:50 --> Utf8 Class Initialized
INFO - 2018-08-14 11:26:50 --> URI Class Initialized
INFO - 2018-08-14 11:26:50 --> Router Class Initialized
INFO - 2018-08-14 11:26:50 --> Output Class Initialized
INFO - 2018-08-14 11:26:50 --> Security Class Initialized
DEBUG - 2018-08-14 11:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:26:50 --> CSRF cookie sent
INFO - 2018-08-14 11:26:50 --> Input Class Initialized
INFO - 2018-08-14 11:26:50 --> Language Class Initialized
INFO - 2018-08-14 11:26:50 --> Loader Class Initialized
INFO - 2018-08-14 11:26:50 --> Helper loaded: url_helper
INFO - 2018-08-14 11:26:50 --> Helper loaded: form_helper
INFO - 2018-08-14 11:26:50 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:26:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:26:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:26:50 --> User Agent Class Initialized
INFO - 2018-08-14 11:26:50 --> Controller Class Initialized
INFO - 2018-08-14 11:26:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:26:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:26:50 --> Pixel_Model class loaded
INFO - 2018-08-14 11:26:50 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:50 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:50 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:50 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:26:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-08-14 11:26:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:26:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 11:26:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 11:26:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 11:26:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 11:26:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/times_slept_couch.php
INFO - 2018-08-14 11:26:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:26:50 --> Final output sent to browser
DEBUG - 2018-08-14 11:26:50 --> Total execution time: 0.0453
INFO - 2018-08-14 11:26:51 --> Config Class Initialized
INFO - 2018-08-14 11:26:51 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:26:51 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:26:51 --> Utf8 Class Initialized
INFO - 2018-08-14 11:26:51 --> URI Class Initialized
INFO - 2018-08-14 11:26:51 --> Router Class Initialized
INFO - 2018-08-14 11:26:51 --> Output Class Initialized
INFO - 2018-08-14 11:26:51 --> Security Class Initialized
DEBUG - 2018-08-14 11:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:26:51 --> CSRF cookie sent
INFO - 2018-08-14 11:26:51 --> Input Class Initialized
INFO - 2018-08-14 11:26:51 --> Language Class Initialized
INFO - 2018-08-14 11:26:51 --> Loader Class Initialized
INFO - 2018-08-14 11:26:51 --> Helper loaded: url_helper
INFO - 2018-08-14 11:26:51 --> Helper loaded: form_helper
INFO - 2018-08-14 11:26:51 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:26:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:26:51 --> User Agent Class Initialized
INFO - 2018-08-14 11:26:51 --> Controller Class Initialized
INFO - 2018-08-14 11:26:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:26:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:26:51 --> Pixel_Model class loaded
INFO - 2018-08-14 11:26:51 --> Database Driver Class Initialized
INFO - 2018-08-14 11:26:51 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:26:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:26:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-08-14 11:26:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:26:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 11:26:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 11:26:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 11:26:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 11:26:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-08-14 11:26:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:26:51 --> Final output sent to browser
DEBUG - 2018-08-14 11:26:51 --> Total execution time: 0.0387
INFO - 2018-08-14 11:27:01 --> Config Class Initialized
INFO - 2018-08-14 11:27:01 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:27:01 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:27:01 --> Utf8 Class Initialized
INFO - 2018-08-14 11:27:01 --> URI Class Initialized
INFO - 2018-08-14 11:27:01 --> Router Class Initialized
INFO - 2018-08-14 11:27:01 --> Output Class Initialized
INFO - 2018-08-14 11:27:01 --> Security Class Initialized
DEBUG - 2018-08-14 11:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:27:01 --> CSRF cookie sent
INFO - 2018-08-14 11:27:01 --> CSRF token verified
INFO - 2018-08-14 11:27:01 --> Input Class Initialized
INFO - 2018-08-14 11:27:01 --> Language Class Initialized
INFO - 2018-08-14 11:27:01 --> Loader Class Initialized
INFO - 2018-08-14 11:27:01 --> Helper loaded: url_helper
INFO - 2018-08-14 11:27:01 --> Helper loaded: form_helper
INFO - 2018-08-14 11:27:01 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:27:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:27:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:27:01 --> User Agent Class Initialized
INFO - 2018-08-14 11:27:01 --> Controller Class Initialized
INFO - 2018-08-14 11:27:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:27:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:27:01 --> Pixel_Model class loaded
INFO - 2018-08-14 11:27:01 --> Database Driver Class Initialized
INFO - 2018-08-14 11:27:01 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:27:01 --> Form Validation Class Initialized
INFO - 2018-08-14 11:27:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 11:27:01 --> Database Driver Class Initialized
INFO - 2018-08-14 11:27:01 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:27:01 --> Config Class Initialized
INFO - 2018-08-14 11:27:01 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:27:01 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:27:01 --> Utf8 Class Initialized
INFO - 2018-08-14 11:27:01 --> URI Class Initialized
INFO - 2018-08-14 11:27:01 --> Router Class Initialized
INFO - 2018-08-14 11:27:01 --> Output Class Initialized
INFO - 2018-08-14 11:27:01 --> Security Class Initialized
DEBUG - 2018-08-14 11:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:27:01 --> CSRF cookie sent
INFO - 2018-08-14 11:27:01 --> Input Class Initialized
INFO - 2018-08-14 11:27:01 --> Language Class Initialized
INFO - 2018-08-14 11:27:01 --> Loader Class Initialized
INFO - 2018-08-14 11:27:01 --> Helper loaded: url_helper
INFO - 2018-08-14 11:27:01 --> Helper loaded: form_helper
INFO - 2018-08-14 11:27:01 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:27:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:27:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:27:01 --> User Agent Class Initialized
INFO - 2018-08-14 11:27:01 --> Controller Class Initialized
INFO - 2018-08-14 11:27:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:27:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:27:01 --> Pixel_Model class loaded
INFO - 2018-08-14 11:27:01 --> Database Driver Class Initialized
INFO - 2018-08-14 11:27:01 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:27:01 --> Database Driver Class Initialized
INFO - 2018-08-14 11:27:01 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:27:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:27:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-08-14 11:27:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:27:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 11:27:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 11:27:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 11:27:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 11:27:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-14 11:27:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:27:01 --> Final output sent to browser
DEBUG - 2018-08-14 11:27:01 --> Total execution time: 0.0441
INFO - 2018-08-14 11:27:02 --> Config Class Initialized
INFO - 2018-08-14 11:27:02 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:27:02 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:27:02 --> Utf8 Class Initialized
INFO - 2018-08-14 11:27:02 --> URI Class Initialized
INFO - 2018-08-14 11:27:02 --> Router Class Initialized
INFO - 2018-08-14 11:27:02 --> Output Class Initialized
INFO - 2018-08-14 11:27:02 --> Security Class Initialized
DEBUG - 2018-08-14 11:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:27:02 --> CSRF cookie sent
INFO - 2018-08-14 11:27:02 --> CSRF token verified
INFO - 2018-08-14 11:27:02 --> Input Class Initialized
INFO - 2018-08-14 11:27:02 --> Language Class Initialized
INFO - 2018-08-14 11:27:02 --> Loader Class Initialized
INFO - 2018-08-14 11:27:02 --> Helper loaded: url_helper
INFO - 2018-08-14 11:27:02 --> Helper loaded: form_helper
INFO - 2018-08-14 11:27:02 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:27:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:27:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:27:02 --> User Agent Class Initialized
INFO - 2018-08-14 11:27:02 --> Controller Class Initialized
INFO - 2018-08-14 11:27:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:27:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:27:02 --> Pixel_Model class loaded
INFO - 2018-08-14 11:27:02 --> Database Driver Class Initialized
INFO - 2018-08-14 11:27:02 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:27:02 --> Form Validation Class Initialized
INFO - 2018-08-14 11:27:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 11:27:02 --> Database Driver Class Initialized
INFO - 2018-08-14 11:27:02 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:27:02 --> Config Class Initialized
INFO - 2018-08-14 11:27:02 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:27:02 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:27:02 --> Utf8 Class Initialized
INFO - 2018-08-14 11:27:02 --> URI Class Initialized
INFO - 2018-08-14 11:27:02 --> Router Class Initialized
INFO - 2018-08-14 11:27:02 --> Output Class Initialized
INFO - 2018-08-14 11:27:02 --> Security Class Initialized
DEBUG - 2018-08-14 11:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:27:02 --> CSRF cookie sent
INFO - 2018-08-14 11:27:02 --> Input Class Initialized
INFO - 2018-08-14 11:27:02 --> Language Class Initialized
INFO - 2018-08-14 11:27:02 --> Loader Class Initialized
INFO - 2018-08-14 11:27:02 --> Helper loaded: url_helper
INFO - 2018-08-14 11:27:02 --> Helper loaded: form_helper
INFO - 2018-08-14 11:27:02 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:27:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:27:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:27:02 --> User Agent Class Initialized
INFO - 2018-08-14 11:27:02 --> Controller Class Initialized
INFO - 2018-08-14 11:27:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:27:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:27:02 --> Pixel_Model class loaded
INFO - 2018-08-14 11:27:02 --> Database Driver Class Initialized
INFO - 2018-08-14 11:27:02 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:27:02 --> Database Driver Class Initialized
INFO - 2018-08-14 11:27:02 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:27:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:27:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-08-14 11:27:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:27:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 11:27:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 11:27:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 11:27:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 11:27:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-08-14 11:27:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:27:02 --> Final output sent to browser
DEBUG - 2018-08-14 11:27:02 --> Total execution time: 0.0484
INFO - 2018-08-14 11:27:04 --> Config Class Initialized
INFO - 2018-08-14 11:27:04 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:27:04 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:27:04 --> Utf8 Class Initialized
INFO - 2018-08-14 11:27:04 --> URI Class Initialized
INFO - 2018-08-14 11:27:04 --> Router Class Initialized
INFO - 2018-08-14 11:27:04 --> Output Class Initialized
INFO - 2018-08-14 11:27:04 --> Security Class Initialized
DEBUG - 2018-08-14 11:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:27:04 --> CSRF cookie sent
INFO - 2018-08-14 11:27:04 --> CSRF token verified
INFO - 2018-08-14 11:27:04 --> Input Class Initialized
INFO - 2018-08-14 11:27:04 --> Language Class Initialized
INFO - 2018-08-14 11:27:04 --> Loader Class Initialized
INFO - 2018-08-14 11:27:04 --> Helper loaded: url_helper
INFO - 2018-08-14 11:27:04 --> Helper loaded: form_helper
INFO - 2018-08-14 11:27:04 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:27:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:27:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:27:04 --> User Agent Class Initialized
INFO - 2018-08-14 11:27:04 --> Controller Class Initialized
INFO - 2018-08-14 11:27:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:27:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:27:04 --> Pixel_Model class loaded
INFO - 2018-08-14 11:27:04 --> Database Driver Class Initialized
INFO - 2018-08-14 11:27:04 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:27:04 --> Form Validation Class Initialized
INFO - 2018-08-14 11:27:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 11:27:04 --> Database Driver Class Initialized
INFO - 2018-08-14 11:27:04 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:27:04 --> Config Class Initialized
INFO - 2018-08-14 11:27:04 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:27:04 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:27:04 --> Utf8 Class Initialized
INFO - 2018-08-14 11:27:04 --> URI Class Initialized
INFO - 2018-08-14 11:27:04 --> Router Class Initialized
INFO - 2018-08-14 11:27:04 --> Output Class Initialized
INFO - 2018-08-14 11:27:04 --> Security Class Initialized
DEBUG - 2018-08-14 11:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:27:04 --> CSRF cookie sent
INFO - 2018-08-14 11:27:04 --> Input Class Initialized
INFO - 2018-08-14 11:27:04 --> Language Class Initialized
INFO - 2018-08-14 11:27:04 --> Loader Class Initialized
INFO - 2018-08-14 11:27:04 --> Helper loaded: url_helper
INFO - 2018-08-14 11:27:04 --> Helper loaded: form_helper
INFO - 2018-08-14 11:27:04 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:27:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:27:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:27:04 --> User Agent Class Initialized
INFO - 2018-08-14 11:27:04 --> Controller Class Initialized
INFO - 2018-08-14 11:27:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:27:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:27:04 --> Pixel_Model class loaded
INFO - 2018-08-14 11:27:04 --> Database Driver Class Initialized
INFO - 2018-08-14 11:27:04 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:27:04 --> Database Driver Class Initialized
INFO - 2018-08-14 11:27:04 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:27:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:27:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-08-14 11:27:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:27:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-08-14 11:27:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 11:27:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 11:27:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 11:27:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 11:27:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-08-14 11:27:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:27:04 --> Final output sent to browser
DEBUG - 2018-08-14 11:27:04 --> Total execution time: 0.0396
INFO - 2018-08-14 11:27:13 --> Config Class Initialized
INFO - 2018-08-14 11:27:13 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:27:13 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:27:13 --> Utf8 Class Initialized
INFO - 2018-08-14 11:27:13 --> URI Class Initialized
INFO - 2018-08-14 11:27:13 --> Router Class Initialized
INFO - 2018-08-14 11:27:13 --> Output Class Initialized
INFO - 2018-08-14 11:27:13 --> Security Class Initialized
DEBUG - 2018-08-14 11:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:27:13 --> CSRF cookie sent
INFO - 2018-08-14 11:27:13 --> CSRF token verified
INFO - 2018-08-14 11:27:13 --> Input Class Initialized
INFO - 2018-08-14 11:27:13 --> Language Class Initialized
INFO - 2018-08-14 11:27:13 --> Loader Class Initialized
INFO - 2018-08-14 11:27:13 --> Helper loaded: url_helper
INFO - 2018-08-14 11:27:13 --> Helper loaded: form_helper
INFO - 2018-08-14 11:27:13 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:27:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:27:13 --> User Agent Class Initialized
INFO - 2018-08-14 11:27:13 --> Controller Class Initialized
INFO - 2018-08-14 11:27:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:27:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:27:13 --> Pixel_Model class loaded
INFO - 2018-08-14 11:27:13 --> Database Driver Class Initialized
INFO - 2018-08-14 11:27:13 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:27:13 --> Form Validation Class Initialized
INFO - 2018-08-14 11:27:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 11:27:13 --> Database Driver Class Initialized
INFO - 2018-08-14 11:27:13 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:27:13 --> Config Class Initialized
INFO - 2018-08-14 11:27:13 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:27:13 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:27:13 --> Utf8 Class Initialized
INFO - 2018-08-14 11:27:13 --> URI Class Initialized
INFO - 2018-08-14 11:27:13 --> Router Class Initialized
INFO - 2018-08-14 11:27:13 --> Output Class Initialized
INFO - 2018-08-14 11:27:13 --> Security Class Initialized
DEBUG - 2018-08-14 11:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:27:13 --> CSRF cookie sent
INFO - 2018-08-14 11:27:13 --> Input Class Initialized
INFO - 2018-08-14 11:27:13 --> Language Class Initialized
INFO - 2018-08-14 11:27:13 --> Loader Class Initialized
INFO - 2018-08-14 11:27:13 --> Helper loaded: url_helper
INFO - 2018-08-14 11:27:13 --> Helper loaded: form_helper
INFO - 2018-08-14 11:27:13 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:27:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:27:13 --> User Agent Class Initialized
INFO - 2018-08-14 11:27:13 --> Controller Class Initialized
INFO - 2018-08-14 11:27:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:27:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:27:13 --> Pixel_Model class loaded
INFO - 2018-08-14 11:27:13 --> Database Driver Class Initialized
INFO - 2018-08-14 11:27:13 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:27:13 --> Database Driver Class Initialized
INFO - 2018-08-14 11:27:13 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:27:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:27:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-08-14 11:27:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:27:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 11:27:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 11:27:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 11:27:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 11:27:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-08-14 11:27:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:27:13 --> Final output sent to browser
DEBUG - 2018-08-14 11:27:13 --> Total execution time: 0.0387
INFO - 2018-08-14 11:27:15 --> Config Class Initialized
INFO - 2018-08-14 11:27:15 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:27:15 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:27:15 --> Utf8 Class Initialized
INFO - 2018-08-14 11:27:15 --> URI Class Initialized
INFO - 2018-08-14 11:27:15 --> Router Class Initialized
INFO - 2018-08-14 11:27:15 --> Output Class Initialized
INFO - 2018-08-14 11:27:15 --> Security Class Initialized
DEBUG - 2018-08-14 11:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:27:15 --> CSRF cookie sent
INFO - 2018-08-14 11:27:15 --> CSRF token verified
INFO - 2018-08-14 11:27:15 --> Input Class Initialized
INFO - 2018-08-14 11:27:15 --> Language Class Initialized
INFO - 2018-08-14 11:27:15 --> Loader Class Initialized
INFO - 2018-08-14 11:27:15 --> Helper loaded: url_helper
INFO - 2018-08-14 11:27:15 --> Helper loaded: form_helper
INFO - 2018-08-14 11:27:15 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:27:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:27:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:27:15 --> User Agent Class Initialized
INFO - 2018-08-14 11:27:15 --> Controller Class Initialized
INFO - 2018-08-14 11:27:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:27:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:27:15 --> Pixel_Model class loaded
INFO - 2018-08-14 11:27:15 --> Database Driver Class Initialized
INFO - 2018-08-14 11:27:15 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:27:15 --> Form Validation Class Initialized
INFO - 2018-08-14 11:27:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 11:27:15 --> Database Driver Class Initialized
INFO - 2018-08-14 11:27:15 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:27:15 --> Config Class Initialized
INFO - 2018-08-14 11:27:15 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:27:15 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:27:15 --> Utf8 Class Initialized
INFO - 2018-08-14 11:27:15 --> URI Class Initialized
INFO - 2018-08-14 11:27:15 --> Router Class Initialized
INFO - 2018-08-14 11:27:15 --> Output Class Initialized
INFO - 2018-08-14 11:27:15 --> Security Class Initialized
DEBUG - 2018-08-14 11:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:27:15 --> CSRF cookie sent
INFO - 2018-08-14 11:27:15 --> Input Class Initialized
INFO - 2018-08-14 11:27:15 --> Language Class Initialized
INFO - 2018-08-14 11:27:15 --> Loader Class Initialized
INFO - 2018-08-14 11:27:15 --> Helper loaded: url_helper
INFO - 2018-08-14 11:27:15 --> Helper loaded: form_helper
INFO - 2018-08-14 11:27:15 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:27:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:27:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:27:15 --> User Agent Class Initialized
INFO - 2018-08-14 11:27:15 --> Controller Class Initialized
INFO - 2018-08-14 11:27:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:27:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:27:15 --> Pixel_Model class loaded
INFO - 2018-08-14 11:27:15 --> Database Driver Class Initialized
INFO - 2018-08-14 11:27:15 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:27:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:27:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-08-14 11:27:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:27:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 11:27:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 11:27:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 11:27:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/cohabitation.php
INFO - 2018-08-14 11:27:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:27:15 --> Final output sent to browser
DEBUG - 2018-08-14 11:27:15 --> Total execution time: 0.0362
INFO - 2018-08-14 11:28:27 --> Config Class Initialized
INFO - 2018-08-14 11:28:27 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:28:27 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:28:27 --> Utf8 Class Initialized
INFO - 2018-08-14 11:28:27 --> URI Class Initialized
INFO - 2018-08-14 11:28:27 --> Router Class Initialized
INFO - 2018-08-14 11:28:27 --> Output Class Initialized
INFO - 2018-08-14 11:28:27 --> Security Class Initialized
DEBUG - 2018-08-14 11:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:28:27 --> CSRF cookie sent
INFO - 2018-08-14 11:28:27 --> CSRF token verified
INFO - 2018-08-14 11:28:27 --> Input Class Initialized
INFO - 2018-08-14 11:28:27 --> Language Class Initialized
INFO - 2018-08-14 11:28:27 --> Loader Class Initialized
INFO - 2018-08-14 11:28:27 --> Helper loaded: url_helper
INFO - 2018-08-14 11:28:27 --> Helper loaded: form_helper
INFO - 2018-08-14 11:28:27 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:28:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:28:28 --> User Agent Class Initialized
INFO - 2018-08-14 11:28:28 --> Controller Class Initialized
INFO - 2018-08-14 11:28:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:28:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:28:28 --> Pixel_Model class loaded
INFO - 2018-08-14 11:28:28 --> Database Driver Class Initialized
INFO - 2018-08-14 11:28:28 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:28:28 --> Form Validation Class Initialized
INFO - 2018-08-14 11:28:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 11:28:28 --> Database Driver Class Initialized
INFO - 2018-08-14 11:28:28 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:28:28 --> Config Class Initialized
INFO - 2018-08-14 11:28:28 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:28:28 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:28:28 --> Utf8 Class Initialized
INFO - 2018-08-14 11:28:28 --> URI Class Initialized
INFO - 2018-08-14 11:28:28 --> Router Class Initialized
INFO - 2018-08-14 11:28:28 --> Output Class Initialized
INFO - 2018-08-14 11:28:28 --> Security Class Initialized
DEBUG - 2018-08-14 11:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:28:28 --> CSRF cookie sent
INFO - 2018-08-14 11:28:28 --> Input Class Initialized
INFO - 2018-08-14 11:28:28 --> Language Class Initialized
INFO - 2018-08-14 11:28:28 --> Loader Class Initialized
INFO - 2018-08-14 11:28:28 --> Helper loaded: url_helper
INFO - 2018-08-14 11:28:28 --> Helper loaded: form_helper
INFO - 2018-08-14 11:28:28 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:28:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:28:28 --> User Agent Class Initialized
INFO - 2018-08-14 11:28:28 --> Controller Class Initialized
INFO - 2018-08-14 11:28:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:28:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:28:28 --> Pixel_Model class loaded
INFO - 2018-08-14 11:28:28 --> Database Driver Class Initialized
INFO - 2018-08-14 11:28:28 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:28:28 --> Database Driver Class Initialized
INFO - 2018-08-14 11:28:28 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:28:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:28:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-08-14 11:28:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:28:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 11:28:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 11:28:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 11:28:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 11:28:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-08-14 11:28:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:28:28 --> Final output sent to browser
DEBUG - 2018-08-14 11:28:28 --> Total execution time: 0.0467
INFO - 2018-08-14 11:28:32 --> Config Class Initialized
INFO - 2018-08-14 11:28:32 --> Hooks Class Initialized
DEBUG - 2018-08-14 11:28:32 --> UTF-8 Support Enabled
INFO - 2018-08-14 11:28:32 --> Utf8 Class Initialized
INFO - 2018-08-14 11:28:32 --> URI Class Initialized
INFO - 2018-08-14 11:28:32 --> Router Class Initialized
INFO - 2018-08-14 11:28:32 --> Output Class Initialized
INFO - 2018-08-14 11:28:32 --> Security Class Initialized
DEBUG - 2018-08-14 11:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 11:28:32 --> CSRF cookie sent
INFO - 2018-08-14 11:28:32 --> Input Class Initialized
INFO - 2018-08-14 11:28:32 --> Language Class Initialized
INFO - 2018-08-14 11:28:32 --> Loader Class Initialized
INFO - 2018-08-14 11:28:32 --> Helper loaded: url_helper
INFO - 2018-08-14 11:28:32 --> Helper loaded: form_helper
INFO - 2018-08-14 11:28:32 --> Helper loaded: language_helper
DEBUG - 2018-08-14 11:28:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 11:28:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 11:28:32 --> User Agent Class Initialized
INFO - 2018-08-14 11:28:32 --> Controller Class Initialized
INFO - 2018-08-14 11:28:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 11:28:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 11:28:32 --> Pixel_Model class loaded
INFO - 2018-08-14 11:28:32 --> Database Driver Class Initialized
INFO - 2018-08-14 11:28:32 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:28:32 --> Database Driver Class Initialized
INFO - 2018-08-14 11:28:32 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 11:28:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 11:28:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-08-14 11:28:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 11:28:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 11:28:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 11:28:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-08-14 11:28:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 11:28:32 --> Final output sent to browser
DEBUG - 2018-08-14 11:28:32 --> Total execution time: 0.0460
INFO - 2018-08-14 13:10:24 --> Config Class Initialized
INFO - 2018-08-14 13:10:24 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:10:24 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:10:24 --> Utf8 Class Initialized
INFO - 2018-08-14 13:10:24 --> URI Class Initialized
INFO - 2018-08-14 13:10:24 --> Router Class Initialized
INFO - 2018-08-14 13:10:24 --> Output Class Initialized
INFO - 2018-08-14 13:10:24 --> Security Class Initialized
DEBUG - 2018-08-14 13:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:10:24 --> CSRF cookie sent
INFO - 2018-08-14 13:10:24 --> Input Class Initialized
INFO - 2018-08-14 13:10:24 --> Language Class Initialized
INFO - 2018-08-14 13:10:24 --> Loader Class Initialized
INFO - 2018-08-14 13:10:24 --> Helper loaded: url_helper
INFO - 2018-08-14 13:10:24 --> Helper loaded: form_helper
INFO - 2018-08-14 13:10:24 --> Helper loaded: language_helper
DEBUG - 2018-08-14 13:10:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:10:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:10:24 --> User Agent Class Initialized
INFO - 2018-08-14 13:10:24 --> Controller Class Initialized
INFO - 2018-08-14 13:10:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 13:10:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 13:10:24 --> Pixel_Model class loaded
INFO - 2018-08-14 13:10:24 --> Database Driver Class Initialized
INFO - 2018-08-14 13:10:24 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:10:24 --> Config Class Initialized
INFO - 2018-08-14 13:10:24 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:10:24 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:10:24 --> Utf8 Class Initialized
INFO - 2018-08-14 13:10:24 --> URI Class Initialized
INFO - 2018-08-14 13:10:24 --> Router Class Initialized
INFO - 2018-08-14 13:10:24 --> Output Class Initialized
INFO - 2018-08-14 13:10:24 --> Security Class Initialized
DEBUG - 2018-08-14 13:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:10:24 --> CSRF cookie sent
INFO - 2018-08-14 13:10:24 --> Input Class Initialized
INFO - 2018-08-14 13:10:24 --> Language Class Initialized
INFO - 2018-08-14 13:10:24 --> Loader Class Initialized
INFO - 2018-08-14 13:10:24 --> Helper loaded: url_helper
INFO - 2018-08-14 13:10:24 --> Helper loaded: form_helper
INFO - 2018-08-14 13:10:24 --> Helper loaded: language_helper
DEBUG - 2018-08-14 13:10:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:10:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:10:24 --> User Agent Class Initialized
INFO - 2018-08-14 13:10:24 --> Controller Class Initialized
INFO - 2018-08-14 13:10:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 13:10:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 13:10:24 --> Pixel_Model class loaded
INFO - 2018-08-14 13:10:24 --> Database Driver Class Initialized
INFO - 2018-08-14 13:10:24 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:10:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 13:10:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 13:10:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 13:10:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 13:10:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 13:10:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 13:10:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-08-14 13:10:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 13:10:24 --> Final output sent to browser
DEBUG - 2018-08-14 13:10:24 --> Total execution time: 0.0501
INFO - 2018-08-14 13:10:30 --> Config Class Initialized
INFO - 2018-08-14 13:10:30 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:10:30 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:10:30 --> Utf8 Class Initialized
INFO - 2018-08-14 13:10:30 --> URI Class Initialized
INFO - 2018-08-14 13:10:30 --> Router Class Initialized
INFO - 2018-08-14 13:10:30 --> Output Class Initialized
INFO - 2018-08-14 13:10:30 --> Security Class Initialized
DEBUG - 2018-08-14 13:10:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:10:30 --> CSRF cookie sent
INFO - 2018-08-14 13:10:30 --> Input Class Initialized
INFO - 2018-08-14 13:10:30 --> Language Class Initialized
INFO - 2018-08-14 13:10:30 --> Loader Class Initialized
INFO - 2018-08-14 13:10:30 --> Helper loaded: url_helper
INFO - 2018-08-14 13:10:30 --> Helper loaded: form_helper
INFO - 2018-08-14 13:10:30 --> Helper loaded: language_helper
DEBUG - 2018-08-14 13:10:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:10:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:10:30 --> User Agent Class Initialized
INFO - 2018-08-14 13:10:30 --> Controller Class Initialized
INFO - 2018-08-14 13:10:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 13:10:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 13:10:30 --> Pixel_Model class loaded
INFO - 2018-08-14 13:10:30 --> Database Driver Class Initialized
INFO - 2018-08-14 13:10:30 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:10:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 13:10:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 13:10:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 13:10:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 13:10:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 13:10:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 13:10:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-08-14 13:10:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 13:10:30 --> Final output sent to browser
DEBUG - 2018-08-14 13:10:30 --> Total execution time: 0.0406
INFO - 2018-08-14 13:10:48 --> Config Class Initialized
INFO - 2018-08-14 13:10:48 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:10:48 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:10:48 --> Utf8 Class Initialized
INFO - 2018-08-14 13:10:48 --> URI Class Initialized
INFO - 2018-08-14 13:10:48 --> Router Class Initialized
INFO - 2018-08-14 13:10:48 --> Output Class Initialized
INFO - 2018-08-14 13:10:48 --> Security Class Initialized
DEBUG - 2018-08-14 13:10:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:10:48 --> CSRF cookie sent
INFO - 2018-08-14 13:10:48 --> Input Class Initialized
INFO - 2018-08-14 13:10:48 --> Language Class Initialized
INFO - 2018-08-14 13:10:48 --> Loader Class Initialized
INFO - 2018-08-14 13:10:48 --> Helper loaded: url_helper
INFO - 2018-08-14 13:10:48 --> Helper loaded: form_helper
INFO - 2018-08-14 13:10:48 --> Helper loaded: language_helper
DEBUG - 2018-08-14 13:10:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:10:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:10:48 --> User Agent Class Initialized
INFO - 2018-08-14 13:10:48 --> Controller Class Initialized
INFO - 2018-08-14 13:10:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 13:10:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 13:10:48 --> Pixel_Model class loaded
INFO - 2018-08-14 13:10:48 --> Database Driver Class Initialized
INFO - 2018-08-14 13:10:48 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:10:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 13:10:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 13:10:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 13:10:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 13:10:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 13:10:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 13:10:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-08-14 13:10:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 13:10:48 --> Final output sent to browser
DEBUG - 2018-08-14 13:10:48 --> Total execution time: 0.0484
INFO - 2018-08-14 13:10:58 --> Config Class Initialized
INFO - 2018-08-14 13:10:58 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:10:58 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:10:58 --> Utf8 Class Initialized
INFO - 2018-08-14 13:10:58 --> URI Class Initialized
INFO - 2018-08-14 13:10:58 --> Router Class Initialized
INFO - 2018-08-14 13:10:58 --> Output Class Initialized
INFO - 2018-08-14 13:10:58 --> Security Class Initialized
DEBUG - 2018-08-14 13:10:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:10:58 --> CSRF cookie sent
INFO - 2018-08-14 13:10:58 --> Input Class Initialized
INFO - 2018-08-14 13:10:58 --> Language Class Initialized
INFO - 2018-08-14 13:10:58 --> Loader Class Initialized
INFO - 2018-08-14 13:10:58 --> Helper loaded: url_helper
INFO - 2018-08-14 13:10:58 --> Helper loaded: form_helper
INFO - 2018-08-14 13:10:58 --> Helper loaded: language_helper
DEBUG - 2018-08-14 13:10:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:10:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:10:58 --> User Agent Class Initialized
INFO - 2018-08-14 13:10:58 --> Controller Class Initialized
INFO - 2018-08-14 13:10:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 13:10:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 13:10:58 --> Pixel_Model class loaded
INFO - 2018-08-14 13:10:58 --> Database Driver Class Initialized
INFO - 2018-08-14 13:10:58 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:10:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 13:10:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 13:10:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 13:10:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 13:10:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 13:10:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 13:10:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-08-14 13:10:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 13:10:58 --> Final output sent to browser
DEBUG - 2018-08-14 13:10:58 --> Total execution time: 0.0392
INFO - 2018-08-14 13:31:15 --> Config Class Initialized
INFO - 2018-08-14 13:31:15 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:31:15 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:31:15 --> Utf8 Class Initialized
INFO - 2018-08-14 13:31:15 --> URI Class Initialized
DEBUG - 2018-08-14 13:31:15 --> No URI present. Default controller set.
INFO - 2018-08-14 13:31:15 --> Router Class Initialized
INFO - 2018-08-14 13:31:15 --> Output Class Initialized
INFO - 2018-08-14 13:31:15 --> Security Class Initialized
DEBUG - 2018-08-14 13:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:31:15 --> CSRF cookie sent
INFO - 2018-08-14 13:31:15 --> Input Class Initialized
INFO - 2018-08-14 13:31:15 --> Language Class Initialized
INFO - 2018-08-14 13:31:15 --> Loader Class Initialized
INFO - 2018-08-14 13:31:15 --> Helper loaded: url_helper
INFO - 2018-08-14 13:31:15 --> Helper loaded: form_helper
INFO - 2018-08-14 13:31:15 --> Helper loaded: language_helper
DEBUG - 2018-08-14 13:31:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:31:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:31:15 --> User Agent Class Initialized
INFO - 2018-08-14 13:31:15 --> Controller Class Initialized
INFO - 2018-08-14 13:31:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 13:31:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 13:31:15 --> Pixel_Model class loaded
INFO - 2018-08-14 13:31:15 --> Database Driver Class Initialized
INFO - 2018-08-14 13:31:15 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:31:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 13:31:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 13:31:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-14 13:31:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 13:31:15 --> Final output sent to browser
DEBUG - 2018-08-14 13:31:15 --> Total execution time: 0.0438
INFO - 2018-08-14 13:33:12 --> Config Class Initialized
INFO - 2018-08-14 13:33:12 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:33:12 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:33:12 --> Utf8 Class Initialized
INFO - 2018-08-14 13:33:12 --> URI Class Initialized
INFO - 2018-08-14 13:33:12 --> Router Class Initialized
INFO - 2018-08-14 13:33:12 --> Output Class Initialized
INFO - 2018-08-14 13:33:12 --> Security Class Initialized
DEBUG - 2018-08-14 13:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:33:12 --> CSRF cookie sent
INFO - 2018-08-14 13:33:12 --> CSRF token verified
INFO - 2018-08-14 13:33:12 --> Input Class Initialized
INFO - 2018-08-14 13:33:12 --> Language Class Initialized
INFO - 2018-08-14 13:33:12 --> Loader Class Initialized
INFO - 2018-08-14 13:33:12 --> Helper loaded: url_helper
INFO - 2018-08-14 13:33:12 --> Helper loaded: form_helper
INFO - 2018-08-14 13:33:12 --> Helper loaded: language_helper
DEBUG - 2018-08-14 13:33:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:33:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:33:12 --> User Agent Class Initialized
INFO - 2018-08-14 13:33:12 --> Controller Class Initialized
INFO - 2018-08-14 13:33:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 13:33:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 13:33:12 --> Pixel_Model class loaded
INFO - 2018-08-14 13:33:12 --> Database Driver Class Initialized
INFO - 2018-08-14 13:33:12 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:33:12 --> Database Driver Class Initialized
INFO - 2018-08-14 13:33:12 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:33:12 --> Config Class Initialized
INFO - 2018-08-14 13:33:12 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:33:12 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:33:12 --> Utf8 Class Initialized
INFO - 2018-08-14 13:33:12 --> URI Class Initialized
INFO - 2018-08-14 13:33:12 --> Router Class Initialized
INFO - 2018-08-14 13:33:12 --> Output Class Initialized
INFO - 2018-08-14 13:33:12 --> Security Class Initialized
DEBUG - 2018-08-14 13:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:33:12 --> CSRF cookie sent
INFO - 2018-08-14 13:33:12 --> Input Class Initialized
INFO - 2018-08-14 13:33:12 --> Language Class Initialized
INFO - 2018-08-14 13:33:12 --> Loader Class Initialized
INFO - 2018-08-14 13:33:12 --> Helper loaded: url_helper
INFO - 2018-08-14 13:33:12 --> Helper loaded: form_helper
INFO - 2018-08-14 13:33:12 --> Helper loaded: language_helper
DEBUG - 2018-08-14 13:33:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:33:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:33:12 --> User Agent Class Initialized
INFO - 2018-08-14 13:33:12 --> Controller Class Initialized
INFO - 2018-08-14 13:33:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 13:33:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 13:33:12 --> Pixel_Model class loaded
INFO - 2018-08-14 13:33:12 --> Database Driver Class Initialized
INFO - 2018-08-14 13:33:12 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:33:12 --> Database Driver Class Initialized
INFO - 2018-08-14 13:33:12 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:33:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 13:33:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 13:33:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 13:33:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 13:33:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 13:33:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 13:33:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-14 13:33:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 13:33:12 --> Final output sent to browser
DEBUG - 2018-08-14 13:33:12 --> Total execution time: 0.0426
INFO - 2018-08-14 13:33:40 --> Config Class Initialized
INFO - 2018-08-14 13:33:40 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:33:40 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:33:40 --> Utf8 Class Initialized
INFO - 2018-08-14 13:33:40 --> URI Class Initialized
DEBUG - 2018-08-14 13:33:40 --> No URI present. Default controller set.
INFO - 2018-08-14 13:33:40 --> Router Class Initialized
INFO - 2018-08-14 13:33:40 --> Output Class Initialized
INFO - 2018-08-14 13:33:40 --> Security Class Initialized
DEBUG - 2018-08-14 13:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:33:40 --> CSRF cookie sent
INFO - 2018-08-14 13:33:40 --> Input Class Initialized
INFO - 2018-08-14 13:33:40 --> Language Class Initialized
INFO - 2018-08-14 13:33:40 --> Loader Class Initialized
INFO - 2018-08-14 13:33:40 --> Helper loaded: url_helper
INFO - 2018-08-14 13:33:40 --> Helper loaded: form_helper
INFO - 2018-08-14 13:33:40 --> Helper loaded: language_helper
DEBUG - 2018-08-14 13:33:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:33:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:33:40 --> User Agent Class Initialized
INFO - 2018-08-14 13:33:40 --> Controller Class Initialized
INFO - 2018-08-14 13:33:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 13:33:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 13:33:40 --> Pixel_Model class loaded
INFO - 2018-08-14 13:33:40 --> Database Driver Class Initialized
INFO - 2018-08-14 13:33:40 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:33:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 13:33:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 13:33:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-14 13:33:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 13:33:40 --> Final output sent to browser
DEBUG - 2018-08-14 13:33:40 --> Total execution time: 0.0350
INFO - 2018-08-14 13:33:50 --> Config Class Initialized
INFO - 2018-08-14 13:33:50 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:33:50 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:33:50 --> Utf8 Class Initialized
INFO - 2018-08-14 13:33:50 --> URI Class Initialized
INFO - 2018-08-14 13:33:50 --> Router Class Initialized
INFO - 2018-08-14 13:33:50 --> Output Class Initialized
INFO - 2018-08-14 13:33:50 --> Security Class Initialized
DEBUG - 2018-08-14 13:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:33:50 --> CSRF cookie sent
INFO - 2018-08-14 13:33:50 --> CSRF token verified
INFO - 2018-08-14 13:33:50 --> Input Class Initialized
INFO - 2018-08-14 13:33:50 --> Language Class Initialized
INFO - 2018-08-14 13:33:50 --> Loader Class Initialized
INFO - 2018-08-14 13:33:50 --> Helper loaded: url_helper
INFO - 2018-08-14 13:33:50 --> Helper loaded: form_helper
INFO - 2018-08-14 13:33:50 --> Helper loaded: language_helper
DEBUG - 2018-08-14 13:33:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:33:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:33:50 --> User Agent Class Initialized
INFO - 2018-08-14 13:33:50 --> Controller Class Initialized
INFO - 2018-08-14 13:33:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 13:33:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 13:33:50 --> Pixel_Model class loaded
INFO - 2018-08-14 13:33:50 --> Database Driver Class Initialized
INFO - 2018-08-14 13:33:50 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:33:50 --> Database Driver Class Initialized
INFO - 2018-08-14 13:33:50 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:33:51 --> Config Class Initialized
INFO - 2018-08-14 13:33:51 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:33:51 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:33:51 --> Utf8 Class Initialized
INFO - 2018-08-14 13:33:51 --> URI Class Initialized
INFO - 2018-08-14 13:33:51 --> Router Class Initialized
INFO - 2018-08-14 13:33:51 --> Output Class Initialized
INFO - 2018-08-14 13:33:51 --> Security Class Initialized
DEBUG - 2018-08-14 13:33:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:33:51 --> CSRF cookie sent
INFO - 2018-08-14 13:33:51 --> Input Class Initialized
INFO - 2018-08-14 13:33:51 --> Language Class Initialized
INFO - 2018-08-14 13:33:51 --> Loader Class Initialized
INFO - 2018-08-14 13:33:51 --> Helper loaded: url_helper
INFO - 2018-08-14 13:33:51 --> Helper loaded: form_helper
INFO - 2018-08-14 13:33:51 --> Helper loaded: language_helper
DEBUG - 2018-08-14 13:33:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:33:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:33:51 --> User Agent Class Initialized
INFO - 2018-08-14 13:33:51 --> Controller Class Initialized
INFO - 2018-08-14 13:33:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 13:33:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 13:33:51 --> Pixel_Model class loaded
INFO - 2018-08-14 13:33:51 --> Database Driver Class Initialized
INFO - 2018-08-14 13:33:51 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:33:51 --> Database Driver Class Initialized
INFO - 2018-08-14 13:33:51 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:33:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 13:33:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 13:33:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-08-14 13:33:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 13:33:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 13:33:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 13:33:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 13:33:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-08-14 13:33:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 13:33:51 --> Final output sent to browser
DEBUG - 2018-08-14 13:33:51 --> Total execution time: 0.0434
INFO - 2018-08-14 13:35:46 --> Config Class Initialized
INFO - 2018-08-14 13:35:46 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:35:46 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:35:46 --> Utf8 Class Initialized
INFO - 2018-08-14 13:35:46 --> URI Class Initialized
DEBUG - 2018-08-14 13:35:46 --> No URI present. Default controller set.
INFO - 2018-08-14 13:35:46 --> Router Class Initialized
INFO - 2018-08-14 13:35:46 --> Output Class Initialized
INFO - 2018-08-14 13:35:46 --> Security Class Initialized
DEBUG - 2018-08-14 13:35:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:35:46 --> CSRF cookie sent
INFO - 2018-08-14 13:35:46 --> Input Class Initialized
INFO - 2018-08-14 13:35:46 --> Language Class Initialized
INFO - 2018-08-14 13:35:46 --> Loader Class Initialized
INFO - 2018-08-14 13:35:46 --> Helper loaded: url_helper
INFO - 2018-08-14 13:35:46 --> Helper loaded: form_helper
INFO - 2018-08-14 13:35:46 --> Helper loaded: language_helper
DEBUG - 2018-08-14 13:35:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:35:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:35:46 --> User Agent Class Initialized
INFO - 2018-08-14 13:35:46 --> Controller Class Initialized
INFO - 2018-08-14 13:35:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 13:35:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 13:35:46 --> Pixel_Model class loaded
INFO - 2018-08-14 13:35:46 --> Database Driver Class Initialized
INFO - 2018-08-14 13:35:46 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:35:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 13:35:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 13:35:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-14 13:35:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 13:35:46 --> Final output sent to browser
DEBUG - 2018-08-14 13:35:46 --> Total execution time: 0.0529
INFO - 2018-08-14 13:36:42 --> Config Class Initialized
INFO - 2018-08-14 13:36:42 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:36:42 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:36:42 --> Utf8 Class Initialized
INFO - 2018-08-14 13:36:42 --> URI Class Initialized
INFO - 2018-08-14 13:36:42 --> Router Class Initialized
INFO - 2018-08-14 13:36:42 --> Output Class Initialized
INFO - 2018-08-14 13:36:42 --> Security Class Initialized
DEBUG - 2018-08-14 13:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:36:42 --> CSRF cookie sent
INFO - 2018-08-14 13:36:42 --> CSRF token verified
INFO - 2018-08-14 13:36:42 --> Input Class Initialized
INFO - 2018-08-14 13:36:42 --> Language Class Initialized
INFO - 2018-08-14 13:36:42 --> Loader Class Initialized
INFO - 2018-08-14 13:36:42 --> Helper loaded: url_helper
INFO - 2018-08-14 13:36:42 --> Helper loaded: form_helper
INFO - 2018-08-14 13:36:42 --> Helper loaded: language_helper
DEBUG - 2018-08-14 13:36:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:36:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:36:42 --> User Agent Class Initialized
INFO - 2018-08-14 13:36:42 --> Controller Class Initialized
INFO - 2018-08-14 13:36:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 13:36:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 13:36:42 --> Pixel_Model class loaded
INFO - 2018-08-14 13:36:42 --> Database Driver Class Initialized
INFO - 2018-08-14 13:36:42 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:36:42 --> Database Driver Class Initialized
INFO - 2018-08-14 13:36:42 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:36:42 --> Config Class Initialized
INFO - 2018-08-14 13:36:42 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:36:42 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:36:42 --> Utf8 Class Initialized
INFO - 2018-08-14 13:36:42 --> URI Class Initialized
INFO - 2018-08-14 13:36:42 --> Router Class Initialized
INFO - 2018-08-14 13:36:42 --> Output Class Initialized
INFO - 2018-08-14 13:36:42 --> Security Class Initialized
DEBUG - 2018-08-14 13:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:36:42 --> CSRF cookie sent
INFO - 2018-08-14 13:36:42 --> Input Class Initialized
INFO - 2018-08-14 13:36:42 --> Language Class Initialized
INFO - 2018-08-14 13:36:42 --> Loader Class Initialized
INFO - 2018-08-14 13:36:42 --> Helper loaded: url_helper
INFO - 2018-08-14 13:36:42 --> Helper loaded: form_helper
INFO - 2018-08-14 13:36:42 --> Helper loaded: language_helper
DEBUG - 2018-08-14 13:36:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:36:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:36:42 --> User Agent Class Initialized
INFO - 2018-08-14 13:36:42 --> Controller Class Initialized
INFO - 2018-08-14 13:36:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 13:36:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 13:36:42 --> Pixel_Model class loaded
INFO - 2018-08-14 13:36:42 --> Database Driver Class Initialized
INFO - 2018-08-14 13:36:42 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:36:42 --> Database Driver Class Initialized
INFO - 2018-08-14 13:36:42 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:36:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 13:36:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 13:36:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-08-14 13:36:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 13:36:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 13:36:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 13:36:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 13:36:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-08-14 13:36:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 13:36:42 --> Final output sent to browser
DEBUG - 2018-08-14 13:36:42 --> Total execution time: 0.0345
INFO - 2018-08-14 13:36:53 --> Config Class Initialized
INFO - 2018-08-14 13:36:53 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:36:53 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:36:53 --> Utf8 Class Initialized
INFO - 2018-08-14 13:36:53 --> URI Class Initialized
DEBUG - 2018-08-14 13:36:53 --> No URI present. Default controller set.
INFO - 2018-08-14 13:36:53 --> Router Class Initialized
INFO - 2018-08-14 13:36:53 --> Output Class Initialized
INFO - 2018-08-14 13:36:53 --> Security Class Initialized
DEBUG - 2018-08-14 13:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:36:53 --> CSRF cookie sent
INFO - 2018-08-14 13:36:53 --> Input Class Initialized
INFO - 2018-08-14 13:36:53 --> Language Class Initialized
INFO - 2018-08-14 13:36:53 --> Loader Class Initialized
INFO - 2018-08-14 13:36:53 --> Helper loaded: url_helper
INFO - 2018-08-14 13:36:53 --> Helper loaded: form_helper
INFO - 2018-08-14 13:36:53 --> Helper loaded: language_helper
DEBUG - 2018-08-14 13:36:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:36:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:36:53 --> User Agent Class Initialized
INFO - 2018-08-14 13:36:53 --> Controller Class Initialized
INFO - 2018-08-14 13:36:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 13:36:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 13:36:53 --> Pixel_Model class loaded
INFO - 2018-08-14 13:36:53 --> Database Driver Class Initialized
INFO - 2018-08-14 13:36:53 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:36:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 13:36:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 13:36:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-14 13:36:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 13:36:53 --> Final output sent to browser
DEBUG - 2018-08-14 13:36:53 --> Total execution time: 0.0472
INFO - 2018-08-14 13:37:05 --> Config Class Initialized
INFO - 2018-08-14 13:37:05 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:37:05 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:37:05 --> Utf8 Class Initialized
INFO - 2018-08-14 13:37:05 --> URI Class Initialized
INFO - 2018-08-14 13:37:05 --> Router Class Initialized
INFO - 2018-08-14 13:37:05 --> Output Class Initialized
INFO - 2018-08-14 13:37:05 --> Security Class Initialized
DEBUG - 2018-08-14 13:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:37:05 --> CSRF cookie sent
INFO - 2018-08-14 13:37:05 --> CSRF token verified
INFO - 2018-08-14 13:37:05 --> Input Class Initialized
INFO - 2018-08-14 13:37:05 --> Language Class Initialized
INFO - 2018-08-14 13:37:05 --> Loader Class Initialized
INFO - 2018-08-14 13:37:05 --> Helper loaded: url_helper
INFO - 2018-08-14 13:37:05 --> Helper loaded: form_helper
INFO - 2018-08-14 13:37:05 --> Helper loaded: language_helper
DEBUG - 2018-08-14 13:37:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:37:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:37:05 --> User Agent Class Initialized
INFO - 2018-08-14 13:37:05 --> Controller Class Initialized
INFO - 2018-08-14 13:37:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 13:37:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 13:37:05 --> Pixel_Model class loaded
INFO - 2018-08-14 13:37:05 --> Database Driver Class Initialized
INFO - 2018-08-14 13:37:05 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:37:05 --> Database Driver Class Initialized
INFO - 2018-08-14 13:37:05 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:37:05 --> Config Class Initialized
INFO - 2018-08-14 13:37:05 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:37:05 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:37:05 --> Utf8 Class Initialized
INFO - 2018-08-14 13:37:05 --> URI Class Initialized
INFO - 2018-08-14 13:37:05 --> Router Class Initialized
INFO - 2018-08-14 13:37:05 --> Output Class Initialized
INFO - 2018-08-14 13:37:05 --> Security Class Initialized
DEBUG - 2018-08-14 13:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:37:05 --> CSRF cookie sent
INFO - 2018-08-14 13:37:05 --> Input Class Initialized
INFO - 2018-08-14 13:37:05 --> Language Class Initialized
INFO - 2018-08-14 13:37:05 --> Loader Class Initialized
INFO - 2018-08-14 13:37:05 --> Helper loaded: url_helper
INFO - 2018-08-14 13:37:05 --> Helper loaded: form_helper
INFO - 2018-08-14 13:37:05 --> Helper loaded: language_helper
DEBUG - 2018-08-14 13:37:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:37:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:37:05 --> User Agent Class Initialized
INFO - 2018-08-14 13:37:05 --> Controller Class Initialized
INFO - 2018-08-14 13:37:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 13:37:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 13:37:05 --> Pixel_Model class loaded
INFO - 2018-08-14 13:37:05 --> Database Driver Class Initialized
INFO - 2018-08-14 13:37:05 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:37:05 --> Database Driver Class Initialized
INFO - 2018-08-14 13:37:05 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:37:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 13:37:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 13:37:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-08-14 13:37:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 13:37:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 13:37:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 13:37:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 13:37:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-08-14 13:37:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 13:37:05 --> Final output sent to browser
DEBUG - 2018-08-14 13:37:05 --> Total execution time: 0.0411
INFO - 2018-08-14 13:37:16 --> Config Class Initialized
INFO - 2018-08-14 13:37:16 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:37:16 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:37:16 --> Utf8 Class Initialized
INFO - 2018-08-14 13:37:16 --> URI Class Initialized
DEBUG - 2018-08-14 13:37:16 --> No URI present. Default controller set.
INFO - 2018-08-14 13:37:16 --> Router Class Initialized
INFO - 2018-08-14 13:37:16 --> Output Class Initialized
INFO - 2018-08-14 13:37:16 --> Security Class Initialized
DEBUG - 2018-08-14 13:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:37:16 --> CSRF cookie sent
INFO - 2018-08-14 13:37:16 --> Input Class Initialized
INFO - 2018-08-14 13:37:16 --> Language Class Initialized
INFO - 2018-08-14 13:37:16 --> Loader Class Initialized
INFO - 2018-08-14 13:37:16 --> Helper loaded: url_helper
INFO - 2018-08-14 13:37:16 --> Helper loaded: form_helper
INFO - 2018-08-14 13:37:16 --> Helper loaded: language_helper
DEBUG - 2018-08-14 13:37:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:37:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:37:16 --> User Agent Class Initialized
INFO - 2018-08-14 13:37:16 --> Controller Class Initialized
INFO - 2018-08-14 13:37:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 13:37:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 13:37:16 --> Pixel_Model class loaded
INFO - 2018-08-14 13:37:16 --> Database Driver Class Initialized
INFO - 2018-08-14 13:37:16 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:37:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 13:37:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 13:37:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-14 13:37:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 13:37:16 --> Final output sent to browser
DEBUG - 2018-08-14 13:37:16 --> Total execution time: 0.0444
INFO - 2018-08-14 13:37:22 --> Config Class Initialized
INFO - 2018-08-14 13:37:22 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:37:22 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:37:22 --> Utf8 Class Initialized
INFO - 2018-08-14 13:37:22 --> URI Class Initialized
INFO - 2018-08-14 13:37:22 --> Router Class Initialized
INFO - 2018-08-14 13:37:22 --> Output Class Initialized
INFO - 2018-08-14 13:37:22 --> Security Class Initialized
DEBUG - 2018-08-14 13:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:37:22 --> CSRF cookie sent
INFO - 2018-08-14 13:37:22 --> CSRF token verified
INFO - 2018-08-14 13:37:22 --> Input Class Initialized
INFO - 2018-08-14 13:37:22 --> Language Class Initialized
INFO - 2018-08-14 13:37:22 --> Loader Class Initialized
INFO - 2018-08-14 13:37:22 --> Helper loaded: url_helper
INFO - 2018-08-14 13:37:22 --> Helper loaded: form_helper
INFO - 2018-08-14 13:37:22 --> Helper loaded: language_helper
DEBUG - 2018-08-14 13:37:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:37:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:37:22 --> User Agent Class Initialized
INFO - 2018-08-14 13:37:22 --> Controller Class Initialized
INFO - 2018-08-14 13:37:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 13:37:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 13:37:22 --> Pixel_Model class loaded
INFO - 2018-08-14 13:37:22 --> Database Driver Class Initialized
INFO - 2018-08-14 13:37:22 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:37:22 --> Database Driver Class Initialized
INFO - 2018-08-14 13:37:22 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:37:22 --> Config Class Initialized
INFO - 2018-08-14 13:37:22 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:37:22 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:37:22 --> Utf8 Class Initialized
INFO - 2018-08-14 13:37:22 --> URI Class Initialized
INFO - 2018-08-14 13:37:22 --> Router Class Initialized
INFO - 2018-08-14 13:37:22 --> Output Class Initialized
INFO - 2018-08-14 13:37:22 --> Security Class Initialized
DEBUG - 2018-08-14 13:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:37:22 --> CSRF cookie sent
INFO - 2018-08-14 13:37:22 --> Input Class Initialized
INFO - 2018-08-14 13:37:22 --> Language Class Initialized
INFO - 2018-08-14 13:37:22 --> Loader Class Initialized
INFO - 2018-08-14 13:37:22 --> Helper loaded: url_helper
INFO - 2018-08-14 13:37:22 --> Helper loaded: form_helper
INFO - 2018-08-14 13:37:22 --> Helper loaded: language_helper
DEBUG - 2018-08-14 13:37:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:37:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:37:22 --> User Agent Class Initialized
INFO - 2018-08-14 13:37:22 --> Controller Class Initialized
INFO - 2018-08-14 13:37:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 13:37:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 13:37:22 --> Pixel_Model class loaded
INFO - 2018-08-14 13:37:22 --> Database Driver Class Initialized
INFO - 2018-08-14 13:37:22 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:37:22 --> Database Driver Class Initialized
INFO - 2018-08-14 13:37:22 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:37:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 13:37:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 13:37:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-08-14 13:37:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 13:37:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 13:37:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 13:37:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 13:37:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-08-14 13:37:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 13:37:22 --> Final output sent to browser
DEBUG - 2018-08-14 13:37:22 --> Total execution time: 0.0377
INFO - 2018-08-14 13:37:52 --> Config Class Initialized
INFO - 2018-08-14 13:37:52 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:37:52 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:37:52 --> Utf8 Class Initialized
INFO - 2018-08-14 13:37:52 --> URI Class Initialized
INFO - 2018-08-14 13:37:52 --> Router Class Initialized
INFO - 2018-08-14 13:37:52 --> Output Class Initialized
INFO - 2018-08-14 13:37:52 --> Security Class Initialized
DEBUG - 2018-08-14 13:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:37:52 --> CSRF cookie sent
INFO - 2018-08-14 13:37:52 --> Input Class Initialized
INFO - 2018-08-14 13:37:52 --> Language Class Initialized
ERROR - 2018-08-14 13:37:52 --> 404 Page Not Found: 401shtml/index
INFO - 2018-08-14 13:37:59 --> Config Class Initialized
INFO - 2018-08-14 13:37:59 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:37:59 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:37:59 --> Utf8 Class Initialized
INFO - 2018-08-14 13:37:59 --> URI Class Initialized
DEBUG - 2018-08-14 13:37:59 --> No URI present. Default controller set.
INFO - 2018-08-14 13:37:59 --> Router Class Initialized
INFO - 2018-08-14 13:37:59 --> Output Class Initialized
INFO - 2018-08-14 13:37:59 --> Security Class Initialized
DEBUG - 2018-08-14 13:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:37:59 --> CSRF cookie sent
INFO - 2018-08-14 13:37:59 --> Input Class Initialized
INFO - 2018-08-14 13:37:59 --> Language Class Initialized
INFO - 2018-08-14 13:37:59 --> Loader Class Initialized
INFO - 2018-08-14 13:37:59 --> Helper loaded: url_helper
INFO - 2018-08-14 13:37:59 --> Helper loaded: form_helper
INFO - 2018-08-14 13:37:59 --> Helper loaded: language_helper
DEBUG - 2018-08-14 13:37:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:37:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:37:59 --> User Agent Class Initialized
INFO - 2018-08-14 13:37:59 --> Controller Class Initialized
INFO - 2018-08-14 13:37:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 13:37:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 13:37:59 --> Pixel_Model class loaded
INFO - 2018-08-14 13:37:59 --> Database Driver Class Initialized
INFO - 2018-08-14 13:37:59 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:37:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 13:37:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 13:37:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-14 13:37:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 13:37:59 --> Final output sent to browser
DEBUG - 2018-08-14 13:37:59 --> Total execution time: 0.0331
INFO - 2018-08-14 13:37:59 --> Config Class Initialized
INFO - 2018-08-14 13:37:59 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:37:59 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:37:59 --> Utf8 Class Initialized
INFO - 2018-08-14 13:37:59 --> URI Class Initialized
DEBUG - 2018-08-14 13:37:59 --> No URI present. Default controller set.
INFO - 2018-08-14 13:37:59 --> Router Class Initialized
INFO - 2018-08-14 13:37:59 --> Output Class Initialized
INFO - 2018-08-14 13:37:59 --> Security Class Initialized
DEBUG - 2018-08-14 13:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:37:59 --> CSRF cookie sent
INFO - 2018-08-14 13:37:59 --> Input Class Initialized
INFO - 2018-08-14 13:37:59 --> Language Class Initialized
INFO - 2018-08-14 13:37:59 --> Loader Class Initialized
INFO - 2018-08-14 13:37:59 --> Helper loaded: url_helper
INFO - 2018-08-14 13:37:59 --> Helper loaded: form_helper
INFO - 2018-08-14 13:37:59 --> Helper loaded: language_helper
DEBUG - 2018-08-14 13:37:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:37:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:37:59 --> User Agent Class Initialized
INFO - 2018-08-14 13:37:59 --> Controller Class Initialized
INFO - 2018-08-14 13:37:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 13:37:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 13:37:59 --> Pixel_Model class loaded
INFO - 2018-08-14 13:37:59 --> Database Driver Class Initialized
INFO - 2018-08-14 13:37:59 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:37:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 13:37:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 13:37:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-14 13:37:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 13:37:59 --> Final output sent to browser
DEBUG - 2018-08-14 13:37:59 --> Total execution time: 0.0505
INFO - 2018-08-14 13:38:49 --> Config Class Initialized
INFO - 2018-08-14 13:38:49 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:38:49 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:38:49 --> Utf8 Class Initialized
INFO - 2018-08-14 13:38:49 --> URI Class Initialized
INFO - 2018-08-14 13:38:49 --> Router Class Initialized
INFO - 2018-08-14 13:38:49 --> Output Class Initialized
INFO - 2018-08-14 13:38:49 --> Security Class Initialized
DEBUG - 2018-08-14 13:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:38:49 --> CSRF cookie sent
INFO - 2018-08-14 13:38:49 --> CSRF token verified
INFO - 2018-08-14 13:38:49 --> Input Class Initialized
INFO - 2018-08-14 13:38:49 --> Language Class Initialized
INFO - 2018-08-14 13:38:49 --> Loader Class Initialized
INFO - 2018-08-14 13:38:49 --> Helper loaded: url_helper
INFO - 2018-08-14 13:38:49 --> Helper loaded: form_helper
INFO - 2018-08-14 13:38:49 --> Helper loaded: language_helper
DEBUG - 2018-08-14 13:38:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:38:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:38:49 --> User Agent Class Initialized
INFO - 2018-08-14 13:38:49 --> Controller Class Initialized
INFO - 2018-08-14 13:38:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 13:38:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 13:38:49 --> Pixel_Model class loaded
INFO - 2018-08-14 13:38:49 --> Database Driver Class Initialized
INFO - 2018-08-14 13:38:49 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:38:49 --> Form Validation Class Initialized
INFO - 2018-08-14 13:38:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 13:38:49 --> Database Driver Class Initialized
INFO - 2018-08-14 13:38:49 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:38:49 --> Config Class Initialized
INFO - 2018-08-14 13:38:49 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:38:49 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:38:49 --> Utf8 Class Initialized
INFO - 2018-08-14 13:38:49 --> URI Class Initialized
INFO - 2018-08-14 13:38:49 --> Router Class Initialized
INFO - 2018-08-14 13:38:49 --> Output Class Initialized
INFO - 2018-08-14 13:38:49 --> Security Class Initialized
DEBUG - 2018-08-14 13:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:38:49 --> CSRF cookie sent
INFO - 2018-08-14 13:38:49 --> Input Class Initialized
INFO - 2018-08-14 13:38:49 --> Language Class Initialized
INFO - 2018-08-14 13:38:49 --> Loader Class Initialized
INFO - 2018-08-14 13:38:49 --> Helper loaded: url_helper
INFO - 2018-08-14 13:38:49 --> Helper loaded: form_helper
INFO - 2018-08-14 13:38:49 --> Helper loaded: language_helper
DEBUG - 2018-08-14 13:38:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:38:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:38:49 --> User Agent Class Initialized
INFO - 2018-08-14 13:38:49 --> Controller Class Initialized
INFO - 2018-08-14 13:38:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 13:38:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 13:38:49 --> Pixel_Model class loaded
INFO - 2018-08-14 13:38:49 --> Database Driver Class Initialized
INFO - 2018-08-14 13:38:49 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:38:49 --> Database Driver Class Initialized
INFO - 2018-08-14 13:38:49 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:38:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 13:38:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 13:38:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 13:38:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 13:38:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 13:38:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 13:38:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-08-14 13:38:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 13:38:49 --> Final output sent to browser
DEBUG - 2018-08-14 13:38:49 --> Total execution time: 0.0409
INFO - 2018-08-14 13:39:27 --> Config Class Initialized
INFO - 2018-08-14 13:39:27 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:39:27 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:39:27 --> Utf8 Class Initialized
INFO - 2018-08-14 13:39:28 --> URI Class Initialized
INFO - 2018-08-14 13:39:28 --> Router Class Initialized
INFO - 2018-08-14 13:39:28 --> Output Class Initialized
INFO - 2018-08-14 13:39:28 --> Security Class Initialized
DEBUG - 2018-08-14 13:39:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:39:28 --> CSRF cookie sent
INFO - 2018-08-14 13:39:28 --> CSRF token verified
INFO - 2018-08-14 13:39:28 --> Input Class Initialized
INFO - 2018-08-14 13:39:28 --> Language Class Initialized
INFO - 2018-08-14 13:39:28 --> Loader Class Initialized
INFO - 2018-08-14 13:39:28 --> Helper loaded: url_helper
INFO - 2018-08-14 13:39:28 --> Helper loaded: form_helper
INFO - 2018-08-14 13:39:28 --> Helper loaded: language_helper
DEBUG - 2018-08-14 13:39:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:39:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:39:28 --> User Agent Class Initialized
INFO - 2018-08-14 13:39:28 --> Controller Class Initialized
INFO - 2018-08-14 13:39:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 13:39:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 13:39:28 --> Pixel_Model class loaded
INFO - 2018-08-14 13:39:28 --> Database Driver Class Initialized
INFO - 2018-08-14 13:39:28 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:39:28 --> Form Validation Class Initialized
INFO - 2018-08-14 13:39:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 13:39:28 --> Database Driver Class Initialized
INFO - 2018-08-14 13:39:28 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:39:28 --> Config Class Initialized
INFO - 2018-08-14 13:39:28 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:39:28 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:39:28 --> Utf8 Class Initialized
INFO - 2018-08-14 13:39:28 --> URI Class Initialized
INFO - 2018-08-14 13:39:28 --> Router Class Initialized
INFO - 2018-08-14 13:39:28 --> Output Class Initialized
INFO - 2018-08-14 13:39:28 --> Security Class Initialized
DEBUG - 2018-08-14 13:39:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:39:28 --> CSRF cookie sent
INFO - 2018-08-14 13:39:28 --> Input Class Initialized
INFO - 2018-08-14 13:39:28 --> Language Class Initialized
INFO - 2018-08-14 13:39:28 --> Loader Class Initialized
INFO - 2018-08-14 13:39:28 --> Helper loaded: url_helper
INFO - 2018-08-14 13:39:28 --> Helper loaded: form_helper
INFO - 2018-08-14 13:39:28 --> Helper loaded: language_helper
DEBUG - 2018-08-14 13:39:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:39:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:39:28 --> User Agent Class Initialized
INFO - 2018-08-14 13:39:28 --> Controller Class Initialized
INFO - 2018-08-14 13:39:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 13:39:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 13:39:28 --> Pixel_Model class loaded
INFO - 2018-08-14 13:39:28 --> Database Driver Class Initialized
INFO - 2018-08-14 13:39:28 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:39:28 --> Database Driver Class Initialized
INFO - 2018-08-14 13:39:28 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:39:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 13:39:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 13:39:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 13:39:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 13:39:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 13:39:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 13:39:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-08-14 13:39:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 13:39:28 --> Final output sent to browser
DEBUG - 2018-08-14 13:39:28 --> Total execution time: 0.0612
INFO - 2018-08-14 13:39:41 --> Config Class Initialized
INFO - 2018-08-14 13:39:41 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:39:41 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:39:41 --> Utf8 Class Initialized
INFO - 2018-08-14 13:39:41 --> URI Class Initialized
INFO - 2018-08-14 13:39:41 --> Router Class Initialized
INFO - 2018-08-14 13:39:41 --> Output Class Initialized
INFO - 2018-08-14 13:39:41 --> Security Class Initialized
DEBUG - 2018-08-14 13:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:39:41 --> CSRF cookie sent
INFO - 2018-08-14 13:39:41 --> Input Class Initialized
INFO - 2018-08-14 13:39:41 --> Language Class Initialized
INFO - 2018-08-14 13:39:41 --> Loader Class Initialized
INFO - 2018-08-14 13:39:41 --> Helper loaded: url_helper
INFO - 2018-08-14 13:39:41 --> Helper loaded: form_helper
INFO - 2018-08-14 13:39:41 --> Helper loaded: language_helper
DEBUG - 2018-08-14 13:39:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:39:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:39:41 --> User Agent Class Initialized
INFO - 2018-08-14 13:39:41 --> Controller Class Initialized
INFO - 2018-08-14 13:39:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 13:39:41 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-08-14 13:39:41 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-08-14 13:39:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 13:39:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 13:39:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 13:39:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-08-14 13:39:41 --> Could not find the language line "req_email"
INFO - 2018-08-14 13:39:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-08-14 13:39:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 13:39:41 --> Final output sent to browser
DEBUG - 2018-08-14 13:39:41 --> Total execution time: 0.0356
INFO - 2018-08-14 13:39:45 --> Config Class Initialized
INFO - 2018-08-14 13:39:45 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:39:45 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:39:45 --> Utf8 Class Initialized
INFO - 2018-08-14 13:39:45 --> URI Class Initialized
INFO - 2018-08-14 13:39:45 --> Router Class Initialized
INFO - 2018-08-14 13:39:45 --> Output Class Initialized
INFO - 2018-08-14 13:39:45 --> Security Class Initialized
DEBUG - 2018-08-14 13:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:39:45 --> CSRF cookie sent
INFO - 2018-08-14 13:39:45 --> Input Class Initialized
INFO - 2018-08-14 13:39:45 --> Language Class Initialized
INFO - 2018-08-14 13:39:45 --> Loader Class Initialized
INFO - 2018-08-14 13:39:45 --> Helper loaded: url_helper
INFO - 2018-08-14 13:39:45 --> Helper loaded: form_helper
INFO - 2018-08-14 13:39:45 --> Helper loaded: language_helper
DEBUG - 2018-08-14 13:39:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:39:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:39:45 --> User Agent Class Initialized
INFO - 2018-08-14 13:39:45 --> Controller Class Initialized
INFO - 2018-08-14 13:39:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 13:39:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 13:39:45 --> Pixel_Model class loaded
INFO - 2018-08-14 13:39:45 --> Database Driver Class Initialized
INFO - 2018-08-14 13:39:45 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:39:45 --> Database Driver Class Initialized
INFO - 2018-08-14 13:39:45 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:39:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 13:39:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 13:39:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 13:39:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 13:39:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-08-14 13:39:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 13:39:45 --> Final output sent to browser
DEBUG - 2018-08-14 13:39:45 --> Total execution time: 0.0446
INFO - 2018-08-14 13:39:52 --> Config Class Initialized
INFO - 2018-08-14 13:39:52 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:39:52 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:39:52 --> Utf8 Class Initialized
INFO - 2018-08-14 13:39:52 --> URI Class Initialized
INFO - 2018-08-14 13:39:52 --> Router Class Initialized
INFO - 2018-08-14 13:39:52 --> Output Class Initialized
INFO - 2018-08-14 13:39:52 --> Security Class Initialized
DEBUG - 2018-08-14 13:39:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:39:52 --> CSRF cookie sent
INFO - 2018-08-14 13:39:52 --> CSRF token verified
INFO - 2018-08-14 13:39:52 --> Input Class Initialized
INFO - 2018-08-14 13:39:52 --> Language Class Initialized
INFO - 2018-08-14 13:39:52 --> Loader Class Initialized
INFO - 2018-08-14 13:39:52 --> Helper loaded: url_helper
INFO - 2018-08-14 13:39:52 --> Helper loaded: form_helper
INFO - 2018-08-14 13:39:52 --> Helper loaded: language_helper
DEBUG - 2018-08-14 13:39:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:39:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:39:52 --> User Agent Class Initialized
INFO - 2018-08-14 13:39:52 --> Controller Class Initialized
INFO - 2018-08-14 13:39:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 13:39:52 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-08-14 13:39:52 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-08-14 13:39:53 --> Form Validation Class Initialized
INFO - 2018-08-14 13:39:53 --> Pixel_Model class loaded
INFO - 2018-08-14 13:39:53 --> Database Driver Class Initialized
INFO - 2018-08-14 13:39:53 --> Model "AuthenticationModel" initialized
INFO - 2018-08-14 13:39:53 --> Config Class Initialized
INFO - 2018-08-14 13:39:53 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:39:53 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:39:53 --> Utf8 Class Initialized
INFO - 2018-08-14 13:39:53 --> URI Class Initialized
DEBUG - 2018-08-14 13:39:53 --> No URI present. Default controller set.
INFO - 2018-08-14 13:39:53 --> Router Class Initialized
INFO - 2018-08-14 13:39:53 --> Output Class Initialized
INFO - 2018-08-14 13:39:53 --> Security Class Initialized
DEBUG - 2018-08-14 13:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:39:53 --> CSRF cookie sent
INFO - 2018-08-14 13:39:53 --> Input Class Initialized
INFO - 2018-08-14 13:39:53 --> Language Class Initialized
INFO - 2018-08-14 13:39:53 --> Loader Class Initialized
INFO - 2018-08-14 13:39:53 --> Helper loaded: url_helper
INFO - 2018-08-14 13:39:53 --> Helper loaded: form_helper
INFO - 2018-08-14 13:39:53 --> Helper loaded: language_helper
DEBUG - 2018-08-14 13:39:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:39:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:39:53 --> User Agent Class Initialized
INFO - 2018-08-14 13:39:53 --> Controller Class Initialized
INFO - 2018-08-14 13:39:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 13:39:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 13:39:53 --> Pixel_Model class loaded
INFO - 2018-08-14 13:39:53 --> Database Driver Class Initialized
INFO - 2018-08-14 13:39:53 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:39:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 13:39:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-08-14 13:39:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 13:39:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-14 13:39:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 13:39:53 --> Final output sent to browser
DEBUG - 2018-08-14 13:39:53 --> Total execution time: 0.0339
INFO - 2018-08-14 13:39:54 --> Config Class Initialized
INFO - 2018-08-14 13:39:54 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:39:54 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:39:54 --> Utf8 Class Initialized
INFO - 2018-08-14 13:39:54 --> URI Class Initialized
INFO - 2018-08-14 13:39:54 --> Router Class Initialized
INFO - 2018-08-14 13:39:54 --> Output Class Initialized
INFO - 2018-08-14 13:39:54 --> Security Class Initialized
DEBUG - 2018-08-14 13:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:39:54 --> CSRF cookie sent
INFO - 2018-08-14 13:39:54 --> Input Class Initialized
INFO - 2018-08-14 13:39:54 --> Language Class Initialized
INFO - 2018-08-14 13:39:54 --> Loader Class Initialized
INFO - 2018-08-14 13:39:54 --> Helper loaded: url_helper
INFO - 2018-08-14 13:39:54 --> Helper loaded: form_helper
INFO - 2018-08-14 13:39:54 --> Helper loaded: language_helper
DEBUG - 2018-08-14 13:39:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:39:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:39:54 --> User Agent Class Initialized
INFO - 2018-08-14 13:39:54 --> Controller Class Initialized
INFO - 2018-08-14 13:39:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 13:39:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 13:39:54 --> Pixel_Model class loaded
INFO - 2018-08-14 13:39:54 --> Database Driver Class Initialized
INFO - 2018-08-14 13:39:54 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:39:54 --> Database Driver Class Initialized
INFO - 2018-08-14 13:39:54 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:39:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 13:39:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 13:39:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 13:39:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 13:39:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 13:39:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 13:39:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-08-14 13:39:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 13:39:54 --> Final output sent to browser
DEBUG - 2018-08-14 13:39:54 --> Total execution time: 0.0458
INFO - 2018-08-14 13:39:58 --> Config Class Initialized
INFO - 2018-08-14 13:39:58 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:39:58 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:39:58 --> Utf8 Class Initialized
INFO - 2018-08-14 13:39:58 --> URI Class Initialized
INFO - 2018-08-14 13:39:58 --> Router Class Initialized
INFO - 2018-08-14 13:39:58 --> Output Class Initialized
INFO - 2018-08-14 13:39:58 --> Security Class Initialized
DEBUG - 2018-08-14 13:39:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:39:58 --> CSRF cookie sent
INFO - 2018-08-14 13:39:58 --> Input Class Initialized
INFO - 2018-08-14 13:39:58 --> Language Class Initialized
INFO - 2018-08-14 13:39:58 --> Loader Class Initialized
INFO - 2018-08-14 13:39:58 --> Helper loaded: url_helper
INFO - 2018-08-14 13:39:58 --> Helper loaded: form_helper
INFO - 2018-08-14 13:39:58 --> Helper loaded: language_helper
DEBUG - 2018-08-14 13:39:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:39:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:39:58 --> User Agent Class Initialized
INFO - 2018-08-14 13:39:58 --> Controller Class Initialized
INFO - 2018-08-14 13:39:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 13:39:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 13:39:58 --> Pixel_Model class loaded
INFO - 2018-08-14 13:39:58 --> Database Driver Class Initialized
INFO - 2018-08-14 13:39:58 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:39:58 --> Database Driver Class Initialized
INFO - 2018-08-14 13:39:58 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:39:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 13:39:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 13:39:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 13:39:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 13:39:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 13:39:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 13:39:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-08-14 13:39:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 13:39:58 --> Final output sent to browser
DEBUG - 2018-08-14 13:39:58 --> Total execution time: 0.0443
INFO - 2018-08-14 13:56:08 --> Config Class Initialized
INFO - 2018-08-14 13:56:08 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:56:08 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:56:08 --> Utf8 Class Initialized
INFO - 2018-08-14 13:56:08 --> URI Class Initialized
INFO - 2018-08-14 13:56:08 --> Router Class Initialized
INFO - 2018-08-14 13:56:08 --> Output Class Initialized
INFO - 2018-08-14 13:56:08 --> Security Class Initialized
DEBUG - 2018-08-14 13:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:56:08 --> CSRF cookie sent
INFO - 2018-08-14 13:56:08 --> Input Class Initialized
INFO - 2018-08-14 13:56:08 --> Language Class Initialized
ERROR - 2018-08-14 13:56:08 --> 404 Page Not Found: 401shtml/index
INFO - 2018-08-14 13:56:09 --> Config Class Initialized
INFO - 2018-08-14 13:56:09 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:56:09 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:56:09 --> Utf8 Class Initialized
INFO - 2018-08-14 13:56:09 --> URI Class Initialized
INFO - 2018-08-14 13:56:09 --> Router Class Initialized
INFO - 2018-08-14 13:56:09 --> Output Class Initialized
INFO - 2018-08-14 13:56:09 --> Security Class Initialized
DEBUG - 2018-08-14 13:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:56:09 --> CSRF cookie sent
INFO - 2018-08-14 13:56:09 --> Input Class Initialized
INFO - 2018-08-14 13:56:09 --> Language Class Initialized
ERROR - 2018-08-14 13:56:09 --> 404 Page Not Found: 401shtml/index
INFO - 2018-08-14 13:56:09 --> Config Class Initialized
INFO - 2018-08-14 13:56:09 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:56:09 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:56:09 --> Utf8 Class Initialized
INFO - 2018-08-14 13:56:09 --> URI Class Initialized
INFO - 2018-08-14 13:56:09 --> Router Class Initialized
INFO - 2018-08-14 13:56:09 --> Output Class Initialized
INFO - 2018-08-14 13:56:09 --> Security Class Initialized
DEBUG - 2018-08-14 13:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:56:09 --> CSRF cookie sent
INFO - 2018-08-14 13:56:09 --> Input Class Initialized
INFO - 2018-08-14 13:56:09 --> Language Class Initialized
ERROR - 2018-08-14 13:56:09 --> 404 Page Not Found: Faviconico/index
INFO - 2018-08-14 13:56:14 --> Config Class Initialized
INFO - 2018-08-14 13:56:14 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:56:14 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:56:14 --> Utf8 Class Initialized
INFO - 2018-08-14 13:56:14 --> URI Class Initialized
INFO - 2018-08-14 13:56:14 --> Router Class Initialized
INFO - 2018-08-14 13:56:14 --> Output Class Initialized
INFO - 2018-08-14 13:56:14 --> Security Class Initialized
DEBUG - 2018-08-14 13:56:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:56:14 --> CSRF cookie sent
INFO - 2018-08-14 13:56:14 --> Input Class Initialized
INFO - 2018-08-14 13:56:14 --> Language Class Initialized
ERROR - 2018-08-14 13:56:14 --> 404 Page Not Found: Faviconico/index
INFO - 2018-08-14 13:56:16 --> Config Class Initialized
INFO - 2018-08-14 13:56:16 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:56:16 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:56:16 --> Utf8 Class Initialized
INFO - 2018-08-14 13:56:16 --> URI Class Initialized
INFO - 2018-08-14 13:56:16 --> Router Class Initialized
INFO - 2018-08-14 13:56:16 --> Output Class Initialized
INFO - 2018-08-14 13:56:16 --> Security Class Initialized
DEBUG - 2018-08-14 13:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:56:16 --> CSRF cookie sent
INFO - 2018-08-14 13:56:16 --> Input Class Initialized
INFO - 2018-08-14 13:56:16 --> Language Class Initialized
INFO - 2018-08-14 13:56:16 --> Loader Class Initialized
INFO - 2018-08-14 13:56:16 --> Helper loaded: url_helper
INFO - 2018-08-14 13:56:16 --> Helper loaded: form_helper
INFO - 2018-08-14 13:56:16 --> Helper loaded: language_helper
DEBUG - 2018-08-14 13:56:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:56:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:56:16 --> User Agent Class Initialized
INFO - 2018-08-14 13:56:16 --> Controller Class Initialized
INFO - 2018-08-14 13:56:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 13:56:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 13:56:16 --> Pixel_Model class loaded
INFO - 2018-08-14 13:56:16 --> Database Driver Class Initialized
INFO - 2018-08-14 13:56:16 --> Model "RegistrationModel" initialized
DEBUG - 2018-08-14 13:56:16 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-08-14 13:56:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 13:56:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 13:56:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 13:56:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 13:56:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/temp.php
INFO - 2018-08-14 13:56:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 13:56:16 --> Final output sent to browser
DEBUG - 2018-08-14 13:56:16 --> Total execution time: 0.0383
INFO - 2018-08-14 13:56:17 --> Config Class Initialized
INFO - 2018-08-14 13:56:17 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:56:17 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:56:17 --> Utf8 Class Initialized
INFO - 2018-08-14 13:56:17 --> URI Class Initialized
DEBUG - 2018-08-14 13:56:17 --> No URI present. Default controller set.
INFO - 2018-08-14 13:56:17 --> Router Class Initialized
INFO - 2018-08-14 13:56:17 --> Output Class Initialized
INFO - 2018-08-14 13:56:17 --> Security Class Initialized
DEBUG - 2018-08-14 13:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:56:17 --> CSRF cookie sent
INFO - 2018-08-14 13:56:17 --> Input Class Initialized
INFO - 2018-08-14 13:56:17 --> Language Class Initialized
INFO - 2018-08-14 13:56:17 --> Loader Class Initialized
INFO - 2018-08-14 13:56:17 --> Helper loaded: url_helper
INFO - 2018-08-14 13:56:17 --> Helper loaded: form_helper
INFO - 2018-08-14 13:56:17 --> Helper loaded: language_helper
DEBUG - 2018-08-14 13:56:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:56:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:56:17 --> User Agent Class Initialized
INFO - 2018-08-14 13:56:17 --> Controller Class Initialized
INFO - 2018-08-14 13:56:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 13:56:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 13:56:17 --> Pixel_Model class loaded
INFO - 2018-08-14 13:56:17 --> Database Driver Class Initialized
INFO - 2018-08-14 13:56:17 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:56:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 13:56:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 13:56:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-14 13:56:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 13:56:17 --> Final output sent to browser
DEBUG - 2018-08-14 13:56:17 --> Total execution time: 0.0344
INFO - 2018-08-14 13:56:19 --> Config Class Initialized
INFO - 2018-08-14 13:56:19 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:56:19 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:56:19 --> Utf8 Class Initialized
INFO - 2018-08-14 13:56:19 --> URI Class Initialized
DEBUG - 2018-08-14 13:56:19 --> No URI present. Default controller set.
INFO - 2018-08-14 13:56:19 --> Router Class Initialized
INFO - 2018-08-14 13:56:19 --> Output Class Initialized
INFO - 2018-08-14 13:56:19 --> Security Class Initialized
DEBUG - 2018-08-14 13:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:56:19 --> CSRF cookie sent
INFO - 2018-08-14 13:56:19 --> Input Class Initialized
INFO - 2018-08-14 13:56:19 --> Language Class Initialized
INFO - 2018-08-14 13:56:19 --> Loader Class Initialized
INFO - 2018-08-14 13:56:19 --> Helper loaded: url_helper
INFO - 2018-08-14 13:56:19 --> Helper loaded: form_helper
INFO - 2018-08-14 13:56:19 --> Helper loaded: language_helper
DEBUG - 2018-08-14 13:56:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:56:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:56:19 --> User Agent Class Initialized
INFO - 2018-08-14 13:56:19 --> Controller Class Initialized
INFO - 2018-08-14 13:56:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 13:56:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 13:56:19 --> Pixel_Model class loaded
INFO - 2018-08-14 13:56:19 --> Database Driver Class Initialized
INFO - 2018-08-14 13:56:19 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:56:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 13:56:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 13:56:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-14 13:56:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 13:56:19 --> Final output sent to browser
DEBUG - 2018-08-14 13:56:19 --> Total execution time: 0.0366
INFO - 2018-08-14 13:57:01 --> Config Class Initialized
INFO - 2018-08-14 13:57:01 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:57:01 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:57:01 --> Utf8 Class Initialized
INFO - 2018-08-14 13:57:01 --> URI Class Initialized
INFO - 2018-08-14 13:57:01 --> Router Class Initialized
INFO - 2018-08-14 13:57:01 --> Output Class Initialized
INFO - 2018-08-14 13:57:01 --> Security Class Initialized
DEBUG - 2018-08-14 13:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:57:01 --> CSRF cookie sent
INFO - 2018-08-14 13:57:01 --> Input Class Initialized
INFO - 2018-08-14 13:57:01 --> Language Class Initialized
INFO - 2018-08-14 13:57:01 --> Loader Class Initialized
INFO - 2018-08-14 13:57:01 --> Helper loaded: url_helper
INFO - 2018-08-14 13:57:01 --> Helper loaded: form_helper
INFO - 2018-08-14 13:57:01 --> Helper loaded: language_helper
DEBUG - 2018-08-14 13:57:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:57:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:57:01 --> User Agent Class Initialized
INFO - 2018-08-14 13:57:01 --> Controller Class Initialized
INFO - 2018-08-14 13:57:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 13:57:01 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-08-14 13:57:01 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-08-14 13:57:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 13:57:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 13:57:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 13:57:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-08-14 13:57:01 --> Could not find the language line "req_email"
INFO - 2018-08-14 13:57:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-08-14 13:57:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 13:57:01 --> Final output sent to browser
DEBUG - 2018-08-14 13:57:01 --> Total execution time: 0.0226
INFO - 2018-08-14 13:57:26 --> Config Class Initialized
INFO - 2018-08-14 13:57:26 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:57:26 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:57:26 --> Utf8 Class Initialized
INFO - 2018-08-14 13:57:26 --> URI Class Initialized
INFO - 2018-08-14 13:57:26 --> Router Class Initialized
INFO - 2018-08-14 13:57:26 --> Output Class Initialized
INFO - 2018-08-14 13:57:26 --> Security Class Initialized
DEBUG - 2018-08-14 13:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:57:26 --> CSRF cookie sent
INFO - 2018-08-14 13:57:26 --> CSRF token verified
INFO - 2018-08-14 13:57:26 --> Input Class Initialized
INFO - 2018-08-14 13:57:26 --> Language Class Initialized
INFO - 2018-08-14 13:57:26 --> Loader Class Initialized
INFO - 2018-08-14 13:57:26 --> Helper loaded: url_helper
INFO - 2018-08-14 13:57:26 --> Helper loaded: form_helper
INFO - 2018-08-14 13:57:26 --> Helper loaded: language_helper
DEBUG - 2018-08-14 13:57:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:57:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:57:26 --> User Agent Class Initialized
INFO - 2018-08-14 13:57:26 --> Controller Class Initialized
INFO - 2018-08-14 13:57:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 13:57:26 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-08-14 13:57:26 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-08-14 13:57:26 --> Form Validation Class Initialized
INFO - 2018-08-14 13:57:26 --> Pixel_Model class loaded
INFO - 2018-08-14 13:57:26 --> Database Driver Class Initialized
INFO - 2018-08-14 13:57:26 --> Model "AuthenticationModel" initialized
INFO - 2018-08-14 13:57:27 --> Config Class Initialized
INFO - 2018-08-14 13:57:27 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:57:27 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:57:27 --> Utf8 Class Initialized
INFO - 2018-08-14 13:57:27 --> URI Class Initialized
DEBUG - 2018-08-14 13:57:27 --> No URI present. Default controller set.
INFO - 2018-08-14 13:57:27 --> Router Class Initialized
INFO - 2018-08-14 13:57:27 --> Output Class Initialized
INFO - 2018-08-14 13:57:27 --> Security Class Initialized
DEBUG - 2018-08-14 13:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:57:27 --> CSRF cookie sent
INFO - 2018-08-14 13:57:27 --> Input Class Initialized
INFO - 2018-08-14 13:57:27 --> Language Class Initialized
INFO - 2018-08-14 13:57:27 --> Loader Class Initialized
INFO - 2018-08-14 13:57:27 --> Helper loaded: url_helper
INFO - 2018-08-14 13:57:27 --> Helper loaded: form_helper
INFO - 2018-08-14 13:57:27 --> Helper loaded: language_helper
DEBUG - 2018-08-14 13:57:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:57:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:57:27 --> User Agent Class Initialized
INFO - 2018-08-14 13:57:27 --> Controller Class Initialized
INFO - 2018-08-14 13:57:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 13:57:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 13:57:27 --> Pixel_Model class loaded
INFO - 2018-08-14 13:57:27 --> Database Driver Class Initialized
INFO - 2018-08-14 13:57:27 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:57:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 13:57:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-14 13:57:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 13:57:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-14 13:57:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 13:57:27 --> Final output sent to browser
DEBUG - 2018-08-14 13:57:27 --> Total execution time: 0.0503
INFO - 2018-08-14 13:57:31 --> Config Class Initialized
INFO - 2018-08-14 13:57:31 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:57:31 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:57:31 --> Utf8 Class Initialized
INFO - 2018-08-14 13:57:31 --> URI Class Initialized
INFO - 2018-08-14 13:57:31 --> Router Class Initialized
INFO - 2018-08-14 13:57:31 --> Output Class Initialized
INFO - 2018-08-14 13:57:31 --> Security Class Initialized
DEBUG - 2018-08-14 13:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:57:31 --> CSRF cookie sent
INFO - 2018-08-14 13:57:31 --> Input Class Initialized
INFO - 2018-08-14 13:57:31 --> Language Class Initialized
INFO - 2018-08-14 13:57:31 --> Loader Class Initialized
INFO - 2018-08-14 13:57:31 --> Helper loaded: url_helper
INFO - 2018-08-14 13:57:31 --> Helper loaded: form_helper
INFO - 2018-08-14 13:57:31 --> Helper loaded: language_helper
DEBUG - 2018-08-14 13:57:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:57:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:57:31 --> User Agent Class Initialized
INFO - 2018-08-14 13:57:31 --> Controller Class Initialized
INFO - 2018-08-14 13:57:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 13:57:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 13:57:31 --> Pixel_Model class loaded
INFO - 2018-08-14 13:57:31 --> Database Driver Class Initialized
INFO - 2018-08-14 13:57:31 --> Model "MyAccountModel" initialized
INFO - 2018-08-14 13:57:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 13:57:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-14 13:57:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 13:57:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 13:57:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 13:57:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/application_list.php
INFO - 2018-08-14 13:57:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 13:57:31 --> Final output sent to browser
DEBUG - 2018-08-14 13:57:31 --> Total execution time: 0.0539
INFO - 2018-08-14 13:57:33 --> Config Class Initialized
INFO - 2018-08-14 13:57:33 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:57:33 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:57:33 --> Utf8 Class Initialized
INFO - 2018-08-14 13:57:33 --> URI Class Initialized
INFO - 2018-08-14 13:57:33 --> Router Class Initialized
INFO - 2018-08-14 13:57:33 --> Output Class Initialized
INFO - 2018-08-14 13:57:33 --> Security Class Initialized
DEBUG - 2018-08-14 13:57:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:57:33 --> CSRF cookie sent
INFO - 2018-08-14 13:57:33 --> Input Class Initialized
INFO - 2018-08-14 13:57:33 --> Language Class Initialized
INFO - 2018-08-14 13:57:33 --> Loader Class Initialized
INFO - 2018-08-14 13:57:33 --> Helper loaded: url_helper
INFO - 2018-08-14 13:57:33 --> Helper loaded: form_helper
INFO - 2018-08-14 13:57:33 --> Helper loaded: language_helper
DEBUG - 2018-08-14 13:57:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:57:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:57:33 --> User Agent Class Initialized
INFO - 2018-08-14 13:57:33 --> Controller Class Initialized
INFO - 2018-08-14 13:57:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 13:57:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 13:57:33 --> Pixel_Model class loaded
INFO - 2018-08-14 13:57:33 --> Database Driver Class Initialized
INFO - 2018-08-14 13:57:33 --> Model "MyAccountModel" initialized
INFO - 2018-08-14 13:57:33 --> Config Class Initialized
INFO - 2018-08-14 13:57:33 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:57:33 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:57:33 --> Utf8 Class Initialized
INFO - 2018-08-14 13:57:33 --> URI Class Initialized
INFO - 2018-08-14 13:57:33 --> Router Class Initialized
INFO - 2018-08-14 13:57:33 --> Output Class Initialized
INFO - 2018-08-14 13:57:33 --> Security Class Initialized
DEBUG - 2018-08-14 13:57:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:57:33 --> CSRF cookie sent
INFO - 2018-08-14 13:57:33 --> Input Class Initialized
INFO - 2018-08-14 13:57:33 --> Language Class Initialized
INFO - 2018-08-14 13:57:33 --> Loader Class Initialized
INFO - 2018-08-14 13:57:33 --> Helper loaded: url_helper
INFO - 2018-08-14 13:57:33 --> Helper loaded: form_helper
INFO - 2018-08-14 13:57:33 --> Helper loaded: language_helper
DEBUG - 2018-08-14 13:57:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:57:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:57:33 --> User Agent Class Initialized
INFO - 2018-08-14 13:57:33 --> Controller Class Initialized
INFO - 2018-08-14 13:57:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 13:57:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 13:57:33 --> Pixel_Model class loaded
INFO - 2018-08-14 13:57:33 --> Database Driver Class Initialized
INFO - 2018-08-14 13:57:33 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:57:33 --> Database Driver Class Initialized
INFO - 2018-08-14 13:57:33 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:57:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 13:57:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-14 13:57:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 13:57:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 13:57:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 13:57:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 13:57:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 13:57:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-08-14 13:57:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 13:57:33 --> Final output sent to browser
DEBUG - 2018-08-14 13:57:33 --> Total execution time: 0.0464
INFO - 2018-08-14 13:57:39 --> Config Class Initialized
INFO - 2018-08-14 13:57:39 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:57:39 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:57:39 --> Utf8 Class Initialized
INFO - 2018-08-14 13:57:39 --> URI Class Initialized
INFO - 2018-08-14 13:57:39 --> Router Class Initialized
INFO - 2018-08-14 13:57:39 --> Output Class Initialized
INFO - 2018-08-14 13:57:39 --> Security Class Initialized
DEBUG - 2018-08-14 13:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:57:39 --> CSRF cookie sent
INFO - 2018-08-14 13:57:39 --> Input Class Initialized
INFO - 2018-08-14 13:57:39 --> Language Class Initialized
INFO - 2018-08-14 13:57:39 --> Loader Class Initialized
INFO - 2018-08-14 13:57:39 --> Helper loaded: url_helper
INFO - 2018-08-14 13:57:39 --> Helper loaded: form_helper
INFO - 2018-08-14 13:57:39 --> Helper loaded: language_helper
DEBUG - 2018-08-14 13:57:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:57:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:57:39 --> User Agent Class Initialized
INFO - 2018-08-14 13:57:39 --> Controller Class Initialized
INFO - 2018-08-14 13:57:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 13:57:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 13:57:39 --> Pixel_Model class loaded
INFO - 2018-08-14 13:57:39 --> Database Driver Class Initialized
INFO - 2018-08-14 13:57:39 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:57:39 --> Database Driver Class Initialized
INFO - 2018-08-14 13:57:39 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:57:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 13:57:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-14 13:57:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 13:57:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 13:57:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 13:57:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 13:57:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 13:57:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-08-14 13:57:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 13:57:39 --> Final output sent to browser
DEBUG - 2018-08-14 13:57:39 --> Total execution time: 0.0453
INFO - 2018-08-14 13:57:46 --> Config Class Initialized
INFO - 2018-08-14 13:57:46 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:57:46 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:57:46 --> Utf8 Class Initialized
INFO - 2018-08-14 13:57:46 --> URI Class Initialized
INFO - 2018-08-14 13:57:46 --> Router Class Initialized
INFO - 2018-08-14 13:57:46 --> Output Class Initialized
INFO - 2018-08-14 13:57:46 --> Security Class Initialized
DEBUG - 2018-08-14 13:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:57:46 --> CSRF cookie sent
INFO - 2018-08-14 13:57:46 --> Input Class Initialized
INFO - 2018-08-14 13:57:46 --> Language Class Initialized
INFO - 2018-08-14 13:57:46 --> Loader Class Initialized
INFO - 2018-08-14 13:57:46 --> Helper loaded: url_helper
INFO - 2018-08-14 13:57:46 --> Helper loaded: form_helper
INFO - 2018-08-14 13:57:46 --> Helper loaded: language_helper
DEBUG - 2018-08-14 13:57:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:57:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:57:46 --> User Agent Class Initialized
INFO - 2018-08-14 13:57:46 --> Controller Class Initialized
INFO - 2018-08-14 13:57:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 13:57:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 13:57:46 --> Pixel_Model class loaded
INFO - 2018-08-14 13:57:46 --> Database Driver Class Initialized
INFO - 2018-08-14 13:57:46 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:57:46 --> Database Driver Class Initialized
INFO - 2018-08-14 13:57:46 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:57:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 13:57:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-14 13:57:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 13:57:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 13:57:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 13:57:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 13:57:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 13:57:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-08-14 13:57:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 13:57:46 --> Final output sent to browser
DEBUG - 2018-08-14 13:57:46 --> Total execution time: 0.0556
INFO - 2018-08-14 13:57:50 --> Config Class Initialized
INFO - 2018-08-14 13:57:50 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:57:50 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:57:50 --> Utf8 Class Initialized
INFO - 2018-08-14 13:57:50 --> URI Class Initialized
INFO - 2018-08-14 13:57:50 --> Router Class Initialized
INFO - 2018-08-14 13:57:50 --> Output Class Initialized
INFO - 2018-08-14 13:57:50 --> Security Class Initialized
DEBUG - 2018-08-14 13:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:57:50 --> CSRF cookie sent
INFO - 2018-08-14 13:57:50 --> Input Class Initialized
INFO - 2018-08-14 13:57:50 --> Language Class Initialized
INFO - 2018-08-14 13:57:50 --> Loader Class Initialized
INFO - 2018-08-14 13:57:50 --> Helper loaded: url_helper
INFO - 2018-08-14 13:57:50 --> Helper loaded: form_helper
INFO - 2018-08-14 13:57:50 --> Helper loaded: language_helper
DEBUG - 2018-08-14 13:57:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:57:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:57:50 --> User Agent Class Initialized
INFO - 2018-08-14 13:57:50 --> Controller Class Initialized
INFO - 2018-08-14 13:57:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 13:57:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 13:57:50 --> Pixel_Model class loaded
INFO - 2018-08-14 13:57:50 --> Database Driver Class Initialized
INFO - 2018-08-14 13:57:50 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:57:50 --> Database Driver Class Initialized
INFO - 2018-08-14 13:57:50 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:57:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 13:57:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-14 13:57:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 13:57:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 13:57:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 13:57:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 13:57:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 13:57:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-14 13:57:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 13:57:50 --> Final output sent to browser
DEBUG - 2018-08-14 13:57:50 --> Total execution time: 0.0520
INFO - 2018-08-14 13:57:52 --> Config Class Initialized
INFO - 2018-08-14 13:57:52 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:57:52 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:57:52 --> Utf8 Class Initialized
INFO - 2018-08-14 13:57:52 --> URI Class Initialized
INFO - 2018-08-14 13:57:52 --> Router Class Initialized
INFO - 2018-08-14 13:57:52 --> Output Class Initialized
INFO - 2018-08-14 13:57:52 --> Security Class Initialized
DEBUG - 2018-08-14 13:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:57:52 --> CSRF cookie sent
INFO - 2018-08-14 13:57:52 --> CSRF token verified
INFO - 2018-08-14 13:57:52 --> Input Class Initialized
INFO - 2018-08-14 13:57:52 --> Language Class Initialized
INFO - 2018-08-14 13:57:52 --> Loader Class Initialized
INFO - 2018-08-14 13:57:52 --> Helper loaded: url_helper
INFO - 2018-08-14 13:57:52 --> Helper loaded: form_helper
INFO - 2018-08-14 13:57:52 --> Helper loaded: language_helper
DEBUG - 2018-08-14 13:57:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:57:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:57:52 --> User Agent Class Initialized
INFO - 2018-08-14 13:57:52 --> Controller Class Initialized
INFO - 2018-08-14 13:57:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 13:57:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 13:57:52 --> Pixel_Model class loaded
INFO - 2018-08-14 13:57:52 --> Database Driver Class Initialized
INFO - 2018-08-14 13:57:52 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:57:52 --> Form Validation Class Initialized
INFO - 2018-08-14 13:57:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 13:57:52 --> Database Driver Class Initialized
INFO - 2018-08-14 13:57:52 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:57:52 --> Config Class Initialized
INFO - 2018-08-14 13:57:52 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:57:52 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:57:52 --> Utf8 Class Initialized
INFO - 2018-08-14 13:57:52 --> URI Class Initialized
INFO - 2018-08-14 13:57:52 --> Router Class Initialized
INFO - 2018-08-14 13:57:52 --> Output Class Initialized
INFO - 2018-08-14 13:57:52 --> Security Class Initialized
DEBUG - 2018-08-14 13:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:57:52 --> CSRF cookie sent
INFO - 2018-08-14 13:57:52 --> Input Class Initialized
INFO - 2018-08-14 13:57:52 --> Language Class Initialized
INFO - 2018-08-14 13:57:52 --> Loader Class Initialized
INFO - 2018-08-14 13:57:52 --> Helper loaded: url_helper
INFO - 2018-08-14 13:57:52 --> Helper loaded: form_helper
INFO - 2018-08-14 13:57:52 --> Helper loaded: language_helper
DEBUG - 2018-08-14 13:57:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:57:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:57:52 --> User Agent Class Initialized
INFO - 2018-08-14 13:57:52 --> Controller Class Initialized
INFO - 2018-08-14 13:57:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 13:57:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 13:57:52 --> Pixel_Model class loaded
INFO - 2018-08-14 13:57:52 --> Database Driver Class Initialized
INFO - 2018-08-14 13:57:52 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:57:52 --> Database Driver Class Initialized
INFO - 2018-08-14 13:57:52 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:57:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 13:57:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-14 13:57:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 13:57:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 13:57:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 13:57:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 13:57:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 13:57:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-08-14 13:57:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 13:57:52 --> Final output sent to browser
DEBUG - 2018-08-14 13:57:52 --> Total execution time: 0.0595
INFO - 2018-08-14 13:57:56 --> Config Class Initialized
INFO - 2018-08-14 13:57:56 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:57:56 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:57:56 --> Utf8 Class Initialized
INFO - 2018-08-14 13:57:56 --> URI Class Initialized
INFO - 2018-08-14 13:57:56 --> Router Class Initialized
INFO - 2018-08-14 13:57:56 --> Output Class Initialized
INFO - 2018-08-14 13:57:56 --> Security Class Initialized
DEBUG - 2018-08-14 13:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:57:56 --> CSRF cookie sent
INFO - 2018-08-14 13:57:56 --> CSRF token verified
INFO - 2018-08-14 13:57:56 --> Input Class Initialized
INFO - 2018-08-14 13:57:56 --> Language Class Initialized
INFO - 2018-08-14 13:57:56 --> Loader Class Initialized
INFO - 2018-08-14 13:57:56 --> Helper loaded: url_helper
INFO - 2018-08-14 13:57:56 --> Helper loaded: form_helper
INFO - 2018-08-14 13:57:56 --> Helper loaded: language_helper
DEBUG - 2018-08-14 13:57:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:57:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:57:56 --> User Agent Class Initialized
INFO - 2018-08-14 13:57:56 --> Controller Class Initialized
INFO - 2018-08-14 13:57:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 13:57:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 13:57:56 --> Pixel_Model class loaded
INFO - 2018-08-14 13:57:56 --> Database Driver Class Initialized
INFO - 2018-08-14 13:57:56 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:57:56 --> Form Validation Class Initialized
INFO - 2018-08-14 13:57:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 13:57:56 --> Database Driver Class Initialized
INFO - 2018-08-14 13:57:56 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:57:56 --> Config Class Initialized
INFO - 2018-08-14 13:57:56 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:57:56 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:57:56 --> Utf8 Class Initialized
INFO - 2018-08-14 13:57:56 --> URI Class Initialized
INFO - 2018-08-14 13:57:56 --> Router Class Initialized
INFO - 2018-08-14 13:57:56 --> Output Class Initialized
INFO - 2018-08-14 13:57:56 --> Security Class Initialized
DEBUG - 2018-08-14 13:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:57:56 --> CSRF cookie sent
INFO - 2018-08-14 13:57:56 --> Input Class Initialized
INFO - 2018-08-14 13:57:56 --> Language Class Initialized
INFO - 2018-08-14 13:57:56 --> Loader Class Initialized
INFO - 2018-08-14 13:57:56 --> Helper loaded: url_helper
INFO - 2018-08-14 13:57:56 --> Helper loaded: form_helper
INFO - 2018-08-14 13:57:56 --> Helper loaded: language_helper
DEBUG - 2018-08-14 13:57:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:57:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:57:56 --> User Agent Class Initialized
INFO - 2018-08-14 13:57:56 --> Controller Class Initialized
INFO - 2018-08-14 13:57:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 13:57:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 13:57:56 --> Pixel_Model class loaded
INFO - 2018-08-14 13:57:56 --> Database Driver Class Initialized
INFO - 2018-08-14 13:57:56 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:57:56 --> Database Driver Class Initialized
INFO - 2018-08-14 13:57:56 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:57:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 13:57:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-14 13:57:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 13:57:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-08-14 13:57:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 13:57:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 13:57:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 13:57:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 13:57:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-08-14 13:57:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 13:57:56 --> Final output sent to browser
DEBUG - 2018-08-14 13:57:56 --> Total execution time: 0.0490
INFO - 2018-08-14 13:57:59 --> Config Class Initialized
INFO - 2018-08-14 13:57:59 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:57:59 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:57:59 --> Utf8 Class Initialized
INFO - 2018-08-14 13:57:59 --> URI Class Initialized
INFO - 2018-08-14 13:57:59 --> Router Class Initialized
INFO - 2018-08-14 13:57:59 --> Output Class Initialized
INFO - 2018-08-14 13:57:59 --> Security Class Initialized
DEBUG - 2018-08-14 13:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:57:59 --> CSRF cookie sent
INFO - 2018-08-14 13:57:59 --> CSRF token verified
INFO - 2018-08-14 13:57:59 --> Input Class Initialized
INFO - 2018-08-14 13:57:59 --> Language Class Initialized
INFO - 2018-08-14 13:57:59 --> Loader Class Initialized
INFO - 2018-08-14 13:57:59 --> Helper loaded: url_helper
INFO - 2018-08-14 13:57:59 --> Helper loaded: form_helper
INFO - 2018-08-14 13:57:59 --> Helper loaded: language_helper
DEBUG - 2018-08-14 13:57:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:57:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:57:59 --> User Agent Class Initialized
INFO - 2018-08-14 13:57:59 --> Controller Class Initialized
INFO - 2018-08-14 13:57:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 13:57:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 13:57:59 --> Pixel_Model class loaded
INFO - 2018-08-14 13:57:59 --> Database Driver Class Initialized
INFO - 2018-08-14 13:57:59 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:57:59 --> Form Validation Class Initialized
INFO - 2018-08-14 13:57:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 13:57:59 --> Database Driver Class Initialized
INFO - 2018-08-14 13:57:59 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:57:59 --> Config Class Initialized
INFO - 2018-08-14 13:57:59 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:57:59 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:57:59 --> Utf8 Class Initialized
INFO - 2018-08-14 13:57:59 --> URI Class Initialized
INFO - 2018-08-14 13:57:59 --> Router Class Initialized
INFO - 2018-08-14 13:57:59 --> Output Class Initialized
INFO - 2018-08-14 13:57:59 --> Security Class Initialized
DEBUG - 2018-08-14 13:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:57:59 --> CSRF cookie sent
INFO - 2018-08-14 13:57:59 --> Input Class Initialized
INFO - 2018-08-14 13:57:59 --> Language Class Initialized
INFO - 2018-08-14 13:57:59 --> Loader Class Initialized
INFO - 2018-08-14 13:57:59 --> Helper loaded: url_helper
INFO - 2018-08-14 13:57:59 --> Helper loaded: form_helper
INFO - 2018-08-14 13:57:59 --> Helper loaded: language_helper
DEBUG - 2018-08-14 13:57:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:57:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:57:59 --> User Agent Class Initialized
INFO - 2018-08-14 13:57:59 --> Controller Class Initialized
INFO - 2018-08-14 13:57:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 13:57:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 13:57:59 --> Pixel_Model class loaded
INFO - 2018-08-14 13:57:59 --> Database Driver Class Initialized
INFO - 2018-08-14 13:57:59 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:57:59 --> Database Driver Class Initialized
INFO - 2018-08-14 13:57:59 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:57:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 13:57:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-14 13:57:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 13:57:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 13:57:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 13:57:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 13:57:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 13:57:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-08-14 13:57:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 13:57:59 --> Final output sent to browser
DEBUG - 2018-08-14 13:57:59 --> Total execution time: 0.0382
INFO - 2018-08-14 13:58:02 --> Config Class Initialized
INFO - 2018-08-14 13:58:02 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:58:02 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:58:02 --> Utf8 Class Initialized
INFO - 2018-08-14 13:58:02 --> URI Class Initialized
INFO - 2018-08-14 13:58:02 --> Router Class Initialized
INFO - 2018-08-14 13:58:02 --> Output Class Initialized
INFO - 2018-08-14 13:58:02 --> Security Class Initialized
DEBUG - 2018-08-14 13:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:58:02 --> CSRF cookie sent
INFO - 2018-08-14 13:58:02 --> CSRF token verified
INFO - 2018-08-14 13:58:02 --> Input Class Initialized
INFO - 2018-08-14 13:58:02 --> Language Class Initialized
INFO - 2018-08-14 13:58:02 --> Loader Class Initialized
INFO - 2018-08-14 13:58:02 --> Helper loaded: url_helper
INFO - 2018-08-14 13:58:02 --> Helper loaded: form_helper
INFO - 2018-08-14 13:58:02 --> Helper loaded: language_helper
DEBUG - 2018-08-14 13:58:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:58:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:58:02 --> User Agent Class Initialized
INFO - 2018-08-14 13:58:02 --> Controller Class Initialized
INFO - 2018-08-14 13:58:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 13:58:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 13:58:02 --> Pixel_Model class loaded
INFO - 2018-08-14 13:58:02 --> Database Driver Class Initialized
INFO - 2018-08-14 13:58:02 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:58:02 --> Form Validation Class Initialized
INFO - 2018-08-14 13:58:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 13:58:02 --> Database Driver Class Initialized
INFO - 2018-08-14 13:58:02 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:58:02 --> Config Class Initialized
INFO - 2018-08-14 13:58:02 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:58:02 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:58:02 --> Utf8 Class Initialized
INFO - 2018-08-14 13:58:02 --> URI Class Initialized
INFO - 2018-08-14 13:58:02 --> Router Class Initialized
INFO - 2018-08-14 13:58:02 --> Output Class Initialized
INFO - 2018-08-14 13:58:02 --> Security Class Initialized
DEBUG - 2018-08-14 13:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:58:02 --> CSRF cookie sent
INFO - 2018-08-14 13:58:02 --> Input Class Initialized
INFO - 2018-08-14 13:58:02 --> Language Class Initialized
INFO - 2018-08-14 13:58:02 --> Loader Class Initialized
INFO - 2018-08-14 13:58:02 --> Helper loaded: url_helper
INFO - 2018-08-14 13:58:02 --> Helper loaded: form_helper
INFO - 2018-08-14 13:58:02 --> Helper loaded: language_helper
DEBUG - 2018-08-14 13:58:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:58:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:58:02 --> User Agent Class Initialized
INFO - 2018-08-14 13:58:02 --> Controller Class Initialized
INFO - 2018-08-14 13:58:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 13:58:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 13:58:02 --> Pixel_Model class loaded
INFO - 2018-08-14 13:58:02 --> Database Driver Class Initialized
INFO - 2018-08-14 13:58:02 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:58:02 --> Database Driver Class Initialized
INFO - 2018-08-14 13:58:02 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:58:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 13:58:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-14 13:58:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 13:58:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 13:58:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 13:58:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 13:58:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 13:58:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-08-14 13:58:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 13:58:02 --> Final output sent to browser
DEBUG - 2018-08-14 13:58:02 --> Total execution time: 0.0377
INFO - 2018-08-14 13:58:09 --> Config Class Initialized
INFO - 2018-08-14 13:58:09 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:58:09 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:58:09 --> Utf8 Class Initialized
INFO - 2018-08-14 13:58:09 --> URI Class Initialized
INFO - 2018-08-14 13:58:09 --> Router Class Initialized
INFO - 2018-08-14 13:58:09 --> Output Class Initialized
INFO - 2018-08-14 13:58:09 --> Security Class Initialized
DEBUG - 2018-08-14 13:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:58:09 --> CSRF cookie sent
INFO - 2018-08-14 13:58:09 --> Input Class Initialized
INFO - 2018-08-14 13:58:09 --> Language Class Initialized
INFO - 2018-08-14 13:58:09 --> Loader Class Initialized
INFO - 2018-08-14 13:58:09 --> Helper loaded: url_helper
INFO - 2018-08-14 13:58:09 --> Helper loaded: form_helper
INFO - 2018-08-14 13:58:09 --> Helper loaded: language_helper
DEBUG - 2018-08-14 13:58:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:58:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:58:09 --> User Agent Class Initialized
INFO - 2018-08-14 13:58:09 --> Controller Class Initialized
INFO - 2018-08-14 13:58:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 13:58:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 13:58:09 --> Pixel_Model class loaded
INFO - 2018-08-14 13:58:09 --> Database Driver Class Initialized
INFO - 2018-08-14 13:58:09 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:58:09 --> Database Driver Class Initialized
INFO - 2018-08-14 13:58:09 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:58:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 13:58:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-14 13:58:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 13:58:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 13:58:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 13:58:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 13:58:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 13:58:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-08-14 13:58:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 13:58:09 --> Final output sent to browser
DEBUG - 2018-08-14 13:58:09 --> Total execution time: 0.0449
INFO - 2018-08-14 13:58:13 --> Config Class Initialized
INFO - 2018-08-14 13:58:13 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:58:13 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:58:13 --> Utf8 Class Initialized
INFO - 2018-08-14 13:58:13 --> URI Class Initialized
INFO - 2018-08-14 13:58:13 --> Router Class Initialized
INFO - 2018-08-14 13:58:13 --> Output Class Initialized
INFO - 2018-08-14 13:58:13 --> Security Class Initialized
DEBUG - 2018-08-14 13:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:58:13 --> CSRF cookie sent
INFO - 2018-08-14 13:58:13 --> CSRF token verified
INFO - 2018-08-14 13:58:13 --> Input Class Initialized
INFO - 2018-08-14 13:58:13 --> Language Class Initialized
INFO - 2018-08-14 13:58:13 --> Loader Class Initialized
INFO - 2018-08-14 13:58:13 --> Helper loaded: url_helper
INFO - 2018-08-14 13:58:13 --> Helper loaded: form_helper
INFO - 2018-08-14 13:58:13 --> Helper loaded: language_helper
DEBUG - 2018-08-14 13:58:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:58:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:58:13 --> User Agent Class Initialized
INFO - 2018-08-14 13:58:13 --> Controller Class Initialized
INFO - 2018-08-14 13:58:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 13:58:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 13:58:13 --> Pixel_Model class loaded
INFO - 2018-08-14 13:58:13 --> Database Driver Class Initialized
INFO - 2018-08-14 13:58:13 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:58:13 --> Form Validation Class Initialized
INFO - 2018-08-14 13:58:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 13:58:13 --> Database Driver Class Initialized
INFO - 2018-08-14 13:58:13 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:58:13 --> Config Class Initialized
INFO - 2018-08-14 13:58:13 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:58:13 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:58:13 --> Utf8 Class Initialized
INFO - 2018-08-14 13:58:13 --> URI Class Initialized
INFO - 2018-08-14 13:58:13 --> Router Class Initialized
INFO - 2018-08-14 13:58:13 --> Output Class Initialized
INFO - 2018-08-14 13:58:13 --> Security Class Initialized
DEBUG - 2018-08-14 13:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:58:13 --> CSRF cookie sent
INFO - 2018-08-14 13:58:13 --> Input Class Initialized
INFO - 2018-08-14 13:58:13 --> Language Class Initialized
INFO - 2018-08-14 13:58:13 --> Loader Class Initialized
INFO - 2018-08-14 13:58:13 --> Helper loaded: url_helper
INFO - 2018-08-14 13:58:13 --> Helper loaded: form_helper
INFO - 2018-08-14 13:58:13 --> Helper loaded: language_helper
DEBUG - 2018-08-14 13:58:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:58:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:58:13 --> User Agent Class Initialized
INFO - 2018-08-14 13:58:13 --> Controller Class Initialized
INFO - 2018-08-14 13:58:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 13:58:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 13:58:13 --> Pixel_Model class loaded
INFO - 2018-08-14 13:58:13 --> Database Driver Class Initialized
INFO - 2018-08-14 13:58:13 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:58:13 --> Database Driver Class Initialized
INFO - 2018-08-14 13:58:13 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:58:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 13:58:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-14 13:58:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 13:58:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 13:58:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 13:58:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 13:58:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 13:58:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-08-14 13:58:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 13:58:13 --> Final output sent to browser
DEBUG - 2018-08-14 13:58:13 --> Total execution time: 0.0459
INFO - 2018-08-14 13:58:22 --> Config Class Initialized
INFO - 2018-08-14 13:58:22 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:58:22 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:58:22 --> Utf8 Class Initialized
INFO - 2018-08-14 13:58:22 --> URI Class Initialized
INFO - 2018-08-14 13:58:22 --> Router Class Initialized
INFO - 2018-08-14 13:58:22 --> Output Class Initialized
INFO - 2018-08-14 13:58:22 --> Security Class Initialized
DEBUG - 2018-08-14 13:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:58:22 --> CSRF cookie sent
INFO - 2018-08-14 13:58:22 --> CSRF token verified
INFO - 2018-08-14 13:58:22 --> Input Class Initialized
INFO - 2018-08-14 13:58:22 --> Language Class Initialized
INFO - 2018-08-14 13:58:22 --> Loader Class Initialized
INFO - 2018-08-14 13:58:22 --> Helper loaded: url_helper
INFO - 2018-08-14 13:58:22 --> Helper loaded: form_helper
INFO - 2018-08-14 13:58:22 --> Helper loaded: language_helper
DEBUG - 2018-08-14 13:58:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:58:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:58:22 --> User Agent Class Initialized
INFO - 2018-08-14 13:58:22 --> Controller Class Initialized
INFO - 2018-08-14 13:58:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 13:58:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 13:58:22 --> Pixel_Model class loaded
INFO - 2018-08-14 13:58:22 --> Database Driver Class Initialized
INFO - 2018-08-14 13:58:22 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:58:22 --> Form Validation Class Initialized
INFO - 2018-08-14 13:58:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 13:58:22 --> Database Driver Class Initialized
INFO - 2018-08-14 13:58:22 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:58:22 --> Config Class Initialized
INFO - 2018-08-14 13:58:22 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:58:22 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:58:22 --> Utf8 Class Initialized
INFO - 2018-08-14 13:58:22 --> URI Class Initialized
INFO - 2018-08-14 13:58:22 --> Router Class Initialized
INFO - 2018-08-14 13:58:22 --> Output Class Initialized
INFO - 2018-08-14 13:58:22 --> Security Class Initialized
DEBUG - 2018-08-14 13:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:58:22 --> CSRF cookie sent
INFO - 2018-08-14 13:58:22 --> Input Class Initialized
INFO - 2018-08-14 13:58:22 --> Language Class Initialized
INFO - 2018-08-14 13:58:22 --> Loader Class Initialized
INFO - 2018-08-14 13:58:22 --> Helper loaded: url_helper
INFO - 2018-08-14 13:58:22 --> Helper loaded: form_helper
INFO - 2018-08-14 13:58:22 --> Helper loaded: language_helper
DEBUG - 2018-08-14 13:58:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:58:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:58:22 --> User Agent Class Initialized
INFO - 2018-08-14 13:58:22 --> Controller Class Initialized
INFO - 2018-08-14 13:58:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 13:58:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 13:58:22 --> Pixel_Model class loaded
INFO - 2018-08-14 13:58:22 --> Database Driver Class Initialized
INFO - 2018-08-14 13:58:22 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:58:22 --> Database Driver Class Initialized
INFO - 2018-08-14 13:58:22 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:58:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 13:58:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-14 13:58:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 13:58:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 13:58:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 13:58:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 13:58:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 13:58:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-08-14 13:58:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 13:58:22 --> Final output sent to browser
DEBUG - 2018-08-14 13:58:22 --> Total execution time: 0.0605
INFO - 2018-08-14 13:58:32 --> Config Class Initialized
INFO - 2018-08-14 13:58:32 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:58:32 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:58:32 --> Utf8 Class Initialized
INFO - 2018-08-14 13:58:32 --> URI Class Initialized
INFO - 2018-08-14 13:58:32 --> Router Class Initialized
INFO - 2018-08-14 13:58:32 --> Output Class Initialized
INFO - 2018-08-14 13:58:32 --> Security Class Initialized
DEBUG - 2018-08-14 13:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:58:32 --> CSRF cookie sent
INFO - 2018-08-14 13:58:32 --> CSRF token verified
INFO - 2018-08-14 13:58:32 --> Input Class Initialized
INFO - 2018-08-14 13:58:32 --> Language Class Initialized
INFO - 2018-08-14 13:58:32 --> Loader Class Initialized
INFO - 2018-08-14 13:58:32 --> Helper loaded: url_helper
INFO - 2018-08-14 13:58:32 --> Helper loaded: form_helper
INFO - 2018-08-14 13:58:32 --> Helper loaded: language_helper
DEBUG - 2018-08-14 13:58:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:58:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:58:32 --> User Agent Class Initialized
INFO - 2018-08-14 13:58:32 --> Controller Class Initialized
INFO - 2018-08-14 13:58:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 13:58:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 13:58:32 --> Pixel_Model class loaded
INFO - 2018-08-14 13:58:32 --> Database Driver Class Initialized
INFO - 2018-08-14 13:58:32 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:58:32 --> Form Validation Class Initialized
INFO - 2018-08-14 13:58:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 13:58:32 --> Database Driver Class Initialized
INFO - 2018-08-14 13:58:32 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:58:32 --> Config Class Initialized
INFO - 2018-08-14 13:58:32 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:58:32 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:58:32 --> Utf8 Class Initialized
INFO - 2018-08-14 13:58:32 --> URI Class Initialized
INFO - 2018-08-14 13:58:32 --> Router Class Initialized
INFO - 2018-08-14 13:58:32 --> Output Class Initialized
INFO - 2018-08-14 13:58:32 --> Security Class Initialized
DEBUG - 2018-08-14 13:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:58:32 --> CSRF cookie sent
INFO - 2018-08-14 13:58:32 --> Input Class Initialized
INFO - 2018-08-14 13:58:32 --> Language Class Initialized
INFO - 2018-08-14 13:58:32 --> Loader Class Initialized
INFO - 2018-08-14 13:58:32 --> Helper loaded: url_helper
INFO - 2018-08-14 13:58:32 --> Helper loaded: form_helper
INFO - 2018-08-14 13:58:32 --> Helper loaded: language_helper
DEBUG - 2018-08-14 13:58:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:58:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:58:32 --> User Agent Class Initialized
INFO - 2018-08-14 13:58:32 --> Controller Class Initialized
INFO - 2018-08-14 13:58:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 13:58:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 13:58:32 --> Pixel_Model class loaded
INFO - 2018-08-14 13:58:32 --> Database Driver Class Initialized
INFO - 2018-08-14 13:58:32 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:58:32 --> Database Driver Class Initialized
INFO - 2018-08-14 13:58:32 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:58:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 13:58:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-14 13:58:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 13:58:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 13:58:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 13:58:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 13:58:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 13:58:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-08-14 13:58:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 13:58:32 --> Final output sent to browser
DEBUG - 2018-08-14 13:58:32 --> Total execution time: 0.0540
INFO - 2018-08-14 13:58:34 --> Config Class Initialized
INFO - 2018-08-14 13:58:34 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:58:34 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:58:34 --> Utf8 Class Initialized
INFO - 2018-08-14 13:58:34 --> URI Class Initialized
INFO - 2018-08-14 13:58:34 --> Router Class Initialized
INFO - 2018-08-14 13:58:34 --> Output Class Initialized
INFO - 2018-08-14 13:58:34 --> Security Class Initialized
DEBUG - 2018-08-14 13:58:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:58:34 --> CSRF cookie sent
INFO - 2018-08-14 13:58:34 --> CSRF token verified
INFO - 2018-08-14 13:58:34 --> Input Class Initialized
INFO - 2018-08-14 13:58:34 --> Language Class Initialized
INFO - 2018-08-14 13:58:34 --> Loader Class Initialized
INFO - 2018-08-14 13:58:34 --> Helper loaded: url_helper
INFO - 2018-08-14 13:58:34 --> Helper loaded: form_helper
INFO - 2018-08-14 13:58:34 --> Helper loaded: language_helper
DEBUG - 2018-08-14 13:58:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:58:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:58:34 --> User Agent Class Initialized
INFO - 2018-08-14 13:58:34 --> Controller Class Initialized
INFO - 2018-08-14 13:58:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 13:58:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 13:58:34 --> Pixel_Model class loaded
INFO - 2018-08-14 13:58:34 --> Database Driver Class Initialized
INFO - 2018-08-14 13:58:34 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:58:34 --> Form Validation Class Initialized
INFO - 2018-08-14 13:58:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 13:58:34 --> Database Driver Class Initialized
INFO - 2018-08-14 13:58:34 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:58:34 --> Config Class Initialized
INFO - 2018-08-14 13:58:34 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:58:34 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:58:34 --> Utf8 Class Initialized
INFO - 2018-08-14 13:58:34 --> URI Class Initialized
INFO - 2018-08-14 13:58:34 --> Router Class Initialized
INFO - 2018-08-14 13:58:34 --> Output Class Initialized
INFO - 2018-08-14 13:58:34 --> Security Class Initialized
DEBUG - 2018-08-14 13:58:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:58:34 --> CSRF cookie sent
INFO - 2018-08-14 13:58:34 --> Input Class Initialized
INFO - 2018-08-14 13:58:34 --> Language Class Initialized
INFO - 2018-08-14 13:58:34 --> Loader Class Initialized
INFO - 2018-08-14 13:58:34 --> Helper loaded: url_helper
INFO - 2018-08-14 13:58:34 --> Helper loaded: form_helper
INFO - 2018-08-14 13:58:34 --> Helper loaded: language_helper
DEBUG - 2018-08-14 13:58:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:58:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:58:35 --> User Agent Class Initialized
INFO - 2018-08-14 13:58:35 --> Controller Class Initialized
INFO - 2018-08-14 13:58:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 13:58:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 13:58:35 --> Pixel_Model class loaded
INFO - 2018-08-14 13:58:35 --> Database Driver Class Initialized
INFO - 2018-08-14 13:58:35 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:58:35 --> Database Driver Class Initialized
INFO - 2018-08-14 13:58:35 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:58:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 13:58:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-14 13:58:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 13:58:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 13:58:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 13:58:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 13:58:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 13:58:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_owner.php
INFO - 2018-08-14 13:58:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 13:58:35 --> Final output sent to browser
DEBUG - 2018-08-14 13:58:35 --> Total execution time: 0.0598
INFO - 2018-08-14 13:58:36 --> Config Class Initialized
INFO - 2018-08-14 13:58:36 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:58:36 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:58:36 --> Utf8 Class Initialized
INFO - 2018-08-14 13:58:36 --> URI Class Initialized
INFO - 2018-08-14 13:58:36 --> Router Class Initialized
INFO - 2018-08-14 13:58:36 --> Output Class Initialized
INFO - 2018-08-14 13:58:36 --> Security Class Initialized
DEBUG - 2018-08-14 13:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:58:36 --> CSRF cookie sent
INFO - 2018-08-14 13:58:36 --> CSRF token verified
INFO - 2018-08-14 13:58:36 --> Input Class Initialized
INFO - 2018-08-14 13:58:36 --> Language Class Initialized
INFO - 2018-08-14 13:58:36 --> Loader Class Initialized
INFO - 2018-08-14 13:58:36 --> Helper loaded: url_helper
INFO - 2018-08-14 13:58:36 --> Helper loaded: form_helper
INFO - 2018-08-14 13:58:36 --> Helper loaded: language_helper
DEBUG - 2018-08-14 13:58:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:58:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:58:36 --> User Agent Class Initialized
INFO - 2018-08-14 13:58:36 --> Controller Class Initialized
INFO - 2018-08-14 13:58:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 13:58:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 13:58:36 --> Pixel_Model class loaded
INFO - 2018-08-14 13:58:36 --> Database Driver Class Initialized
INFO - 2018-08-14 13:58:36 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:58:36 --> Form Validation Class Initialized
INFO - 2018-08-14 13:58:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 13:58:36 --> Database Driver Class Initialized
INFO - 2018-08-14 13:58:36 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:58:37 --> Config Class Initialized
INFO - 2018-08-14 13:58:37 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:58:37 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:58:37 --> Utf8 Class Initialized
INFO - 2018-08-14 13:58:37 --> URI Class Initialized
INFO - 2018-08-14 13:58:37 --> Router Class Initialized
INFO - 2018-08-14 13:58:37 --> Output Class Initialized
INFO - 2018-08-14 13:58:37 --> Security Class Initialized
DEBUG - 2018-08-14 13:58:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:58:37 --> CSRF cookie sent
INFO - 2018-08-14 13:58:37 --> Input Class Initialized
INFO - 2018-08-14 13:58:37 --> Language Class Initialized
INFO - 2018-08-14 13:58:37 --> Loader Class Initialized
INFO - 2018-08-14 13:58:37 --> Helper loaded: url_helper
INFO - 2018-08-14 13:58:37 --> Helper loaded: form_helper
INFO - 2018-08-14 13:58:37 --> Helper loaded: language_helper
DEBUG - 2018-08-14 13:58:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:58:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:58:37 --> User Agent Class Initialized
INFO - 2018-08-14 13:58:37 --> Controller Class Initialized
INFO - 2018-08-14 13:58:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 13:58:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 13:58:37 --> Pixel_Model class loaded
INFO - 2018-08-14 13:58:37 --> Database Driver Class Initialized
INFO - 2018-08-14 13:58:37 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:58:37 --> Database Driver Class Initialized
INFO - 2018-08-14 13:58:37 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:58:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 13:58:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-14 13:58:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 13:58:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 13:58:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 13:58:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 13:58:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 13:58:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_value.php
INFO - 2018-08-14 13:58:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 13:58:37 --> Final output sent to browser
DEBUG - 2018-08-14 13:58:37 --> Total execution time: 0.0620
INFO - 2018-08-14 13:58:40 --> Config Class Initialized
INFO - 2018-08-14 13:58:40 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:58:40 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:58:40 --> Utf8 Class Initialized
INFO - 2018-08-14 13:58:40 --> URI Class Initialized
INFO - 2018-08-14 13:58:40 --> Router Class Initialized
INFO - 2018-08-14 13:58:40 --> Output Class Initialized
INFO - 2018-08-14 13:58:40 --> Security Class Initialized
DEBUG - 2018-08-14 13:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:58:40 --> CSRF cookie sent
INFO - 2018-08-14 13:58:40 --> Input Class Initialized
INFO - 2018-08-14 13:58:40 --> Language Class Initialized
INFO - 2018-08-14 13:58:40 --> Loader Class Initialized
INFO - 2018-08-14 13:58:40 --> Helper loaded: url_helper
INFO - 2018-08-14 13:58:40 --> Helper loaded: form_helper
INFO - 2018-08-14 13:58:40 --> Helper loaded: language_helper
DEBUG - 2018-08-14 13:58:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:58:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:58:40 --> User Agent Class Initialized
INFO - 2018-08-14 13:58:40 --> Controller Class Initialized
INFO - 2018-08-14 13:58:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 13:58:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 13:58:40 --> Pixel_Model class loaded
INFO - 2018-08-14 13:58:40 --> Database Driver Class Initialized
INFO - 2018-08-14 13:58:40 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:58:40 --> Database Driver Class Initialized
INFO - 2018-08-14 13:58:40 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:58:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 13:58:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-14 13:58:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 13:58:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 13:58:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 13:58:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 13:58:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 13:58:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-08-14 13:58:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 13:58:40 --> Final output sent to browser
DEBUG - 2018-08-14 13:58:40 --> Total execution time: 0.0413
INFO - 2018-08-14 13:58:43 --> Config Class Initialized
INFO - 2018-08-14 13:58:43 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:58:43 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:58:43 --> Utf8 Class Initialized
INFO - 2018-08-14 13:58:43 --> URI Class Initialized
INFO - 2018-08-14 13:58:43 --> Router Class Initialized
INFO - 2018-08-14 13:58:43 --> Output Class Initialized
INFO - 2018-08-14 13:58:43 --> Security Class Initialized
DEBUG - 2018-08-14 13:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:58:43 --> CSRF cookie sent
INFO - 2018-08-14 13:58:43 --> CSRF token verified
INFO - 2018-08-14 13:58:43 --> Input Class Initialized
INFO - 2018-08-14 13:58:43 --> Language Class Initialized
INFO - 2018-08-14 13:58:43 --> Loader Class Initialized
INFO - 2018-08-14 13:58:43 --> Helper loaded: url_helper
INFO - 2018-08-14 13:58:43 --> Helper loaded: form_helper
INFO - 2018-08-14 13:58:43 --> Helper loaded: language_helper
DEBUG - 2018-08-14 13:58:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:58:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:58:43 --> User Agent Class Initialized
INFO - 2018-08-14 13:58:43 --> Controller Class Initialized
INFO - 2018-08-14 13:58:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 13:58:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 13:58:43 --> Pixel_Model class loaded
INFO - 2018-08-14 13:58:43 --> Database Driver Class Initialized
INFO - 2018-08-14 13:58:43 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:58:43 --> Form Validation Class Initialized
INFO - 2018-08-14 13:58:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 13:58:43 --> Database Driver Class Initialized
INFO - 2018-08-14 13:58:43 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:58:43 --> Config Class Initialized
INFO - 2018-08-14 13:58:43 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:58:43 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:58:43 --> Utf8 Class Initialized
INFO - 2018-08-14 13:58:43 --> URI Class Initialized
INFO - 2018-08-14 13:58:43 --> Router Class Initialized
INFO - 2018-08-14 13:58:43 --> Output Class Initialized
INFO - 2018-08-14 13:58:43 --> Security Class Initialized
DEBUG - 2018-08-14 13:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:58:43 --> CSRF cookie sent
INFO - 2018-08-14 13:58:43 --> Input Class Initialized
INFO - 2018-08-14 13:58:43 --> Language Class Initialized
INFO - 2018-08-14 13:58:43 --> Loader Class Initialized
INFO - 2018-08-14 13:58:43 --> Helper loaded: url_helper
INFO - 2018-08-14 13:58:43 --> Helper loaded: form_helper
INFO - 2018-08-14 13:58:43 --> Helper loaded: language_helper
DEBUG - 2018-08-14 13:58:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:58:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:58:43 --> User Agent Class Initialized
INFO - 2018-08-14 13:58:43 --> Controller Class Initialized
INFO - 2018-08-14 13:58:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 13:58:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 13:58:43 --> Pixel_Model class loaded
INFO - 2018-08-14 13:58:43 --> Database Driver Class Initialized
INFO - 2018-08-14 13:58:43 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:58:43 --> Database Driver Class Initialized
INFO - 2018-08-14 13:58:43 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:58:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 13:58:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-14 13:58:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 13:58:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 13:58:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 13:58:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 13:58:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 13:58:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids_info.php
INFO - 2018-08-14 13:58:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 13:58:43 --> Final output sent to browser
DEBUG - 2018-08-14 13:58:43 --> Total execution time: 0.0610
INFO - 2018-08-14 13:58:47 --> Config Class Initialized
INFO - 2018-08-14 13:58:47 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:58:47 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:58:47 --> Utf8 Class Initialized
INFO - 2018-08-14 13:58:47 --> URI Class Initialized
INFO - 2018-08-14 13:58:47 --> Router Class Initialized
INFO - 2018-08-14 13:58:47 --> Output Class Initialized
INFO - 2018-08-14 13:58:47 --> Security Class Initialized
DEBUG - 2018-08-14 13:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:58:47 --> CSRF cookie sent
INFO - 2018-08-14 13:58:47 --> CSRF token verified
INFO - 2018-08-14 13:58:47 --> Input Class Initialized
INFO - 2018-08-14 13:58:47 --> Language Class Initialized
INFO - 2018-08-14 13:58:47 --> Loader Class Initialized
INFO - 2018-08-14 13:58:47 --> Helper loaded: url_helper
INFO - 2018-08-14 13:58:47 --> Helper loaded: form_helper
INFO - 2018-08-14 13:58:47 --> Helper loaded: language_helper
DEBUG - 2018-08-14 13:58:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:58:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:58:47 --> User Agent Class Initialized
INFO - 2018-08-14 13:58:47 --> Controller Class Initialized
INFO - 2018-08-14 13:58:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 13:58:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 13:58:47 --> Pixel_Model class loaded
INFO - 2018-08-14 13:58:47 --> Database Driver Class Initialized
INFO - 2018-08-14 13:58:47 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:58:47 --> Form Validation Class Initialized
INFO - 2018-08-14 13:58:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 13:58:47 --> Database Driver Class Initialized
INFO - 2018-08-14 13:58:47 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:58:47 --> Config Class Initialized
INFO - 2018-08-14 13:58:47 --> Hooks Class Initialized
DEBUG - 2018-08-14 13:58:47 --> UTF-8 Support Enabled
INFO - 2018-08-14 13:58:47 --> Utf8 Class Initialized
INFO - 2018-08-14 13:58:47 --> URI Class Initialized
INFO - 2018-08-14 13:58:47 --> Router Class Initialized
INFO - 2018-08-14 13:58:47 --> Output Class Initialized
INFO - 2018-08-14 13:58:47 --> Security Class Initialized
DEBUG - 2018-08-14 13:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 13:58:47 --> CSRF cookie sent
INFO - 2018-08-14 13:58:47 --> Input Class Initialized
INFO - 2018-08-14 13:58:47 --> Language Class Initialized
INFO - 2018-08-14 13:58:47 --> Loader Class Initialized
INFO - 2018-08-14 13:58:47 --> Helper loaded: url_helper
INFO - 2018-08-14 13:58:47 --> Helper loaded: form_helper
INFO - 2018-08-14 13:58:47 --> Helper loaded: language_helper
DEBUG - 2018-08-14 13:58:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 13:58:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 13:58:47 --> User Agent Class Initialized
INFO - 2018-08-14 13:58:47 --> Controller Class Initialized
INFO - 2018-08-14 13:58:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 13:58:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 13:58:47 --> Pixel_Model class loaded
INFO - 2018-08-14 13:58:47 --> Database Driver Class Initialized
INFO - 2018-08-14 13:58:47 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:58:47 --> Database Driver Class Initialized
INFO - 2018-08-14 13:58:47 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 13:58:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 13:58:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-14 13:58:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 13:58:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 13:58:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 13:58:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 13:58:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 13:58:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/other_kids.php
INFO - 2018-08-14 13:58:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 13:58:47 --> Final output sent to browser
DEBUG - 2018-08-14 13:58:47 --> Total execution time: 0.0557
INFO - 2018-08-14 14:02:07 --> Config Class Initialized
INFO - 2018-08-14 14:02:07 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:02:07 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:02:07 --> Utf8 Class Initialized
INFO - 2018-08-14 14:02:07 --> URI Class Initialized
INFO - 2018-08-14 14:02:07 --> Router Class Initialized
INFO - 2018-08-14 14:02:07 --> Output Class Initialized
INFO - 2018-08-14 14:02:07 --> Security Class Initialized
DEBUG - 2018-08-14 14:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:02:07 --> CSRF cookie sent
INFO - 2018-08-14 14:02:07 --> Input Class Initialized
INFO - 2018-08-14 14:02:07 --> Language Class Initialized
INFO - 2018-08-14 14:02:07 --> Loader Class Initialized
INFO - 2018-08-14 14:02:07 --> Helper loaded: url_helper
INFO - 2018-08-14 14:02:07 --> Helper loaded: form_helper
INFO - 2018-08-14 14:02:07 --> Helper loaded: language_helper
DEBUG - 2018-08-14 14:02:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:02:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:02:07 --> User Agent Class Initialized
INFO - 2018-08-14 14:02:07 --> Controller Class Initialized
INFO - 2018-08-14 14:02:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 14:02:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 14:02:07 --> Pixel_Model class loaded
INFO - 2018-08-14 14:02:07 --> Database Driver Class Initialized
INFO - 2018-08-14 14:02:07 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 14:02:07 --> Database Driver Class Initialized
INFO - 2018-08-14 14:02:07 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 14:02:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 14:02:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-14 14:02:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 14:02:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 14:02:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 14:02:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 14:02:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 14:02:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/business_tax_info.php
INFO - 2018-08-14 14:02:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 14:02:07 --> Final output sent to browser
DEBUG - 2018-08-14 14:02:07 --> Total execution time: 0.0693
INFO - 2018-08-14 14:03:03 --> Config Class Initialized
INFO - 2018-08-14 14:03:03 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:03:03 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:03:03 --> Utf8 Class Initialized
INFO - 2018-08-14 14:03:03 --> URI Class Initialized
INFO - 2018-08-14 14:03:03 --> Router Class Initialized
INFO - 2018-08-14 14:03:03 --> Output Class Initialized
INFO - 2018-08-14 14:03:03 --> Security Class Initialized
DEBUG - 2018-08-14 14:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:03:03 --> CSRF cookie sent
INFO - 2018-08-14 14:03:03 --> Input Class Initialized
INFO - 2018-08-14 14:03:03 --> Language Class Initialized
INFO - 2018-08-14 14:03:03 --> Loader Class Initialized
INFO - 2018-08-14 14:03:03 --> Helper loaded: url_helper
INFO - 2018-08-14 14:03:03 --> Helper loaded: form_helper
INFO - 2018-08-14 14:03:03 --> Helper loaded: language_helper
DEBUG - 2018-08-14 14:03:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:03:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:03:03 --> User Agent Class Initialized
INFO - 2018-08-14 14:03:03 --> Controller Class Initialized
INFO - 2018-08-14 14:03:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 14:03:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 14:03:03 --> Pixel_Model class loaded
INFO - 2018-08-14 14:03:03 --> Database Driver Class Initialized
INFO - 2018-08-14 14:03:03 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 14:03:03 --> Database Driver Class Initialized
INFO - 2018-08-14 14:03:03 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 14:03:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 14:03:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-14 14:03:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 14:03:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 14:03:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 14:03:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-08-14 14:03:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 14:03:03 --> Final output sent to browser
DEBUG - 2018-08-14 14:03:03 --> Total execution time: 0.0457
INFO - 2018-08-14 14:03:21 --> Config Class Initialized
INFO - 2018-08-14 14:03:21 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:03:21 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:03:21 --> Utf8 Class Initialized
INFO - 2018-08-14 14:03:21 --> URI Class Initialized
INFO - 2018-08-14 14:03:21 --> Router Class Initialized
INFO - 2018-08-14 14:03:21 --> Output Class Initialized
INFO - 2018-08-14 14:03:21 --> Security Class Initialized
DEBUG - 2018-08-14 14:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:03:21 --> CSRF cookie sent
INFO - 2018-08-14 14:03:21 --> Input Class Initialized
INFO - 2018-08-14 14:03:21 --> Language Class Initialized
INFO - 2018-08-14 14:03:21 --> Loader Class Initialized
INFO - 2018-08-14 14:03:21 --> Helper loaded: url_helper
INFO - 2018-08-14 14:03:21 --> Helper loaded: form_helper
INFO - 2018-08-14 14:03:21 --> Helper loaded: language_helper
DEBUG - 2018-08-14 14:03:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:03:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:03:21 --> User Agent Class Initialized
INFO - 2018-08-14 14:03:21 --> Controller Class Initialized
INFO - 2018-08-14 14:03:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 14:03:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 14:03:21 --> Pixel_Model class loaded
INFO - 2018-08-14 14:03:21 --> Database Driver Class Initialized
INFO - 2018-08-14 14:03:21 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 14:03:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 14:03:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-14 14:03:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 14:03:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 14:03:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 14:03:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 14:03:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/cohabitation.php
INFO - 2018-08-14 14:03:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 14:03:21 --> Final output sent to browser
DEBUG - 2018-08-14 14:03:21 --> Total execution time: 0.0380
INFO - 2018-08-14 14:12:19 --> Config Class Initialized
INFO - 2018-08-14 14:12:19 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:12:19 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:12:19 --> Utf8 Class Initialized
INFO - 2018-08-14 14:12:19 --> URI Class Initialized
DEBUG - 2018-08-14 14:12:19 --> No URI present. Default controller set.
INFO - 2018-08-14 14:12:19 --> Router Class Initialized
INFO - 2018-08-14 14:12:19 --> Output Class Initialized
INFO - 2018-08-14 14:12:19 --> Security Class Initialized
DEBUG - 2018-08-14 14:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:12:19 --> CSRF cookie sent
INFO - 2018-08-14 14:12:19 --> Input Class Initialized
INFO - 2018-08-14 14:12:19 --> Language Class Initialized
INFO - 2018-08-14 14:12:19 --> Loader Class Initialized
INFO - 2018-08-14 14:12:19 --> Helper loaded: url_helper
INFO - 2018-08-14 14:12:19 --> Helper loaded: form_helper
INFO - 2018-08-14 14:12:19 --> Helper loaded: language_helper
DEBUG - 2018-08-14 14:12:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:12:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:12:19 --> User Agent Class Initialized
INFO - 2018-08-14 14:12:19 --> Controller Class Initialized
INFO - 2018-08-14 14:12:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 14:12:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 14:12:19 --> Pixel_Model class loaded
INFO - 2018-08-14 14:12:19 --> Database Driver Class Initialized
INFO - 2018-08-14 14:12:19 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 14:12:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 14:12:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 14:12:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-14 14:12:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 14:12:19 --> Final output sent to browser
DEBUG - 2018-08-14 14:12:19 --> Total execution time: 0.0388
INFO - 2018-08-14 14:12:21 --> Config Class Initialized
INFO - 2018-08-14 14:12:21 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:12:21 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:12:21 --> Utf8 Class Initialized
INFO - 2018-08-14 14:12:21 --> URI Class Initialized
INFO - 2018-08-14 14:12:21 --> Router Class Initialized
INFO - 2018-08-14 14:12:21 --> Output Class Initialized
INFO - 2018-08-14 14:12:21 --> Security Class Initialized
DEBUG - 2018-08-14 14:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:12:21 --> CSRF cookie sent
INFO - 2018-08-14 14:12:21 --> Input Class Initialized
INFO - 2018-08-14 14:12:21 --> Language Class Initialized
INFO - 2018-08-14 14:12:21 --> Loader Class Initialized
INFO - 2018-08-14 14:12:21 --> Helper loaded: url_helper
INFO - 2018-08-14 14:12:21 --> Helper loaded: form_helper
INFO - 2018-08-14 14:12:21 --> Helper loaded: language_helper
DEBUG - 2018-08-14 14:12:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:12:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:12:21 --> User Agent Class Initialized
INFO - 2018-08-14 14:12:21 --> Controller Class Initialized
INFO - 2018-08-14 14:12:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 14:12:21 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-08-14 14:12:21 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-08-14 14:12:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 14:12:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 14:12:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 14:12:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-08-14 14:12:21 --> Could not find the language line "req_email"
INFO - 2018-08-14 14:12:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-08-14 14:12:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 14:12:21 --> Final output sent to browser
DEBUG - 2018-08-14 14:12:21 --> Total execution time: 0.0223
INFO - 2018-08-14 14:12:25 --> Config Class Initialized
INFO - 2018-08-14 14:12:25 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:12:25 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:12:25 --> Utf8 Class Initialized
INFO - 2018-08-14 14:12:25 --> URI Class Initialized
INFO - 2018-08-14 14:12:25 --> Router Class Initialized
INFO - 2018-08-14 14:12:25 --> Output Class Initialized
INFO - 2018-08-14 14:12:25 --> Security Class Initialized
DEBUG - 2018-08-14 14:12:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:12:25 --> CSRF cookie sent
INFO - 2018-08-14 14:12:25 --> CSRF token verified
INFO - 2018-08-14 14:12:25 --> Input Class Initialized
INFO - 2018-08-14 14:12:25 --> Language Class Initialized
INFO - 2018-08-14 14:12:25 --> Loader Class Initialized
INFO - 2018-08-14 14:12:25 --> Helper loaded: url_helper
INFO - 2018-08-14 14:12:25 --> Helper loaded: form_helper
INFO - 2018-08-14 14:12:25 --> Helper loaded: language_helper
DEBUG - 2018-08-14 14:12:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:12:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:12:25 --> User Agent Class Initialized
INFO - 2018-08-14 14:12:25 --> Controller Class Initialized
INFO - 2018-08-14 14:12:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 14:12:25 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-08-14 14:12:25 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-08-14 14:12:25 --> Form Validation Class Initialized
INFO - 2018-08-14 14:12:25 --> Pixel_Model class loaded
INFO - 2018-08-14 14:12:25 --> Database Driver Class Initialized
INFO - 2018-08-14 14:12:25 --> Model "AuthenticationModel" initialized
INFO - 2018-08-14 14:12:26 --> Config Class Initialized
INFO - 2018-08-14 14:12:26 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:12:26 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:12:26 --> Utf8 Class Initialized
INFO - 2018-08-14 14:12:26 --> URI Class Initialized
DEBUG - 2018-08-14 14:12:26 --> No URI present. Default controller set.
INFO - 2018-08-14 14:12:26 --> Router Class Initialized
INFO - 2018-08-14 14:12:26 --> Output Class Initialized
INFO - 2018-08-14 14:12:26 --> Security Class Initialized
DEBUG - 2018-08-14 14:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:12:26 --> CSRF cookie sent
INFO - 2018-08-14 14:12:26 --> Input Class Initialized
INFO - 2018-08-14 14:12:26 --> Language Class Initialized
INFO - 2018-08-14 14:12:26 --> Loader Class Initialized
INFO - 2018-08-14 14:12:26 --> Helper loaded: url_helper
INFO - 2018-08-14 14:12:26 --> Helper loaded: form_helper
INFO - 2018-08-14 14:12:26 --> Helper loaded: language_helper
DEBUG - 2018-08-14 14:12:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:12:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:12:26 --> User Agent Class Initialized
INFO - 2018-08-14 14:12:26 --> Controller Class Initialized
INFO - 2018-08-14 14:12:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 14:12:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 14:12:26 --> Pixel_Model class loaded
INFO - 2018-08-14 14:12:26 --> Database Driver Class Initialized
INFO - 2018-08-14 14:12:26 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 14:12:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 14:12:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-14 14:12:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 14:12:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-14 14:12:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 14:12:26 --> Final output sent to browser
DEBUG - 2018-08-14 14:12:26 --> Total execution time: 0.0347
INFO - 2018-08-14 14:12:28 --> Config Class Initialized
INFO - 2018-08-14 14:12:28 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:12:28 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:12:28 --> Utf8 Class Initialized
INFO - 2018-08-14 14:12:28 --> URI Class Initialized
INFO - 2018-08-14 14:12:28 --> Router Class Initialized
INFO - 2018-08-14 14:12:28 --> Output Class Initialized
INFO - 2018-08-14 14:12:28 --> Security Class Initialized
DEBUG - 2018-08-14 14:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:12:28 --> CSRF cookie sent
INFO - 2018-08-14 14:12:28 --> Input Class Initialized
INFO - 2018-08-14 14:12:28 --> Language Class Initialized
INFO - 2018-08-14 14:12:28 --> Loader Class Initialized
INFO - 2018-08-14 14:12:28 --> Helper loaded: url_helper
INFO - 2018-08-14 14:12:28 --> Helper loaded: form_helper
INFO - 2018-08-14 14:12:28 --> Helper loaded: language_helper
DEBUG - 2018-08-14 14:12:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:12:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:12:28 --> User Agent Class Initialized
INFO - 2018-08-14 14:12:28 --> Controller Class Initialized
INFO - 2018-08-14 14:12:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 14:12:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 14:12:28 --> Pixel_Model class loaded
INFO - 2018-08-14 14:12:28 --> Database Driver Class Initialized
INFO - 2018-08-14 14:12:28 --> Model "MyAccountModel" initialized
INFO - 2018-08-14 14:12:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 14:12:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-14 14:12:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 14:12:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 14:12:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 14:12:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/application_list.php
INFO - 2018-08-14 14:12:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 14:12:28 --> Final output sent to browser
DEBUG - 2018-08-14 14:12:28 --> Total execution time: 0.0360
INFO - 2018-08-14 14:12:30 --> Config Class Initialized
INFO - 2018-08-14 14:12:30 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:12:30 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:12:30 --> Utf8 Class Initialized
INFO - 2018-08-14 14:12:30 --> URI Class Initialized
INFO - 2018-08-14 14:12:30 --> Router Class Initialized
INFO - 2018-08-14 14:12:30 --> Output Class Initialized
INFO - 2018-08-14 14:12:30 --> Security Class Initialized
DEBUG - 2018-08-14 14:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:12:30 --> CSRF cookie sent
INFO - 2018-08-14 14:12:30 --> Input Class Initialized
INFO - 2018-08-14 14:12:30 --> Language Class Initialized
INFO - 2018-08-14 14:12:30 --> Loader Class Initialized
INFO - 2018-08-14 14:12:30 --> Helper loaded: url_helper
INFO - 2018-08-14 14:12:30 --> Helper loaded: form_helper
INFO - 2018-08-14 14:12:30 --> Helper loaded: language_helper
DEBUG - 2018-08-14 14:12:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:12:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:12:30 --> User Agent Class Initialized
INFO - 2018-08-14 14:12:30 --> Controller Class Initialized
INFO - 2018-08-14 14:12:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 14:12:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 14:12:30 --> Pixel_Model class loaded
INFO - 2018-08-14 14:12:30 --> Database Driver Class Initialized
INFO - 2018-08-14 14:12:30 --> Model "MyAccountModel" initialized
INFO - 2018-08-14 14:12:30 --> Config Class Initialized
INFO - 2018-08-14 14:12:30 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:12:30 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:12:30 --> Utf8 Class Initialized
INFO - 2018-08-14 14:12:30 --> URI Class Initialized
INFO - 2018-08-14 14:12:30 --> Router Class Initialized
INFO - 2018-08-14 14:12:30 --> Output Class Initialized
INFO - 2018-08-14 14:12:30 --> Security Class Initialized
DEBUG - 2018-08-14 14:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:12:30 --> CSRF cookie sent
INFO - 2018-08-14 14:12:30 --> Input Class Initialized
INFO - 2018-08-14 14:12:30 --> Language Class Initialized
INFO - 2018-08-14 14:12:30 --> Loader Class Initialized
INFO - 2018-08-14 14:12:30 --> Helper loaded: url_helper
INFO - 2018-08-14 14:12:30 --> Helper loaded: form_helper
INFO - 2018-08-14 14:12:30 --> Helper loaded: language_helper
DEBUG - 2018-08-14 14:12:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:12:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:12:30 --> User Agent Class Initialized
INFO - 2018-08-14 14:12:30 --> Controller Class Initialized
INFO - 2018-08-14 14:12:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 14:12:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 14:12:30 --> Pixel_Model class loaded
INFO - 2018-08-14 14:12:30 --> Database Driver Class Initialized
INFO - 2018-08-14 14:12:30 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 14:12:30 --> Database Driver Class Initialized
INFO - 2018-08-14 14:12:30 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 14:12:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 14:12:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-14 14:12:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 14:12:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 14:12:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 14:12:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 14:12:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 14:12:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-08-14 14:12:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 14:12:30 --> Final output sent to browser
DEBUG - 2018-08-14 14:12:30 --> Total execution time: 0.0415
INFO - 2018-08-14 14:12:34 --> Config Class Initialized
INFO - 2018-08-14 14:12:34 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:12:34 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:12:34 --> Utf8 Class Initialized
INFO - 2018-08-14 14:12:34 --> URI Class Initialized
INFO - 2018-08-14 14:12:34 --> Router Class Initialized
INFO - 2018-08-14 14:12:34 --> Output Class Initialized
INFO - 2018-08-14 14:12:34 --> Security Class Initialized
DEBUG - 2018-08-14 14:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:12:34 --> CSRF cookie sent
INFO - 2018-08-14 14:12:34 --> Input Class Initialized
INFO - 2018-08-14 14:12:34 --> Language Class Initialized
INFO - 2018-08-14 14:12:34 --> Loader Class Initialized
INFO - 2018-08-14 14:12:34 --> Helper loaded: url_helper
INFO - 2018-08-14 14:12:34 --> Helper loaded: form_helper
INFO - 2018-08-14 14:12:34 --> Helper loaded: language_helper
DEBUG - 2018-08-14 14:12:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:12:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:12:34 --> User Agent Class Initialized
INFO - 2018-08-14 14:12:34 --> Controller Class Initialized
INFO - 2018-08-14 14:12:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 14:12:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 14:12:34 --> Pixel_Model class loaded
INFO - 2018-08-14 14:12:34 --> Database Driver Class Initialized
INFO - 2018-08-14 14:12:34 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 14:12:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 14:12:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-14 14:12:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 14:12:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 14:12:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 14:12:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 14:12:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 14:12:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-08-14 14:12:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 14:12:34 --> Final output sent to browser
DEBUG - 2018-08-14 14:12:34 --> Total execution time: 0.0445
INFO - 2018-08-14 14:14:55 --> Config Class Initialized
INFO - 2018-08-14 14:14:55 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:14:55 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:14:55 --> Utf8 Class Initialized
INFO - 2018-08-14 14:14:55 --> URI Class Initialized
INFO - 2018-08-14 14:14:55 --> Router Class Initialized
INFO - 2018-08-14 14:14:55 --> Output Class Initialized
INFO - 2018-08-14 14:14:55 --> Security Class Initialized
DEBUG - 2018-08-14 14:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:14:55 --> CSRF cookie sent
INFO - 2018-08-14 14:14:55 --> Input Class Initialized
INFO - 2018-08-14 14:14:55 --> Language Class Initialized
INFO - 2018-08-14 14:14:55 --> Loader Class Initialized
INFO - 2018-08-14 14:14:55 --> Helper loaded: url_helper
INFO - 2018-08-14 14:14:55 --> Helper loaded: form_helper
INFO - 2018-08-14 14:14:55 --> Helper loaded: language_helper
DEBUG - 2018-08-14 14:14:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:14:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:14:55 --> User Agent Class Initialized
INFO - 2018-08-14 14:14:55 --> Controller Class Initialized
INFO - 2018-08-14 14:14:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 14:14:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 14:14:55 --> CSRF cookie sent
INFO - 2018-08-14 14:14:55 --> Config Class Initialized
INFO - 2018-08-14 14:14:55 --> Hooks Class Initialized
DEBUG - 2018-08-14 14:14:55 --> UTF-8 Support Enabled
INFO - 2018-08-14 14:14:55 --> Utf8 Class Initialized
INFO - 2018-08-14 14:14:55 --> URI Class Initialized
DEBUG - 2018-08-14 14:14:55 --> No URI present. Default controller set.
INFO - 2018-08-14 14:14:55 --> Router Class Initialized
INFO - 2018-08-14 14:14:55 --> Output Class Initialized
INFO - 2018-08-14 14:14:55 --> Security Class Initialized
DEBUG - 2018-08-14 14:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 14:14:55 --> CSRF cookie sent
INFO - 2018-08-14 14:14:55 --> Input Class Initialized
INFO - 2018-08-14 14:14:55 --> Language Class Initialized
INFO - 2018-08-14 14:14:55 --> Loader Class Initialized
INFO - 2018-08-14 14:14:55 --> Helper loaded: url_helper
INFO - 2018-08-14 14:14:55 --> Helper loaded: form_helper
INFO - 2018-08-14 14:14:55 --> Helper loaded: language_helper
DEBUG - 2018-08-14 14:14:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 14:14:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 14:14:55 --> User Agent Class Initialized
INFO - 2018-08-14 14:14:55 --> Controller Class Initialized
INFO - 2018-08-14 14:14:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 14:14:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 14:14:55 --> Pixel_Model class loaded
INFO - 2018-08-14 14:14:55 --> Database Driver Class Initialized
INFO - 2018-08-14 14:14:55 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 14:14:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 14:14:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 14:14:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-14 14:14:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 14:14:55 --> Final output sent to browser
DEBUG - 2018-08-14 14:14:55 --> Total execution time: 0.0363
INFO - 2018-08-14 18:12:57 --> Config Class Initialized
INFO - 2018-08-14 18:12:57 --> Hooks Class Initialized
DEBUG - 2018-08-14 18:12:57 --> UTF-8 Support Enabled
INFO - 2018-08-14 18:12:57 --> Utf8 Class Initialized
INFO - 2018-08-14 18:12:57 --> URI Class Initialized
DEBUG - 2018-08-14 18:12:57 --> No URI present. Default controller set.
INFO - 2018-08-14 18:12:57 --> Router Class Initialized
INFO - 2018-08-14 18:12:57 --> Output Class Initialized
INFO - 2018-08-14 18:12:57 --> Security Class Initialized
DEBUG - 2018-08-14 18:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 18:12:57 --> CSRF cookie sent
INFO - 2018-08-14 18:12:57 --> Input Class Initialized
INFO - 2018-08-14 18:12:57 --> Language Class Initialized
INFO - 2018-08-14 18:12:57 --> Loader Class Initialized
INFO - 2018-08-14 18:12:57 --> Helper loaded: url_helper
INFO - 2018-08-14 18:12:57 --> Helper loaded: form_helper
INFO - 2018-08-14 18:12:57 --> Helper loaded: language_helper
DEBUG - 2018-08-14 18:12:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 18:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 18:12:57 --> User Agent Class Initialized
INFO - 2018-08-14 18:12:57 --> Controller Class Initialized
INFO - 2018-08-14 18:12:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 18:12:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 18:12:57 --> Pixel_Model class loaded
INFO - 2018-08-14 18:12:57 --> Database Driver Class Initialized
INFO - 2018-08-14 18:12:57 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 18:12:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 18:12:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 18:12:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-14 18:12:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 18:12:57 --> Final output sent to browser
DEBUG - 2018-08-14 18:12:57 --> Total execution time: 0.0411
INFO - 2018-08-14 18:13:02 --> Config Class Initialized
INFO - 2018-08-14 18:13:02 --> Hooks Class Initialized
DEBUG - 2018-08-14 18:13:02 --> UTF-8 Support Enabled
INFO - 2018-08-14 18:13:02 --> Utf8 Class Initialized
INFO - 2018-08-14 18:13:02 --> URI Class Initialized
INFO - 2018-08-14 18:13:02 --> Router Class Initialized
INFO - 2018-08-14 18:13:02 --> Output Class Initialized
INFO - 2018-08-14 18:13:02 --> Security Class Initialized
DEBUG - 2018-08-14 18:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 18:13:02 --> CSRF cookie sent
INFO - 2018-08-14 18:13:02 --> CSRF token verified
INFO - 2018-08-14 18:13:02 --> Input Class Initialized
INFO - 2018-08-14 18:13:02 --> Language Class Initialized
INFO - 2018-08-14 18:13:02 --> Loader Class Initialized
INFO - 2018-08-14 18:13:02 --> Helper loaded: url_helper
INFO - 2018-08-14 18:13:02 --> Helper loaded: form_helper
INFO - 2018-08-14 18:13:02 --> Helper loaded: language_helper
DEBUG - 2018-08-14 18:13:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 18:13:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 18:13:02 --> User Agent Class Initialized
INFO - 2018-08-14 18:13:02 --> Controller Class Initialized
INFO - 2018-08-14 18:13:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 18:13:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 18:13:02 --> Pixel_Model class loaded
INFO - 2018-08-14 18:13:02 --> Database Driver Class Initialized
INFO - 2018-08-14 18:13:02 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 18:13:02 --> Database Driver Class Initialized
INFO - 2018-08-14 18:13:02 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 18:13:02 --> Config Class Initialized
INFO - 2018-08-14 18:13:02 --> Hooks Class Initialized
DEBUG - 2018-08-14 18:13:02 --> UTF-8 Support Enabled
INFO - 2018-08-14 18:13:02 --> Utf8 Class Initialized
INFO - 2018-08-14 18:13:02 --> URI Class Initialized
INFO - 2018-08-14 18:13:02 --> Router Class Initialized
INFO - 2018-08-14 18:13:02 --> Output Class Initialized
INFO - 2018-08-14 18:13:02 --> Security Class Initialized
DEBUG - 2018-08-14 18:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 18:13:02 --> CSRF cookie sent
INFO - 2018-08-14 18:13:02 --> Input Class Initialized
INFO - 2018-08-14 18:13:02 --> Language Class Initialized
INFO - 2018-08-14 18:13:02 --> Loader Class Initialized
INFO - 2018-08-14 18:13:02 --> Helper loaded: url_helper
INFO - 2018-08-14 18:13:02 --> Helper loaded: form_helper
INFO - 2018-08-14 18:13:02 --> Helper loaded: language_helper
DEBUG - 2018-08-14 18:13:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 18:13:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 18:13:02 --> User Agent Class Initialized
INFO - 2018-08-14 18:13:02 --> Controller Class Initialized
INFO - 2018-08-14 18:13:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 18:13:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 18:13:02 --> Pixel_Model class loaded
INFO - 2018-08-14 18:13:02 --> Database Driver Class Initialized
INFO - 2018-08-14 18:13:02 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 18:13:02 --> Database Driver Class Initialized
INFO - 2018-08-14 18:13:02 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 18:13:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 18:13:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 18:13:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 18:13:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 18:13:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 18:13:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 18:13:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-14 18:13:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 18:13:02 --> Final output sent to browser
DEBUG - 2018-08-14 18:13:02 --> Total execution time: 0.0451
INFO - 2018-08-14 18:13:14 --> Config Class Initialized
INFO - 2018-08-14 18:13:14 --> Hooks Class Initialized
DEBUG - 2018-08-14 18:13:14 --> UTF-8 Support Enabled
INFO - 2018-08-14 18:13:14 --> Utf8 Class Initialized
INFO - 2018-08-14 18:13:14 --> URI Class Initialized
INFO - 2018-08-14 18:13:14 --> Router Class Initialized
INFO - 2018-08-14 18:13:14 --> Output Class Initialized
INFO - 2018-08-14 18:13:14 --> Security Class Initialized
DEBUG - 2018-08-14 18:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 18:13:14 --> CSRF cookie sent
INFO - 2018-08-14 18:13:14 --> CSRF token verified
INFO - 2018-08-14 18:13:14 --> Input Class Initialized
INFO - 2018-08-14 18:13:14 --> Language Class Initialized
INFO - 2018-08-14 18:13:14 --> Loader Class Initialized
INFO - 2018-08-14 18:13:14 --> Helper loaded: url_helper
INFO - 2018-08-14 18:13:14 --> Helper loaded: form_helper
INFO - 2018-08-14 18:13:14 --> Helper loaded: language_helper
DEBUG - 2018-08-14 18:13:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 18:13:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 18:13:14 --> User Agent Class Initialized
INFO - 2018-08-14 18:13:14 --> Controller Class Initialized
INFO - 2018-08-14 18:13:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 18:13:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 18:13:14 --> Pixel_Model class loaded
INFO - 2018-08-14 18:13:14 --> Database Driver Class Initialized
INFO - 2018-08-14 18:13:14 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 18:13:14 --> Form Validation Class Initialized
INFO - 2018-08-14 18:13:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 18:13:14 --> Database Driver Class Initialized
INFO - 2018-08-14 18:13:14 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 18:13:14 --> Config Class Initialized
INFO - 2018-08-14 18:13:14 --> Hooks Class Initialized
DEBUG - 2018-08-14 18:13:14 --> UTF-8 Support Enabled
INFO - 2018-08-14 18:13:14 --> Utf8 Class Initialized
INFO - 2018-08-14 18:13:14 --> URI Class Initialized
INFO - 2018-08-14 18:13:14 --> Router Class Initialized
INFO - 2018-08-14 18:13:14 --> Output Class Initialized
INFO - 2018-08-14 18:13:14 --> Security Class Initialized
DEBUG - 2018-08-14 18:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 18:13:14 --> CSRF cookie sent
INFO - 2018-08-14 18:13:14 --> Input Class Initialized
INFO - 2018-08-14 18:13:14 --> Language Class Initialized
INFO - 2018-08-14 18:13:14 --> Loader Class Initialized
INFO - 2018-08-14 18:13:14 --> Helper loaded: url_helper
INFO - 2018-08-14 18:13:14 --> Helper loaded: form_helper
INFO - 2018-08-14 18:13:14 --> Helper loaded: language_helper
DEBUG - 2018-08-14 18:13:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 18:13:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 18:13:14 --> User Agent Class Initialized
INFO - 2018-08-14 18:13:14 --> Controller Class Initialized
INFO - 2018-08-14 18:13:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 18:13:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 18:13:14 --> Pixel_Model class loaded
INFO - 2018-08-14 18:13:14 --> Database Driver Class Initialized
INFO - 2018-08-14 18:13:14 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 18:13:14 --> Database Driver Class Initialized
INFO - 2018-08-14 18:13:14 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 18:13:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 18:13:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 18:13:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 18:13:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 18:13:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 18:13:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 18:13:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-08-14 18:13:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 18:13:14 --> Final output sent to browser
DEBUG - 2018-08-14 18:13:14 --> Total execution time: 0.0471
INFO - 2018-08-14 18:13:49 --> Config Class Initialized
INFO - 2018-08-14 18:13:49 --> Hooks Class Initialized
DEBUG - 2018-08-14 18:13:49 --> UTF-8 Support Enabled
INFO - 2018-08-14 18:13:49 --> Utf8 Class Initialized
INFO - 2018-08-14 18:13:49 --> URI Class Initialized
INFO - 2018-08-14 18:13:49 --> Router Class Initialized
INFO - 2018-08-14 18:13:49 --> Output Class Initialized
INFO - 2018-08-14 18:13:49 --> Security Class Initialized
DEBUG - 2018-08-14 18:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 18:13:49 --> CSRF cookie sent
INFO - 2018-08-14 18:13:49 --> CSRF token verified
INFO - 2018-08-14 18:13:49 --> Input Class Initialized
INFO - 2018-08-14 18:13:49 --> Language Class Initialized
INFO - 2018-08-14 18:13:49 --> Loader Class Initialized
INFO - 2018-08-14 18:13:49 --> Helper loaded: url_helper
INFO - 2018-08-14 18:13:49 --> Helper loaded: form_helper
INFO - 2018-08-14 18:13:49 --> Helper loaded: language_helper
DEBUG - 2018-08-14 18:13:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 18:13:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 18:13:49 --> User Agent Class Initialized
INFO - 2018-08-14 18:13:49 --> Controller Class Initialized
INFO - 2018-08-14 18:13:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 18:13:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 18:13:49 --> Pixel_Model class loaded
INFO - 2018-08-14 18:13:49 --> Database Driver Class Initialized
INFO - 2018-08-14 18:13:49 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 18:13:49 --> Form Validation Class Initialized
INFO - 2018-08-14 18:13:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 18:13:49 --> Database Driver Class Initialized
INFO - 2018-08-14 18:13:49 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 18:13:49 --> Config Class Initialized
INFO - 2018-08-14 18:13:49 --> Hooks Class Initialized
DEBUG - 2018-08-14 18:13:49 --> UTF-8 Support Enabled
INFO - 2018-08-14 18:13:49 --> Utf8 Class Initialized
INFO - 2018-08-14 18:13:49 --> URI Class Initialized
INFO - 2018-08-14 18:13:49 --> Router Class Initialized
INFO - 2018-08-14 18:13:49 --> Output Class Initialized
INFO - 2018-08-14 18:13:49 --> Security Class Initialized
DEBUG - 2018-08-14 18:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 18:13:49 --> CSRF cookie sent
INFO - 2018-08-14 18:13:49 --> Input Class Initialized
INFO - 2018-08-14 18:13:49 --> Language Class Initialized
INFO - 2018-08-14 18:13:49 --> Loader Class Initialized
INFO - 2018-08-14 18:13:49 --> Helper loaded: url_helper
INFO - 2018-08-14 18:13:49 --> Helper loaded: form_helper
INFO - 2018-08-14 18:13:49 --> Helper loaded: language_helper
DEBUG - 2018-08-14 18:13:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 18:13:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 18:13:49 --> User Agent Class Initialized
INFO - 2018-08-14 18:13:49 --> Controller Class Initialized
INFO - 2018-08-14 18:13:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 18:13:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 18:13:49 --> Pixel_Model class loaded
INFO - 2018-08-14 18:13:49 --> Database Driver Class Initialized
INFO - 2018-08-14 18:13:49 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 18:13:49 --> Database Driver Class Initialized
INFO - 2018-08-14 18:13:49 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 18:13:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 18:13:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 18:13:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-08-14 18:13:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 18:13:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 18:13:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 18:13:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 18:13:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-08-14 18:13:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 18:13:49 --> Final output sent to browser
DEBUG - 2018-08-14 18:13:49 --> Total execution time: 0.0409
INFO - 2018-08-14 18:16:39 --> Config Class Initialized
INFO - 2018-08-14 18:16:39 --> Hooks Class Initialized
DEBUG - 2018-08-14 18:16:39 --> UTF-8 Support Enabled
INFO - 2018-08-14 18:16:39 --> Utf8 Class Initialized
INFO - 2018-08-14 18:16:39 --> URI Class Initialized
INFO - 2018-08-14 18:16:39 --> Router Class Initialized
INFO - 2018-08-14 18:16:39 --> Output Class Initialized
INFO - 2018-08-14 18:16:39 --> Security Class Initialized
DEBUG - 2018-08-14 18:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 18:16:39 --> CSRF cookie sent
INFO - 2018-08-14 18:16:39 --> Input Class Initialized
INFO - 2018-08-14 18:16:39 --> Language Class Initialized
INFO - 2018-08-14 18:16:39 --> Loader Class Initialized
INFO - 2018-08-14 18:16:39 --> Helper loaded: url_helper
INFO - 2018-08-14 18:16:39 --> Helper loaded: form_helper
INFO - 2018-08-14 18:16:39 --> Helper loaded: language_helper
DEBUG - 2018-08-14 18:16:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 18:16:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 18:16:39 --> User Agent Class Initialized
INFO - 2018-08-14 18:16:39 --> Controller Class Initialized
INFO - 2018-08-14 18:16:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 18:16:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 18:16:39 --> Pixel_Model class loaded
INFO - 2018-08-14 18:16:39 --> Database Driver Class Initialized
INFO - 2018-08-14 18:16:39 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 18:16:39 --> Database Driver Class Initialized
INFO - 2018-08-14 18:16:39 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 18:16:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 18:16:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 18:16:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 18:16:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 18:16:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 18:16:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 18:16:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-08-14 18:16:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 18:16:39 --> Final output sent to browser
DEBUG - 2018-08-14 18:16:39 --> Total execution time: 0.0480
INFO - 2018-08-14 18:16:40 --> Config Class Initialized
INFO - 2018-08-14 18:16:40 --> Hooks Class Initialized
DEBUG - 2018-08-14 18:16:40 --> UTF-8 Support Enabled
INFO - 2018-08-14 18:16:40 --> Utf8 Class Initialized
INFO - 2018-08-14 18:16:40 --> URI Class Initialized
INFO - 2018-08-14 18:16:40 --> Router Class Initialized
INFO - 2018-08-14 18:16:40 --> Output Class Initialized
INFO - 2018-08-14 18:16:40 --> Security Class Initialized
DEBUG - 2018-08-14 18:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 18:16:40 --> CSRF cookie sent
INFO - 2018-08-14 18:16:40 --> Input Class Initialized
INFO - 2018-08-14 18:16:40 --> Language Class Initialized
INFO - 2018-08-14 18:16:40 --> Loader Class Initialized
INFO - 2018-08-14 18:16:40 --> Helper loaded: url_helper
INFO - 2018-08-14 18:16:40 --> Helper loaded: form_helper
INFO - 2018-08-14 18:16:40 --> Helper loaded: language_helper
DEBUG - 2018-08-14 18:16:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 18:16:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 18:16:40 --> User Agent Class Initialized
INFO - 2018-08-14 18:16:40 --> Controller Class Initialized
INFO - 2018-08-14 18:16:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 18:16:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 18:16:40 --> Pixel_Model class loaded
INFO - 2018-08-14 18:16:40 --> Database Driver Class Initialized
INFO - 2018-08-14 18:16:40 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 18:16:40 --> Database Driver Class Initialized
INFO - 2018-08-14 18:16:40 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 18:16:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 18:16:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 18:16:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 18:16:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 18:16:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 18:16:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 18:16:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-14 18:16:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 18:16:40 --> Final output sent to browser
DEBUG - 2018-08-14 18:16:40 --> Total execution time: 0.0524
INFO - 2018-08-14 18:16:41 --> Config Class Initialized
INFO - 2018-08-14 18:16:41 --> Hooks Class Initialized
DEBUG - 2018-08-14 18:16:41 --> UTF-8 Support Enabled
INFO - 2018-08-14 18:16:41 --> Utf8 Class Initialized
INFO - 2018-08-14 18:16:41 --> URI Class Initialized
DEBUG - 2018-08-14 18:16:41 --> No URI present. Default controller set.
INFO - 2018-08-14 18:16:41 --> Router Class Initialized
INFO - 2018-08-14 18:16:41 --> Output Class Initialized
INFO - 2018-08-14 18:16:41 --> Security Class Initialized
DEBUG - 2018-08-14 18:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 18:16:41 --> CSRF cookie sent
INFO - 2018-08-14 18:16:41 --> Input Class Initialized
INFO - 2018-08-14 18:16:41 --> Language Class Initialized
INFO - 2018-08-14 18:16:41 --> Loader Class Initialized
INFO - 2018-08-14 18:16:41 --> Helper loaded: url_helper
INFO - 2018-08-14 18:16:41 --> Helper loaded: form_helper
INFO - 2018-08-14 18:16:41 --> Helper loaded: language_helper
DEBUG - 2018-08-14 18:16:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 18:16:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 18:16:41 --> User Agent Class Initialized
INFO - 2018-08-14 18:16:41 --> Controller Class Initialized
INFO - 2018-08-14 18:16:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 18:16:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 18:16:41 --> Pixel_Model class loaded
INFO - 2018-08-14 18:16:41 --> Database Driver Class Initialized
INFO - 2018-08-14 18:16:41 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 18:16:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 18:16:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 18:16:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-14 18:16:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 18:16:41 --> Final output sent to browser
DEBUG - 2018-08-14 18:16:41 --> Total execution time: 0.0368
INFO - 2018-08-14 18:17:50 --> Config Class Initialized
INFO - 2018-08-14 18:17:50 --> Hooks Class Initialized
DEBUG - 2018-08-14 18:17:50 --> UTF-8 Support Enabled
INFO - 2018-08-14 18:17:50 --> Utf8 Class Initialized
INFO - 2018-08-14 18:17:50 --> URI Class Initialized
INFO - 2018-08-14 18:17:50 --> Router Class Initialized
INFO - 2018-08-14 18:17:50 --> Output Class Initialized
INFO - 2018-08-14 18:17:50 --> Security Class Initialized
DEBUG - 2018-08-14 18:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 18:17:50 --> CSRF cookie sent
INFO - 2018-08-14 18:17:50 --> CSRF token verified
INFO - 2018-08-14 18:17:50 --> Input Class Initialized
INFO - 2018-08-14 18:17:50 --> Language Class Initialized
INFO - 2018-08-14 18:17:50 --> Loader Class Initialized
INFO - 2018-08-14 18:17:50 --> Helper loaded: url_helper
INFO - 2018-08-14 18:17:50 --> Helper loaded: form_helper
INFO - 2018-08-14 18:17:50 --> Helper loaded: language_helper
DEBUG - 2018-08-14 18:17:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 18:17:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 18:17:50 --> User Agent Class Initialized
INFO - 2018-08-14 18:17:50 --> Controller Class Initialized
INFO - 2018-08-14 18:17:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 18:17:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 18:17:50 --> Pixel_Model class loaded
INFO - 2018-08-14 18:17:50 --> Database Driver Class Initialized
INFO - 2018-08-14 18:17:50 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 18:17:50 --> Database Driver Class Initialized
INFO - 2018-08-14 18:17:50 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 18:17:50 --> Config Class Initialized
INFO - 2018-08-14 18:17:50 --> Hooks Class Initialized
DEBUG - 2018-08-14 18:17:50 --> UTF-8 Support Enabled
INFO - 2018-08-14 18:17:50 --> Utf8 Class Initialized
INFO - 2018-08-14 18:17:50 --> URI Class Initialized
INFO - 2018-08-14 18:17:50 --> Router Class Initialized
INFO - 2018-08-14 18:17:50 --> Output Class Initialized
INFO - 2018-08-14 18:17:50 --> Security Class Initialized
DEBUG - 2018-08-14 18:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 18:17:50 --> CSRF cookie sent
INFO - 2018-08-14 18:17:50 --> Input Class Initialized
INFO - 2018-08-14 18:17:50 --> Language Class Initialized
INFO - 2018-08-14 18:17:50 --> Loader Class Initialized
INFO - 2018-08-14 18:17:50 --> Helper loaded: url_helper
INFO - 2018-08-14 18:17:50 --> Helper loaded: form_helper
INFO - 2018-08-14 18:17:50 --> Helper loaded: language_helper
DEBUG - 2018-08-14 18:17:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 18:17:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 18:17:50 --> User Agent Class Initialized
INFO - 2018-08-14 18:17:50 --> Controller Class Initialized
INFO - 2018-08-14 18:17:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 18:17:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 18:17:50 --> Pixel_Model class loaded
INFO - 2018-08-14 18:17:50 --> Database Driver Class Initialized
INFO - 2018-08-14 18:17:50 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 18:17:50 --> Database Driver Class Initialized
INFO - 2018-08-14 18:17:50 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 18:17:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 18:17:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 18:17:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-08-14 18:17:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 18:17:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 18:17:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 18:17:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 18:17:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-08-14 18:17:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 18:17:50 --> Final output sent to browser
DEBUG - 2018-08-14 18:17:50 --> Total execution time: 0.0315
INFO - 2018-08-14 18:17:57 --> Config Class Initialized
INFO - 2018-08-14 18:17:57 --> Hooks Class Initialized
DEBUG - 2018-08-14 18:17:57 --> UTF-8 Support Enabled
INFO - 2018-08-14 18:17:57 --> Utf8 Class Initialized
INFO - 2018-08-14 18:17:57 --> URI Class Initialized
INFO - 2018-08-14 18:17:57 --> Router Class Initialized
INFO - 2018-08-14 18:17:57 --> Output Class Initialized
INFO - 2018-08-14 18:17:57 --> Security Class Initialized
DEBUG - 2018-08-14 18:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 18:17:57 --> CSRF cookie sent
INFO - 2018-08-14 18:17:57 --> CSRF token verified
INFO - 2018-08-14 18:17:57 --> Input Class Initialized
INFO - 2018-08-14 18:17:57 --> Language Class Initialized
INFO - 2018-08-14 18:17:57 --> Loader Class Initialized
INFO - 2018-08-14 18:17:57 --> Helper loaded: url_helper
INFO - 2018-08-14 18:17:57 --> Helper loaded: form_helper
INFO - 2018-08-14 18:17:57 --> Helper loaded: language_helper
DEBUG - 2018-08-14 18:17:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 18:17:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 18:17:57 --> User Agent Class Initialized
INFO - 2018-08-14 18:17:57 --> Controller Class Initialized
INFO - 2018-08-14 18:17:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 18:17:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 18:17:57 --> Pixel_Model class loaded
INFO - 2018-08-14 18:17:57 --> Database Driver Class Initialized
INFO - 2018-08-14 18:17:57 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 18:17:57 --> Form Validation Class Initialized
INFO - 2018-08-14 18:17:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 18:17:57 --> Database Driver Class Initialized
INFO - 2018-08-14 18:17:57 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 18:17:57 --> Config Class Initialized
INFO - 2018-08-14 18:17:57 --> Hooks Class Initialized
DEBUG - 2018-08-14 18:17:57 --> UTF-8 Support Enabled
INFO - 2018-08-14 18:17:57 --> Utf8 Class Initialized
INFO - 2018-08-14 18:17:57 --> URI Class Initialized
INFO - 2018-08-14 18:17:57 --> Router Class Initialized
INFO - 2018-08-14 18:17:57 --> Output Class Initialized
INFO - 2018-08-14 18:17:57 --> Security Class Initialized
DEBUG - 2018-08-14 18:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 18:17:57 --> CSRF cookie sent
INFO - 2018-08-14 18:17:57 --> Input Class Initialized
INFO - 2018-08-14 18:17:57 --> Language Class Initialized
INFO - 2018-08-14 18:17:57 --> Loader Class Initialized
INFO - 2018-08-14 18:17:57 --> Helper loaded: url_helper
INFO - 2018-08-14 18:17:57 --> Helper loaded: form_helper
INFO - 2018-08-14 18:17:57 --> Helper loaded: language_helper
DEBUG - 2018-08-14 18:17:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 18:17:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 18:17:57 --> User Agent Class Initialized
INFO - 2018-08-14 18:17:57 --> Controller Class Initialized
INFO - 2018-08-14 18:17:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 18:17:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 18:17:57 --> Pixel_Model class loaded
INFO - 2018-08-14 18:17:57 --> Database Driver Class Initialized
INFO - 2018-08-14 18:17:57 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 18:17:57 --> Database Driver Class Initialized
INFO - 2018-08-14 18:17:57 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 18:17:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 18:17:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 18:17:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 18:17:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 18:17:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 18:17:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 18:17:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-08-14 18:17:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 18:17:57 --> Final output sent to browser
DEBUG - 2018-08-14 18:17:57 --> Total execution time: 0.0383
INFO - 2018-08-14 18:18:00 --> Config Class Initialized
INFO - 2018-08-14 18:18:00 --> Hooks Class Initialized
DEBUG - 2018-08-14 18:18:00 --> UTF-8 Support Enabled
INFO - 2018-08-14 18:18:00 --> Utf8 Class Initialized
INFO - 2018-08-14 18:18:00 --> URI Class Initialized
INFO - 2018-08-14 18:18:00 --> Router Class Initialized
INFO - 2018-08-14 18:18:00 --> Output Class Initialized
INFO - 2018-08-14 18:18:00 --> Security Class Initialized
DEBUG - 2018-08-14 18:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 18:18:00 --> CSRF cookie sent
INFO - 2018-08-14 18:18:00 --> Input Class Initialized
INFO - 2018-08-14 18:18:00 --> Language Class Initialized
INFO - 2018-08-14 18:18:00 --> Loader Class Initialized
INFO - 2018-08-14 18:18:00 --> Helper loaded: url_helper
INFO - 2018-08-14 18:18:00 --> Helper loaded: form_helper
INFO - 2018-08-14 18:18:00 --> Helper loaded: language_helper
DEBUG - 2018-08-14 18:18:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 18:18:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 18:18:00 --> User Agent Class Initialized
INFO - 2018-08-14 18:18:00 --> Controller Class Initialized
INFO - 2018-08-14 18:18:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 18:18:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 18:18:00 --> Pixel_Model class loaded
INFO - 2018-08-14 18:18:00 --> Database Driver Class Initialized
INFO - 2018-08-14 18:18:00 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 18:18:00 --> Database Driver Class Initialized
INFO - 2018-08-14 18:18:00 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 18:18:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 18:18:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 18:18:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-08-14 18:18:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 18:18:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 18:18:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 18:18:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 18:18:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-08-14 18:18:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 18:18:00 --> Final output sent to browser
DEBUG - 2018-08-14 18:18:00 --> Total execution time: 0.0395
INFO - 2018-08-14 18:18:12 --> Config Class Initialized
INFO - 2018-08-14 18:18:12 --> Hooks Class Initialized
DEBUG - 2018-08-14 18:18:12 --> UTF-8 Support Enabled
INFO - 2018-08-14 18:18:12 --> Utf8 Class Initialized
INFO - 2018-08-14 18:18:12 --> URI Class Initialized
INFO - 2018-08-14 18:18:12 --> Router Class Initialized
INFO - 2018-08-14 18:18:12 --> Output Class Initialized
INFO - 2018-08-14 18:18:12 --> Security Class Initialized
DEBUG - 2018-08-14 18:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 18:18:12 --> CSRF cookie sent
INFO - 2018-08-14 18:18:12 --> Input Class Initialized
INFO - 2018-08-14 18:18:12 --> Language Class Initialized
INFO - 2018-08-14 18:18:12 --> Loader Class Initialized
INFO - 2018-08-14 18:18:12 --> Helper loaded: url_helper
INFO - 2018-08-14 18:18:12 --> Helper loaded: form_helper
INFO - 2018-08-14 18:18:12 --> Helper loaded: language_helper
DEBUG - 2018-08-14 18:18:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 18:18:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 18:18:12 --> User Agent Class Initialized
INFO - 2018-08-14 18:18:12 --> Controller Class Initialized
INFO - 2018-08-14 18:18:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 18:18:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 18:18:12 --> Pixel_Model class loaded
INFO - 2018-08-14 18:18:12 --> Database Driver Class Initialized
INFO - 2018-08-14 18:18:12 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 18:18:12 --> Database Driver Class Initialized
INFO - 2018-08-14 18:18:12 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 18:18:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 18:18:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 18:18:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 18:18:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 18:18:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 18:18:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 18:18:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-08-14 18:18:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 18:18:12 --> Final output sent to browser
DEBUG - 2018-08-14 18:18:12 --> Total execution time: 0.0413
INFO - 2018-08-14 18:18:28 --> Config Class Initialized
INFO - 2018-08-14 18:18:28 --> Hooks Class Initialized
DEBUG - 2018-08-14 18:18:28 --> UTF-8 Support Enabled
INFO - 2018-08-14 18:18:28 --> Utf8 Class Initialized
INFO - 2018-08-14 18:18:28 --> URI Class Initialized
INFO - 2018-08-14 18:18:28 --> Router Class Initialized
INFO - 2018-08-14 18:18:28 --> Output Class Initialized
INFO - 2018-08-14 18:18:28 --> Security Class Initialized
DEBUG - 2018-08-14 18:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 18:18:28 --> CSRF cookie sent
INFO - 2018-08-14 18:18:28 --> CSRF token verified
INFO - 2018-08-14 18:18:28 --> Input Class Initialized
INFO - 2018-08-14 18:18:28 --> Language Class Initialized
INFO - 2018-08-14 18:18:28 --> Loader Class Initialized
INFO - 2018-08-14 18:18:28 --> Helper loaded: url_helper
INFO - 2018-08-14 18:18:28 --> Helper loaded: form_helper
INFO - 2018-08-14 18:18:28 --> Helper loaded: language_helper
DEBUG - 2018-08-14 18:18:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 18:18:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 18:18:28 --> User Agent Class Initialized
INFO - 2018-08-14 18:18:28 --> Controller Class Initialized
INFO - 2018-08-14 18:18:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 18:18:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 18:18:28 --> Pixel_Model class loaded
INFO - 2018-08-14 18:18:28 --> Database Driver Class Initialized
INFO - 2018-08-14 18:18:28 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 18:18:28 --> Form Validation Class Initialized
INFO - 2018-08-14 18:18:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 18:18:28 --> Database Driver Class Initialized
INFO - 2018-08-14 18:18:28 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 18:18:29 --> Config Class Initialized
INFO - 2018-08-14 18:18:29 --> Hooks Class Initialized
DEBUG - 2018-08-14 18:18:29 --> UTF-8 Support Enabled
INFO - 2018-08-14 18:18:29 --> Utf8 Class Initialized
INFO - 2018-08-14 18:18:29 --> URI Class Initialized
INFO - 2018-08-14 18:18:29 --> Router Class Initialized
INFO - 2018-08-14 18:18:29 --> Output Class Initialized
INFO - 2018-08-14 18:18:29 --> Security Class Initialized
DEBUG - 2018-08-14 18:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 18:18:29 --> CSRF cookie sent
INFO - 2018-08-14 18:18:29 --> Input Class Initialized
INFO - 2018-08-14 18:18:29 --> Language Class Initialized
INFO - 2018-08-14 18:18:29 --> Loader Class Initialized
INFO - 2018-08-14 18:18:29 --> Helper loaded: url_helper
INFO - 2018-08-14 18:18:29 --> Helper loaded: form_helper
INFO - 2018-08-14 18:18:29 --> Helper loaded: language_helper
DEBUG - 2018-08-14 18:18:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 18:18:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 18:18:29 --> User Agent Class Initialized
INFO - 2018-08-14 18:18:29 --> Controller Class Initialized
INFO - 2018-08-14 18:18:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 18:18:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 18:18:29 --> Pixel_Model class loaded
INFO - 2018-08-14 18:18:29 --> Database Driver Class Initialized
INFO - 2018-08-14 18:18:29 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 18:18:29 --> Database Driver Class Initialized
INFO - 2018-08-14 18:18:29 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 18:18:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 18:18:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 18:18:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 18:18:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 18:18:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 18:18:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 18:18:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-08-14 18:18:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 18:18:29 --> Final output sent to browser
DEBUG - 2018-08-14 18:18:29 --> Total execution time: 0.0448
INFO - 2018-08-14 18:18:35 --> Config Class Initialized
INFO - 2018-08-14 18:18:35 --> Hooks Class Initialized
DEBUG - 2018-08-14 18:18:35 --> UTF-8 Support Enabled
INFO - 2018-08-14 18:18:35 --> Utf8 Class Initialized
INFO - 2018-08-14 18:18:35 --> URI Class Initialized
INFO - 2018-08-14 18:18:35 --> Router Class Initialized
INFO - 2018-08-14 18:18:35 --> Output Class Initialized
INFO - 2018-08-14 18:18:35 --> Security Class Initialized
DEBUG - 2018-08-14 18:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 18:18:35 --> CSRF cookie sent
INFO - 2018-08-14 18:18:35 --> Input Class Initialized
INFO - 2018-08-14 18:18:35 --> Language Class Initialized
INFO - 2018-08-14 18:18:35 --> Loader Class Initialized
INFO - 2018-08-14 18:18:35 --> Helper loaded: url_helper
INFO - 2018-08-14 18:18:35 --> Helper loaded: form_helper
INFO - 2018-08-14 18:18:35 --> Helper loaded: language_helper
DEBUG - 2018-08-14 18:18:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 18:18:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 18:18:35 --> User Agent Class Initialized
INFO - 2018-08-14 18:18:35 --> Controller Class Initialized
INFO - 2018-08-14 18:18:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 18:18:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 18:18:35 --> Pixel_Model class loaded
INFO - 2018-08-14 18:18:35 --> Database Driver Class Initialized
INFO - 2018-08-14 18:18:35 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 18:18:35 --> Database Driver Class Initialized
INFO - 2018-08-14 18:18:35 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 18:18:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 18:18:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 18:18:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 18:18:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 18:18:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 18:18:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 18:18:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-08-14 18:18:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 18:18:35 --> Final output sent to browser
DEBUG - 2018-08-14 18:18:35 --> Total execution time: 0.0612
INFO - 2018-08-14 18:20:11 --> Config Class Initialized
INFO - 2018-08-14 18:20:11 --> Hooks Class Initialized
DEBUG - 2018-08-14 18:20:11 --> UTF-8 Support Enabled
INFO - 2018-08-14 18:20:11 --> Utf8 Class Initialized
INFO - 2018-08-14 18:20:11 --> URI Class Initialized
INFO - 2018-08-14 18:20:11 --> Router Class Initialized
INFO - 2018-08-14 18:20:11 --> Output Class Initialized
INFO - 2018-08-14 18:20:11 --> Security Class Initialized
DEBUG - 2018-08-14 18:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 18:20:11 --> CSRF cookie sent
INFO - 2018-08-14 18:20:11 --> Input Class Initialized
INFO - 2018-08-14 18:20:11 --> Language Class Initialized
INFO - 2018-08-14 18:20:11 --> Loader Class Initialized
INFO - 2018-08-14 18:20:11 --> Helper loaded: url_helper
INFO - 2018-08-14 18:20:11 --> Helper loaded: form_helper
INFO - 2018-08-14 18:20:11 --> Helper loaded: language_helper
DEBUG - 2018-08-14 18:20:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 18:20:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 18:20:11 --> User Agent Class Initialized
INFO - 2018-08-14 18:20:11 --> Controller Class Initialized
INFO - 2018-08-14 18:20:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 18:20:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 18:20:11 --> Pixel_Model class loaded
INFO - 2018-08-14 18:20:11 --> Database Driver Class Initialized
INFO - 2018-08-14 18:20:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 18:20:11 --> Database Driver Class Initialized
INFO - 2018-08-14 18:20:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 18:20:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 18:20:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 18:20:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 18:20:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 18:20:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-08-14 18:20:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 18:20:11 --> Final output sent to browser
DEBUG - 2018-08-14 18:20:11 --> Total execution time: 0.0532
INFO - 2018-08-14 18:21:13 --> Config Class Initialized
INFO - 2018-08-14 18:21:13 --> Hooks Class Initialized
DEBUG - 2018-08-14 18:21:13 --> UTF-8 Support Enabled
INFO - 2018-08-14 18:21:13 --> Utf8 Class Initialized
INFO - 2018-08-14 18:21:13 --> URI Class Initialized
INFO - 2018-08-14 18:21:13 --> Router Class Initialized
INFO - 2018-08-14 18:21:13 --> Output Class Initialized
INFO - 2018-08-14 18:21:13 --> Security Class Initialized
DEBUG - 2018-08-14 18:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 18:21:13 --> CSRF cookie sent
INFO - 2018-08-14 18:21:13 --> Input Class Initialized
INFO - 2018-08-14 18:21:13 --> Language Class Initialized
INFO - 2018-08-14 18:21:13 --> Loader Class Initialized
INFO - 2018-08-14 18:21:13 --> Helper loaded: url_helper
INFO - 2018-08-14 18:21:13 --> Helper loaded: form_helper
INFO - 2018-08-14 18:21:13 --> Helper loaded: language_helper
DEBUG - 2018-08-14 18:21:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 18:21:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 18:21:13 --> User Agent Class Initialized
INFO - 2018-08-14 18:21:13 --> Controller Class Initialized
INFO - 2018-08-14 18:21:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 18:21:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 18:21:13 --> Pixel_Model class loaded
INFO - 2018-08-14 18:21:13 --> Database Driver Class Initialized
INFO - 2018-08-14 18:21:13 --> Model "MyAccountModel" initialized
ERROR - 2018-08-14 18:21:13 --> 404 Page Not Found: 
INFO - 2018-08-14 18:21:16 --> Config Class Initialized
INFO - 2018-08-14 18:21:16 --> Hooks Class Initialized
DEBUG - 2018-08-14 18:21:16 --> UTF-8 Support Enabled
INFO - 2018-08-14 18:21:16 --> Utf8 Class Initialized
INFO - 2018-08-14 18:21:16 --> URI Class Initialized
INFO - 2018-08-14 18:21:16 --> Router Class Initialized
INFO - 2018-08-14 18:21:16 --> Output Class Initialized
INFO - 2018-08-14 18:21:16 --> Security Class Initialized
DEBUG - 2018-08-14 18:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 18:21:16 --> CSRF cookie sent
INFO - 2018-08-14 18:21:16 --> Input Class Initialized
INFO - 2018-08-14 18:21:16 --> Language Class Initialized
INFO - 2018-08-14 18:21:16 --> Loader Class Initialized
INFO - 2018-08-14 18:21:16 --> Helper loaded: url_helper
INFO - 2018-08-14 18:21:16 --> Helper loaded: form_helper
INFO - 2018-08-14 18:21:16 --> Helper loaded: language_helper
DEBUG - 2018-08-14 18:21:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 18:21:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 18:21:16 --> User Agent Class Initialized
INFO - 2018-08-14 18:21:16 --> Controller Class Initialized
INFO - 2018-08-14 18:21:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 18:21:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 18:21:16 --> Pixel_Model class loaded
INFO - 2018-08-14 18:21:16 --> Database Driver Class Initialized
INFO - 2018-08-14 18:21:16 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 18:21:16 --> Database Driver Class Initialized
INFO - 2018-08-14 18:21:16 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 18:21:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 18:21:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 18:21:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 18:21:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 18:21:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-08-14 18:21:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 18:21:16 --> Final output sent to browser
DEBUG - 2018-08-14 18:21:16 --> Total execution time: 0.0494
INFO - 2018-08-14 18:35:38 --> Config Class Initialized
INFO - 2018-08-14 18:35:38 --> Hooks Class Initialized
DEBUG - 2018-08-14 18:35:38 --> UTF-8 Support Enabled
INFO - 2018-08-14 18:35:38 --> Utf8 Class Initialized
INFO - 2018-08-14 18:35:38 --> URI Class Initialized
INFO - 2018-08-14 18:35:38 --> Router Class Initialized
INFO - 2018-08-14 18:35:38 --> Output Class Initialized
INFO - 2018-08-14 18:35:38 --> Security Class Initialized
DEBUG - 2018-08-14 18:35:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 18:35:38 --> CSRF cookie sent
INFO - 2018-08-14 18:35:38 --> Input Class Initialized
INFO - 2018-08-14 18:35:38 --> Language Class Initialized
INFO - 2018-08-14 18:35:38 --> Loader Class Initialized
INFO - 2018-08-14 18:35:38 --> Helper loaded: url_helper
INFO - 2018-08-14 18:35:38 --> Helper loaded: form_helper
INFO - 2018-08-14 18:35:38 --> Helper loaded: language_helper
DEBUG - 2018-08-14 18:35:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 18:35:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 18:35:38 --> User Agent Class Initialized
INFO - 2018-08-14 18:35:38 --> Controller Class Initialized
INFO - 2018-08-14 18:35:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 18:35:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 18:35:38 --> Pixel_Model class loaded
INFO - 2018-08-14 18:35:38 --> Database Driver Class Initialized
INFO - 2018-08-14 18:35:38 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 18:35:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 18:35:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 18:35:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 18:35:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 18:35:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 18:35:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 18:35:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-08-14 18:35:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 18:35:38 --> Final output sent to browser
DEBUG - 2018-08-14 18:35:38 --> Total execution time: 0.0594
INFO - 2018-08-14 18:41:05 --> Config Class Initialized
INFO - 2018-08-14 18:41:05 --> Hooks Class Initialized
DEBUG - 2018-08-14 18:41:05 --> UTF-8 Support Enabled
INFO - 2018-08-14 18:41:05 --> Utf8 Class Initialized
INFO - 2018-08-14 18:41:05 --> URI Class Initialized
INFO - 2018-08-14 18:41:05 --> Router Class Initialized
INFO - 2018-08-14 18:41:05 --> Output Class Initialized
INFO - 2018-08-14 18:41:05 --> Security Class Initialized
DEBUG - 2018-08-14 18:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 18:41:05 --> CSRF cookie sent
INFO - 2018-08-14 18:41:05 --> Input Class Initialized
INFO - 2018-08-14 18:41:05 --> Language Class Initialized
INFO - 2018-08-14 18:41:05 --> Loader Class Initialized
INFO - 2018-08-14 18:41:05 --> Helper loaded: url_helper
INFO - 2018-08-14 18:41:05 --> Helper loaded: form_helper
INFO - 2018-08-14 18:41:05 --> Helper loaded: language_helper
DEBUG - 2018-08-14 18:41:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 18:41:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 18:41:05 --> User Agent Class Initialized
INFO - 2018-08-14 18:41:05 --> Controller Class Initialized
INFO - 2018-08-14 18:41:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 18:41:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 18:41:05 --> Pixel_Model class loaded
INFO - 2018-08-14 18:41:05 --> Database Driver Class Initialized
INFO - 2018-08-14 18:41:05 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 18:41:06 --> Config Class Initialized
INFO - 2018-08-14 18:41:06 --> Hooks Class Initialized
DEBUG - 2018-08-14 18:41:06 --> UTF-8 Support Enabled
INFO - 2018-08-14 18:41:06 --> Utf8 Class Initialized
INFO - 2018-08-14 18:41:06 --> URI Class Initialized
INFO - 2018-08-14 18:41:06 --> Router Class Initialized
INFO - 2018-08-14 18:41:06 --> Output Class Initialized
INFO - 2018-08-14 18:41:06 --> Security Class Initialized
DEBUG - 2018-08-14 18:41:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 18:41:06 --> CSRF cookie sent
INFO - 2018-08-14 18:41:06 --> Input Class Initialized
INFO - 2018-08-14 18:41:06 --> Language Class Initialized
INFO - 2018-08-14 18:41:06 --> Loader Class Initialized
INFO - 2018-08-14 18:41:06 --> Helper loaded: url_helper
INFO - 2018-08-14 18:41:06 --> Helper loaded: form_helper
INFO - 2018-08-14 18:41:06 --> Helper loaded: language_helper
DEBUG - 2018-08-14 18:41:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 18:41:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 18:41:06 --> User Agent Class Initialized
INFO - 2018-08-14 18:41:06 --> Controller Class Initialized
INFO - 2018-08-14 18:41:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 18:41:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 18:41:06 --> Pixel_Model class loaded
INFO - 2018-08-14 18:41:06 --> Database Driver Class Initialized
INFO - 2018-08-14 18:41:06 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 18:41:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 18:41:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 18:41:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 18:41:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 18:41:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 18:41:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 18:41:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-08-14 18:41:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 18:41:06 --> Final output sent to browser
DEBUG - 2018-08-14 18:41:06 --> Total execution time: 0.0448
INFO - 2018-08-14 18:41:23 --> Config Class Initialized
INFO - 2018-08-14 18:41:23 --> Hooks Class Initialized
DEBUG - 2018-08-14 18:41:23 --> UTF-8 Support Enabled
INFO - 2018-08-14 18:41:23 --> Utf8 Class Initialized
INFO - 2018-08-14 18:41:23 --> URI Class Initialized
INFO - 2018-08-14 18:41:23 --> Router Class Initialized
INFO - 2018-08-14 18:41:23 --> Output Class Initialized
INFO - 2018-08-14 18:41:23 --> Security Class Initialized
DEBUG - 2018-08-14 18:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 18:41:23 --> CSRF cookie sent
INFO - 2018-08-14 18:41:23 --> CSRF token verified
INFO - 2018-08-14 18:41:23 --> Input Class Initialized
INFO - 2018-08-14 18:41:23 --> Language Class Initialized
INFO - 2018-08-14 18:41:23 --> Loader Class Initialized
INFO - 2018-08-14 18:41:23 --> Helper loaded: url_helper
INFO - 2018-08-14 18:41:23 --> Helper loaded: form_helper
INFO - 2018-08-14 18:41:23 --> Helper loaded: language_helper
DEBUG - 2018-08-14 18:41:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 18:41:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 18:41:23 --> User Agent Class Initialized
INFO - 2018-08-14 18:41:23 --> Controller Class Initialized
INFO - 2018-08-14 18:41:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 18:41:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 18:41:23 --> Pixel_Model class loaded
INFO - 2018-08-14 18:41:23 --> Database Driver Class Initialized
INFO - 2018-08-14 18:41:23 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 18:41:23 --> Database Driver Class Initialized
INFO - 2018-08-14 18:41:23 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 18:41:24 --> Config Class Initialized
INFO - 2018-08-14 18:41:24 --> Hooks Class Initialized
DEBUG - 2018-08-14 18:41:24 --> UTF-8 Support Enabled
INFO - 2018-08-14 18:41:24 --> Utf8 Class Initialized
INFO - 2018-08-14 18:41:24 --> URI Class Initialized
INFO - 2018-08-14 18:41:24 --> Router Class Initialized
INFO - 2018-08-14 18:41:24 --> Output Class Initialized
INFO - 2018-08-14 18:41:24 --> Security Class Initialized
DEBUG - 2018-08-14 18:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 18:41:24 --> CSRF cookie sent
INFO - 2018-08-14 18:41:24 --> Input Class Initialized
INFO - 2018-08-14 18:41:24 --> Language Class Initialized
INFO - 2018-08-14 18:41:24 --> Loader Class Initialized
INFO - 2018-08-14 18:41:24 --> Helper loaded: url_helper
INFO - 2018-08-14 18:41:24 --> Helper loaded: form_helper
INFO - 2018-08-14 18:41:24 --> Helper loaded: language_helper
DEBUG - 2018-08-14 18:41:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 18:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 18:41:24 --> User Agent Class Initialized
INFO - 2018-08-14 18:41:24 --> Controller Class Initialized
INFO - 2018-08-14 18:41:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 18:41:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 18:41:24 --> Pixel_Model class loaded
INFO - 2018-08-14 18:41:24 --> Database Driver Class Initialized
INFO - 2018-08-14 18:41:24 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 18:41:24 --> Database Driver Class Initialized
INFO - 2018-08-14 18:41:24 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 18:41:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 18:41:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 18:41:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 18:41:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 18:41:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 18:41:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 18:41:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-14 18:41:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 18:41:24 --> Final output sent to browser
DEBUG - 2018-08-14 18:41:24 --> Total execution time: 0.0441
INFO - 2018-08-14 18:41:37 --> Config Class Initialized
INFO - 2018-08-14 18:41:37 --> Hooks Class Initialized
DEBUG - 2018-08-14 18:41:37 --> UTF-8 Support Enabled
INFO - 2018-08-14 18:41:37 --> Utf8 Class Initialized
INFO - 2018-08-14 18:41:37 --> URI Class Initialized
INFO - 2018-08-14 18:41:37 --> Router Class Initialized
INFO - 2018-08-14 18:41:37 --> Output Class Initialized
INFO - 2018-08-14 18:41:37 --> Security Class Initialized
DEBUG - 2018-08-14 18:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 18:41:37 --> CSRF cookie sent
INFO - 2018-08-14 18:41:37 --> CSRF token verified
INFO - 2018-08-14 18:41:37 --> Input Class Initialized
INFO - 2018-08-14 18:41:37 --> Language Class Initialized
INFO - 2018-08-14 18:41:37 --> Loader Class Initialized
INFO - 2018-08-14 18:41:37 --> Helper loaded: url_helper
INFO - 2018-08-14 18:41:37 --> Helper loaded: form_helper
INFO - 2018-08-14 18:41:37 --> Helper loaded: language_helper
DEBUG - 2018-08-14 18:41:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 18:41:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 18:41:37 --> User Agent Class Initialized
INFO - 2018-08-14 18:41:37 --> Controller Class Initialized
INFO - 2018-08-14 18:41:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 18:41:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 18:41:37 --> Pixel_Model class loaded
INFO - 2018-08-14 18:41:37 --> Database Driver Class Initialized
INFO - 2018-08-14 18:41:37 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 18:41:37 --> Form Validation Class Initialized
INFO - 2018-08-14 18:41:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 18:41:37 --> Database Driver Class Initialized
INFO - 2018-08-14 18:41:37 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 18:41:38 --> Config Class Initialized
INFO - 2018-08-14 18:41:38 --> Hooks Class Initialized
DEBUG - 2018-08-14 18:41:38 --> UTF-8 Support Enabled
INFO - 2018-08-14 18:41:38 --> Utf8 Class Initialized
INFO - 2018-08-14 18:41:38 --> URI Class Initialized
INFO - 2018-08-14 18:41:38 --> Router Class Initialized
INFO - 2018-08-14 18:41:38 --> Output Class Initialized
INFO - 2018-08-14 18:41:38 --> Security Class Initialized
DEBUG - 2018-08-14 18:41:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 18:41:38 --> CSRF cookie sent
INFO - 2018-08-14 18:41:38 --> Input Class Initialized
INFO - 2018-08-14 18:41:38 --> Language Class Initialized
INFO - 2018-08-14 18:41:38 --> Loader Class Initialized
INFO - 2018-08-14 18:41:38 --> Helper loaded: url_helper
INFO - 2018-08-14 18:41:38 --> Helper loaded: form_helper
INFO - 2018-08-14 18:41:38 --> Helper loaded: language_helper
DEBUG - 2018-08-14 18:41:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 18:41:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 18:41:38 --> User Agent Class Initialized
INFO - 2018-08-14 18:41:38 --> Controller Class Initialized
INFO - 2018-08-14 18:41:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 18:41:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 18:41:38 --> Pixel_Model class loaded
INFO - 2018-08-14 18:41:38 --> Database Driver Class Initialized
INFO - 2018-08-14 18:41:38 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 18:41:38 --> Database Driver Class Initialized
INFO - 2018-08-14 18:41:38 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 18:41:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 18:41:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 18:41:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 18:41:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 18:41:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 18:41:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 18:41:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-08-14 18:41:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 18:41:38 --> Final output sent to browser
DEBUG - 2018-08-14 18:41:38 --> Total execution time: 0.0447
INFO - 2018-08-14 18:41:43 --> Config Class Initialized
INFO - 2018-08-14 18:41:43 --> Hooks Class Initialized
DEBUG - 2018-08-14 18:41:43 --> UTF-8 Support Enabled
INFO - 2018-08-14 18:41:43 --> Utf8 Class Initialized
INFO - 2018-08-14 18:41:43 --> URI Class Initialized
INFO - 2018-08-14 18:41:43 --> Router Class Initialized
INFO - 2018-08-14 18:41:43 --> Output Class Initialized
INFO - 2018-08-14 18:41:43 --> Security Class Initialized
DEBUG - 2018-08-14 18:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 18:41:43 --> CSRF cookie sent
INFO - 2018-08-14 18:41:43 --> Input Class Initialized
INFO - 2018-08-14 18:41:43 --> Language Class Initialized
INFO - 2018-08-14 18:41:43 --> Loader Class Initialized
INFO - 2018-08-14 18:41:43 --> Helper loaded: url_helper
INFO - 2018-08-14 18:41:43 --> Helper loaded: form_helper
INFO - 2018-08-14 18:41:43 --> Helper loaded: language_helper
DEBUG - 2018-08-14 18:41:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 18:41:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 18:41:43 --> User Agent Class Initialized
INFO - 2018-08-14 18:41:43 --> Controller Class Initialized
INFO - 2018-08-14 18:41:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 18:41:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 18:41:43 --> Pixel_Model class loaded
INFO - 2018-08-14 18:41:43 --> Database Driver Class Initialized
INFO - 2018-08-14 18:41:43 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 18:41:43 --> Database Driver Class Initialized
INFO - 2018-08-14 18:41:43 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 18:41:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 18:41:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 18:41:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 18:41:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 18:41:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 18:41:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 18:41:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-14 18:41:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 18:41:43 --> Final output sent to browser
DEBUG - 2018-08-14 18:41:43 --> Total execution time: 0.0447
INFO - 2018-08-14 18:41:51 --> Config Class Initialized
INFO - 2018-08-14 18:41:51 --> Hooks Class Initialized
DEBUG - 2018-08-14 18:41:51 --> UTF-8 Support Enabled
INFO - 2018-08-14 18:41:51 --> Utf8 Class Initialized
INFO - 2018-08-14 18:41:51 --> URI Class Initialized
INFO - 2018-08-14 18:41:51 --> Router Class Initialized
INFO - 2018-08-14 18:41:51 --> Output Class Initialized
INFO - 2018-08-14 18:41:51 --> Security Class Initialized
DEBUG - 2018-08-14 18:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 18:41:51 --> CSRF cookie sent
INFO - 2018-08-14 18:41:51 --> CSRF token verified
INFO - 2018-08-14 18:41:51 --> Input Class Initialized
INFO - 2018-08-14 18:41:51 --> Language Class Initialized
INFO - 2018-08-14 18:41:51 --> Loader Class Initialized
INFO - 2018-08-14 18:41:51 --> Helper loaded: url_helper
INFO - 2018-08-14 18:41:51 --> Helper loaded: form_helper
INFO - 2018-08-14 18:41:51 --> Helper loaded: language_helper
DEBUG - 2018-08-14 18:41:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 18:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 18:41:51 --> User Agent Class Initialized
INFO - 2018-08-14 18:41:51 --> Controller Class Initialized
INFO - 2018-08-14 18:41:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 18:41:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 18:41:51 --> Pixel_Model class loaded
INFO - 2018-08-14 18:41:51 --> Database Driver Class Initialized
INFO - 2018-08-14 18:41:51 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 18:41:51 --> Form Validation Class Initialized
INFO - 2018-08-14 18:41:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 18:41:51 --> Database Driver Class Initialized
INFO - 2018-08-14 18:41:51 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 18:41:52 --> Config Class Initialized
INFO - 2018-08-14 18:41:52 --> Hooks Class Initialized
DEBUG - 2018-08-14 18:41:52 --> UTF-8 Support Enabled
INFO - 2018-08-14 18:41:52 --> Utf8 Class Initialized
INFO - 2018-08-14 18:41:52 --> URI Class Initialized
INFO - 2018-08-14 18:41:52 --> Router Class Initialized
INFO - 2018-08-14 18:41:52 --> Output Class Initialized
INFO - 2018-08-14 18:41:52 --> Security Class Initialized
DEBUG - 2018-08-14 18:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 18:41:52 --> CSRF cookie sent
INFO - 2018-08-14 18:41:52 --> Input Class Initialized
INFO - 2018-08-14 18:41:52 --> Language Class Initialized
INFO - 2018-08-14 18:41:52 --> Loader Class Initialized
INFO - 2018-08-14 18:41:52 --> Helper loaded: url_helper
INFO - 2018-08-14 18:41:52 --> Helper loaded: form_helper
INFO - 2018-08-14 18:41:52 --> Helper loaded: language_helper
DEBUG - 2018-08-14 18:41:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 18:41:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 18:41:52 --> User Agent Class Initialized
INFO - 2018-08-14 18:41:52 --> Controller Class Initialized
INFO - 2018-08-14 18:41:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 18:41:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 18:41:52 --> Pixel_Model class loaded
INFO - 2018-08-14 18:41:52 --> Database Driver Class Initialized
INFO - 2018-08-14 18:41:52 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 18:41:52 --> Database Driver Class Initialized
INFO - 2018-08-14 18:41:52 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 18:41:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 18:41:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 18:41:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 18:41:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 18:41:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 18:41:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 18:41:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-08-14 18:41:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 18:41:52 --> Final output sent to browser
DEBUG - 2018-08-14 18:41:52 --> Total execution time: 0.0593
INFO - 2018-08-14 20:20:13 --> Config Class Initialized
INFO - 2018-08-14 20:20:13 --> Hooks Class Initialized
DEBUG - 2018-08-14 20:20:13 --> UTF-8 Support Enabled
INFO - 2018-08-14 20:20:13 --> Utf8 Class Initialized
INFO - 2018-08-14 20:20:13 --> URI Class Initialized
DEBUG - 2018-08-14 20:20:13 --> No URI present. Default controller set.
INFO - 2018-08-14 20:20:13 --> Router Class Initialized
INFO - 2018-08-14 20:20:13 --> Output Class Initialized
INFO - 2018-08-14 20:20:13 --> Security Class Initialized
DEBUG - 2018-08-14 20:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 20:20:13 --> CSRF cookie sent
INFO - 2018-08-14 20:20:13 --> Input Class Initialized
INFO - 2018-08-14 20:20:13 --> Language Class Initialized
INFO - 2018-08-14 20:20:13 --> Loader Class Initialized
INFO - 2018-08-14 20:20:13 --> Helper loaded: url_helper
INFO - 2018-08-14 20:20:13 --> Helper loaded: form_helper
INFO - 2018-08-14 20:20:13 --> Helper loaded: language_helper
DEBUG - 2018-08-14 20:20:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 20:20:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 20:20:13 --> User Agent Class Initialized
INFO - 2018-08-14 20:20:13 --> Controller Class Initialized
INFO - 2018-08-14 20:20:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 20:20:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 20:20:13 --> Pixel_Model class loaded
INFO - 2018-08-14 20:20:13 --> Database Driver Class Initialized
INFO - 2018-08-14 20:20:13 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 20:20:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 20:20:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 20:20:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-14 20:20:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 20:20:13 --> Final output sent to browser
DEBUG - 2018-08-14 20:20:13 --> Total execution time: 0.0346
INFO - 2018-08-14 20:20:14 --> Config Class Initialized
INFO - 2018-08-14 20:20:14 --> Hooks Class Initialized
DEBUG - 2018-08-14 20:20:14 --> UTF-8 Support Enabled
INFO - 2018-08-14 20:20:14 --> Utf8 Class Initialized
INFO - 2018-08-14 20:20:14 --> URI Class Initialized
DEBUG - 2018-08-14 20:20:14 --> No URI present. Default controller set.
INFO - 2018-08-14 20:20:14 --> Router Class Initialized
INFO - 2018-08-14 20:20:14 --> Output Class Initialized
INFO - 2018-08-14 20:20:14 --> Security Class Initialized
DEBUG - 2018-08-14 20:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 20:20:14 --> CSRF cookie sent
INFO - 2018-08-14 20:20:14 --> Input Class Initialized
INFO - 2018-08-14 20:20:14 --> Language Class Initialized
INFO - 2018-08-14 20:20:14 --> Loader Class Initialized
INFO - 2018-08-14 20:20:14 --> Helper loaded: url_helper
INFO - 2018-08-14 20:20:14 --> Helper loaded: form_helper
INFO - 2018-08-14 20:20:14 --> Helper loaded: language_helper
DEBUG - 2018-08-14 20:20:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 20:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 20:20:14 --> User Agent Class Initialized
INFO - 2018-08-14 20:20:14 --> Controller Class Initialized
INFO - 2018-08-14 20:20:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 20:20:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 20:20:14 --> Pixel_Model class loaded
INFO - 2018-08-14 20:20:14 --> Database Driver Class Initialized
INFO - 2018-08-14 20:20:14 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 20:20:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 20:20:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 20:20:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-14 20:20:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 20:20:14 --> Final output sent to browser
DEBUG - 2018-08-14 20:20:14 --> Total execution time: 0.0342
INFO - 2018-08-14 20:20:21 --> Config Class Initialized
INFO - 2018-08-14 20:20:21 --> Hooks Class Initialized
DEBUG - 2018-08-14 20:20:21 --> UTF-8 Support Enabled
INFO - 2018-08-14 20:20:21 --> Utf8 Class Initialized
INFO - 2018-08-14 20:20:21 --> URI Class Initialized
INFO - 2018-08-14 20:20:21 --> Router Class Initialized
INFO - 2018-08-14 20:20:21 --> Output Class Initialized
INFO - 2018-08-14 20:20:21 --> Security Class Initialized
DEBUG - 2018-08-14 20:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 20:20:21 --> CSRF cookie sent
INFO - 2018-08-14 20:20:21 --> CSRF token verified
INFO - 2018-08-14 20:20:21 --> Input Class Initialized
INFO - 2018-08-14 20:20:21 --> Language Class Initialized
INFO - 2018-08-14 20:20:21 --> Loader Class Initialized
INFO - 2018-08-14 20:20:21 --> Helper loaded: url_helper
INFO - 2018-08-14 20:20:21 --> Helper loaded: form_helper
INFO - 2018-08-14 20:20:21 --> Helper loaded: language_helper
DEBUG - 2018-08-14 20:20:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 20:20:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 20:20:21 --> User Agent Class Initialized
INFO - 2018-08-14 20:20:21 --> Controller Class Initialized
INFO - 2018-08-14 20:20:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 20:20:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 20:20:21 --> Pixel_Model class loaded
INFO - 2018-08-14 20:20:21 --> Database Driver Class Initialized
INFO - 2018-08-14 20:20:21 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 20:20:21 --> Database Driver Class Initialized
INFO - 2018-08-14 20:20:21 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 20:20:21 --> Config Class Initialized
INFO - 2018-08-14 20:20:21 --> Hooks Class Initialized
DEBUG - 2018-08-14 20:20:21 --> UTF-8 Support Enabled
INFO - 2018-08-14 20:20:21 --> Utf8 Class Initialized
INFO - 2018-08-14 20:20:21 --> URI Class Initialized
INFO - 2018-08-14 20:20:21 --> Router Class Initialized
INFO - 2018-08-14 20:20:21 --> Output Class Initialized
INFO - 2018-08-14 20:20:21 --> Security Class Initialized
DEBUG - 2018-08-14 20:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 20:20:21 --> CSRF cookie sent
INFO - 2018-08-14 20:20:21 --> Input Class Initialized
INFO - 2018-08-14 20:20:21 --> Language Class Initialized
INFO - 2018-08-14 20:20:21 --> Loader Class Initialized
INFO - 2018-08-14 20:20:21 --> Helper loaded: url_helper
INFO - 2018-08-14 20:20:21 --> Helper loaded: form_helper
INFO - 2018-08-14 20:20:21 --> Helper loaded: language_helper
DEBUG - 2018-08-14 20:20:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 20:20:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 20:20:21 --> User Agent Class Initialized
INFO - 2018-08-14 20:20:21 --> Controller Class Initialized
INFO - 2018-08-14 20:20:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 20:20:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 20:20:21 --> Pixel_Model class loaded
INFO - 2018-08-14 20:20:21 --> Database Driver Class Initialized
INFO - 2018-08-14 20:20:21 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 20:20:21 --> Database Driver Class Initialized
INFO - 2018-08-14 20:20:21 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 20:20:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 20:20:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 20:20:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 20:20:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 20:20:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 20:20:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 20:20:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-14 20:20:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 20:20:21 --> Final output sent to browser
DEBUG - 2018-08-14 20:20:21 --> Total execution time: 0.0557
INFO - 2018-08-14 20:31:46 --> Config Class Initialized
INFO - 2018-08-14 20:31:46 --> Hooks Class Initialized
DEBUG - 2018-08-14 20:31:46 --> UTF-8 Support Enabled
INFO - 2018-08-14 20:31:46 --> Utf8 Class Initialized
INFO - 2018-08-14 20:31:46 --> URI Class Initialized
INFO - 2018-08-14 20:31:46 --> Router Class Initialized
INFO - 2018-08-14 20:31:46 --> Output Class Initialized
INFO - 2018-08-14 20:31:46 --> Security Class Initialized
DEBUG - 2018-08-14 20:31:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 20:31:46 --> CSRF cookie sent
INFO - 2018-08-14 20:31:46 --> Input Class Initialized
INFO - 2018-08-14 20:31:46 --> Language Class Initialized
INFO - 2018-08-14 20:31:46 --> Loader Class Initialized
INFO - 2018-08-14 20:31:46 --> Helper loaded: url_helper
INFO - 2018-08-14 20:31:46 --> Helper loaded: form_helper
INFO - 2018-08-14 20:31:46 --> Helper loaded: language_helper
DEBUG - 2018-08-14 20:31:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 20:31:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 20:31:46 --> User Agent Class Initialized
INFO - 2018-08-14 20:31:46 --> Controller Class Initialized
INFO - 2018-08-14 20:31:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 20:31:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 20:31:46 --> Pixel_Model class loaded
INFO - 2018-08-14 20:31:46 --> Database Driver Class Initialized
INFO - 2018-08-14 20:31:46 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 20:31:46 --> Database Driver Class Initialized
INFO - 2018-08-14 20:31:46 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 20:31:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 20:31:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 20:31:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 20:31:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 20:31:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 20:31:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 20:31:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-08-14 20:31:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 20:31:46 --> Final output sent to browser
DEBUG - 2018-08-14 20:31:46 --> Total execution time: 0.0450
INFO - 2018-08-14 20:32:00 --> Config Class Initialized
INFO - 2018-08-14 20:32:00 --> Hooks Class Initialized
DEBUG - 2018-08-14 20:32:00 --> UTF-8 Support Enabled
INFO - 2018-08-14 20:32:00 --> Utf8 Class Initialized
INFO - 2018-08-14 20:32:00 --> URI Class Initialized
INFO - 2018-08-14 20:32:00 --> Router Class Initialized
INFO - 2018-08-14 20:32:00 --> Output Class Initialized
INFO - 2018-08-14 20:32:00 --> Security Class Initialized
DEBUG - 2018-08-14 20:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 20:32:00 --> CSRF cookie sent
INFO - 2018-08-14 20:32:00 --> Input Class Initialized
INFO - 2018-08-14 20:32:00 --> Language Class Initialized
INFO - 2018-08-14 20:32:00 --> Loader Class Initialized
INFO - 2018-08-14 20:32:00 --> Helper loaded: url_helper
INFO - 2018-08-14 20:32:00 --> Helper loaded: form_helper
INFO - 2018-08-14 20:32:00 --> Helper loaded: language_helper
DEBUG - 2018-08-14 20:32:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 20:32:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 20:32:00 --> User Agent Class Initialized
INFO - 2018-08-14 20:32:00 --> Controller Class Initialized
INFO - 2018-08-14 20:32:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 20:32:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 20:32:00 --> Pixel_Model class loaded
INFO - 2018-08-14 20:32:00 --> Database Driver Class Initialized
INFO - 2018-08-14 20:32:00 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 20:32:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 20:32:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 20:32:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 20:32:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 20:32:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 20:32:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 20:32:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-08-14 20:32:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 20:32:00 --> Final output sent to browser
DEBUG - 2018-08-14 20:32:00 --> Total execution time: 0.0383
INFO - 2018-08-14 20:32:19 --> Config Class Initialized
INFO - 2018-08-14 20:32:19 --> Hooks Class Initialized
DEBUG - 2018-08-14 20:32:19 --> UTF-8 Support Enabled
INFO - 2018-08-14 20:32:19 --> Utf8 Class Initialized
INFO - 2018-08-14 20:32:19 --> URI Class Initialized
INFO - 2018-08-14 20:32:19 --> Router Class Initialized
INFO - 2018-08-14 20:32:19 --> Output Class Initialized
INFO - 2018-08-14 20:32:19 --> Security Class Initialized
DEBUG - 2018-08-14 20:32:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 20:32:19 --> CSRF cookie sent
INFO - 2018-08-14 20:32:19 --> CSRF token verified
INFO - 2018-08-14 20:32:19 --> Input Class Initialized
INFO - 2018-08-14 20:32:19 --> Language Class Initialized
INFO - 2018-08-14 20:32:19 --> Loader Class Initialized
INFO - 2018-08-14 20:32:19 --> Helper loaded: url_helper
INFO - 2018-08-14 20:32:19 --> Helper loaded: form_helper
INFO - 2018-08-14 20:32:19 --> Helper loaded: language_helper
DEBUG - 2018-08-14 20:32:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 20:32:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 20:32:19 --> User Agent Class Initialized
INFO - 2018-08-14 20:32:19 --> Controller Class Initialized
INFO - 2018-08-14 20:32:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 20:32:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 20:32:19 --> Pixel_Model class loaded
INFO - 2018-08-14 20:32:19 --> Database Driver Class Initialized
INFO - 2018-08-14 20:32:19 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 20:32:19 --> Database Driver Class Initialized
INFO - 2018-08-14 20:32:19 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 20:32:20 --> Config Class Initialized
INFO - 2018-08-14 20:32:20 --> Hooks Class Initialized
DEBUG - 2018-08-14 20:32:20 --> UTF-8 Support Enabled
INFO - 2018-08-14 20:32:20 --> Utf8 Class Initialized
INFO - 2018-08-14 20:32:20 --> URI Class Initialized
INFO - 2018-08-14 20:32:20 --> Router Class Initialized
INFO - 2018-08-14 20:32:20 --> Output Class Initialized
INFO - 2018-08-14 20:32:20 --> Security Class Initialized
DEBUG - 2018-08-14 20:32:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 20:32:20 --> CSRF cookie sent
INFO - 2018-08-14 20:32:20 --> Input Class Initialized
INFO - 2018-08-14 20:32:20 --> Language Class Initialized
INFO - 2018-08-14 20:32:20 --> Loader Class Initialized
INFO - 2018-08-14 20:32:20 --> Helper loaded: url_helper
INFO - 2018-08-14 20:32:20 --> Helper loaded: form_helper
INFO - 2018-08-14 20:32:20 --> Helper loaded: language_helper
DEBUG - 2018-08-14 20:32:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 20:32:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 20:32:20 --> User Agent Class Initialized
INFO - 2018-08-14 20:32:20 --> Controller Class Initialized
INFO - 2018-08-14 20:32:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 20:32:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 20:32:20 --> Pixel_Model class loaded
INFO - 2018-08-14 20:32:20 --> Database Driver Class Initialized
INFO - 2018-08-14 20:32:20 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 20:32:20 --> Database Driver Class Initialized
INFO - 2018-08-14 20:32:20 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 20:32:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 20:32:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 20:32:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 20:32:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 20:32:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 20:32:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 20:32:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-14 20:32:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 20:32:20 --> Final output sent to browser
DEBUG - 2018-08-14 20:32:20 --> Total execution time: 0.0620
INFO - 2018-08-14 21:07:25 --> Config Class Initialized
INFO - 2018-08-14 21:07:25 --> Hooks Class Initialized
DEBUG - 2018-08-14 21:07:25 --> UTF-8 Support Enabled
INFO - 2018-08-14 21:07:25 --> Utf8 Class Initialized
INFO - 2018-08-14 21:07:25 --> URI Class Initialized
INFO - 2018-08-14 21:07:25 --> Router Class Initialized
INFO - 2018-08-14 21:07:25 --> Output Class Initialized
INFO - 2018-08-14 21:07:25 --> Security Class Initialized
DEBUG - 2018-08-14 21:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 21:07:25 --> CSRF cookie sent
INFO - 2018-08-14 21:07:25 --> Input Class Initialized
INFO - 2018-08-14 21:07:25 --> Language Class Initialized
ERROR - 2018-08-14 21:07:25 --> 404 Page Not Found: 401shtml/index
INFO - 2018-08-14 21:07:31 --> Config Class Initialized
INFO - 2018-08-14 21:07:31 --> Hooks Class Initialized
DEBUG - 2018-08-14 21:07:31 --> UTF-8 Support Enabled
INFO - 2018-08-14 21:07:31 --> Utf8 Class Initialized
INFO - 2018-08-14 21:07:31 --> URI Class Initialized
DEBUG - 2018-08-14 21:07:31 --> No URI present. Default controller set.
INFO - 2018-08-14 21:07:31 --> Router Class Initialized
INFO - 2018-08-14 21:07:31 --> Output Class Initialized
INFO - 2018-08-14 21:07:31 --> Security Class Initialized
DEBUG - 2018-08-14 21:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 21:07:31 --> CSRF cookie sent
INFO - 2018-08-14 21:07:31 --> Input Class Initialized
INFO - 2018-08-14 21:07:31 --> Language Class Initialized
INFO - 2018-08-14 21:07:31 --> Loader Class Initialized
INFO - 2018-08-14 21:07:31 --> Helper loaded: url_helper
INFO - 2018-08-14 21:07:31 --> Helper loaded: form_helper
INFO - 2018-08-14 21:07:31 --> Helper loaded: language_helper
DEBUG - 2018-08-14 21:07:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 21:07:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 21:07:31 --> User Agent Class Initialized
INFO - 2018-08-14 21:07:31 --> Controller Class Initialized
INFO - 2018-08-14 21:07:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 21:07:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 21:07:31 --> Pixel_Model class loaded
INFO - 2018-08-14 21:07:31 --> Database Driver Class Initialized
INFO - 2018-08-14 21:07:31 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 21:07:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 21:07:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 21:07:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-14 21:07:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 21:07:31 --> Final output sent to browser
DEBUG - 2018-08-14 21:07:31 --> Total execution time: 0.0496
INFO - 2018-08-14 21:07:31 --> Config Class Initialized
INFO - 2018-08-14 21:07:31 --> Hooks Class Initialized
DEBUG - 2018-08-14 21:07:31 --> UTF-8 Support Enabled
INFO - 2018-08-14 21:07:31 --> Utf8 Class Initialized
INFO - 2018-08-14 21:07:31 --> URI Class Initialized
DEBUG - 2018-08-14 21:07:31 --> No URI present. Default controller set.
INFO - 2018-08-14 21:07:31 --> Router Class Initialized
INFO - 2018-08-14 21:07:31 --> Output Class Initialized
INFO - 2018-08-14 21:07:31 --> Security Class Initialized
DEBUG - 2018-08-14 21:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 21:07:31 --> CSRF cookie sent
INFO - 2018-08-14 21:07:31 --> Input Class Initialized
INFO - 2018-08-14 21:07:31 --> Language Class Initialized
INFO - 2018-08-14 21:07:31 --> Loader Class Initialized
INFO - 2018-08-14 21:07:31 --> Helper loaded: url_helper
INFO - 2018-08-14 21:07:31 --> Helper loaded: form_helper
INFO - 2018-08-14 21:07:31 --> Helper loaded: language_helper
DEBUG - 2018-08-14 21:07:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 21:07:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 21:07:31 --> User Agent Class Initialized
INFO - 2018-08-14 21:07:31 --> Controller Class Initialized
INFO - 2018-08-14 21:07:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 21:07:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 21:07:31 --> Pixel_Model class loaded
INFO - 2018-08-14 21:07:31 --> Database Driver Class Initialized
INFO - 2018-08-14 21:07:31 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 21:07:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 21:07:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 21:07:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-14 21:07:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 21:07:31 --> Final output sent to browser
DEBUG - 2018-08-14 21:07:31 --> Total execution time: 0.0458
INFO - 2018-08-14 21:07:35 --> Config Class Initialized
INFO - 2018-08-14 21:07:35 --> Hooks Class Initialized
DEBUG - 2018-08-14 21:07:35 --> UTF-8 Support Enabled
INFO - 2018-08-14 21:07:35 --> Utf8 Class Initialized
INFO - 2018-08-14 21:07:35 --> URI Class Initialized
INFO - 2018-08-14 21:07:35 --> Router Class Initialized
INFO - 2018-08-14 21:07:35 --> Output Class Initialized
INFO - 2018-08-14 21:07:35 --> Security Class Initialized
DEBUG - 2018-08-14 21:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 21:07:35 --> CSRF cookie sent
INFO - 2018-08-14 21:07:35 --> CSRF token verified
INFO - 2018-08-14 21:07:35 --> Input Class Initialized
INFO - 2018-08-14 21:07:35 --> Language Class Initialized
INFO - 2018-08-14 21:07:35 --> Loader Class Initialized
INFO - 2018-08-14 21:07:35 --> Helper loaded: url_helper
INFO - 2018-08-14 21:07:35 --> Helper loaded: form_helper
INFO - 2018-08-14 21:07:35 --> Helper loaded: language_helper
DEBUG - 2018-08-14 21:07:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 21:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 21:07:35 --> User Agent Class Initialized
INFO - 2018-08-14 21:07:35 --> Controller Class Initialized
INFO - 2018-08-14 21:07:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 21:07:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 21:07:35 --> Pixel_Model class loaded
INFO - 2018-08-14 21:07:35 --> Database Driver Class Initialized
INFO - 2018-08-14 21:07:35 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 21:07:35 --> Database Driver Class Initialized
INFO - 2018-08-14 21:07:35 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 21:07:35 --> Config Class Initialized
INFO - 2018-08-14 21:07:35 --> Hooks Class Initialized
DEBUG - 2018-08-14 21:07:35 --> UTF-8 Support Enabled
INFO - 2018-08-14 21:07:35 --> Utf8 Class Initialized
INFO - 2018-08-14 21:07:35 --> URI Class Initialized
INFO - 2018-08-14 21:07:35 --> Router Class Initialized
INFO - 2018-08-14 21:07:35 --> Output Class Initialized
INFO - 2018-08-14 21:07:35 --> Security Class Initialized
DEBUG - 2018-08-14 21:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 21:07:35 --> CSRF cookie sent
INFO - 2018-08-14 21:07:35 --> Input Class Initialized
INFO - 2018-08-14 21:07:35 --> Language Class Initialized
INFO - 2018-08-14 21:07:35 --> Loader Class Initialized
INFO - 2018-08-14 21:07:35 --> Helper loaded: url_helper
INFO - 2018-08-14 21:07:35 --> Helper loaded: form_helper
INFO - 2018-08-14 21:07:35 --> Helper loaded: language_helper
DEBUG - 2018-08-14 21:07:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 21:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 21:07:35 --> User Agent Class Initialized
INFO - 2018-08-14 21:07:35 --> Controller Class Initialized
INFO - 2018-08-14 21:07:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 21:07:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 21:07:35 --> Pixel_Model class loaded
INFO - 2018-08-14 21:07:35 --> Database Driver Class Initialized
INFO - 2018-08-14 21:07:35 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 21:07:35 --> Database Driver Class Initialized
INFO - 2018-08-14 21:07:35 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 21:07:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 21:07:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 21:07:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 21:07:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 21:07:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 21:07:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 21:07:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-14 21:07:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 21:07:35 --> Final output sent to browser
DEBUG - 2018-08-14 21:07:35 --> Total execution time: 0.0451
INFO - 2018-08-14 21:07:43 --> Config Class Initialized
INFO - 2018-08-14 21:07:43 --> Hooks Class Initialized
DEBUG - 2018-08-14 21:07:43 --> UTF-8 Support Enabled
INFO - 2018-08-14 21:07:43 --> Utf8 Class Initialized
INFO - 2018-08-14 21:07:43 --> URI Class Initialized
INFO - 2018-08-14 21:07:43 --> Router Class Initialized
INFO - 2018-08-14 21:07:43 --> Output Class Initialized
INFO - 2018-08-14 21:07:43 --> Security Class Initialized
DEBUG - 2018-08-14 21:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 21:07:43 --> CSRF cookie sent
INFO - 2018-08-14 21:07:43 --> CSRF token verified
INFO - 2018-08-14 21:07:43 --> Input Class Initialized
INFO - 2018-08-14 21:07:43 --> Language Class Initialized
INFO - 2018-08-14 21:07:43 --> Loader Class Initialized
INFO - 2018-08-14 21:07:43 --> Helper loaded: url_helper
INFO - 2018-08-14 21:07:43 --> Helper loaded: form_helper
INFO - 2018-08-14 21:07:43 --> Helper loaded: language_helper
DEBUG - 2018-08-14 21:07:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 21:07:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 21:07:43 --> User Agent Class Initialized
INFO - 2018-08-14 21:07:43 --> Controller Class Initialized
INFO - 2018-08-14 21:07:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 21:07:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 21:07:43 --> Pixel_Model class loaded
INFO - 2018-08-14 21:07:43 --> Database Driver Class Initialized
INFO - 2018-08-14 21:07:43 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 21:07:43 --> Form Validation Class Initialized
INFO - 2018-08-14 21:07:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 21:07:43 --> Database Driver Class Initialized
INFO - 2018-08-14 21:07:43 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 21:07:43 --> Config Class Initialized
INFO - 2018-08-14 21:07:43 --> Hooks Class Initialized
DEBUG - 2018-08-14 21:07:43 --> UTF-8 Support Enabled
INFO - 2018-08-14 21:07:43 --> Utf8 Class Initialized
INFO - 2018-08-14 21:07:43 --> URI Class Initialized
INFO - 2018-08-14 21:07:43 --> Router Class Initialized
INFO - 2018-08-14 21:07:43 --> Output Class Initialized
INFO - 2018-08-14 21:07:43 --> Security Class Initialized
DEBUG - 2018-08-14 21:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 21:07:43 --> CSRF cookie sent
INFO - 2018-08-14 21:07:43 --> Input Class Initialized
INFO - 2018-08-14 21:07:43 --> Language Class Initialized
INFO - 2018-08-14 21:07:43 --> Loader Class Initialized
INFO - 2018-08-14 21:07:43 --> Helper loaded: url_helper
INFO - 2018-08-14 21:07:43 --> Helper loaded: form_helper
INFO - 2018-08-14 21:07:43 --> Helper loaded: language_helper
DEBUG - 2018-08-14 21:07:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 21:07:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 21:07:43 --> User Agent Class Initialized
INFO - 2018-08-14 21:07:43 --> Controller Class Initialized
INFO - 2018-08-14 21:07:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 21:07:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 21:07:43 --> Pixel_Model class loaded
INFO - 2018-08-14 21:07:43 --> Database Driver Class Initialized
INFO - 2018-08-14 21:07:43 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 21:07:43 --> Database Driver Class Initialized
INFO - 2018-08-14 21:07:43 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 21:07:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 21:07:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 21:07:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 21:07:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 21:07:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 21:07:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 21:07:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-08-14 21:07:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 21:07:43 --> Final output sent to browser
DEBUG - 2018-08-14 21:07:43 --> Total execution time: 0.0562
INFO - 2018-08-14 21:07:48 --> Config Class Initialized
INFO - 2018-08-14 21:07:48 --> Hooks Class Initialized
DEBUG - 2018-08-14 21:07:48 --> UTF-8 Support Enabled
INFO - 2018-08-14 21:07:48 --> Utf8 Class Initialized
INFO - 2018-08-14 21:07:48 --> URI Class Initialized
INFO - 2018-08-14 21:07:48 --> Router Class Initialized
INFO - 2018-08-14 21:07:48 --> Output Class Initialized
INFO - 2018-08-14 21:07:48 --> Security Class Initialized
DEBUG - 2018-08-14 21:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 21:07:48 --> CSRF cookie sent
INFO - 2018-08-14 21:07:48 --> Input Class Initialized
INFO - 2018-08-14 21:07:48 --> Language Class Initialized
INFO - 2018-08-14 21:07:48 --> Loader Class Initialized
INFO - 2018-08-14 21:07:48 --> Helper loaded: url_helper
INFO - 2018-08-14 21:07:48 --> Helper loaded: form_helper
INFO - 2018-08-14 21:07:48 --> Helper loaded: language_helper
DEBUG - 2018-08-14 21:07:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 21:07:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 21:07:48 --> User Agent Class Initialized
INFO - 2018-08-14 21:07:48 --> Controller Class Initialized
INFO - 2018-08-14 21:07:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 21:07:48 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-08-14 21:07:48 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-08-14 21:07:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 21:07:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 21:07:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 21:07:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-08-14 21:07:48 --> Could not find the language line "req_email"
INFO - 2018-08-14 21:07:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-08-14 21:07:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 21:07:48 --> Final output sent to browser
DEBUG - 2018-08-14 21:07:48 --> Total execution time: 0.0233
INFO - 2018-08-14 21:07:59 --> Config Class Initialized
INFO - 2018-08-14 21:07:59 --> Hooks Class Initialized
DEBUG - 2018-08-14 21:07:59 --> UTF-8 Support Enabled
INFO - 2018-08-14 21:07:59 --> Utf8 Class Initialized
INFO - 2018-08-14 21:07:59 --> URI Class Initialized
INFO - 2018-08-14 21:07:59 --> Router Class Initialized
INFO - 2018-08-14 21:07:59 --> Output Class Initialized
INFO - 2018-08-14 21:07:59 --> Security Class Initialized
DEBUG - 2018-08-14 21:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 21:07:59 --> CSRF cookie sent
INFO - 2018-08-14 21:07:59 --> CSRF token verified
INFO - 2018-08-14 21:07:59 --> Input Class Initialized
INFO - 2018-08-14 21:07:59 --> Language Class Initialized
INFO - 2018-08-14 21:07:59 --> Loader Class Initialized
INFO - 2018-08-14 21:07:59 --> Helper loaded: url_helper
INFO - 2018-08-14 21:07:59 --> Helper loaded: form_helper
INFO - 2018-08-14 21:07:59 --> Helper loaded: language_helper
DEBUG - 2018-08-14 21:07:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 21:07:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 21:07:59 --> User Agent Class Initialized
INFO - 2018-08-14 21:07:59 --> Controller Class Initialized
INFO - 2018-08-14 21:07:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 21:07:59 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-08-14 21:07:59 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-08-14 21:08:00 --> Form Validation Class Initialized
INFO - 2018-08-14 21:08:00 --> Pixel_Model class loaded
INFO - 2018-08-14 21:08:00 --> Database Driver Class Initialized
INFO - 2018-08-14 21:08:00 --> Model "AuthenticationModel" initialized
INFO - 2018-08-14 21:08:00 --> Database Driver Class Initialized
INFO - 2018-08-14 21:08:00 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 21:08:00 --> Config Class Initialized
INFO - 2018-08-14 21:08:00 --> Hooks Class Initialized
DEBUG - 2018-08-14 21:08:00 --> UTF-8 Support Enabled
INFO - 2018-08-14 21:08:00 --> Utf8 Class Initialized
INFO - 2018-08-14 21:08:00 --> URI Class Initialized
INFO - 2018-08-14 21:08:00 --> Router Class Initialized
INFO - 2018-08-14 21:08:00 --> Output Class Initialized
INFO - 2018-08-14 21:08:00 --> Security Class Initialized
DEBUG - 2018-08-14 21:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 21:08:00 --> CSRF cookie sent
INFO - 2018-08-14 21:08:00 --> Input Class Initialized
INFO - 2018-08-14 21:08:00 --> Language Class Initialized
INFO - 2018-08-14 21:08:00 --> Loader Class Initialized
INFO - 2018-08-14 21:08:00 --> Helper loaded: url_helper
INFO - 2018-08-14 21:08:00 --> Helper loaded: form_helper
INFO - 2018-08-14 21:08:00 --> Helper loaded: language_helper
DEBUG - 2018-08-14 21:08:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 21:08:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 21:08:00 --> User Agent Class Initialized
INFO - 2018-08-14 21:08:00 --> Controller Class Initialized
INFO - 2018-08-14 21:08:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 21:08:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 21:08:00 --> Pixel_Model class loaded
INFO - 2018-08-14 21:08:00 --> Database Driver Class Initialized
INFO - 2018-08-14 21:08:00 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 21:08:00 --> Database Driver Class Initialized
INFO - 2018-08-14 21:08:00 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 21:08:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 21:08:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-08-14 21:08:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 21:08:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 21:08:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 21:08:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 21:08:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 21:08:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-08-14 21:08:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 21:08:00 --> Final output sent to browser
DEBUG - 2018-08-14 21:08:00 --> Total execution time: 0.0585
INFO - 2018-08-14 21:08:11 --> Config Class Initialized
INFO - 2018-08-14 21:08:11 --> Hooks Class Initialized
DEBUG - 2018-08-14 21:08:11 --> UTF-8 Support Enabled
INFO - 2018-08-14 21:08:11 --> Utf8 Class Initialized
INFO - 2018-08-14 21:08:11 --> URI Class Initialized
INFO - 2018-08-14 21:08:11 --> Router Class Initialized
INFO - 2018-08-14 21:08:11 --> Output Class Initialized
INFO - 2018-08-14 21:08:11 --> Security Class Initialized
DEBUG - 2018-08-14 21:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 21:08:11 --> CSRF cookie sent
INFO - 2018-08-14 21:08:11 --> CSRF token verified
INFO - 2018-08-14 21:08:11 --> Input Class Initialized
INFO - 2018-08-14 21:08:11 --> Language Class Initialized
INFO - 2018-08-14 21:08:11 --> Loader Class Initialized
INFO - 2018-08-14 21:08:11 --> Helper loaded: url_helper
INFO - 2018-08-14 21:08:11 --> Helper loaded: form_helper
INFO - 2018-08-14 21:08:11 --> Helper loaded: language_helper
DEBUG - 2018-08-14 21:08:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 21:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 21:08:11 --> User Agent Class Initialized
INFO - 2018-08-14 21:08:11 --> Controller Class Initialized
INFO - 2018-08-14 21:08:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 21:08:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 21:08:11 --> Pixel_Model class loaded
INFO - 2018-08-14 21:08:11 --> Database Driver Class Initialized
INFO - 2018-08-14 21:08:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 21:08:11 --> Form Validation Class Initialized
INFO - 2018-08-14 21:08:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 21:08:11 --> Database Driver Class Initialized
INFO - 2018-08-14 21:08:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 21:08:11 --> Config Class Initialized
INFO - 2018-08-14 21:08:11 --> Hooks Class Initialized
DEBUG - 2018-08-14 21:08:11 --> UTF-8 Support Enabled
INFO - 2018-08-14 21:08:11 --> Utf8 Class Initialized
INFO - 2018-08-14 21:08:11 --> URI Class Initialized
INFO - 2018-08-14 21:08:11 --> Router Class Initialized
INFO - 2018-08-14 21:08:11 --> Output Class Initialized
INFO - 2018-08-14 21:08:11 --> Security Class Initialized
DEBUG - 2018-08-14 21:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 21:08:11 --> CSRF cookie sent
INFO - 2018-08-14 21:08:11 --> Input Class Initialized
INFO - 2018-08-14 21:08:11 --> Language Class Initialized
INFO - 2018-08-14 21:08:11 --> Loader Class Initialized
INFO - 2018-08-14 21:08:11 --> Helper loaded: url_helper
INFO - 2018-08-14 21:08:11 --> Helper loaded: form_helper
INFO - 2018-08-14 21:08:11 --> Helper loaded: language_helper
DEBUG - 2018-08-14 21:08:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 21:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 21:08:11 --> User Agent Class Initialized
INFO - 2018-08-14 21:08:11 --> Controller Class Initialized
INFO - 2018-08-14 21:08:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 21:08:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 21:08:11 --> Pixel_Model class loaded
INFO - 2018-08-14 21:08:11 --> Database Driver Class Initialized
INFO - 2018-08-14 21:08:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 21:08:11 --> Database Driver Class Initialized
INFO - 2018-08-14 21:08:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 21:08:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 21:08:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-08-14 21:08:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 21:08:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-08-14 21:08:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 21:08:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 21:08:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 21:08:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 21:08:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-08-14 21:08:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 21:08:11 --> Final output sent to browser
DEBUG - 2018-08-14 21:08:11 --> Total execution time: 0.0428
INFO - 2018-08-14 21:08:12 --> Config Class Initialized
INFO - 2018-08-14 21:08:12 --> Hooks Class Initialized
DEBUG - 2018-08-14 21:08:12 --> UTF-8 Support Enabled
INFO - 2018-08-14 21:08:12 --> Utf8 Class Initialized
INFO - 2018-08-14 21:08:12 --> URI Class Initialized
INFO - 2018-08-14 21:08:12 --> Router Class Initialized
INFO - 2018-08-14 21:08:12 --> Output Class Initialized
INFO - 2018-08-14 21:08:12 --> Security Class Initialized
DEBUG - 2018-08-14 21:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 21:08:12 --> CSRF cookie sent
INFO - 2018-08-14 21:08:12 --> CSRF token verified
INFO - 2018-08-14 21:08:12 --> Input Class Initialized
INFO - 2018-08-14 21:08:12 --> Language Class Initialized
INFO - 2018-08-14 21:08:12 --> Loader Class Initialized
INFO - 2018-08-14 21:08:12 --> Helper loaded: url_helper
INFO - 2018-08-14 21:08:12 --> Helper loaded: form_helper
INFO - 2018-08-14 21:08:12 --> Helper loaded: language_helper
DEBUG - 2018-08-14 21:08:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 21:08:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 21:08:12 --> User Agent Class Initialized
INFO - 2018-08-14 21:08:12 --> Controller Class Initialized
INFO - 2018-08-14 21:08:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 21:08:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 21:08:12 --> Pixel_Model class loaded
INFO - 2018-08-14 21:08:12 --> Database Driver Class Initialized
INFO - 2018-08-14 21:08:12 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 21:08:12 --> Form Validation Class Initialized
INFO - 2018-08-14 21:08:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 21:08:12 --> Database Driver Class Initialized
INFO - 2018-08-14 21:08:12 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 21:08:12 --> Config Class Initialized
INFO - 2018-08-14 21:08:12 --> Hooks Class Initialized
DEBUG - 2018-08-14 21:08:12 --> UTF-8 Support Enabled
INFO - 2018-08-14 21:08:12 --> Utf8 Class Initialized
INFO - 2018-08-14 21:08:12 --> URI Class Initialized
INFO - 2018-08-14 21:08:12 --> Router Class Initialized
INFO - 2018-08-14 21:08:12 --> Output Class Initialized
INFO - 2018-08-14 21:08:12 --> Security Class Initialized
DEBUG - 2018-08-14 21:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 21:08:12 --> CSRF cookie sent
INFO - 2018-08-14 21:08:12 --> Input Class Initialized
INFO - 2018-08-14 21:08:12 --> Language Class Initialized
INFO - 2018-08-14 21:08:12 --> Loader Class Initialized
INFO - 2018-08-14 21:08:12 --> Helper loaded: url_helper
INFO - 2018-08-14 21:08:12 --> Helper loaded: form_helper
INFO - 2018-08-14 21:08:12 --> Helper loaded: language_helper
DEBUG - 2018-08-14 21:08:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 21:08:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 21:08:12 --> User Agent Class Initialized
INFO - 2018-08-14 21:08:12 --> Controller Class Initialized
INFO - 2018-08-14 21:08:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 21:08:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 21:08:12 --> Pixel_Model class loaded
INFO - 2018-08-14 21:08:12 --> Database Driver Class Initialized
INFO - 2018-08-14 21:08:12 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 21:08:12 --> Database Driver Class Initialized
INFO - 2018-08-14 21:08:12 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 21:08:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 21:08:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-08-14 21:08:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 21:08:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 21:08:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 21:08:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 21:08:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 21:08:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-08-14 21:08:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 21:08:12 --> Final output sent to browser
DEBUG - 2018-08-14 21:08:12 --> Total execution time: 0.0386
INFO - 2018-08-14 21:08:18 --> Config Class Initialized
INFO - 2018-08-14 21:08:18 --> Hooks Class Initialized
DEBUG - 2018-08-14 21:08:18 --> UTF-8 Support Enabled
INFO - 2018-08-14 21:08:18 --> Utf8 Class Initialized
INFO - 2018-08-14 21:08:18 --> URI Class Initialized
INFO - 2018-08-14 21:08:18 --> Router Class Initialized
INFO - 2018-08-14 21:08:18 --> Output Class Initialized
INFO - 2018-08-14 21:08:18 --> Security Class Initialized
DEBUG - 2018-08-14 21:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 21:08:18 --> CSRF cookie sent
INFO - 2018-08-14 21:08:18 --> Input Class Initialized
INFO - 2018-08-14 21:08:18 --> Language Class Initialized
INFO - 2018-08-14 21:08:18 --> Loader Class Initialized
INFO - 2018-08-14 21:08:18 --> Helper loaded: url_helper
INFO - 2018-08-14 21:08:18 --> Helper loaded: form_helper
INFO - 2018-08-14 21:08:18 --> Helper loaded: language_helper
DEBUG - 2018-08-14 21:08:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 21:08:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 21:08:18 --> User Agent Class Initialized
INFO - 2018-08-14 21:08:18 --> Controller Class Initialized
INFO - 2018-08-14 21:08:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 21:08:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 21:08:18 --> Pixel_Model class loaded
INFO - 2018-08-14 21:08:18 --> Database Driver Class Initialized
INFO - 2018-08-14 21:08:18 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 21:08:18 --> Database Driver Class Initialized
INFO - 2018-08-14 21:08:18 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 21:08:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 21:08:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-08-14 21:08:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 21:08:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 21:08:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 21:08:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 21:08:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 21:08:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-14 21:08:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 21:08:18 --> Final output sent to browser
DEBUG - 2018-08-14 21:08:18 --> Total execution time: 0.0450
INFO - 2018-08-14 21:08:20 --> Config Class Initialized
INFO - 2018-08-14 21:08:20 --> Hooks Class Initialized
DEBUG - 2018-08-14 21:08:20 --> UTF-8 Support Enabled
INFO - 2018-08-14 21:08:20 --> Utf8 Class Initialized
INFO - 2018-08-14 21:08:20 --> URI Class Initialized
INFO - 2018-08-14 21:08:20 --> Router Class Initialized
INFO - 2018-08-14 21:08:20 --> Output Class Initialized
INFO - 2018-08-14 21:08:20 --> Security Class Initialized
DEBUG - 2018-08-14 21:08:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 21:08:20 --> CSRF cookie sent
INFO - 2018-08-14 21:08:20 --> Input Class Initialized
INFO - 2018-08-14 21:08:20 --> Language Class Initialized
INFO - 2018-08-14 21:08:20 --> Loader Class Initialized
INFO - 2018-08-14 21:08:20 --> Helper loaded: url_helper
INFO - 2018-08-14 21:08:20 --> Helper loaded: form_helper
INFO - 2018-08-14 21:08:20 --> Helper loaded: language_helper
DEBUG - 2018-08-14 21:08:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 21:08:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 21:08:20 --> User Agent Class Initialized
INFO - 2018-08-14 21:08:20 --> Controller Class Initialized
INFO - 2018-08-14 21:08:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 21:08:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 21:08:20 --> Pixel_Model class loaded
INFO - 2018-08-14 21:08:20 --> Database Driver Class Initialized
INFO - 2018-08-14 21:08:20 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 21:08:20 --> Database Driver Class Initialized
INFO - 2018-08-14 21:08:20 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 21:08:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 21:08:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-08-14 21:08:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 21:08:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 21:08:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 21:08:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 21:08:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 21:08:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-14 21:08:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 21:08:20 --> Final output sent to browser
DEBUG - 2018-08-14 21:08:20 --> Total execution time: 0.0452
INFO - 2018-08-14 21:08:21 --> Config Class Initialized
INFO - 2018-08-14 21:08:21 --> Hooks Class Initialized
DEBUG - 2018-08-14 21:08:21 --> UTF-8 Support Enabled
INFO - 2018-08-14 21:08:21 --> Utf8 Class Initialized
INFO - 2018-08-14 21:08:21 --> URI Class Initialized
INFO - 2018-08-14 21:08:21 --> Router Class Initialized
INFO - 2018-08-14 21:08:21 --> Output Class Initialized
INFO - 2018-08-14 21:08:21 --> Security Class Initialized
DEBUG - 2018-08-14 21:08:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 21:08:21 --> CSRF cookie sent
INFO - 2018-08-14 21:08:21 --> CSRF token verified
INFO - 2018-08-14 21:08:21 --> Input Class Initialized
INFO - 2018-08-14 21:08:21 --> Language Class Initialized
INFO - 2018-08-14 21:08:21 --> Loader Class Initialized
INFO - 2018-08-14 21:08:21 --> Helper loaded: url_helper
INFO - 2018-08-14 21:08:21 --> Helper loaded: form_helper
INFO - 2018-08-14 21:08:21 --> Helper loaded: language_helper
DEBUG - 2018-08-14 21:08:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 21:08:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 21:08:21 --> User Agent Class Initialized
INFO - 2018-08-14 21:08:21 --> Controller Class Initialized
INFO - 2018-08-14 21:08:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 21:08:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 21:08:21 --> Pixel_Model class loaded
INFO - 2018-08-14 21:08:21 --> Database Driver Class Initialized
INFO - 2018-08-14 21:08:21 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 21:08:21 --> Form Validation Class Initialized
INFO - 2018-08-14 21:08:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 21:08:21 --> Database Driver Class Initialized
INFO - 2018-08-14 21:08:21 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 21:08:21 --> Config Class Initialized
INFO - 2018-08-14 21:08:21 --> Hooks Class Initialized
DEBUG - 2018-08-14 21:08:21 --> UTF-8 Support Enabled
INFO - 2018-08-14 21:08:21 --> Utf8 Class Initialized
INFO - 2018-08-14 21:08:21 --> URI Class Initialized
INFO - 2018-08-14 21:08:21 --> Router Class Initialized
INFO - 2018-08-14 21:08:21 --> Output Class Initialized
INFO - 2018-08-14 21:08:21 --> Security Class Initialized
DEBUG - 2018-08-14 21:08:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 21:08:21 --> CSRF cookie sent
INFO - 2018-08-14 21:08:21 --> Input Class Initialized
INFO - 2018-08-14 21:08:21 --> Language Class Initialized
INFO - 2018-08-14 21:08:21 --> Loader Class Initialized
INFO - 2018-08-14 21:08:21 --> Helper loaded: url_helper
INFO - 2018-08-14 21:08:21 --> Helper loaded: form_helper
INFO - 2018-08-14 21:08:21 --> Helper loaded: language_helper
DEBUG - 2018-08-14 21:08:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 21:08:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 21:08:21 --> User Agent Class Initialized
INFO - 2018-08-14 21:08:21 --> Controller Class Initialized
INFO - 2018-08-14 21:08:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 21:08:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 21:08:21 --> Pixel_Model class loaded
INFO - 2018-08-14 21:08:21 --> Database Driver Class Initialized
INFO - 2018-08-14 21:08:21 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 21:08:21 --> Database Driver Class Initialized
INFO - 2018-08-14 21:08:21 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 21:08:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 21:08:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-08-14 21:08:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 21:08:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 21:08:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 21:08:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 21:08:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 21:08:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-08-14 21:08:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 21:08:21 --> Final output sent to browser
DEBUG - 2018-08-14 21:08:21 --> Total execution time: 0.0367
INFO - 2018-08-14 21:08:23 --> Config Class Initialized
INFO - 2018-08-14 21:08:23 --> Hooks Class Initialized
DEBUG - 2018-08-14 21:08:23 --> UTF-8 Support Enabled
INFO - 2018-08-14 21:08:23 --> Utf8 Class Initialized
INFO - 2018-08-14 21:08:23 --> URI Class Initialized
INFO - 2018-08-14 21:08:23 --> Router Class Initialized
INFO - 2018-08-14 21:08:23 --> Output Class Initialized
INFO - 2018-08-14 21:08:23 --> Security Class Initialized
DEBUG - 2018-08-14 21:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 21:08:23 --> CSRF cookie sent
INFO - 2018-08-14 21:08:23 --> CSRF token verified
INFO - 2018-08-14 21:08:23 --> Input Class Initialized
INFO - 2018-08-14 21:08:23 --> Language Class Initialized
INFO - 2018-08-14 21:08:23 --> Loader Class Initialized
INFO - 2018-08-14 21:08:23 --> Helper loaded: url_helper
INFO - 2018-08-14 21:08:23 --> Helper loaded: form_helper
INFO - 2018-08-14 21:08:23 --> Helper loaded: language_helper
DEBUG - 2018-08-14 21:08:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 21:08:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 21:08:23 --> User Agent Class Initialized
INFO - 2018-08-14 21:08:23 --> Controller Class Initialized
INFO - 2018-08-14 21:08:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 21:08:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 21:08:23 --> Pixel_Model class loaded
INFO - 2018-08-14 21:08:23 --> Database Driver Class Initialized
INFO - 2018-08-14 21:08:23 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 21:08:23 --> Form Validation Class Initialized
INFO - 2018-08-14 21:08:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 21:08:23 --> Database Driver Class Initialized
INFO - 2018-08-14 21:08:23 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 21:08:23 --> Config Class Initialized
INFO - 2018-08-14 21:08:23 --> Hooks Class Initialized
DEBUG - 2018-08-14 21:08:23 --> UTF-8 Support Enabled
INFO - 2018-08-14 21:08:23 --> Utf8 Class Initialized
INFO - 2018-08-14 21:08:23 --> URI Class Initialized
INFO - 2018-08-14 21:08:23 --> Router Class Initialized
INFO - 2018-08-14 21:08:23 --> Output Class Initialized
INFO - 2018-08-14 21:08:23 --> Security Class Initialized
DEBUG - 2018-08-14 21:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 21:08:23 --> CSRF cookie sent
INFO - 2018-08-14 21:08:23 --> Input Class Initialized
INFO - 2018-08-14 21:08:23 --> Language Class Initialized
INFO - 2018-08-14 21:08:23 --> Loader Class Initialized
INFO - 2018-08-14 21:08:23 --> Helper loaded: url_helper
INFO - 2018-08-14 21:08:23 --> Helper loaded: form_helper
INFO - 2018-08-14 21:08:23 --> Helper loaded: language_helper
DEBUG - 2018-08-14 21:08:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 21:08:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 21:08:23 --> User Agent Class Initialized
INFO - 2018-08-14 21:08:23 --> Controller Class Initialized
INFO - 2018-08-14 21:08:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 21:08:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 21:08:23 --> Pixel_Model class loaded
INFO - 2018-08-14 21:08:23 --> Database Driver Class Initialized
INFO - 2018-08-14 21:08:23 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 21:08:23 --> Database Driver Class Initialized
INFO - 2018-08-14 21:08:23 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 21:08:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 21:08:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-08-14 21:08:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 21:08:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-08-14 21:08:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 21:08:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 21:08:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 21:08:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 21:08:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-08-14 21:08:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 21:08:23 --> Final output sent to browser
DEBUG - 2018-08-14 21:08:23 --> Total execution time: 0.0383
INFO - 2018-08-14 21:08:24 --> Config Class Initialized
INFO - 2018-08-14 21:08:24 --> Hooks Class Initialized
DEBUG - 2018-08-14 21:08:24 --> UTF-8 Support Enabled
INFO - 2018-08-14 21:08:24 --> Utf8 Class Initialized
INFO - 2018-08-14 21:08:24 --> URI Class Initialized
INFO - 2018-08-14 21:08:24 --> Router Class Initialized
INFO - 2018-08-14 21:08:24 --> Output Class Initialized
INFO - 2018-08-14 21:08:24 --> Security Class Initialized
DEBUG - 2018-08-14 21:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 21:08:24 --> CSRF cookie sent
INFO - 2018-08-14 21:08:24 --> CSRF token verified
INFO - 2018-08-14 21:08:24 --> Input Class Initialized
INFO - 2018-08-14 21:08:24 --> Language Class Initialized
INFO - 2018-08-14 21:08:24 --> Loader Class Initialized
INFO - 2018-08-14 21:08:24 --> Helper loaded: url_helper
INFO - 2018-08-14 21:08:24 --> Helper loaded: form_helper
INFO - 2018-08-14 21:08:24 --> Helper loaded: language_helper
DEBUG - 2018-08-14 21:08:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 21:08:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 21:08:24 --> User Agent Class Initialized
INFO - 2018-08-14 21:08:24 --> Controller Class Initialized
INFO - 2018-08-14 21:08:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 21:08:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 21:08:24 --> Pixel_Model class loaded
INFO - 2018-08-14 21:08:24 --> Database Driver Class Initialized
INFO - 2018-08-14 21:08:24 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 21:08:24 --> Form Validation Class Initialized
INFO - 2018-08-14 21:08:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-14 21:08:24 --> Database Driver Class Initialized
INFO - 2018-08-14 21:08:24 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 21:08:24 --> Config Class Initialized
INFO - 2018-08-14 21:08:24 --> Hooks Class Initialized
DEBUG - 2018-08-14 21:08:24 --> UTF-8 Support Enabled
INFO - 2018-08-14 21:08:24 --> Utf8 Class Initialized
INFO - 2018-08-14 21:08:24 --> URI Class Initialized
INFO - 2018-08-14 21:08:24 --> Router Class Initialized
INFO - 2018-08-14 21:08:24 --> Output Class Initialized
INFO - 2018-08-14 21:08:24 --> Security Class Initialized
DEBUG - 2018-08-14 21:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 21:08:24 --> CSRF cookie sent
INFO - 2018-08-14 21:08:24 --> Input Class Initialized
INFO - 2018-08-14 21:08:24 --> Language Class Initialized
INFO - 2018-08-14 21:08:24 --> Loader Class Initialized
INFO - 2018-08-14 21:08:24 --> Helper loaded: url_helper
INFO - 2018-08-14 21:08:24 --> Helper loaded: form_helper
INFO - 2018-08-14 21:08:24 --> Helper loaded: language_helper
DEBUG - 2018-08-14 21:08:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 21:08:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 21:08:24 --> User Agent Class Initialized
INFO - 2018-08-14 21:08:24 --> Controller Class Initialized
INFO - 2018-08-14 21:08:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 21:08:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 21:08:24 --> Pixel_Model class loaded
INFO - 2018-08-14 21:08:24 --> Database Driver Class Initialized
INFO - 2018-08-14 21:08:24 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 21:08:24 --> Database Driver Class Initialized
INFO - 2018-08-14 21:08:24 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 21:08:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 21:08:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-08-14 21:08:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 21:08:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 21:08:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 21:08:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 21:08:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 21:08:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-08-14 21:08:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 21:08:24 --> Final output sent to browser
DEBUG - 2018-08-14 21:08:24 --> Total execution time: 0.0315
INFO - 2018-08-14 21:19:45 --> Config Class Initialized
INFO - 2018-08-14 21:19:45 --> Hooks Class Initialized
DEBUG - 2018-08-14 21:19:45 --> UTF-8 Support Enabled
INFO - 2018-08-14 21:19:45 --> Utf8 Class Initialized
INFO - 2018-08-14 21:19:45 --> URI Class Initialized
INFO - 2018-08-14 21:19:45 --> Router Class Initialized
INFO - 2018-08-14 21:19:45 --> Output Class Initialized
INFO - 2018-08-14 21:19:45 --> Security Class Initialized
DEBUG - 2018-08-14 21:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-14 21:19:45 --> CSRF cookie sent
INFO - 2018-08-14 21:19:45 --> Input Class Initialized
INFO - 2018-08-14 21:19:45 --> Language Class Initialized
INFO - 2018-08-14 21:19:45 --> Loader Class Initialized
INFO - 2018-08-14 21:19:45 --> Helper loaded: url_helper
INFO - 2018-08-14 21:19:45 --> Helper loaded: form_helper
INFO - 2018-08-14 21:19:45 --> Helper loaded: language_helper
DEBUG - 2018-08-14 21:19:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-14 21:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-14 21:19:45 --> User Agent Class Initialized
INFO - 2018-08-14 21:19:45 --> Controller Class Initialized
INFO - 2018-08-14 21:19:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-14 21:19:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-14 21:19:45 --> Pixel_Model class loaded
INFO - 2018-08-14 21:19:45 --> Database Driver Class Initialized
INFO - 2018-08-14 21:19:45 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 21:19:45 --> Database Driver Class Initialized
INFO - 2018-08-14 21:19:45 --> Model "QuestionsModel" initialized
INFO - 2018-08-14 21:19:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-14 21:19:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-14 21:19:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-14 21:19:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-14 21:19:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-14 21:19:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-14 21:19:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-14 21:19:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-14 21:19:45 --> Final output sent to browser
DEBUG - 2018-08-14 21:19:45 --> Total execution time: 0.0575

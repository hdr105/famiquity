<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-08-21 18:14:57 --> Config Class Initialized
INFO - 2018-08-21 18:14:57 --> Hooks Class Initialized
DEBUG - 2018-08-21 18:14:57 --> UTF-8 Support Enabled
INFO - 2018-08-21 18:14:57 --> Utf8 Class Initialized
INFO - 2018-08-21 18:14:57 --> URI Class Initialized
DEBUG - 2018-08-21 18:14:57 --> No URI present. Default controller set.
INFO - 2018-08-21 18:14:57 --> Router Class Initialized
INFO - 2018-08-21 18:14:57 --> Output Class Initialized
INFO - 2018-08-21 18:14:57 --> Security Class Initialized
DEBUG - 2018-08-21 18:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-21 18:14:57 --> CSRF cookie sent
INFO - 2018-08-21 18:14:57 --> Input Class Initialized
INFO - 2018-08-21 18:14:57 --> Language Class Initialized
INFO - 2018-08-21 18:14:57 --> Loader Class Initialized
INFO - 2018-08-21 18:14:57 --> Helper loaded: url_helper
INFO - 2018-08-21 18:14:57 --> Helper loaded: form_helper
INFO - 2018-08-21 18:14:57 --> Helper loaded: language_helper
DEBUG - 2018-08-21 18:14:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-21 18:14:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-21 18:14:57 --> User Agent Class Initialized
INFO - 2018-08-21 18:14:57 --> Controller Class Initialized
INFO - 2018-08-21 18:14:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-21 18:14:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-21 18:14:57 --> Pixel_Model class loaded
INFO - 2018-08-21 18:14:57 --> Database Driver Class Initialized
INFO - 2018-08-21 18:14:57 --> Model "QuestionsModel" initialized
INFO - 2018-08-21 18:14:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-21 18:14:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-21 18:14:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-21 18:14:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-21 18:14:57 --> Final output sent to browser
DEBUG - 2018-08-21 18:14:57 --> Total execution time: 0.0336
INFO - 2018-08-21 18:15:08 --> Config Class Initialized
INFO - 2018-08-21 18:15:08 --> Hooks Class Initialized
DEBUG - 2018-08-21 18:15:08 --> UTF-8 Support Enabled
INFO - 2018-08-21 18:15:08 --> Utf8 Class Initialized
INFO - 2018-08-21 18:15:08 --> URI Class Initialized
INFO - 2018-08-21 18:15:08 --> Router Class Initialized
INFO - 2018-08-21 18:15:08 --> Output Class Initialized
INFO - 2018-08-21 18:15:08 --> Security Class Initialized
DEBUG - 2018-08-21 18:15:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-21 18:15:08 --> CSRF cookie sent
INFO - 2018-08-21 18:15:08 --> CSRF token verified
INFO - 2018-08-21 18:15:08 --> Input Class Initialized
INFO - 2018-08-21 18:15:08 --> Language Class Initialized
INFO - 2018-08-21 18:15:08 --> Loader Class Initialized
INFO - 2018-08-21 18:15:08 --> Helper loaded: url_helper
INFO - 2018-08-21 18:15:08 --> Helper loaded: form_helper
INFO - 2018-08-21 18:15:08 --> Helper loaded: language_helper
DEBUG - 2018-08-21 18:15:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-21 18:15:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-21 18:15:08 --> User Agent Class Initialized
INFO - 2018-08-21 18:15:08 --> Controller Class Initialized
INFO - 2018-08-21 18:15:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-21 18:15:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-21 18:15:08 --> Pixel_Model class loaded
INFO - 2018-08-21 18:15:08 --> Database Driver Class Initialized
INFO - 2018-08-21 18:15:08 --> Model "QuestionsModel" initialized
INFO - 2018-08-21 18:15:08 --> Database Driver Class Initialized
INFO - 2018-08-21 18:15:08 --> Model "QuestionsModel" initialized
INFO - 2018-08-21 18:15:08 --> Config Class Initialized
INFO - 2018-08-21 18:15:08 --> Hooks Class Initialized
DEBUG - 2018-08-21 18:15:08 --> UTF-8 Support Enabled
INFO - 2018-08-21 18:15:08 --> Utf8 Class Initialized
INFO - 2018-08-21 18:15:08 --> URI Class Initialized
INFO - 2018-08-21 18:15:08 --> Router Class Initialized
INFO - 2018-08-21 18:15:08 --> Output Class Initialized
INFO - 2018-08-21 18:15:08 --> Security Class Initialized
DEBUG - 2018-08-21 18:15:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-21 18:15:08 --> CSRF cookie sent
INFO - 2018-08-21 18:15:08 --> Input Class Initialized
INFO - 2018-08-21 18:15:08 --> Language Class Initialized
INFO - 2018-08-21 18:15:08 --> Loader Class Initialized
INFO - 2018-08-21 18:15:08 --> Helper loaded: url_helper
INFO - 2018-08-21 18:15:08 --> Helper loaded: form_helper
INFO - 2018-08-21 18:15:08 --> Helper loaded: language_helper
DEBUG - 2018-08-21 18:15:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-21 18:15:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-21 18:15:08 --> User Agent Class Initialized
INFO - 2018-08-21 18:15:08 --> Controller Class Initialized
INFO - 2018-08-21 18:15:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-21 18:15:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-21 18:15:08 --> Pixel_Model class loaded
INFO - 2018-08-21 18:15:08 --> Database Driver Class Initialized
INFO - 2018-08-21 18:15:08 --> Model "QuestionsModel" initialized
INFO - 2018-08-21 18:15:08 --> Database Driver Class Initialized
INFO - 2018-08-21 18:15:08 --> Model "QuestionsModel" initialized
INFO - 2018-08-21 18:15:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-21 18:15:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-21 18:15:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-21 18:15:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-21 18:15:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-21 18:15:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-21 18:15:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-21 18:15:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-21 18:15:08 --> Final output sent to browser
DEBUG - 2018-08-21 18:15:08 --> Total execution time: 0.0453
INFO - 2018-08-21 18:15:10 --> Config Class Initialized
INFO - 2018-08-21 18:15:10 --> Hooks Class Initialized
DEBUG - 2018-08-21 18:15:10 --> UTF-8 Support Enabled
INFO - 2018-08-21 18:15:10 --> Utf8 Class Initialized
INFO - 2018-08-21 18:15:10 --> URI Class Initialized
INFO - 2018-08-21 18:15:10 --> Router Class Initialized
INFO - 2018-08-21 18:15:10 --> Output Class Initialized
INFO - 2018-08-21 18:15:10 --> Security Class Initialized
DEBUG - 2018-08-21 18:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-21 18:15:10 --> CSRF cookie sent
INFO - 2018-08-21 18:15:10 --> Input Class Initialized
INFO - 2018-08-21 18:15:10 --> Language Class Initialized
INFO - 2018-08-21 18:15:10 --> Loader Class Initialized
INFO - 2018-08-21 18:15:10 --> Helper loaded: url_helper
INFO - 2018-08-21 18:15:10 --> Helper loaded: form_helper
INFO - 2018-08-21 18:15:10 --> Helper loaded: language_helper
DEBUG - 2018-08-21 18:15:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-21 18:15:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-21 18:15:10 --> User Agent Class Initialized
INFO - 2018-08-21 18:15:10 --> Controller Class Initialized
INFO - 2018-08-21 18:15:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-21 18:15:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-21 18:15:10 --> Pixel_Model class loaded
INFO - 2018-08-21 18:15:10 --> Database Driver Class Initialized
INFO - 2018-08-21 18:15:10 --> Model "QuestionsModel" initialized
INFO - 2018-08-21 18:15:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-21 18:15:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-21 18:15:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-21 18:15:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-21 18:15:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-21 18:15:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-21 18:15:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-08-21 18:15:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-21 18:15:10 --> Final output sent to browser
DEBUG - 2018-08-21 18:15:10 --> Total execution time: 0.0354
INFO - 2018-08-21 18:15:14 --> Config Class Initialized
INFO - 2018-08-21 18:15:14 --> Hooks Class Initialized
DEBUG - 2018-08-21 18:15:14 --> UTF-8 Support Enabled
INFO - 2018-08-21 18:15:14 --> Utf8 Class Initialized
INFO - 2018-08-21 18:15:14 --> URI Class Initialized
INFO - 2018-08-21 18:15:14 --> Router Class Initialized
INFO - 2018-08-21 18:15:14 --> Output Class Initialized
INFO - 2018-08-21 18:15:14 --> Security Class Initialized
DEBUG - 2018-08-21 18:15:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-21 18:15:14 --> CSRF cookie sent
INFO - 2018-08-21 18:15:14 --> CSRF token verified
INFO - 2018-08-21 18:15:14 --> Input Class Initialized
INFO - 2018-08-21 18:15:14 --> Language Class Initialized
INFO - 2018-08-21 18:15:14 --> Loader Class Initialized
INFO - 2018-08-21 18:15:14 --> Helper loaded: url_helper
INFO - 2018-08-21 18:15:14 --> Helper loaded: form_helper
INFO - 2018-08-21 18:15:14 --> Helper loaded: language_helper
DEBUG - 2018-08-21 18:15:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-21 18:15:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-21 18:15:14 --> User Agent Class Initialized
INFO - 2018-08-21 18:15:14 --> Controller Class Initialized
INFO - 2018-08-21 18:15:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-21 18:15:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-21 18:15:14 --> Pixel_Model class loaded
INFO - 2018-08-21 18:15:14 --> Database Driver Class Initialized
INFO - 2018-08-21 18:15:14 --> Model "QuestionsModel" initialized
INFO - 2018-08-21 18:15:14 --> Database Driver Class Initialized
INFO - 2018-08-21 18:15:14 --> Model "QuestionsModel" initialized
INFO - 2018-08-21 18:15:14 --> Config Class Initialized
INFO - 2018-08-21 18:15:14 --> Hooks Class Initialized
DEBUG - 2018-08-21 18:15:14 --> UTF-8 Support Enabled
INFO - 2018-08-21 18:15:14 --> Utf8 Class Initialized
INFO - 2018-08-21 18:15:14 --> URI Class Initialized
INFO - 2018-08-21 18:15:14 --> Router Class Initialized
INFO - 2018-08-21 18:15:14 --> Output Class Initialized
INFO - 2018-08-21 18:15:14 --> Security Class Initialized
DEBUG - 2018-08-21 18:15:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-21 18:15:14 --> CSRF cookie sent
INFO - 2018-08-21 18:15:14 --> Input Class Initialized
INFO - 2018-08-21 18:15:14 --> Language Class Initialized
INFO - 2018-08-21 18:15:14 --> Loader Class Initialized
INFO - 2018-08-21 18:15:14 --> Helper loaded: url_helper
INFO - 2018-08-21 18:15:14 --> Helper loaded: form_helper
INFO - 2018-08-21 18:15:14 --> Helper loaded: language_helper
DEBUG - 2018-08-21 18:15:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-21 18:15:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-21 18:15:14 --> User Agent Class Initialized
INFO - 2018-08-21 18:15:14 --> Controller Class Initialized
INFO - 2018-08-21 18:15:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-21 18:15:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-21 18:15:14 --> Pixel_Model class loaded
INFO - 2018-08-21 18:15:14 --> Database Driver Class Initialized
INFO - 2018-08-21 18:15:14 --> Model "QuestionsModel" initialized
INFO - 2018-08-21 18:15:14 --> Database Driver Class Initialized
INFO - 2018-08-21 18:15:14 --> Model "QuestionsModel" initialized
INFO - 2018-08-21 18:15:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-21 18:15:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-21 18:15:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-21 18:15:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-21 18:15:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-21 18:15:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-21 18:15:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-21 18:15:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-21 18:15:14 --> Final output sent to browser
DEBUG - 2018-08-21 18:15:14 --> Total execution time: 0.0452
INFO - 2018-08-21 18:15:23 --> Config Class Initialized
INFO - 2018-08-21 18:15:23 --> Hooks Class Initialized
DEBUG - 2018-08-21 18:15:23 --> UTF-8 Support Enabled
INFO - 2018-08-21 18:15:23 --> Utf8 Class Initialized
INFO - 2018-08-21 18:15:23 --> URI Class Initialized
INFO - 2018-08-21 18:15:23 --> Router Class Initialized
INFO - 2018-08-21 18:15:23 --> Output Class Initialized
INFO - 2018-08-21 18:15:23 --> Security Class Initialized
DEBUG - 2018-08-21 18:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-21 18:15:23 --> CSRF cookie sent
INFO - 2018-08-21 18:15:23 --> CSRF token verified
INFO - 2018-08-21 18:15:23 --> Input Class Initialized
INFO - 2018-08-21 18:15:23 --> Language Class Initialized
INFO - 2018-08-21 18:15:23 --> Loader Class Initialized
INFO - 2018-08-21 18:15:23 --> Helper loaded: url_helper
INFO - 2018-08-21 18:15:23 --> Helper loaded: form_helper
INFO - 2018-08-21 18:15:23 --> Helper loaded: language_helper
DEBUG - 2018-08-21 18:15:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-21 18:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-21 18:15:23 --> User Agent Class Initialized
INFO - 2018-08-21 18:15:23 --> Controller Class Initialized
INFO - 2018-08-21 18:15:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-21 18:15:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-21 18:15:23 --> Pixel_Model class loaded
INFO - 2018-08-21 18:15:23 --> Database Driver Class Initialized
INFO - 2018-08-21 18:15:23 --> Model "QuestionsModel" initialized
INFO - 2018-08-21 18:15:23 --> Form Validation Class Initialized
INFO - 2018-08-21 18:15:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-21 18:15:23 --> Database Driver Class Initialized
INFO - 2018-08-21 18:15:23 --> Model "QuestionsModel" initialized
INFO - 2018-08-21 18:15:23 --> Config Class Initialized
INFO - 2018-08-21 18:15:23 --> Hooks Class Initialized
DEBUG - 2018-08-21 18:15:23 --> UTF-8 Support Enabled
INFO - 2018-08-21 18:15:23 --> Utf8 Class Initialized
INFO - 2018-08-21 18:15:23 --> URI Class Initialized
INFO - 2018-08-21 18:15:23 --> Router Class Initialized
INFO - 2018-08-21 18:15:23 --> Output Class Initialized
INFO - 2018-08-21 18:15:23 --> Security Class Initialized
DEBUG - 2018-08-21 18:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-21 18:15:23 --> CSRF cookie sent
INFO - 2018-08-21 18:15:23 --> Input Class Initialized
INFO - 2018-08-21 18:15:23 --> Language Class Initialized
INFO - 2018-08-21 18:15:23 --> Loader Class Initialized
INFO - 2018-08-21 18:15:23 --> Helper loaded: url_helper
INFO - 2018-08-21 18:15:23 --> Helper loaded: form_helper
INFO - 2018-08-21 18:15:23 --> Helper loaded: language_helper
DEBUG - 2018-08-21 18:15:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-21 18:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-21 18:15:23 --> User Agent Class Initialized
INFO - 2018-08-21 18:15:23 --> Controller Class Initialized
INFO - 2018-08-21 18:15:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-21 18:15:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-21 18:15:23 --> Pixel_Model class loaded
INFO - 2018-08-21 18:15:23 --> Database Driver Class Initialized
INFO - 2018-08-21 18:15:23 --> Model "QuestionsModel" initialized
INFO - 2018-08-21 18:15:23 --> Database Driver Class Initialized
INFO - 2018-08-21 18:15:23 --> Model "QuestionsModel" initialized
INFO - 2018-08-21 18:15:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-21 18:15:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-21 18:15:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-21 18:15:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-21 18:15:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-21 18:15:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-21 18:15:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-08-21 18:15:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-21 18:15:23 --> Final output sent to browser
DEBUG - 2018-08-21 18:15:23 --> Total execution time: 0.0453
INFO - 2018-08-21 18:15:29 --> Config Class Initialized
INFO - 2018-08-21 18:15:29 --> Hooks Class Initialized
DEBUG - 2018-08-21 18:15:29 --> UTF-8 Support Enabled
INFO - 2018-08-21 18:15:29 --> Utf8 Class Initialized
INFO - 2018-08-21 18:15:29 --> URI Class Initialized
INFO - 2018-08-21 18:15:29 --> Router Class Initialized
INFO - 2018-08-21 18:15:29 --> Output Class Initialized
INFO - 2018-08-21 18:15:29 --> Security Class Initialized
DEBUG - 2018-08-21 18:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-21 18:15:29 --> CSRF cookie sent
INFO - 2018-08-21 18:15:29 --> CSRF token verified
INFO - 2018-08-21 18:15:29 --> Input Class Initialized
INFO - 2018-08-21 18:15:29 --> Language Class Initialized
INFO - 2018-08-21 18:15:29 --> Loader Class Initialized
INFO - 2018-08-21 18:15:29 --> Helper loaded: url_helper
INFO - 2018-08-21 18:15:29 --> Helper loaded: form_helper
INFO - 2018-08-21 18:15:29 --> Helper loaded: language_helper
DEBUG - 2018-08-21 18:15:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-21 18:15:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-21 18:15:29 --> User Agent Class Initialized
INFO - 2018-08-21 18:15:29 --> Controller Class Initialized
INFO - 2018-08-21 18:15:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-21 18:15:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-21 18:15:29 --> Pixel_Model class loaded
INFO - 2018-08-21 18:15:29 --> Database Driver Class Initialized
INFO - 2018-08-21 18:15:29 --> Model "QuestionsModel" initialized
INFO - 2018-08-21 18:15:29 --> Form Validation Class Initialized
INFO - 2018-08-21 18:15:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-21 18:15:29 --> Database Driver Class Initialized
INFO - 2018-08-21 18:15:29 --> Model "QuestionsModel" initialized
INFO - 2018-08-21 18:15:29 --> Config Class Initialized
INFO - 2018-08-21 18:15:29 --> Hooks Class Initialized
DEBUG - 2018-08-21 18:15:29 --> UTF-8 Support Enabled
INFO - 2018-08-21 18:15:29 --> Utf8 Class Initialized
INFO - 2018-08-21 18:15:29 --> URI Class Initialized
INFO - 2018-08-21 18:15:29 --> Router Class Initialized
INFO - 2018-08-21 18:15:29 --> Output Class Initialized
INFO - 2018-08-21 18:15:29 --> Security Class Initialized
DEBUG - 2018-08-21 18:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-21 18:15:29 --> CSRF cookie sent
INFO - 2018-08-21 18:15:29 --> Input Class Initialized
INFO - 2018-08-21 18:15:29 --> Language Class Initialized
INFO - 2018-08-21 18:15:29 --> Loader Class Initialized
INFO - 2018-08-21 18:15:29 --> Helper loaded: url_helper
INFO - 2018-08-21 18:15:29 --> Helper loaded: form_helper
INFO - 2018-08-21 18:15:29 --> Helper loaded: language_helper
DEBUG - 2018-08-21 18:15:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-21 18:15:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-21 18:15:29 --> User Agent Class Initialized
INFO - 2018-08-21 18:15:29 --> Controller Class Initialized
INFO - 2018-08-21 18:15:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-21 18:15:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-21 18:15:29 --> Pixel_Model class loaded
INFO - 2018-08-21 18:15:29 --> Database Driver Class Initialized
INFO - 2018-08-21 18:15:29 --> Model "QuestionsModel" initialized
INFO - 2018-08-21 18:15:29 --> Database Driver Class Initialized
INFO - 2018-08-21 18:15:29 --> Model "QuestionsModel" initialized
INFO - 2018-08-21 18:15:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-21 18:15:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-21 18:15:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-08-21 18:15:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-21 18:15:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-21 18:15:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-21 18:15:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-21 18:15:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-08-21 18:15:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-21 18:15:29 --> Final output sent to browser
DEBUG - 2018-08-21 18:15:29 --> Total execution time: 0.0391
INFO - 2018-08-21 18:15:35 --> Config Class Initialized
INFO - 2018-08-21 18:15:35 --> Hooks Class Initialized
DEBUG - 2018-08-21 18:15:35 --> UTF-8 Support Enabled
INFO - 2018-08-21 18:15:35 --> Utf8 Class Initialized
INFO - 2018-08-21 18:15:35 --> URI Class Initialized
INFO - 2018-08-21 18:15:35 --> Router Class Initialized
INFO - 2018-08-21 18:15:35 --> Output Class Initialized
INFO - 2018-08-21 18:15:35 --> Security Class Initialized
DEBUG - 2018-08-21 18:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-21 18:15:35 --> CSRF cookie sent
INFO - 2018-08-21 18:15:35 --> CSRF token verified
INFO - 2018-08-21 18:15:35 --> Input Class Initialized
INFO - 2018-08-21 18:15:35 --> Language Class Initialized
INFO - 2018-08-21 18:15:35 --> Loader Class Initialized
INFO - 2018-08-21 18:15:35 --> Helper loaded: url_helper
INFO - 2018-08-21 18:15:35 --> Helper loaded: form_helper
INFO - 2018-08-21 18:15:35 --> Helper loaded: language_helper
DEBUG - 2018-08-21 18:15:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-21 18:15:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-21 18:15:35 --> User Agent Class Initialized
INFO - 2018-08-21 18:15:35 --> Controller Class Initialized
INFO - 2018-08-21 18:15:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-21 18:15:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-21 18:15:35 --> Pixel_Model class loaded
INFO - 2018-08-21 18:15:35 --> Database Driver Class Initialized
INFO - 2018-08-21 18:15:35 --> Model "QuestionsModel" initialized
INFO - 2018-08-21 18:15:35 --> Form Validation Class Initialized
INFO - 2018-08-21 18:15:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-21 18:15:35 --> Database Driver Class Initialized
INFO - 2018-08-21 18:15:35 --> Model "QuestionsModel" initialized
INFO - 2018-08-21 18:15:36 --> Config Class Initialized
INFO - 2018-08-21 18:15:36 --> Hooks Class Initialized
DEBUG - 2018-08-21 18:15:36 --> UTF-8 Support Enabled
INFO - 2018-08-21 18:15:36 --> Utf8 Class Initialized
INFO - 2018-08-21 18:15:36 --> URI Class Initialized
INFO - 2018-08-21 18:15:36 --> Router Class Initialized
INFO - 2018-08-21 18:15:36 --> Output Class Initialized
INFO - 2018-08-21 18:15:36 --> Security Class Initialized
DEBUG - 2018-08-21 18:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-21 18:15:36 --> CSRF cookie sent
INFO - 2018-08-21 18:15:36 --> Input Class Initialized
INFO - 2018-08-21 18:15:36 --> Language Class Initialized
INFO - 2018-08-21 18:15:36 --> Loader Class Initialized
INFO - 2018-08-21 18:15:36 --> Helper loaded: url_helper
INFO - 2018-08-21 18:15:36 --> Helper loaded: form_helper
INFO - 2018-08-21 18:15:36 --> Helper loaded: language_helper
DEBUG - 2018-08-21 18:15:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-21 18:15:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-21 18:15:36 --> User Agent Class Initialized
INFO - 2018-08-21 18:15:36 --> Controller Class Initialized
INFO - 2018-08-21 18:15:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-21 18:15:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-21 18:15:36 --> Pixel_Model class loaded
INFO - 2018-08-21 18:15:36 --> Database Driver Class Initialized
INFO - 2018-08-21 18:15:36 --> Model "QuestionsModel" initialized
INFO - 2018-08-21 18:15:36 --> Database Driver Class Initialized
INFO - 2018-08-21 18:15:36 --> Model "QuestionsModel" initialized
INFO - 2018-08-21 18:15:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-21 18:15:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-21 18:15:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-21 18:15:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-21 18:15:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-21 18:15:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-21 18:15:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-08-21 18:15:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-21 18:15:36 --> Final output sent to browser
DEBUG - 2018-08-21 18:15:36 --> Total execution time: 0.0388
INFO - 2018-08-21 18:15:49 --> Config Class Initialized
INFO - 2018-08-21 18:15:49 --> Hooks Class Initialized
DEBUG - 2018-08-21 18:15:49 --> UTF-8 Support Enabled
INFO - 2018-08-21 18:15:49 --> Utf8 Class Initialized
INFO - 2018-08-21 18:15:49 --> URI Class Initialized
INFO - 2018-08-21 18:15:49 --> Router Class Initialized
INFO - 2018-08-21 18:15:49 --> Output Class Initialized
INFO - 2018-08-21 18:15:49 --> Security Class Initialized
DEBUG - 2018-08-21 18:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-21 18:15:49 --> CSRF cookie sent
INFO - 2018-08-21 18:15:49 --> CSRF token verified
INFO - 2018-08-21 18:15:49 --> Input Class Initialized
INFO - 2018-08-21 18:15:49 --> Language Class Initialized
INFO - 2018-08-21 18:15:49 --> Loader Class Initialized
INFO - 2018-08-21 18:15:49 --> Helper loaded: url_helper
INFO - 2018-08-21 18:15:49 --> Helper loaded: form_helper
INFO - 2018-08-21 18:15:49 --> Helper loaded: language_helper
DEBUG - 2018-08-21 18:15:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-21 18:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-21 18:15:49 --> User Agent Class Initialized
INFO - 2018-08-21 18:15:49 --> Controller Class Initialized
INFO - 2018-08-21 18:15:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-21 18:15:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-21 18:15:49 --> Pixel_Model class loaded
INFO - 2018-08-21 18:15:49 --> Database Driver Class Initialized
INFO - 2018-08-21 18:15:49 --> Model "QuestionsModel" initialized
INFO - 2018-08-21 18:15:49 --> Form Validation Class Initialized
INFO - 2018-08-21 18:15:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-21 18:15:49 --> Database Driver Class Initialized
INFO - 2018-08-21 18:15:49 --> Model "QuestionsModel" initialized
INFO - 2018-08-21 18:15:49 --> Config Class Initialized
INFO - 2018-08-21 18:15:49 --> Hooks Class Initialized
DEBUG - 2018-08-21 18:15:49 --> UTF-8 Support Enabled
INFO - 2018-08-21 18:15:49 --> Utf8 Class Initialized
INFO - 2018-08-21 18:15:49 --> URI Class Initialized
INFO - 2018-08-21 18:15:49 --> Router Class Initialized
INFO - 2018-08-21 18:15:49 --> Output Class Initialized
INFO - 2018-08-21 18:15:49 --> Security Class Initialized
DEBUG - 2018-08-21 18:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-21 18:15:49 --> CSRF cookie sent
INFO - 2018-08-21 18:15:49 --> Input Class Initialized
INFO - 2018-08-21 18:15:49 --> Language Class Initialized
INFO - 2018-08-21 18:15:49 --> Loader Class Initialized
INFO - 2018-08-21 18:15:49 --> Helper loaded: url_helper
INFO - 2018-08-21 18:15:49 --> Helper loaded: form_helper
INFO - 2018-08-21 18:15:49 --> Helper loaded: language_helper
DEBUG - 2018-08-21 18:15:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-21 18:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-21 18:15:49 --> User Agent Class Initialized
INFO - 2018-08-21 18:15:49 --> Controller Class Initialized
INFO - 2018-08-21 18:15:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-21 18:15:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-21 18:15:49 --> Pixel_Model class loaded
INFO - 2018-08-21 18:15:49 --> Database Driver Class Initialized
INFO - 2018-08-21 18:15:49 --> Model "QuestionsModel" initialized
INFO - 2018-08-21 18:15:49 --> Database Driver Class Initialized
INFO - 2018-08-21 18:15:49 --> Model "QuestionsModel" initialized
INFO - 2018-08-21 18:15:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-21 18:15:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-21 18:15:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-21 18:15:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-21 18:15:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-21 18:15:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-21 18:15:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-08-21 18:15:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-21 18:15:49 --> Final output sent to browser
DEBUG - 2018-08-21 18:15:49 --> Total execution time: 0.0504
INFO - 2018-08-21 18:16:05 --> Config Class Initialized
INFO - 2018-08-21 18:16:05 --> Hooks Class Initialized
DEBUG - 2018-08-21 18:16:05 --> UTF-8 Support Enabled
INFO - 2018-08-21 18:16:05 --> Utf8 Class Initialized
INFO - 2018-08-21 18:16:05 --> URI Class Initialized
INFO - 2018-08-21 18:16:05 --> Router Class Initialized
INFO - 2018-08-21 18:16:05 --> Output Class Initialized
INFO - 2018-08-21 18:16:05 --> Security Class Initialized
DEBUG - 2018-08-21 18:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-21 18:16:05 --> CSRF cookie sent
INFO - 2018-08-21 18:16:05 --> CSRF token verified
INFO - 2018-08-21 18:16:05 --> Input Class Initialized
INFO - 2018-08-21 18:16:05 --> Language Class Initialized
INFO - 2018-08-21 18:16:05 --> Loader Class Initialized
INFO - 2018-08-21 18:16:05 --> Helper loaded: url_helper
INFO - 2018-08-21 18:16:05 --> Helper loaded: form_helper
INFO - 2018-08-21 18:16:05 --> Helper loaded: language_helper
DEBUG - 2018-08-21 18:16:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-21 18:16:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-21 18:16:05 --> User Agent Class Initialized
INFO - 2018-08-21 18:16:05 --> Controller Class Initialized
INFO - 2018-08-21 18:16:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-21 18:16:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-21 18:16:05 --> Pixel_Model class loaded
INFO - 2018-08-21 18:16:05 --> Database Driver Class Initialized
INFO - 2018-08-21 18:16:05 --> Model "QuestionsModel" initialized
INFO - 2018-08-21 18:16:05 --> Form Validation Class Initialized
INFO - 2018-08-21 18:16:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-21 18:16:05 --> Database Driver Class Initialized
INFO - 2018-08-21 18:16:05 --> Model "QuestionsModel" initialized
INFO - 2018-08-21 18:16:06 --> Config Class Initialized
INFO - 2018-08-21 18:16:06 --> Hooks Class Initialized
DEBUG - 2018-08-21 18:16:06 --> UTF-8 Support Enabled
INFO - 2018-08-21 18:16:06 --> Utf8 Class Initialized
INFO - 2018-08-21 18:16:06 --> URI Class Initialized
INFO - 2018-08-21 18:16:06 --> Router Class Initialized
INFO - 2018-08-21 18:16:06 --> Output Class Initialized
INFO - 2018-08-21 18:16:06 --> Security Class Initialized
DEBUG - 2018-08-21 18:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-21 18:16:06 --> CSRF cookie sent
INFO - 2018-08-21 18:16:06 --> Input Class Initialized
INFO - 2018-08-21 18:16:06 --> Language Class Initialized
INFO - 2018-08-21 18:16:06 --> Loader Class Initialized
INFO - 2018-08-21 18:16:06 --> Helper loaded: url_helper
INFO - 2018-08-21 18:16:06 --> Helper loaded: form_helper
INFO - 2018-08-21 18:16:06 --> Helper loaded: language_helper
DEBUG - 2018-08-21 18:16:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-21 18:16:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-21 18:16:06 --> User Agent Class Initialized
INFO - 2018-08-21 18:16:06 --> Controller Class Initialized
INFO - 2018-08-21 18:16:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-21 18:16:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-21 18:16:06 --> Pixel_Model class loaded
INFO - 2018-08-21 18:16:06 --> Database Driver Class Initialized
INFO - 2018-08-21 18:16:06 --> Model "QuestionsModel" initialized
INFO - 2018-08-21 18:16:06 --> Database Driver Class Initialized
INFO - 2018-08-21 18:16:06 --> Model "QuestionsModel" initialized
INFO - 2018-08-21 18:16:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-21 18:16:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-21 18:16:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-21 18:16:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-21 18:16:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-21 18:16:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-21 18:16:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-08-21 18:16:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-21 18:16:06 --> Final output sent to browser
DEBUG - 2018-08-21 18:16:06 --> Total execution time: 0.0429
INFO - 2018-08-21 18:16:13 --> Config Class Initialized
INFO - 2018-08-21 18:16:13 --> Hooks Class Initialized
DEBUG - 2018-08-21 18:16:13 --> UTF-8 Support Enabled
INFO - 2018-08-21 18:16:13 --> Utf8 Class Initialized
INFO - 2018-08-21 18:16:13 --> URI Class Initialized
INFO - 2018-08-21 18:16:13 --> Router Class Initialized
INFO - 2018-08-21 18:16:13 --> Output Class Initialized
INFO - 2018-08-21 18:16:13 --> Security Class Initialized
DEBUG - 2018-08-21 18:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-21 18:16:13 --> CSRF cookie sent
INFO - 2018-08-21 18:16:13 --> CSRF token verified
INFO - 2018-08-21 18:16:13 --> Input Class Initialized
INFO - 2018-08-21 18:16:13 --> Language Class Initialized
INFO - 2018-08-21 18:16:13 --> Loader Class Initialized
INFO - 2018-08-21 18:16:13 --> Helper loaded: url_helper
INFO - 2018-08-21 18:16:13 --> Helper loaded: form_helper
INFO - 2018-08-21 18:16:13 --> Helper loaded: language_helper
DEBUG - 2018-08-21 18:16:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-21 18:16:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-21 18:16:13 --> User Agent Class Initialized
INFO - 2018-08-21 18:16:13 --> Controller Class Initialized
INFO - 2018-08-21 18:16:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-21 18:16:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-21 18:16:13 --> Pixel_Model class loaded
INFO - 2018-08-21 18:16:13 --> Database Driver Class Initialized
INFO - 2018-08-21 18:16:13 --> Model "QuestionsModel" initialized
INFO - 2018-08-21 18:16:13 --> Form Validation Class Initialized
INFO - 2018-08-21 18:16:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-21 18:16:13 --> Database Driver Class Initialized
INFO - 2018-08-21 18:16:13 --> Model "QuestionsModel" initialized
INFO - 2018-08-21 18:16:13 --> Config Class Initialized
INFO - 2018-08-21 18:16:13 --> Hooks Class Initialized
DEBUG - 2018-08-21 18:16:13 --> UTF-8 Support Enabled
INFO - 2018-08-21 18:16:13 --> Utf8 Class Initialized
INFO - 2018-08-21 18:16:13 --> URI Class Initialized
INFO - 2018-08-21 18:16:13 --> Router Class Initialized
INFO - 2018-08-21 18:16:13 --> Output Class Initialized
INFO - 2018-08-21 18:16:13 --> Security Class Initialized
DEBUG - 2018-08-21 18:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-21 18:16:13 --> CSRF cookie sent
INFO - 2018-08-21 18:16:13 --> Input Class Initialized
INFO - 2018-08-21 18:16:13 --> Language Class Initialized
INFO - 2018-08-21 18:16:13 --> Loader Class Initialized
INFO - 2018-08-21 18:16:13 --> Helper loaded: url_helper
INFO - 2018-08-21 18:16:13 --> Helper loaded: form_helper
INFO - 2018-08-21 18:16:13 --> Helper loaded: language_helper
DEBUG - 2018-08-21 18:16:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-21 18:16:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-21 18:16:13 --> User Agent Class Initialized
INFO - 2018-08-21 18:16:13 --> Controller Class Initialized
INFO - 2018-08-21 18:16:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-21 18:16:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-21 18:16:13 --> Pixel_Model class loaded
INFO - 2018-08-21 18:16:13 --> Database Driver Class Initialized
INFO - 2018-08-21 18:16:13 --> Model "QuestionsModel" initialized
INFO - 2018-08-21 18:16:13 --> Database Driver Class Initialized
INFO - 2018-08-21 18:16:13 --> Model "QuestionsModel" initialized
INFO - 2018-08-21 18:16:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-21 18:16:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-21 18:16:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-21 18:16:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-21 18:16:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-21 18:16:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-21 18:16:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-08-21 18:16:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-21 18:16:13 --> Final output sent to browser
DEBUG - 2018-08-21 18:16:13 --> Total execution time: 0.0556
INFO - 2018-08-21 18:16:37 --> Config Class Initialized
INFO - 2018-08-21 18:16:37 --> Hooks Class Initialized
DEBUG - 2018-08-21 18:16:37 --> UTF-8 Support Enabled
INFO - 2018-08-21 18:16:37 --> Utf8 Class Initialized
INFO - 2018-08-21 18:16:37 --> URI Class Initialized
INFO - 2018-08-21 18:16:37 --> Router Class Initialized
INFO - 2018-08-21 18:16:37 --> Output Class Initialized
INFO - 2018-08-21 18:16:37 --> Security Class Initialized
DEBUG - 2018-08-21 18:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-21 18:16:37 --> CSRF cookie sent
INFO - 2018-08-21 18:16:37 --> CSRF token verified
INFO - 2018-08-21 18:16:37 --> Input Class Initialized
INFO - 2018-08-21 18:16:37 --> Language Class Initialized
INFO - 2018-08-21 18:16:37 --> Loader Class Initialized
INFO - 2018-08-21 18:16:37 --> Helper loaded: url_helper
INFO - 2018-08-21 18:16:37 --> Helper loaded: form_helper
INFO - 2018-08-21 18:16:37 --> Helper loaded: language_helper
DEBUG - 2018-08-21 18:16:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-21 18:16:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-21 18:16:37 --> User Agent Class Initialized
INFO - 2018-08-21 18:16:37 --> Controller Class Initialized
INFO - 2018-08-21 18:16:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-21 18:16:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-21 18:16:37 --> Pixel_Model class loaded
INFO - 2018-08-21 18:16:37 --> Database Driver Class Initialized
INFO - 2018-08-21 18:16:37 --> Model "QuestionsModel" initialized
INFO - 2018-08-21 18:16:37 --> Form Validation Class Initialized
INFO - 2018-08-21 18:16:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-21 18:16:37 --> Database Driver Class Initialized
INFO - 2018-08-21 18:16:37 --> Model "QuestionsModel" initialized
INFO - 2018-08-21 18:16:37 --> Config Class Initialized
INFO - 2018-08-21 18:16:37 --> Hooks Class Initialized
DEBUG - 2018-08-21 18:16:37 --> UTF-8 Support Enabled
INFO - 2018-08-21 18:16:37 --> Utf8 Class Initialized
INFO - 2018-08-21 18:16:37 --> URI Class Initialized
INFO - 2018-08-21 18:16:37 --> Router Class Initialized
INFO - 2018-08-21 18:16:37 --> Output Class Initialized
INFO - 2018-08-21 18:16:37 --> Security Class Initialized
DEBUG - 2018-08-21 18:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-21 18:16:37 --> CSRF cookie sent
INFO - 2018-08-21 18:16:37 --> Input Class Initialized
INFO - 2018-08-21 18:16:37 --> Language Class Initialized
INFO - 2018-08-21 18:16:37 --> Loader Class Initialized
INFO - 2018-08-21 18:16:37 --> Helper loaded: url_helper
INFO - 2018-08-21 18:16:37 --> Helper loaded: form_helper
INFO - 2018-08-21 18:16:37 --> Helper loaded: language_helper
DEBUG - 2018-08-21 18:16:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-21 18:16:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-21 18:16:37 --> User Agent Class Initialized
INFO - 2018-08-21 18:16:37 --> Controller Class Initialized
INFO - 2018-08-21 18:16:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-21 18:16:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-21 18:16:37 --> Pixel_Model class loaded
INFO - 2018-08-21 18:16:37 --> Database Driver Class Initialized
INFO - 2018-08-21 18:16:37 --> Model "QuestionsModel" initialized
INFO - 2018-08-21 18:16:37 --> Database Driver Class Initialized
INFO - 2018-08-21 18:16:37 --> Model "QuestionsModel" initialized
INFO - 2018-08-21 18:16:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-21 18:16:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-21 18:16:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-21 18:16:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-21 18:16:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-21 18:16:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-21 18:16:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_title.php
INFO - 2018-08-21 18:16:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-21 18:16:37 --> Final output sent to browser
DEBUG - 2018-08-21 18:16:37 --> Total execution time: 0.0565
INFO - 2018-08-21 18:16:41 --> Config Class Initialized
INFO - 2018-08-21 18:16:41 --> Hooks Class Initialized
DEBUG - 2018-08-21 18:16:41 --> UTF-8 Support Enabled
INFO - 2018-08-21 18:16:41 --> Utf8 Class Initialized
INFO - 2018-08-21 18:16:41 --> URI Class Initialized
INFO - 2018-08-21 18:16:41 --> Router Class Initialized
INFO - 2018-08-21 18:16:41 --> Output Class Initialized
INFO - 2018-08-21 18:16:41 --> Security Class Initialized
DEBUG - 2018-08-21 18:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-21 18:16:41 --> CSRF cookie sent
INFO - 2018-08-21 18:16:41 --> CSRF token verified
INFO - 2018-08-21 18:16:41 --> Input Class Initialized
INFO - 2018-08-21 18:16:41 --> Language Class Initialized
INFO - 2018-08-21 18:16:41 --> Loader Class Initialized
INFO - 2018-08-21 18:16:41 --> Helper loaded: url_helper
INFO - 2018-08-21 18:16:41 --> Helper loaded: form_helper
INFO - 2018-08-21 18:16:41 --> Helper loaded: language_helper
DEBUG - 2018-08-21 18:16:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-21 18:16:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-21 18:16:41 --> User Agent Class Initialized
INFO - 2018-08-21 18:16:41 --> Controller Class Initialized
INFO - 2018-08-21 18:16:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-21 18:16:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-21 18:16:41 --> Pixel_Model class loaded
INFO - 2018-08-21 18:16:41 --> Database Driver Class Initialized
INFO - 2018-08-21 18:16:41 --> Model "QuestionsModel" initialized
INFO - 2018-08-21 18:16:41 --> Form Validation Class Initialized
INFO - 2018-08-21 18:16:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-21 18:16:41 --> Database Driver Class Initialized
INFO - 2018-08-21 18:16:41 --> Model "QuestionsModel" initialized
INFO - 2018-08-21 18:16:41 --> Config Class Initialized
INFO - 2018-08-21 18:16:41 --> Hooks Class Initialized
DEBUG - 2018-08-21 18:16:41 --> UTF-8 Support Enabled
INFO - 2018-08-21 18:16:41 --> Utf8 Class Initialized
INFO - 2018-08-21 18:16:41 --> URI Class Initialized
INFO - 2018-08-21 18:16:41 --> Router Class Initialized
INFO - 2018-08-21 18:16:41 --> Output Class Initialized
INFO - 2018-08-21 18:16:41 --> Security Class Initialized
DEBUG - 2018-08-21 18:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-21 18:16:41 --> CSRF cookie sent
INFO - 2018-08-21 18:16:41 --> Input Class Initialized
INFO - 2018-08-21 18:16:41 --> Language Class Initialized
INFO - 2018-08-21 18:16:41 --> Loader Class Initialized
INFO - 2018-08-21 18:16:41 --> Helper loaded: url_helper
INFO - 2018-08-21 18:16:41 --> Helper loaded: form_helper
INFO - 2018-08-21 18:16:41 --> Helper loaded: language_helper
DEBUG - 2018-08-21 18:16:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-21 18:16:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-21 18:16:41 --> User Agent Class Initialized
INFO - 2018-08-21 18:16:41 --> Controller Class Initialized
INFO - 2018-08-21 18:16:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-21 18:16:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-21 18:16:41 --> Pixel_Model class loaded
INFO - 2018-08-21 18:16:41 --> Database Driver Class Initialized
INFO - 2018-08-21 18:16:41 --> Model "QuestionsModel" initialized
INFO - 2018-08-21 18:16:41 --> Database Driver Class Initialized
INFO - 2018-08-21 18:16:41 --> Model "QuestionsModel" initialized
INFO - 2018-08-21 18:16:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-21 18:16:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-21 18:16:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-21 18:16:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-21 18:16:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-21 18:16:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-21 18:16:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-08-21 18:16:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-21 18:16:41 --> Final output sent to browser
DEBUG - 2018-08-21 18:16:41 --> Total execution time: 0.0465
INFO - 2018-08-21 18:16:43 --> Config Class Initialized
INFO - 2018-08-21 18:16:43 --> Hooks Class Initialized
DEBUG - 2018-08-21 18:16:43 --> UTF-8 Support Enabled
INFO - 2018-08-21 18:16:43 --> Utf8 Class Initialized
INFO - 2018-08-21 18:16:43 --> URI Class Initialized
INFO - 2018-08-21 18:16:43 --> Router Class Initialized
INFO - 2018-08-21 18:16:43 --> Output Class Initialized
INFO - 2018-08-21 18:16:43 --> Security Class Initialized
DEBUG - 2018-08-21 18:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-21 18:16:43 --> CSRF cookie sent
INFO - 2018-08-21 18:16:43 --> CSRF token verified
INFO - 2018-08-21 18:16:43 --> Input Class Initialized
INFO - 2018-08-21 18:16:43 --> Language Class Initialized
INFO - 2018-08-21 18:16:43 --> Loader Class Initialized
INFO - 2018-08-21 18:16:43 --> Helper loaded: url_helper
INFO - 2018-08-21 18:16:43 --> Helper loaded: form_helper
INFO - 2018-08-21 18:16:43 --> Helper loaded: language_helper
DEBUG - 2018-08-21 18:16:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-21 18:16:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-21 18:16:43 --> User Agent Class Initialized
INFO - 2018-08-21 18:16:43 --> Controller Class Initialized
INFO - 2018-08-21 18:16:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-21 18:16:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-21 18:16:43 --> Pixel_Model class loaded
INFO - 2018-08-21 18:16:43 --> Database Driver Class Initialized
INFO - 2018-08-21 18:16:43 --> Model "QuestionsModel" initialized
INFO - 2018-08-21 18:16:43 --> Form Validation Class Initialized
INFO - 2018-08-21 18:16:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-21 18:16:43 --> Database Driver Class Initialized
INFO - 2018-08-21 18:16:43 --> Model "QuestionsModel" initialized
INFO - 2018-08-21 18:16:43 --> Config Class Initialized
INFO - 2018-08-21 18:16:43 --> Hooks Class Initialized
DEBUG - 2018-08-21 18:16:43 --> UTF-8 Support Enabled
INFO - 2018-08-21 18:16:43 --> Utf8 Class Initialized
INFO - 2018-08-21 18:16:43 --> URI Class Initialized
INFO - 2018-08-21 18:16:43 --> Router Class Initialized
INFO - 2018-08-21 18:16:43 --> Output Class Initialized
INFO - 2018-08-21 18:16:43 --> Security Class Initialized
DEBUG - 2018-08-21 18:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-21 18:16:43 --> CSRF cookie sent
INFO - 2018-08-21 18:16:43 --> Input Class Initialized
INFO - 2018-08-21 18:16:43 --> Language Class Initialized
INFO - 2018-08-21 18:16:43 --> Loader Class Initialized
INFO - 2018-08-21 18:16:43 --> Helper loaded: url_helper
INFO - 2018-08-21 18:16:43 --> Helper loaded: form_helper
INFO - 2018-08-21 18:16:43 --> Helper loaded: language_helper
DEBUG - 2018-08-21 18:16:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-21 18:16:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-21 18:16:43 --> User Agent Class Initialized
INFO - 2018-08-21 18:16:43 --> Controller Class Initialized
INFO - 2018-08-21 18:16:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-21 18:16:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-21 18:16:43 --> Pixel_Model class loaded
INFO - 2018-08-21 18:16:43 --> Database Driver Class Initialized
INFO - 2018-08-21 18:16:43 --> Model "QuestionsModel" initialized
INFO - 2018-08-21 18:16:43 --> Config Class Initialized
INFO - 2018-08-21 18:16:43 --> Hooks Class Initialized
DEBUG - 2018-08-21 18:16:43 --> UTF-8 Support Enabled
INFO - 2018-08-21 18:16:43 --> Utf8 Class Initialized
INFO - 2018-08-21 18:16:43 --> URI Class Initialized
INFO - 2018-08-21 18:16:43 --> Router Class Initialized
INFO - 2018-08-21 18:16:43 --> Output Class Initialized
INFO - 2018-08-21 18:16:43 --> Security Class Initialized
DEBUG - 2018-08-21 18:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-21 18:16:43 --> CSRF cookie sent
INFO - 2018-08-21 18:16:43 --> Input Class Initialized
INFO - 2018-08-21 18:16:43 --> Language Class Initialized
INFO - 2018-08-21 18:16:43 --> Loader Class Initialized
INFO - 2018-08-21 18:16:43 --> Helper loaded: url_helper
INFO - 2018-08-21 18:16:43 --> Helper loaded: form_helper
INFO - 2018-08-21 18:16:43 --> Helper loaded: language_helper
DEBUG - 2018-08-21 18:16:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-21 18:16:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-21 18:16:43 --> User Agent Class Initialized
INFO - 2018-08-21 18:16:43 --> Controller Class Initialized
INFO - 2018-08-21 18:16:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-21 18:16:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-21 18:16:43 --> Pixel_Model class loaded
INFO - 2018-08-21 18:16:43 --> Database Driver Class Initialized
INFO - 2018-08-21 18:16:43 --> Model "RegistrationModel" initialized
DEBUG - 2018-08-21 18:16:43 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-08-21 18:16:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-21 18:16:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-21 18:16:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-21 18:16:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-08-21 18:16:43 --> Could not find the language line "req_email"
INFO - 2018-08-21 18:16:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup.php
INFO - 2018-08-21 18:16:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-21 18:16:43 --> Final output sent to browser
DEBUG - 2018-08-21 18:16:43 --> Total execution time: 0.0305
INFO - 2018-08-21 18:16:50 --> Config Class Initialized
INFO - 2018-08-21 18:16:50 --> Hooks Class Initialized
DEBUG - 2018-08-21 18:16:50 --> UTF-8 Support Enabled
INFO - 2018-08-21 18:16:50 --> Utf8 Class Initialized
INFO - 2018-08-21 18:16:50 --> URI Class Initialized
INFO - 2018-08-21 18:16:50 --> Router Class Initialized
INFO - 2018-08-21 18:16:50 --> Output Class Initialized
INFO - 2018-08-21 18:16:50 --> Security Class Initialized
DEBUG - 2018-08-21 18:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-21 18:16:50 --> CSRF cookie sent
INFO - 2018-08-21 18:16:50 --> Input Class Initialized
INFO - 2018-08-21 18:16:50 --> Language Class Initialized
INFO - 2018-08-21 18:16:50 --> Loader Class Initialized
INFO - 2018-08-21 18:16:50 --> Helper loaded: url_helper
INFO - 2018-08-21 18:16:50 --> Helper loaded: form_helper
INFO - 2018-08-21 18:16:50 --> Helper loaded: language_helper
DEBUG - 2018-08-21 18:16:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-21 18:16:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-21 18:16:50 --> User Agent Class Initialized
INFO - 2018-08-21 18:16:50 --> Controller Class Initialized
INFO - 2018-08-21 18:16:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-21 18:16:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-21 18:16:50 --> Pixel_Model class loaded
INFO - 2018-08-21 18:16:50 --> Database Driver Class Initialized
INFO - 2018-08-21 18:16:50 --> Model "QuestionsModel" initialized
INFO - 2018-08-21 18:16:50 --> Database Driver Class Initialized
INFO - 2018-08-21 18:16:50 --> Model "QuestionsModel" initialized
INFO - 2018-08-21 18:16:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-21 18:16:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-21 18:16:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-21 18:16:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-21 18:16:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-21 18:16:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-21 18:16:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-08-21 18:16:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-21 18:16:50 --> Final output sent to browser
DEBUG - 2018-08-21 18:16:50 --> Total execution time: 0.0443
INFO - 2018-08-21 19:13:11 --> Config Class Initialized
INFO - 2018-08-21 19:13:11 --> Hooks Class Initialized
DEBUG - 2018-08-21 19:13:11 --> UTF-8 Support Enabled
INFO - 2018-08-21 19:13:11 --> Utf8 Class Initialized
INFO - 2018-08-21 19:13:11 --> URI Class Initialized
INFO - 2018-08-21 19:13:11 --> Router Class Initialized
INFO - 2018-08-21 19:13:11 --> Output Class Initialized
INFO - 2018-08-21 19:13:11 --> Security Class Initialized
DEBUG - 2018-08-21 19:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-21 19:13:11 --> CSRF cookie sent
INFO - 2018-08-21 19:13:11 --> Input Class Initialized
INFO - 2018-08-21 19:13:11 --> Language Class Initialized
INFO - 2018-08-21 19:13:11 --> Loader Class Initialized
INFO - 2018-08-21 19:13:11 --> Helper loaded: url_helper
INFO - 2018-08-21 19:13:11 --> Helper loaded: form_helper
INFO - 2018-08-21 19:13:11 --> Helper loaded: language_helper
DEBUG - 2018-08-21 19:13:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-21 19:13:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-21 19:13:11 --> User Agent Class Initialized
INFO - 2018-08-21 19:13:11 --> Controller Class Initialized
INFO - 2018-08-21 19:13:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-21 19:13:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-21 19:13:11 --> Pixel_Model class loaded
INFO - 2018-08-21 19:13:11 --> Database Driver Class Initialized
INFO - 2018-08-21 19:13:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-21 19:13:11 --> Config Class Initialized
INFO - 2018-08-21 19:13:11 --> Hooks Class Initialized
DEBUG - 2018-08-21 19:13:11 --> UTF-8 Support Enabled
INFO - 2018-08-21 19:13:11 --> Utf8 Class Initialized
INFO - 2018-08-21 19:13:11 --> URI Class Initialized
INFO - 2018-08-21 19:13:11 --> Router Class Initialized
INFO - 2018-08-21 19:13:11 --> Output Class Initialized
INFO - 2018-08-21 19:13:11 --> Security Class Initialized
DEBUG - 2018-08-21 19:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-21 19:13:11 --> CSRF cookie sent
INFO - 2018-08-21 19:13:11 --> Input Class Initialized
INFO - 2018-08-21 19:13:11 --> Language Class Initialized
INFO - 2018-08-21 19:13:11 --> Loader Class Initialized
INFO - 2018-08-21 19:13:11 --> Helper loaded: url_helper
INFO - 2018-08-21 19:13:11 --> Helper loaded: form_helper
INFO - 2018-08-21 19:13:11 --> Helper loaded: language_helper
DEBUG - 2018-08-21 19:13:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-21 19:13:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-21 19:13:11 --> User Agent Class Initialized
INFO - 2018-08-21 19:13:11 --> Controller Class Initialized
INFO - 2018-08-21 19:13:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-21 19:13:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-21 19:13:11 --> Pixel_Model class loaded
INFO - 2018-08-21 19:13:11 --> Database Driver Class Initialized
INFO - 2018-08-21 19:13:11 --> Model "RegistrationModel" initialized
DEBUG - 2018-08-21 19:13:11 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-08-21 19:13:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-21 19:13:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-21 19:13:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-21 19:13:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-08-21 19:13:11 --> Could not find the language line "req_email"
INFO - 2018-08-21 19:13:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup.php
INFO - 2018-08-21 19:13:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-21 19:13:11 --> Final output sent to browser
DEBUG - 2018-08-21 19:13:11 --> Total execution time: 0.0334
INFO - 2018-08-21 19:13:14 --> Config Class Initialized
INFO - 2018-08-21 19:13:14 --> Hooks Class Initialized
DEBUG - 2018-08-21 19:13:14 --> UTF-8 Support Enabled
INFO - 2018-08-21 19:13:14 --> Utf8 Class Initialized
INFO - 2018-08-21 19:13:14 --> URI Class Initialized
INFO - 2018-08-21 19:13:14 --> Router Class Initialized
INFO - 2018-08-21 19:13:14 --> Output Class Initialized
INFO - 2018-08-21 19:13:14 --> Security Class Initialized
DEBUG - 2018-08-21 19:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-21 19:13:14 --> CSRF cookie sent
INFO - 2018-08-21 19:13:14 --> Input Class Initialized
INFO - 2018-08-21 19:13:14 --> Language Class Initialized
INFO - 2018-08-21 19:13:14 --> Loader Class Initialized
INFO - 2018-08-21 19:13:14 --> Helper loaded: url_helper
INFO - 2018-08-21 19:13:14 --> Helper loaded: form_helper
INFO - 2018-08-21 19:13:14 --> Helper loaded: language_helper
DEBUG - 2018-08-21 19:13:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-21 19:13:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-21 19:13:14 --> User Agent Class Initialized
INFO - 2018-08-21 19:13:14 --> Controller Class Initialized
INFO - 2018-08-21 19:13:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-21 19:13:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-21 19:13:14 --> Pixel_Model class loaded
INFO - 2018-08-21 19:13:14 --> Database Driver Class Initialized
INFO - 2018-08-21 19:13:14 --> Model "QuestionsModel" initialized
INFO - 2018-08-21 19:13:14 --> Database Driver Class Initialized
INFO - 2018-08-21 19:13:14 --> Model "QuestionsModel" initialized
INFO - 2018-08-21 19:13:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-21 19:13:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-21 19:13:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-21 19:13:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-21 19:13:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-21 19:13:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-21 19:13:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-08-21 19:13:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-21 19:13:14 --> Final output sent to browser
DEBUG - 2018-08-21 19:13:14 --> Total execution time: 0.0457
INFO - 2018-08-21 19:13:18 --> Config Class Initialized
INFO - 2018-08-21 19:13:18 --> Hooks Class Initialized
DEBUG - 2018-08-21 19:13:18 --> UTF-8 Support Enabled
INFO - 2018-08-21 19:13:18 --> Utf8 Class Initialized
INFO - 2018-08-21 19:13:18 --> URI Class Initialized
INFO - 2018-08-21 19:13:18 --> Router Class Initialized
INFO - 2018-08-21 19:13:18 --> Output Class Initialized
INFO - 2018-08-21 19:13:18 --> Security Class Initialized
DEBUG - 2018-08-21 19:13:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-21 19:13:18 --> CSRF cookie sent
INFO - 2018-08-21 19:13:18 --> Input Class Initialized
INFO - 2018-08-21 19:13:18 --> Language Class Initialized
INFO - 2018-08-21 19:13:18 --> Loader Class Initialized
INFO - 2018-08-21 19:13:18 --> Helper loaded: url_helper
INFO - 2018-08-21 19:13:18 --> Helper loaded: form_helper
INFO - 2018-08-21 19:13:18 --> Helper loaded: language_helper
DEBUG - 2018-08-21 19:13:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-21 19:13:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-21 19:13:19 --> User Agent Class Initialized
INFO - 2018-08-21 19:13:19 --> Controller Class Initialized
INFO - 2018-08-21 19:13:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-21 19:13:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-21 19:13:19 --> Pixel_Model class loaded
INFO - 2018-08-21 19:13:19 --> Database Driver Class Initialized
INFO - 2018-08-21 19:13:19 --> Model "QuestionsModel" initialized
INFO - 2018-08-21 19:13:19 --> Database Driver Class Initialized
INFO - 2018-08-21 19:13:19 --> Model "QuestionsModel" initialized
INFO - 2018-08-21 19:13:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-21 19:13:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-21 19:13:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-21 19:13:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-21 19:13:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-21 19:13:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-21 19:13:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_title.php
INFO - 2018-08-21 19:13:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-21 19:13:19 --> Final output sent to browser
DEBUG - 2018-08-21 19:13:19 --> Total execution time: 0.0542
INFO - 2018-08-21 19:13:22 --> Config Class Initialized
INFO - 2018-08-21 19:13:22 --> Hooks Class Initialized
DEBUG - 2018-08-21 19:13:22 --> UTF-8 Support Enabled
INFO - 2018-08-21 19:13:22 --> Utf8 Class Initialized
INFO - 2018-08-21 19:13:22 --> URI Class Initialized
INFO - 2018-08-21 19:13:22 --> Router Class Initialized
INFO - 2018-08-21 19:13:22 --> Output Class Initialized
INFO - 2018-08-21 19:13:22 --> Security Class Initialized
DEBUG - 2018-08-21 19:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-21 19:13:22 --> CSRF cookie sent
INFO - 2018-08-21 19:13:22 --> Input Class Initialized
INFO - 2018-08-21 19:13:22 --> Language Class Initialized
INFO - 2018-08-21 19:13:22 --> Loader Class Initialized
INFO - 2018-08-21 19:13:22 --> Helper loaded: url_helper
INFO - 2018-08-21 19:13:22 --> Helper loaded: form_helper
INFO - 2018-08-21 19:13:22 --> Helper loaded: language_helper
DEBUG - 2018-08-21 19:13:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-21 19:13:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-21 19:13:22 --> User Agent Class Initialized
INFO - 2018-08-21 19:13:22 --> Controller Class Initialized
INFO - 2018-08-21 19:13:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-21 19:13:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-21 19:13:22 --> Pixel_Model class loaded
INFO - 2018-08-21 19:13:22 --> Database Driver Class Initialized
INFO - 2018-08-21 19:13:22 --> Model "QuestionsModel" initialized
INFO - 2018-08-21 19:13:22 --> Database Driver Class Initialized
INFO - 2018-08-21 19:13:22 --> Model "QuestionsModel" initialized
INFO - 2018-08-21 19:13:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-21 19:13:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-21 19:13:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-21 19:13:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-21 19:13:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-21 19:13:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-21 19:13:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-08-21 19:13:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-21 19:13:22 --> Final output sent to browser
DEBUG - 2018-08-21 19:13:22 --> Total execution time: 0.0485
INFO - 2018-08-21 19:14:30 --> Config Class Initialized
INFO - 2018-08-21 19:14:30 --> Hooks Class Initialized
DEBUG - 2018-08-21 19:14:30 --> UTF-8 Support Enabled
INFO - 2018-08-21 19:14:30 --> Utf8 Class Initialized
INFO - 2018-08-21 19:14:30 --> URI Class Initialized
INFO - 2018-08-21 19:14:30 --> Router Class Initialized
INFO - 2018-08-21 19:14:30 --> Output Class Initialized
INFO - 2018-08-21 19:14:30 --> Security Class Initialized
DEBUG - 2018-08-21 19:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-21 19:14:30 --> CSRF cookie sent
INFO - 2018-08-21 19:14:30 --> Input Class Initialized
INFO - 2018-08-21 19:14:30 --> Language Class Initialized
INFO - 2018-08-21 19:14:30 --> Loader Class Initialized
INFO - 2018-08-21 19:14:30 --> Helper loaded: url_helper
INFO - 2018-08-21 19:14:30 --> Helper loaded: form_helper
INFO - 2018-08-21 19:14:30 --> Helper loaded: language_helper
DEBUG - 2018-08-21 19:14:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-21 19:14:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-21 19:14:30 --> User Agent Class Initialized
INFO - 2018-08-21 19:14:30 --> Controller Class Initialized
INFO - 2018-08-21 19:14:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-21 19:14:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-21 19:14:30 --> Pixel_Model class loaded
INFO - 2018-08-21 19:14:30 --> Database Driver Class Initialized
INFO - 2018-08-21 19:14:30 --> Model "QuestionsModel" initialized
INFO - 2018-08-21 19:14:30 --> Database Driver Class Initialized
INFO - 2018-08-21 19:14:30 --> Model "QuestionsModel" initialized
INFO - 2018-08-21 19:14:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-21 19:14:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-21 19:14:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-21 19:14:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-21 19:14:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-21 19:14:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-21 19:14:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-08-21 19:14:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-21 19:14:30 --> Final output sent to browser
DEBUG - 2018-08-21 19:14:30 --> Total execution time: 0.0488
INFO - 2018-08-21 19:14:33 --> Config Class Initialized
INFO - 2018-08-21 19:14:33 --> Hooks Class Initialized
DEBUG - 2018-08-21 19:14:33 --> UTF-8 Support Enabled
INFO - 2018-08-21 19:14:33 --> Utf8 Class Initialized
INFO - 2018-08-21 19:14:33 --> URI Class Initialized
INFO - 2018-08-21 19:14:33 --> Router Class Initialized
INFO - 2018-08-21 19:14:33 --> Output Class Initialized
INFO - 2018-08-21 19:14:33 --> Security Class Initialized
DEBUG - 2018-08-21 19:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-21 19:14:33 --> CSRF cookie sent
INFO - 2018-08-21 19:14:33 --> Input Class Initialized
INFO - 2018-08-21 19:14:33 --> Language Class Initialized
INFO - 2018-08-21 19:14:33 --> Loader Class Initialized
INFO - 2018-08-21 19:14:33 --> Helper loaded: url_helper
INFO - 2018-08-21 19:14:33 --> Helper loaded: form_helper
INFO - 2018-08-21 19:14:33 --> Helper loaded: language_helper
DEBUG - 2018-08-21 19:14:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-21 19:14:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-21 19:14:33 --> User Agent Class Initialized
INFO - 2018-08-21 19:14:33 --> Controller Class Initialized
INFO - 2018-08-21 19:14:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-21 19:14:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-21 19:14:33 --> Pixel_Model class loaded
INFO - 2018-08-21 19:14:33 --> Database Driver Class Initialized
INFO - 2018-08-21 19:14:33 --> Model "QuestionsModel" initialized
INFO - 2018-08-21 19:14:33 --> Database Driver Class Initialized
INFO - 2018-08-21 19:14:33 --> Model "QuestionsModel" initialized
INFO - 2018-08-21 19:14:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-21 19:14:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-21 19:14:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-21 19:14:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-21 19:14:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-21 19:14:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-21 19:14:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-08-21 19:14:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-21 19:14:33 --> Final output sent to browser
DEBUG - 2018-08-21 19:14:33 --> Total execution time: 0.0457
INFO - 2018-08-21 19:14:36 --> Config Class Initialized
INFO - 2018-08-21 19:14:36 --> Hooks Class Initialized
DEBUG - 2018-08-21 19:14:36 --> UTF-8 Support Enabled
INFO - 2018-08-21 19:14:36 --> Utf8 Class Initialized
INFO - 2018-08-21 19:14:36 --> URI Class Initialized
INFO - 2018-08-21 19:14:36 --> Router Class Initialized
INFO - 2018-08-21 19:14:36 --> Output Class Initialized
INFO - 2018-08-21 19:14:36 --> Security Class Initialized
DEBUG - 2018-08-21 19:14:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-21 19:14:36 --> CSRF cookie sent
INFO - 2018-08-21 19:14:36 --> Input Class Initialized
INFO - 2018-08-21 19:14:36 --> Language Class Initialized
INFO - 2018-08-21 19:14:36 --> Loader Class Initialized
INFO - 2018-08-21 19:14:36 --> Helper loaded: url_helper
INFO - 2018-08-21 19:14:36 --> Helper loaded: form_helper
INFO - 2018-08-21 19:14:36 --> Helper loaded: language_helper
DEBUG - 2018-08-21 19:14:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-21 19:14:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-21 19:14:36 --> User Agent Class Initialized
INFO - 2018-08-21 19:14:36 --> Controller Class Initialized
INFO - 2018-08-21 19:14:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-21 19:14:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-21 19:14:36 --> Pixel_Model class loaded
INFO - 2018-08-21 19:14:36 --> Database Driver Class Initialized
INFO - 2018-08-21 19:14:36 --> Model "QuestionsModel" initialized
INFO - 2018-08-21 19:14:36 --> Database Driver Class Initialized
INFO - 2018-08-21 19:14:36 --> Model "QuestionsModel" initialized
INFO - 2018-08-21 19:14:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-21 19:14:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-21 19:14:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-21 19:14:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-21 19:14:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-21 19:14:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-21 19:14:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-08-21 19:14:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-21 19:14:36 --> Final output sent to browser
DEBUG - 2018-08-21 19:14:36 --> Total execution time: 0.0372
INFO - 2018-08-21 19:14:40 --> Config Class Initialized
INFO - 2018-08-21 19:14:40 --> Hooks Class Initialized
DEBUG - 2018-08-21 19:14:40 --> UTF-8 Support Enabled
INFO - 2018-08-21 19:14:40 --> Utf8 Class Initialized
INFO - 2018-08-21 19:14:40 --> URI Class Initialized
INFO - 2018-08-21 19:14:40 --> Router Class Initialized
INFO - 2018-08-21 19:14:40 --> Output Class Initialized
INFO - 2018-08-21 19:14:40 --> Security Class Initialized
DEBUG - 2018-08-21 19:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-21 19:14:40 --> CSRF cookie sent
INFO - 2018-08-21 19:14:40 --> Input Class Initialized
INFO - 2018-08-21 19:14:40 --> Language Class Initialized
INFO - 2018-08-21 19:14:40 --> Loader Class Initialized
INFO - 2018-08-21 19:14:40 --> Helper loaded: url_helper
INFO - 2018-08-21 19:14:40 --> Helper loaded: form_helper
INFO - 2018-08-21 19:14:40 --> Helper loaded: language_helper
DEBUG - 2018-08-21 19:14:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-21 19:14:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-21 19:14:40 --> User Agent Class Initialized
INFO - 2018-08-21 19:14:40 --> Controller Class Initialized
INFO - 2018-08-21 19:14:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-21 19:14:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-21 19:14:40 --> Pixel_Model class loaded
INFO - 2018-08-21 19:14:40 --> Database Driver Class Initialized
INFO - 2018-08-21 19:14:40 --> Model "QuestionsModel" initialized
INFO - 2018-08-21 19:14:40 --> Database Driver Class Initialized
INFO - 2018-08-21 19:14:40 --> Model "QuestionsModel" initialized
INFO - 2018-08-21 19:14:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-21 19:14:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-21 19:14:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-08-21 19:14:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-21 19:14:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-21 19:14:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-21 19:14:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-21 19:14:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-08-21 19:14:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-21 19:14:40 --> Final output sent to browser
DEBUG - 2018-08-21 19:14:40 --> Total execution time: 0.0416
INFO - 2018-08-21 19:14:42 --> Config Class Initialized
INFO - 2018-08-21 19:14:42 --> Hooks Class Initialized
DEBUG - 2018-08-21 19:14:42 --> UTF-8 Support Enabled
INFO - 2018-08-21 19:14:42 --> Utf8 Class Initialized
INFO - 2018-08-21 19:14:42 --> URI Class Initialized
INFO - 2018-08-21 19:14:42 --> Router Class Initialized
INFO - 2018-08-21 19:14:42 --> Output Class Initialized
INFO - 2018-08-21 19:14:42 --> Security Class Initialized
DEBUG - 2018-08-21 19:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-21 19:14:42 --> CSRF cookie sent
INFO - 2018-08-21 19:14:42 --> Input Class Initialized
INFO - 2018-08-21 19:14:42 --> Language Class Initialized
INFO - 2018-08-21 19:14:42 --> Loader Class Initialized
INFO - 2018-08-21 19:14:42 --> Helper loaded: url_helper
INFO - 2018-08-21 19:14:42 --> Helper loaded: form_helper
INFO - 2018-08-21 19:14:42 --> Helper loaded: language_helper
DEBUG - 2018-08-21 19:14:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-21 19:14:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-21 19:14:42 --> User Agent Class Initialized
INFO - 2018-08-21 19:14:42 --> Controller Class Initialized
INFO - 2018-08-21 19:14:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-21 19:14:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-21 19:14:42 --> Pixel_Model class loaded
INFO - 2018-08-21 19:14:42 --> Database Driver Class Initialized
INFO - 2018-08-21 19:14:42 --> Model "QuestionsModel" initialized
INFO - 2018-08-21 19:14:42 --> Database Driver Class Initialized
INFO - 2018-08-21 19:14:42 --> Model "QuestionsModel" initialized
INFO - 2018-08-21 19:14:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-21 19:14:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-21 19:14:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-21 19:14:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-21 19:14:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-21 19:14:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-21 19:14:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-08-21 19:14:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-21 19:14:42 --> Final output sent to browser
DEBUG - 2018-08-21 19:14:42 --> Total execution time: 0.0449
INFO - 2018-08-21 19:14:57 --> Config Class Initialized
INFO - 2018-08-21 19:14:57 --> Hooks Class Initialized
DEBUG - 2018-08-21 19:14:57 --> UTF-8 Support Enabled
INFO - 2018-08-21 19:14:57 --> Utf8 Class Initialized
INFO - 2018-08-21 19:14:57 --> URI Class Initialized
INFO - 2018-08-21 19:14:57 --> Router Class Initialized
INFO - 2018-08-21 19:14:57 --> Output Class Initialized
INFO - 2018-08-21 19:14:57 --> Security Class Initialized
DEBUG - 2018-08-21 19:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-21 19:14:57 --> CSRF cookie sent
INFO - 2018-08-21 19:14:57 --> Input Class Initialized
INFO - 2018-08-21 19:14:57 --> Language Class Initialized
INFO - 2018-08-21 19:14:57 --> Loader Class Initialized
INFO - 2018-08-21 19:14:57 --> Helper loaded: url_helper
INFO - 2018-08-21 19:14:57 --> Helper loaded: form_helper
INFO - 2018-08-21 19:14:57 --> Helper loaded: language_helper
DEBUG - 2018-08-21 19:14:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-21 19:14:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-21 19:14:57 --> User Agent Class Initialized
INFO - 2018-08-21 19:14:57 --> Controller Class Initialized
INFO - 2018-08-21 19:14:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-21 19:14:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-21 19:14:57 --> Pixel_Model class loaded
INFO - 2018-08-21 19:14:57 --> Database Driver Class Initialized
INFO - 2018-08-21 19:14:57 --> Model "QuestionsModel" initialized
INFO - 2018-08-21 19:14:57 --> Database Driver Class Initialized
INFO - 2018-08-21 19:14:57 --> Model "QuestionsModel" initialized
INFO - 2018-08-21 19:14:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-21 19:14:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-21 19:14:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-21 19:14:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-21 19:14:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-21 19:14:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-21 19:14:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-21 19:14:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-21 19:14:57 --> Final output sent to browser
DEBUG - 2018-08-21 19:14:57 --> Total execution time: 0.0444
INFO - 2018-08-21 19:14:58 --> Config Class Initialized
INFO - 2018-08-21 19:14:58 --> Hooks Class Initialized
DEBUG - 2018-08-21 19:14:58 --> UTF-8 Support Enabled
INFO - 2018-08-21 19:14:58 --> Utf8 Class Initialized
INFO - 2018-08-21 19:14:58 --> URI Class Initialized
INFO - 2018-08-21 19:14:58 --> Router Class Initialized
INFO - 2018-08-21 19:14:58 --> Output Class Initialized
INFO - 2018-08-21 19:14:58 --> Security Class Initialized
DEBUG - 2018-08-21 19:14:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-21 19:14:58 --> CSRF cookie sent
INFO - 2018-08-21 19:14:58 --> Input Class Initialized
INFO - 2018-08-21 19:14:58 --> Language Class Initialized
INFO - 2018-08-21 19:14:58 --> Loader Class Initialized
INFO - 2018-08-21 19:14:58 --> Helper loaded: url_helper
INFO - 2018-08-21 19:14:58 --> Helper loaded: form_helper
INFO - 2018-08-21 19:14:58 --> Helper loaded: language_helper
DEBUG - 2018-08-21 19:14:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-21 19:14:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-21 19:14:58 --> User Agent Class Initialized
INFO - 2018-08-21 19:14:58 --> Controller Class Initialized
INFO - 2018-08-21 19:14:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-21 19:14:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-21 19:14:58 --> Pixel_Model class loaded
INFO - 2018-08-21 19:14:58 --> Database Driver Class Initialized
INFO - 2018-08-21 19:14:58 --> Model "QuestionsModel" initialized
INFO - 2018-08-21 19:14:58 --> Database Driver Class Initialized
INFO - 2018-08-21 19:14:58 --> Model "QuestionsModel" initialized
INFO - 2018-08-21 19:14:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-21 19:14:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-21 19:14:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-21 19:14:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-21 19:14:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-21 19:14:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-21 19:14:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-08-21 19:14:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-21 19:14:58 --> Final output sent to browser
DEBUG - 2018-08-21 19:14:58 --> Total execution time: 0.0696
INFO - 2018-08-21 19:15:05 --> Config Class Initialized
INFO - 2018-08-21 19:15:05 --> Hooks Class Initialized
DEBUG - 2018-08-21 19:15:05 --> UTF-8 Support Enabled
INFO - 2018-08-21 19:15:05 --> Utf8 Class Initialized
INFO - 2018-08-21 19:15:05 --> URI Class Initialized
INFO - 2018-08-21 19:15:05 --> Router Class Initialized
INFO - 2018-08-21 19:15:05 --> Output Class Initialized
INFO - 2018-08-21 19:15:05 --> Security Class Initialized
DEBUG - 2018-08-21 19:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-21 19:15:05 --> CSRF cookie sent
INFO - 2018-08-21 19:15:05 --> Input Class Initialized
INFO - 2018-08-21 19:15:05 --> Language Class Initialized
INFO - 2018-08-21 19:15:05 --> Loader Class Initialized
INFO - 2018-08-21 19:15:05 --> Helper loaded: url_helper
INFO - 2018-08-21 19:15:05 --> Helper loaded: form_helper
INFO - 2018-08-21 19:15:05 --> Helper loaded: language_helper
DEBUG - 2018-08-21 19:15:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-21 19:15:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-21 19:15:05 --> User Agent Class Initialized
INFO - 2018-08-21 19:15:05 --> Controller Class Initialized
INFO - 2018-08-21 19:15:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-21 19:15:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-21 19:15:05 --> Pixel_Model class loaded
INFO - 2018-08-21 19:15:05 --> Database Driver Class Initialized
INFO - 2018-08-21 19:15:05 --> Model "QuestionsModel" initialized
INFO - 2018-08-21 19:15:05 --> Database Driver Class Initialized
INFO - 2018-08-21 19:15:05 --> Model "QuestionsModel" initialized
INFO - 2018-08-21 19:15:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-21 19:15:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-21 19:15:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-08-21 19:15:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-21 19:15:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-21 19:15:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-21 19:15:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-21 19:15:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-08-21 19:15:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-21 19:15:05 --> Final output sent to browser
DEBUG - 2018-08-21 19:15:05 --> Total execution time: 0.0428
INFO - 2018-08-21 19:15:58 --> Config Class Initialized
INFO - 2018-08-21 19:15:58 --> Hooks Class Initialized
DEBUG - 2018-08-21 19:15:58 --> UTF-8 Support Enabled
INFO - 2018-08-21 19:15:58 --> Utf8 Class Initialized
INFO - 2018-08-21 19:15:58 --> URI Class Initialized
INFO - 2018-08-21 19:15:58 --> Router Class Initialized
INFO - 2018-08-21 19:15:58 --> Output Class Initialized
INFO - 2018-08-21 19:15:58 --> Security Class Initialized
DEBUG - 2018-08-21 19:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-21 19:15:58 --> CSRF cookie sent
INFO - 2018-08-21 19:15:58 --> Input Class Initialized
INFO - 2018-08-21 19:15:58 --> Language Class Initialized
INFO - 2018-08-21 19:15:58 --> Loader Class Initialized
INFO - 2018-08-21 19:15:58 --> Helper loaded: url_helper
INFO - 2018-08-21 19:15:58 --> Helper loaded: form_helper
INFO - 2018-08-21 19:15:58 --> Helper loaded: language_helper
DEBUG - 2018-08-21 19:15:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-21 19:15:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-21 19:15:58 --> User Agent Class Initialized
INFO - 2018-08-21 19:15:58 --> Controller Class Initialized
INFO - 2018-08-21 19:15:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-21 19:15:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-21 19:15:58 --> Pixel_Model class loaded
INFO - 2018-08-21 19:15:58 --> Database Driver Class Initialized
INFO - 2018-08-21 19:15:58 --> Model "QuestionsModel" initialized
INFO - 2018-08-21 19:15:58 --> Database Driver Class Initialized
INFO - 2018-08-21 19:15:58 --> Model "QuestionsModel" initialized
INFO - 2018-08-21 19:15:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-21 19:15:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-21 19:15:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-21 19:15:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-21 19:15:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-21 19:15:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-21 19:15:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-08-21 19:15:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-21 19:15:58 --> Final output sent to browser
DEBUG - 2018-08-21 19:15:58 --> Total execution time: 0.0685

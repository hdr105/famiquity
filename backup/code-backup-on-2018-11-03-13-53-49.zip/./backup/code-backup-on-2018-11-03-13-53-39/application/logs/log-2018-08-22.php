<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-08-22 14:40:37 --> Config Class Initialized
INFO - 2018-08-22 14:40:37 --> Hooks Class Initialized
DEBUG - 2018-08-22 14:40:37 --> UTF-8 Support Enabled
INFO - 2018-08-22 14:40:37 --> Utf8 Class Initialized
INFO - 2018-08-22 14:40:37 --> URI Class Initialized
DEBUG - 2018-08-22 14:40:37 --> No URI present. Default controller set.
INFO - 2018-08-22 14:40:37 --> Router Class Initialized
INFO - 2018-08-22 14:40:37 --> Output Class Initialized
INFO - 2018-08-22 14:40:37 --> Security Class Initialized
DEBUG - 2018-08-22 14:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 14:40:37 --> CSRF cookie sent
INFO - 2018-08-22 14:40:37 --> Input Class Initialized
INFO - 2018-08-22 14:40:37 --> Language Class Initialized
INFO - 2018-08-22 14:40:37 --> Loader Class Initialized
INFO - 2018-08-22 14:40:37 --> Helper loaded: url_helper
INFO - 2018-08-22 14:40:37 --> Helper loaded: form_helper
INFO - 2018-08-22 14:40:37 --> Helper loaded: language_helper
DEBUG - 2018-08-22 14:40:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 14:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 14:40:37 --> User Agent Class Initialized
INFO - 2018-08-22 14:40:37 --> Controller Class Initialized
INFO - 2018-08-22 14:40:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 14:40:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 14:40:37 --> Pixel_Model class loaded
INFO - 2018-08-22 14:40:37 --> Database Driver Class Initialized
INFO - 2018-08-22 14:40:37 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 14:40:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 14:40:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 14:40:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-22 14:40:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 14:40:37 --> Final output sent to browser
DEBUG - 2018-08-22 14:40:37 --> Total execution time: 0.0344
INFO - 2018-08-22 14:40:38 --> Config Class Initialized
INFO - 2018-08-22 14:40:38 --> Hooks Class Initialized
DEBUG - 2018-08-22 14:40:38 --> UTF-8 Support Enabled
INFO - 2018-08-22 14:40:38 --> Utf8 Class Initialized
INFO - 2018-08-22 14:40:38 --> URI Class Initialized
DEBUG - 2018-08-22 14:40:38 --> No URI present. Default controller set.
INFO - 2018-08-22 14:40:38 --> Router Class Initialized
INFO - 2018-08-22 14:40:38 --> Output Class Initialized
INFO - 2018-08-22 14:40:38 --> Security Class Initialized
DEBUG - 2018-08-22 14:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 14:40:38 --> CSRF cookie sent
INFO - 2018-08-22 14:40:38 --> Input Class Initialized
INFO - 2018-08-22 14:40:38 --> Language Class Initialized
INFO - 2018-08-22 14:40:38 --> Loader Class Initialized
INFO - 2018-08-22 14:40:38 --> Helper loaded: url_helper
INFO - 2018-08-22 14:40:38 --> Helper loaded: form_helper
INFO - 2018-08-22 14:40:38 --> Helper loaded: language_helper
DEBUG - 2018-08-22 14:40:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 14:40:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 14:40:38 --> User Agent Class Initialized
INFO - 2018-08-22 14:40:38 --> Controller Class Initialized
INFO - 2018-08-22 14:40:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 14:40:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 14:40:38 --> Pixel_Model class loaded
INFO - 2018-08-22 14:40:38 --> Database Driver Class Initialized
INFO - 2018-08-22 14:40:38 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 14:40:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 14:40:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 14:40:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-22 14:40:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 14:40:38 --> Final output sent to browser
DEBUG - 2018-08-22 14:40:38 --> Total execution time: 0.0351
INFO - 2018-08-22 14:40:45 --> Config Class Initialized
INFO - 2018-08-22 14:40:45 --> Hooks Class Initialized
DEBUG - 2018-08-22 14:40:45 --> UTF-8 Support Enabled
INFO - 2018-08-22 14:40:45 --> Utf8 Class Initialized
INFO - 2018-08-22 14:40:45 --> URI Class Initialized
INFO - 2018-08-22 14:40:45 --> Router Class Initialized
INFO - 2018-08-22 14:40:45 --> Output Class Initialized
INFO - 2018-08-22 14:40:45 --> Security Class Initialized
DEBUG - 2018-08-22 14:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 14:40:45 --> CSRF cookie sent
INFO - 2018-08-22 14:40:45 --> CSRF token verified
INFO - 2018-08-22 14:40:45 --> Input Class Initialized
INFO - 2018-08-22 14:40:45 --> Language Class Initialized
INFO - 2018-08-22 14:40:45 --> Loader Class Initialized
INFO - 2018-08-22 14:40:45 --> Helper loaded: url_helper
INFO - 2018-08-22 14:40:45 --> Helper loaded: form_helper
INFO - 2018-08-22 14:40:45 --> Helper loaded: language_helper
DEBUG - 2018-08-22 14:40:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 14:40:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 14:40:45 --> User Agent Class Initialized
INFO - 2018-08-22 14:40:45 --> Controller Class Initialized
INFO - 2018-08-22 14:40:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 14:40:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 14:40:45 --> Pixel_Model class loaded
INFO - 2018-08-22 14:40:45 --> Database Driver Class Initialized
INFO - 2018-08-22 14:40:45 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 14:40:45 --> Database Driver Class Initialized
INFO - 2018-08-22 14:40:45 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 14:40:45 --> Config Class Initialized
INFO - 2018-08-22 14:40:45 --> Hooks Class Initialized
DEBUG - 2018-08-22 14:40:45 --> UTF-8 Support Enabled
INFO - 2018-08-22 14:40:45 --> Utf8 Class Initialized
INFO - 2018-08-22 14:40:45 --> URI Class Initialized
INFO - 2018-08-22 14:40:45 --> Router Class Initialized
INFO - 2018-08-22 14:40:45 --> Output Class Initialized
INFO - 2018-08-22 14:40:45 --> Security Class Initialized
DEBUG - 2018-08-22 14:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 14:40:45 --> CSRF cookie sent
INFO - 2018-08-22 14:40:45 --> Input Class Initialized
INFO - 2018-08-22 14:40:45 --> Language Class Initialized
INFO - 2018-08-22 14:40:45 --> Loader Class Initialized
INFO - 2018-08-22 14:40:45 --> Helper loaded: url_helper
INFO - 2018-08-22 14:40:45 --> Helper loaded: form_helper
INFO - 2018-08-22 14:40:45 --> Helper loaded: language_helper
DEBUG - 2018-08-22 14:40:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 14:40:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 14:40:45 --> User Agent Class Initialized
INFO - 2018-08-22 14:40:45 --> Controller Class Initialized
INFO - 2018-08-22 14:40:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 14:40:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 14:40:45 --> Pixel_Model class loaded
INFO - 2018-08-22 14:40:45 --> Database Driver Class Initialized
INFO - 2018-08-22 14:40:45 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 14:40:45 --> Database Driver Class Initialized
INFO - 2018-08-22 14:40:45 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 14:40:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 14:40:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 14:40:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 14:40:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 14:40:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 14:40:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 14:40:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-22 14:40:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 14:40:45 --> Final output sent to browser
DEBUG - 2018-08-22 14:40:45 --> Total execution time: 0.0463
INFO - 2018-08-22 18:35:21 --> Config Class Initialized
INFO - 2018-08-22 18:35:21 --> Hooks Class Initialized
DEBUG - 2018-08-22 18:35:21 --> UTF-8 Support Enabled
INFO - 2018-08-22 18:35:21 --> Utf8 Class Initialized
INFO - 2018-08-22 18:35:21 --> URI Class Initialized
DEBUG - 2018-08-22 18:35:21 --> No URI present. Default controller set.
INFO - 2018-08-22 18:35:21 --> Router Class Initialized
INFO - 2018-08-22 18:35:21 --> Output Class Initialized
INFO - 2018-08-22 18:35:21 --> Security Class Initialized
DEBUG - 2018-08-22 18:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 18:35:21 --> CSRF cookie sent
INFO - 2018-08-22 18:35:21 --> Input Class Initialized
INFO - 2018-08-22 18:35:21 --> Language Class Initialized
INFO - 2018-08-22 18:35:21 --> Loader Class Initialized
INFO - 2018-08-22 18:35:21 --> Helper loaded: url_helper
INFO - 2018-08-22 18:35:21 --> Helper loaded: form_helper
INFO - 2018-08-22 18:35:21 --> Helper loaded: language_helper
DEBUG - 2018-08-22 18:35:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 18:35:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 18:35:21 --> User Agent Class Initialized
INFO - 2018-08-22 18:35:21 --> Controller Class Initialized
INFO - 2018-08-22 18:35:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 18:35:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 18:35:21 --> Pixel_Model class loaded
INFO - 2018-08-22 18:35:21 --> Database Driver Class Initialized
INFO - 2018-08-22 18:35:21 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:35:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 18:35:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 18:35:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-22 18:35:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 18:35:21 --> Final output sent to browser
DEBUG - 2018-08-22 18:35:21 --> Total execution time: 0.0354
INFO - 2018-08-22 18:35:40 --> Config Class Initialized
INFO - 2018-08-22 18:35:40 --> Hooks Class Initialized
DEBUG - 2018-08-22 18:35:40 --> UTF-8 Support Enabled
INFO - 2018-08-22 18:35:40 --> Utf8 Class Initialized
INFO - 2018-08-22 18:35:40 --> URI Class Initialized
INFO - 2018-08-22 18:35:40 --> Router Class Initialized
INFO - 2018-08-22 18:35:40 --> Output Class Initialized
INFO - 2018-08-22 18:35:40 --> Security Class Initialized
DEBUG - 2018-08-22 18:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 18:35:40 --> CSRF cookie sent
INFO - 2018-08-22 18:35:40 --> Input Class Initialized
INFO - 2018-08-22 18:35:40 --> Language Class Initialized
INFO - 2018-08-22 18:35:40 --> Loader Class Initialized
INFO - 2018-08-22 18:35:40 --> Helper loaded: url_helper
INFO - 2018-08-22 18:35:40 --> Helper loaded: form_helper
INFO - 2018-08-22 18:35:40 --> Helper loaded: language_helper
DEBUG - 2018-08-22 18:35:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 18:35:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 18:35:40 --> User Agent Class Initialized
INFO - 2018-08-22 18:35:40 --> Controller Class Initialized
INFO - 2018-08-22 18:35:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 18:35:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 18:35:40 --> Pixel_Model class loaded
INFO - 2018-08-22 18:35:40 --> Database Driver Class Initialized
INFO - 2018-08-22 18:35:40 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:35:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 18:35:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 18:35:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 18:35:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 18:35:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 18:35:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 18:35:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-08-22 18:35:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 18:35:40 --> Final output sent to browser
DEBUG - 2018-08-22 18:35:40 --> Total execution time: 0.0480
INFO - 2018-08-22 18:35:59 --> Config Class Initialized
INFO - 2018-08-22 18:35:59 --> Hooks Class Initialized
DEBUG - 2018-08-22 18:35:59 --> UTF-8 Support Enabled
INFO - 2018-08-22 18:35:59 --> Utf8 Class Initialized
INFO - 2018-08-22 18:35:59 --> URI Class Initialized
INFO - 2018-08-22 18:35:59 --> Router Class Initialized
INFO - 2018-08-22 18:35:59 --> Output Class Initialized
INFO - 2018-08-22 18:35:59 --> Security Class Initialized
DEBUG - 2018-08-22 18:35:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 18:35:59 --> CSRF cookie sent
INFO - 2018-08-22 18:35:59 --> CSRF token verified
INFO - 2018-08-22 18:35:59 --> Input Class Initialized
INFO - 2018-08-22 18:35:59 --> Language Class Initialized
INFO - 2018-08-22 18:35:59 --> Loader Class Initialized
INFO - 2018-08-22 18:35:59 --> Helper loaded: url_helper
INFO - 2018-08-22 18:35:59 --> Helper loaded: form_helper
INFO - 2018-08-22 18:35:59 --> Helper loaded: language_helper
DEBUG - 2018-08-22 18:35:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 18:35:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 18:35:59 --> User Agent Class Initialized
INFO - 2018-08-22 18:35:59 --> Controller Class Initialized
INFO - 2018-08-22 18:35:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 18:35:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 18:35:59 --> Pixel_Model class loaded
INFO - 2018-08-22 18:35:59 --> Database Driver Class Initialized
INFO - 2018-08-22 18:35:59 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:35:59 --> Database Driver Class Initialized
INFO - 2018-08-22 18:36:00 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:36:00 --> Config Class Initialized
INFO - 2018-08-22 18:36:00 --> Hooks Class Initialized
DEBUG - 2018-08-22 18:36:00 --> UTF-8 Support Enabled
INFO - 2018-08-22 18:36:00 --> Utf8 Class Initialized
INFO - 2018-08-22 18:36:00 --> URI Class Initialized
INFO - 2018-08-22 18:36:00 --> Router Class Initialized
INFO - 2018-08-22 18:36:00 --> Output Class Initialized
INFO - 2018-08-22 18:36:00 --> Security Class Initialized
DEBUG - 2018-08-22 18:36:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 18:36:00 --> CSRF cookie sent
INFO - 2018-08-22 18:36:00 --> Input Class Initialized
INFO - 2018-08-22 18:36:00 --> Language Class Initialized
INFO - 2018-08-22 18:36:00 --> Loader Class Initialized
INFO - 2018-08-22 18:36:00 --> Helper loaded: url_helper
INFO - 2018-08-22 18:36:00 --> Helper loaded: form_helper
INFO - 2018-08-22 18:36:00 --> Helper loaded: language_helper
DEBUG - 2018-08-22 18:36:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 18:36:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 18:36:00 --> User Agent Class Initialized
INFO - 2018-08-22 18:36:00 --> Controller Class Initialized
INFO - 2018-08-22 18:36:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 18:36:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 18:36:00 --> Pixel_Model class loaded
INFO - 2018-08-22 18:36:00 --> Database Driver Class Initialized
INFO - 2018-08-22 18:36:00 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:36:00 --> Database Driver Class Initialized
INFO - 2018-08-22 18:36:00 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:36:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 18:36:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 18:36:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 18:36:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 18:36:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 18:36:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 18:36:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-22 18:36:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 18:36:00 --> Final output sent to browser
DEBUG - 2018-08-22 18:36:00 --> Total execution time: 0.0570
INFO - 2018-08-22 18:36:03 --> Config Class Initialized
INFO - 2018-08-22 18:36:03 --> Hooks Class Initialized
DEBUG - 2018-08-22 18:36:03 --> UTF-8 Support Enabled
INFO - 2018-08-22 18:36:03 --> Utf8 Class Initialized
INFO - 2018-08-22 18:36:03 --> URI Class Initialized
INFO - 2018-08-22 18:36:03 --> Router Class Initialized
INFO - 2018-08-22 18:36:03 --> Output Class Initialized
INFO - 2018-08-22 18:36:03 --> Security Class Initialized
DEBUG - 2018-08-22 18:36:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 18:36:03 --> CSRF cookie sent
INFO - 2018-08-22 18:36:03 --> Input Class Initialized
INFO - 2018-08-22 18:36:03 --> Language Class Initialized
INFO - 2018-08-22 18:36:03 --> Loader Class Initialized
INFO - 2018-08-22 18:36:03 --> Helper loaded: url_helper
INFO - 2018-08-22 18:36:03 --> Helper loaded: form_helper
INFO - 2018-08-22 18:36:03 --> Helper loaded: language_helper
DEBUG - 2018-08-22 18:36:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 18:36:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 18:36:03 --> User Agent Class Initialized
INFO - 2018-08-22 18:36:03 --> Controller Class Initialized
INFO - 2018-08-22 18:36:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 18:36:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 18:36:03 --> Pixel_Model class loaded
INFO - 2018-08-22 18:36:03 --> Database Driver Class Initialized
INFO - 2018-08-22 18:36:03 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:36:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 18:36:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 18:36:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 18:36:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 18:36:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 18:36:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 18:36:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-08-22 18:36:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 18:36:03 --> Final output sent to browser
DEBUG - 2018-08-22 18:36:03 --> Total execution time: 0.0545
INFO - 2018-08-22 18:36:14 --> Config Class Initialized
INFO - 2018-08-22 18:36:14 --> Hooks Class Initialized
DEBUG - 2018-08-22 18:36:14 --> UTF-8 Support Enabled
INFO - 2018-08-22 18:36:14 --> Utf8 Class Initialized
INFO - 2018-08-22 18:36:14 --> URI Class Initialized
DEBUG - 2018-08-22 18:36:14 --> No URI present. Default controller set.
INFO - 2018-08-22 18:36:14 --> Router Class Initialized
INFO - 2018-08-22 18:36:14 --> Output Class Initialized
INFO - 2018-08-22 18:36:14 --> Security Class Initialized
DEBUG - 2018-08-22 18:36:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 18:36:14 --> CSRF cookie sent
INFO - 2018-08-22 18:36:14 --> Input Class Initialized
INFO - 2018-08-22 18:36:14 --> Language Class Initialized
INFO - 2018-08-22 18:36:14 --> Loader Class Initialized
INFO - 2018-08-22 18:36:14 --> Helper loaded: url_helper
INFO - 2018-08-22 18:36:14 --> Helper loaded: form_helper
INFO - 2018-08-22 18:36:14 --> Helper loaded: language_helper
DEBUG - 2018-08-22 18:36:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 18:36:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 18:36:14 --> User Agent Class Initialized
INFO - 2018-08-22 18:36:14 --> Controller Class Initialized
INFO - 2018-08-22 18:36:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 18:36:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 18:36:14 --> Pixel_Model class loaded
INFO - 2018-08-22 18:36:14 --> Database Driver Class Initialized
INFO - 2018-08-22 18:36:14 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:36:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 18:36:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 18:36:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-22 18:36:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 18:36:14 --> Final output sent to browser
DEBUG - 2018-08-22 18:36:14 --> Total execution time: 0.0408
INFO - 2018-08-22 18:43:58 --> Config Class Initialized
INFO - 2018-08-22 18:43:58 --> Hooks Class Initialized
DEBUG - 2018-08-22 18:43:58 --> UTF-8 Support Enabled
INFO - 2018-08-22 18:43:58 --> Utf8 Class Initialized
INFO - 2018-08-22 18:43:58 --> URI Class Initialized
INFO - 2018-08-22 18:43:58 --> Router Class Initialized
INFO - 2018-08-22 18:43:58 --> Output Class Initialized
INFO - 2018-08-22 18:43:58 --> Security Class Initialized
DEBUG - 2018-08-22 18:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 18:43:58 --> CSRF cookie sent
INFO - 2018-08-22 18:43:58 --> CSRF token verified
INFO - 2018-08-22 18:43:58 --> Input Class Initialized
INFO - 2018-08-22 18:43:58 --> Language Class Initialized
INFO - 2018-08-22 18:43:58 --> Loader Class Initialized
INFO - 2018-08-22 18:43:58 --> Helper loaded: url_helper
INFO - 2018-08-22 18:43:58 --> Helper loaded: form_helper
INFO - 2018-08-22 18:43:58 --> Helper loaded: language_helper
DEBUG - 2018-08-22 18:43:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 18:43:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 18:43:58 --> User Agent Class Initialized
INFO - 2018-08-22 18:43:58 --> Controller Class Initialized
INFO - 2018-08-22 18:43:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 18:43:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 18:43:58 --> Pixel_Model class loaded
INFO - 2018-08-22 18:43:58 --> Database Driver Class Initialized
INFO - 2018-08-22 18:43:58 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:43:58 --> Database Driver Class Initialized
INFO - 2018-08-22 18:43:58 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:43:59 --> Config Class Initialized
INFO - 2018-08-22 18:43:59 --> Hooks Class Initialized
DEBUG - 2018-08-22 18:43:59 --> UTF-8 Support Enabled
INFO - 2018-08-22 18:43:59 --> Utf8 Class Initialized
INFO - 2018-08-22 18:43:59 --> URI Class Initialized
INFO - 2018-08-22 18:43:59 --> Router Class Initialized
INFO - 2018-08-22 18:43:59 --> Output Class Initialized
INFO - 2018-08-22 18:43:59 --> Security Class Initialized
DEBUG - 2018-08-22 18:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 18:43:59 --> CSRF cookie sent
INFO - 2018-08-22 18:43:59 --> Input Class Initialized
INFO - 2018-08-22 18:43:59 --> Language Class Initialized
INFO - 2018-08-22 18:43:59 --> Loader Class Initialized
INFO - 2018-08-22 18:43:59 --> Helper loaded: url_helper
INFO - 2018-08-22 18:43:59 --> Helper loaded: form_helper
INFO - 2018-08-22 18:43:59 --> Helper loaded: language_helper
DEBUG - 2018-08-22 18:43:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 18:43:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 18:43:59 --> User Agent Class Initialized
INFO - 2018-08-22 18:43:59 --> Controller Class Initialized
INFO - 2018-08-22 18:43:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 18:43:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 18:43:59 --> Pixel_Model class loaded
INFO - 2018-08-22 18:43:59 --> Database Driver Class Initialized
INFO - 2018-08-22 18:43:59 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:43:59 --> Database Driver Class Initialized
INFO - 2018-08-22 18:43:59 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:43:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 18:43:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 18:43:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 18:43:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 18:43:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 18:43:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 18:43:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-22 18:43:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 18:43:59 --> Final output sent to browser
DEBUG - 2018-08-22 18:43:59 --> Total execution time: 0.0835
INFO - 2018-08-22 18:44:15 --> Config Class Initialized
INFO - 2018-08-22 18:44:15 --> Hooks Class Initialized
DEBUG - 2018-08-22 18:44:15 --> UTF-8 Support Enabled
INFO - 2018-08-22 18:44:15 --> Utf8 Class Initialized
INFO - 2018-08-22 18:44:15 --> URI Class Initialized
INFO - 2018-08-22 18:44:15 --> Router Class Initialized
INFO - 2018-08-22 18:44:15 --> Output Class Initialized
INFO - 2018-08-22 18:44:15 --> Security Class Initialized
DEBUG - 2018-08-22 18:44:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 18:44:15 --> CSRF cookie sent
INFO - 2018-08-22 18:44:15 --> CSRF token verified
INFO - 2018-08-22 18:44:15 --> Input Class Initialized
INFO - 2018-08-22 18:44:15 --> Language Class Initialized
INFO - 2018-08-22 18:44:15 --> Loader Class Initialized
INFO - 2018-08-22 18:44:15 --> Helper loaded: url_helper
INFO - 2018-08-22 18:44:15 --> Helper loaded: form_helper
INFO - 2018-08-22 18:44:15 --> Helper loaded: language_helper
DEBUG - 2018-08-22 18:44:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 18:44:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 18:44:15 --> User Agent Class Initialized
INFO - 2018-08-22 18:44:15 --> Controller Class Initialized
INFO - 2018-08-22 18:44:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 18:44:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 18:44:15 --> Pixel_Model class loaded
INFO - 2018-08-22 18:44:15 --> Database Driver Class Initialized
INFO - 2018-08-22 18:44:15 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:44:15 --> Form Validation Class Initialized
INFO - 2018-08-22 18:44:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 18:44:15 --> Database Driver Class Initialized
INFO - 2018-08-22 18:44:15 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:44:16 --> Config Class Initialized
INFO - 2018-08-22 18:44:16 --> Hooks Class Initialized
DEBUG - 2018-08-22 18:44:16 --> UTF-8 Support Enabled
INFO - 2018-08-22 18:44:16 --> Utf8 Class Initialized
INFO - 2018-08-22 18:44:16 --> URI Class Initialized
INFO - 2018-08-22 18:44:16 --> Router Class Initialized
INFO - 2018-08-22 18:44:16 --> Output Class Initialized
INFO - 2018-08-22 18:44:16 --> Security Class Initialized
DEBUG - 2018-08-22 18:44:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 18:44:16 --> CSRF cookie sent
INFO - 2018-08-22 18:44:16 --> Input Class Initialized
INFO - 2018-08-22 18:44:16 --> Language Class Initialized
INFO - 2018-08-22 18:44:16 --> Loader Class Initialized
INFO - 2018-08-22 18:44:16 --> Helper loaded: url_helper
INFO - 2018-08-22 18:44:16 --> Helper loaded: form_helper
INFO - 2018-08-22 18:44:16 --> Helper loaded: language_helper
DEBUG - 2018-08-22 18:44:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 18:44:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 18:44:16 --> User Agent Class Initialized
INFO - 2018-08-22 18:44:16 --> Controller Class Initialized
INFO - 2018-08-22 18:44:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 18:44:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 18:44:16 --> Pixel_Model class loaded
INFO - 2018-08-22 18:44:16 --> Database Driver Class Initialized
INFO - 2018-08-22 18:44:16 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:44:16 --> Database Driver Class Initialized
INFO - 2018-08-22 18:44:16 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:44:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 18:44:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 18:44:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 18:44:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 18:44:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 18:44:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 18:44:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-08-22 18:44:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 18:44:16 --> Final output sent to browser
DEBUG - 2018-08-22 18:44:16 --> Total execution time: 0.0418
INFO - 2018-08-22 18:44:22 --> Config Class Initialized
INFO - 2018-08-22 18:44:22 --> Hooks Class Initialized
DEBUG - 2018-08-22 18:44:22 --> UTF-8 Support Enabled
INFO - 2018-08-22 18:44:22 --> Utf8 Class Initialized
INFO - 2018-08-22 18:44:22 --> URI Class Initialized
INFO - 2018-08-22 18:44:22 --> Router Class Initialized
INFO - 2018-08-22 18:44:22 --> Output Class Initialized
INFO - 2018-08-22 18:44:22 --> Security Class Initialized
DEBUG - 2018-08-22 18:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 18:44:22 --> CSRF cookie sent
INFO - 2018-08-22 18:44:22 --> CSRF token verified
INFO - 2018-08-22 18:44:22 --> Input Class Initialized
INFO - 2018-08-22 18:44:22 --> Language Class Initialized
INFO - 2018-08-22 18:44:22 --> Loader Class Initialized
INFO - 2018-08-22 18:44:22 --> Helper loaded: url_helper
INFO - 2018-08-22 18:44:22 --> Helper loaded: form_helper
INFO - 2018-08-22 18:44:22 --> Helper loaded: language_helper
DEBUG - 2018-08-22 18:44:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 18:44:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 18:44:22 --> User Agent Class Initialized
INFO - 2018-08-22 18:44:22 --> Controller Class Initialized
INFO - 2018-08-22 18:44:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 18:44:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 18:44:22 --> Pixel_Model class loaded
INFO - 2018-08-22 18:44:22 --> Database Driver Class Initialized
INFO - 2018-08-22 18:44:22 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:44:22 --> Form Validation Class Initialized
INFO - 2018-08-22 18:44:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 18:44:22 --> Database Driver Class Initialized
INFO - 2018-08-22 18:44:22 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:44:23 --> Config Class Initialized
INFO - 2018-08-22 18:44:23 --> Hooks Class Initialized
DEBUG - 2018-08-22 18:44:23 --> UTF-8 Support Enabled
INFO - 2018-08-22 18:44:23 --> Utf8 Class Initialized
INFO - 2018-08-22 18:44:23 --> URI Class Initialized
INFO - 2018-08-22 18:44:23 --> Router Class Initialized
INFO - 2018-08-22 18:44:23 --> Output Class Initialized
INFO - 2018-08-22 18:44:23 --> Security Class Initialized
DEBUG - 2018-08-22 18:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 18:44:23 --> CSRF cookie sent
INFO - 2018-08-22 18:44:23 --> Input Class Initialized
INFO - 2018-08-22 18:44:23 --> Language Class Initialized
INFO - 2018-08-22 18:44:23 --> Loader Class Initialized
INFO - 2018-08-22 18:44:23 --> Helper loaded: url_helper
INFO - 2018-08-22 18:44:23 --> Helper loaded: form_helper
INFO - 2018-08-22 18:44:23 --> Helper loaded: language_helper
DEBUG - 2018-08-22 18:44:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 18:44:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 18:44:23 --> User Agent Class Initialized
INFO - 2018-08-22 18:44:23 --> Controller Class Initialized
INFO - 2018-08-22 18:44:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 18:44:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 18:44:23 --> Pixel_Model class loaded
INFO - 2018-08-22 18:44:23 --> Database Driver Class Initialized
INFO - 2018-08-22 18:44:23 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:44:23 --> Database Driver Class Initialized
INFO - 2018-08-22 18:44:23 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:44:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 18:44:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 18:44:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-08-22 18:44:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 18:44:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 18:44:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 18:44:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 18:44:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-08-22 18:44:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 18:44:23 --> Final output sent to browser
DEBUG - 2018-08-22 18:44:23 --> Total execution time: 0.0535
INFO - 2018-08-22 18:44:31 --> Config Class Initialized
INFO - 2018-08-22 18:44:31 --> Hooks Class Initialized
DEBUG - 2018-08-22 18:44:31 --> UTF-8 Support Enabled
INFO - 2018-08-22 18:44:31 --> Utf8 Class Initialized
INFO - 2018-08-22 18:44:31 --> URI Class Initialized
INFO - 2018-08-22 18:44:31 --> Router Class Initialized
INFO - 2018-08-22 18:44:31 --> Output Class Initialized
INFO - 2018-08-22 18:44:31 --> Security Class Initialized
DEBUG - 2018-08-22 18:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 18:44:31 --> CSRF cookie sent
INFO - 2018-08-22 18:44:31 --> CSRF token verified
INFO - 2018-08-22 18:44:31 --> Input Class Initialized
INFO - 2018-08-22 18:44:31 --> Language Class Initialized
INFO - 2018-08-22 18:44:31 --> Loader Class Initialized
INFO - 2018-08-22 18:44:31 --> Helper loaded: url_helper
INFO - 2018-08-22 18:44:31 --> Helper loaded: form_helper
INFO - 2018-08-22 18:44:31 --> Helper loaded: language_helper
DEBUG - 2018-08-22 18:44:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 18:44:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 18:44:31 --> User Agent Class Initialized
INFO - 2018-08-22 18:44:31 --> Controller Class Initialized
INFO - 2018-08-22 18:44:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 18:44:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 18:44:31 --> Pixel_Model class loaded
INFO - 2018-08-22 18:44:31 --> Database Driver Class Initialized
INFO - 2018-08-22 18:44:31 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:44:31 --> Form Validation Class Initialized
INFO - 2018-08-22 18:44:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 18:44:31 --> Database Driver Class Initialized
INFO - 2018-08-22 18:44:31 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:44:32 --> Config Class Initialized
INFO - 2018-08-22 18:44:32 --> Hooks Class Initialized
DEBUG - 2018-08-22 18:44:32 --> UTF-8 Support Enabled
INFO - 2018-08-22 18:44:32 --> Utf8 Class Initialized
INFO - 2018-08-22 18:44:32 --> URI Class Initialized
INFO - 2018-08-22 18:44:32 --> Router Class Initialized
INFO - 2018-08-22 18:44:32 --> Output Class Initialized
INFO - 2018-08-22 18:44:32 --> Security Class Initialized
DEBUG - 2018-08-22 18:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 18:44:32 --> CSRF cookie sent
INFO - 2018-08-22 18:44:32 --> Input Class Initialized
INFO - 2018-08-22 18:44:32 --> Language Class Initialized
INFO - 2018-08-22 18:44:32 --> Loader Class Initialized
INFO - 2018-08-22 18:44:32 --> Helper loaded: url_helper
INFO - 2018-08-22 18:44:32 --> Helper loaded: form_helper
INFO - 2018-08-22 18:44:32 --> Helper loaded: language_helper
DEBUG - 2018-08-22 18:44:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 18:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 18:44:32 --> User Agent Class Initialized
INFO - 2018-08-22 18:44:32 --> Controller Class Initialized
INFO - 2018-08-22 18:44:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 18:44:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 18:44:32 --> Pixel_Model class loaded
INFO - 2018-08-22 18:44:32 --> Database Driver Class Initialized
INFO - 2018-08-22 18:44:32 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:44:32 --> Database Driver Class Initialized
INFO - 2018-08-22 18:44:32 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:44:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 18:44:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 18:44:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 18:44:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 18:44:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 18:44:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 18:44:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-08-22 18:44:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 18:44:32 --> Final output sent to browser
DEBUG - 2018-08-22 18:44:32 --> Total execution time: 0.0410
INFO - 2018-08-22 18:44:40 --> Config Class Initialized
INFO - 2018-08-22 18:44:40 --> Hooks Class Initialized
DEBUG - 2018-08-22 18:44:40 --> UTF-8 Support Enabled
INFO - 2018-08-22 18:44:40 --> Utf8 Class Initialized
INFO - 2018-08-22 18:44:40 --> URI Class Initialized
INFO - 2018-08-22 18:44:40 --> Router Class Initialized
INFO - 2018-08-22 18:44:40 --> Output Class Initialized
INFO - 2018-08-22 18:44:40 --> Security Class Initialized
DEBUG - 2018-08-22 18:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 18:44:40 --> CSRF cookie sent
INFO - 2018-08-22 18:44:40 --> CSRF token verified
INFO - 2018-08-22 18:44:40 --> Input Class Initialized
INFO - 2018-08-22 18:44:40 --> Language Class Initialized
INFO - 2018-08-22 18:44:40 --> Loader Class Initialized
INFO - 2018-08-22 18:44:40 --> Helper loaded: url_helper
INFO - 2018-08-22 18:44:40 --> Helper loaded: form_helper
INFO - 2018-08-22 18:44:40 --> Helper loaded: language_helper
DEBUG - 2018-08-22 18:44:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 18:44:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 18:44:40 --> User Agent Class Initialized
INFO - 2018-08-22 18:44:40 --> Controller Class Initialized
INFO - 2018-08-22 18:44:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 18:44:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 18:44:40 --> Pixel_Model class loaded
INFO - 2018-08-22 18:44:40 --> Database Driver Class Initialized
INFO - 2018-08-22 18:44:40 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:44:40 --> Form Validation Class Initialized
INFO - 2018-08-22 18:44:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 18:44:40 --> Database Driver Class Initialized
INFO - 2018-08-22 18:44:40 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:44:42 --> Config Class Initialized
INFO - 2018-08-22 18:44:42 --> Hooks Class Initialized
DEBUG - 2018-08-22 18:44:42 --> UTF-8 Support Enabled
INFO - 2018-08-22 18:44:42 --> Utf8 Class Initialized
INFO - 2018-08-22 18:44:42 --> URI Class Initialized
INFO - 2018-08-22 18:44:42 --> Router Class Initialized
INFO - 2018-08-22 18:44:42 --> Output Class Initialized
INFO - 2018-08-22 18:44:42 --> Security Class Initialized
DEBUG - 2018-08-22 18:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 18:44:42 --> CSRF cookie sent
INFO - 2018-08-22 18:44:42 --> Input Class Initialized
INFO - 2018-08-22 18:44:42 --> Language Class Initialized
INFO - 2018-08-22 18:44:42 --> Loader Class Initialized
INFO - 2018-08-22 18:44:42 --> Helper loaded: url_helper
INFO - 2018-08-22 18:44:42 --> Helper loaded: form_helper
INFO - 2018-08-22 18:44:42 --> Helper loaded: language_helper
DEBUG - 2018-08-22 18:44:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 18:44:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 18:44:42 --> User Agent Class Initialized
INFO - 2018-08-22 18:44:42 --> Controller Class Initialized
INFO - 2018-08-22 18:44:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 18:44:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 18:44:42 --> Pixel_Model class loaded
INFO - 2018-08-22 18:44:42 --> Database Driver Class Initialized
INFO - 2018-08-22 18:44:42 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:44:42 --> Database Driver Class Initialized
INFO - 2018-08-22 18:44:42 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:44:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 18:44:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 18:44:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 18:44:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 18:44:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 18:44:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 18:44:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-08-22 18:44:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 18:44:42 --> Final output sent to browser
DEBUG - 2018-08-22 18:44:42 --> Total execution time: 0.0439
INFO - 2018-08-22 18:45:29 --> Config Class Initialized
INFO - 2018-08-22 18:45:29 --> Hooks Class Initialized
DEBUG - 2018-08-22 18:45:29 --> UTF-8 Support Enabled
INFO - 2018-08-22 18:45:29 --> Utf8 Class Initialized
INFO - 2018-08-22 18:45:29 --> URI Class Initialized
INFO - 2018-08-22 18:45:29 --> Router Class Initialized
INFO - 2018-08-22 18:45:29 --> Output Class Initialized
INFO - 2018-08-22 18:45:29 --> Security Class Initialized
DEBUG - 2018-08-22 18:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 18:45:29 --> CSRF cookie sent
INFO - 2018-08-22 18:45:29 --> CSRF token verified
INFO - 2018-08-22 18:45:29 --> Input Class Initialized
INFO - 2018-08-22 18:45:29 --> Language Class Initialized
INFO - 2018-08-22 18:45:29 --> Loader Class Initialized
INFO - 2018-08-22 18:45:29 --> Helper loaded: url_helper
INFO - 2018-08-22 18:45:29 --> Helper loaded: form_helper
INFO - 2018-08-22 18:45:29 --> Helper loaded: language_helper
DEBUG - 2018-08-22 18:45:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 18:45:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 18:45:29 --> User Agent Class Initialized
INFO - 2018-08-22 18:45:29 --> Controller Class Initialized
INFO - 2018-08-22 18:45:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 18:45:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 18:45:29 --> Pixel_Model class loaded
INFO - 2018-08-22 18:45:29 --> Database Driver Class Initialized
INFO - 2018-08-22 18:45:29 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:45:29 --> Form Validation Class Initialized
INFO - 2018-08-22 18:45:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 18:45:29 --> Database Driver Class Initialized
INFO - 2018-08-22 18:45:29 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:45:30 --> Config Class Initialized
INFO - 2018-08-22 18:45:30 --> Hooks Class Initialized
DEBUG - 2018-08-22 18:45:30 --> UTF-8 Support Enabled
INFO - 2018-08-22 18:45:30 --> Utf8 Class Initialized
INFO - 2018-08-22 18:45:30 --> URI Class Initialized
INFO - 2018-08-22 18:45:30 --> Router Class Initialized
INFO - 2018-08-22 18:45:30 --> Output Class Initialized
INFO - 2018-08-22 18:45:30 --> Security Class Initialized
DEBUG - 2018-08-22 18:45:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 18:45:30 --> CSRF cookie sent
INFO - 2018-08-22 18:45:30 --> Input Class Initialized
INFO - 2018-08-22 18:45:30 --> Language Class Initialized
INFO - 2018-08-22 18:45:30 --> Loader Class Initialized
INFO - 2018-08-22 18:45:30 --> Helper loaded: url_helper
INFO - 2018-08-22 18:45:30 --> Helper loaded: form_helper
INFO - 2018-08-22 18:45:30 --> Helper loaded: language_helper
DEBUG - 2018-08-22 18:45:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 18:45:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 18:45:30 --> User Agent Class Initialized
INFO - 2018-08-22 18:45:30 --> Controller Class Initialized
INFO - 2018-08-22 18:45:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 18:45:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 18:45:30 --> Pixel_Model class loaded
INFO - 2018-08-22 18:45:30 --> Database Driver Class Initialized
INFO - 2018-08-22 18:45:30 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:45:30 --> Database Driver Class Initialized
INFO - 2018-08-22 18:45:30 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:45:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 18:45:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 18:45:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 18:45:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 18:45:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 18:45:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 18:45:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-08-22 18:45:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 18:45:30 --> Final output sent to browser
DEBUG - 2018-08-22 18:45:30 --> Total execution time: 0.0507
INFO - 2018-08-22 18:51:49 --> Config Class Initialized
INFO - 2018-08-22 18:51:49 --> Hooks Class Initialized
DEBUG - 2018-08-22 18:51:49 --> UTF-8 Support Enabled
INFO - 2018-08-22 18:51:49 --> Utf8 Class Initialized
INFO - 2018-08-22 18:51:49 --> URI Class Initialized
INFO - 2018-08-22 18:51:49 --> Router Class Initialized
INFO - 2018-08-22 18:51:49 --> Output Class Initialized
INFO - 2018-08-22 18:51:49 --> Security Class Initialized
DEBUG - 2018-08-22 18:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 18:51:49 --> CSRF cookie sent
INFO - 2018-08-22 18:51:49 --> Input Class Initialized
INFO - 2018-08-22 18:51:49 --> Language Class Initialized
ERROR - 2018-08-22 18:51:49 --> 404 Page Not Found: 401shtml/index
INFO - 2018-08-22 18:51:49 --> Config Class Initialized
INFO - 2018-08-22 18:51:49 --> Hooks Class Initialized
DEBUG - 2018-08-22 18:51:49 --> UTF-8 Support Enabled
INFO - 2018-08-22 18:51:49 --> Utf8 Class Initialized
INFO - 2018-08-22 18:51:49 --> URI Class Initialized
INFO - 2018-08-22 18:51:49 --> Router Class Initialized
INFO - 2018-08-22 18:51:49 --> Output Class Initialized
INFO - 2018-08-22 18:51:49 --> Security Class Initialized
DEBUG - 2018-08-22 18:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 18:51:49 --> CSRF cookie sent
INFO - 2018-08-22 18:51:49 --> Input Class Initialized
INFO - 2018-08-22 18:51:49 --> Language Class Initialized
ERROR - 2018-08-22 18:51:49 --> 404 Page Not Found: Faviconico/index
INFO - 2018-08-22 18:51:54 --> Config Class Initialized
INFO - 2018-08-22 18:51:54 --> Hooks Class Initialized
DEBUG - 2018-08-22 18:51:54 --> UTF-8 Support Enabled
INFO - 2018-08-22 18:51:54 --> Utf8 Class Initialized
INFO - 2018-08-22 18:51:54 --> URI Class Initialized
DEBUG - 2018-08-22 18:51:54 --> No URI present. Default controller set.
INFO - 2018-08-22 18:51:54 --> Router Class Initialized
INFO - 2018-08-22 18:51:54 --> Output Class Initialized
INFO - 2018-08-22 18:51:54 --> Security Class Initialized
DEBUG - 2018-08-22 18:51:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 18:51:54 --> CSRF cookie sent
INFO - 2018-08-22 18:51:54 --> Input Class Initialized
INFO - 2018-08-22 18:51:54 --> Language Class Initialized
INFO - 2018-08-22 18:51:54 --> Loader Class Initialized
INFO - 2018-08-22 18:51:54 --> Helper loaded: url_helper
INFO - 2018-08-22 18:51:54 --> Helper loaded: form_helper
INFO - 2018-08-22 18:51:54 --> Helper loaded: language_helper
DEBUG - 2018-08-22 18:51:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 18:51:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 18:51:54 --> User Agent Class Initialized
INFO - 2018-08-22 18:51:54 --> Controller Class Initialized
INFO - 2018-08-22 18:51:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 18:51:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 18:51:54 --> Pixel_Model class loaded
INFO - 2018-08-22 18:51:54 --> Database Driver Class Initialized
INFO - 2018-08-22 18:51:54 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:51:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 18:51:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 18:51:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-22 18:51:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 18:51:54 --> Final output sent to browser
DEBUG - 2018-08-22 18:51:54 --> Total execution time: 0.0397
INFO - 2018-08-22 18:51:59 --> Config Class Initialized
INFO - 2018-08-22 18:51:59 --> Hooks Class Initialized
DEBUG - 2018-08-22 18:51:59 --> UTF-8 Support Enabled
INFO - 2018-08-22 18:51:59 --> Utf8 Class Initialized
INFO - 2018-08-22 18:51:59 --> URI Class Initialized
INFO - 2018-08-22 18:51:59 --> Router Class Initialized
INFO - 2018-08-22 18:51:59 --> Output Class Initialized
INFO - 2018-08-22 18:51:59 --> Security Class Initialized
DEBUG - 2018-08-22 18:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 18:51:59 --> CSRF cookie sent
INFO - 2018-08-22 18:51:59 --> Input Class Initialized
INFO - 2018-08-22 18:51:59 --> Language Class Initialized
INFO - 2018-08-22 18:51:59 --> Loader Class Initialized
INFO - 2018-08-22 18:51:59 --> Helper loaded: url_helper
INFO - 2018-08-22 18:51:59 --> Helper loaded: form_helper
INFO - 2018-08-22 18:51:59 --> Helper loaded: language_helper
DEBUG - 2018-08-22 18:51:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 18:51:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 18:51:59 --> User Agent Class Initialized
INFO - 2018-08-22 18:51:59 --> Controller Class Initialized
INFO - 2018-08-22 18:51:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 18:51:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 18:51:59 --> Pixel_Model class loaded
INFO - 2018-08-22 18:51:59 --> Database Driver Class Initialized
INFO - 2018-08-22 18:51:59 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:51:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 18:51:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 18:51:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 18:51:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 18:51:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 18:51:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 18:51:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-08-22 18:51:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 18:51:59 --> Final output sent to browser
DEBUG - 2018-08-22 18:51:59 --> Total execution time: 0.0358
INFO - 2018-08-22 18:54:28 --> Config Class Initialized
INFO - 2018-08-22 18:54:28 --> Hooks Class Initialized
DEBUG - 2018-08-22 18:54:28 --> UTF-8 Support Enabled
INFO - 2018-08-22 18:54:28 --> Utf8 Class Initialized
INFO - 2018-08-22 18:54:28 --> URI Class Initialized
INFO - 2018-08-22 18:54:28 --> Router Class Initialized
INFO - 2018-08-22 18:54:28 --> Output Class Initialized
INFO - 2018-08-22 18:54:28 --> Security Class Initialized
DEBUG - 2018-08-22 18:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 18:54:28 --> CSRF cookie sent
INFO - 2018-08-22 18:54:28 --> CSRF token verified
INFO - 2018-08-22 18:54:28 --> Input Class Initialized
INFO - 2018-08-22 18:54:28 --> Language Class Initialized
INFO - 2018-08-22 18:54:28 --> Loader Class Initialized
INFO - 2018-08-22 18:54:28 --> Helper loaded: url_helper
INFO - 2018-08-22 18:54:28 --> Helper loaded: form_helper
INFO - 2018-08-22 18:54:28 --> Helper loaded: language_helper
DEBUG - 2018-08-22 18:54:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 18:54:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 18:54:28 --> User Agent Class Initialized
INFO - 2018-08-22 18:54:28 --> Controller Class Initialized
INFO - 2018-08-22 18:54:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 18:54:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 18:54:28 --> Pixel_Model class loaded
INFO - 2018-08-22 18:54:28 --> Database Driver Class Initialized
INFO - 2018-08-22 18:54:28 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:54:28 --> Database Driver Class Initialized
INFO - 2018-08-22 18:54:28 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:54:28 --> Config Class Initialized
INFO - 2018-08-22 18:54:28 --> Hooks Class Initialized
DEBUG - 2018-08-22 18:54:28 --> UTF-8 Support Enabled
INFO - 2018-08-22 18:54:28 --> Utf8 Class Initialized
INFO - 2018-08-22 18:54:28 --> URI Class Initialized
INFO - 2018-08-22 18:54:28 --> Router Class Initialized
INFO - 2018-08-22 18:54:28 --> Output Class Initialized
INFO - 2018-08-22 18:54:28 --> Security Class Initialized
DEBUG - 2018-08-22 18:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 18:54:28 --> CSRF cookie sent
INFO - 2018-08-22 18:54:28 --> Input Class Initialized
INFO - 2018-08-22 18:54:28 --> Language Class Initialized
INFO - 2018-08-22 18:54:28 --> Loader Class Initialized
INFO - 2018-08-22 18:54:28 --> Helper loaded: url_helper
INFO - 2018-08-22 18:54:28 --> Helper loaded: form_helper
INFO - 2018-08-22 18:54:28 --> Helper loaded: language_helper
DEBUG - 2018-08-22 18:54:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 18:54:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 18:54:28 --> User Agent Class Initialized
INFO - 2018-08-22 18:54:28 --> Controller Class Initialized
INFO - 2018-08-22 18:54:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 18:54:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 18:54:28 --> Pixel_Model class loaded
INFO - 2018-08-22 18:54:28 --> Database Driver Class Initialized
INFO - 2018-08-22 18:54:28 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:54:28 --> Database Driver Class Initialized
INFO - 2018-08-22 18:54:28 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:54:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 18:54:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 18:54:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 18:54:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 18:54:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 18:54:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 18:54:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-22 18:54:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 18:54:28 --> Final output sent to browser
DEBUG - 2018-08-22 18:54:28 --> Total execution time: 0.0436
INFO - 2018-08-22 18:54:33 --> Config Class Initialized
INFO - 2018-08-22 18:54:33 --> Hooks Class Initialized
DEBUG - 2018-08-22 18:54:33 --> UTF-8 Support Enabled
INFO - 2018-08-22 18:54:33 --> Utf8 Class Initialized
INFO - 2018-08-22 18:54:33 --> URI Class Initialized
INFO - 2018-08-22 18:54:33 --> Router Class Initialized
INFO - 2018-08-22 18:54:33 --> Output Class Initialized
INFO - 2018-08-22 18:54:33 --> Security Class Initialized
DEBUG - 2018-08-22 18:54:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 18:54:33 --> CSRF cookie sent
INFO - 2018-08-22 18:54:33 --> CSRF token verified
INFO - 2018-08-22 18:54:33 --> Input Class Initialized
INFO - 2018-08-22 18:54:33 --> Language Class Initialized
INFO - 2018-08-22 18:54:33 --> Loader Class Initialized
INFO - 2018-08-22 18:54:33 --> Helper loaded: url_helper
INFO - 2018-08-22 18:54:33 --> Helper loaded: form_helper
INFO - 2018-08-22 18:54:33 --> Helper loaded: language_helper
DEBUG - 2018-08-22 18:54:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 18:54:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 18:54:33 --> User Agent Class Initialized
INFO - 2018-08-22 18:54:33 --> Controller Class Initialized
INFO - 2018-08-22 18:54:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 18:54:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 18:54:33 --> Pixel_Model class loaded
INFO - 2018-08-22 18:54:33 --> Database Driver Class Initialized
INFO - 2018-08-22 18:54:33 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:54:33 --> Form Validation Class Initialized
INFO - 2018-08-22 18:54:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 18:54:33 --> Database Driver Class Initialized
INFO - 2018-08-22 18:54:33 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:54:33 --> Config Class Initialized
INFO - 2018-08-22 18:54:33 --> Hooks Class Initialized
DEBUG - 2018-08-22 18:54:33 --> UTF-8 Support Enabled
INFO - 2018-08-22 18:54:33 --> Utf8 Class Initialized
INFO - 2018-08-22 18:54:33 --> URI Class Initialized
INFO - 2018-08-22 18:54:33 --> Router Class Initialized
INFO - 2018-08-22 18:54:33 --> Output Class Initialized
INFO - 2018-08-22 18:54:33 --> Security Class Initialized
DEBUG - 2018-08-22 18:54:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 18:54:33 --> CSRF cookie sent
INFO - 2018-08-22 18:54:33 --> Input Class Initialized
INFO - 2018-08-22 18:54:33 --> Language Class Initialized
INFO - 2018-08-22 18:54:33 --> Loader Class Initialized
INFO - 2018-08-22 18:54:33 --> Helper loaded: url_helper
INFO - 2018-08-22 18:54:33 --> Helper loaded: form_helper
INFO - 2018-08-22 18:54:33 --> Helper loaded: language_helper
DEBUG - 2018-08-22 18:54:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 18:54:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 18:54:33 --> User Agent Class Initialized
INFO - 2018-08-22 18:54:33 --> Controller Class Initialized
INFO - 2018-08-22 18:54:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 18:54:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 18:54:33 --> Pixel_Model class loaded
INFO - 2018-08-22 18:54:33 --> Database Driver Class Initialized
INFO - 2018-08-22 18:54:33 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:54:33 --> Database Driver Class Initialized
INFO - 2018-08-22 18:54:33 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:54:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 18:54:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 18:54:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 18:54:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 18:54:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 18:54:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 18:54:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-08-22 18:54:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 18:54:33 --> Final output sent to browser
DEBUG - 2018-08-22 18:54:33 --> Total execution time: 0.0358
INFO - 2018-08-22 18:56:04 --> Config Class Initialized
INFO - 2018-08-22 18:56:04 --> Hooks Class Initialized
DEBUG - 2018-08-22 18:56:04 --> UTF-8 Support Enabled
INFO - 2018-08-22 18:56:04 --> Utf8 Class Initialized
INFO - 2018-08-22 18:56:04 --> URI Class Initialized
INFO - 2018-08-22 18:56:04 --> Router Class Initialized
INFO - 2018-08-22 18:56:04 --> Output Class Initialized
INFO - 2018-08-22 18:56:04 --> Security Class Initialized
DEBUG - 2018-08-22 18:56:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 18:56:04 --> CSRF cookie sent
INFO - 2018-08-22 18:56:04 --> CSRF token verified
INFO - 2018-08-22 18:56:04 --> Input Class Initialized
INFO - 2018-08-22 18:56:04 --> Language Class Initialized
INFO - 2018-08-22 18:56:04 --> Loader Class Initialized
INFO - 2018-08-22 18:56:04 --> Helper loaded: url_helper
INFO - 2018-08-22 18:56:04 --> Helper loaded: form_helper
INFO - 2018-08-22 18:56:04 --> Helper loaded: language_helper
DEBUG - 2018-08-22 18:56:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 18:56:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 18:56:04 --> User Agent Class Initialized
INFO - 2018-08-22 18:56:04 --> Controller Class Initialized
INFO - 2018-08-22 18:56:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 18:56:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 18:56:04 --> Pixel_Model class loaded
INFO - 2018-08-22 18:56:04 --> Database Driver Class Initialized
INFO - 2018-08-22 18:56:04 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:56:04 --> Form Validation Class Initialized
INFO - 2018-08-22 18:56:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 18:56:04 --> Database Driver Class Initialized
INFO - 2018-08-22 18:56:04 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:56:04 --> Config Class Initialized
INFO - 2018-08-22 18:56:04 --> Hooks Class Initialized
DEBUG - 2018-08-22 18:56:04 --> UTF-8 Support Enabled
INFO - 2018-08-22 18:56:04 --> Utf8 Class Initialized
INFO - 2018-08-22 18:56:04 --> URI Class Initialized
INFO - 2018-08-22 18:56:04 --> Router Class Initialized
INFO - 2018-08-22 18:56:04 --> Output Class Initialized
INFO - 2018-08-22 18:56:04 --> Security Class Initialized
DEBUG - 2018-08-22 18:56:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 18:56:04 --> CSRF cookie sent
INFO - 2018-08-22 18:56:04 --> Input Class Initialized
INFO - 2018-08-22 18:56:04 --> Language Class Initialized
INFO - 2018-08-22 18:56:04 --> Loader Class Initialized
INFO - 2018-08-22 18:56:04 --> Helper loaded: url_helper
INFO - 2018-08-22 18:56:04 --> Helper loaded: form_helper
INFO - 2018-08-22 18:56:04 --> Helper loaded: language_helper
DEBUG - 2018-08-22 18:56:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 18:56:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 18:56:04 --> User Agent Class Initialized
INFO - 2018-08-22 18:56:04 --> Controller Class Initialized
INFO - 2018-08-22 18:56:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 18:56:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 18:56:04 --> Pixel_Model class loaded
INFO - 2018-08-22 18:56:04 --> Database Driver Class Initialized
INFO - 2018-08-22 18:56:04 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:56:04 --> Database Driver Class Initialized
INFO - 2018-08-22 18:56:04 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:56:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 18:56:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 18:56:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-08-22 18:56:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 18:56:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 18:56:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 18:56:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 18:56:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-08-22 18:56:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 18:56:04 --> Final output sent to browser
DEBUG - 2018-08-22 18:56:04 --> Total execution time: 0.0539
INFO - 2018-08-22 18:56:06 --> Config Class Initialized
INFO - 2018-08-22 18:56:06 --> Hooks Class Initialized
DEBUG - 2018-08-22 18:56:06 --> UTF-8 Support Enabled
INFO - 2018-08-22 18:56:06 --> Utf8 Class Initialized
INFO - 2018-08-22 18:56:06 --> URI Class Initialized
INFO - 2018-08-22 18:56:06 --> Router Class Initialized
INFO - 2018-08-22 18:56:06 --> Output Class Initialized
INFO - 2018-08-22 18:56:06 --> Security Class Initialized
DEBUG - 2018-08-22 18:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 18:56:06 --> CSRF cookie sent
INFO - 2018-08-22 18:56:06 --> CSRF token verified
INFO - 2018-08-22 18:56:06 --> Input Class Initialized
INFO - 2018-08-22 18:56:06 --> Language Class Initialized
INFO - 2018-08-22 18:56:06 --> Loader Class Initialized
INFO - 2018-08-22 18:56:06 --> Helper loaded: url_helper
INFO - 2018-08-22 18:56:06 --> Helper loaded: form_helper
INFO - 2018-08-22 18:56:06 --> Helper loaded: language_helper
DEBUG - 2018-08-22 18:56:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 18:56:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 18:56:06 --> User Agent Class Initialized
INFO - 2018-08-22 18:56:06 --> Controller Class Initialized
INFO - 2018-08-22 18:56:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 18:56:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 18:56:06 --> Pixel_Model class loaded
INFO - 2018-08-22 18:56:06 --> Database Driver Class Initialized
INFO - 2018-08-22 18:56:06 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:56:06 --> Form Validation Class Initialized
INFO - 2018-08-22 18:56:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 18:56:06 --> Database Driver Class Initialized
INFO - 2018-08-22 18:56:06 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:56:06 --> Config Class Initialized
INFO - 2018-08-22 18:56:06 --> Hooks Class Initialized
DEBUG - 2018-08-22 18:56:06 --> UTF-8 Support Enabled
INFO - 2018-08-22 18:56:06 --> Utf8 Class Initialized
INFO - 2018-08-22 18:56:06 --> URI Class Initialized
INFO - 2018-08-22 18:56:06 --> Router Class Initialized
INFO - 2018-08-22 18:56:06 --> Output Class Initialized
INFO - 2018-08-22 18:56:06 --> Security Class Initialized
DEBUG - 2018-08-22 18:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 18:56:06 --> CSRF cookie sent
INFO - 2018-08-22 18:56:06 --> Input Class Initialized
INFO - 2018-08-22 18:56:06 --> Language Class Initialized
INFO - 2018-08-22 18:56:06 --> Loader Class Initialized
INFO - 2018-08-22 18:56:06 --> Helper loaded: url_helper
INFO - 2018-08-22 18:56:06 --> Helper loaded: form_helper
INFO - 2018-08-22 18:56:06 --> Helper loaded: language_helper
DEBUG - 2018-08-22 18:56:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 18:56:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 18:56:06 --> User Agent Class Initialized
INFO - 2018-08-22 18:56:06 --> Controller Class Initialized
INFO - 2018-08-22 18:56:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 18:56:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 18:56:06 --> Pixel_Model class loaded
INFO - 2018-08-22 18:56:06 --> Database Driver Class Initialized
INFO - 2018-08-22 18:56:06 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:56:06 --> Database Driver Class Initialized
INFO - 2018-08-22 18:56:06 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:56:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 18:56:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 18:56:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 18:56:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 18:56:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 18:56:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 18:56:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-08-22 18:56:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 18:56:06 --> Final output sent to browser
DEBUG - 2018-08-22 18:56:06 --> Total execution time: 0.0410
INFO - 2018-08-22 18:56:27 --> Config Class Initialized
INFO - 2018-08-22 18:56:27 --> Hooks Class Initialized
DEBUG - 2018-08-22 18:56:27 --> UTF-8 Support Enabled
INFO - 2018-08-22 18:56:27 --> Utf8 Class Initialized
INFO - 2018-08-22 18:56:27 --> URI Class Initialized
INFO - 2018-08-22 18:56:27 --> Router Class Initialized
INFO - 2018-08-22 18:56:27 --> Output Class Initialized
INFO - 2018-08-22 18:56:27 --> Security Class Initialized
DEBUG - 2018-08-22 18:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 18:56:27 --> CSRF cookie sent
INFO - 2018-08-22 18:56:27 --> CSRF token verified
INFO - 2018-08-22 18:56:27 --> Input Class Initialized
INFO - 2018-08-22 18:56:27 --> Language Class Initialized
INFO - 2018-08-22 18:56:27 --> Loader Class Initialized
INFO - 2018-08-22 18:56:27 --> Helper loaded: url_helper
INFO - 2018-08-22 18:56:27 --> Helper loaded: form_helper
INFO - 2018-08-22 18:56:27 --> Helper loaded: language_helper
DEBUG - 2018-08-22 18:56:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 18:56:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 18:56:27 --> User Agent Class Initialized
INFO - 2018-08-22 18:56:27 --> Controller Class Initialized
INFO - 2018-08-22 18:56:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 18:56:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 18:56:27 --> Pixel_Model class loaded
INFO - 2018-08-22 18:56:27 --> Database Driver Class Initialized
INFO - 2018-08-22 18:56:27 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:56:27 --> Form Validation Class Initialized
INFO - 2018-08-22 18:56:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 18:56:27 --> Database Driver Class Initialized
INFO - 2018-08-22 18:56:27 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:56:27 --> Config Class Initialized
INFO - 2018-08-22 18:56:27 --> Hooks Class Initialized
DEBUG - 2018-08-22 18:56:27 --> UTF-8 Support Enabled
INFO - 2018-08-22 18:56:27 --> Utf8 Class Initialized
INFO - 2018-08-22 18:56:27 --> URI Class Initialized
INFO - 2018-08-22 18:56:27 --> Router Class Initialized
INFO - 2018-08-22 18:56:27 --> Output Class Initialized
INFO - 2018-08-22 18:56:27 --> Security Class Initialized
DEBUG - 2018-08-22 18:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 18:56:27 --> CSRF cookie sent
INFO - 2018-08-22 18:56:27 --> Input Class Initialized
INFO - 2018-08-22 18:56:27 --> Language Class Initialized
INFO - 2018-08-22 18:56:27 --> Loader Class Initialized
INFO - 2018-08-22 18:56:27 --> Helper loaded: url_helper
INFO - 2018-08-22 18:56:27 --> Helper loaded: form_helper
INFO - 2018-08-22 18:56:27 --> Helper loaded: language_helper
DEBUG - 2018-08-22 18:56:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 18:56:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 18:56:27 --> User Agent Class Initialized
INFO - 2018-08-22 18:56:27 --> Controller Class Initialized
INFO - 2018-08-22 18:56:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 18:56:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 18:56:27 --> Pixel_Model class loaded
INFO - 2018-08-22 18:56:27 --> Database Driver Class Initialized
INFO - 2018-08-22 18:56:27 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:56:27 --> Database Driver Class Initialized
INFO - 2018-08-22 18:56:27 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:56:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 18:56:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 18:56:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 18:56:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 18:56:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 18:56:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 18:56:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-08-22 18:56:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 18:56:27 --> Final output sent to browser
DEBUG - 2018-08-22 18:56:27 --> Total execution time: 0.0608
INFO - 2018-08-22 18:56:34 --> Config Class Initialized
INFO - 2018-08-22 18:56:34 --> Hooks Class Initialized
DEBUG - 2018-08-22 18:56:34 --> UTF-8 Support Enabled
INFO - 2018-08-22 18:56:34 --> Utf8 Class Initialized
INFO - 2018-08-22 18:56:34 --> URI Class Initialized
INFO - 2018-08-22 18:56:34 --> Router Class Initialized
INFO - 2018-08-22 18:56:34 --> Output Class Initialized
INFO - 2018-08-22 18:56:34 --> Security Class Initialized
DEBUG - 2018-08-22 18:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 18:56:34 --> CSRF cookie sent
INFO - 2018-08-22 18:56:34 --> CSRF token verified
INFO - 2018-08-22 18:56:34 --> Input Class Initialized
INFO - 2018-08-22 18:56:34 --> Language Class Initialized
INFO - 2018-08-22 18:56:34 --> Loader Class Initialized
INFO - 2018-08-22 18:56:34 --> Helper loaded: url_helper
INFO - 2018-08-22 18:56:34 --> Helper loaded: form_helper
INFO - 2018-08-22 18:56:34 --> Helper loaded: language_helper
DEBUG - 2018-08-22 18:56:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 18:56:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 18:56:34 --> User Agent Class Initialized
INFO - 2018-08-22 18:56:34 --> Controller Class Initialized
INFO - 2018-08-22 18:56:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 18:56:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 18:56:34 --> Pixel_Model class loaded
INFO - 2018-08-22 18:56:34 --> Database Driver Class Initialized
INFO - 2018-08-22 18:56:34 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:56:34 --> Form Validation Class Initialized
INFO - 2018-08-22 18:56:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 18:56:34 --> Database Driver Class Initialized
INFO - 2018-08-22 18:56:34 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:56:34 --> Config Class Initialized
INFO - 2018-08-22 18:56:34 --> Hooks Class Initialized
DEBUG - 2018-08-22 18:56:34 --> UTF-8 Support Enabled
INFO - 2018-08-22 18:56:34 --> Utf8 Class Initialized
INFO - 2018-08-22 18:56:34 --> URI Class Initialized
INFO - 2018-08-22 18:56:34 --> Router Class Initialized
INFO - 2018-08-22 18:56:34 --> Output Class Initialized
INFO - 2018-08-22 18:56:34 --> Security Class Initialized
DEBUG - 2018-08-22 18:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 18:56:34 --> CSRF cookie sent
INFO - 2018-08-22 18:56:34 --> Input Class Initialized
INFO - 2018-08-22 18:56:34 --> Language Class Initialized
INFO - 2018-08-22 18:56:34 --> Loader Class Initialized
INFO - 2018-08-22 18:56:34 --> Helper loaded: url_helper
INFO - 2018-08-22 18:56:34 --> Helper loaded: form_helper
INFO - 2018-08-22 18:56:34 --> Helper loaded: language_helper
DEBUG - 2018-08-22 18:56:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 18:56:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 18:56:34 --> User Agent Class Initialized
INFO - 2018-08-22 18:56:34 --> Controller Class Initialized
INFO - 2018-08-22 18:56:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 18:56:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 18:56:34 --> Pixel_Model class loaded
INFO - 2018-08-22 18:56:34 --> Database Driver Class Initialized
INFO - 2018-08-22 18:56:34 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:56:34 --> Database Driver Class Initialized
INFO - 2018-08-22 18:56:34 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:56:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 18:56:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 18:56:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 18:56:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 18:56:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 18:56:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 18:56:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-08-22 18:56:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 18:56:34 --> Final output sent to browser
DEBUG - 2018-08-22 18:56:34 --> Total execution time: 0.0541
INFO - 2018-08-22 18:56:49 --> Config Class Initialized
INFO - 2018-08-22 18:56:49 --> Hooks Class Initialized
DEBUG - 2018-08-22 18:56:49 --> UTF-8 Support Enabled
INFO - 2018-08-22 18:56:49 --> Utf8 Class Initialized
INFO - 2018-08-22 18:56:49 --> URI Class Initialized
INFO - 2018-08-22 18:56:49 --> Router Class Initialized
INFO - 2018-08-22 18:56:49 --> Output Class Initialized
INFO - 2018-08-22 18:56:49 --> Security Class Initialized
DEBUG - 2018-08-22 18:56:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 18:56:49 --> CSRF cookie sent
INFO - 2018-08-22 18:56:49 --> CSRF token verified
INFO - 2018-08-22 18:56:49 --> Input Class Initialized
INFO - 2018-08-22 18:56:49 --> Language Class Initialized
INFO - 2018-08-22 18:56:49 --> Loader Class Initialized
INFO - 2018-08-22 18:56:49 --> Helper loaded: url_helper
INFO - 2018-08-22 18:56:49 --> Helper loaded: form_helper
INFO - 2018-08-22 18:56:49 --> Helper loaded: language_helper
DEBUG - 2018-08-22 18:56:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 18:56:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 18:56:49 --> User Agent Class Initialized
INFO - 2018-08-22 18:56:49 --> Controller Class Initialized
INFO - 2018-08-22 18:56:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 18:56:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 18:56:49 --> Pixel_Model class loaded
INFO - 2018-08-22 18:56:49 --> Database Driver Class Initialized
INFO - 2018-08-22 18:56:49 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:56:49 --> Form Validation Class Initialized
INFO - 2018-08-22 18:56:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 18:56:49 --> Database Driver Class Initialized
INFO - 2018-08-22 18:56:49 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:56:49 --> Config Class Initialized
INFO - 2018-08-22 18:56:49 --> Hooks Class Initialized
DEBUG - 2018-08-22 18:56:49 --> UTF-8 Support Enabled
INFO - 2018-08-22 18:56:49 --> Utf8 Class Initialized
INFO - 2018-08-22 18:56:49 --> URI Class Initialized
INFO - 2018-08-22 18:56:49 --> Router Class Initialized
INFO - 2018-08-22 18:56:49 --> Output Class Initialized
INFO - 2018-08-22 18:56:49 --> Security Class Initialized
DEBUG - 2018-08-22 18:56:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 18:56:49 --> CSRF cookie sent
INFO - 2018-08-22 18:56:49 --> Input Class Initialized
INFO - 2018-08-22 18:56:49 --> Language Class Initialized
INFO - 2018-08-22 18:56:49 --> Loader Class Initialized
INFO - 2018-08-22 18:56:49 --> Helper loaded: url_helper
INFO - 2018-08-22 18:56:49 --> Helper loaded: form_helper
INFO - 2018-08-22 18:56:49 --> Helper loaded: language_helper
DEBUG - 2018-08-22 18:56:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 18:56:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 18:56:49 --> User Agent Class Initialized
INFO - 2018-08-22 18:56:49 --> Controller Class Initialized
INFO - 2018-08-22 18:56:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 18:56:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 18:56:49 --> Pixel_Model class loaded
INFO - 2018-08-22 18:56:49 --> Database Driver Class Initialized
INFO - 2018-08-22 18:56:49 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:56:49 --> Database Driver Class Initialized
INFO - 2018-08-22 18:56:49 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:56:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 18:56:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 18:56:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 18:56:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 18:56:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 18:56:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 18:56:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-08-22 18:56:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 18:56:49 --> Final output sent to browser
DEBUG - 2018-08-22 18:56:49 --> Total execution time: 0.0639
INFO - 2018-08-22 18:56:51 --> Config Class Initialized
INFO - 2018-08-22 18:56:51 --> Hooks Class Initialized
DEBUG - 2018-08-22 18:56:51 --> UTF-8 Support Enabled
INFO - 2018-08-22 18:56:51 --> Utf8 Class Initialized
INFO - 2018-08-22 18:56:51 --> URI Class Initialized
INFO - 2018-08-22 18:56:51 --> Router Class Initialized
INFO - 2018-08-22 18:56:51 --> Output Class Initialized
INFO - 2018-08-22 18:56:51 --> Security Class Initialized
DEBUG - 2018-08-22 18:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 18:56:51 --> CSRF cookie sent
INFO - 2018-08-22 18:56:51 --> CSRF token verified
INFO - 2018-08-22 18:56:51 --> Input Class Initialized
INFO - 2018-08-22 18:56:51 --> Language Class Initialized
INFO - 2018-08-22 18:56:51 --> Loader Class Initialized
INFO - 2018-08-22 18:56:51 --> Helper loaded: url_helper
INFO - 2018-08-22 18:56:51 --> Helper loaded: form_helper
INFO - 2018-08-22 18:56:51 --> Helper loaded: language_helper
DEBUG - 2018-08-22 18:56:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 18:56:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 18:56:51 --> User Agent Class Initialized
INFO - 2018-08-22 18:56:51 --> Controller Class Initialized
INFO - 2018-08-22 18:56:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 18:56:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 18:56:51 --> Pixel_Model class loaded
INFO - 2018-08-22 18:56:51 --> Database Driver Class Initialized
INFO - 2018-08-22 18:56:51 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:56:51 --> Form Validation Class Initialized
INFO - 2018-08-22 18:56:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 18:56:51 --> Database Driver Class Initialized
INFO - 2018-08-22 18:56:51 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:56:52 --> Config Class Initialized
INFO - 2018-08-22 18:56:52 --> Hooks Class Initialized
DEBUG - 2018-08-22 18:56:52 --> UTF-8 Support Enabled
INFO - 2018-08-22 18:56:52 --> Utf8 Class Initialized
INFO - 2018-08-22 18:56:52 --> URI Class Initialized
INFO - 2018-08-22 18:56:52 --> Router Class Initialized
INFO - 2018-08-22 18:56:52 --> Output Class Initialized
INFO - 2018-08-22 18:56:52 --> Security Class Initialized
DEBUG - 2018-08-22 18:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 18:56:52 --> CSRF cookie sent
INFO - 2018-08-22 18:56:52 --> Input Class Initialized
INFO - 2018-08-22 18:56:52 --> Language Class Initialized
INFO - 2018-08-22 18:56:52 --> Loader Class Initialized
INFO - 2018-08-22 18:56:52 --> Helper loaded: url_helper
INFO - 2018-08-22 18:56:52 --> Helper loaded: form_helper
INFO - 2018-08-22 18:56:52 --> Helper loaded: language_helper
DEBUG - 2018-08-22 18:56:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 18:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 18:56:52 --> User Agent Class Initialized
INFO - 2018-08-22 18:56:52 --> Controller Class Initialized
INFO - 2018-08-22 18:56:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 18:56:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 18:56:52 --> Pixel_Model class loaded
INFO - 2018-08-22 18:56:52 --> Database Driver Class Initialized
INFO - 2018-08-22 18:56:52 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:56:52 --> Database Driver Class Initialized
INFO - 2018-08-22 18:56:52 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:56:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 18:56:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 18:56:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 18:56:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 18:56:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 18:56:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 18:56:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_title.php
INFO - 2018-08-22 18:56:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 18:56:52 --> Final output sent to browser
DEBUG - 2018-08-22 18:56:52 --> Total execution time: 0.0513
INFO - 2018-08-22 18:56:54 --> Config Class Initialized
INFO - 2018-08-22 18:56:54 --> Hooks Class Initialized
DEBUG - 2018-08-22 18:56:54 --> UTF-8 Support Enabled
INFO - 2018-08-22 18:56:54 --> Utf8 Class Initialized
INFO - 2018-08-22 18:56:54 --> URI Class Initialized
INFO - 2018-08-22 18:56:54 --> Router Class Initialized
INFO - 2018-08-22 18:56:54 --> Output Class Initialized
INFO - 2018-08-22 18:56:54 --> Security Class Initialized
DEBUG - 2018-08-22 18:56:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 18:56:54 --> CSRF cookie sent
INFO - 2018-08-22 18:56:54 --> Input Class Initialized
INFO - 2018-08-22 18:56:54 --> Language Class Initialized
INFO - 2018-08-22 18:56:54 --> Loader Class Initialized
INFO - 2018-08-22 18:56:54 --> Helper loaded: url_helper
INFO - 2018-08-22 18:56:54 --> Helper loaded: form_helper
INFO - 2018-08-22 18:56:54 --> Helper loaded: language_helper
DEBUG - 2018-08-22 18:56:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 18:56:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 18:56:54 --> User Agent Class Initialized
INFO - 2018-08-22 18:56:54 --> Controller Class Initialized
INFO - 2018-08-22 18:56:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 18:56:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 18:56:54 --> Pixel_Model class loaded
INFO - 2018-08-22 18:56:54 --> Database Driver Class Initialized
INFO - 2018-08-22 18:56:54 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:56:54 --> Database Driver Class Initialized
INFO - 2018-08-22 18:56:54 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:56:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 18:56:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 18:56:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 18:56:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 18:56:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 18:56:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 18:56:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-08-22 18:56:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 18:56:54 --> Final output sent to browser
DEBUG - 2018-08-22 18:56:54 --> Total execution time: 0.0474
INFO - 2018-08-22 18:57:04 --> Config Class Initialized
INFO - 2018-08-22 18:57:04 --> Hooks Class Initialized
DEBUG - 2018-08-22 18:57:04 --> UTF-8 Support Enabled
INFO - 2018-08-22 18:57:04 --> Utf8 Class Initialized
INFO - 2018-08-22 18:57:04 --> URI Class Initialized
INFO - 2018-08-22 18:57:04 --> Router Class Initialized
INFO - 2018-08-22 18:57:04 --> Output Class Initialized
INFO - 2018-08-22 18:57:04 --> Security Class Initialized
DEBUG - 2018-08-22 18:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 18:57:04 --> CSRF cookie sent
INFO - 2018-08-22 18:57:04 --> Input Class Initialized
INFO - 2018-08-22 18:57:04 --> Language Class Initialized
INFO - 2018-08-22 18:57:04 --> Loader Class Initialized
INFO - 2018-08-22 18:57:04 --> Helper loaded: url_helper
INFO - 2018-08-22 18:57:04 --> Helper loaded: form_helper
INFO - 2018-08-22 18:57:04 --> Helper loaded: language_helper
DEBUG - 2018-08-22 18:57:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 18:57:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 18:57:04 --> User Agent Class Initialized
INFO - 2018-08-22 18:57:04 --> Controller Class Initialized
INFO - 2018-08-22 18:57:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 18:57:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 18:57:04 --> Pixel_Model class loaded
INFO - 2018-08-22 18:57:04 --> Database Driver Class Initialized
INFO - 2018-08-22 18:57:04 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:57:04 --> Database Driver Class Initialized
INFO - 2018-08-22 18:57:04 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:57:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 18:57:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 18:57:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 18:57:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 18:57:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 18:57:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 18:57:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-08-22 18:57:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 18:57:04 --> Final output sent to browser
DEBUG - 2018-08-22 18:57:04 --> Total execution time: 0.0437
INFO - 2018-08-22 18:57:11 --> Config Class Initialized
INFO - 2018-08-22 18:57:11 --> Hooks Class Initialized
DEBUG - 2018-08-22 18:57:11 --> UTF-8 Support Enabled
INFO - 2018-08-22 18:57:11 --> Utf8 Class Initialized
INFO - 2018-08-22 18:57:11 --> URI Class Initialized
INFO - 2018-08-22 18:57:11 --> Router Class Initialized
INFO - 2018-08-22 18:57:11 --> Output Class Initialized
INFO - 2018-08-22 18:57:11 --> Security Class Initialized
DEBUG - 2018-08-22 18:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 18:57:11 --> CSRF cookie sent
INFO - 2018-08-22 18:57:11 --> Input Class Initialized
INFO - 2018-08-22 18:57:11 --> Language Class Initialized
INFO - 2018-08-22 18:57:11 --> Loader Class Initialized
INFO - 2018-08-22 18:57:11 --> Helper loaded: url_helper
INFO - 2018-08-22 18:57:11 --> Helper loaded: form_helper
INFO - 2018-08-22 18:57:11 --> Helper loaded: language_helper
DEBUG - 2018-08-22 18:57:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 18:57:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 18:57:11 --> User Agent Class Initialized
INFO - 2018-08-22 18:57:11 --> Controller Class Initialized
INFO - 2018-08-22 18:57:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 18:57:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 18:57:11 --> Pixel_Model class loaded
INFO - 2018-08-22 18:57:11 --> Database Driver Class Initialized
INFO - 2018-08-22 18:57:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:57:11 --> Database Driver Class Initialized
INFO - 2018-08-22 18:57:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:57:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 18:57:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 18:57:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 18:57:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 18:57:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 18:57:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 18:57:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-08-22 18:57:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 18:57:11 --> Final output sent to browser
DEBUG - 2018-08-22 18:57:11 --> Total execution time: 0.0462
INFO - 2018-08-22 18:57:13 --> Config Class Initialized
INFO - 2018-08-22 18:57:13 --> Hooks Class Initialized
DEBUG - 2018-08-22 18:57:13 --> UTF-8 Support Enabled
INFO - 2018-08-22 18:57:13 --> Utf8 Class Initialized
INFO - 2018-08-22 18:57:13 --> URI Class Initialized
INFO - 2018-08-22 18:57:13 --> Router Class Initialized
INFO - 2018-08-22 18:57:13 --> Output Class Initialized
INFO - 2018-08-22 18:57:13 --> Security Class Initialized
DEBUG - 2018-08-22 18:57:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 18:57:13 --> CSRF cookie sent
INFO - 2018-08-22 18:57:13 --> Input Class Initialized
INFO - 2018-08-22 18:57:13 --> Language Class Initialized
INFO - 2018-08-22 18:57:13 --> Loader Class Initialized
INFO - 2018-08-22 18:57:13 --> Helper loaded: url_helper
INFO - 2018-08-22 18:57:13 --> Helper loaded: form_helper
INFO - 2018-08-22 18:57:13 --> Helper loaded: language_helper
DEBUG - 2018-08-22 18:57:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 18:57:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 18:57:13 --> User Agent Class Initialized
INFO - 2018-08-22 18:57:13 --> Controller Class Initialized
INFO - 2018-08-22 18:57:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 18:57:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 18:57:13 --> Pixel_Model class loaded
INFO - 2018-08-22 18:57:13 --> Database Driver Class Initialized
INFO - 2018-08-22 18:57:13 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:57:13 --> Database Driver Class Initialized
INFO - 2018-08-22 18:57:13 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:57:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 18:57:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 18:57:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 18:57:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 18:57:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 18:57:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 18:57:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_title.php
INFO - 2018-08-22 18:57:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 18:57:13 --> Final output sent to browser
DEBUG - 2018-08-22 18:57:13 --> Total execution time: 0.0501
INFO - 2018-08-22 18:57:18 --> Config Class Initialized
INFO - 2018-08-22 18:57:18 --> Hooks Class Initialized
DEBUG - 2018-08-22 18:57:18 --> UTF-8 Support Enabled
INFO - 2018-08-22 18:57:18 --> Utf8 Class Initialized
INFO - 2018-08-22 18:57:18 --> URI Class Initialized
INFO - 2018-08-22 18:57:18 --> Router Class Initialized
INFO - 2018-08-22 18:57:18 --> Output Class Initialized
INFO - 2018-08-22 18:57:18 --> Security Class Initialized
DEBUG - 2018-08-22 18:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 18:57:18 --> CSRF cookie sent
INFO - 2018-08-22 18:57:18 --> CSRF token verified
INFO - 2018-08-22 18:57:18 --> Input Class Initialized
INFO - 2018-08-22 18:57:18 --> Language Class Initialized
INFO - 2018-08-22 18:57:18 --> Loader Class Initialized
INFO - 2018-08-22 18:57:18 --> Helper loaded: url_helper
INFO - 2018-08-22 18:57:18 --> Helper loaded: form_helper
INFO - 2018-08-22 18:57:18 --> Helper loaded: language_helper
DEBUG - 2018-08-22 18:57:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 18:57:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 18:57:18 --> User Agent Class Initialized
INFO - 2018-08-22 18:57:18 --> Controller Class Initialized
INFO - 2018-08-22 18:57:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 18:57:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 18:57:18 --> Pixel_Model class loaded
INFO - 2018-08-22 18:57:18 --> Database Driver Class Initialized
INFO - 2018-08-22 18:57:18 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:57:18 --> Form Validation Class Initialized
INFO - 2018-08-22 18:57:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 18:57:18 --> Database Driver Class Initialized
INFO - 2018-08-22 18:57:18 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:57:18 --> Config Class Initialized
INFO - 2018-08-22 18:57:18 --> Hooks Class Initialized
DEBUG - 2018-08-22 18:57:18 --> UTF-8 Support Enabled
INFO - 2018-08-22 18:57:18 --> Utf8 Class Initialized
INFO - 2018-08-22 18:57:18 --> URI Class Initialized
INFO - 2018-08-22 18:57:18 --> Router Class Initialized
INFO - 2018-08-22 18:57:18 --> Output Class Initialized
INFO - 2018-08-22 18:57:18 --> Security Class Initialized
DEBUG - 2018-08-22 18:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 18:57:18 --> CSRF cookie sent
INFO - 2018-08-22 18:57:18 --> Input Class Initialized
INFO - 2018-08-22 18:57:18 --> Language Class Initialized
INFO - 2018-08-22 18:57:18 --> Loader Class Initialized
INFO - 2018-08-22 18:57:18 --> Helper loaded: url_helper
INFO - 2018-08-22 18:57:18 --> Helper loaded: form_helper
INFO - 2018-08-22 18:57:18 --> Helper loaded: language_helper
DEBUG - 2018-08-22 18:57:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 18:57:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 18:57:18 --> User Agent Class Initialized
INFO - 2018-08-22 18:57:18 --> Controller Class Initialized
INFO - 2018-08-22 18:57:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 18:57:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 18:57:18 --> Pixel_Model class loaded
INFO - 2018-08-22 18:57:18 --> Database Driver Class Initialized
INFO - 2018-08-22 18:57:18 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:57:18 --> Database Driver Class Initialized
INFO - 2018-08-22 18:57:18 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:57:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 18:57:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 18:57:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 18:57:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 18:57:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 18:57:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 18:57:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-08-22 18:57:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 18:57:18 --> Final output sent to browser
DEBUG - 2018-08-22 18:57:18 --> Total execution time: 0.0434
INFO - 2018-08-22 18:57:20 --> Config Class Initialized
INFO - 2018-08-22 18:57:20 --> Hooks Class Initialized
DEBUG - 2018-08-22 18:57:20 --> UTF-8 Support Enabled
INFO - 2018-08-22 18:57:20 --> Utf8 Class Initialized
INFO - 2018-08-22 18:57:20 --> URI Class Initialized
INFO - 2018-08-22 18:57:20 --> Router Class Initialized
INFO - 2018-08-22 18:57:20 --> Output Class Initialized
INFO - 2018-08-22 18:57:20 --> Security Class Initialized
DEBUG - 2018-08-22 18:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 18:57:20 --> CSRF cookie sent
INFO - 2018-08-22 18:57:20 --> CSRF token verified
INFO - 2018-08-22 18:57:20 --> Input Class Initialized
INFO - 2018-08-22 18:57:20 --> Language Class Initialized
INFO - 2018-08-22 18:57:20 --> Loader Class Initialized
INFO - 2018-08-22 18:57:20 --> Helper loaded: url_helper
INFO - 2018-08-22 18:57:20 --> Helper loaded: form_helper
INFO - 2018-08-22 18:57:20 --> Helper loaded: language_helper
DEBUG - 2018-08-22 18:57:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 18:57:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 18:57:20 --> User Agent Class Initialized
INFO - 2018-08-22 18:57:20 --> Controller Class Initialized
INFO - 2018-08-22 18:57:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 18:57:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 18:57:20 --> Pixel_Model class loaded
INFO - 2018-08-22 18:57:20 --> Database Driver Class Initialized
INFO - 2018-08-22 18:57:20 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:57:20 --> Form Validation Class Initialized
INFO - 2018-08-22 18:57:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 18:57:20 --> Database Driver Class Initialized
INFO - 2018-08-22 18:57:20 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:57:20 --> Config Class Initialized
INFO - 2018-08-22 18:57:20 --> Hooks Class Initialized
DEBUG - 2018-08-22 18:57:20 --> UTF-8 Support Enabled
INFO - 2018-08-22 18:57:20 --> Utf8 Class Initialized
INFO - 2018-08-22 18:57:20 --> URI Class Initialized
INFO - 2018-08-22 18:57:20 --> Router Class Initialized
INFO - 2018-08-22 18:57:20 --> Output Class Initialized
INFO - 2018-08-22 18:57:20 --> Security Class Initialized
DEBUG - 2018-08-22 18:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 18:57:20 --> CSRF cookie sent
INFO - 2018-08-22 18:57:20 --> Input Class Initialized
INFO - 2018-08-22 18:57:20 --> Language Class Initialized
INFO - 2018-08-22 18:57:20 --> Loader Class Initialized
INFO - 2018-08-22 18:57:20 --> Helper loaded: url_helper
INFO - 2018-08-22 18:57:20 --> Helper loaded: form_helper
INFO - 2018-08-22 18:57:20 --> Helper loaded: language_helper
DEBUG - 2018-08-22 18:57:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 18:57:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 18:57:20 --> User Agent Class Initialized
INFO - 2018-08-22 18:57:20 --> Controller Class Initialized
INFO - 2018-08-22 18:57:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 18:57:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 18:57:20 --> Pixel_Model class loaded
INFO - 2018-08-22 18:57:20 --> Database Driver Class Initialized
INFO - 2018-08-22 18:57:20 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:57:20 --> Config Class Initialized
INFO - 2018-08-22 18:57:20 --> Hooks Class Initialized
DEBUG - 2018-08-22 18:57:20 --> UTF-8 Support Enabled
INFO - 2018-08-22 18:57:20 --> Utf8 Class Initialized
INFO - 2018-08-22 18:57:20 --> URI Class Initialized
INFO - 2018-08-22 18:57:20 --> Router Class Initialized
INFO - 2018-08-22 18:57:20 --> Output Class Initialized
INFO - 2018-08-22 18:57:20 --> Security Class Initialized
DEBUG - 2018-08-22 18:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 18:57:20 --> CSRF cookie sent
INFO - 2018-08-22 18:57:20 --> Input Class Initialized
INFO - 2018-08-22 18:57:20 --> Language Class Initialized
INFO - 2018-08-22 18:57:20 --> Loader Class Initialized
INFO - 2018-08-22 18:57:20 --> Helper loaded: url_helper
INFO - 2018-08-22 18:57:20 --> Helper loaded: form_helper
INFO - 2018-08-22 18:57:20 --> Helper loaded: language_helper
DEBUG - 2018-08-22 18:57:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 18:57:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 18:57:20 --> User Agent Class Initialized
INFO - 2018-08-22 18:57:20 --> Controller Class Initialized
INFO - 2018-08-22 18:57:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 18:57:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 18:57:20 --> Pixel_Model class loaded
INFO - 2018-08-22 18:57:20 --> Database Driver Class Initialized
INFO - 2018-08-22 18:57:20 --> Model "RegistrationModel" initialized
DEBUG - 2018-08-22 18:57:20 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-08-22 18:57:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 18:57:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 18:57:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 18:57:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-08-22 18:57:20 --> Could not find the language line "req_email"
INFO - 2018-08-22 18:57:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup.php
INFO - 2018-08-22 18:57:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 18:57:20 --> Final output sent to browser
DEBUG - 2018-08-22 18:57:20 --> Total execution time: 0.0386
INFO - 2018-08-22 18:57:58 --> Config Class Initialized
INFO - 2018-08-22 18:57:58 --> Hooks Class Initialized
DEBUG - 2018-08-22 18:57:58 --> UTF-8 Support Enabled
INFO - 2018-08-22 18:57:58 --> Utf8 Class Initialized
INFO - 2018-08-22 18:57:58 --> URI Class Initialized
INFO - 2018-08-22 18:57:58 --> Router Class Initialized
INFO - 2018-08-22 18:57:58 --> Output Class Initialized
INFO - 2018-08-22 18:57:58 --> Security Class Initialized
DEBUG - 2018-08-22 18:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 18:57:58 --> CSRF cookie sent
INFO - 2018-08-22 18:57:58 --> CSRF token verified
INFO - 2018-08-22 18:57:58 --> Input Class Initialized
INFO - 2018-08-22 18:57:58 --> Language Class Initialized
INFO - 2018-08-22 18:57:58 --> Loader Class Initialized
INFO - 2018-08-22 18:57:58 --> Helper loaded: url_helper
INFO - 2018-08-22 18:57:58 --> Helper loaded: form_helper
INFO - 2018-08-22 18:57:58 --> Helper loaded: language_helper
DEBUG - 2018-08-22 18:57:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 18:57:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 18:57:58 --> User Agent Class Initialized
INFO - 2018-08-22 18:57:58 --> Controller Class Initialized
INFO - 2018-08-22 18:57:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 18:57:58 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-08-22 18:57:58 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-08-22 18:57:58 --> Form Validation Class Initialized
INFO - 2018-08-22 18:57:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 18:57:58 --> Pixel_Model class loaded
INFO - 2018-08-22 18:57:58 --> Database Driver Class Initialized
INFO - 2018-08-22 18:57:58 --> Model "RegistrationModel" initialized
INFO - 2018-08-22 18:57:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 18:57:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 18:57:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 18:57:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 18:57:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup_terms.php
INFO - 2018-08-22 18:57:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 18:57:58 --> Final output sent to browser
DEBUG - 2018-08-22 18:57:58 --> Total execution time: 0.1952
INFO - 2018-08-22 18:58:02 --> Config Class Initialized
INFO - 2018-08-22 18:58:02 --> Hooks Class Initialized
DEBUG - 2018-08-22 18:58:02 --> UTF-8 Support Enabled
INFO - 2018-08-22 18:58:02 --> Utf8 Class Initialized
INFO - 2018-08-22 18:58:02 --> URI Class Initialized
INFO - 2018-08-22 18:58:02 --> Router Class Initialized
INFO - 2018-08-22 18:58:02 --> Output Class Initialized
INFO - 2018-08-22 18:58:02 --> Security Class Initialized
DEBUG - 2018-08-22 18:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 18:58:02 --> CSRF cookie sent
INFO - 2018-08-22 18:58:02 --> CSRF token verified
INFO - 2018-08-22 18:58:02 --> Input Class Initialized
INFO - 2018-08-22 18:58:02 --> Language Class Initialized
INFO - 2018-08-22 18:58:02 --> Loader Class Initialized
INFO - 2018-08-22 18:58:02 --> Helper loaded: url_helper
INFO - 2018-08-22 18:58:02 --> Helper loaded: form_helper
INFO - 2018-08-22 18:58:02 --> Helper loaded: language_helper
DEBUG - 2018-08-22 18:58:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 18:58:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 18:58:02 --> User Agent Class Initialized
INFO - 2018-08-22 18:58:02 --> Controller Class Initialized
INFO - 2018-08-22 18:58:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 18:58:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 18:58:02 --> Pixel_Model class loaded
INFO - 2018-08-22 18:58:02 --> Database Driver Class Initialized
INFO - 2018-08-22 18:58:02 --> Model "RegistrationModel" initialized
INFO - 2018-08-22 18:58:02 --> Helper loaded: string_helper
INFO - 2018-08-22 18:58:02 --> Language file loaded: language/en/notifications_lang.php
INFO - 2018-08-22 18:58:02 --> Database Driver Class Initialized
INFO - 2018-08-22 18:58:02 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:58:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/emails/_buttons.php
INFO - 2018-08-22 18:58:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/emails/header.php
INFO - 2018-08-22 18:58:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/emails/footer.php
INFO - 2018-08-22 18:58:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/emails/generic.php
INFO - 2018-08-22 18:58:02 --> Email Class Initialized
INFO - 2018-08-22 18:58:02 --> Language file loaded: language/english/email_lang.php
INFO - 2018-08-22 18:58:02 --> Config Class Initialized
INFO - 2018-08-22 18:58:02 --> Hooks Class Initialized
DEBUG - 2018-08-22 18:58:02 --> UTF-8 Support Enabled
INFO - 2018-08-22 18:58:02 --> Utf8 Class Initialized
INFO - 2018-08-22 18:58:02 --> URI Class Initialized
INFO - 2018-08-22 18:58:02 --> Router Class Initialized
INFO - 2018-08-22 18:58:03 --> Output Class Initialized
INFO - 2018-08-22 18:58:03 --> Security Class Initialized
DEBUG - 2018-08-22 18:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 18:58:03 --> CSRF cookie sent
INFO - 2018-08-22 18:58:03 --> Input Class Initialized
INFO - 2018-08-22 18:58:03 --> Language Class Initialized
INFO - 2018-08-22 18:58:03 --> Loader Class Initialized
INFO - 2018-08-22 18:58:03 --> Helper loaded: url_helper
INFO - 2018-08-22 18:58:03 --> Helper loaded: form_helper
INFO - 2018-08-22 18:58:03 --> Helper loaded: language_helper
DEBUG - 2018-08-22 18:58:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 18:58:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 18:58:03 --> User Agent Class Initialized
INFO - 2018-08-22 18:58:03 --> Controller Class Initialized
INFO - 2018-08-22 18:58:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 18:58:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 18:58:03 --> Pixel_Model class loaded
INFO - 2018-08-22 18:58:03 --> Database Driver Class Initialized
INFO - 2018-08-22 18:58:03 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:58:03 --> Database Driver Class Initialized
INFO - 2018-08-22 18:58:03 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:58:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 18:58:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 18:58:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 18:58:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 18:58:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 18:58:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 18:58:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 18:58:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-08-22 18:58:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 18:58:03 --> Final output sent to browser
DEBUG - 2018-08-22 18:58:03 --> Total execution time: 0.0498
INFO - 2018-08-22 18:58:20 --> Config Class Initialized
INFO - 2018-08-22 18:58:20 --> Hooks Class Initialized
DEBUG - 2018-08-22 18:58:20 --> UTF-8 Support Enabled
INFO - 2018-08-22 18:58:20 --> Utf8 Class Initialized
INFO - 2018-08-22 18:58:20 --> URI Class Initialized
INFO - 2018-08-22 18:58:20 --> Router Class Initialized
INFO - 2018-08-22 18:58:20 --> Output Class Initialized
INFO - 2018-08-22 18:58:20 --> Security Class Initialized
DEBUG - 2018-08-22 18:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 18:58:20 --> CSRF cookie sent
INFO - 2018-08-22 18:58:20 --> CSRF token verified
INFO - 2018-08-22 18:58:20 --> Input Class Initialized
INFO - 2018-08-22 18:58:20 --> Language Class Initialized
INFO - 2018-08-22 18:58:20 --> Loader Class Initialized
INFO - 2018-08-22 18:58:20 --> Helper loaded: url_helper
INFO - 2018-08-22 18:58:20 --> Helper loaded: form_helper
INFO - 2018-08-22 18:58:20 --> Helper loaded: language_helper
DEBUG - 2018-08-22 18:58:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 18:58:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 18:58:20 --> User Agent Class Initialized
INFO - 2018-08-22 18:58:20 --> Controller Class Initialized
INFO - 2018-08-22 18:58:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 18:58:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 18:58:20 --> Pixel_Model class loaded
INFO - 2018-08-22 18:58:20 --> Database Driver Class Initialized
INFO - 2018-08-22 18:58:20 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:58:20 --> Form Validation Class Initialized
INFO - 2018-08-22 18:58:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 18:58:20 --> Database Driver Class Initialized
INFO - 2018-08-22 18:58:20 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:58:20 --> Config Class Initialized
INFO - 2018-08-22 18:58:20 --> Hooks Class Initialized
DEBUG - 2018-08-22 18:58:20 --> UTF-8 Support Enabled
INFO - 2018-08-22 18:58:20 --> Utf8 Class Initialized
INFO - 2018-08-22 18:58:20 --> URI Class Initialized
INFO - 2018-08-22 18:58:20 --> Router Class Initialized
INFO - 2018-08-22 18:58:20 --> Output Class Initialized
INFO - 2018-08-22 18:58:20 --> Security Class Initialized
DEBUG - 2018-08-22 18:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 18:58:20 --> CSRF cookie sent
INFO - 2018-08-22 18:58:20 --> Input Class Initialized
INFO - 2018-08-22 18:58:20 --> Language Class Initialized
INFO - 2018-08-22 18:58:20 --> Loader Class Initialized
INFO - 2018-08-22 18:58:20 --> Helper loaded: url_helper
INFO - 2018-08-22 18:58:20 --> Helper loaded: form_helper
INFO - 2018-08-22 18:58:20 --> Helper loaded: language_helper
DEBUG - 2018-08-22 18:58:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 18:58:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 18:58:20 --> User Agent Class Initialized
INFO - 2018-08-22 18:58:20 --> Controller Class Initialized
INFO - 2018-08-22 18:58:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 18:58:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 18:58:20 --> Pixel_Model class loaded
INFO - 2018-08-22 18:58:20 --> Database Driver Class Initialized
INFO - 2018-08-22 18:58:20 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:58:20 --> Database Driver Class Initialized
INFO - 2018-08-22 18:58:20 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:58:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 18:58:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 18:58:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 18:58:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 18:58:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 18:58:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 18:58:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 18:58:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/spouse_info.php
INFO - 2018-08-22 18:58:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 18:58:20 --> Final output sent to browser
DEBUG - 2018-08-22 18:58:20 --> Total execution time: 0.0599
INFO - 2018-08-22 18:58:30 --> Config Class Initialized
INFO - 2018-08-22 18:58:30 --> Hooks Class Initialized
DEBUG - 2018-08-22 18:58:30 --> UTF-8 Support Enabled
INFO - 2018-08-22 18:58:30 --> Utf8 Class Initialized
INFO - 2018-08-22 18:58:30 --> URI Class Initialized
INFO - 2018-08-22 18:58:30 --> Router Class Initialized
INFO - 2018-08-22 18:58:30 --> Output Class Initialized
INFO - 2018-08-22 18:58:30 --> Security Class Initialized
DEBUG - 2018-08-22 18:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 18:58:30 --> CSRF cookie sent
INFO - 2018-08-22 18:58:30 --> Input Class Initialized
INFO - 2018-08-22 18:58:30 --> Language Class Initialized
INFO - 2018-08-22 18:58:30 --> Loader Class Initialized
INFO - 2018-08-22 18:58:30 --> Helper loaded: url_helper
INFO - 2018-08-22 18:58:30 --> Helper loaded: form_helper
INFO - 2018-08-22 18:58:30 --> Helper loaded: language_helper
DEBUG - 2018-08-22 18:58:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 18:58:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 18:58:30 --> User Agent Class Initialized
INFO - 2018-08-22 18:58:30 --> Controller Class Initialized
INFO - 2018-08-22 18:58:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 18:58:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 18:58:30 --> Pixel_Model class loaded
INFO - 2018-08-22 18:58:30 --> Database Driver Class Initialized
INFO - 2018-08-22 18:58:30 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:58:30 --> Database Driver Class Initialized
INFO - 2018-08-22 18:58:30 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:58:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 18:58:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 18:58:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 18:58:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 18:58:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 18:58:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 18:58:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 18:58:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids_help_complaint.php
INFO - 2018-08-22 18:58:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 18:58:30 --> Final output sent to browser
DEBUG - 2018-08-22 18:58:30 --> Total execution time: 0.0600
INFO - 2018-08-22 18:58:34 --> Config Class Initialized
INFO - 2018-08-22 18:58:34 --> Hooks Class Initialized
DEBUG - 2018-08-22 18:58:34 --> UTF-8 Support Enabled
INFO - 2018-08-22 18:58:34 --> Utf8 Class Initialized
INFO - 2018-08-22 18:58:34 --> URI Class Initialized
INFO - 2018-08-22 18:58:34 --> Router Class Initialized
INFO - 2018-08-22 18:58:34 --> Output Class Initialized
INFO - 2018-08-22 18:58:34 --> Security Class Initialized
DEBUG - 2018-08-22 18:58:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 18:58:34 --> CSRF cookie sent
INFO - 2018-08-22 18:58:34 --> Input Class Initialized
INFO - 2018-08-22 18:58:34 --> Language Class Initialized
INFO - 2018-08-22 18:58:34 --> Loader Class Initialized
INFO - 2018-08-22 18:58:34 --> Helper loaded: url_helper
INFO - 2018-08-22 18:58:34 --> Helper loaded: form_helper
INFO - 2018-08-22 18:58:34 --> Helper loaded: language_helper
DEBUG - 2018-08-22 18:58:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 18:58:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 18:58:34 --> User Agent Class Initialized
INFO - 2018-08-22 18:58:34 --> Controller Class Initialized
INFO - 2018-08-22 18:58:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 18:58:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 18:58:34 --> Pixel_Model class loaded
INFO - 2018-08-22 18:58:34 --> Database Driver Class Initialized
INFO - 2018-08-22 18:58:34 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:58:34 --> Database Driver Class Initialized
INFO - 2018-08-22 18:58:34 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:58:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 18:58:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 18:58:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 18:58:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 18:58:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 18:58:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 18:58:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 18:58:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids_doctor.php
INFO - 2018-08-22 18:58:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 18:58:34 --> Final output sent to browser
DEBUG - 2018-08-22 18:58:34 --> Total execution time: 0.0479
INFO - 2018-08-22 18:58:36 --> Config Class Initialized
INFO - 2018-08-22 18:58:36 --> Hooks Class Initialized
DEBUG - 2018-08-22 18:58:36 --> UTF-8 Support Enabled
INFO - 2018-08-22 18:58:36 --> Utf8 Class Initialized
INFO - 2018-08-22 18:58:36 --> URI Class Initialized
INFO - 2018-08-22 18:58:36 --> Router Class Initialized
INFO - 2018-08-22 18:58:36 --> Output Class Initialized
INFO - 2018-08-22 18:58:36 --> Security Class Initialized
DEBUG - 2018-08-22 18:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 18:58:36 --> CSRF cookie sent
INFO - 2018-08-22 18:58:36 --> Input Class Initialized
INFO - 2018-08-22 18:58:36 --> Language Class Initialized
INFO - 2018-08-22 18:58:36 --> Loader Class Initialized
INFO - 2018-08-22 18:58:36 --> Helper loaded: url_helper
INFO - 2018-08-22 18:58:36 --> Helper loaded: form_helper
INFO - 2018-08-22 18:58:36 --> Helper loaded: language_helper
DEBUG - 2018-08-22 18:58:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 18:58:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 18:58:36 --> User Agent Class Initialized
INFO - 2018-08-22 18:58:36 --> Controller Class Initialized
INFO - 2018-08-22 18:58:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 18:58:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 18:58:36 --> Pixel_Model class loaded
INFO - 2018-08-22 18:58:36 --> Database Driver Class Initialized
INFO - 2018-08-22 18:58:36 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:58:36 --> Database Driver Class Initialized
INFO - 2018-08-22 18:58:36 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:58:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 18:58:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 18:58:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 18:58:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 18:58:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 18:58:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 18:58:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 18:58:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids_homework.php
INFO - 2018-08-22 18:58:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 18:58:36 --> Final output sent to browser
DEBUG - 2018-08-22 18:58:36 --> Total execution time: 0.0467
INFO - 2018-08-22 18:58:36 --> Config Class Initialized
INFO - 2018-08-22 18:58:36 --> Hooks Class Initialized
DEBUG - 2018-08-22 18:58:36 --> UTF-8 Support Enabled
INFO - 2018-08-22 18:58:36 --> Utf8 Class Initialized
INFO - 2018-08-22 18:58:36 --> URI Class Initialized
INFO - 2018-08-22 18:58:36 --> Router Class Initialized
INFO - 2018-08-22 18:58:36 --> Output Class Initialized
INFO - 2018-08-22 18:58:36 --> Security Class Initialized
DEBUG - 2018-08-22 18:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 18:58:36 --> CSRF cookie sent
INFO - 2018-08-22 18:58:36 --> Input Class Initialized
INFO - 2018-08-22 18:58:36 --> Language Class Initialized
INFO - 2018-08-22 18:58:36 --> Loader Class Initialized
INFO - 2018-08-22 18:58:36 --> Helper loaded: url_helper
INFO - 2018-08-22 18:58:36 --> Helper loaded: form_helper
INFO - 2018-08-22 18:58:36 --> Helper loaded: language_helper
DEBUG - 2018-08-22 18:58:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 18:58:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 18:58:36 --> User Agent Class Initialized
INFO - 2018-08-22 18:58:36 --> Controller Class Initialized
INFO - 2018-08-22 18:58:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 18:58:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 18:58:36 --> Pixel_Model class loaded
INFO - 2018-08-22 18:58:36 --> Database Driver Class Initialized
INFO - 2018-08-22 18:58:37 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:58:37 --> Database Driver Class Initialized
INFO - 2018-08-22 18:58:37 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:58:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 18:58:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 18:58:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 18:58:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 18:58:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 18:58:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 18:58:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 18:58:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids_dinner.php
INFO - 2018-08-22 18:58:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 18:58:37 --> Final output sent to browser
DEBUG - 2018-08-22 18:58:37 --> Total execution time: 0.0555
INFO - 2018-08-22 18:58:37 --> Config Class Initialized
INFO - 2018-08-22 18:58:37 --> Hooks Class Initialized
DEBUG - 2018-08-22 18:58:37 --> UTF-8 Support Enabled
INFO - 2018-08-22 18:58:37 --> Utf8 Class Initialized
INFO - 2018-08-22 18:58:37 --> URI Class Initialized
INFO - 2018-08-22 18:58:37 --> Router Class Initialized
INFO - 2018-08-22 18:58:37 --> Output Class Initialized
INFO - 2018-08-22 18:58:37 --> Security Class Initialized
DEBUG - 2018-08-22 18:58:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 18:58:37 --> CSRF cookie sent
INFO - 2018-08-22 18:58:37 --> Input Class Initialized
INFO - 2018-08-22 18:58:37 --> Language Class Initialized
INFO - 2018-08-22 18:58:37 --> Loader Class Initialized
INFO - 2018-08-22 18:58:37 --> Helper loaded: url_helper
INFO - 2018-08-22 18:58:37 --> Helper loaded: form_helper
INFO - 2018-08-22 18:58:37 --> Helper loaded: language_helper
DEBUG - 2018-08-22 18:58:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 18:58:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 18:58:37 --> User Agent Class Initialized
INFO - 2018-08-22 18:58:37 --> Controller Class Initialized
INFO - 2018-08-22 18:58:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 18:58:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 18:58:37 --> Pixel_Model class loaded
INFO - 2018-08-22 18:58:37 --> Database Driver Class Initialized
INFO - 2018-08-22 18:58:37 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:58:37 --> Database Driver Class Initialized
INFO - 2018-08-22 18:58:37 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:58:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 18:58:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 18:58:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 18:58:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 18:58:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 18:58:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 18:58:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 18:58:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids_communicate.php
INFO - 2018-08-22 18:58:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 18:58:37 --> Final output sent to browser
DEBUG - 2018-08-22 18:58:37 --> Total execution time: 0.0444
INFO - 2018-08-22 18:58:38 --> Config Class Initialized
INFO - 2018-08-22 18:58:38 --> Hooks Class Initialized
DEBUG - 2018-08-22 18:58:38 --> UTF-8 Support Enabled
INFO - 2018-08-22 18:58:38 --> Utf8 Class Initialized
INFO - 2018-08-22 18:58:38 --> URI Class Initialized
INFO - 2018-08-22 18:58:38 --> Router Class Initialized
INFO - 2018-08-22 18:58:38 --> Output Class Initialized
INFO - 2018-08-22 18:58:38 --> Security Class Initialized
DEBUG - 2018-08-22 18:58:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 18:58:38 --> CSRF cookie sent
INFO - 2018-08-22 18:58:38 --> Input Class Initialized
INFO - 2018-08-22 18:58:38 --> Language Class Initialized
INFO - 2018-08-22 18:58:38 --> Loader Class Initialized
INFO - 2018-08-22 18:58:38 --> Helper loaded: url_helper
INFO - 2018-08-22 18:58:38 --> Helper loaded: form_helper
INFO - 2018-08-22 18:58:38 --> Helper loaded: language_helper
DEBUG - 2018-08-22 18:58:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 18:58:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 18:58:38 --> User Agent Class Initialized
INFO - 2018-08-22 18:58:38 --> Controller Class Initialized
INFO - 2018-08-22 18:58:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 18:58:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 18:58:38 --> Pixel_Model class loaded
INFO - 2018-08-22 18:58:38 --> Database Driver Class Initialized
INFO - 2018-08-22 18:58:38 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:58:38 --> Database Driver Class Initialized
INFO - 2018-08-22 18:58:38 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:58:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 18:58:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 18:58:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 18:58:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 18:58:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 18:58:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 18:58:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 18:58:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids_activities.php
INFO - 2018-08-22 18:58:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 18:58:38 --> Final output sent to browser
DEBUG - 2018-08-22 18:58:38 --> Total execution time: 0.0436
INFO - 2018-08-22 18:58:42 --> Config Class Initialized
INFO - 2018-08-22 18:58:42 --> Hooks Class Initialized
DEBUG - 2018-08-22 18:58:42 --> UTF-8 Support Enabled
INFO - 2018-08-22 18:58:42 --> Utf8 Class Initialized
INFO - 2018-08-22 18:58:42 --> URI Class Initialized
INFO - 2018-08-22 18:58:42 --> Router Class Initialized
INFO - 2018-08-22 18:58:42 --> Output Class Initialized
INFO - 2018-08-22 18:58:42 --> Security Class Initialized
DEBUG - 2018-08-22 18:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 18:58:42 --> CSRF cookie sent
INFO - 2018-08-22 18:58:42 --> Input Class Initialized
INFO - 2018-08-22 18:58:42 --> Language Class Initialized
INFO - 2018-08-22 18:58:42 --> Loader Class Initialized
INFO - 2018-08-22 18:58:42 --> Helper loaded: url_helper
INFO - 2018-08-22 18:58:42 --> Helper loaded: form_helper
INFO - 2018-08-22 18:58:42 --> Helper loaded: language_helper
DEBUG - 2018-08-22 18:58:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 18:58:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 18:58:42 --> User Agent Class Initialized
INFO - 2018-08-22 18:58:42 --> Controller Class Initialized
INFO - 2018-08-22 18:58:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 18:58:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 18:58:42 --> Pixel_Model class loaded
INFO - 2018-08-22 18:58:42 --> Database Driver Class Initialized
INFO - 2018-08-22 18:58:42 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:58:42 --> Database Driver Class Initialized
INFO - 2018-08-22 18:58:42 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:58:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 18:58:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 18:58:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 18:58:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 18:58:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 18:58:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 18:58:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 18:58:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/other_kids.php
INFO - 2018-08-22 18:58:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 18:58:42 --> Final output sent to browser
DEBUG - 2018-08-22 18:58:42 --> Total execution time: 0.0663
INFO - 2018-08-22 18:58:44 --> Config Class Initialized
INFO - 2018-08-22 18:58:44 --> Hooks Class Initialized
DEBUG - 2018-08-22 18:58:44 --> UTF-8 Support Enabled
INFO - 2018-08-22 18:58:44 --> Utf8 Class Initialized
INFO - 2018-08-22 18:58:44 --> URI Class Initialized
INFO - 2018-08-22 18:58:44 --> Router Class Initialized
INFO - 2018-08-22 18:58:44 --> Output Class Initialized
INFO - 2018-08-22 18:58:44 --> Security Class Initialized
DEBUG - 2018-08-22 18:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 18:58:44 --> CSRF cookie sent
INFO - 2018-08-22 18:58:44 --> Input Class Initialized
INFO - 2018-08-22 18:58:44 --> Language Class Initialized
INFO - 2018-08-22 18:58:44 --> Loader Class Initialized
INFO - 2018-08-22 18:58:44 --> Helper loaded: url_helper
INFO - 2018-08-22 18:58:44 --> Helper loaded: form_helper
INFO - 2018-08-22 18:58:44 --> Helper loaded: language_helper
DEBUG - 2018-08-22 18:58:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 18:58:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 18:58:44 --> User Agent Class Initialized
INFO - 2018-08-22 18:58:44 --> Controller Class Initialized
INFO - 2018-08-22 18:58:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 18:58:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 18:58:44 --> Pixel_Model class loaded
INFO - 2018-08-22 18:58:44 --> Database Driver Class Initialized
INFO - 2018-08-22 18:58:44 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:58:44 --> Database Driver Class Initialized
INFO - 2018-08-22 18:58:44 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:58:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 18:58:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 18:58:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 18:58:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 18:58:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 18:58:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 18:58:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 18:58:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids_info.php
INFO - 2018-08-22 18:58:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 18:58:44 --> Final output sent to browser
DEBUG - 2018-08-22 18:58:44 --> Total execution time: 0.0469
INFO - 2018-08-22 18:58:46 --> Config Class Initialized
INFO - 2018-08-22 18:58:46 --> Hooks Class Initialized
DEBUG - 2018-08-22 18:58:46 --> UTF-8 Support Enabled
INFO - 2018-08-22 18:58:46 --> Utf8 Class Initialized
INFO - 2018-08-22 18:58:46 --> URI Class Initialized
INFO - 2018-08-22 18:58:46 --> Router Class Initialized
INFO - 2018-08-22 18:58:46 --> Output Class Initialized
INFO - 2018-08-22 18:58:46 --> Security Class Initialized
DEBUG - 2018-08-22 18:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 18:58:46 --> CSRF cookie sent
INFO - 2018-08-22 18:58:46 --> Input Class Initialized
INFO - 2018-08-22 18:58:46 --> Language Class Initialized
INFO - 2018-08-22 18:58:46 --> Loader Class Initialized
INFO - 2018-08-22 18:58:46 --> Helper loaded: url_helper
INFO - 2018-08-22 18:58:46 --> Helper loaded: form_helper
INFO - 2018-08-22 18:58:46 --> Helper loaded: language_helper
DEBUG - 2018-08-22 18:58:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 18:58:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 18:58:46 --> User Agent Class Initialized
INFO - 2018-08-22 18:58:46 --> Controller Class Initialized
INFO - 2018-08-22 18:58:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 18:58:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 18:58:46 --> Pixel_Model class loaded
INFO - 2018-08-22 18:58:46 --> Database Driver Class Initialized
INFO - 2018-08-22 18:58:46 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:58:46 --> Database Driver Class Initialized
INFO - 2018-08-22 18:58:46 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:58:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 18:58:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 18:58:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 18:58:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 18:58:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 18:58:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 18:58:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 18:58:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-08-22 18:58:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 18:58:46 --> Final output sent to browser
DEBUG - 2018-08-22 18:58:46 --> Total execution time: 0.0373
INFO - 2018-08-22 18:59:21 --> Config Class Initialized
INFO - 2018-08-22 18:59:21 --> Hooks Class Initialized
DEBUG - 2018-08-22 18:59:21 --> UTF-8 Support Enabled
INFO - 2018-08-22 18:59:21 --> Utf8 Class Initialized
INFO - 2018-08-22 18:59:21 --> URI Class Initialized
INFO - 2018-08-22 18:59:21 --> Router Class Initialized
INFO - 2018-08-22 18:59:21 --> Output Class Initialized
INFO - 2018-08-22 18:59:21 --> Security Class Initialized
DEBUG - 2018-08-22 18:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 18:59:21 --> CSRF cookie sent
INFO - 2018-08-22 18:59:21 --> CSRF token verified
INFO - 2018-08-22 18:59:21 --> Input Class Initialized
INFO - 2018-08-22 18:59:21 --> Language Class Initialized
INFO - 2018-08-22 18:59:21 --> Loader Class Initialized
INFO - 2018-08-22 18:59:21 --> Helper loaded: url_helper
INFO - 2018-08-22 18:59:21 --> Helper loaded: form_helper
INFO - 2018-08-22 18:59:21 --> Helper loaded: language_helper
DEBUG - 2018-08-22 18:59:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 18:59:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 18:59:21 --> User Agent Class Initialized
INFO - 2018-08-22 18:59:21 --> Controller Class Initialized
INFO - 2018-08-22 18:59:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 18:59:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 18:59:21 --> Pixel_Model class loaded
INFO - 2018-08-22 18:59:21 --> Database Driver Class Initialized
INFO - 2018-08-22 18:59:21 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:59:21 --> Form Validation Class Initialized
INFO - 2018-08-22 18:59:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 18:59:21 --> Database Driver Class Initialized
INFO - 2018-08-22 18:59:21 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:59:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 18:59:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 18:59:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 18:59:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 18:59:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 18:59:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 18:59:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_errors.php
INFO - 2018-08-22 18:59:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 18:59:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-08-22 18:59:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 18:59:21 --> Final output sent to browser
DEBUG - 2018-08-22 18:59:21 --> Total execution time: 0.0578
INFO - 2018-08-22 18:59:34 --> Config Class Initialized
INFO - 2018-08-22 18:59:34 --> Hooks Class Initialized
DEBUG - 2018-08-22 18:59:34 --> UTF-8 Support Enabled
INFO - 2018-08-22 18:59:34 --> Utf8 Class Initialized
INFO - 2018-08-22 18:59:34 --> URI Class Initialized
INFO - 2018-08-22 18:59:34 --> Router Class Initialized
INFO - 2018-08-22 18:59:34 --> Output Class Initialized
INFO - 2018-08-22 18:59:34 --> Security Class Initialized
DEBUG - 2018-08-22 18:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 18:59:34 --> CSRF cookie sent
INFO - 2018-08-22 18:59:34 --> CSRF token verified
INFO - 2018-08-22 18:59:34 --> Input Class Initialized
INFO - 2018-08-22 18:59:34 --> Language Class Initialized
INFO - 2018-08-22 18:59:34 --> Loader Class Initialized
INFO - 2018-08-22 18:59:34 --> Helper loaded: url_helper
INFO - 2018-08-22 18:59:34 --> Helper loaded: form_helper
INFO - 2018-08-22 18:59:34 --> Helper loaded: language_helper
DEBUG - 2018-08-22 18:59:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 18:59:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 18:59:34 --> User Agent Class Initialized
INFO - 2018-08-22 18:59:34 --> Controller Class Initialized
INFO - 2018-08-22 18:59:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 18:59:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 18:59:34 --> Pixel_Model class loaded
INFO - 2018-08-22 18:59:34 --> Database Driver Class Initialized
INFO - 2018-08-22 18:59:34 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:59:34 --> Form Validation Class Initialized
INFO - 2018-08-22 18:59:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 18:59:34 --> Database Driver Class Initialized
INFO - 2018-08-22 18:59:34 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:59:34 --> Config Class Initialized
INFO - 2018-08-22 18:59:34 --> Hooks Class Initialized
DEBUG - 2018-08-22 18:59:34 --> UTF-8 Support Enabled
INFO - 2018-08-22 18:59:34 --> Utf8 Class Initialized
INFO - 2018-08-22 18:59:34 --> URI Class Initialized
INFO - 2018-08-22 18:59:34 --> Router Class Initialized
INFO - 2018-08-22 18:59:34 --> Output Class Initialized
INFO - 2018-08-22 18:59:34 --> Security Class Initialized
DEBUG - 2018-08-22 18:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 18:59:34 --> CSRF cookie sent
INFO - 2018-08-22 18:59:34 --> Input Class Initialized
INFO - 2018-08-22 18:59:34 --> Language Class Initialized
INFO - 2018-08-22 18:59:34 --> Loader Class Initialized
INFO - 2018-08-22 18:59:34 --> Helper loaded: url_helper
INFO - 2018-08-22 18:59:34 --> Helper loaded: form_helper
INFO - 2018-08-22 18:59:34 --> Helper loaded: language_helper
DEBUG - 2018-08-22 18:59:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 18:59:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 18:59:34 --> User Agent Class Initialized
INFO - 2018-08-22 18:59:34 --> Controller Class Initialized
INFO - 2018-08-22 18:59:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 18:59:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 18:59:34 --> Pixel_Model class loaded
INFO - 2018-08-22 18:59:34 --> Database Driver Class Initialized
INFO - 2018-08-22 18:59:34 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:59:34 --> Database Driver Class Initialized
INFO - 2018-08-22 18:59:34 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:59:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 18:59:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 18:59:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 18:59:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 18:59:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 18:59:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 18:59:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 18:59:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/spouse_info.php
INFO - 2018-08-22 18:59:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 18:59:35 --> Final output sent to browser
DEBUG - 2018-08-22 18:59:35 --> Total execution time: 0.0432
INFO - 2018-08-22 18:59:42 --> Config Class Initialized
INFO - 2018-08-22 18:59:42 --> Hooks Class Initialized
DEBUG - 2018-08-22 18:59:42 --> UTF-8 Support Enabled
INFO - 2018-08-22 18:59:42 --> Utf8 Class Initialized
INFO - 2018-08-22 18:59:42 --> URI Class Initialized
INFO - 2018-08-22 18:59:42 --> Router Class Initialized
INFO - 2018-08-22 18:59:42 --> Output Class Initialized
INFO - 2018-08-22 18:59:42 --> Security Class Initialized
DEBUG - 2018-08-22 18:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 18:59:42 --> CSRF cookie sent
INFO - 2018-08-22 18:59:42 --> CSRF token verified
INFO - 2018-08-22 18:59:42 --> Input Class Initialized
INFO - 2018-08-22 18:59:42 --> Language Class Initialized
INFO - 2018-08-22 18:59:42 --> Loader Class Initialized
INFO - 2018-08-22 18:59:42 --> Helper loaded: url_helper
INFO - 2018-08-22 18:59:42 --> Helper loaded: form_helper
INFO - 2018-08-22 18:59:42 --> Helper loaded: language_helper
DEBUG - 2018-08-22 18:59:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 18:59:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 18:59:42 --> User Agent Class Initialized
INFO - 2018-08-22 18:59:42 --> Controller Class Initialized
INFO - 2018-08-22 18:59:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 18:59:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 18:59:42 --> Pixel_Model class loaded
INFO - 2018-08-22 18:59:42 --> Database Driver Class Initialized
INFO - 2018-08-22 18:59:42 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:59:42 --> Form Validation Class Initialized
INFO - 2018-08-22 18:59:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 18:59:42 --> Database Driver Class Initialized
INFO - 2018-08-22 18:59:42 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:59:42 --> Config Class Initialized
INFO - 2018-08-22 18:59:42 --> Hooks Class Initialized
DEBUG - 2018-08-22 18:59:42 --> UTF-8 Support Enabled
INFO - 2018-08-22 18:59:42 --> Utf8 Class Initialized
INFO - 2018-08-22 18:59:42 --> URI Class Initialized
INFO - 2018-08-22 18:59:42 --> Router Class Initialized
INFO - 2018-08-22 18:59:42 --> Output Class Initialized
INFO - 2018-08-22 18:59:42 --> Security Class Initialized
DEBUG - 2018-08-22 18:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 18:59:42 --> CSRF cookie sent
INFO - 2018-08-22 18:59:42 --> Input Class Initialized
INFO - 2018-08-22 18:59:42 --> Language Class Initialized
INFO - 2018-08-22 18:59:42 --> Loader Class Initialized
INFO - 2018-08-22 18:59:42 --> Helper loaded: url_helper
INFO - 2018-08-22 18:59:42 --> Helper loaded: form_helper
INFO - 2018-08-22 18:59:42 --> Helper loaded: language_helper
DEBUG - 2018-08-22 18:59:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 18:59:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 18:59:42 --> User Agent Class Initialized
INFO - 2018-08-22 18:59:42 --> Controller Class Initialized
INFO - 2018-08-22 18:59:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 18:59:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 18:59:42 --> Pixel_Model class loaded
INFO - 2018-08-22 18:59:42 --> Database Driver Class Initialized
INFO - 2018-08-22 18:59:42 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:59:42 --> Database Driver Class Initialized
INFO - 2018-08-22 18:59:42 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:59:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 18:59:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 18:59:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 18:59:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 18:59:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 18:59:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 18:59:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 18:59:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/spouse_job.php
INFO - 2018-08-22 18:59:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 18:59:42 --> Final output sent to browser
DEBUG - 2018-08-22 18:59:42 --> Total execution time: 0.0503
INFO - 2018-08-22 18:59:48 --> Config Class Initialized
INFO - 2018-08-22 18:59:48 --> Hooks Class Initialized
DEBUG - 2018-08-22 18:59:48 --> UTF-8 Support Enabled
INFO - 2018-08-22 18:59:48 --> Utf8 Class Initialized
INFO - 2018-08-22 18:59:48 --> URI Class Initialized
INFO - 2018-08-22 18:59:48 --> Router Class Initialized
INFO - 2018-08-22 18:59:48 --> Output Class Initialized
INFO - 2018-08-22 18:59:48 --> Security Class Initialized
DEBUG - 2018-08-22 18:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 18:59:48 --> CSRF cookie sent
INFO - 2018-08-22 18:59:48 --> CSRF token verified
INFO - 2018-08-22 18:59:48 --> Input Class Initialized
INFO - 2018-08-22 18:59:48 --> Language Class Initialized
INFO - 2018-08-22 18:59:48 --> Loader Class Initialized
INFO - 2018-08-22 18:59:48 --> Helper loaded: url_helper
INFO - 2018-08-22 18:59:48 --> Helper loaded: form_helper
INFO - 2018-08-22 18:59:48 --> Helper loaded: language_helper
DEBUG - 2018-08-22 18:59:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 18:59:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 18:59:48 --> User Agent Class Initialized
INFO - 2018-08-22 18:59:48 --> Controller Class Initialized
INFO - 2018-08-22 18:59:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 18:59:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 18:59:48 --> Pixel_Model class loaded
INFO - 2018-08-22 18:59:48 --> Database Driver Class Initialized
INFO - 2018-08-22 18:59:48 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:59:48 --> Form Validation Class Initialized
INFO - 2018-08-22 18:59:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 18:59:48 --> Database Driver Class Initialized
INFO - 2018-08-22 18:59:48 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:59:48 --> Config Class Initialized
INFO - 2018-08-22 18:59:48 --> Hooks Class Initialized
DEBUG - 2018-08-22 18:59:48 --> UTF-8 Support Enabled
INFO - 2018-08-22 18:59:48 --> Utf8 Class Initialized
INFO - 2018-08-22 18:59:48 --> URI Class Initialized
INFO - 2018-08-22 18:59:48 --> Router Class Initialized
INFO - 2018-08-22 18:59:48 --> Output Class Initialized
INFO - 2018-08-22 18:59:48 --> Security Class Initialized
DEBUG - 2018-08-22 18:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 18:59:48 --> CSRF cookie sent
INFO - 2018-08-22 18:59:48 --> Input Class Initialized
INFO - 2018-08-22 18:59:48 --> Language Class Initialized
INFO - 2018-08-22 18:59:48 --> Loader Class Initialized
INFO - 2018-08-22 18:59:48 --> Helper loaded: url_helper
INFO - 2018-08-22 18:59:48 --> Helper loaded: form_helper
INFO - 2018-08-22 18:59:48 --> Helper loaded: language_helper
DEBUG - 2018-08-22 18:59:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 18:59:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 18:59:48 --> User Agent Class Initialized
INFO - 2018-08-22 18:59:48 --> Controller Class Initialized
INFO - 2018-08-22 18:59:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 18:59:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 18:59:48 --> Pixel_Model class loaded
INFO - 2018-08-22 18:59:48 --> Database Driver Class Initialized
INFO - 2018-08-22 18:59:48 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:59:48 --> Database Driver Class Initialized
INFO - 2018-08-22 18:59:48 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:59:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 18:59:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 18:59:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 18:59:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 18:59:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 18:59:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 18:59:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 18:59:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/affectionate_salutation.php
INFO - 2018-08-22 18:59:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 18:59:48 --> Final output sent to browser
DEBUG - 2018-08-22 18:59:48 --> Total execution time: 0.0521
INFO - 2018-08-22 18:59:54 --> Config Class Initialized
INFO - 2018-08-22 18:59:54 --> Hooks Class Initialized
DEBUG - 2018-08-22 18:59:54 --> UTF-8 Support Enabled
INFO - 2018-08-22 18:59:54 --> Utf8 Class Initialized
INFO - 2018-08-22 18:59:54 --> URI Class Initialized
INFO - 2018-08-22 18:59:54 --> Router Class Initialized
INFO - 2018-08-22 18:59:54 --> Output Class Initialized
INFO - 2018-08-22 18:59:54 --> Security Class Initialized
DEBUG - 2018-08-22 18:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 18:59:54 --> CSRF cookie sent
INFO - 2018-08-22 18:59:54 --> CSRF token verified
INFO - 2018-08-22 18:59:54 --> Input Class Initialized
INFO - 2018-08-22 18:59:54 --> Language Class Initialized
INFO - 2018-08-22 18:59:54 --> Loader Class Initialized
INFO - 2018-08-22 18:59:54 --> Helper loaded: url_helper
INFO - 2018-08-22 18:59:54 --> Helper loaded: form_helper
INFO - 2018-08-22 18:59:54 --> Helper loaded: language_helper
DEBUG - 2018-08-22 18:59:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 18:59:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 18:59:54 --> User Agent Class Initialized
INFO - 2018-08-22 18:59:54 --> Controller Class Initialized
INFO - 2018-08-22 18:59:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 18:59:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 18:59:54 --> Pixel_Model class loaded
INFO - 2018-08-22 18:59:54 --> Database Driver Class Initialized
INFO - 2018-08-22 18:59:54 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:59:54 --> Form Validation Class Initialized
INFO - 2018-08-22 18:59:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 18:59:54 --> Database Driver Class Initialized
INFO - 2018-08-22 18:59:54 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:59:54 --> Config Class Initialized
INFO - 2018-08-22 18:59:54 --> Hooks Class Initialized
DEBUG - 2018-08-22 18:59:54 --> UTF-8 Support Enabled
INFO - 2018-08-22 18:59:54 --> Utf8 Class Initialized
INFO - 2018-08-22 18:59:54 --> URI Class Initialized
INFO - 2018-08-22 18:59:54 --> Router Class Initialized
INFO - 2018-08-22 18:59:54 --> Output Class Initialized
INFO - 2018-08-22 18:59:54 --> Security Class Initialized
DEBUG - 2018-08-22 18:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 18:59:54 --> CSRF cookie sent
INFO - 2018-08-22 18:59:54 --> Input Class Initialized
INFO - 2018-08-22 18:59:54 --> Language Class Initialized
INFO - 2018-08-22 18:59:55 --> Loader Class Initialized
INFO - 2018-08-22 18:59:55 --> Helper loaded: url_helper
INFO - 2018-08-22 18:59:55 --> Helper loaded: form_helper
INFO - 2018-08-22 18:59:55 --> Helper loaded: language_helper
DEBUG - 2018-08-22 18:59:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 18:59:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 18:59:55 --> User Agent Class Initialized
INFO - 2018-08-22 18:59:55 --> Controller Class Initialized
INFO - 2018-08-22 18:59:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 18:59:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 18:59:55 --> Pixel_Model class loaded
INFO - 2018-08-22 18:59:55 --> Database Driver Class Initialized
INFO - 2018-08-22 18:59:55 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:59:55 --> Database Driver Class Initialized
INFO - 2018-08-22 18:59:55 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 18:59:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 18:59:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 18:59:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 18:59:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 18:59:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 18:59:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 18:59:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 18:59:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/business_tax_info.php
INFO - 2018-08-22 18:59:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 18:59:55 --> Final output sent to browser
DEBUG - 2018-08-22 18:59:55 --> Total execution time: 0.0529
INFO - 2018-08-22 19:00:19 --> Config Class Initialized
INFO - 2018-08-22 19:00:19 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:00:19 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:00:19 --> Utf8 Class Initialized
INFO - 2018-08-22 19:00:19 --> URI Class Initialized
INFO - 2018-08-22 19:00:19 --> Router Class Initialized
INFO - 2018-08-22 19:00:19 --> Output Class Initialized
INFO - 2018-08-22 19:00:19 --> Security Class Initialized
DEBUG - 2018-08-22 19:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:00:19 --> CSRF cookie sent
INFO - 2018-08-22 19:00:19 --> CSRF token verified
INFO - 2018-08-22 19:00:19 --> Input Class Initialized
INFO - 2018-08-22 19:00:19 --> Language Class Initialized
INFO - 2018-08-22 19:00:19 --> Loader Class Initialized
INFO - 2018-08-22 19:00:19 --> Helper loaded: url_helper
INFO - 2018-08-22 19:00:19 --> Helper loaded: form_helper
INFO - 2018-08-22 19:00:19 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:00:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:00:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:00:19 --> User Agent Class Initialized
INFO - 2018-08-22 19:00:19 --> Controller Class Initialized
INFO - 2018-08-22 19:00:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:00:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:00:19 --> Pixel_Model class loaded
INFO - 2018-08-22 19:00:19 --> Database Driver Class Initialized
INFO - 2018-08-22 19:00:19 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:00:19 --> Form Validation Class Initialized
INFO - 2018-08-22 19:00:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 19:00:19 --> Database Driver Class Initialized
INFO - 2018-08-22 19:00:19 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:00:19 --> Config Class Initialized
INFO - 2018-08-22 19:00:19 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:00:19 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:00:19 --> Utf8 Class Initialized
INFO - 2018-08-22 19:00:19 --> URI Class Initialized
INFO - 2018-08-22 19:00:19 --> Router Class Initialized
INFO - 2018-08-22 19:00:19 --> Output Class Initialized
INFO - 2018-08-22 19:00:19 --> Security Class Initialized
DEBUG - 2018-08-22 19:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:00:19 --> CSRF cookie sent
INFO - 2018-08-22 19:00:19 --> Input Class Initialized
INFO - 2018-08-22 19:00:19 --> Language Class Initialized
INFO - 2018-08-22 19:00:19 --> Loader Class Initialized
INFO - 2018-08-22 19:00:19 --> Helper loaded: url_helper
INFO - 2018-08-22 19:00:19 --> Helper loaded: form_helper
INFO - 2018-08-22 19:00:19 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:00:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:00:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:00:19 --> User Agent Class Initialized
INFO - 2018-08-22 19:00:19 --> Controller Class Initialized
INFO - 2018-08-22 19:00:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:00:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:00:19 --> Pixel_Model class loaded
INFO - 2018-08-22 19:00:19 --> Database Driver Class Initialized
INFO - 2018-08-22 19:00:19 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:00:19 --> Database Driver Class Initialized
INFO - 2018-08-22 19:00:19 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:00:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:00:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 19:00:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:00:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:00:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:00:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:00:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:00:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/trust_info.php
INFO - 2018-08-22 19:00:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:00:19 --> Final output sent to browser
DEBUG - 2018-08-22 19:00:19 --> Total execution time: 0.0449
INFO - 2018-08-22 19:00:26 --> Config Class Initialized
INFO - 2018-08-22 19:00:26 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:00:26 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:00:26 --> Utf8 Class Initialized
INFO - 2018-08-22 19:00:26 --> URI Class Initialized
INFO - 2018-08-22 19:00:26 --> Router Class Initialized
INFO - 2018-08-22 19:00:26 --> Output Class Initialized
INFO - 2018-08-22 19:00:26 --> Security Class Initialized
DEBUG - 2018-08-22 19:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:00:26 --> CSRF cookie sent
INFO - 2018-08-22 19:00:26 --> CSRF token verified
INFO - 2018-08-22 19:00:26 --> Input Class Initialized
INFO - 2018-08-22 19:00:26 --> Language Class Initialized
INFO - 2018-08-22 19:00:26 --> Loader Class Initialized
INFO - 2018-08-22 19:00:26 --> Helper loaded: url_helper
INFO - 2018-08-22 19:00:26 --> Helper loaded: form_helper
INFO - 2018-08-22 19:00:26 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:00:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:00:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:00:26 --> User Agent Class Initialized
INFO - 2018-08-22 19:00:26 --> Controller Class Initialized
INFO - 2018-08-22 19:00:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:00:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:00:26 --> Pixel_Model class loaded
INFO - 2018-08-22 19:00:26 --> Database Driver Class Initialized
INFO - 2018-08-22 19:00:26 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:00:26 --> Form Validation Class Initialized
INFO - 2018-08-22 19:00:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 19:00:26 --> Database Driver Class Initialized
INFO - 2018-08-22 19:00:26 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:00:26 --> Config Class Initialized
INFO - 2018-08-22 19:00:26 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:00:26 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:00:26 --> Utf8 Class Initialized
INFO - 2018-08-22 19:00:26 --> URI Class Initialized
INFO - 2018-08-22 19:00:26 --> Router Class Initialized
INFO - 2018-08-22 19:00:26 --> Output Class Initialized
INFO - 2018-08-22 19:00:26 --> Security Class Initialized
DEBUG - 2018-08-22 19:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:00:26 --> CSRF cookie sent
INFO - 2018-08-22 19:00:26 --> Input Class Initialized
INFO - 2018-08-22 19:00:26 --> Language Class Initialized
INFO - 2018-08-22 19:00:26 --> Loader Class Initialized
INFO - 2018-08-22 19:00:26 --> Helper loaded: url_helper
INFO - 2018-08-22 19:00:26 --> Helper loaded: form_helper
INFO - 2018-08-22 19:00:26 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:00:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:00:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:00:26 --> User Agent Class Initialized
INFO - 2018-08-22 19:00:26 --> Controller Class Initialized
INFO - 2018-08-22 19:00:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:00:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:00:26 --> Pixel_Model class loaded
INFO - 2018-08-22 19:00:26 --> Database Driver Class Initialized
INFO - 2018-08-22 19:00:26 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:00:26 --> Database Driver Class Initialized
INFO - 2018-08-22 19:00:26 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:00:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:00:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 19:00:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:00:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:00:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:00:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:00:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:00:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inherited_income.php
INFO - 2018-08-22 19:00:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:00:26 --> Final output sent to browser
DEBUG - 2018-08-22 19:00:26 --> Total execution time: 0.0454
INFO - 2018-08-22 19:00:34 --> Config Class Initialized
INFO - 2018-08-22 19:00:34 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:00:34 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:00:34 --> Utf8 Class Initialized
INFO - 2018-08-22 19:00:34 --> URI Class Initialized
INFO - 2018-08-22 19:00:34 --> Router Class Initialized
INFO - 2018-08-22 19:00:34 --> Output Class Initialized
INFO - 2018-08-22 19:00:34 --> Security Class Initialized
DEBUG - 2018-08-22 19:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:00:34 --> CSRF cookie sent
INFO - 2018-08-22 19:00:34 --> CSRF token verified
INFO - 2018-08-22 19:00:34 --> Input Class Initialized
INFO - 2018-08-22 19:00:34 --> Language Class Initialized
INFO - 2018-08-22 19:00:34 --> Loader Class Initialized
INFO - 2018-08-22 19:00:34 --> Helper loaded: url_helper
INFO - 2018-08-22 19:00:34 --> Helper loaded: form_helper
INFO - 2018-08-22 19:00:34 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:00:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:00:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:00:34 --> User Agent Class Initialized
INFO - 2018-08-22 19:00:34 --> Controller Class Initialized
INFO - 2018-08-22 19:00:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:00:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:00:34 --> Pixel_Model class loaded
INFO - 2018-08-22 19:00:34 --> Database Driver Class Initialized
INFO - 2018-08-22 19:00:34 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:00:34 --> Form Validation Class Initialized
INFO - 2018-08-22 19:00:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 19:00:34 --> Database Driver Class Initialized
INFO - 2018-08-22 19:00:34 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:00:34 --> Config Class Initialized
INFO - 2018-08-22 19:00:34 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:00:34 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:00:34 --> Utf8 Class Initialized
INFO - 2018-08-22 19:00:34 --> URI Class Initialized
INFO - 2018-08-22 19:00:34 --> Router Class Initialized
INFO - 2018-08-22 19:00:34 --> Output Class Initialized
INFO - 2018-08-22 19:00:34 --> Security Class Initialized
DEBUG - 2018-08-22 19:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:00:34 --> CSRF cookie sent
INFO - 2018-08-22 19:00:34 --> Input Class Initialized
INFO - 2018-08-22 19:00:34 --> Language Class Initialized
INFO - 2018-08-22 19:00:34 --> Loader Class Initialized
INFO - 2018-08-22 19:00:34 --> Helper loaded: url_helper
INFO - 2018-08-22 19:00:34 --> Helper loaded: form_helper
INFO - 2018-08-22 19:00:34 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:00:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:00:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:00:34 --> User Agent Class Initialized
INFO - 2018-08-22 19:00:34 --> Controller Class Initialized
INFO - 2018-08-22 19:00:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:00:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:00:34 --> Pixel_Model class loaded
INFO - 2018-08-22 19:00:34 --> Database Driver Class Initialized
INFO - 2018-08-22 19:00:34 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:00:34 --> Database Driver Class Initialized
INFO - 2018-08-22 19:00:34 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:00:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:00:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 19:00:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:00:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:00:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:00:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:00:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:00:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/shift_work.php
INFO - 2018-08-22 19:00:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:00:34 --> Final output sent to browser
DEBUG - 2018-08-22 19:00:34 --> Total execution time: 0.0467
INFO - 2018-08-22 19:00:38 --> Config Class Initialized
INFO - 2018-08-22 19:00:38 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:00:38 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:00:38 --> Utf8 Class Initialized
INFO - 2018-08-22 19:00:38 --> URI Class Initialized
INFO - 2018-08-22 19:00:38 --> Router Class Initialized
INFO - 2018-08-22 19:00:38 --> Output Class Initialized
INFO - 2018-08-22 19:00:38 --> Security Class Initialized
DEBUG - 2018-08-22 19:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:00:38 --> CSRF cookie sent
INFO - 2018-08-22 19:00:38 --> CSRF token verified
INFO - 2018-08-22 19:00:38 --> Input Class Initialized
INFO - 2018-08-22 19:00:38 --> Language Class Initialized
INFO - 2018-08-22 19:00:38 --> Loader Class Initialized
INFO - 2018-08-22 19:00:38 --> Helper loaded: url_helper
INFO - 2018-08-22 19:00:38 --> Helper loaded: form_helper
INFO - 2018-08-22 19:00:38 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:00:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:00:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:00:38 --> User Agent Class Initialized
INFO - 2018-08-22 19:00:38 --> Controller Class Initialized
INFO - 2018-08-22 19:00:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:00:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:00:38 --> Pixel_Model class loaded
INFO - 2018-08-22 19:00:38 --> Database Driver Class Initialized
INFO - 2018-08-22 19:00:38 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:00:38 --> Form Validation Class Initialized
INFO - 2018-08-22 19:00:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 19:00:38 --> Database Driver Class Initialized
INFO - 2018-08-22 19:00:38 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:00:38 --> Config Class Initialized
INFO - 2018-08-22 19:00:38 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:00:38 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:00:38 --> Utf8 Class Initialized
INFO - 2018-08-22 19:00:38 --> URI Class Initialized
INFO - 2018-08-22 19:00:38 --> Router Class Initialized
INFO - 2018-08-22 19:00:38 --> Output Class Initialized
INFO - 2018-08-22 19:00:38 --> Security Class Initialized
DEBUG - 2018-08-22 19:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:00:38 --> CSRF cookie sent
INFO - 2018-08-22 19:00:38 --> Input Class Initialized
INFO - 2018-08-22 19:00:38 --> Language Class Initialized
INFO - 2018-08-22 19:00:38 --> Loader Class Initialized
INFO - 2018-08-22 19:00:38 --> Helper loaded: url_helper
INFO - 2018-08-22 19:00:38 --> Helper loaded: form_helper
INFO - 2018-08-22 19:00:38 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:00:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:00:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:00:38 --> User Agent Class Initialized
INFO - 2018-08-22 19:00:38 --> Controller Class Initialized
INFO - 2018-08-22 19:00:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:00:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:00:38 --> Pixel_Model class loaded
INFO - 2018-08-22 19:00:38 --> Database Driver Class Initialized
INFO - 2018-08-22 19:00:38 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:00:38 --> Database Driver Class Initialized
INFO - 2018-08-22 19:00:38 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:00:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:00:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 19:00:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:00:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:00:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:00:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:00:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:00:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/night_without_s.php
INFO - 2018-08-22 19:00:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:00:38 --> Final output sent to browser
DEBUG - 2018-08-22 19:00:38 --> Total execution time: 0.0450
INFO - 2018-08-22 19:00:43 --> Config Class Initialized
INFO - 2018-08-22 19:00:43 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:00:43 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:00:43 --> Utf8 Class Initialized
INFO - 2018-08-22 19:00:43 --> URI Class Initialized
INFO - 2018-08-22 19:00:43 --> Router Class Initialized
INFO - 2018-08-22 19:00:43 --> Output Class Initialized
INFO - 2018-08-22 19:00:43 --> Security Class Initialized
DEBUG - 2018-08-22 19:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:00:43 --> CSRF cookie sent
INFO - 2018-08-22 19:00:43 --> CSRF token verified
INFO - 2018-08-22 19:00:43 --> Input Class Initialized
INFO - 2018-08-22 19:00:43 --> Language Class Initialized
INFO - 2018-08-22 19:00:43 --> Loader Class Initialized
INFO - 2018-08-22 19:00:43 --> Helper loaded: url_helper
INFO - 2018-08-22 19:00:43 --> Helper loaded: form_helper
INFO - 2018-08-22 19:00:43 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:00:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:00:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:00:43 --> User Agent Class Initialized
INFO - 2018-08-22 19:00:43 --> Controller Class Initialized
INFO - 2018-08-22 19:00:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:00:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:00:43 --> Pixel_Model class loaded
INFO - 2018-08-22 19:00:43 --> Database Driver Class Initialized
INFO - 2018-08-22 19:00:43 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:00:43 --> Form Validation Class Initialized
INFO - 2018-08-22 19:00:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 19:00:43 --> Database Driver Class Initialized
INFO - 2018-08-22 19:00:43 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:00:43 --> Config Class Initialized
INFO - 2018-08-22 19:00:43 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:00:43 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:00:43 --> Utf8 Class Initialized
INFO - 2018-08-22 19:00:43 --> URI Class Initialized
INFO - 2018-08-22 19:00:43 --> Router Class Initialized
INFO - 2018-08-22 19:00:43 --> Output Class Initialized
INFO - 2018-08-22 19:00:43 --> Security Class Initialized
DEBUG - 2018-08-22 19:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:00:43 --> CSRF cookie sent
INFO - 2018-08-22 19:00:43 --> Input Class Initialized
INFO - 2018-08-22 19:00:43 --> Language Class Initialized
INFO - 2018-08-22 19:00:43 --> Loader Class Initialized
INFO - 2018-08-22 19:00:43 --> Helper loaded: url_helper
INFO - 2018-08-22 19:00:43 --> Helper loaded: form_helper
INFO - 2018-08-22 19:00:43 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:00:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:00:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:00:43 --> User Agent Class Initialized
INFO - 2018-08-22 19:00:43 --> Controller Class Initialized
INFO - 2018-08-22 19:00:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:00:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:00:43 --> Pixel_Model class loaded
INFO - 2018-08-22 19:00:43 --> Database Driver Class Initialized
INFO - 2018-08-22 19:00:43 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:00:43 --> Database Driver Class Initialized
INFO - 2018-08-22 19:00:43 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:00:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:00:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 19:00:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:00:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:00:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:00:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:00:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:00:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/have_date.php
INFO - 2018-08-22 19:00:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:00:43 --> Final output sent to browser
DEBUG - 2018-08-22 19:00:43 --> Total execution time: 0.0600
INFO - 2018-08-22 19:00:51 --> Config Class Initialized
INFO - 2018-08-22 19:00:51 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:00:51 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:00:51 --> Utf8 Class Initialized
INFO - 2018-08-22 19:00:51 --> URI Class Initialized
INFO - 2018-08-22 19:00:51 --> Router Class Initialized
INFO - 2018-08-22 19:00:51 --> Output Class Initialized
INFO - 2018-08-22 19:00:51 --> Security Class Initialized
DEBUG - 2018-08-22 19:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:00:51 --> CSRF cookie sent
INFO - 2018-08-22 19:00:51 --> CSRF token verified
INFO - 2018-08-22 19:00:51 --> Input Class Initialized
INFO - 2018-08-22 19:00:51 --> Language Class Initialized
INFO - 2018-08-22 19:00:51 --> Loader Class Initialized
INFO - 2018-08-22 19:00:51 --> Helper loaded: url_helper
INFO - 2018-08-22 19:00:51 --> Helper loaded: form_helper
INFO - 2018-08-22 19:00:51 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:00:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:00:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:00:51 --> User Agent Class Initialized
INFO - 2018-08-22 19:00:51 --> Controller Class Initialized
INFO - 2018-08-22 19:00:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:00:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:00:51 --> Pixel_Model class loaded
INFO - 2018-08-22 19:00:51 --> Database Driver Class Initialized
INFO - 2018-08-22 19:00:51 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:00:51 --> Form Validation Class Initialized
INFO - 2018-08-22 19:00:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 19:00:51 --> Database Driver Class Initialized
INFO - 2018-08-22 19:00:51 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:00:51 --> Config Class Initialized
INFO - 2018-08-22 19:00:51 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:00:51 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:00:51 --> Utf8 Class Initialized
INFO - 2018-08-22 19:00:51 --> URI Class Initialized
INFO - 2018-08-22 19:00:51 --> Router Class Initialized
INFO - 2018-08-22 19:00:51 --> Output Class Initialized
INFO - 2018-08-22 19:00:51 --> Security Class Initialized
DEBUG - 2018-08-22 19:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:00:51 --> CSRF cookie sent
INFO - 2018-08-22 19:00:51 --> Input Class Initialized
INFO - 2018-08-22 19:00:51 --> Language Class Initialized
INFO - 2018-08-22 19:00:51 --> Loader Class Initialized
INFO - 2018-08-22 19:00:51 --> Helper loaded: url_helper
INFO - 2018-08-22 19:00:51 --> Helper loaded: form_helper
INFO - 2018-08-22 19:00:51 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:00:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:00:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:00:51 --> User Agent Class Initialized
INFO - 2018-08-22 19:00:51 --> Controller Class Initialized
INFO - 2018-08-22 19:00:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:00:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:00:51 --> Pixel_Model class loaded
INFO - 2018-08-22 19:00:51 --> Database Driver Class Initialized
INFO - 2018-08-22 19:00:51 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:00:51 --> Database Driver Class Initialized
INFO - 2018-08-22 19:00:51 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:00:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:00:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 19:00:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:00:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:00:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:00:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:00:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:00:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/nights_not_home.php
INFO - 2018-08-22 19:00:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:00:51 --> Final output sent to browser
DEBUG - 2018-08-22 19:00:51 --> Total execution time: 0.0632
INFO - 2018-08-22 19:00:56 --> Config Class Initialized
INFO - 2018-08-22 19:00:56 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:00:56 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:00:56 --> Utf8 Class Initialized
INFO - 2018-08-22 19:00:56 --> URI Class Initialized
INFO - 2018-08-22 19:00:56 --> Router Class Initialized
INFO - 2018-08-22 19:00:56 --> Output Class Initialized
INFO - 2018-08-22 19:00:56 --> Security Class Initialized
DEBUG - 2018-08-22 19:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:00:56 --> CSRF cookie sent
INFO - 2018-08-22 19:00:56 --> CSRF token verified
INFO - 2018-08-22 19:00:56 --> Input Class Initialized
INFO - 2018-08-22 19:00:56 --> Language Class Initialized
INFO - 2018-08-22 19:00:56 --> Loader Class Initialized
INFO - 2018-08-22 19:00:56 --> Helper loaded: url_helper
INFO - 2018-08-22 19:00:56 --> Helper loaded: form_helper
INFO - 2018-08-22 19:00:56 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:00:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:00:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:00:56 --> User Agent Class Initialized
INFO - 2018-08-22 19:00:56 --> Controller Class Initialized
INFO - 2018-08-22 19:00:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:00:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:00:56 --> Pixel_Model class loaded
INFO - 2018-08-22 19:00:56 --> Database Driver Class Initialized
INFO - 2018-08-22 19:00:56 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:00:56 --> Form Validation Class Initialized
INFO - 2018-08-22 19:00:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 19:00:56 --> Database Driver Class Initialized
INFO - 2018-08-22 19:00:56 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:00:56 --> Config Class Initialized
INFO - 2018-08-22 19:00:56 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:00:56 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:00:56 --> Utf8 Class Initialized
INFO - 2018-08-22 19:00:56 --> URI Class Initialized
INFO - 2018-08-22 19:00:56 --> Router Class Initialized
INFO - 2018-08-22 19:00:56 --> Output Class Initialized
INFO - 2018-08-22 19:00:56 --> Security Class Initialized
DEBUG - 2018-08-22 19:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:00:56 --> CSRF cookie sent
INFO - 2018-08-22 19:00:56 --> Input Class Initialized
INFO - 2018-08-22 19:00:56 --> Language Class Initialized
INFO - 2018-08-22 19:00:56 --> Loader Class Initialized
INFO - 2018-08-22 19:00:56 --> Helper loaded: url_helper
INFO - 2018-08-22 19:00:56 --> Helper loaded: form_helper
INFO - 2018-08-22 19:00:56 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:00:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:00:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:00:56 --> User Agent Class Initialized
INFO - 2018-08-22 19:00:56 --> Controller Class Initialized
INFO - 2018-08-22 19:00:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:00:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:00:56 --> Pixel_Model class loaded
INFO - 2018-08-22 19:00:56 --> Database Driver Class Initialized
INFO - 2018-08-22 19:00:56 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:00:56 --> Database Driver Class Initialized
INFO - 2018-08-22 19:00:56 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:00:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:00:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 19:00:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:00:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:00:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:00:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:00:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:00:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/s_nights_not_home.php
INFO - 2018-08-22 19:00:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:00:56 --> Final output sent to browser
DEBUG - 2018-08-22 19:00:56 --> Total execution time: 0.0436
INFO - 2018-08-22 19:00:59 --> Config Class Initialized
INFO - 2018-08-22 19:00:59 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:00:59 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:00:59 --> Utf8 Class Initialized
INFO - 2018-08-22 19:00:59 --> URI Class Initialized
INFO - 2018-08-22 19:00:59 --> Router Class Initialized
INFO - 2018-08-22 19:00:59 --> Output Class Initialized
INFO - 2018-08-22 19:00:59 --> Security Class Initialized
DEBUG - 2018-08-22 19:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:00:59 --> CSRF cookie sent
INFO - 2018-08-22 19:00:59 --> CSRF token verified
INFO - 2018-08-22 19:00:59 --> Input Class Initialized
INFO - 2018-08-22 19:00:59 --> Language Class Initialized
INFO - 2018-08-22 19:00:59 --> Loader Class Initialized
INFO - 2018-08-22 19:00:59 --> Helper loaded: url_helper
INFO - 2018-08-22 19:00:59 --> Helper loaded: form_helper
INFO - 2018-08-22 19:00:59 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:00:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:00:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:00:59 --> User Agent Class Initialized
INFO - 2018-08-22 19:00:59 --> Controller Class Initialized
INFO - 2018-08-22 19:00:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:00:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:00:59 --> Pixel_Model class loaded
INFO - 2018-08-22 19:00:59 --> Database Driver Class Initialized
INFO - 2018-08-22 19:00:59 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:00:59 --> Form Validation Class Initialized
INFO - 2018-08-22 19:00:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 19:00:59 --> Database Driver Class Initialized
INFO - 2018-08-22 19:00:59 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:00:59 --> Config Class Initialized
INFO - 2018-08-22 19:00:59 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:00:59 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:00:59 --> Utf8 Class Initialized
INFO - 2018-08-22 19:00:59 --> URI Class Initialized
INFO - 2018-08-22 19:00:59 --> Router Class Initialized
INFO - 2018-08-22 19:00:59 --> Output Class Initialized
INFO - 2018-08-22 19:00:59 --> Security Class Initialized
DEBUG - 2018-08-22 19:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:00:59 --> CSRF cookie sent
INFO - 2018-08-22 19:00:59 --> Input Class Initialized
INFO - 2018-08-22 19:00:59 --> Language Class Initialized
INFO - 2018-08-22 19:00:59 --> Loader Class Initialized
INFO - 2018-08-22 19:00:59 --> Helper loaded: url_helper
INFO - 2018-08-22 19:00:59 --> Helper loaded: form_helper
INFO - 2018-08-22 19:00:59 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:00:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:00:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:00:59 --> User Agent Class Initialized
INFO - 2018-08-22 19:00:59 --> Controller Class Initialized
INFO - 2018-08-22 19:00:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:00:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:00:59 --> Pixel_Model class loaded
INFO - 2018-08-22 19:00:59 --> Database Driver Class Initialized
INFO - 2018-08-22 19:00:59 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:00:59 --> Database Driver Class Initialized
INFO - 2018-08-22 19:00:59 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:00:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:00:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 19:00:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:00:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:00:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:00:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:00:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:00:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/s_nights_without_you.php
INFO - 2018-08-22 19:00:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:00:59 --> Final output sent to browser
DEBUG - 2018-08-22 19:00:59 --> Total execution time: 0.0406
INFO - 2018-08-22 19:01:01 --> Config Class Initialized
INFO - 2018-08-22 19:01:01 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:01:01 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:01:01 --> Utf8 Class Initialized
INFO - 2018-08-22 19:01:01 --> URI Class Initialized
INFO - 2018-08-22 19:01:01 --> Router Class Initialized
INFO - 2018-08-22 19:01:01 --> Output Class Initialized
INFO - 2018-08-22 19:01:01 --> Security Class Initialized
DEBUG - 2018-08-22 19:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:01:01 --> CSRF cookie sent
INFO - 2018-08-22 19:01:01 --> CSRF token verified
INFO - 2018-08-22 19:01:01 --> Input Class Initialized
INFO - 2018-08-22 19:01:01 --> Language Class Initialized
INFO - 2018-08-22 19:01:01 --> Loader Class Initialized
INFO - 2018-08-22 19:01:01 --> Helper loaded: url_helper
INFO - 2018-08-22 19:01:01 --> Helper loaded: form_helper
INFO - 2018-08-22 19:01:01 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:01:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:01:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:01:01 --> User Agent Class Initialized
INFO - 2018-08-22 19:01:01 --> Controller Class Initialized
INFO - 2018-08-22 19:01:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:01:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:01:01 --> Pixel_Model class loaded
INFO - 2018-08-22 19:01:01 --> Database Driver Class Initialized
INFO - 2018-08-22 19:01:01 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:01:01 --> Form Validation Class Initialized
INFO - 2018-08-22 19:01:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 19:01:01 --> Database Driver Class Initialized
INFO - 2018-08-22 19:01:01 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:01:01 --> Config Class Initialized
INFO - 2018-08-22 19:01:01 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:01:01 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:01:01 --> Utf8 Class Initialized
INFO - 2018-08-22 19:01:01 --> URI Class Initialized
INFO - 2018-08-22 19:01:01 --> Router Class Initialized
INFO - 2018-08-22 19:01:01 --> Output Class Initialized
INFO - 2018-08-22 19:01:01 --> Security Class Initialized
DEBUG - 2018-08-22 19:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:01:01 --> CSRF cookie sent
INFO - 2018-08-22 19:01:01 --> Input Class Initialized
INFO - 2018-08-22 19:01:01 --> Language Class Initialized
INFO - 2018-08-22 19:01:01 --> Loader Class Initialized
INFO - 2018-08-22 19:01:01 --> Helper loaded: url_helper
INFO - 2018-08-22 19:01:01 --> Helper loaded: form_helper
INFO - 2018-08-22 19:01:01 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:01:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:01:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:01:01 --> User Agent Class Initialized
INFO - 2018-08-22 19:01:01 --> Controller Class Initialized
INFO - 2018-08-22 19:01:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:01:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:01:01 --> Pixel_Model class loaded
INFO - 2018-08-22 19:01:01 --> Database Driver Class Initialized
INFO - 2018-08-22 19:01:01 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:01:01 --> Database Driver Class Initialized
INFO - 2018-08-22 19:01:01 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:01:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:01:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 19:01:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:01:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:01:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:01:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:01:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:01:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/alcoholic_drinks_per_week.php
INFO - 2018-08-22 19:01:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:01:01 --> Final output sent to browser
DEBUG - 2018-08-22 19:01:01 --> Total execution time: 0.0442
INFO - 2018-08-22 19:01:03 --> Config Class Initialized
INFO - 2018-08-22 19:01:03 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:01:03 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:01:03 --> Utf8 Class Initialized
INFO - 2018-08-22 19:01:03 --> URI Class Initialized
INFO - 2018-08-22 19:01:03 --> Router Class Initialized
INFO - 2018-08-22 19:01:03 --> Output Class Initialized
INFO - 2018-08-22 19:01:03 --> Security Class Initialized
DEBUG - 2018-08-22 19:01:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:01:03 --> CSRF cookie sent
INFO - 2018-08-22 19:01:03 --> CSRF token verified
INFO - 2018-08-22 19:01:03 --> Input Class Initialized
INFO - 2018-08-22 19:01:03 --> Language Class Initialized
INFO - 2018-08-22 19:01:03 --> Loader Class Initialized
INFO - 2018-08-22 19:01:03 --> Helper loaded: url_helper
INFO - 2018-08-22 19:01:03 --> Helper loaded: form_helper
INFO - 2018-08-22 19:01:03 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:01:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:01:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:01:03 --> User Agent Class Initialized
INFO - 2018-08-22 19:01:03 --> Controller Class Initialized
INFO - 2018-08-22 19:01:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:01:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:01:03 --> Pixel_Model class loaded
INFO - 2018-08-22 19:01:03 --> Database Driver Class Initialized
INFO - 2018-08-22 19:01:03 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:01:03 --> Form Validation Class Initialized
INFO - 2018-08-22 19:01:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 19:01:03 --> Database Driver Class Initialized
INFO - 2018-08-22 19:01:03 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:01:04 --> Config Class Initialized
INFO - 2018-08-22 19:01:04 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:01:04 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:01:04 --> Utf8 Class Initialized
INFO - 2018-08-22 19:01:04 --> URI Class Initialized
INFO - 2018-08-22 19:01:04 --> Router Class Initialized
INFO - 2018-08-22 19:01:04 --> Output Class Initialized
INFO - 2018-08-22 19:01:04 --> Security Class Initialized
DEBUG - 2018-08-22 19:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:01:04 --> CSRF cookie sent
INFO - 2018-08-22 19:01:04 --> Input Class Initialized
INFO - 2018-08-22 19:01:04 --> Language Class Initialized
INFO - 2018-08-22 19:01:04 --> Loader Class Initialized
INFO - 2018-08-22 19:01:04 --> Helper loaded: url_helper
INFO - 2018-08-22 19:01:04 --> Helper loaded: form_helper
INFO - 2018-08-22 19:01:04 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:01:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:01:04 --> User Agent Class Initialized
INFO - 2018-08-22 19:01:04 --> Controller Class Initialized
INFO - 2018-08-22 19:01:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:01:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:01:04 --> Pixel_Model class loaded
INFO - 2018-08-22 19:01:04 --> Database Driver Class Initialized
INFO - 2018-08-22 19:01:04 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:01:04 --> Database Driver Class Initialized
INFO - 2018-08-22 19:01:04 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:01:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:01:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 19:01:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:01:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:01:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:01:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:01:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:01:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/have_drugs.php
INFO - 2018-08-22 19:01:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:01:04 --> Final output sent to browser
DEBUG - 2018-08-22 19:01:04 --> Total execution time: 0.0609
INFO - 2018-08-22 19:01:07 --> Config Class Initialized
INFO - 2018-08-22 19:01:07 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:01:07 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:01:07 --> Utf8 Class Initialized
INFO - 2018-08-22 19:01:07 --> URI Class Initialized
INFO - 2018-08-22 19:01:07 --> Router Class Initialized
INFO - 2018-08-22 19:01:07 --> Output Class Initialized
INFO - 2018-08-22 19:01:07 --> Security Class Initialized
DEBUG - 2018-08-22 19:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:01:07 --> CSRF cookie sent
INFO - 2018-08-22 19:01:07 --> CSRF token verified
INFO - 2018-08-22 19:01:07 --> Input Class Initialized
INFO - 2018-08-22 19:01:07 --> Language Class Initialized
INFO - 2018-08-22 19:01:07 --> Loader Class Initialized
INFO - 2018-08-22 19:01:07 --> Helper loaded: url_helper
INFO - 2018-08-22 19:01:07 --> Helper loaded: form_helper
INFO - 2018-08-22 19:01:07 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:01:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:01:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:01:07 --> User Agent Class Initialized
INFO - 2018-08-22 19:01:07 --> Controller Class Initialized
INFO - 2018-08-22 19:01:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:01:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:01:07 --> Pixel_Model class loaded
INFO - 2018-08-22 19:01:07 --> Database Driver Class Initialized
INFO - 2018-08-22 19:01:07 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:01:07 --> Form Validation Class Initialized
INFO - 2018-08-22 19:01:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 19:01:07 --> Database Driver Class Initialized
INFO - 2018-08-22 19:01:07 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:01:07 --> Config Class Initialized
INFO - 2018-08-22 19:01:07 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:01:07 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:01:07 --> Utf8 Class Initialized
INFO - 2018-08-22 19:01:07 --> URI Class Initialized
INFO - 2018-08-22 19:01:07 --> Router Class Initialized
INFO - 2018-08-22 19:01:07 --> Output Class Initialized
INFO - 2018-08-22 19:01:07 --> Security Class Initialized
DEBUG - 2018-08-22 19:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:01:07 --> CSRF cookie sent
INFO - 2018-08-22 19:01:07 --> Input Class Initialized
INFO - 2018-08-22 19:01:07 --> Language Class Initialized
INFO - 2018-08-22 19:01:07 --> Loader Class Initialized
INFO - 2018-08-22 19:01:07 --> Helper loaded: url_helper
INFO - 2018-08-22 19:01:07 --> Helper loaded: form_helper
INFO - 2018-08-22 19:01:07 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:01:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:01:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:01:07 --> User Agent Class Initialized
INFO - 2018-08-22 19:01:07 --> Controller Class Initialized
INFO - 2018-08-22 19:01:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:01:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:01:07 --> Pixel_Model class loaded
INFO - 2018-08-22 19:01:07 --> Database Driver Class Initialized
INFO - 2018-08-22 19:01:07 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:01:07 --> Database Driver Class Initialized
INFO - 2018-08-22 19:01:07 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:01:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:01:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 19:01:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:01:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:01:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:01:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:01:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:01:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/has_addiction_problem.php
INFO - 2018-08-22 19:01:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:01:07 --> Final output sent to browser
DEBUG - 2018-08-22 19:01:07 --> Total execution time: 0.0370
INFO - 2018-08-22 19:01:13 --> Config Class Initialized
INFO - 2018-08-22 19:01:13 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:01:13 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:01:13 --> Utf8 Class Initialized
INFO - 2018-08-22 19:01:13 --> URI Class Initialized
INFO - 2018-08-22 19:01:13 --> Router Class Initialized
INFO - 2018-08-22 19:01:13 --> Output Class Initialized
INFO - 2018-08-22 19:01:13 --> Security Class Initialized
DEBUG - 2018-08-22 19:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:01:13 --> CSRF cookie sent
INFO - 2018-08-22 19:01:13 --> CSRF token verified
INFO - 2018-08-22 19:01:13 --> Input Class Initialized
INFO - 2018-08-22 19:01:13 --> Language Class Initialized
INFO - 2018-08-22 19:01:13 --> Loader Class Initialized
INFO - 2018-08-22 19:01:13 --> Helper loaded: url_helper
INFO - 2018-08-22 19:01:13 --> Helper loaded: form_helper
INFO - 2018-08-22 19:01:13 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:01:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:01:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:01:13 --> User Agent Class Initialized
INFO - 2018-08-22 19:01:13 --> Controller Class Initialized
INFO - 2018-08-22 19:01:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:01:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:01:13 --> Pixel_Model class loaded
INFO - 2018-08-22 19:01:13 --> Database Driver Class Initialized
INFO - 2018-08-22 19:01:13 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:01:13 --> Form Validation Class Initialized
INFO - 2018-08-22 19:01:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 19:01:13 --> Database Driver Class Initialized
INFO - 2018-08-22 19:01:13 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:01:13 --> Config Class Initialized
INFO - 2018-08-22 19:01:13 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:01:13 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:01:13 --> Utf8 Class Initialized
INFO - 2018-08-22 19:01:13 --> URI Class Initialized
INFO - 2018-08-22 19:01:13 --> Router Class Initialized
INFO - 2018-08-22 19:01:13 --> Output Class Initialized
INFO - 2018-08-22 19:01:13 --> Security Class Initialized
DEBUG - 2018-08-22 19:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:01:13 --> CSRF cookie sent
INFO - 2018-08-22 19:01:13 --> Input Class Initialized
INFO - 2018-08-22 19:01:13 --> Language Class Initialized
INFO - 2018-08-22 19:01:13 --> Loader Class Initialized
INFO - 2018-08-22 19:01:13 --> Helper loaded: url_helper
INFO - 2018-08-22 19:01:13 --> Helper loaded: form_helper
INFO - 2018-08-22 19:01:13 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:01:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:01:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:01:13 --> User Agent Class Initialized
INFO - 2018-08-22 19:01:13 --> Controller Class Initialized
INFO - 2018-08-22 19:01:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:01:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:01:13 --> Pixel_Model class loaded
INFO - 2018-08-22 19:01:13 --> Database Driver Class Initialized
INFO - 2018-08-22 19:01:13 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:01:13 --> Database Driver Class Initialized
INFO - 2018-08-22 19:01:13 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:01:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:01:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 19:01:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:01:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:01:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:01:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:01:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:01:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/have_hit_s.php
INFO - 2018-08-22 19:01:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:01:13 --> Final output sent to browser
DEBUG - 2018-08-22 19:01:13 --> Total execution time: 0.0395
INFO - 2018-08-22 19:01:22 --> Config Class Initialized
INFO - 2018-08-22 19:01:22 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:01:22 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:01:22 --> Utf8 Class Initialized
INFO - 2018-08-22 19:01:22 --> URI Class Initialized
INFO - 2018-08-22 19:01:22 --> Router Class Initialized
INFO - 2018-08-22 19:01:22 --> Output Class Initialized
INFO - 2018-08-22 19:01:22 --> Security Class Initialized
DEBUG - 2018-08-22 19:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:01:22 --> CSRF cookie sent
INFO - 2018-08-22 19:01:22 --> CSRF token verified
INFO - 2018-08-22 19:01:22 --> Input Class Initialized
INFO - 2018-08-22 19:01:22 --> Language Class Initialized
INFO - 2018-08-22 19:01:22 --> Loader Class Initialized
INFO - 2018-08-22 19:01:22 --> Helper loaded: url_helper
INFO - 2018-08-22 19:01:22 --> Helper loaded: form_helper
INFO - 2018-08-22 19:01:22 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:01:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:01:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:01:22 --> User Agent Class Initialized
INFO - 2018-08-22 19:01:22 --> Controller Class Initialized
INFO - 2018-08-22 19:01:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:01:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:01:22 --> Pixel_Model class loaded
INFO - 2018-08-22 19:01:22 --> Database Driver Class Initialized
INFO - 2018-08-22 19:01:22 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:01:22 --> Form Validation Class Initialized
INFO - 2018-08-22 19:01:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 19:01:22 --> Database Driver Class Initialized
INFO - 2018-08-22 19:01:22 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:01:22 --> Config Class Initialized
INFO - 2018-08-22 19:01:22 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:01:22 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:01:22 --> Utf8 Class Initialized
INFO - 2018-08-22 19:01:22 --> URI Class Initialized
INFO - 2018-08-22 19:01:22 --> Router Class Initialized
INFO - 2018-08-22 19:01:22 --> Output Class Initialized
INFO - 2018-08-22 19:01:22 --> Security Class Initialized
DEBUG - 2018-08-22 19:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:01:22 --> CSRF cookie sent
INFO - 2018-08-22 19:01:22 --> Input Class Initialized
INFO - 2018-08-22 19:01:22 --> Language Class Initialized
INFO - 2018-08-22 19:01:22 --> Loader Class Initialized
INFO - 2018-08-22 19:01:22 --> Helper loaded: url_helper
INFO - 2018-08-22 19:01:22 --> Helper loaded: form_helper
INFO - 2018-08-22 19:01:22 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:01:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:01:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:01:22 --> User Agent Class Initialized
INFO - 2018-08-22 19:01:22 --> Controller Class Initialized
INFO - 2018-08-22 19:01:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:01:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:01:22 --> Pixel_Model class loaded
INFO - 2018-08-22 19:01:22 --> Database Driver Class Initialized
INFO - 2018-08-22 19:01:22 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:01:22 --> Database Driver Class Initialized
INFO - 2018-08-22 19:01:22 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:01:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:01:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 19:01:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:01:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:01:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:01:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:01:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:01:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial_control.php
INFO - 2018-08-22 19:01:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:01:22 --> Final output sent to browser
DEBUG - 2018-08-22 19:01:22 --> Total execution time: 0.0395
INFO - 2018-08-22 19:01:26 --> Config Class Initialized
INFO - 2018-08-22 19:01:26 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:01:26 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:01:26 --> Utf8 Class Initialized
INFO - 2018-08-22 19:01:26 --> URI Class Initialized
INFO - 2018-08-22 19:01:26 --> Router Class Initialized
INFO - 2018-08-22 19:01:26 --> Output Class Initialized
INFO - 2018-08-22 19:01:26 --> Security Class Initialized
DEBUG - 2018-08-22 19:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:01:26 --> CSRF cookie sent
INFO - 2018-08-22 19:01:26 --> CSRF token verified
INFO - 2018-08-22 19:01:26 --> Input Class Initialized
INFO - 2018-08-22 19:01:26 --> Language Class Initialized
INFO - 2018-08-22 19:01:26 --> Loader Class Initialized
INFO - 2018-08-22 19:01:26 --> Helper loaded: url_helper
INFO - 2018-08-22 19:01:26 --> Helper loaded: form_helper
INFO - 2018-08-22 19:01:26 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:01:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:01:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:01:26 --> User Agent Class Initialized
INFO - 2018-08-22 19:01:26 --> Controller Class Initialized
INFO - 2018-08-22 19:01:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:01:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:01:26 --> Pixel_Model class loaded
INFO - 2018-08-22 19:01:26 --> Database Driver Class Initialized
INFO - 2018-08-22 19:01:26 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:01:26 --> Form Validation Class Initialized
INFO - 2018-08-22 19:01:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 19:01:26 --> Database Driver Class Initialized
INFO - 2018-08-22 19:01:26 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:01:26 --> Config Class Initialized
INFO - 2018-08-22 19:01:26 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:01:26 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:01:26 --> Utf8 Class Initialized
INFO - 2018-08-22 19:01:26 --> URI Class Initialized
INFO - 2018-08-22 19:01:26 --> Router Class Initialized
INFO - 2018-08-22 19:01:26 --> Output Class Initialized
INFO - 2018-08-22 19:01:26 --> Security Class Initialized
DEBUG - 2018-08-22 19:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:01:26 --> CSRF cookie sent
INFO - 2018-08-22 19:01:26 --> Input Class Initialized
INFO - 2018-08-22 19:01:26 --> Language Class Initialized
INFO - 2018-08-22 19:01:26 --> Loader Class Initialized
INFO - 2018-08-22 19:01:26 --> Helper loaded: url_helper
INFO - 2018-08-22 19:01:26 --> Helper loaded: form_helper
INFO - 2018-08-22 19:01:26 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:01:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:01:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:01:26 --> User Agent Class Initialized
INFO - 2018-08-22 19:01:26 --> Controller Class Initialized
INFO - 2018-08-22 19:01:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:01:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:01:26 --> Pixel_Model class loaded
INFO - 2018-08-22 19:01:26 --> Database Driver Class Initialized
INFO - 2018-08-22 19:01:26 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:01:26 --> Database Driver Class Initialized
INFO - 2018-08-22 19:01:26 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:01:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:01:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 19:01:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:01:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:01:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:01:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:01:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:01:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/has_hit_kids.php
INFO - 2018-08-22 19:01:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:01:26 --> Final output sent to browser
DEBUG - 2018-08-22 19:01:26 --> Total execution time: 0.0503
INFO - 2018-08-22 19:01:52 --> Config Class Initialized
INFO - 2018-08-22 19:01:52 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:01:52 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:01:52 --> Utf8 Class Initialized
INFO - 2018-08-22 19:01:52 --> URI Class Initialized
INFO - 2018-08-22 19:01:52 --> Router Class Initialized
INFO - 2018-08-22 19:01:52 --> Output Class Initialized
INFO - 2018-08-22 19:01:52 --> Security Class Initialized
DEBUG - 2018-08-22 19:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:01:52 --> CSRF cookie sent
INFO - 2018-08-22 19:01:52 --> CSRF token verified
INFO - 2018-08-22 19:01:52 --> Input Class Initialized
INFO - 2018-08-22 19:01:52 --> Language Class Initialized
INFO - 2018-08-22 19:01:52 --> Loader Class Initialized
INFO - 2018-08-22 19:01:52 --> Helper loaded: url_helper
INFO - 2018-08-22 19:01:52 --> Helper loaded: form_helper
INFO - 2018-08-22 19:01:52 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:01:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:01:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:01:52 --> User Agent Class Initialized
INFO - 2018-08-22 19:01:52 --> Controller Class Initialized
INFO - 2018-08-22 19:01:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:01:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:01:52 --> Pixel_Model class loaded
INFO - 2018-08-22 19:01:52 --> Database Driver Class Initialized
INFO - 2018-08-22 19:01:52 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:01:52 --> Form Validation Class Initialized
INFO - 2018-08-22 19:01:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 19:01:52 --> Database Driver Class Initialized
INFO - 2018-08-22 19:01:52 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:01:52 --> Config Class Initialized
INFO - 2018-08-22 19:01:52 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:01:52 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:01:52 --> Utf8 Class Initialized
INFO - 2018-08-22 19:01:52 --> URI Class Initialized
INFO - 2018-08-22 19:01:52 --> Router Class Initialized
INFO - 2018-08-22 19:01:52 --> Output Class Initialized
INFO - 2018-08-22 19:01:52 --> Security Class Initialized
DEBUG - 2018-08-22 19:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:01:52 --> CSRF cookie sent
INFO - 2018-08-22 19:01:52 --> Input Class Initialized
INFO - 2018-08-22 19:01:52 --> Language Class Initialized
INFO - 2018-08-22 19:01:52 --> Loader Class Initialized
INFO - 2018-08-22 19:01:52 --> Helper loaded: url_helper
INFO - 2018-08-22 19:01:52 --> Helper loaded: form_helper
INFO - 2018-08-22 19:01:52 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:01:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:01:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:01:52 --> User Agent Class Initialized
INFO - 2018-08-22 19:01:52 --> Controller Class Initialized
INFO - 2018-08-22 19:01:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:01:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:01:52 --> Pixel_Model class loaded
INFO - 2018-08-22 19:01:52 --> Database Driver Class Initialized
INFO - 2018-08-22 19:01:52 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:01:52 --> Database Driver Class Initialized
INFO - 2018-08-22 19:01:52 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:01:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:01:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 19:01:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:01:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:01:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:01:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:01:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:01:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/withheld_sex.php
INFO - 2018-08-22 19:01:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:01:52 --> Final output sent to browser
DEBUG - 2018-08-22 19:01:52 --> Total execution time: 0.0439
INFO - 2018-08-22 19:01:53 --> Config Class Initialized
INFO - 2018-08-22 19:01:53 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:01:53 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:01:53 --> Utf8 Class Initialized
INFO - 2018-08-22 19:01:53 --> URI Class Initialized
INFO - 2018-08-22 19:01:53 --> Router Class Initialized
INFO - 2018-08-22 19:01:53 --> Output Class Initialized
INFO - 2018-08-22 19:01:53 --> Security Class Initialized
DEBUG - 2018-08-22 19:01:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:01:53 --> CSRF cookie sent
INFO - 2018-08-22 19:01:53 --> CSRF token verified
INFO - 2018-08-22 19:01:53 --> Input Class Initialized
INFO - 2018-08-22 19:01:53 --> Language Class Initialized
INFO - 2018-08-22 19:01:53 --> Loader Class Initialized
INFO - 2018-08-22 19:01:53 --> Helper loaded: url_helper
INFO - 2018-08-22 19:01:53 --> Helper loaded: form_helper
INFO - 2018-08-22 19:01:53 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:01:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:01:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:01:53 --> User Agent Class Initialized
INFO - 2018-08-22 19:01:53 --> Controller Class Initialized
INFO - 2018-08-22 19:01:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:01:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:01:53 --> Pixel_Model class loaded
INFO - 2018-08-22 19:01:53 --> Database Driver Class Initialized
INFO - 2018-08-22 19:01:53 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:01:53 --> Form Validation Class Initialized
INFO - 2018-08-22 19:01:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 19:01:53 --> Database Driver Class Initialized
INFO - 2018-08-22 19:01:53 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:01:54 --> Config Class Initialized
INFO - 2018-08-22 19:01:54 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:01:54 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:01:54 --> Utf8 Class Initialized
INFO - 2018-08-22 19:01:54 --> URI Class Initialized
INFO - 2018-08-22 19:01:54 --> Router Class Initialized
INFO - 2018-08-22 19:01:54 --> Output Class Initialized
INFO - 2018-08-22 19:01:54 --> Security Class Initialized
DEBUG - 2018-08-22 19:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:01:54 --> CSRF cookie sent
INFO - 2018-08-22 19:01:54 --> Input Class Initialized
INFO - 2018-08-22 19:01:54 --> Language Class Initialized
INFO - 2018-08-22 19:01:54 --> Loader Class Initialized
INFO - 2018-08-22 19:01:54 --> Helper loaded: url_helper
INFO - 2018-08-22 19:01:54 --> Helper loaded: form_helper
INFO - 2018-08-22 19:01:54 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:01:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:01:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:01:54 --> User Agent Class Initialized
INFO - 2018-08-22 19:01:54 --> Controller Class Initialized
INFO - 2018-08-22 19:01:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:01:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:01:54 --> Pixel_Model class loaded
INFO - 2018-08-22 19:01:54 --> Database Driver Class Initialized
INFO - 2018-08-22 19:01:54 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:01:54 --> Database Driver Class Initialized
INFO - 2018-08-22 19:01:54 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:01:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:01:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:01:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:01:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:01:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:01:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:01:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-08-22 19:01:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:01:54 --> Final output sent to browser
DEBUG - 2018-08-22 19:01:54 --> Total execution time: 0.0407
INFO - 2018-08-22 19:05:37 --> Config Class Initialized
INFO - 2018-08-22 19:05:37 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:05:37 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:05:37 --> Utf8 Class Initialized
INFO - 2018-08-22 19:05:37 --> URI Class Initialized
INFO - 2018-08-22 19:05:37 --> Router Class Initialized
INFO - 2018-08-22 19:05:37 --> Output Class Initialized
INFO - 2018-08-22 19:05:37 --> Security Class Initialized
DEBUG - 2018-08-22 19:05:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:05:37 --> CSRF cookie sent
INFO - 2018-08-22 19:05:37 --> Input Class Initialized
INFO - 2018-08-22 19:05:37 --> Language Class Initialized
INFO - 2018-08-22 19:05:37 --> Loader Class Initialized
INFO - 2018-08-22 19:05:37 --> Helper loaded: url_helper
INFO - 2018-08-22 19:05:37 --> Helper loaded: form_helper
INFO - 2018-08-22 19:05:37 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:05:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:05:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:05:37 --> User Agent Class Initialized
INFO - 2018-08-22 19:05:37 --> Controller Class Initialized
INFO - 2018-08-22 19:05:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:05:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:05:37 --> Pixel_Model class loaded
INFO - 2018-08-22 19:05:37 --> Database Driver Class Initialized
INFO - 2018-08-22 19:05:37 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:05:37 --> Database Driver Class Initialized
INFO - 2018-08-22 19:05:37 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:05:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:05:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 19:05:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:05:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:05:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:05:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:05:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:05:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-22 19:05:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:05:37 --> Final output sent to browser
DEBUG - 2018-08-22 19:05:37 --> Total execution time: 0.0560
INFO - 2018-08-22 19:05:40 --> Config Class Initialized
INFO - 2018-08-22 19:05:40 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:05:40 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:05:40 --> Utf8 Class Initialized
INFO - 2018-08-22 19:05:40 --> URI Class Initialized
INFO - 2018-08-22 19:05:40 --> Router Class Initialized
INFO - 2018-08-22 19:05:40 --> Output Class Initialized
INFO - 2018-08-22 19:05:40 --> Security Class Initialized
DEBUG - 2018-08-22 19:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:05:40 --> CSRF cookie sent
INFO - 2018-08-22 19:05:40 --> Input Class Initialized
INFO - 2018-08-22 19:05:40 --> Language Class Initialized
INFO - 2018-08-22 19:05:40 --> Loader Class Initialized
INFO - 2018-08-22 19:05:40 --> Helper loaded: url_helper
INFO - 2018-08-22 19:05:40 --> Helper loaded: form_helper
INFO - 2018-08-22 19:05:40 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:05:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:05:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:05:40 --> User Agent Class Initialized
INFO - 2018-08-22 19:05:40 --> Controller Class Initialized
INFO - 2018-08-22 19:05:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:05:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:05:40 --> Pixel_Model class loaded
INFO - 2018-08-22 19:05:40 --> Database Driver Class Initialized
INFO - 2018-08-22 19:05:40 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:05:40 --> Database Driver Class Initialized
INFO - 2018-08-22 19:05:40 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:05:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:05:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 19:05:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:05:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:05:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:05:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:05:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:05:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-08-22 19:05:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:05:40 --> Final output sent to browser
DEBUG - 2018-08-22 19:05:40 --> Total execution time: 0.0546
INFO - 2018-08-22 19:05:42 --> Config Class Initialized
INFO - 2018-08-22 19:05:42 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:05:42 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:05:42 --> Utf8 Class Initialized
INFO - 2018-08-22 19:05:42 --> URI Class Initialized
INFO - 2018-08-22 19:05:42 --> Router Class Initialized
INFO - 2018-08-22 19:05:42 --> Output Class Initialized
INFO - 2018-08-22 19:05:42 --> Security Class Initialized
DEBUG - 2018-08-22 19:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:05:42 --> CSRF cookie sent
INFO - 2018-08-22 19:05:42 --> Input Class Initialized
INFO - 2018-08-22 19:05:42 --> Language Class Initialized
INFO - 2018-08-22 19:05:42 --> Loader Class Initialized
INFO - 2018-08-22 19:05:42 --> Helper loaded: url_helper
INFO - 2018-08-22 19:05:42 --> Helper loaded: form_helper
INFO - 2018-08-22 19:05:42 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:05:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:05:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:05:42 --> User Agent Class Initialized
INFO - 2018-08-22 19:05:42 --> Controller Class Initialized
INFO - 2018-08-22 19:05:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:05:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:05:42 --> Pixel_Model class loaded
INFO - 2018-08-22 19:05:42 --> Database Driver Class Initialized
INFO - 2018-08-22 19:05:42 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:05:42 --> Database Driver Class Initialized
INFO - 2018-08-22 19:05:42 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:05:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:05:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 19:05:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:05:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-08-22 19:05:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:05:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:05:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:05:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:05:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-08-22 19:05:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:05:42 --> Final output sent to browser
DEBUG - 2018-08-22 19:05:42 --> Total execution time: 0.0400
INFO - 2018-08-22 19:07:48 --> Config Class Initialized
INFO - 2018-08-22 19:07:48 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:07:48 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:07:48 --> Utf8 Class Initialized
INFO - 2018-08-22 19:07:48 --> URI Class Initialized
INFO - 2018-08-22 19:07:48 --> Router Class Initialized
INFO - 2018-08-22 19:07:48 --> Output Class Initialized
INFO - 2018-08-22 19:07:48 --> Security Class Initialized
DEBUG - 2018-08-22 19:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:07:48 --> CSRF cookie sent
INFO - 2018-08-22 19:07:48 --> Input Class Initialized
INFO - 2018-08-22 19:07:48 --> Language Class Initialized
INFO - 2018-08-22 19:07:48 --> Loader Class Initialized
INFO - 2018-08-22 19:07:48 --> Helper loaded: url_helper
INFO - 2018-08-22 19:07:48 --> Helper loaded: form_helper
INFO - 2018-08-22 19:07:48 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:07:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:07:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:07:48 --> User Agent Class Initialized
INFO - 2018-08-22 19:07:48 --> Controller Class Initialized
INFO - 2018-08-22 19:07:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:07:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:07:48 --> Pixel_Model class loaded
INFO - 2018-08-22 19:07:48 --> Database Driver Class Initialized
INFO - 2018-08-22 19:07:48 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:07:50 --> Config Class Initialized
INFO - 2018-08-22 19:07:50 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:07:50 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:07:50 --> Utf8 Class Initialized
INFO - 2018-08-22 19:07:50 --> URI Class Initialized
INFO - 2018-08-22 19:07:50 --> Router Class Initialized
INFO - 2018-08-22 19:07:50 --> Output Class Initialized
INFO - 2018-08-22 19:07:50 --> Security Class Initialized
DEBUG - 2018-08-22 19:07:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:07:50 --> CSRF cookie sent
INFO - 2018-08-22 19:07:50 --> Input Class Initialized
INFO - 2018-08-22 19:07:50 --> Language Class Initialized
INFO - 2018-08-22 19:07:50 --> Loader Class Initialized
INFO - 2018-08-22 19:07:50 --> Helper loaded: url_helper
INFO - 2018-08-22 19:07:50 --> Helper loaded: form_helper
INFO - 2018-08-22 19:07:50 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:07:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:07:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:07:50 --> User Agent Class Initialized
INFO - 2018-08-22 19:07:50 --> Controller Class Initialized
INFO - 2018-08-22 19:07:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:07:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:07:50 --> Pixel_Model class loaded
INFO - 2018-08-22 19:07:50 --> Database Driver Class Initialized
INFO - 2018-08-22 19:07:50 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:07:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:07:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:07:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:07:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:07:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:07:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:07:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-08-22 19:07:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:07:50 --> Final output sent to browser
DEBUG - 2018-08-22 19:07:50 --> Total execution time: 0.0378
INFO - 2018-08-22 19:08:04 --> Config Class Initialized
INFO - 2018-08-22 19:08:04 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:08:04 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:08:04 --> Utf8 Class Initialized
INFO - 2018-08-22 19:08:04 --> URI Class Initialized
INFO - 2018-08-22 19:08:04 --> Router Class Initialized
INFO - 2018-08-22 19:08:04 --> Output Class Initialized
INFO - 2018-08-22 19:08:04 --> Security Class Initialized
DEBUG - 2018-08-22 19:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:08:04 --> CSRF cookie sent
INFO - 2018-08-22 19:08:04 --> Input Class Initialized
INFO - 2018-08-22 19:08:04 --> Language Class Initialized
INFO - 2018-08-22 19:08:04 --> Loader Class Initialized
INFO - 2018-08-22 19:08:04 --> Helper loaded: url_helper
INFO - 2018-08-22 19:08:04 --> Helper loaded: form_helper
INFO - 2018-08-22 19:08:04 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:08:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:08:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:08:04 --> User Agent Class Initialized
INFO - 2018-08-22 19:08:04 --> Controller Class Initialized
INFO - 2018-08-22 19:08:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:08:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:08:04 --> Pixel_Model class loaded
INFO - 2018-08-22 19:08:04 --> Database Driver Class Initialized
INFO - 2018-08-22 19:08:04 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:08:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:08:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:08:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:08:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:08:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:08:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:08:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-08-22 19:08:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:08:04 --> Final output sent to browser
DEBUG - 2018-08-22 19:08:04 --> Total execution time: 0.0364
INFO - 2018-08-22 19:08:23 --> Config Class Initialized
INFO - 2018-08-22 19:08:23 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:08:23 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:08:23 --> Utf8 Class Initialized
INFO - 2018-08-22 19:08:23 --> URI Class Initialized
INFO - 2018-08-22 19:08:23 --> Router Class Initialized
INFO - 2018-08-22 19:08:23 --> Output Class Initialized
INFO - 2018-08-22 19:08:23 --> Security Class Initialized
DEBUG - 2018-08-22 19:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:08:23 --> CSRF cookie sent
INFO - 2018-08-22 19:08:23 --> CSRF token verified
INFO - 2018-08-22 19:08:23 --> Input Class Initialized
INFO - 2018-08-22 19:08:23 --> Language Class Initialized
INFO - 2018-08-22 19:08:23 --> Loader Class Initialized
INFO - 2018-08-22 19:08:23 --> Helper loaded: url_helper
INFO - 2018-08-22 19:08:23 --> Helper loaded: form_helper
INFO - 2018-08-22 19:08:23 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:08:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:08:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:08:23 --> User Agent Class Initialized
INFO - 2018-08-22 19:08:23 --> Controller Class Initialized
INFO - 2018-08-22 19:08:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:08:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:08:23 --> Pixel_Model class loaded
INFO - 2018-08-22 19:08:23 --> Database Driver Class Initialized
INFO - 2018-08-22 19:08:23 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:08:23 --> Database Driver Class Initialized
INFO - 2018-08-22 19:08:23 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:08:23 --> Config Class Initialized
INFO - 2018-08-22 19:08:23 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:08:23 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:08:23 --> Utf8 Class Initialized
INFO - 2018-08-22 19:08:23 --> URI Class Initialized
INFO - 2018-08-22 19:08:23 --> Router Class Initialized
INFO - 2018-08-22 19:08:23 --> Output Class Initialized
INFO - 2018-08-22 19:08:23 --> Security Class Initialized
DEBUG - 2018-08-22 19:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:08:23 --> CSRF cookie sent
INFO - 2018-08-22 19:08:23 --> Input Class Initialized
INFO - 2018-08-22 19:08:23 --> Language Class Initialized
INFO - 2018-08-22 19:08:23 --> Loader Class Initialized
INFO - 2018-08-22 19:08:23 --> Helper loaded: url_helper
INFO - 2018-08-22 19:08:23 --> Helper loaded: form_helper
INFO - 2018-08-22 19:08:23 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:08:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:08:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:08:23 --> User Agent Class Initialized
INFO - 2018-08-22 19:08:23 --> Controller Class Initialized
INFO - 2018-08-22 19:08:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:08:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:08:23 --> Pixel_Model class loaded
INFO - 2018-08-22 19:08:23 --> Database Driver Class Initialized
INFO - 2018-08-22 19:08:23 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:08:23 --> Database Driver Class Initialized
INFO - 2018-08-22 19:08:23 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:08:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:08:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:08:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:08:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:08:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:08:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:08:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-22 19:08:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:08:23 --> Final output sent to browser
DEBUG - 2018-08-22 19:08:23 --> Total execution time: 0.0585
INFO - 2018-08-22 19:08:27 --> Config Class Initialized
INFO - 2018-08-22 19:08:27 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:08:27 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:08:27 --> Utf8 Class Initialized
INFO - 2018-08-22 19:08:27 --> URI Class Initialized
INFO - 2018-08-22 19:08:27 --> Router Class Initialized
INFO - 2018-08-22 19:08:27 --> Output Class Initialized
INFO - 2018-08-22 19:08:27 --> Security Class Initialized
DEBUG - 2018-08-22 19:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:08:27 --> CSRF cookie sent
INFO - 2018-08-22 19:08:27 --> CSRF token verified
INFO - 2018-08-22 19:08:27 --> Input Class Initialized
INFO - 2018-08-22 19:08:27 --> Language Class Initialized
INFO - 2018-08-22 19:08:27 --> Loader Class Initialized
INFO - 2018-08-22 19:08:27 --> Helper loaded: url_helper
INFO - 2018-08-22 19:08:27 --> Helper loaded: form_helper
INFO - 2018-08-22 19:08:27 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:08:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:08:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:08:27 --> User Agent Class Initialized
INFO - 2018-08-22 19:08:27 --> Controller Class Initialized
INFO - 2018-08-22 19:08:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:08:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:08:27 --> Pixel_Model class loaded
INFO - 2018-08-22 19:08:27 --> Database Driver Class Initialized
INFO - 2018-08-22 19:08:27 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:08:27 --> Form Validation Class Initialized
INFO - 2018-08-22 19:08:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 19:08:27 --> Database Driver Class Initialized
INFO - 2018-08-22 19:08:27 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:08:27 --> Config Class Initialized
INFO - 2018-08-22 19:08:27 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:08:27 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:08:27 --> Utf8 Class Initialized
INFO - 2018-08-22 19:08:27 --> URI Class Initialized
INFO - 2018-08-22 19:08:27 --> Router Class Initialized
INFO - 2018-08-22 19:08:27 --> Output Class Initialized
INFO - 2018-08-22 19:08:27 --> Security Class Initialized
DEBUG - 2018-08-22 19:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:08:27 --> CSRF cookie sent
INFO - 2018-08-22 19:08:27 --> Input Class Initialized
INFO - 2018-08-22 19:08:27 --> Language Class Initialized
INFO - 2018-08-22 19:08:27 --> Loader Class Initialized
INFO - 2018-08-22 19:08:27 --> Helper loaded: url_helper
INFO - 2018-08-22 19:08:27 --> Helper loaded: form_helper
INFO - 2018-08-22 19:08:27 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:08:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:08:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:08:27 --> User Agent Class Initialized
INFO - 2018-08-22 19:08:27 --> Controller Class Initialized
INFO - 2018-08-22 19:08:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:08:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:08:27 --> Pixel_Model class loaded
INFO - 2018-08-22 19:08:27 --> Database Driver Class Initialized
INFO - 2018-08-22 19:08:27 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:08:27 --> Database Driver Class Initialized
INFO - 2018-08-22 19:08:27 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:08:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:08:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:08:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:08:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:08:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:08:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:08:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-08-22 19:08:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:08:27 --> Final output sent to browser
DEBUG - 2018-08-22 19:08:27 --> Total execution time: 0.0631
INFO - 2018-08-22 19:08:29 --> Config Class Initialized
INFO - 2018-08-22 19:08:29 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:08:29 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:08:29 --> Utf8 Class Initialized
INFO - 2018-08-22 19:08:29 --> URI Class Initialized
INFO - 2018-08-22 19:08:29 --> Router Class Initialized
INFO - 2018-08-22 19:08:29 --> Output Class Initialized
INFO - 2018-08-22 19:08:29 --> Security Class Initialized
DEBUG - 2018-08-22 19:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:08:29 --> CSRF cookie sent
INFO - 2018-08-22 19:08:29 --> CSRF token verified
INFO - 2018-08-22 19:08:29 --> Input Class Initialized
INFO - 2018-08-22 19:08:29 --> Language Class Initialized
INFO - 2018-08-22 19:08:29 --> Loader Class Initialized
INFO - 2018-08-22 19:08:29 --> Helper loaded: url_helper
INFO - 2018-08-22 19:08:29 --> Helper loaded: form_helper
INFO - 2018-08-22 19:08:29 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:08:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:08:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:08:29 --> User Agent Class Initialized
INFO - 2018-08-22 19:08:29 --> Controller Class Initialized
INFO - 2018-08-22 19:08:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:08:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:08:29 --> Pixel_Model class loaded
INFO - 2018-08-22 19:08:29 --> Database Driver Class Initialized
INFO - 2018-08-22 19:08:29 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:08:29 --> Form Validation Class Initialized
INFO - 2018-08-22 19:08:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 19:08:29 --> Database Driver Class Initialized
INFO - 2018-08-22 19:08:29 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:08:29 --> Config Class Initialized
INFO - 2018-08-22 19:08:29 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:08:29 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:08:29 --> Utf8 Class Initialized
INFO - 2018-08-22 19:08:29 --> URI Class Initialized
INFO - 2018-08-22 19:08:29 --> Router Class Initialized
INFO - 2018-08-22 19:08:29 --> Output Class Initialized
INFO - 2018-08-22 19:08:29 --> Security Class Initialized
DEBUG - 2018-08-22 19:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:08:29 --> CSRF cookie sent
INFO - 2018-08-22 19:08:29 --> Input Class Initialized
INFO - 2018-08-22 19:08:29 --> Language Class Initialized
INFO - 2018-08-22 19:08:29 --> Loader Class Initialized
INFO - 2018-08-22 19:08:29 --> Helper loaded: url_helper
INFO - 2018-08-22 19:08:29 --> Helper loaded: form_helper
INFO - 2018-08-22 19:08:29 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:08:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:08:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:08:29 --> User Agent Class Initialized
INFO - 2018-08-22 19:08:29 --> Controller Class Initialized
INFO - 2018-08-22 19:08:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:08:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:08:29 --> Pixel_Model class loaded
INFO - 2018-08-22 19:08:29 --> Database Driver Class Initialized
INFO - 2018-08-22 19:08:29 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:08:29 --> Database Driver Class Initialized
INFO - 2018-08-22 19:08:29 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:08:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:08:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:08:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-08-22 19:08:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:08:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:08:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:08:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:08:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-08-22 19:08:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:08:29 --> Final output sent to browser
DEBUG - 2018-08-22 19:08:29 --> Total execution time: 0.0496
INFO - 2018-08-22 19:08:33 --> Config Class Initialized
INFO - 2018-08-22 19:08:33 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:08:33 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:08:33 --> Utf8 Class Initialized
INFO - 2018-08-22 19:08:33 --> URI Class Initialized
INFO - 2018-08-22 19:08:33 --> Router Class Initialized
INFO - 2018-08-22 19:08:33 --> Output Class Initialized
INFO - 2018-08-22 19:08:33 --> Security Class Initialized
DEBUG - 2018-08-22 19:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:08:33 --> CSRF cookie sent
INFO - 2018-08-22 19:08:33 --> CSRF token verified
INFO - 2018-08-22 19:08:33 --> Input Class Initialized
INFO - 2018-08-22 19:08:33 --> Language Class Initialized
INFO - 2018-08-22 19:08:33 --> Loader Class Initialized
INFO - 2018-08-22 19:08:33 --> Helper loaded: url_helper
INFO - 2018-08-22 19:08:33 --> Helper loaded: form_helper
INFO - 2018-08-22 19:08:33 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:08:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:08:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:08:33 --> User Agent Class Initialized
INFO - 2018-08-22 19:08:33 --> Controller Class Initialized
INFO - 2018-08-22 19:08:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:08:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:08:33 --> Pixel_Model class loaded
INFO - 2018-08-22 19:08:33 --> Database Driver Class Initialized
INFO - 2018-08-22 19:08:33 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:08:33 --> Form Validation Class Initialized
INFO - 2018-08-22 19:08:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 19:08:33 --> Database Driver Class Initialized
INFO - 2018-08-22 19:08:33 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:08:33 --> Config Class Initialized
INFO - 2018-08-22 19:08:33 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:08:33 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:08:33 --> Utf8 Class Initialized
INFO - 2018-08-22 19:08:33 --> URI Class Initialized
INFO - 2018-08-22 19:08:33 --> Router Class Initialized
INFO - 2018-08-22 19:08:33 --> Output Class Initialized
INFO - 2018-08-22 19:08:33 --> Security Class Initialized
DEBUG - 2018-08-22 19:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:08:33 --> CSRF cookie sent
INFO - 2018-08-22 19:08:33 --> Input Class Initialized
INFO - 2018-08-22 19:08:33 --> Language Class Initialized
INFO - 2018-08-22 19:08:33 --> Loader Class Initialized
INFO - 2018-08-22 19:08:33 --> Helper loaded: url_helper
INFO - 2018-08-22 19:08:33 --> Helper loaded: form_helper
INFO - 2018-08-22 19:08:33 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:08:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:08:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:08:33 --> User Agent Class Initialized
INFO - 2018-08-22 19:08:33 --> Controller Class Initialized
INFO - 2018-08-22 19:08:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:08:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:08:33 --> Pixel_Model class loaded
INFO - 2018-08-22 19:08:33 --> Database Driver Class Initialized
INFO - 2018-08-22 19:08:33 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:08:33 --> Database Driver Class Initialized
INFO - 2018-08-22 19:08:33 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:08:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:08:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:08:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:08:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:08:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:08:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:08:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-08-22 19:08:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:08:33 --> Final output sent to browser
DEBUG - 2018-08-22 19:08:33 --> Total execution time: 0.0422
INFO - 2018-08-22 19:09:13 --> Config Class Initialized
INFO - 2018-08-22 19:09:13 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:09:13 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:09:13 --> Utf8 Class Initialized
INFO - 2018-08-22 19:09:13 --> URI Class Initialized
DEBUG - 2018-08-22 19:09:13 --> No URI present. Default controller set.
INFO - 2018-08-22 19:09:13 --> Router Class Initialized
INFO - 2018-08-22 19:09:13 --> Output Class Initialized
INFO - 2018-08-22 19:09:13 --> Security Class Initialized
DEBUG - 2018-08-22 19:09:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:09:13 --> CSRF cookie sent
INFO - 2018-08-22 19:09:13 --> Input Class Initialized
INFO - 2018-08-22 19:09:13 --> Language Class Initialized
INFO - 2018-08-22 19:09:13 --> Loader Class Initialized
INFO - 2018-08-22 19:09:13 --> Helper loaded: url_helper
INFO - 2018-08-22 19:09:13 --> Helper loaded: form_helper
INFO - 2018-08-22 19:09:13 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:09:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:09:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:09:13 --> User Agent Class Initialized
INFO - 2018-08-22 19:09:13 --> Controller Class Initialized
INFO - 2018-08-22 19:09:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:09:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:09:13 --> Pixel_Model class loaded
INFO - 2018-08-22 19:09:13 --> Database Driver Class Initialized
INFO - 2018-08-22 19:09:13 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:09:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:09:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:09:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-22 19:09:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:09:13 --> Final output sent to browser
DEBUG - 2018-08-22 19:09:13 --> Total execution time: 0.0420
INFO - 2018-08-22 19:09:28 --> Config Class Initialized
INFO - 2018-08-22 19:09:28 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:09:28 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:09:28 --> Utf8 Class Initialized
INFO - 2018-08-22 19:09:28 --> URI Class Initialized
INFO - 2018-08-22 19:09:28 --> Router Class Initialized
INFO - 2018-08-22 19:09:28 --> Output Class Initialized
INFO - 2018-08-22 19:09:28 --> Security Class Initialized
DEBUG - 2018-08-22 19:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:09:28 --> CSRF cookie sent
INFO - 2018-08-22 19:09:28 --> Input Class Initialized
INFO - 2018-08-22 19:09:28 --> Language Class Initialized
INFO - 2018-08-22 19:09:28 --> Loader Class Initialized
INFO - 2018-08-22 19:09:28 --> Helper loaded: url_helper
INFO - 2018-08-22 19:09:28 --> Helper loaded: form_helper
INFO - 2018-08-22 19:09:28 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:09:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:09:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:09:28 --> User Agent Class Initialized
INFO - 2018-08-22 19:09:28 --> Controller Class Initialized
INFO - 2018-08-22 19:09:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:09:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:09:28 --> Pixel_Model class loaded
INFO - 2018-08-22 19:09:28 --> Database Driver Class Initialized
INFO - 2018-08-22 19:09:28 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:09:28 --> Database Driver Class Initialized
INFO - 2018-08-22 19:09:28 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:09:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:09:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:09:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-08-22 19:09:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:09:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:09:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:09:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:09:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-08-22 19:09:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:09:28 --> Final output sent to browser
DEBUG - 2018-08-22 19:09:28 --> Total execution time: 0.0399
INFO - 2018-08-22 19:09:30 --> Config Class Initialized
INFO - 2018-08-22 19:09:30 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:09:30 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:09:30 --> Utf8 Class Initialized
INFO - 2018-08-22 19:09:30 --> URI Class Initialized
INFO - 2018-08-22 19:09:30 --> Router Class Initialized
INFO - 2018-08-22 19:09:30 --> Output Class Initialized
INFO - 2018-08-22 19:09:30 --> Security Class Initialized
DEBUG - 2018-08-22 19:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:09:30 --> CSRF cookie sent
INFO - 2018-08-22 19:09:30 --> Input Class Initialized
INFO - 2018-08-22 19:09:30 --> Language Class Initialized
INFO - 2018-08-22 19:09:30 --> Loader Class Initialized
INFO - 2018-08-22 19:09:30 --> Helper loaded: url_helper
INFO - 2018-08-22 19:09:30 --> Helper loaded: form_helper
INFO - 2018-08-22 19:09:30 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:09:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:09:30 --> User Agent Class Initialized
INFO - 2018-08-22 19:09:30 --> Controller Class Initialized
INFO - 2018-08-22 19:09:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:09:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:09:30 --> Pixel_Model class loaded
INFO - 2018-08-22 19:09:30 --> Database Driver Class Initialized
INFO - 2018-08-22 19:09:30 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:09:30 --> Database Driver Class Initialized
INFO - 2018-08-22 19:09:30 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:09:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:09:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:09:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:09:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:09:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:09:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:09:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-08-22 19:09:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:09:30 --> Final output sent to browser
DEBUG - 2018-08-22 19:09:30 --> Total execution time: 0.0599
INFO - 2018-08-22 19:09:32 --> Config Class Initialized
INFO - 2018-08-22 19:09:32 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:09:32 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:09:32 --> Utf8 Class Initialized
INFO - 2018-08-22 19:09:32 --> URI Class Initialized
INFO - 2018-08-22 19:09:32 --> Router Class Initialized
INFO - 2018-08-22 19:09:32 --> Output Class Initialized
INFO - 2018-08-22 19:09:32 --> Security Class Initialized
DEBUG - 2018-08-22 19:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:09:32 --> CSRF cookie sent
INFO - 2018-08-22 19:09:32 --> Input Class Initialized
INFO - 2018-08-22 19:09:32 --> Language Class Initialized
INFO - 2018-08-22 19:09:32 --> Loader Class Initialized
INFO - 2018-08-22 19:09:32 --> Helper loaded: url_helper
INFO - 2018-08-22 19:09:32 --> Helper loaded: form_helper
INFO - 2018-08-22 19:09:32 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:09:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:09:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:09:32 --> User Agent Class Initialized
INFO - 2018-08-22 19:09:32 --> Controller Class Initialized
INFO - 2018-08-22 19:09:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:09:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:09:32 --> Pixel_Model class loaded
INFO - 2018-08-22 19:09:32 --> Database Driver Class Initialized
INFO - 2018-08-22 19:09:32 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:09:32 --> Database Driver Class Initialized
INFO - 2018-08-22 19:09:32 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:09:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:09:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:09:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:09:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:09:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:09:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:09:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-22 19:09:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:09:32 --> Final output sent to browser
DEBUG - 2018-08-22 19:09:32 --> Total execution time: 0.0446
INFO - 2018-08-22 19:09:33 --> Config Class Initialized
INFO - 2018-08-22 19:09:33 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:09:33 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:09:33 --> Utf8 Class Initialized
INFO - 2018-08-22 19:09:33 --> URI Class Initialized
INFO - 2018-08-22 19:09:33 --> Router Class Initialized
INFO - 2018-08-22 19:09:33 --> Output Class Initialized
INFO - 2018-08-22 19:09:33 --> Security Class Initialized
DEBUG - 2018-08-22 19:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:09:33 --> CSRF cookie sent
INFO - 2018-08-22 19:09:33 --> Input Class Initialized
INFO - 2018-08-22 19:09:33 --> Language Class Initialized
INFO - 2018-08-22 19:09:33 --> Loader Class Initialized
INFO - 2018-08-22 19:09:33 --> Helper loaded: url_helper
INFO - 2018-08-22 19:09:33 --> Helper loaded: form_helper
INFO - 2018-08-22 19:09:33 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:09:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:09:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:09:33 --> User Agent Class Initialized
INFO - 2018-08-22 19:09:33 --> Controller Class Initialized
INFO - 2018-08-22 19:09:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:09:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:09:33 --> Pixel_Model class loaded
INFO - 2018-08-22 19:09:33 --> Database Driver Class Initialized
INFO - 2018-08-22 19:09:33 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:09:33 --> Database Driver Class Initialized
INFO - 2018-08-22 19:09:33 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:09:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:09:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:09:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:09:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:09:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:09:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:09:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-08-22 19:09:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:09:33 --> Final output sent to browser
DEBUG - 2018-08-22 19:09:33 --> Total execution time: 0.0452
INFO - 2018-08-22 19:09:42 --> Config Class Initialized
INFO - 2018-08-22 19:09:42 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:09:42 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:09:42 --> Utf8 Class Initialized
INFO - 2018-08-22 19:09:42 --> URI Class Initialized
INFO - 2018-08-22 19:09:42 --> Router Class Initialized
INFO - 2018-08-22 19:09:42 --> Output Class Initialized
INFO - 2018-08-22 19:09:42 --> Security Class Initialized
DEBUG - 2018-08-22 19:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:09:42 --> CSRF cookie sent
INFO - 2018-08-22 19:09:42 --> Input Class Initialized
INFO - 2018-08-22 19:09:42 --> Language Class Initialized
INFO - 2018-08-22 19:09:42 --> Loader Class Initialized
INFO - 2018-08-22 19:09:42 --> Helper loaded: url_helper
INFO - 2018-08-22 19:09:42 --> Helper loaded: form_helper
INFO - 2018-08-22 19:09:42 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:09:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:09:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:09:42 --> User Agent Class Initialized
INFO - 2018-08-22 19:09:42 --> Controller Class Initialized
INFO - 2018-08-22 19:09:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:09:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:09:42 --> Pixel_Model class loaded
INFO - 2018-08-22 19:09:42 --> Database Driver Class Initialized
INFO - 2018-08-22 19:09:42 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:09:42 --> Database Driver Class Initialized
INFO - 2018-08-22 19:09:42 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:09:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:09:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:09:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-08-22 19:09:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:09:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:09:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:09:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:09:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-08-22 19:09:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:09:42 --> Final output sent to browser
DEBUG - 2018-08-22 19:09:42 --> Total execution time: 0.0393
INFO - 2018-08-22 19:10:07 --> Config Class Initialized
INFO - 2018-08-22 19:10:07 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:10:07 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:10:07 --> Utf8 Class Initialized
INFO - 2018-08-22 19:10:07 --> URI Class Initialized
INFO - 2018-08-22 19:10:07 --> Router Class Initialized
INFO - 2018-08-22 19:10:07 --> Output Class Initialized
INFO - 2018-08-22 19:10:07 --> Security Class Initialized
DEBUG - 2018-08-22 19:10:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:10:07 --> CSRF cookie sent
INFO - 2018-08-22 19:10:07 --> CSRF token verified
INFO - 2018-08-22 19:10:07 --> Input Class Initialized
INFO - 2018-08-22 19:10:07 --> Language Class Initialized
INFO - 2018-08-22 19:10:07 --> Loader Class Initialized
INFO - 2018-08-22 19:10:07 --> Helper loaded: url_helper
INFO - 2018-08-22 19:10:07 --> Helper loaded: form_helper
INFO - 2018-08-22 19:10:07 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:10:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:10:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:10:07 --> User Agent Class Initialized
INFO - 2018-08-22 19:10:07 --> Controller Class Initialized
INFO - 2018-08-22 19:10:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:10:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:10:07 --> Pixel_Model class loaded
INFO - 2018-08-22 19:10:07 --> Database Driver Class Initialized
INFO - 2018-08-22 19:10:07 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:10:07 --> Form Validation Class Initialized
INFO - 2018-08-22 19:10:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 19:10:07 --> Database Driver Class Initialized
INFO - 2018-08-22 19:10:07 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:10:07 --> Config Class Initialized
INFO - 2018-08-22 19:10:07 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:10:07 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:10:07 --> Utf8 Class Initialized
INFO - 2018-08-22 19:10:07 --> URI Class Initialized
INFO - 2018-08-22 19:10:07 --> Router Class Initialized
INFO - 2018-08-22 19:10:07 --> Output Class Initialized
INFO - 2018-08-22 19:10:07 --> Security Class Initialized
DEBUG - 2018-08-22 19:10:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:10:07 --> CSRF cookie sent
INFO - 2018-08-22 19:10:07 --> Input Class Initialized
INFO - 2018-08-22 19:10:07 --> Language Class Initialized
INFO - 2018-08-22 19:10:07 --> Loader Class Initialized
INFO - 2018-08-22 19:10:07 --> Helper loaded: url_helper
INFO - 2018-08-22 19:10:07 --> Helper loaded: form_helper
INFO - 2018-08-22 19:10:07 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:10:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:10:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:10:07 --> User Agent Class Initialized
INFO - 2018-08-22 19:10:07 --> Controller Class Initialized
INFO - 2018-08-22 19:10:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:10:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:10:07 --> Pixel_Model class loaded
INFO - 2018-08-22 19:10:07 --> Database Driver Class Initialized
INFO - 2018-08-22 19:10:07 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:10:07 --> Database Driver Class Initialized
INFO - 2018-08-22 19:10:07 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:10:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:10:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:10:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:10:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:10:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:10:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:10:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-08-22 19:10:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:10:07 --> Final output sent to browser
DEBUG - 2018-08-22 19:10:07 --> Total execution time: 0.0407
INFO - 2018-08-22 19:10:26 --> Config Class Initialized
INFO - 2018-08-22 19:10:26 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:10:26 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:10:26 --> Utf8 Class Initialized
INFO - 2018-08-22 19:10:26 --> URI Class Initialized
INFO - 2018-08-22 19:10:26 --> Router Class Initialized
INFO - 2018-08-22 19:10:26 --> Output Class Initialized
INFO - 2018-08-22 19:10:26 --> Security Class Initialized
DEBUG - 2018-08-22 19:10:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:10:26 --> CSRF cookie sent
INFO - 2018-08-22 19:10:26 --> CSRF token verified
INFO - 2018-08-22 19:10:26 --> Input Class Initialized
INFO - 2018-08-22 19:10:26 --> Language Class Initialized
INFO - 2018-08-22 19:10:26 --> Loader Class Initialized
INFO - 2018-08-22 19:10:26 --> Helper loaded: url_helper
INFO - 2018-08-22 19:10:26 --> Helper loaded: form_helper
INFO - 2018-08-22 19:10:26 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:10:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:10:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:10:26 --> User Agent Class Initialized
INFO - 2018-08-22 19:10:26 --> Controller Class Initialized
INFO - 2018-08-22 19:10:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:10:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:10:26 --> Pixel_Model class loaded
INFO - 2018-08-22 19:10:26 --> Database Driver Class Initialized
INFO - 2018-08-22 19:10:26 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:10:26 --> Form Validation Class Initialized
INFO - 2018-08-22 19:10:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 19:10:26 --> Database Driver Class Initialized
INFO - 2018-08-22 19:10:26 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:10:26 --> Config Class Initialized
INFO - 2018-08-22 19:10:26 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:10:26 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:10:26 --> Utf8 Class Initialized
INFO - 2018-08-22 19:10:26 --> URI Class Initialized
INFO - 2018-08-22 19:10:26 --> Router Class Initialized
INFO - 2018-08-22 19:10:26 --> Output Class Initialized
INFO - 2018-08-22 19:10:26 --> Security Class Initialized
DEBUG - 2018-08-22 19:10:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:10:26 --> CSRF cookie sent
INFO - 2018-08-22 19:10:26 --> Input Class Initialized
INFO - 2018-08-22 19:10:26 --> Language Class Initialized
INFO - 2018-08-22 19:10:26 --> Loader Class Initialized
INFO - 2018-08-22 19:10:26 --> Helper loaded: url_helper
INFO - 2018-08-22 19:10:26 --> Helper loaded: form_helper
INFO - 2018-08-22 19:10:26 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:10:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:10:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:10:26 --> User Agent Class Initialized
INFO - 2018-08-22 19:10:26 --> Controller Class Initialized
INFO - 2018-08-22 19:10:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:10:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:10:26 --> Pixel_Model class loaded
INFO - 2018-08-22 19:10:26 --> Database Driver Class Initialized
INFO - 2018-08-22 19:10:26 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:10:26 --> Database Driver Class Initialized
INFO - 2018-08-22 19:10:26 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:10:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:10:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:10:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:10:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:10:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:10:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:10:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-08-22 19:10:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:10:26 --> Final output sent to browser
DEBUG - 2018-08-22 19:10:26 --> Total execution time: 0.0438
INFO - 2018-08-22 19:10:42 --> Config Class Initialized
INFO - 2018-08-22 19:10:42 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:10:42 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:10:42 --> Utf8 Class Initialized
INFO - 2018-08-22 19:10:42 --> URI Class Initialized
INFO - 2018-08-22 19:10:42 --> Router Class Initialized
INFO - 2018-08-22 19:10:42 --> Output Class Initialized
INFO - 2018-08-22 19:10:42 --> Security Class Initialized
DEBUG - 2018-08-22 19:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:10:42 --> CSRF cookie sent
INFO - 2018-08-22 19:10:42 --> CSRF token verified
INFO - 2018-08-22 19:10:42 --> Input Class Initialized
INFO - 2018-08-22 19:10:42 --> Language Class Initialized
INFO - 2018-08-22 19:10:42 --> Loader Class Initialized
INFO - 2018-08-22 19:10:42 --> Helper loaded: url_helper
INFO - 2018-08-22 19:10:42 --> Helper loaded: form_helper
INFO - 2018-08-22 19:10:42 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:10:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:10:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:10:42 --> User Agent Class Initialized
INFO - 2018-08-22 19:10:42 --> Controller Class Initialized
INFO - 2018-08-22 19:10:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:10:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:10:42 --> Pixel_Model class loaded
INFO - 2018-08-22 19:10:42 --> Database Driver Class Initialized
INFO - 2018-08-22 19:10:42 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:10:42 --> Form Validation Class Initialized
INFO - 2018-08-22 19:10:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 19:10:42 --> Database Driver Class Initialized
INFO - 2018-08-22 19:10:42 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:10:42 --> Config Class Initialized
INFO - 2018-08-22 19:10:42 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:10:42 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:10:42 --> Utf8 Class Initialized
INFO - 2018-08-22 19:10:42 --> URI Class Initialized
INFO - 2018-08-22 19:10:42 --> Router Class Initialized
INFO - 2018-08-22 19:10:42 --> Output Class Initialized
INFO - 2018-08-22 19:10:42 --> Security Class Initialized
DEBUG - 2018-08-22 19:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:10:42 --> CSRF cookie sent
INFO - 2018-08-22 19:10:42 --> Input Class Initialized
INFO - 2018-08-22 19:10:42 --> Language Class Initialized
INFO - 2018-08-22 19:10:42 --> Loader Class Initialized
INFO - 2018-08-22 19:10:42 --> Helper loaded: url_helper
INFO - 2018-08-22 19:10:42 --> Helper loaded: form_helper
INFO - 2018-08-22 19:10:42 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:10:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:10:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:10:42 --> User Agent Class Initialized
INFO - 2018-08-22 19:10:42 --> Controller Class Initialized
INFO - 2018-08-22 19:10:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:10:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:10:42 --> Pixel_Model class loaded
INFO - 2018-08-22 19:10:42 --> Database Driver Class Initialized
INFO - 2018-08-22 19:10:42 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:10:42 --> Database Driver Class Initialized
INFO - 2018-08-22 19:10:42 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:10:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:10:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:10:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:10:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:10:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:10:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:10:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-08-22 19:10:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:10:42 --> Final output sent to browser
DEBUG - 2018-08-22 19:10:42 --> Total execution time: 0.0372
INFO - 2018-08-22 19:13:15 --> Config Class Initialized
INFO - 2018-08-22 19:13:15 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:13:15 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:13:15 --> Utf8 Class Initialized
INFO - 2018-08-22 19:13:15 --> URI Class Initialized
INFO - 2018-08-22 19:13:15 --> Router Class Initialized
INFO - 2018-08-22 19:13:15 --> Output Class Initialized
INFO - 2018-08-22 19:13:15 --> Security Class Initialized
DEBUG - 2018-08-22 19:13:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:13:15 --> CSRF cookie sent
INFO - 2018-08-22 19:13:15 --> CSRF token verified
INFO - 2018-08-22 19:13:15 --> Input Class Initialized
INFO - 2018-08-22 19:13:15 --> Language Class Initialized
INFO - 2018-08-22 19:13:15 --> Loader Class Initialized
INFO - 2018-08-22 19:13:15 --> Helper loaded: url_helper
INFO - 2018-08-22 19:13:15 --> Helper loaded: form_helper
INFO - 2018-08-22 19:13:15 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:13:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:13:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:13:15 --> User Agent Class Initialized
INFO - 2018-08-22 19:13:15 --> Controller Class Initialized
INFO - 2018-08-22 19:13:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:13:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:13:15 --> Pixel_Model class loaded
INFO - 2018-08-22 19:13:15 --> Database Driver Class Initialized
INFO - 2018-08-22 19:13:15 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:13:15 --> Form Validation Class Initialized
INFO - 2018-08-22 19:13:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 19:13:15 --> Database Driver Class Initialized
INFO - 2018-08-22 19:13:15 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:13:16 --> Config Class Initialized
INFO - 2018-08-22 19:13:16 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:13:16 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:13:16 --> Utf8 Class Initialized
INFO - 2018-08-22 19:13:16 --> URI Class Initialized
INFO - 2018-08-22 19:13:16 --> Router Class Initialized
INFO - 2018-08-22 19:13:16 --> Output Class Initialized
INFO - 2018-08-22 19:13:16 --> Security Class Initialized
DEBUG - 2018-08-22 19:13:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:13:16 --> CSRF cookie sent
INFO - 2018-08-22 19:13:16 --> Input Class Initialized
INFO - 2018-08-22 19:13:16 --> Language Class Initialized
INFO - 2018-08-22 19:13:16 --> Loader Class Initialized
INFO - 2018-08-22 19:13:16 --> Helper loaded: url_helper
INFO - 2018-08-22 19:13:16 --> Helper loaded: form_helper
INFO - 2018-08-22 19:13:16 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:13:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:13:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:13:16 --> User Agent Class Initialized
INFO - 2018-08-22 19:13:16 --> Controller Class Initialized
INFO - 2018-08-22 19:13:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:13:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:13:16 --> Pixel_Model class loaded
INFO - 2018-08-22 19:13:16 --> Database Driver Class Initialized
INFO - 2018-08-22 19:13:16 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:13:16 --> Database Driver Class Initialized
INFO - 2018-08-22 19:13:16 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:13:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:13:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:13:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:13:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:13:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:13:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:13:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-08-22 19:13:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:13:16 --> Final output sent to browser
DEBUG - 2018-08-22 19:13:16 --> Total execution time: 0.0677
INFO - 2018-08-22 19:13:34 --> Config Class Initialized
INFO - 2018-08-22 19:13:34 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:13:34 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:13:34 --> Utf8 Class Initialized
INFO - 2018-08-22 19:13:34 --> URI Class Initialized
INFO - 2018-08-22 19:13:34 --> Router Class Initialized
INFO - 2018-08-22 19:13:34 --> Output Class Initialized
INFO - 2018-08-22 19:13:34 --> Security Class Initialized
DEBUG - 2018-08-22 19:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:13:34 --> CSRF cookie sent
INFO - 2018-08-22 19:13:34 --> Input Class Initialized
INFO - 2018-08-22 19:13:34 --> Language Class Initialized
INFO - 2018-08-22 19:13:34 --> Loader Class Initialized
INFO - 2018-08-22 19:13:34 --> Helper loaded: url_helper
INFO - 2018-08-22 19:13:34 --> Helper loaded: form_helper
INFO - 2018-08-22 19:13:34 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:13:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:13:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:13:34 --> User Agent Class Initialized
INFO - 2018-08-22 19:13:34 --> Controller Class Initialized
INFO - 2018-08-22 19:13:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:13:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:13:34 --> Pixel_Model class loaded
INFO - 2018-08-22 19:13:34 --> Database Driver Class Initialized
INFO - 2018-08-22 19:13:34 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:13:34 --> Database Driver Class Initialized
INFO - 2018-08-22 19:13:34 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:13:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:13:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:13:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:13:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:13:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:13:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:13:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/wedding_gifit_value.php
INFO - 2018-08-22 19:13:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:13:34 --> Final output sent to browser
DEBUG - 2018-08-22 19:13:34 --> Total execution time: 0.0408
INFO - 2018-08-22 19:14:04 --> Config Class Initialized
INFO - 2018-08-22 19:14:04 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:14:04 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:14:04 --> Utf8 Class Initialized
INFO - 2018-08-22 19:14:04 --> URI Class Initialized
INFO - 2018-08-22 19:14:04 --> Router Class Initialized
INFO - 2018-08-22 19:14:04 --> Output Class Initialized
INFO - 2018-08-22 19:14:04 --> Security Class Initialized
DEBUG - 2018-08-22 19:14:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:14:04 --> CSRF cookie sent
INFO - 2018-08-22 19:14:04 --> Input Class Initialized
INFO - 2018-08-22 19:14:04 --> Language Class Initialized
INFO - 2018-08-22 19:14:04 --> Loader Class Initialized
INFO - 2018-08-22 19:14:04 --> Helper loaded: url_helper
INFO - 2018-08-22 19:14:04 --> Helper loaded: form_helper
INFO - 2018-08-22 19:14:04 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:14:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:14:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:14:04 --> User Agent Class Initialized
INFO - 2018-08-22 19:14:04 --> Controller Class Initialized
INFO - 2018-08-22 19:14:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:14:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:14:04 --> Pixel_Model class loaded
INFO - 2018-08-22 19:14:04 --> Database Driver Class Initialized
INFO - 2018-08-22 19:14:04 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:14:04 --> Database Driver Class Initialized
INFO - 2018-08-22 19:14:04 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:14:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:14:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 19:14:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:14:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:14:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:14:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:14:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:14:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-08-22 19:14:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:14:04 --> Final output sent to browser
DEBUG - 2018-08-22 19:14:04 --> Total execution time: 0.0461
INFO - 2018-08-22 19:14:16 --> Config Class Initialized
INFO - 2018-08-22 19:14:16 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:14:16 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:14:16 --> Utf8 Class Initialized
INFO - 2018-08-22 19:14:16 --> URI Class Initialized
INFO - 2018-08-22 19:14:16 --> Router Class Initialized
INFO - 2018-08-22 19:14:16 --> Output Class Initialized
INFO - 2018-08-22 19:14:16 --> Security Class Initialized
DEBUG - 2018-08-22 19:14:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:14:16 --> CSRF cookie sent
INFO - 2018-08-22 19:14:16 --> CSRF token verified
INFO - 2018-08-22 19:14:16 --> Input Class Initialized
INFO - 2018-08-22 19:14:16 --> Language Class Initialized
INFO - 2018-08-22 19:14:16 --> Loader Class Initialized
INFO - 2018-08-22 19:14:16 --> Helper loaded: url_helper
INFO - 2018-08-22 19:14:16 --> Helper loaded: form_helper
INFO - 2018-08-22 19:14:16 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:14:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:14:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:14:16 --> User Agent Class Initialized
INFO - 2018-08-22 19:14:16 --> Controller Class Initialized
INFO - 2018-08-22 19:14:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:14:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:14:16 --> Pixel_Model class loaded
INFO - 2018-08-22 19:14:16 --> Database Driver Class Initialized
INFO - 2018-08-22 19:14:16 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:14:16 --> Form Validation Class Initialized
INFO - 2018-08-22 19:14:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 19:14:16 --> Database Driver Class Initialized
INFO - 2018-08-22 19:14:16 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:14:16 --> Config Class Initialized
INFO - 2018-08-22 19:14:16 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:14:16 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:14:16 --> Utf8 Class Initialized
INFO - 2018-08-22 19:14:16 --> URI Class Initialized
INFO - 2018-08-22 19:14:16 --> Router Class Initialized
INFO - 2018-08-22 19:14:16 --> Output Class Initialized
INFO - 2018-08-22 19:14:16 --> Security Class Initialized
DEBUG - 2018-08-22 19:14:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:14:16 --> CSRF cookie sent
INFO - 2018-08-22 19:14:16 --> Input Class Initialized
INFO - 2018-08-22 19:14:16 --> Language Class Initialized
INFO - 2018-08-22 19:14:16 --> Loader Class Initialized
INFO - 2018-08-22 19:14:16 --> Helper loaded: url_helper
INFO - 2018-08-22 19:14:16 --> Helper loaded: form_helper
INFO - 2018-08-22 19:14:16 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:14:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:14:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:14:16 --> User Agent Class Initialized
INFO - 2018-08-22 19:14:16 --> Controller Class Initialized
INFO - 2018-08-22 19:14:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:14:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:14:16 --> Pixel_Model class loaded
INFO - 2018-08-22 19:14:16 --> Database Driver Class Initialized
INFO - 2018-08-22 19:14:16 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:14:16 --> Database Driver Class Initialized
INFO - 2018-08-22 19:14:16 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:14:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:14:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:14:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:14:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:14:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:14:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:14:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_title.php
INFO - 2018-08-22 19:14:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:14:16 --> Final output sent to browser
DEBUG - 2018-08-22 19:14:16 --> Total execution time: 0.0572
INFO - 2018-08-22 19:14:17 --> Config Class Initialized
INFO - 2018-08-22 19:14:17 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:14:17 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:14:17 --> Utf8 Class Initialized
INFO - 2018-08-22 19:14:17 --> URI Class Initialized
INFO - 2018-08-22 19:14:17 --> Router Class Initialized
INFO - 2018-08-22 19:14:17 --> Output Class Initialized
INFO - 2018-08-22 19:14:17 --> Security Class Initialized
DEBUG - 2018-08-22 19:14:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:14:17 --> CSRF cookie sent
INFO - 2018-08-22 19:14:17 --> Input Class Initialized
INFO - 2018-08-22 19:14:17 --> Language Class Initialized
INFO - 2018-08-22 19:14:17 --> Loader Class Initialized
INFO - 2018-08-22 19:14:17 --> Helper loaded: url_helper
INFO - 2018-08-22 19:14:17 --> Helper loaded: form_helper
INFO - 2018-08-22 19:14:17 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:14:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:14:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:14:17 --> User Agent Class Initialized
INFO - 2018-08-22 19:14:17 --> Controller Class Initialized
INFO - 2018-08-22 19:14:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:14:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:14:17 --> Pixel_Model class loaded
INFO - 2018-08-22 19:14:17 --> Database Driver Class Initialized
INFO - 2018-08-22 19:14:17 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:14:17 --> Database Driver Class Initialized
INFO - 2018-08-22 19:14:17 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:14:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:14:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 19:14:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:14:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:14:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:14:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:14:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:14:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_title.php
INFO - 2018-08-22 19:14:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:14:17 --> Final output sent to browser
DEBUG - 2018-08-22 19:14:17 --> Total execution time: 0.0400
INFO - 2018-08-22 19:14:21 --> Config Class Initialized
INFO - 2018-08-22 19:14:21 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:14:21 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:14:21 --> Utf8 Class Initialized
INFO - 2018-08-22 19:14:21 --> URI Class Initialized
INFO - 2018-08-22 19:14:21 --> Router Class Initialized
INFO - 2018-08-22 19:14:21 --> Output Class Initialized
INFO - 2018-08-22 19:14:21 --> Security Class Initialized
DEBUG - 2018-08-22 19:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:14:21 --> CSRF cookie sent
INFO - 2018-08-22 19:14:21 --> Input Class Initialized
INFO - 2018-08-22 19:14:21 --> Language Class Initialized
INFO - 2018-08-22 19:14:21 --> Loader Class Initialized
INFO - 2018-08-22 19:14:21 --> Helper loaded: url_helper
INFO - 2018-08-22 19:14:21 --> Helper loaded: form_helper
INFO - 2018-08-22 19:14:21 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:14:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:14:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:14:21 --> User Agent Class Initialized
INFO - 2018-08-22 19:14:21 --> Controller Class Initialized
INFO - 2018-08-22 19:14:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:14:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:14:21 --> Pixel_Model class loaded
INFO - 2018-08-22 19:14:21 --> Database Driver Class Initialized
INFO - 2018-08-22 19:14:21 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:14:21 --> Database Driver Class Initialized
INFO - 2018-08-22 19:14:21 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:14:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:14:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 19:14:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:14:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:14:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:14:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:14:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:14:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-08-22 19:14:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:14:21 --> Final output sent to browser
DEBUG - 2018-08-22 19:14:21 --> Total execution time: 0.0598
INFO - 2018-08-22 19:14:29 --> Config Class Initialized
INFO - 2018-08-22 19:14:29 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:14:29 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:14:29 --> Utf8 Class Initialized
INFO - 2018-08-22 19:14:29 --> URI Class Initialized
INFO - 2018-08-22 19:14:29 --> Router Class Initialized
INFO - 2018-08-22 19:14:29 --> Output Class Initialized
INFO - 2018-08-22 19:14:29 --> Security Class Initialized
DEBUG - 2018-08-22 19:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:14:29 --> CSRF cookie sent
INFO - 2018-08-22 19:14:29 --> CSRF token verified
INFO - 2018-08-22 19:14:29 --> Input Class Initialized
INFO - 2018-08-22 19:14:29 --> Language Class Initialized
INFO - 2018-08-22 19:14:29 --> Loader Class Initialized
INFO - 2018-08-22 19:14:29 --> Helper loaded: url_helper
INFO - 2018-08-22 19:14:29 --> Helper loaded: form_helper
INFO - 2018-08-22 19:14:29 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:14:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:14:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:14:29 --> User Agent Class Initialized
INFO - 2018-08-22 19:14:29 --> Controller Class Initialized
INFO - 2018-08-22 19:14:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:14:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:14:29 --> Pixel_Model class loaded
INFO - 2018-08-22 19:14:29 --> Database Driver Class Initialized
INFO - 2018-08-22 19:14:29 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:14:29 --> Form Validation Class Initialized
INFO - 2018-08-22 19:14:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 19:14:29 --> Database Driver Class Initialized
INFO - 2018-08-22 19:14:29 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:14:29 --> Config Class Initialized
INFO - 2018-08-22 19:14:29 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:14:29 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:14:29 --> Utf8 Class Initialized
INFO - 2018-08-22 19:14:29 --> URI Class Initialized
INFO - 2018-08-22 19:14:29 --> Router Class Initialized
INFO - 2018-08-22 19:14:29 --> Output Class Initialized
INFO - 2018-08-22 19:14:29 --> Security Class Initialized
DEBUG - 2018-08-22 19:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:14:29 --> CSRF cookie sent
INFO - 2018-08-22 19:14:29 --> Input Class Initialized
INFO - 2018-08-22 19:14:29 --> Language Class Initialized
INFO - 2018-08-22 19:14:29 --> Loader Class Initialized
INFO - 2018-08-22 19:14:29 --> Helper loaded: url_helper
INFO - 2018-08-22 19:14:29 --> Helper loaded: form_helper
INFO - 2018-08-22 19:14:29 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:14:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:14:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:14:29 --> User Agent Class Initialized
INFO - 2018-08-22 19:14:29 --> Controller Class Initialized
INFO - 2018-08-22 19:14:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:14:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:14:29 --> Pixel_Model class loaded
INFO - 2018-08-22 19:14:29 --> Database Driver Class Initialized
INFO - 2018-08-22 19:14:29 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:14:29 --> Database Driver Class Initialized
INFO - 2018-08-22 19:14:29 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:14:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:14:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:14:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:14:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:14:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:14:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:14:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-08-22 19:14:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:14:29 --> Final output sent to browser
DEBUG - 2018-08-22 19:14:29 --> Total execution time: 0.0453
INFO - 2018-08-22 19:14:47 --> Config Class Initialized
INFO - 2018-08-22 19:14:47 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:14:47 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:14:47 --> Utf8 Class Initialized
INFO - 2018-08-22 19:14:47 --> URI Class Initialized
INFO - 2018-08-22 19:14:47 --> Router Class Initialized
INFO - 2018-08-22 19:14:47 --> Output Class Initialized
INFO - 2018-08-22 19:14:47 --> Security Class Initialized
DEBUG - 2018-08-22 19:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:14:47 --> CSRF cookie sent
INFO - 2018-08-22 19:14:47 --> CSRF token verified
INFO - 2018-08-22 19:14:47 --> Input Class Initialized
INFO - 2018-08-22 19:14:47 --> Language Class Initialized
INFO - 2018-08-22 19:14:47 --> Loader Class Initialized
INFO - 2018-08-22 19:14:47 --> Helper loaded: url_helper
INFO - 2018-08-22 19:14:47 --> Helper loaded: form_helper
INFO - 2018-08-22 19:14:47 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:14:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:14:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:14:47 --> User Agent Class Initialized
INFO - 2018-08-22 19:14:47 --> Controller Class Initialized
INFO - 2018-08-22 19:14:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:14:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:14:47 --> Pixel_Model class loaded
INFO - 2018-08-22 19:14:47 --> Database Driver Class Initialized
INFO - 2018-08-22 19:14:47 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:14:47 --> Form Validation Class Initialized
INFO - 2018-08-22 19:14:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 19:14:47 --> Database Driver Class Initialized
INFO - 2018-08-22 19:14:47 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:14:47 --> Config Class Initialized
INFO - 2018-08-22 19:14:47 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:14:47 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:14:47 --> Utf8 Class Initialized
INFO - 2018-08-22 19:14:47 --> URI Class Initialized
INFO - 2018-08-22 19:14:47 --> Router Class Initialized
INFO - 2018-08-22 19:14:47 --> Output Class Initialized
INFO - 2018-08-22 19:14:47 --> Security Class Initialized
DEBUG - 2018-08-22 19:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:14:47 --> CSRF cookie sent
INFO - 2018-08-22 19:14:47 --> Input Class Initialized
INFO - 2018-08-22 19:14:47 --> Language Class Initialized
INFO - 2018-08-22 19:14:47 --> Loader Class Initialized
INFO - 2018-08-22 19:14:47 --> Helper loaded: url_helper
INFO - 2018-08-22 19:14:47 --> Helper loaded: form_helper
INFO - 2018-08-22 19:14:47 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:14:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:14:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:14:47 --> User Agent Class Initialized
INFO - 2018-08-22 19:14:47 --> Controller Class Initialized
INFO - 2018-08-22 19:14:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:14:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:14:47 --> Pixel_Model class loaded
INFO - 2018-08-22 19:14:47 --> Database Driver Class Initialized
INFO - 2018-08-22 19:14:47 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:14:47 --> Config Class Initialized
INFO - 2018-08-22 19:14:47 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:14:47 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:14:47 --> Utf8 Class Initialized
INFO - 2018-08-22 19:14:47 --> URI Class Initialized
INFO - 2018-08-22 19:14:47 --> Router Class Initialized
INFO - 2018-08-22 19:14:47 --> Output Class Initialized
INFO - 2018-08-22 19:14:47 --> Security Class Initialized
DEBUG - 2018-08-22 19:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:14:47 --> CSRF cookie sent
INFO - 2018-08-22 19:14:47 --> Input Class Initialized
INFO - 2018-08-22 19:14:47 --> Language Class Initialized
INFO - 2018-08-22 19:14:47 --> Loader Class Initialized
INFO - 2018-08-22 19:14:47 --> Helper loaded: url_helper
INFO - 2018-08-22 19:14:47 --> Helper loaded: form_helper
INFO - 2018-08-22 19:14:47 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:14:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:14:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:14:47 --> User Agent Class Initialized
INFO - 2018-08-22 19:14:47 --> Controller Class Initialized
INFO - 2018-08-22 19:14:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:14:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:14:47 --> Pixel_Model class loaded
INFO - 2018-08-22 19:14:47 --> Database Driver Class Initialized
INFO - 2018-08-22 19:14:47 --> Model "RegistrationModel" initialized
DEBUG - 2018-08-22 19:14:47 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-08-22 19:14:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:14:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:14:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:14:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-08-22 19:14:47 --> Could not find the language line "req_email"
INFO - 2018-08-22 19:14:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup.php
INFO - 2018-08-22 19:14:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:14:47 --> Final output sent to browser
DEBUG - 2018-08-22 19:14:47 --> Total execution time: 0.0503
INFO - 2018-08-22 19:14:50 --> Config Class Initialized
INFO - 2018-08-22 19:14:50 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:14:50 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:14:50 --> Utf8 Class Initialized
INFO - 2018-08-22 19:14:50 --> URI Class Initialized
INFO - 2018-08-22 19:14:50 --> Router Class Initialized
INFO - 2018-08-22 19:14:50 --> Output Class Initialized
INFO - 2018-08-22 19:14:50 --> Security Class Initialized
DEBUG - 2018-08-22 19:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:14:50 --> CSRF cookie sent
INFO - 2018-08-22 19:14:50 --> CSRF token verified
INFO - 2018-08-22 19:14:50 --> Input Class Initialized
INFO - 2018-08-22 19:14:50 --> Language Class Initialized
INFO - 2018-08-22 19:14:50 --> Loader Class Initialized
INFO - 2018-08-22 19:14:50 --> Helper loaded: url_helper
INFO - 2018-08-22 19:14:50 --> Helper loaded: form_helper
INFO - 2018-08-22 19:14:50 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:14:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:14:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:14:50 --> User Agent Class Initialized
INFO - 2018-08-22 19:14:50 --> Controller Class Initialized
INFO - 2018-08-22 19:14:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:14:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:14:50 --> Pixel_Model class loaded
INFO - 2018-08-22 19:14:50 --> Database Driver Class Initialized
INFO - 2018-08-22 19:14:50 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:14:50 --> Form Validation Class Initialized
INFO - 2018-08-22 19:14:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 19:14:50 --> Database Driver Class Initialized
INFO - 2018-08-22 19:14:50 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:14:50 --> Config Class Initialized
INFO - 2018-08-22 19:14:50 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:14:50 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:14:50 --> Utf8 Class Initialized
INFO - 2018-08-22 19:14:50 --> URI Class Initialized
INFO - 2018-08-22 19:14:50 --> Router Class Initialized
INFO - 2018-08-22 19:14:50 --> Output Class Initialized
INFO - 2018-08-22 19:14:50 --> Security Class Initialized
DEBUG - 2018-08-22 19:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:14:50 --> CSRF cookie sent
INFO - 2018-08-22 19:14:50 --> Input Class Initialized
INFO - 2018-08-22 19:14:50 --> Language Class Initialized
INFO - 2018-08-22 19:14:50 --> Loader Class Initialized
INFO - 2018-08-22 19:14:50 --> Helper loaded: url_helper
INFO - 2018-08-22 19:14:50 --> Helper loaded: form_helper
INFO - 2018-08-22 19:14:50 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:14:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:14:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:14:50 --> User Agent Class Initialized
INFO - 2018-08-22 19:14:50 --> Controller Class Initialized
INFO - 2018-08-22 19:14:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:14:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:14:50 --> Pixel_Model class loaded
INFO - 2018-08-22 19:14:50 --> Database Driver Class Initialized
INFO - 2018-08-22 19:14:50 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:14:50 --> Database Driver Class Initialized
INFO - 2018-08-22 19:14:50 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:14:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:14:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 19:14:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:14:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:14:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:14:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:14:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:14:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-08-22 19:14:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:14:50 --> Final output sent to browser
DEBUG - 2018-08-22 19:14:50 --> Total execution time: 0.0389
INFO - 2018-08-22 19:15:29 --> Config Class Initialized
INFO - 2018-08-22 19:15:29 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:15:29 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:15:29 --> Utf8 Class Initialized
INFO - 2018-08-22 19:15:29 --> URI Class Initialized
INFO - 2018-08-22 19:15:29 --> Router Class Initialized
INFO - 2018-08-22 19:15:29 --> Output Class Initialized
INFO - 2018-08-22 19:15:29 --> Security Class Initialized
DEBUG - 2018-08-22 19:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:15:29 --> CSRF cookie sent
INFO - 2018-08-22 19:15:29 --> CSRF token verified
INFO - 2018-08-22 19:15:29 --> Input Class Initialized
INFO - 2018-08-22 19:15:29 --> Language Class Initialized
INFO - 2018-08-22 19:15:29 --> Loader Class Initialized
INFO - 2018-08-22 19:15:29 --> Helper loaded: url_helper
INFO - 2018-08-22 19:15:29 --> Helper loaded: form_helper
INFO - 2018-08-22 19:15:29 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:15:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:15:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:15:29 --> User Agent Class Initialized
INFO - 2018-08-22 19:15:29 --> Controller Class Initialized
INFO - 2018-08-22 19:15:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:15:29 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-08-22 19:15:29 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-08-22 19:15:29 --> Form Validation Class Initialized
INFO - 2018-08-22 19:15:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 19:15:29 --> Pixel_Model class loaded
INFO - 2018-08-22 19:15:29 --> Database Driver Class Initialized
INFO - 2018-08-22 19:15:29 --> Model "RegistrationModel" initialized
INFO - 2018-08-22 19:15:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:15:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:15:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:15:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:15:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup_terms.php
INFO - 2018-08-22 19:15:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:15:29 --> Final output sent to browser
DEBUG - 2018-08-22 19:15:29 --> Total execution time: 0.1989
INFO - 2018-08-22 19:15:36 --> Config Class Initialized
INFO - 2018-08-22 19:15:36 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:15:36 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:15:36 --> Utf8 Class Initialized
INFO - 2018-08-22 19:15:36 --> URI Class Initialized
INFO - 2018-08-22 19:15:36 --> Router Class Initialized
INFO - 2018-08-22 19:15:36 --> Output Class Initialized
INFO - 2018-08-22 19:15:36 --> Security Class Initialized
DEBUG - 2018-08-22 19:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:15:36 --> CSRF cookie sent
INFO - 2018-08-22 19:15:36 --> CSRF token verified
INFO - 2018-08-22 19:15:36 --> Input Class Initialized
INFO - 2018-08-22 19:15:36 --> Language Class Initialized
INFO - 2018-08-22 19:15:36 --> Loader Class Initialized
INFO - 2018-08-22 19:15:36 --> Helper loaded: url_helper
INFO - 2018-08-22 19:15:36 --> Helper loaded: form_helper
INFO - 2018-08-22 19:15:36 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:15:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:15:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:15:36 --> User Agent Class Initialized
INFO - 2018-08-22 19:15:36 --> Controller Class Initialized
INFO - 2018-08-22 19:15:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:15:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:15:36 --> Pixel_Model class loaded
INFO - 2018-08-22 19:15:36 --> Database Driver Class Initialized
INFO - 2018-08-22 19:15:36 --> Model "RegistrationModel" initialized
INFO - 2018-08-22 19:15:36 --> Helper loaded: string_helper
INFO - 2018-08-22 19:15:36 --> Language file loaded: language/en/notifications_lang.php
INFO - 2018-08-22 19:15:36 --> Database Driver Class Initialized
INFO - 2018-08-22 19:15:36 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:15:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/emails/_buttons.php
INFO - 2018-08-22 19:15:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/emails/header.php
INFO - 2018-08-22 19:15:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/emails/footer.php
INFO - 2018-08-22 19:15:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/emails/generic.php
INFO - 2018-08-22 19:15:36 --> Email Class Initialized
INFO - 2018-08-22 19:15:37 --> Language file loaded: language/english/email_lang.php
INFO - 2018-08-22 19:15:37 --> Config Class Initialized
INFO - 2018-08-22 19:15:37 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:15:37 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:15:37 --> Utf8 Class Initialized
INFO - 2018-08-22 19:15:37 --> URI Class Initialized
INFO - 2018-08-22 19:15:37 --> Router Class Initialized
INFO - 2018-08-22 19:15:37 --> Output Class Initialized
INFO - 2018-08-22 19:15:37 --> Security Class Initialized
DEBUG - 2018-08-22 19:15:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:15:37 --> CSRF cookie sent
INFO - 2018-08-22 19:15:37 --> Input Class Initialized
INFO - 2018-08-22 19:15:37 --> Language Class Initialized
INFO - 2018-08-22 19:15:37 --> Loader Class Initialized
INFO - 2018-08-22 19:15:37 --> Helper loaded: url_helper
INFO - 2018-08-22 19:15:37 --> Helper loaded: form_helper
INFO - 2018-08-22 19:15:37 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:15:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:15:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:15:37 --> User Agent Class Initialized
INFO - 2018-08-22 19:15:37 --> Controller Class Initialized
INFO - 2018-08-22 19:15:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:15:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:15:37 --> Pixel_Model class loaded
INFO - 2018-08-22 19:15:37 --> Database Driver Class Initialized
INFO - 2018-08-22 19:15:37 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:15:37 --> Database Driver Class Initialized
INFO - 2018-08-22 19:15:37 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:15:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:15:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 19:15:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:15:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:15:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:15:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:15:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:15:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-08-22 19:15:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:15:37 --> Final output sent to browser
DEBUG - 2018-08-22 19:15:37 --> Total execution time: 0.0358
INFO - 2018-08-22 19:26:02 --> Config Class Initialized
INFO - 2018-08-22 19:26:02 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:26:02 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:26:02 --> Utf8 Class Initialized
INFO - 2018-08-22 19:26:02 --> URI Class Initialized
DEBUG - 2018-08-22 19:26:02 --> No URI present. Default controller set.
INFO - 2018-08-22 19:26:02 --> Router Class Initialized
INFO - 2018-08-22 19:26:02 --> Output Class Initialized
INFO - 2018-08-22 19:26:02 --> Security Class Initialized
DEBUG - 2018-08-22 19:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:26:02 --> CSRF cookie sent
INFO - 2018-08-22 19:26:02 --> Input Class Initialized
INFO - 2018-08-22 19:26:02 --> Language Class Initialized
INFO - 2018-08-22 19:26:02 --> Loader Class Initialized
INFO - 2018-08-22 19:26:02 --> Helper loaded: url_helper
INFO - 2018-08-22 19:26:02 --> Helper loaded: form_helper
INFO - 2018-08-22 19:26:02 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:26:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:26:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:26:02 --> User Agent Class Initialized
INFO - 2018-08-22 19:26:02 --> Controller Class Initialized
INFO - 2018-08-22 19:26:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:26:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:26:02 --> Pixel_Model class loaded
INFO - 2018-08-22 19:26:02 --> Database Driver Class Initialized
INFO - 2018-08-22 19:26:02 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:26:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:26:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:26:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-22 19:26:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:26:02 --> Final output sent to browser
DEBUG - 2018-08-22 19:26:02 --> Total execution time: 0.0425
INFO - 2018-08-22 19:26:11 --> Config Class Initialized
INFO - 2018-08-22 19:26:11 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:26:11 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:26:11 --> Utf8 Class Initialized
INFO - 2018-08-22 19:26:11 --> URI Class Initialized
INFO - 2018-08-22 19:26:11 --> Router Class Initialized
INFO - 2018-08-22 19:26:11 --> Output Class Initialized
INFO - 2018-08-22 19:26:11 --> Security Class Initialized
DEBUG - 2018-08-22 19:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:26:11 --> CSRF cookie sent
INFO - 2018-08-22 19:26:11 --> Input Class Initialized
INFO - 2018-08-22 19:26:11 --> Language Class Initialized
INFO - 2018-08-22 19:26:11 --> Loader Class Initialized
INFO - 2018-08-22 19:26:11 --> Helper loaded: url_helper
INFO - 2018-08-22 19:26:11 --> Helper loaded: form_helper
INFO - 2018-08-22 19:26:11 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:26:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:26:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:26:11 --> User Agent Class Initialized
INFO - 2018-08-22 19:26:11 --> Controller Class Initialized
INFO - 2018-08-22 19:26:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:26:11 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-08-22 19:26:11 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-08-22 19:26:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:26:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:26:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:26:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-08-22 19:26:11 --> Could not find the language line "req_email"
INFO - 2018-08-22 19:26:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-08-22 19:26:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:26:11 --> Final output sent to browser
DEBUG - 2018-08-22 19:26:11 --> Total execution time: 0.0244
INFO - 2018-08-22 19:26:18 --> Config Class Initialized
INFO - 2018-08-22 19:26:18 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:26:18 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:26:18 --> Utf8 Class Initialized
INFO - 2018-08-22 19:26:18 --> URI Class Initialized
INFO - 2018-08-22 19:26:18 --> Router Class Initialized
INFO - 2018-08-22 19:26:18 --> Output Class Initialized
INFO - 2018-08-22 19:26:18 --> Security Class Initialized
DEBUG - 2018-08-22 19:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:26:18 --> CSRF cookie sent
INFO - 2018-08-22 19:26:18 --> CSRF token verified
INFO - 2018-08-22 19:26:18 --> Input Class Initialized
INFO - 2018-08-22 19:26:18 --> Language Class Initialized
INFO - 2018-08-22 19:26:18 --> Loader Class Initialized
INFO - 2018-08-22 19:26:18 --> Helper loaded: url_helper
INFO - 2018-08-22 19:26:18 --> Helper loaded: form_helper
INFO - 2018-08-22 19:26:18 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:26:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:26:18 --> User Agent Class Initialized
INFO - 2018-08-22 19:26:18 --> Controller Class Initialized
INFO - 2018-08-22 19:26:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:26:18 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-08-22 19:26:18 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-08-22 19:26:18 --> Form Validation Class Initialized
INFO - 2018-08-22 19:26:18 --> Pixel_Model class loaded
INFO - 2018-08-22 19:26:18 --> Database Driver Class Initialized
INFO - 2018-08-22 19:26:18 --> Model "AuthenticationModel" initialized
INFO - 2018-08-22 19:26:18 --> Config Class Initialized
INFO - 2018-08-22 19:26:18 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:26:18 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:26:18 --> Utf8 Class Initialized
INFO - 2018-08-22 19:26:18 --> URI Class Initialized
DEBUG - 2018-08-22 19:26:18 --> No URI present. Default controller set.
INFO - 2018-08-22 19:26:18 --> Router Class Initialized
INFO - 2018-08-22 19:26:18 --> Output Class Initialized
INFO - 2018-08-22 19:26:18 --> Security Class Initialized
DEBUG - 2018-08-22 19:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:26:18 --> CSRF cookie sent
INFO - 2018-08-22 19:26:18 --> Input Class Initialized
INFO - 2018-08-22 19:26:18 --> Language Class Initialized
INFO - 2018-08-22 19:26:18 --> Loader Class Initialized
INFO - 2018-08-22 19:26:18 --> Helper loaded: url_helper
INFO - 2018-08-22 19:26:18 --> Helper loaded: form_helper
INFO - 2018-08-22 19:26:18 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:26:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:26:18 --> User Agent Class Initialized
INFO - 2018-08-22 19:26:18 --> Controller Class Initialized
INFO - 2018-08-22 19:26:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:26:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:26:18 --> Pixel_Model class loaded
INFO - 2018-08-22 19:26:18 --> Database Driver Class Initialized
INFO - 2018-08-22 19:26:18 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:26:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:26:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 19:26:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:26:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-22 19:26:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:26:18 --> Final output sent to browser
DEBUG - 2018-08-22 19:26:18 --> Total execution time: 0.0474
INFO - 2018-08-22 19:26:22 --> Config Class Initialized
INFO - 2018-08-22 19:26:22 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:26:22 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:26:22 --> Utf8 Class Initialized
INFO - 2018-08-22 19:26:22 --> URI Class Initialized
INFO - 2018-08-22 19:26:22 --> Router Class Initialized
INFO - 2018-08-22 19:26:22 --> Output Class Initialized
INFO - 2018-08-22 19:26:22 --> Security Class Initialized
DEBUG - 2018-08-22 19:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:26:22 --> CSRF cookie sent
INFO - 2018-08-22 19:26:22 --> Input Class Initialized
INFO - 2018-08-22 19:26:22 --> Language Class Initialized
INFO - 2018-08-22 19:26:22 --> Loader Class Initialized
INFO - 2018-08-22 19:26:22 --> Helper loaded: url_helper
INFO - 2018-08-22 19:26:22 --> Helper loaded: form_helper
INFO - 2018-08-22 19:26:22 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:26:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:26:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:26:22 --> User Agent Class Initialized
INFO - 2018-08-22 19:26:22 --> Controller Class Initialized
INFO - 2018-08-22 19:26:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:26:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:26:22 --> Pixel_Model class loaded
INFO - 2018-08-22 19:26:22 --> Database Driver Class Initialized
INFO - 2018-08-22 19:26:22 --> Model "MyAccountModel" initialized
INFO - 2018-08-22 19:26:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:26:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 19:26:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:26:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:26:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:26:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/application_list.php
INFO - 2018-08-22 19:26:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:26:22 --> Final output sent to browser
DEBUG - 2018-08-22 19:26:22 --> Total execution time: 0.0465
INFO - 2018-08-22 19:26:26 --> Config Class Initialized
INFO - 2018-08-22 19:26:26 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:26:26 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:26:26 --> Utf8 Class Initialized
INFO - 2018-08-22 19:26:26 --> URI Class Initialized
INFO - 2018-08-22 19:26:26 --> Router Class Initialized
INFO - 2018-08-22 19:26:26 --> Output Class Initialized
INFO - 2018-08-22 19:26:26 --> Security Class Initialized
DEBUG - 2018-08-22 19:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:26:26 --> CSRF cookie sent
INFO - 2018-08-22 19:26:26 --> Input Class Initialized
INFO - 2018-08-22 19:26:26 --> Language Class Initialized
INFO - 2018-08-22 19:26:26 --> Loader Class Initialized
INFO - 2018-08-22 19:26:26 --> Helper loaded: url_helper
INFO - 2018-08-22 19:26:26 --> Helper loaded: form_helper
INFO - 2018-08-22 19:26:26 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:26:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:26:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:26:26 --> User Agent Class Initialized
INFO - 2018-08-22 19:26:26 --> Controller Class Initialized
INFO - 2018-08-22 19:26:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:26:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:26:26 --> Pixel_Model class loaded
INFO - 2018-08-22 19:26:26 --> Database Driver Class Initialized
INFO - 2018-08-22 19:26:26 --> Model "MyAccountModel" initialized
INFO - 2018-08-22 19:26:26 --> Config Class Initialized
INFO - 2018-08-22 19:26:26 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:26:26 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:26:26 --> Utf8 Class Initialized
INFO - 2018-08-22 19:26:26 --> URI Class Initialized
INFO - 2018-08-22 19:26:26 --> Router Class Initialized
INFO - 2018-08-22 19:26:26 --> Output Class Initialized
INFO - 2018-08-22 19:26:26 --> Security Class Initialized
DEBUG - 2018-08-22 19:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:26:26 --> CSRF cookie sent
INFO - 2018-08-22 19:26:26 --> Input Class Initialized
INFO - 2018-08-22 19:26:26 --> Language Class Initialized
INFO - 2018-08-22 19:26:26 --> Loader Class Initialized
INFO - 2018-08-22 19:26:26 --> Helper loaded: url_helper
INFO - 2018-08-22 19:26:26 --> Helper loaded: form_helper
INFO - 2018-08-22 19:26:26 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:26:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:26:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:26:26 --> User Agent Class Initialized
INFO - 2018-08-22 19:26:26 --> Controller Class Initialized
INFO - 2018-08-22 19:26:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:26:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:26:26 --> Pixel_Model class loaded
INFO - 2018-08-22 19:26:26 --> Database Driver Class Initialized
INFO - 2018-08-22 19:26:26 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:26:26 --> Database Driver Class Initialized
INFO - 2018-08-22 19:26:26 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:26:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:26:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 19:26:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:26:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:26:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:26:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:26:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:26:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-22 19:26:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:26:26 --> Final output sent to browser
DEBUG - 2018-08-22 19:26:26 --> Total execution time: 0.0478
INFO - 2018-08-22 19:31:31 --> Config Class Initialized
INFO - 2018-08-22 19:31:31 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:31:31 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:31:31 --> Utf8 Class Initialized
INFO - 2018-08-22 19:31:31 --> URI Class Initialized
INFO - 2018-08-22 19:31:31 --> Router Class Initialized
INFO - 2018-08-22 19:31:31 --> Output Class Initialized
INFO - 2018-08-22 19:31:31 --> Security Class Initialized
DEBUG - 2018-08-22 19:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:31:31 --> CSRF cookie sent
INFO - 2018-08-22 19:31:31 --> Input Class Initialized
INFO - 2018-08-22 19:31:31 --> Language Class Initialized
INFO - 2018-08-22 19:31:31 --> Loader Class Initialized
INFO - 2018-08-22 19:31:31 --> Helper loaded: url_helper
INFO - 2018-08-22 19:31:31 --> Helper loaded: form_helper
INFO - 2018-08-22 19:31:31 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:31:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:31:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:31:31 --> User Agent Class Initialized
INFO - 2018-08-22 19:31:31 --> Controller Class Initialized
INFO - 2018-08-22 19:31:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:31:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:31:31 --> Pixel_Model class loaded
INFO - 2018-08-22 19:31:31 --> Database Driver Class Initialized
INFO - 2018-08-22 19:31:31 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:31:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:31:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 19:31:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:31:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:31:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:31:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:31:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:31:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-08-22 19:31:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:31:31 --> Final output sent to browser
DEBUG - 2018-08-22 19:31:31 --> Total execution time: 0.0376
INFO - 2018-08-22 19:31:37 --> Config Class Initialized
INFO - 2018-08-22 19:31:37 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:31:37 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:31:37 --> Utf8 Class Initialized
INFO - 2018-08-22 19:31:37 --> URI Class Initialized
INFO - 2018-08-22 19:31:37 --> Router Class Initialized
INFO - 2018-08-22 19:31:37 --> Output Class Initialized
INFO - 2018-08-22 19:31:37 --> Security Class Initialized
DEBUG - 2018-08-22 19:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:31:37 --> CSRF cookie sent
INFO - 2018-08-22 19:31:37 --> Input Class Initialized
INFO - 2018-08-22 19:31:37 --> Language Class Initialized
ERROR - 2018-08-22 19:31:37 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 19:32:46 --> Config Class Initialized
INFO - 2018-08-22 19:32:46 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:32:46 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:32:46 --> Utf8 Class Initialized
INFO - 2018-08-22 19:32:46 --> URI Class Initialized
INFO - 2018-08-22 19:32:46 --> Router Class Initialized
INFO - 2018-08-22 19:32:46 --> Output Class Initialized
INFO - 2018-08-22 19:32:46 --> Security Class Initialized
DEBUG - 2018-08-22 19:32:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:32:46 --> CSRF cookie sent
INFO - 2018-08-22 19:32:46 --> Input Class Initialized
INFO - 2018-08-22 19:32:46 --> Language Class Initialized
INFO - 2018-08-22 19:32:46 --> Loader Class Initialized
INFO - 2018-08-22 19:32:46 --> Helper loaded: url_helper
INFO - 2018-08-22 19:32:46 --> Helper loaded: form_helper
INFO - 2018-08-22 19:32:46 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:32:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:32:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:32:46 --> User Agent Class Initialized
INFO - 2018-08-22 19:32:46 --> Controller Class Initialized
INFO - 2018-08-22 19:32:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:32:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:32:46 --> Pixel_Model class loaded
INFO - 2018-08-22 19:32:46 --> Database Driver Class Initialized
INFO - 2018-08-22 19:32:46 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:32:46 --> Database Driver Class Initialized
INFO - 2018-08-22 19:32:46 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:32:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:32:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 19:32:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:32:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-08-22 19:32:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:32:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:32:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:32:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:32:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-08-22 19:32:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:32:46 --> Final output sent to browser
DEBUG - 2018-08-22 19:32:46 --> Total execution time: 0.0394
INFO - 2018-08-22 19:32:46 --> Config Class Initialized
INFO - 2018-08-22 19:32:46 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:32:46 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:32:46 --> Utf8 Class Initialized
INFO - 2018-08-22 19:32:46 --> URI Class Initialized
INFO - 2018-08-22 19:32:46 --> Router Class Initialized
INFO - 2018-08-22 19:32:46 --> Output Class Initialized
INFO - 2018-08-22 19:32:46 --> Security Class Initialized
DEBUG - 2018-08-22 19:32:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:32:46 --> CSRF cookie sent
INFO - 2018-08-22 19:32:46 --> Input Class Initialized
INFO - 2018-08-22 19:32:46 --> Language Class Initialized
ERROR - 2018-08-22 19:32:46 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 19:33:23 --> Config Class Initialized
INFO - 2018-08-22 19:33:23 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:33:23 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:33:23 --> Utf8 Class Initialized
INFO - 2018-08-22 19:33:23 --> URI Class Initialized
INFO - 2018-08-22 19:33:23 --> Router Class Initialized
INFO - 2018-08-22 19:33:23 --> Output Class Initialized
INFO - 2018-08-22 19:33:23 --> Security Class Initialized
DEBUG - 2018-08-22 19:33:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:33:23 --> CSRF cookie sent
INFO - 2018-08-22 19:33:23 --> Input Class Initialized
INFO - 2018-08-22 19:33:23 --> Language Class Initialized
INFO - 2018-08-22 19:33:23 --> Loader Class Initialized
INFO - 2018-08-22 19:33:23 --> Helper loaded: url_helper
INFO - 2018-08-22 19:33:23 --> Helper loaded: form_helper
INFO - 2018-08-22 19:33:23 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:33:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:33:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:33:23 --> User Agent Class Initialized
INFO - 2018-08-22 19:33:23 --> Controller Class Initialized
INFO - 2018-08-22 19:33:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:33:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:33:23 --> Pixel_Model class loaded
INFO - 2018-08-22 19:33:23 --> Database Driver Class Initialized
INFO - 2018-08-22 19:33:23 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:33:23 --> Database Driver Class Initialized
INFO - 2018-08-22 19:33:23 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:33:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:33:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 19:33:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:33:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:33:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:33:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:33:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:33:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-08-22 19:33:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:33:23 --> Final output sent to browser
DEBUG - 2018-08-22 19:33:23 --> Total execution time: 0.0462
INFO - 2018-08-22 19:33:24 --> Config Class Initialized
INFO - 2018-08-22 19:33:24 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:33:24 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:33:24 --> Utf8 Class Initialized
INFO - 2018-08-22 19:33:24 --> URI Class Initialized
INFO - 2018-08-22 19:33:24 --> Router Class Initialized
INFO - 2018-08-22 19:33:24 --> Output Class Initialized
INFO - 2018-08-22 19:33:24 --> Security Class Initialized
DEBUG - 2018-08-22 19:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:33:24 --> CSRF cookie sent
INFO - 2018-08-22 19:33:24 --> Input Class Initialized
INFO - 2018-08-22 19:33:24 --> Language Class Initialized
ERROR - 2018-08-22 19:33:24 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 19:34:19 --> Config Class Initialized
INFO - 2018-08-22 19:34:19 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:34:19 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:34:19 --> Utf8 Class Initialized
INFO - 2018-08-22 19:34:19 --> URI Class Initialized
INFO - 2018-08-22 19:34:19 --> Router Class Initialized
INFO - 2018-08-22 19:34:19 --> Output Class Initialized
INFO - 2018-08-22 19:34:19 --> Security Class Initialized
DEBUG - 2018-08-22 19:34:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:34:19 --> CSRF cookie sent
INFO - 2018-08-22 19:34:19 --> Input Class Initialized
INFO - 2018-08-22 19:34:19 --> Language Class Initialized
INFO - 2018-08-22 19:34:19 --> Loader Class Initialized
INFO - 2018-08-22 19:34:19 --> Helper loaded: url_helper
INFO - 2018-08-22 19:34:19 --> Helper loaded: form_helper
INFO - 2018-08-22 19:34:19 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:34:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:34:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:34:19 --> User Agent Class Initialized
INFO - 2018-08-22 19:34:19 --> Controller Class Initialized
INFO - 2018-08-22 19:34:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:34:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:34:19 --> Pixel_Model class loaded
INFO - 2018-08-22 19:34:19 --> Database Driver Class Initialized
INFO - 2018-08-22 19:34:19 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:34:19 --> Database Driver Class Initialized
INFO - 2018-08-22 19:34:19 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:34:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:34:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 19:34:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:34:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:34:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:34:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:34:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:34:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/cohabitation.php
INFO - 2018-08-22 19:34:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:34:19 --> Final output sent to browser
DEBUG - 2018-08-22 19:34:19 --> Total execution time: 0.0451
INFO - 2018-08-22 19:34:20 --> Config Class Initialized
INFO - 2018-08-22 19:34:20 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:34:20 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:34:20 --> Utf8 Class Initialized
INFO - 2018-08-22 19:34:20 --> URI Class Initialized
INFO - 2018-08-22 19:34:20 --> Router Class Initialized
INFO - 2018-08-22 19:34:20 --> Output Class Initialized
INFO - 2018-08-22 19:34:20 --> Security Class Initialized
DEBUG - 2018-08-22 19:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:34:20 --> CSRF cookie sent
INFO - 2018-08-22 19:34:20 --> Input Class Initialized
INFO - 2018-08-22 19:34:20 --> Language Class Initialized
ERROR - 2018-08-22 19:34:20 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 19:34:57 --> Config Class Initialized
INFO - 2018-08-22 19:34:57 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:34:57 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:34:57 --> Utf8 Class Initialized
INFO - 2018-08-22 19:34:57 --> URI Class Initialized
INFO - 2018-08-22 19:34:57 --> Router Class Initialized
INFO - 2018-08-22 19:34:57 --> Output Class Initialized
INFO - 2018-08-22 19:34:57 --> Security Class Initialized
DEBUG - 2018-08-22 19:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:34:57 --> CSRF cookie sent
INFO - 2018-08-22 19:34:57 --> Input Class Initialized
INFO - 2018-08-22 19:34:57 --> Language Class Initialized
INFO - 2018-08-22 19:34:57 --> Loader Class Initialized
INFO - 2018-08-22 19:34:57 --> Helper loaded: url_helper
INFO - 2018-08-22 19:34:57 --> Helper loaded: form_helper
INFO - 2018-08-22 19:34:57 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:34:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:34:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:34:57 --> User Agent Class Initialized
INFO - 2018-08-22 19:34:57 --> Controller Class Initialized
INFO - 2018-08-22 19:34:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:34:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:34:57 --> Pixel_Model class loaded
INFO - 2018-08-22 19:34:57 --> Database Driver Class Initialized
INFO - 2018-08-22 19:34:57 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:34:57 --> Database Driver Class Initialized
INFO - 2018-08-22 19:34:57 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:34:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:34:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 19:34:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:34:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:34:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:34:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:34:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:34:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/coh_home_title.php
INFO - 2018-08-22 19:34:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:34:57 --> Final output sent to browser
DEBUG - 2018-08-22 19:34:57 --> Total execution time: 0.0441
INFO - 2018-08-22 19:34:57 --> Config Class Initialized
INFO - 2018-08-22 19:34:57 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:34:57 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:34:57 --> Utf8 Class Initialized
INFO - 2018-08-22 19:34:57 --> URI Class Initialized
INFO - 2018-08-22 19:34:57 --> Router Class Initialized
INFO - 2018-08-22 19:34:57 --> Output Class Initialized
INFO - 2018-08-22 19:34:57 --> Security Class Initialized
DEBUG - 2018-08-22 19:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:34:57 --> CSRF cookie sent
INFO - 2018-08-22 19:34:57 --> Input Class Initialized
INFO - 2018-08-22 19:34:57 --> Language Class Initialized
ERROR - 2018-08-22 19:34:57 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 19:36:07 --> Config Class Initialized
INFO - 2018-08-22 19:36:07 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:36:07 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:36:07 --> Utf8 Class Initialized
INFO - 2018-08-22 19:36:07 --> URI Class Initialized
INFO - 2018-08-22 19:36:07 --> Router Class Initialized
INFO - 2018-08-22 19:36:07 --> Output Class Initialized
INFO - 2018-08-22 19:36:07 --> Security Class Initialized
DEBUG - 2018-08-22 19:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:36:07 --> CSRF cookie sent
INFO - 2018-08-22 19:36:07 --> Input Class Initialized
INFO - 2018-08-22 19:36:07 --> Language Class Initialized
INFO - 2018-08-22 19:36:07 --> Loader Class Initialized
INFO - 2018-08-22 19:36:07 --> Helper loaded: url_helper
INFO - 2018-08-22 19:36:07 --> Helper loaded: form_helper
INFO - 2018-08-22 19:36:07 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:36:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:36:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:36:07 --> User Agent Class Initialized
INFO - 2018-08-22 19:36:07 --> Controller Class Initialized
INFO - 2018-08-22 19:36:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:36:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:36:07 --> Pixel_Model class loaded
INFO - 2018-08-22 19:36:07 --> Database Driver Class Initialized
INFO - 2018-08-22 19:36:07 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:36:07 --> Database Driver Class Initialized
INFO - 2018-08-22 19:36:07 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:36:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:36:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 19:36:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:36:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:36:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:36:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:36:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:36:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-08-22 19:36:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:36:07 --> Final output sent to browser
DEBUG - 2018-08-22 19:36:07 --> Total execution time: 0.0385
INFO - 2018-08-22 19:36:08 --> Config Class Initialized
INFO - 2018-08-22 19:36:08 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:36:08 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:36:08 --> Utf8 Class Initialized
INFO - 2018-08-22 19:36:08 --> URI Class Initialized
INFO - 2018-08-22 19:36:08 --> Router Class Initialized
INFO - 2018-08-22 19:36:08 --> Output Class Initialized
INFO - 2018-08-22 19:36:08 --> Security Class Initialized
DEBUG - 2018-08-22 19:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:36:08 --> CSRF cookie sent
INFO - 2018-08-22 19:36:08 --> Input Class Initialized
INFO - 2018-08-22 19:36:08 --> Language Class Initialized
ERROR - 2018-08-22 19:36:08 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 19:37:00 --> Config Class Initialized
INFO - 2018-08-22 19:37:00 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:37:00 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:37:00 --> Utf8 Class Initialized
INFO - 2018-08-22 19:37:00 --> URI Class Initialized
INFO - 2018-08-22 19:37:00 --> Router Class Initialized
INFO - 2018-08-22 19:37:00 --> Output Class Initialized
INFO - 2018-08-22 19:37:00 --> Security Class Initialized
DEBUG - 2018-08-22 19:37:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:37:00 --> CSRF cookie sent
INFO - 2018-08-22 19:37:00 --> Input Class Initialized
INFO - 2018-08-22 19:37:00 --> Language Class Initialized
INFO - 2018-08-22 19:37:00 --> Loader Class Initialized
INFO - 2018-08-22 19:37:00 --> Helper loaded: url_helper
INFO - 2018-08-22 19:37:00 --> Helper loaded: form_helper
INFO - 2018-08-22 19:37:00 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:37:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:37:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:37:00 --> User Agent Class Initialized
INFO - 2018-08-22 19:37:00 --> Controller Class Initialized
INFO - 2018-08-22 19:37:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:37:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:37:00 --> Pixel_Model class loaded
INFO - 2018-08-22 19:37:00 --> Database Driver Class Initialized
INFO - 2018-08-22 19:37:00 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:37:00 --> Database Driver Class Initialized
INFO - 2018-08-22 19:37:00 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:37:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:37:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 19:37:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:37:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:37:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:37:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:37:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:37:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/marriage.php
INFO - 2018-08-22 19:37:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:37:00 --> Final output sent to browser
DEBUG - 2018-08-22 19:37:00 --> Total execution time: 0.0380
INFO - 2018-08-22 19:37:01 --> Config Class Initialized
INFO - 2018-08-22 19:37:01 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:37:01 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:37:01 --> Utf8 Class Initialized
INFO - 2018-08-22 19:37:01 --> URI Class Initialized
INFO - 2018-08-22 19:37:01 --> Router Class Initialized
INFO - 2018-08-22 19:37:01 --> Output Class Initialized
INFO - 2018-08-22 19:37:01 --> Security Class Initialized
DEBUG - 2018-08-22 19:37:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:37:01 --> CSRF cookie sent
INFO - 2018-08-22 19:37:01 --> Input Class Initialized
INFO - 2018-08-22 19:37:01 --> Language Class Initialized
ERROR - 2018-08-22 19:37:01 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 19:37:27 --> Config Class Initialized
INFO - 2018-08-22 19:37:27 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:37:27 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:37:27 --> Utf8 Class Initialized
INFO - 2018-08-22 19:37:27 --> URI Class Initialized
INFO - 2018-08-22 19:37:27 --> Router Class Initialized
INFO - 2018-08-22 19:37:27 --> Output Class Initialized
INFO - 2018-08-22 19:37:27 --> Security Class Initialized
DEBUG - 2018-08-22 19:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:37:27 --> CSRF cookie sent
INFO - 2018-08-22 19:37:27 --> Input Class Initialized
INFO - 2018-08-22 19:37:27 --> Language Class Initialized
INFO - 2018-08-22 19:37:27 --> Loader Class Initialized
INFO - 2018-08-22 19:37:27 --> Helper loaded: url_helper
INFO - 2018-08-22 19:37:27 --> Helper loaded: form_helper
INFO - 2018-08-22 19:37:27 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:37:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:37:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:37:27 --> User Agent Class Initialized
INFO - 2018-08-22 19:37:27 --> Controller Class Initialized
INFO - 2018-08-22 19:37:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:37:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:37:27 --> Pixel_Model class loaded
INFO - 2018-08-22 19:37:27 --> Database Driver Class Initialized
INFO - 2018-08-22 19:37:27 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:37:27 --> Database Driver Class Initialized
INFO - 2018-08-22 19:37:27 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:37:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:37:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 19:37:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:37:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:37:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:37:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:37:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:37:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-08-22 19:37:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:37:27 --> Final output sent to browser
DEBUG - 2018-08-22 19:37:27 --> Total execution time: 0.0475
INFO - 2018-08-22 19:37:28 --> Config Class Initialized
INFO - 2018-08-22 19:37:28 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:37:28 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:37:28 --> Utf8 Class Initialized
INFO - 2018-08-22 19:37:28 --> URI Class Initialized
INFO - 2018-08-22 19:37:28 --> Router Class Initialized
INFO - 2018-08-22 19:37:28 --> Output Class Initialized
INFO - 2018-08-22 19:37:28 --> Security Class Initialized
DEBUG - 2018-08-22 19:37:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:37:28 --> CSRF cookie sent
INFO - 2018-08-22 19:37:28 --> Input Class Initialized
INFO - 2018-08-22 19:37:28 --> Language Class Initialized
ERROR - 2018-08-22 19:37:28 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 19:38:00 --> Config Class Initialized
INFO - 2018-08-22 19:38:00 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:38:00 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:38:00 --> Utf8 Class Initialized
INFO - 2018-08-22 19:38:00 --> URI Class Initialized
INFO - 2018-08-22 19:38:00 --> Router Class Initialized
INFO - 2018-08-22 19:38:00 --> Output Class Initialized
INFO - 2018-08-22 19:38:00 --> Security Class Initialized
DEBUG - 2018-08-22 19:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:38:00 --> CSRF cookie sent
INFO - 2018-08-22 19:38:00 --> Input Class Initialized
INFO - 2018-08-22 19:38:00 --> Language Class Initialized
INFO - 2018-08-22 19:38:00 --> Loader Class Initialized
INFO - 2018-08-22 19:38:00 --> Helper loaded: url_helper
INFO - 2018-08-22 19:38:00 --> Helper loaded: form_helper
INFO - 2018-08-22 19:38:00 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:38:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:38:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:38:00 --> User Agent Class Initialized
INFO - 2018-08-22 19:38:00 --> Controller Class Initialized
INFO - 2018-08-22 19:38:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:38:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:38:00 --> Pixel_Model class loaded
INFO - 2018-08-22 19:38:00 --> Database Driver Class Initialized
INFO - 2018-08-22 19:38:01 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:38:01 --> Database Driver Class Initialized
INFO - 2018-08-22 19:38:01 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:38:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:38:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 19:38:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:38:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:38:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:38:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:38:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:38:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-08-22 19:38:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:38:01 --> Final output sent to browser
DEBUG - 2018-08-22 19:38:01 --> Total execution time: 0.0574
INFO - 2018-08-22 19:38:01 --> Config Class Initialized
INFO - 2018-08-22 19:38:01 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:38:01 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:38:01 --> Utf8 Class Initialized
INFO - 2018-08-22 19:38:01 --> URI Class Initialized
INFO - 2018-08-22 19:38:01 --> Router Class Initialized
INFO - 2018-08-22 19:38:01 --> Output Class Initialized
INFO - 2018-08-22 19:38:01 --> Security Class Initialized
DEBUG - 2018-08-22 19:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:38:01 --> CSRF cookie sent
INFO - 2018-08-22 19:38:01 --> Input Class Initialized
INFO - 2018-08-22 19:38:01 --> Language Class Initialized
ERROR - 2018-08-22 19:38:01 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 19:38:40 --> Config Class Initialized
INFO - 2018-08-22 19:38:40 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:38:40 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:38:40 --> Utf8 Class Initialized
INFO - 2018-08-22 19:38:40 --> URI Class Initialized
INFO - 2018-08-22 19:38:40 --> Router Class Initialized
INFO - 2018-08-22 19:38:40 --> Output Class Initialized
INFO - 2018-08-22 19:38:40 --> Security Class Initialized
DEBUG - 2018-08-22 19:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:38:40 --> CSRF cookie sent
INFO - 2018-08-22 19:38:40 --> Input Class Initialized
INFO - 2018-08-22 19:38:40 --> Language Class Initialized
INFO - 2018-08-22 19:38:40 --> Loader Class Initialized
INFO - 2018-08-22 19:38:40 --> Helper loaded: url_helper
INFO - 2018-08-22 19:38:40 --> Helper loaded: form_helper
INFO - 2018-08-22 19:38:40 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:38:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:38:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:38:40 --> User Agent Class Initialized
INFO - 2018-08-22 19:38:40 --> Controller Class Initialized
INFO - 2018-08-22 19:38:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:38:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:38:40 --> Pixel_Model class loaded
INFO - 2018-08-22 19:38:40 --> Database Driver Class Initialized
INFO - 2018-08-22 19:38:40 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:38:40 --> Database Driver Class Initialized
INFO - 2018-08-22 19:38:40 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:38:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:38:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 19:38:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:38:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:38:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:38:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:38:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:38:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_owner.php
INFO - 2018-08-22 19:38:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:38:40 --> Final output sent to browser
DEBUG - 2018-08-22 19:38:40 --> Total execution time: 0.0567
INFO - 2018-08-22 19:38:41 --> Config Class Initialized
INFO - 2018-08-22 19:38:41 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:38:41 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:38:41 --> Utf8 Class Initialized
INFO - 2018-08-22 19:38:41 --> URI Class Initialized
INFO - 2018-08-22 19:38:41 --> Router Class Initialized
INFO - 2018-08-22 19:38:41 --> Output Class Initialized
INFO - 2018-08-22 19:38:41 --> Security Class Initialized
DEBUG - 2018-08-22 19:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:38:41 --> CSRF cookie sent
INFO - 2018-08-22 19:38:41 --> Input Class Initialized
INFO - 2018-08-22 19:38:41 --> Language Class Initialized
ERROR - 2018-08-22 19:38:41 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 19:39:07 --> Config Class Initialized
INFO - 2018-08-22 19:39:07 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:39:07 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:39:07 --> Utf8 Class Initialized
INFO - 2018-08-22 19:39:07 --> URI Class Initialized
INFO - 2018-08-22 19:39:07 --> Router Class Initialized
INFO - 2018-08-22 19:39:07 --> Output Class Initialized
INFO - 2018-08-22 19:39:07 --> Security Class Initialized
DEBUG - 2018-08-22 19:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:39:07 --> CSRF cookie sent
INFO - 2018-08-22 19:39:07 --> Input Class Initialized
INFO - 2018-08-22 19:39:07 --> Language Class Initialized
INFO - 2018-08-22 19:39:07 --> Loader Class Initialized
INFO - 2018-08-22 19:39:07 --> Helper loaded: url_helper
INFO - 2018-08-22 19:39:07 --> Helper loaded: form_helper
INFO - 2018-08-22 19:39:07 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:39:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:39:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:39:07 --> User Agent Class Initialized
INFO - 2018-08-22 19:39:07 --> Controller Class Initialized
INFO - 2018-08-22 19:39:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:39:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:39:07 --> Pixel_Model class loaded
INFO - 2018-08-22 19:39:07 --> Database Driver Class Initialized
INFO - 2018-08-22 19:39:07 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:39:07 --> Database Driver Class Initialized
INFO - 2018-08-22 19:39:07 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:39:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:39:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 19:39:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:39:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:39:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:39:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:39:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:39:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_value.php
INFO - 2018-08-22 19:39:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:39:07 --> Final output sent to browser
DEBUG - 2018-08-22 19:39:07 --> Total execution time: 0.0444
INFO - 2018-08-22 19:39:08 --> Config Class Initialized
INFO - 2018-08-22 19:39:08 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:39:08 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:39:08 --> Utf8 Class Initialized
INFO - 2018-08-22 19:39:08 --> URI Class Initialized
INFO - 2018-08-22 19:39:08 --> Router Class Initialized
INFO - 2018-08-22 19:39:08 --> Output Class Initialized
INFO - 2018-08-22 19:39:08 --> Security Class Initialized
DEBUG - 2018-08-22 19:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:39:08 --> CSRF cookie sent
INFO - 2018-08-22 19:39:08 --> Input Class Initialized
INFO - 2018-08-22 19:39:08 --> Language Class Initialized
ERROR - 2018-08-22 19:39:08 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 19:40:00 --> Config Class Initialized
INFO - 2018-08-22 19:40:00 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:40:00 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:40:00 --> Utf8 Class Initialized
INFO - 2018-08-22 19:40:00 --> URI Class Initialized
INFO - 2018-08-22 19:40:00 --> Router Class Initialized
INFO - 2018-08-22 19:40:00 --> Output Class Initialized
INFO - 2018-08-22 19:40:00 --> Security Class Initialized
DEBUG - 2018-08-22 19:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:40:00 --> CSRF cookie sent
INFO - 2018-08-22 19:40:00 --> Input Class Initialized
INFO - 2018-08-22 19:40:00 --> Language Class Initialized
INFO - 2018-08-22 19:40:00 --> Loader Class Initialized
INFO - 2018-08-22 19:40:00 --> Helper loaded: url_helper
INFO - 2018-08-22 19:40:00 --> Helper loaded: form_helper
INFO - 2018-08-22 19:40:00 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:40:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:40:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:40:00 --> User Agent Class Initialized
INFO - 2018-08-22 19:40:00 --> Controller Class Initialized
INFO - 2018-08-22 19:40:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:40:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:40:00 --> Pixel_Model class loaded
INFO - 2018-08-22 19:40:00 --> Database Driver Class Initialized
INFO - 2018-08-22 19:40:00 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:40:00 --> Database Driver Class Initialized
INFO - 2018-08-22 19:40:00 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:40:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:40:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 19:40:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:40:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:40:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:40:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:40:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:40:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_title.php
INFO - 2018-08-22 19:40:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:40:00 --> Final output sent to browser
DEBUG - 2018-08-22 19:40:00 --> Total execution time: 0.0709
INFO - 2018-08-22 19:40:01 --> Config Class Initialized
INFO - 2018-08-22 19:40:01 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:40:01 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:40:01 --> Utf8 Class Initialized
INFO - 2018-08-22 19:40:01 --> URI Class Initialized
INFO - 2018-08-22 19:40:01 --> Router Class Initialized
INFO - 2018-08-22 19:40:01 --> Output Class Initialized
INFO - 2018-08-22 19:40:01 --> Security Class Initialized
DEBUG - 2018-08-22 19:40:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:40:01 --> CSRF cookie sent
INFO - 2018-08-22 19:40:01 --> Input Class Initialized
INFO - 2018-08-22 19:40:01 --> Language Class Initialized
ERROR - 2018-08-22 19:40:01 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 19:40:28 --> Config Class Initialized
INFO - 2018-08-22 19:40:28 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:40:28 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:40:28 --> Utf8 Class Initialized
INFO - 2018-08-22 19:40:28 --> URI Class Initialized
INFO - 2018-08-22 19:40:28 --> Router Class Initialized
INFO - 2018-08-22 19:40:28 --> Output Class Initialized
INFO - 2018-08-22 19:40:28 --> Security Class Initialized
DEBUG - 2018-08-22 19:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:40:28 --> CSRF cookie sent
INFO - 2018-08-22 19:40:28 --> Input Class Initialized
INFO - 2018-08-22 19:40:28 --> Language Class Initialized
INFO - 2018-08-22 19:40:28 --> Loader Class Initialized
INFO - 2018-08-22 19:40:28 --> Helper loaded: url_helper
INFO - 2018-08-22 19:40:28 --> Helper loaded: form_helper
INFO - 2018-08-22 19:40:28 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:40:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:40:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:40:28 --> User Agent Class Initialized
INFO - 2018-08-22 19:40:28 --> Controller Class Initialized
INFO - 2018-08-22 19:40:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:40:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:40:28 --> Pixel_Model class loaded
INFO - 2018-08-22 19:40:28 --> Database Driver Class Initialized
INFO - 2018-08-22 19:40:28 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:40:28 --> Database Driver Class Initialized
INFO - 2018-08-22 19:40:28 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:40:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:40:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 19:40:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:40:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:40:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:40:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:40:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:40:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/merriage_home_title.php
INFO - 2018-08-22 19:40:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:40:28 --> Final output sent to browser
DEBUG - 2018-08-22 19:40:28 --> Total execution time: 0.0552
INFO - 2018-08-22 19:40:28 --> Config Class Initialized
INFO - 2018-08-22 19:40:28 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:40:28 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:40:28 --> Utf8 Class Initialized
INFO - 2018-08-22 19:40:28 --> URI Class Initialized
INFO - 2018-08-22 19:40:28 --> Router Class Initialized
INFO - 2018-08-22 19:40:28 --> Output Class Initialized
INFO - 2018-08-22 19:40:28 --> Security Class Initialized
DEBUG - 2018-08-22 19:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:40:28 --> CSRF cookie sent
INFO - 2018-08-22 19:40:28 --> Input Class Initialized
INFO - 2018-08-22 19:40:28 --> Language Class Initialized
ERROR - 2018-08-22 19:40:28 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 19:49:28 --> Config Class Initialized
INFO - 2018-08-22 19:49:28 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:49:28 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:49:28 --> Utf8 Class Initialized
INFO - 2018-08-22 19:49:28 --> URI Class Initialized
INFO - 2018-08-22 19:49:28 --> Router Class Initialized
INFO - 2018-08-22 19:49:28 --> Output Class Initialized
INFO - 2018-08-22 19:49:28 --> Security Class Initialized
DEBUG - 2018-08-22 19:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:49:28 --> CSRF cookie sent
INFO - 2018-08-22 19:49:28 --> Input Class Initialized
INFO - 2018-08-22 19:49:28 --> Language Class Initialized
INFO - 2018-08-22 19:49:28 --> Loader Class Initialized
INFO - 2018-08-22 19:49:28 --> Helper loaded: url_helper
INFO - 2018-08-22 19:49:28 --> Helper loaded: form_helper
INFO - 2018-08-22 19:49:28 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:49:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:49:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:49:28 --> User Agent Class Initialized
INFO - 2018-08-22 19:49:28 --> Controller Class Initialized
INFO - 2018-08-22 19:49:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:49:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:49:28 --> Pixel_Model class loaded
INFO - 2018-08-22 19:49:28 --> Database Driver Class Initialized
INFO - 2018-08-22 19:49:28 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:49:28 --> Database Driver Class Initialized
INFO - 2018-08-22 19:49:28 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:49:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:49:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 19:49:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:49:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:49:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:49:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:49:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:49:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-08-22 19:49:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:49:28 --> Final output sent to browser
DEBUG - 2018-08-22 19:49:28 --> Total execution time: 0.0463
INFO - 2018-08-22 19:49:29 --> Config Class Initialized
INFO - 2018-08-22 19:49:29 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:49:29 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:49:29 --> Utf8 Class Initialized
INFO - 2018-08-22 19:49:29 --> URI Class Initialized
INFO - 2018-08-22 19:49:29 --> Router Class Initialized
INFO - 2018-08-22 19:49:29 --> Output Class Initialized
INFO - 2018-08-22 19:49:29 --> Security Class Initialized
DEBUG - 2018-08-22 19:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:49:29 --> CSRF cookie sent
INFO - 2018-08-22 19:49:29 --> Input Class Initialized
INFO - 2018-08-22 19:49:29 --> Language Class Initialized
ERROR - 2018-08-22 19:49:29 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 19:50:11 --> Config Class Initialized
INFO - 2018-08-22 19:50:11 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:50:11 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:50:11 --> Utf8 Class Initialized
INFO - 2018-08-22 19:50:11 --> URI Class Initialized
INFO - 2018-08-22 19:50:11 --> Router Class Initialized
INFO - 2018-08-22 19:50:11 --> Output Class Initialized
INFO - 2018-08-22 19:50:11 --> Security Class Initialized
DEBUG - 2018-08-22 19:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:50:11 --> CSRF cookie sent
INFO - 2018-08-22 19:50:11 --> Input Class Initialized
INFO - 2018-08-22 19:50:11 --> Language Class Initialized
INFO - 2018-08-22 19:50:11 --> Loader Class Initialized
INFO - 2018-08-22 19:50:11 --> Helper loaded: url_helper
INFO - 2018-08-22 19:50:11 --> Helper loaded: form_helper
INFO - 2018-08-22 19:50:11 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:50:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:50:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:50:11 --> User Agent Class Initialized
INFO - 2018-08-22 19:50:11 --> Controller Class Initialized
INFO - 2018-08-22 19:50:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:50:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:50:11 --> Pixel_Model class loaded
INFO - 2018-08-22 19:50:11 --> Database Driver Class Initialized
INFO - 2018-08-22 19:50:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:50:11 --> Database Driver Class Initialized
INFO - 2018-08-22 19:50:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:50:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:50:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 19:50:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:50:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:50:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:50:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:50:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:50:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/other_kids.php
INFO - 2018-08-22 19:50:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:50:11 --> Final output sent to browser
DEBUG - 2018-08-22 19:50:11 --> Total execution time: 0.0498
INFO - 2018-08-22 19:50:15 --> Config Class Initialized
INFO - 2018-08-22 19:50:15 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:50:15 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:50:15 --> Utf8 Class Initialized
INFO - 2018-08-22 19:50:15 --> URI Class Initialized
INFO - 2018-08-22 19:50:15 --> Router Class Initialized
INFO - 2018-08-22 19:50:15 --> Output Class Initialized
INFO - 2018-08-22 19:50:15 --> Security Class Initialized
DEBUG - 2018-08-22 19:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:50:15 --> CSRF cookie sent
INFO - 2018-08-22 19:50:15 --> Input Class Initialized
INFO - 2018-08-22 19:50:15 --> Language Class Initialized
ERROR - 2018-08-22 19:50:15 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 19:50:38 --> Config Class Initialized
INFO - 2018-08-22 19:50:38 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:50:38 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:50:38 --> Utf8 Class Initialized
INFO - 2018-08-22 19:50:38 --> URI Class Initialized
INFO - 2018-08-22 19:50:38 --> Router Class Initialized
INFO - 2018-08-22 19:50:38 --> Output Class Initialized
INFO - 2018-08-22 19:50:38 --> Security Class Initialized
DEBUG - 2018-08-22 19:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:50:38 --> CSRF cookie sent
INFO - 2018-08-22 19:50:38 --> Input Class Initialized
INFO - 2018-08-22 19:50:38 --> Language Class Initialized
INFO - 2018-08-22 19:50:38 --> Loader Class Initialized
INFO - 2018-08-22 19:50:38 --> Helper loaded: url_helper
INFO - 2018-08-22 19:50:38 --> Helper loaded: form_helper
INFO - 2018-08-22 19:50:38 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:50:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:50:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:50:38 --> User Agent Class Initialized
INFO - 2018-08-22 19:50:38 --> Controller Class Initialized
INFO - 2018-08-22 19:50:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:50:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:50:38 --> Pixel_Model class loaded
INFO - 2018-08-22 19:50:38 --> Database Driver Class Initialized
INFO - 2018-08-22 19:50:38 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:50:38 --> Database Driver Class Initialized
INFO - 2018-08-22 19:50:38 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:50:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:50:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 19:50:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:50:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:50:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:50:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:50:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:50:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids_info.php
INFO - 2018-08-22 19:50:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:50:38 --> Final output sent to browser
DEBUG - 2018-08-22 19:50:38 --> Total execution time: 0.0500
INFO - 2018-08-22 19:50:45 --> Config Class Initialized
INFO - 2018-08-22 19:50:45 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:50:45 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:50:45 --> Utf8 Class Initialized
INFO - 2018-08-22 19:50:45 --> URI Class Initialized
INFO - 2018-08-22 19:50:45 --> Router Class Initialized
INFO - 2018-08-22 19:50:45 --> Output Class Initialized
INFO - 2018-08-22 19:50:45 --> Security Class Initialized
DEBUG - 2018-08-22 19:50:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:50:45 --> CSRF cookie sent
INFO - 2018-08-22 19:50:45 --> Input Class Initialized
INFO - 2018-08-22 19:50:45 --> Language Class Initialized
ERROR - 2018-08-22 19:50:45 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 19:50:48 --> Config Class Initialized
INFO - 2018-08-22 19:50:48 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:50:48 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:50:48 --> Utf8 Class Initialized
INFO - 2018-08-22 19:50:48 --> URI Class Initialized
INFO - 2018-08-22 19:50:48 --> Router Class Initialized
INFO - 2018-08-22 19:50:48 --> Output Class Initialized
INFO - 2018-08-22 19:50:48 --> Security Class Initialized
DEBUG - 2018-08-22 19:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:50:48 --> CSRF cookie sent
INFO - 2018-08-22 19:50:48 --> Input Class Initialized
INFO - 2018-08-22 19:50:48 --> Language Class Initialized
INFO - 2018-08-22 19:50:48 --> Loader Class Initialized
INFO - 2018-08-22 19:50:48 --> Helper loaded: url_helper
INFO - 2018-08-22 19:50:48 --> Helper loaded: form_helper
INFO - 2018-08-22 19:50:48 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:50:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:50:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:50:48 --> User Agent Class Initialized
INFO - 2018-08-22 19:50:48 --> Controller Class Initialized
INFO - 2018-08-22 19:50:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:50:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:50:48 --> Pixel_Model class loaded
INFO - 2018-08-22 19:50:48 --> Database Driver Class Initialized
INFO - 2018-08-22 19:50:48 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:50:48 --> Database Driver Class Initialized
INFO - 2018-08-22 19:50:48 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:50:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:50:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 19:50:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:50:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:50:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:50:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:50:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:50:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-08-22 19:50:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:50:48 --> Final output sent to browser
DEBUG - 2018-08-22 19:50:48 --> Total execution time: 0.0498
INFO - 2018-08-22 19:50:51 --> Config Class Initialized
INFO - 2018-08-22 19:50:51 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:50:51 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:50:51 --> Utf8 Class Initialized
INFO - 2018-08-22 19:50:51 --> URI Class Initialized
INFO - 2018-08-22 19:50:51 --> Router Class Initialized
INFO - 2018-08-22 19:50:51 --> Output Class Initialized
INFO - 2018-08-22 19:50:51 --> Security Class Initialized
DEBUG - 2018-08-22 19:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:50:51 --> CSRF cookie sent
INFO - 2018-08-22 19:50:51 --> Input Class Initialized
INFO - 2018-08-22 19:50:51 --> Language Class Initialized
ERROR - 2018-08-22 19:50:51 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 19:50:56 --> Config Class Initialized
INFO - 2018-08-22 19:50:56 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:50:56 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:50:56 --> Utf8 Class Initialized
INFO - 2018-08-22 19:50:56 --> URI Class Initialized
INFO - 2018-08-22 19:50:56 --> Router Class Initialized
INFO - 2018-08-22 19:50:56 --> Output Class Initialized
INFO - 2018-08-22 19:50:56 --> Security Class Initialized
DEBUG - 2018-08-22 19:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:50:56 --> CSRF cookie sent
INFO - 2018-08-22 19:50:56 --> CSRF token verified
INFO - 2018-08-22 19:50:56 --> Input Class Initialized
INFO - 2018-08-22 19:50:56 --> Language Class Initialized
INFO - 2018-08-22 19:50:56 --> Loader Class Initialized
INFO - 2018-08-22 19:50:56 --> Helper loaded: url_helper
INFO - 2018-08-22 19:50:56 --> Helper loaded: form_helper
INFO - 2018-08-22 19:50:56 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:50:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:50:56 --> User Agent Class Initialized
INFO - 2018-08-22 19:50:56 --> Controller Class Initialized
INFO - 2018-08-22 19:50:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:50:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:50:56 --> Pixel_Model class loaded
INFO - 2018-08-22 19:50:56 --> Database Driver Class Initialized
INFO - 2018-08-22 19:50:56 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:50:56 --> Form Validation Class Initialized
INFO - 2018-08-22 19:50:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 19:50:56 --> Database Driver Class Initialized
INFO - 2018-08-22 19:50:56 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:50:56 --> Config Class Initialized
INFO - 2018-08-22 19:50:56 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:50:56 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:50:56 --> Utf8 Class Initialized
INFO - 2018-08-22 19:50:56 --> URI Class Initialized
INFO - 2018-08-22 19:50:56 --> Router Class Initialized
INFO - 2018-08-22 19:50:56 --> Output Class Initialized
INFO - 2018-08-22 19:50:56 --> Security Class Initialized
DEBUG - 2018-08-22 19:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:50:56 --> CSRF cookie sent
INFO - 2018-08-22 19:50:56 --> Input Class Initialized
INFO - 2018-08-22 19:50:56 --> Language Class Initialized
INFO - 2018-08-22 19:50:56 --> Loader Class Initialized
INFO - 2018-08-22 19:50:56 --> Helper loaded: url_helper
INFO - 2018-08-22 19:50:56 --> Helper loaded: form_helper
INFO - 2018-08-22 19:50:56 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:50:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:50:56 --> User Agent Class Initialized
INFO - 2018-08-22 19:50:56 --> Controller Class Initialized
INFO - 2018-08-22 19:50:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:50:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:50:56 --> Pixel_Model class loaded
INFO - 2018-08-22 19:50:56 --> Database Driver Class Initialized
INFO - 2018-08-22 19:50:56 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:50:56 --> Database Driver Class Initialized
INFO - 2018-08-22 19:50:56 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:50:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:50:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 19:50:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:50:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:50:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:50:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:50:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:50:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids_info.php
INFO - 2018-08-22 19:50:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:50:56 --> Final output sent to browser
DEBUG - 2018-08-22 19:50:56 --> Total execution time: 0.0367
INFO - 2018-08-22 19:50:58 --> Config Class Initialized
INFO - 2018-08-22 19:50:58 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:50:58 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:50:58 --> Utf8 Class Initialized
INFO - 2018-08-22 19:50:58 --> URI Class Initialized
INFO - 2018-08-22 19:50:58 --> Router Class Initialized
INFO - 2018-08-22 19:50:58 --> Output Class Initialized
INFO - 2018-08-22 19:50:58 --> Security Class Initialized
DEBUG - 2018-08-22 19:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:50:58 --> CSRF cookie sent
INFO - 2018-08-22 19:50:58 --> Input Class Initialized
INFO - 2018-08-22 19:50:58 --> Language Class Initialized
ERROR - 2018-08-22 19:50:58 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 19:51:34 --> Config Class Initialized
INFO - 2018-08-22 19:51:34 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:51:34 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:51:34 --> Utf8 Class Initialized
INFO - 2018-08-22 19:51:34 --> URI Class Initialized
INFO - 2018-08-22 19:51:34 --> Router Class Initialized
INFO - 2018-08-22 19:51:34 --> Output Class Initialized
INFO - 2018-08-22 19:51:34 --> Security Class Initialized
DEBUG - 2018-08-22 19:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:51:34 --> CSRF cookie sent
INFO - 2018-08-22 19:51:34 --> CSRF token verified
INFO - 2018-08-22 19:51:34 --> Input Class Initialized
INFO - 2018-08-22 19:51:34 --> Language Class Initialized
INFO - 2018-08-22 19:51:34 --> Loader Class Initialized
INFO - 2018-08-22 19:51:34 --> Helper loaded: url_helper
INFO - 2018-08-22 19:51:34 --> Helper loaded: form_helper
INFO - 2018-08-22 19:51:34 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:51:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:51:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:51:34 --> User Agent Class Initialized
INFO - 2018-08-22 19:51:34 --> Controller Class Initialized
INFO - 2018-08-22 19:51:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:51:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:51:34 --> Pixel_Model class loaded
INFO - 2018-08-22 19:51:34 --> Database Driver Class Initialized
INFO - 2018-08-22 19:51:34 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:51:34 --> Form Validation Class Initialized
INFO - 2018-08-22 19:51:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 19:51:34 --> Database Driver Class Initialized
INFO - 2018-08-22 19:51:34 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:51:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:51:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 19:51:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:51:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:51:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:51:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:51:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_errors.php
INFO - 2018-08-22 19:51:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:51:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids_info.php
INFO - 2018-08-22 19:51:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:51:34 --> Final output sent to browser
DEBUG - 2018-08-22 19:51:34 --> Total execution time: 0.0613
INFO - 2018-08-22 19:51:34 --> Config Class Initialized
INFO - 2018-08-22 19:51:34 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:51:34 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:51:34 --> Utf8 Class Initialized
INFO - 2018-08-22 19:51:34 --> URI Class Initialized
INFO - 2018-08-22 19:51:34 --> Router Class Initialized
INFO - 2018-08-22 19:51:34 --> Output Class Initialized
INFO - 2018-08-22 19:51:34 --> Security Class Initialized
DEBUG - 2018-08-22 19:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:51:34 --> CSRF cookie sent
INFO - 2018-08-22 19:51:34 --> Input Class Initialized
INFO - 2018-08-22 19:51:34 --> Language Class Initialized
ERROR - 2018-08-22 19:51:34 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 19:51:38 --> Config Class Initialized
INFO - 2018-08-22 19:51:38 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:51:38 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:51:38 --> Utf8 Class Initialized
INFO - 2018-08-22 19:51:38 --> URI Class Initialized
INFO - 2018-08-22 19:51:38 --> Router Class Initialized
INFO - 2018-08-22 19:51:38 --> Output Class Initialized
INFO - 2018-08-22 19:51:38 --> Security Class Initialized
DEBUG - 2018-08-22 19:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:51:38 --> CSRF cookie sent
INFO - 2018-08-22 19:51:38 --> Input Class Initialized
INFO - 2018-08-22 19:51:38 --> Language Class Initialized
INFO - 2018-08-22 19:51:38 --> Loader Class Initialized
INFO - 2018-08-22 19:51:38 --> Helper loaded: url_helper
INFO - 2018-08-22 19:51:38 --> Helper loaded: form_helper
INFO - 2018-08-22 19:51:38 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:51:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:51:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:51:38 --> User Agent Class Initialized
INFO - 2018-08-22 19:51:38 --> Controller Class Initialized
INFO - 2018-08-22 19:51:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:51:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:51:38 --> Pixel_Model class loaded
INFO - 2018-08-22 19:51:38 --> Database Driver Class Initialized
INFO - 2018-08-22 19:51:38 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:51:38 --> Database Driver Class Initialized
INFO - 2018-08-22 19:51:38 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:51:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:51:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 19:51:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:51:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:51:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:51:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:51:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:51:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/other_kids.php
INFO - 2018-08-22 19:51:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:51:38 --> Final output sent to browser
DEBUG - 2018-08-22 19:51:38 --> Total execution time: 0.0590
INFO - 2018-08-22 19:51:38 --> Config Class Initialized
INFO - 2018-08-22 19:51:38 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:51:38 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:51:38 --> Utf8 Class Initialized
INFO - 2018-08-22 19:51:38 --> URI Class Initialized
INFO - 2018-08-22 19:51:38 --> Router Class Initialized
INFO - 2018-08-22 19:51:38 --> Output Class Initialized
INFO - 2018-08-22 19:51:38 --> Security Class Initialized
DEBUG - 2018-08-22 19:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:51:38 --> CSRF cookie sent
INFO - 2018-08-22 19:51:38 --> Input Class Initialized
INFO - 2018-08-22 19:51:38 --> Language Class Initialized
ERROR - 2018-08-22 19:51:38 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 19:51:40 --> Config Class Initialized
INFO - 2018-08-22 19:51:40 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:51:40 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:51:40 --> Utf8 Class Initialized
INFO - 2018-08-22 19:51:40 --> URI Class Initialized
INFO - 2018-08-22 19:51:40 --> Router Class Initialized
INFO - 2018-08-22 19:51:40 --> Output Class Initialized
INFO - 2018-08-22 19:51:40 --> Security Class Initialized
DEBUG - 2018-08-22 19:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:51:40 --> CSRF cookie sent
INFO - 2018-08-22 19:51:40 --> Input Class Initialized
INFO - 2018-08-22 19:51:40 --> Language Class Initialized
INFO - 2018-08-22 19:51:40 --> Loader Class Initialized
INFO - 2018-08-22 19:51:40 --> Helper loaded: url_helper
INFO - 2018-08-22 19:51:40 --> Helper loaded: form_helper
INFO - 2018-08-22 19:51:40 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:51:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:51:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:51:40 --> User Agent Class Initialized
INFO - 2018-08-22 19:51:40 --> Controller Class Initialized
INFO - 2018-08-22 19:51:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:51:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:51:40 --> Pixel_Model class loaded
INFO - 2018-08-22 19:51:40 --> Database Driver Class Initialized
INFO - 2018-08-22 19:51:40 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:51:40 --> Database Driver Class Initialized
INFO - 2018-08-22 19:51:40 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:51:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:51:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 19:51:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:51:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:51:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:51:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:51:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:51:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids_activities.php
INFO - 2018-08-22 19:51:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:51:40 --> Final output sent to browser
DEBUG - 2018-08-22 19:51:40 --> Total execution time: 0.0449
INFO - 2018-08-22 19:51:41 --> Config Class Initialized
INFO - 2018-08-22 19:51:41 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:51:41 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:51:41 --> Utf8 Class Initialized
INFO - 2018-08-22 19:51:41 --> URI Class Initialized
INFO - 2018-08-22 19:51:41 --> Router Class Initialized
INFO - 2018-08-22 19:51:41 --> Output Class Initialized
INFO - 2018-08-22 19:51:41 --> Security Class Initialized
DEBUG - 2018-08-22 19:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:51:41 --> CSRF cookie sent
INFO - 2018-08-22 19:51:41 --> Input Class Initialized
INFO - 2018-08-22 19:51:41 --> Language Class Initialized
ERROR - 2018-08-22 19:51:41 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 19:52:17 --> Config Class Initialized
INFO - 2018-08-22 19:52:17 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:52:17 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:52:17 --> Utf8 Class Initialized
INFO - 2018-08-22 19:52:17 --> URI Class Initialized
INFO - 2018-08-22 19:52:17 --> Router Class Initialized
INFO - 2018-08-22 19:52:17 --> Output Class Initialized
INFO - 2018-08-22 19:52:17 --> Security Class Initialized
DEBUG - 2018-08-22 19:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:52:17 --> CSRF cookie sent
INFO - 2018-08-22 19:52:17 --> Input Class Initialized
INFO - 2018-08-22 19:52:17 --> Language Class Initialized
INFO - 2018-08-22 19:52:17 --> Loader Class Initialized
INFO - 2018-08-22 19:52:17 --> Helper loaded: url_helper
INFO - 2018-08-22 19:52:17 --> Helper loaded: form_helper
INFO - 2018-08-22 19:52:17 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:52:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:52:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:52:17 --> User Agent Class Initialized
INFO - 2018-08-22 19:52:17 --> Controller Class Initialized
INFO - 2018-08-22 19:52:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:52:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:52:17 --> Pixel_Model class loaded
INFO - 2018-08-22 19:52:17 --> Database Driver Class Initialized
INFO - 2018-08-22 19:52:17 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:52:17 --> Database Driver Class Initialized
INFO - 2018-08-22 19:52:17 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:52:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:52:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 19:52:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:52:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:52:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:52:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:52:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:52:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids_communicate.php
INFO - 2018-08-22 19:52:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:52:17 --> Final output sent to browser
DEBUG - 2018-08-22 19:52:17 --> Total execution time: 0.0573
INFO - 2018-08-22 19:52:18 --> Config Class Initialized
INFO - 2018-08-22 19:52:18 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:52:18 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:52:18 --> Utf8 Class Initialized
INFO - 2018-08-22 19:52:18 --> URI Class Initialized
INFO - 2018-08-22 19:52:18 --> Router Class Initialized
INFO - 2018-08-22 19:52:18 --> Output Class Initialized
INFO - 2018-08-22 19:52:18 --> Security Class Initialized
DEBUG - 2018-08-22 19:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:52:18 --> CSRF cookie sent
INFO - 2018-08-22 19:52:18 --> Input Class Initialized
INFO - 2018-08-22 19:52:18 --> Language Class Initialized
ERROR - 2018-08-22 19:52:18 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 19:52:33 --> Config Class Initialized
INFO - 2018-08-22 19:52:33 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:52:33 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:52:33 --> Utf8 Class Initialized
INFO - 2018-08-22 19:52:33 --> URI Class Initialized
INFO - 2018-08-22 19:52:33 --> Router Class Initialized
INFO - 2018-08-22 19:52:33 --> Output Class Initialized
INFO - 2018-08-22 19:52:33 --> Security Class Initialized
DEBUG - 2018-08-22 19:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:52:33 --> CSRF cookie sent
INFO - 2018-08-22 19:52:33 --> Input Class Initialized
INFO - 2018-08-22 19:52:33 --> Language Class Initialized
INFO - 2018-08-22 19:52:33 --> Loader Class Initialized
INFO - 2018-08-22 19:52:33 --> Helper loaded: url_helper
INFO - 2018-08-22 19:52:33 --> Helper loaded: form_helper
INFO - 2018-08-22 19:52:33 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:52:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:52:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:52:33 --> User Agent Class Initialized
INFO - 2018-08-22 19:52:33 --> Controller Class Initialized
INFO - 2018-08-22 19:52:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:52:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:52:33 --> Pixel_Model class loaded
INFO - 2018-08-22 19:52:33 --> Database Driver Class Initialized
INFO - 2018-08-22 19:52:33 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:52:33 --> Database Driver Class Initialized
INFO - 2018-08-22 19:52:33 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:52:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:52:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 19:52:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:52:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:52:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:52:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:52:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:52:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids_dinner.php
INFO - 2018-08-22 19:52:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:52:33 --> Final output sent to browser
DEBUG - 2018-08-22 19:52:33 --> Total execution time: 0.0651
INFO - 2018-08-22 19:52:34 --> Config Class Initialized
INFO - 2018-08-22 19:52:34 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:52:34 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:52:34 --> Utf8 Class Initialized
INFO - 2018-08-22 19:52:34 --> URI Class Initialized
INFO - 2018-08-22 19:52:34 --> Router Class Initialized
INFO - 2018-08-22 19:52:34 --> Output Class Initialized
INFO - 2018-08-22 19:52:34 --> Security Class Initialized
DEBUG - 2018-08-22 19:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:52:34 --> CSRF cookie sent
INFO - 2018-08-22 19:52:34 --> Input Class Initialized
INFO - 2018-08-22 19:52:34 --> Language Class Initialized
ERROR - 2018-08-22 19:52:34 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 19:52:51 --> Config Class Initialized
INFO - 2018-08-22 19:52:51 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:52:51 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:52:51 --> Utf8 Class Initialized
INFO - 2018-08-22 19:52:51 --> URI Class Initialized
INFO - 2018-08-22 19:52:51 --> Router Class Initialized
INFO - 2018-08-22 19:52:51 --> Output Class Initialized
INFO - 2018-08-22 19:52:51 --> Security Class Initialized
DEBUG - 2018-08-22 19:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:52:51 --> CSRF cookie sent
INFO - 2018-08-22 19:52:51 --> Input Class Initialized
INFO - 2018-08-22 19:52:51 --> Language Class Initialized
INFO - 2018-08-22 19:52:51 --> Loader Class Initialized
INFO - 2018-08-22 19:52:51 --> Helper loaded: url_helper
INFO - 2018-08-22 19:52:51 --> Helper loaded: form_helper
INFO - 2018-08-22 19:52:51 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:52:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:52:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:52:51 --> User Agent Class Initialized
INFO - 2018-08-22 19:52:51 --> Controller Class Initialized
INFO - 2018-08-22 19:52:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:52:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:52:51 --> Pixel_Model class loaded
INFO - 2018-08-22 19:52:51 --> Database Driver Class Initialized
INFO - 2018-08-22 19:52:51 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:52:51 --> Database Driver Class Initialized
INFO - 2018-08-22 19:52:51 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:52:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:52:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 19:52:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:52:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:52:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:52:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:52:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:52:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids_homework.php
INFO - 2018-08-22 19:52:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:52:51 --> Final output sent to browser
DEBUG - 2018-08-22 19:52:51 --> Total execution time: 0.0642
INFO - 2018-08-22 19:52:52 --> Config Class Initialized
INFO - 2018-08-22 19:52:52 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:52:52 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:52:52 --> Utf8 Class Initialized
INFO - 2018-08-22 19:52:52 --> URI Class Initialized
INFO - 2018-08-22 19:52:52 --> Router Class Initialized
INFO - 2018-08-22 19:52:52 --> Output Class Initialized
INFO - 2018-08-22 19:52:52 --> Security Class Initialized
DEBUG - 2018-08-22 19:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:52:52 --> CSRF cookie sent
INFO - 2018-08-22 19:52:52 --> Input Class Initialized
INFO - 2018-08-22 19:52:52 --> Language Class Initialized
ERROR - 2018-08-22 19:52:52 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 19:53:17 --> Config Class Initialized
INFO - 2018-08-22 19:53:17 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:53:17 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:53:17 --> Utf8 Class Initialized
INFO - 2018-08-22 19:53:17 --> URI Class Initialized
INFO - 2018-08-22 19:53:17 --> Router Class Initialized
INFO - 2018-08-22 19:53:17 --> Output Class Initialized
INFO - 2018-08-22 19:53:17 --> Security Class Initialized
DEBUG - 2018-08-22 19:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:53:17 --> CSRF cookie sent
INFO - 2018-08-22 19:53:17 --> Input Class Initialized
INFO - 2018-08-22 19:53:17 --> Language Class Initialized
INFO - 2018-08-22 19:53:17 --> Loader Class Initialized
INFO - 2018-08-22 19:53:17 --> Helper loaded: url_helper
INFO - 2018-08-22 19:53:17 --> Helper loaded: form_helper
INFO - 2018-08-22 19:53:17 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:53:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:53:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:53:17 --> User Agent Class Initialized
INFO - 2018-08-22 19:53:17 --> Controller Class Initialized
INFO - 2018-08-22 19:53:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:53:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:53:17 --> Pixel_Model class loaded
INFO - 2018-08-22 19:53:17 --> Database Driver Class Initialized
INFO - 2018-08-22 19:53:17 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:53:17 --> Database Driver Class Initialized
INFO - 2018-08-22 19:53:17 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:53:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:53:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 19:53:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:53:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:53:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:53:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:53:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:53:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids_doctor.php
INFO - 2018-08-22 19:53:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:53:17 --> Final output sent to browser
DEBUG - 2018-08-22 19:53:17 --> Total execution time: 0.0441
INFO - 2018-08-22 19:53:18 --> Config Class Initialized
INFO - 2018-08-22 19:53:18 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:53:18 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:53:18 --> Utf8 Class Initialized
INFO - 2018-08-22 19:53:18 --> URI Class Initialized
INFO - 2018-08-22 19:53:18 --> Router Class Initialized
INFO - 2018-08-22 19:53:18 --> Output Class Initialized
INFO - 2018-08-22 19:53:18 --> Security Class Initialized
DEBUG - 2018-08-22 19:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:53:18 --> CSRF cookie sent
INFO - 2018-08-22 19:53:18 --> Input Class Initialized
INFO - 2018-08-22 19:53:18 --> Language Class Initialized
ERROR - 2018-08-22 19:53:18 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 19:53:37 --> Config Class Initialized
INFO - 2018-08-22 19:53:37 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:53:37 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:53:37 --> Utf8 Class Initialized
INFO - 2018-08-22 19:53:37 --> URI Class Initialized
INFO - 2018-08-22 19:53:37 --> Router Class Initialized
INFO - 2018-08-22 19:53:37 --> Output Class Initialized
INFO - 2018-08-22 19:53:37 --> Security Class Initialized
DEBUG - 2018-08-22 19:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:53:37 --> CSRF cookie sent
INFO - 2018-08-22 19:53:37 --> Input Class Initialized
INFO - 2018-08-22 19:53:37 --> Language Class Initialized
INFO - 2018-08-22 19:53:37 --> Loader Class Initialized
INFO - 2018-08-22 19:53:37 --> Helper loaded: url_helper
INFO - 2018-08-22 19:53:37 --> Helper loaded: form_helper
INFO - 2018-08-22 19:53:37 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:53:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:53:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:53:37 --> User Agent Class Initialized
INFO - 2018-08-22 19:53:37 --> Controller Class Initialized
INFO - 2018-08-22 19:53:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:53:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:53:37 --> Pixel_Model class loaded
INFO - 2018-08-22 19:53:37 --> Database Driver Class Initialized
INFO - 2018-08-22 19:53:37 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:53:37 --> Database Driver Class Initialized
INFO - 2018-08-22 19:53:37 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:53:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:53:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 19:53:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:53:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:53:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:53:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:53:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:53:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids_help_complaint.php
INFO - 2018-08-22 19:53:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:53:37 --> Final output sent to browser
DEBUG - 2018-08-22 19:53:37 --> Total execution time: 0.0656
INFO - 2018-08-22 19:53:38 --> Config Class Initialized
INFO - 2018-08-22 19:53:38 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:53:38 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:53:38 --> Utf8 Class Initialized
INFO - 2018-08-22 19:53:38 --> URI Class Initialized
INFO - 2018-08-22 19:53:38 --> Router Class Initialized
INFO - 2018-08-22 19:53:38 --> Output Class Initialized
INFO - 2018-08-22 19:53:38 --> Security Class Initialized
DEBUG - 2018-08-22 19:53:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:53:38 --> CSRF cookie sent
INFO - 2018-08-22 19:53:38 --> Input Class Initialized
INFO - 2018-08-22 19:53:38 --> Language Class Initialized
ERROR - 2018-08-22 19:53:38 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 19:54:03 --> Config Class Initialized
INFO - 2018-08-22 19:54:03 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:54:03 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:54:03 --> Utf8 Class Initialized
INFO - 2018-08-22 19:54:03 --> URI Class Initialized
INFO - 2018-08-22 19:54:03 --> Router Class Initialized
INFO - 2018-08-22 19:54:03 --> Output Class Initialized
INFO - 2018-08-22 19:54:03 --> Security Class Initialized
DEBUG - 2018-08-22 19:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:54:03 --> CSRF cookie sent
INFO - 2018-08-22 19:54:03 --> Input Class Initialized
INFO - 2018-08-22 19:54:03 --> Language Class Initialized
INFO - 2018-08-22 19:54:03 --> Loader Class Initialized
INFO - 2018-08-22 19:54:03 --> Helper loaded: url_helper
INFO - 2018-08-22 19:54:03 --> Helper loaded: form_helper
INFO - 2018-08-22 19:54:03 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:54:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:54:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:54:03 --> User Agent Class Initialized
INFO - 2018-08-22 19:54:03 --> Controller Class Initialized
INFO - 2018-08-22 19:54:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:54:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:54:03 --> Pixel_Model class loaded
INFO - 2018-08-22 19:54:03 --> Database Driver Class Initialized
INFO - 2018-08-22 19:54:03 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:54:03 --> Database Driver Class Initialized
INFO - 2018-08-22 19:54:03 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:54:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:54:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 19:54:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:54:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:54:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:54:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:54:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:54:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/spouse_info.php
INFO - 2018-08-22 19:54:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:54:03 --> Final output sent to browser
DEBUG - 2018-08-22 19:54:03 --> Total execution time: 0.0492
INFO - 2018-08-22 19:54:03 --> Config Class Initialized
INFO - 2018-08-22 19:54:03 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:54:03 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:54:03 --> Utf8 Class Initialized
INFO - 2018-08-22 19:54:03 --> URI Class Initialized
INFO - 2018-08-22 19:54:03 --> Router Class Initialized
INFO - 2018-08-22 19:54:03 --> Output Class Initialized
INFO - 2018-08-22 19:54:03 --> Security Class Initialized
DEBUG - 2018-08-22 19:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:54:03 --> CSRF cookie sent
INFO - 2018-08-22 19:54:03 --> Input Class Initialized
INFO - 2018-08-22 19:54:03 --> Language Class Initialized
ERROR - 2018-08-22 19:54:03 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 19:54:37 --> Config Class Initialized
INFO - 2018-08-22 19:54:37 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:54:37 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:54:37 --> Utf8 Class Initialized
INFO - 2018-08-22 19:54:37 --> URI Class Initialized
INFO - 2018-08-22 19:54:37 --> Router Class Initialized
INFO - 2018-08-22 19:54:37 --> Output Class Initialized
INFO - 2018-08-22 19:54:37 --> Security Class Initialized
DEBUG - 2018-08-22 19:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:54:37 --> CSRF cookie sent
INFO - 2018-08-22 19:54:37 --> Input Class Initialized
INFO - 2018-08-22 19:54:37 --> Language Class Initialized
INFO - 2018-08-22 19:54:37 --> Loader Class Initialized
INFO - 2018-08-22 19:54:37 --> Helper loaded: url_helper
INFO - 2018-08-22 19:54:37 --> Helper loaded: form_helper
INFO - 2018-08-22 19:54:37 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:54:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:54:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:54:37 --> User Agent Class Initialized
INFO - 2018-08-22 19:54:37 --> Controller Class Initialized
INFO - 2018-08-22 19:54:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:54:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:54:37 --> Pixel_Model class loaded
INFO - 2018-08-22 19:54:37 --> Database Driver Class Initialized
INFO - 2018-08-22 19:54:37 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:54:37 --> Database Driver Class Initialized
INFO - 2018-08-22 19:54:37 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:54:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:54:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 19:54:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:54:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:54:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:54:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:54:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:54:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/spouse_job.php
INFO - 2018-08-22 19:54:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:54:37 --> Final output sent to browser
DEBUG - 2018-08-22 19:54:37 --> Total execution time: 0.0468
INFO - 2018-08-22 19:54:38 --> Config Class Initialized
INFO - 2018-08-22 19:54:38 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:54:38 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:54:38 --> Utf8 Class Initialized
INFO - 2018-08-22 19:54:38 --> URI Class Initialized
INFO - 2018-08-22 19:54:38 --> Router Class Initialized
INFO - 2018-08-22 19:54:38 --> Output Class Initialized
INFO - 2018-08-22 19:54:38 --> Security Class Initialized
DEBUG - 2018-08-22 19:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:54:38 --> CSRF cookie sent
INFO - 2018-08-22 19:54:38 --> Input Class Initialized
INFO - 2018-08-22 19:54:38 --> Language Class Initialized
ERROR - 2018-08-22 19:54:38 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 19:54:56 --> Config Class Initialized
INFO - 2018-08-22 19:54:56 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:54:56 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:54:56 --> Utf8 Class Initialized
INFO - 2018-08-22 19:54:56 --> URI Class Initialized
INFO - 2018-08-22 19:54:56 --> Router Class Initialized
INFO - 2018-08-22 19:54:56 --> Output Class Initialized
INFO - 2018-08-22 19:54:56 --> Security Class Initialized
DEBUG - 2018-08-22 19:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:54:56 --> CSRF cookie sent
INFO - 2018-08-22 19:54:56 --> Input Class Initialized
INFO - 2018-08-22 19:54:56 --> Language Class Initialized
INFO - 2018-08-22 19:54:56 --> Loader Class Initialized
INFO - 2018-08-22 19:54:56 --> Helper loaded: url_helper
INFO - 2018-08-22 19:54:56 --> Helper loaded: form_helper
INFO - 2018-08-22 19:54:56 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:54:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:54:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:54:56 --> User Agent Class Initialized
INFO - 2018-08-22 19:54:56 --> Controller Class Initialized
INFO - 2018-08-22 19:54:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:54:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:54:56 --> Pixel_Model class loaded
INFO - 2018-08-22 19:54:56 --> Database Driver Class Initialized
INFO - 2018-08-22 19:54:56 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:54:56 --> Database Driver Class Initialized
INFO - 2018-08-22 19:54:56 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:54:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:54:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 19:54:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:54:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:54:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:54:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:54:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:54:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/affectionate_salutation.php
INFO - 2018-08-22 19:54:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:54:56 --> Final output sent to browser
DEBUG - 2018-08-22 19:54:56 --> Total execution time: 0.0454
INFO - 2018-08-22 19:54:58 --> Config Class Initialized
INFO - 2018-08-22 19:54:58 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:54:58 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:54:58 --> Utf8 Class Initialized
INFO - 2018-08-22 19:54:58 --> URI Class Initialized
INFO - 2018-08-22 19:54:58 --> Router Class Initialized
INFO - 2018-08-22 19:54:58 --> Output Class Initialized
INFO - 2018-08-22 19:54:58 --> Security Class Initialized
DEBUG - 2018-08-22 19:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:54:58 --> CSRF cookie sent
INFO - 2018-08-22 19:54:58 --> Input Class Initialized
INFO - 2018-08-22 19:54:58 --> Language Class Initialized
ERROR - 2018-08-22 19:54:58 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 19:55:13 --> Config Class Initialized
INFO - 2018-08-22 19:55:13 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:55:13 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:55:13 --> Utf8 Class Initialized
INFO - 2018-08-22 19:55:13 --> URI Class Initialized
INFO - 2018-08-22 19:55:13 --> Router Class Initialized
INFO - 2018-08-22 19:55:13 --> Output Class Initialized
INFO - 2018-08-22 19:55:13 --> Security Class Initialized
DEBUG - 2018-08-22 19:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:55:13 --> CSRF cookie sent
INFO - 2018-08-22 19:55:13 --> Input Class Initialized
INFO - 2018-08-22 19:55:13 --> Language Class Initialized
INFO - 2018-08-22 19:55:13 --> Loader Class Initialized
INFO - 2018-08-22 19:55:13 --> Helper loaded: url_helper
INFO - 2018-08-22 19:55:13 --> Helper loaded: form_helper
INFO - 2018-08-22 19:55:13 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:55:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:55:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:55:13 --> User Agent Class Initialized
INFO - 2018-08-22 19:55:13 --> Controller Class Initialized
INFO - 2018-08-22 19:55:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:55:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:55:13 --> Pixel_Model class loaded
INFO - 2018-08-22 19:55:13 --> Database Driver Class Initialized
INFO - 2018-08-22 19:55:13 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:55:13 --> Database Driver Class Initialized
INFO - 2018-08-22 19:55:13 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:55:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:55:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 19:55:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:55:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:55:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:55:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:55:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:55:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-08-22 19:55:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:55:13 --> Final output sent to browser
DEBUG - 2018-08-22 19:55:13 --> Total execution time: 0.0517
INFO - 2018-08-22 19:55:14 --> Config Class Initialized
INFO - 2018-08-22 19:55:14 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:55:14 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:55:14 --> Utf8 Class Initialized
INFO - 2018-08-22 19:55:14 --> URI Class Initialized
INFO - 2018-08-22 19:55:14 --> Router Class Initialized
INFO - 2018-08-22 19:55:14 --> Output Class Initialized
INFO - 2018-08-22 19:55:14 --> Security Class Initialized
DEBUG - 2018-08-22 19:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:55:14 --> CSRF cookie sent
INFO - 2018-08-22 19:55:14 --> Input Class Initialized
INFO - 2018-08-22 19:55:14 --> Language Class Initialized
ERROR - 2018-08-22 19:55:14 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 19:55:39 --> Config Class Initialized
INFO - 2018-08-22 19:55:39 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:55:39 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:55:39 --> Utf8 Class Initialized
INFO - 2018-08-22 19:55:39 --> URI Class Initialized
INFO - 2018-08-22 19:55:39 --> Router Class Initialized
INFO - 2018-08-22 19:55:39 --> Output Class Initialized
INFO - 2018-08-22 19:55:39 --> Security Class Initialized
DEBUG - 2018-08-22 19:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:55:39 --> CSRF cookie sent
INFO - 2018-08-22 19:55:39 --> Input Class Initialized
INFO - 2018-08-22 19:55:39 --> Language Class Initialized
INFO - 2018-08-22 19:55:39 --> Loader Class Initialized
INFO - 2018-08-22 19:55:39 --> Helper loaded: url_helper
INFO - 2018-08-22 19:55:39 --> Helper loaded: form_helper
INFO - 2018-08-22 19:55:39 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:55:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:55:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:55:39 --> User Agent Class Initialized
INFO - 2018-08-22 19:55:39 --> Controller Class Initialized
INFO - 2018-08-22 19:55:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:55:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:55:39 --> Pixel_Model class loaded
INFO - 2018-08-22 19:55:39 --> Database Driver Class Initialized
INFO - 2018-08-22 19:55:39 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:55:39 --> Database Driver Class Initialized
INFO - 2018-08-22 19:55:39 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:55:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:55:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 19:55:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:55:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:55:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:55:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:55:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:55:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/wedding_gifit_value.php
INFO - 2018-08-22 19:55:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:55:39 --> Final output sent to browser
DEBUG - 2018-08-22 19:55:39 --> Total execution time: 0.0451
INFO - 2018-08-22 19:55:39 --> Config Class Initialized
INFO - 2018-08-22 19:55:39 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:55:39 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:55:39 --> Utf8 Class Initialized
INFO - 2018-08-22 19:55:39 --> URI Class Initialized
INFO - 2018-08-22 19:55:39 --> Router Class Initialized
INFO - 2018-08-22 19:55:39 --> Output Class Initialized
INFO - 2018-08-22 19:55:39 --> Security Class Initialized
DEBUG - 2018-08-22 19:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:55:39 --> CSRF cookie sent
INFO - 2018-08-22 19:55:39 --> Input Class Initialized
INFO - 2018-08-22 19:55:39 --> Language Class Initialized
ERROR - 2018-08-22 19:55:39 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 19:56:09 --> Config Class Initialized
INFO - 2018-08-22 19:56:09 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:56:09 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:56:09 --> Utf8 Class Initialized
INFO - 2018-08-22 19:56:09 --> URI Class Initialized
INFO - 2018-08-22 19:56:09 --> Router Class Initialized
INFO - 2018-08-22 19:56:09 --> Output Class Initialized
INFO - 2018-08-22 19:56:09 --> Security Class Initialized
DEBUG - 2018-08-22 19:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:56:09 --> CSRF cookie sent
INFO - 2018-08-22 19:56:09 --> Input Class Initialized
INFO - 2018-08-22 19:56:09 --> Language Class Initialized
INFO - 2018-08-22 19:56:09 --> Loader Class Initialized
INFO - 2018-08-22 19:56:09 --> Helper loaded: url_helper
INFO - 2018-08-22 19:56:09 --> Helper loaded: form_helper
INFO - 2018-08-22 19:56:09 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:56:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:56:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:56:09 --> User Agent Class Initialized
INFO - 2018-08-22 19:56:09 --> Controller Class Initialized
INFO - 2018-08-22 19:56:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:56:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:56:09 --> Pixel_Model class loaded
INFO - 2018-08-22 19:56:09 --> Database Driver Class Initialized
INFO - 2018-08-22 19:56:09 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:56:09 --> Database Driver Class Initialized
INFO - 2018-08-22 19:56:09 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:56:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:56:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 19:56:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:56:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:56:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:56:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:56:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:56:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/business_tax_info.php
INFO - 2018-08-22 19:56:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:56:09 --> Final output sent to browser
DEBUG - 2018-08-22 19:56:09 --> Total execution time: 0.0621
INFO - 2018-08-22 19:56:10 --> Config Class Initialized
INFO - 2018-08-22 19:56:10 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:56:10 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:56:10 --> Utf8 Class Initialized
INFO - 2018-08-22 19:56:10 --> URI Class Initialized
INFO - 2018-08-22 19:56:10 --> Router Class Initialized
INFO - 2018-08-22 19:56:10 --> Output Class Initialized
INFO - 2018-08-22 19:56:10 --> Security Class Initialized
DEBUG - 2018-08-22 19:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:56:10 --> CSRF cookie sent
INFO - 2018-08-22 19:56:10 --> Input Class Initialized
INFO - 2018-08-22 19:56:10 --> Language Class Initialized
ERROR - 2018-08-22 19:56:10 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 19:56:51 --> Config Class Initialized
INFO - 2018-08-22 19:56:51 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:56:51 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:56:51 --> Utf8 Class Initialized
INFO - 2018-08-22 19:56:51 --> URI Class Initialized
INFO - 2018-08-22 19:56:51 --> Router Class Initialized
INFO - 2018-08-22 19:56:51 --> Output Class Initialized
INFO - 2018-08-22 19:56:51 --> Security Class Initialized
DEBUG - 2018-08-22 19:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:56:51 --> CSRF cookie sent
INFO - 2018-08-22 19:56:51 --> Input Class Initialized
INFO - 2018-08-22 19:56:51 --> Language Class Initialized
INFO - 2018-08-22 19:56:51 --> Loader Class Initialized
INFO - 2018-08-22 19:56:51 --> Helper loaded: url_helper
INFO - 2018-08-22 19:56:51 --> Helper loaded: form_helper
INFO - 2018-08-22 19:56:51 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:56:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:56:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:56:51 --> User Agent Class Initialized
INFO - 2018-08-22 19:56:51 --> Controller Class Initialized
INFO - 2018-08-22 19:56:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:56:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:56:51 --> Pixel_Model class loaded
INFO - 2018-08-22 19:56:51 --> Database Driver Class Initialized
INFO - 2018-08-22 19:56:51 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:56:51 --> Database Driver Class Initialized
INFO - 2018-08-22 19:56:51 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:56:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:56:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 19:56:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:56:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:56:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:56:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:56:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:56:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/trust_info.php
INFO - 2018-08-22 19:56:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:56:51 --> Final output sent to browser
DEBUG - 2018-08-22 19:56:51 --> Total execution time: 0.0619
INFO - 2018-08-22 19:56:52 --> Config Class Initialized
INFO - 2018-08-22 19:56:52 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:56:52 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:56:52 --> Utf8 Class Initialized
INFO - 2018-08-22 19:56:52 --> URI Class Initialized
INFO - 2018-08-22 19:56:52 --> Router Class Initialized
INFO - 2018-08-22 19:56:52 --> Output Class Initialized
INFO - 2018-08-22 19:56:52 --> Security Class Initialized
DEBUG - 2018-08-22 19:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:56:52 --> CSRF cookie sent
INFO - 2018-08-22 19:56:52 --> Input Class Initialized
INFO - 2018-08-22 19:56:52 --> Language Class Initialized
ERROR - 2018-08-22 19:56:52 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 19:57:34 --> Config Class Initialized
INFO - 2018-08-22 19:57:34 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:57:34 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:57:34 --> Utf8 Class Initialized
INFO - 2018-08-22 19:57:34 --> URI Class Initialized
INFO - 2018-08-22 19:57:34 --> Router Class Initialized
INFO - 2018-08-22 19:57:34 --> Output Class Initialized
INFO - 2018-08-22 19:57:34 --> Security Class Initialized
DEBUG - 2018-08-22 19:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:57:34 --> CSRF cookie sent
INFO - 2018-08-22 19:57:34 --> Input Class Initialized
INFO - 2018-08-22 19:57:34 --> Language Class Initialized
INFO - 2018-08-22 19:57:34 --> Loader Class Initialized
INFO - 2018-08-22 19:57:34 --> Helper loaded: url_helper
INFO - 2018-08-22 19:57:34 --> Helper loaded: form_helper
INFO - 2018-08-22 19:57:34 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:57:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:57:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:57:34 --> User Agent Class Initialized
INFO - 2018-08-22 19:57:34 --> Controller Class Initialized
INFO - 2018-08-22 19:57:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:57:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:57:34 --> Pixel_Model class loaded
INFO - 2018-08-22 19:57:34 --> Database Driver Class Initialized
INFO - 2018-08-22 19:57:34 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:57:34 --> Database Driver Class Initialized
INFO - 2018-08-22 19:57:34 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:57:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:57:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 19:57:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:57:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:57:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:57:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:57:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:57:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/shift_work.php
INFO - 2018-08-22 19:57:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:57:34 --> Final output sent to browser
DEBUG - 2018-08-22 19:57:34 --> Total execution time: 0.0523
INFO - 2018-08-22 19:57:34 --> Config Class Initialized
INFO - 2018-08-22 19:57:34 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:57:34 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:57:34 --> Utf8 Class Initialized
INFO - 2018-08-22 19:57:34 --> URI Class Initialized
INFO - 2018-08-22 19:57:34 --> Router Class Initialized
INFO - 2018-08-22 19:57:34 --> Output Class Initialized
INFO - 2018-08-22 19:57:34 --> Security Class Initialized
DEBUG - 2018-08-22 19:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:57:34 --> CSRF cookie sent
INFO - 2018-08-22 19:57:34 --> Input Class Initialized
INFO - 2018-08-22 19:57:34 --> Language Class Initialized
ERROR - 2018-08-22 19:57:35 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 19:57:37 --> Config Class Initialized
INFO - 2018-08-22 19:57:37 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:57:37 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:57:37 --> Utf8 Class Initialized
INFO - 2018-08-22 19:57:37 --> URI Class Initialized
INFO - 2018-08-22 19:57:37 --> Router Class Initialized
INFO - 2018-08-22 19:57:38 --> Output Class Initialized
INFO - 2018-08-22 19:57:38 --> Security Class Initialized
DEBUG - 2018-08-22 19:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:57:38 --> CSRF cookie sent
INFO - 2018-08-22 19:57:38 --> Input Class Initialized
INFO - 2018-08-22 19:57:38 --> Language Class Initialized
INFO - 2018-08-22 19:57:38 --> Loader Class Initialized
INFO - 2018-08-22 19:57:38 --> Helper loaded: url_helper
INFO - 2018-08-22 19:57:38 --> Helper loaded: form_helper
INFO - 2018-08-22 19:57:38 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:57:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:57:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:57:38 --> User Agent Class Initialized
INFO - 2018-08-22 19:57:38 --> Controller Class Initialized
INFO - 2018-08-22 19:57:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:57:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:57:38 --> Pixel_Model class loaded
INFO - 2018-08-22 19:57:38 --> Database Driver Class Initialized
INFO - 2018-08-22 19:57:38 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:57:38 --> Database Driver Class Initialized
INFO - 2018-08-22 19:57:38 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:57:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:57:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 19:57:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:57:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:57:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:57:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:57:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:57:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/shift_work.php
INFO - 2018-08-22 19:57:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:57:38 --> Final output sent to browser
DEBUG - 2018-08-22 19:57:38 --> Total execution time: 0.0743
INFO - 2018-08-22 19:57:38 --> Config Class Initialized
INFO - 2018-08-22 19:57:38 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:57:38 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:57:38 --> Utf8 Class Initialized
INFO - 2018-08-22 19:57:38 --> URI Class Initialized
INFO - 2018-08-22 19:57:38 --> Router Class Initialized
INFO - 2018-08-22 19:57:38 --> Output Class Initialized
INFO - 2018-08-22 19:57:38 --> Security Class Initialized
DEBUG - 2018-08-22 19:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:57:38 --> CSRF cookie sent
INFO - 2018-08-22 19:57:38 --> Input Class Initialized
INFO - 2018-08-22 19:57:38 --> Language Class Initialized
ERROR - 2018-08-22 19:57:38 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 19:57:53 --> Config Class Initialized
INFO - 2018-08-22 19:57:53 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:57:53 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:57:53 --> Utf8 Class Initialized
INFO - 2018-08-22 19:57:53 --> URI Class Initialized
INFO - 2018-08-22 19:57:53 --> Router Class Initialized
INFO - 2018-08-22 19:57:53 --> Output Class Initialized
INFO - 2018-08-22 19:57:53 --> Security Class Initialized
DEBUG - 2018-08-22 19:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:57:53 --> CSRF cookie sent
INFO - 2018-08-22 19:57:53 --> CSRF token verified
INFO - 2018-08-22 19:57:53 --> Input Class Initialized
INFO - 2018-08-22 19:57:53 --> Language Class Initialized
INFO - 2018-08-22 19:57:53 --> Loader Class Initialized
INFO - 2018-08-22 19:57:53 --> Helper loaded: url_helper
INFO - 2018-08-22 19:57:53 --> Helper loaded: form_helper
INFO - 2018-08-22 19:57:53 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:57:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:57:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:57:53 --> User Agent Class Initialized
INFO - 2018-08-22 19:57:53 --> Controller Class Initialized
INFO - 2018-08-22 19:57:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:57:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:57:53 --> Pixel_Model class loaded
INFO - 2018-08-22 19:57:53 --> Database Driver Class Initialized
INFO - 2018-08-22 19:57:53 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:57:53 --> Form Validation Class Initialized
INFO - 2018-08-22 19:57:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 19:57:53 --> Database Driver Class Initialized
INFO - 2018-08-22 19:57:53 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:57:53 --> Config Class Initialized
INFO - 2018-08-22 19:57:53 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:57:53 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:57:53 --> Utf8 Class Initialized
INFO - 2018-08-22 19:57:53 --> URI Class Initialized
INFO - 2018-08-22 19:57:53 --> Router Class Initialized
INFO - 2018-08-22 19:57:53 --> Output Class Initialized
INFO - 2018-08-22 19:57:53 --> Security Class Initialized
DEBUG - 2018-08-22 19:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:57:53 --> CSRF cookie sent
INFO - 2018-08-22 19:57:53 --> Input Class Initialized
INFO - 2018-08-22 19:57:53 --> Language Class Initialized
INFO - 2018-08-22 19:57:53 --> Loader Class Initialized
INFO - 2018-08-22 19:57:53 --> Helper loaded: url_helper
INFO - 2018-08-22 19:57:53 --> Helper loaded: form_helper
INFO - 2018-08-22 19:57:53 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:57:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:57:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:57:53 --> User Agent Class Initialized
INFO - 2018-08-22 19:57:53 --> Controller Class Initialized
INFO - 2018-08-22 19:57:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:57:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:57:53 --> Pixel_Model class loaded
INFO - 2018-08-22 19:57:53 --> Database Driver Class Initialized
INFO - 2018-08-22 19:57:53 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:57:53 --> Database Driver Class Initialized
INFO - 2018-08-22 19:57:53 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:57:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:57:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 19:57:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:57:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:57:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:57:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:57:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:57:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/night_without_s.php
INFO - 2018-08-22 19:57:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:57:53 --> Final output sent to browser
DEBUG - 2018-08-22 19:57:53 --> Total execution time: 0.0379
INFO - 2018-08-22 19:57:54 --> Config Class Initialized
INFO - 2018-08-22 19:57:54 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:57:54 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:57:54 --> Utf8 Class Initialized
INFO - 2018-08-22 19:57:54 --> URI Class Initialized
INFO - 2018-08-22 19:57:54 --> Router Class Initialized
INFO - 2018-08-22 19:57:54 --> Output Class Initialized
INFO - 2018-08-22 19:57:54 --> Security Class Initialized
DEBUG - 2018-08-22 19:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:57:54 --> CSRF cookie sent
INFO - 2018-08-22 19:57:54 --> Input Class Initialized
INFO - 2018-08-22 19:57:54 --> Language Class Initialized
ERROR - 2018-08-22 19:57:54 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 19:58:15 --> Config Class Initialized
INFO - 2018-08-22 19:58:15 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:58:15 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:58:15 --> Utf8 Class Initialized
INFO - 2018-08-22 19:58:15 --> URI Class Initialized
INFO - 2018-08-22 19:58:15 --> Router Class Initialized
INFO - 2018-08-22 19:58:15 --> Output Class Initialized
INFO - 2018-08-22 19:58:15 --> Security Class Initialized
DEBUG - 2018-08-22 19:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:58:15 --> CSRF cookie sent
INFO - 2018-08-22 19:58:15 --> Input Class Initialized
INFO - 2018-08-22 19:58:15 --> Language Class Initialized
INFO - 2018-08-22 19:58:15 --> Loader Class Initialized
INFO - 2018-08-22 19:58:15 --> Helper loaded: url_helper
INFO - 2018-08-22 19:58:15 --> Helper loaded: form_helper
INFO - 2018-08-22 19:58:15 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:58:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:58:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:58:15 --> User Agent Class Initialized
INFO - 2018-08-22 19:58:15 --> Controller Class Initialized
INFO - 2018-08-22 19:58:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:58:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:58:15 --> Pixel_Model class loaded
INFO - 2018-08-22 19:58:15 --> Database Driver Class Initialized
INFO - 2018-08-22 19:58:15 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:58:15 --> Database Driver Class Initialized
INFO - 2018-08-22 19:58:15 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:58:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:58:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 19:58:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:58:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:58:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:58:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:58:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:58:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/have_date.php
INFO - 2018-08-22 19:58:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:58:15 --> Final output sent to browser
DEBUG - 2018-08-22 19:58:15 --> Total execution time: 0.0678
INFO - 2018-08-22 19:58:15 --> Config Class Initialized
INFO - 2018-08-22 19:58:15 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:58:15 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:58:15 --> Utf8 Class Initialized
INFO - 2018-08-22 19:58:15 --> URI Class Initialized
INFO - 2018-08-22 19:58:15 --> Router Class Initialized
INFO - 2018-08-22 19:58:15 --> Output Class Initialized
INFO - 2018-08-22 19:58:15 --> Security Class Initialized
DEBUG - 2018-08-22 19:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:58:15 --> CSRF cookie sent
INFO - 2018-08-22 19:58:15 --> Input Class Initialized
INFO - 2018-08-22 19:58:15 --> Language Class Initialized
ERROR - 2018-08-22 19:58:15 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 19:58:31 --> Config Class Initialized
INFO - 2018-08-22 19:58:31 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:58:31 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:58:31 --> Utf8 Class Initialized
INFO - 2018-08-22 19:58:31 --> URI Class Initialized
INFO - 2018-08-22 19:58:31 --> Router Class Initialized
INFO - 2018-08-22 19:58:31 --> Output Class Initialized
INFO - 2018-08-22 19:58:31 --> Security Class Initialized
DEBUG - 2018-08-22 19:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:58:31 --> CSRF cookie sent
INFO - 2018-08-22 19:58:31 --> CSRF token verified
INFO - 2018-08-22 19:58:31 --> Input Class Initialized
INFO - 2018-08-22 19:58:31 --> Language Class Initialized
INFO - 2018-08-22 19:58:31 --> Loader Class Initialized
INFO - 2018-08-22 19:58:31 --> Helper loaded: url_helper
INFO - 2018-08-22 19:58:31 --> Helper loaded: form_helper
INFO - 2018-08-22 19:58:31 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:58:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:58:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:58:31 --> User Agent Class Initialized
INFO - 2018-08-22 19:58:31 --> Controller Class Initialized
INFO - 2018-08-22 19:58:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:58:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:58:31 --> Pixel_Model class loaded
INFO - 2018-08-22 19:58:31 --> Database Driver Class Initialized
INFO - 2018-08-22 19:58:31 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:58:31 --> Form Validation Class Initialized
INFO - 2018-08-22 19:58:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 19:58:31 --> Database Driver Class Initialized
INFO - 2018-08-22 19:58:31 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:58:31 --> Config Class Initialized
INFO - 2018-08-22 19:58:31 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:58:31 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:58:31 --> Utf8 Class Initialized
INFO - 2018-08-22 19:58:31 --> URI Class Initialized
INFO - 2018-08-22 19:58:31 --> Router Class Initialized
INFO - 2018-08-22 19:58:31 --> Output Class Initialized
INFO - 2018-08-22 19:58:31 --> Security Class Initialized
DEBUG - 2018-08-22 19:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:58:31 --> CSRF cookie sent
INFO - 2018-08-22 19:58:31 --> Input Class Initialized
INFO - 2018-08-22 19:58:31 --> Language Class Initialized
INFO - 2018-08-22 19:58:31 --> Loader Class Initialized
INFO - 2018-08-22 19:58:31 --> Helper loaded: url_helper
INFO - 2018-08-22 19:58:31 --> Helper loaded: form_helper
INFO - 2018-08-22 19:58:31 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:58:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:58:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:58:31 --> User Agent Class Initialized
INFO - 2018-08-22 19:58:31 --> Controller Class Initialized
INFO - 2018-08-22 19:58:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:58:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:58:31 --> Pixel_Model class loaded
INFO - 2018-08-22 19:58:31 --> Database Driver Class Initialized
INFO - 2018-08-22 19:58:31 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:58:31 --> Database Driver Class Initialized
INFO - 2018-08-22 19:58:31 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:58:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:58:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 19:58:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:58:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:58:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:58:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:58:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:58:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/nights_not_home.php
INFO - 2018-08-22 19:58:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:58:31 --> Final output sent to browser
DEBUG - 2018-08-22 19:58:31 --> Total execution time: 0.0530
INFO - 2018-08-22 19:58:32 --> Config Class Initialized
INFO - 2018-08-22 19:58:32 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:58:32 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:58:32 --> Utf8 Class Initialized
INFO - 2018-08-22 19:58:32 --> URI Class Initialized
INFO - 2018-08-22 19:58:32 --> Router Class Initialized
INFO - 2018-08-22 19:58:32 --> Output Class Initialized
INFO - 2018-08-22 19:58:32 --> Security Class Initialized
DEBUG - 2018-08-22 19:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:58:32 --> CSRF cookie sent
INFO - 2018-08-22 19:58:32 --> Input Class Initialized
INFO - 2018-08-22 19:58:32 --> Language Class Initialized
ERROR - 2018-08-22 19:58:32 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 19:58:49 --> Config Class Initialized
INFO - 2018-08-22 19:58:49 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:58:49 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:58:49 --> Utf8 Class Initialized
INFO - 2018-08-22 19:58:49 --> URI Class Initialized
INFO - 2018-08-22 19:58:49 --> Router Class Initialized
INFO - 2018-08-22 19:58:49 --> Output Class Initialized
INFO - 2018-08-22 19:58:49 --> Security Class Initialized
DEBUG - 2018-08-22 19:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:58:49 --> CSRF cookie sent
INFO - 2018-08-22 19:58:49 --> CSRF token verified
INFO - 2018-08-22 19:58:49 --> Input Class Initialized
INFO - 2018-08-22 19:58:49 --> Language Class Initialized
INFO - 2018-08-22 19:58:49 --> Loader Class Initialized
INFO - 2018-08-22 19:58:49 --> Helper loaded: url_helper
INFO - 2018-08-22 19:58:49 --> Helper loaded: form_helper
INFO - 2018-08-22 19:58:49 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:58:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:58:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:58:49 --> User Agent Class Initialized
INFO - 2018-08-22 19:58:49 --> Controller Class Initialized
INFO - 2018-08-22 19:58:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:58:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:58:49 --> Pixel_Model class loaded
INFO - 2018-08-22 19:58:49 --> Database Driver Class Initialized
INFO - 2018-08-22 19:58:49 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:58:49 --> Form Validation Class Initialized
INFO - 2018-08-22 19:58:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 19:58:49 --> Database Driver Class Initialized
INFO - 2018-08-22 19:58:49 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:58:50 --> Config Class Initialized
INFO - 2018-08-22 19:58:50 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:58:50 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:58:50 --> Utf8 Class Initialized
INFO - 2018-08-22 19:58:50 --> URI Class Initialized
INFO - 2018-08-22 19:58:50 --> Router Class Initialized
INFO - 2018-08-22 19:58:50 --> Output Class Initialized
INFO - 2018-08-22 19:58:50 --> Security Class Initialized
DEBUG - 2018-08-22 19:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:58:50 --> CSRF cookie sent
INFO - 2018-08-22 19:58:50 --> Input Class Initialized
INFO - 2018-08-22 19:58:50 --> Language Class Initialized
INFO - 2018-08-22 19:58:50 --> Loader Class Initialized
INFO - 2018-08-22 19:58:50 --> Helper loaded: url_helper
INFO - 2018-08-22 19:58:50 --> Helper loaded: form_helper
INFO - 2018-08-22 19:58:50 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:58:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:58:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:58:50 --> User Agent Class Initialized
INFO - 2018-08-22 19:58:50 --> Controller Class Initialized
INFO - 2018-08-22 19:58:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:58:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:58:50 --> Pixel_Model class loaded
INFO - 2018-08-22 19:58:50 --> Database Driver Class Initialized
INFO - 2018-08-22 19:58:50 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:58:50 --> Database Driver Class Initialized
INFO - 2018-08-22 19:58:50 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:58:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:58:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 19:58:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:58:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:58:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:58:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:58:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:58:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/s_nights_not_home.php
INFO - 2018-08-22 19:58:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:58:50 --> Final output sent to browser
DEBUG - 2018-08-22 19:58:50 --> Total execution time: 0.0701
INFO - 2018-08-22 19:58:50 --> Config Class Initialized
INFO - 2018-08-22 19:58:50 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:58:50 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:58:50 --> Utf8 Class Initialized
INFO - 2018-08-22 19:58:50 --> URI Class Initialized
INFO - 2018-08-22 19:58:50 --> Router Class Initialized
INFO - 2018-08-22 19:58:50 --> Output Class Initialized
INFO - 2018-08-22 19:58:50 --> Security Class Initialized
DEBUG - 2018-08-22 19:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:58:50 --> CSRF cookie sent
INFO - 2018-08-22 19:58:50 --> Input Class Initialized
INFO - 2018-08-22 19:58:50 --> Language Class Initialized
ERROR - 2018-08-22 19:58:50 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 19:59:15 --> Config Class Initialized
INFO - 2018-08-22 19:59:15 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:59:15 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:59:15 --> Utf8 Class Initialized
INFO - 2018-08-22 19:59:15 --> URI Class Initialized
INFO - 2018-08-22 19:59:15 --> Router Class Initialized
INFO - 2018-08-22 19:59:15 --> Output Class Initialized
INFO - 2018-08-22 19:59:15 --> Security Class Initialized
DEBUG - 2018-08-22 19:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:59:15 --> CSRF cookie sent
INFO - 2018-08-22 19:59:15 --> CSRF token verified
INFO - 2018-08-22 19:59:15 --> Input Class Initialized
INFO - 2018-08-22 19:59:15 --> Language Class Initialized
INFO - 2018-08-22 19:59:15 --> Loader Class Initialized
INFO - 2018-08-22 19:59:15 --> Helper loaded: url_helper
INFO - 2018-08-22 19:59:15 --> Helper loaded: form_helper
INFO - 2018-08-22 19:59:15 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:59:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:59:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:59:15 --> User Agent Class Initialized
INFO - 2018-08-22 19:59:15 --> Controller Class Initialized
INFO - 2018-08-22 19:59:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:59:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:59:15 --> Pixel_Model class loaded
INFO - 2018-08-22 19:59:15 --> Database Driver Class Initialized
INFO - 2018-08-22 19:59:15 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:59:15 --> Form Validation Class Initialized
INFO - 2018-08-22 19:59:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 19:59:15 --> Database Driver Class Initialized
INFO - 2018-08-22 19:59:15 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:59:16 --> Config Class Initialized
INFO - 2018-08-22 19:59:16 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:59:16 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:59:16 --> Utf8 Class Initialized
INFO - 2018-08-22 19:59:16 --> URI Class Initialized
INFO - 2018-08-22 19:59:16 --> Router Class Initialized
INFO - 2018-08-22 19:59:16 --> Output Class Initialized
INFO - 2018-08-22 19:59:16 --> Security Class Initialized
DEBUG - 2018-08-22 19:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:59:16 --> CSRF cookie sent
INFO - 2018-08-22 19:59:16 --> Input Class Initialized
INFO - 2018-08-22 19:59:16 --> Language Class Initialized
INFO - 2018-08-22 19:59:16 --> Loader Class Initialized
INFO - 2018-08-22 19:59:16 --> Helper loaded: url_helper
INFO - 2018-08-22 19:59:16 --> Helper loaded: form_helper
INFO - 2018-08-22 19:59:16 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:59:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:59:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:59:16 --> User Agent Class Initialized
INFO - 2018-08-22 19:59:16 --> Controller Class Initialized
INFO - 2018-08-22 19:59:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:59:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:59:16 --> Pixel_Model class loaded
INFO - 2018-08-22 19:59:16 --> Database Driver Class Initialized
INFO - 2018-08-22 19:59:16 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:59:16 --> Database Driver Class Initialized
INFO - 2018-08-22 19:59:16 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:59:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:59:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 19:59:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:59:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:59:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:59:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:59:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:59:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/s_nights_without_you.php
INFO - 2018-08-22 19:59:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:59:16 --> Final output sent to browser
DEBUG - 2018-08-22 19:59:16 --> Total execution time: 0.0550
INFO - 2018-08-22 19:59:17 --> Config Class Initialized
INFO - 2018-08-22 19:59:17 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:59:17 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:59:17 --> Utf8 Class Initialized
INFO - 2018-08-22 19:59:17 --> URI Class Initialized
INFO - 2018-08-22 19:59:17 --> Router Class Initialized
INFO - 2018-08-22 19:59:17 --> Output Class Initialized
INFO - 2018-08-22 19:59:17 --> Security Class Initialized
DEBUG - 2018-08-22 19:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:59:17 --> CSRF cookie sent
INFO - 2018-08-22 19:59:17 --> Input Class Initialized
INFO - 2018-08-22 19:59:17 --> Language Class Initialized
ERROR - 2018-08-22 19:59:17 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 19:59:41 --> Config Class Initialized
INFO - 2018-08-22 19:59:41 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:59:41 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:59:41 --> Utf8 Class Initialized
INFO - 2018-08-22 19:59:41 --> URI Class Initialized
INFO - 2018-08-22 19:59:41 --> Router Class Initialized
INFO - 2018-08-22 19:59:41 --> Output Class Initialized
INFO - 2018-08-22 19:59:41 --> Security Class Initialized
DEBUG - 2018-08-22 19:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:59:41 --> CSRF cookie sent
INFO - 2018-08-22 19:59:41 --> CSRF token verified
INFO - 2018-08-22 19:59:41 --> Input Class Initialized
INFO - 2018-08-22 19:59:41 --> Language Class Initialized
INFO - 2018-08-22 19:59:41 --> Loader Class Initialized
INFO - 2018-08-22 19:59:41 --> Helper loaded: url_helper
INFO - 2018-08-22 19:59:41 --> Helper loaded: form_helper
INFO - 2018-08-22 19:59:41 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:59:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:59:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:59:41 --> User Agent Class Initialized
INFO - 2018-08-22 19:59:41 --> Controller Class Initialized
INFO - 2018-08-22 19:59:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:59:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:59:41 --> Pixel_Model class loaded
INFO - 2018-08-22 19:59:41 --> Database Driver Class Initialized
INFO - 2018-08-22 19:59:41 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:59:41 --> Form Validation Class Initialized
INFO - 2018-08-22 19:59:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 19:59:41 --> Database Driver Class Initialized
INFO - 2018-08-22 19:59:41 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:59:41 --> Config Class Initialized
INFO - 2018-08-22 19:59:41 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:59:41 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:59:41 --> Utf8 Class Initialized
INFO - 2018-08-22 19:59:41 --> URI Class Initialized
INFO - 2018-08-22 19:59:41 --> Router Class Initialized
INFO - 2018-08-22 19:59:41 --> Output Class Initialized
INFO - 2018-08-22 19:59:41 --> Security Class Initialized
DEBUG - 2018-08-22 19:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:59:41 --> CSRF cookie sent
INFO - 2018-08-22 19:59:41 --> Input Class Initialized
INFO - 2018-08-22 19:59:41 --> Language Class Initialized
INFO - 2018-08-22 19:59:41 --> Loader Class Initialized
INFO - 2018-08-22 19:59:41 --> Helper loaded: url_helper
INFO - 2018-08-22 19:59:41 --> Helper loaded: form_helper
INFO - 2018-08-22 19:59:41 --> Helper loaded: language_helper
DEBUG - 2018-08-22 19:59:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 19:59:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 19:59:41 --> User Agent Class Initialized
INFO - 2018-08-22 19:59:41 --> Controller Class Initialized
INFO - 2018-08-22 19:59:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 19:59:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 19:59:41 --> Pixel_Model class loaded
INFO - 2018-08-22 19:59:41 --> Database Driver Class Initialized
INFO - 2018-08-22 19:59:41 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:59:41 --> Database Driver Class Initialized
INFO - 2018-08-22 19:59:41 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 19:59:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 19:59:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 19:59:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 19:59:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 19:59:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 19:59:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 19:59:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 19:59:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/alcoholic_drinks_per_week.php
INFO - 2018-08-22 19:59:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 19:59:41 --> Final output sent to browser
DEBUG - 2018-08-22 19:59:41 --> Total execution time: 0.0459
INFO - 2018-08-22 19:59:42 --> Config Class Initialized
INFO - 2018-08-22 19:59:42 --> Hooks Class Initialized
DEBUG - 2018-08-22 19:59:42 --> UTF-8 Support Enabled
INFO - 2018-08-22 19:59:42 --> Utf8 Class Initialized
INFO - 2018-08-22 19:59:42 --> URI Class Initialized
INFO - 2018-08-22 19:59:42 --> Router Class Initialized
INFO - 2018-08-22 19:59:42 --> Output Class Initialized
INFO - 2018-08-22 19:59:42 --> Security Class Initialized
DEBUG - 2018-08-22 19:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 19:59:42 --> CSRF cookie sent
INFO - 2018-08-22 19:59:42 --> Input Class Initialized
INFO - 2018-08-22 19:59:42 --> Language Class Initialized
ERROR - 2018-08-22 19:59:42 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 20:00:05 --> Config Class Initialized
INFO - 2018-08-22 20:00:05 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:00:05 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:00:05 --> Utf8 Class Initialized
INFO - 2018-08-22 20:00:05 --> URI Class Initialized
INFO - 2018-08-22 20:00:05 --> Router Class Initialized
INFO - 2018-08-22 20:00:05 --> Output Class Initialized
INFO - 2018-08-22 20:00:05 --> Security Class Initialized
DEBUG - 2018-08-22 20:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:00:05 --> CSRF cookie sent
INFO - 2018-08-22 20:00:05 --> CSRF token verified
INFO - 2018-08-22 20:00:05 --> Input Class Initialized
INFO - 2018-08-22 20:00:05 --> Language Class Initialized
INFO - 2018-08-22 20:00:05 --> Loader Class Initialized
INFO - 2018-08-22 20:00:05 --> Helper loaded: url_helper
INFO - 2018-08-22 20:00:05 --> Helper loaded: form_helper
INFO - 2018-08-22 20:00:05 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:00:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:00:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:00:05 --> User Agent Class Initialized
INFO - 2018-08-22 20:00:05 --> Controller Class Initialized
INFO - 2018-08-22 20:00:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:00:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:00:05 --> Pixel_Model class loaded
INFO - 2018-08-22 20:00:05 --> Database Driver Class Initialized
INFO - 2018-08-22 20:00:05 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:00:05 --> Form Validation Class Initialized
INFO - 2018-08-22 20:00:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 20:00:05 --> Database Driver Class Initialized
INFO - 2018-08-22 20:00:05 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:00:05 --> Config Class Initialized
INFO - 2018-08-22 20:00:05 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:00:05 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:00:05 --> Utf8 Class Initialized
INFO - 2018-08-22 20:00:05 --> URI Class Initialized
INFO - 2018-08-22 20:00:05 --> Router Class Initialized
INFO - 2018-08-22 20:00:05 --> Output Class Initialized
INFO - 2018-08-22 20:00:05 --> Security Class Initialized
DEBUG - 2018-08-22 20:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:00:05 --> CSRF cookie sent
INFO - 2018-08-22 20:00:05 --> Input Class Initialized
INFO - 2018-08-22 20:00:05 --> Language Class Initialized
INFO - 2018-08-22 20:00:05 --> Loader Class Initialized
INFO - 2018-08-22 20:00:05 --> Helper loaded: url_helper
INFO - 2018-08-22 20:00:05 --> Helper loaded: form_helper
INFO - 2018-08-22 20:00:05 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:00:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:00:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:00:05 --> User Agent Class Initialized
INFO - 2018-08-22 20:00:05 --> Controller Class Initialized
INFO - 2018-08-22 20:00:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:00:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:00:05 --> Pixel_Model class loaded
INFO - 2018-08-22 20:00:05 --> Database Driver Class Initialized
INFO - 2018-08-22 20:00:05 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:00:05 --> Database Driver Class Initialized
INFO - 2018-08-22 20:00:05 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:00:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 20:00:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 20:00:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 20:00:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 20:00:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 20:00:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 20:00:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 20:00:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/have_drugs.php
INFO - 2018-08-22 20:00:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 20:00:05 --> Final output sent to browser
DEBUG - 2018-08-22 20:00:05 --> Total execution time: 0.0461
INFO - 2018-08-22 20:00:05 --> Config Class Initialized
INFO - 2018-08-22 20:00:05 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:00:05 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:00:05 --> Utf8 Class Initialized
INFO - 2018-08-22 20:00:05 --> URI Class Initialized
INFO - 2018-08-22 20:00:05 --> Router Class Initialized
INFO - 2018-08-22 20:00:05 --> Output Class Initialized
INFO - 2018-08-22 20:00:05 --> Security Class Initialized
DEBUG - 2018-08-22 20:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:00:05 --> CSRF cookie sent
INFO - 2018-08-22 20:00:05 --> Input Class Initialized
INFO - 2018-08-22 20:00:05 --> Language Class Initialized
ERROR - 2018-08-22 20:00:05 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 20:00:19 --> Config Class Initialized
INFO - 2018-08-22 20:00:19 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:00:19 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:00:19 --> Utf8 Class Initialized
INFO - 2018-08-22 20:00:19 --> URI Class Initialized
INFO - 2018-08-22 20:00:19 --> Router Class Initialized
INFO - 2018-08-22 20:00:19 --> Output Class Initialized
INFO - 2018-08-22 20:00:19 --> Security Class Initialized
DEBUG - 2018-08-22 20:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:00:19 --> CSRF cookie sent
INFO - 2018-08-22 20:00:19 --> CSRF token verified
INFO - 2018-08-22 20:00:19 --> Input Class Initialized
INFO - 2018-08-22 20:00:19 --> Language Class Initialized
INFO - 2018-08-22 20:00:19 --> Loader Class Initialized
INFO - 2018-08-22 20:00:19 --> Helper loaded: url_helper
INFO - 2018-08-22 20:00:19 --> Helper loaded: form_helper
INFO - 2018-08-22 20:00:19 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:00:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:00:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:00:19 --> User Agent Class Initialized
INFO - 2018-08-22 20:00:19 --> Controller Class Initialized
INFO - 2018-08-22 20:00:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:00:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:00:19 --> Pixel_Model class loaded
INFO - 2018-08-22 20:00:19 --> Database Driver Class Initialized
INFO - 2018-08-22 20:00:19 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:00:19 --> Form Validation Class Initialized
INFO - 2018-08-22 20:00:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 20:00:19 --> Database Driver Class Initialized
INFO - 2018-08-22 20:00:19 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:00:19 --> Config Class Initialized
INFO - 2018-08-22 20:00:19 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:00:19 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:00:19 --> Utf8 Class Initialized
INFO - 2018-08-22 20:00:19 --> URI Class Initialized
INFO - 2018-08-22 20:00:19 --> Router Class Initialized
INFO - 2018-08-22 20:00:19 --> Output Class Initialized
INFO - 2018-08-22 20:00:19 --> Security Class Initialized
DEBUG - 2018-08-22 20:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:00:19 --> CSRF cookie sent
INFO - 2018-08-22 20:00:19 --> Input Class Initialized
INFO - 2018-08-22 20:00:19 --> Language Class Initialized
INFO - 2018-08-22 20:00:19 --> Loader Class Initialized
INFO - 2018-08-22 20:00:19 --> Helper loaded: url_helper
INFO - 2018-08-22 20:00:19 --> Helper loaded: form_helper
INFO - 2018-08-22 20:00:19 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:00:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:00:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:00:19 --> User Agent Class Initialized
INFO - 2018-08-22 20:00:19 --> Controller Class Initialized
INFO - 2018-08-22 20:00:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:00:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:00:19 --> Pixel_Model class loaded
INFO - 2018-08-22 20:00:19 --> Database Driver Class Initialized
INFO - 2018-08-22 20:00:19 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:00:19 --> Database Driver Class Initialized
INFO - 2018-08-22 20:00:19 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:00:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 20:00:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 20:00:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 20:00:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 20:00:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 20:00:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 20:00:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 20:00:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/has_addiction_problem.php
INFO - 2018-08-22 20:00:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 20:00:19 --> Final output sent to browser
DEBUG - 2018-08-22 20:00:19 --> Total execution time: 0.0456
INFO - 2018-08-22 20:00:20 --> Config Class Initialized
INFO - 2018-08-22 20:00:20 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:00:20 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:00:20 --> Utf8 Class Initialized
INFO - 2018-08-22 20:00:20 --> URI Class Initialized
INFO - 2018-08-22 20:00:20 --> Router Class Initialized
INFO - 2018-08-22 20:00:20 --> Output Class Initialized
INFO - 2018-08-22 20:00:20 --> Security Class Initialized
DEBUG - 2018-08-22 20:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:00:20 --> CSRF cookie sent
INFO - 2018-08-22 20:00:20 --> Input Class Initialized
INFO - 2018-08-22 20:00:20 --> Language Class Initialized
ERROR - 2018-08-22 20:00:20 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 20:00:37 --> Config Class Initialized
INFO - 2018-08-22 20:00:37 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:00:37 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:00:37 --> Utf8 Class Initialized
INFO - 2018-08-22 20:00:37 --> URI Class Initialized
INFO - 2018-08-22 20:00:37 --> Router Class Initialized
INFO - 2018-08-22 20:00:37 --> Output Class Initialized
INFO - 2018-08-22 20:00:37 --> Security Class Initialized
DEBUG - 2018-08-22 20:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:00:37 --> CSRF cookie sent
INFO - 2018-08-22 20:00:37 --> CSRF token verified
INFO - 2018-08-22 20:00:37 --> Input Class Initialized
INFO - 2018-08-22 20:00:37 --> Language Class Initialized
INFO - 2018-08-22 20:00:37 --> Loader Class Initialized
INFO - 2018-08-22 20:00:37 --> Helper loaded: url_helper
INFO - 2018-08-22 20:00:37 --> Helper loaded: form_helper
INFO - 2018-08-22 20:00:37 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:00:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:00:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:00:37 --> User Agent Class Initialized
INFO - 2018-08-22 20:00:37 --> Controller Class Initialized
INFO - 2018-08-22 20:00:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:00:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:00:37 --> Pixel_Model class loaded
INFO - 2018-08-22 20:00:37 --> Database Driver Class Initialized
INFO - 2018-08-22 20:00:37 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:00:37 --> Form Validation Class Initialized
INFO - 2018-08-22 20:00:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 20:00:37 --> Database Driver Class Initialized
INFO - 2018-08-22 20:00:37 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:00:37 --> Config Class Initialized
INFO - 2018-08-22 20:00:37 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:00:37 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:00:37 --> Utf8 Class Initialized
INFO - 2018-08-22 20:00:37 --> URI Class Initialized
INFO - 2018-08-22 20:00:37 --> Router Class Initialized
INFO - 2018-08-22 20:00:37 --> Output Class Initialized
INFO - 2018-08-22 20:00:37 --> Security Class Initialized
DEBUG - 2018-08-22 20:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:00:37 --> CSRF cookie sent
INFO - 2018-08-22 20:00:37 --> Input Class Initialized
INFO - 2018-08-22 20:00:37 --> Language Class Initialized
INFO - 2018-08-22 20:00:37 --> Loader Class Initialized
INFO - 2018-08-22 20:00:37 --> Helper loaded: url_helper
INFO - 2018-08-22 20:00:37 --> Helper loaded: form_helper
INFO - 2018-08-22 20:00:37 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:00:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:00:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:00:37 --> User Agent Class Initialized
INFO - 2018-08-22 20:00:37 --> Controller Class Initialized
INFO - 2018-08-22 20:00:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:00:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:00:37 --> Pixel_Model class loaded
INFO - 2018-08-22 20:00:37 --> Database Driver Class Initialized
INFO - 2018-08-22 20:00:37 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:00:37 --> Database Driver Class Initialized
INFO - 2018-08-22 20:00:37 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:00:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 20:00:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 20:00:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 20:00:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 20:00:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 20:00:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 20:00:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 20:00:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/have_hit_s.php
INFO - 2018-08-22 20:00:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 20:00:37 --> Final output sent to browser
DEBUG - 2018-08-22 20:00:37 --> Total execution time: 0.0557
INFO - 2018-08-22 20:00:38 --> Config Class Initialized
INFO - 2018-08-22 20:00:38 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:00:38 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:00:38 --> Utf8 Class Initialized
INFO - 2018-08-22 20:00:38 --> URI Class Initialized
INFO - 2018-08-22 20:00:38 --> Router Class Initialized
INFO - 2018-08-22 20:00:38 --> Output Class Initialized
INFO - 2018-08-22 20:00:38 --> Security Class Initialized
DEBUG - 2018-08-22 20:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:00:38 --> CSRF cookie sent
INFO - 2018-08-22 20:00:38 --> Input Class Initialized
INFO - 2018-08-22 20:00:38 --> Language Class Initialized
ERROR - 2018-08-22 20:00:38 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 20:01:12 --> Config Class Initialized
INFO - 2018-08-22 20:01:12 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:01:12 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:01:12 --> Utf8 Class Initialized
INFO - 2018-08-22 20:01:12 --> URI Class Initialized
INFO - 2018-08-22 20:01:12 --> Router Class Initialized
INFO - 2018-08-22 20:01:12 --> Output Class Initialized
INFO - 2018-08-22 20:01:12 --> Security Class Initialized
DEBUG - 2018-08-22 20:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:01:12 --> CSRF cookie sent
INFO - 2018-08-22 20:01:12 --> CSRF token verified
INFO - 2018-08-22 20:01:12 --> Input Class Initialized
INFO - 2018-08-22 20:01:12 --> Language Class Initialized
INFO - 2018-08-22 20:01:12 --> Loader Class Initialized
INFO - 2018-08-22 20:01:12 --> Helper loaded: url_helper
INFO - 2018-08-22 20:01:12 --> Helper loaded: form_helper
INFO - 2018-08-22 20:01:12 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:01:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:01:12 --> User Agent Class Initialized
INFO - 2018-08-22 20:01:12 --> Controller Class Initialized
INFO - 2018-08-22 20:01:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:01:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:01:12 --> Pixel_Model class loaded
INFO - 2018-08-22 20:01:12 --> Database Driver Class Initialized
INFO - 2018-08-22 20:01:12 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:01:12 --> Form Validation Class Initialized
INFO - 2018-08-22 20:01:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 20:01:12 --> Database Driver Class Initialized
INFO - 2018-08-22 20:01:12 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:01:12 --> Config Class Initialized
INFO - 2018-08-22 20:01:12 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:01:12 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:01:12 --> Utf8 Class Initialized
INFO - 2018-08-22 20:01:12 --> URI Class Initialized
INFO - 2018-08-22 20:01:12 --> Router Class Initialized
INFO - 2018-08-22 20:01:12 --> Output Class Initialized
INFO - 2018-08-22 20:01:12 --> Security Class Initialized
DEBUG - 2018-08-22 20:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:01:12 --> CSRF cookie sent
INFO - 2018-08-22 20:01:12 --> Input Class Initialized
INFO - 2018-08-22 20:01:12 --> Language Class Initialized
INFO - 2018-08-22 20:01:12 --> Loader Class Initialized
INFO - 2018-08-22 20:01:12 --> Helper loaded: url_helper
INFO - 2018-08-22 20:01:12 --> Helper loaded: form_helper
INFO - 2018-08-22 20:01:12 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:01:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:01:12 --> User Agent Class Initialized
INFO - 2018-08-22 20:01:12 --> Controller Class Initialized
INFO - 2018-08-22 20:01:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:01:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:01:12 --> Pixel_Model class loaded
INFO - 2018-08-22 20:01:12 --> Database Driver Class Initialized
INFO - 2018-08-22 20:01:12 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:01:12 --> Database Driver Class Initialized
INFO - 2018-08-22 20:01:12 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:01:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 20:01:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 20:01:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 20:01:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 20:01:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 20:01:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 20:01:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 20:01:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial_control.php
INFO - 2018-08-22 20:01:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 20:01:12 --> Final output sent to browser
DEBUG - 2018-08-22 20:01:12 --> Total execution time: 0.0576
INFO - 2018-08-22 20:01:13 --> Config Class Initialized
INFO - 2018-08-22 20:01:13 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:01:13 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:01:13 --> Utf8 Class Initialized
INFO - 2018-08-22 20:01:13 --> URI Class Initialized
INFO - 2018-08-22 20:01:13 --> Router Class Initialized
INFO - 2018-08-22 20:01:13 --> Output Class Initialized
INFO - 2018-08-22 20:01:13 --> Security Class Initialized
DEBUG - 2018-08-22 20:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:01:13 --> CSRF cookie sent
INFO - 2018-08-22 20:01:13 --> Input Class Initialized
INFO - 2018-08-22 20:01:13 --> Language Class Initialized
ERROR - 2018-08-22 20:01:13 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 20:01:20 --> Config Class Initialized
INFO - 2018-08-22 20:01:20 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:01:20 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:01:20 --> Utf8 Class Initialized
INFO - 2018-08-22 20:01:20 --> URI Class Initialized
INFO - 2018-08-22 20:01:20 --> Router Class Initialized
INFO - 2018-08-22 20:01:20 --> Output Class Initialized
INFO - 2018-08-22 20:01:20 --> Security Class Initialized
DEBUG - 2018-08-22 20:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:01:20 --> CSRF cookie sent
INFO - 2018-08-22 20:01:20 --> Input Class Initialized
INFO - 2018-08-22 20:01:20 --> Language Class Initialized
INFO - 2018-08-22 20:01:20 --> Loader Class Initialized
INFO - 2018-08-22 20:01:20 --> Helper loaded: url_helper
INFO - 2018-08-22 20:01:20 --> Helper loaded: form_helper
INFO - 2018-08-22 20:01:20 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:01:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:01:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:01:20 --> User Agent Class Initialized
INFO - 2018-08-22 20:01:20 --> Controller Class Initialized
INFO - 2018-08-22 20:01:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:01:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:01:20 --> Pixel_Model class loaded
INFO - 2018-08-22 20:01:20 --> Database Driver Class Initialized
INFO - 2018-08-22 20:01:20 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:01:20 --> Database Driver Class Initialized
INFO - 2018-08-22 20:01:20 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:01:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 20:01:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 20:01:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 20:01:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 20:01:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 20:01:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 20:01:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 20:01:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/has_hit_kids.php
INFO - 2018-08-22 20:01:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 20:01:20 --> Final output sent to browser
DEBUG - 2018-08-22 20:01:20 --> Total execution time: 0.0476
INFO - 2018-08-22 20:01:21 --> Config Class Initialized
INFO - 2018-08-22 20:01:21 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:01:21 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:01:21 --> Utf8 Class Initialized
INFO - 2018-08-22 20:01:21 --> URI Class Initialized
INFO - 2018-08-22 20:01:21 --> Router Class Initialized
INFO - 2018-08-22 20:01:21 --> Output Class Initialized
INFO - 2018-08-22 20:01:21 --> Security Class Initialized
DEBUG - 2018-08-22 20:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:01:21 --> CSRF cookie sent
INFO - 2018-08-22 20:01:21 --> Input Class Initialized
INFO - 2018-08-22 20:01:21 --> Language Class Initialized
ERROR - 2018-08-22 20:01:21 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 20:01:44 --> Config Class Initialized
INFO - 2018-08-22 20:01:44 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:01:44 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:01:44 --> Utf8 Class Initialized
INFO - 2018-08-22 20:01:44 --> URI Class Initialized
INFO - 2018-08-22 20:01:44 --> Router Class Initialized
INFO - 2018-08-22 20:01:44 --> Output Class Initialized
INFO - 2018-08-22 20:01:44 --> Security Class Initialized
DEBUG - 2018-08-22 20:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:01:44 --> CSRF cookie sent
INFO - 2018-08-22 20:01:44 --> CSRF token verified
INFO - 2018-08-22 20:01:44 --> Input Class Initialized
INFO - 2018-08-22 20:01:44 --> Language Class Initialized
INFO - 2018-08-22 20:01:44 --> Loader Class Initialized
INFO - 2018-08-22 20:01:44 --> Helper loaded: url_helper
INFO - 2018-08-22 20:01:44 --> Helper loaded: form_helper
INFO - 2018-08-22 20:01:44 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:01:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:01:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:01:44 --> User Agent Class Initialized
INFO - 2018-08-22 20:01:44 --> Controller Class Initialized
INFO - 2018-08-22 20:01:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:01:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:01:44 --> Pixel_Model class loaded
INFO - 2018-08-22 20:01:44 --> Database Driver Class Initialized
INFO - 2018-08-22 20:01:44 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:01:44 --> Form Validation Class Initialized
INFO - 2018-08-22 20:01:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 20:01:44 --> Database Driver Class Initialized
INFO - 2018-08-22 20:01:44 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:01:44 --> Config Class Initialized
INFO - 2018-08-22 20:01:44 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:01:44 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:01:44 --> Utf8 Class Initialized
INFO - 2018-08-22 20:01:44 --> URI Class Initialized
INFO - 2018-08-22 20:01:44 --> Router Class Initialized
INFO - 2018-08-22 20:01:44 --> Output Class Initialized
INFO - 2018-08-22 20:01:44 --> Security Class Initialized
DEBUG - 2018-08-22 20:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:01:44 --> CSRF cookie sent
INFO - 2018-08-22 20:01:44 --> Input Class Initialized
INFO - 2018-08-22 20:01:44 --> Language Class Initialized
INFO - 2018-08-22 20:01:44 --> Loader Class Initialized
INFO - 2018-08-22 20:01:44 --> Helper loaded: url_helper
INFO - 2018-08-22 20:01:44 --> Helper loaded: form_helper
INFO - 2018-08-22 20:01:44 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:01:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:01:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:01:44 --> User Agent Class Initialized
INFO - 2018-08-22 20:01:44 --> Controller Class Initialized
INFO - 2018-08-22 20:01:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:01:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:01:44 --> Pixel_Model class loaded
INFO - 2018-08-22 20:01:44 --> Database Driver Class Initialized
INFO - 2018-08-22 20:01:44 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:01:44 --> Database Driver Class Initialized
INFO - 2018-08-22 20:01:44 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:01:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 20:01:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 20:01:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 20:01:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 20:01:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 20:01:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 20:01:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 20:01:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/withheld_sex.php
INFO - 2018-08-22 20:01:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 20:01:44 --> Final output sent to browser
DEBUG - 2018-08-22 20:01:44 --> Total execution time: 0.0476
INFO - 2018-08-22 20:01:44 --> Config Class Initialized
INFO - 2018-08-22 20:01:44 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:01:44 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:01:44 --> Utf8 Class Initialized
INFO - 2018-08-22 20:01:44 --> URI Class Initialized
INFO - 2018-08-22 20:01:44 --> Router Class Initialized
INFO - 2018-08-22 20:01:44 --> Output Class Initialized
INFO - 2018-08-22 20:01:44 --> Security Class Initialized
DEBUG - 2018-08-22 20:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:01:44 --> CSRF cookie sent
INFO - 2018-08-22 20:01:44 --> Input Class Initialized
INFO - 2018-08-22 20:01:44 --> Language Class Initialized
ERROR - 2018-08-22 20:01:44 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 20:01:52 --> Config Class Initialized
INFO - 2018-08-22 20:01:52 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:01:52 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:01:52 --> Utf8 Class Initialized
INFO - 2018-08-22 20:01:52 --> URI Class Initialized
INFO - 2018-08-22 20:01:52 --> Router Class Initialized
INFO - 2018-08-22 20:01:52 --> Output Class Initialized
INFO - 2018-08-22 20:01:52 --> Security Class Initialized
DEBUG - 2018-08-22 20:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:01:52 --> CSRF cookie sent
INFO - 2018-08-22 20:01:52 --> Input Class Initialized
INFO - 2018-08-22 20:01:52 --> Language Class Initialized
INFO - 2018-08-22 20:01:52 --> Loader Class Initialized
INFO - 2018-08-22 20:01:52 --> Helper loaded: url_helper
INFO - 2018-08-22 20:01:52 --> Helper loaded: form_helper
INFO - 2018-08-22 20:01:52 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:01:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:01:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:01:52 --> User Agent Class Initialized
INFO - 2018-08-22 20:01:52 --> Controller Class Initialized
INFO - 2018-08-22 20:01:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:01:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:01:52 --> Pixel_Model class loaded
INFO - 2018-08-22 20:01:52 --> Database Driver Class Initialized
INFO - 2018-08-22 20:01:52 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:01:52 --> Database Driver Class Initialized
INFO - 2018-08-22 20:01:52 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:01:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 20:01:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 20:01:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 20:01:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 20:01:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 20:01:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 20:01:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 20:01:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/has_dating_profile.php
INFO - 2018-08-22 20:01:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 20:01:52 --> Final output sent to browser
DEBUG - 2018-08-22 20:01:52 --> Total execution time: 0.0471
INFO - 2018-08-22 20:01:52 --> Config Class Initialized
INFO - 2018-08-22 20:01:52 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:01:52 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:01:52 --> Utf8 Class Initialized
INFO - 2018-08-22 20:01:52 --> URI Class Initialized
INFO - 2018-08-22 20:01:52 --> Router Class Initialized
INFO - 2018-08-22 20:01:52 --> Output Class Initialized
INFO - 2018-08-22 20:01:52 --> Security Class Initialized
DEBUG - 2018-08-22 20:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:01:52 --> CSRF cookie sent
INFO - 2018-08-22 20:01:52 --> Input Class Initialized
INFO - 2018-08-22 20:01:52 --> Language Class Initialized
ERROR - 2018-08-22 20:01:52 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 20:02:21 --> Config Class Initialized
INFO - 2018-08-22 20:02:21 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:02:21 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:02:21 --> Utf8 Class Initialized
INFO - 2018-08-22 20:02:21 --> URI Class Initialized
INFO - 2018-08-22 20:02:21 --> Router Class Initialized
INFO - 2018-08-22 20:02:21 --> Output Class Initialized
INFO - 2018-08-22 20:02:21 --> Security Class Initialized
DEBUG - 2018-08-22 20:02:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:02:21 --> CSRF cookie sent
INFO - 2018-08-22 20:02:21 --> Input Class Initialized
INFO - 2018-08-22 20:02:21 --> Language Class Initialized
ERROR - 2018-08-22 20:02:21 --> 404 Page Not Found: Slept-on-coach/index
INFO - 2018-08-22 20:02:25 --> Config Class Initialized
INFO - 2018-08-22 20:02:25 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:02:25 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:02:25 --> Utf8 Class Initialized
INFO - 2018-08-22 20:02:25 --> URI Class Initialized
INFO - 2018-08-22 20:02:25 --> Router Class Initialized
INFO - 2018-08-22 20:02:25 --> Output Class Initialized
INFO - 2018-08-22 20:02:25 --> Security Class Initialized
DEBUG - 2018-08-22 20:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:02:25 --> CSRF cookie sent
INFO - 2018-08-22 20:02:25 --> Input Class Initialized
INFO - 2018-08-22 20:02:25 --> Language Class Initialized
INFO - 2018-08-22 20:02:25 --> Loader Class Initialized
INFO - 2018-08-22 20:02:25 --> Helper loaded: url_helper
INFO - 2018-08-22 20:02:25 --> Helper loaded: form_helper
INFO - 2018-08-22 20:02:25 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:02:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:02:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:02:25 --> User Agent Class Initialized
INFO - 2018-08-22 20:02:25 --> Controller Class Initialized
INFO - 2018-08-22 20:02:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:02:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:02:25 --> Pixel_Model class loaded
INFO - 2018-08-22 20:02:25 --> Database Driver Class Initialized
INFO - 2018-08-22 20:02:25 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:02:25 --> Database Driver Class Initialized
INFO - 2018-08-22 20:02:25 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:02:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 20:02:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 20:02:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 20:02:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 20:02:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 20:02:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 20:02:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 20:02:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/times_slept_couch.php
INFO - 2018-08-22 20:02:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 20:02:25 --> Final output sent to browser
DEBUG - 2018-08-22 20:02:25 --> Total execution time: 0.0560
INFO - 2018-08-22 20:02:27 --> Config Class Initialized
INFO - 2018-08-22 20:02:27 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:02:27 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:02:27 --> Utf8 Class Initialized
INFO - 2018-08-22 20:02:27 --> URI Class Initialized
INFO - 2018-08-22 20:02:27 --> Router Class Initialized
INFO - 2018-08-22 20:02:27 --> Output Class Initialized
INFO - 2018-08-22 20:02:27 --> Security Class Initialized
DEBUG - 2018-08-22 20:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:02:27 --> CSRF cookie sent
INFO - 2018-08-22 20:02:27 --> Input Class Initialized
INFO - 2018-08-22 20:02:27 --> Language Class Initialized
ERROR - 2018-08-22 20:02:27 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 20:02:54 --> Config Class Initialized
INFO - 2018-08-22 20:02:54 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:02:54 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:02:54 --> Utf8 Class Initialized
INFO - 2018-08-22 20:02:54 --> URI Class Initialized
INFO - 2018-08-22 20:02:54 --> Router Class Initialized
INFO - 2018-08-22 20:02:54 --> Output Class Initialized
INFO - 2018-08-22 20:02:54 --> Security Class Initialized
DEBUG - 2018-08-22 20:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:02:54 --> CSRF cookie sent
INFO - 2018-08-22 20:02:54 --> CSRF token verified
INFO - 2018-08-22 20:02:54 --> Input Class Initialized
INFO - 2018-08-22 20:02:54 --> Language Class Initialized
INFO - 2018-08-22 20:02:54 --> Loader Class Initialized
INFO - 2018-08-22 20:02:54 --> Helper loaded: url_helper
INFO - 2018-08-22 20:02:54 --> Helper loaded: form_helper
INFO - 2018-08-22 20:02:54 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:02:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:02:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:02:54 --> User Agent Class Initialized
INFO - 2018-08-22 20:02:54 --> Controller Class Initialized
INFO - 2018-08-22 20:02:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:02:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:02:54 --> Pixel_Model class loaded
INFO - 2018-08-22 20:02:54 --> Database Driver Class Initialized
INFO - 2018-08-22 20:02:54 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:02:54 --> Form Validation Class Initialized
INFO - 2018-08-22 20:02:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 20:02:54 --> Database Driver Class Initialized
INFO - 2018-08-22 20:02:54 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:02:54 --> Config Class Initialized
INFO - 2018-08-22 20:02:54 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:02:54 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:02:54 --> Utf8 Class Initialized
INFO - 2018-08-22 20:02:54 --> URI Class Initialized
INFO - 2018-08-22 20:02:54 --> Router Class Initialized
INFO - 2018-08-22 20:02:54 --> Output Class Initialized
INFO - 2018-08-22 20:02:54 --> Security Class Initialized
DEBUG - 2018-08-22 20:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:02:54 --> CSRF cookie sent
INFO - 2018-08-22 20:02:54 --> Input Class Initialized
INFO - 2018-08-22 20:02:54 --> Language Class Initialized
INFO - 2018-08-22 20:02:54 --> Loader Class Initialized
INFO - 2018-08-22 20:02:54 --> Helper loaded: url_helper
INFO - 2018-08-22 20:02:54 --> Helper loaded: form_helper
INFO - 2018-08-22 20:02:54 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:02:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:02:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:02:54 --> User Agent Class Initialized
INFO - 2018-08-22 20:02:54 --> Controller Class Initialized
INFO - 2018-08-22 20:02:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:02:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:02:54 --> Pixel_Model class loaded
INFO - 2018-08-22 20:02:54 --> Database Driver Class Initialized
INFO - 2018-08-22 20:02:54 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:02:54 --> Database Driver Class Initialized
INFO - 2018-08-22 20:02:54 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:02:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 20:02:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 20:02:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 20:02:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 20:02:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 20:02:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 20:02:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 20:02:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/has_relationship_outside.php
INFO - 2018-08-22 20:02:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 20:02:54 --> Final output sent to browser
DEBUG - 2018-08-22 20:02:54 --> Total execution time: 0.0461
INFO - 2018-08-22 20:02:55 --> Config Class Initialized
INFO - 2018-08-22 20:02:55 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:02:55 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:02:55 --> Utf8 Class Initialized
INFO - 2018-08-22 20:02:55 --> URI Class Initialized
INFO - 2018-08-22 20:02:55 --> Router Class Initialized
INFO - 2018-08-22 20:02:55 --> Output Class Initialized
INFO - 2018-08-22 20:02:55 --> Security Class Initialized
DEBUG - 2018-08-22 20:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:02:55 --> CSRF cookie sent
INFO - 2018-08-22 20:02:55 --> Input Class Initialized
INFO - 2018-08-22 20:02:55 --> Language Class Initialized
ERROR - 2018-08-22 20:02:55 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 20:03:28 --> Config Class Initialized
INFO - 2018-08-22 20:03:28 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:03:28 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:03:28 --> Utf8 Class Initialized
INFO - 2018-08-22 20:03:28 --> URI Class Initialized
INFO - 2018-08-22 20:03:28 --> Router Class Initialized
INFO - 2018-08-22 20:03:28 --> Output Class Initialized
INFO - 2018-08-22 20:03:28 --> Security Class Initialized
DEBUG - 2018-08-22 20:03:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:03:28 --> CSRF cookie sent
INFO - 2018-08-22 20:03:28 --> CSRF token verified
INFO - 2018-08-22 20:03:28 --> Input Class Initialized
INFO - 2018-08-22 20:03:28 --> Language Class Initialized
INFO - 2018-08-22 20:03:28 --> Loader Class Initialized
INFO - 2018-08-22 20:03:28 --> Helper loaded: url_helper
INFO - 2018-08-22 20:03:28 --> Helper loaded: form_helper
INFO - 2018-08-22 20:03:28 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:03:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:03:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:03:28 --> User Agent Class Initialized
INFO - 2018-08-22 20:03:28 --> Controller Class Initialized
INFO - 2018-08-22 20:03:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:03:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:03:28 --> Pixel_Model class loaded
INFO - 2018-08-22 20:03:28 --> Database Driver Class Initialized
INFO - 2018-08-22 20:03:28 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:03:28 --> Form Validation Class Initialized
INFO - 2018-08-22 20:03:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 20:03:28 --> Database Driver Class Initialized
INFO - 2018-08-22 20:03:28 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:03:28 --> Config Class Initialized
INFO - 2018-08-22 20:03:28 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:03:28 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:03:28 --> Utf8 Class Initialized
INFO - 2018-08-22 20:03:28 --> URI Class Initialized
INFO - 2018-08-22 20:03:28 --> Router Class Initialized
INFO - 2018-08-22 20:03:28 --> Output Class Initialized
INFO - 2018-08-22 20:03:28 --> Security Class Initialized
DEBUG - 2018-08-22 20:03:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:03:28 --> CSRF cookie sent
INFO - 2018-08-22 20:03:28 --> Input Class Initialized
INFO - 2018-08-22 20:03:28 --> Language Class Initialized
INFO - 2018-08-22 20:03:28 --> Loader Class Initialized
INFO - 2018-08-22 20:03:28 --> Helper loaded: url_helper
INFO - 2018-08-22 20:03:28 --> Helper loaded: form_helper
INFO - 2018-08-22 20:03:28 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:03:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:03:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:03:28 --> User Agent Class Initialized
INFO - 2018-08-22 20:03:28 --> Controller Class Initialized
INFO - 2018-08-22 20:03:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:03:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:03:28 --> Pixel_Model class loaded
INFO - 2018-08-22 20:03:28 --> Database Driver Class Initialized
INFO - 2018-08-22 20:03:28 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:03:28 --> Database Driver Class Initialized
INFO - 2018-08-22 20:03:28 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:03:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 20:03:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 20:03:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 20:03:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 20:03:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 20:03:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 20:03:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 20:03:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/liens_on_house.php
INFO - 2018-08-22 20:03:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 20:03:28 --> Final output sent to browser
DEBUG - 2018-08-22 20:03:28 --> Total execution time: 0.0462
INFO - 2018-08-22 20:03:29 --> Config Class Initialized
INFO - 2018-08-22 20:03:29 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:03:29 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:03:29 --> Utf8 Class Initialized
INFO - 2018-08-22 20:03:29 --> URI Class Initialized
INFO - 2018-08-22 20:03:29 --> Router Class Initialized
INFO - 2018-08-22 20:03:29 --> Output Class Initialized
INFO - 2018-08-22 20:03:29 --> Security Class Initialized
DEBUG - 2018-08-22 20:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:03:29 --> CSRF cookie sent
INFO - 2018-08-22 20:03:29 --> Input Class Initialized
INFO - 2018-08-22 20:03:29 --> Language Class Initialized
ERROR - 2018-08-22 20:03:29 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 20:03:51 --> Config Class Initialized
INFO - 2018-08-22 20:03:51 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:03:51 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:03:51 --> Utf8 Class Initialized
INFO - 2018-08-22 20:03:51 --> URI Class Initialized
INFO - 2018-08-22 20:03:51 --> Router Class Initialized
INFO - 2018-08-22 20:03:51 --> Output Class Initialized
INFO - 2018-08-22 20:03:51 --> Security Class Initialized
DEBUG - 2018-08-22 20:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:03:51 --> CSRF cookie sent
INFO - 2018-08-22 20:03:51 --> CSRF token verified
INFO - 2018-08-22 20:03:51 --> Input Class Initialized
INFO - 2018-08-22 20:03:51 --> Language Class Initialized
INFO - 2018-08-22 20:03:51 --> Loader Class Initialized
INFO - 2018-08-22 20:03:51 --> Helper loaded: url_helper
INFO - 2018-08-22 20:03:51 --> Helper loaded: form_helper
INFO - 2018-08-22 20:03:51 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:03:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:03:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:03:51 --> User Agent Class Initialized
INFO - 2018-08-22 20:03:51 --> Controller Class Initialized
INFO - 2018-08-22 20:03:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:03:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:03:51 --> Pixel_Model class loaded
INFO - 2018-08-22 20:03:51 --> Database Driver Class Initialized
INFO - 2018-08-22 20:03:51 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:03:51 --> Form Validation Class Initialized
INFO - 2018-08-22 20:03:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 20:03:51 --> Database Driver Class Initialized
INFO - 2018-08-22 20:03:51 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:03:51 --> Config Class Initialized
INFO - 2018-08-22 20:03:51 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:03:51 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:03:51 --> Utf8 Class Initialized
INFO - 2018-08-22 20:03:51 --> URI Class Initialized
INFO - 2018-08-22 20:03:51 --> Router Class Initialized
INFO - 2018-08-22 20:03:51 --> Output Class Initialized
INFO - 2018-08-22 20:03:51 --> Security Class Initialized
DEBUG - 2018-08-22 20:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:03:51 --> CSRF cookie sent
INFO - 2018-08-22 20:03:51 --> Input Class Initialized
INFO - 2018-08-22 20:03:51 --> Language Class Initialized
INFO - 2018-08-22 20:03:51 --> Loader Class Initialized
INFO - 2018-08-22 20:03:51 --> Helper loaded: url_helper
INFO - 2018-08-22 20:03:51 --> Helper loaded: form_helper
INFO - 2018-08-22 20:03:51 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:03:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:03:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:03:51 --> User Agent Class Initialized
INFO - 2018-08-22 20:03:51 --> Controller Class Initialized
INFO - 2018-08-22 20:03:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:03:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:03:51 --> Pixel_Model class loaded
INFO - 2018-08-22 20:03:51 --> Database Driver Class Initialized
INFO - 2018-08-22 20:03:51 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:03:51 --> Database Driver Class Initialized
INFO - 2018-08-22 20:03:51 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:03:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 20:03:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 20:03:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 20:03:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 20:03:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 20:03:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 20:03:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 20:03:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/have_loan_money.php
INFO - 2018-08-22 20:03:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 20:03:51 --> Final output sent to browser
DEBUG - 2018-08-22 20:03:51 --> Total execution time: 0.0479
INFO - 2018-08-22 20:03:52 --> Config Class Initialized
INFO - 2018-08-22 20:03:52 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:03:52 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:03:52 --> Utf8 Class Initialized
INFO - 2018-08-22 20:03:52 --> URI Class Initialized
INFO - 2018-08-22 20:03:52 --> Router Class Initialized
INFO - 2018-08-22 20:03:52 --> Output Class Initialized
INFO - 2018-08-22 20:03:52 --> Security Class Initialized
DEBUG - 2018-08-22 20:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:03:52 --> CSRF cookie sent
INFO - 2018-08-22 20:03:52 --> Input Class Initialized
INFO - 2018-08-22 20:03:52 --> Language Class Initialized
ERROR - 2018-08-22 20:03:52 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 20:04:15 --> Config Class Initialized
INFO - 2018-08-22 20:04:15 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:04:15 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:04:15 --> Utf8 Class Initialized
INFO - 2018-08-22 20:04:15 --> URI Class Initialized
INFO - 2018-08-22 20:04:15 --> Router Class Initialized
INFO - 2018-08-22 20:04:15 --> Output Class Initialized
INFO - 2018-08-22 20:04:15 --> Security Class Initialized
DEBUG - 2018-08-22 20:04:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:04:15 --> CSRF cookie sent
INFO - 2018-08-22 20:04:15 --> CSRF token verified
INFO - 2018-08-22 20:04:15 --> Input Class Initialized
INFO - 2018-08-22 20:04:15 --> Language Class Initialized
INFO - 2018-08-22 20:04:15 --> Loader Class Initialized
INFO - 2018-08-22 20:04:15 --> Helper loaded: url_helper
INFO - 2018-08-22 20:04:15 --> Helper loaded: form_helper
INFO - 2018-08-22 20:04:15 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:04:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:04:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:04:15 --> User Agent Class Initialized
INFO - 2018-08-22 20:04:15 --> Controller Class Initialized
INFO - 2018-08-22 20:04:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:04:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:04:15 --> Pixel_Model class loaded
INFO - 2018-08-22 20:04:15 --> Database Driver Class Initialized
INFO - 2018-08-22 20:04:15 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:04:15 --> Form Validation Class Initialized
INFO - 2018-08-22 20:04:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 20:04:15 --> Database Driver Class Initialized
INFO - 2018-08-22 20:04:15 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:04:15 --> Config Class Initialized
INFO - 2018-08-22 20:04:15 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:04:15 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:04:15 --> Utf8 Class Initialized
INFO - 2018-08-22 20:04:15 --> URI Class Initialized
INFO - 2018-08-22 20:04:15 --> Router Class Initialized
INFO - 2018-08-22 20:04:15 --> Output Class Initialized
INFO - 2018-08-22 20:04:15 --> Security Class Initialized
DEBUG - 2018-08-22 20:04:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:04:15 --> CSRF cookie sent
INFO - 2018-08-22 20:04:15 --> Input Class Initialized
INFO - 2018-08-22 20:04:15 --> Language Class Initialized
INFO - 2018-08-22 20:04:15 --> Loader Class Initialized
INFO - 2018-08-22 20:04:15 --> Helper loaded: url_helper
INFO - 2018-08-22 20:04:15 --> Helper loaded: form_helper
INFO - 2018-08-22 20:04:15 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:04:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:04:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:04:15 --> User Agent Class Initialized
INFO - 2018-08-22 20:04:15 --> Controller Class Initialized
INFO - 2018-08-22 20:04:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:04:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:04:15 --> Pixel_Model class loaded
INFO - 2018-08-22 20:04:15 --> Database Driver Class Initialized
INFO - 2018-08-22 20:04:15 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:04:15 --> Database Driver Class Initialized
INFO - 2018-08-22 20:04:15 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:04:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 20:04:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 20:04:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 20:04:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 20:04:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 20:04:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 20:04:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 20:04:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/social_class.php
INFO - 2018-08-22 20:04:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 20:04:15 --> Final output sent to browser
DEBUG - 2018-08-22 20:04:15 --> Total execution time: 0.0381
INFO - 2018-08-22 20:04:15 --> Config Class Initialized
INFO - 2018-08-22 20:04:15 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:04:15 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:04:15 --> Utf8 Class Initialized
INFO - 2018-08-22 20:04:15 --> URI Class Initialized
INFO - 2018-08-22 20:04:15 --> Router Class Initialized
INFO - 2018-08-22 20:04:15 --> Output Class Initialized
INFO - 2018-08-22 20:04:15 --> Security Class Initialized
DEBUG - 2018-08-22 20:04:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:04:15 --> CSRF cookie sent
INFO - 2018-08-22 20:04:15 --> Input Class Initialized
INFO - 2018-08-22 20:04:15 --> Language Class Initialized
ERROR - 2018-08-22 20:04:15 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 20:04:34 --> Config Class Initialized
INFO - 2018-08-22 20:04:34 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:04:34 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:04:34 --> Utf8 Class Initialized
INFO - 2018-08-22 20:04:34 --> URI Class Initialized
INFO - 2018-08-22 20:04:34 --> Router Class Initialized
INFO - 2018-08-22 20:04:34 --> Output Class Initialized
INFO - 2018-08-22 20:04:34 --> Security Class Initialized
DEBUG - 2018-08-22 20:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:04:34 --> CSRF cookie sent
INFO - 2018-08-22 20:04:34 --> CSRF token verified
INFO - 2018-08-22 20:04:34 --> Input Class Initialized
INFO - 2018-08-22 20:04:34 --> Language Class Initialized
INFO - 2018-08-22 20:04:34 --> Loader Class Initialized
INFO - 2018-08-22 20:04:34 --> Helper loaded: url_helper
INFO - 2018-08-22 20:04:34 --> Helper loaded: form_helper
INFO - 2018-08-22 20:04:34 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:04:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:04:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:04:34 --> User Agent Class Initialized
INFO - 2018-08-22 20:04:34 --> Controller Class Initialized
INFO - 2018-08-22 20:04:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:04:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:04:34 --> Pixel_Model class loaded
INFO - 2018-08-22 20:04:34 --> Database Driver Class Initialized
INFO - 2018-08-22 20:04:34 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:04:34 --> Form Validation Class Initialized
INFO - 2018-08-22 20:04:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 20:04:34 --> Database Driver Class Initialized
INFO - 2018-08-22 20:04:34 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:04:34 --> Config Class Initialized
INFO - 2018-08-22 20:04:34 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:04:34 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:04:34 --> Utf8 Class Initialized
INFO - 2018-08-22 20:04:34 --> URI Class Initialized
INFO - 2018-08-22 20:04:34 --> Router Class Initialized
INFO - 2018-08-22 20:04:34 --> Output Class Initialized
INFO - 2018-08-22 20:04:34 --> Security Class Initialized
DEBUG - 2018-08-22 20:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:04:34 --> CSRF cookie sent
INFO - 2018-08-22 20:04:34 --> Input Class Initialized
INFO - 2018-08-22 20:04:34 --> Language Class Initialized
INFO - 2018-08-22 20:04:34 --> Loader Class Initialized
INFO - 2018-08-22 20:04:34 --> Helper loaded: url_helper
INFO - 2018-08-22 20:04:34 --> Helper loaded: form_helper
INFO - 2018-08-22 20:04:34 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:04:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:04:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:04:34 --> User Agent Class Initialized
INFO - 2018-08-22 20:04:34 --> Controller Class Initialized
INFO - 2018-08-22 20:04:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:04:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:04:34 --> Pixel_Model class loaded
INFO - 2018-08-22 20:04:34 --> Database Driver Class Initialized
INFO - 2018-08-22 20:04:34 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:04:34 --> Database Driver Class Initialized
INFO - 2018-08-22 20:04:34 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:04:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 20:04:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 20:04:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 20:04:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 20:04:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 20:04:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 20:04:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 20:04:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/s_social_class.php
INFO - 2018-08-22 20:04:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 20:04:34 --> Final output sent to browser
DEBUG - 2018-08-22 20:04:34 --> Total execution time: 0.0482
INFO - 2018-08-22 20:04:35 --> Config Class Initialized
INFO - 2018-08-22 20:04:35 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:04:35 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:04:35 --> Utf8 Class Initialized
INFO - 2018-08-22 20:04:35 --> URI Class Initialized
INFO - 2018-08-22 20:04:35 --> Router Class Initialized
INFO - 2018-08-22 20:04:35 --> Output Class Initialized
INFO - 2018-08-22 20:04:35 --> Security Class Initialized
DEBUG - 2018-08-22 20:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:04:35 --> CSRF cookie sent
INFO - 2018-08-22 20:04:35 --> Input Class Initialized
INFO - 2018-08-22 20:04:35 --> Language Class Initialized
ERROR - 2018-08-22 20:04:35 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 20:05:14 --> Config Class Initialized
INFO - 2018-08-22 20:05:14 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:05:14 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:05:14 --> Utf8 Class Initialized
INFO - 2018-08-22 20:05:14 --> URI Class Initialized
INFO - 2018-08-22 20:05:14 --> Router Class Initialized
INFO - 2018-08-22 20:05:14 --> Output Class Initialized
INFO - 2018-08-22 20:05:14 --> Security Class Initialized
DEBUG - 2018-08-22 20:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:05:14 --> CSRF cookie sent
INFO - 2018-08-22 20:05:14 --> Input Class Initialized
INFO - 2018-08-22 20:05:14 --> Language Class Initialized
INFO - 2018-08-22 20:05:14 --> Loader Class Initialized
INFO - 2018-08-22 20:05:14 --> Helper loaded: url_helper
INFO - 2018-08-22 20:05:14 --> Helper loaded: form_helper
INFO - 2018-08-22 20:05:14 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:05:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:05:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:05:14 --> User Agent Class Initialized
INFO - 2018-08-22 20:05:14 --> Controller Class Initialized
INFO - 2018-08-22 20:05:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:05:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:05:14 --> Pixel_Model class loaded
INFO - 2018-08-22 20:05:15 --> Database Driver Class Initialized
INFO - 2018-08-22 20:05:15 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:05:15 --> Database Driver Class Initialized
INFO - 2018-08-22 20:05:15 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:05:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 20:05:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 20:05:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 20:05:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 20:05:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 20:05:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 20:05:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 20:05:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-22 20:05:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 20:05:15 --> Final output sent to browser
DEBUG - 2018-08-22 20:05:15 --> Total execution time: 0.0608
INFO - 2018-08-22 20:05:15 --> Config Class Initialized
INFO - 2018-08-22 20:05:15 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:05:15 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:05:15 --> Utf8 Class Initialized
INFO - 2018-08-22 20:05:15 --> URI Class Initialized
INFO - 2018-08-22 20:05:15 --> Router Class Initialized
INFO - 2018-08-22 20:05:15 --> Output Class Initialized
INFO - 2018-08-22 20:05:15 --> Security Class Initialized
DEBUG - 2018-08-22 20:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:05:15 --> CSRF cookie sent
INFO - 2018-08-22 20:05:15 --> Input Class Initialized
INFO - 2018-08-22 20:05:15 --> Language Class Initialized
ERROR - 2018-08-22 20:05:15 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 20:05:49 --> Config Class Initialized
INFO - 2018-08-22 20:05:49 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:05:49 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:05:49 --> Utf8 Class Initialized
INFO - 2018-08-22 20:05:49 --> URI Class Initialized
INFO - 2018-08-22 20:05:49 --> Router Class Initialized
INFO - 2018-08-22 20:05:49 --> Output Class Initialized
INFO - 2018-08-22 20:05:49 --> Security Class Initialized
DEBUG - 2018-08-22 20:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:05:49 --> CSRF cookie sent
INFO - 2018-08-22 20:05:49 --> Input Class Initialized
INFO - 2018-08-22 20:05:49 --> Language Class Initialized
ERROR - 2018-08-22 20:05:49 --> 404 Page Not Found: Influancer/index
INFO - 2018-08-22 20:05:57 --> Config Class Initialized
INFO - 2018-08-22 20:05:57 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:05:57 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:05:57 --> Utf8 Class Initialized
INFO - 2018-08-22 20:05:57 --> URI Class Initialized
INFO - 2018-08-22 20:05:57 --> Router Class Initialized
INFO - 2018-08-22 20:05:57 --> Output Class Initialized
INFO - 2018-08-22 20:05:57 --> Security Class Initialized
DEBUG - 2018-08-22 20:05:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:05:57 --> CSRF cookie sent
INFO - 2018-08-22 20:05:57 --> Input Class Initialized
INFO - 2018-08-22 20:05:57 --> Language Class Initialized
INFO - 2018-08-22 20:05:57 --> Loader Class Initialized
INFO - 2018-08-22 20:05:57 --> Helper loaded: url_helper
INFO - 2018-08-22 20:05:57 --> Helper loaded: form_helper
INFO - 2018-08-22 20:05:57 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:05:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:05:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:05:57 --> User Agent Class Initialized
INFO - 2018-08-22 20:05:57 --> Controller Class Initialized
INFO - 2018-08-22 20:05:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:05:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:05:57 --> Pixel_Model class loaded
INFO - 2018-08-22 20:05:57 --> Database Driver Class Initialized
INFO - 2018-08-22 20:05:57 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:05:57 --> Database Driver Class Initialized
INFO - 2018-08-22 20:05:57 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:05:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 20:05:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 20:05:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 20:05:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 20:05:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 20:05:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 20:05:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 20:05:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/influencer_info.php
INFO - 2018-08-22 20:05:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 20:05:57 --> Final output sent to browser
DEBUG - 2018-08-22 20:05:57 --> Total execution time: 0.0640
INFO - 2018-08-22 20:05:58 --> Config Class Initialized
INFO - 2018-08-22 20:05:58 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:05:58 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:05:58 --> Utf8 Class Initialized
INFO - 2018-08-22 20:05:58 --> URI Class Initialized
INFO - 2018-08-22 20:05:58 --> Router Class Initialized
INFO - 2018-08-22 20:05:58 --> Output Class Initialized
INFO - 2018-08-22 20:05:58 --> Security Class Initialized
DEBUG - 2018-08-22 20:05:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:05:58 --> CSRF cookie sent
INFO - 2018-08-22 20:05:58 --> Input Class Initialized
INFO - 2018-08-22 20:05:58 --> Language Class Initialized
ERROR - 2018-08-22 20:05:58 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 20:06:52 --> Config Class Initialized
INFO - 2018-08-22 20:06:52 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:06:52 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:06:52 --> Utf8 Class Initialized
INFO - 2018-08-22 20:06:52 --> URI Class Initialized
INFO - 2018-08-22 20:06:52 --> Router Class Initialized
INFO - 2018-08-22 20:06:52 --> Output Class Initialized
INFO - 2018-08-22 20:06:52 --> Security Class Initialized
DEBUG - 2018-08-22 20:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:06:52 --> CSRF cookie sent
INFO - 2018-08-22 20:06:52 --> Input Class Initialized
INFO - 2018-08-22 20:06:52 --> Language Class Initialized
INFO - 2018-08-22 20:06:52 --> Loader Class Initialized
INFO - 2018-08-22 20:06:52 --> Helper loaded: url_helper
INFO - 2018-08-22 20:06:52 --> Helper loaded: form_helper
INFO - 2018-08-22 20:06:52 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:06:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:06:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:06:52 --> User Agent Class Initialized
INFO - 2018-08-22 20:06:52 --> Controller Class Initialized
INFO - 2018-08-22 20:06:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:06:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:06:52 --> Pixel_Model class loaded
INFO - 2018-08-22 20:06:52 --> Database Driver Class Initialized
INFO - 2018-08-22 20:06:52 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:06:52 --> Database Driver Class Initialized
INFO - 2018-08-22 20:06:52 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:06:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 20:06:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 20:06:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 20:06:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 20:06:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 20:06:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 20:06:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 20:06:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-08-22 20:06:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 20:06:52 --> Final output sent to browser
DEBUG - 2018-08-22 20:06:52 --> Total execution time: 0.0567
INFO - 2018-08-22 20:06:53 --> Config Class Initialized
INFO - 2018-08-22 20:06:53 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:06:53 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:06:53 --> Utf8 Class Initialized
INFO - 2018-08-22 20:06:53 --> URI Class Initialized
INFO - 2018-08-22 20:06:53 --> Router Class Initialized
INFO - 2018-08-22 20:06:53 --> Output Class Initialized
INFO - 2018-08-22 20:06:53 --> Security Class Initialized
DEBUG - 2018-08-22 20:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:06:53 --> CSRF cookie sent
INFO - 2018-08-22 20:06:53 --> Input Class Initialized
INFO - 2018-08-22 20:06:53 --> Language Class Initialized
ERROR - 2018-08-22 20:06:53 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 20:07:19 --> Config Class Initialized
INFO - 2018-08-22 20:07:19 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:07:19 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:07:19 --> Utf8 Class Initialized
INFO - 2018-08-22 20:07:19 --> URI Class Initialized
INFO - 2018-08-22 20:07:19 --> Router Class Initialized
INFO - 2018-08-22 20:07:19 --> Output Class Initialized
INFO - 2018-08-22 20:07:19 --> Security Class Initialized
DEBUG - 2018-08-22 20:07:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:07:19 --> CSRF cookie sent
INFO - 2018-08-22 20:07:19 --> CSRF token verified
INFO - 2018-08-22 20:07:19 --> Input Class Initialized
INFO - 2018-08-22 20:07:19 --> Language Class Initialized
INFO - 2018-08-22 20:07:19 --> Loader Class Initialized
INFO - 2018-08-22 20:07:19 --> Helper loaded: url_helper
INFO - 2018-08-22 20:07:19 --> Helper loaded: form_helper
INFO - 2018-08-22 20:07:19 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:07:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:07:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:07:19 --> User Agent Class Initialized
INFO - 2018-08-22 20:07:19 --> Controller Class Initialized
INFO - 2018-08-22 20:07:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:07:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:07:19 --> Pixel_Model class loaded
INFO - 2018-08-22 20:07:19 --> Database Driver Class Initialized
INFO - 2018-08-22 20:07:19 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:07:19 --> Form Validation Class Initialized
INFO - 2018-08-22 20:07:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 20:07:19 --> Database Driver Class Initialized
INFO - 2018-08-22 20:07:19 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:07:19 --> Config Class Initialized
INFO - 2018-08-22 20:07:19 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:07:19 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:07:19 --> Utf8 Class Initialized
INFO - 2018-08-22 20:07:19 --> URI Class Initialized
INFO - 2018-08-22 20:07:19 --> Router Class Initialized
INFO - 2018-08-22 20:07:19 --> Output Class Initialized
INFO - 2018-08-22 20:07:19 --> Security Class Initialized
DEBUG - 2018-08-22 20:07:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:07:19 --> CSRF cookie sent
INFO - 2018-08-22 20:07:19 --> Input Class Initialized
INFO - 2018-08-22 20:07:19 --> Language Class Initialized
INFO - 2018-08-22 20:07:19 --> Loader Class Initialized
INFO - 2018-08-22 20:07:19 --> Helper loaded: url_helper
INFO - 2018-08-22 20:07:19 --> Helper loaded: form_helper
INFO - 2018-08-22 20:07:19 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:07:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:07:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:07:19 --> User Agent Class Initialized
INFO - 2018-08-22 20:07:19 --> Controller Class Initialized
INFO - 2018-08-22 20:07:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:07:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:07:19 --> Pixel_Model class loaded
INFO - 2018-08-22 20:07:19 --> Database Driver Class Initialized
INFO - 2018-08-22 20:07:19 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:07:19 --> Database Driver Class Initialized
INFO - 2018-08-22 20:07:19 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:07:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 20:07:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 20:07:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 20:07:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 20:07:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 20:07:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 20:07:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 20:07:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_title.php
INFO - 2018-08-22 20:07:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 20:07:19 --> Final output sent to browser
DEBUG - 2018-08-22 20:07:19 --> Total execution time: 0.0474
INFO - 2018-08-22 20:07:19 --> Config Class Initialized
INFO - 2018-08-22 20:07:19 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:07:19 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:07:19 --> Utf8 Class Initialized
INFO - 2018-08-22 20:07:19 --> URI Class Initialized
INFO - 2018-08-22 20:07:19 --> Router Class Initialized
INFO - 2018-08-22 20:07:19 --> Output Class Initialized
INFO - 2018-08-22 20:07:19 --> Security Class Initialized
DEBUG - 2018-08-22 20:07:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:07:19 --> CSRF cookie sent
INFO - 2018-08-22 20:07:19 --> Input Class Initialized
INFO - 2018-08-22 20:07:19 --> Language Class Initialized
ERROR - 2018-08-22 20:07:19 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 20:07:24 --> Config Class Initialized
INFO - 2018-08-22 20:07:24 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:07:24 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:07:24 --> Utf8 Class Initialized
INFO - 2018-08-22 20:07:24 --> URI Class Initialized
INFO - 2018-08-22 20:07:24 --> Router Class Initialized
INFO - 2018-08-22 20:07:24 --> Output Class Initialized
INFO - 2018-08-22 20:07:24 --> Security Class Initialized
DEBUG - 2018-08-22 20:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:07:24 --> CSRF cookie sent
INFO - 2018-08-22 20:07:24 --> Input Class Initialized
INFO - 2018-08-22 20:07:24 --> Language Class Initialized
INFO - 2018-08-22 20:07:24 --> Loader Class Initialized
INFO - 2018-08-22 20:07:24 --> Helper loaded: url_helper
INFO - 2018-08-22 20:07:24 --> Helper loaded: form_helper
INFO - 2018-08-22 20:07:24 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:07:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:07:24 --> User Agent Class Initialized
INFO - 2018-08-22 20:07:24 --> Controller Class Initialized
INFO - 2018-08-22 20:07:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:07:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:07:24 --> Pixel_Model class loaded
INFO - 2018-08-22 20:07:24 --> Database Driver Class Initialized
INFO - 2018-08-22 20:07:24 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:07:24 --> Database Driver Class Initialized
INFO - 2018-08-22 20:07:24 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:07:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 20:07:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 20:07:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 20:07:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 20:07:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 20:07:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 20:07:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 20:07:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/affectionate_salutation.php
INFO - 2018-08-22 20:07:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 20:07:24 --> Final output sent to browser
DEBUG - 2018-08-22 20:07:24 --> Total execution time: 0.0449
INFO - 2018-08-22 20:07:25 --> Config Class Initialized
INFO - 2018-08-22 20:07:25 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:07:25 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:07:25 --> Utf8 Class Initialized
INFO - 2018-08-22 20:07:25 --> URI Class Initialized
INFO - 2018-08-22 20:07:25 --> Router Class Initialized
INFO - 2018-08-22 20:07:25 --> Output Class Initialized
INFO - 2018-08-22 20:07:25 --> Security Class Initialized
DEBUG - 2018-08-22 20:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:07:25 --> CSRF cookie sent
INFO - 2018-08-22 20:07:25 --> Input Class Initialized
INFO - 2018-08-22 20:07:25 --> Language Class Initialized
ERROR - 2018-08-22 20:07:25 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 20:07:45 --> Config Class Initialized
INFO - 2018-08-22 20:07:45 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:07:45 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:07:45 --> Utf8 Class Initialized
INFO - 2018-08-22 20:07:45 --> URI Class Initialized
INFO - 2018-08-22 20:07:45 --> Router Class Initialized
INFO - 2018-08-22 20:07:45 --> Output Class Initialized
INFO - 2018-08-22 20:07:45 --> Security Class Initialized
DEBUG - 2018-08-22 20:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:07:45 --> CSRF cookie sent
INFO - 2018-08-22 20:07:45 --> CSRF token verified
INFO - 2018-08-22 20:07:45 --> Input Class Initialized
INFO - 2018-08-22 20:07:45 --> Language Class Initialized
INFO - 2018-08-22 20:07:45 --> Loader Class Initialized
INFO - 2018-08-22 20:07:45 --> Helper loaded: url_helper
INFO - 2018-08-22 20:07:45 --> Helper loaded: form_helper
INFO - 2018-08-22 20:07:45 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:07:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:07:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:07:45 --> User Agent Class Initialized
INFO - 2018-08-22 20:07:45 --> Controller Class Initialized
INFO - 2018-08-22 20:07:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:07:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:07:45 --> Pixel_Model class loaded
INFO - 2018-08-22 20:07:45 --> Database Driver Class Initialized
INFO - 2018-08-22 20:07:45 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:07:45 --> Form Validation Class Initialized
INFO - 2018-08-22 20:07:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 20:07:45 --> Database Driver Class Initialized
INFO - 2018-08-22 20:07:45 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:07:45 --> Config Class Initialized
INFO - 2018-08-22 20:07:45 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:07:45 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:07:45 --> Utf8 Class Initialized
INFO - 2018-08-22 20:07:45 --> URI Class Initialized
INFO - 2018-08-22 20:07:45 --> Router Class Initialized
INFO - 2018-08-22 20:07:45 --> Output Class Initialized
INFO - 2018-08-22 20:07:45 --> Security Class Initialized
DEBUG - 2018-08-22 20:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:07:45 --> CSRF cookie sent
INFO - 2018-08-22 20:07:45 --> Input Class Initialized
INFO - 2018-08-22 20:07:45 --> Language Class Initialized
INFO - 2018-08-22 20:07:45 --> Loader Class Initialized
INFO - 2018-08-22 20:07:45 --> Helper loaded: url_helper
INFO - 2018-08-22 20:07:45 --> Helper loaded: form_helper
INFO - 2018-08-22 20:07:45 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:07:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:07:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:07:45 --> User Agent Class Initialized
INFO - 2018-08-22 20:07:45 --> Controller Class Initialized
INFO - 2018-08-22 20:07:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:07:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:07:45 --> Pixel_Model class loaded
INFO - 2018-08-22 20:07:45 --> Database Driver Class Initialized
INFO - 2018-08-22 20:07:45 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:07:45 --> Database Driver Class Initialized
INFO - 2018-08-22 20:07:45 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:07:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 20:07:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 20:07:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 20:07:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 20:07:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 20:07:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 20:07:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 20:07:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/business_tax_info.php
INFO - 2018-08-22 20:07:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 20:07:45 --> Final output sent to browser
DEBUG - 2018-08-22 20:07:45 --> Total execution time: 0.0454
INFO - 2018-08-22 20:07:45 --> Config Class Initialized
INFO - 2018-08-22 20:07:45 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:07:45 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:07:45 --> Utf8 Class Initialized
INFO - 2018-08-22 20:07:45 --> URI Class Initialized
INFO - 2018-08-22 20:07:45 --> Router Class Initialized
INFO - 2018-08-22 20:07:45 --> Output Class Initialized
INFO - 2018-08-22 20:07:45 --> Security Class Initialized
DEBUG - 2018-08-22 20:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:07:45 --> CSRF cookie sent
INFO - 2018-08-22 20:07:45 --> Input Class Initialized
INFO - 2018-08-22 20:07:45 --> Language Class Initialized
ERROR - 2018-08-22 20:07:45 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 20:08:00 --> Config Class Initialized
INFO - 2018-08-22 20:08:00 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:08:00 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:08:00 --> Utf8 Class Initialized
INFO - 2018-08-22 20:08:00 --> URI Class Initialized
INFO - 2018-08-22 20:08:00 --> Router Class Initialized
INFO - 2018-08-22 20:08:00 --> Output Class Initialized
INFO - 2018-08-22 20:08:00 --> Security Class Initialized
DEBUG - 2018-08-22 20:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:08:00 --> CSRF cookie sent
INFO - 2018-08-22 20:08:00 --> Input Class Initialized
INFO - 2018-08-22 20:08:00 --> Language Class Initialized
INFO - 2018-08-22 20:08:00 --> Loader Class Initialized
INFO - 2018-08-22 20:08:00 --> Helper loaded: url_helper
INFO - 2018-08-22 20:08:00 --> Helper loaded: form_helper
INFO - 2018-08-22 20:08:00 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:08:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:08:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:08:00 --> User Agent Class Initialized
INFO - 2018-08-22 20:08:00 --> Controller Class Initialized
INFO - 2018-08-22 20:08:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:08:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:08:00 --> Pixel_Model class loaded
INFO - 2018-08-22 20:08:00 --> Database Driver Class Initialized
INFO - 2018-08-22 20:08:00 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:08:00 --> Database Driver Class Initialized
INFO - 2018-08-22 20:08:00 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:08:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 20:08:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 20:08:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 20:08:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 20:08:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 20:08:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 20:08:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 20:08:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inherited_income.php
INFO - 2018-08-22 20:08:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 20:08:00 --> Final output sent to browser
DEBUG - 2018-08-22 20:08:00 --> Total execution time: 0.0472
INFO - 2018-08-22 20:08:00 --> Config Class Initialized
INFO - 2018-08-22 20:08:00 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:08:00 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:08:00 --> Utf8 Class Initialized
INFO - 2018-08-22 20:08:00 --> URI Class Initialized
INFO - 2018-08-22 20:08:00 --> Router Class Initialized
INFO - 2018-08-22 20:08:00 --> Output Class Initialized
INFO - 2018-08-22 20:08:00 --> Security Class Initialized
DEBUG - 2018-08-22 20:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:08:00 --> CSRF cookie sent
INFO - 2018-08-22 20:08:00 --> Input Class Initialized
INFO - 2018-08-22 20:08:00 --> Language Class Initialized
ERROR - 2018-08-22 20:08:00 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 20:08:31 --> Config Class Initialized
INFO - 2018-08-22 20:08:31 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:08:31 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:08:31 --> Utf8 Class Initialized
INFO - 2018-08-22 20:08:31 --> URI Class Initialized
INFO - 2018-08-22 20:08:31 --> Router Class Initialized
INFO - 2018-08-22 20:08:31 --> Output Class Initialized
INFO - 2018-08-22 20:08:31 --> Security Class Initialized
DEBUG - 2018-08-22 20:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:08:31 --> CSRF cookie sent
INFO - 2018-08-22 20:08:31 --> CSRF token verified
INFO - 2018-08-22 20:08:31 --> Input Class Initialized
INFO - 2018-08-22 20:08:31 --> Language Class Initialized
INFO - 2018-08-22 20:08:31 --> Loader Class Initialized
INFO - 2018-08-22 20:08:31 --> Helper loaded: url_helper
INFO - 2018-08-22 20:08:31 --> Helper loaded: form_helper
INFO - 2018-08-22 20:08:31 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:08:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:08:31 --> User Agent Class Initialized
INFO - 2018-08-22 20:08:31 --> Controller Class Initialized
INFO - 2018-08-22 20:08:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:08:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:08:31 --> Pixel_Model class loaded
INFO - 2018-08-22 20:08:31 --> Database Driver Class Initialized
INFO - 2018-08-22 20:08:31 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:08:31 --> Form Validation Class Initialized
INFO - 2018-08-22 20:08:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 20:08:31 --> Database Driver Class Initialized
INFO - 2018-08-22 20:08:31 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:08:31 --> Config Class Initialized
INFO - 2018-08-22 20:08:31 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:08:31 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:08:31 --> Utf8 Class Initialized
INFO - 2018-08-22 20:08:31 --> URI Class Initialized
INFO - 2018-08-22 20:08:31 --> Router Class Initialized
INFO - 2018-08-22 20:08:31 --> Output Class Initialized
INFO - 2018-08-22 20:08:31 --> Security Class Initialized
DEBUG - 2018-08-22 20:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:08:31 --> CSRF cookie sent
INFO - 2018-08-22 20:08:31 --> Input Class Initialized
INFO - 2018-08-22 20:08:31 --> Language Class Initialized
INFO - 2018-08-22 20:08:31 --> Loader Class Initialized
INFO - 2018-08-22 20:08:31 --> Helper loaded: url_helper
INFO - 2018-08-22 20:08:31 --> Helper loaded: form_helper
INFO - 2018-08-22 20:08:31 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:08:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:08:31 --> User Agent Class Initialized
INFO - 2018-08-22 20:08:31 --> Controller Class Initialized
INFO - 2018-08-22 20:08:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:08:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:08:31 --> Pixel_Model class loaded
INFO - 2018-08-22 20:08:31 --> Database Driver Class Initialized
INFO - 2018-08-22 20:08:31 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:08:31 --> Database Driver Class Initialized
INFO - 2018-08-22 20:08:31 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:08:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 20:08:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 20:08:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 20:08:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 20:08:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 20:08:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 20:08:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 20:08:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/shift_work.php
INFO - 2018-08-22 20:08:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 20:08:31 --> Final output sent to browser
DEBUG - 2018-08-22 20:08:31 --> Total execution time: 0.0456
INFO - 2018-08-22 20:08:32 --> Config Class Initialized
INFO - 2018-08-22 20:08:32 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:08:32 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:08:32 --> Utf8 Class Initialized
INFO - 2018-08-22 20:08:32 --> URI Class Initialized
INFO - 2018-08-22 20:08:32 --> Router Class Initialized
INFO - 2018-08-22 20:08:32 --> Output Class Initialized
INFO - 2018-08-22 20:08:32 --> Security Class Initialized
DEBUG - 2018-08-22 20:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:08:32 --> CSRF cookie sent
INFO - 2018-08-22 20:08:32 --> Input Class Initialized
INFO - 2018-08-22 20:08:32 --> Language Class Initialized
ERROR - 2018-08-22 20:08:32 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 20:08:38 --> Config Class Initialized
INFO - 2018-08-22 20:08:38 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:08:38 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:08:38 --> Utf8 Class Initialized
INFO - 2018-08-22 20:08:38 --> URI Class Initialized
INFO - 2018-08-22 20:08:38 --> Router Class Initialized
INFO - 2018-08-22 20:08:38 --> Output Class Initialized
INFO - 2018-08-22 20:08:38 --> Security Class Initialized
DEBUG - 2018-08-22 20:08:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:08:38 --> CSRF cookie sent
INFO - 2018-08-22 20:08:38 --> Input Class Initialized
INFO - 2018-08-22 20:08:38 --> Language Class Initialized
INFO - 2018-08-22 20:08:38 --> Loader Class Initialized
INFO - 2018-08-22 20:08:38 --> Helper loaded: url_helper
INFO - 2018-08-22 20:08:38 --> Helper loaded: form_helper
INFO - 2018-08-22 20:08:38 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:08:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:08:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:08:38 --> User Agent Class Initialized
INFO - 2018-08-22 20:08:38 --> Controller Class Initialized
INFO - 2018-08-22 20:08:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:08:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:08:38 --> Pixel_Model class loaded
INFO - 2018-08-22 20:08:38 --> Database Driver Class Initialized
INFO - 2018-08-22 20:08:38 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:08:38 --> Database Driver Class Initialized
INFO - 2018-08-22 20:08:38 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:08:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 20:08:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 20:08:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 20:08:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 20:08:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 20:08:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 20:08:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 20:08:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial_control.php
INFO - 2018-08-22 20:08:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 20:08:38 --> Final output sent to browser
DEBUG - 2018-08-22 20:08:38 --> Total execution time: 0.0518
INFO - 2018-08-22 20:08:39 --> Config Class Initialized
INFO - 2018-08-22 20:08:39 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:08:39 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:08:39 --> Utf8 Class Initialized
INFO - 2018-08-22 20:08:39 --> URI Class Initialized
INFO - 2018-08-22 20:08:39 --> Router Class Initialized
INFO - 2018-08-22 20:08:39 --> Output Class Initialized
INFO - 2018-08-22 20:08:39 --> Security Class Initialized
DEBUG - 2018-08-22 20:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:08:39 --> CSRF cookie sent
INFO - 2018-08-22 20:08:39 --> Input Class Initialized
INFO - 2018-08-22 20:08:39 --> Language Class Initialized
ERROR - 2018-08-22 20:08:39 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 20:08:58 --> Config Class Initialized
INFO - 2018-08-22 20:08:58 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:08:58 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:08:58 --> Utf8 Class Initialized
INFO - 2018-08-22 20:08:58 --> URI Class Initialized
INFO - 2018-08-22 20:08:58 --> Router Class Initialized
INFO - 2018-08-22 20:08:58 --> Output Class Initialized
INFO - 2018-08-22 20:08:58 --> Security Class Initialized
DEBUG - 2018-08-22 20:08:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:08:58 --> CSRF cookie sent
INFO - 2018-08-22 20:08:58 --> Input Class Initialized
INFO - 2018-08-22 20:08:58 --> Language Class Initialized
INFO - 2018-08-22 20:08:58 --> Loader Class Initialized
INFO - 2018-08-22 20:08:58 --> Helper loaded: url_helper
INFO - 2018-08-22 20:08:58 --> Helper loaded: form_helper
INFO - 2018-08-22 20:08:58 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:08:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:08:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:08:58 --> User Agent Class Initialized
INFO - 2018-08-22 20:08:58 --> Controller Class Initialized
INFO - 2018-08-22 20:08:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:08:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:08:58 --> Pixel_Model class loaded
INFO - 2018-08-22 20:08:58 --> Database Driver Class Initialized
INFO - 2018-08-22 20:08:58 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:08:58 --> Database Driver Class Initialized
INFO - 2018-08-22 20:08:58 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:08:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 20:08:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 20:08:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 20:08:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 20:08:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 20:08:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 20:08:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 20:08:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/withheld_sex.php
INFO - 2018-08-22 20:08:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 20:08:58 --> Final output sent to browser
DEBUG - 2018-08-22 20:08:58 --> Total execution time: 0.0730
INFO - 2018-08-22 20:08:59 --> Config Class Initialized
INFO - 2018-08-22 20:08:59 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:08:59 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:08:59 --> Utf8 Class Initialized
INFO - 2018-08-22 20:08:59 --> URI Class Initialized
INFO - 2018-08-22 20:08:59 --> Router Class Initialized
INFO - 2018-08-22 20:08:59 --> Output Class Initialized
INFO - 2018-08-22 20:08:59 --> Security Class Initialized
DEBUG - 2018-08-22 20:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:08:59 --> CSRF cookie sent
INFO - 2018-08-22 20:08:59 --> Input Class Initialized
INFO - 2018-08-22 20:08:59 --> Language Class Initialized
ERROR - 2018-08-22 20:08:59 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 20:09:28 --> Config Class Initialized
INFO - 2018-08-22 20:09:28 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:09:28 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:09:28 --> Utf8 Class Initialized
INFO - 2018-08-22 20:09:28 --> URI Class Initialized
INFO - 2018-08-22 20:09:28 --> Router Class Initialized
INFO - 2018-08-22 20:09:28 --> Output Class Initialized
INFO - 2018-08-22 20:09:28 --> Security Class Initialized
DEBUG - 2018-08-22 20:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:09:28 --> CSRF cookie sent
INFO - 2018-08-22 20:09:28 --> Input Class Initialized
INFO - 2018-08-22 20:09:28 --> Language Class Initialized
INFO - 2018-08-22 20:09:28 --> Loader Class Initialized
INFO - 2018-08-22 20:09:28 --> Helper loaded: url_helper
INFO - 2018-08-22 20:09:28 --> Helper loaded: form_helper
INFO - 2018-08-22 20:09:28 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:09:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:09:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:09:28 --> User Agent Class Initialized
INFO - 2018-08-22 20:09:28 --> Controller Class Initialized
INFO - 2018-08-22 20:09:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:09:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:09:28 --> Pixel_Model class loaded
INFO - 2018-08-22 20:09:28 --> Database Driver Class Initialized
INFO - 2018-08-22 20:09:28 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:09:28 --> Database Driver Class Initialized
INFO - 2018-08-22 20:09:28 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:09:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 20:09:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 20:09:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 20:09:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 20:09:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 20:09:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 20:09:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 20:09:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pet_abuse.php
INFO - 2018-08-22 20:09:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 20:09:28 --> Final output sent to browser
DEBUG - 2018-08-22 20:09:28 --> Total execution time: 0.0572
INFO - 2018-08-22 20:09:28 --> Config Class Initialized
INFO - 2018-08-22 20:09:28 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:09:28 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:09:28 --> Utf8 Class Initialized
INFO - 2018-08-22 20:09:28 --> URI Class Initialized
INFO - 2018-08-22 20:09:28 --> Router Class Initialized
INFO - 2018-08-22 20:09:28 --> Output Class Initialized
INFO - 2018-08-22 20:09:28 --> Security Class Initialized
DEBUG - 2018-08-22 20:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:09:28 --> CSRF cookie sent
INFO - 2018-08-22 20:09:28 --> Input Class Initialized
INFO - 2018-08-22 20:09:28 --> Language Class Initialized
ERROR - 2018-08-22 20:09:28 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 20:09:40 --> Config Class Initialized
INFO - 2018-08-22 20:09:40 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:09:40 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:09:40 --> Utf8 Class Initialized
INFO - 2018-08-22 20:09:40 --> URI Class Initialized
INFO - 2018-08-22 20:09:40 --> Router Class Initialized
INFO - 2018-08-22 20:09:40 --> Output Class Initialized
INFO - 2018-08-22 20:09:40 --> Security Class Initialized
DEBUG - 2018-08-22 20:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:09:41 --> CSRF cookie sent
INFO - 2018-08-22 20:09:41 --> CSRF token verified
INFO - 2018-08-22 20:09:41 --> Input Class Initialized
INFO - 2018-08-22 20:09:41 --> Language Class Initialized
INFO - 2018-08-22 20:09:41 --> Loader Class Initialized
INFO - 2018-08-22 20:09:41 --> Helper loaded: url_helper
INFO - 2018-08-22 20:09:41 --> Helper loaded: form_helper
INFO - 2018-08-22 20:09:41 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:09:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:09:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:09:41 --> User Agent Class Initialized
INFO - 2018-08-22 20:09:41 --> Controller Class Initialized
INFO - 2018-08-22 20:09:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:09:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:09:41 --> Pixel_Model class loaded
INFO - 2018-08-22 20:09:41 --> Database Driver Class Initialized
INFO - 2018-08-22 20:09:41 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:09:41 --> Form Validation Class Initialized
INFO - 2018-08-22 20:09:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 20:09:41 --> Database Driver Class Initialized
INFO - 2018-08-22 20:09:41 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:09:41 --> Config Class Initialized
INFO - 2018-08-22 20:09:41 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:09:41 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:09:41 --> Utf8 Class Initialized
INFO - 2018-08-22 20:09:41 --> URI Class Initialized
INFO - 2018-08-22 20:09:41 --> Router Class Initialized
INFO - 2018-08-22 20:09:41 --> Output Class Initialized
INFO - 2018-08-22 20:09:41 --> Security Class Initialized
DEBUG - 2018-08-22 20:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:09:41 --> CSRF cookie sent
INFO - 2018-08-22 20:09:41 --> Input Class Initialized
INFO - 2018-08-22 20:09:41 --> Language Class Initialized
INFO - 2018-08-22 20:09:41 --> Loader Class Initialized
INFO - 2018-08-22 20:09:41 --> Helper loaded: url_helper
INFO - 2018-08-22 20:09:41 --> Helper loaded: form_helper
INFO - 2018-08-22 20:09:41 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:09:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:09:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:09:41 --> User Agent Class Initialized
INFO - 2018-08-22 20:09:41 --> Controller Class Initialized
INFO - 2018-08-22 20:09:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:09:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:09:41 --> Pixel_Model class loaded
INFO - 2018-08-22 20:09:41 --> Database Driver Class Initialized
INFO - 2018-08-22 20:09:41 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:09:41 --> Database Driver Class Initialized
INFO - 2018-08-22 20:09:41 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:09:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 20:09:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 20:09:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 20:09:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 20:09:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 20:09:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 20:09:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 20:09:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/has_dating_profile.php
INFO - 2018-08-22 20:09:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 20:09:41 --> Final output sent to browser
DEBUG - 2018-08-22 20:09:41 --> Total execution time: 0.0476
INFO - 2018-08-22 20:09:41 --> Config Class Initialized
INFO - 2018-08-22 20:09:41 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:09:41 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:09:41 --> Utf8 Class Initialized
INFO - 2018-08-22 20:09:41 --> URI Class Initialized
INFO - 2018-08-22 20:09:41 --> Router Class Initialized
INFO - 2018-08-22 20:09:41 --> Output Class Initialized
INFO - 2018-08-22 20:09:41 --> Security Class Initialized
DEBUG - 2018-08-22 20:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:09:41 --> CSRF cookie sent
INFO - 2018-08-22 20:09:41 --> Input Class Initialized
INFO - 2018-08-22 20:09:41 --> Language Class Initialized
ERROR - 2018-08-22 20:09:41 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 20:09:52 --> Config Class Initialized
INFO - 2018-08-22 20:09:52 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:09:52 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:09:52 --> Utf8 Class Initialized
INFO - 2018-08-22 20:09:52 --> URI Class Initialized
INFO - 2018-08-22 20:09:52 --> Router Class Initialized
INFO - 2018-08-22 20:09:52 --> Output Class Initialized
INFO - 2018-08-22 20:09:52 --> Security Class Initialized
DEBUG - 2018-08-22 20:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:09:52 --> CSRF cookie sent
INFO - 2018-08-22 20:09:52 --> Input Class Initialized
INFO - 2018-08-22 20:09:52 --> Language Class Initialized
INFO - 2018-08-22 20:09:52 --> Loader Class Initialized
INFO - 2018-08-22 20:09:52 --> Helper loaded: url_helper
INFO - 2018-08-22 20:09:52 --> Helper loaded: form_helper
INFO - 2018-08-22 20:09:52 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:09:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:09:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:09:52 --> User Agent Class Initialized
INFO - 2018-08-22 20:09:52 --> Controller Class Initialized
INFO - 2018-08-22 20:09:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:09:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:09:52 --> Pixel_Model class loaded
INFO - 2018-08-22 20:09:52 --> Database Driver Class Initialized
INFO - 2018-08-22 20:09:52 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:09:52 --> Database Driver Class Initialized
INFO - 2018-08-22 20:09:52 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:09:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 20:09:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 20:09:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 20:09:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 20:09:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 20:09:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 20:09:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 20:09:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/ethnic_background.php
INFO - 2018-08-22 20:09:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 20:09:52 --> Final output sent to browser
DEBUG - 2018-08-22 20:09:52 --> Total execution time: 0.0597
INFO - 2018-08-22 20:09:53 --> Config Class Initialized
INFO - 2018-08-22 20:09:53 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:09:53 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:09:53 --> Utf8 Class Initialized
INFO - 2018-08-22 20:09:53 --> URI Class Initialized
INFO - 2018-08-22 20:09:53 --> Router Class Initialized
INFO - 2018-08-22 20:09:53 --> Output Class Initialized
INFO - 2018-08-22 20:09:53 --> Security Class Initialized
DEBUG - 2018-08-22 20:09:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:09:53 --> CSRF cookie sent
INFO - 2018-08-22 20:09:53 --> Input Class Initialized
INFO - 2018-08-22 20:09:53 --> Language Class Initialized
ERROR - 2018-08-22 20:09:53 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 20:10:18 --> Config Class Initialized
INFO - 2018-08-22 20:10:18 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:10:18 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:10:18 --> Utf8 Class Initialized
INFO - 2018-08-22 20:10:18 --> URI Class Initialized
INFO - 2018-08-22 20:10:18 --> Router Class Initialized
INFO - 2018-08-22 20:10:18 --> Output Class Initialized
INFO - 2018-08-22 20:10:18 --> Security Class Initialized
DEBUG - 2018-08-22 20:10:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:10:18 --> CSRF cookie sent
INFO - 2018-08-22 20:10:18 --> CSRF token verified
INFO - 2018-08-22 20:10:18 --> Input Class Initialized
INFO - 2018-08-22 20:10:18 --> Language Class Initialized
INFO - 2018-08-22 20:10:18 --> Loader Class Initialized
INFO - 2018-08-22 20:10:18 --> Helper loaded: url_helper
INFO - 2018-08-22 20:10:18 --> Helper loaded: form_helper
INFO - 2018-08-22 20:10:18 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:10:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:10:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:10:18 --> User Agent Class Initialized
INFO - 2018-08-22 20:10:18 --> Controller Class Initialized
INFO - 2018-08-22 20:10:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:10:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:10:18 --> Pixel_Model class loaded
INFO - 2018-08-22 20:10:18 --> Database Driver Class Initialized
INFO - 2018-08-22 20:10:18 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:10:18 --> Form Validation Class Initialized
INFO - 2018-08-22 20:10:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 20:10:18 --> Database Driver Class Initialized
INFO - 2018-08-22 20:10:18 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:10:18 --> Config Class Initialized
INFO - 2018-08-22 20:10:18 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:10:18 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:10:18 --> Utf8 Class Initialized
INFO - 2018-08-22 20:10:18 --> URI Class Initialized
INFO - 2018-08-22 20:10:18 --> Router Class Initialized
INFO - 2018-08-22 20:10:18 --> Output Class Initialized
INFO - 2018-08-22 20:10:18 --> Security Class Initialized
DEBUG - 2018-08-22 20:10:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:10:18 --> CSRF cookie sent
INFO - 2018-08-22 20:10:18 --> Input Class Initialized
INFO - 2018-08-22 20:10:18 --> Language Class Initialized
INFO - 2018-08-22 20:10:18 --> Loader Class Initialized
INFO - 2018-08-22 20:10:18 --> Helper loaded: url_helper
INFO - 2018-08-22 20:10:18 --> Helper loaded: form_helper
INFO - 2018-08-22 20:10:18 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:10:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:10:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:10:18 --> User Agent Class Initialized
INFO - 2018-08-22 20:10:18 --> Controller Class Initialized
INFO - 2018-08-22 20:10:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:10:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:10:18 --> Pixel_Model class loaded
INFO - 2018-08-22 20:10:18 --> Database Driver Class Initialized
INFO - 2018-08-22 20:10:18 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:10:18 --> Database Driver Class Initialized
INFO - 2018-08-22 20:10:18 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:10:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 20:10:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 20:10:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 20:10:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 20:10:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 20:10:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 20:10:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 20:10:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/assets_info.php
INFO - 2018-08-22 20:10:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 20:10:18 --> Final output sent to browser
DEBUG - 2018-08-22 20:10:18 --> Total execution time: 0.0457
INFO - 2018-08-22 20:10:19 --> Config Class Initialized
INFO - 2018-08-22 20:10:19 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:10:19 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:10:19 --> Utf8 Class Initialized
INFO - 2018-08-22 20:10:19 --> URI Class Initialized
INFO - 2018-08-22 20:10:19 --> Router Class Initialized
INFO - 2018-08-22 20:10:19 --> Output Class Initialized
INFO - 2018-08-22 20:10:19 --> Security Class Initialized
DEBUG - 2018-08-22 20:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:10:19 --> CSRF cookie sent
INFO - 2018-08-22 20:10:19 --> Input Class Initialized
INFO - 2018-08-22 20:10:19 --> Language Class Initialized
ERROR - 2018-08-22 20:10:19 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 20:10:30 --> Config Class Initialized
INFO - 2018-08-22 20:10:30 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:10:30 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:10:30 --> Utf8 Class Initialized
INFO - 2018-08-22 20:10:30 --> URI Class Initialized
INFO - 2018-08-22 20:10:30 --> Router Class Initialized
INFO - 2018-08-22 20:10:30 --> Output Class Initialized
INFO - 2018-08-22 20:10:30 --> Security Class Initialized
DEBUG - 2018-08-22 20:10:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:10:30 --> CSRF cookie sent
INFO - 2018-08-22 20:10:30 --> Input Class Initialized
INFO - 2018-08-22 20:10:30 --> Language Class Initialized
INFO - 2018-08-22 20:10:30 --> Loader Class Initialized
INFO - 2018-08-22 20:10:30 --> Helper loaded: url_helper
INFO - 2018-08-22 20:10:30 --> Helper loaded: form_helper
INFO - 2018-08-22 20:10:30 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:10:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:10:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:10:30 --> User Agent Class Initialized
INFO - 2018-08-22 20:10:30 --> Controller Class Initialized
INFO - 2018-08-22 20:10:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:10:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:10:30 --> Pixel_Model class loaded
INFO - 2018-08-22 20:10:30 --> Database Driver Class Initialized
INFO - 2018-08-22 20:10:30 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:10:30 --> Database Driver Class Initialized
INFO - 2018-08-22 20:10:30 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:10:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 20:10:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 20:10:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 20:10:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 20:10:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 20:10:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 20:10:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 20:10:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/automobile.php
INFO - 2018-08-22 20:10:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 20:10:30 --> Final output sent to browser
DEBUG - 2018-08-22 20:10:30 --> Total execution time: 0.0704
INFO - 2018-08-22 20:10:31 --> Config Class Initialized
INFO - 2018-08-22 20:10:31 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:10:31 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:10:31 --> Utf8 Class Initialized
INFO - 2018-08-22 20:10:31 --> URI Class Initialized
INFO - 2018-08-22 20:10:31 --> Router Class Initialized
INFO - 2018-08-22 20:10:31 --> Output Class Initialized
INFO - 2018-08-22 20:10:31 --> Security Class Initialized
DEBUG - 2018-08-22 20:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:10:31 --> CSRF cookie sent
INFO - 2018-08-22 20:10:31 --> Input Class Initialized
INFO - 2018-08-22 20:10:31 --> Language Class Initialized
ERROR - 2018-08-22 20:10:31 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 20:11:06 --> Config Class Initialized
INFO - 2018-08-22 20:11:06 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:11:06 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:11:06 --> Utf8 Class Initialized
INFO - 2018-08-22 20:11:06 --> URI Class Initialized
INFO - 2018-08-22 20:11:06 --> Router Class Initialized
INFO - 2018-08-22 20:11:06 --> Output Class Initialized
INFO - 2018-08-22 20:11:06 --> Security Class Initialized
DEBUG - 2018-08-22 20:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:11:06 --> CSRF cookie sent
INFO - 2018-08-22 20:11:06 --> CSRF token verified
INFO - 2018-08-22 20:11:06 --> Input Class Initialized
INFO - 2018-08-22 20:11:06 --> Language Class Initialized
INFO - 2018-08-22 20:11:06 --> Loader Class Initialized
INFO - 2018-08-22 20:11:06 --> Helper loaded: url_helper
INFO - 2018-08-22 20:11:06 --> Helper loaded: form_helper
INFO - 2018-08-22 20:11:06 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:11:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:11:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:11:06 --> User Agent Class Initialized
INFO - 2018-08-22 20:11:06 --> Controller Class Initialized
INFO - 2018-08-22 20:11:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:11:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:11:06 --> Pixel_Model class loaded
INFO - 2018-08-22 20:11:06 --> Database Driver Class Initialized
INFO - 2018-08-22 20:11:06 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:11:06 --> Form Validation Class Initialized
INFO - 2018-08-22 20:11:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 20:11:06 --> Database Driver Class Initialized
INFO - 2018-08-22 20:11:06 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:11:06 --> Config Class Initialized
INFO - 2018-08-22 20:11:06 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:11:06 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:11:06 --> Utf8 Class Initialized
INFO - 2018-08-22 20:11:06 --> URI Class Initialized
INFO - 2018-08-22 20:11:06 --> Router Class Initialized
INFO - 2018-08-22 20:11:06 --> Output Class Initialized
INFO - 2018-08-22 20:11:06 --> Security Class Initialized
DEBUG - 2018-08-22 20:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:11:06 --> CSRF cookie sent
INFO - 2018-08-22 20:11:06 --> Input Class Initialized
INFO - 2018-08-22 20:11:06 --> Language Class Initialized
INFO - 2018-08-22 20:11:06 --> Loader Class Initialized
INFO - 2018-08-22 20:11:06 --> Helper loaded: url_helper
INFO - 2018-08-22 20:11:06 --> Helper loaded: form_helper
INFO - 2018-08-22 20:11:06 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:11:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:11:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:11:06 --> User Agent Class Initialized
INFO - 2018-08-22 20:11:06 --> Controller Class Initialized
INFO - 2018-08-22 20:11:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:11:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:11:06 --> Pixel_Model class loaded
INFO - 2018-08-22 20:11:06 --> Database Driver Class Initialized
INFO - 2018-08-22 20:11:06 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:11:06 --> Database Driver Class Initialized
INFO - 2018-08-22 20:11:06 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:11:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 20:11:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 20:11:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 20:11:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 20:11:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 20:11:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 20:11:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 20:11:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/other_autos.php
INFO - 2018-08-22 20:11:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 20:11:06 --> Final output sent to browser
DEBUG - 2018-08-22 20:11:06 --> Total execution time: 0.0499
INFO - 2018-08-22 20:11:08 --> Config Class Initialized
INFO - 2018-08-22 20:11:08 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:11:08 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:11:08 --> Utf8 Class Initialized
INFO - 2018-08-22 20:11:08 --> URI Class Initialized
INFO - 2018-08-22 20:11:08 --> Router Class Initialized
INFO - 2018-08-22 20:11:08 --> Output Class Initialized
INFO - 2018-08-22 20:11:08 --> Security Class Initialized
DEBUG - 2018-08-22 20:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:11:08 --> CSRF cookie sent
INFO - 2018-08-22 20:11:08 --> Input Class Initialized
INFO - 2018-08-22 20:11:08 --> Language Class Initialized
ERROR - 2018-08-22 20:11:08 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 20:11:52 --> Config Class Initialized
INFO - 2018-08-22 20:11:52 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:11:52 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:11:52 --> Utf8 Class Initialized
INFO - 2018-08-22 20:11:52 --> URI Class Initialized
INFO - 2018-08-22 20:11:52 --> Router Class Initialized
INFO - 2018-08-22 20:11:52 --> Output Class Initialized
INFO - 2018-08-22 20:11:52 --> Security Class Initialized
DEBUG - 2018-08-22 20:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:11:52 --> CSRF cookie sent
INFO - 2018-08-22 20:11:52 --> CSRF token verified
INFO - 2018-08-22 20:11:52 --> Input Class Initialized
INFO - 2018-08-22 20:11:52 --> Language Class Initialized
INFO - 2018-08-22 20:11:52 --> Loader Class Initialized
INFO - 2018-08-22 20:11:52 --> Helper loaded: url_helper
INFO - 2018-08-22 20:11:52 --> Helper loaded: form_helper
INFO - 2018-08-22 20:11:52 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:11:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:11:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:11:52 --> User Agent Class Initialized
INFO - 2018-08-22 20:11:52 --> Controller Class Initialized
INFO - 2018-08-22 20:11:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:11:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:11:52 --> Pixel_Model class loaded
INFO - 2018-08-22 20:11:52 --> Database Driver Class Initialized
INFO - 2018-08-22 20:11:52 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:11:52 --> Form Validation Class Initialized
INFO - 2018-08-22 20:11:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 20:11:52 --> Database Driver Class Initialized
INFO - 2018-08-22 20:11:52 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:11:52 --> Config Class Initialized
INFO - 2018-08-22 20:11:52 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:11:52 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:11:52 --> Utf8 Class Initialized
INFO - 2018-08-22 20:11:52 --> URI Class Initialized
INFO - 2018-08-22 20:11:52 --> Router Class Initialized
INFO - 2018-08-22 20:11:52 --> Output Class Initialized
INFO - 2018-08-22 20:11:52 --> Security Class Initialized
DEBUG - 2018-08-22 20:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:11:52 --> CSRF cookie sent
INFO - 2018-08-22 20:11:52 --> Input Class Initialized
INFO - 2018-08-22 20:11:52 --> Language Class Initialized
INFO - 2018-08-22 20:11:52 --> Loader Class Initialized
INFO - 2018-08-22 20:11:52 --> Helper loaded: url_helper
INFO - 2018-08-22 20:11:52 --> Helper loaded: form_helper
INFO - 2018-08-22 20:11:52 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:11:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:11:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:11:52 --> User Agent Class Initialized
INFO - 2018-08-22 20:11:52 --> Controller Class Initialized
INFO - 2018-08-22 20:11:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:11:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:11:52 --> Pixel_Model class loaded
INFO - 2018-08-22 20:11:52 --> Database Driver Class Initialized
INFO - 2018-08-22 20:11:52 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:11:52 --> Database Driver Class Initialized
INFO - 2018-08-22 20:11:52 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:11:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 20:11:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 20:11:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 20:11:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 20:11:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 20:11:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 20:11:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 20:11:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/collectables.php
INFO - 2018-08-22 20:11:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 20:11:52 --> Final output sent to browser
DEBUG - 2018-08-22 20:11:52 --> Total execution time: 0.0562
INFO - 2018-08-22 20:11:53 --> Config Class Initialized
INFO - 2018-08-22 20:11:53 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:11:53 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:11:53 --> Utf8 Class Initialized
INFO - 2018-08-22 20:11:53 --> URI Class Initialized
INFO - 2018-08-22 20:11:53 --> Router Class Initialized
INFO - 2018-08-22 20:11:53 --> Output Class Initialized
INFO - 2018-08-22 20:11:53 --> Security Class Initialized
DEBUG - 2018-08-22 20:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:11:53 --> CSRF cookie sent
INFO - 2018-08-22 20:11:53 --> Input Class Initialized
INFO - 2018-08-22 20:11:53 --> Language Class Initialized
ERROR - 2018-08-22 20:11:53 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 20:12:23 --> Config Class Initialized
INFO - 2018-08-22 20:12:23 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:12:23 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:12:23 --> Utf8 Class Initialized
INFO - 2018-08-22 20:12:23 --> URI Class Initialized
INFO - 2018-08-22 20:12:23 --> Router Class Initialized
INFO - 2018-08-22 20:12:23 --> Output Class Initialized
INFO - 2018-08-22 20:12:23 --> Security Class Initialized
DEBUG - 2018-08-22 20:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:12:23 --> CSRF cookie sent
INFO - 2018-08-22 20:12:23 --> CSRF token verified
INFO - 2018-08-22 20:12:23 --> Input Class Initialized
INFO - 2018-08-22 20:12:23 --> Language Class Initialized
INFO - 2018-08-22 20:12:23 --> Loader Class Initialized
INFO - 2018-08-22 20:12:23 --> Helper loaded: url_helper
INFO - 2018-08-22 20:12:23 --> Helper loaded: form_helper
INFO - 2018-08-22 20:12:23 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:12:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:12:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:12:23 --> User Agent Class Initialized
INFO - 2018-08-22 20:12:23 --> Controller Class Initialized
INFO - 2018-08-22 20:12:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:12:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:12:23 --> Pixel_Model class loaded
INFO - 2018-08-22 20:12:23 --> Database Driver Class Initialized
INFO - 2018-08-22 20:12:23 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:12:23 --> Form Validation Class Initialized
INFO - 2018-08-22 20:12:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 20:12:23 --> Database Driver Class Initialized
INFO - 2018-08-22 20:12:23 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:12:23 --> Config Class Initialized
INFO - 2018-08-22 20:12:23 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:12:23 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:12:23 --> Utf8 Class Initialized
INFO - 2018-08-22 20:12:23 --> URI Class Initialized
INFO - 2018-08-22 20:12:23 --> Router Class Initialized
INFO - 2018-08-22 20:12:23 --> Output Class Initialized
INFO - 2018-08-22 20:12:23 --> Security Class Initialized
DEBUG - 2018-08-22 20:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:12:23 --> CSRF cookie sent
INFO - 2018-08-22 20:12:23 --> Input Class Initialized
INFO - 2018-08-22 20:12:23 --> Language Class Initialized
INFO - 2018-08-22 20:12:23 --> Loader Class Initialized
INFO - 2018-08-22 20:12:23 --> Helper loaded: url_helper
INFO - 2018-08-22 20:12:23 --> Helper loaded: form_helper
INFO - 2018-08-22 20:12:23 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:12:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:12:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:12:23 --> User Agent Class Initialized
INFO - 2018-08-22 20:12:23 --> Controller Class Initialized
INFO - 2018-08-22 20:12:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:12:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:12:23 --> Pixel_Model class loaded
INFO - 2018-08-22 20:12:23 --> Database Driver Class Initialized
INFO - 2018-08-22 20:12:23 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:12:23 --> Database Driver Class Initialized
INFO - 2018-08-22 20:12:23 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:12:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 20:12:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 20:12:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 20:12:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 20:12:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 20:12:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 20:12:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 20:12:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/gadgets.php
INFO - 2018-08-22 20:12:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 20:12:23 --> Final output sent to browser
DEBUG - 2018-08-22 20:12:23 --> Total execution time: 0.0478
INFO - 2018-08-22 20:12:24 --> Config Class Initialized
INFO - 2018-08-22 20:12:24 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:12:24 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:12:24 --> Utf8 Class Initialized
INFO - 2018-08-22 20:12:24 --> URI Class Initialized
INFO - 2018-08-22 20:12:24 --> Router Class Initialized
INFO - 2018-08-22 20:12:24 --> Output Class Initialized
INFO - 2018-08-22 20:12:24 --> Security Class Initialized
DEBUG - 2018-08-22 20:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:12:24 --> CSRF cookie sent
INFO - 2018-08-22 20:12:24 --> Input Class Initialized
INFO - 2018-08-22 20:12:24 --> Language Class Initialized
ERROR - 2018-08-22 20:12:24 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 20:12:44 --> Config Class Initialized
INFO - 2018-08-22 20:12:44 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:12:44 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:12:44 --> Utf8 Class Initialized
INFO - 2018-08-22 20:12:44 --> URI Class Initialized
INFO - 2018-08-22 20:12:44 --> Router Class Initialized
INFO - 2018-08-22 20:12:44 --> Output Class Initialized
INFO - 2018-08-22 20:12:44 --> Security Class Initialized
DEBUG - 2018-08-22 20:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:12:44 --> CSRF cookie sent
INFO - 2018-08-22 20:12:44 --> CSRF token verified
INFO - 2018-08-22 20:12:44 --> Input Class Initialized
INFO - 2018-08-22 20:12:44 --> Language Class Initialized
INFO - 2018-08-22 20:12:44 --> Loader Class Initialized
INFO - 2018-08-22 20:12:44 --> Helper loaded: url_helper
INFO - 2018-08-22 20:12:44 --> Helper loaded: form_helper
INFO - 2018-08-22 20:12:44 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:12:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:12:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:12:44 --> User Agent Class Initialized
INFO - 2018-08-22 20:12:44 --> Controller Class Initialized
INFO - 2018-08-22 20:12:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:12:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:12:44 --> Pixel_Model class loaded
INFO - 2018-08-22 20:12:44 --> Database Driver Class Initialized
INFO - 2018-08-22 20:12:44 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:12:44 --> Form Validation Class Initialized
INFO - 2018-08-22 20:12:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 20:12:44 --> Database Driver Class Initialized
INFO - 2018-08-22 20:12:44 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:12:44 --> Config Class Initialized
INFO - 2018-08-22 20:12:44 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:12:44 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:12:44 --> Utf8 Class Initialized
INFO - 2018-08-22 20:12:44 --> URI Class Initialized
INFO - 2018-08-22 20:12:44 --> Router Class Initialized
INFO - 2018-08-22 20:12:44 --> Output Class Initialized
INFO - 2018-08-22 20:12:44 --> Security Class Initialized
DEBUG - 2018-08-22 20:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:12:44 --> CSRF cookie sent
INFO - 2018-08-22 20:12:44 --> Input Class Initialized
INFO - 2018-08-22 20:12:44 --> Language Class Initialized
INFO - 2018-08-22 20:12:44 --> Loader Class Initialized
INFO - 2018-08-22 20:12:44 --> Helper loaded: url_helper
INFO - 2018-08-22 20:12:44 --> Helper loaded: form_helper
INFO - 2018-08-22 20:12:44 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:12:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:12:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:12:44 --> User Agent Class Initialized
INFO - 2018-08-22 20:12:44 --> Controller Class Initialized
INFO - 2018-08-22 20:12:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:12:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:12:44 --> Pixel_Model class loaded
INFO - 2018-08-22 20:12:44 --> Database Driver Class Initialized
INFO - 2018-08-22 20:12:44 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:12:44 --> Database Driver Class Initialized
INFO - 2018-08-22 20:12:44 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:12:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 20:12:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 20:12:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 20:12:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 20:12:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 20:12:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 20:12:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 20:12:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/bank_accounts.php
INFO - 2018-08-22 20:12:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 20:12:44 --> Final output sent to browser
DEBUG - 2018-08-22 20:12:44 --> Total execution time: 0.0483
INFO - 2018-08-22 20:12:45 --> Config Class Initialized
INFO - 2018-08-22 20:12:45 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:12:45 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:12:45 --> Utf8 Class Initialized
INFO - 2018-08-22 20:12:45 --> URI Class Initialized
INFO - 2018-08-22 20:12:45 --> Router Class Initialized
INFO - 2018-08-22 20:12:45 --> Output Class Initialized
INFO - 2018-08-22 20:12:45 --> Security Class Initialized
DEBUG - 2018-08-22 20:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:12:45 --> CSRF cookie sent
INFO - 2018-08-22 20:12:45 --> Input Class Initialized
INFO - 2018-08-22 20:12:45 --> Language Class Initialized
ERROR - 2018-08-22 20:12:45 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 20:13:29 --> Config Class Initialized
INFO - 2018-08-22 20:13:29 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:13:29 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:13:29 --> Utf8 Class Initialized
INFO - 2018-08-22 20:13:29 --> URI Class Initialized
INFO - 2018-08-22 20:13:29 --> Router Class Initialized
INFO - 2018-08-22 20:13:29 --> Output Class Initialized
INFO - 2018-08-22 20:13:29 --> Security Class Initialized
DEBUG - 2018-08-22 20:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:13:29 --> CSRF cookie sent
INFO - 2018-08-22 20:13:29 --> CSRF token verified
INFO - 2018-08-22 20:13:29 --> Input Class Initialized
INFO - 2018-08-22 20:13:29 --> Language Class Initialized
INFO - 2018-08-22 20:13:29 --> Loader Class Initialized
INFO - 2018-08-22 20:13:29 --> Helper loaded: url_helper
INFO - 2018-08-22 20:13:29 --> Helper loaded: form_helper
INFO - 2018-08-22 20:13:29 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:13:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:13:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:13:29 --> User Agent Class Initialized
INFO - 2018-08-22 20:13:29 --> Controller Class Initialized
INFO - 2018-08-22 20:13:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:13:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:13:29 --> Pixel_Model class loaded
INFO - 2018-08-22 20:13:29 --> Database Driver Class Initialized
INFO - 2018-08-22 20:13:29 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:13:29 --> Form Validation Class Initialized
INFO - 2018-08-22 20:13:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 20:13:29 --> Database Driver Class Initialized
INFO - 2018-08-22 20:13:29 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:13:29 --> Config Class Initialized
INFO - 2018-08-22 20:13:29 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:13:29 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:13:29 --> Utf8 Class Initialized
INFO - 2018-08-22 20:13:29 --> URI Class Initialized
INFO - 2018-08-22 20:13:29 --> Router Class Initialized
INFO - 2018-08-22 20:13:29 --> Output Class Initialized
INFO - 2018-08-22 20:13:29 --> Security Class Initialized
DEBUG - 2018-08-22 20:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:13:29 --> CSRF cookie sent
INFO - 2018-08-22 20:13:29 --> Input Class Initialized
INFO - 2018-08-22 20:13:29 --> Language Class Initialized
INFO - 2018-08-22 20:13:29 --> Loader Class Initialized
INFO - 2018-08-22 20:13:29 --> Helper loaded: url_helper
INFO - 2018-08-22 20:13:29 --> Helper loaded: form_helper
INFO - 2018-08-22 20:13:29 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:13:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:13:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:13:29 --> User Agent Class Initialized
INFO - 2018-08-22 20:13:29 --> Controller Class Initialized
INFO - 2018-08-22 20:13:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:13:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:13:29 --> Pixel_Model class loaded
INFO - 2018-08-22 20:13:29 --> Database Driver Class Initialized
INFO - 2018-08-22 20:13:29 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:13:29 --> Database Driver Class Initialized
INFO - 2018-08-22 20:13:29 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:13:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 20:13:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 20:13:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 20:13:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 20:13:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 20:13:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 20:13:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 20:13:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/crypto_currencies.php
INFO - 2018-08-22 20:13:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 20:13:29 --> Final output sent to browser
DEBUG - 2018-08-22 20:13:29 --> Total execution time: 0.0407
INFO - 2018-08-22 20:13:30 --> Config Class Initialized
INFO - 2018-08-22 20:13:30 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:13:30 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:13:30 --> Utf8 Class Initialized
INFO - 2018-08-22 20:13:30 --> URI Class Initialized
INFO - 2018-08-22 20:13:30 --> Router Class Initialized
INFO - 2018-08-22 20:13:30 --> Output Class Initialized
INFO - 2018-08-22 20:13:30 --> Security Class Initialized
DEBUG - 2018-08-22 20:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:13:30 --> CSRF cookie sent
INFO - 2018-08-22 20:13:30 --> Input Class Initialized
INFO - 2018-08-22 20:13:30 --> Language Class Initialized
ERROR - 2018-08-22 20:13:30 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 20:14:00 --> Config Class Initialized
INFO - 2018-08-22 20:14:00 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:14:00 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:14:00 --> Utf8 Class Initialized
INFO - 2018-08-22 20:14:00 --> URI Class Initialized
INFO - 2018-08-22 20:14:00 --> Router Class Initialized
INFO - 2018-08-22 20:14:00 --> Output Class Initialized
INFO - 2018-08-22 20:14:00 --> Security Class Initialized
DEBUG - 2018-08-22 20:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:14:00 --> CSRF cookie sent
INFO - 2018-08-22 20:14:00 --> CSRF token verified
INFO - 2018-08-22 20:14:00 --> Input Class Initialized
INFO - 2018-08-22 20:14:00 --> Language Class Initialized
INFO - 2018-08-22 20:14:00 --> Loader Class Initialized
INFO - 2018-08-22 20:14:00 --> Helper loaded: url_helper
INFO - 2018-08-22 20:14:00 --> Helper loaded: form_helper
INFO - 2018-08-22 20:14:00 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:14:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:14:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:14:00 --> User Agent Class Initialized
INFO - 2018-08-22 20:14:00 --> Controller Class Initialized
INFO - 2018-08-22 20:14:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:14:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:14:00 --> Pixel_Model class loaded
INFO - 2018-08-22 20:14:00 --> Database Driver Class Initialized
INFO - 2018-08-22 20:14:00 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:14:00 --> Form Validation Class Initialized
INFO - 2018-08-22 20:14:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 20:14:00 --> Database Driver Class Initialized
INFO - 2018-08-22 20:14:00 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:14:00 --> Config Class Initialized
INFO - 2018-08-22 20:14:00 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:14:00 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:14:00 --> Utf8 Class Initialized
INFO - 2018-08-22 20:14:00 --> URI Class Initialized
INFO - 2018-08-22 20:14:00 --> Router Class Initialized
INFO - 2018-08-22 20:14:00 --> Output Class Initialized
INFO - 2018-08-22 20:14:00 --> Security Class Initialized
DEBUG - 2018-08-22 20:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:14:00 --> CSRF cookie sent
INFO - 2018-08-22 20:14:00 --> Input Class Initialized
INFO - 2018-08-22 20:14:00 --> Language Class Initialized
INFO - 2018-08-22 20:14:00 --> Loader Class Initialized
INFO - 2018-08-22 20:14:00 --> Helper loaded: url_helper
INFO - 2018-08-22 20:14:00 --> Helper loaded: form_helper
INFO - 2018-08-22 20:14:00 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:14:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:14:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:14:00 --> User Agent Class Initialized
INFO - 2018-08-22 20:14:00 --> Controller Class Initialized
INFO - 2018-08-22 20:14:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:14:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:14:00 --> Pixel_Model class loaded
INFO - 2018-08-22 20:14:00 --> Database Driver Class Initialized
INFO - 2018-08-22 20:14:00 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:14:00 --> Database Driver Class Initialized
INFO - 2018-08-22 20:14:00 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:14:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 20:14:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 20:14:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 20:14:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 20:14:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 20:14:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 20:14:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 20:14:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/money_owed_you.php
INFO - 2018-08-22 20:14:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 20:14:00 --> Final output sent to browser
DEBUG - 2018-08-22 20:14:00 --> Total execution time: 0.0472
INFO - 2018-08-22 20:14:01 --> Config Class Initialized
INFO - 2018-08-22 20:14:01 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:14:01 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:14:01 --> Utf8 Class Initialized
INFO - 2018-08-22 20:14:01 --> URI Class Initialized
INFO - 2018-08-22 20:14:01 --> Router Class Initialized
INFO - 2018-08-22 20:14:01 --> Output Class Initialized
INFO - 2018-08-22 20:14:01 --> Security Class Initialized
DEBUG - 2018-08-22 20:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:14:01 --> CSRF cookie sent
INFO - 2018-08-22 20:14:01 --> Input Class Initialized
INFO - 2018-08-22 20:14:01 --> Language Class Initialized
ERROR - 2018-08-22 20:14:01 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 20:14:33 --> Config Class Initialized
INFO - 2018-08-22 20:14:33 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:14:33 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:14:33 --> Utf8 Class Initialized
INFO - 2018-08-22 20:14:33 --> URI Class Initialized
INFO - 2018-08-22 20:14:33 --> Router Class Initialized
INFO - 2018-08-22 20:14:33 --> Output Class Initialized
INFO - 2018-08-22 20:14:33 --> Security Class Initialized
DEBUG - 2018-08-22 20:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:14:33 --> CSRF cookie sent
INFO - 2018-08-22 20:14:33 --> CSRF token verified
INFO - 2018-08-22 20:14:33 --> Input Class Initialized
INFO - 2018-08-22 20:14:33 --> Language Class Initialized
INFO - 2018-08-22 20:14:33 --> Loader Class Initialized
INFO - 2018-08-22 20:14:33 --> Helper loaded: url_helper
INFO - 2018-08-22 20:14:33 --> Helper loaded: form_helper
INFO - 2018-08-22 20:14:33 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:14:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:14:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:14:33 --> User Agent Class Initialized
INFO - 2018-08-22 20:14:33 --> Controller Class Initialized
INFO - 2018-08-22 20:14:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:14:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:14:33 --> Pixel_Model class loaded
INFO - 2018-08-22 20:14:33 --> Database Driver Class Initialized
INFO - 2018-08-22 20:14:33 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:14:33 --> Form Validation Class Initialized
INFO - 2018-08-22 20:14:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 20:14:33 --> Database Driver Class Initialized
INFO - 2018-08-22 20:14:33 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:14:33 --> Config Class Initialized
INFO - 2018-08-22 20:14:33 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:14:33 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:14:33 --> Utf8 Class Initialized
INFO - 2018-08-22 20:14:33 --> URI Class Initialized
INFO - 2018-08-22 20:14:33 --> Router Class Initialized
INFO - 2018-08-22 20:14:33 --> Output Class Initialized
INFO - 2018-08-22 20:14:33 --> Security Class Initialized
DEBUG - 2018-08-22 20:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:14:33 --> CSRF cookie sent
INFO - 2018-08-22 20:14:33 --> Input Class Initialized
INFO - 2018-08-22 20:14:33 --> Language Class Initialized
INFO - 2018-08-22 20:14:33 --> Loader Class Initialized
INFO - 2018-08-22 20:14:33 --> Helper loaded: url_helper
INFO - 2018-08-22 20:14:33 --> Helper loaded: form_helper
INFO - 2018-08-22 20:14:33 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:14:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:14:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:14:33 --> User Agent Class Initialized
INFO - 2018-08-22 20:14:33 --> Controller Class Initialized
INFO - 2018-08-22 20:14:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:14:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:14:33 --> Pixel_Model class loaded
INFO - 2018-08-22 20:14:33 --> Database Driver Class Initialized
INFO - 2018-08-22 20:14:33 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:14:33 --> Database Driver Class Initialized
INFO - 2018-08-22 20:14:33 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:14:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 20:14:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 20:14:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 20:14:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 20:14:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 20:14:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 20:14:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 20:14:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/investments_stocks.php
INFO - 2018-08-22 20:14:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 20:14:33 --> Final output sent to browser
DEBUG - 2018-08-22 20:14:33 --> Total execution time: 0.0564
INFO - 2018-08-22 20:14:33 --> Config Class Initialized
INFO - 2018-08-22 20:14:33 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:14:33 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:14:33 --> Utf8 Class Initialized
INFO - 2018-08-22 20:14:33 --> URI Class Initialized
INFO - 2018-08-22 20:14:33 --> Router Class Initialized
INFO - 2018-08-22 20:14:33 --> Output Class Initialized
INFO - 2018-08-22 20:14:33 --> Security Class Initialized
DEBUG - 2018-08-22 20:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:14:33 --> CSRF cookie sent
INFO - 2018-08-22 20:14:33 --> Input Class Initialized
INFO - 2018-08-22 20:14:33 --> Language Class Initialized
ERROR - 2018-08-22 20:14:33 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 20:15:05 --> Config Class Initialized
INFO - 2018-08-22 20:15:05 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:15:05 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:15:05 --> Utf8 Class Initialized
INFO - 2018-08-22 20:15:05 --> URI Class Initialized
INFO - 2018-08-22 20:15:05 --> Router Class Initialized
INFO - 2018-08-22 20:15:05 --> Output Class Initialized
INFO - 2018-08-22 20:15:05 --> Security Class Initialized
DEBUG - 2018-08-22 20:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:15:05 --> CSRF cookie sent
INFO - 2018-08-22 20:15:05 --> CSRF token verified
INFO - 2018-08-22 20:15:05 --> Input Class Initialized
INFO - 2018-08-22 20:15:05 --> Language Class Initialized
INFO - 2018-08-22 20:15:05 --> Loader Class Initialized
INFO - 2018-08-22 20:15:05 --> Helper loaded: url_helper
INFO - 2018-08-22 20:15:05 --> Helper loaded: form_helper
INFO - 2018-08-22 20:15:05 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:15:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:15:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:15:05 --> User Agent Class Initialized
INFO - 2018-08-22 20:15:05 --> Controller Class Initialized
INFO - 2018-08-22 20:15:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:15:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:15:05 --> Pixel_Model class loaded
INFO - 2018-08-22 20:15:05 --> Database Driver Class Initialized
INFO - 2018-08-22 20:15:05 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:15:05 --> Form Validation Class Initialized
INFO - 2018-08-22 20:15:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 20:15:05 --> Database Driver Class Initialized
INFO - 2018-08-22 20:15:05 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:15:05 --> Config Class Initialized
INFO - 2018-08-22 20:15:05 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:15:05 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:15:05 --> Utf8 Class Initialized
INFO - 2018-08-22 20:15:05 --> URI Class Initialized
INFO - 2018-08-22 20:15:05 --> Router Class Initialized
INFO - 2018-08-22 20:15:05 --> Output Class Initialized
INFO - 2018-08-22 20:15:05 --> Security Class Initialized
DEBUG - 2018-08-22 20:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:15:05 --> CSRF cookie sent
INFO - 2018-08-22 20:15:05 --> Input Class Initialized
INFO - 2018-08-22 20:15:05 --> Language Class Initialized
INFO - 2018-08-22 20:15:05 --> Loader Class Initialized
INFO - 2018-08-22 20:15:05 --> Helper loaded: url_helper
INFO - 2018-08-22 20:15:05 --> Helper loaded: form_helper
INFO - 2018-08-22 20:15:05 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:15:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:15:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:15:05 --> User Agent Class Initialized
INFO - 2018-08-22 20:15:05 --> Controller Class Initialized
INFO - 2018-08-22 20:15:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:15:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:15:05 --> Pixel_Model class loaded
INFO - 2018-08-22 20:15:05 --> Database Driver Class Initialized
INFO - 2018-08-22 20:15:05 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:15:05 --> Database Driver Class Initialized
INFO - 2018-08-22 20:15:05 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:15:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 20:15:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 20:15:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 20:15:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 20:15:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 20:15:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 20:15:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 20:15:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/business_value_assets.php
INFO - 2018-08-22 20:15:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 20:15:05 --> Final output sent to browser
DEBUG - 2018-08-22 20:15:05 --> Total execution time: 0.0459
INFO - 2018-08-22 20:15:06 --> Config Class Initialized
INFO - 2018-08-22 20:15:06 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:15:06 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:15:06 --> Utf8 Class Initialized
INFO - 2018-08-22 20:15:06 --> URI Class Initialized
INFO - 2018-08-22 20:15:06 --> Router Class Initialized
INFO - 2018-08-22 20:15:06 --> Output Class Initialized
INFO - 2018-08-22 20:15:06 --> Security Class Initialized
DEBUG - 2018-08-22 20:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:15:06 --> CSRF cookie sent
INFO - 2018-08-22 20:15:06 --> Input Class Initialized
INFO - 2018-08-22 20:15:06 --> Language Class Initialized
ERROR - 2018-08-22 20:15:06 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 20:15:50 --> Config Class Initialized
INFO - 2018-08-22 20:15:50 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:15:50 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:15:50 --> Utf8 Class Initialized
INFO - 2018-08-22 20:15:50 --> URI Class Initialized
INFO - 2018-08-22 20:15:50 --> Router Class Initialized
INFO - 2018-08-22 20:15:50 --> Output Class Initialized
INFO - 2018-08-22 20:15:50 --> Security Class Initialized
DEBUG - 2018-08-22 20:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:15:50 --> CSRF cookie sent
INFO - 2018-08-22 20:15:50 --> CSRF token verified
INFO - 2018-08-22 20:15:50 --> Input Class Initialized
INFO - 2018-08-22 20:15:50 --> Language Class Initialized
INFO - 2018-08-22 20:15:50 --> Loader Class Initialized
INFO - 2018-08-22 20:15:50 --> Helper loaded: url_helper
INFO - 2018-08-22 20:15:50 --> Helper loaded: form_helper
INFO - 2018-08-22 20:15:50 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:15:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:15:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:15:50 --> User Agent Class Initialized
INFO - 2018-08-22 20:15:50 --> Controller Class Initialized
INFO - 2018-08-22 20:15:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:15:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:15:50 --> Pixel_Model class loaded
INFO - 2018-08-22 20:15:50 --> Database Driver Class Initialized
INFO - 2018-08-22 20:15:50 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:15:50 --> Form Validation Class Initialized
INFO - 2018-08-22 20:15:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 20:15:50 --> Database Driver Class Initialized
INFO - 2018-08-22 20:15:50 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:15:50 --> Config Class Initialized
INFO - 2018-08-22 20:15:50 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:15:50 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:15:50 --> Utf8 Class Initialized
INFO - 2018-08-22 20:15:50 --> URI Class Initialized
INFO - 2018-08-22 20:15:50 --> Router Class Initialized
INFO - 2018-08-22 20:15:50 --> Output Class Initialized
INFO - 2018-08-22 20:15:50 --> Security Class Initialized
DEBUG - 2018-08-22 20:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:15:50 --> CSRF cookie sent
INFO - 2018-08-22 20:15:50 --> Input Class Initialized
INFO - 2018-08-22 20:15:50 --> Language Class Initialized
INFO - 2018-08-22 20:15:50 --> Loader Class Initialized
INFO - 2018-08-22 20:15:50 --> Helper loaded: url_helper
INFO - 2018-08-22 20:15:50 --> Helper loaded: form_helper
INFO - 2018-08-22 20:15:50 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:15:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:15:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:15:50 --> User Agent Class Initialized
INFO - 2018-08-22 20:15:50 --> Controller Class Initialized
INFO - 2018-08-22 20:15:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:15:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:15:50 --> Pixel_Model class loaded
INFO - 2018-08-22 20:15:50 --> Database Driver Class Initialized
INFO - 2018-08-22 20:15:50 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:15:50 --> Database Driver Class Initialized
INFO - 2018-08-22 20:15:50 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:15:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 20:15:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 20:15:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 20:15:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 20:15:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 20:15:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 20:15:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 20:15:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/disability_insurance.php
INFO - 2018-08-22 20:15:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 20:15:50 --> Final output sent to browser
DEBUG - 2018-08-22 20:15:50 --> Total execution time: 0.0450
INFO - 2018-08-22 20:15:51 --> Config Class Initialized
INFO - 2018-08-22 20:15:51 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:15:51 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:15:51 --> Utf8 Class Initialized
INFO - 2018-08-22 20:15:51 --> URI Class Initialized
INFO - 2018-08-22 20:15:51 --> Router Class Initialized
INFO - 2018-08-22 20:15:51 --> Output Class Initialized
INFO - 2018-08-22 20:15:51 --> Security Class Initialized
DEBUG - 2018-08-22 20:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:15:51 --> CSRF cookie sent
INFO - 2018-08-22 20:15:51 --> Input Class Initialized
INFO - 2018-08-22 20:15:51 --> Language Class Initialized
ERROR - 2018-08-22 20:15:51 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 20:16:22 --> Config Class Initialized
INFO - 2018-08-22 20:16:22 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:16:22 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:16:22 --> Utf8 Class Initialized
INFO - 2018-08-22 20:16:22 --> URI Class Initialized
INFO - 2018-08-22 20:16:22 --> Router Class Initialized
INFO - 2018-08-22 20:16:22 --> Output Class Initialized
INFO - 2018-08-22 20:16:22 --> Security Class Initialized
DEBUG - 2018-08-22 20:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:16:22 --> CSRF cookie sent
INFO - 2018-08-22 20:16:22 --> CSRF token verified
INFO - 2018-08-22 20:16:22 --> Input Class Initialized
INFO - 2018-08-22 20:16:22 --> Language Class Initialized
INFO - 2018-08-22 20:16:22 --> Loader Class Initialized
INFO - 2018-08-22 20:16:22 --> Helper loaded: url_helper
INFO - 2018-08-22 20:16:22 --> Helper loaded: form_helper
INFO - 2018-08-22 20:16:22 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:16:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:16:22 --> User Agent Class Initialized
INFO - 2018-08-22 20:16:22 --> Controller Class Initialized
INFO - 2018-08-22 20:16:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:16:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:16:22 --> Pixel_Model class loaded
INFO - 2018-08-22 20:16:22 --> Database Driver Class Initialized
INFO - 2018-08-22 20:16:22 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:16:22 --> Form Validation Class Initialized
INFO - 2018-08-22 20:16:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 20:16:22 --> Database Driver Class Initialized
INFO - 2018-08-22 20:16:22 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:16:23 --> Config Class Initialized
INFO - 2018-08-22 20:16:23 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:16:23 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:16:23 --> Utf8 Class Initialized
INFO - 2018-08-22 20:16:23 --> URI Class Initialized
INFO - 2018-08-22 20:16:23 --> Router Class Initialized
INFO - 2018-08-22 20:16:23 --> Output Class Initialized
INFO - 2018-08-22 20:16:23 --> Security Class Initialized
DEBUG - 2018-08-22 20:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:16:23 --> CSRF cookie sent
INFO - 2018-08-22 20:16:23 --> Input Class Initialized
INFO - 2018-08-22 20:16:23 --> Language Class Initialized
INFO - 2018-08-22 20:16:23 --> Loader Class Initialized
INFO - 2018-08-22 20:16:23 --> Helper loaded: url_helper
INFO - 2018-08-22 20:16:23 --> Helper loaded: form_helper
INFO - 2018-08-22 20:16:23 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:16:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:16:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:16:23 --> User Agent Class Initialized
INFO - 2018-08-22 20:16:23 --> Controller Class Initialized
INFO - 2018-08-22 20:16:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:16:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:16:23 --> Pixel_Model class loaded
INFO - 2018-08-22 20:16:23 --> Database Driver Class Initialized
INFO - 2018-08-22 20:16:23 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:16:23 --> Database Driver Class Initialized
INFO - 2018-08-22 20:16:23 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:16:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 20:16:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 20:16:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 20:16:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 20:16:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 20:16:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 20:16:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 20:16:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/personal_loans.php
INFO - 2018-08-22 20:16:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 20:16:23 --> Final output sent to browser
DEBUG - 2018-08-22 20:16:23 --> Total execution time: 0.0442
INFO - 2018-08-22 20:16:24 --> Config Class Initialized
INFO - 2018-08-22 20:16:24 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:16:24 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:16:24 --> Utf8 Class Initialized
INFO - 2018-08-22 20:16:24 --> URI Class Initialized
INFO - 2018-08-22 20:16:24 --> Router Class Initialized
INFO - 2018-08-22 20:16:24 --> Output Class Initialized
INFO - 2018-08-22 20:16:24 --> Security Class Initialized
DEBUG - 2018-08-22 20:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:16:24 --> CSRF cookie sent
INFO - 2018-08-22 20:16:24 --> Input Class Initialized
INFO - 2018-08-22 20:16:24 --> Language Class Initialized
ERROR - 2018-08-22 20:16:24 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 20:16:56 --> Config Class Initialized
INFO - 2018-08-22 20:16:56 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:16:56 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:16:56 --> Utf8 Class Initialized
INFO - 2018-08-22 20:16:56 --> URI Class Initialized
INFO - 2018-08-22 20:16:56 --> Router Class Initialized
INFO - 2018-08-22 20:16:56 --> Output Class Initialized
INFO - 2018-08-22 20:16:56 --> Security Class Initialized
DEBUG - 2018-08-22 20:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:16:56 --> CSRF cookie sent
INFO - 2018-08-22 20:16:56 --> CSRF token verified
INFO - 2018-08-22 20:16:56 --> Input Class Initialized
INFO - 2018-08-22 20:16:56 --> Language Class Initialized
INFO - 2018-08-22 20:16:56 --> Loader Class Initialized
INFO - 2018-08-22 20:16:56 --> Helper loaded: url_helper
INFO - 2018-08-22 20:16:56 --> Helper loaded: form_helper
INFO - 2018-08-22 20:16:56 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:16:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:16:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:16:56 --> User Agent Class Initialized
INFO - 2018-08-22 20:16:56 --> Controller Class Initialized
INFO - 2018-08-22 20:16:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:16:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:16:56 --> Pixel_Model class loaded
INFO - 2018-08-22 20:16:56 --> Database Driver Class Initialized
INFO - 2018-08-22 20:16:56 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:16:56 --> Form Validation Class Initialized
INFO - 2018-08-22 20:16:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 20:16:56 --> Database Driver Class Initialized
INFO - 2018-08-22 20:16:56 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:16:56 --> Config Class Initialized
INFO - 2018-08-22 20:16:56 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:16:56 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:16:56 --> Utf8 Class Initialized
INFO - 2018-08-22 20:16:56 --> URI Class Initialized
INFO - 2018-08-22 20:16:56 --> Router Class Initialized
INFO - 2018-08-22 20:16:56 --> Output Class Initialized
INFO - 2018-08-22 20:16:56 --> Security Class Initialized
DEBUG - 2018-08-22 20:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:16:56 --> CSRF cookie sent
INFO - 2018-08-22 20:16:56 --> Input Class Initialized
INFO - 2018-08-22 20:16:56 --> Language Class Initialized
INFO - 2018-08-22 20:16:56 --> Loader Class Initialized
INFO - 2018-08-22 20:16:56 --> Helper loaded: url_helper
INFO - 2018-08-22 20:16:56 --> Helper loaded: form_helper
INFO - 2018-08-22 20:16:56 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:16:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:16:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:16:56 --> User Agent Class Initialized
INFO - 2018-08-22 20:16:56 --> Controller Class Initialized
INFO - 2018-08-22 20:16:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:16:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:16:56 --> Pixel_Model class loaded
INFO - 2018-08-22 20:16:56 --> Database Driver Class Initialized
INFO - 2018-08-22 20:16:56 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:16:56 --> Database Driver Class Initialized
INFO - 2018-08-22 20:16:56 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:16:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 20:16:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 20:16:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 20:16:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 20:16:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 20:16:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 20:16:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 20:16:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/personal_credit_line.php
INFO - 2018-08-22 20:16:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 20:16:56 --> Final output sent to browser
DEBUG - 2018-08-22 20:16:56 --> Total execution time: 0.0443
INFO - 2018-08-22 20:16:58 --> Config Class Initialized
INFO - 2018-08-22 20:16:58 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:16:58 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:16:58 --> Utf8 Class Initialized
INFO - 2018-08-22 20:16:58 --> URI Class Initialized
INFO - 2018-08-22 20:16:58 --> Router Class Initialized
INFO - 2018-08-22 20:16:58 --> Output Class Initialized
INFO - 2018-08-22 20:16:58 --> Security Class Initialized
DEBUG - 2018-08-22 20:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:16:58 --> CSRF cookie sent
INFO - 2018-08-22 20:16:58 --> Input Class Initialized
INFO - 2018-08-22 20:16:58 --> Language Class Initialized
ERROR - 2018-08-22 20:16:58 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 20:17:33 --> Config Class Initialized
INFO - 2018-08-22 20:17:33 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:17:33 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:17:33 --> Utf8 Class Initialized
INFO - 2018-08-22 20:17:33 --> URI Class Initialized
INFO - 2018-08-22 20:17:33 --> Router Class Initialized
INFO - 2018-08-22 20:17:33 --> Output Class Initialized
INFO - 2018-08-22 20:17:33 --> Security Class Initialized
DEBUG - 2018-08-22 20:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:17:33 --> CSRF cookie sent
INFO - 2018-08-22 20:17:33 --> CSRF token verified
INFO - 2018-08-22 20:17:33 --> Input Class Initialized
INFO - 2018-08-22 20:17:33 --> Language Class Initialized
INFO - 2018-08-22 20:17:33 --> Loader Class Initialized
INFO - 2018-08-22 20:17:33 --> Helper loaded: url_helper
INFO - 2018-08-22 20:17:33 --> Helper loaded: form_helper
INFO - 2018-08-22 20:17:33 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:17:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:17:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:17:33 --> User Agent Class Initialized
INFO - 2018-08-22 20:17:33 --> Controller Class Initialized
INFO - 2018-08-22 20:17:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:17:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:17:33 --> Pixel_Model class loaded
INFO - 2018-08-22 20:17:33 --> Database Driver Class Initialized
INFO - 2018-08-22 20:17:33 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:17:33 --> Form Validation Class Initialized
INFO - 2018-08-22 20:17:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 20:17:33 --> Database Driver Class Initialized
INFO - 2018-08-22 20:17:33 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:17:33 --> Config Class Initialized
INFO - 2018-08-22 20:17:33 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:17:33 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:17:33 --> Utf8 Class Initialized
INFO - 2018-08-22 20:17:33 --> URI Class Initialized
INFO - 2018-08-22 20:17:33 --> Router Class Initialized
INFO - 2018-08-22 20:17:33 --> Output Class Initialized
INFO - 2018-08-22 20:17:33 --> Security Class Initialized
DEBUG - 2018-08-22 20:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:17:33 --> CSRF cookie sent
INFO - 2018-08-22 20:17:33 --> Input Class Initialized
INFO - 2018-08-22 20:17:33 --> Language Class Initialized
INFO - 2018-08-22 20:17:33 --> Loader Class Initialized
INFO - 2018-08-22 20:17:33 --> Helper loaded: url_helper
INFO - 2018-08-22 20:17:33 --> Helper loaded: form_helper
INFO - 2018-08-22 20:17:33 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:17:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:17:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:17:33 --> User Agent Class Initialized
INFO - 2018-08-22 20:17:33 --> Controller Class Initialized
INFO - 2018-08-22 20:17:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:17:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:17:33 --> Pixel_Model class loaded
INFO - 2018-08-22 20:17:33 --> Database Driver Class Initialized
INFO - 2018-08-22 20:17:33 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:17:33 --> Database Driver Class Initialized
INFO - 2018-08-22 20:17:33 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:17:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 20:17:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 20:17:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 20:17:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 20:17:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 20:17:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 20:17:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 20:17:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/credit_cards.php
INFO - 2018-08-22 20:17:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 20:17:33 --> Final output sent to browser
DEBUG - 2018-08-22 20:17:33 --> Total execution time: 0.0446
INFO - 2018-08-22 20:17:33 --> Config Class Initialized
INFO - 2018-08-22 20:17:33 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:17:33 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:17:33 --> Utf8 Class Initialized
INFO - 2018-08-22 20:17:33 --> URI Class Initialized
INFO - 2018-08-22 20:17:33 --> Router Class Initialized
INFO - 2018-08-22 20:17:33 --> Output Class Initialized
INFO - 2018-08-22 20:17:33 --> Security Class Initialized
DEBUG - 2018-08-22 20:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:17:33 --> CSRF cookie sent
INFO - 2018-08-22 20:17:33 --> Input Class Initialized
INFO - 2018-08-22 20:17:33 --> Language Class Initialized
ERROR - 2018-08-22 20:17:33 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 20:18:13 --> Config Class Initialized
INFO - 2018-08-22 20:18:13 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:18:13 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:18:13 --> Utf8 Class Initialized
INFO - 2018-08-22 20:18:13 --> URI Class Initialized
INFO - 2018-08-22 20:18:13 --> Router Class Initialized
INFO - 2018-08-22 20:18:13 --> Output Class Initialized
INFO - 2018-08-22 20:18:13 --> Security Class Initialized
DEBUG - 2018-08-22 20:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:18:13 --> CSRF cookie sent
INFO - 2018-08-22 20:18:13 --> CSRF token verified
INFO - 2018-08-22 20:18:13 --> Input Class Initialized
INFO - 2018-08-22 20:18:13 --> Language Class Initialized
INFO - 2018-08-22 20:18:13 --> Loader Class Initialized
INFO - 2018-08-22 20:18:13 --> Helper loaded: url_helper
INFO - 2018-08-22 20:18:13 --> Helper loaded: form_helper
INFO - 2018-08-22 20:18:13 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:18:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:18:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:18:13 --> User Agent Class Initialized
INFO - 2018-08-22 20:18:13 --> Controller Class Initialized
INFO - 2018-08-22 20:18:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:18:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:18:13 --> Pixel_Model class loaded
INFO - 2018-08-22 20:18:13 --> Database Driver Class Initialized
INFO - 2018-08-22 20:18:13 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:18:13 --> Form Validation Class Initialized
INFO - 2018-08-22 20:18:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 20:18:13 --> Database Driver Class Initialized
INFO - 2018-08-22 20:18:13 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:18:13 --> Config Class Initialized
INFO - 2018-08-22 20:18:13 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:18:13 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:18:13 --> Utf8 Class Initialized
INFO - 2018-08-22 20:18:13 --> URI Class Initialized
INFO - 2018-08-22 20:18:13 --> Router Class Initialized
INFO - 2018-08-22 20:18:13 --> Output Class Initialized
INFO - 2018-08-22 20:18:13 --> Security Class Initialized
DEBUG - 2018-08-22 20:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:18:13 --> CSRF cookie sent
INFO - 2018-08-22 20:18:13 --> Input Class Initialized
INFO - 2018-08-22 20:18:13 --> Language Class Initialized
INFO - 2018-08-22 20:18:13 --> Loader Class Initialized
INFO - 2018-08-22 20:18:13 --> Helper loaded: url_helper
INFO - 2018-08-22 20:18:13 --> Helper loaded: form_helper
INFO - 2018-08-22 20:18:13 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:18:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:18:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:18:13 --> User Agent Class Initialized
INFO - 2018-08-22 20:18:13 --> Controller Class Initialized
INFO - 2018-08-22 20:18:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:18:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:18:13 --> Pixel_Model class loaded
INFO - 2018-08-22 20:18:13 --> Database Driver Class Initialized
INFO - 2018-08-22 20:18:13 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:18:13 --> Database Driver Class Initialized
INFO - 2018-08-22 20:18:13 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:18:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 20:18:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 20:18:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 20:18:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 20:18:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 20:18:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 20:18:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 20:18:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/other_debt.php
INFO - 2018-08-22 20:18:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 20:18:13 --> Final output sent to browser
DEBUG - 2018-08-22 20:18:13 --> Total execution time: 0.0461
INFO - 2018-08-22 20:18:13 --> Config Class Initialized
INFO - 2018-08-22 20:18:13 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:18:13 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:18:13 --> Utf8 Class Initialized
INFO - 2018-08-22 20:18:13 --> URI Class Initialized
INFO - 2018-08-22 20:18:13 --> Router Class Initialized
INFO - 2018-08-22 20:18:13 --> Output Class Initialized
INFO - 2018-08-22 20:18:13 --> Security Class Initialized
DEBUG - 2018-08-22 20:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:18:13 --> CSRF cookie sent
INFO - 2018-08-22 20:18:13 --> Input Class Initialized
INFO - 2018-08-22 20:18:13 --> Language Class Initialized
ERROR - 2018-08-22 20:18:13 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 20:18:43 --> Config Class Initialized
INFO - 2018-08-22 20:18:43 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:18:43 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:18:43 --> Utf8 Class Initialized
INFO - 2018-08-22 20:18:43 --> URI Class Initialized
INFO - 2018-08-22 20:18:43 --> Router Class Initialized
INFO - 2018-08-22 20:18:43 --> Output Class Initialized
INFO - 2018-08-22 20:18:43 --> Security Class Initialized
DEBUG - 2018-08-22 20:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:18:43 --> CSRF cookie sent
INFO - 2018-08-22 20:18:43 --> CSRF token verified
INFO - 2018-08-22 20:18:43 --> Input Class Initialized
INFO - 2018-08-22 20:18:43 --> Language Class Initialized
INFO - 2018-08-22 20:18:43 --> Loader Class Initialized
INFO - 2018-08-22 20:18:43 --> Helper loaded: url_helper
INFO - 2018-08-22 20:18:43 --> Helper loaded: form_helper
INFO - 2018-08-22 20:18:43 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:18:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:18:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:18:43 --> User Agent Class Initialized
INFO - 2018-08-22 20:18:43 --> Controller Class Initialized
INFO - 2018-08-22 20:18:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:18:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:18:43 --> Pixel_Model class loaded
INFO - 2018-08-22 20:18:43 --> Database Driver Class Initialized
INFO - 2018-08-22 20:18:43 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:18:43 --> Form Validation Class Initialized
INFO - 2018-08-22 20:18:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 20:18:43 --> Database Driver Class Initialized
INFO - 2018-08-22 20:18:43 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:18:43 --> Config Class Initialized
INFO - 2018-08-22 20:18:43 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:18:43 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:18:43 --> Utf8 Class Initialized
INFO - 2018-08-22 20:18:43 --> URI Class Initialized
INFO - 2018-08-22 20:18:43 --> Router Class Initialized
INFO - 2018-08-22 20:18:43 --> Output Class Initialized
INFO - 2018-08-22 20:18:43 --> Security Class Initialized
DEBUG - 2018-08-22 20:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:18:43 --> CSRF cookie sent
INFO - 2018-08-22 20:18:43 --> Input Class Initialized
INFO - 2018-08-22 20:18:43 --> Language Class Initialized
INFO - 2018-08-22 20:18:43 --> Loader Class Initialized
INFO - 2018-08-22 20:18:43 --> Helper loaded: url_helper
INFO - 2018-08-22 20:18:43 --> Helper loaded: form_helper
INFO - 2018-08-22 20:18:43 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:18:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:18:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:18:43 --> User Agent Class Initialized
INFO - 2018-08-22 20:18:43 --> Controller Class Initialized
INFO - 2018-08-22 20:18:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:18:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:18:43 --> Pixel_Model class loaded
INFO - 2018-08-22 20:18:43 --> Database Driver Class Initialized
INFO - 2018-08-22 20:18:43 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:18:43 --> Database Driver Class Initialized
INFO - 2018-08-22 20:18:43 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:18:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 20:18:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 20:18:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 20:18:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 20:18:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 20:18:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 20:18:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 20:18:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/business_credit_line.php
INFO - 2018-08-22 20:18:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 20:18:43 --> Final output sent to browser
DEBUG - 2018-08-22 20:18:43 --> Total execution time: 0.0675
INFO - 2018-08-22 20:18:44 --> Config Class Initialized
INFO - 2018-08-22 20:18:44 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:18:44 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:18:44 --> Utf8 Class Initialized
INFO - 2018-08-22 20:18:44 --> URI Class Initialized
INFO - 2018-08-22 20:18:44 --> Router Class Initialized
INFO - 2018-08-22 20:18:44 --> Output Class Initialized
INFO - 2018-08-22 20:18:44 --> Security Class Initialized
DEBUG - 2018-08-22 20:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:18:44 --> CSRF cookie sent
INFO - 2018-08-22 20:18:44 --> Input Class Initialized
INFO - 2018-08-22 20:18:44 --> Language Class Initialized
ERROR - 2018-08-22 20:18:44 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 20:19:18 --> Config Class Initialized
INFO - 2018-08-22 20:19:18 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:19:18 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:19:18 --> Utf8 Class Initialized
INFO - 2018-08-22 20:19:18 --> URI Class Initialized
INFO - 2018-08-22 20:19:18 --> Router Class Initialized
INFO - 2018-08-22 20:19:18 --> Output Class Initialized
INFO - 2018-08-22 20:19:18 --> Security Class Initialized
DEBUG - 2018-08-22 20:19:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:19:18 --> CSRF cookie sent
INFO - 2018-08-22 20:19:18 --> CSRF token verified
INFO - 2018-08-22 20:19:18 --> Input Class Initialized
INFO - 2018-08-22 20:19:18 --> Language Class Initialized
INFO - 2018-08-22 20:19:18 --> Loader Class Initialized
INFO - 2018-08-22 20:19:18 --> Helper loaded: url_helper
INFO - 2018-08-22 20:19:18 --> Helper loaded: form_helper
INFO - 2018-08-22 20:19:18 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:19:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:19:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:19:18 --> User Agent Class Initialized
INFO - 2018-08-22 20:19:18 --> Controller Class Initialized
INFO - 2018-08-22 20:19:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:19:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:19:18 --> Pixel_Model class loaded
INFO - 2018-08-22 20:19:18 --> Database Driver Class Initialized
INFO - 2018-08-22 20:19:18 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:19:18 --> Form Validation Class Initialized
INFO - 2018-08-22 20:19:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 20:19:18 --> Database Driver Class Initialized
INFO - 2018-08-22 20:19:18 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:19:18 --> Config Class Initialized
INFO - 2018-08-22 20:19:18 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:19:18 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:19:18 --> Utf8 Class Initialized
INFO - 2018-08-22 20:19:18 --> URI Class Initialized
INFO - 2018-08-22 20:19:18 --> Router Class Initialized
INFO - 2018-08-22 20:19:18 --> Output Class Initialized
INFO - 2018-08-22 20:19:18 --> Security Class Initialized
DEBUG - 2018-08-22 20:19:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:19:18 --> CSRF cookie sent
INFO - 2018-08-22 20:19:18 --> Input Class Initialized
INFO - 2018-08-22 20:19:18 --> Language Class Initialized
INFO - 2018-08-22 20:19:18 --> Loader Class Initialized
INFO - 2018-08-22 20:19:18 --> Helper loaded: url_helper
INFO - 2018-08-22 20:19:18 --> Helper loaded: form_helper
INFO - 2018-08-22 20:19:18 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:19:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:19:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:19:18 --> User Agent Class Initialized
INFO - 2018-08-22 20:19:18 --> Controller Class Initialized
INFO - 2018-08-22 20:19:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:19:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:19:18 --> Pixel_Model class loaded
INFO - 2018-08-22 20:19:18 --> Database Driver Class Initialized
INFO - 2018-08-22 20:19:18 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:19:18 --> Database Driver Class Initialized
INFO - 2018-08-22 20:19:18 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:19:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 20:19:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 20:19:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 20:19:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 20:19:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 20:19:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 20:19:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 20:19:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/influencer_info.php
INFO - 2018-08-22 20:19:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 20:19:18 --> Final output sent to browser
DEBUG - 2018-08-22 20:19:18 --> Total execution time: 0.0485
INFO - 2018-08-22 20:19:18 --> Config Class Initialized
INFO - 2018-08-22 20:19:18 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:19:18 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:19:18 --> Utf8 Class Initialized
INFO - 2018-08-22 20:19:18 --> URI Class Initialized
INFO - 2018-08-22 20:19:18 --> Router Class Initialized
INFO - 2018-08-22 20:19:18 --> Output Class Initialized
INFO - 2018-08-22 20:19:18 --> Security Class Initialized
DEBUG - 2018-08-22 20:19:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:19:18 --> CSRF cookie sent
INFO - 2018-08-22 20:19:18 --> Input Class Initialized
INFO - 2018-08-22 20:19:18 --> Language Class Initialized
ERROR - 2018-08-22 20:19:18 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 20:19:35 --> Config Class Initialized
INFO - 2018-08-22 20:19:35 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:19:35 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:19:35 --> Utf8 Class Initialized
INFO - 2018-08-22 20:19:35 --> URI Class Initialized
INFO - 2018-08-22 20:19:35 --> Router Class Initialized
INFO - 2018-08-22 20:19:35 --> Output Class Initialized
INFO - 2018-08-22 20:19:35 --> Security Class Initialized
DEBUG - 2018-08-22 20:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:19:35 --> CSRF cookie sent
INFO - 2018-08-22 20:19:35 --> CSRF token verified
INFO - 2018-08-22 20:19:35 --> Input Class Initialized
INFO - 2018-08-22 20:19:35 --> Language Class Initialized
INFO - 2018-08-22 20:19:35 --> Loader Class Initialized
INFO - 2018-08-22 20:19:35 --> Helper loaded: url_helper
INFO - 2018-08-22 20:19:35 --> Helper loaded: form_helper
INFO - 2018-08-22 20:19:35 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:19:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:19:35 --> User Agent Class Initialized
INFO - 2018-08-22 20:19:35 --> Controller Class Initialized
INFO - 2018-08-22 20:19:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:19:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:19:35 --> Pixel_Model class loaded
INFO - 2018-08-22 20:19:35 --> Database Driver Class Initialized
INFO - 2018-08-22 20:19:35 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:19:35 --> Form Validation Class Initialized
INFO - 2018-08-22 20:19:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 20:19:35 --> Config Class Initialized
INFO - 2018-08-22 20:19:35 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:19:35 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:19:35 --> Utf8 Class Initialized
INFO - 2018-08-22 20:19:35 --> URI Class Initialized
INFO - 2018-08-22 20:19:35 --> Router Class Initialized
INFO - 2018-08-22 20:19:35 --> Output Class Initialized
INFO - 2018-08-22 20:19:35 --> Security Class Initialized
DEBUG - 2018-08-22 20:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:19:35 --> CSRF cookie sent
INFO - 2018-08-22 20:19:35 --> Input Class Initialized
INFO - 2018-08-22 20:19:35 --> Language Class Initialized
INFO - 2018-08-22 20:19:35 --> Loader Class Initialized
INFO - 2018-08-22 20:19:35 --> Helper loaded: url_helper
INFO - 2018-08-22 20:19:35 --> Helper loaded: form_helper
INFO - 2018-08-22 20:19:35 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:19:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:19:35 --> User Agent Class Initialized
INFO - 2018-08-22 20:19:35 --> Controller Class Initialized
INFO - 2018-08-22 20:19:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:19:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:19:35 --> Pixel_Model class loaded
INFO - 2018-08-22 20:19:35 --> Database Driver Class Initialized
INFO - 2018-08-22 20:19:35 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:19:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 20:19:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 20:19:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 20:19:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 20:19:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 20:19:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/finish.php
INFO - 2018-08-22 20:19:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 20:19:35 --> Final output sent to browser
DEBUG - 2018-08-22 20:19:35 --> Total execution time: 0.0391
INFO - 2018-08-22 20:19:36 --> Config Class Initialized
INFO - 2018-08-22 20:19:36 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:19:36 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:19:36 --> Utf8 Class Initialized
INFO - 2018-08-22 20:19:36 --> URI Class Initialized
INFO - 2018-08-22 20:19:36 --> Router Class Initialized
INFO - 2018-08-22 20:19:36 --> Output Class Initialized
INFO - 2018-08-22 20:19:36 --> Security Class Initialized
DEBUG - 2018-08-22 20:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:19:36 --> CSRF cookie sent
INFO - 2018-08-22 20:19:36 --> Input Class Initialized
INFO - 2018-08-22 20:19:36 --> Language Class Initialized
ERROR - 2018-08-22 20:19:36 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 20:19:45 --> Config Class Initialized
INFO - 2018-08-22 20:19:45 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:19:45 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:19:45 --> Utf8 Class Initialized
INFO - 2018-08-22 20:19:45 --> URI Class Initialized
INFO - 2018-08-22 20:19:45 --> Router Class Initialized
INFO - 2018-08-22 20:19:45 --> Output Class Initialized
INFO - 2018-08-22 20:19:45 --> Security Class Initialized
DEBUG - 2018-08-22 20:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:19:45 --> CSRF cookie sent
INFO - 2018-08-22 20:19:45 --> Input Class Initialized
INFO - 2018-08-22 20:19:45 --> Language Class Initialized
INFO - 2018-08-22 20:19:45 --> Loader Class Initialized
INFO - 2018-08-22 20:19:45 --> Helper loaded: url_helper
INFO - 2018-08-22 20:19:45 --> Helper loaded: form_helper
INFO - 2018-08-22 20:19:45 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:19:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:19:45 --> User Agent Class Initialized
INFO - 2018-08-22 20:19:45 --> Controller Class Initialized
INFO - 2018-08-22 20:19:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:19:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:19:45 --> Pixel_Model class loaded
INFO - 2018-08-22 20:19:45 --> Database Driver Class Initialized
INFO - 2018-08-22 20:19:45 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:19:45 --> Database Driver Class Initialized
INFO - 2018-08-22 20:19:45 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:19:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 20:19:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 20:19:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 20:19:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 20:19:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 20:19:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 20:19:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 20:19:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/assets_info.php
INFO - 2018-08-22 20:19:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 20:19:45 --> Final output sent to browser
DEBUG - 2018-08-22 20:19:45 --> Total execution time: 0.0557
INFO - 2018-08-22 20:19:45 --> Config Class Initialized
INFO - 2018-08-22 20:19:45 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:19:45 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:19:45 --> Utf8 Class Initialized
INFO - 2018-08-22 20:19:45 --> URI Class Initialized
INFO - 2018-08-22 20:19:45 --> Router Class Initialized
INFO - 2018-08-22 20:19:45 --> Output Class Initialized
INFO - 2018-08-22 20:19:45 --> Security Class Initialized
DEBUG - 2018-08-22 20:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:19:45 --> CSRF cookie sent
INFO - 2018-08-22 20:19:45 --> Input Class Initialized
INFO - 2018-08-22 20:19:45 --> Language Class Initialized
ERROR - 2018-08-22 20:19:45 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 20:20:39 --> Config Class Initialized
INFO - 2018-08-22 20:20:39 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:20:39 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:20:39 --> Utf8 Class Initialized
INFO - 2018-08-22 20:20:39 --> URI Class Initialized
INFO - 2018-08-22 20:20:39 --> Router Class Initialized
INFO - 2018-08-22 20:20:39 --> Output Class Initialized
INFO - 2018-08-22 20:20:39 --> Security Class Initialized
DEBUG - 2018-08-22 20:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:20:39 --> CSRF cookie sent
INFO - 2018-08-22 20:20:39 --> CSRF token verified
INFO - 2018-08-22 20:20:39 --> Input Class Initialized
INFO - 2018-08-22 20:20:39 --> Language Class Initialized
INFO - 2018-08-22 20:20:39 --> Loader Class Initialized
INFO - 2018-08-22 20:20:39 --> Helper loaded: url_helper
INFO - 2018-08-22 20:20:39 --> Helper loaded: form_helper
INFO - 2018-08-22 20:20:39 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:20:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:20:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:20:39 --> User Agent Class Initialized
INFO - 2018-08-22 20:20:39 --> Controller Class Initialized
INFO - 2018-08-22 20:20:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:20:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:20:39 --> Pixel_Model class loaded
INFO - 2018-08-22 20:20:39 --> Database Driver Class Initialized
INFO - 2018-08-22 20:20:39 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:20:39 --> Form Validation Class Initialized
INFO - 2018-08-22 20:20:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 20:20:39 --> Database Driver Class Initialized
INFO - 2018-08-22 20:20:39 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:20:39 --> Config Class Initialized
INFO - 2018-08-22 20:20:39 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:20:39 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:20:39 --> Utf8 Class Initialized
INFO - 2018-08-22 20:20:39 --> URI Class Initialized
INFO - 2018-08-22 20:20:39 --> Router Class Initialized
INFO - 2018-08-22 20:20:39 --> Output Class Initialized
INFO - 2018-08-22 20:20:39 --> Security Class Initialized
DEBUG - 2018-08-22 20:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:20:39 --> CSRF cookie sent
INFO - 2018-08-22 20:20:39 --> Input Class Initialized
INFO - 2018-08-22 20:20:39 --> Language Class Initialized
INFO - 2018-08-22 20:20:39 --> Loader Class Initialized
INFO - 2018-08-22 20:20:39 --> Helper loaded: url_helper
INFO - 2018-08-22 20:20:39 --> Helper loaded: form_helper
INFO - 2018-08-22 20:20:39 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:20:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:20:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:20:39 --> User Agent Class Initialized
INFO - 2018-08-22 20:20:39 --> Controller Class Initialized
INFO - 2018-08-22 20:20:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:20:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:20:39 --> Pixel_Model class loaded
INFO - 2018-08-22 20:20:39 --> Database Driver Class Initialized
INFO - 2018-08-22 20:20:39 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:20:39 --> Database Driver Class Initialized
INFO - 2018-08-22 20:20:39 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:20:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 20:20:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 20:20:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 20:20:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 20:20:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 20:20:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 20:20:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 20:20:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/assets_details.php
INFO - 2018-08-22 20:20:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 20:20:39 --> Final output sent to browser
DEBUG - 2018-08-22 20:20:39 --> Total execution time: 0.0488
INFO - 2018-08-22 20:20:39 --> Config Class Initialized
INFO - 2018-08-22 20:20:39 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:20:39 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:20:39 --> Utf8 Class Initialized
INFO - 2018-08-22 20:20:39 --> URI Class Initialized
INFO - 2018-08-22 20:20:39 --> Router Class Initialized
INFO - 2018-08-22 20:20:39 --> Output Class Initialized
INFO - 2018-08-22 20:20:39 --> Security Class Initialized
DEBUG - 2018-08-22 20:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:20:39 --> CSRF cookie sent
INFO - 2018-08-22 20:20:39 --> Input Class Initialized
INFO - 2018-08-22 20:20:39 --> Language Class Initialized
ERROR - 2018-08-22 20:20:39 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 20:21:58 --> Config Class Initialized
INFO - 2018-08-22 20:21:58 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:21:58 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:21:58 --> Utf8 Class Initialized
INFO - 2018-08-22 20:21:58 --> URI Class Initialized
DEBUG - 2018-08-22 20:21:58 --> No URI present. Default controller set.
INFO - 2018-08-22 20:21:58 --> Router Class Initialized
INFO - 2018-08-22 20:21:58 --> Output Class Initialized
INFO - 2018-08-22 20:21:58 --> Security Class Initialized
DEBUG - 2018-08-22 20:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:21:58 --> CSRF cookie sent
INFO - 2018-08-22 20:21:58 --> Input Class Initialized
INFO - 2018-08-22 20:21:58 --> Language Class Initialized
INFO - 2018-08-22 20:21:58 --> Loader Class Initialized
INFO - 2018-08-22 20:21:58 --> Helper loaded: url_helper
INFO - 2018-08-22 20:21:58 --> Helper loaded: form_helper
INFO - 2018-08-22 20:21:58 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:21:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:21:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:21:58 --> User Agent Class Initialized
INFO - 2018-08-22 20:21:58 --> Controller Class Initialized
INFO - 2018-08-22 20:21:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:21:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:21:58 --> Pixel_Model class loaded
INFO - 2018-08-22 20:21:58 --> Database Driver Class Initialized
INFO - 2018-08-22 20:21:58 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:21:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 20:21:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 20:21:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-22 20:21:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 20:21:58 --> Final output sent to browser
DEBUG - 2018-08-22 20:21:58 --> Total execution time: 0.0368
INFO - 2018-08-22 20:22:17 --> Config Class Initialized
INFO - 2018-08-22 20:22:17 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:22:17 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:22:17 --> Utf8 Class Initialized
INFO - 2018-08-22 20:22:17 --> URI Class Initialized
INFO - 2018-08-22 20:22:17 --> Router Class Initialized
INFO - 2018-08-22 20:22:17 --> Output Class Initialized
INFO - 2018-08-22 20:22:17 --> Security Class Initialized
DEBUG - 2018-08-22 20:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:22:17 --> CSRF cookie sent
INFO - 2018-08-22 20:22:17 --> CSRF token verified
INFO - 2018-08-22 20:22:17 --> Input Class Initialized
INFO - 2018-08-22 20:22:17 --> Language Class Initialized
INFO - 2018-08-22 20:22:17 --> Loader Class Initialized
INFO - 2018-08-22 20:22:17 --> Helper loaded: url_helper
INFO - 2018-08-22 20:22:17 --> Helper loaded: form_helper
INFO - 2018-08-22 20:22:17 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:22:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:22:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:22:17 --> User Agent Class Initialized
INFO - 2018-08-22 20:22:17 --> Controller Class Initialized
INFO - 2018-08-22 20:22:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:22:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:22:17 --> Pixel_Model class loaded
INFO - 2018-08-22 20:22:17 --> Database Driver Class Initialized
INFO - 2018-08-22 20:22:17 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:22:17 --> Database Driver Class Initialized
INFO - 2018-08-22 20:22:17 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:22:17 --> Config Class Initialized
INFO - 2018-08-22 20:22:17 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:22:17 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:22:17 --> Utf8 Class Initialized
INFO - 2018-08-22 20:22:17 --> URI Class Initialized
INFO - 2018-08-22 20:22:17 --> Router Class Initialized
INFO - 2018-08-22 20:22:17 --> Output Class Initialized
INFO - 2018-08-22 20:22:17 --> Security Class Initialized
DEBUG - 2018-08-22 20:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:22:17 --> CSRF cookie sent
INFO - 2018-08-22 20:22:17 --> Input Class Initialized
INFO - 2018-08-22 20:22:17 --> Language Class Initialized
INFO - 2018-08-22 20:22:17 --> Loader Class Initialized
INFO - 2018-08-22 20:22:17 --> Helper loaded: url_helper
INFO - 2018-08-22 20:22:17 --> Helper loaded: form_helper
INFO - 2018-08-22 20:22:17 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:22:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:22:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:22:17 --> User Agent Class Initialized
INFO - 2018-08-22 20:22:17 --> Controller Class Initialized
INFO - 2018-08-22 20:22:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:22:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:22:17 --> Pixel_Model class loaded
INFO - 2018-08-22 20:22:17 --> Database Driver Class Initialized
INFO - 2018-08-22 20:22:17 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:22:17 --> Database Driver Class Initialized
INFO - 2018-08-22 20:22:17 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:22:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 20:22:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 20:22:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 20:22:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 20:22:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 20:22:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 20:22:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-22 20:22:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 20:22:17 --> Final output sent to browser
DEBUG - 2018-08-22 20:22:17 --> Total execution time: 0.0475
INFO - 2018-08-22 20:22:44 --> Config Class Initialized
INFO - 2018-08-22 20:22:44 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:22:44 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:22:44 --> Utf8 Class Initialized
INFO - 2018-08-22 20:22:44 --> URI Class Initialized
INFO - 2018-08-22 20:22:44 --> Router Class Initialized
INFO - 2018-08-22 20:22:44 --> Output Class Initialized
INFO - 2018-08-22 20:22:44 --> Security Class Initialized
DEBUG - 2018-08-22 20:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:22:44 --> CSRF cookie sent
INFO - 2018-08-22 20:22:44 --> Input Class Initialized
INFO - 2018-08-22 20:22:44 --> Language Class Initialized
INFO - 2018-08-22 20:22:44 --> Loader Class Initialized
INFO - 2018-08-22 20:22:44 --> Helper loaded: url_helper
INFO - 2018-08-22 20:22:44 --> Helper loaded: form_helper
INFO - 2018-08-22 20:22:44 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:22:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:22:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:22:44 --> User Agent Class Initialized
INFO - 2018-08-22 20:22:44 --> Controller Class Initialized
INFO - 2018-08-22 20:22:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:22:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:22:44 --> Pixel_Model class loaded
INFO - 2018-08-22 20:22:44 --> Database Driver Class Initialized
INFO - 2018-08-22 20:22:44 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:22:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 20:22:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 20:22:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 20:22:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 20:22:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 20:22:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 20:22:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-08-22 20:22:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 20:22:44 --> Final output sent to browser
DEBUG - 2018-08-22 20:22:44 --> Total execution time: 0.0397
INFO - 2018-08-22 20:22:55 --> Config Class Initialized
INFO - 2018-08-22 20:22:55 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:22:55 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:22:55 --> Utf8 Class Initialized
INFO - 2018-08-22 20:22:55 --> URI Class Initialized
INFO - 2018-08-22 20:22:55 --> Router Class Initialized
INFO - 2018-08-22 20:22:55 --> Output Class Initialized
INFO - 2018-08-22 20:22:55 --> Security Class Initialized
DEBUG - 2018-08-22 20:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:22:55 --> CSRF cookie sent
INFO - 2018-08-22 20:22:55 --> Input Class Initialized
INFO - 2018-08-22 20:22:55 --> Language Class Initialized
INFO - 2018-08-22 20:22:55 --> Loader Class Initialized
INFO - 2018-08-22 20:22:55 --> Helper loaded: url_helper
INFO - 2018-08-22 20:22:55 --> Helper loaded: form_helper
INFO - 2018-08-22 20:22:55 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:22:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:22:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:22:55 --> User Agent Class Initialized
INFO - 2018-08-22 20:22:55 --> Controller Class Initialized
INFO - 2018-08-22 20:22:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:22:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:22:55 --> Pixel_Model class loaded
INFO - 2018-08-22 20:22:55 --> Database Driver Class Initialized
INFO - 2018-08-22 20:22:55 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:22:55 --> Database Driver Class Initialized
INFO - 2018-08-22 20:22:55 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:22:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 20:22:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 20:22:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 20:22:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 20:22:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 20:22:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 20:22:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 20:22:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/gifts_info.php
INFO - 2018-08-22 20:22:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 20:22:55 --> Final output sent to browser
DEBUG - 2018-08-22 20:22:55 --> Total execution time: 0.0537
INFO - 2018-08-22 20:22:56 --> Config Class Initialized
INFO - 2018-08-22 20:22:56 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:22:56 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:22:56 --> Utf8 Class Initialized
INFO - 2018-08-22 20:22:56 --> URI Class Initialized
INFO - 2018-08-22 20:22:56 --> Router Class Initialized
INFO - 2018-08-22 20:22:56 --> Output Class Initialized
INFO - 2018-08-22 20:22:56 --> Security Class Initialized
DEBUG - 2018-08-22 20:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:22:56 --> CSRF cookie sent
INFO - 2018-08-22 20:22:56 --> Input Class Initialized
INFO - 2018-08-22 20:22:56 --> Language Class Initialized
ERROR - 2018-08-22 20:22:56 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 20:23:18 --> Config Class Initialized
INFO - 2018-08-22 20:23:18 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:23:18 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:23:18 --> Utf8 Class Initialized
INFO - 2018-08-22 20:23:18 --> URI Class Initialized
INFO - 2018-08-22 20:23:18 --> Router Class Initialized
INFO - 2018-08-22 20:23:18 --> Output Class Initialized
INFO - 2018-08-22 20:23:18 --> Security Class Initialized
DEBUG - 2018-08-22 20:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:23:18 --> CSRF cookie sent
INFO - 2018-08-22 20:23:18 --> CSRF token verified
INFO - 2018-08-22 20:23:18 --> Input Class Initialized
INFO - 2018-08-22 20:23:18 --> Language Class Initialized
INFO - 2018-08-22 20:23:18 --> Loader Class Initialized
INFO - 2018-08-22 20:23:18 --> Helper loaded: url_helper
INFO - 2018-08-22 20:23:18 --> Helper loaded: form_helper
INFO - 2018-08-22 20:23:18 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:23:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:23:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:23:18 --> User Agent Class Initialized
INFO - 2018-08-22 20:23:18 --> Controller Class Initialized
INFO - 2018-08-22 20:23:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:23:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:23:18 --> Pixel_Model class loaded
INFO - 2018-08-22 20:23:18 --> Database Driver Class Initialized
INFO - 2018-08-22 20:23:18 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:23:18 --> Form Validation Class Initialized
INFO - 2018-08-22 20:23:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-22 20:23:18 --> Database Driver Class Initialized
INFO - 2018-08-22 20:23:18 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:23:18 --> Config Class Initialized
INFO - 2018-08-22 20:23:18 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:23:18 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:23:18 --> Utf8 Class Initialized
INFO - 2018-08-22 20:23:18 --> URI Class Initialized
INFO - 2018-08-22 20:23:18 --> Router Class Initialized
INFO - 2018-08-22 20:23:18 --> Output Class Initialized
INFO - 2018-08-22 20:23:18 --> Security Class Initialized
DEBUG - 2018-08-22 20:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:23:18 --> CSRF cookie sent
INFO - 2018-08-22 20:23:18 --> Input Class Initialized
INFO - 2018-08-22 20:23:18 --> Language Class Initialized
INFO - 2018-08-22 20:23:18 --> Loader Class Initialized
INFO - 2018-08-22 20:23:18 --> Helper loaded: url_helper
INFO - 2018-08-22 20:23:18 --> Helper loaded: form_helper
INFO - 2018-08-22 20:23:18 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:23:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:23:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:23:18 --> User Agent Class Initialized
INFO - 2018-08-22 20:23:18 --> Controller Class Initialized
INFO - 2018-08-22 20:23:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:23:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:23:18 --> Pixel_Model class loaded
INFO - 2018-08-22 20:23:18 --> Database Driver Class Initialized
INFO - 2018-08-22 20:23:18 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:23:18 --> Database Driver Class Initialized
INFO - 2018-08-22 20:23:18 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:23:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 20:23:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 20:23:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 20:23:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 20:23:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 20:23:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 20:23:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 20:23:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/gift_details.php
INFO - 2018-08-22 20:23:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 20:23:18 --> Final output sent to browser
DEBUG - 2018-08-22 20:23:18 --> Total execution time: 0.0411
INFO - 2018-08-22 20:23:18 --> Config Class Initialized
INFO - 2018-08-22 20:23:18 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:23:18 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:23:18 --> Utf8 Class Initialized
INFO - 2018-08-22 20:23:18 --> URI Class Initialized
INFO - 2018-08-22 20:23:18 --> Router Class Initialized
INFO - 2018-08-22 20:23:18 --> Output Class Initialized
INFO - 2018-08-22 20:23:18 --> Security Class Initialized
DEBUG - 2018-08-22 20:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:23:18 --> CSRF cookie sent
INFO - 2018-08-22 20:23:18 --> Input Class Initialized
INFO - 2018-08-22 20:23:18 --> Language Class Initialized
ERROR - 2018-08-22 20:23:18 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 20:25:31 --> Config Class Initialized
INFO - 2018-08-22 20:25:31 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:25:31 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:25:31 --> Utf8 Class Initialized
INFO - 2018-08-22 20:25:31 --> URI Class Initialized
DEBUG - 2018-08-22 20:25:31 --> No URI present. Default controller set.
INFO - 2018-08-22 20:25:31 --> Router Class Initialized
INFO - 2018-08-22 20:25:31 --> Output Class Initialized
INFO - 2018-08-22 20:25:31 --> Security Class Initialized
DEBUG - 2018-08-22 20:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:25:31 --> CSRF cookie sent
INFO - 2018-08-22 20:25:31 --> Input Class Initialized
INFO - 2018-08-22 20:25:31 --> Language Class Initialized
INFO - 2018-08-22 20:25:31 --> Loader Class Initialized
INFO - 2018-08-22 20:25:31 --> Helper loaded: url_helper
INFO - 2018-08-22 20:25:31 --> Helper loaded: form_helper
INFO - 2018-08-22 20:25:31 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:25:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:25:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:25:31 --> User Agent Class Initialized
INFO - 2018-08-22 20:25:31 --> Controller Class Initialized
INFO - 2018-08-22 20:25:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:25:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:25:31 --> Pixel_Model class loaded
INFO - 2018-08-22 20:25:31 --> Database Driver Class Initialized
INFO - 2018-08-22 20:25:31 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:25:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 20:25:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 20:25:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-22 20:25:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 20:25:31 --> Final output sent to browser
DEBUG - 2018-08-22 20:25:31 --> Total execution time: 0.0339
INFO - 2018-08-22 20:53:52 --> Config Class Initialized
INFO - 2018-08-22 20:53:52 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:53:52 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:53:52 --> Utf8 Class Initialized
INFO - 2018-08-22 20:53:52 --> URI Class Initialized
INFO - 2018-08-22 20:53:52 --> Router Class Initialized
INFO - 2018-08-22 20:53:52 --> Output Class Initialized
INFO - 2018-08-22 20:53:52 --> Security Class Initialized
DEBUG - 2018-08-22 20:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:53:52 --> CSRF cookie sent
INFO - 2018-08-22 20:53:52 --> Input Class Initialized
INFO - 2018-08-22 20:53:52 --> Language Class Initialized
INFO - 2018-08-22 20:53:52 --> Loader Class Initialized
INFO - 2018-08-22 20:53:52 --> Helper loaded: url_helper
INFO - 2018-08-22 20:53:52 --> Helper loaded: form_helper
INFO - 2018-08-22 20:53:52 --> Helper loaded: language_helper
DEBUG - 2018-08-22 20:53:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 20:53:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 20:53:52 --> User Agent Class Initialized
INFO - 2018-08-22 20:53:52 --> Controller Class Initialized
INFO - 2018-08-22 20:53:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 20:53:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 20:53:52 --> Pixel_Model class loaded
INFO - 2018-08-22 20:53:52 --> Database Driver Class Initialized
INFO - 2018-08-22 20:53:52 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 20:53:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 20:53:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 20:53:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 20:53:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 20:53:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 20:53:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 20:53:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 20:53:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-08-22 20:53:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 20:53:52 --> Final output sent to browser
DEBUG - 2018-08-22 20:53:52 --> Total execution time: 0.0658
INFO - 2018-08-22 20:53:53 --> Config Class Initialized
INFO - 2018-08-22 20:53:53 --> Hooks Class Initialized
DEBUG - 2018-08-22 20:53:53 --> UTF-8 Support Enabled
INFO - 2018-08-22 20:53:53 --> Utf8 Class Initialized
INFO - 2018-08-22 20:53:53 --> URI Class Initialized
INFO - 2018-08-22 20:53:53 --> Router Class Initialized
INFO - 2018-08-22 20:53:53 --> Output Class Initialized
INFO - 2018-08-22 20:53:53 --> Security Class Initialized
DEBUG - 2018-08-22 20:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 20:53:53 --> CSRF cookie sent
INFO - 2018-08-22 20:53:53 --> Input Class Initialized
INFO - 2018-08-22 20:53:53 --> Language Class Initialized
ERROR - 2018-08-22 20:53:53 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 21:01:51 --> Config Class Initialized
INFO - 2018-08-22 21:01:51 --> Hooks Class Initialized
DEBUG - 2018-08-22 21:01:51 --> UTF-8 Support Enabled
INFO - 2018-08-22 21:01:51 --> Utf8 Class Initialized
INFO - 2018-08-22 21:01:51 --> URI Class Initialized
INFO - 2018-08-22 21:01:51 --> Router Class Initialized
INFO - 2018-08-22 21:01:51 --> Output Class Initialized
INFO - 2018-08-22 21:01:51 --> Security Class Initialized
DEBUG - 2018-08-22 21:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 21:01:51 --> CSRF cookie sent
INFO - 2018-08-22 21:01:51 --> Input Class Initialized
INFO - 2018-08-22 21:01:51 --> Language Class Initialized
INFO - 2018-08-22 21:01:51 --> Loader Class Initialized
INFO - 2018-08-22 21:01:51 --> Helper loaded: url_helper
INFO - 2018-08-22 21:01:51 --> Helper loaded: form_helper
INFO - 2018-08-22 21:01:51 --> Helper loaded: language_helper
DEBUG - 2018-08-22 21:01:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 21:01:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 21:01:51 --> User Agent Class Initialized
INFO - 2018-08-22 21:01:51 --> Controller Class Initialized
INFO - 2018-08-22 21:01:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 21:01:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 21:01:51 --> Pixel_Model class loaded
INFO - 2018-08-22 21:01:51 --> Database Driver Class Initialized
INFO - 2018-08-22 21:01:51 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 21:01:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 21:01:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 21:01:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 21:01:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 21:01:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 21:01:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 21:01:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 21:01:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-08-22 21:01:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 21:01:51 --> Final output sent to browser
DEBUG - 2018-08-22 21:01:51 --> Total execution time: 0.0367
INFO - 2018-08-22 21:01:52 --> Config Class Initialized
INFO - 2018-08-22 21:01:52 --> Hooks Class Initialized
DEBUG - 2018-08-22 21:01:52 --> UTF-8 Support Enabled
INFO - 2018-08-22 21:01:52 --> Utf8 Class Initialized
INFO - 2018-08-22 21:01:52 --> URI Class Initialized
INFO - 2018-08-22 21:01:52 --> Router Class Initialized
INFO - 2018-08-22 21:01:52 --> Output Class Initialized
INFO - 2018-08-22 21:01:52 --> Security Class Initialized
DEBUG - 2018-08-22 21:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 21:01:52 --> CSRF cookie sent
INFO - 2018-08-22 21:01:52 --> Input Class Initialized
INFO - 2018-08-22 21:01:52 --> Language Class Initialized
ERROR - 2018-08-22 21:01:52 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 21:01:58 --> Config Class Initialized
INFO - 2018-08-22 21:01:58 --> Hooks Class Initialized
DEBUG - 2018-08-22 21:01:58 --> UTF-8 Support Enabled
INFO - 2018-08-22 21:01:58 --> Utf8 Class Initialized
INFO - 2018-08-22 21:01:58 --> URI Class Initialized
INFO - 2018-08-22 21:01:58 --> Router Class Initialized
INFO - 2018-08-22 21:01:58 --> Output Class Initialized
INFO - 2018-08-22 21:01:58 --> Security Class Initialized
DEBUG - 2018-08-22 21:01:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 21:01:58 --> CSRF cookie sent
INFO - 2018-08-22 21:01:58 --> Input Class Initialized
INFO - 2018-08-22 21:01:58 --> Language Class Initialized
INFO - 2018-08-22 21:01:58 --> Loader Class Initialized
INFO - 2018-08-22 21:01:58 --> Helper loaded: url_helper
INFO - 2018-08-22 21:01:58 --> Helper loaded: form_helper
INFO - 2018-08-22 21:01:58 --> Helper loaded: language_helper
DEBUG - 2018-08-22 21:01:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 21:01:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 21:01:58 --> User Agent Class Initialized
INFO - 2018-08-22 21:01:58 --> Controller Class Initialized
INFO - 2018-08-22 21:01:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 21:01:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 21:01:58 --> Pixel_Model class loaded
INFO - 2018-08-22 21:01:58 --> Database Driver Class Initialized
INFO - 2018-08-22 21:01:58 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 21:01:58 --> Database Driver Class Initialized
INFO - 2018-08-22 21:01:58 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 21:01:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 21:01:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 21:01:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 21:01:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 21:01:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 21:01:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 21:01:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 21:01:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-08-22 21:01:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 21:01:58 --> Final output sent to browser
DEBUG - 2018-08-22 21:01:58 --> Total execution time: 0.0417
INFO - 2018-08-22 21:01:59 --> Config Class Initialized
INFO - 2018-08-22 21:01:59 --> Hooks Class Initialized
DEBUG - 2018-08-22 21:01:59 --> UTF-8 Support Enabled
INFO - 2018-08-22 21:01:59 --> Utf8 Class Initialized
INFO - 2018-08-22 21:01:59 --> URI Class Initialized
INFO - 2018-08-22 21:01:59 --> Router Class Initialized
INFO - 2018-08-22 21:01:59 --> Output Class Initialized
INFO - 2018-08-22 21:01:59 --> Security Class Initialized
DEBUG - 2018-08-22 21:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 21:01:59 --> CSRF cookie sent
INFO - 2018-08-22 21:01:59 --> Input Class Initialized
INFO - 2018-08-22 21:01:59 --> Language Class Initialized
ERROR - 2018-08-22 21:01:59 --> 404 Page Not Found: Assets/css
INFO - 2018-08-22 21:02:52 --> Config Class Initialized
INFO - 2018-08-22 21:02:52 --> Hooks Class Initialized
DEBUG - 2018-08-22 21:02:52 --> UTF-8 Support Enabled
INFO - 2018-08-22 21:02:52 --> Utf8 Class Initialized
INFO - 2018-08-22 21:02:52 --> URI Class Initialized
INFO - 2018-08-22 21:02:52 --> Router Class Initialized
INFO - 2018-08-22 21:02:52 --> Output Class Initialized
INFO - 2018-08-22 21:02:52 --> Security Class Initialized
DEBUG - 2018-08-22 21:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 21:02:52 --> CSRF cookie sent
INFO - 2018-08-22 21:02:52 --> Input Class Initialized
INFO - 2018-08-22 21:02:52 --> Language Class Initialized
INFO - 2018-08-22 21:02:52 --> Loader Class Initialized
INFO - 2018-08-22 21:02:52 --> Helper loaded: url_helper
INFO - 2018-08-22 21:02:52 --> Helper loaded: form_helper
INFO - 2018-08-22 21:02:52 --> Helper loaded: language_helper
DEBUG - 2018-08-22 21:02:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 21:02:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 21:02:52 --> User Agent Class Initialized
INFO - 2018-08-22 21:02:52 --> Controller Class Initialized
INFO - 2018-08-22 21:02:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-22 21:02:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-22 21:02:52 --> Pixel_Model class loaded
INFO - 2018-08-22 21:02:52 --> Database Driver Class Initialized
INFO - 2018-08-22 21:02:52 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 21:02:52 --> Database Driver Class Initialized
INFO - 2018-08-22 21:02:52 --> Model "QuestionsModel" initialized
INFO - 2018-08-22 21:02:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-22 21:02:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_end_user_nav.php
INFO - 2018-08-22 21:02:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-22 21:02:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-22 21:02:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-22 21:02:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-22 21:02:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-22 21:02:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-08-22 21:02:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-22 21:02:52 --> Final output sent to browser
DEBUG - 2018-08-22 21:02:52 --> Total execution time: 0.0602
INFO - 2018-08-22 21:02:52 --> Config Class Initialized
INFO - 2018-08-22 21:02:52 --> Hooks Class Initialized
DEBUG - 2018-08-22 21:02:52 --> UTF-8 Support Enabled
INFO - 2018-08-22 21:02:52 --> Utf8 Class Initialized
INFO - 2018-08-22 21:02:52 --> URI Class Initialized
INFO - 2018-08-22 21:02:52 --> Router Class Initialized
INFO - 2018-08-22 21:02:52 --> Output Class Initialized
INFO - 2018-08-22 21:02:52 --> Security Class Initialized
DEBUG - 2018-08-22 21:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 21:02:52 --> CSRF cookie sent
INFO - 2018-08-22 21:02:52 --> Input Class Initialized
INFO - 2018-08-22 21:02:52 --> Language Class Initialized
ERROR - 2018-08-22 21:02:52 --> 404 Page Not Found: Assets/css

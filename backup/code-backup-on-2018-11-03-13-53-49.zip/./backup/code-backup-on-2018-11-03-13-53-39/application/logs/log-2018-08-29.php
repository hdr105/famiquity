<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-08-29 09:15:11 --> Config Class Initialized
INFO - 2018-08-29 09:15:11 --> Hooks Class Initialized
DEBUG - 2018-08-29 09:15:11 --> UTF-8 Support Enabled
INFO - 2018-08-29 09:15:11 --> Utf8 Class Initialized
INFO - 2018-08-29 09:15:11 --> URI Class Initialized
DEBUG - 2018-08-29 09:15:11 --> No URI present. Default controller set.
INFO - 2018-08-29 09:15:11 --> Router Class Initialized
INFO - 2018-08-29 09:15:11 --> Output Class Initialized
INFO - 2018-08-29 09:15:11 --> Security Class Initialized
DEBUG - 2018-08-29 09:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-29 09:15:11 --> CSRF cookie sent
INFO - 2018-08-29 09:15:11 --> Input Class Initialized
INFO - 2018-08-29 09:15:11 --> Language Class Initialized
INFO - 2018-08-29 09:15:11 --> Loader Class Initialized
INFO - 2018-08-29 09:15:11 --> Helper loaded: url_helper
INFO - 2018-08-29 09:15:11 --> Helper loaded: form_helper
INFO - 2018-08-29 09:15:11 --> Helper loaded: language_helper
DEBUG - 2018-08-29 09:15:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-29 09:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-29 09:15:11 --> User Agent Class Initialized
INFO - 2018-08-29 09:15:11 --> Controller Class Initialized
INFO - 2018-08-29 09:15:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-29 09:15:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-29 09:15:11 --> Pixel_Model class loaded
INFO - 2018-08-29 09:15:11 --> Database Driver Class Initialized
INFO - 2018-08-29 09:15:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 09:15:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-29 09:15:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-29 09:15:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-29 09:15:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-29 09:15:11 --> Final output sent to browser
DEBUG - 2018-08-29 09:15:11 --> Total execution time: 0.0515
INFO - 2018-08-29 09:15:16 --> Config Class Initialized
INFO - 2018-08-29 09:15:16 --> Hooks Class Initialized
DEBUG - 2018-08-29 09:15:16 --> UTF-8 Support Enabled
INFO - 2018-08-29 09:15:16 --> Utf8 Class Initialized
INFO - 2018-08-29 09:15:16 --> URI Class Initialized
INFO - 2018-08-29 09:15:16 --> Router Class Initialized
INFO - 2018-08-29 09:15:16 --> Output Class Initialized
INFO - 2018-08-29 09:15:16 --> Security Class Initialized
DEBUG - 2018-08-29 09:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-29 09:15:16 --> CSRF cookie sent
INFO - 2018-08-29 09:15:16 --> CSRF token verified
INFO - 2018-08-29 09:15:16 --> Input Class Initialized
INFO - 2018-08-29 09:15:16 --> Language Class Initialized
INFO - 2018-08-29 09:15:16 --> Loader Class Initialized
INFO - 2018-08-29 09:15:16 --> Helper loaded: url_helper
INFO - 2018-08-29 09:15:16 --> Helper loaded: form_helper
INFO - 2018-08-29 09:15:16 --> Helper loaded: language_helper
DEBUG - 2018-08-29 09:15:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-29 09:15:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-29 09:15:16 --> User Agent Class Initialized
INFO - 2018-08-29 09:15:16 --> Controller Class Initialized
INFO - 2018-08-29 09:15:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-29 09:15:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-29 09:15:16 --> Pixel_Model class loaded
INFO - 2018-08-29 09:15:17 --> Database Driver Class Initialized
INFO - 2018-08-29 09:15:17 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 09:15:17 --> Database Driver Class Initialized
INFO - 2018-08-29 09:15:17 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 09:15:17 --> Config Class Initialized
INFO - 2018-08-29 09:15:17 --> Hooks Class Initialized
DEBUG - 2018-08-29 09:15:17 --> UTF-8 Support Enabled
INFO - 2018-08-29 09:15:17 --> Utf8 Class Initialized
INFO - 2018-08-29 09:15:17 --> URI Class Initialized
INFO - 2018-08-29 09:15:17 --> Router Class Initialized
INFO - 2018-08-29 09:15:17 --> Output Class Initialized
INFO - 2018-08-29 09:15:17 --> Security Class Initialized
DEBUG - 2018-08-29 09:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-29 09:15:17 --> CSRF cookie sent
INFO - 2018-08-29 09:15:17 --> Input Class Initialized
INFO - 2018-08-29 09:15:17 --> Language Class Initialized
INFO - 2018-08-29 09:15:17 --> Loader Class Initialized
INFO - 2018-08-29 09:15:17 --> Helper loaded: url_helper
INFO - 2018-08-29 09:15:17 --> Helper loaded: form_helper
INFO - 2018-08-29 09:15:17 --> Helper loaded: language_helper
DEBUG - 2018-08-29 09:15:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-29 09:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-29 09:15:17 --> User Agent Class Initialized
INFO - 2018-08-29 09:15:17 --> Controller Class Initialized
INFO - 2018-08-29 09:15:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-29 09:15:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-29 09:15:17 --> Pixel_Model class loaded
INFO - 2018-08-29 09:15:17 --> Database Driver Class Initialized
INFO - 2018-08-29 09:15:17 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 09:15:17 --> Database Driver Class Initialized
INFO - 2018-08-29 09:15:17 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 09:15:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-29 09:15:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-29 09:15:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-29 09:15:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-29 09:15:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-29 09:15:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-29 09:15:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-29 09:15:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-29 09:15:17 --> Final output sent to browser
DEBUG - 2018-08-29 09:15:17 --> Total execution time: 0.0506
INFO - 2018-08-29 09:15:24 --> Config Class Initialized
INFO - 2018-08-29 09:15:24 --> Hooks Class Initialized
DEBUG - 2018-08-29 09:15:24 --> UTF-8 Support Enabled
INFO - 2018-08-29 09:15:24 --> Utf8 Class Initialized
INFO - 2018-08-29 09:15:24 --> URI Class Initialized
INFO - 2018-08-29 09:15:24 --> Router Class Initialized
INFO - 2018-08-29 09:15:24 --> Output Class Initialized
INFO - 2018-08-29 09:15:24 --> Security Class Initialized
DEBUG - 2018-08-29 09:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-29 09:15:24 --> CSRF cookie sent
INFO - 2018-08-29 09:15:24 --> Input Class Initialized
INFO - 2018-08-29 09:15:24 --> Language Class Initialized
INFO - 2018-08-29 09:15:24 --> Loader Class Initialized
INFO - 2018-08-29 09:15:24 --> Helper loaded: url_helper
INFO - 2018-08-29 09:15:24 --> Helper loaded: form_helper
INFO - 2018-08-29 09:15:24 --> Helper loaded: language_helper
DEBUG - 2018-08-29 09:15:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-29 09:15:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-29 09:15:24 --> User Agent Class Initialized
INFO - 2018-08-29 09:15:24 --> Controller Class Initialized
INFO - 2018-08-29 09:15:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-29 09:15:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-29 09:15:24 --> Pixel_Model class loaded
INFO - 2018-08-29 09:15:24 --> Database Driver Class Initialized
INFO - 2018-08-29 09:15:24 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 09:15:24 --> Database Driver Class Initialized
INFO - 2018-08-29 09:15:24 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 09:15:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-29 09:15:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-29 09:15:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-29 09:15:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-29 09:15:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/save_exit.php
INFO - 2018-08-29 09:15:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-29 09:15:24 --> Final output sent to browser
DEBUG - 2018-08-29 09:15:24 --> Total execution time: 0.0534
INFO - 2018-08-29 09:15:29 --> Config Class Initialized
INFO - 2018-08-29 09:15:29 --> Hooks Class Initialized
DEBUG - 2018-08-29 09:15:29 --> UTF-8 Support Enabled
INFO - 2018-08-29 09:15:29 --> Utf8 Class Initialized
INFO - 2018-08-29 09:15:29 --> URI Class Initialized
INFO - 2018-08-29 09:15:29 --> Router Class Initialized
INFO - 2018-08-29 09:15:29 --> Output Class Initialized
INFO - 2018-08-29 09:15:29 --> Security Class Initialized
DEBUG - 2018-08-29 09:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-29 09:15:29 --> CSRF cookie sent
INFO - 2018-08-29 09:15:29 --> Input Class Initialized
INFO - 2018-08-29 09:15:29 --> Language Class Initialized
INFO - 2018-08-29 09:15:29 --> Loader Class Initialized
INFO - 2018-08-29 09:15:29 --> Helper loaded: url_helper
INFO - 2018-08-29 09:15:29 --> Helper loaded: form_helper
INFO - 2018-08-29 09:15:29 --> Helper loaded: language_helper
DEBUG - 2018-08-29 09:15:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-29 09:15:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-29 09:15:29 --> User Agent Class Initialized
INFO - 2018-08-29 09:15:29 --> Controller Class Initialized
INFO - 2018-08-29 09:15:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-29 09:15:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-29 09:15:29 --> Pixel_Model class loaded
INFO - 2018-08-29 09:15:29 --> Database Driver Class Initialized
INFO - 2018-08-29 09:15:29 --> Model "RegistrationModel" initialized
DEBUG - 2018-08-29 09:15:29 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-08-29 09:15:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-29 09:15:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-29 09:15:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-29 09:15:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-08-29 09:15:29 --> Could not find the language line "req_email"
INFO - 2018-08-29 09:15:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup.php
INFO - 2018-08-29 09:15:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-29 09:15:29 --> Final output sent to browser
DEBUG - 2018-08-29 09:15:29 --> Total execution time: 0.0358
INFO - 2018-08-29 09:15:43 --> Config Class Initialized
INFO - 2018-08-29 09:15:43 --> Hooks Class Initialized
DEBUG - 2018-08-29 09:15:43 --> UTF-8 Support Enabled
INFO - 2018-08-29 09:15:43 --> Utf8 Class Initialized
INFO - 2018-08-29 09:15:43 --> URI Class Initialized
INFO - 2018-08-29 09:15:43 --> Router Class Initialized
INFO - 2018-08-29 09:15:43 --> Output Class Initialized
INFO - 2018-08-29 09:15:43 --> Security Class Initialized
DEBUG - 2018-08-29 09:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-29 09:15:43 --> CSRF cookie sent
INFO - 2018-08-29 09:15:43 --> Input Class Initialized
INFO - 2018-08-29 09:15:43 --> Language Class Initialized
INFO - 2018-08-29 09:15:43 --> Loader Class Initialized
INFO - 2018-08-29 09:15:43 --> Helper loaded: url_helper
INFO - 2018-08-29 09:15:43 --> Helper loaded: form_helper
INFO - 2018-08-29 09:15:43 --> Helper loaded: language_helper
DEBUG - 2018-08-29 09:15:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-29 09:15:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-29 09:15:43 --> User Agent Class Initialized
INFO - 2018-08-29 09:15:43 --> Controller Class Initialized
INFO - 2018-08-29 09:15:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-29 09:15:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-29 09:15:43 --> Pixel_Model class loaded
INFO - 2018-08-29 09:15:43 --> Database Driver Class Initialized
INFO - 2018-08-29 09:15:43 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 09:15:43 --> Database Driver Class Initialized
INFO - 2018-08-29 09:15:43 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 09:15:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-29 09:15:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-29 09:15:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-29 09:15:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-29 09:15:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/save_exit.php
INFO - 2018-08-29 09:15:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-29 09:15:43 --> Final output sent to browser
DEBUG - 2018-08-29 09:15:43 --> Total execution time: 0.0469
INFO - 2018-08-29 09:15:44 --> Config Class Initialized
INFO - 2018-08-29 09:15:44 --> Hooks Class Initialized
DEBUG - 2018-08-29 09:15:44 --> UTF-8 Support Enabled
INFO - 2018-08-29 09:15:44 --> Utf8 Class Initialized
INFO - 2018-08-29 09:15:44 --> URI Class Initialized
INFO - 2018-08-29 09:15:44 --> Router Class Initialized
INFO - 2018-08-29 09:15:44 --> Output Class Initialized
INFO - 2018-08-29 09:15:44 --> Security Class Initialized
DEBUG - 2018-08-29 09:15:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-29 09:15:44 --> CSRF cookie sent
INFO - 2018-08-29 09:15:44 --> Input Class Initialized
INFO - 2018-08-29 09:15:44 --> Language Class Initialized
INFO - 2018-08-29 09:15:44 --> Loader Class Initialized
INFO - 2018-08-29 09:15:44 --> Helper loaded: url_helper
INFO - 2018-08-29 09:15:44 --> Helper loaded: form_helper
INFO - 2018-08-29 09:15:44 --> Helper loaded: language_helper
DEBUG - 2018-08-29 09:15:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-29 09:15:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-29 09:15:44 --> User Agent Class Initialized
INFO - 2018-08-29 09:15:44 --> Controller Class Initialized
INFO - 2018-08-29 09:15:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-29 09:15:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-29 09:15:44 --> Pixel_Model class loaded
INFO - 2018-08-29 09:15:44 --> Database Driver Class Initialized
INFO - 2018-08-29 09:15:44 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 09:15:44 --> Database Driver Class Initialized
INFO - 2018-08-29 09:15:44 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 09:15:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-29 09:15:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-29 09:15:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-29 09:15:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-29 09:15:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-29 09:15:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-29 09:15:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-29 09:15:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-29 09:15:44 --> Final output sent to browser
DEBUG - 2018-08-29 09:15:44 --> Total execution time: 0.0516
INFO - 2018-08-29 09:15:49 --> Config Class Initialized
INFO - 2018-08-29 09:15:49 --> Hooks Class Initialized
DEBUG - 2018-08-29 09:15:49 --> UTF-8 Support Enabled
INFO - 2018-08-29 09:15:49 --> Utf8 Class Initialized
INFO - 2018-08-29 09:15:49 --> URI Class Initialized
INFO - 2018-08-29 09:15:49 --> Router Class Initialized
INFO - 2018-08-29 09:15:49 --> Output Class Initialized
INFO - 2018-08-29 09:15:49 --> Security Class Initialized
DEBUG - 2018-08-29 09:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-29 09:15:49 --> CSRF cookie sent
INFO - 2018-08-29 09:15:49 --> CSRF token verified
INFO - 2018-08-29 09:15:49 --> Input Class Initialized
INFO - 2018-08-29 09:15:49 --> Language Class Initialized
INFO - 2018-08-29 09:15:49 --> Loader Class Initialized
INFO - 2018-08-29 09:15:49 --> Helper loaded: url_helper
INFO - 2018-08-29 09:15:49 --> Helper loaded: form_helper
INFO - 2018-08-29 09:15:49 --> Helper loaded: language_helper
DEBUG - 2018-08-29 09:15:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-29 09:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-29 09:15:49 --> User Agent Class Initialized
INFO - 2018-08-29 09:15:49 --> Controller Class Initialized
INFO - 2018-08-29 09:15:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-29 09:15:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-29 09:15:49 --> Pixel_Model class loaded
INFO - 2018-08-29 09:15:49 --> Database Driver Class Initialized
INFO - 2018-08-29 09:15:49 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 09:15:49 --> Form Validation Class Initialized
INFO - 2018-08-29 09:15:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-29 09:15:49 --> Database Driver Class Initialized
INFO - 2018-08-29 09:15:49 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 09:15:49 --> Config Class Initialized
INFO - 2018-08-29 09:15:49 --> Hooks Class Initialized
DEBUG - 2018-08-29 09:15:49 --> UTF-8 Support Enabled
INFO - 2018-08-29 09:15:49 --> Utf8 Class Initialized
INFO - 2018-08-29 09:15:49 --> URI Class Initialized
INFO - 2018-08-29 09:15:49 --> Router Class Initialized
INFO - 2018-08-29 09:15:49 --> Output Class Initialized
INFO - 2018-08-29 09:15:49 --> Security Class Initialized
DEBUG - 2018-08-29 09:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-29 09:15:49 --> CSRF cookie sent
INFO - 2018-08-29 09:15:49 --> Input Class Initialized
INFO - 2018-08-29 09:15:49 --> Language Class Initialized
INFO - 2018-08-29 09:15:49 --> Loader Class Initialized
INFO - 2018-08-29 09:15:49 --> Helper loaded: url_helper
INFO - 2018-08-29 09:15:49 --> Helper loaded: form_helper
INFO - 2018-08-29 09:15:49 --> Helper loaded: language_helper
DEBUG - 2018-08-29 09:15:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-29 09:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-29 09:15:49 --> User Agent Class Initialized
INFO - 2018-08-29 09:15:49 --> Controller Class Initialized
INFO - 2018-08-29 09:15:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-29 09:15:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-29 09:15:49 --> Pixel_Model class loaded
INFO - 2018-08-29 09:15:49 --> Database Driver Class Initialized
INFO - 2018-08-29 09:15:49 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 09:15:49 --> Database Driver Class Initialized
INFO - 2018-08-29 09:15:49 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 09:15:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-29 09:15:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-29 09:15:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-29 09:15:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-29 09:15:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-29 09:15:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-29 09:15:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-08-29 09:15:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-29 09:15:49 --> Final output sent to browser
DEBUG - 2018-08-29 09:15:49 --> Total execution time: 0.0454
INFO - 2018-08-29 09:16:06 --> Config Class Initialized
INFO - 2018-08-29 09:16:06 --> Hooks Class Initialized
DEBUG - 2018-08-29 09:16:06 --> UTF-8 Support Enabled
INFO - 2018-08-29 09:16:06 --> Utf8 Class Initialized
INFO - 2018-08-29 09:16:06 --> URI Class Initialized
INFO - 2018-08-29 09:16:06 --> Router Class Initialized
INFO - 2018-08-29 09:16:06 --> Output Class Initialized
INFO - 2018-08-29 09:16:06 --> Security Class Initialized
DEBUG - 2018-08-29 09:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-29 09:16:06 --> CSRF cookie sent
INFO - 2018-08-29 09:16:06 --> CSRF token verified
INFO - 2018-08-29 09:16:06 --> Input Class Initialized
INFO - 2018-08-29 09:16:06 --> Language Class Initialized
INFO - 2018-08-29 09:16:06 --> Loader Class Initialized
INFO - 2018-08-29 09:16:06 --> Helper loaded: url_helper
INFO - 2018-08-29 09:16:06 --> Helper loaded: form_helper
INFO - 2018-08-29 09:16:06 --> Helper loaded: language_helper
DEBUG - 2018-08-29 09:16:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-29 09:16:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-29 09:16:06 --> User Agent Class Initialized
INFO - 2018-08-29 09:16:06 --> Controller Class Initialized
INFO - 2018-08-29 09:16:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-29 09:16:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-29 09:16:06 --> Pixel_Model class loaded
INFO - 2018-08-29 09:16:06 --> Database Driver Class Initialized
INFO - 2018-08-29 09:16:06 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 09:16:06 --> Form Validation Class Initialized
INFO - 2018-08-29 09:16:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-29 09:16:06 --> Database Driver Class Initialized
INFO - 2018-08-29 09:16:06 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 09:16:06 --> Config Class Initialized
INFO - 2018-08-29 09:16:06 --> Hooks Class Initialized
DEBUG - 2018-08-29 09:16:06 --> UTF-8 Support Enabled
INFO - 2018-08-29 09:16:06 --> Utf8 Class Initialized
INFO - 2018-08-29 09:16:06 --> URI Class Initialized
INFO - 2018-08-29 09:16:06 --> Router Class Initialized
INFO - 2018-08-29 09:16:06 --> Output Class Initialized
INFO - 2018-08-29 09:16:06 --> Security Class Initialized
DEBUG - 2018-08-29 09:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-29 09:16:06 --> CSRF cookie sent
INFO - 2018-08-29 09:16:06 --> Input Class Initialized
INFO - 2018-08-29 09:16:06 --> Language Class Initialized
INFO - 2018-08-29 09:16:06 --> Loader Class Initialized
INFO - 2018-08-29 09:16:06 --> Helper loaded: url_helper
INFO - 2018-08-29 09:16:06 --> Helper loaded: form_helper
INFO - 2018-08-29 09:16:06 --> Helper loaded: language_helper
DEBUG - 2018-08-29 09:16:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-29 09:16:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-29 09:16:06 --> User Agent Class Initialized
INFO - 2018-08-29 09:16:06 --> Controller Class Initialized
INFO - 2018-08-29 09:16:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-29 09:16:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-29 09:16:06 --> Pixel_Model class loaded
INFO - 2018-08-29 09:16:06 --> Database Driver Class Initialized
INFO - 2018-08-29 09:16:06 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 09:16:06 --> Database Driver Class Initialized
INFO - 2018-08-29 09:16:06 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 09:16:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-29 09:16:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-29 09:16:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-08-29 09:16:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-29 09:16:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-29 09:16:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-29 09:16:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-29 09:16:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-08-29 09:16:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-29 09:16:06 --> Final output sent to browser
DEBUG - 2018-08-29 09:16:06 --> Total execution time: 0.0422
INFO - 2018-08-29 09:16:11 --> Config Class Initialized
INFO - 2018-08-29 09:16:11 --> Hooks Class Initialized
DEBUG - 2018-08-29 09:16:11 --> UTF-8 Support Enabled
INFO - 2018-08-29 09:16:11 --> Utf8 Class Initialized
INFO - 2018-08-29 09:16:11 --> URI Class Initialized
INFO - 2018-08-29 09:16:11 --> Router Class Initialized
INFO - 2018-08-29 09:16:11 --> Output Class Initialized
INFO - 2018-08-29 09:16:11 --> Security Class Initialized
DEBUG - 2018-08-29 09:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-29 09:16:11 --> CSRF cookie sent
INFO - 2018-08-29 09:16:11 --> CSRF token verified
INFO - 2018-08-29 09:16:11 --> Input Class Initialized
INFO - 2018-08-29 09:16:11 --> Language Class Initialized
INFO - 2018-08-29 09:16:11 --> Loader Class Initialized
INFO - 2018-08-29 09:16:11 --> Helper loaded: url_helper
INFO - 2018-08-29 09:16:11 --> Helper loaded: form_helper
INFO - 2018-08-29 09:16:11 --> Helper loaded: language_helper
DEBUG - 2018-08-29 09:16:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-29 09:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-29 09:16:11 --> User Agent Class Initialized
INFO - 2018-08-29 09:16:11 --> Controller Class Initialized
INFO - 2018-08-29 09:16:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-29 09:16:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-29 09:16:11 --> Pixel_Model class loaded
INFO - 2018-08-29 09:16:11 --> Database Driver Class Initialized
INFO - 2018-08-29 09:16:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 09:16:11 --> Form Validation Class Initialized
INFO - 2018-08-29 09:16:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-29 09:16:11 --> Database Driver Class Initialized
INFO - 2018-08-29 09:16:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 09:16:11 --> Config Class Initialized
INFO - 2018-08-29 09:16:11 --> Hooks Class Initialized
DEBUG - 2018-08-29 09:16:11 --> UTF-8 Support Enabled
INFO - 2018-08-29 09:16:11 --> Utf8 Class Initialized
INFO - 2018-08-29 09:16:11 --> URI Class Initialized
INFO - 2018-08-29 09:16:11 --> Router Class Initialized
INFO - 2018-08-29 09:16:11 --> Output Class Initialized
INFO - 2018-08-29 09:16:11 --> Security Class Initialized
DEBUG - 2018-08-29 09:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-29 09:16:11 --> CSRF cookie sent
INFO - 2018-08-29 09:16:11 --> Input Class Initialized
INFO - 2018-08-29 09:16:11 --> Language Class Initialized
INFO - 2018-08-29 09:16:11 --> Loader Class Initialized
INFO - 2018-08-29 09:16:11 --> Helper loaded: url_helper
INFO - 2018-08-29 09:16:11 --> Helper loaded: form_helper
INFO - 2018-08-29 09:16:11 --> Helper loaded: language_helper
DEBUG - 2018-08-29 09:16:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-29 09:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-29 09:16:11 --> User Agent Class Initialized
INFO - 2018-08-29 09:16:11 --> Controller Class Initialized
INFO - 2018-08-29 09:16:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-29 09:16:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-29 09:16:11 --> Pixel_Model class loaded
INFO - 2018-08-29 09:16:11 --> Database Driver Class Initialized
INFO - 2018-08-29 09:16:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 09:16:11 --> Database Driver Class Initialized
INFO - 2018-08-29 09:16:11 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 09:16:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-29 09:16:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-29 09:16:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-29 09:16:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-29 09:16:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-29 09:16:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-29 09:16:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-08-29 09:16:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-29 09:16:11 --> Final output sent to browser
DEBUG - 2018-08-29 09:16:11 --> Total execution time: 0.0414
INFO - 2018-08-29 09:16:37 --> Config Class Initialized
INFO - 2018-08-29 09:16:37 --> Hooks Class Initialized
DEBUG - 2018-08-29 09:16:37 --> UTF-8 Support Enabled
INFO - 2018-08-29 09:16:37 --> Utf8 Class Initialized
INFO - 2018-08-29 09:16:37 --> URI Class Initialized
INFO - 2018-08-29 09:16:37 --> Router Class Initialized
INFO - 2018-08-29 09:16:37 --> Output Class Initialized
INFO - 2018-08-29 09:16:37 --> Security Class Initialized
DEBUG - 2018-08-29 09:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-29 09:16:37 --> CSRF cookie sent
INFO - 2018-08-29 09:16:37 --> CSRF token verified
INFO - 2018-08-29 09:16:37 --> Input Class Initialized
INFO - 2018-08-29 09:16:37 --> Language Class Initialized
INFO - 2018-08-29 09:16:37 --> Loader Class Initialized
INFO - 2018-08-29 09:16:37 --> Helper loaded: url_helper
INFO - 2018-08-29 09:16:37 --> Helper loaded: form_helper
INFO - 2018-08-29 09:16:37 --> Helper loaded: language_helper
DEBUG - 2018-08-29 09:16:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-29 09:16:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-29 09:16:37 --> User Agent Class Initialized
INFO - 2018-08-29 09:16:37 --> Controller Class Initialized
INFO - 2018-08-29 09:16:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-29 09:16:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-29 09:16:37 --> Pixel_Model class loaded
INFO - 2018-08-29 09:16:37 --> Database Driver Class Initialized
INFO - 2018-08-29 09:16:37 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 09:16:37 --> Form Validation Class Initialized
INFO - 2018-08-29 09:16:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-29 09:16:37 --> Database Driver Class Initialized
INFO - 2018-08-29 09:16:37 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 09:16:37 --> Config Class Initialized
INFO - 2018-08-29 09:16:37 --> Hooks Class Initialized
DEBUG - 2018-08-29 09:16:37 --> UTF-8 Support Enabled
INFO - 2018-08-29 09:16:37 --> Utf8 Class Initialized
INFO - 2018-08-29 09:16:37 --> URI Class Initialized
INFO - 2018-08-29 09:16:37 --> Router Class Initialized
INFO - 2018-08-29 09:16:37 --> Output Class Initialized
INFO - 2018-08-29 09:16:37 --> Security Class Initialized
DEBUG - 2018-08-29 09:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-29 09:16:37 --> CSRF cookie sent
INFO - 2018-08-29 09:16:37 --> Input Class Initialized
INFO - 2018-08-29 09:16:37 --> Language Class Initialized
INFO - 2018-08-29 09:16:37 --> Loader Class Initialized
INFO - 2018-08-29 09:16:37 --> Helper loaded: url_helper
INFO - 2018-08-29 09:16:37 --> Helper loaded: form_helper
INFO - 2018-08-29 09:16:37 --> Helper loaded: language_helper
DEBUG - 2018-08-29 09:16:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-29 09:16:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-29 09:16:37 --> User Agent Class Initialized
INFO - 2018-08-29 09:16:37 --> Controller Class Initialized
INFO - 2018-08-29 09:16:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-29 09:16:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-29 09:16:37 --> Pixel_Model class loaded
INFO - 2018-08-29 09:16:37 --> Database Driver Class Initialized
INFO - 2018-08-29 09:16:37 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 09:16:37 --> Database Driver Class Initialized
INFO - 2018-08-29 09:16:37 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 09:16:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-29 09:16:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-29 09:16:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-29 09:16:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-29 09:16:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-29 09:16:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-29 09:16:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-08-29 09:16:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-29 09:16:37 --> Final output sent to browser
DEBUG - 2018-08-29 09:16:37 --> Total execution time: 0.0480
INFO - 2018-08-29 09:16:50 --> Config Class Initialized
INFO - 2018-08-29 09:16:50 --> Hooks Class Initialized
DEBUG - 2018-08-29 09:16:50 --> UTF-8 Support Enabled
INFO - 2018-08-29 09:16:50 --> Utf8 Class Initialized
INFO - 2018-08-29 09:16:50 --> URI Class Initialized
INFO - 2018-08-29 09:16:50 --> Router Class Initialized
INFO - 2018-08-29 09:16:50 --> Output Class Initialized
INFO - 2018-08-29 09:16:50 --> Security Class Initialized
DEBUG - 2018-08-29 09:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-29 09:16:50 --> CSRF cookie sent
INFO - 2018-08-29 09:16:50 --> CSRF token verified
INFO - 2018-08-29 09:16:50 --> Input Class Initialized
INFO - 2018-08-29 09:16:50 --> Language Class Initialized
INFO - 2018-08-29 09:16:50 --> Loader Class Initialized
INFO - 2018-08-29 09:16:50 --> Helper loaded: url_helper
INFO - 2018-08-29 09:16:50 --> Helper loaded: form_helper
INFO - 2018-08-29 09:16:50 --> Helper loaded: language_helper
DEBUG - 2018-08-29 09:16:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-29 09:16:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-29 09:16:50 --> User Agent Class Initialized
INFO - 2018-08-29 09:16:50 --> Controller Class Initialized
INFO - 2018-08-29 09:16:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-29 09:16:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-29 09:16:50 --> Pixel_Model class loaded
INFO - 2018-08-29 09:16:50 --> Database Driver Class Initialized
INFO - 2018-08-29 09:16:50 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 09:16:50 --> Form Validation Class Initialized
INFO - 2018-08-29 09:16:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-29 09:16:50 --> Database Driver Class Initialized
INFO - 2018-08-29 09:16:50 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 09:16:50 --> Config Class Initialized
INFO - 2018-08-29 09:16:50 --> Hooks Class Initialized
DEBUG - 2018-08-29 09:16:50 --> UTF-8 Support Enabled
INFO - 2018-08-29 09:16:50 --> Utf8 Class Initialized
INFO - 2018-08-29 09:16:50 --> URI Class Initialized
INFO - 2018-08-29 09:16:50 --> Router Class Initialized
INFO - 2018-08-29 09:16:50 --> Output Class Initialized
INFO - 2018-08-29 09:16:50 --> Security Class Initialized
DEBUG - 2018-08-29 09:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-29 09:16:50 --> CSRF cookie sent
INFO - 2018-08-29 09:16:50 --> Input Class Initialized
INFO - 2018-08-29 09:16:50 --> Language Class Initialized
INFO - 2018-08-29 09:16:50 --> Loader Class Initialized
INFO - 2018-08-29 09:16:50 --> Helper loaded: url_helper
INFO - 2018-08-29 09:16:50 --> Helper loaded: form_helper
INFO - 2018-08-29 09:16:50 --> Helper loaded: language_helper
DEBUG - 2018-08-29 09:16:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-29 09:16:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-29 09:16:50 --> User Agent Class Initialized
INFO - 2018-08-29 09:16:50 --> Controller Class Initialized
INFO - 2018-08-29 09:16:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-29 09:16:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-29 09:16:50 --> Pixel_Model class loaded
INFO - 2018-08-29 09:16:50 --> Database Driver Class Initialized
INFO - 2018-08-29 09:16:50 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 09:16:50 --> Database Driver Class Initialized
INFO - 2018-08-29 09:16:50 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 09:16:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-29 09:16:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-29 09:16:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-29 09:16:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-29 09:16:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-29 09:16:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-29 09:16:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-08-29 09:16:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-29 09:16:50 --> Final output sent to browser
DEBUG - 2018-08-29 09:16:50 --> Total execution time: 0.0486
INFO - 2018-08-29 09:17:07 --> Config Class Initialized
INFO - 2018-08-29 09:17:07 --> Hooks Class Initialized
DEBUG - 2018-08-29 09:17:07 --> UTF-8 Support Enabled
INFO - 2018-08-29 09:17:07 --> Utf8 Class Initialized
INFO - 2018-08-29 09:17:07 --> URI Class Initialized
INFO - 2018-08-29 09:17:07 --> Router Class Initialized
INFO - 2018-08-29 09:17:07 --> Output Class Initialized
INFO - 2018-08-29 09:17:07 --> Security Class Initialized
DEBUG - 2018-08-29 09:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-29 09:17:07 --> CSRF cookie sent
INFO - 2018-08-29 09:17:07 --> Input Class Initialized
INFO - 2018-08-29 09:17:07 --> Language Class Initialized
INFO - 2018-08-29 09:17:07 --> Loader Class Initialized
INFO - 2018-08-29 09:17:07 --> Helper loaded: url_helper
INFO - 2018-08-29 09:17:07 --> Helper loaded: form_helper
INFO - 2018-08-29 09:17:07 --> Helper loaded: language_helper
DEBUG - 2018-08-29 09:17:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-29 09:17:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-29 09:17:07 --> User Agent Class Initialized
INFO - 2018-08-29 09:17:07 --> Controller Class Initialized
INFO - 2018-08-29 09:17:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-29 09:17:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-29 09:17:07 --> Pixel_Model class loaded
INFO - 2018-08-29 09:17:07 --> Database Driver Class Initialized
INFO - 2018-08-29 09:17:07 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 09:17:07 --> Database Driver Class Initialized
INFO - 2018-08-29 09:17:07 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 09:17:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-29 09:17:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-29 09:17:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-29 09:17:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-29 09:17:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-08-29 09:17:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-29 09:17:07 --> Final output sent to browser
DEBUG - 2018-08-29 09:17:07 --> Total execution time: 0.0527
INFO - 2018-08-29 17:13:43 --> Config Class Initialized
INFO - 2018-08-29 17:13:43 --> Hooks Class Initialized
DEBUG - 2018-08-29 17:13:43 --> UTF-8 Support Enabled
INFO - 2018-08-29 17:13:43 --> Utf8 Class Initialized
INFO - 2018-08-29 17:13:43 --> URI Class Initialized
DEBUG - 2018-08-29 17:13:43 --> No URI present. Default controller set.
INFO - 2018-08-29 17:13:43 --> Router Class Initialized
INFO - 2018-08-29 17:13:43 --> Output Class Initialized
INFO - 2018-08-29 17:13:43 --> Security Class Initialized
DEBUG - 2018-08-29 17:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-29 17:13:43 --> CSRF cookie sent
INFO - 2018-08-29 17:13:43 --> Input Class Initialized
INFO - 2018-08-29 17:13:43 --> Language Class Initialized
INFO - 2018-08-29 17:13:43 --> Loader Class Initialized
INFO - 2018-08-29 17:13:43 --> Helper loaded: url_helper
INFO - 2018-08-29 17:13:43 --> Helper loaded: form_helper
INFO - 2018-08-29 17:13:43 --> Helper loaded: language_helper
DEBUG - 2018-08-29 17:13:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-29 17:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-29 17:13:43 --> User Agent Class Initialized
INFO - 2018-08-29 17:13:43 --> Controller Class Initialized
INFO - 2018-08-29 17:13:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-29 17:13:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-29 17:13:43 --> Pixel_Model class loaded
INFO - 2018-08-29 17:13:43 --> Database Driver Class Initialized
INFO - 2018-08-29 17:13:43 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 17:13:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-29 17:13:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-29 17:13:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-08-29 17:13:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-29 17:13:43 --> Final output sent to browser
DEBUG - 2018-08-29 17:13:43 --> Total execution time: 0.0361
INFO - 2018-08-29 17:14:13 --> Config Class Initialized
INFO - 2018-08-29 17:14:13 --> Hooks Class Initialized
DEBUG - 2018-08-29 17:14:13 --> UTF-8 Support Enabled
INFO - 2018-08-29 17:14:13 --> Utf8 Class Initialized
INFO - 2018-08-29 17:14:13 --> URI Class Initialized
INFO - 2018-08-29 17:14:13 --> Router Class Initialized
INFO - 2018-08-29 17:14:13 --> Output Class Initialized
INFO - 2018-08-29 17:14:13 --> Security Class Initialized
DEBUG - 2018-08-29 17:14:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-29 17:14:13 --> CSRF cookie sent
INFO - 2018-08-29 17:14:13 --> CSRF token verified
INFO - 2018-08-29 17:14:13 --> Input Class Initialized
INFO - 2018-08-29 17:14:13 --> Language Class Initialized
INFO - 2018-08-29 17:14:13 --> Loader Class Initialized
INFO - 2018-08-29 17:14:13 --> Helper loaded: url_helper
INFO - 2018-08-29 17:14:13 --> Helper loaded: form_helper
INFO - 2018-08-29 17:14:13 --> Helper loaded: language_helper
DEBUG - 2018-08-29 17:14:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-29 17:14:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-29 17:14:13 --> User Agent Class Initialized
INFO - 2018-08-29 17:14:13 --> Controller Class Initialized
INFO - 2018-08-29 17:14:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-29 17:14:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-29 17:14:13 --> Pixel_Model class loaded
INFO - 2018-08-29 17:14:13 --> Database Driver Class Initialized
INFO - 2018-08-29 17:14:13 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 17:14:13 --> Database Driver Class Initialized
INFO - 2018-08-29 17:14:13 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 17:14:14 --> Config Class Initialized
INFO - 2018-08-29 17:14:14 --> Hooks Class Initialized
DEBUG - 2018-08-29 17:14:14 --> UTF-8 Support Enabled
INFO - 2018-08-29 17:14:14 --> Utf8 Class Initialized
INFO - 2018-08-29 17:14:14 --> URI Class Initialized
INFO - 2018-08-29 17:14:14 --> Router Class Initialized
INFO - 2018-08-29 17:14:14 --> Output Class Initialized
INFO - 2018-08-29 17:14:14 --> Security Class Initialized
DEBUG - 2018-08-29 17:14:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-29 17:14:14 --> CSRF cookie sent
INFO - 2018-08-29 17:14:14 --> Input Class Initialized
INFO - 2018-08-29 17:14:14 --> Language Class Initialized
INFO - 2018-08-29 17:14:14 --> Loader Class Initialized
INFO - 2018-08-29 17:14:14 --> Helper loaded: url_helper
INFO - 2018-08-29 17:14:14 --> Helper loaded: form_helper
INFO - 2018-08-29 17:14:14 --> Helper loaded: language_helper
DEBUG - 2018-08-29 17:14:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-29 17:14:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-29 17:14:14 --> User Agent Class Initialized
INFO - 2018-08-29 17:14:14 --> Controller Class Initialized
INFO - 2018-08-29 17:14:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-29 17:14:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-29 17:14:14 --> Pixel_Model class loaded
INFO - 2018-08-29 17:14:14 --> Database Driver Class Initialized
INFO - 2018-08-29 17:14:14 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 17:14:14 --> Database Driver Class Initialized
INFO - 2018-08-29 17:14:14 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 17:14:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-29 17:14:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-29 17:14:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-29 17:14:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-29 17:14:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-29 17:14:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-29 17:14:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-08-29 17:14:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-29 17:14:14 --> Final output sent to browser
DEBUG - 2018-08-29 17:14:14 --> Total execution time: 0.0522
INFO - 2018-08-29 17:14:24 --> Config Class Initialized
INFO - 2018-08-29 17:14:24 --> Hooks Class Initialized
DEBUG - 2018-08-29 17:14:24 --> UTF-8 Support Enabled
INFO - 2018-08-29 17:14:24 --> Utf8 Class Initialized
INFO - 2018-08-29 17:14:24 --> URI Class Initialized
INFO - 2018-08-29 17:14:24 --> Router Class Initialized
INFO - 2018-08-29 17:14:24 --> Output Class Initialized
INFO - 2018-08-29 17:14:24 --> Security Class Initialized
DEBUG - 2018-08-29 17:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-29 17:14:24 --> CSRF cookie sent
INFO - 2018-08-29 17:14:24 --> CSRF token verified
INFO - 2018-08-29 17:14:24 --> Input Class Initialized
INFO - 2018-08-29 17:14:24 --> Language Class Initialized
INFO - 2018-08-29 17:14:24 --> Loader Class Initialized
INFO - 2018-08-29 17:14:24 --> Helper loaded: url_helper
INFO - 2018-08-29 17:14:24 --> Helper loaded: form_helper
INFO - 2018-08-29 17:14:24 --> Helper loaded: language_helper
DEBUG - 2018-08-29 17:14:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-29 17:14:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-29 17:14:24 --> User Agent Class Initialized
INFO - 2018-08-29 17:14:24 --> Controller Class Initialized
INFO - 2018-08-29 17:14:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-29 17:14:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-29 17:14:24 --> Pixel_Model class loaded
INFO - 2018-08-29 17:14:24 --> Database Driver Class Initialized
INFO - 2018-08-29 17:14:24 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 17:14:24 --> Form Validation Class Initialized
INFO - 2018-08-29 17:14:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-29 17:14:24 --> Database Driver Class Initialized
INFO - 2018-08-29 17:14:24 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 17:14:25 --> Config Class Initialized
INFO - 2018-08-29 17:14:25 --> Hooks Class Initialized
DEBUG - 2018-08-29 17:14:25 --> UTF-8 Support Enabled
INFO - 2018-08-29 17:14:25 --> Utf8 Class Initialized
INFO - 2018-08-29 17:14:25 --> URI Class Initialized
INFO - 2018-08-29 17:14:25 --> Router Class Initialized
INFO - 2018-08-29 17:14:25 --> Output Class Initialized
INFO - 2018-08-29 17:14:25 --> Security Class Initialized
DEBUG - 2018-08-29 17:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-29 17:14:25 --> CSRF cookie sent
INFO - 2018-08-29 17:14:25 --> Input Class Initialized
INFO - 2018-08-29 17:14:25 --> Language Class Initialized
INFO - 2018-08-29 17:14:25 --> Loader Class Initialized
INFO - 2018-08-29 17:14:25 --> Helper loaded: url_helper
INFO - 2018-08-29 17:14:25 --> Helper loaded: form_helper
INFO - 2018-08-29 17:14:25 --> Helper loaded: language_helper
DEBUG - 2018-08-29 17:14:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-29 17:14:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-29 17:14:25 --> User Agent Class Initialized
INFO - 2018-08-29 17:14:25 --> Controller Class Initialized
INFO - 2018-08-29 17:14:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-29 17:14:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-29 17:14:25 --> Pixel_Model class loaded
INFO - 2018-08-29 17:14:25 --> Database Driver Class Initialized
INFO - 2018-08-29 17:14:25 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 17:14:25 --> Database Driver Class Initialized
INFO - 2018-08-29 17:14:25 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 17:14:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-29 17:14:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-29 17:14:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-29 17:14:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-29 17:14:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-29 17:14:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-29 17:14:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-08-29 17:14:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-29 17:14:25 --> Final output sent to browser
DEBUG - 2018-08-29 17:14:25 --> Total execution time: 0.0475
INFO - 2018-08-29 17:14:33 --> Config Class Initialized
INFO - 2018-08-29 17:14:33 --> Hooks Class Initialized
DEBUG - 2018-08-29 17:14:33 --> UTF-8 Support Enabled
INFO - 2018-08-29 17:14:33 --> Utf8 Class Initialized
INFO - 2018-08-29 17:14:33 --> URI Class Initialized
INFO - 2018-08-29 17:14:33 --> Router Class Initialized
INFO - 2018-08-29 17:14:33 --> Output Class Initialized
INFO - 2018-08-29 17:14:33 --> Security Class Initialized
DEBUG - 2018-08-29 17:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-29 17:14:33 --> CSRF cookie sent
INFO - 2018-08-29 17:14:33 --> CSRF token verified
INFO - 2018-08-29 17:14:33 --> Input Class Initialized
INFO - 2018-08-29 17:14:33 --> Language Class Initialized
INFO - 2018-08-29 17:14:33 --> Loader Class Initialized
INFO - 2018-08-29 17:14:33 --> Helper loaded: url_helper
INFO - 2018-08-29 17:14:33 --> Helper loaded: form_helper
INFO - 2018-08-29 17:14:33 --> Helper loaded: language_helper
DEBUG - 2018-08-29 17:14:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-29 17:14:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-29 17:14:33 --> User Agent Class Initialized
INFO - 2018-08-29 17:14:33 --> Controller Class Initialized
INFO - 2018-08-29 17:14:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-29 17:14:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-29 17:14:33 --> Pixel_Model class loaded
INFO - 2018-08-29 17:14:33 --> Database Driver Class Initialized
INFO - 2018-08-29 17:14:33 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 17:14:33 --> Form Validation Class Initialized
INFO - 2018-08-29 17:14:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-29 17:14:33 --> Database Driver Class Initialized
INFO - 2018-08-29 17:14:33 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 17:14:34 --> Config Class Initialized
INFO - 2018-08-29 17:14:34 --> Hooks Class Initialized
DEBUG - 2018-08-29 17:14:34 --> UTF-8 Support Enabled
INFO - 2018-08-29 17:14:34 --> Utf8 Class Initialized
INFO - 2018-08-29 17:14:34 --> URI Class Initialized
INFO - 2018-08-29 17:14:34 --> Router Class Initialized
INFO - 2018-08-29 17:14:34 --> Output Class Initialized
INFO - 2018-08-29 17:14:34 --> Security Class Initialized
DEBUG - 2018-08-29 17:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-29 17:14:34 --> CSRF cookie sent
INFO - 2018-08-29 17:14:34 --> Input Class Initialized
INFO - 2018-08-29 17:14:34 --> Language Class Initialized
INFO - 2018-08-29 17:14:34 --> Loader Class Initialized
INFO - 2018-08-29 17:14:34 --> Helper loaded: url_helper
INFO - 2018-08-29 17:14:34 --> Helper loaded: form_helper
INFO - 2018-08-29 17:14:34 --> Helper loaded: language_helper
DEBUG - 2018-08-29 17:14:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-29 17:14:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-29 17:14:34 --> User Agent Class Initialized
INFO - 2018-08-29 17:14:34 --> Controller Class Initialized
INFO - 2018-08-29 17:14:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-29 17:14:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-29 17:14:34 --> Pixel_Model class loaded
INFO - 2018-08-29 17:14:34 --> Database Driver Class Initialized
INFO - 2018-08-29 17:14:34 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 17:14:34 --> Database Driver Class Initialized
INFO - 2018-08-29 17:14:34 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 17:14:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-29 17:14:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-29 17:14:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-08-29 17:14:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-29 17:14:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-29 17:14:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-29 17:14:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-29 17:14:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-08-29 17:14:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-29 17:14:34 --> Final output sent to browser
DEBUG - 2018-08-29 17:14:34 --> Total execution time: 0.0441
INFO - 2018-08-29 17:14:40 --> Config Class Initialized
INFO - 2018-08-29 17:14:40 --> Hooks Class Initialized
DEBUG - 2018-08-29 17:14:40 --> UTF-8 Support Enabled
INFO - 2018-08-29 17:14:40 --> Utf8 Class Initialized
INFO - 2018-08-29 17:14:40 --> URI Class Initialized
INFO - 2018-08-29 17:14:40 --> Router Class Initialized
INFO - 2018-08-29 17:14:40 --> Output Class Initialized
INFO - 2018-08-29 17:14:40 --> Security Class Initialized
DEBUG - 2018-08-29 17:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-29 17:14:40 --> CSRF cookie sent
INFO - 2018-08-29 17:14:40 --> CSRF token verified
INFO - 2018-08-29 17:14:40 --> Input Class Initialized
INFO - 2018-08-29 17:14:40 --> Language Class Initialized
INFO - 2018-08-29 17:14:40 --> Loader Class Initialized
INFO - 2018-08-29 17:14:40 --> Helper loaded: url_helper
INFO - 2018-08-29 17:14:40 --> Helper loaded: form_helper
INFO - 2018-08-29 17:14:40 --> Helper loaded: language_helper
DEBUG - 2018-08-29 17:14:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-29 17:14:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-29 17:14:40 --> User Agent Class Initialized
INFO - 2018-08-29 17:14:40 --> Controller Class Initialized
INFO - 2018-08-29 17:14:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-29 17:14:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-29 17:14:40 --> Pixel_Model class loaded
INFO - 2018-08-29 17:14:40 --> Database Driver Class Initialized
INFO - 2018-08-29 17:14:40 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 17:14:40 --> Form Validation Class Initialized
INFO - 2018-08-29 17:14:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-29 17:14:40 --> Database Driver Class Initialized
INFO - 2018-08-29 17:14:40 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 17:14:41 --> Config Class Initialized
INFO - 2018-08-29 17:14:41 --> Hooks Class Initialized
DEBUG - 2018-08-29 17:14:41 --> UTF-8 Support Enabled
INFO - 2018-08-29 17:14:41 --> Utf8 Class Initialized
INFO - 2018-08-29 17:14:41 --> URI Class Initialized
INFO - 2018-08-29 17:14:41 --> Router Class Initialized
INFO - 2018-08-29 17:14:41 --> Output Class Initialized
INFO - 2018-08-29 17:14:41 --> Security Class Initialized
DEBUG - 2018-08-29 17:14:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-29 17:14:41 --> CSRF cookie sent
INFO - 2018-08-29 17:14:41 --> Input Class Initialized
INFO - 2018-08-29 17:14:41 --> Language Class Initialized
INFO - 2018-08-29 17:14:41 --> Loader Class Initialized
INFO - 2018-08-29 17:14:41 --> Helper loaded: url_helper
INFO - 2018-08-29 17:14:41 --> Helper loaded: form_helper
INFO - 2018-08-29 17:14:41 --> Helper loaded: language_helper
DEBUG - 2018-08-29 17:14:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-29 17:14:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-29 17:14:41 --> User Agent Class Initialized
INFO - 2018-08-29 17:14:41 --> Controller Class Initialized
INFO - 2018-08-29 17:14:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-29 17:14:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-29 17:14:41 --> Pixel_Model class loaded
INFO - 2018-08-29 17:14:41 --> Database Driver Class Initialized
INFO - 2018-08-29 17:14:41 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 17:14:41 --> Database Driver Class Initialized
INFO - 2018-08-29 17:14:41 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 17:14:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-29 17:14:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-29 17:14:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-29 17:14:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-29 17:14:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-29 17:14:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-29 17:14:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-08-29 17:14:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-29 17:14:41 --> Final output sent to browser
DEBUG - 2018-08-29 17:14:41 --> Total execution time: 0.0384
INFO - 2018-08-29 17:17:40 --> Config Class Initialized
INFO - 2018-08-29 17:17:40 --> Hooks Class Initialized
DEBUG - 2018-08-29 17:17:40 --> UTF-8 Support Enabled
INFO - 2018-08-29 17:17:40 --> Utf8 Class Initialized
INFO - 2018-08-29 17:17:40 --> URI Class Initialized
INFO - 2018-08-29 17:17:40 --> Router Class Initialized
INFO - 2018-08-29 17:17:40 --> Output Class Initialized
INFO - 2018-08-29 17:17:40 --> Security Class Initialized
DEBUG - 2018-08-29 17:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-29 17:17:40 --> CSRF cookie sent
INFO - 2018-08-29 17:17:40 --> CSRF token verified
INFO - 2018-08-29 17:17:40 --> Input Class Initialized
INFO - 2018-08-29 17:17:40 --> Language Class Initialized
INFO - 2018-08-29 17:17:40 --> Loader Class Initialized
INFO - 2018-08-29 17:17:40 --> Helper loaded: url_helper
INFO - 2018-08-29 17:17:40 --> Helper loaded: form_helper
INFO - 2018-08-29 17:17:40 --> Helper loaded: language_helper
DEBUG - 2018-08-29 17:17:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-29 17:17:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-29 17:17:40 --> User Agent Class Initialized
INFO - 2018-08-29 17:17:40 --> Controller Class Initialized
INFO - 2018-08-29 17:17:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-29 17:17:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-29 17:17:40 --> Pixel_Model class loaded
INFO - 2018-08-29 17:17:40 --> Database Driver Class Initialized
INFO - 2018-08-29 17:17:40 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 17:17:40 --> Form Validation Class Initialized
INFO - 2018-08-29 17:17:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-29 17:17:40 --> Database Driver Class Initialized
INFO - 2018-08-29 17:17:40 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 17:17:42 --> Config Class Initialized
INFO - 2018-08-29 17:17:42 --> Hooks Class Initialized
DEBUG - 2018-08-29 17:17:42 --> UTF-8 Support Enabled
INFO - 2018-08-29 17:17:42 --> Utf8 Class Initialized
INFO - 2018-08-29 17:17:42 --> URI Class Initialized
INFO - 2018-08-29 17:17:42 --> Router Class Initialized
INFO - 2018-08-29 17:17:42 --> Output Class Initialized
INFO - 2018-08-29 17:17:42 --> Security Class Initialized
DEBUG - 2018-08-29 17:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-29 17:17:42 --> CSRF cookie sent
INFO - 2018-08-29 17:17:42 --> Input Class Initialized
INFO - 2018-08-29 17:17:42 --> Language Class Initialized
INFO - 2018-08-29 17:17:42 --> Loader Class Initialized
INFO - 2018-08-29 17:17:42 --> Helper loaded: url_helper
INFO - 2018-08-29 17:17:42 --> Helper loaded: form_helper
INFO - 2018-08-29 17:17:42 --> Helper loaded: language_helper
DEBUG - 2018-08-29 17:17:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-29 17:17:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-29 17:17:42 --> User Agent Class Initialized
INFO - 2018-08-29 17:17:42 --> Controller Class Initialized
INFO - 2018-08-29 17:17:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-29 17:17:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-29 17:17:42 --> Pixel_Model class loaded
INFO - 2018-08-29 17:17:42 --> Database Driver Class Initialized
INFO - 2018-08-29 17:17:42 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 17:17:42 --> Database Driver Class Initialized
INFO - 2018-08-29 17:17:42 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 17:17:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-29 17:17:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-29 17:17:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-29 17:17:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-29 17:17:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-29 17:17:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-29 17:17:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-08-29 17:17:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-29 17:17:42 --> Final output sent to browser
DEBUG - 2018-08-29 17:17:42 --> Total execution time: 0.0488
INFO - 2018-08-29 17:17:49 --> Config Class Initialized
INFO - 2018-08-29 17:17:49 --> Hooks Class Initialized
DEBUG - 2018-08-29 17:17:49 --> UTF-8 Support Enabled
INFO - 2018-08-29 17:17:49 --> Utf8 Class Initialized
INFO - 2018-08-29 17:17:49 --> URI Class Initialized
INFO - 2018-08-29 17:17:49 --> Router Class Initialized
INFO - 2018-08-29 17:17:49 --> Output Class Initialized
INFO - 2018-08-29 17:17:49 --> Security Class Initialized
DEBUG - 2018-08-29 17:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-29 17:17:49 --> CSRF cookie sent
INFO - 2018-08-29 17:17:49 --> CSRF token verified
INFO - 2018-08-29 17:17:49 --> Input Class Initialized
INFO - 2018-08-29 17:17:49 --> Language Class Initialized
INFO - 2018-08-29 17:17:49 --> Loader Class Initialized
INFO - 2018-08-29 17:17:49 --> Helper loaded: url_helper
INFO - 2018-08-29 17:17:49 --> Helper loaded: form_helper
INFO - 2018-08-29 17:17:49 --> Helper loaded: language_helper
DEBUG - 2018-08-29 17:17:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-29 17:17:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-29 17:17:49 --> User Agent Class Initialized
INFO - 2018-08-29 17:17:49 --> Controller Class Initialized
INFO - 2018-08-29 17:17:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-29 17:17:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-29 17:17:49 --> Pixel_Model class loaded
INFO - 2018-08-29 17:17:49 --> Database Driver Class Initialized
INFO - 2018-08-29 17:17:49 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 17:17:49 --> Form Validation Class Initialized
INFO - 2018-08-29 17:17:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-29 17:17:49 --> Database Driver Class Initialized
INFO - 2018-08-29 17:17:49 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 17:17:50 --> Config Class Initialized
INFO - 2018-08-29 17:17:50 --> Hooks Class Initialized
DEBUG - 2018-08-29 17:17:50 --> UTF-8 Support Enabled
INFO - 2018-08-29 17:17:50 --> Utf8 Class Initialized
INFO - 2018-08-29 17:17:50 --> URI Class Initialized
INFO - 2018-08-29 17:17:50 --> Router Class Initialized
INFO - 2018-08-29 17:17:50 --> Output Class Initialized
INFO - 2018-08-29 17:17:50 --> Security Class Initialized
DEBUG - 2018-08-29 17:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-29 17:17:50 --> CSRF cookie sent
INFO - 2018-08-29 17:17:50 --> Input Class Initialized
INFO - 2018-08-29 17:17:50 --> Language Class Initialized
INFO - 2018-08-29 17:17:50 --> Loader Class Initialized
INFO - 2018-08-29 17:17:50 --> Helper loaded: url_helper
INFO - 2018-08-29 17:17:50 --> Helper loaded: form_helper
INFO - 2018-08-29 17:17:50 --> Helper loaded: language_helper
DEBUG - 2018-08-29 17:17:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-29 17:17:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-29 17:17:50 --> User Agent Class Initialized
INFO - 2018-08-29 17:17:50 --> Controller Class Initialized
INFO - 2018-08-29 17:17:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-29 17:17:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-29 17:17:50 --> Pixel_Model class loaded
INFO - 2018-08-29 17:17:50 --> Database Driver Class Initialized
INFO - 2018-08-29 17:17:50 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 17:17:50 --> Database Driver Class Initialized
INFO - 2018-08-29 17:17:50 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 17:17:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-29 17:17:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-29 17:17:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-29 17:17:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-29 17:17:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-29 17:17:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-29 17:17:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-08-29 17:17:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-29 17:17:50 --> Final output sent to browser
DEBUG - 2018-08-29 17:17:50 --> Total execution time: 0.0404
INFO - 2018-08-29 17:18:36 --> Config Class Initialized
INFO - 2018-08-29 17:18:36 --> Hooks Class Initialized
DEBUG - 2018-08-29 17:18:36 --> UTF-8 Support Enabled
INFO - 2018-08-29 17:18:36 --> Utf8 Class Initialized
INFO - 2018-08-29 17:18:36 --> URI Class Initialized
INFO - 2018-08-29 17:18:36 --> Router Class Initialized
INFO - 2018-08-29 17:18:36 --> Output Class Initialized
INFO - 2018-08-29 17:18:36 --> Security Class Initialized
DEBUG - 2018-08-29 17:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-29 17:18:36 --> CSRF cookie sent
INFO - 2018-08-29 17:18:36 --> CSRF token verified
INFO - 2018-08-29 17:18:36 --> Input Class Initialized
INFO - 2018-08-29 17:18:36 --> Language Class Initialized
INFO - 2018-08-29 17:18:36 --> Loader Class Initialized
INFO - 2018-08-29 17:18:36 --> Helper loaded: url_helper
INFO - 2018-08-29 17:18:36 --> Helper loaded: form_helper
INFO - 2018-08-29 17:18:36 --> Helper loaded: language_helper
DEBUG - 2018-08-29 17:18:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-29 17:18:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-29 17:18:36 --> User Agent Class Initialized
INFO - 2018-08-29 17:18:36 --> Controller Class Initialized
INFO - 2018-08-29 17:18:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-29 17:18:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-29 17:18:36 --> Pixel_Model class loaded
INFO - 2018-08-29 17:18:36 --> Database Driver Class Initialized
INFO - 2018-08-29 17:18:36 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 17:18:36 --> Form Validation Class Initialized
INFO - 2018-08-29 17:18:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-29 17:18:36 --> Database Driver Class Initialized
INFO - 2018-08-29 17:18:36 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 17:18:37 --> Config Class Initialized
INFO - 2018-08-29 17:18:37 --> Hooks Class Initialized
DEBUG - 2018-08-29 17:18:37 --> UTF-8 Support Enabled
INFO - 2018-08-29 17:18:37 --> Utf8 Class Initialized
INFO - 2018-08-29 17:18:37 --> URI Class Initialized
INFO - 2018-08-29 17:18:37 --> Router Class Initialized
INFO - 2018-08-29 17:18:37 --> Output Class Initialized
INFO - 2018-08-29 17:18:37 --> Security Class Initialized
DEBUG - 2018-08-29 17:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-29 17:18:37 --> CSRF cookie sent
INFO - 2018-08-29 17:18:37 --> Input Class Initialized
INFO - 2018-08-29 17:18:37 --> Language Class Initialized
INFO - 2018-08-29 17:18:37 --> Loader Class Initialized
INFO - 2018-08-29 17:18:37 --> Helper loaded: url_helper
INFO - 2018-08-29 17:18:37 --> Helper loaded: form_helper
INFO - 2018-08-29 17:18:37 --> Helper loaded: language_helper
DEBUG - 2018-08-29 17:18:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-29 17:18:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-29 17:18:37 --> User Agent Class Initialized
INFO - 2018-08-29 17:18:37 --> Controller Class Initialized
INFO - 2018-08-29 17:18:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-29 17:18:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-29 17:18:37 --> Pixel_Model class loaded
INFO - 2018-08-29 17:18:37 --> Database Driver Class Initialized
INFO - 2018-08-29 17:18:37 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 17:18:37 --> Database Driver Class Initialized
INFO - 2018-08-29 17:18:37 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 17:18:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-29 17:18:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-29 17:18:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-29 17:18:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-29 17:18:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-29 17:18:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-29 17:18:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-08-29 17:18:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-29 17:18:37 --> Final output sent to browser
DEBUG - 2018-08-29 17:18:37 --> Total execution time: 0.0470
INFO - 2018-08-29 17:19:13 --> Config Class Initialized
INFO - 2018-08-29 17:19:13 --> Hooks Class Initialized
DEBUG - 2018-08-29 17:19:13 --> UTF-8 Support Enabled
INFO - 2018-08-29 17:19:13 --> Utf8 Class Initialized
INFO - 2018-08-29 17:19:13 --> URI Class Initialized
INFO - 2018-08-29 17:19:13 --> Router Class Initialized
INFO - 2018-08-29 17:19:13 --> Output Class Initialized
INFO - 2018-08-29 17:19:13 --> Security Class Initialized
DEBUG - 2018-08-29 17:19:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-29 17:19:13 --> CSRF cookie sent
INFO - 2018-08-29 17:19:13 --> CSRF token verified
INFO - 2018-08-29 17:19:13 --> Input Class Initialized
INFO - 2018-08-29 17:19:13 --> Language Class Initialized
INFO - 2018-08-29 17:19:13 --> Loader Class Initialized
INFO - 2018-08-29 17:19:13 --> Helper loaded: url_helper
INFO - 2018-08-29 17:19:13 --> Helper loaded: form_helper
INFO - 2018-08-29 17:19:13 --> Helper loaded: language_helper
DEBUG - 2018-08-29 17:19:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-29 17:19:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-29 17:19:13 --> User Agent Class Initialized
INFO - 2018-08-29 17:19:13 --> Controller Class Initialized
INFO - 2018-08-29 17:19:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-29 17:19:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-29 17:19:13 --> Pixel_Model class loaded
INFO - 2018-08-29 17:19:13 --> Database Driver Class Initialized
INFO - 2018-08-29 17:19:13 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 17:19:13 --> Form Validation Class Initialized
INFO - 2018-08-29 17:19:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-29 17:19:13 --> Database Driver Class Initialized
INFO - 2018-08-29 17:19:13 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 17:19:14 --> Config Class Initialized
INFO - 2018-08-29 17:19:14 --> Hooks Class Initialized
DEBUG - 2018-08-29 17:19:14 --> UTF-8 Support Enabled
INFO - 2018-08-29 17:19:14 --> Utf8 Class Initialized
INFO - 2018-08-29 17:19:14 --> URI Class Initialized
INFO - 2018-08-29 17:19:14 --> Router Class Initialized
INFO - 2018-08-29 17:19:14 --> Output Class Initialized
INFO - 2018-08-29 17:19:14 --> Security Class Initialized
DEBUG - 2018-08-29 17:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-29 17:19:14 --> CSRF cookie sent
INFO - 2018-08-29 17:19:14 --> Input Class Initialized
INFO - 2018-08-29 17:19:14 --> Language Class Initialized
INFO - 2018-08-29 17:19:14 --> Loader Class Initialized
INFO - 2018-08-29 17:19:14 --> Helper loaded: url_helper
INFO - 2018-08-29 17:19:14 --> Helper loaded: form_helper
INFO - 2018-08-29 17:19:14 --> Helper loaded: language_helper
DEBUG - 2018-08-29 17:19:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-29 17:19:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-29 17:19:14 --> User Agent Class Initialized
INFO - 2018-08-29 17:19:14 --> Controller Class Initialized
INFO - 2018-08-29 17:19:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-29 17:19:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-29 17:19:14 --> Pixel_Model class loaded
INFO - 2018-08-29 17:19:14 --> Database Driver Class Initialized
INFO - 2018-08-29 17:19:14 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 17:19:14 --> Database Driver Class Initialized
INFO - 2018-08-29 17:19:14 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 17:19:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-29 17:19:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-29 17:19:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-29 17:19:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-29 17:19:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-29 17:19:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-29 17:19:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_owner.php
INFO - 2018-08-29 17:19:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-29 17:19:14 --> Final output sent to browser
DEBUG - 2018-08-29 17:19:14 --> Total execution time: 0.0454
INFO - 2018-08-29 17:19:19 --> Config Class Initialized
INFO - 2018-08-29 17:19:19 --> Hooks Class Initialized
DEBUG - 2018-08-29 17:19:19 --> UTF-8 Support Enabled
INFO - 2018-08-29 17:19:19 --> Utf8 Class Initialized
INFO - 2018-08-29 17:19:19 --> URI Class Initialized
INFO - 2018-08-29 17:19:19 --> Router Class Initialized
INFO - 2018-08-29 17:19:19 --> Output Class Initialized
INFO - 2018-08-29 17:19:19 --> Security Class Initialized
DEBUG - 2018-08-29 17:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-29 17:19:19 --> CSRF cookie sent
INFO - 2018-08-29 17:19:19 --> CSRF token verified
INFO - 2018-08-29 17:19:19 --> Input Class Initialized
INFO - 2018-08-29 17:19:19 --> Language Class Initialized
INFO - 2018-08-29 17:19:19 --> Loader Class Initialized
INFO - 2018-08-29 17:19:19 --> Helper loaded: url_helper
INFO - 2018-08-29 17:19:19 --> Helper loaded: form_helper
INFO - 2018-08-29 17:19:19 --> Helper loaded: language_helper
DEBUG - 2018-08-29 17:19:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-29 17:19:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-29 17:19:19 --> User Agent Class Initialized
INFO - 2018-08-29 17:19:19 --> Controller Class Initialized
INFO - 2018-08-29 17:19:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-29 17:19:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-29 17:19:19 --> Pixel_Model class loaded
INFO - 2018-08-29 17:19:19 --> Database Driver Class Initialized
INFO - 2018-08-29 17:19:19 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 17:19:19 --> Form Validation Class Initialized
INFO - 2018-08-29 17:19:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-29 17:19:19 --> Database Driver Class Initialized
INFO - 2018-08-29 17:19:19 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 17:19:20 --> Config Class Initialized
INFO - 2018-08-29 17:19:20 --> Hooks Class Initialized
DEBUG - 2018-08-29 17:19:20 --> UTF-8 Support Enabled
INFO - 2018-08-29 17:19:20 --> Utf8 Class Initialized
INFO - 2018-08-29 17:19:20 --> URI Class Initialized
INFO - 2018-08-29 17:19:20 --> Router Class Initialized
INFO - 2018-08-29 17:19:20 --> Output Class Initialized
INFO - 2018-08-29 17:19:20 --> Security Class Initialized
DEBUG - 2018-08-29 17:19:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-29 17:19:20 --> CSRF cookie sent
INFO - 2018-08-29 17:19:20 --> Input Class Initialized
INFO - 2018-08-29 17:19:20 --> Language Class Initialized
INFO - 2018-08-29 17:19:20 --> Loader Class Initialized
INFO - 2018-08-29 17:19:20 --> Helper loaded: url_helper
INFO - 2018-08-29 17:19:20 --> Helper loaded: form_helper
INFO - 2018-08-29 17:19:20 --> Helper loaded: language_helper
DEBUG - 2018-08-29 17:19:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-29 17:19:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-29 17:19:20 --> User Agent Class Initialized
INFO - 2018-08-29 17:19:20 --> Controller Class Initialized
INFO - 2018-08-29 17:19:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-29 17:19:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-29 17:19:20 --> Pixel_Model class loaded
INFO - 2018-08-29 17:19:20 --> Database Driver Class Initialized
INFO - 2018-08-29 17:19:20 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 17:19:20 --> Database Driver Class Initialized
INFO - 2018-08-29 17:19:20 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 17:19:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-29 17:19:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-29 17:19:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-29 17:19:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-29 17:19:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-29 17:19:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-29 17:19:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_value.php
INFO - 2018-08-29 17:19:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-29 17:19:20 --> Final output sent to browser
DEBUG - 2018-08-29 17:19:20 --> Total execution time: 0.0474
INFO - 2018-08-29 17:19:34 --> Config Class Initialized
INFO - 2018-08-29 17:19:34 --> Hooks Class Initialized
DEBUG - 2018-08-29 17:19:34 --> UTF-8 Support Enabled
INFO - 2018-08-29 17:19:34 --> Utf8 Class Initialized
INFO - 2018-08-29 17:19:34 --> URI Class Initialized
INFO - 2018-08-29 17:19:34 --> Router Class Initialized
INFO - 2018-08-29 17:19:34 --> Output Class Initialized
INFO - 2018-08-29 17:19:34 --> Security Class Initialized
DEBUG - 2018-08-29 17:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-29 17:19:34 --> CSRF cookie sent
INFO - 2018-08-29 17:19:34 --> CSRF token verified
INFO - 2018-08-29 17:19:34 --> Input Class Initialized
INFO - 2018-08-29 17:19:34 --> Language Class Initialized
INFO - 2018-08-29 17:19:34 --> Loader Class Initialized
INFO - 2018-08-29 17:19:34 --> Helper loaded: url_helper
INFO - 2018-08-29 17:19:34 --> Helper loaded: form_helper
INFO - 2018-08-29 17:19:34 --> Helper loaded: language_helper
DEBUG - 2018-08-29 17:19:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-29 17:19:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-29 17:19:34 --> User Agent Class Initialized
INFO - 2018-08-29 17:19:34 --> Controller Class Initialized
INFO - 2018-08-29 17:19:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-29 17:19:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-29 17:19:34 --> Pixel_Model class loaded
INFO - 2018-08-29 17:19:34 --> Database Driver Class Initialized
INFO - 2018-08-29 17:19:34 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 17:19:34 --> Form Validation Class Initialized
INFO - 2018-08-29 17:19:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-29 17:19:34 --> Database Driver Class Initialized
INFO - 2018-08-29 17:19:34 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 17:19:35 --> Config Class Initialized
INFO - 2018-08-29 17:19:35 --> Hooks Class Initialized
DEBUG - 2018-08-29 17:19:35 --> UTF-8 Support Enabled
INFO - 2018-08-29 17:19:35 --> Utf8 Class Initialized
INFO - 2018-08-29 17:19:35 --> URI Class Initialized
INFO - 2018-08-29 17:19:35 --> Router Class Initialized
INFO - 2018-08-29 17:19:35 --> Output Class Initialized
INFO - 2018-08-29 17:19:35 --> Security Class Initialized
DEBUG - 2018-08-29 17:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-29 17:19:35 --> CSRF cookie sent
INFO - 2018-08-29 17:19:35 --> Input Class Initialized
INFO - 2018-08-29 17:19:35 --> Language Class Initialized
INFO - 2018-08-29 17:19:35 --> Loader Class Initialized
INFO - 2018-08-29 17:19:35 --> Helper loaded: url_helper
INFO - 2018-08-29 17:19:35 --> Helper loaded: form_helper
INFO - 2018-08-29 17:19:35 --> Helper loaded: language_helper
DEBUG - 2018-08-29 17:19:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-29 17:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-29 17:19:35 --> User Agent Class Initialized
INFO - 2018-08-29 17:19:35 --> Controller Class Initialized
INFO - 2018-08-29 17:19:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-29 17:19:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-29 17:19:35 --> Pixel_Model class loaded
INFO - 2018-08-29 17:19:35 --> Database Driver Class Initialized
INFO - 2018-08-29 17:19:35 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 17:19:37 --> Config Class Initialized
INFO - 2018-08-29 17:19:37 --> Hooks Class Initialized
DEBUG - 2018-08-29 17:19:37 --> UTF-8 Support Enabled
INFO - 2018-08-29 17:19:37 --> Utf8 Class Initialized
INFO - 2018-08-29 17:19:37 --> URI Class Initialized
INFO - 2018-08-29 17:19:37 --> Router Class Initialized
INFO - 2018-08-29 17:19:37 --> Output Class Initialized
INFO - 2018-08-29 17:19:37 --> Security Class Initialized
DEBUG - 2018-08-29 17:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-29 17:19:37 --> CSRF cookie sent
INFO - 2018-08-29 17:19:37 --> Input Class Initialized
INFO - 2018-08-29 17:19:37 --> Language Class Initialized
INFO - 2018-08-29 17:19:37 --> Loader Class Initialized
INFO - 2018-08-29 17:19:37 --> Helper loaded: url_helper
INFO - 2018-08-29 17:19:37 --> Helper loaded: form_helper
INFO - 2018-08-29 17:19:37 --> Helper loaded: language_helper
DEBUG - 2018-08-29 17:19:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-29 17:19:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-29 17:19:37 --> User Agent Class Initialized
INFO - 2018-08-29 17:19:37 --> Controller Class Initialized
INFO - 2018-08-29 17:19:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-29 17:19:37 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-08-29 17:19:37 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-08-29 17:19:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-29 17:19:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-29 17:19:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-29 17:19:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-08-29 17:19:37 --> Could not find the language line "req_email"
INFO - 2018-08-29 17:19:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-08-29 17:19:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-29 17:19:37 --> Final output sent to browser
DEBUG - 2018-08-29 17:19:37 --> Total execution time: 0.0305
INFO - 2018-08-29 17:20:20 --> Config Class Initialized
INFO - 2018-08-29 17:20:20 --> Hooks Class Initialized
DEBUG - 2018-08-29 17:20:20 --> UTF-8 Support Enabled
INFO - 2018-08-29 17:20:20 --> Utf8 Class Initialized
INFO - 2018-08-29 17:20:20 --> URI Class Initialized
INFO - 2018-08-29 17:20:20 --> Router Class Initialized
INFO - 2018-08-29 17:20:20 --> Output Class Initialized
INFO - 2018-08-29 17:20:20 --> Security Class Initialized
DEBUG - 2018-08-29 17:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-29 17:20:20 --> CSRF cookie sent
INFO - 2018-08-29 17:20:20 --> CSRF token verified
INFO - 2018-08-29 17:20:20 --> Input Class Initialized
INFO - 2018-08-29 17:20:20 --> Language Class Initialized
INFO - 2018-08-29 17:20:20 --> Loader Class Initialized
INFO - 2018-08-29 17:20:20 --> Helper loaded: url_helper
INFO - 2018-08-29 17:20:20 --> Helper loaded: form_helper
INFO - 2018-08-29 17:20:20 --> Helper loaded: language_helper
DEBUG - 2018-08-29 17:20:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-29 17:20:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-29 17:20:20 --> User Agent Class Initialized
INFO - 2018-08-29 17:20:20 --> Controller Class Initialized
INFO - 2018-08-29 17:20:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-29 17:20:20 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-08-29 17:20:20 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-08-29 17:20:20 --> Form Validation Class Initialized
INFO - 2018-08-29 17:20:20 --> Pixel_Model class loaded
INFO - 2018-08-29 17:20:20 --> Database Driver Class Initialized
INFO - 2018-08-29 17:20:20 --> Model "AuthenticationModel" initialized
INFO - 2018-08-29 17:20:22 --> Config Class Initialized
INFO - 2018-08-29 17:20:22 --> Hooks Class Initialized
DEBUG - 2018-08-29 17:20:22 --> UTF-8 Support Enabled
INFO - 2018-08-29 17:20:22 --> Utf8 Class Initialized
INFO - 2018-08-29 17:20:22 --> URI Class Initialized
INFO - 2018-08-29 17:20:22 --> Router Class Initialized
INFO - 2018-08-29 17:20:22 --> Output Class Initialized
INFO - 2018-08-29 17:20:22 --> Security Class Initialized
DEBUG - 2018-08-29 17:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-29 17:20:22 --> CSRF cookie sent
INFO - 2018-08-29 17:20:22 --> Input Class Initialized
INFO - 2018-08-29 17:20:22 --> Language Class Initialized
INFO - 2018-08-29 17:20:22 --> Loader Class Initialized
INFO - 2018-08-29 17:20:22 --> Helper loaded: url_helper
INFO - 2018-08-29 17:20:22 --> Helper loaded: form_helper
INFO - 2018-08-29 17:20:22 --> Helper loaded: language_helper
DEBUG - 2018-08-29 17:20:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-29 17:20:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-29 17:20:22 --> User Agent Class Initialized
INFO - 2018-08-29 17:20:22 --> Controller Class Initialized
INFO - 2018-08-29 17:20:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-29 17:20:22 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-08-29 17:20:22 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-08-29 17:20:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-29 17:20:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-29 17:20:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-29 17:20:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-29 17:20:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_soft_error.php
ERROR - 2018-08-29 17:20:22 --> Could not find the language line "req_email"
INFO - 2018-08-29 17:20:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-08-29 17:20:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-29 17:20:22 --> Final output sent to browser
DEBUG - 2018-08-29 17:20:22 --> Total execution time: 0.0236
INFO - 2018-08-29 17:21:03 --> Config Class Initialized
INFO - 2018-08-29 17:21:03 --> Hooks Class Initialized
DEBUG - 2018-08-29 17:21:03 --> UTF-8 Support Enabled
INFO - 2018-08-29 17:21:03 --> Utf8 Class Initialized
INFO - 2018-08-29 17:21:03 --> URI Class Initialized
INFO - 2018-08-29 17:21:03 --> Router Class Initialized
INFO - 2018-08-29 17:21:03 --> Output Class Initialized
INFO - 2018-08-29 17:21:03 --> Security Class Initialized
DEBUG - 2018-08-29 17:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-29 17:21:03 --> CSRF cookie sent
INFO - 2018-08-29 17:21:03 --> CSRF token verified
INFO - 2018-08-29 17:21:03 --> Input Class Initialized
INFO - 2018-08-29 17:21:03 --> Language Class Initialized
INFO - 2018-08-29 17:21:03 --> Loader Class Initialized
INFO - 2018-08-29 17:21:03 --> Helper loaded: url_helper
INFO - 2018-08-29 17:21:03 --> Helper loaded: form_helper
INFO - 2018-08-29 17:21:03 --> Helper loaded: language_helper
DEBUG - 2018-08-29 17:21:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-29 17:21:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-29 17:21:03 --> User Agent Class Initialized
INFO - 2018-08-29 17:21:03 --> Controller Class Initialized
INFO - 2018-08-29 17:21:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-29 17:21:03 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-08-29 17:21:03 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-08-29 17:21:03 --> Form Validation Class Initialized
INFO - 2018-08-29 17:21:03 --> Pixel_Model class loaded
INFO - 2018-08-29 17:21:03 --> Database Driver Class Initialized
INFO - 2018-08-29 17:21:03 --> Model "AuthenticationModel" initialized
INFO - 2018-08-29 17:21:03 --> Database Driver Class Initialized
INFO - 2018-08-29 17:21:03 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 17:21:05 --> Config Class Initialized
INFO - 2018-08-29 17:21:05 --> Hooks Class Initialized
DEBUG - 2018-08-29 17:21:05 --> UTF-8 Support Enabled
INFO - 2018-08-29 17:21:05 --> Utf8 Class Initialized
INFO - 2018-08-29 17:21:05 --> URI Class Initialized
INFO - 2018-08-29 17:21:05 --> Router Class Initialized
INFO - 2018-08-29 17:21:05 --> Output Class Initialized
INFO - 2018-08-29 17:21:05 --> Security Class Initialized
DEBUG - 2018-08-29 17:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-29 17:21:05 --> CSRF cookie sent
INFO - 2018-08-29 17:21:05 --> Input Class Initialized
INFO - 2018-08-29 17:21:05 --> Language Class Initialized
INFO - 2018-08-29 17:21:05 --> Loader Class Initialized
INFO - 2018-08-29 17:21:05 --> Helper loaded: url_helper
INFO - 2018-08-29 17:21:05 --> Helper loaded: form_helper
INFO - 2018-08-29 17:21:05 --> Helper loaded: language_helper
DEBUG - 2018-08-29 17:21:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-29 17:21:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-29 17:21:05 --> User Agent Class Initialized
INFO - 2018-08-29 17:21:05 --> Controller Class Initialized
INFO - 2018-08-29 17:21:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-29 17:21:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-29 17:21:05 --> Pixel_Model class loaded
INFO - 2018-08-29 17:21:05 --> Database Driver Class Initialized
INFO - 2018-08-29 17:21:05 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 17:21:05 --> Database Driver Class Initialized
INFO - 2018-08-29 17:21:05 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 17:21:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-29 17:21:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-08-29 17:21:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-29 17:21:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-29 17:21:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-29 17:21:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-29 17:21:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-29 17:21:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/marriage.php
INFO - 2018-08-29 17:21:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-29 17:21:05 --> Final output sent to browser
DEBUG - 2018-08-29 17:21:05 --> Total execution time: 0.0534
INFO - 2018-08-29 17:21:12 --> Config Class Initialized
INFO - 2018-08-29 17:21:12 --> Hooks Class Initialized
DEBUG - 2018-08-29 17:21:12 --> UTF-8 Support Enabled
INFO - 2018-08-29 17:21:12 --> Utf8 Class Initialized
INFO - 2018-08-29 17:21:12 --> URI Class Initialized
INFO - 2018-08-29 17:21:12 --> Router Class Initialized
INFO - 2018-08-29 17:21:12 --> Output Class Initialized
INFO - 2018-08-29 17:21:12 --> Security Class Initialized
DEBUG - 2018-08-29 17:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-29 17:21:12 --> CSRF cookie sent
INFO - 2018-08-29 17:21:12 --> CSRF token verified
INFO - 2018-08-29 17:21:12 --> Input Class Initialized
INFO - 2018-08-29 17:21:12 --> Language Class Initialized
INFO - 2018-08-29 17:21:12 --> Loader Class Initialized
INFO - 2018-08-29 17:21:12 --> Helper loaded: url_helper
INFO - 2018-08-29 17:21:12 --> Helper loaded: form_helper
INFO - 2018-08-29 17:21:12 --> Helper loaded: language_helper
DEBUG - 2018-08-29 17:21:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-29 17:21:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-29 17:21:12 --> User Agent Class Initialized
INFO - 2018-08-29 17:21:12 --> Controller Class Initialized
INFO - 2018-08-29 17:21:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-29 17:21:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-29 17:21:12 --> Pixel_Model class loaded
INFO - 2018-08-29 17:21:12 --> Database Driver Class Initialized
INFO - 2018-08-29 17:21:12 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 17:21:12 --> Form Validation Class Initialized
INFO - 2018-08-29 17:21:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-29 17:21:12 --> Database Driver Class Initialized
INFO - 2018-08-29 17:21:12 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 17:21:13 --> Config Class Initialized
INFO - 2018-08-29 17:21:13 --> Hooks Class Initialized
DEBUG - 2018-08-29 17:21:13 --> UTF-8 Support Enabled
INFO - 2018-08-29 17:21:13 --> Utf8 Class Initialized
INFO - 2018-08-29 17:21:13 --> URI Class Initialized
INFO - 2018-08-29 17:21:13 --> Router Class Initialized
INFO - 2018-08-29 17:21:13 --> Output Class Initialized
INFO - 2018-08-29 17:21:13 --> Security Class Initialized
DEBUG - 2018-08-29 17:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-29 17:21:13 --> CSRF cookie sent
INFO - 2018-08-29 17:21:13 --> Input Class Initialized
INFO - 2018-08-29 17:21:13 --> Language Class Initialized
INFO - 2018-08-29 17:21:13 --> Loader Class Initialized
INFO - 2018-08-29 17:21:13 --> Helper loaded: url_helper
INFO - 2018-08-29 17:21:13 --> Helper loaded: form_helper
INFO - 2018-08-29 17:21:13 --> Helper loaded: language_helper
DEBUG - 2018-08-29 17:21:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-29 17:21:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-29 17:21:13 --> User Agent Class Initialized
INFO - 2018-08-29 17:21:13 --> Controller Class Initialized
INFO - 2018-08-29 17:21:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-29 17:21:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-29 17:21:13 --> Pixel_Model class loaded
INFO - 2018-08-29 17:21:13 --> Database Driver Class Initialized
INFO - 2018-08-29 17:21:13 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 17:21:13 --> Database Driver Class Initialized
INFO - 2018-08-29 17:21:13 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 17:21:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-29 17:21:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-08-29 17:21:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-29 17:21:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-29 17:21:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-29 17:21:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-29 17:21:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-29 17:21:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/merriage_home_title.php
INFO - 2018-08-29 17:21:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-29 17:21:13 --> Final output sent to browser
DEBUG - 2018-08-29 17:21:13 --> Total execution time: 0.0644
INFO - 2018-08-29 17:21:18 --> Config Class Initialized
INFO - 2018-08-29 17:21:18 --> Hooks Class Initialized
DEBUG - 2018-08-29 17:21:18 --> UTF-8 Support Enabled
INFO - 2018-08-29 17:21:18 --> Utf8 Class Initialized
INFO - 2018-08-29 17:21:18 --> URI Class Initialized
INFO - 2018-08-29 17:21:18 --> Router Class Initialized
INFO - 2018-08-29 17:21:18 --> Output Class Initialized
INFO - 2018-08-29 17:21:18 --> Security Class Initialized
DEBUG - 2018-08-29 17:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-29 17:21:18 --> CSRF cookie sent
INFO - 2018-08-29 17:21:18 --> CSRF token verified
INFO - 2018-08-29 17:21:18 --> Input Class Initialized
INFO - 2018-08-29 17:21:18 --> Language Class Initialized
INFO - 2018-08-29 17:21:18 --> Loader Class Initialized
INFO - 2018-08-29 17:21:18 --> Helper loaded: url_helper
INFO - 2018-08-29 17:21:18 --> Helper loaded: form_helper
INFO - 2018-08-29 17:21:18 --> Helper loaded: language_helper
DEBUG - 2018-08-29 17:21:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-29 17:21:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-29 17:21:18 --> User Agent Class Initialized
INFO - 2018-08-29 17:21:18 --> Controller Class Initialized
INFO - 2018-08-29 17:21:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-29 17:21:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-29 17:21:18 --> Pixel_Model class loaded
INFO - 2018-08-29 17:21:18 --> Database Driver Class Initialized
INFO - 2018-08-29 17:21:18 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 17:21:18 --> Form Validation Class Initialized
INFO - 2018-08-29 17:21:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-29 17:21:18 --> Database Driver Class Initialized
INFO - 2018-08-29 17:21:18 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 17:21:19 --> Config Class Initialized
INFO - 2018-08-29 17:21:19 --> Hooks Class Initialized
DEBUG - 2018-08-29 17:21:19 --> UTF-8 Support Enabled
INFO - 2018-08-29 17:21:19 --> Utf8 Class Initialized
INFO - 2018-08-29 17:21:19 --> URI Class Initialized
INFO - 2018-08-29 17:21:19 --> Router Class Initialized
INFO - 2018-08-29 17:21:19 --> Output Class Initialized
INFO - 2018-08-29 17:21:19 --> Security Class Initialized
DEBUG - 2018-08-29 17:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-29 17:21:19 --> CSRF cookie sent
INFO - 2018-08-29 17:21:19 --> Input Class Initialized
INFO - 2018-08-29 17:21:19 --> Language Class Initialized
INFO - 2018-08-29 17:21:19 --> Loader Class Initialized
INFO - 2018-08-29 17:21:19 --> Helper loaded: url_helper
INFO - 2018-08-29 17:21:19 --> Helper loaded: form_helper
INFO - 2018-08-29 17:21:19 --> Helper loaded: language_helper
DEBUG - 2018-08-29 17:21:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-29 17:21:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-29 17:21:19 --> User Agent Class Initialized
INFO - 2018-08-29 17:21:19 --> Controller Class Initialized
INFO - 2018-08-29 17:21:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-29 17:21:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-29 17:21:19 --> Pixel_Model class loaded
INFO - 2018-08-29 17:21:19 --> Database Driver Class Initialized
INFO - 2018-08-29 17:21:19 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 17:21:19 --> Database Driver Class Initialized
INFO - 2018-08-29 17:21:19 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 17:21:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-29 17:21:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-08-29 17:21:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-29 17:21:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-29 17:21:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-29 17:21:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-29 17:21:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-29 17:21:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-08-29 17:21:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-29 17:21:19 --> Final output sent to browser
DEBUG - 2018-08-29 17:21:19 --> Total execution time: 0.0575
INFO - 2018-08-29 17:21:24 --> Config Class Initialized
INFO - 2018-08-29 17:21:24 --> Hooks Class Initialized
DEBUG - 2018-08-29 17:21:24 --> UTF-8 Support Enabled
INFO - 2018-08-29 17:21:24 --> Utf8 Class Initialized
INFO - 2018-08-29 17:21:24 --> URI Class Initialized
INFO - 2018-08-29 17:21:24 --> Router Class Initialized
INFO - 2018-08-29 17:21:24 --> Output Class Initialized
INFO - 2018-08-29 17:21:24 --> Security Class Initialized
DEBUG - 2018-08-29 17:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-29 17:21:24 --> CSRF cookie sent
INFO - 2018-08-29 17:21:24 --> CSRF token verified
INFO - 2018-08-29 17:21:24 --> Input Class Initialized
INFO - 2018-08-29 17:21:24 --> Language Class Initialized
INFO - 2018-08-29 17:21:24 --> Loader Class Initialized
INFO - 2018-08-29 17:21:24 --> Helper loaded: url_helper
INFO - 2018-08-29 17:21:24 --> Helper loaded: form_helper
INFO - 2018-08-29 17:21:24 --> Helper loaded: language_helper
DEBUG - 2018-08-29 17:21:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-29 17:21:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-29 17:21:24 --> User Agent Class Initialized
INFO - 2018-08-29 17:21:24 --> Controller Class Initialized
INFO - 2018-08-29 17:21:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-29 17:21:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-29 17:21:24 --> Pixel_Model class loaded
INFO - 2018-08-29 17:21:24 --> Database Driver Class Initialized
INFO - 2018-08-29 17:21:24 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 17:21:24 --> Form Validation Class Initialized
INFO - 2018-08-29 17:21:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-08-29 17:21:24 --> Database Driver Class Initialized
INFO - 2018-08-29 17:21:24 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 17:21:25 --> Config Class Initialized
INFO - 2018-08-29 17:21:25 --> Hooks Class Initialized
DEBUG - 2018-08-29 17:21:25 --> UTF-8 Support Enabled
INFO - 2018-08-29 17:21:25 --> Utf8 Class Initialized
INFO - 2018-08-29 17:21:25 --> URI Class Initialized
INFO - 2018-08-29 17:21:25 --> Router Class Initialized
INFO - 2018-08-29 17:21:25 --> Output Class Initialized
INFO - 2018-08-29 17:21:25 --> Security Class Initialized
DEBUG - 2018-08-29 17:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-29 17:21:25 --> CSRF cookie sent
INFO - 2018-08-29 17:21:25 --> Input Class Initialized
INFO - 2018-08-29 17:21:25 --> Language Class Initialized
INFO - 2018-08-29 17:21:25 --> Loader Class Initialized
INFO - 2018-08-29 17:21:25 --> Helper loaded: url_helper
INFO - 2018-08-29 17:21:25 --> Helper loaded: form_helper
INFO - 2018-08-29 17:21:25 --> Helper loaded: language_helper
DEBUG - 2018-08-29 17:21:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-29 17:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-29 17:21:25 --> User Agent Class Initialized
INFO - 2018-08-29 17:21:25 --> Controller Class Initialized
INFO - 2018-08-29 17:21:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-08-29 17:21:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-08-29 17:21:25 --> Pixel_Model class loaded
INFO - 2018-08-29 17:21:25 --> Database Driver Class Initialized
INFO - 2018-08-29 17:21:25 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 17:21:25 --> Database Driver Class Initialized
INFO - 2018-08-29 17:21:25 --> Model "QuestionsModel" initialized
INFO - 2018-08-29 17:21:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-08-29 17:21:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-08-29 17:21:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-08-29 17:21:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-08-29 17:21:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-08-29 17:21:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-08-29 17:21:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-08-29 17:21:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-08-29 17:21:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-08-29 17:21:25 --> Final output sent to browser
DEBUG - 2018-08-29 17:21:25 --> Total execution time: 0.0407

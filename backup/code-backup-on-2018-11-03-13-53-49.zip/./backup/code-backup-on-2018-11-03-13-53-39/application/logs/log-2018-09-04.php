<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-09-04 21:09:49 --> Config Class Initialized
INFO - 2018-09-04 21:09:49 --> Hooks Class Initialized
DEBUG - 2018-09-04 21:09:49 --> UTF-8 Support Enabled
INFO - 2018-09-04 21:09:49 --> Utf8 Class Initialized
INFO - 2018-09-04 21:09:49 --> URI Class Initialized
INFO - 2018-09-04 21:09:49 --> Router Class Initialized
INFO - 2018-09-04 21:09:49 --> Output Class Initialized
INFO - 2018-09-04 21:09:49 --> Security Class Initialized
DEBUG - 2018-09-04 21:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-04 21:09:49 --> CSRF cookie sent
INFO - 2018-09-04 21:09:49 --> Input Class Initialized
INFO - 2018-09-04 21:09:49 --> Language Class Initialized
INFO - 2018-09-04 21:09:49 --> Loader Class Initialized
INFO - 2018-09-04 21:09:49 --> Helper loaded: url_helper
INFO - 2018-09-04 21:09:49 --> Helper loaded: form_helper
INFO - 2018-09-04 21:09:49 --> Helper loaded: language_helper
DEBUG - 2018-09-04 21:09:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-04 21:09:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-04 21:09:49 --> User Agent Class Initialized
INFO - 2018-09-04 21:09:49 --> Controller Class Initialized
INFO - 2018-09-04 21:09:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-04 21:09:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-04 21:09:49 --> Pixel_Model class loaded
INFO - 2018-09-04 21:09:49 --> Database Driver Class Initialized
INFO - 2018-09-04 21:09:49 --> Model "QuestionsModel" initialized
INFO - 2018-09-04 21:09:50 --> Config Class Initialized
INFO - 2018-09-04 21:09:50 --> Hooks Class Initialized
DEBUG - 2018-09-04 21:09:50 --> UTF-8 Support Enabled
INFO - 2018-09-04 21:09:50 --> Utf8 Class Initialized
INFO - 2018-09-04 21:09:50 --> URI Class Initialized
INFO - 2018-09-04 21:09:50 --> Router Class Initialized
INFO - 2018-09-04 21:09:50 --> Output Class Initialized
INFO - 2018-09-04 21:09:50 --> Security Class Initialized
DEBUG - 2018-09-04 21:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-04 21:09:50 --> CSRF cookie sent
INFO - 2018-09-04 21:09:50 --> Input Class Initialized
INFO - 2018-09-04 21:09:50 --> Language Class Initialized
INFO - 2018-09-04 21:09:50 --> Loader Class Initialized
INFO - 2018-09-04 21:09:50 --> Helper loaded: url_helper
INFO - 2018-09-04 21:09:50 --> Helper loaded: form_helper
INFO - 2018-09-04 21:09:50 --> Helper loaded: language_helper
DEBUG - 2018-09-04 21:09:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-04 21:09:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-04 21:09:50 --> User Agent Class Initialized
INFO - 2018-09-04 21:09:50 --> Controller Class Initialized
INFO - 2018-09-04 21:09:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-04 21:09:50 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-09-04 21:09:50 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-09-04 21:09:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-04 21:09:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-04 21:09:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-04 21:09:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-09-04 21:09:50 --> Could not find the language line "req_email"
INFO - 2018-09-04 21:09:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-09-04 21:09:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-04 21:09:50 --> Final output sent to browser
DEBUG - 2018-09-04 21:09:50 --> Total execution time: 0.0338
INFO - 2018-09-04 21:16:11 --> Config Class Initialized
INFO - 2018-09-04 21:16:11 --> Hooks Class Initialized
DEBUG - 2018-09-04 21:16:11 --> UTF-8 Support Enabled
INFO - 2018-09-04 21:16:11 --> Utf8 Class Initialized
INFO - 2018-09-04 21:16:11 --> URI Class Initialized
INFO - 2018-09-04 21:16:11 --> Router Class Initialized
INFO - 2018-09-04 21:16:11 --> Output Class Initialized
INFO - 2018-09-04 21:16:11 --> Security Class Initialized
DEBUG - 2018-09-04 21:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-04 21:16:11 --> CSRF cookie sent
INFO - 2018-09-04 21:16:11 --> Input Class Initialized
INFO - 2018-09-04 21:16:11 --> Language Class Initialized
INFO - 2018-09-04 21:16:11 --> Loader Class Initialized
INFO - 2018-09-04 21:16:11 --> Helper loaded: url_helper
INFO - 2018-09-04 21:16:11 --> Helper loaded: form_helper
INFO - 2018-09-04 21:16:11 --> Helper loaded: language_helper
DEBUG - 2018-09-04 21:16:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-04 21:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-04 21:16:11 --> User Agent Class Initialized
INFO - 2018-09-04 21:16:11 --> Controller Class Initialized
INFO - 2018-09-04 21:16:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-04 21:16:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-04 21:16:11 --> Pixel_Model class loaded
INFO - 2018-09-04 21:16:11 --> Database Driver Class Initialized
INFO - 2018-09-04 21:16:11 --> Model "QuestionsModel" initialized
INFO - 2018-09-04 21:16:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-04 21:16:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-04 21:16:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-04 21:16:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-04 21:16:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-04 21:16:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-04 21:16:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-09-04 21:16:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-04 21:16:11 --> Final output sent to browser
DEBUG - 2018-09-04 21:16:11 --> Total execution time: 0.0519
INFO - 2018-09-04 21:22:33 --> Config Class Initialized
INFO - 2018-09-04 21:22:33 --> Hooks Class Initialized
DEBUG - 2018-09-04 21:22:33 --> UTF-8 Support Enabled
INFO - 2018-09-04 21:22:33 --> Utf8 Class Initialized
INFO - 2018-09-04 21:22:33 --> URI Class Initialized
INFO - 2018-09-04 21:22:33 --> Router Class Initialized
INFO - 2018-09-04 21:22:33 --> Output Class Initialized
INFO - 2018-09-04 21:22:33 --> Security Class Initialized
DEBUG - 2018-09-04 21:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-04 21:22:33 --> CSRF cookie sent
INFO - 2018-09-04 21:22:33 --> CSRF token verified
INFO - 2018-09-04 21:22:33 --> Input Class Initialized
INFO - 2018-09-04 21:22:33 --> Language Class Initialized
INFO - 2018-09-04 21:22:33 --> Loader Class Initialized
INFO - 2018-09-04 21:22:33 --> Helper loaded: url_helper
INFO - 2018-09-04 21:22:33 --> Helper loaded: form_helper
INFO - 2018-09-04 21:22:33 --> Helper loaded: language_helper
DEBUG - 2018-09-04 21:22:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-04 21:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-04 21:22:33 --> User Agent Class Initialized
INFO - 2018-09-04 21:22:33 --> Controller Class Initialized
INFO - 2018-09-04 21:22:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-04 21:22:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-04 21:22:33 --> Pixel_Model class loaded
INFO - 2018-09-04 21:22:33 --> Database Driver Class Initialized
INFO - 2018-09-04 21:22:33 --> Model "QuestionsModel" initialized
INFO - 2018-09-04 21:22:33 --> Database Driver Class Initialized
INFO - 2018-09-04 21:22:33 --> Model "QuestionsModel" initialized
INFO - 2018-09-04 21:22:33 --> Config Class Initialized
INFO - 2018-09-04 21:22:33 --> Hooks Class Initialized
DEBUG - 2018-09-04 21:22:33 --> UTF-8 Support Enabled
INFO - 2018-09-04 21:22:33 --> Utf8 Class Initialized
INFO - 2018-09-04 21:22:33 --> URI Class Initialized
INFO - 2018-09-04 21:22:33 --> Router Class Initialized
INFO - 2018-09-04 21:22:33 --> Output Class Initialized
INFO - 2018-09-04 21:22:33 --> Security Class Initialized
DEBUG - 2018-09-04 21:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-04 21:22:33 --> CSRF cookie sent
INFO - 2018-09-04 21:22:33 --> Input Class Initialized
INFO - 2018-09-04 21:22:33 --> Language Class Initialized
INFO - 2018-09-04 21:22:33 --> Loader Class Initialized
INFO - 2018-09-04 21:22:33 --> Helper loaded: url_helper
INFO - 2018-09-04 21:22:33 --> Helper loaded: form_helper
INFO - 2018-09-04 21:22:33 --> Helper loaded: language_helper
DEBUG - 2018-09-04 21:22:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-04 21:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-04 21:22:33 --> User Agent Class Initialized
INFO - 2018-09-04 21:22:33 --> Controller Class Initialized
INFO - 2018-09-04 21:22:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-04 21:22:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-04 21:22:33 --> Pixel_Model class loaded
INFO - 2018-09-04 21:22:33 --> Database Driver Class Initialized
INFO - 2018-09-04 21:22:33 --> Model "QuestionsModel" initialized
INFO - 2018-09-04 21:22:33 --> Database Driver Class Initialized
INFO - 2018-09-04 21:22:33 --> Model "QuestionsModel" initialized
INFO - 2018-09-04 21:22:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-04 21:22:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-04 21:22:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-04 21:22:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-04 21:22:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-04 21:22:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-04 21:22:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-09-04 21:22:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-04 21:22:33 --> Final output sent to browser
DEBUG - 2018-09-04 21:22:33 --> Total execution time: 0.0472
INFO - 2018-09-04 21:22:37 --> Config Class Initialized
INFO - 2018-09-04 21:22:37 --> Hooks Class Initialized
DEBUG - 2018-09-04 21:22:37 --> UTF-8 Support Enabled
INFO - 2018-09-04 21:22:37 --> Utf8 Class Initialized
INFO - 2018-09-04 21:22:37 --> URI Class Initialized
INFO - 2018-09-04 21:22:37 --> Router Class Initialized
INFO - 2018-09-04 21:22:37 --> Output Class Initialized
INFO - 2018-09-04 21:22:37 --> Security Class Initialized
DEBUG - 2018-09-04 21:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-04 21:22:37 --> CSRF cookie sent
INFO - 2018-09-04 21:22:37 --> CSRF token verified
INFO - 2018-09-04 21:22:37 --> Input Class Initialized
INFO - 2018-09-04 21:22:37 --> Language Class Initialized
INFO - 2018-09-04 21:22:37 --> Loader Class Initialized
INFO - 2018-09-04 21:22:37 --> Helper loaded: url_helper
INFO - 2018-09-04 21:22:37 --> Helper loaded: form_helper
INFO - 2018-09-04 21:22:37 --> Helper loaded: language_helper
DEBUG - 2018-09-04 21:22:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-04 21:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-04 21:22:37 --> User Agent Class Initialized
INFO - 2018-09-04 21:22:37 --> Controller Class Initialized
INFO - 2018-09-04 21:22:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-04 21:22:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-04 21:22:37 --> Pixel_Model class loaded
INFO - 2018-09-04 21:22:37 --> Database Driver Class Initialized
INFO - 2018-09-04 21:22:37 --> Model "QuestionsModel" initialized
INFO - 2018-09-04 21:22:37 --> Form Validation Class Initialized
INFO - 2018-09-04 21:22:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-04 21:22:37 --> Database Driver Class Initialized
INFO - 2018-09-04 21:22:37 --> Model "QuestionsModel" initialized
INFO - 2018-09-04 21:22:37 --> Config Class Initialized
INFO - 2018-09-04 21:22:37 --> Hooks Class Initialized
DEBUG - 2018-09-04 21:22:37 --> UTF-8 Support Enabled
INFO - 2018-09-04 21:22:37 --> Utf8 Class Initialized
INFO - 2018-09-04 21:22:37 --> URI Class Initialized
INFO - 2018-09-04 21:22:37 --> Router Class Initialized
INFO - 2018-09-04 21:22:37 --> Output Class Initialized
INFO - 2018-09-04 21:22:37 --> Security Class Initialized
DEBUG - 2018-09-04 21:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-04 21:22:37 --> CSRF cookie sent
INFO - 2018-09-04 21:22:37 --> Input Class Initialized
INFO - 2018-09-04 21:22:37 --> Language Class Initialized
INFO - 2018-09-04 21:22:37 --> Loader Class Initialized
INFO - 2018-09-04 21:22:37 --> Helper loaded: url_helper
INFO - 2018-09-04 21:22:37 --> Helper loaded: form_helper
INFO - 2018-09-04 21:22:37 --> Helper loaded: language_helper
DEBUG - 2018-09-04 21:22:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-04 21:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-04 21:22:37 --> User Agent Class Initialized
INFO - 2018-09-04 21:22:37 --> Controller Class Initialized
INFO - 2018-09-04 21:22:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-04 21:22:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-04 21:22:37 --> Pixel_Model class loaded
INFO - 2018-09-04 21:22:37 --> Database Driver Class Initialized
INFO - 2018-09-04 21:22:37 --> Model "QuestionsModel" initialized
INFO - 2018-09-04 21:22:37 --> Database Driver Class Initialized
INFO - 2018-09-04 21:22:37 --> Model "QuestionsModel" initialized
INFO - 2018-09-04 21:22:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-04 21:22:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-04 21:22:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-04 21:22:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-04 21:22:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-04 21:22:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-04 21:22:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-09-04 21:22:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-04 21:22:37 --> Final output sent to browser
DEBUG - 2018-09-04 21:22:37 --> Total execution time: 0.0380
INFO - 2018-09-04 21:28:02 --> Config Class Initialized
INFO - 2018-09-04 21:28:02 --> Hooks Class Initialized
DEBUG - 2018-09-04 21:28:02 --> UTF-8 Support Enabled
INFO - 2018-09-04 21:28:02 --> Utf8 Class Initialized
INFO - 2018-09-04 21:28:02 --> URI Class Initialized
DEBUG - 2018-09-04 21:28:02 --> No URI present. Default controller set.
INFO - 2018-09-04 21:28:02 --> Router Class Initialized
INFO - 2018-09-04 21:28:02 --> Output Class Initialized
INFO - 2018-09-04 21:28:02 --> Security Class Initialized
DEBUG - 2018-09-04 21:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-04 21:28:02 --> CSRF cookie sent
INFO - 2018-09-04 21:28:02 --> Input Class Initialized
INFO - 2018-09-04 21:28:02 --> Language Class Initialized
INFO - 2018-09-04 21:28:02 --> Loader Class Initialized
INFO - 2018-09-04 21:28:02 --> Helper loaded: url_helper
INFO - 2018-09-04 21:28:02 --> Helper loaded: form_helper
INFO - 2018-09-04 21:28:02 --> Helper loaded: language_helper
DEBUG - 2018-09-04 21:28:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-04 21:28:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-04 21:28:02 --> User Agent Class Initialized
INFO - 2018-09-04 21:28:02 --> Controller Class Initialized
INFO - 2018-09-04 21:28:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-04 21:28:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-04 21:28:02 --> Pixel_Model class loaded
INFO - 2018-09-04 21:28:02 --> Database Driver Class Initialized
INFO - 2018-09-04 21:28:02 --> Model "QuestionsModel" initialized
INFO - 2018-09-04 21:28:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-04 21:28:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-04 21:28:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-09-04 21:28:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-04 21:28:02 --> Final output sent to browser
DEBUG - 2018-09-04 21:28:02 --> Total execution time: 0.0429
INFO - 2018-09-04 21:28:50 --> Config Class Initialized
INFO - 2018-09-04 21:28:50 --> Hooks Class Initialized
DEBUG - 2018-09-04 21:28:50 --> UTF-8 Support Enabled
INFO - 2018-09-04 21:28:50 --> Utf8 Class Initialized
INFO - 2018-09-04 21:28:50 --> URI Class Initialized
INFO - 2018-09-04 21:28:50 --> Router Class Initialized
INFO - 2018-09-04 21:28:50 --> Output Class Initialized
INFO - 2018-09-04 21:28:50 --> Security Class Initialized
DEBUG - 2018-09-04 21:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-04 21:28:50 --> CSRF cookie sent
INFO - 2018-09-04 21:28:50 --> Input Class Initialized
INFO - 2018-09-04 21:28:50 --> Language Class Initialized
INFO - 2018-09-04 21:28:50 --> Loader Class Initialized
INFO - 2018-09-04 21:28:50 --> Helper loaded: url_helper
INFO - 2018-09-04 21:28:50 --> Helper loaded: form_helper
INFO - 2018-09-04 21:28:50 --> Helper loaded: language_helper
DEBUG - 2018-09-04 21:28:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-04 21:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-04 21:28:50 --> User Agent Class Initialized
INFO - 2018-09-04 21:28:50 --> Controller Class Initialized
INFO - 2018-09-04 21:28:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-04 21:28:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-04 21:28:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-04 21:28:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-04 21:28:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-04 21:28:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-04 21:28:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-09-04 21:28:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-04 21:28:50 --> Final output sent to browser
DEBUG - 2018-09-04 21:28:50 --> Total execution time: 0.0234
INFO - 2018-09-04 21:28:58 --> Config Class Initialized
INFO - 2018-09-04 21:28:58 --> Hooks Class Initialized
DEBUG - 2018-09-04 21:28:58 --> UTF-8 Support Enabled
INFO - 2018-09-04 21:28:58 --> Utf8 Class Initialized
INFO - 2018-09-04 21:28:58 --> URI Class Initialized
DEBUG - 2018-09-04 21:28:58 --> No URI present. Default controller set.
INFO - 2018-09-04 21:28:58 --> Router Class Initialized
INFO - 2018-09-04 21:28:58 --> Output Class Initialized
INFO - 2018-09-04 21:28:58 --> Security Class Initialized
DEBUG - 2018-09-04 21:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-04 21:28:58 --> CSRF cookie sent
INFO - 2018-09-04 21:28:58 --> Input Class Initialized
INFO - 2018-09-04 21:28:58 --> Language Class Initialized
INFO - 2018-09-04 21:28:58 --> Loader Class Initialized
INFO - 2018-09-04 21:28:58 --> Helper loaded: url_helper
INFO - 2018-09-04 21:28:58 --> Helper loaded: form_helper
INFO - 2018-09-04 21:28:58 --> Helper loaded: language_helper
DEBUG - 2018-09-04 21:28:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-04 21:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-04 21:28:58 --> User Agent Class Initialized
INFO - 2018-09-04 21:28:58 --> Controller Class Initialized
INFO - 2018-09-04 21:28:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-04 21:28:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-04 21:28:58 --> Pixel_Model class loaded
INFO - 2018-09-04 21:28:58 --> Database Driver Class Initialized
INFO - 2018-09-04 21:28:58 --> Model "QuestionsModel" initialized
INFO - 2018-09-04 21:28:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-04 21:28:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-04 21:28:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-09-04 21:28:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-04 21:28:58 --> Final output sent to browser
DEBUG - 2018-09-04 21:28:58 --> Total execution time: 0.0373
INFO - 2018-09-04 21:31:04 --> Config Class Initialized
INFO - 2018-09-04 21:31:04 --> Hooks Class Initialized
DEBUG - 2018-09-04 21:31:04 --> UTF-8 Support Enabled
INFO - 2018-09-04 21:31:04 --> Utf8 Class Initialized
INFO - 2018-09-04 21:31:04 --> URI Class Initialized
INFO - 2018-09-04 21:31:04 --> Router Class Initialized
INFO - 2018-09-04 21:31:04 --> Output Class Initialized
INFO - 2018-09-04 21:31:04 --> Security Class Initialized
DEBUG - 2018-09-04 21:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-04 21:31:04 --> CSRF cookie sent
INFO - 2018-09-04 21:31:04 --> CSRF token verified
INFO - 2018-09-04 21:31:04 --> Input Class Initialized
INFO - 2018-09-04 21:31:04 --> Language Class Initialized
INFO - 2018-09-04 21:31:04 --> Loader Class Initialized
INFO - 2018-09-04 21:31:04 --> Helper loaded: url_helper
INFO - 2018-09-04 21:31:04 --> Helper loaded: form_helper
INFO - 2018-09-04 21:31:04 --> Helper loaded: language_helper
DEBUG - 2018-09-04 21:31:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-04 21:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-04 21:31:04 --> User Agent Class Initialized
INFO - 2018-09-04 21:31:04 --> Controller Class Initialized
INFO - 2018-09-04 21:31:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-04 21:31:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-04 21:31:04 --> Pixel_Model class loaded
INFO - 2018-09-04 21:31:04 --> Database Driver Class Initialized
INFO - 2018-09-04 21:31:04 --> Model "QuestionsModel" initialized
INFO - 2018-09-04 21:31:04 --> Database Driver Class Initialized
INFO - 2018-09-04 21:31:04 --> Model "QuestionsModel" initialized
INFO - 2018-09-04 21:31:04 --> Config Class Initialized
INFO - 2018-09-04 21:31:04 --> Hooks Class Initialized
DEBUG - 2018-09-04 21:31:04 --> UTF-8 Support Enabled
INFO - 2018-09-04 21:31:04 --> Utf8 Class Initialized
INFO - 2018-09-04 21:31:04 --> URI Class Initialized
INFO - 2018-09-04 21:31:04 --> Router Class Initialized
INFO - 2018-09-04 21:31:04 --> Output Class Initialized
INFO - 2018-09-04 21:31:04 --> Security Class Initialized
DEBUG - 2018-09-04 21:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-04 21:31:04 --> CSRF cookie sent
INFO - 2018-09-04 21:31:04 --> Input Class Initialized
INFO - 2018-09-04 21:31:04 --> Language Class Initialized
INFO - 2018-09-04 21:31:04 --> Loader Class Initialized
INFO - 2018-09-04 21:31:04 --> Helper loaded: url_helper
INFO - 2018-09-04 21:31:04 --> Helper loaded: form_helper
INFO - 2018-09-04 21:31:04 --> Helper loaded: language_helper
DEBUG - 2018-09-04 21:31:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-04 21:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-04 21:31:04 --> User Agent Class Initialized
INFO - 2018-09-04 21:31:04 --> Controller Class Initialized
INFO - 2018-09-04 21:31:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-04 21:31:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-04 21:31:04 --> Pixel_Model class loaded
INFO - 2018-09-04 21:31:04 --> Database Driver Class Initialized
INFO - 2018-09-04 21:31:04 --> Model "QuestionsModel" initialized
INFO - 2018-09-04 21:31:04 --> Database Driver Class Initialized
INFO - 2018-09-04 21:31:04 --> Model "QuestionsModel" initialized
INFO - 2018-09-04 21:31:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-04 21:31:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-04 21:31:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-04 21:31:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-04 21:31:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-04 21:31:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-04 21:31:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-09-04 21:31:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-04 21:31:04 --> Final output sent to browser
DEBUG - 2018-09-04 21:31:04 --> Total execution time: 0.0679
INFO - 2018-09-04 21:31:13 --> Config Class Initialized
INFO - 2018-09-04 21:31:13 --> Hooks Class Initialized
DEBUG - 2018-09-04 21:31:13 --> UTF-8 Support Enabled
INFO - 2018-09-04 21:31:13 --> Utf8 Class Initialized
INFO - 2018-09-04 21:31:13 --> URI Class Initialized
INFO - 2018-09-04 21:31:13 --> Router Class Initialized
INFO - 2018-09-04 21:31:13 --> Output Class Initialized
INFO - 2018-09-04 21:31:13 --> Security Class Initialized
DEBUG - 2018-09-04 21:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-04 21:31:13 --> CSRF cookie sent
INFO - 2018-09-04 21:31:13 --> CSRF token verified
INFO - 2018-09-04 21:31:13 --> Input Class Initialized
INFO - 2018-09-04 21:31:13 --> Language Class Initialized
INFO - 2018-09-04 21:31:13 --> Loader Class Initialized
INFO - 2018-09-04 21:31:13 --> Helper loaded: url_helper
INFO - 2018-09-04 21:31:13 --> Helper loaded: form_helper
INFO - 2018-09-04 21:31:13 --> Helper loaded: language_helper
DEBUG - 2018-09-04 21:31:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-04 21:31:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-04 21:31:13 --> User Agent Class Initialized
INFO - 2018-09-04 21:31:13 --> Controller Class Initialized
INFO - 2018-09-04 21:31:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-04 21:31:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-04 21:31:13 --> Pixel_Model class loaded
INFO - 2018-09-04 21:31:13 --> Database Driver Class Initialized
INFO - 2018-09-04 21:31:13 --> Model "QuestionsModel" initialized
INFO - 2018-09-04 21:31:13 --> Form Validation Class Initialized
INFO - 2018-09-04 21:31:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-04 21:31:13 --> Database Driver Class Initialized
INFO - 2018-09-04 21:31:13 --> Model "QuestionsModel" initialized
INFO - 2018-09-04 21:31:13 --> Config Class Initialized
INFO - 2018-09-04 21:31:13 --> Hooks Class Initialized
DEBUG - 2018-09-04 21:31:13 --> UTF-8 Support Enabled
INFO - 2018-09-04 21:31:13 --> Utf8 Class Initialized
INFO - 2018-09-04 21:31:13 --> URI Class Initialized
INFO - 2018-09-04 21:31:13 --> Router Class Initialized
INFO - 2018-09-04 21:31:13 --> Output Class Initialized
INFO - 2018-09-04 21:31:13 --> Security Class Initialized
DEBUG - 2018-09-04 21:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-04 21:31:13 --> CSRF cookie sent
INFO - 2018-09-04 21:31:13 --> Input Class Initialized
INFO - 2018-09-04 21:31:13 --> Language Class Initialized
INFO - 2018-09-04 21:31:13 --> Loader Class Initialized
INFO - 2018-09-04 21:31:13 --> Helper loaded: url_helper
INFO - 2018-09-04 21:31:13 --> Helper loaded: form_helper
INFO - 2018-09-04 21:31:13 --> Helper loaded: language_helper
DEBUG - 2018-09-04 21:31:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-04 21:31:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-04 21:31:13 --> User Agent Class Initialized
INFO - 2018-09-04 21:31:13 --> Controller Class Initialized
INFO - 2018-09-04 21:31:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-04 21:31:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-04 21:31:13 --> Pixel_Model class loaded
INFO - 2018-09-04 21:31:13 --> Database Driver Class Initialized
INFO - 2018-09-04 21:31:13 --> Model "QuestionsModel" initialized
INFO - 2018-09-04 21:31:13 --> Database Driver Class Initialized
INFO - 2018-09-04 21:31:13 --> Model "QuestionsModel" initialized
INFO - 2018-09-04 21:31:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-04 21:31:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-04 21:31:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-09-04 21:31:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-04 21:31:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-04 21:31:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-04 21:31:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-04 21:31:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-09-04 21:31:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-04 21:31:13 --> Final output sent to browser
DEBUG - 2018-09-04 21:31:13 --> Total execution time: 0.0400
INFO - 2018-09-04 21:31:18 --> Config Class Initialized
INFO - 2018-09-04 21:31:18 --> Hooks Class Initialized
DEBUG - 2018-09-04 21:31:18 --> UTF-8 Support Enabled
INFO - 2018-09-04 21:31:18 --> Utf8 Class Initialized
INFO - 2018-09-04 21:31:18 --> URI Class Initialized
INFO - 2018-09-04 21:31:18 --> Router Class Initialized
INFO - 2018-09-04 21:31:18 --> Output Class Initialized
INFO - 2018-09-04 21:31:18 --> Security Class Initialized
DEBUG - 2018-09-04 21:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-04 21:31:18 --> CSRF cookie sent
INFO - 2018-09-04 21:31:18 --> Input Class Initialized
INFO - 2018-09-04 21:31:18 --> Language Class Initialized
INFO - 2018-09-04 21:31:18 --> Loader Class Initialized
INFO - 2018-09-04 21:31:18 --> Helper loaded: url_helper
INFO - 2018-09-04 21:31:18 --> Helper loaded: form_helper
INFO - 2018-09-04 21:31:18 --> Helper loaded: language_helper
DEBUG - 2018-09-04 21:31:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-04 21:31:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-04 21:31:18 --> User Agent Class Initialized
INFO - 2018-09-04 21:31:18 --> Controller Class Initialized
INFO - 2018-09-04 21:31:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-04 21:31:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-04 21:31:18 --> Pixel_Model class loaded
INFO - 2018-09-04 21:31:18 --> Database Driver Class Initialized
INFO - 2018-09-04 21:31:18 --> Model "QuestionsModel" initialized
INFO - 2018-09-04 21:31:18 --> Database Driver Class Initialized
INFO - 2018-09-04 21:31:18 --> Model "QuestionsModel" initialized
INFO - 2018-09-04 21:31:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-04 21:31:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-04 21:31:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-04 21:31:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-04 21:31:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-04 21:31:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-04 21:31:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-09-04 21:31:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-04 21:31:18 --> Final output sent to browser
DEBUG - 2018-09-04 21:31:18 --> Total execution time: 0.0484
INFO - 2018-09-04 21:31:24 --> Config Class Initialized
INFO - 2018-09-04 21:31:24 --> Hooks Class Initialized
DEBUG - 2018-09-04 21:31:24 --> UTF-8 Support Enabled
INFO - 2018-09-04 21:31:24 --> Utf8 Class Initialized
INFO - 2018-09-04 21:31:24 --> URI Class Initialized
INFO - 2018-09-04 21:31:24 --> Router Class Initialized
INFO - 2018-09-04 21:31:24 --> Output Class Initialized
INFO - 2018-09-04 21:31:24 --> Security Class Initialized
DEBUG - 2018-09-04 21:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-04 21:31:24 --> CSRF cookie sent
INFO - 2018-09-04 21:31:24 --> CSRF token verified
INFO - 2018-09-04 21:31:24 --> Input Class Initialized
INFO - 2018-09-04 21:31:24 --> Language Class Initialized
INFO - 2018-09-04 21:31:24 --> Loader Class Initialized
INFO - 2018-09-04 21:31:24 --> Helper loaded: url_helper
INFO - 2018-09-04 21:31:24 --> Helper loaded: form_helper
INFO - 2018-09-04 21:31:24 --> Helper loaded: language_helper
DEBUG - 2018-09-04 21:31:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-04 21:31:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-04 21:31:24 --> User Agent Class Initialized
INFO - 2018-09-04 21:31:24 --> Controller Class Initialized
INFO - 2018-09-04 21:31:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-04 21:31:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-04 21:31:24 --> Pixel_Model class loaded
INFO - 2018-09-04 21:31:24 --> Database Driver Class Initialized
INFO - 2018-09-04 21:31:24 --> Model "QuestionsModel" initialized
INFO - 2018-09-04 21:31:24 --> Form Validation Class Initialized
INFO - 2018-09-04 21:31:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-04 21:31:24 --> Database Driver Class Initialized
INFO - 2018-09-04 21:31:24 --> Model "QuestionsModel" initialized
INFO - 2018-09-04 21:31:25 --> Config Class Initialized
INFO - 2018-09-04 21:31:25 --> Hooks Class Initialized
DEBUG - 2018-09-04 21:31:25 --> UTF-8 Support Enabled
INFO - 2018-09-04 21:31:25 --> Utf8 Class Initialized
INFO - 2018-09-04 21:31:25 --> URI Class Initialized
INFO - 2018-09-04 21:31:25 --> Router Class Initialized
INFO - 2018-09-04 21:31:25 --> Output Class Initialized
INFO - 2018-09-04 21:31:25 --> Security Class Initialized
DEBUG - 2018-09-04 21:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-04 21:31:25 --> CSRF cookie sent
INFO - 2018-09-04 21:31:25 --> Input Class Initialized
INFO - 2018-09-04 21:31:25 --> Language Class Initialized
INFO - 2018-09-04 21:31:25 --> Loader Class Initialized
INFO - 2018-09-04 21:31:25 --> Helper loaded: url_helper
INFO - 2018-09-04 21:31:25 --> Helper loaded: form_helper
INFO - 2018-09-04 21:31:25 --> Helper loaded: language_helper
DEBUG - 2018-09-04 21:31:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-04 21:31:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-04 21:31:25 --> User Agent Class Initialized
INFO - 2018-09-04 21:31:25 --> Controller Class Initialized
INFO - 2018-09-04 21:31:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-04 21:31:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-04 21:31:25 --> Pixel_Model class loaded
INFO - 2018-09-04 21:31:25 --> Database Driver Class Initialized
INFO - 2018-09-04 21:31:25 --> Model "QuestionsModel" initialized
INFO - 2018-09-04 21:31:25 --> Database Driver Class Initialized
INFO - 2018-09-04 21:31:25 --> Model "QuestionsModel" initialized
INFO - 2018-09-04 21:31:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-04 21:31:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-04 21:31:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-09-04 21:31:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-04 21:31:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-04 21:31:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-04 21:31:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-04 21:31:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-09-04 21:31:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-04 21:31:25 --> Final output sent to browser
DEBUG - 2018-09-04 21:31:25 --> Total execution time: 0.0504
INFO - 2018-09-04 21:32:38 --> Config Class Initialized
INFO - 2018-09-04 21:32:38 --> Hooks Class Initialized
DEBUG - 2018-09-04 21:32:38 --> UTF-8 Support Enabled
INFO - 2018-09-04 21:32:38 --> Utf8 Class Initialized
INFO - 2018-09-04 21:32:38 --> URI Class Initialized
INFO - 2018-09-04 21:32:38 --> Router Class Initialized
INFO - 2018-09-04 21:32:38 --> Output Class Initialized
INFO - 2018-09-04 21:32:38 --> Security Class Initialized
DEBUG - 2018-09-04 21:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-04 21:32:38 --> CSRF cookie sent
INFO - 2018-09-04 21:32:38 --> CSRF token verified
INFO - 2018-09-04 21:32:38 --> Input Class Initialized
INFO - 2018-09-04 21:32:38 --> Language Class Initialized
INFO - 2018-09-04 21:32:38 --> Loader Class Initialized
INFO - 2018-09-04 21:32:38 --> Helper loaded: url_helper
INFO - 2018-09-04 21:32:38 --> Helper loaded: form_helper
INFO - 2018-09-04 21:32:38 --> Helper loaded: language_helper
DEBUG - 2018-09-04 21:32:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-04 21:32:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-04 21:32:38 --> User Agent Class Initialized
INFO - 2018-09-04 21:32:38 --> Controller Class Initialized
INFO - 2018-09-04 21:32:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-04 21:32:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-04 21:32:38 --> Pixel_Model class loaded
INFO - 2018-09-04 21:32:38 --> Database Driver Class Initialized
INFO - 2018-09-04 21:32:38 --> Model "QuestionsModel" initialized
INFO - 2018-09-04 21:32:38 --> Form Validation Class Initialized
INFO - 2018-09-04 21:32:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-04 21:32:38 --> Database Driver Class Initialized
INFO - 2018-09-04 21:32:38 --> Model "QuestionsModel" initialized
INFO - 2018-09-04 21:32:38 --> Config Class Initialized
INFO - 2018-09-04 21:32:38 --> Hooks Class Initialized
DEBUG - 2018-09-04 21:32:38 --> UTF-8 Support Enabled
INFO - 2018-09-04 21:32:38 --> Utf8 Class Initialized
INFO - 2018-09-04 21:32:38 --> URI Class Initialized
INFO - 2018-09-04 21:32:38 --> Router Class Initialized
INFO - 2018-09-04 21:32:38 --> Output Class Initialized
INFO - 2018-09-04 21:32:38 --> Security Class Initialized
DEBUG - 2018-09-04 21:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-04 21:32:38 --> CSRF cookie sent
INFO - 2018-09-04 21:32:38 --> Input Class Initialized
INFO - 2018-09-04 21:32:38 --> Language Class Initialized
INFO - 2018-09-04 21:32:38 --> Loader Class Initialized
INFO - 2018-09-04 21:32:38 --> Helper loaded: url_helper
INFO - 2018-09-04 21:32:38 --> Helper loaded: form_helper
INFO - 2018-09-04 21:32:38 --> Helper loaded: language_helper
DEBUG - 2018-09-04 21:32:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-04 21:32:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-04 21:32:38 --> User Agent Class Initialized
INFO - 2018-09-04 21:32:38 --> Controller Class Initialized
INFO - 2018-09-04 21:32:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-04 21:32:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-04 21:32:38 --> Pixel_Model class loaded
INFO - 2018-09-04 21:32:38 --> Database Driver Class Initialized
INFO - 2018-09-04 21:32:38 --> Model "QuestionsModel" initialized
INFO - 2018-09-04 21:32:38 --> Database Driver Class Initialized
INFO - 2018-09-04 21:32:38 --> Model "QuestionsModel" initialized
INFO - 2018-09-04 21:32:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-04 21:32:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-04 21:32:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-04 21:32:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-04 21:32:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-04 21:32:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-04 21:32:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-09-04 21:32:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-04 21:32:38 --> Final output sent to browser
DEBUG - 2018-09-04 21:32:38 --> Total execution time: 0.0528
INFO - 2018-09-04 21:32:44 --> Config Class Initialized
INFO - 2018-09-04 21:32:44 --> Hooks Class Initialized
DEBUG - 2018-09-04 21:32:44 --> UTF-8 Support Enabled
INFO - 2018-09-04 21:32:44 --> Utf8 Class Initialized
INFO - 2018-09-04 21:32:44 --> URI Class Initialized
INFO - 2018-09-04 21:32:44 --> Router Class Initialized
INFO - 2018-09-04 21:32:44 --> Output Class Initialized
INFO - 2018-09-04 21:32:44 --> Security Class Initialized
DEBUG - 2018-09-04 21:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-04 21:32:44 --> CSRF cookie sent
INFO - 2018-09-04 21:32:44 --> CSRF token verified
INFO - 2018-09-04 21:32:44 --> Input Class Initialized
INFO - 2018-09-04 21:32:44 --> Language Class Initialized
INFO - 2018-09-04 21:32:44 --> Loader Class Initialized
INFO - 2018-09-04 21:32:44 --> Helper loaded: url_helper
INFO - 2018-09-04 21:32:44 --> Helper loaded: form_helper
INFO - 2018-09-04 21:32:44 --> Helper loaded: language_helper
DEBUG - 2018-09-04 21:32:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-04 21:32:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-04 21:32:44 --> User Agent Class Initialized
INFO - 2018-09-04 21:32:44 --> Controller Class Initialized
INFO - 2018-09-04 21:32:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-04 21:32:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-04 21:32:44 --> Pixel_Model class loaded
INFO - 2018-09-04 21:32:44 --> Database Driver Class Initialized
INFO - 2018-09-04 21:32:44 --> Model "QuestionsModel" initialized
INFO - 2018-09-04 21:32:44 --> Form Validation Class Initialized
INFO - 2018-09-04 21:32:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-04 21:32:44 --> Database Driver Class Initialized
INFO - 2018-09-04 21:32:44 --> Model "QuestionsModel" initialized
INFO - 2018-09-04 21:32:44 --> Config Class Initialized
INFO - 2018-09-04 21:32:44 --> Hooks Class Initialized
DEBUG - 2018-09-04 21:32:44 --> UTF-8 Support Enabled
INFO - 2018-09-04 21:32:44 --> Utf8 Class Initialized
INFO - 2018-09-04 21:32:44 --> URI Class Initialized
INFO - 2018-09-04 21:32:44 --> Router Class Initialized
INFO - 2018-09-04 21:32:44 --> Output Class Initialized
INFO - 2018-09-04 21:32:44 --> Security Class Initialized
DEBUG - 2018-09-04 21:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-04 21:32:44 --> CSRF cookie sent
INFO - 2018-09-04 21:32:44 --> Input Class Initialized
INFO - 2018-09-04 21:32:44 --> Language Class Initialized
INFO - 2018-09-04 21:32:44 --> Loader Class Initialized
INFO - 2018-09-04 21:32:44 --> Helper loaded: url_helper
INFO - 2018-09-04 21:32:44 --> Helper loaded: form_helper
INFO - 2018-09-04 21:32:44 --> Helper loaded: language_helper
DEBUG - 2018-09-04 21:32:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-04 21:32:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-04 21:32:44 --> User Agent Class Initialized
INFO - 2018-09-04 21:32:44 --> Controller Class Initialized
INFO - 2018-09-04 21:32:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-04 21:32:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-04 21:32:44 --> Pixel_Model class loaded
INFO - 2018-09-04 21:32:44 --> Database Driver Class Initialized
INFO - 2018-09-04 21:32:44 --> Model "QuestionsModel" initialized
INFO - 2018-09-04 21:32:44 --> Database Driver Class Initialized
INFO - 2018-09-04 21:32:44 --> Model "QuestionsModel" initialized
INFO - 2018-09-04 21:32:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-04 21:32:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-04 21:32:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-04 21:32:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-04 21:32:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-04 21:32:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-04 21:32:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-09-04 21:32:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-04 21:32:44 --> Final output sent to browser
DEBUG - 2018-09-04 21:32:44 --> Total execution time: 0.0468

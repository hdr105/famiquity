<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-09-06 13:15:54 --> Config Class Initialized
INFO - 2018-09-06 13:15:54 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:15:54 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:15:54 --> Utf8 Class Initialized
INFO - 2018-09-06 13:15:54 --> URI Class Initialized
DEBUG - 2018-09-06 13:15:54 --> No URI present. Default controller set.
INFO - 2018-09-06 13:15:54 --> Router Class Initialized
INFO - 2018-09-06 13:15:54 --> Output Class Initialized
INFO - 2018-09-06 13:15:54 --> Security Class Initialized
DEBUG - 2018-09-06 13:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:15:54 --> CSRF cookie sent
INFO - 2018-09-06 13:15:54 --> Input Class Initialized
INFO - 2018-09-06 13:15:54 --> Language Class Initialized
INFO - 2018-09-06 13:15:54 --> Loader Class Initialized
INFO - 2018-09-06 13:15:54 --> Helper loaded: url_helper
INFO - 2018-09-06 13:15:54 --> Helper loaded: form_helper
INFO - 2018-09-06 13:15:54 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:15:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:15:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:15:54 --> User Agent Class Initialized
INFO - 2018-09-06 13:15:54 --> Controller Class Initialized
INFO - 2018-09-06 13:15:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:15:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:15:54 --> Pixel_Model class loaded
INFO - 2018-09-06 13:15:54 --> Database Driver Class Initialized
INFO - 2018-09-06 13:15:54 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:15:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 13:15:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 13:15:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-09-06 13:15:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 13:15:55 --> Final output sent to browser
DEBUG - 2018-09-06 13:15:55 --> Total execution time: 0.0372
INFO - 2018-09-06 13:16:01 --> Config Class Initialized
INFO - 2018-09-06 13:16:01 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:16:01 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:16:01 --> Utf8 Class Initialized
INFO - 2018-09-06 13:16:01 --> URI Class Initialized
INFO - 2018-09-06 13:16:01 --> Router Class Initialized
INFO - 2018-09-06 13:16:01 --> Output Class Initialized
INFO - 2018-09-06 13:16:01 --> Security Class Initialized
DEBUG - 2018-09-06 13:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:16:01 --> CSRF cookie sent
INFO - 2018-09-06 13:16:01 --> CSRF token verified
INFO - 2018-09-06 13:16:01 --> Input Class Initialized
INFO - 2018-09-06 13:16:01 --> Language Class Initialized
INFO - 2018-09-06 13:16:01 --> Loader Class Initialized
INFO - 2018-09-06 13:16:01 --> Helper loaded: url_helper
INFO - 2018-09-06 13:16:01 --> Helper loaded: form_helper
INFO - 2018-09-06 13:16:01 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:16:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:16:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:16:01 --> User Agent Class Initialized
INFO - 2018-09-06 13:16:01 --> Controller Class Initialized
INFO - 2018-09-06 13:16:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:16:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:16:01 --> Pixel_Model class loaded
INFO - 2018-09-06 13:16:01 --> Database Driver Class Initialized
INFO - 2018-09-06 13:16:01 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:16:01 --> Database Driver Class Initialized
INFO - 2018-09-06 13:16:01 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:16:01 --> Config Class Initialized
INFO - 2018-09-06 13:16:01 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:16:01 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:16:01 --> Utf8 Class Initialized
INFO - 2018-09-06 13:16:01 --> URI Class Initialized
INFO - 2018-09-06 13:16:01 --> Router Class Initialized
INFO - 2018-09-06 13:16:01 --> Output Class Initialized
INFO - 2018-09-06 13:16:01 --> Security Class Initialized
DEBUG - 2018-09-06 13:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:16:01 --> CSRF cookie sent
INFO - 2018-09-06 13:16:01 --> Input Class Initialized
INFO - 2018-09-06 13:16:01 --> Language Class Initialized
INFO - 2018-09-06 13:16:01 --> Loader Class Initialized
INFO - 2018-09-06 13:16:01 --> Helper loaded: url_helper
INFO - 2018-09-06 13:16:01 --> Helper loaded: form_helper
INFO - 2018-09-06 13:16:01 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:16:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:16:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:16:01 --> User Agent Class Initialized
INFO - 2018-09-06 13:16:01 --> Controller Class Initialized
INFO - 2018-09-06 13:16:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:16:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:16:01 --> Pixel_Model class loaded
INFO - 2018-09-06 13:16:01 --> Database Driver Class Initialized
INFO - 2018-09-06 13:16:01 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:16:01 --> Database Driver Class Initialized
INFO - 2018-09-06 13:16:01 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:16:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 13:16:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 13:16:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 13:16:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-06 13:16:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-06 13:16:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-06 13:16:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-09-06 13:16:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 13:16:01 --> Final output sent to browser
DEBUG - 2018-09-06 13:16:01 --> Total execution time: 0.0510
INFO - 2018-09-06 13:16:07 --> Config Class Initialized
INFO - 2018-09-06 13:16:07 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:16:07 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:16:07 --> Utf8 Class Initialized
INFO - 2018-09-06 13:16:07 --> URI Class Initialized
INFO - 2018-09-06 13:16:07 --> Router Class Initialized
INFO - 2018-09-06 13:16:07 --> Output Class Initialized
INFO - 2018-09-06 13:16:07 --> Security Class Initialized
DEBUG - 2018-09-06 13:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:16:07 --> CSRF cookie sent
INFO - 2018-09-06 13:16:07 --> CSRF token verified
INFO - 2018-09-06 13:16:07 --> Input Class Initialized
INFO - 2018-09-06 13:16:07 --> Language Class Initialized
INFO - 2018-09-06 13:16:07 --> Loader Class Initialized
INFO - 2018-09-06 13:16:07 --> Helper loaded: url_helper
INFO - 2018-09-06 13:16:07 --> Helper loaded: form_helper
INFO - 2018-09-06 13:16:07 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:16:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:16:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:16:07 --> User Agent Class Initialized
INFO - 2018-09-06 13:16:07 --> Controller Class Initialized
INFO - 2018-09-06 13:16:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:16:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:16:07 --> Pixel_Model class loaded
INFO - 2018-09-06 13:16:07 --> Database Driver Class Initialized
INFO - 2018-09-06 13:16:07 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:16:07 --> Form Validation Class Initialized
INFO - 2018-09-06 13:16:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-06 13:16:07 --> Database Driver Class Initialized
INFO - 2018-09-06 13:16:07 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:16:07 --> Config Class Initialized
INFO - 2018-09-06 13:16:07 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:16:07 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:16:07 --> Utf8 Class Initialized
INFO - 2018-09-06 13:16:07 --> URI Class Initialized
INFO - 2018-09-06 13:16:07 --> Router Class Initialized
INFO - 2018-09-06 13:16:07 --> Output Class Initialized
INFO - 2018-09-06 13:16:07 --> Security Class Initialized
DEBUG - 2018-09-06 13:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:16:07 --> CSRF cookie sent
INFO - 2018-09-06 13:16:07 --> Input Class Initialized
INFO - 2018-09-06 13:16:07 --> Language Class Initialized
INFO - 2018-09-06 13:16:07 --> Loader Class Initialized
INFO - 2018-09-06 13:16:07 --> Helper loaded: url_helper
INFO - 2018-09-06 13:16:07 --> Helper loaded: form_helper
INFO - 2018-09-06 13:16:07 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:16:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:16:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:16:07 --> User Agent Class Initialized
INFO - 2018-09-06 13:16:07 --> Controller Class Initialized
INFO - 2018-09-06 13:16:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:16:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:16:07 --> Pixel_Model class loaded
INFO - 2018-09-06 13:16:07 --> Database Driver Class Initialized
INFO - 2018-09-06 13:16:07 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:16:07 --> Database Driver Class Initialized
INFO - 2018-09-06 13:16:07 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:16:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 13:16:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 13:16:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 13:16:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-06 13:16:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-06 13:16:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-06 13:16:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-09-06 13:16:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 13:16:07 --> Final output sent to browser
DEBUG - 2018-09-06 13:16:07 --> Total execution time: 0.0486
INFO - 2018-09-06 13:16:44 --> Config Class Initialized
INFO - 2018-09-06 13:16:44 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:16:44 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:16:44 --> Utf8 Class Initialized
INFO - 2018-09-06 13:16:44 --> URI Class Initialized
INFO - 2018-09-06 13:16:44 --> Router Class Initialized
INFO - 2018-09-06 13:16:44 --> Output Class Initialized
INFO - 2018-09-06 13:16:44 --> Security Class Initialized
DEBUG - 2018-09-06 13:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:16:44 --> CSRF cookie sent
INFO - 2018-09-06 13:16:44 --> CSRF token verified
INFO - 2018-09-06 13:16:44 --> Input Class Initialized
INFO - 2018-09-06 13:16:44 --> Language Class Initialized
INFO - 2018-09-06 13:16:44 --> Loader Class Initialized
INFO - 2018-09-06 13:16:44 --> Helper loaded: url_helper
INFO - 2018-09-06 13:16:44 --> Helper loaded: form_helper
INFO - 2018-09-06 13:16:44 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:16:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:16:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:16:44 --> User Agent Class Initialized
INFO - 2018-09-06 13:16:44 --> Controller Class Initialized
INFO - 2018-09-06 13:16:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:16:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:16:44 --> Pixel_Model class loaded
INFO - 2018-09-06 13:16:44 --> Database Driver Class Initialized
INFO - 2018-09-06 13:16:44 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:16:44 --> Form Validation Class Initialized
INFO - 2018-09-06 13:16:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-06 13:16:44 --> Database Driver Class Initialized
INFO - 2018-09-06 13:16:44 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:16:45 --> Config Class Initialized
INFO - 2018-09-06 13:16:45 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:16:45 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:16:45 --> Utf8 Class Initialized
INFO - 2018-09-06 13:16:45 --> URI Class Initialized
INFO - 2018-09-06 13:16:45 --> Router Class Initialized
INFO - 2018-09-06 13:16:45 --> Output Class Initialized
INFO - 2018-09-06 13:16:45 --> Security Class Initialized
DEBUG - 2018-09-06 13:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:16:45 --> CSRF cookie sent
INFO - 2018-09-06 13:16:45 --> Input Class Initialized
INFO - 2018-09-06 13:16:45 --> Language Class Initialized
INFO - 2018-09-06 13:16:45 --> Loader Class Initialized
INFO - 2018-09-06 13:16:45 --> Helper loaded: url_helper
INFO - 2018-09-06 13:16:45 --> Helper loaded: form_helper
INFO - 2018-09-06 13:16:45 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:16:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:16:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:16:45 --> User Agent Class Initialized
INFO - 2018-09-06 13:16:45 --> Controller Class Initialized
INFO - 2018-09-06 13:16:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:16:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:16:45 --> Pixel_Model class loaded
INFO - 2018-09-06 13:16:45 --> Database Driver Class Initialized
INFO - 2018-09-06 13:16:45 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:16:45 --> Database Driver Class Initialized
INFO - 2018-09-06 13:16:45 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:16:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 13:16:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 13:16:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-09-06 13:16:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 13:16:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-06 13:16:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-06 13:16:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-06 13:16:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-09-06 13:16:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 13:16:45 --> Final output sent to browser
DEBUG - 2018-09-06 13:16:45 --> Total execution time: 0.0459
INFO - 2018-09-06 13:16:46 --> Config Class Initialized
INFO - 2018-09-06 13:16:46 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:16:46 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:16:46 --> Utf8 Class Initialized
INFO - 2018-09-06 13:16:46 --> URI Class Initialized
INFO - 2018-09-06 13:16:46 --> Router Class Initialized
INFO - 2018-09-06 13:16:46 --> Output Class Initialized
INFO - 2018-09-06 13:16:46 --> Security Class Initialized
DEBUG - 2018-09-06 13:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:16:46 --> CSRF cookie sent
INFO - 2018-09-06 13:16:46 --> CSRF token verified
INFO - 2018-09-06 13:16:46 --> Input Class Initialized
INFO - 2018-09-06 13:16:46 --> Language Class Initialized
INFO - 2018-09-06 13:16:46 --> Loader Class Initialized
INFO - 2018-09-06 13:16:46 --> Helper loaded: url_helper
INFO - 2018-09-06 13:16:46 --> Helper loaded: form_helper
INFO - 2018-09-06 13:16:46 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:16:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:16:46 --> User Agent Class Initialized
INFO - 2018-09-06 13:16:46 --> Controller Class Initialized
INFO - 2018-09-06 13:16:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:16:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:16:46 --> Pixel_Model class loaded
INFO - 2018-09-06 13:16:46 --> Database Driver Class Initialized
INFO - 2018-09-06 13:16:46 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:16:46 --> Form Validation Class Initialized
INFO - 2018-09-06 13:16:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-06 13:16:46 --> Database Driver Class Initialized
INFO - 2018-09-06 13:16:46 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:16:46 --> Config Class Initialized
INFO - 2018-09-06 13:16:46 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:16:46 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:16:46 --> Utf8 Class Initialized
INFO - 2018-09-06 13:16:46 --> URI Class Initialized
INFO - 2018-09-06 13:16:46 --> Router Class Initialized
INFO - 2018-09-06 13:16:46 --> Output Class Initialized
INFO - 2018-09-06 13:16:46 --> Security Class Initialized
DEBUG - 2018-09-06 13:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:16:46 --> CSRF cookie sent
INFO - 2018-09-06 13:16:46 --> Input Class Initialized
INFO - 2018-09-06 13:16:46 --> Language Class Initialized
INFO - 2018-09-06 13:16:46 --> Loader Class Initialized
INFO - 2018-09-06 13:16:46 --> Helper loaded: url_helper
INFO - 2018-09-06 13:16:46 --> Helper loaded: form_helper
INFO - 2018-09-06 13:16:46 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:16:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:16:46 --> User Agent Class Initialized
INFO - 2018-09-06 13:16:46 --> Controller Class Initialized
INFO - 2018-09-06 13:16:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:16:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:16:46 --> Pixel_Model class loaded
INFO - 2018-09-06 13:16:46 --> Database Driver Class Initialized
INFO - 2018-09-06 13:16:46 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:16:46 --> Database Driver Class Initialized
INFO - 2018-09-06 13:16:46 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:16:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 13:16:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 13:16:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 13:16:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-06 13:16:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-06 13:16:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-06 13:16:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-09-06 13:16:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 13:16:46 --> Final output sent to browser
DEBUG - 2018-09-06 13:16:46 --> Total execution time: 0.0450
INFO - 2018-09-06 13:17:54 --> Config Class Initialized
INFO - 2018-09-06 13:17:54 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:17:54 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:17:54 --> Utf8 Class Initialized
INFO - 2018-09-06 13:17:54 --> URI Class Initialized
INFO - 2018-09-06 13:17:54 --> Router Class Initialized
INFO - 2018-09-06 13:17:54 --> Output Class Initialized
INFO - 2018-09-06 13:17:54 --> Security Class Initialized
DEBUG - 2018-09-06 13:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:17:54 --> CSRF cookie sent
INFO - 2018-09-06 13:17:54 --> CSRF token verified
INFO - 2018-09-06 13:17:54 --> Input Class Initialized
INFO - 2018-09-06 13:17:54 --> Language Class Initialized
INFO - 2018-09-06 13:17:54 --> Loader Class Initialized
INFO - 2018-09-06 13:17:54 --> Helper loaded: url_helper
INFO - 2018-09-06 13:17:54 --> Helper loaded: form_helper
INFO - 2018-09-06 13:17:54 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:17:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:17:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:17:54 --> User Agent Class Initialized
INFO - 2018-09-06 13:17:54 --> Controller Class Initialized
INFO - 2018-09-06 13:17:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:17:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:17:54 --> Pixel_Model class loaded
INFO - 2018-09-06 13:17:54 --> Database Driver Class Initialized
INFO - 2018-09-06 13:17:54 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:17:54 --> Form Validation Class Initialized
INFO - 2018-09-06 13:17:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-06 13:17:54 --> Database Driver Class Initialized
INFO - 2018-09-06 13:17:54 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:17:54 --> Config Class Initialized
INFO - 2018-09-06 13:17:54 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:17:54 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:17:54 --> Utf8 Class Initialized
INFO - 2018-09-06 13:17:54 --> URI Class Initialized
INFO - 2018-09-06 13:17:54 --> Router Class Initialized
INFO - 2018-09-06 13:17:54 --> Output Class Initialized
INFO - 2018-09-06 13:17:54 --> Security Class Initialized
DEBUG - 2018-09-06 13:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:17:54 --> CSRF cookie sent
INFO - 2018-09-06 13:17:54 --> Input Class Initialized
INFO - 2018-09-06 13:17:54 --> Language Class Initialized
INFO - 2018-09-06 13:17:54 --> Loader Class Initialized
INFO - 2018-09-06 13:17:54 --> Helper loaded: url_helper
INFO - 2018-09-06 13:17:54 --> Helper loaded: form_helper
INFO - 2018-09-06 13:17:54 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:17:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:17:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:17:54 --> User Agent Class Initialized
INFO - 2018-09-06 13:17:54 --> Controller Class Initialized
INFO - 2018-09-06 13:17:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:17:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:17:54 --> Pixel_Model class loaded
INFO - 2018-09-06 13:17:54 --> Database Driver Class Initialized
INFO - 2018-09-06 13:17:54 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:17:54 --> Database Driver Class Initialized
INFO - 2018-09-06 13:17:54 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:17:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 13:17:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 13:17:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 13:17:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-06 13:17:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-06 13:17:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-06 13:17:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-09-06 13:17:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 13:17:54 --> Final output sent to browser
DEBUG - 2018-09-06 13:17:54 --> Total execution time: 0.0493
INFO - 2018-09-06 13:17:59 --> Config Class Initialized
INFO - 2018-09-06 13:17:59 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:17:59 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:17:59 --> Utf8 Class Initialized
INFO - 2018-09-06 13:17:59 --> URI Class Initialized
INFO - 2018-09-06 13:17:59 --> Router Class Initialized
INFO - 2018-09-06 13:17:59 --> Output Class Initialized
INFO - 2018-09-06 13:17:59 --> Security Class Initialized
DEBUG - 2018-09-06 13:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:17:59 --> CSRF cookie sent
INFO - 2018-09-06 13:17:59 --> Input Class Initialized
INFO - 2018-09-06 13:17:59 --> Language Class Initialized
INFO - 2018-09-06 13:17:59 --> Loader Class Initialized
INFO - 2018-09-06 13:17:59 --> Helper loaded: url_helper
INFO - 2018-09-06 13:17:59 --> Helper loaded: form_helper
INFO - 2018-09-06 13:17:59 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:17:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:17:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:17:59 --> User Agent Class Initialized
INFO - 2018-09-06 13:17:59 --> Controller Class Initialized
INFO - 2018-09-06 13:17:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:17:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:17:59 --> Pixel_Model class loaded
INFO - 2018-09-06 13:17:59 --> Database Driver Class Initialized
INFO - 2018-09-06 13:17:59 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:17:59 --> Database Driver Class Initialized
INFO - 2018-09-06 13:17:59 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:17:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 13:17:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 13:17:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 13:17:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-06 13:17:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-06 13:17:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-06 13:17:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-09-06 13:17:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 13:17:59 --> Final output sent to browser
DEBUG - 2018-09-06 13:17:59 --> Total execution time: 0.0473
INFO - 2018-09-06 13:18:00 --> Config Class Initialized
INFO - 2018-09-06 13:18:00 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:18:00 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:18:00 --> Utf8 Class Initialized
INFO - 2018-09-06 13:18:00 --> URI Class Initialized
INFO - 2018-09-06 13:18:00 --> Router Class Initialized
INFO - 2018-09-06 13:18:00 --> Output Class Initialized
INFO - 2018-09-06 13:18:00 --> Security Class Initialized
DEBUG - 2018-09-06 13:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:18:00 --> CSRF cookie sent
INFO - 2018-09-06 13:18:00 --> Input Class Initialized
INFO - 2018-09-06 13:18:00 --> Language Class Initialized
INFO - 2018-09-06 13:18:00 --> Loader Class Initialized
INFO - 2018-09-06 13:18:00 --> Helper loaded: url_helper
INFO - 2018-09-06 13:18:00 --> Helper loaded: form_helper
INFO - 2018-09-06 13:18:00 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:18:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:18:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:18:00 --> User Agent Class Initialized
INFO - 2018-09-06 13:18:00 --> Controller Class Initialized
INFO - 2018-09-06 13:18:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:18:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:18:00 --> Pixel_Model class loaded
INFO - 2018-09-06 13:18:00 --> Database Driver Class Initialized
INFO - 2018-09-06 13:18:00 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:18:00 --> Database Driver Class Initialized
INFO - 2018-09-06 13:18:00 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:18:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 13:18:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 13:18:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-09-06 13:18:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 13:18:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-06 13:18:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-06 13:18:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-06 13:18:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-09-06 13:18:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 13:18:00 --> Final output sent to browser
DEBUG - 2018-09-06 13:18:00 --> Total execution time: 0.0525
INFO - 2018-09-06 13:18:04 --> Config Class Initialized
INFO - 2018-09-06 13:18:04 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:18:04 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:18:04 --> Utf8 Class Initialized
INFO - 2018-09-06 13:18:04 --> URI Class Initialized
INFO - 2018-09-06 13:18:04 --> Router Class Initialized
INFO - 2018-09-06 13:18:04 --> Output Class Initialized
INFO - 2018-09-06 13:18:04 --> Security Class Initialized
DEBUG - 2018-09-06 13:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:18:04 --> CSRF cookie sent
INFO - 2018-09-06 13:18:04 --> CSRF token verified
INFO - 2018-09-06 13:18:04 --> Input Class Initialized
INFO - 2018-09-06 13:18:04 --> Language Class Initialized
INFO - 2018-09-06 13:18:04 --> Loader Class Initialized
INFO - 2018-09-06 13:18:04 --> Helper loaded: url_helper
INFO - 2018-09-06 13:18:04 --> Helper loaded: form_helper
INFO - 2018-09-06 13:18:04 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:18:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:18:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:18:04 --> User Agent Class Initialized
INFO - 2018-09-06 13:18:04 --> Controller Class Initialized
INFO - 2018-09-06 13:18:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:18:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:18:04 --> Pixel_Model class loaded
INFO - 2018-09-06 13:18:04 --> Database Driver Class Initialized
INFO - 2018-09-06 13:18:04 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:18:04 --> Form Validation Class Initialized
INFO - 2018-09-06 13:18:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-06 13:18:04 --> Database Driver Class Initialized
INFO - 2018-09-06 13:18:04 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:18:04 --> Config Class Initialized
INFO - 2018-09-06 13:18:04 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:18:04 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:18:04 --> Utf8 Class Initialized
INFO - 2018-09-06 13:18:04 --> URI Class Initialized
INFO - 2018-09-06 13:18:04 --> Router Class Initialized
INFO - 2018-09-06 13:18:04 --> Output Class Initialized
INFO - 2018-09-06 13:18:04 --> Security Class Initialized
DEBUG - 2018-09-06 13:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:18:04 --> CSRF cookie sent
INFO - 2018-09-06 13:18:04 --> Input Class Initialized
INFO - 2018-09-06 13:18:04 --> Language Class Initialized
INFO - 2018-09-06 13:18:04 --> Loader Class Initialized
INFO - 2018-09-06 13:18:04 --> Helper loaded: url_helper
INFO - 2018-09-06 13:18:04 --> Helper loaded: form_helper
INFO - 2018-09-06 13:18:04 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:18:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:18:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:18:04 --> User Agent Class Initialized
INFO - 2018-09-06 13:18:04 --> Controller Class Initialized
INFO - 2018-09-06 13:18:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:18:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:18:04 --> Pixel_Model class loaded
INFO - 2018-09-06 13:18:04 --> Database Driver Class Initialized
INFO - 2018-09-06 13:18:04 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:18:04 --> Database Driver Class Initialized
INFO - 2018-09-06 13:18:04 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:18:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 13:18:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 13:18:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 13:18:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-06 13:18:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-06 13:18:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-06 13:18:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-09-06 13:18:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 13:18:04 --> Final output sent to browser
DEBUG - 2018-09-06 13:18:04 --> Total execution time: 0.0500
INFO - 2018-09-06 13:18:05 --> Config Class Initialized
INFO - 2018-09-06 13:18:05 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:18:05 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:18:05 --> Utf8 Class Initialized
INFO - 2018-09-06 13:18:05 --> URI Class Initialized
INFO - 2018-09-06 13:18:05 --> Router Class Initialized
INFO - 2018-09-06 13:18:05 --> Output Class Initialized
INFO - 2018-09-06 13:18:05 --> Security Class Initialized
DEBUG - 2018-09-06 13:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:18:05 --> CSRF cookie sent
INFO - 2018-09-06 13:18:05 --> CSRF token verified
INFO - 2018-09-06 13:18:05 --> Input Class Initialized
INFO - 2018-09-06 13:18:05 --> Language Class Initialized
INFO - 2018-09-06 13:18:05 --> Loader Class Initialized
INFO - 2018-09-06 13:18:05 --> Helper loaded: url_helper
INFO - 2018-09-06 13:18:05 --> Helper loaded: form_helper
INFO - 2018-09-06 13:18:05 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:18:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:18:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:18:05 --> User Agent Class Initialized
INFO - 2018-09-06 13:18:05 --> Controller Class Initialized
INFO - 2018-09-06 13:18:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:18:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:18:05 --> Pixel_Model class loaded
INFO - 2018-09-06 13:18:05 --> Database Driver Class Initialized
INFO - 2018-09-06 13:18:05 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:18:05 --> Form Validation Class Initialized
INFO - 2018-09-06 13:18:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-06 13:18:05 --> Database Driver Class Initialized
INFO - 2018-09-06 13:18:05 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:18:05 --> Config Class Initialized
INFO - 2018-09-06 13:18:05 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:18:05 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:18:05 --> Utf8 Class Initialized
INFO - 2018-09-06 13:18:05 --> URI Class Initialized
INFO - 2018-09-06 13:18:05 --> Router Class Initialized
INFO - 2018-09-06 13:18:05 --> Output Class Initialized
INFO - 2018-09-06 13:18:05 --> Security Class Initialized
DEBUG - 2018-09-06 13:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:18:06 --> CSRF cookie sent
INFO - 2018-09-06 13:18:06 --> Input Class Initialized
INFO - 2018-09-06 13:18:06 --> Language Class Initialized
INFO - 2018-09-06 13:18:06 --> Loader Class Initialized
INFO - 2018-09-06 13:18:06 --> Helper loaded: url_helper
INFO - 2018-09-06 13:18:06 --> Helper loaded: form_helper
INFO - 2018-09-06 13:18:06 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:18:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:18:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:18:06 --> User Agent Class Initialized
INFO - 2018-09-06 13:18:06 --> Controller Class Initialized
INFO - 2018-09-06 13:18:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:18:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:18:06 --> Pixel_Model class loaded
INFO - 2018-09-06 13:18:06 --> Database Driver Class Initialized
INFO - 2018-09-06 13:18:06 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:18:06 --> Database Driver Class Initialized
INFO - 2018-09-06 13:18:06 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:18:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 13:18:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 13:18:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 13:18:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-06 13:18:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-06 13:18:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-06 13:18:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/cohabitation.php
INFO - 2018-09-06 13:18:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 13:18:06 --> Final output sent to browser
DEBUG - 2018-09-06 13:18:06 --> Total execution time: 0.0411
INFO - 2018-09-06 13:18:12 --> Config Class Initialized
INFO - 2018-09-06 13:18:12 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:18:12 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:18:12 --> Utf8 Class Initialized
INFO - 2018-09-06 13:18:12 --> URI Class Initialized
INFO - 2018-09-06 13:18:12 --> Router Class Initialized
INFO - 2018-09-06 13:18:12 --> Output Class Initialized
INFO - 2018-09-06 13:18:12 --> Security Class Initialized
DEBUG - 2018-09-06 13:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:18:12 --> CSRF cookie sent
INFO - 2018-09-06 13:18:12 --> CSRF token verified
INFO - 2018-09-06 13:18:12 --> Input Class Initialized
INFO - 2018-09-06 13:18:12 --> Language Class Initialized
INFO - 2018-09-06 13:18:12 --> Loader Class Initialized
INFO - 2018-09-06 13:18:12 --> Helper loaded: url_helper
INFO - 2018-09-06 13:18:12 --> Helper loaded: form_helper
INFO - 2018-09-06 13:18:12 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:18:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:18:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:18:12 --> User Agent Class Initialized
INFO - 2018-09-06 13:18:12 --> Controller Class Initialized
INFO - 2018-09-06 13:18:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:18:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:18:12 --> Pixel_Model class loaded
INFO - 2018-09-06 13:18:12 --> Database Driver Class Initialized
INFO - 2018-09-06 13:18:12 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:18:12 --> Form Validation Class Initialized
INFO - 2018-09-06 13:18:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-06 13:18:12 --> Database Driver Class Initialized
INFO - 2018-09-06 13:18:12 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:18:12 --> Config Class Initialized
INFO - 2018-09-06 13:18:12 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:18:12 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:18:12 --> Utf8 Class Initialized
INFO - 2018-09-06 13:18:12 --> URI Class Initialized
INFO - 2018-09-06 13:18:12 --> Router Class Initialized
INFO - 2018-09-06 13:18:12 --> Output Class Initialized
INFO - 2018-09-06 13:18:12 --> Security Class Initialized
DEBUG - 2018-09-06 13:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:18:12 --> CSRF cookie sent
INFO - 2018-09-06 13:18:12 --> Input Class Initialized
INFO - 2018-09-06 13:18:12 --> Language Class Initialized
INFO - 2018-09-06 13:18:12 --> Loader Class Initialized
INFO - 2018-09-06 13:18:12 --> Helper loaded: url_helper
INFO - 2018-09-06 13:18:12 --> Helper loaded: form_helper
INFO - 2018-09-06 13:18:12 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:18:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:18:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:18:12 --> User Agent Class Initialized
INFO - 2018-09-06 13:18:12 --> Controller Class Initialized
INFO - 2018-09-06 13:18:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:18:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:18:12 --> Pixel_Model class loaded
INFO - 2018-09-06 13:18:12 --> Database Driver Class Initialized
INFO - 2018-09-06 13:18:12 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:18:12 --> Database Driver Class Initialized
INFO - 2018-09-06 13:18:12 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:18:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 13:18:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 13:18:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 13:18:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-06 13:18:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-06 13:18:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-06 13:18:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-09-06 13:18:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 13:18:12 --> Final output sent to browser
DEBUG - 2018-09-06 13:18:12 --> Total execution time: 0.0401
INFO - 2018-09-06 13:26:52 --> Config Class Initialized
INFO - 2018-09-06 13:26:52 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:26:52 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:26:52 --> Utf8 Class Initialized
INFO - 2018-09-06 13:26:52 --> URI Class Initialized
DEBUG - 2018-09-06 13:26:52 --> No URI present. Default controller set.
INFO - 2018-09-06 13:26:52 --> Router Class Initialized
INFO - 2018-09-06 13:26:52 --> Output Class Initialized
INFO - 2018-09-06 13:26:52 --> Security Class Initialized
DEBUG - 2018-09-06 13:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:26:52 --> CSRF cookie sent
INFO - 2018-09-06 13:26:52 --> Input Class Initialized
INFO - 2018-09-06 13:26:52 --> Language Class Initialized
INFO - 2018-09-06 13:26:52 --> Loader Class Initialized
INFO - 2018-09-06 13:26:52 --> Helper loaded: url_helper
INFO - 2018-09-06 13:26:52 --> Helper loaded: form_helper
INFO - 2018-09-06 13:26:52 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:26:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:26:52 --> User Agent Class Initialized
INFO - 2018-09-06 13:26:52 --> Controller Class Initialized
INFO - 2018-09-06 13:26:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:26:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:26:52 --> Pixel_Model class loaded
INFO - 2018-09-06 13:26:52 --> Database Driver Class Initialized
INFO - 2018-09-06 13:26:52 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:26:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 13:26:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 13:26:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-09-06 13:26:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 13:26:52 --> Final output sent to browser
DEBUG - 2018-09-06 13:26:52 --> Total execution time: 0.0428
INFO - 2018-09-06 13:26:54 --> Config Class Initialized
INFO - 2018-09-06 13:26:54 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:26:54 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:26:54 --> Utf8 Class Initialized
INFO - 2018-09-06 13:26:54 --> URI Class Initialized
DEBUG - 2018-09-06 13:26:54 --> No URI present. Default controller set.
INFO - 2018-09-06 13:26:54 --> Router Class Initialized
INFO - 2018-09-06 13:26:54 --> Output Class Initialized
INFO - 2018-09-06 13:26:54 --> Security Class Initialized
DEBUG - 2018-09-06 13:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:26:54 --> CSRF cookie sent
INFO - 2018-09-06 13:26:54 --> Input Class Initialized
INFO - 2018-09-06 13:26:54 --> Language Class Initialized
INFO - 2018-09-06 13:26:54 --> Loader Class Initialized
INFO - 2018-09-06 13:26:54 --> Helper loaded: url_helper
INFO - 2018-09-06 13:26:54 --> Helper loaded: form_helper
INFO - 2018-09-06 13:26:54 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:26:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:26:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:26:54 --> User Agent Class Initialized
INFO - 2018-09-06 13:26:54 --> Controller Class Initialized
INFO - 2018-09-06 13:26:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:26:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:26:54 --> Pixel_Model class loaded
INFO - 2018-09-06 13:26:54 --> Database Driver Class Initialized
INFO - 2018-09-06 13:26:54 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:26:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 13:26:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 13:26:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-09-06 13:26:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 13:26:54 --> Final output sent to browser
DEBUG - 2018-09-06 13:26:54 --> Total execution time: 0.0387
INFO - 2018-09-06 13:34:36 --> Config Class Initialized
INFO - 2018-09-06 13:34:36 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:34:36 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:34:36 --> Utf8 Class Initialized
INFO - 2018-09-06 13:34:36 --> URI Class Initialized
INFO - 2018-09-06 13:34:36 --> Router Class Initialized
INFO - 2018-09-06 13:34:36 --> Output Class Initialized
INFO - 2018-09-06 13:34:36 --> Security Class Initialized
DEBUG - 2018-09-06 13:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:34:36 --> CSRF cookie sent
INFO - 2018-09-06 13:34:36 --> CSRF token verified
INFO - 2018-09-06 13:34:36 --> Input Class Initialized
INFO - 2018-09-06 13:34:36 --> Language Class Initialized
INFO - 2018-09-06 13:34:36 --> Loader Class Initialized
INFO - 2018-09-06 13:34:36 --> Helper loaded: url_helper
INFO - 2018-09-06 13:34:36 --> Helper loaded: form_helper
INFO - 2018-09-06 13:34:36 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:34:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:34:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:34:36 --> User Agent Class Initialized
INFO - 2018-09-06 13:34:36 --> Controller Class Initialized
INFO - 2018-09-06 13:34:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:34:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:34:36 --> Pixel_Model class loaded
INFO - 2018-09-06 13:34:36 --> Database Driver Class Initialized
INFO - 2018-09-06 13:34:36 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:34:36 --> Database Driver Class Initialized
INFO - 2018-09-06 13:34:36 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:34:36 --> Config Class Initialized
INFO - 2018-09-06 13:34:36 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:34:36 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:34:36 --> Utf8 Class Initialized
INFO - 2018-09-06 13:34:36 --> URI Class Initialized
INFO - 2018-09-06 13:34:36 --> Router Class Initialized
INFO - 2018-09-06 13:34:36 --> Output Class Initialized
INFO - 2018-09-06 13:34:36 --> Security Class Initialized
DEBUG - 2018-09-06 13:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:34:36 --> CSRF cookie sent
INFO - 2018-09-06 13:34:36 --> Input Class Initialized
INFO - 2018-09-06 13:34:36 --> Language Class Initialized
INFO - 2018-09-06 13:34:36 --> Loader Class Initialized
INFO - 2018-09-06 13:34:36 --> Helper loaded: url_helper
INFO - 2018-09-06 13:34:36 --> Helper loaded: form_helper
INFO - 2018-09-06 13:34:36 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:34:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:34:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:34:36 --> User Agent Class Initialized
INFO - 2018-09-06 13:34:36 --> Controller Class Initialized
INFO - 2018-09-06 13:34:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:34:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:34:36 --> Pixel_Model class loaded
INFO - 2018-09-06 13:34:36 --> Database Driver Class Initialized
INFO - 2018-09-06 13:34:36 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:34:36 --> Database Driver Class Initialized
INFO - 2018-09-06 13:34:36 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:34:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 13:34:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 13:34:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 13:34:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-06 13:34:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-06 13:34:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-06 13:34:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-09-06 13:34:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 13:34:36 --> Final output sent to browser
DEBUG - 2018-09-06 13:34:36 --> Total execution time: 0.0512
INFO - 2018-09-06 13:34:41 --> Config Class Initialized
INFO - 2018-09-06 13:34:41 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:34:41 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:34:41 --> Utf8 Class Initialized
INFO - 2018-09-06 13:34:41 --> URI Class Initialized
INFO - 2018-09-06 13:34:41 --> Router Class Initialized
INFO - 2018-09-06 13:34:41 --> Output Class Initialized
INFO - 2018-09-06 13:34:41 --> Security Class Initialized
DEBUG - 2018-09-06 13:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:34:41 --> CSRF cookie sent
INFO - 2018-09-06 13:34:41 --> CSRF token verified
INFO - 2018-09-06 13:34:41 --> Input Class Initialized
INFO - 2018-09-06 13:34:41 --> Language Class Initialized
INFO - 2018-09-06 13:34:41 --> Loader Class Initialized
INFO - 2018-09-06 13:34:41 --> Helper loaded: url_helper
INFO - 2018-09-06 13:34:41 --> Helper loaded: form_helper
INFO - 2018-09-06 13:34:41 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:34:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:34:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:34:41 --> User Agent Class Initialized
INFO - 2018-09-06 13:34:41 --> Controller Class Initialized
INFO - 2018-09-06 13:34:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:34:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:34:41 --> Pixel_Model class loaded
INFO - 2018-09-06 13:34:41 --> Database Driver Class Initialized
INFO - 2018-09-06 13:34:41 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:34:41 --> Form Validation Class Initialized
INFO - 2018-09-06 13:34:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-06 13:34:41 --> Database Driver Class Initialized
INFO - 2018-09-06 13:34:41 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:34:41 --> Config Class Initialized
INFO - 2018-09-06 13:34:41 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:34:41 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:34:41 --> Utf8 Class Initialized
INFO - 2018-09-06 13:34:41 --> URI Class Initialized
INFO - 2018-09-06 13:34:41 --> Router Class Initialized
INFO - 2018-09-06 13:34:41 --> Output Class Initialized
INFO - 2018-09-06 13:34:41 --> Security Class Initialized
DEBUG - 2018-09-06 13:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:34:41 --> CSRF cookie sent
INFO - 2018-09-06 13:34:41 --> Input Class Initialized
INFO - 2018-09-06 13:34:41 --> Language Class Initialized
INFO - 2018-09-06 13:34:41 --> Loader Class Initialized
INFO - 2018-09-06 13:34:41 --> Helper loaded: url_helper
INFO - 2018-09-06 13:34:41 --> Helper loaded: form_helper
INFO - 2018-09-06 13:34:41 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:34:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:34:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:34:41 --> User Agent Class Initialized
INFO - 2018-09-06 13:34:41 --> Controller Class Initialized
INFO - 2018-09-06 13:34:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:34:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:34:41 --> Pixel_Model class loaded
INFO - 2018-09-06 13:34:41 --> Database Driver Class Initialized
INFO - 2018-09-06 13:34:41 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:34:41 --> Database Driver Class Initialized
INFO - 2018-09-06 13:34:41 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:34:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 13:34:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 13:34:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 13:34:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-06 13:34:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-06 13:34:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-06 13:34:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-09-06 13:34:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 13:34:41 --> Final output sent to browser
DEBUG - 2018-09-06 13:34:41 --> Total execution time: 0.0491
INFO - 2018-09-06 13:34:47 --> Config Class Initialized
INFO - 2018-09-06 13:34:47 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:34:47 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:34:47 --> Utf8 Class Initialized
INFO - 2018-09-06 13:34:47 --> URI Class Initialized
INFO - 2018-09-06 13:34:47 --> Router Class Initialized
INFO - 2018-09-06 13:34:47 --> Output Class Initialized
INFO - 2018-09-06 13:34:47 --> Security Class Initialized
DEBUG - 2018-09-06 13:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:34:47 --> CSRF cookie sent
INFO - 2018-09-06 13:34:47 --> CSRF token verified
INFO - 2018-09-06 13:34:47 --> Input Class Initialized
INFO - 2018-09-06 13:34:47 --> Language Class Initialized
INFO - 2018-09-06 13:34:47 --> Loader Class Initialized
INFO - 2018-09-06 13:34:47 --> Helper loaded: url_helper
INFO - 2018-09-06 13:34:47 --> Helper loaded: form_helper
INFO - 2018-09-06 13:34:47 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:34:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:34:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:34:47 --> User Agent Class Initialized
INFO - 2018-09-06 13:34:47 --> Controller Class Initialized
INFO - 2018-09-06 13:34:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:34:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:34:47 --> Pixel_Model class loaded
INFO - 2018-09-06 13:34:47 --> Database Driver Class Initialized
INFO - 2018-09-06 13:34:47 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:34:47 --> Form Validation Class Initialized
INFO - 2018-09-06 13:34:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-06 13:34:47 --> Database Driver Class Initialized
INFO - 2018-09-06 13:34:47 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:34:47 --> Config Class Initialized
INFO - 2018-09-06 13:34:47 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:34:47 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:34:47 --> Utf8 Class Initialized
INFO - 2018-09-06 13:34:47 --> URI Class Initialized
INFO - 2018-09-06 13:34:47 --> Router Class Initialized
INFO - 2018-09-06 13:34:47 --> Output Class Initialized
INFO - 2018-09-06 13:34:47 --> Security Class Initialized
DEBUG - 2018-09-06 13:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:34:47 --> CSRF cookie sent
INFO - 2018-09-06 13:34:47 --> Input Class Initialized
INFO - 2018-09-06 13:34:47 --> Language Class Initialized
INFO - 2018-09-06 13:34:47 --> Loader Class Initialized
INFO - 2018-09-06 13:34:47 --> Helper loaded: url_helper
INFO - 2018-09-06 13:34:47 --> Helper loaded: form_helper
INFO - 2018-09-06 13:34:47 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:34:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:34:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:34:47 --> User Agent Class Initialized
INFO - 2018-09-06 13:34:47 --> Controller Class Initialized
INFO - 2018-09-06 13:34:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:34:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:34:47 --> Pixel_Model class loaded
INFO - 2018-09-06 13:34:47 --> Database Driver Class Initialized
INFO - 2018-09-06 13:34:47 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:34:47 --> Database Driver Class Initialized
INFO - 2018-09-06 13:34:47 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:34:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 13:34:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 13:34:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-09-06 13:34:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 13:34:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-06 13:34:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-06 13:34:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-06 13:34:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-09-06 13:34:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 13:34:47 --> Final output sent to browser
DEBUG - 2018-09-06 13:34:47 --> Total execution time: 0.0453
INFO - 2018-09-06 13:34:52 --> Config Class Initialized
INFO - 2018-09-06 13:34:52 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:34:52 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:34:52 --> Utf8 Class Initialized
INFO - 2018-09-06 13:34:52 --> URI Class Initialized
INFO - 2018-09-06 13:34:52 --> Router Class Initialized
INFO - 2018-09-06 13:34:52 --> Output Class Initialized
INFO - 2018-09-06 13:34:52 --> Security Class Initialized
DEBUG - 2018-09-06 13:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:34:52 --> CSRF cookie sent
INFO - 2018-09-06 13:34:52 --> CSRF token verified
INFO - 2018-09-06 13:34:52 --> Input Class Initialized
INFO - 2018-09-06 13:34:52 --> Language Class Initialized
INFO - 2018-09-06 13:34:52 --> Loader Class Initialized
INFO - 2018-09-06 13:34:52 --> Helper loaded: url_helper
INFO - 2018-09-06 13:34:52 --> Helper loaded: form_helper
INFO - 2018-09-06 13:34:52 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:34:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:34:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:34:52 --> User Agent Class Initialized
INFO - 2018-09-06 13:34:52 --> Controller Class Initialized
INFO - 2018-09-06 13:34:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:34:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:34:52 --> Pixel_Model class loaded
INFO - 2018-09-06 13:34:52 --> Database Driver Class Initialized
INFO - 2018-09-06 13:34:52 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:34:52 --> Form Validation Class Initialized
INFO - 2018-09-06 13:34:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-06 13:34:52 --> Database Driver Class Initialized
INFO - 2018-09-06 13:34:52 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:34:52 --> Config Class Initialized
INFO - 2018-09-06 13:34:52 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:34:52 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:34:52 --> Utf8 Class Initialized
INFO - 2018-09-06 13:34:52 --> URI Class Initialized
INFO - 2018-09-06 13:34:52 --> Router Class Initialized
INFO - 2018-09-06 13:34:52 --> Output Class Initialized
INFO - 2018-09-06 13:34:52 --> Security Class Initialized
DEBUG - 2018-09-06 13:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:34:52 --> CSRF cookie sent
INFO - 2018-09-06 13:34:52 --> Input Class Initialized
INFO - 2018-09-06 13:34:52 --> Language Class Initialized
INFO - 2018-09-06 13:34:52 --> Loader Class Initialized
INFO - 2018-09-06 13:34:52 --> Helper loaded: url_helper
INFO - 2018-09-06 13:34:52 --> Helper loaded: form_helper
INFO - 2018-09-06 13:34:52 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:34:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:34:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:34:52 --> User Agent Class Initialized
INFO - 2018-09-06 13:34:52 --> Controller Class Initialized
INFO - 2018-09-06 13:34:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:34:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:34:52 --> Pixel_Model class loaded
INFO - 2018-09-06 13:34:52 --> Database Driver Class Initialized
INFO - 2018-09-06 13:34:52 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:34:52 --> Database Driver Class Initialized
INFO - 2018-09-06 13:34:52 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:34:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 13:34:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 13:34:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 13:34:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-06 13:34:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-06 13:34:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-06 13:34:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-09-06 13:34:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 13:34:52 --> Final output sent to browser
DEBUG - 2018-09-06 13:34:52 --> Total execution time: 0.0552
INFO - 2018-09-06 13:35:01 --> Config Class Initialized
INFO - 2018-09-06 13:35:01 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:35:01 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:35:01 --> Utf8 Class Initialized
INFO - 2018-09-06 13:35:01 --> URI Class Initialized
INFO - 2018-09-06 13:35:01 --> Router Class Initialized
INFO - 2018-09-06 13:35:01 --> Output Class Initialized
INFO - 2018-09-06 13:35:01 --> Security Class Initialized
DEBUG - 2018-09-06 13:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:35:01 --> CSRF cookie sent
INFO - 2018-09-06 13:35:01 --> CSRF token verified
INFO - 2018-09-06 13:35:01 --> Input Class Initialized
INFO - 2018-09-06 13:35:01 --> Language Class Initialized
INFO - 2018-09-06 13:35:01 --> Loader Class Initialized
INFO - 2018-09-06 13:35:01 --> Helper loaded: url_helper
INFO - 2018-09-06 13:35:01 --> Helper loaded: form_helper
INFO - 2018-09-06 13:35:01 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:35:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:35:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:35:01 --> User Agent Class Initialized
INFO - 2018-09-06 13:35:01 --> Controller Class Initialized
INFO - 2018-09-06 13:35:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:35:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:35:01 --> Pixel_Model class loaded
INFO - 2018-09-06 13:35:01 --> Database Driver Class Initialized
INFO - 2018-09-06 13:35:01 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:35:01 --> Form Validation Class Initialized
INFO - 2018-09-06 13:35:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-06 13:35:01 --> Database Driver Class Initialized
INFO - 2018-09-06 13:35:01 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:35:01 --> Config Class Initialized
INFO - 2018-09-06 13:35:01 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:35:01 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:35:01 --> Utf8 Class Initialized
INFO - 2018-09-06 13:35:01 --> URI Class Initialized
INFO - 2018-09-06 13:35:01 --> Router Class Initialized
INFO - 2018-09-06 13:35:01 --> Output Class Initialized
INFO - 2018-09-06 13:35:01 --> Security Class Initialized
DEBUG - 2018-09-06 13:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:35:01 --> CSRF cookie sent
INFO - 2018-09-06 13:35:01 --> Input Class Initialized
INFO - 2018-09-06 13:35:01 --> Language Class Initialized
INFO - 2018-09-06 13:35:01 --> Loader Class Initialized
INFO - 2018-09-06 13:35:01 --> Helper loaded: url_helper
INFO - 2018-09-06 13:35:01 --> Helper loaded: form_helper
INFO - 2018-09-06 13:35:01 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:35:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:35:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:35:01 --> User Agent Class Initialized
INFO - 2018-09-06 13:35:01 --> Controller Class Initialized
INFO - 2018-09-06 13:35:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:35:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:35:01 --> Pixel_Model class loaded
INFO - 2018-09-06 13:35:01 --> Database Driver Class Initialized
INFO - 2018-09-06 13:35:01 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:35:01 --> Config Class Initialized
INFO - 2018-09-06 13:35:01 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:35:01 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:35:01 --> Utf8 Class Initialized
INFO - 2018-09-06 13:35:01 --> URI Class Initialized
INFO - 2018-09-06 13:35:01 --> Router Class Initialized
INFO - 2018-09-06 13:35:01 --> Output Class Initialized
INFO - 2018-09-06 13:35:01 --> Security Class Initialized
DEBUG - 2018-09-06 13:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:35:01 --> CSRF cookie sent
INFO - 2018-09-06 13:35:01 --> Input Class Initialized
INFO - 2018-09-06 13:35:01 --> Language Class Initialized
INFO - 2018-09-06 13:35:01 --> Loader Class Initialized
INFO - 2018-09-06 13:35:01 --> Helper loaded: url_helper
INFO - 2018-09-06 13:35:01 --> Helper loaded: form_helper
INFO - 2018-09-06 13:35:01 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:35:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:35:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:35:01 --> User Agent Class Initialized
INFO - 2018-09-06 13:35:01 --> Controller Class Initialized
INFO - 2018-09-06 13:35:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:35:01 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-09-06 13:35:01 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-09-06 13:35:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 13:35:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 13:35:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 13:35:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-09-06 13:35:01 --> Could not find the language line "req_email"
INFO - 2018-09-06 13:35:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-09-06 13:35:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 13:35:01 --> Final output sent to browser
DEBUG - 2018-09-06 13:35:01 --> Total execution time: 0.0694
INFO - 2018-09-06 13:35:06 --> Config Class Initialized
INFO - 2018-09-06 13:35:06 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:35:06 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:35:06 --> Utf8 Class Initialized
INFO - 2018-09-06 13:35:06 --> URI Class Initialized
INFO - 2018-09-06 13:35:06 --> Router Class Initialized
INFO - 2018-09-06 13:35:06 --> Output Class Initialized
INFO - 2018-09-06 13:35:06 --> Security Class Initialized
DEBUG - 2018-09-06 13:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:35:06 --> CSRF cookie sent
INFO - 2018-09-06 13:35:06 --> Input Class Initialized
INFO - 2018-09-06 13:35:06 --> Language Class Initialized
INFO - 2018-09-06 13:35:06 --> Loader Class Initialized
INFO - 2018-09-06 13:35:06 --> Helper loaded: url_helper
INFO - 2018-09-06 13:35:06 --> Helper loaded: form_helper
INFO - 2018-09-06 13:35:06 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:35:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:35:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:35:06 --> User Agent Class Initialized
INFO - 2018-09-06 13:35:06 --> Controller Class Initialized
INFO - 2018-09-06 13:35:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:35:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:35:06 --> Pixel_Model class loaded
INFO - 2018-09-06 13:35:06 --> Database Driver Class Initialized
INFO - 2018-09-06 13:35:06 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:35:06 --> Database Driver Class Initialized
INFO - 2018-09-06 13:35:06 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:35:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 13:35:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 13:35:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 13:35:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-06 13:35:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-06 13:35:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-06 13:35:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-09-06 13:35:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 13:35:06 --> Final output sent to browser
DEBUG - 2018-09-06 13:35:06 --> Total execution time: 0.0443
INFO - 2018-09-06 13:40:13 --> Config Class Initialized
INFO - 2018-09-06 13:40:13 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:40:13 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:40:13 --> Utf8 Class Initialized
INFO - 2018-09-06 13:40:13 --> URI Class Initialized
INFO - 2018-09-06 13:40:13 --> Router Class Initialized
INFO - 2018-09-06 13:40:13 --> Output Class Initialized
INFO - 2018-09-06 13:40:13 --> Security Class Initialized
DEBUG - 2018-09-06 13:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:40:13 --> CSRF cookie sent
INFO - 2018-09-06 13:40:13 --> CSRF token verified
INFO - 2018-09-06 13:40:13 --> Input Class Initialized
INFO - 2018-09-06 13:40:13 --> Language Class Initialized
INFO - 2018-09-06 13:40:13 --> Loader Class Initialized
INFO - 2018-09-06 13:40:13 --> Helper loaded: url_helper
INFO - 2018-09-06 13:40:13 --> Helper loaded: form_helper
INFO - 2018-09-06 13:40:13 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:40:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:40:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:40:13 --> User Agent Class Initialized
INFO - 2018-09-06 13:40:13 --> Controller Class Initialized
INFO - 2018-09-06 13:40:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:40:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:40:13 --> Pixel_Model class loaded
INFO - 2018-09-06 13:40:13 --> Database Driver Class Initialized
INFO - 2018-09-06 13:40:13 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:40:13 --> Form Validation Class Initialized
INFO - 2018-09-06 13:40:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-06 13:40:13 --> Database Driver Class Initialized
INFO - 2018-09-06 13:40:13 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:40:13 --> Config Class Initialized
INFO - 2018-09-06 13:40:13 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:40:13 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:40:13 --> Utf8 Class Initialized
INFO - 2018-09-06 13:40:13 --> URI Class Initialized
INFO - 2018-09-06 13:40:13 --> Router Class Initialized
INFO - 2018-09-06 13:40:13 --> Output Class Initialized
INFO - 2018-09-06 13:40:13 --> Security Class Initialized
DEBUG - 2018-09-06 13:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:40:13 --> CSRF cookie sent
INFO - 2018-09-06 13:40:13 --> Input Class Initialized
INFO - 2018-09-06 13:40:13 --> Language Class Initialized
INFO - 2018-09-06 13:40:13 --> Loader Class Initialized
INFO - 2018-09-06 13:40:13 --> Helper loaded: url_helper
INFO - 2018-09-06 13:40:13 --> Helper loaded: form_helper
INFO - 2018-09-06 13:40:13 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:40:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:40:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:40:13 --> User Agent Class Initialized
INFO - 2018-09-06 13:40:13 --> Controller Class Initialized
INFO - 2018-09-06 13:40:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:40:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:40:13 --> Pixel_Model class loaded
INFO - 2018-09-06 13:40:13 --> Database Driver Class Initialized
INFO - 2018-09-06 13:40:13 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:40:13 --> Config Class Initialized
INFO - 2018-09-06 13:40:13 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:40:13 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:40:13 --> Utf8 Class Initialized
INFO - 2018-09-06 13:40:13 --> URI Class Initialized
INFO - 2018-09-06 13:40:13 --> Router Class Initialized
INFO - 2018-09-06 13:40:13 --> Output Class Initialized
INFO - 2018-09-06 13:40:13 --> Security Class Initialized
DEBUG - 2018-09-06 13:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:40:13 --> CSRF cookie sent
INFO - 2018-09-06 13:40:13 --> Input Class Initialized
INFO - 2018-09-06 13:40:13 --> Language Class Initialized
INFO - 2018-09-06 13:40:13 --> Loader Class Initialized
INFO - 2018-09-06 13:40:13 --> Helper loaded: url_helper
INFO - 2018-09-06 13:40:13 --> Helper loaded: form_helper
INFO - 2018-09-06 13:40:13 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:40:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:40:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:40:13 --> User Agent Class Initialized
INFO - 2018-09-06 13:40:13 --> Controller Class Initialized
INFO - 2018-09-06 13:40:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:40:13 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-09-06 13:40:13 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-09-06 13:40:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 13:40:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 13:40:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 13:40:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-09-06 13:40:13 --> Could not find the language line "req_email"
INFO - 2018-09-06 13:40:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-09-06 13:40:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 13:40:13 --> Final output sent to browser
DEBUG - 2018-09-06 13:40:13 --> Total execution time: 0.0248
INFO - 2018-09-06 13:40:22 --> Config Class Initialized
INFO - 2018-09-06 13:40:22 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:40:22 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:40:22 --> Utf8 Class Initialized
INFO - 2018-09-06 13:40:22 --> URI Class Initialized
INFO - 2018-09-06 13:40:22 --> Router Class Initialized
INFO - 2018-09-06 13:40:22 --> Output Class Initialized
INFO - 2018-09-06 13:40:22 --> Security Class Initialized
DEBUG - 2018-09-06 13:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:40:22 --> CSRF cookie sent
INFO - 2018-09-06 13:40:22 --> Input Class Initialized
INFO - 2018-09-06 13:40:22 --> Language Class Initialized
INFO - 2018-09-06 13:40:22 --> Loader Class Initialized
INFO - 2018-09-06 13:40:22 --> Helper loaded: url_helper
INFO - 2018-09-06 13:40:22 --> Helper loaded: form_helper
INFO - 2018-09-06 13:40:22 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:40:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:40:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:40:22 --> User Agent Class Initialized
INFO - 2018-09-06 13:40:22 --> Controller Class Initialized
INFO - 2018-09-06 13:40:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:40:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:40:22 --> Pixel_Model class loaded
INFO - 2018-09-06 13:40:22 --> Database Driver Class Initialized
INFO - 2018-09-06 13:40:22 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:40:22 --> Database Driver Class Initialized
INFO - 2018-09-06 13:40:22 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:40:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 13:40:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 13:40:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 13:40:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-06 13:40:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-06 13:40:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-06 13:40:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-09-06 13:40:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 13:40:22 --> Final output sent to browser
DEBUG - 2018-09-06 13:40:22 --> Total execution time: 0.0398
INFO - 2018-09-06 13:40:43 --> Config Class Initialized
INFO - 2018-09-06 13:40:43 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:40:43 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:40:43 --> Utf8 Class Initialized
INFO - 2018-09-06 13:40:43 --> URI Class Initialized
INFO - 2018-09-06 13:40:43 --> Router Class Initialized
INFO - 2018-09-06 13:40:43 --> Output Class Initialized
INFO - 2018-09-06 13:40:43 --> Security Class Initialized
DEBUG - 2018-09-06 13:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:40:43 --> CSRF cookie sent
INFO - 2018-09-06 13:40:43 --> Input Class Initialized
INFO - 2018-09-06 13:40:43 --> Language Class Initialized
INFO - 2018-09-06 13:40:43 --> Loader Class Initialized
INFO - 2018-09-06 13:40:43 --> Helper loaded: url_helper
INFO - 2018-09-06 13:40:43 --> Helper loaded: form_helper
INFO - 2018-09-06 13:40:43 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:40:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:40:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:40:43 --> User Agent Class Initialized
INFO - 2018-09-06 13:40:43 --> Controller Class Initialized
INFO - 2018-09-06 13:40:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:40:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:40:43 --> Pixel_Model class loaded
INFO - 2018-09-06 13:40:43 --> Database Driver Class Initialized
INFO - 2018-09-06 13:40:43 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:40:43 --> Database Driver Class Initialized
INFO - 2018-09-06 13:40:43 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:40:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 13:40:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 13:40:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 13:40:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-06 13:40:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/save_exit.php
INFO - 2018-09-06 13:40:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 13:40:43 --> Final output sent to browser
DEBUG - 2018-09-06 13:40:43 --> Total execution time: 0.0511
INFO - 2018-09-06 13:40:45 --> Config Class Initialized
INFO - 2018-09-06 13:40:45 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:40:45 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:40:45 --> Utf8 Class Initialized
INFO - 2018-09-06 13:40:45 --> URI Class Initialized
INFO - 2018-09-06 13:40:45 --> Router Class Initialized
INFO - 2018-09-06 13:40:45 --> Output Class Initialized
INFO - 2018-09-06 13:40:45 --> Security Class Initialized
DEBUG - 2018-09-06 13:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:40:45 --> CSRF cookie sent
INFO - 2018-09-06 13:40:45 --> Input Class Initialized
INFO - 2018-09-06 13:40:45 --> Language Class Initialized
INFO - 2018-09-06 13:40:45 --> Loader Class Initialized
INFO - 2018-09-06 13:40:45 --> Helper loaded: url_helper
INFO - 2018-09-06 13:40:45 --> Helper loaded: form_helper
INFO - 2018-09-06 13:40:45 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:40:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:40:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:40:45 --> User Agent Class Initialized
INFO - 2018-09-06 13:40:45 --> Controller Class Initialized
INFO - 2018-09-06 13:40:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:40:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:40:45 --> Pixel_Model class loaded
INFO - 2018-09-06 13:40:45 --> Database Driver Class Initialized
INFO - 2018-09-06 13:40:45 --> Model "RegistrationModel" initialized
DEBUG - 2018-09-06 13:40:45 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-09-06 13:40:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 13:40:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 13:40:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 13:40:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-09-06 13:40:45 --> Could not find the language line "req_email"
INFO - 2018-09-06 13:40:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup.php
INFO - 2018-09-06 13:40:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 13:40:45 --> Final output sent to browser
DEBUG - 2018-09-06 13:40:45 --> Total execution time: 0.0453
INFO - 2018-09-06 13:40:52 --> Config Class Initialized
INFO - 2018-09-06 13:40:52 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:40:52 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:40:52 --> Utf8 Class Initialized
INFO - 2018-09-06 13:40:52 --> URI Class Initialized
INFO - 2018-09-06 13:40:52 --> Router Class Initialized
INFO - 2018-09-06 13:40:52 --> Output Class Initialized
INFO - 2018-09-06 13:40:52 --> Security Class Initialized
DEBUG - 2018-09-06 13:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:40:52 --> CSRF cookie sent
INFO - 2018-09-06 13:40:52 --> Input Class Initialized
INFO - 2018-09-06 13:40:52 --> Language Class Initialized
INFO - 2018-09-06 13:40:52 --> Loader Class Initialized
INFO - 2018-09-06 13:40:52 --> Helper loaded: url_helper
INFO - 2018-09-06 13:40:52 --> Helper loaded: form_helper
INFO - 2018-09-06 13:40:52 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:40:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:40:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:40:52 --> User Agent Class Initialized
INFO - 2018-09-06 13:40:52 --> Controller Class Initialized
INFO - 2018-09-06 13:40:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:40:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:40:52 --> Pixel_Model class loaded
INFO - 2018-09-06 13:40:52 --> Database Driver Class Initialized
INFO - 2018-09-06 13:40:52 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:40:52 --> Database Driver Class Initialized
INFO - 2018-09-06 13:40:52 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:40:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 13:40:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 13:40:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 13:40:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-06 13:40:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/save_exit.php
INFO - 2018-09-06 13:40:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 13:40:52 --> Final output sent to browser
DEBUG - 2018-09-06 13:40:52 --> Total execution time: 0.0476
INFO - 2018-09-06 13:40:53 --> Config Class Initialized
INFO - 2018-09-06 13:40:53 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:40:53 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:40:53 --> Utf8 Class Initialized
INFO - 2018-09-06 13:40:53 --> URI Class Initialized
INFO - 2018-09-06 13:40:53 --> Router Class Initialized
INFO - 2018-09-06 13:40:53 --> Output Class Initialized
INFO - 2018-09-06 13:40:53 --> Security Class Initialized
DEBUG - 2018-09-06 13:40:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:40:53 --> CSRF cookie sent
INFO - 2018-09-06 13:40:53 --> Input Class Initialized
INFO - 2018-09-06 13:40:53 --> Language Class Initialized
INFO - 2018-09-06 13:40:53 --> Loader Class Initialized
INFO - 2018-09-06 13:40:53 --> Helper loaded: url_helper
INFO - 2018-09-06 13:40:53 --> Helper loaded: form_helper
INFO - 2018-09-06 13:40:53 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:40:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:40:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:40:53 --> User Agent Class Initialized
INFO - 2018-09-06 13:40:53 --> Controller Class Initialized
INFO - 2018-09-06 13:40:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:40:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:40:53 --> Pixel_Model class loaded
INFO - 2018-09-06 13:40:53 --> Database Driver Class Initialized
INFO - 2018-09-06 13:40:53 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:40:53 --> Database Driver Class Initialized
INFO - 2018-09-06 13:40:53 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:40:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 13:40:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 13:40:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 13:40:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-06 13:40:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-06 13:40:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-06 13:40:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-09-06 13:40:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 13:40:53 --> Final output sent to browser
DEBUG - 2018-09-06 13:40:53 --> Total execution time: 0.0400
INFO - 2018-09-06 13:41:43 --> Config Class Initialized
INFO - 2018-09-06 13:41:43 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:41:43 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:41:43 --> Utf8 Class Initialized
INFO - 2018-09-06 13:41:43 --> URI Class Initialized
INFO - 2018-09-06 13:41:43 --> Router Class Initialized
INFO - 2018-09-06 13:41:43 --> Output Class Initialized
INFO - 2018-09-06 13:41:43 --> Security Class Initialized
DEBUG - 2018-09-06 13:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:41:43 --> CSRF cookie sent
INFO - 2018-09-06 13:41:43 --> CSRF token verified
INFO - 2018-09-06 13:41:43 --> Input Class Initialized
INFO - 2018-09-06 13:41:43 --> Language Class Initialized
INFO - 2018-09-06 13:41:43 --> Loader Class Initialized
INFO - 2018-09-06 13:41:43 --> Helper loaded: url_helper
INFO - 2018-09-06 13:41:43 --> Helper loaded: form_helper
INFO - 2018-09-06 13:41:43 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:41:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:41:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:41:43 --> User Agent Class Initialized
INFO - 2018-09-06 13:41:43 --> Controller Class Initialized
INFO - 2018-09-06 13:41:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:41:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:41:43 --> Pixel_Model class loaded
INFO - 2018-09-06 13:41:43 --> Database Driver Class Initialized
INFO - 2018-09-06 13:41:43 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:41:43 --> Form Validation Class Initialized
INFO - 2018-09-06 13:41:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-06 13:41:43 --> Database Driver Class Initialized
INFO - 2018-09-06 13:41:43 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:41:43 --> Config Class Initialized
INFO - 2018-09-06 13:41:43 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:41:43 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:41:43 --> Utf8 Class Initialized
INFO - 2018-09-06 13:41:43 --> URI Class Initialized
INFO - 2018-09-06 13:41:43 --> Router Class Initialized
INFO - 2018-09-06 13:41:43 --> Output Class Initialized
INFO - 2018-09-06 13:41:43 --> Security Class Initialized
DEBUG - 2018-09-06 13:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:41:43 --> CSRF cookie sent
INFO - 2018-09-06 13:41:43 --> Input Class Initialized
INFO - 2018-09-06 13:41:43 --> Language Class Initialized
INFO - 2018-09-06 13:41:43 --> Loader Class Initialized
INFO - 2018-09-06 13:41:43 --> Helper loaded: url_helper
INFO - 2018-09-06 13:41:43 --> Helper loaded: form_helper
INFO - 2018-09-06 13:41:43 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:41:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:41:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:41:43 --> User Agent Class Initialized
INFO - 2018-09-06 13:41:43 --> Controller Class Initialized
INFO - 2018-09-06 13:41:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:41:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:41:43 --> Pixel_Model class loaded
INFO - 2018-09-06 13:41:43 --> Database Driver Class Initialized
INFO - 2018-09-06 13:41:43 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:41:44 --> Config Class Initialized
INFO - 2018-09-06 13:41:44 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:41:44 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:41:44 --> Utf8 Class Initialized
INFO - 2018-09-06 13:41:44 --> URI Class Initialized
INFO - 2018-09-06 13:41:44 --> Router Class Initialized
INFO - 2018-09-06 13:41:44 --> Output Class Initialized
INFO - 2018-09-06 13:41:44 --> Security Class Initialized
DEBUG - 2018-09-06 13:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:41:44 --> CSRF cookie sent
INFO - 2018-09-06 13:41:44 --> Input Class Initialized
INFO - 2018-09-06 13:41:44 --> Language Class Initialized
INFO - 2018-09-06 13:41:44 --> Loader Class Initialized
INFO - 2018-09-06 13:41:44 --> Helper loaded: url_helper
INFO - 2018-09-06 13:41:44 --> Helper loaded: form_helper
INFO - 2018-09-06 13:41:44 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:41:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:41:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:41:44 --> User Agent Class Initialized
INFO - 2018-09-06 13:41:44 --> Controller Class Initialized
INFO - 2018-09-06 13:41:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:41:44 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-09-06 13:41:44 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-09-06 13:41:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 13:41:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 13:41:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 13:41:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-09-06 13:41:44 --> Could not find the language line "req_email"
INFO - 2018-09-06 13:41:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-09-06 13:41:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 13:41:44 --> Final output sent to browser
DEBUG - 2018-09-06 13:41:44 --> Total execution time: 0.0197
INFO - 2018-09-06 13:41:47 --> Config Class Initialized
INFO - 2018-09-06 13:41:47 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:41:47 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:41:47 --> Utf8 Class Initialized
INFO - 2018-09-06 13:41:47 --> URI Class Initialized
INFO - 2018-09-06 13:41:47 --> Router Class Initialized
INFO - 2018-09-06 13:41:47 --> Output Class Initialized
INFO - 2018-09-06 13:41:47 --> Security Class Initialized
DEBUG - 2018-09-06 13:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:41:47 --> CSRF cookie sent
INFO - 2018-09-06 13:41:47 --> Input Class Initialized
INFO - 2018-09-06 13:41:47 --> Language Class Initialized
INFO - 2018-09-06 13:41:47 --> Loader Class Initialized
INFO - 2018-09-06 13:41:47 --> Helper loaded: url_helper
INFO - 2018-09-06 13:41:47 --> Helper loaded: form_helper
INFO - 2018-09-06 13:41:47 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:41:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:41:47 --> User Agent Class Initialized
INFO - 2018-09-06 13:41:47 --> Controller Class Initialized
INFO - 2018-09-06 13:41:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:41:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:41:47 --> Pixel_Model class loaded
INFO - 2018-09-06 13:41:47 --> Database Driver Class Initialized
INFO - 2018-09-06 13:41:47 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:41:47 --> Database Driver Class Initialized
INFO - 2018-09-06 13:41:47 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:41:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 13:41:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 13:41:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 13:41:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-06 13:41:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-06 13:41:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-06 13:41:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-09-06 13:41:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 13:41:47 --> Final output sent to browser
DEBUG - 2018-09-06 13:41:47 --> Total execution time: 0.0426
INFO - 2018-09-06 13:41:52 --> Config Class Initialized
INFO - 2018-09-06 13:41:52 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:41:52 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:41:52 --> Utf8 Class Initialized
INFO - 2018-09-06 13:41:52 --> URI Class Initialized
INFO - 2018-09-06 13:41:52 --> Router Class Initialized
INFO - 2018-09-06 13:41:52 --> Output Class Initialized
INFO - 2018-09-06 13:41:52 --> Security Class Initialized
DEBUG - 2018-09-06 13:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:41:52 --> CSRF cookie sent
INFO - 2018-09-06 13:41:52 --> Input Class Initialized
INFO - 2018-09-06 13:41:52 --> Language Class Initialized
INFO - 2018-09-06 13:41:52 --> Loader Class Initialized
INFO - 2018-09-06 13:41:52 --> Helper loaded: url_helper
INFO - 2018-09-06 13:41:52 --> Helper loaded: form_helper
INFO - 2018-09-06 13:41:52 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:41:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:41:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:41:52 --> User Agent Class Initialized
INFO - 2018-09-06 13:41:52 --> Controller Class Initialized
INFO - 2018-09-06 13:41:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:41:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:41:52 --> Pixel_Model class loaded
INFO - 2018-09-06 13:41:52 --> Database Driver Class Initialized
INFO - 2018-09-06 13:41:52 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:41:52 --> Database Driver Class Initialized
INFO - 2018-09-06 13:41:52 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:41:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 13:41:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 13:41:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-09-06 13:41:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 13:41:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-06 13:41:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-06 13:41:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-06 13:41:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-09-06 13:41:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 13:41:52 --> Final output sent to browser
DEBUG - 2018-09-06 13:41:52 --> Total execution time: 0.0396
INFO - 2018-09-06 13:42:38 --> Config Class Initialized
INFO - 2018-09-06 13:42:38 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:42:38 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:42:38 --> Utf8 Class Initialized
INFO - 2018-09-06 13:42:38 --> URI Class Initialized
INFO - 2018-09-06 13:42:38 --> Router Class Initialized
INFO - 2018-09-06 13:42:38 --> Output Class Initialized
INFO - 2018-09-06 13:42:38 --> Security Class Initialized
DEBUG - 2018-09-06 13:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:42:38 --> CSRF cookie sent
INFO - 2018-09-06 13:42:38 --> CSRF token verified
INFO - 2018-09-06 13:42:38 --> Input Class Initialized
INFO - 2018-09-06 13:42:38 --> Language Class Initialized
INFO - 2018-09-06 13:42:38 --> Loader Class Initialized
INFO - 2018-09-06 13:42:38 --> Helper loaded: url_helper
INFO - 2018-09-06 13:42:38 --> Helper loaded: form_helper
INFO - 2018-09-06 13:42:38 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:42:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:42:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:42:38 --> User Agent Class Initialized
INFO - 2018-09-06 13:42:38 --> Controller Class Initialized
INFO - 2018-09-06 13:42:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:42:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:42:38 --> Pixel_Model class loaded
INFO - 2018-09-06 13:42:38 --> Database Driver Class Initialized
INFO - 2018-09-06 13:42:38 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:42:38 --> Form Validation Class Initialized
INFO - 2018-09-06 13:42:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-06 13:42:38 --> Database Driver Class Initialized
INFO - 2018-09-06 13:42:38 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:42:38 --> Config Class Initialized
INFO - 2018-09-06 13:42:38 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:42:38 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:42:38 --> Utf8 Class Initialized
INFO - 2018-09-06 13:42:38 --> URI Class Initialized
INFO - 2018-09-06 13:42:38 --> Router Class Initialized
INFO - 2018-09-06 13:42:38 --> Output Class Initialized
INFO - 2018-09-06 13:42:38 --> Security Class Initialized
DEBUG - 2018-09-06 13:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:42:38 --> CSRF cookie sent
INFO - 2018-09-06 13:42:38 --> Input Class Initialized
INFO - 2018-09-06 13:42:38 --> Language Class Initialized
INFO - 2018-09-06 13:42:38 --> Loader Class Initialized
INFO - 2018-09-06 13:42:38 --> Helper loaded: url_helper
INFO - 2018-09-06 13:42:38 --> Helper loaded: form_helper
INFO - 2018-09-06 13:42:38 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:42:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:42:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:42:38 --> User Agent Class Initialized
INFO - 2018-09-06 13:42:38 --> Controller Class Initialized
INFO - 2018-09-06 13:42:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:42:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:42:38 --> Pixel_Model class loaded
INFO - 2018-09-06 13:42:38 --> Database Driver Class Initialized
INFO - 2018-09-06 13:42:38 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:42:38 --> Database Driver Class Initialized
INFO - 2018-09-06 13:42:38 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:42:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 13:42:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 13:42:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 13:42:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-06 13:42:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-06 13:42:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-06 13:42:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-09-06 13:42:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 13:42:38 --> Final output sent to browser
DEBUG - 2018-09-06 13:42:38 --> Total execution time: 0.0469
INFO - 2018-09-06 13:42:39 --> Config Class Initialized
INFO - 2018-09-06 13:42:39 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:42:39 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:42:39 --> Utf8 Class Initialized
INFO - 2018-09-06 13:42:39 --> URI Class Initialized
INFO - 2018-09-06 13:42:39 --> Router Class Initialized
INFO - 2018-09-06 13:42:39 --> Output Class Initialized
INFO - 2018-09-06 13:42:39 --> Security Class Initialized
DEBUG - 2018-09-06 13:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:42:39 --> CSRF cookie sent
INFO - 2018-09-06 13:42:39 --> Input Class Initialized
INFO - 2018-09-06 13:42:39 --> Language Class Initialized
INFO - 2018-09-06 13:42:39 --> Loader Class Initialized
INFO - 2018-09-06 13:42:39 --> Helper loaded: url_helper
INFO - 2018-09-06 13:42:39 --> Helper loaded: form_helper
INFO - 2018-09-06 13:42:39 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:42:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:42:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:42:39 --> User Agent Class Initialized
INFO - 2018-09-06 13:42:39 --> Controller Class Initialized
INFO - 2018-09-06 13:42:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:42:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:42:39 --> Pixel_Model class loaded
INFO - 2018-09-06 13:42:39 --> Database Driver Class Initialized
INFO - 2018-09-06 13:42:39 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:42:39 --> Database Driver Class Initialized
INFO - 2018-09-06 13:42:39 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:42:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 13:42:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 13:42:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 13:42:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-06 13:42:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-06 13:42:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-06 13:42:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/cohabitation.php
INFO - 2018-09-06 13:42:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 13:42:39 --> Final output sent to browser
DEBUG - 2018-09-06 13:42:39 --> Total execution time: 0.0419
INFO - 2018-09-06 13:42:40 --> Config Class Initialized
INFO - 2018-09-06 13:42:40 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:42:40 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:42:40 --> Utf8 Class Initialized
INFO - 2018-09-06 13:42:40 --> URI Class Initialized
INFO - 2018-09-06 13:42:40 --> Router Class Initialized
INFO - 2018-09-06 13:42:40 --> Output Class Initialized
INFO - 2018-09-06 13:42:40 --> Security Class Initialized
DEBUG - 2018-09-06 13:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:42:40 --> CSRF cookie sent
INFO - 2018-09-06 13:42:40 --> Input Class Initialized
INFO - 2018-09-06 13:42:40 --> Language Class Initialized
INFO - 2018-09-06 13:42:40 --> Loader Class Initialized
INFO - 2018-09-06 13:42:40 --> Helper loaded: url_helper
INFO - 2018-09-06 13:42:40 --> Helper loaded: form_helper
INFO - 2018-09-06 13:42:40 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:42:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:42:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:42:40 --> User Agent Class Initialized
INFO - 2018-09-06 13:42:40 --> Controller Class Initialized
INFO - 2018-09-06 13:42:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:42:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:42:40 --> Pixel_Model class loaded
INFO - 2018-09-06 13:42:40 --> Database Driver Class Initialized
INFO - 2018-09-06 13:42:40 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:42:40 --> Database Driver Class Initialized
INFO - 2018-09-06 13:42:40 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:42:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 13:42:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 13:42:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 13:42:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-06 13:42:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-06 13:42:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-06 13:42:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-09-06 13:42:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 13:42:40 --> Final output sent to browser
DEBUG - 2018-09-06 13:42:40 --> Total execution time: 0.0544
INFO - 2018-09-06 13:42:42 --> Config Class Initialized
INFO - 2018-09-06 13:42:42 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:42:42 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:42:42 --> Utf8 Class Initialized
INFO - 2018-09-06 13:42:42 --> URI Class Initialized
INFO - 2018-09-06 13:42:42 --> Router Class Initialized
INFO - 2018-09-06 13:42:42 --> Output Class Initialized
INFO - 2018-09-06 13:42:42 --> Security Class Initialized
DEBUG - 2018-09-06 13:42:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:42:42 --> CSRF cookie sent
INFO - 2018-09-06 13:42:42 --> Input Class Initialized
INFO - 2018-09-06 13:42:42 --> Language Class Initialized
INFO - 2018-09-06 13:42:42 --> Loader Class Initialized
INFO - 2018-09-06 13:42:42 --> Helper loaded: url_helper
INFO - 2018-09-06 13:42:42 --> Helper loaded: form_helper
INFO - 2018-09-06 13:42:42 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:42:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:42:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:42:42 --> User Agent Class Initialized
INFO - 2018-09-06 13:42:42 --> Controller Class Initialized
INFO - 2018-09-06 13:42:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:42:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:42:42 --> Pixel_Model class loaded
INFO - 2018-09-06 13:42:42 --> Database Driver Class Initialized
INFO - 2018-09-06 13:42:42 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:42:42 --> Database Driver Class Initialized
INFO - 2018-09-06 13:42:42 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:42:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 13:42:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 13:42:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-09-06 13:42:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 13:42:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-06 13:42:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-06 13:42:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-06 13:42:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-09-06 13:42:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 13:42:42 --> Final output sent to browser
DEBUG - 2018-09-06 13:42:42 --> Total execution time: 0.0513
INFO - 2018-09-06 13:42:46 --> Config Class Initialized
INFO - 2018-09-06 13:42:46 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:42:46 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:42:46 --> Utf8 Class Initialized
INFO - 2018-09-06 13:42:46 --> URI Class Initialized
INFO - 2018-09-06 13:42:46 --> Router Class Initialized
INFO - 2018-09-06 13:42:46 --> Output Class Initialized
INFO - 2018-09-06 13:42:46 --> Security Class Initialized
DEBUG - 2018-09-06 13:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:42:46 --> CSRF cookie sent
INFO - 2018-09-06 13:42:46 --> CSRF token verified
INFO - 2018-09-06 13:42:46 --> Input Class Initialized
INFO - 2018-09-06 13:42:46 --> Language Class Initialized
INFO - 2018-09-06 13:42:46 --> Loader Class Initialized
INFO - 2018-09-06 13:42:46 --> Helper loaded: url_helper
INFO - 2018-09-06 13:42:46 --> Helper loaded: form_helper
INFO - 2018-09-06 13:42:46 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:42:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:42:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:42:46 --> User Agent Class Initialized
INFO - 2018-09-06 13:42:46 --> Controller Class Initialized
INFO - 2018-09-06 13:42:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:42:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:42:47 --> Pixel_Model class loaded
INFO - 2018-09-06 13:42:47 --> Database Driver Class Initialized
INFO - 2018-09-06 13:42:47 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:42:47 --> Form Validation Class Initialized
INFO - 2018-09-06 13:42:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-06 13:42:47 --> Database Driver Class Initialized
INFO - 2018-09-06 13:42:47 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:42:47 --> Config Class Initialized
INFO - 2018-09-06 13:42:47 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:42:47 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:42:47 --> Utf8 Class Initialized
INFO - 2018-09-06 13:42:47 --> URI Class Initialized
INFO - 2018-09-06 13:42:47 --> Router Class Initialized
INFO - 2018-09-06 13:42:47 --> Output Class Initialized
INFO - 2018-09-06 13:42:47 --> Security Class Initialized
DEBUG - 2018-09-06 13:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:42:47 --> CSRF cookie sent
INFO - 2018-09-06 13:42:47 --> Input Class Initialized
INFO - 2018-09-06 13:42:47 --> Language Class Initialized
INFO - 2018-09-06 13:42:47 --> Loader Class Initialized
INFO - 2018-09-06 13:42:47 --> Helper loaded: url_helper
INFO - 2018-09-06 13:42:47 --> Helper loaded: form_helper
INFO - 2018-09-06 13:42:47 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:42:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:42:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:42:47 --> User Agent Class Initialized
INFO - 2018-09-06 13:42:47 --> Controller Class Initialized
INFO - 2018-09-06 13:42:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:42:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:42:47 --> Pixel_Model class loaded
INFO - 2018-09-06 13:42:47 --> Database Driver Class Initialized
INFO - 2018-09-06 13:42:47 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:42:47 --> Database Driver Class Initialized
INFO - 2018-09-06 13:42:47 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:42:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 13:42:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 13:42:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 13:42:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-06 13:42:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-06 13:42:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-06 13:42:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-09-06 13:42:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 13:42:47 --> Final output sent to browser
DEBUG - 2018-09-06 13:42:47 --> Total execution time: 0.0398
INFO - 2018-09-06 13:42:49 --> Config Class Initialized
INFO - 2018-09-06 13:42:49 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:42:49 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:42:49 --> Utf8 Class Initialized
INFO - 2018-09-06 13:42:49 --> URI Class Initialized
INFO - 2018-09-06 13:42:49 --> Router Class Initialized
INFO - 2018-09-06 13:42:49 --> Output Class Initialized
INFO - 2018-09-06 13:42:49 --> Security Class Initialized
DEBUG - 2018-09-06 13:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:42:49 --> CSRF cookie sent
INFO - 2018-09-06 13:42:49 --> CSRF token verified
INFO - 2018-09-06 13:42:49 --> Input Class Initialized
INFO - 2018-09-06 13:42:49 --> Language Class Initialized
INFO - 2018-09-06 13:42:49 --> Loader Class Initialized
INFO - 2018-09-06 13:42:49 --> Helper loaded: url_helper
INFO - 2018-09-06 13:42:49 --> Helper loaded: form_helper
INFO - 2018-09-06 13:42:49 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:42:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:42:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:42:49 --> User Agent Class Initialized
INFO - 2018-09-06 13:42:49 --> Controller Class Initialized
INFO - 2018-09-06 13:42:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:42:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:42:49 --> Pixel_Model class loaded
INFO - 2018-09-06 13:42:49 --> Database Driver Class Initialized
INFO - 2018-09-06 13:42:49 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:42:49 --> Form Validation Class Initialized
INFO - 2018-09-06 13:42:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-06 13:42:49 --> Database Driver Class Initialized
INFO - 2018-09-06 13:42:49 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:42:49 --> Config Class Initialized
INFO - 2018-09-06 13:42:49 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:42:49 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:42:49 --> Utf8 Class Initialized
INFO - 2018-09-06 13:42:49 --> URI Class Initialized
INFO - 2018-09-06 13:42:49 --> Router Class Initialized
INFO - 2018-09-06 13:42:49 --> Output Class Initialized
INFO - 2018-09-06 13:42:49 --> Security Class Initialized
DEBUG - 2018-09-06 13:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:42:49 --> CSRF cookie sent
INFO - 2018-09-06 13:42:49 --> Input Class Initialized
INFO - 2018-09-06 13:42:49 --> Language Class Initialized
INFO - 2018-09-06 13:42:49 --> Loader Class Initialized
INFO - 2018-09-06 13:42:49 --> Helper loaded: url_helper
INFO - 2018-09-06 13:42:49 --> Helper loaded: form_helper
INFO - 2018-09-06 13:42:49 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:42:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:42:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:42:49 --> User Agent Class Initialized
INFO - 2018-09-06 13:42:49 --> Controller Class Initialized
INFO - 2018-09-06 13:42:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:42:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:42:49 --> Pixel_Model class loaded
INFO - 2018-09-06 13:42:49 --> Database Driver Class Initialized
INFO - 2018-09-06 13:42:49 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:42:49 --> Config Class Initialized
INFO - 2018-09-06 13:42:49 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:42:49 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:42:49 --> Utf8 Class Initialized
INFO - 2018-09-06 13:42:49 --> URI Class Initialized
INFO - 2018-09-06 13:42:49 --> Router Class Initialized
INFO - 2018-09-06 13:42:49 --> Output Class Initialized
INFO - 2018-09-06 13:42:49 --> Security Class Initialized
DEBUG - 2018-09-06 13:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:42:49 --> CSRF cookie sent
INFO - 2018-09-06 13:42:49 --> Input Class Initialized
INFO - 2018-09-06 13:42:49 --> Language Class Initialized
INFO - 2018-09-06 13:42:49 --> Loader Class Initialized
INFO - 2018-09-06 13:42:49 --> Helper loaded: url_helper
INFO - 2018-09-06 13:42:49 --> Helper loaded: form_helper
INFO - 2018-09-06 13:42:49 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:42:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:42:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:42:49 --> User Agent Class Initialized
INFO - 2018-09-06 13:42:49 --> Controller Class Initialized
INFO - 2018-09-06 13:42:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:42:49 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-09-06 13:42:49 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-09-06 13:42:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 13:42:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 13:42:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 13:42:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-09-06 13:42:49 --> Could not find the language line "req_email"
INFO - 2018-09-06 13:42:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-09-06 13:42:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 13:42:49 --> Final output sent to browser
DEBUG - 2018-09-06 13:42:49 --> Total execution time: 0.0233
INFO - 2018-09-06 13:42:50 --> Config Class Initialized
INFO - 2018-09-06 13:42:50 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:42:50 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:42:50 --> Utf8 Class Initialized
INFO - 2018-09-06 13:42:50 --> URI Class Initialized
INFO - 2018-09-06 13:42:50 --> Router Class Initialized
INFO - 2018-09-06 13:42:50 --> Output Class Initialized
INFO - 2018-09-06 13:42:50 --> Security Class Initialized
DEBUG - 2018-09-06 13:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:42:50 --> CSRF cookie sent
INFO - 2018-09-06 13:42:50 --> CSRF token verified
INFO - 2018-09-06 13:42:50 --> Input Class Initialized
INFO - 2018-09-06 13:42:50 --> Language Class Initialized
INFO - 2018-09-06 13:42:50 --> Loader Class Initialized
INFO - 2018-09-06 13:42:50 --> Helper loaded: url_helper
INFO - 2018-09-06 13:42:50 --> Helper loaded: form_helper
INFO - 2018-09-06 13:42:50 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:42:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:42:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:42:50 --> User Agent Class Initialized
INFO - 2018-09-06 13:42:50 --> Controller Class Initialized
INFO - 2018-09-06 13:42:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:42:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:42:50 --> Pixel_Model class loaded
INFO - 2018-09-06 13:42:50 --> Database Driver Class Initialized
INFO - 2018-09-06 13:42:51 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:42:51 --> Form Validation Class Initialized
INFO - 2018-09-06 13:42:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-06 13:42:51 --> Database Driver Class Initialized
INFO - 2018-09-06 13:42:51 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:42:51 --> Config Class Initialized
INFO - 2018-09-06 13:42:51 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:42:51 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:42:51 --> Utf8 Class Initialized
INFO - 2018-09-06 13:42:51 --> URI Class Initialized
INFO - 2018-09-06 13:42:51 --> Router Class Initialized
INFO - 2018-09-06 13:42:51 --> Output Class Initialized
INFO - 2018-09-06 13:42:51 --> Security Class Initialized
DEBUG - 2018-09-06 13:42:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:42:51 --> CSRF cookie sent
INFO - 2018-09-06 13:42:51 --> Input Class Initialized
INFO - 2018-09-06 13:42:51 --> Language Class Initialized
INFO - 2018-09-06 13:42:51 --> Loader Class Initialized
INFO - 2018-09-06 13:42:51 --> Helper loaded: url_helper
INFO - 2018-09-06 13:42:51 --> Helper loaded: form_helper
INFO - 2018-09-06 13:42:51 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:42:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:42:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:42:51 --> User Agent Class Initialized
INFO - 2018-09-06 13:42:51 --> Controller Class Initialized
INFO - 2018-09-06 13:42:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:42:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:42:51 --> Pixel_Model class loaded
INFO - 2018-09-06 13:42:51 --> Database Driver Class Initialized
INFO - 2018-09-06 13:42:51 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:42:51 --> Config Class Initialized
INFO - 2018-09-06 13:42:51 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:42:51 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:42:51 --> Utf8 Class Initialized
INFO - 2018-09-06 13:42:51 --> URI Class Initialized
INFO - 2018-09-06 13:42:51 --> Router Class Initialized
INFO - 2018-09-06 13:42:51 --> Output Class Initialized
INFO - 2018-09-06 13:42:51 --> Security Class Initialized
DEBUG - 2018-09-06 13:42:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:42:51 --> CSRF cookie sent
INFO - 2018-09-06 13:42:51 --> Input Class Initialized
INFO - 2018-09-06 13:42:51 --> Language Class Initialized
INFO - 2018-09-06 13:42:51 --> Loader Class Initialized
INFO - 2018-09-06 13:42:51 --> Helper loaded: url_helper
INFO - 2018-09-06 13:42:51 --> Helper loaded: form_helper
INFO - 2018-09-06 13:42:51 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:42:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:42:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:42:51 --> User Agent Class Initialized
INFO - 2018-09-06 13:42:51 --> Controller Class Initialized
INFO - 2018-09-06 13:42:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:42:51 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-09-06 13:42:51 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-09-06 13:42:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 13:42:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 13:42:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 13:42:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-09-06 13:42:51 --> Could not find the language line "req_email"
INFO - 2018-09-06 13:42:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-09-06 13:42:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 13:42:51 --> Final output sent to browser
DEBUG - 2018-09-06 13:42:51 --> Total execution time: 0.0210
INFO - 2018-09-06 13:43:08 --> Config Class Initialized
INFO - 2018-09-06 13:43:08 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:43:08 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:43:08 --> Utf8 Class Initialized
INFO - 2018-09-06 13:43:08 --> URI Class Initialized
INFO - 2018-09-06 13:43:08 --> Router Class Initialized
INFO - 2018-09-06 13:43:08 --> Output Class Initialized
INFO - 2018-09-06 13:43:08 --> Security Class Initialized
DEBUG - 2018-09-06 13:43:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:43:08 --> CSRF cookie sent
INFO - 2018-09-06 13:43:08 --> Input Class Initialized
INFO - 2018-09-06 13:43:08 --> Language Class Initialized
INFO - 2018-09-06 13:43:08 --> Loader Class Initialized
INFO - 2018-09-06 13:43:08 --> Helper loaded: url_helper
INFO - 2018-09-06 13:43:08 --> Helper loaded: form_helper
INFO - 2018-09-06 13:43:08 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:43:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:43:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:43:08 --> User Agent Class Initialized
INFO - 2018-09-06 13:43:08 --> Controller Class Initialized
INFO - 2018-09-06 13:43:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:43:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:43:08 --> Pixel_Model class loaded
INFO - 2018-09-06 13:43:08 --> Database Driver Class Initialized
INFO - 2018-09-06 13:43:08 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:43:08 --> Database Driver Class Initialized
INFO - 2018-09-06 13:43:08 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:43:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 13:43:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 13:43:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 13:43:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-06 13:43:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-06 13:43:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-06 13:43:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-09-06 13:43:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 13:43:08 --> Final output sent to browser
DEBUG - 2018-09-06 13:43:08 --> Total execution time: 0.0411
INFO - 2018-09-06 13:43:12 --> Config Class Initialized
INFO - 2018-09-06 13:43:12 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:43:12 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:43:12 --> Utf8 Class Initialized
INFO - 2018-09-06 13:43:12 --> URI Class Initialized
INFO - 2018-09-06 13:43:12 --> Router Class Initialized
INFO - 2018-09-06 13:43:12 --> Output Class Initialized
INFO - 2018-09-06 13:43:12 --> Security Class Initialized
DEBUG - 2018-09-06 13:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:43:12 --> CSRF cookie sent
INFO - 2018-09-06 13:43:12 --> Input Class Initialized
INFO - 2018-09-06 13:43:12 --> Language Class Initialized
INFO - 2018-09-06 13:43:12 --> Loader Class Initialized
INFO - 2018-09-06 13:43:12 --> Helper loaded: url_helper
INFO - 2018-09-06 13:43:12 --> Helper loaded: form_helper
INFO - 2018-09-06 13:43:12 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:43:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:43:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:43:12 --> User Agent Class Initialized
INFO - 2018-09-06 13:43:12 --> Controller Class Initialized
INFO - 2018-09-06 13:43:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:43:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:43:12 --> Pixel_Model class loaded
INFO - 2018-09-06 13:43:12 --> Database Driver Class Initialized
INFO - 2018-09-06 13:43:12 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:43:12 --> Database Driver Class Initialized
INFO - 2018-09-06 13:43:12 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:43:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 13:43:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 13:43:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-09-06 13:43:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 13:43:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-06 13:43:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-06 13:43:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-06 13:43:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-09-06 13:43:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 13:43:12 --> Final output sent to browser
DEBUG - 2018-09-06 13:43:12 --> Total execution time: 0.0493
INFO - 2018-09-06 13:43:20 --> Config Class Initialized
INFO - 2018-09-06 13:43:20 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:43:20 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:43:20 --> Utf8 Class Initialized
INFO - 2018-09-06 13:43:20 --> URI Class Initialized
INFO - 2018-09-06 13:43:20 --> Router Class Initialized
INFO - 2018-09-06 13:43:20 --> Output Class Initialized
INFO - 2018-09-06 13:43:20 --> Security Class Initialized
DEBUG - 2018-09-06 13:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:43:20 --> CSRF cookie sent
INFO - 2018-09-06 13:43:20 --> Input Class Initialized
INFO - 2018-09-06 13:43:20 --> Language Class Initialized
INFO - 2018-09-06 13:43:20 --> Loader Class Initialized
INFO - 2018-09-06 13:43:20 --> Helper loaded: url_helper
INFO - 2018-09-06 13:43:20 --> Helper loaded: form_helper
INFO - 2018-09-06 13:43:20 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:43:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:43:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:43:20 --> User Agent Class Initialized
INFO - 2018-09-06 13:43:20 --> Controller Class Initialized
INFO - 2018-09-06 13:43:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:43:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:43:20 --> Pixel_Model class loaded
INFO - 2018-09-06 13:43:20 --> Database Driver Class Initialized
INFO - 2018-09-06 13:43:20 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:43:20 --> Database Driver Class Initialized
INFO - 2018-09-06 13:43:20 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:43:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 13:43:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 13:43:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 13:43:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-06 13:43:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-06 13:43:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-06 13:43:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-09-06 13:43:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 13:43:20 --> Final output sent to browser
DEBUG - 2018-09-06 13:43:20 --> Total execution time: 0.0557
INFO - 2018-09-06 13:43:21 --> Config Class Initialized
INFO - 2018-09-06 13:43:21 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:43:21 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:43:21 --> Utf8 Class Initialized
INFO - 2018-09-06 13:43:21 --> URI Class Initialized
INFO - 2018-09-06 13:43:21 --> Router Class Initialized
INFO - 2018-09-06 13:43:21 --> Output Class Initialized
INFO - 2018-09-06 13:43:21 --> Security Class Initialized
DEBUG - 2018-09-06 13:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:43:21 --> CSRF cookie sent
INFO - 2018-09-06 13:43:21 --> Input Class Initialized
INFO - 2018-09-06 13:43:21 --> Language Class Initialized
INFO - 2018-09-06 13:43:21 --> Loader Class Initialized
INFO - 2018-09-06 13:43:21 --> Helper loaded: url_helper
INFO - 2018-09-06 13:43:21 --> Helper loaded: form_helper
INFO - 2018-09-06 13:43:21 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:43:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:43:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:43:21 --> User Agent Class Initialized
INFO - 2018-09-06 13:43:21 --> Controller Class Initialized
INFO - 2018-09-06 13:43:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:43:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:43:21 --> Pixel_Model class loaded
INFO - 2018-09-06 13:43:21 --> Database Driver Class Initialized
INFO - 2018-09-06 13:43:21 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:43:21 --> Database Driver Class Initialized
INFO - 2018-09-06 13:43:21 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:43:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 13:43:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 13:43:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 13:43:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-06 13:43:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-06 13:43:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-06 13:43:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-09-06 13:43:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 13:43:21 --> Final output sent to browser
DEBUG - 2018-09-06 13:43:21 --> Total execution time: 0.0477
INFO - 2018-09-06 13:43:22 --> Config Class Initialized
INFO - 2018-09-06 13:43:22 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:43:22 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:43:22 --> Utf8 Class Initialized
INFO - 2018-09-06 13:43:22 --> URI Class Initialized
INFO - 2018-09-06 13:43:22 --> Router Class Initialized
INFO - 2018-09-06 13:43:22 --> Output Class Initialized
INFO - 2018-09-06 13:43:22 --> Security Class Initialized
DEBUG - 2018-09-06 13:43:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:43:22 --> CSRF cookie sent
INFO - 2018-09-06 13:43:22 --> Input Class Initialized
INFO - 2018-09-06 13:43:22 --> Language Class Initialized
INFO - 2018-09-06 13:43:22 --> Loader Class Initialized
INFO - 2018-09-06 13:43:22 --> Helper loaded: url_helper
INFO - 2018-09-06 13:43:22 --> Helper loaded: form_helper
INFO - 2018-09-06 13:43:22 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:43:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:43:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:43:22 --> User Agent Class Initialized
INFO - 2018-09-06 13:43:22 --> Controller Class Initialized
INFO - 2018-09-06 13:43:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:43:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:43:22 --> Pixel_Model class loaded
INFO - 2018-09-06 13:43:22 --> Database Driver Class Initialized
INFO - 2018-09-06 13:43:22 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:43:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 13:43:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 13:43:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 13:43:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-06 13:43:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-06 13:43:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-06 13:43:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-09-06 13:43:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 13:43:22 --> Final output sent to browser
DEBUG - 2018-09-06 13:43:22 --> Total execution time: 0.0577
INFO - 2018-09-06 13:43:26 --> Config Class Initialized
INFO - 2018-09-06 13:43:26 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:43:26 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:43:26 --> Utf8 Class Initialized
INFO - 2018-09-06 13:43:26 --> URI Class Initialized
INFO - 2018-09-06 13:43:26 --> Router Class Initialized
INFO - 2018-09-06 13:43:26 --> Output Class Initialized
INFO - 2018-09-06 13:43:26 --> Security Class Initialized
DEBUG - 2018-09-06 13:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:43:26 --> CSRF cookie sent
INFO - 2018-09-06 13:43:26 --> CSRF token verified
INFO - 2018-09-06 13:43:26 --> Input Class Initialized
INFO - 2018-09-06 13:43:26 --> Language Class Initialized
INFO - 2018-09-06 13:43:26 --> Loader Class Initialized
INFO - 2018-09-06 13:43:26 --> Helper loaded: url_helper
INFO - 2018-09-06 13:43:26 --> Helper loaded: form_helper
INFO - 2018-09-06 13:43:26 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:43:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:43:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:43:26 --> User Agent Class Initialized
INFO - 2018-09-06 13:43:26 --> Controller Class Initialized
INFO - 2018-09-06 13:43:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:43:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:43:26 --> Pixel_Model class loaded
INFO - 2018-09-06 13:43:26 --> Database Driver Class Initialized
INFO - 2018-09-06 13:43:26 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:43:26 --> Database Driver Class Initialized
INFO - 2018-09-06 13:43:26 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:43:26 --> Config Class Initialized
INFO - 2018-09-06 13:43:26 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:43:26 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:43:26 --> Utf8 Class Initialized
INFO - 2018-09-06 13:43:26 --> URI Class Initialized
INFO - 2018-09-06 13:43:26 --> Router Class Initialized
INFO - 2018-09-06 13:43:26 --> Output Class Initialized
INFO - 2018-09-06 13:43:26 --> Security Class Initialized
DEBUG - 2018-09-06 13:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:43:26 --> CSRF cookie sent
INFO - 2018-09-06 13:43:26 --> Input Class Initialized
INFO - 2018-09-06 13:43:26 --> Language Class Initialized
INFO - 2018-09-06 13:43:26 --> Loader Class Initialized
INFO - 2018-09-06 13:43:26 --> Helper loaded: url_helper
INFO - 2018-09-06 13:43:26 --> Helper loaded: form_helper
INFO - 2018-09-06 13:43:26 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:43:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:43:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:43:26 --> User Agent Class Initialized
INFO - 2018-09-06 13:43:26 --> Controller Class Initialized
INFO - 2018-09-06 13:43:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:43:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:43:26 --> Pixel_Model class loaded
INFO - 2018-09-06 13:43:26 --> Database Driver Class Initialized
INFO - 2018-09-06 13:43:26 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:43:26 --> Database Driver Class Initialized
INFO - 2018-09-06 13:43:26 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:43:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 13:43:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 13:43:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 13:43:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-06 13:43:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-06 13:43:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-06 13:43:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-09-06 13:43:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 13:43:26 --> Final output sent to browser
DEBUG - 2018-09-06 13:43:26 --> Total execution time: 0.0468
INFO - 2018-09-06 13:43:28 --> Config Class Initialized
INFO - 2018-09-06 13:43:28 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:43:28 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:43:28 --> Utf8 Class Initialized
INFO - 2018-09-06 13:43:28 --> URI Class Initialized
INFO - 2018-09-06 13:43:28 --> Router Class Initialized
INFO - 2018-09-06 13:43:28 --> Output Class Initialized
INFO - 2018-09-06 13:43:28 --> Security Class Initialized
DEBUG - 2018-09-06 13:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:43:28 --> CSRF cookie sent
INFO - 2018-09-06 13:43:28 --> CSRF token verified
INFO - 2018-09-06 13:43:28 --> Input Class Initialized
INFO - 2018-09-06 13:43:28 --> Language Class Initialized
INFO - 2018-09-06 13:43:28 --> Loader Class Initialized
INFO - 2018-09-06 13:43:28 --> Helper loaded: url_helper
INFO - 2018-09-06 13:43:28 --> Helper loaded: form_helper
INFO - 2018-09-06 13:43:28 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:43:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:43:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:43:28 --> User Agent Class Initialized
INFO - 2018-09-06 13:43:28 --> Controller Class Initialized
INFO - 2018-09-06 13:43:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:43:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:43:28 --> Pixel_Model class loaded
INFO - 2018-09-06 13:43:28 --> Database Driver Class Initialized
INFO - 2018-09-06 13:43:28 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:43:28 --> Form Validation Class Initialized
INFO - 2018-09-06 13:43:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-06 13:43:28 --> Database Driver Class Initialized
INFO - 2018-09-06 13:43:28 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:43:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 13:43:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 13:43:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 13:43:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-06 13:43:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-06 13:43:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_errors.php
INFO - 2018-09-06 13:43:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-06 13:43:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-09-06 13:43:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 13:43:28 --> Final output sent to browser
DEBUG - 2018-09-06 13:43:28 --> Total execution time: 0.0471
INFO - 2018-09-06 13:43:30 --> Config Class Initialized
INFO - 2018-09-06 13:43:30 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:43:30 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:43:30 --> Utf8 Class Initialized
INFO - 2018-09-06 13:43:30 --> URI Class Initialized
INFO - 2018-09-06 13:43:30 --> Router Class Initialized
INFO - 2018-09-06 13:43:30 --> Output Class Initialized
INFO - 2018-09-06 13:43:30 --> Security Class Initialized
DEBUG - 2018-09-06 13:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:43:30 --> CSRF cookie sent
INFO - 2018-09-06 13:43:30 --> CSRF token verified
INFO - 2018-09-06 13:43:30 --> Input Class Initialized
INFO - 2018-09-06 13:43:30 --> Language Class Initialized
INFO - 2018-09-06 13:43:30 --> Loader Class Initialized
INFO - 2018-09-06 13:43:30 --> Helper loaded: url_helper
INFO - 2018-09-06 13:43:30 --> Helper loaded: form_helper
INFO - 2018-09-06 13:43:30 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:43:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:43:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:43:30 --> User Agent Class Initialized
INFO - 2018-09-06 13:43:30 --> Controller Class Initialized
INFO - 2018-09-06 13:43:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:43:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:43:30 --> Pixel_Model class loaded
INFO - 2018-09-06 13:43:30 --> Database Driver Class Initialized
INFO - 2018-09-06 13:43:30 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:43:30 --> Form Validation Class Initialized
INFO - 2018-09-06 13:43:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-06 13:43:30 --> Database Driver Class Initialized
INFO - 2018-09-06 13:43:30 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:43:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 13:43:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 13:43:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 13:43:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-06 13:43:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-06 13:43:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_errors.php
INFO - 2018-09-06 13:43:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-06 13:43:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-09-06 13:43:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 13:43:30 --> Final output sent to browser
DEBUG - 2018-09-06 13:43:30 --> Total execution time: 0.0488
INFO - 2018-09-06 13:43:31 --> Config Class Initialized
INFO - 2018-09-06 13:43:31 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:43:31 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:43:31 --> Utf8 Class Initialized
INFO - 2018-09-06 13:43:31 --> URI Class Initialized
INFO - 2018-09-06 13:43:31 --> Router Class Initialized
INFO - 2018-09-06 13:43:31 --> Output Class Initialized
INFO - 2018-09-06 13:43:31 --> Security Class Initialized
DEBUG - 2018-09-06 13:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:43:31 --> CSRF cookie sent
INFO - 2018-09-06 13:43:31 --> CSRF token verified
INFO - 2018-09-06 13:43:31 --> Input Class Initialized
INFO - 2018-09-06 13:43:31 --> Language Class Initialized
INFO - 2018-09-06 13:43:31 --> Loader Class Initialized
INFO - 2018-09-06 13:43:31 --> Helper loaded: url_helper
INFO - 2018-09-06 13:43:31 --> Helper loaded: form_helper
INFO - 2018-09-06 13:43:31 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:43:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:43:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:43:31 --> User Agent Class Initialized
INFO - 2018-09-06 13:43:31 --> Controller Class Initialized
INFO - 2018-09-06 13:43:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:43:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:43:31 --> Pixel_Model class loaded
INFO - 2018-09-06 13:43:31 --> Database Driver Class Initialized
INFO - 2018-09-06 13:43:31 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:43:31 --> Form Validation Class Initialized
INFO - 2018-09-06 13:43:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-06 13:43:31 --> Database Driver Class Initialized
INFO - 2018-09-06 13:43:31 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:43:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 13:43:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 13:43:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 13:43:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-06 13:43:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-06 13:43:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_errors.php
INFO - 2018-09-06 13:43:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-06 13:43:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-09-06 13:43:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 13:43:31 --> Final output sent to browser
DEBUG - 2018-09-06 13:43:31 --> Total execution time: 0.0509
INFO - 2018-09-06 13:43:37 --> Config Class Initialized
INFO - 2018-09-06 13:43:37 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:43:37 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:43:37 --> Utf8 Class Initialized
INFO - 2018-09-06 13:43:37 --> URI Class Initialized
INFO - 2018-09-06 13:43:37 --> Router Class Initialized
INFO - 2018-09-06 13:43:37 --> Output Class Initialized
INFO - 2018-09-06 13:43:37 --> Security Class Initialized
DEBUG - 2018-09-06 13:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:43:37 --> CSRF cookie sent
INFO - 2018-09-06 13:43:37 --> CSRF token verified
INFO - 2018-09-06 13:43:37 --> Input Class Initialized
INFO - 2018-09-06 13:43:37 --> Language Class Initialized
INFO - 2018-09-06 13:43:37 --> Loader Class Initialized
INFO - 2018-09-06 13:43:37 --> Helper loaded: url_helper
INFO - 2018-09-06 13:43:37 --> Helper loaded: form_helper
INFO - 2018-09-06 13:43:37 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:43:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:43:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:43:37 --> User Agent Class Initialized
INFO - 2018-09-06 13:43:37 --> Controller Class Initialized
INFO - 2018-09-06 13:43:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:43:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:43:37 --> Pixel_Model class loaded
INFO - 2018-09-06 13:43:37 --> Database Driver Class Initialized
INFO - 2018-09-06 13:43:37 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:43:37 --> Form Validation Class Initialized
INFO - 2018-09-06 13:43:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-06 13:43:37 --> Database Driver Class Initialized
INFO - 2018-09-06 13:43:37 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:43:37 --> Config Class Initialized
INFO - 2018-09-06 13:43:37 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:43:37 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:43:37 --> Utf8 Class Initialized
INFO - 2018-09-06 13:43:37 --> URI Class Initialized
INFO - 2018-09-06 13:43:37 --> Router Class Initialized
INFO - 2018-09-06 13:43:37 --> Output Class Initialized
INFO - 2018-09-06 13:43:37 --> Security Class Initialized
DEBUG - 2018-09-06 13:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:43:37 --> CSRF cookie sent
INFO - 2018-09-06 13:43:37 --> Input Class Initialized
INFO - 2018-09-06 13:43:37 --> Language Class Initialized
INFO - 2018-09-06 13:43:37 --> Loader Class Initialized
INFO - 2018-09-06 13:43:37 --> Helper loaded: url_helper
INFO - 2018-09-06 13:43:37 --> Helper loaded: form_helper
INFO - 2018-09-06 13:43:37 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:43:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:43:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:43:37 --> User Agent Class Initialized
INFO - 2018-09-06 13:43:37 --> Controller Class Initialized
INFO - 2018-09-06 13:43:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:43:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:43:37 --> Pixel_Model class loaded
INFO - 2018-09-06 13:43:37 --> Database Driver Class Initialized
INFO - 2018-09-06 13:43:37 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:43:37 --> Database Driver Class Initialized
INFO - 2018-09-06 13:43:37 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:43:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 13:43:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 13:43:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 13:43:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-06 13:43:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-06 13:43:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-06 13:43:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-09-06 13:43:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 13:43:37 --> Final output sent to browser
DEBUG - 2018-09-06 13:43:37 --> Total execution time: 0.0454
INFO - 2018-09-06 13:43:38 --> Config Class Initialized
INFO - 2018-09-06 13:43:38 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:43:38 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:43:38 --> Utf8 Class Initialized
INFO - 2018-09-06 13:43:38 --> URI Class Initialized
INFO - 2018-09-06 13:43:38 --> Router Class Initialized
INFO - 2018-09-06 13:43:38 --> Output Class Initialized
INFO - 2018-09-06 13:43:38 --> Security Class Initialized
DEBUG - 2018-09-06 13:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:43:38 --> CSRF cookie sent
INFO - 2018-09-06 13:43:38 --> CSRF token verified
INFO - 2018-09-06 13:43:38 --> Input Class Initialized
INFO - 2018-09-06 13:43:38 --> Language Class Initialized
INFO - 2018-09-06 13:43:38 --> Loader Class Initialized
INFO - 2018-09-06 13:43:38 --> Helper loaded: url_helper
INFO - 2018-09-06 13:43:38 --> Helper loaded: form_helper
INFO - 2018-09-06 13:43:38 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:43:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:43:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:43:38 --> User Agent Class Initialized
INFO - 2018-09-06 13:43:38 --> Controller Class Initialized
INFO - 2018-09-06 13:43:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:43:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:43:38 --> Pixel_Model class loaded
INFO - 2018-09-06 13:43:38 --> Database Driver Class Initialized
INFO - 2018-09-06 13:43:38 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:43:38 --> Form Validation Class Initialized
INFO - 2018-09-06 13:43:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-06 13:43:38 --> Database Driver Class Initialized
INFO - 2018-09-06 13:43:38 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:43:39 --> Config Class Initialized
INFO - 2018-09-06 13:43:39 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:43:39 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:43:39 --> Utf8 Class Initialized
INFO - 2018-09-06 13:43:39 --> URI Class Initialized
INFO - 2018-09-06 13:43:39 --> Router Class Initialized
INFO - 2018-09-06 13:43:39 --> Output Class Initialized
INFO - 2018-09-06 13:43:39 --> Security Class Initialized
DEBUG - 2018-09-06 13:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:43:39 --> CSRF cookie sent
INFO - 2018-09-06 13:43:39 --> Input Class Initialized
INFO - 2018-09-06 13:43:39 --> Language Class Initialized
INFO - 2018-09-06 13:43:39 --> Loader Class Initialized
INFO - 2018-09-06 13:43:39 --> Helper loaded: url_helper
INFO - 2018-09-06 13:43:39 --> Helper loaded: form_helper
INFO - 2018-09-06 13:43:39 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:43:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:43:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:43:39 --> User Agent Class Initialized
INFO - 2018-09-06 13:43:39 --> Controller Class Initialized
INFO - 2018-09-06 13:43:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:43:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:43:39 --> Pixel_Model class loaded
INFO - 2018-09-06 13:43:39 --> Database Driver Class Initialized
INFO - 2018-09-06 13:43:39 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:43:39 --> Database Driver Class Initialized
INFO - 2018-09-06 13:43:39 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:43:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 13:43:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 13:43:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-09-06 13:43:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 13:43:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-06 13:43:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-06 13:43:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-06 13:43:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-09-06 13:43:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 13:43:39 --> Final output sent to browser
DEBUG - 2018-09-06 13:43:39 --> Total execution time: 0.0425
INFO - 2018-09-06 13:43:40 --> Config Class Initialized
INFO - 2018-09-06 13:43:40 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:43:40 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:43:40 --> Utf8 Class Initialized
INFO - 2018-09-06 13:43:40 --> URI Class Initialized
INFO - 2018-09-06 13:43:40 --> Router Class Initialized
INFO - 2018-09-06 13:43:40 --> Output Class Initialized
INFO - 2018-09-06 13:43:40 --> Security Class Initialized
DEBUG - 2018-09-06 13:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:43:40 --> CSRF cookie sent
INFO - 2018-09-06 13:43:40 --> CSRF token verified
INFO - 2018-09-06 13:43:40 --> Input Class Initialized
INFO - 2018-09-06 13:43:40 --> Language Class Initialized
INFO - 2018-09-06 13:43:40 --> Loader Class Initialized
INFO - 2018-09-06 13:43:40 --> Helper loaded: url_helper
INFO - 2018-09-06 13:43:40 --> Helper loaded: form_helper
INFO - 2018-09-06 13:43:40 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:43:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:43:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:43:40 --> User Agent Class Initialized
INFO - 2018-09-06 13:43:40 --> Controller Class Initialized
INFO - 2018-09-06 13:43:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:43:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:43:40 --> Pixel_Model class loaded
INFO - 2018-09-06 13:43:40 --> Database Driver Class Initialized
INFO - 2018-09-06 13:43:40 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:43:40 --> Form Validation Class Initialized
INFO - 2018-09-06 13:43:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-06 13:43:40 --> Database Driver Class Initialized
INFO - 2018-09-06 13:43:40 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:43:40 --> Config Class Initialized
INFO - 2018-09-06 13:43:40 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:43:40 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:43:40 --> Utf8 Class Initialized
INFO - 2018-09-06 13:43:40 --> URI Class Initialized
INFO - 2018-09-06 13:43:40 --> Router Class Initialized
INFO - 2018-09-06 13:43:40 --> Output Class Initialized
INFO - 2018-09-06 13:43:40 --> Security Class Initialized
DEBUG - 2018-09-06 13:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:43:40 --> CSRF cookie sent
INFO - 2018-09-06 13:43:40 --> Input Class Initialized
INFO - 2018-09-06 13:43:40 --> Language Class Initialized
INFO - 2018-09-06 13:43:40 --> Config Class Initialized
INFO - 2018-09-06 13:43:40 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:43:40 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:43:40 --> Utf8 Class Initialized
INFO - 2018-09-06 13:43:40 --> Loader Class Initialized
INFO - 2018-09-06 13:43:40 --> URI Class Initialized
INFO - 2018-09-06 13:43:40 --> Helper loaded: url_helper
INFO - 2018-09-06 13:43:40 --> Router Class Initialized
INFO - 2018-09-06 13:43:40 --> Helper loaded: form_helper
INFO - 2018-09-06 13:43:40 --> Helper loaded: language_helper
INFO - 2018-09-06 13:43:40 --> Output Class Initialized
INFO - 2018-09-06 13:43:40 --> Security Class Initialized
DEBUG - 2018-09-06 13:43:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:43:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-09-06 13:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:43:40 --> CSRF cookie sent
INFO - 2018-09-06 13:43:40 --> CSRF token verified
INFO - 2018-09-06 13:43:40 --> Input Class Initialized
INFO - 2018-09-06 13:43:40 --> User Agent Class Initialized
INFO - 2018-09-06 13:43:40 --> Language Class Initialized
INFO - 2018-09-06 13:43:40 --> Controller Class Initialized
INFO - 2018-09-06 13:43:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:43:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:43:40 --> Loader Class Initialized
INFO - 2018-09-06 13:43:40 --> Pixel_Model class loaded
INFO - 2018-09-06 13:43:40 --> Helper loaded: url_helper
INFO - 2018-09-06 13:43:40 --> Helper loaded: form_helper
INFO - 2018-09-06 13:43:40 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:43:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:43:40 --> Database Driver Class Initialized
INFO - 2018-09-06 13:43:40 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:43:40 --> Database Driver Class Initialized
INFO - 2018-09-06 13:43:40 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:43:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 13:43:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 13:43:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 13:43:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-06 13:43:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-06 13:43:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-06 13:43:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-09-06 13:43:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 13:43:40 --> Final output sent to browser
DEBUG - 2018-09-06 13:43:40 --> Total execution time: 0.0514
INFO - 2018-09-06 13:43:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:43:40 --> User Agent Class Initialized
INFO - 2018-09-06 13:43:40 --> Controller Class Initialized
INFO - 2018-09-06 13:43:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:43:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:43:40 --> Pixel_Model class loaded
INFO - 2018-09-06 13:43:40 --> Database Driver Class Initialized
INFO - 2018-09-06 13:43:40 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:43:40 --> Form Validation Class Initialized
INFO - 2018-09-06 13:43:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-06 13:43:40 --> Database Driver Class Initialized
INFO - 2018-09-06 13:43:40 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:43:40 --> Config Class Initialized
INFO - 2018-09-06 13:43:40 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:43:40 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:43:40 --> Utf8 Class Initialized
INFO - 2018-09-06 13:43:40 --> URI Class Initialized
INFO - 2018-09-06 13:43:40 --> Router Class Initialized
INFO - 2018-09-06 13:43:40 --> Output Class Initialized
INFO - 2018-09-06 13:43:40 --> Security Class Initialized
DEBUG - 2018-09-06 13:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:43:40 --> CSRF cookie sent
INFO - 2018-09-06 13:43:40 --> Input Class Initialized
INFO - 2018-09-06 13:43:40 --> Language Class Initialized
INFO - 2018-09-06 13:43:40 --> Loader Class Initialized
INFO - 2018-09-06 13:43:40 --> Helper loaded: url_helper
INFO - 2018-09-06 13:43:40 --> Helper loaded: form_helper
INFO - 2018-09-06 13:43:40 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:43:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:43:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:43:40 --> User Agent Class Initialized
INFO - 2018-09-06 13:43:40 --> Controller Class Initialized
INFO - 2018-09-06 13:43:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:43:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:43:40 --> Pixel_Model class loaded
INFO - 2018-09-06 13:43:40 --> Database Driver Class Initialized
INFO - 2018-09-06 13:43:40 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:43:40 --> Database Driver Class Initialized
INFO - 2018-09-06 13:43:40 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:43:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 13:43:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 13:43:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 13:43:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-06 13:43:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-06 13:43:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-06 13:43:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-09-06 13:43:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 13:43:40 --> Final output sent to browser
DEBUG - 2018-09-06 13:43:40 --> Total execution time: 0.0416
INFO - 2018-09-06 13:43:43 --> Config Class Initialized
INFO - 2018-09-06 13:43:43 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:43:43 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:43:43 --> Utf8 Class Initialized
INFO - 2018-09-06 13:43:43 --> URI Class Initialized
INFO - 2018-09-06 13:43:43 --> Router Class Initialized
INFO - 2018-09-06 13:43:43 --> Output Class Initialized
INFO - 2018-09-06 13:43:43 --> Security Class Initialized
DEBUG - 2018-09-06 13:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:43:43 --> CSRF cookie sent
INFO - 2018-09-06 13:43:43 --> Input Class Initialized
INFO - 2018-09-06 13:43:43 --> Language Class Initialized
INFO - 2018-09-06 13:43:43 --> Loader Class Initialized
INFO - 2018-09-06 13:43:43 --> Helper loaded: url_helper
INFO - 2018-09-06 13:43:43 --> Helper loaded: form_helper
INFO - 2018-09-06 13:43:43 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:43:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:43:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:43:43 --> User Agent Class Initialized
INFO - 2018-09-06 13:43:43 --> Controller Class Initialized
INFO - 2018-09-06 13:43:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:43:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:43:43 --> Pixel_Model class loaded
INFO - 2018-09-06 13:43:43 --> Database Driver Class Initialized
INFO - 2018-09-06 13:43:43 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:43:43 --> Database Driver Class Initialized
INFO - 2018-09-06 13:43:43 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:43:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 13:43:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 13:43:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-09-06 13:43:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 13:43:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-06 13:43:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-06 13:43:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-06 13:43:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-09-06 13:43:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 13:43:43 --> Final output sent to browser
DEBUG - 2018-09-06 13:43:43 --> Total execution time: 0.0409
INFO - 2018-09-06 13:43:49 --> Config Class Initialized
INFO - 2018-09-06 13:43:49 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:43:49 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:43:49 --> Utf8 Class Initialized
INFO - 2018-09-06 13:43:49 --> URI Class Initialized
INFO - 2018-09-06 13:43:49 --> Router Class Initialized
INFO - 2018-09-06 13:43:49 --> Output Class Initialized
INFO - 2018-09-06 13:43:49 --> Security Class Initialized
DEBUG - 2018-09-06 13:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:43:49 --> CSRF cookie sent
INFO - 2018-09-06 13:43:49 --> CSRF token verified
INFO - 2018-09-06 13:43:49 --> Input Class Initialized
INFO - 2018-09-06 13:43:49 --> Language Class Initialized
INFO - 2018-09-06 13:43:49 --> Loader Class Initialized
INFO - 2018-09-06 13:43:49 --> Helper loaded: url_helper
INFO - 2018-09-06 13:43:49 --> Helper loaded: form_helper
INFO - 2018-09-06 13:43:49 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:43:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:43:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:43:49 --> User Agent Class Initialized
INFO - 2018-09-06 13:43:49 --> Controller Class Initialized
INFO - 2018-09-06 13:43:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:43:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:43:49 --> Pixel_Model class loaded
INFO - 2018-09-06 13:43:49 --> Database Driver Class Initialized
INFO - 2018-09-06 13:43:49 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:43:49 --> Form Validation Class Initialized
INFO - 2018-09-06 13:43:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-06 13:43:49 --> Database Driver Class Initialized
INFO - 2018-09-06 13:43:49 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:43:49 --> Config Class Initialized
INFO - 2018-09-06 13:43:49 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:43:49 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:43:49 --> Utf8 Class Initialized
INFO - 2018-09-06 13:43:49 --> URI Class Initialized
INFO - 2018-09-06 13:43:49 --> Router Class Initialized
INFO - 2018-09-06 13:43:49 --> Output Class Initialized
INFO - 2018-09-06 13:43:49 --> Security Class Initialized
DEBUG - 2018-09-06 13:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:43:49 --> CSRF cookie sent
INFO - 2018-09-06 13:43:49 --> Input Class Initialized
INFO - 2018-09-06 13:43:49 --> Language Class Initialized
INFO - 2018-09-06 13:43:49 --> Loader Class Initialized
INFO - 2018-09-06 13:43:49 --> Helper loaded: url_helper
INFO - 2018-09-06 13:43:49 --> Helper loaded: form_helper
INFO - 2018-09-06 13:43:49 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:43:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:43:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:43:49 --> User Agent Class Initialized
INFO - 2018-09-06 13:43:49 --> Controller Class Initialized
INFO - 2018-09-06 13:43:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:43:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:43:49 --> Pixel_Model class loaded
INFO - 2018-09-06 13:43:49 --> Database Driver Class Initialized
INFO - 2018-09-06 13:43:49 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:43:49 --> Database Driver Class Initialized
INFO - 2018-09-06 13:43:49 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:43:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 13:43:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 13:43:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 13:43:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-06 13:43:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-06 13:43:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-06 13:43:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-09-06 13:43:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 13:43:49 --> Final output sent to browser
DEBUG - 2018-09-06 13:43:49 --> Total execution time: 0.0469
INFO - 2018-09-06 13:43:56 --> Config Class Initialized
INFO - 2018-09-06 13:43:56 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:43:56 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:43:56 --> Utf8 Class Initialized
INFO - 2018-09-06 13:43:56 --> URI Class Initialized
INFO - 2018-09-06 13:43:56 --> Router Class Initialized
INFO - 2018-09-06 13:43:56 --> Output Class Initialized
INFO - 2018-09-06 13:43:56 --> Security Class Initialized
DEBUG - 2018-09-06 13:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:43:56 --> CSRF cookie sent
INFO - 2018-09-06 13:43:56 --> CSRF token verified
INFO - 2018-09-06 13:43:56 --> Input Class Initialized
INFO - 2018-09-06 13:43:56 --> Language Class Initialized
INFO - 2018-09-06 13:43:56 --> Loader Class Initialized
INFO - 2018-09-06 13:43:56 --> Helper loaded: url_helper
INFO - 2018-09-06 13:43:56 --> Helper loaded: form_helper
INFO - 2018-09-06 13:43:56 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:43:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:43:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:43:56 --> User Agent Class Initialized
INFO - 2018-09-06 13:43:56 --> Controller Class Initialized
INFO - 2018-09-06 13:43:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:43:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:43:56 --> Pixel_Model class loaded
INFO - 2018-09-06 13:43:56 --> Database Driver Class Initialized
INFO - 2018-09-06 13:43:56 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:43:56 --> Form Validation Class Initialized
INFO - 2018-09-06 13:43:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-06 13:43:56 --> Database Driver Class Initialized
INFO - 2018-09-06 13:43:56 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:43:56 --> Config Class Initialized
INFO - 2018-09-06 13:43:56 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:43:56 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:43:56 --> Utf8 Class Initialized
INFO - 2018-09-06 13:43:56 --> URI Class Initialized
INFO - 2018-09-06 13:43:56 --> Router Class Initialized
INFO - 2018-09-06 13:43:56 --> Output Class Initialized
INFO - 2018-09-06 13:43:56 --> Security Class Initialized
DEBUG - 2018-09-06 13:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:43:56 --> CSRF cookie sent
INFO - 2018-09-06 13:43:56 --> Input Class Initialized
INFO - 2018-09-06 13:43:56 --> Language Class Initialized
INFO - 2018-09-06 13:43:56 --> Loader Class Initialized
INFO - 2018-09-06 13:43:56 --> Helper loaded: url_helper
INFO - 2018-09-06 13:43:56 --> Helper loaded: form_helper
INFO - 2018-09-06 13:43:56 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:43:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:43:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:43:56 --> User Agent Class Initialized
INFO - 2018-09-06 13:43:56 --> Controller Class Initialized
INFO - 2018-09-06 13:43:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:43:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:43:56 --> Pixel_Model class loaded
INFO - 2018-09-06 13:43:56 --> Database Driver Class Initialized
INFO - 2018-09-06 13:43:56 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:43:56 --> Database Driver Class Initialized
INFO - 2018-09-06 13:43:56 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:43:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 13:43:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 13:43:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 13:43:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-06 13:43:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-06 13:43:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-06 13:43:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/cohabitation.php
INFO - 2018-09-06 13:43:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 13:43:56 --> Final output sent to browser
DEBUG - 2018-09-06 13:43:56 --> Total execution time: 0.0423
INFO - 2018-09-06 13:44:02 --> Config Class Initialized
INFO - 2018-09-06 13:44:02 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:44:02 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:44:02 --> Utf8 Class Initialized
INFO - 2018-09-06 13:44:02 --> URI Class Initialized
INFO - 2018-09-06 13:44:02 --> Router Class Initialized
INFO - 2018-09-06 13:44:02 --> Output Class Initialized
INFO - 2018-09-06 13:44:02 --> Security Class Initialized
DEBUG - 2018-09-06 13:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:44:02 --> CSRF cookie sent
INFO - 2018-09-06 13:44:02 --> CSRF token verified
INFO - 2018-09-06 13:44:02 --> Input Class Initialized
INFO - 2018-09-06 13:44:02 --> Language Class Initialized
INFO - 2018-09-06 13:44:02 --> Loader Class Initialized
INFO - 2018-09-06 13:44:02 --> Helper loaded: url_helper
INFO - 2018-09-06 13:44:02 --> Helper loaded: form_helper
INFO - 2018-09-06 13:44:02 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:44:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:44:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:44:02 --> User Agent Class Initialized
INFO - 2018-09-06 13:44:02 --> Controller Class Initialized
INFO - 2018-09-06 13:44:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:44:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:44:02 --> Pixel_Model class loaded
INFO - 2018-09-06 13:44:02 --> Database Driver Class Initialized
INFO - 2018-09-06 13:44:02 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:44:02 --> Form Validation Class Initialized
INFO - 2018-09-06 13:44:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-06 13:44:02 --> Database Driver Class Initialized
INFO - 2018-09-06 13:44:02 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:44:02 --> Config Class Initialized
INFO - 2018-09-06 13:44:02 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:44:02 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:44:02 --> Utf8 Class Initialized
INFO - 2018-09-06 13:44:02 --> URI Class Initialized
INFO - 2018-09-06 13:44:02 --> Router Class Initialized
INFO - 2018-09-06 13:44:02 --> Output Class Initialized
INFO - 2018-09-06 13:44:02 --> Security Class Initialized
DEBUG - 2018-09-06 13:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:44:02 --> CSRF cookie sent
INFO - 2018-09-06 13:44:02 --> Input Class Initialized
INFO - 2018-09-06 13:44:02 --> Language Class Initialized
INFO - 2018-09-06 13:44:02 --> Loader Class Initialized
INFO - 2018-09-06 13:44:02 --> Helper loaded: url_helper
INFO - 2018-09-06 13:44:02 --> Helper loaded: form_helper
INFO - 2018-09-06 13:44:02 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:44:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:44:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:44:02 --> User Agent Class Initialized
INFO - 2018-09-06 13:44:02 --> Controller Class Initialized
INFO - 2018-09-06 13:44:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:44:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:44:02 --> Pixel_Model class loaded
INFO - 2018-09-06 13:44:02 --> Database Driver Class Initialized
INFO - 2018-09-06 13:44:02 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:44:02 --> Database Driver Class Initialized
INFO - 2018-09-06 13:44:02 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:44:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 13:44:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 13:44:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 13:44:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-06 13:44:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-06 13:44:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-06 13:44:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-09-06 13:44:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 13:44:02 --> Final output sent to browser
DEBUG - 2018-09-06 13:44:02 --> Total execution time: 0.0426
INFO - 2018-09-06 13:44:04 --> Config Class Initialized
INFO - 2018-09-06 13:44:04 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:44:04 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:44:04 --> Utf8 Class Initialized
INFO - 2018-09-06 13:44:04 --> URI Class Initialized
INFO - 2018-09-06 13:44:04 --> Router Class Initialized
INFO - 2018-09-06 13:44:04 --> Output Class Initialized
INFO - 2018-09-06 13:44:04 --> Security Class Initialized
DEBUG - 2018-09-06 13:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:44:04 --> CSRF cookie sent
INFO - 2018-09-06 13:44:04 --> CSRF token verified
INFO - 2018-09-06 13:44:04 --> Input Class Initialized
INFO - 2018-09-06 13:44:04 --> Language Class Initialized
INFO - 2018-09-06 13:44:04 --> Loader Class Initialized
INFO - 2018-09-06 13:44:04 --> Helper loaded: url_helper
INFO - 2018-09-06 13:44:04 --> Helper loaded: form_helper
INFO - 2018-09-06 13:44:04 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:44:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:44:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:44:04 --> User Agent Class Initialized
INFO - 2018-09-06 13:44:04 --> Controller Class Initialized
INFO - 2018-09-06 13:44:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:44:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:44:04 --> Pixel_Model class loaded
INFO - 2018-09-06 13:44:04 --> Database Driver Class Initialized
INFO - 2018-09-06 13:44:04 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:44:04 --> Form Validation Class Initialized
INFO - 2018-09-06 13:44:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-06 13:44:04 --> Database Driver Class Initialized
INFO - 2018-09-06 13:44:04 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:44:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 13:44:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 13:44:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 13:44:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-06 13:44:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-06 13:44:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_errors.php
INFO - 2018-09-06 13:44:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-06 13:44:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-09-06 13:44:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 13:44:04 --> Final output sent to browser
DEBUG - 2018-09-06 13:44:04 --> Total execution time: 0.0442
INFO - 2018-09-06 13:44:13 --> Config Class Initialized
INFO - 2018-09-06 13:44:13 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:44:13 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:44:13 --> Utf8 Class Initialized
INFO - 2018-09-06 13:44:13 --> URI Class Initialized
INFO - 2018-09-06 13:44:13 --> Router Class Initialized
INFO - 2018-09-06 13:44:13 --> Output Class Initialized
INFO - 2018-09-06 13:44:13 --> Security Class Initialized
DEBUG - 2018-09-06 13:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:44:13 --> CSRF cookie sent
INFO - 2018-09-06 13:44:13 --> CSRF token verified
INFO - 2018-09-06 13:44:13 --> Input Class Initialized
INFO - 2018-09-06 13:44:13 --> Language Class Initialized
INFO - 2018-09-06 13:44:13 --> Loader Class Initialized
INFO - 2018-09-06 13:44:13 --> Helper loaded: url_helper
INFO - 2018-09-06 13:44:13 --> Helper loaded: form_helper
INFO - 2018-09-06 13:44:13 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:44:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:44:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:44:13 --> User Agent Class Initialized
INFO - 2018-09-06 13:44:13 --> Controller Class Initialized
INFO - 2018-09-06 13:44:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:44:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:44:13 --> Pixel_Model class loaded
INFO - 2018-09-06 13:44:13 --> Database Driver Class Initialized
INFO - 2018-09-06 13:44:13 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:44:13 --> Form Validation Class Initialized
INFO - 2018-09-06 13:44:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-06 13:44:13 --> Database Driver Class Initialized
INFO - 2018-09-06 13:44:13 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:44:14 --> Config Class Initialized
INFO - 2018-09-06 13:44:14 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:44:14 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:44:14 --> Utf8 Class Initialized
INFO - 2018-09-06 13:44:14 --> URI Class Initialized
INFO - 2018-09-06 13:44:14 --> Router Class Initialized
INFO - 2018-09-06 13:44:14 --> Output Class Initialized
INFO - 2018-09-06 13:44:14 --> Security Class Initialized
DEBUG - 2018-09-06 13:44:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:44:14 --> CSRF cookie sent
INFO - 2018-09-06 13:44:14 --> Input Class Initialized
INFO - 2018-09-06 13:44:14 --> Language Class Initialized
INFO - 2018-09-06 13:44:14 --> Loader Class Initialized
INFO - 2018-09-06 13:44:14 --> Helper loaded: url_helper
INFO - 2018-09-06 13:44:14 --> Helper loaded: form_helper
INFO - 2018-09-06 13:44:14 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:44:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:44:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:44:14 --> User Agent Class Initialized
INFO - 2018-09-06 13:44:14 --> Controller Class Initialized
INFO - 2018-09-06 13:44:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:44:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:44:14 --> Pixel_Model class loaded
INFO - 2018-09-06 13:44:14 --> Database Driver Class Initialized
INFO - 2018-09-06 13:44:14 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:44:14 --> Database Driver Class Initialized
INFO - 2018-09-06 13:44:14 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:44:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 13:44:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 13:44:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 13:44:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-06 13:44:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-06 13:44:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-06 13:44:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-09-06 13:44:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 13:44:14 --> Final output sent to browser
DEBUG - 2018-09-06 13:44:14 --> Total execution time: 0.0448
INFO - 2018-09-06 13:44:22 --> Config Class Initialized
INFO - 2018-09-06 13:44:22 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:44:22 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:44:22 --> Utf8 Class Initialized
INFO - 2018-09-06 13:44:22 --> URI Class Initialized
INFO - 2018-09-06 13:44:22 --> Router Class Initialized
INFO - 2018-09-06 13:44:22 --> Output Class Initialized
INFO - 2018-09-06 13:44:22 --> Security Class Initialized
DEBUG - 2018-09-06 13:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:44:22 --> CSRF cookie sent
INFO - 2018-09-06 13:44:22 --> CSRF token verified
INFO - 2018-09-06 13:44:22 --> Input Class Initialized
INFO - 2018-09-06 13:44:22 --> Language Class Initialized
INFO - 2018-09-06 13:44:22 --> Loader Class Initialized
INFO - 2018-09-06 13:44:22 --> Helper loaded: url_helper
INFO - 2018-09-06 13:44:22 --> Helper loaded: form_helper
INFO - 2018-09-06 13:44:22 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:44:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:44:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:44:22 --> User Agent Class Initialized
INFO - 2018-09-06 13:44:22 --> Controller Class Initialized
INFO - 2018-09-06 13:44:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:44:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:44:22 --> Pixel_Model class loaded
INFO - 2018-09-06 13:44:22 --> Database Driver Class Initialized
INFO - 2018-09-06 13:44:22 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:44:22 --> Form Validation Class Initialized
INFO - 2018-09-06 13:44:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-06 13:44:22 --> Database Driver Class Initialized
INFO - 2018-09-06 13:44:22 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:44:22 --> Config Class Initialized
INFO - 2018-09-06 13:44:22 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:44:22 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:44:22 --> Utf8 Class Initialized
INFO - 2018-09-06 13:44:22 --> URI Class Initialized
INFO - 2018-09-06 13:44:22 --> Router Class Initialized
INFO - 2018-09-06 13:44:22 --> Output Class Initialized
INFO - 2018-09-06 13:44:22 --> Security Class Initialized
DEBUG - 2018-09-06 13:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:44:22 --> CSRF cookie sent
INFO - 2018-09-06 13:44:22 --> Input Class Initialized
INFO - 2018-09-06 13:44:22 --> Language Class Initialized
INFO - 2018-09-06 13:44:22 --> Loader Class Initialized
INFO - 2018-09-06 13:44:22 --> Helper loaded: url_helper
INFO - 2018-09-06 13:44:22 --> Helper loaded: form_helper
INFO - 2018-09-06 13:44:22 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:44:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:44:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:44:22 --> User Agent Class Initialized
INFO - 2018-09-06 13:44:22 --> Controller Class Initialized
INFO - 2018-09-06 13:44:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:44:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:44:22 --> Pixel_Model class loaded
INFO - 2018-09-06 13:44:22 --> Database Driver Class Initialized
INFO - 2018-09-06 13:44:22 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:44:22 --> Database Driver Class Initialized
INFO - 2018-09-06 13:44:22 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:44:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 13:44:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 13:44:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 13:44:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-06 13:44:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-06 13:44:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-06 13:44:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-09-06 13:44:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 13:44:22 --> Final output sent to browser
DEBUG - 2018-09-06 13:44:22 --> Total execution time: 0.0501
INFO - 2018-09-06 13:44:28 --> Config Class Initialized
INFO - 2018-09-06 13:44:28 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:44:28 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:44:28 --> Utf8 Class Initialized
INFO - 2018-09-06 13:44:28 --> URI Class Initialized
INFO - 2018-09-06 13:44:28 --> Router Class Initialized
INFO - 2018-09-06 13:44:28 --> Output Class Initialized
INFO - 2018-09-06 13:44:28 --> Security Class Initialized
DEBUG - 2018-09-06 13:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:44:28 --> CSRF cookie sent
INFO - 2018-09-06 13:44:28 --> CSRF token verified
INFO - 2018-09-06 13:44:28 --> Input Class Initialized
INFO - 2018-09-06 13:44:28 --> Language Class Initialized
INFO - 2018-09-06 13:44:28 --> Loader Class Initialized
INFO - 2018-09-06 13:44:28 --> Helper loaded: url_helper
INFO - 2018-09-06 13:44:28 --> Helper loaded: form_helper
INFO - 2018-09-06 13:44:28 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:44:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:44:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:44:28 --> User Agent Class Initialized
INFO - 2018-09-06 13:44:28 --> Controller Class Initialized
INFO - 2018-09-06 13:44:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:44:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:44:28 --> Pixel_Model class loaded
INFO - 2018-09-06 13:44:28 --> Database Driver Class Initialized
INFO - 2018-09-06 13:44:28 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:44:28 --> Form Validation Class Initialized
INFO - 2018-09-06 13:44:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-06 13:44:28 --> Database Driver Class Initialized
INFO - 2018-09-06 13:44:28 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:44:28 --> Config Class Initialized
INFO - 2018-09-06 13:44:28 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:44:28 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:44:28 --> Utf8 Class Initialized
INFO - 2018-09-06 13:44:28 --> URI Class Initialized
INFO - 2018-09-06 13:44:28 --> Router Class Initialized
INFO - 2018-09-06 13:44:28 --> Output Class Initialized
INFO - 2018-09-06 13:44:28 --> Security Class Initialized
DEBUG - 2018-09-06 13:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:44:28 --> CSRF cookie sent
INFO - 2018-09-06 13:44:28 --> Input Class Initialized
INFO - 2018-09-06 13:44:28 --> Language Class Initialized
INFO - 2018-09-06 13:44:28 --> Loader Class Initialized
INFO - 2018-09-06 13:44:28 --> Helper loaded: url_helper
INFO - 2018-09-06 13:44:28 --> Helper loaded: form_helper
INFO - 2018-09-06 13:44:28 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:44:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:44:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:44:28 --> User Agent Class Initialized
INFO - 2018-09-06 13:44:28 --> Controller Class Initialized
INFO - 2018-09-06 13:44:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:44:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:44:28 --> Pixel_Model class loaded
INFO - 2018-09-06 13:44:28 --> Database Driver Class Initialized
INFO - 2018-09-06 13:44:28 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:44:28 --> Database Driver Class Initialized
INFO - 2018-09-06 13:44:28 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:44:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 13:44:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 13:44:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 13:44:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-06 13:44:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-06 13:44:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-06 13:44:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-09-06 13:44:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 13:44:28 --> Final output sent to browser
DEBUG - 2018-09-06 13:44:28 --> Total execution time: 0.0454
INFO - 2018-09-06 13:44:30 --> Config Class Initialized
INFO - 2018-09-06 13:44:30 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:44:30 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:44:30 --> Utf8 Class Initialized
INFO - 2018-09-06 13:44:30 --> URI Class Initialized
INFO - 2018-09-06 13:44:30 --> Router Class Initialized
INFO - 2018-09-06 13:44:30 --> Output Class Initialized
INFO - 2018-09-06 13:44:30 --> Security Class Initialized
DEBUG - 2018-09-06 13:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:44:30 --> CSRF cookie sent
INFO - 2018-09-06 13:44:30 --> CSRF token verified
INFO - 2018-09-06 13:44:30 --> Input Class Initialized
INFO - 2018-09-06 13:44:30 --> Language Class Initialized
INFO - 2018-09-06 13:44:30 --> Loader Class Initialized
INFO - 2018-09-06 13:44:30 --> Helper loaded: url_helper
INFO - 2018-09-06 13:44:30 --> Helper loaded: form_helper
INFO - 2018-09-06 13:44:30 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:44:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:44:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:44:30 --> User Agent Class Initialized
INFO - 2018-09-06 13:44:30 --> Controller Class Initialized
INFO - 2018-09-06 13:44:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:44:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:44:30 --> Pixel_Model class loaded
INFO - 2018-09-06 13:44:30 --> Database Driver Class Initialized
INFO - 2018-09-06 13:44:30 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:44:30 --> Form Validation Class Initialized
INFO - 2018-09-06 13:44:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-06 13:44:30 --> Database Driver Class Initialized
INFO - 2018-09-06 13:44:30 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:44:30 --> Config Class Initialized
INFO - 2018-09-06 13:44:30 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:44:30 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:44:30 --> Utf8 Class Initialized
INFO - 2018-09-06 13:44:30 --> URI Class Initialized
INFO - 2018-09-06 13:44:30 --> Router Class Initialized
INFO - 2018-09-06 13:44:30 --> Output Class Initialized
INFO - 2018-09-06 13:44:30 --> Security Class Initialized
DEBUG - 2018-09-06 13:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:44:30 --> CSRF cookie sent
INFO - 2018-09-06 13:44:30 --> Input Class Initialized
INFO - 2018-09-06 13:44:30 --> Language Class Initialized
INFO - 2018-09-06 13:44:30 --> Loader Class Initialized
INFO - 2018-09-06 13:44:30 --> Helper loaded: url_helper
INFO - 2018-09-06 13:44:30 --> Helper loaded: form_helper
INFO - 2018-09-06 13:44:30 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:44:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:44:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:44:30 --> User Agent Class Initialized
INFO - 2018-09-06 13:44:30 --> Controller Class Initialized
INFO - 2018-09-06 13:44:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:44:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:44:30 --> Pixel_Model class loaded
INFO - 2018-09-06 13:44:30 --> Database Driver Class Initialized
INFO - 2018-09-06 13:44:30 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:44:30 --> Database Driver Class Initialized
INFO - 2018-09-06 13:44:30 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:44:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 13:44:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 13:44:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 13:44:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-06 13:44:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-06 13:44:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-06 13:44:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_owner.php
INFO - 2018-09-06 13:44:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 13:44:30 --> Final output sent to browser
DEBUG - 2018-09-06 13:44:30 --> Total execution time: 0.0480
INFO - 2018-09-06 13:44:31 --> Config Class Initialized
INFO - 2018-09-06 13:44:31 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:44:31 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:44:31 --> Utf8 Class Initialized
INFO - 2018-09-06 13:44:31 --> URI Class Initialized
INFO - 2018-09-06 13:44:31 --> Router Class Initialized
INFO - 2018-09-06 13:44:31 --> Output Class Initialized
INFO - 2018-09-06 13:44:31 --> Security Class Initialized
DEBUG - 2018-09-06 13:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:44:31 --> CSRF cookie sent
INFO - 2018-09-06 13:44:31 --> CSRF token verified
INFO - 2018-09-06 13:44:31 --> Input Class Initialized
INFO - 2018-09-06 13:44:31 --> Language Class Initialized
INFO - 2018-09-06 13:44:31 --> Loader Class Initialized
INFO - 2018-09-06 13:44:31 --> Helper loaded: url_helper
INFO - 2018-09-06 13:44:31 --> Helper loaded: form_helper
INFO - 2018-09-06 13:44:31 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:44:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:44:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:44:31 --> User Agent Class Initialized
INFO - 2018-09-06 13:44:31 --> Controller Class Initialized
INFO - 2018-09-06 13:44:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:44:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:44:31 --> Pixel_Model class loaded
INFO - 2018-09-06 13:44:31 --> Database Driver Class Initialized
INFO - 2018-09-06 13:44:31 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:44:31 --> Form Validation Class Initialized
INFO - 2018-09-06 13:44:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-06 13:44:31 --> Database Driver Class Initialized
INFO - 2018-09-06 13:44:31 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:44:31 --> Config Class Initialized
INFO - 2018-09-06 13:44:31 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:44:31 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:44:31 --> Utf8 Class Initialized
INFO - 2018-09-06 13:44:31 --> URI Class Initialized
INFO - 2018-09-06 13:44:31 --> Router Class Initialized
INFO - 2018-09-06 13:44:31 --> Output Class Initialized
INFO - 2018-09-06 13:44:31 --> Security Class Initialized
DEBUG - 2018-09-06 13:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:44:31 --> CSRF cookie sent
INFO - 2018-09-06 13:44:31 --> Input Class Initialized
INFO - 2018-09-06 13:44:31 --> Language Class Initialized
INFO - 2018-09-06 13:44:31 --> Loader Class Initialized
INFO - 2018-09-06 13:44:31 --> Helper loaded: url_helper
INFO - 2018-09-06 13:44:31 --> Helper loaded: form_helper
INFO - 2018-09-06 13:44:31 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:44:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:44:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:44:31 --> User Agent Class Initialized
INFO - 2018-09-06 13:44:31 --> Controller Class Initialized
INFO - 2018-09-06 13:44:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:44:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:44:31 --> Pixel_Model class loaded
INFO - 2018-09-06 13:44:31 --> Database Driver Class Initialized
INFO - 2018-09-06 13:44:31 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:44:31 --> Database Driver Class Initialized
INFO - 2018-09-06 13:44:31 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:44:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 13:44:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 13:44:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 13:44:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-06 13:44:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-06 13:44:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-06 13:44:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_value.php
INFO - 2018-09-06 13:44:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 13:44:31 --> Final output sent to browser
DEBUG - 2018-09-06 13:44:31 --> Total execution time: 0.0458
INFO - 2018-09-06 13:45:16 --> Config Class Initialized
INFO - 2018-09-06 13:45:16 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:45:16 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:45:16 --> Utf8 Class Initialized
INFO - 2018-09-06 13:45:16 --> URI Class Initialized
INFO - 2018-09-06 13:45:16 --> Router Class Initialized
INFO - 2018-09-06 13:45:16 --> Output Class Initialized
INFO - 2018-09-06 13:45:16 --> Security Class Initialized
DEBUG - 2018-09-06 13:45:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:45:16 --> CSRF cookie sent
INFO - 2018-09-06 13:45:16 --> Input Class Initialized
INFO - 2018-09-06 13:45:16 --> Language Class Initialized
INFO - 2018-09-06 13:45:16 --> Loader Class Initialized
INFO - 2018-09-06 13:45:16 --> Helper loaded: url_helper
INFO - 2018-09-06 13:45:16 --> Helper loaded: form_helper
INFO - 2018-09-06 13:45:16 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:45:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:45:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:45:16 --> User Agent Class Initialized
INFO - 2018-09-06 13:45:16 --> Controller Class Initialized
INFO - 2018-09-06 13:45:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:45:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:45:16 --> Pixel_Model class loaded
INFO - 2018-09-06 13:45:16 --> Database Driver Class Initialized
INFO - 2018-09-06 13:45:16 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:45:16 --> Database Driver Class Initialized
INFO - 2018-09-06 13:45:16 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:45:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 13:45:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 13:45:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 13:45:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-06 13:45:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-06 13:45:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-06 13:45:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_owner.php
INFO - 2018-09-06 13:45:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 13:45:16 --> Final output sent to browser
DEBUG - 2018-09-06 13:45:16 --> Total execution time: 0.0465
INFO - 2018-09-06 13:45:17 --> Config Class Initialized
INFO - 2018-09-06 13:45:17 --> Hooks Class Initialized
DEBUG - 2018-09-06 13:45:17 --> UTF-8 Support Enabled
INFO - 2018-09-06 13:45:17 --> Utf8 Class Initialized
INFO - 2018-09-06 13:45:17 --> URI Class Initialized
INFO - 2018-09-06 13:45:17 --> Router Class Initialized
INFO - 2018-09-06 13:45:17 --> Output Class Initialized
INFO - 2018-09-06 13:45:17 --> Security Class Initialized
DEBUG - 2018-09-06 13:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 13:45:17 --> CSRF cookie sent
INFO - 2018-09-06 13:45:17 --> Input Class Initialized
INFO - 2018-09-06 13:45:17 --> Language Class Initialized
INFO - 2018-09-06 13:45:17 --> Loader Class Initialized
INFO - 2018-09-06 13:45:17 --> Helper loaded: url_helper
INFO - 2018-09-06 13:45:17 --> Helper loaded: form_helper
INFO - 2018-09-06 13:45:17 --> Helper loaded: language_helper
DEBUG - 2018-09-06 13:45:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 13:45:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 13:45:17 --> User Agent Class Initialized
INFO - 2018-09-06 13:45:17 --> Controller Class Initialized
INFO - 2018-09-06 13:45:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 13:45:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 13:45:17 --> Pixel_Model class loaded
INFO - 2018-09-06 13:45:17 --> Database Driver Class Initialized
INFO - 2018-09-06 13:45:17 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:45:17 --> Database Driver Class Initialized
INFO - 2018-09-06 13:45:17 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 13:45:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 13:45:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 13:45:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 13:45:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-06 13:45:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-06 13:45:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-06 13:45:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-09-06 13:45:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 13:45:17 --> Final output sent to browser
DEBUG - 2018-09-06 13:45:17 --> Total execution time: 0.0524
INFO - 2018-09-06 17:48:12 --> Config Class Initialized
INFO - 2018-09-06 17:48:12 --> Hooks Class Initialized
DEBUG - 2018-09-06 17:48:12 --> UTF-8 Support Enabled
INFO - 2018-09-06 17:48:12 --> Utf8 Class Initialized
INFO - 2018-09-06 17:48:12 --> URI Class Initialized
DEBUG - 2018-09-06 17:48:12 --> No URI present. Default controller set.
INFO - 2018-09-06 17:48:12 --> Router Class Initialized
INFO - 2018-09-06 17:48:12 --> Output Class Initialized
INFO - 2018-09-06 17:48:12 --> Security Class Initialized
DEBUG - 2018-09-06 17:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 17:48:12 --> CSRF cookie sent
INFO - 2018-09-06 17:48:12 --> Input Class Initialized
INFO - 2018-09-06 17:48:12 --> Language Class Initialized
INFO - 2018-09-06 17:48:12 --> Loader Class Initialized
INFO - 2018-09-06 17:48:12 --> Helper loaded: url_helper
INFO - 2018-09-06 17:48:12 --> Helper loaded: form_helper
INFO - 2018-09-06 17:48:12 --> Helper loaded: language_helper
DEBUG - 2018-09-06 17:48:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 17:48:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 17:48:12 --> User Agent Class Initialized
INFO - 2018-09-06 17:48:12 --> Controller Class Initialized
INFO - 2018-09-06 17:48:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 17:48:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 17:48:12 --> Pixel_Model class loaded
INFO - 2018-09-06 17:48:12 --> Database Driver Class Initialized
INFO - 2018-09-06 17:48:12 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 17:48:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 17:48:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 17:48:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-09-06 17:48:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 17:48:12 --> Final output sent to browser
DEBUG - 2018-09-06 17:48:12 --> Total execution time: 0.0437
INFO - 2018-09-06 17:48:17 --> Config Class Initialized
INFO - 2018-09-06 17:48:17 --> Hooks Class Initialized
DEBUG - 2018-09-06 17:48:17 --> UTF-8 Support Enabled
INFO - 2018-09-06 17:48:17 --> Utf8 Class Initialized
INFO - 2018-09-06 17:48:17 --> URI Class Initialized
INFO - 2018-09-06 17:48:17 --> Router Class Initialized
INFO - 2018-09-06 17:48:17 --> Output Class Initialized
INFO - 2018-09-06 17:48:17 --> Security Class Initialized
DEBUG - 2018-09-06 17:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 17:48:17 --> CSRF cookie sent
INFO - 2018-09-06 17:48:17 --> CSRF token verified
INFO - 2018-09-06 17:48:17 --> Input Class Initialized
INFO - 2018-09-06 17:48:17 --> Language Class Initialized
INFO - 2018-09-06 17:48:17 --> Loader Class Initialized
INFO - 2018-09-06 17:48:17 --> Helper loaded: url_helper
INFO - 2018-09-06 17:48:17 --> Helper loaded: form_helper
INFO - 2018-09-06 17:48:17 --> Helper loaded: language_helper
DEBUG - 2018-09-06 17:48:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 17:48:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 17:48:17 --> User Agent Class Initialized
INFO - 2018-09-06 17:48:17 --> Controller Class Initialized
INFO - 2018-09-06 17:48:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 17:48:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 17:48:17 --> Pixel_Model class loaded
INFO - 2018-09-06 17:48:17 --> Database Driver Class Initialized
INFO - 2018-09-06 17:48:17 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 17:48:17 --> Database Driver Class Initialized
INFO - 2018-09-06 17:48:17 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 17:48:17 --> Config Class Initialized
INFO - 2018-09-06 17:48:17 --> Hooks Class Initialized
DEBUG - 2018-09-06 17:48:17 --> UTF-8 Support Enabled
INFO - 2018-09-06 17:48:17 --> Utf8 Class Initialized
INFO - 2018-09-06 17:48:17 --> URI Class Initialized
INFO - 2018-09-06 17:48:17 --> Router Class Initialized
INFO - 2018-09-06 17:48:17 --> Output Class Initialized
INFO - 2018-09-06 17:48:17 --> Security Class Initialized
DEBUG - 2018-09-06 17:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 17:48:17 --> CSRF cookie sent
INFO - 2018-09-06 17:48:17 --> Input Class Initialized
INFO - 2018-09-06 17:48:17 --> Language Class Initialized
INFO - 2018-09-06 17:48:17 --> Loader Class Initialized
INFO - 2018-09-06 17:48:17 --> Helper loaded: url_helper
INFO - 2018-09-06 17:48:17 --> Helper loaded: form_helper
INFO - 2018-09-06 17:48:17 --> Helper loaded: language_helper
DEBUG - 2018-09-06 17:48:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 17:48:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 17:48:17 --> User Agent Class Initialized
INFO - 2018-09-06 17:48:17 --> Controller Class Initialized
INFO - 2018-09-06 17:48:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 17:48:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 17:48:17 --> Pixel_Model class loaded
INFO - 2018-09-06 17:48:17 --> Database Driver Class Initialized
INFO - 2018-09-06 17:48:17 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 17:48:17 --> Database Driver Class Initialized
INFO - 2018-09-06 17:48:17 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 17:48:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 17:48:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 17:48:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 17:48:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-06 17:48:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-06 17:48:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-06 17:48:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-09-06 17:48:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 17:48:17 --> Final output sent to browser
DEBUG - 2018-09-06 17:48:17 --> Total execution time: 0.0473
INFO - 2018-09-06 17:48:21 --> Config Class Initialized
INFO - 2018-09-06 17:48:21 --> Hooks Class Initialized
DEBUG - 2018-09-06 17:48:21 --> UTF-8 Support Enabled
INFO - 2018-09-06 17:48:21 --> Utf8 Class Initialized
INFO - 2018-09-06 17:48:21 --> URI Class Initialized
INFO - 2018-09-06 17:48:21 --> Router Class Initialized
INFO - 2018-09-06 17:48:21 --> Output Class Initialized
INFO - 2018-09-06 17:48:21 --> Security Class Initialized
DEBUG - 2018-09-06 17:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 17:48:21 --> CSRF cookie sent
INFO - 2018-09-06 17:48:21 --> CSRF token verified
INFO - 2018-09-06 17:48:21 --> Input Class Initialized
INFO - 2018-09-06 17:48:21 --> Language Class Initialized
INFO - 2018-09-06 17:48:21 --> Loader Class Initialized
INFO - 2018-09-06 17:48:21 --> Helper loaded: url_helper
INFO - 2018-09-06 17:48:21 --> Helper loaded: form_helper
INFO - 2018-09-06 17:48:21 --> Helper loaded: language_helper
DEBUG - 2018-09-06 17:48:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 17:48:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 17:48:21 --> User Agent Class Initialized
INFO - 2018-09-06 17:48:21 --> Controller Class Initialized
INFO - 2018-09-06 17:48:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 17:48:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 17:48:21 --> Pixel_Model class loaded
INFO - 2018-09-06 17:48:21 --> Database Driver Class Initialized
INFO - 2018-09-06 17:48:21 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 17:48:21 --> Form Validation Class Initialized
INFO - 2018-09-06 17:48:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-06 17:48:21 --> Database Driver Class Initialized
INFO - 2018-09-06 17:48:21 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 17:48:21 --> Config Class Initialized
INFO - 2018-09-06 17:48:21 --> Hooks Class Initialized
DEBUG - 2018-09-06 17:48:21 --> UTF-8 Support Enabled
INFO - 2018-09-06 17:48:21 --> Utf8 Class Initialized
INFO - 2018-09-06 17:48:21 --> URI Class Initialized
INFO - 2018-09-06 17:48:21 --> Router Class Initialized
INFO - 2018-09-06 17:48:21 --> Output Class Initialized
INFO - 2018-09-06 17:48:21 --> Security Class Initialized
DEBUG - 2018-09-06 17:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 17:48:21 --> CSRF cookie sent
INFO - 2018-09-06 17:48:21 --> Input Class Initialized
INFO - 2018-09-06 17:48:21 --> Language Class Initialized
INFO - 2018-09-06 17:48:21 --> Loader Class Initialized
INFO - 2018-09-06 17:48:21 --> Helper loaded: url_helper
INFO - 2018-09-06 17:48:21 --> Helper loaded: form_helper
INFO - 2018-09-06 17:48:21 --> Helper loaded: language_helper
DEBUG - 2018-09-06 17:48:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 17:48:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 17:48:21 --> User Agent Class Initialized
INFO - 2018-09-06 17:48:21 --> Controller Class Initialized
INFO - 2018-09-06 17:48:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 17:48:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 17:48:21 --> Pixel_Model class loaded
INFO - 2018-09-06 17:48:21 --> Database Driver Class Initialized
INFO - 2018-09-06 17:48:21 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 17:48:21 --> Database Driver Class Initialized
INFO - 2018-09-06 17:48:21 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 17:48:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 17:48:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 17:48:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 17:48:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-06 17:48:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-06 17:48:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-06 17:48:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-09-06 17:48:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 17:48:21 --> Final output sent to browser
DEBUG - 2018-09-06 17:48:21 --> Total execution time: 0.0458
INFO - 2018-09-06 17:48:22 --> Config Class Initialized
INFO - 2018-09-06 17:48:22 --> Hooks Class Initialized
DEBUG - 2018-09-06 17:48:22 --> UTF-8 Support Enabled
INFO - 2018-09-06 17:48:22 --> Utf8 Class Initialized
INFO - 2018-09-06 17:48:22 --> URI Class Initialized
INFO - 2018-09-06 17:48:22 --> Router Class Initialized
INFO - 2018-09-06 17:48:22 --> Output Class Initialized
INFO - 2018-09-06 17:48:22 --> Security Class Initialized
DEBUG - 2018-09-06 17:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 17:48:22 --> CSRF cookie sent
INFO - 2018-09-06 17:48:22 --> CSRF token verified
INFO - 2018-09-06 17:48:22 --> Input Class Initialized
INFO - 2018-09-06 17:48:22 --> Language Class Initialized
INFO - 2018-09-06 17:48:22 --> Loader Class Initialized
INFO - 2018-09-06 17:48:22 --> Helper loaded: url_helper
INFO - 2018-09-06 17:48:22 --> Helper loaded: form_helper
INFO - 2018-09-06 17:48:22 --> Helper loaded: language_helper
DEBUG - 2018-09-06 17:48:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 17:48:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 17:48:22 --> User Agent Class Initialized
INFO - 2018-09-06 17:48:22 --> Controller Class Initialized
INFO - 2018-09-06 17:48:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 17:48:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 17:48:22 --> Pixel_Model class loaded
INFO - 2018-09-06 17:48:22 --> Database Driver Class Initialized
INFO - 2018-09-06 17:48:22 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 17:48:22 --> Form Validation Class Initialized
INFO - 2018-09-06 17:48:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-06 17:48:22 --> Database Driver Class Initialized
INFO - 2018-09-06 17:48:22 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 17:48:22 --> Config Class Initialized
INFO - 2018-09-06 17:48:22 --> Hooks Class Initialized
DEBUG - 2018-09-06 17:48:22 --> UTF-8 Support Enabled
INFO - 2018-09-06 17:48:22 --> Utf8 Class Initialized
INFO - 2018-09-06 17:48:22 --> URI Class Initialized
INFO - 2018-09-06 17:48:22 --> Router Class Initialized
INFO - 2018-09-06 17:48:22 --> Output Class Initialized
INFO - 2018-09-06 17:48:22 --> Security Class Initialized
DEBUG - 2018-09-06 17:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 17:48:22 --> CSRF cookie sent
INFO - 2018-09-06 17:48:22 --> Input Class Initialized
INFO - 2018-09-06 17:48:22 --> Language Class Initialized
INFO - 2018-09-06 17:48:22 --> Loader Class Initialized
INFO - 2018-09-06 17:48:22 --> Helper loaded: url_helper
INFO - 2018-09-06 17:48:22 --> Helper loaded: form_helper
INFO - 2018-09-06 17:48:22 --> Helper loaded: language_helper
DEBUG - 2018-09-06 17:48:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 17:48:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 17:48:22 --> User Agent Class Initialized
INFO - 2018-09-06 17:48:22 --> Controller Class Initialized
INFO - 2018-09-06 17:48:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 17:48:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 17:48:22 --> Pixel_Model class loaded
INFO - 2018-09-06 17:48:22 --> Database Driver Class Initialized
INFO - 2018-09-06 17:48:22 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 17:48:22 --> Database Driver Class Initialized
INFO - 2018-09-06 17:48:22 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 17:48:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 17:48:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 17:48:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-09-06 17:48:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 17:48:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-06 17:48:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-06 17:48:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-06 17:48:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-09-06 17:48:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 17:48:22 --> Final output sent to browser
DEBUG - 2018-09-06 17:48:22 --> Total execution time: 0.0436
INFO - 2018-09-06 17:48:25 --> Config Class Initialized
INFO - 2018-09-06 17:48:25 --> Hooks Class Initialized
DEBUG - 2018-09-06 17:48:25 --> UTF-8 Support Enabled
INFO - 2018-09-06 17:48:25 --> Utf8 Class Initialized
INFO - 2018-09-06 17:48:25 --> URI Class Initialized
INFO - 2018-09-06 17:48:25 --> Router Class Initialized
INFO - 2018-09-06 17:48:25 --> Output Class Initialized
INFO - 2018-09-06 17:48:25 --> Security Class Initialized
DEBUG - 2018-09-06 17:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 17:48:25 --> CSRF cookie sent
INFO - 2018-09-06 17:48:25 --> CSRF token verified
INFO - 2018-09-06 17:48:25 --> Input Class Initialized
INFO - 2018-09-06 17:48:25 --> Language Class Initialized
INFO - 2018-09-06 17:48:25 --> Loader Class Initialized
INFO - 2018-09-06 17:48:25 --> Helper loaded: url_helper
INFO - 2018-09-06 17:48:25 --> Helper loaded: form_helper
INFO - 2018-09-06 17:48:25 --> Helper loaded: language_helper
DEBUG - 2018-09-06 17:48:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 17:48:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 17:48:26 --> User Agent Class Initialized
INFO - 2018-09-06 17:48:26 --> Controller Class Initialized
INFO - 2018-09-06 17:48:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 17:48:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 17:48:26 --> Pixel_Model class loaded
INFO - 2018-09-06 17:48:26 --> Database Driver Class Initialized
INFO - 2018-09-06 17:48:26 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 17:48:26 --> Form Validation Class Initialized
INFO - 2018-09-06 17:48:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-06 17:48:26 --> Database Driver Class Initialized
INFO - 2018-09-06 17:48:26 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 17:48:26 --> Config Class Initialized
INFO - 2018-09-06 17:48:26 --> Hooks Class Initialized
DEBUG - 2018-09-06 17:48:26 --> UTF-8 Support Enabled
INFO - 2018-09-06 17:48:26 --> Utf8 Class Initialized
INFO - 2018-09-06 17:48:26 --> URI Class Initialized
INFO - 2018-09-06 17:48:26 --> Router Class Initialized
INFO - 2018-09-06 17:48:26 --> Output Class Initialized
INFO - 2018-09-06 17:48:26 --> Security Class Initialized
DEBUG - 2018-09-06 17:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 17:48:26 --> CSRF cookie sent
INFO - 2018-09-06 17:48:26 --> Input Class Initialized
INFO - 2018-09-06 17:48:26 --> Language Class Initialized
INFO - 2018-09-06 17:48:26 --> Loader Class Initialized
INFO - 2018-09-06 17:48:26 --> Helper loaded: url_helper
INFO - 2018-09-06 17:48:26 --> Helper loaded: form_helper
INFO - 2018-09-06 17:48:26 --> Helper loaded: language_helper
DEBUG - 2018-09-06 17:48:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 17:48:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 17:48:26 --> User Agent Class Initialized
INFO - 2018-09-06 17:48:26 --> Controller Class Initialized
INFO - 2018-09-06 17:48:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 17:48:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 17:48:26 --> Pixel_Model class loaded
INFO - 2018-09-06 17:48:26 --> Database Driver Class Initialized
INFO - 2018-09-06 17:48:26 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 17:48:26 --> Database Driver Class Initialized
INFO - 2018-09-06 17:48:26 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 17:48:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 17:48:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 17:48:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 17:48:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-06 17:48:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-06 17:48:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-06 17:48:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-09-06 17:48:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 17:48:26 --> Final output sent to browser
DEBUG - 2018-09-06 17:48:26 --> Total execution time: 0.0447
INFO - 2018-09-06 17:48:29 --> Config Class Initialized
INFO - 2018-09-06 17:48:29 --> Hooks Class Initialized
DEBUG - 2018-09-06 17:48:29 --> UTF-8 Support Enabled
INFO - 2018-09-06 17:48:29 --> Utf8 Class Initialized
INFO - 2018-09-06 17:48:29 --> URI Class Initialized
INFO - 2018-09-06 17:48:29 --> Router Class Initialized
INFO - 2018-09-06 17:48:29 --> Output Class Initialized
INFO - 2018-09-06 17:48:29 --> Security Class Initialized
DEBUG - 2018-09-06 17:48:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 17:48:29 --> CSRF cookie sent
INFO - 2018-09-06 17:48:29 --> CSRF token verified
INFO - 2018-09-06 17:48:29 --> Input Class Initialized
INFO - 2018-09-06 17:48:29 --> Language Class Initialized
INFO - 2018-09-06 17:48:29 --> Loader Class Initialized
INFO - 2018-09-06 17:48:29 --> Helper loaded: url_helper
INFO - 2018-09-06 17:48:29 --> Helper loaded: form_helper
INFO - 2018-09-06 17:48:29 --> Helper loaded: language_helper
DEBUG - 2018-09-06 17:48:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 17:48:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 17:48:29 --> User Agent Class Initialized
INFO - 2018-09-06 17:48:29 --> Controller Class Initialized
INFO - 2018-09-06 17:48:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 17:48:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 17:48:29 --> Pixel_Model class loaded
INFO - 2018-09-06 17:48:29 --> Database Driver Class Initialized
INFO - 2018-09-06 17:48:29 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 17:48:29 --> Form Validation Class Initialized
INFO - 2018-09-06 17:48:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-06 17:48:29 --> Database Driver Class Initialized
INFO - 2018-09-06 17:48:29 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 17:48:29 --> Config Class Initialized
INFO - 2018-09-06 17:48:29 --> Hooks Class Initialized
DEBUG - 2018-09-06 17:48:29 --> UTF-8 Support Enabled
INFO - 2018-09-06 17:48:29 --> Utf8 Class Initialized
INFO - 2018-09-06 17:48:29 --> URI Class Initialized
INFO - 2018-09-06 17:48:29 --> Router Class Initialized
INFO - 2018-09-06 17:48:29 --> Output Class Initialized
INFO - 2018-09-06 17:48:29 --> Security Class Initialized
DEBUG - 2018-09-06 17:48:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 17:48:29 --> CSRF cookie sent
INFO - 2018-09-06 17:48:29 --> Input Class Initialized
INFO - 2018-09-06 17:48:29 --> Language Class Initialized
INFO - 2018-09-06 17:48:29 --> Loader Class Initialized
INFO - 2018-09-06 17:48:29 --> Helper loaded: url_helper
INFO - 2018-09-06 17:48:29 --> Helper loaded: form_helper
INFO - 2018-09-06 17:48:29 --> Helper loaded: language_helper
DEBUG - 2018-09-06 17:48:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 17:48:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 17:48:29 --> User Agent Class Initialized
INFO - 2018-09-06 17:48:29 --> Controller Class Initialized
INFO - 2018-09-06 17:48:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 17:48:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 17:48:30 --> Pixel_Model class loaded
INFO - 2018-09-06 17:48:30 --> Database Driver Class Initialized
INFO - 2018-09-06 17:48:30 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 17:48:30 --> Config Class Initialized
INFO - 2018-09-06 17:48:30 --> Hooks Class Initialized
DEBUG - 2018-09-06 17:48:30 --> UTF-8 Support Enabled
INFO - 2018-09-06 17:48:30 --> Utf8 Class Initialized
INFO - 2018-09-06 17:48:30 --> URI Class Initialized
INFO - 2018-09-06 17:48:30 --> Router Class Initialized
INFO - 2018-09-06 17:48:30 --> Output Class Initialized
INFO - 2018-09-06 17:48:30 --> Security Class Initialized
DEBUG - 2018-09-06 17:48:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 17:48:30 --> CSRF cookie sent
INFO - 2018-09-06 17:48:30 --> Input Class Initialized
INFO - 2018-09-06 17:48:30 --> Language Class Initialized
INFO - 2018-09-06 17:48:30 --> Loader Class Initialized
INFO - 2018-09-06 17:48:30 --> Helper loaded: url_helper
INFO - 2018-09-06 17:48:30 --> Helper loaded: form_helper
INFO - 2018-09-06 17:48:30 --> Helper loaded: language_helper
DEBUG - 2018-09-06 17:48:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 17:48:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 17:48:30 --> User Agent Class Initialized
INFO - 2018-09-06 17:48:30 --> Controller Class Initialized
INFO - 2018-09-06 17:48:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 17:48:30 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-09-06 17:48:30 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-09-06 17:48:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 17:48:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 17:48:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 17:48:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-09-06 17:48:30 --> Could not find the language line "req_email"
INFO - 2018-09-06 17:48:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-09-06 17:48:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 17:48:30 --> Final output sent to browser
DEBUG - 2018-09-06 17:48:30 --> Total execution time: 0.0242
INFO - 2018-09-06 17:48:37 --> Config Class Initialized
INFO - 2018-09-06 17:48:37 --> Hooks Class Initialized
DEBUG - 2018-09-06 17:48:37 --> UTF-8 Support Enabled
INFO - 2018-09-06 17:48:37 --> Utf8 Class Initialized
INFO - 2018-09-06 17:48:37 --> URI Class Initialized
INFO - 2018-09-06 17:48:37 --> Router Class Initialized
INFO - 2018-09-06 17:48:37 --> Output Class Initialized
INFO - 2018-09-06 17:48:37 --> Security Class Initialized
DEBUG - 2018-09-06 17:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 17:48:37 --> CSRF cookie sent
INFO - 2018-09-06 17:48:37 --> Input Class Initialized
INFO - 2018-09-06 17:48:37 --> Language Class Initialized
INFO - 2018-09-06 17:48:37 --> Loader Class Initialized
INFO - 2018-09-06 17:48:37 --> Helper loaded: url_helper
INFO - 2018-09-06 17:48:37 --> Helper loaded: form_helper
INFO - 2018-09-06 17:48:37 --> Helper loaded: language_helper
DEBUG - 2018-09-06 17:48:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 17:48:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 17:48:37 --> User Agent Class Initialized
INFO - 2018-09-06 17:48:37 --> Controller Class Initialized
INFO - 2018-09-06 17:48:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 17:48:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 17:48:37 --> Pixel_Model class loaded
INFO - 2018-09-06 17:48:37 --> Database Driver Class Initialized
INFO - 2018-09-06 17:48:37 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 17:48:37 --> Database Driver Class Initialized
INFO - 2018-09-06 17:48:37 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 17:48:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 17:48:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 17:48:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 17:48:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-06 17:48:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-06 17:48:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-06 17:48:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-09-06 17:48:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 17:48:37 --> Final output sent to browser
DEBUG - 2018-09-06 17:48:37 --> Total execution time: 0.0406
INFO - 2018-09-06 17:50:42 --> Config Class Initialized
INFO - 2018-09-06 17:50:42 --> Hooks Class Initialized
DEBUG - 2018-09-06 17:50:42 --> UTF-8 Support Enabled
INFO - 2018-09-06 17:50:42 --> Utf8 Class Initialized
INFO - 2018-09-06 17:50:42 --> URI Class Initialized
INFO - 2018-09-06 17:50:42 --> Router Class Initialized
INFO - 2018-09-06 17:50:42 --> Output Class Initialized
INFO - 2018-09-06 17:50:42 --> Security Class Initialized
DEBUG - 2018-09-06 17:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 17:50:42 --> CSRF cookie sent
INFO - 2018-09-06 17:50:42 --> CSRF token verified
INFO - 2018-09-06 17:50:42 --> Input Class Initialized
INFO - 2018-09-06 17:50:42 --> Language Class Initialized
INFO - 2018-09-06 17:50:42 --> Loader Class Initialized
INFO - 2018-09-06 17:50:42 --> Helper loaded: url_helper
INFO - 2018-09-06 17:50:42 --> Helper loaded: form_helper
INFO - 2018-09-06 17:50:42 --> Helper loaded: language_helper
DEBUG - 2018-09-06 17:50:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 17:50:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 17:50:42 --> User Agent Class Initialized
INFO - 2018-09-06 17:50:42 --> Controller Class Initialized
INFO - 2018-09-06 17:50:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 17:50:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 17:50:42 --> Pixel_Model class loaded
INFO - 2018-09-06 17:50:42 --> Database Driver Class Initialized
INFO - 2018-09-06 17:50:42 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 17:50:42 --> Form Validation Class Initialized
INFO - 2018-09-06 17:50:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-06 17:50:42 --> Database Driver Class Initialized
INFO - 2018-09-06 17:50:42 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 17:50:42 --> Config Class Initialized
INFO - 2018-09-06 17:50:42 --> Hooks Class Initialized
DEBUG - 2018-09-06 17:50:42 --> UTF-8 Support Enabled
INFO - 2018-09-06 17:50:42 --> Utf8 Class Initialized
INFO - 2018-09-06 17:50:42 --> URI Class Initialized
INFO - 2018-09-06 17:50:42 --> Router Class Initialized
INFO - 2018-09-06 17:50:42 --> Output Class Initialized
INFO - 2018-09-06 17:50:42 --> Security Class Initialized
DEBUG - 2018-09-06 17:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 17:50:42 --> CSRF cookie sent
INFO - 2018-09-06 17:50:42 --> Input Class Initialized
INFO - 2018-09-06 17:50:42 --> Language Class Initialized
INFO - 2018-09-06 17:50:42 --> Loader Class Initialized
INFO - 2018-09-06 17:50:42 --> Helper loaded: url_helper
INFO - 2018-09-06 17:50:42 --> Helper loaded: form_helper
INFO - 2018-09-06 17:50:42 --> Helper loaded: language_helper
DEBUG - 2018-09-06 17:50:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 17:50:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 17:50:42 --> User Agent Class Initialized
INFO - 2018-09-06 17:50:42 --> Controller Class Initialized
INFO - 2018-09-06 17:50:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 17:50:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 17:50:42 --> Pixel_Model class loaded
INFO - 2018-09-06 17:50:42 --> Database Driver Class Initialized
INFO - 2018-09-06 17:50:42 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 17:50:42 --> Database Driver Class Initialized
INFO - 2018-09-06 17:50:42 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 17:50:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 17:50:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 17:50:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 17:50:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-06 17:50:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-06 17:50:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-06 17:50:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/marriage.php
INFO - 2018-09-06 17:50:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 17:50:42 --> Final output sent to browser
DEBUG - 2018-09-06 17:50:42 --> Total execution time: 0.0370
INFO - 2018-09-06 17:50:47 --> Config Class Initialized
INFO - 2018-09-06 17:50:47 --> Hooks Class Initialized
DEBUG - 2018-09-06 17:50:47 --> UTF-8 Support Enabled
INFO - 2018-09-06 17:50:47 --> Utf8 Class Initialized
INFO - 2018-09-06 17:50:47 --> URI Class Initialized
INFO - 2018-09-06 17:50:47 --> Router Class Initialized
INFO - 2018-09-06 17:50:47 --> Output Class Initialized
INFO - 2018-09-06 17:50:47 --> Security Class Initialized
DEBUG - 2018-09-06 17:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 17:50:47 --> CSRF cookie sent
INFO - 2018-09-06 17:50:47 --> CSRF token verified
INFO - 2018-09-06 17:50:47 --> Input Class Initialized
INFO - 2018-09-06 17:50:47 --> Language Class Initialized
INFO - 2018-09-06 17:50:47 --> Loader Class Initialized
INFO - 2018-09-06 17:50:47 --> Helper loaded: url_helper
INFO - 2018-09-06 17:50:47 --> Helper loaded: form_helper
INFO - 2018-09-06 17:50:47 --> Helper loaded: language_helper
DEBUG - 2018-09-06 17:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 17:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 17:50:47 --> User Agent Class Initialized
INFO - 2018-09-06 17:50:47 --> Controller Class Initialized
INFO - 2018-09-06 17:50:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 17:50:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 17:50:47 --> Pixel_Model class loaded
INFO - 2018-09-06 17:50:47 --> Database Driver Class Initialized
INFO - 2018-09-06 17:50:47 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 17:50:47 --> Form Validation Class Initialized
INFO - 2018-09-06 17:50:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-06 17:50:47 --> Database Driver Class Initialized
INFO - 2018-09-06 17:50:47 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 17:50:47 --> Config Class Initialized
INFO - 2018-09-06 17:50:47 --> Hooks Class Initialized
DEBUG - 2018-09-06 17:50:47 --> UTF-8 Support Enabled
INFO - 2018-09-06 17:50:47 --> Utf8 Class Initialized
INFO - 2018-09-06 17:50:47 --> URI Class Initialized
INFO - 2018-09-06 17:50:47 --> Router Class Initialized
INFO - 2018-09-06 17:50:47 --> Output Class Initialized
INFO - 2018-09-06 17:50:47 --> Security Class Initialized
DEBUG - 2018-09-06 17:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 17:50:47 --> CSRF cookie sent
INFO - 2018-09-06 17:50:47 --> Input Class Initialized
INFO - 2018-09-06 17:50:47 --> Language Class Initialized
INFO - 2018-09-06 17:50:47 --> Loader Class Initialized
INFO - 2018-09-06 17:50:47 --> Helper loaded: url_helper
INFO - 2018-09-06 17:50:47 --> Helper loaded: form_helper
INFO - 2018-09-06 17:50:47 --> Helper loaded: language_helper
DEBUG - 2018-09-06 17:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 17:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 17:50:47 --> User Agent Class Initialized
INFO - 2018-09-06 17:50:47 --> Controller Class Initialized
INFO - 2018-09-06 17:50:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 17:50:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 17:50:47 --> Pixel_Model class loaded
INFO - 2018-09-06 17:50:47 --> Database Driver Class Initialized
INFO - 2018-09-06 17:50:47 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 17:50:47 --> Database Driver Class Initialized
INFO - 2018-09-06 17:50:47 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 17:50:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 17:50:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 17:50:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 17:50:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-06 17:50:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-06 17:50:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-06 17:50:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-09-06 17:50:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 17:50:47 --> Final output sent to browser
DEBUG - 2018-09-06 17:50:47 --> Total execution time: 0.0395
INFO - 2018-09-06 17:50:50 --> Config Class Initialized
INFO - 2018-09-06 17:50:50 --> Hooks Class Initialized
DEBUG - 2018-09-06 17:50:50 --> UTF-8 Support Enabled
INFO - 2018-09-06 17:50:50 --> Utf8 Class Initialized
INFO - 2018-09-06 17:50:50 --> URI Class Initialized
INFO - 2018-09-06 17:50:50 --> Router Class Initialized
INFO - 2018-09-06 17:50:50 --> Output Class Initialized
INFO - 2018-09-06 17:50:50 --> Security Class Initialized
DEBUG - 2018-09-06 17:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 17:50:50 --> CSRF cookie sent
INFO - 2018-09-06 17:50:50 --> CSRF token verified
INFO - 2018-09-06 17:50:50 --> Input Class Initialized
INFO - 2018-09-06 17:50:50 --> Language Class Initialized
INFO - 2018-09-06 17:50:50 --> Loader Class Initialized
INFO - 2018-09-06 17:50:50 --> Helper loaded: url_helper
INFO - 2018-09-06 17:50:50 --> Helper loaded: form_helper
INFO - 2018-09-06 17:50:50 --> Helper loaded: language_helper
DEBUG - 2018-09-06 17:50:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 17:50:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 17:50:50 --> User Agent Class Initialized
INFO - 2018-09-06 17:50:50 --> Controller Class Initialized
INFO - 2018-09-06 17:50:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 17:50:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 17:50:50 --> Pixel_Model class loaded
INFO - 2018-09-06 17:50:50 --> Database Driver Class Initialized
INFO - 2018-09-06 17:50:50 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 17:50:50 --> Form Validation Class Initialized
INFO - 2018-09-06 17:50:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-06 17:50:50 --> Database Driver Class Initialized
INFO - 2018-09-06 17:50:50 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 17:50:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 17:50:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 17:50:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 17:50:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-06 17:50:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-06 17:50:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_errors.php
INFO - 2018-09-06 17:50:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-06 17:50:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-09-06 17:50:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 17:50:50 --> Final output sent to browser
DEBUG - 2018-09-06 17:50:50 --> Total execution time: 0.0416
INFO - 2018-09-06 17:50:53 --> Config Class Initialized
INFO - 2018-09-06 17:50:53 --> Hooks Class Initialized
DEBUG - 2018-09-06 17:50:53 --> UTF-8 Support Enabled
INFO - 2018-09-06 17:50:53 --> Utf8 Class Initialized
INFO - 2018-09-06 17:50:53 --> URI Class Initialized
INFO - 2018-09-06 17:50:53 --> Router Class Initialized
INFO - 2018-09-06 17:50:53 --> Output Class Initialized
INFO - 2018-09-06 17:50:53 --> Security Class Initialized
DEBUG - 2018-09-06 17:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 17:50:53 --> CSRF cookie sent
INFO - 2018-09-06 17:50:53 --> CSRF token verified
INFO - 2018-09-06 17:50:53 --> Input Class Initialized
INFO - 2018-09-06 17:50:53 --> Language Class Initialized
INFO - 2018-09-06 17:50:53 --> Loader Class Initialized
INFO - 2018-09-06 17:50:53 --> Helper loaded: url_helper
INFO - 2018-09-06 17:50:53 --> Helper loaded: form_helper
INFO - 2018-09-06 17:50:53 --> Helper loaded: language_helper
DEBUG - 2018-09-06 17:50:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 17:50:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 17:50:53 --> User Agent Class Initialized
INFO - 2018-09-06 17:50:53 --> Controller Class Initialized
INFO - 2018-09-06 17:50:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 17:50:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 17:50:53 --> Pixel_Model class loaded
INFO - 2018-09-06 17:50:53 --> Database Driver Class Initialized
INFO - 2018-09-06 17:50:53 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 17:50:53 --> Form Validation Class Initialized
INFO - 2018-09-06 17:50:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-06 17:50:53 --> Database Driver Class Initialized
INFO - 2018-09-06 17:50:53 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 17:50:53 --> Config Class Initialized
INFO - 2018-09-06 17:50:53 --> Hooks Class Initialized
DEBUG - 2018-09-06 17:50:53 --> UTF-8 Support Enabled
INFO - 2018-09-06 17:50:53 --> Utf8 Class Initialized
INFO - 2018-09-06 17:50:53 --> URI Class Initialized
INFO - 2018-09-06 17:50:53 --> Router Class Initialized
INFO - 2018-09-06 17:50:53 --> Output Class Initialized
INFO - 2018-09-06 17:50:53 --> Security Class Initialized
DEBUG - 2018-09-06 17:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 17:50:53 --> CSRF cookie sent
INFO - 2018-09-06 17:50:53 --> Input Class Initialized
INFO - 2018-09-06 17:50:53 --> Language Class Initialized
INFO - 2018-09-06 17:50:53 --> Loader Class Initialized
INFO - 2018-09-06 17:50:53 --> Helper loaded: url_helper
INFO - 2018-09-06 17:50:53 --> Helper loaded: form_helper
INFO - 2018-09-06 17:50:53 --> Helper loaded: language_helper
DEBUG - 2018-09-06 17:50:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 17:50:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 17:50:53 --> User Agent Class Initialized
INFO - 2018-09-06 17:50:53 --> Controller Class Initialized
INFO - 2018-09-06 17:50:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 17:50:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 17:50:53 --> Pixel_Model class loaded
INFO - 2018-09-06 17:50:53 --> Database Driver Class Initialized
INFO - 2018-09-06 17:50:53 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 17:50:53 --> Database Driver Class Initialized
INFO - 2018-09-06 17:50:53 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 17:50:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 17:50:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 17:50:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 17:50:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-06 17:50:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-06 17:50:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-06 17:50:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-09-06 17:50:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 17:50:53 --> Final output sent to browser
DEBUG - 2018-09-06 17:50:53 --> Total execution time: 0.0569
INFO - 2018-09-06 17:50:56 --> Config Class Initialized
INFO - 2018-09-06 17:50:56 --> Hooks Class Initialized
DEBUG - 2018-09-06 17:50:56 --> UTF-8 Support Enabled
INFO - 2018-09-06 17:50:56 --> Utf8 Class Initialized
INFO - 2018-09-06 17:50:56 --> URI Class Initialized
INFO - 2018-09-06 17:50:56 --> Router Class Initialized
INFO - 2018-09-06 17:50:56 --> Output Class Initialized
INFO - 2018-09-06 17:50:56 --> Security Class Initialized
DEBUG - 2018-09-06 17:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 17:50:56 --> CSRF cookie sent
INFO - 2018-09-06 17:50:56 --> CSRF token verified
INFO - 2018-09-06 17:50:56 --> Input Class Initialized
INFO - 2018-09-06 17:50:56 --> Language Class Initialized
INFO - 2018-09-06 17:50:56 --> Loader Class Initialized
INFO - 2018-09-06 17:50:56 --> Helper loaded: url_helper
INFO - 2018-09-06 17:50:56 --> Helper loaded: form_helper
INFO - 2018-09-06 17:50:56 --> Helper loaded: language_helper
DEBUG - 2018-09-06 17:50:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 17:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 17:50:56 --> User Agent Class Initialized
INFO - 2018-09-06 17:50:56 --> Controller Class Initialized
INFO - 2018-09-06 17:50:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 17:50:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 17:50:56 --> Pixel_Model class loaded
INFO - 2018-09-06 17:50:56 --> Database Driver Class Initialized
INFO - 2018-09-06 17:50:56 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 17:50:57 --> Form Validation Class Initialized
INFO - 2018-09-06 17:50:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-06 17:50:57 --> Database Driver Class Initialized
INFO - 2018-09-06 17:50:57 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 17:50:57 --> Config Class Initialized
INFO - 2018-09-06 17:50:57 --> Hooks Class Initialized
DEBUG - 2018-09-06 17:50:57 --> UTF-8 Support Enabled
INFO - 2018-09-06 17:50:57 --> Utf8 Class Initialized
INFO - 2018-09-06 17:50:57 --> URI Class Initialized
INFO - 2018-09-06 17:50:57 --> Router Class Initialized
INFO - 2018-09-06 17:50:57 --> Output Class Initialized
INFO - 2018-09-06 17:50:57 --> Security Class Initialized
DEBUG - 2018-09-06 17:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 17:50:57 --> CSRF cookie sent
INFO - 2018-09-06 17:50:57 --> Input Class Initialized
INFO - 2018-09-06 17:50:57 --> Language Class Initialized
INFO - 2018-09-06 17:50:57 --> Loader Class Initialized
INFO - 2018-09-06 17:50:57 --> Helper loaded: url_helper
INFO - 2018-09-06 17:50:57 --> Helper loaded: form_helper
INFO - 2018-09-06 17:50:57 --> Helper loaded: language_helper
DEBUG - 2018-09-06 17:50:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 17:50:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 17:50:57 --> User Agent Class Initialized
INFO - 2018-09-06 17:50:57 --> Controller Class Initialized
INFO - 2018-09-06 17:50:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 17:50:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 17:50:57 --> Pixel_Model class loaded
INFO - 2018-09-06 17:50:57 --> Database Driver Class Initialized
INFO - 2018-09-06 17:50:57 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 17:50:57 --> Database Driver Class Initialized
INFO - 2018-09-06 17:50:57 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 17:50:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 17:50:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 17:50:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 17:50:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-06 17:50:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-06 17:50:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-06 17:50:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-09-06 17:50:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 17:50:57 --> Final output sent to browser
DEBUG - 2018-09-06 17:50:57 --> Total execution time: 0.0445
INFO - 2018-09-06 17:50:59 --> Config Class Initialized
INFO - 2018-09-06 17:50:59 --> Hooks Class Initialized
DEBUG - 2018-09-06 17:50:59 --> UTF-8 Support Enabled
INFO - 2018-09-06 17:50:59 --> Utf8 Class Initialized
INFO - 2018-09-06 17:50:59 --> URI Class Initialized
INFO - 2018-09-06 17:50:59 --> Router Class Initialized
INFO - 2018-09-06 17:50:59 --> Output Class Initialized
INFO - 2018-09-06 17:50:59 --> Security Class Initialized
DEBUG - 2018-09-06 17:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 17:50:59 --> CSRF cookie sent
INFO - 2018-09-06 17:50:59 --> CSRF token verified
INFO - 2018-09-06 17:50:59 --> Input Class Initialized
INFO - 2018-09-06 17:50:59 --> Language Class Initialized
INFO - 2018-09-06 17:50:59 --> Loader Class Initialized
INFO - 2018-09-06 17:50:59 --> Helper loaded: url_helper
INFO - 2018-09-06 17:50:59 --> Helper loaded: form_helper
INFO - 2018-09-06 17:50:59 --> Helper loaded: language_helper
DEBUG - 2018-09-06 17:50:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 17:50:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 17:50:59 --> User Agent Class Initialized
INFO - 2018-09-06 17:50:59 --> Controller Class Initialized
INFO - 2018-09-06 17:50:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 17:50:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 17:50:59 --> Pixel_Model class loaded
INFO - 2018-09-06 17:50:59 --> Database Driver Class Initialized
INFO - 2018-09-06 17:50:59 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 17:50:59 --> Form Validation Class Initialized
INFO - 2018-09-06 17:50:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-06 17:50:59 --> Database Driver Class Initialized
INFO - 2018-09-06 17:50:59 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 17:50:59 --> Config Class Initialized
INFO - 2018-09-06 17:50:59 --> Hooks Class Initialized
DEBUG - 2018-09-06 17:50:59 --> UTF-8 Support Enabled
INFO - 2018-09-06 17:50:59 --> Utf8 Class Initialized
INFO - 2018-09-06 17:50:59 --> URI Class Initialized
INFO - 2018-09-06 17:50:59 --> Router Class Initialized
INFO - 2018-09-06 17:50:59 --> Output Class Initialized
INFO - 2018-09-06 17:50:59 --> Security Class Initialized
DEBUG - 2018-09-06 17:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 17:50:59 --> CSRF cookie sent
INFO - 2018-09-06 17:50:59 --> Input Class Initialized
INFO - 2018-09-06 17:50:59 --> Language Class Initialized
INFO - 2018-09-06 17:50:59 --> Loader Class Initialized
INFO - 2018-09-06 17:50:59 --> Helper loaded: url_helper
INFO - 2018-09-06 17:50:59 --> Helper loaded: form_helper
INFO - 2018-09-06 17:50:59 --> Helper loaded: language_helper
DEBUG - 2018-09-06 17:50:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 17:50:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 17:50:59 --> User Agent Class Initialized
INFO - 2018-09-06 17:50:59 --> Controller Class Initialized
INFO - 2018-09-06 17:50:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 17:50:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 17:50:59 --> Pixel_Model class loaded
INFO - 2018-09-06 17:50:59 --> Database Driver Class Initialized
INFO - 2018-09-06 17:50:59 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 17:50:59 --> Database Driver Class Initialized
INFO - 2018-09-06 17:50:59 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 17:50:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 17:50:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 17:50:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 17:50:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-06 17:50:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-06 17:50:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-06 17:50:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-09-06 17:50:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 17:50:59 --> Final output sent to browser
DEBUG - 2018-09-06 17:50:59 --> Total execution time: 0.0455
INFO - 2018-09-06 17:51:02 --> Config Class Initialized
INFO - 2018-09-06 17:51:02 --> Hooks Class Initialized
DEBUG - 2018-09-06 17:51:02 --> UTF-8 Support Enabled
INFO - 2018-09-06 17:51:02 --> Utf8 Class Initialized
INFO - 2018-09-06 17:51:02 --> URI Class Initialized
INFO - 2018-09-06 17:51:02 --> Router Class Initialized
INFO - 2018-09-06 17:51:02 --> Output Class Initialized
INFO - 2018-09-06 17:51:02 --> Security Class Initialized
DEBUG - 2018-09-06 17:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 17:51:02 --> CSRF cookie sent
INFO - 2018-09-06 17:51:02 --> CSRF token verified
INFO - 2018-09-06 17:51:02 --> Input Class Initialized
INFO - 2018-09-06 17:51:02 --> Language Class Initialized
INFO - 2018-09-06 17:51:02 --> Loader Class Initialized
INFO - 2018-09-06 17:51:02 --> Helper loaded: url_helper
INFO - 2018-09-06 17:51:02 --> Helper loaded: form_helper
INFO - 2018-09-06 17:51:02 --> Helper loaded: language_helper
DEBUG - 2018-09-06 17:51:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 17:51:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 17:51:02 --> User Agent Class Initialized
INFO - 2018-09-06 17:51:02 --> Controller Class Initialized
INFO - 2018-09-06 17:51:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 17:51:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 17:51:02 --> Pixel_Model class loaded
INFO - 2018-09-06 17:51:02 --> Database Driver Class Initialized
INFO - 2018-09-06 17:51:02 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 17:51:02 --> Form Validation Class Initialized
INFO - 2018-09-06 17:51:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-06 17:51:02 --> Database Driver Class Initialized
INFO - 2018-09-06 17:51:02 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 17:51:02 --> Config Class Initialized
INFO - 2018-09-06 17:51:02 --> Hooks Class Initialized
DEBUG - 2018-09-06 17:51:02 --> UTF-8 Support Enabled
INFO - 2018-09-06 17:51:02 --> Utf8 Class Initialized
INFO - 2018-09-06 17:51:02 --> URI Class Initialized
INFO - 2018-09-06 17:51:02 --> Router Class Initialized
INFO - 2018-09-06 17:51:02 --> Output Class Initialized
INFO - 2018-09-06 17:51:02 --> Security Class Initialized
DEBUG - 2018-09-06 17:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 17:51:02 --> CSRF cookie sent
INFO - 2018-09-06 17:51:02 --> Input Class Initialized
INFO - 2018-09-06 17:51:02 --> Language Class Initialized
INFO - 2018-09-06 17:51:02 --> Loader Class Initialized
INFO - 2018-09-06 17:51:02 --> Helper loaded: url_helper
INFO - 2018-09-06 17:51:02 --> Helper loaded: form_helper
INFO - 2018-09-06 17:51:02 --> Helper loaded: language_helper
DEBUG - 2018-09-06 17:51:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 17:51:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 17:51:02 --> User Agent Class Initialized
INFO - 2018-09-06 17:51:02 --> Controller Class Initialized
INFO - 2018-09-06 17:51:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 17:51:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 17:51:02 --> Pixel_Model class loaded
INFO - 2018-09-06 17:51:02 --> Database Driver Class Initialized
INFO - 2018-09-06 17:51:02 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 17:51:02 --> Database Driver Class Initialized
INFO - 2018-09-06 17:51:02 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 17:51:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 17:51:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 17:51:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 17:51:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-06 17:51:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-06 17:51:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-06 17:51:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_owner.php
INFO - 2018-09-06 17:51:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 17:51:02 --> Final output sent to browser
DEBUG - 2018-09-06 17:51:02 --> Total execution time: 0.0455
INFO - 2018-09-06 17:51:03 --> Config Class Initialized
INFO - 2018-09-06 17:51:03 --> Hooks Class Initialized
DEBUG - 2018-09-06 17:51:03 --> UTF-8 Support Enabled
INFO - 2018-09-06 17:51:03 --> Utf8 Class Initialized
INFO - 2018-09-06 17:51:03 --> URI Class Initialized
INFO - 2018-09-06 17:51:03 --> Router Class Initialized
INFO - 2018-09-06 17:51:03 --> Output Class Initialized
INFO - 2018-09-06 17:51:03 --> Security Class Initialized
DEBUG - 2018-09-06 17:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 17:51:03 --> CSRF cookie sent
INFO - 2018-09-06 17:51:03 --> CSRF token verified
INFO - 2018-09-06 17:51:03 --> Input Class Initialized
INFO - 2018-09-06 17:51:03 --> Language Class Initialized
INFO - 2018-09-06 17:51:03 --> Loader Class Initialized
INFO - 2018-09-06 17:51:03 --> Helper loaded: url_helper
INFO - 2018-09-06 17:51:03 --> Helper loaded: form_helper
INFO - 2018-09-06 17:51:03 --> Helper loaded: language_helper
DEBUG - 2018-09-06 17:51:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 17:51:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 17:51:03 --> User Agent Class Initialized
INFO - 2018-09-06 17:51:03 --> Controller Class Initialized
INFO - 2018-09-06 17:51:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 17:51:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 17:51:03 --> Pixel_Model class loaded
INFO - 2018-09-06 17:51:03 --> Database Driver Class Initialized
INFO - 2018-09-06 17:51:03 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 17:51:03 --> Form Validation Class Initialized
INFO - 2018-09-06 17:51:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-06 17:51:03 --> Database Driver Class Initialized
INFO - 2018-09-06 17:51:03 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 17:51:03 --> Config Class Initialized
INFO - 2018-09-06 17:51:03 --> Hooks Class Initialized
DEBUG - 2018-09-06 17:51:03 --> UTF-8 Support Enabled
INFO - 2018-09-06 17:51:03 --> Utf8 Class Initialized
INFO - 2018-09-06 17:51:03 --> URI Class Initialized
INFO - 2018-09-06 17:51:03 --> Router Class Initialized
INFO - 2018-09-06 17:51:03 --> Output Class Initialized
INFO - 2018-09-06 17:51:03 --> Security Class Initialized
DEBUG - 2018-09-06 17:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 17:51:03 --> CSRF cookie sent
INFO - 2018-09-06 17:51:03 --> Input Class Initialized
INFO - 2018-09-06 17:51:03 --> Language Class Initialized
INFO - 2018-09-06 17:51:04 --> Loader Class Initialized
INFO - 2018-09-06 17:51:04 --> Helper loaded: url_helper
INFO - 2018-09-06 17:51:04 --> Helper loaded: form_helper
INFO - 2018-09-06 17:51:04 --> Helper loaded: language_helper
DEBUG - 2018-09-06 17:51:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 17:51:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 17:51:04 --> User Agent Class Initialized
INFO - 2018-09-06 17:51:04 --> Controller Class Initialized
INFO - 2018-09-06 17:51:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 17:51:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 17:51:04 --> Pixel_Model class loaded
INFO - 2018-09-06 17:51:04 --> Database Driver Class Initialized
INFO - 2018-09-06 17:51:04 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 17:51:04 --> Database Driver Class Initialized
INFO - 2018-09-06 17:51:04 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 17:51:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 17:51:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 17:51:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 17:51:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-06 17:51:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-06 17:51:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-06 17:51:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_value.php
INFO - 2018-09-06 17:51:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 17:51:04 --> Final output sent to browser
DEBUG - 2018-09-06 17:51:04 --> Total execution time: 0.0458
INFO - 2018-09-06 17:51:07 --> Config Class Initialized
INFO - 2018-09-06 17:51:07 --> Hooks Class Initialized
DEBUG - 2018-09-06 17:51:07 --> UTF-8 Support Enabled
INFO - 2018-09-06 17:51:07 --> Utf8 Class Initialized
INFO - 2018-09-06 17:51:07 --> URI Class Initialized
INFO - 2018-09-06 17:51:07 --> Router Class Initialized
INFO - 2018-09-06 17:51:07 --> Output Class Initialized
INFO - 2018-09-06 17:51:07 --> Security Class Initialized
DEBUG - 2018-09-06 17:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 17:51:07 --> CSRF cookie sent
INFO - 2018-09-06 17:51:07 --> CSRF token verified
INFO - 2018-09-06 17:51:07 --> Input Class Initialized
INFO - 2018-09-06 17:51:07 --> Language Class Initialized
INFO - 2018-09-06 17:51:07 --> Loader Class Initialized
INFO - 2018-09-06 17:51:07 --> Helper loaded: url_helper
INFO - 2018-09-06 17:51:07 --> Helper loaded: form_helper
INFO - 2018-09-06 17:51:07 --> Helper loaded: language_helper
DEBUG - 2018-09-06 17:51:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 17:51:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 17:51:07 --> User Agent Class Initialized
INFO - 2018-09-06 17:51:07 --> Controller Class Initialized
INFO - 2018-09-06 17:51:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 17:51:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 17:51:07 --> Pixel_Model class loaded
INFO - 2018-09-06 17:51:07 --> Database Driver Class Initialized
INFO - 2018-09-06 17:51:07 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 17:51:07 --> Form Validation Class Initialized
INFO - 2018-09-06 17:51:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-06 17:51:07 --> Database Driver Class Initialized
INFO - 2018-09-06 17:51:07 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 17:51:07 --> Config Class Initialized
INFO - 2018-09-06 17:51:07 --> Hooks Class Initialized
DEBUG - 2018-09-06 17:51:07 --> UTF-8 Support Enabled
INFO - 2018-09-06 17:51:07 --> Utf8 Class Initialized
INFO - 2018-09-06 17:51:07 --> URI Class Initialized
INFO - 2018-09-06 17:51:07 --> Router Class Initialized
INFO - 2018-09-06 17:51:07 --> Output Class Initialized
INFO - 2018-09-06 17:51:07 --> Security Class Initialized
DEBUG - 2018-09-06 17:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 17:51:07 --> CSRF cookie sent
INFO - 2018-09-06 17:51:07 --> Input Class Initialized
INFO - 2018-09-06 17:51:07 --> Language Class Initialized
INFO - 2018-09-06 17:51:08 --> Loader Class Initialized
INFO - 2018-09-06 17:51:08 --> Helper loaded: url_helper
INFO - 2018-09-06 17:51:08 --> Helper loaded: form_helper
INFO - 2018-09-06 17:51:08 --> Helper loaded: language_helper
DEBUG - 2018-09-06 17:51:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 17:51:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 17:51:08 --> User Agent Class Initialized
INFO - 2018-09-06 17:51:08 --> Controller Class Initialized
INFO - 2018-09-06 17:51:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 17:51:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 17:51:08 --> Pixel_Model class loaded
INFO - 2018-09-06 17:51:08 --> Database Driver Class Initialized
INFO - 2018-09-06 17:51:08 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 17:51:08 --> Database Driver Class Initialized
INFO - 2018-09-06 17:51:08 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 17:51:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 17:51:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 17:51:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 17:51:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-06 17:51:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-06 17:51:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-06 17:51:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/merriage_home_title.php
INFO - 2018-09-06 17:51:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 17:51:08 --> Final output sent to browser
DEBUG - 2018-09-06 17:51:08 --> Total execution time: 0.0491
INFO - 2018-09-06 17:51:09 --> Config Class Initialized
INFO - 2018-09-06 17:51:09 --> Hooks Class Initialized
DEBUG - 2018-09-06 17:51:09 --> UTF-8 Support Enabled
INFO - 2018-09-06 17:51:09 --> Utf8 Class Initialized
INFO - 2018-09-06 17:51:09 --> URI Class Initialized
INFO - 2018-09-06 17:51:09 --> Router Class Initialized
INFO - 2018-09-06 17:51:09 --> Output Class Initialized
INFO - 2018-09-06 17:51:09 --> Security Class Initialized
DEBUG - 2018-09-06 17:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 17:51:09 --> CSRF cookie sent
INFO - 2018-09-06 17:51:09 --> CSRF token verified
INFO - 2018-09-06 17:51:09 --> Input Class Initialized
INFO - 2018-09-06 17:51:09 --> Language Class Initialized
INFO - 2018-09-06 17:51:09 --> Loader Class Initialized
INFO - 2018-09-06 17:51:09 --> Helper loaded: url_helper
INFO - 2018-09-06 17:51:09 --> Helper loaded: form_helper
INFO - 2018-09-06 17:51:09 --> Helper loaded: language_helper
DEBUG - 2018-09-06 17:51:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 17:51:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 17:51:09 --> User Agent Class Initialized
INFO - 2018-09-06 17:51:09 --> Controller Class Initialized
INFO - 2018-09-06 17:51:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 17:51:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 17:51:09 --> Pixel_Model class loaded
INFO - 2018-09-06 17:51:09 --> Database Driver Class Initialized
INFO - 2018-09-06 17:51:09 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 17:51:09 --> Form Validation Class Initialized
INFO - 2018-09-06 17:51:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-06 17:51:09 --> Database Driver Class Initialized
INFO - 2018-09-06 17:51:09 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 17:51:09 --> Config Class Initialized
INFO - 2018-09-06 17:51:09 --> Hooks Class Initialized
DEBUG - 2018-09-06 17:51:09 --> UTF-8 Support Enabled
INFO - 2018-09-06 17:51:09 --> Utf8 Class Initialized
INFO - 2018-09-06 17:51:09 --> URI Class Initialized
INFO - 2018-09-06 17:51:09 --> Router Class Initialized
INFO - 2018-09-06 17:51:09 --> Output Class Initialized
INFO - 2018-09-06 17:51:09 --> Security Class Initialized
DEBUG - 2018-09-06 17:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 17:51:09 --> CSRF cookie sent
INFO - 2018-09-06 17:51:09 --> Input Class Initialized
INFO - 2018-09-06 17:51:09 --> Language Class Initialized
INFO - 2018-09-06 17:51:09 --> Loader Class Initialized
INFO - 2018-09-06 17:51:09 --> Helper loaded: url_helper
INFO - 2018-09-06 17:51:09 --> Helper loaded: form_helper
INFO - 2018-09-06 17:51:09 --> Helper loaded: language_helper
DEBUG - 2018-09-06 17:51:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 17:51:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 17:51:09 --> User Agent Class Initialized
INFO - 2018-09-06 17:51:09 --> Controller Class Initialized
INFO - 2018-09-06 17:51:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 17:51:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 17:51:09 --> Pixel_Model class loaded
INFO - 2018-09-06 17:51:09 --> Database Driver Class Initialized
INFO - 2018-09-06 17:51:09 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 17:51:09 --> Database Driver Class Initialized
INFO - 2018-09-06 17:51:09 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 17:51:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 17:51:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 17:51:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 17:51:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-06 17:51:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-06 17:51:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-06 17:51:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-09-06 17:51:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 17:51:09 --> Final output sent to browser
DEBUG - 2018-09-06 17:51:09 --> Total execution time: 0.0457
INFO - 2018-09-06 17:51:10 --> Config Class Initialized
INFO - 2018-09-06 17:51:10 --> Hooks Class Initialized
DEBUG - 2018-09-06 17:51:10 --> UTF-8 Support Enabled
INFO - 2018-09-06 17:51:10 --> Utf8 Class Initialized
INFO - 2018-09-06 17:51:10 --> URI Class Initialized
INFO - 2018-09-06 17:51:10 --> Router Class Initialized
INFO - 2018-09-06 17:51:10 --> Output Class Initialized
INFO - 2018-09-06 17:51:10 --> Security Class Initialized
DEBUG - 2018-09-06 17:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 17:51:10 --> CSRF cookie sent
INFO - 2018-09-06 17:51:10 --> CSRF token verified
INFO - 2018-09-06 17:51:10 --> Input Class Initialized
INFO - 2018-09-06 17:51:10 --> Language Class Initialized
INFO - 2018-09-06 17:51:10 --> Loader Class Initialized
INFO - 2018-09-06 17:51:10 --> Helper loaded: url_helper
INFO - 2018-09-06 17:51:10 --> Helper loaded: form_helper
INFO - 2018-09-06 17:51:10 --> Helper loaded: language_helper
DEBUG - 2018-09-06 17:51:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 17:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 17:51:10 --> User Agent Class Initialized
INFO - 2018-09-06 17:51:10 --> Controller Class Initialized
INFO - 2018-09-06 17:51:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 17:51:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 17:51:10 --> Pixel_Model class loaded
INFO - 2018-09-06 17:51:10 --> Database Driver Class Initialized
INFO - 2018-09-06 17:51:10 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 17:51:10 --> Form Validation Class Initialized
INFO - 2018-09-06 17:51:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-06 17:51:10 --> Database Driver Class Initialized
INFO - 2018-09-06 17:51:10 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 17:51:10 --> Config Class Initialized
INFO - 2018-09-06 17:51:10 --> Hooks Class Initialized
DEBUG - 2018-09-06 17:51:10 --> UTF-8 Support Enabled
INFO - 2018-09-06 17:51:10 --> Utf8 Class Initialized
INFO - 2018-09-06 17:51:10 --> URI Class Initialized
INFO - 2018-09-06 17:51:10 --> Router Class Initialized
INFO - 2018-09-06 17:51:10 --> Output Class Initialized
INFO - 2018-09-06 17:51:10 --> Security Class Initialized
DEBUG - 2018-09-06 17:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 17:51:10 --> CSRF cookie sent
INFO - 2018-09-06 17:51:10 --> Input Class Initialized
INFO - 2018-09-06 17:51:10 --> Language Class Initialized
INFO - 2018-09-06 17:51:10 --> Loader Class Initialized
INFO - 2018-09-06 17:51:10 --> Helper loaded: url_helper
INFO - 2018-09-06 17:51:10 --> Helper loaded: form_helper
INFO - 2018-09-06 17:51:10 --> Helper loaded: language_helper
DEBUG - 2018-09-06 17:51:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 17:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 17:51:10 --> User Agent Class Initialized
INFO - 2018-09-06 17:51:10 --> Controller Class Initialized
INFO - 2018-09-06 17:51:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 17:51:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 17:51:10 --> Pixel_Model class loaded
INFO - 2018-09-06 17:51:10 --> Database Driver Class Initialized
INFO - 2018-09-06 17:51:10 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 17:51:10 --> Config Class Initialized
INFO - 2018-09-06 17:51:10 --> Hooks Class Initialized
DEBUG - 2018-09-06 17:51:10 --> UTF-8 Support Enabled
INFO - 2018-09-06 17:51:10 --> Utf8 Class Initialized
INFO - 2018-09-06 17:51:10 --> URI Class Initialized
INFO - 2018-09-06 17:51:10 --> Router Class Initialized
INFO - 2018-09-06 17:51:10 --> Output Class Initialized
INFO - 2018-09-06 17:51:10 --> Security Class Initialized
DEBUG - 2018-09-06 17:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 17:51:10 --> CSRF cookie sent
INFO - 2018-09-06 17:51:10 --> Input Class Initialized
INFO - 2018-09-06 17:51:10 --> Language Class Initialized
INFO - 2018-09-06 17:51:10 --> Loader Class Initialized
INFO - 2018-09-06 17:51:10 --> Helper loaded: url_helper
INFO - 2018-09-06 17:51:10 --> Helper loaded: form_helper
INFO - 2018-09-06 17:51:10 --> Helper loaded: language_helper
DEBUG - 2018-09-06 17:51:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 17:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 17:51:10 --> User Agent Class Initialized
INFO - 2018-09-06 17:51:10 --> Controller Class Initialized
INFO - 2018-09-06 17:51:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 17:51:10 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-09-06 17:51:10 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-09-06 17:51:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 17:51:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 17:51:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 17:51:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-09-06 17:51:10 --> Could not find the language line "req_email"
INFO - 2018-09-06 17:51:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-09-06 17:51:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 17:51:10 --> Final output sent to browser
DEBUG - 2018-09-06 17:51:10 --> Total execution time: 0.0276
INFO - 2018-09-06 18:22:34 --> Config Class Initialized
INFO - 2018-09-06 18:22:34 --> Hooks Class Initialized
DEBUG - 2018-09-06 18:22:34 --> UTF-8 Support Enabled
INFO - 2018-09-06 18:22:34 --> Utf8 Class Initialized
INFO - 2018-09-06 18:22:34 --> URI Class Initialized
DEBUG - 2018-09-06 18:22:34 --> No URI present. Default controller set.
INFO - 2018-09-06 18:22:34 --> Router Class Initialized
INFO - 2018-09-06 18:22:34 --> Output Class Initialized
INFO - 2018-09-06 18:22:34 --> Security Class Initialized
DEBUG - 2018-09-06 18:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 18:22:34 --> CSRF cookie sent
INFO - 2018-09-06 18:22:34 --> Input Class Initialized
INFO - 2018-09-06 18:22:34 --> Language Class Initialized
INFO - 2018-09-06 18:22:34 --> Loader Class Initialized
INFO - 2018-09-06 18:22:34 --> Helper loaded: url_helper
INFO - 2018-09-06 18:22:34 --> Helper loaded: form_helper
INFO - 2018-09-06 18:22:34 --> Helper loaded: language_helper
DEBUG - 2018-09-06 18:22:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 18:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 18:22:34 --> User Agent Class Initialized
INFO - 2018-09-06 18:22:34 --> Controller Class Initialized
INFO - 2018-09-06 18:22:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 18:22:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 18:22:34 --> Pixel_Model class loaded
INFO - 2018-09-06 18:22:34 --> Database Driver Class Initialized
INFO - 2018-09-06 18:22:34 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 18:22:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 18:22:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 18:22:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-09-06 18:22:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 18:22:34 --> Final output sent to browser
DEBUG - 2018-09-06 18:22:34 --> Total execution time: 0.0459
INFO - 2018-09-06 18:22:36 --> Config Class Initialized
INFO - 2018-09-06 18:22:36 --> Hooks Class Initialized
DEBUG - 2018-09-06 18:22:36 --> UTF-8 Support Enabled
INFO - 2018-09-06 18:22:36 --> Utf8 Class Initialized
INFO - 2018-09-06 18:22:36 --> URI Class Initialized
DEBUG - 2018-09-06 18:22:36 --> No URI present. Default controller set.
INFO - 2018-09-06 18:22:36 --> Router Class Initialized
INFO - 2018-09-06 18:22:36 --> Output Class Initialized
INFO - 2018-09-06 18:22:36 --> Security Class Initialized
DEBUG - 2018-09-06 18:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 18:22:36 --> CSRF cookie sent
INFO - 2018-09-06 18:22:36 --> Input Class Initialized
INFO - 2018-09-06 18:22:36 --> Language Class Initialized
INFO - 2018-09-06 18:22:36 --> Loader Class Initialized
INFO - 2018-09-06 18:22:36 --> Helper loaded: url_helper
INFO - 2018-09-06 18:22:36 --> Helper loaded: form_helper
INFO - 2018-09-06 18:22:36 --> Helper loaded: language_helper
DEBUG - 2018-09-06 18:22:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 18:22:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 18:22:36 --> User Agent Class Initialized
INFO - 2018-09-06 18:22:36 --> Controller Class Initialized
INFO - 2018-09-06 18:22:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 18:22:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 18:22:36 --> Pixel_Model class loaded
INFO - 2018-09-06 18:22:36 --> Database Driver Class Initialized
INFO - 2018-09-06 18:22:36 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 18:22:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 18:22:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 18:22:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-09-06 18:22:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 18:22:36 --> Final output sent to browser
DEBUG - 2018-09-06 18:22:36 --> Total execution time: 0.0381
INFO - 2018-09-06 18:23:20 --> Config Class Initialized
INFO - 2018-09-06 18:23:20 --> Hooks Class Initialized
DEBUG - 2018-09-06 18:23:20 --> UTF-8 Support Enabled
INFO - 2018-09-06 18:23:20 --> Utf8 Class Initialized
INFO - 2018-09-06 18:23:20 --> URI Class Initialized
INFO - 2018-09-06 18:23:20 --> Router Class Initialized
INFO - 2018-09-06 18:23:20 --> Output Class Initialized
INFO - 2018-09-06 18:23:20 --> Security Class Initialized
DEBUG - 2018-09-06 18:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 18:23:20 --> CSRF cookie sent
INFO - 2018-09-06 18:23:20 --> CSRF token verified
INFO - 2018-09-06 18:23:20 --> Input Class Initialized
INFO - 2018-09-06 18:23:20 --> Language Class Initialized
INFO - 2018-09-06 18:23:20 --> Loader Class Initialized
INFO - 2018-09-06 18:23:20 --> Helper loaded: url_helper
INFO - 2018-09-06 18:23:20 --> Helper loaded: form_helper
INFO - 2018-09-06 18:23:20 --> Helper loaded: language_helper
DEBUG - 2018-09-06 18:23:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 18:23:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 18:23:20 --> User Agent Class Initialized
INFO - 2018-09-06 18:23:20 --> Controller Class Initialized
INFO - 2018-09-06 18:23:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 18:23:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 18:23:20 --> Pixel_Model class loaded
INFO - 2018-09-06 18:23:20 --> Database Driver Class Initialized
INFO - 2018-09-06 18:23:20 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 18:23:20 --> Database Driver Class Initialized
INFO - 2018-09-06 18:23:20 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 18:23:20 --> Config Class Initialized
INFO - 2018-09-06 18:23:20 --> Hooks Class Initialized
DEBUG - 2018-09-06 18:23:20 --> UTF-8 Support Enabled
INFO - 2018-09-06 18:23:20 --> Utf8 Class Initialized
INFO - 2018-09-06 18:23:20 --> URI Class Initialized
INFO - 2018-09-06 18:23:20 --> Router Class Initialized
INFO - 2018-09-06 18:23:20 --> Output Class Initialized
INFO - 2018-09-06 18:23:20 --> Security Class Initialized
DEBUG - 2018-09-06 18:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 18:23:20 --> CSRF cookie sent
INFO - 2018-09-06 18:23:20 --> Input Class Initialized
INFO - 2018-09-06 18:23:20 --> Language Class Initialized
INFO - 2018-09-06 18:23:20 --> Loader Class Initialized
INFO - 2018-09-06 18:23:20 --> Helper loaded: url_helper
INFO - 2018-09-06 18:23:20 --> Helper loaded: form_helper
INFO - 2018-09-06 18:23:20 --> Helper loaded: language_helper
DEBUG - 2018-09-06 18:23:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 18:23:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 18:23:20 --> User Agent Class Initialized
INFO - 2018-09-06 18:23:20 --> Controller Class Initialized
INFO - 2018-09-06 18:23:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 18:23:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 18:23:20 --> Pixel_Model class loaded
INFO - 2018-09-06 18:23:20 --> Database Driver Class Initialized
INFO - 2018-09-06 18:23:20 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 18:23:20 --> Database Driver Class Initialized
INFO - 2018-09-06 18:23:20 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 18:23:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 18:23:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 18:23:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 18:23:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-06 18:23:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-06 18:23:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-06 18:23:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-09-06 18:23:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 18:23:20 --> Final output sent to browser
DEBUG - 2018-09-06 18:23:20 --> Total execution time: 0.0467
INFO - 2018-09-06 18:23:22 --> Config Class Initialized
INFO - 2018-09-06 18:23:22 --> Hooks Class Initialized
DEBUG - 2018-09-06 18:23:22 --> UTF-8 Support Enabled
INFO - 2018-09-06 18:23:22 --> Utf8 Class Initialized
INFO - 2018-09-06 18:23:22 --> URI Class Initialized
DEBUG - 2018-09-06 18:23:22 --> No URI present. Default controller set.
INFO - 2018-09-06 18:23:22 --> Router Class Initialized
INFO - 2018-09-06 18:23:22 --> Output Class Initialized
INFO - 2018-09-06 18:23:22 --> Security Class Initialized
DEBUG - 2018-09-06 18:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 18:23:22 --> CSRF cookie sent
INFO - 2018-09-06 18:23:22 --> Input Class Initialized
INFO - 2018-09-06 18:23:22 --> Language Class Initialized
INFO - 2018-09-06 18:23:22 --> Loader Class Initialized
INFO - 2018-09-06 18:23:22 --> Helper loaded: url_helper
INFO - 2018-09-06 18:23:22 --> Helper loaded: form_helper
INFO - 2018-09-06 18:23:22 --> Helper loaded: language_helper
DEBUG - 2018-09-06 18:23:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 18:23:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 18:23:22 --> User Agent Class Initialized
INFO - 2018-09-06 18:23:22 --> Controller Class Initialized
INFO - 2018-09-06 18:23:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 18:23:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 18:23:22 --> Pixel_Model class loaded
INFO - 2018-09-06 18:23:22 --> Database Driver Class Initialized
INFO - 2018-09-06 18:23:22 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 18:23:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 18:23:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 18:23:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-09-06 18:23:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 18:23:22 --> Final output sent to browser
DEBUG - 2018-09-06 18:23:22 --> Total execution time: 0.0347
INFO - 2018-09-06 18:23:31 --> Config Class Initialized
INFO - 2018-09-06 18:23:31 --> Hooks Class Initialized
DEBUG - 2018-09-06 18:23:31 --> UTF-8 Support Enabled
INFO - 2018-09-06 18:23:31 --> Utf8 Class Initialized
INFO - 2018-09-06 18:23:31 --> URI Class Initialized
INFO - 2018-09-06 18:23:31 --> Router Class Initialized
INFO - 2018-09-06 18:23:31 --> Output Class Initialized
INFO - 2018-09-06 18:23:31 --> Security Class Initialized
DEBUG - 2018-09-06 18:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 18:23:31 --> CSRF cookie sent
INFO - 2018-09-06 18:23:31 --> CSRF token verified
INFO - 2018-09-06 18:23:31 --> Input Class Initialized
INFO - 2018-09-06 18:23:31 --> Language Class Initialized
INFO - 2018-09-06 18:23:31 --> Loader Class Initialized
INFO - 2018-09-06 18:23:31 --> Helper loaded: url_helper
INFO - 2018-09-06 18:23:31 --> Helper loaded: form_helper
INFO - 2018-09-06 18:23:31 --> Helper loaded: language_helper
DEBUG - 2018-09-06 18:23:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 18:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 18:23:31 --> User Agent Class Initialized
INFO - 2018-09-06 18:23:31 --> Controller Class Initialized
INFO - 2018-09-06 18:23:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 18:23:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 18:23:31 --> Pixel_Model class loaded
INFO - 2018-09-06 18:23:31 --> Database Driver Class Initialized
INFO - 2018-09-06 18:23:31 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 18:23:31 --> Database Driver Class Initialized
INFO - 2018-09-06 18:23:31 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 18:23:32 --> Config Class Initialized
INFO - 2018-09-06 18:23:32 --> Hooks Class Initialized
DEBUG - 2018-09-06 18:23:32 --> UTF-8 Support Enabled
INFO - 2018-09-06 18:23:32 --> Utf8 Class Initialized
INFO - 2018-09-06 18:23:32 --> URI Class Initialized
INFO - 2018-09-06 18:23:32 --> Router Class Initialized
INFO - 2018-09-06 18:23:32 --> Output Class Initialized
INFO - 2018-09-06 18:23:32 --> Security Class Initialized
DEBUG - 2018-09-06 18:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 18:23:32 --> CSRF cookie sent
INFO - 2018-09-06 18:23:32 --> Input Class Initialized
INFO - 2018-09-06 18:23:32 --> Language Class Initialized
INFO - 2018-09-06 18:23:32 --> Loader Class Initialized
INFO - 2018-09-06 18:23:32 --> Helper loaded: url_helper
INFO - 2018-09-06 18:23:32 --> Helper loaded: form_helper
INFO - 2018-09-06 18:23:32 --> Helper loaded: language_helper
DEBUG - 2018-09-06 18:23:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 18:23:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 18:23:32 --> User Agent Class Initialized
INFO - 2018-09-06 18:23:32 --> Controller Class Initialized
INFO - 2018-09-06 18:23:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 18:23:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 18:23:32 --> Pixel_Model class loaded
INFO - 2018-09-06 18:23:32 --> Database Driver Class Initialized
INFO - 2018-09-06 18:23:32 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 18:23:32 --> Database Driver Class Initialized
INFO - 2018-09-06 18:23:32 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 18:23:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 18:23:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 18:23:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 18:23:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-06 18:23:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-06 18:23:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-06 18:23:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-09-06 18:23:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 18:23:32 --> Final output sent to browser
DEBUG - 2018-09-06 18:23:32 --> Total execution time: 0.0470
INFO - 2018-09-06 18:23:36 --> Config Class Initialized
INFO - 2018-09-06 18:23:36 --> Hooks Class Initialized
DEBUG - 2018-09-06 18:23:36 --> UTF-8 Support Enabled
INFO - 2018-09-06 18:23:36 --> Utf8 Class Initialized
INFO - 2018-09-06 18:23:36 --> URI Class Initialized
INFO - 2018-09-06 18:23:36 --> Router Class Initialized
INFO - 2018-09-06 18:23:36 --> Output Class Initialized
INFO - 2018-09-06 18:23:36 --> Security Class Initialized
DEBUG - 2018-09-06 18:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 18:23:36 --> CSRF cookie sent
INFO - 2018-09-06 18:23:36 --> CSRF token verified
INFO - 2018-09-06 18:23:36 --> Input Class Initialized
INFO - 2018-09-06 18:23:36 --> Language Class Initialized
INFO - 2018-09-06 18:23:36 --> Loader Class Initialized
INFO - 2018-09-06 18:23:36 --> Helper loaded: url_helper
INFO - 2018-09-06 18:23:36 --> Helper loaded: form_helper
INFO - 2018-09-06 18:23:36 --> Helper loaded: language_helper
DEBUG - 2018-09-06 18:23:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 18:23:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 18:23:36 --> User Agent Class Initialized
INFO - 2018-09-06 18:23:36 --> Controller Class Initialized
INFO - 2018-09-06 18:23:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 18:23:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 18:23:36 --> Pixel_Model class loaded
INFO - 2018-09-06 18:23:36 --> Database Driver Class Initialized
INFO - 2018-09-06 18:23:36 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 18:23:36 --> Form Validation Class Initialized
INFO - 2018-09-06 18:23:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-06 18:23:36 --> Database Driver Class Initialized
INFO - 2018-09-06 18:23:36 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 18:23:36 --> Config Class Initialized
INFO - 2018-09-06 18:23:36 --> Hooks Class Initialized
DEBUG - 2018-09-06 18:23:36 --> UTF-8 Support Enabled
INFO - 2018-09-06 18:23:36 --> Utf8 Class Initialized
INFO - 2018-09-06 18:23:36 --> URI Class Initialized
INFO - 2018-09-06 18:23:36 --> Router Class Initialized
INFO - 2018-09-06 18:23:36 --> Output Class Initialized
INFO - 2018-09-06 18:23:36 --> Security Class Initialized
DEBUG - 2018-09-06 18:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 18:23:36 --> CSRF cookie sent
INFO - 2018-09-06 18:23:36 --> Input Class Initialized
INFO - 2018-09-06 18:23:36 --> Language Class Initialized
INFO - 2018-09-06 18:23:36 --> Loader Class Initialized
INFO - 2018-09-06 18:23:36 --> Helper loaded: url_helper
INFO - 2018-09-06 18:23:36 --> Helper loaded: form_helper
INFO - 2018-09-06 18:23:36 --> Helper loaded: language_helper
DEBUG - 2018-09-06 18:23:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 18:23:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 18:23:36 --> User Agent Class Initialized
INFO - 2018-09-06 18:23:36 --> Controller Class Initialized
INFO - 2018-09-06 18:23:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 18:23:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 18:23:36 --> Pixel_Model class loaded
INFO - 2018-09-06 18:23:36 --> Database Driver Class Initialized
INFO - 2018-09-06 18:23:36 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 18:23:36 --> Database Driver Class Initialized
INFO - 2018-09-06 18:23:36 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 18:23:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 18:23:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 18:23:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 18:23:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-06 18:23:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-06 18:23:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-06 18:23:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-09-06 18:23:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 18:23:36 --> Final output sent to browser
DEBUG - 2018-09-06 18:23:36 --> Total execution time: 0.0398
INFO - 2018-09-06 18:23:39 --> Config Class Initialized
INFO - 2018-09-06 18:23:39 --> Hooks Class Initialized
DEBUG - 2018-09-06 18:23:39 --> UTF-8 Support Enabled
INFO - 2018-09-06 18:23:39 --> Utf8 Class Initialized
INFO - 2018-09-06 18:23:39 --> URI Class Initialized
INFO - 2018-09-06 18:23:39 --> Router Class Initialized
INFO - 2018-09-06 18:23:39 --> Output Class Initialized
INFO - 2018-09-06 18:23:39 --> Security Class Initialized
DEBUG - 2018-09-06 18:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 18:23:39 --> CSRF cookie sent
INFO - 2018-09-06 18:23:39 --> CSRF token verified
INFO - 2018-09-06 18:23:39 --> Input Class Initialized
INFO - 2018-09-06 18:23:39 --> Language Class Initialized
INFO - 2018-09-06 18:23:39 --> Loader Class Initialized
INFO - 2018-09-06 18:23:39 --> Helper loaded: url_helper
INFO - 2018-09-06 18:23:39 --> Helper loaded: form_helper
INFO - 2018-09-06 18:23:39 --> Helper loaded: language_helper
DEBUG - 2018-09-06 18:23:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 18:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 18:23:39 --> User Agent Class Initialized
INFO - 2018-09-06 18:23:39 --> Controller Class Initialized
INFO - 2018-09-06 18:23:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 18:23:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 18:23:39 --> Pixel_Model class loaded
INFO - 2018-09-06 18:23:39 --> Database Driver Class Initialized
INFO - 2018-09-06 18:23:39 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 18:23:39 --> Form Validation Class Initialized
INFO - 2018-09-06 18:23:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-06 18:23:39 --> Database Driver Class Initialized
INFO - 2018-09-06 18:23:39 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 18:23:39 --> Config Class Initialized
INFO - 2018-09-06 18:23:39 --> Hooks Class Initialized
DEBUG - 2018-09-06 18:23:39 --> UTF-8 Support Enabled
INFO - 2018-09-06 18:23:39 --> Utf8 Class Initialized
INFO - 2018-09-06 18:23:39 --> URI Class Initialized
INFO - 2018-09-06 18:23:39 --> Router Class Initialized
INFO - 2018-09-06 18:23:39 --> Output Class Initialized
INFO - 2018-09-06 18:23:39 --> Security Class Initialized
DEBUG - 2018-09-06 18:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 18:23:39 --> CSRF cookie sent
INFO - 2018-09-06 18:23:39 --> Input Class Initialized
INFO - 2018-09-06 18:23:39 --> Language Class Initialized
INFO - 2018-09-06 18:23:39 --> Loader Class Initialized
INFO - 2018-09-06 18:23:39 --> Helper loaded: url_helper
INFO - 2018-09-06 18:23:39 --> Helper loaded: form_helper
INFO - 2018-09-06 18:23:39 --> Helper loaded: language_helper
DEBUG - 2018-09-06 18:23:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 18:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 18:23:39 --> User Agent Class Initialized
INFO - 2018-09-06 18:23:39 --> Controller Class Initialized
INFO - 2018-09-06 18:23:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 18:23:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 18:23:39 --> Pixel_Model class loaded
INFO - 2018-09-06 18:23:39 --> Database Driver Class Initialized
INFO - 2018-09-06 18:23:39 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 18:23:39 --> Database Driver Class Initialized
INFO - 2018-09-06 18:23:39 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 18:23:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 18:23:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 18:23:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-09-06 18:23:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 18:23:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-06 18:23:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-06 18:23:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-06 18:23:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-09-06 18:23:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 18:23:39 --> Final output sent to browser
DEBUG - 2018-09-06 18:23:39 --> Total execution time: 0.0326
INFO - 2018-09-06 18:23:44 --> Config Class Initialized
INFO - 2018-09-06 18:23:44 --> Hooks Class Initialized
DEBUG - 2018-09-06 18:23:44 --> UTF-8 Support Enabled
INFO - 2018-09-06 18:23:44 --> Utf8 Class Initialized
INFO - 2018-09-06 18:23:44 --> URI Class Initialized
INFO - 2018-09-06 18:23:44 --> Router Class Initialized
INFO - 2018-09-06 18:23:44 --> Output Class Initialized
INFO - 2018-09-06 18:23:44 --> Security Class Initialized
DEBUG - 2018-09-06 18:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 18:23:44 --> CSRF cookie sent
INFO - 2018-09-06 18:23:44 --> CSRF token verified
INFO - 2018-09-06 18:23:44 --> Input Class Initialized
INFO - 2018-09-06 18:23:44 --> Language Class Initialized
INFO - 2018-09-06 18:23:44 --> Loader Class Initialized
INFO - 2018-09-06 18:23:44 --> Helper loaded: url_helper
INFO - 2018-09-06 18:23:44 --> Helper loaded: form_helper
INFO - 2018-09-06 18:23:44 --> Helper loaded: language_helper
DEBUG - 2018-09-06 18:23:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 18:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 18:23:44 --> User Agent Class Initialized
INFO - 2018-09-06 18:23:44 --> Controller Class Initialized
INFO - 2018-09-06 18:23:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 18:23:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 18:23:44 --> Pixel_Model class loaded
INFO - 2018-09-06 18:23:44 --> Database Driver Class Initialized
INFO - 2018-09-06 18:23:44 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 18:23:44 --> Form Validation Class Initialized
INFO - 2018-09-06 18:23:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-06 18:23:44 --> Database Driver Class Initialized
INFO - 2018-09-06 18:23:44 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 18:23:44 --> Config Class Initialized
INFO - 2018-09-06 18:23:44 --> Hooks Class Initialized
DEBUG - 2018-09-06 18:23:44 --> UTF-8 Support Enabled
INFO - 2018-09-06 18:23:44 --> Utf8 Class Initialized
INFO - 2018-09-06 18:23:44 --> URI Class Initialized
INFO - 2018-09-06 18:23:44 --> Router Class Initialized
INFO - 2018-09-06 18:23:44 --> Output Class Initialized
INFO - 2018-09-06 18:23:44 --> Security Class Initialized
DEBUG - 2018-09-06 18:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 18:23:44 --> CSRF cookie sent
INFO - 2018-09-06 18:23:44 --> Input Class Initialized
INFO - 2018-09-06 18:23:44 --> Language Class Initialized
INFO - 2018-09-06 18:23:44 --> Loader Class Initialized
INFO - 2018-09-06 18:23:44 --> Helper loaded: url_helper
INFO - 2018-09-06 18:23:44 --> Helper loaded: form_helper
INFO - 2018-09-06 18:23:44 --> Helper loaded: language_helper
DEBUG - 2018-09-06 18:23:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 18:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 18:23:44 --> User Agent Class Initialized
INFO - 2018-09-06 18:23:44 --> Controller Class Initialized
INFO - 2018-09-06 18:23:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 18:23:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 18:23:44 --> Pixel_Model class loaded
INFO - 2018-09-06 18:23:44 --> Database Driver Class Initialized
INFO - 2018-09-06 18:23:44 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 18:23:44 --> Database Driver Class Initialized
INFO - 2018-09-06 18:23:44 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 18:23:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 18:23:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 18:23:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 18:23:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-06 18:23:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-06 18:23:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-06 18:23:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-09-06 18:23:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 18:23:44 --> Final output sent to browser
DEBUG - 2018-09-06 18:23:44 --> Total execution time: 0.0348
INFO - 2018-09-06 18:23:52 --> Config Class Initialized
INFO - 2018-09-06 18:23:52 --> Hooks Class Initialized
DEBUG - 2018-09-06 18:23:52 --> UTF-8 Support Enabled
INFO - 2018-09-06 18:23:52 --> Utf8 Class Initialized
INFO - 2018-09-06 18:23:52 --> URI Class Initialized
INFO - 2018-09-06 18:23:52 --> Router Class Initialized
INFO - 2018-09-06 18:23:52 --> Output Class Initialized
INFO - 2018-09-06 18:23:52 --> Security Class Initialized
DEBUG - 2018-09-06 18:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 18:23:52 --> CSRF cookie sent
INFO - 2018-09-06 18:23:52 --> CSRF token verified
INFO - 2018-09-06 18:23:52 --> Input Class Initialized
INFO - 2018-09-06 18:23:52 --> Language Class Initialized
INFO - 2018-09-06 18:23:52 --> Loader Class Initialized
INFO - 2018-09-06 18:23:52 --> Helper loaded: url_helper
INFO - 2018-09-06 18:23:52 --> Helper loaded: form_helper
INFO - 2018-09-06 18:23:52 --> Helper loaded: language_helper
DEBUG - 2018-09-06 18:23:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 18:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 18:23:52 --> User Agent Class Initialized
INFO - 2018-09-06 18:23:52 --> Controller Class Initialized
INFO - 2018-09-06 18:23:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 18:23:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 18:23:52 --> Pixel_Model class loaded
INFO - 2018-09-06 18:23:52 --> Database Driver Class Initialized
INFO - 2018-09-06 18:23:52 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 18:23:52 --> Form Validation Class Initialized
INFO - 2018-09-06 18:23:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-06 18:23:52 --> Database Driver Class Initialized
INFO - 2018-09-06 18:23:52 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 18:23:52 --> Config Class Initialized
INFO - 2018-09-06 18:23:52 --> Hooks Class Initialized
DEBUG - 2018-09-06 18:23:52 --> UTF-8 Support Enabled
INFO - 2018-09-06 18:23:52 --> Utf8 Class Initialized
INFO - 2018-09-06 18:23:52 --> URI Class Initialized
INFO - 2018-09-06 18:23:52 --> Router Class Initialized
INFO - 2018-09-06 18:23:52 --> Output Class Initialized
INFO - 2018-09-06 18:23:52 --> Security Class Initialized
DEBUG - 2018-09-06 18:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 18:23:52 --> CSRF cookie sent
INFO - 2018-09-06 18:23:52 --> Input Class Initialized
INFO - 2018-09-06 18:23:52 --> Language Class Initialized
INFO - 2018-09-06 18:23:52 --> Loader Class Initialized
INFO - 2018-09-06 18:23:52 --> Helper loaded: url_helper
INFO - 2018-09-06 18:23:52 --> Helper loaded: form_helper
INFO - 2018-09-06 18:23:52 --> Helper loaded: language_helper
DEBUG - 2018-09-06 18:23:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 18:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 18:23:52 --> User Agent Class Initialized
INFO - 2018-09-06 18:23:52 --> Controller Class Initialized
INFO - 2018-09-06 18:23:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 18:23:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 18:23:52 --> Pixel_Model class loaded
INFO - 2018-09-06 18:23:52 --> Database Driver Class Initialized
INFO - 2018-09-06 18:23:52 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 18:23:52 --> Database Driver Class Initialized
INFO - 2018-09-06 18:23:52 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 18:23:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 18:23:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 18:23:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 18:23:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-06 18:23:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-06 18:23:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-06 18:23:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/marriage.php
INFO - 2018-09-06 18:23:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 18:23:52 --> Final output sent to browser
DEBUG - 2018-09-06 18:23:52 --> Total execution time: 0.0432
INFO - 2018-09-06 18:24:18 --> Config Class Initialized
INFO - 2018-09-06 18:24:18 --> Hooks Class Initialized
DEBUG - 2018-09-06 18:24:18 --> UTF-8 Support Enabled
INFO - 2018-09-06 18:24:18 --> Utf8 Class Initialized
INFO - 2018-09-06 18:24:18 --> URI Class Initialized
INFO - 2018-09-06 18:24:18 --> Router Class Initialized
INFO - 2018-09-06 18:24:18 --> Output Class Initialized
INFO - 2018-09-06 18:24:18 --> Security Class Initialized
DEBUG - 2018-09-06 18:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 18:24:18 --> CSRF cookie sent
INFO - 2018-09-06 18:24:18 --> CSRF token verified
INFO - 2018-09-06 18:24:18 --> Input Class Initialized
INFO - 2018-09-06 18:24:18 --> Language Class Initialized
INFO - 2018-09-06 18:24:18 --> Loader Class Initialized
INFO - 2018-09-06 18:24:18 --> Helper loaded: url_helper
INFO - 2018-09-06 18:24:18 --> Helper loaded: form_helper
INFO - 2018-09-06 18:24:18 --> Helper loaded: language_helper
DEBUG - 2018-09-06 18:24:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 18:24:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 18:24:18 --> User Agent Class Initialized
INFO - 2018-09-06 18:24:18 --> Controller Class Initialized
INFO - 2018-09-06 18:24:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 18:24:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 18:24:18 --> Pixel_Model class loaded
INFO - 2018-09-06 18:24:18 --> Database Driver Class Initialized
INFO - 2018-09-06 18:24:18 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 18:24:18 --> Form Validation Class Initialized
INFO - 2018-09-06 18:24:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-06 18:24:18 --> Database Driver Class Initialized
INFO - 2018-09-06 18:24:18 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 18:24:18 --> Config Class Initialized
INFO - 2018-09-06 18:24:18 --> Hooks Class Initialized
DEBUG - 2018-09-06 18:24:18 --> UTF-8 Support Enabled
INFO - 2018-09-06 18:24:18 --> Utf8 Class Initialized
INFO - 2018-09-06 18:24:18 --> URI Class Initialized
INFO - 2018-09-06 18:24:18 --> Router Class Initialized
INFO - 2018-09-06 18:24:18 --> Output Class Initialized
INFO - 2018-09-06 18:24:18 --> Security Class Initialized
DEBUG - 2018-09-06 18:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 18:24:18 --> CSRF cookie sent
INFO - 2018-09-06 18:24:18 --> Input Class Initialized
INFO - 2018-09-06 18:24:18 --> Language Class Initialized
INFO - 2018-09-06 18:24:18 --> Loader Class Initialized
INFO - 2018-09-06 18:24:18 --> Helper loaded: url_helper
INFO - 2018-09-06 18:24:18 --> Helper loaded: form_helper
INFO - 2018-09-06 18:24:18 --> Helper loaded: language_helper
DEBUG - 2018-09-06 18:24:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 18:24:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 18:24:18 --> User Agent Class Initialized
INFO - 2018-09-06 18:24:18 --> Controller Class Initialized
INFO - 2018-09-06 18:24:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 18:24:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 18:24:18 --> Pixel_Model class loaded
INFO - 2018-09-06 18:24:18 --> Database Driver Class Initialized
INFO - 2018-09-06 18:24:18 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 18:24:18 --> Database Driver Class Initialized
INFO - 2018-09-06 18:24:18 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 18:24:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 18:24:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 18:24:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 18:24:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-06 18:24:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-06 18:24:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-06 18:24:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-09-06 18:24:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 18:24:18 --> Final output sent to browser
DEBUG - 2018-09-06 18:24:18 --> Total execution time: 0.0455
INFO - 2018-09-06 18:24:29 --> Config Class Initialized
INFO - 2018-09-06 18:24:29 --> Hooks Class Initialized
DEBUG - 2018-09-06 18:24:29 --> UTF-8 Support Enabled
INFO - 2018-09-06 18:24:29 --> Utf8 Class Initialized
INFO - 2018-09-06 18:24:29 --> URI Class Initialized
INFO - 2018-09-06 18:24:29 --> Router Class Initialized
INFO - 2018-09-06 18:24:29 --> Output Class Initialized
INFO - 2018-09-06 18:24:29 --> Security Class Initialized
DEBUG - 2018-09-06 18:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 18:24:29 --> CSRF cookie sent
INFO - 2018-09-06 18:24:29 --> CSRF token verified
INFO - 2018-09-06 18:24:29 --> Input Class Initialized
INFO - 2018-09-06 18:24:29 --> Language Class Initialized
INFO - 2018-09-06 18:24:29 --> Loader Class Initialized
INFO - 2018-09-06 18:24:29 --> Helper loaded: url_helper
INFO - 2018-09-06 18:24:29 --> Helper loaded: form_helper
INFO - 2018-09-06 18:24:29 --> Helper loaded: language_helper
DEBUG - 2018-09-06 18:24:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 18:24:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 18:24:29 --> User Agent Class Initialized
INFO - 2018-09-06 18:24:29 --> Controller Class Initialized
INFO - 2018-09-06 18:24:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 18:24:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 18:24:29 --> Pixel_Model class loaded
INFO - 2018-09-06 18:24:29 --> Database Driver Class Initialized
INFO - 2018-09-06 18:24:29 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 18:24:29 --> Form Validation Class Initialized
INFO - 2018-09-06 18:24:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-06 18:24:29 --> Database Driver Class Initialized
INFO - 2018-09-06 18:24:29 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 18:24:29 --> Config Class Initialized
INFO - 2018-09-06 18:24:29 --> Hooks Class Initialized
DEBUG - 2018-09-06 18:24:29 --> UTF-8 Support Enabled
INFO - 2018-09-06 18:24:29 --> Utf8 Class Initialized
INFO - 2018-09-06 18:24:29 --> URI Class Initialized
INFO - 2018-09-06 18:24:29 --> Router Class Initialized
INFO - 2018-09-06 18:24:29 --> Output Class Initialized
INFO - 2018-09-06 18:24:29 --> Security Class Initialized
DEBUG - 2018-09-06 18:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 18:24:29 --> CSRF cookie sent
INFO - 2018-09-06 18:24:29 --> Input Class Initialized
INFO - 2018-09-06 18:24:29 --> Language Class Initialized
INFO - 2018-09-06 18:24:29 --> Loader Class Initialized
INFO - 2018-09-06 18:24:29 --> Helper loaded: url_helper
INFO - 2018-09-06 18:24:29 --> Helper loaded: form_helper
INFO - 2018-09-06 18:24:29 --> Helper loaded: language_helper
DEBUG - 2018-09-06 18:24:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 18:24:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 18:24:29 --> User Agent Class Initialized
INFO - 2018-09-06 18:24:29 --> Controller Class Initialized
INFO - 2018-09-06 18:24:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 18:24:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 18:24:29 --> Pixel_Model class loaded
INFO - 2018-09-06 18:24:29 --> Database Driver Class Initialized
INFO - 2018-09-06 18:24:29 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 18:24:29 --> Database Driver Class Initialized
INFO - 2018-09-06 18:24:29 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 18:24:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 18:24:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 18:24:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 18:24:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-06 18:24:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-06 18:24:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-06 18:24:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-09-06 18:24:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 18:24:29 --> Final output sent to browser
DEBUG - 2018-09-06 18:24:29 --> Total execution time: 0.0460
INFO - 2018-09-06 18:24:54 --> Config Class Initialized
INFO - 2018-09-06 18:24:54 --> Hooks Class Initialized
DEBUG - 2018-09-06 18:24:54 --> UTF-8 Support Enabled
INFO - 2018-09-06 18:24:54 --> Utf8 Class Initialized
INFO - 2018-09-06 18:24:54 --> URI Class Initialized
INFO - 2018-09-06 18:24:54 --> Router Class Initialized
INFO - 2018-09-06 18:24:54 --> Output Class Initialized
INFO - 2018-09-06 18:24:54 --> Security Class Initialized
DEBUG - 2018-09-06 18:24:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 18:24:54 --> CSRF cookie sent
INFO - 2018-09-06 18:24:54 --> CSRF token verified
INFO - 2018-09-06 18:24:54 --> Input Class Initialized
INFO - 2018-09-06 18:24:54 --> Language Class Initialized
INFO - 2018-09-06 18:24:54 --> Loader Class Initialized
INFO - 2018-09-06 18:24:54 --> Helper loaded: url_helper
INFO - 2018-09-06 18:24:54 --> Helper loaded: form_helper
INFO - 2018-09-06 18:24:54 --> Helper loaded: language_helper
DEBUG - 2018-09-06 18:24:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 18:24:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 18:24:54 --> User Agent Class Initialized
INFO - 2018-09-06 18:24:54 --> Controller Class Initialized
INFO - 2018-09-06 18:24:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 18:24:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 18:24:54 --> Pixel_Model class loaded
INFO - 2018-09-06 18:24:54 --> Database Driver Class Initialized
INFO - 2018-09-06 18:24:54 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 18:24:54 --> Form Validation Class Initialized
INFO - 2018-09-06 18:24:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-06 18:24:54 --> Database Driver Class Initialized
INFO - 2018-09-06 18:24:54 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 18:24:54 --> Config Class Initialized
INFO - 2018-09-06 18:24:54 --> Hooks Class Initialized
DEBUG - 2018-09-06 18:24:54 --> UTF-8 Support Enabled
INFO - 2018-09-06 18:24:54 --> Utf8 Class Initialized
INFO - 2018-09-06 18:24:54 --> URI Class Initialized
INFO - 2018-09-06 18:24:54 --> Router Class Initialized
INFO - 2018-09-06 18:24:54 --> Output Class Initialized
INFO - 2018-09-06 18:24:54 --> Security Class Initialized
DEBUG - 2018-09-06 18:24:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 18:24:54 --> CSRF cookie sent
INFO - 2018-09-06 18:24:54 --> Input Class Initialized
INFO - 2018-09-06 18:24:54 --> Language Class Initialized
INFO - 2018-09-06 18:24:54 --> Loader Class Initialized
INFO - 2018-09-06 18:24:54 --> Helper loaded: url_helper
INFO - 2018-09-06 18:24:54 --> Helper loaded: form_helper
INFO - 2018-09-06 18:24:54 --> Helper loaded: language_helper
DEBUG - 2018-09-06 18:24:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 18:24:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 18:24:54 --> User Agent Class Initialized
INFO - 2018-09-06 18:24:54 --> Controller Class Initialized
INFO - 2018-09-06 18:24:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 18:24:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 18:24:54 --> Pixel_Model class loaded
INFO - 2018-09-06 18:24:54 --> Database Driver Class Initialized
INFO - 2018-09-06 18:24:54 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 18:24:54 --> Database Driver Class Initialized
INFO - 2018-09-06 18:24:54 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 18:24:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 18:24:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 18:24:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 18:24:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-06 18:24:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-06 18:24:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-06 18:24:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-09-06 18:24:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 18:24:54 --> Final output sent to browser
DEBUG - 2018-09-06 18:24:54 --> Total execution time: 0.0460
INFO - 2018-09-06 18:25:04 --> Config Class Initialized
INFO - 2018-09-06 18:25:04 --> Hooks Class Initialized
DEBUG - 2018-09-06 18:25:04 --> UTF-8 Support Enabled
INFO - 2018-09-06 18:25:04 --> Utf8 Class Initialized
INFO - 2018-09-06 18:25:04 --> URI Class Initialized
INFO - 2018-09-06 18:25:04 --> Router Class Initialized
INFO - 2018-09-06 18:25:04 --> Output Class Initialized
INFO - 2018-09-06 18:25:04 --> Security Class Initialized
DEBUG - 2018-09-06 18:25:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 18:25:04 --> CSRF cookie sent
INFO - 2018-09-06 18:25:04 --> CSRF token verified
INFO - 2018-09-06 18:25:04 --> Input Class Initialized
INFO - 2018-09-06 18:25:04 --> Language Class Initialized
INFO - 2018-09-06 18:25:04 --> Loader Class Initialized
INFO - 2018-09-06 18:25:04 --> Helper loaded: url_helper
INFO - 2018-09-06 18:25:04 --> Helper loaded: form_helper
INFO - 2018-09-06 18:25:04 --> Helper loaded: language_helper
DEBUG - 2018-09-06 18:25:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 18:25:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 18:25:04 --> User Agent Class Initialized
INFO - 2018-09-06 18:25:04 --> Controller Class Initialized
INFO - 2018-09-06 18:25:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 18:25:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 18:25:04 --> Pixel_Model class loaded
INFO - 2018-09-06 18:25:04 --> Database Driver Class Initialized
INFO - 2018-09-06 18:25:04 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 18:25:04 --> Form Validation Class Initialized
INFO - 2018-09-06 18:25:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-06 18:25:04 --> Database Driver Class Initialized
INFO - 2018-09-06 18:25:04 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 18:25:04 --> Config Class Initialized
INFO - 2018-09-06 18:25:04 --> Hooks Class Initialized
DEBUG - 2018-09-06 18:25:04 --> UTF-8 Support Enabled
INFO - 2018-09-06 18:25:04 --> Utf8 Class Initialized
INFO - 2018-09-06 18:25:04 --> URI Class Initialized
INFO - 2018-09-06 18:25:04 --> Router Class Initialized
INFO - 2018-09-06 18:25:04 --> Output Class Initialized
INFO - 2018-09-06 18:25:04 --> Security Class Initialized
DEBUG - 2018-09-06 18:25:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 18:25:04 --> CSRF cookie sent
INFO - 2018-09-06 18:25:04 --> Input Class Initialized
INFO - 2018-09-06 18:25:04 --> Language Class Initialized
INFO - 2018-09-06 18:25:04 --> Loader Class Initialized
INFO - 2018-09-06 18:25:04 --> Helper loaded: url_helper
INFO - 2018-09-06 18:25:04 --> Helper loaded: form_helper
INFO - 2018-09-06 18:25:04 --> Helper loaded: language_helper
DEBUG - 2018-09-06 18:25:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 18:25:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 18:25:04 --> User Agent Class Initialized
INFO - 2018-09-06 18:25:04 --> Controller Class Initialized
INFO - 2018-09-06 18:25:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 18:25:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 18:25:04 --> Pixel_Model class loaded
INFO - 2018-09-06 18:25:04 --> Database Driver Class Initialized
INFO - 2018-09-06 18:25:04 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 18:25:04 --> Database Driver Class Initialized
INFO - 2018-09-06 18:25:04 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 18:25:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 18:25:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 18:25:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 18:25:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-06 18:25:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-06 18:25:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-06 18:25:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_owner.php
INFO - 2018-09-06 18:25:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 18:25:04 --> Final output sent to browser
DEBUG - 2018-09-06 18:25:04 --> Total execution time: 0.0491
INFO - 2018-09-06 18:25:07 --> Config Class Initialized
INFO - 2018-09-06 18:25:07 --> Hooks Class Initialized
DEBUG - 2018-09-06 18:25:07 --> UTF-8 Support Enabled
INFO - 2018-09-06 18:25:07 --> Utf8 Class Initialized
INFO - 2018-09-06 18:25:07 --> URI Class Initialized
INFO - 2018-09-06 18:25:07 --> Router Class Initialized
INFO - 2018-09-06 18:25:07 --> Output Class Initialized
INFO - 2018-09-06 18:25:07 --> Security Class Initialized
DEBUG - 2018-09-06 18:25:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 18:25:07 --> CSRF cookie sent
INFO - 2018-09-06 18:25:07 --> CSRF token verified
INFO - 2018-09-06 18:25:07 --> Input Class Initialized
INFO - 2018-09-06 18:25:07 --> Language Class Initialized
INFO - 2018-09-06 18:25:07 --> Loader Class Initialized
INFO - 2018-09-06 18:25:07 --> Helper loaded: url_helper
INFO - 2018-09-06 18:25:07 --> Helper loaded: form_helper
INFO - 2018-09-06 18:25:07 --> Helper loaded: language_helper
DEBUG - 2018-09-06 18:25:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 18:25:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 18:25:07 --> User Agent Class Initialized
INFO - 2018-09-06 18:25:07 --> Controller Class Initialized
INFO - 2018-09-06 18:25:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 18:25:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 18:25:07 --> Pixel_Model class loaded
INFO - 2018-09-06 18:25:07 --> Database Driver Class Initialized
INFO - 2018-09-06 18:25:07 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 18:25:07 --> Form Validation Class Initialized
INFO - 2018-09-06 18:25:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-06 18:25:07 --> Database Driver Class Initialized
INFO - 2018-09-06 18:25:07 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 18:25:07 --> Config Class Initialized
INFO - 2018-09-06 18:25:07 --> Hooks Class Initialized
DEBUG - 2018-09-06 18:25:07 --> UTF-8 Support Enabled
INFO - 2018-09-06 18:25:07 --> Utf8 Class Initialized
INFO - 2018-09-06 18:25:07 --> URI Class Initialized
INFO - 2018-09-06 18:25:07 --> Router Class Initialized
INFO - 2018-09-06 18:25:07 --> Output Class Initialized
INFO - 2018-09-06 18:25:07 --> Security Class Initialized
DEBUG - 2018-09-06 18:25:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 18:25:07 --> CSRF cookie sent
INFO - 2018-09-06 18:25:07 --> Input Class Initialized
INFO - 2018-09-06 18:25:07 --> Language Class Initialized
INFO - 2018-09-06 18:25:07 --> Loader Class Initialized
INFO - 2018-09-06 18:25:07 --> Helper loaded: url_helper
INFO - 2018-09-06 18:25:07 --> Helper loaded: form_helper
INFO - 2018-09-06 18:25:07 --> Helper loaded: language_helper
DEBUG - 2018-09-06 18:25:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 18:25:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 18:25:07 --> User Agent Class Initialized
INFO - 2018-09-06 18:25:07 --> Controller Class Initialized
INFO - 2018-09-06 18:25:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 18:25:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 18:25:07 --> Pixel_Model class loaded
INFO - 2018-09-06 18:25:07 --> Database Driver Class Initialized
INFO - 2018-09-06 18:25:07 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 18:25:07 --> Database Driver Class Initialized
INFO - 2018-09-06 18:25:07 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 18:25:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 18:25:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 18:25:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 18:25:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-06 18:25:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-06 18:25:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-06 18:25:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_value.php
INFO - 2018-09-06 18:25:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 18:25:07 --> Final output sent to browser
DEBUG - 2018-09-06 18:25:07 --> Total execution time: 0.0390
INFO - 2018-09-06 18:25:20 --> Config Class Initialized
INFO - 2018-09-06 18:25:20 --> Hooks Class Initialized
DEBUG - 2018-09-06 18:25:20 --> UTF-8 Support Enabled
INFO - 2018-09-06 18:25:20 --> Utf8 Class Initialized
INFO - 2018-09-06 18:25:20 --> URI Class Initialized
INFO - 2018-09-06 18:25:20 --> Router Class Initialized
INFO - 2018-09-06 18:25:20 --> Output Class Initialized
INFO - 2018-09-06 18:25:20 --> Security Class Initialized
DEBUG - 2018-09-06 18:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 18:25:20 --> CSRF cookie sent
INFO - 2018-09-06 18:25:20 --> CSRF token verified
INFO - 2018-09-06 18:25:20 --> Input Class Initialized
INFO - 2018-09-06 18:25:20 --> Language Class Initialized
INFO - 2018-09-06 18:25:20 --> Loader Class Initialized
INFO - 2018-09-06 18:25:20 --> Helper loaded: url_helper
INFO - 2018-09-06 18:25:20 --> Helper loaded: form_helper
INFO - 2018-09-06 18:25:20 --> Helper loaded: language_helper
DEBUG - 2018-09-06 18:25:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 18:25:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 18:25:20 --> User Agent Class Initialized
INFO - 2018-09-06 18:25:20 --> Controller Class Initialized
INFO - 2018-09-06 18:25:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 18:25:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 18:25:20 --> Pixel_Model class loaded
INFO - 2018-09-06 18:25:20 --> Database Driver Class Initialized
INFO - 2018-09-06 18:25:20 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 18:25:20 --> Form Validation Class Initialized
INFO - 2018-09-06 18:25:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-06 18:25:20 --> Database Driver Class Initialized
INFO - 2018-09-06 18:25:20 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 18:25:20 --> Config Class Initialized
INFO - 2018-09-06 18:25:20 --> Hooks Class Initialized
DEBUG - 2018-09-06 18:25:20 --> UTF-8 Support Enabled
INFO - 2018-09-06 18:25:20 --> Utf8 Class Initialized
INFO - 2018-09-06 18:25:20 --> URI Class Initialized
INFO - 2018-09-06 18:25:20 --> Router Class Initialized
INFO - 2018-09-06 18:25:20 --> Output Class Initialized
INFO - 2018-09-06 18:25:20 --> Security Class Initialized
DEBUG - 2018-09-06 18:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 18:25:20 --> CSRF cookie sent
INFO - 2018-09-06 18:25:20 --> Input Class Initialized
INFO - 2018-09-06 18:25:20 --> Language Class Initialized
INFO - 2018-09-06 18:25:20 --> Loader Class Initialized
INFO - 2018-09-06 18:25:20 --> Helper loaded: url_helper
INFO - 2018-09-06 18:25:20 --> Helper loaded: form_helper
INFO - 2018-09-06 18:25:20 --> Helper loaded: language_helper
DEBUG - 2018-09-06 18:25:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 18:25:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 18:25:20 --> User Agent Class Initialized
INFO - 2018-09-06 18:25:20 --> Controller Class Initialized
INFO - 2018-09-06 18:25:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 18:25:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 18:25:20 --> Pixel_Model class loaded
INFO - 2018-09-06 18:25:20 --> Database Driver Class Initialized
INFO - 2018-09-06 18:25:20 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 18:25:20 --> Database Driver Class Initialized
INFO - 2018-09-06 18:25:20 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 18:25:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 18:25:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 18:25:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 18:25:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-06 18:25:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-06 18:25:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-06 18:25:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/merriage_home_title.php
INFO - 2018-09-06 18:25:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 18:25:20 --> Final output sent to browser
DEBUG - 2018-09-06 18:25:20 --> Total execution time: 0.0484
INFO - 2018-09-06 18:25:40 --> Config Class Initialized
INFO - 2018-09-06 18:25:40 --> Hooks Class Initialized
DEBUG - 2018-09-06 18:25:40 --> UTF-8 Support Enabled
INFO - 2018-09-06 18:25:40 --> Utf8 Class Initialized
INFO - 2018-09-06 18:25:40 --> URI Class Initialized
INFO - 2018-09-06 18:25:40 --> Router Class Initialized
INFO - 2018-09-06 18:25:40 --> Output Class Initialized
INFO - 2018-09-06 18:25:40 --> Security Class Initialized
DEBUG - 2018-09-06 18:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 18:25:40 --> CSRF cookie sent
INFO - 2018-09-06 18:25:40 --> CSRF token verified
INFO - 2018-09-06 18:25:40 --> Input Class Initialized
INFO - 2018-09-06 18:25:40 --> Language Class Initialized
INFO - 2018-09-06 18:25:40 --> Loader Class Initialized
INFO - 2018-09-06 18:25:40 --> Helper loaded: url_helper
INFO - 2018-09-06 18:25:40 --> Helper loaded: form_helper
INFO - 2018-09-06 18:25:40 --> Helper loaded: language_helper
DEBUG - 2018-09-06 18:25:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 18:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 18:25:40 --> User Agent Class Initialized
INFO - 2018-09-06 18:25:40 --> Controller Class Initialized
INFO - 2018-09-06 18:25:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 18:25:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 18:25:40 --> Pixel_Model class loaded
INFO - 2018-09-06 18:25:40 --> Database Driver Class Initialized
INFO - 2018-09-06 18:25:40 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 18:25:40 --> Form Validation Class Initialized
INFO - 2018-09-06 18:25:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-06 18:25:40 --> Database Driver Class Initialized
INFO - 2018-09-06 18:25:40 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 18:25:40 --> Config Class Initialized
INFO - 2018-09-06 18:25:40 --> Hooks Class Initialized
DEBUG - 2018-09-06 18:25:40 --> UTF-8 Support Enabled
INFO - 2018-09-06 18:25:40 --> Utf8 Class Initialized
INFO - 2018-09-06 18:25:40 --> URI Class Initialized
INFO - 2018-09-06 18:25:40 --> Router Class Initialized
INFO - 2018-09-06 18:25:40 --> Output Class Initialized
INFO - 2018-09-06 18:25:40 --> Security Class Initialized
DEBUG - 2018-09-06 18:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 18:25:40 --> CSRF cookie sent
INFO - 2018-09-06 18:25:40 --> Input Class Initialized
INFO - 2018-09-06 18:25:40 --> Language Class Initialized
INFO - 2018-09-06 18:25:40 --> Loader Class Initialized
INFO - 2018-09-06 18:25:40 --> Helper loaded: url_helper
INFO - 2018-09-06 18:25:40 --> Helper loaded: form_helper
INFO - 2018-09-06 18:25:40 --> Helper loaded: language_helper
DEBUG - 2018-09-06 18:25:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 18:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 18:25:40 --> User Agent Class Initialized
INFO - 2018-09-06 18:25:40 --> Controller Class Initialized
INFO - 2018-09-06 18:25:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 18:25:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 18:25:40 --> Pixel_Model class loaded
INFO - 2018-09-06 18:25:40 --> Database Driver Class Initialized
INFO - 2018-09-06 18:25:40 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 18:25:40 --> Database Driver Class Initialized
INFO - 2018-09-06 18:25:40 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 18:25:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 18:25:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 18:25:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 18:25:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-06 18:25:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-06 18:25:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-06 18:25:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-09-06 18:25:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 18:25:40 --> Final output sent to browser
DEBUG - 2018-09-06 18:25:40 --> Total execution time: 0.0476
INFO - 2018-09-06 18:25:49 --> Config Class Initialized
INFO - 2018-09-06 18:25:49 --> Hooks Class Initialized
DEBUG - 2018-09-06 18:25:49 --> UTF-8 Support Enabled
INFO - 2018-09-06 18:25:49 --> Utf8 Class Initialized
INFO - 2018-09-06 18:25:49 --> URI Class Initialized
INFO - 2018-09-06 18:25:49 --> Router Class Initialized
INFO - 2018-09-06 18:25:49 --> Output Class Initialized
INFO - 2018-09-06 18:25:49 --> Security Class Initialized
DEBUG - 2018-09-06 18:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 18:25:49 --> CSRF cookie sent
INFO - 2018-09-06 18:25:49 --> CSRF token verified
INFO - 2018-09-06 18:25:49 --> Input Class Initialized
INFO - 2018-09-06 18:25:49 --> Language Class Initialized
INFO - 2018-09-06 18:25:49 --> Loader Class Initialized
INFO - 2018-09-06 18:25:49 --> Helper loaded: url_helper
INFO - 2018-09-06 18:25:49 --> Helper loaded: form_helper
INFO - 2018-09-06 18:25:49 --> Helper loaded: language_helper
DEBUG - 2018-09-06 18:25:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 18:25:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 18:25:49 --> User Agent Class Initialized
INFO - 2018-09-06 18:25:49 --> Controller Class Initialized
INFO - 2018-09-06 18:25:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 18:25:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 18:25:49 --> Pixel_Model class loaded
INFO - 2018-09-06 18:25:49 --> Database Driver Class Initialized
INFO - 2018-09-06 18:25:49 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 18:25:49 --> Form Validation Class Initialized
INFO - 2018-09-06 18:25:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-06 18:25:49 --> Database Driver Class Initialized
INFO - 2018-09-06 18:25:49 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 18:25:49 --> Config Class Initialized
INFO - 2018-09-06 18:25:49 --> Hooks Class Initialized
DEBUG - 2018-09-06 18:25:49 --> UTF-8 Support Enabled
INFO - 2018-09-06 18:25:49 --> Utf8 Class Initialized
INFO - 2018-09-06 18:25:49 --> URI Class Initialized
INFO - 2018-09-06 18:25:49 --> Router Class Initialized
INFO - 2018-09-06 18:25:49 --> Output Class Initialized
INFO - 2018-09-06 18:25:49 --> Security Class Initialized
DEBUG - 2018-09-06 18:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 18:25:49 --> CSRF cookie sent
INFO - 2018-09-06 18:25:49 --> Input Class Initialized
INFO - 2018-09-06 18:25:49 --> Language Class Initialized
INFO - 2018-09-06 18:25:49 --> Loader Class Initialized
INFO - 2018-09-06 18:25:49 --> Helper loaded: url_helper
INFO - 2018-09-06 18:25:49 --> Helper loaded: form_helper
INFO - 2018-09-06 18:25:49 --> Helper loaded: language_helper
DEBUG - 2018-09-06 18:25:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 18:25:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 18:25:49 --> User Agent Class Initialized
INFO - 2018-09-06 18:25:49 --> Controller Class Initialized
INFO - 2018-09-06 18:25:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 18:25:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-06 18:25:49 --> Pixel_Model class loaded
INFO - 2018-09-06 18:25:49 --> Database Driver Class Initialized
INFO - 2018-09-06 18:25:49 --> Model "QuestionsModel" initialized
INFO - 2018-09-06 18:25:50 --> Config Class Initialized
INFO - 2018-09-06 18:25:50 --> Hooks Class Initialized
DEBUG - 2018-09-06 18:25:50 --> UTF-8 Support Enabled
INFO - 2018-09-06 18:25:50 --> Utf8 Class Initialized
INFO - 2018-09-06 18:25:50 --> URI Class Initialized
INFO - 2018-09-06 18:25:50 --> Router Class Initialized
INFO - 2018-09-06 18:25:50 --> Output Class Initialized
INFO - 2018-09-06 18:25:50 --> Security Class Initialized
DEBUG - 2018-09-06 18:25:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-06 18:25:50 --> CSRF cookie sent
INFO - 2018-09-06 18:25:50 --> Input Class Initialized
INFO - 2018-09-06 18:25:50 --> Language Class Initialized
INFO - 2018-09-06 18:25:50 --> Loader Class Initialized
INFO - 2018-09-06 18:25:50 --> Helper loaded: url_helper
INFO - 2018-09-06 18:25:50 --> Helper loaded: form_helper
INFO - 2018-09-06 18:25:50 --> Helper loaded: language_helper
DEBUG - 2018-09-06 18:25:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-06 18:25:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-06 18:25:50 --> User Agent Class Initialized
INFO - 2018-09-06 18:25:50 --> Controller Class Initialized
INFO - 2018-09-06 18:25:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-06 18:25:50 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-09-06 18:25:50 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-09-06 18:25:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-06 18:25:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-06 18:25:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-06 18:25:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-09-06 18:25:50 --> Could not find the language line "req_email"
INFO - 2018-09-06 18:25:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-09-06 18:25:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-06 18:25:50 --> Final output sent to browser
DEBUG - 2018-09-06 18:25:50 --> Total execution time: 0.0304

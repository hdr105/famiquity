<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-09-07 14:26:53 --> Config Class Initialized
INFO - 2018-09-07 14:26:53 --> Hooks Class Initialized
DEBUG - 2018-09-07 14:26:53 --> UTF-8 Support Enabled
INFO - 2018-09-07 14:26:53 --> Utf8 Class Initialized
INFO - 2018-09-07 14:26:53 --> URI Class Initialized
DEBUG - 2018-09-07 14:26:53 --> No URI present. Default controller set.
INFO - 2018-09-07 14:26:53 --> Router Class Initialized
INFO - 2018-09-07 14:26:53 --> Output Class Initialized
INFO - 2018-09-07 14:26:53 --> Security Class Initialized
DEBUG - 2018-09-07 14:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-07 14:26:53 --> CSRF cookie sent
INFO - 2018-09-07 14:26:53 --> Input Class Initialized
INFO - 2018-09-07 14:26:53 --> Language Class Initialized
INFO - 2018-09-07 14:26:53 --> Loader Class Initialized
INFO - 2018-09-07 14:26:53 --> Helper loaded: url_helper
INFO - 2018-09-07 14:26:53 --> Helper loaded: form_helper
INFO - 2018-09-07 14:26:53 --> Helper loaded: language_helper
DEBUG - 2018-09-07 14:26:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-07 14:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-07 14:26:53 --> User Agent Class Initialized
INFO - 2018-09-07 14:26:53 --> Controller Class Initialized
INFO - 2018-09-07 14:26:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-07 14:26:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-07 14:26:53 --> Pixel_Model class loaded
INFO - 2018-09-07 14:26:53 --> Database Driver Class Initialized
INFO - 2018-09-07 14:26:53 --> Model "QuestionsModel" initialized
INFO - 2018-09-07 14:26:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-07 14:26:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-07 14:26:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-09-07 14:26:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-07 14:26:53 --> Final output sent to browser
DEBUG - 2018-09-07 14:26:53 --> Total execution time: 0.0366
INFO - 2018-09-07 14:47:34 --> Config Class Initialized
INFO - 2018-09-07 14:47:34 --> Hooks Class Initialized
DEBUG - 2018-09-07 14:47:34 --> UTF-8 Support Enabled
INFO - 2018-09-07 14:47:34 --> Utf8 Class Initialized
INFO - 2018-09-07 14:47:34 --> URI Class Initialized
DEBUG - 2018-09-07 14:47:34 --> No URI present. Default controller set.
INFO - 2018-09-07 14:47:34 --> Router Class Initialized
INFO - 2018-09-07 14:47:34 --> Output Class Initialized
INFO - 2018-09-07 14:47:34 --> Security Class Initialized
DEBUG - 2018-09-07 14:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-07 14:47:34 --> CSRF cookie sent
INFO - 2018-09-07 14:47:34 --> Input Class Initialized
INFO - 2018-09-07 14:47:34 --> Language Class Initialized
INFO - 2018-09-07 14:47:34 --> Loader Class Initialized
INFO - 2018-09-07 14:47:34 --> Helper loaded: url_helper
INFO - 2018-09-07 14:47:34 --> Helper loaded: form_helper
INFO - 2018-09-07 14:47:34 --> Helper loaded: language_helper
DEBUG - 2018-09-07 14:47:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-07 14:47:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-07 14:47:34 --> User Agent Class Initialized
INFO - 2018-09-07 14:47:34 --> Controller Class Initialized
INFO - 2018-09-07 14:47:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-07 14:47:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-07 14:47:34 --> Pixel_Model class loaded
INFO - 2018-09-07 14:47:34 --> Database Driver Class Initialized
INFO - 2018-09-07 14:47:34 --> Model "QuestionsModel" initialized
INFO - 2018-09-07 14:47:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-07 14:47:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-07 14:47:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-09-07 14:47:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-07 14:47:34 --> Final output sent to browser
DEBUG - 2018-09-07 14:47:34 --> Total execution time: 0.0345
INFO - 2018-09-07 14:47:34 --> Config Class Initialized
INFO - 2018-09-07 14:47:34 --> Hooks Class Initialized
DEBUG - 2018-09-07 14:47:34 --> UTF-8 Support Enabled
INFO - 2018-09-07 14:47:34 --> Utf8 Class Initialized
INFO - 2018-09-07 14:47:34 --> URI Class Initialized
DEBUG - 2018-09-07 14:47:34 --> No URI present. Default controller set.
INFO - 2018-09-07 14:47:34 --> Router Class Initialized
INFO - 2018-09-07 14:47:34 --> Output Class Initialized
INFO - 2018-09-07 14:47:34 --> Security Class Initialized
DEBUG - 2018-09-07 14:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-07 14:47:34 --> CSRF cookie sent
INFO - 2018-09-07 14:47:34 --> Input Class Initialized
INFO - 2018-09-07 14:47:34 --> Language Class Initialized
INFO - 2018-09-07 14:47:34 --> Loader Class Initialized
INFO - 2018-09-07 14:47:34 --> Helper loaded: url_helper
INFO - 2018-09-07 14:47:34 --> Helper loaded: form_helper
INFO - 2018-09-07 14:47:34 --> Helper loaded: language_helper
DEBUG - 2018-09-07 14:47:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-07 14:47:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-07 14:47:34 --> User Agent Class Initialized
INFO - 2018-09-07 14:47:35 --> Controller Class Initialized
INFO - 2018-09-07 14:47:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-07 14:47:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-07 14:47:35 --> Pixel_Model class loaded
INFO - 2018-09-07 14:47:35 --> Database Driver Class Initialized
INFO - 2018-09-07 14:47:35 --> Model "QuestionsModel" initialized
INFO - 2018-09-07 14:47:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-07 14:47:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-07 14:47:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-09-07 14:47:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-07 14:47:35 --> Final output sent to browser
DEBUG - 2018-09-07 14:47:35 --> Total execution time: 0.0417
INFO - 2018-09-07 19:49:14 --> Config Class Initialized
INFO - 2018-09-07 19:49:14 --> Hooks Class Initialized
DEBUG - 2018-09-07 19:49:14 --> UTF-8 Support Enabled
INFO - 2018-09-07 19:49:14 --> Utf8 Class Initialized
INFO - 2018-09-07 19:49:14 --> URI Class Initialized
DEBUG - 2018-09-07 19:49:14 --> No URI present. Default controller set.
INFO - 2018-09-07 19:49:14 --> Router Class Initialized
INFO - 2018-09-07 19:49:14 --> Output Class Initialized
INFO - 2018-09-07 19:49:14 --> Security Class Initialized
DEBUG - 2018-09-07 19:49:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-07 19:49:14 --> CSRF cookie sent
INFO - 2018-09-07 19:49:14 --> Input Class Initialized
INFO - 2018-09-07 19:49:14 --> Language Class Initialized
INFO - 2018-09-07 19:49:14 --> Loader Class Initialized
INFO - 2018-09-07 19:49:14 --> Helper loaded: url_helper
INFO - 2018-09-07 19:49:14 --> Helper loaded: form_helper
INFO - 2018-09-07 19:49:14 --> Helper loaded: language_helper
DEBUG - 2018-09-07 19:49:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-07 19:49:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-07 19:49:14 --> User Agent Class Initialized
INFO - 2018-09-07 19:49:14 --> Controller Class Initialized
INFO - 2018-09-07 19:49:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-07 19:49:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-07 19:49:14 --> Pixel_Model class loaded
INFO - 2018-09-07 19:49:14 --> Database Driver Class Initialized
INFO - 2018-09-07 19:49:14 --> Model "QuestionsModel" initialized
INFO - 2018-09-07 19:49:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-07 19:49:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-07 19:49:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-09-07 19:49:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-07 19:49:14 --> Final output sent to browser
DEBUG - 2018-09-07 19:49:14 --> Total execution time: 0.0359
INFO - 2018-09-07 19:49:18 --> Config Class Initialized
INFO - 2018-09-07 19:49:18 --> Hooks Class Initialized
DEBUG - 2018-09-07 19:49:18 --> UTF-8 Support Enabled
INFO - 2018-09-07 19:49:18 --> Utf8 Class Initialized
INFO - 2018-09-07 19:49:18 --> URI Class Initialized
INFO - 2018-09-07 19:49:18 --> Router Class Initialized
INFO - 2018-09-07 19:49:18 --> Output Class Initialized
INFO - 2018-09-07 19:49:18 --> Security Class Initialized
DEBUG - 2018-09-07 19:49:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-07 19:49:18 --> CSRF cookie sent
INFO - 2018-09-07 19:49:18 --> Input Class Initialized
INFO - 2018-09-07 19:49:18 --> Language Class Initialized
INFO - 2018-09-07 19:49:18 --> Loader Class Initialized
INFO - 2018-09-07 19:49:18 --> Helper loaded: url_helper
INFO - 2018-09-07 19:49:18 --> Helper loaded: form_helper
INFO - 2018-09-07 19:49:18 --> Helper loaded: language_helper
DEBUG - 2018-09-07 19:49:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-07 19:49:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-07 19:49:18 --> User Agent Class Initialized
INFO - 2018-09-07 19:49:18 --> Controller Class Initialized
INFO - 2018-09-07 19:49:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-07 19:49:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-07 19:49:18 --> Pixel_Model class loaded
INFO - 2018-09-07 19:49:18 --> Database Driver Class Initialized
INFO - 2018-09-07 19:49:18 --> Model "QuestionsModel" initialized
INFO - 2018-09-07 19:49:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-07 19:49:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-07 19:49:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-07 19:49:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-07 19:49:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-07 19:49:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-07 19:49:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-09-07 19:49:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-07 19:49:18 --> Final output sent to browser
DEBUG - 2018-09-07 19:49:18 --> Total execution time: 0.0399
INFO - 2018-09-07 19:49:24 --> Config Class Initialized
INFO - 2018-09-07 19:49:24 --> Hooks Class Initialized
DEBUG - 2018-09-07 19:49:24 --> UTF-8 Support Enabled
INFO - 2018-09-07 19:49:24 --> Utf8 Class Initialized
INFO - 2018-09-07 19:49:24 --> URI Class Initialized
DEBUG - 2018-09-07 19:49:24 --> No URI present. Default controller set.
INFO - 2018-09-07 19:49:24 --> Router Class Initialized
INFO - 2018-09-07 19:49:24 --> Output Class Initialized
INFO - 2018-09-07 19:49:24 --> Security Class Initialized
DEBUG - 2018-09-07 19:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-07 19:49:24 --> CSRF cookie sent
INFO - 2018-09-07 19:49:24 --> Input Class Initialized
INFO - 2018-09-07 19:49:24 --> Language Class Initialized
INFO - 2018-09-07 19:49:24 --> Loader Class Initialized
INFO - 2018-09-07 19:49:24 --> Helper loaded: url_helper
INFO - 2018-09-07 19:49:24 --> Helper loaded: form_helper
INFO - 2018-09-07 19:49:24 --> Helper loaded: language_helper
DEBUG - 2018-09-07 19:49:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-07 19:49:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-07 19:49:24 --> User Agent Class Initialized
INFO - 2018-09-07 19:49:24 --> Controller Class Initialized
INFO - 2018-09-07 19:49:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-07 19:49:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-07 19:49:24 --> Pixel_Model class loaded
INFO - 2018-09-07 19:49:24 --> Database Driver Class Initialized
INFO - 2018-09-07 19:49:24 --> Model "QuestionsModel" initialized
INFO - 2018-09-07 19:49:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-07 19:49:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-07 19:49:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-09-07 19:49:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-07 19:49:24 --> Final output sent to browser
DEBUG - 2018-09-07 19:49:24 --> Total execution time: 0.0376

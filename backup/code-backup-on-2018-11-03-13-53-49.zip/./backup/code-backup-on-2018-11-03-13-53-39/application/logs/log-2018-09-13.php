<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-09-13 13:44:56 --> Config Class Initialized
INFO - 2018-09-13 13:44:56 --> Hooks Class Initialized
DEBUG - 2018-09-13 13:44:56 --> UTF-8 Support Enabled
INFO - 2018-09-13 13:44:56 --> Utf8 Class Initialized
INFO - 2018-09-13 13:44:56 --> URI Class Initialized
DEBUG - 2018-09-13 13:44:56 --> No URI present. Default controller set.
INFO - 2018-09-13 13:44:56 --> Router Class Initialized
INFO - 2018-09-13 13:44:56 --> Output Class Initialized
INFO - 2018-09-13 13:44:56 --> Security Class Initialized
DEBUG - 2018-09-13 13:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-13 13:44:56 --> CSRF cookie sent
INFO - 2018-09-13 13:44:56 --> Input Class Initialized
INFO - 2018-09-13 13:44:56 --> Language Class Initialized
INFO - 2018-09-13 13:44:56 --> Loader Class Initialized
INFO - 2018-09-13 13:44:56 --> Helper loaded: url_helper
INFO - 2018-09-13 13:44:56 --> Helper loaded: form_helper
INFO - 2018-09-13 13:44:56 --> Helper loaded: language_helper
DEBUG - 2018-09-13 13:44:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-13 13:44:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-13 13:44:56 --> User Agent Class Initialized
INFO - 2018-09-13 13:44:56 --> Controller Class Initialized
INFO - 2018-09-13 13:44:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-13 13:44:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-13 13:44:56 --> Pixel_Model class loaded
INFO - 2018-09-13 13:44:56 --> Database Driver Class Initialized
INFO - 2018-09-13 13:44:56 --> Model "QuestionsModel" initialized
INFO - 2018-09-13 13:44:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-13 13:44:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-13 13:44:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-09-13 13:44:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-13 13:44:56 --> Final output sent to browser
DEBUG - 2018-09-13 13:44:56 --> Total execution time: 0.0385
INFO - 2018-09-13 13:44:57 --> Config Class Initialized
INFO - 2018-09-13 13:44:57 --> Hooks Class Initialized
DEBUG - 2018-09-13 13:44:57 --> UTF-8 Support Enabled
INFO - 2018-09-13 13:44:57 --> Utf8 Class Initialized
INFO - 2018-09-13 13:44:57 --> URI Class Initialized
DEBUG - 2018-09-13 13:44:57 --> No URI present. Default controller set.
INFO - 2018-09-13 13:44:57 --> Router Class Initialized
INFO - 2018-09-13 13:44:57 --> Output Class Initialized
INFO - 2018-09-13 13:44:57 --> Security Class Initialized
DEBUG - 2018-09-13 13:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-13 13:44:57 --> CSRF cookie sent
INFO - 2018-09-13 13:44:57 --> Input Class Initialized
INFO - 2018-09-13 13:44:57 --> Language Class Initialized
INFO - 2018-09-13 13:44:57 --> Loader Class Initialized
INFO - 2018-09-13 13:44:57 --> Helper loaded: url_helper
INFO - 2018-09-13 13:44:57 --> Helper loaded: form_helper
INFO - 2018-09-13 13:44:57 --> Helper loaded: language_helper
DEBUG - 2018-09-13 13:44:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-13 13:44:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-13 13:44:57 --> User Agent Class Initialized
INFO - 2018-09-13 13:44:57 --> Controller Class Initialized
INFO - 2018-09-13 13:44:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-13 13:44:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-13 13:44:57 --> Pixel_Model class loaded
INFO - 2018-09-13 13:44:57 --> Database Driver Class Initialized
INFO - 2018-09-13 13:44:57 --> Model "QuestionsModel" initialized
INFO - 2018-09-13 13:44:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-13 13:44:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-13 13:44:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-09-13 13:44:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-13 13:44:57 --> Final output sent to browser
DEBUG - 2018-09-13 13:44:57 --> Total execution time: 0.0438
INFO - 2018-09-13 14:31:01 --> Config Class Initialized
INFO - 2018-09-13 14:31:01 --> Hooks Class Initialized
DEBUG - 2018-09-13 14:31:01 --> UTF-8 Support Enabled
INFO - 2018-09-13 14:31:01 --> Utf8 Class Initialized
INFO - 2018-09-13 14:31:01 --> URI Class Initialized
DEBUG - 2018-09-13 14:31:01 --> No URI present. Default controller set.
INFO - 2018-09-13 14:31:01 --> Router Class Initialized
INFO - 2018-09-13 14:31:01 --> Output Class Initialized
INFO - 2018-09-13 14:31:01 --> Security Class Initialized
DEBUG - 2018-09-13 14:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-13 14:31:01 --> CSRF cookie sent
INFO - 2018-09-13 14:31:01 --> Input Class Initialized
INFO - 2018-09-13 14:31:01 --> Language Class Initialized
INFO - 2018-09-13 14:31:01 --> Loader Class Initialized
INFO - 2018-09-13 14:31:01 --> Helper loaded: url_helper
INFO - 2018-09-13 14:31:01 --> Helper loaded: form_helper
INFO - 2018-09-13 14:31:01 --> Helper loaded: language_helper
DEBUG - 2018-09-13 14:31:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-13 14:31:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-13 14:31:01 --> User Agent Class Initialized
INFO - 2018-09-13 14:31:01 --> Controller Class Initialized
INFO - 2018-09-13 14:31:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-13 14:31:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-13 14:31:01 --> Pixel_Model class loaded
INFO - 2018-09-13 14:31:01 --> Database Driver Class Initialized
INFO - 2018-09-13 14:31:01 --> Model "QuestionsModel" initialized
INFO - 2018-09-13 14:31:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-13 14:31:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-13 14:31:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-09-13 14:31:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-13 14:31:01 --> Final output sent to browser
DEBUG - 2018-09-13 14:31:01 --> Total execution time: 0.0355
INFO - 2018-09-13 14:31:05 --> Config Class Initialized
INFO - 2018-09-13 14:31:05 --> Hooks Class Initialized
DEBUG - 2018-09-13 14:31:05 --> UTF-8 Support Enabled
INFO - 2018-09-13 14:31:05 --> Utf8 Class Initialized
INFO - 2018-09-13 14:31:05 --> URI Class Initialized
INFO - 2018-09-13 14:31:05 --> Router Class Initialized
INFO - 2018-09-13 14:31:05 --> Output Class Initialized
INFO - 2018-09-13 14:31:05 --> Security Class Initialized
DEBUG - 2018-09-13 14:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-13 14:31:05 --> CSRF cookie sent
INFO - 2018-09-13 14:31:05 --> Input Class Initialized
INFO - 2018-09-13 14:31:05 --> Language Class Initialized
INFO - 2018-09-13 14:31:05 --> Loader Class Initialized
INFO - 2018-09-13 14:31:05 --> Helper loaded: url_helper
INFO - 2018-09-13 14:31:05 --> Helper loaded: form_helper
INFO - 2018-09-13 14:31:05 --> Helper loaded: language_helper
DEBUG - 2018-09-13 14:31:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-13 14:31:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-13 14:31:05 --> User Agent Class Initialized
INFO - 2018-09-13 14:31:05 --> Controller Class Initialized
INFO - 2018-09-13 14:31:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-13 14:31:05 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-09-13 14:31:05 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-09-13 14:31:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-13 14:31:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-13 14:31:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-13 14:31:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-09-13 14:31:05 --> Could not find the language line "req_email"
INFO - 2018-09-13 14:31:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-09-13 14:31:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-13 14:31:05 --> Final output sent to browser
DEBUG - 2018-09-13 14:31:05 --> Total execution time: 0.0311
INFO - 2018-09-13 14:31:55 --> Config Class Initialized
INFO - 2018-09-13 14:31:55 --> Hooks Class Initialized
DEBUG - 2018-09-13 14:31:55 --> UTF-8 Support Enabled
INFO - 2018-09-13 14:31:55 --> Utf8 Class Initialized
INFO - 2018-09-13 14:31:55 --> URI Class Initialized
DEBUG - 2018-09-13 14:31:55 --> No URI present. Default controller set.
INFO - 2018-09-13 14:31:55 --> Router Class Initialized
INFO - 2018-09-13 14:31:55 --> Output Class Initialized
INFO - 2018-09-13 14:31:55 --> Security Class Initialized
DEBUG - 2018-09-13 14:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-13 14:31:55 --> CSRF cookie sent
INFO - 2018-09-13 14:31:55 --> Input Class Initialized
INFO - 2018-09-13 14:31:55 --> Language Class Initialized
INFO - 2018-09-13 14:31:55 --> Loader Class Initialized
INFO - 2018-09-13 14:31:55 --> Helper loaded: url_helper
INFO - 2018-09-13 14:31:55 --> Helper loaded: form_helper
INFO - 2018-09-13 14:31:55 --> Helper loaded: language_helper
DEBUG - 2018-09-13 14:31:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-13 14:31:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-13 14:31:55 --> User Agent Class Initialized
INFO - 2018-09-13 14:31:55 --> Controller Class Initialized
INFO - 2018-09-13 14:31:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-13 14:31:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-13 14:31:55 --> Pixel_Model class loaded
INFO - 2018-09-13 14:31:55 --> Database Driver Class Initialized
INFO - 2018-09-13 14:31:55 --> Model "QuestionsModel" initialized
INFO - 2018-09-13 14:31:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-13 14:31:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-13 14:31:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-09-13 14:31:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-13 14:31:55 --> Final output sent to browser
DEBUG - 2018-09-13 14:31:55 --> Total execution time: 0.0347

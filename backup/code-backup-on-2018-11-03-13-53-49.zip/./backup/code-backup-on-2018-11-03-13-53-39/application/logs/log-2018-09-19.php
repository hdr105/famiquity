<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-09-19 16:56:09 --> Config Class Initialized
INFO - 2018-09-19 16:56:09 --> Hooks Class Initialized
DEBUG - 2018-09-19 16:56:09 --> UTF-8 Support Enabled
INFO - 2018-09-19 16:56:09 --> Utf8 Class Initialized
INFO - 2018-09-19 16:56:09 --> URI Class Initialized
DEBUG - 2018-09-19 16:56:09 --> No URI present. Default controller set.
INFO - 2018-09-19 16:56:09 --> Router Class Initialized
INFO - 2018-09-19 16:56:09 --> Output Class Initialized
INFO - 2018-09-19 16:56:09 --> Security Class Initialized
DEBUG - 2018-09-19 16:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-19 16:56:09 --> CSRF cookie sent
INFO - 2018-09-19 16:56:09 --> Input Class Initialized
INFO - 2018-09-19 16:56:09 --> Language Class Initialized
INFO - 2018-09-19 16:56:09 --> Loader Class Initialized
INFO - 2018-09-19 16:56:09 --> Helper loaded: url_helper
INFO - 2018-09-19 16:56:09 --> Helper loaded: form_helper
INFO - 2018-09-19 16:56:09 --> Helper loaded: language_helper
DEBUG - 2018-09-19 16:56:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-19 16:56:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-19 16:56:09 --> User Agent Class Initialized
INFO - 2018-09-19 16:56:09 --> Controller Class Initialized
INFO - 2018-09-19 16:56:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-19 16:56:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-19 16:56:09 --> Pixel_Model class loaded
INFO - 2018-09-19 16:56:09 --> Database Driver Class Initialized
INFO - 2018-09-19 16:56:09 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 16:56:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-19 16:56:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-19 16:56:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-09-19 16:56:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-19 16:56:09 --> Final output sent to browser
DEBUG - 2018-09-19 16:56:09 --> Total execution time: 0.0360
INFO - 2018-09-19 16:56:09 --> Config Class Initialized
INFO - 2018-09-19 16:56:09 --> Hooks Class Initialized
DEBUG - 2018-09-19 16:56:09 --> UTF-8 Support Enabled
INFO - 2018-09-19 16:56:09 --> Utf8 Class Initialized
INFO - 2018-09-19 16:56:09 --> URI Class Initialized
DEBUG - 2018-09-19 16:56:09 --> No URI present. Default controller set.
INFO - 2018-09-19 16:56:09 --> Router Class Initialized
INFO - 2018-09-19 16:56:09 --> Output Class Initialized
INFO - 2018-09-19 16:56:09 --> Security Class Initialized
DEBUG - 2018-09-19 16:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-19 16:56:09 --> CSRF cookie sent
INFO - 2018-09-19 16:56:09 --> Input Class Initialized
INFO - 2018-09-19 16:56:09 --> Language Class Initialized
INFO - 2018-09-19 16:56:09 --> Loader Class Initialized
INFO - 2018-09-19 16:56:09 --> Helper loaded: url_helper
INFO - 2018-09-19 16:56:09 --> Helper loaded: form_helper
INFO - 2018-09-19 16:56:09 --> Helper loaded: language_helper
DEBUG - 2018-09-19 16:56:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-19 16:56:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-19 16:56:09 --> User Agent Class Initialized
INFO - 2018-09-19 16:56:09 --> Controller Class Initialized
INFO - 2018-09-19 16:56:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-19 16:56:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-19 16:56:09 --> Pixel_Model class loaded
INFO - 2018-09-19 16:56:09 --> Database Driver Class Initialized
INFO - 2018-09-19 16:56:09 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 16:56:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-19 16:56:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-19 16:56:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-09-19 16:56:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-19 16:56:09 --> Final output sent to browser
DEBUG - 2018-09-19 16:56:09 --> Total execution time: 0.0356
INFO - 2018-09-19 16:56:13 --> Config Class Initialized
INFO - 2018-09-19 16:56:13 --> Hooks Class Initialized
DEBUG - 2018-09-19 16:56:13 --> UTF-8 Support Enabled
INFO - 2018-09-19 16:56:13 --> Utf8 Class Initialized
INFO - 2018-09-19 16:56:13 --> URI Class Initialized
INFO - 2018-09-19 16:56:13 --> Router Class Initialized
INFO - 2018-09-19 16:56:13 --> Output Class Initialized
INFO - 2018-09-19 16:56:13 --> Security Class Initialized
DEBUG - 2018-09-19 16:56:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-19 16:56:13 --> CSRF cookie sent
INFO - 2018-09-19 16:56:13 --> CSRF token verified
INFO - 2018-09-19 16:56:13 --> Input Class Initialized
INFO - 2018-09-19 16:56:13 --> Language Class Initialized
INFO - 2018-09-19 16:56:13 --> Loader Class Initialized
INFO - 2018-09-19 16:56:13 --> Helper loaded: url_helper
INFO - 2018-09-19 16:56:13 --> Helper loaded: form_helper
INFO - 2018-09-19 16:56:13 --> Helper loaded: language_helper
DEBUG - 2018-09-19 16:56:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-19 16:56:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-19 16:56:13 --> User Agent Class Initialized
INFO - 2018-09-19 16:56:13 --> Controller Class Initialized
INFO - 2018-09-19 16:56:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-19 16:56:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-19 16:56:13 --> Pixel_Model class loaded
INFO - 2018-09-19 16:56:13 --> Database Driver Class Initialized
INFO - 2018-09-19 16:56:13 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 16:56:13 --> Database Driver Class Initialized
INFO - 2018-09-19 16:56:13 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 16:56:13 --> Config Class Initialized
INFO - 2018-09-19 16:56:13 --> Hooks Class Initialized
DEBUG - 2018-09-19 16:56:13 --> UTF-8 Support Enabled
INFO - 2018-09-19 16:56:13 --> Utf8 Class Initialized
INFO - 2018-09-19 16:56:13 --> URI Class Initialized
INFO - 2018-09-19 16:56:13 --> Router Class Initialized
INFO - 2018-09-19 16:56:13 --> Output Class Initialized
INFO - 2018-09-19 16:56:13 --> Security Class Initialized
DEBUG - 2018-09-19 16:56:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-19 16:56:13 --> CSRF cookie sent
INFO - 2018-09-19 16:56:13 --> Input Class Initialized
INFO - 2018-09-19 16:56:13 --> Language Class Initialized
INFO - 2018-09-19 16:56:13 --> Loader Class Initialized
INFO - 2018-09-19 16:56:13 --> Helper loaded: url_helper
INFO - 2018-09-19 16:56:13 --> Helper loaded: form_helper
INFO - 2018-09-19 16:56:13 --> Helper loaded: language_helper
DEBUG - 2018-09-19 16:56:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-19 16:56:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-19 16:56:13 --> User Agent Class Initialized
INFO - 2018-09-19 16:56:13 --> Controller Class Initialized
INFO - 2018-09-19 16:56:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-19 16:56:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-19 16:56:13 --> Pixel_Model class loaded
INFO - 2018-09-19 16:56:13 --> Database Driver Class Initialized
INFO - 2018-09-19 16:56:13 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 16:56:13 --> Database Driver Class Initialized
INFO - 2018-09-19 16:56:13 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 16:56:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-19 16:56:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-19 16:56:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-19 16:56:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-19 16:56:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-19 16:56:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-19 16:56:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-09-19 16:56:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-19 16:56:13 --> Final output sent to browser
DEBUG - 2018-09-19 16:56:13 --> Total execution time: 0.0584
INFO - 2018-09-19 16:56:16 --> Config Class Initialized
INFO - 2018-09-19 16:56:16 --> Hooks Class Initialized
DEBUG - 2018-09-19 16:56:16 --> UTF-8 Support Enabled
INFO - 2018-09-19 16:56:16 --> Utf8 Class Initialized
INFO - 2018-09-19 16:56:16 --> URI Class Initialized
INFO - 2018-09-19 16:56:16 --> Router Class Initialized
INFO - 2018-09-19 16:56:16 --> Output Class Initialized
INFO - 2018-09-19 16:56:16 --> Security Class Initialized
DEBUG - 2018-09-19 16:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-19 16:56:16 --> CSRF cookie sent
INFO - 2018-09-19 16:56:16 --> CSRF token verified
INFO - 2018-09-19 16:56:16 --> Input Class Initialized
INFO - 2018-09-19 16:56:16 --> Language Class Initialized
INFO - 2018-09-19 16:56:16 --> Loader Class Initialized
INFO - 2018-09-19 16:56:16 --> Helper loaded: url_helper
INFO - 2018-09-19 16:56:16 --> Helper loaded: form_helper
INFO - 2018-09-19 16:56:16 --> Helper loaded: language_helper
DEBUG - 2018-09-19 16:56:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-19 16:56:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-19 16:56:16 --> User Agent Class Initialized
INFO - 2018-09-19 16:56:16 --> Controller Class Initialized
INFO - 2018-09-19 16:56:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-19 16:56:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-19 16:56:16 --> Pixel_Model class loaded
INFO - 2018-09-19 16:56:16 --> Database Driver Class Initialized
INFO - 2018-09-19 16:56:16 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 16:56:16 --> Form Validation Class Initialized
INFO - 2018-09-19 16:56:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-19 16:56:16 --> Database Driver Class Initialized
INFO - 2018-09-19 16:56:16 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 16:56:16 --> Config Class Initialized
INFO - 2018-09-19 16:56:16 --> Hooks Class Initialized
DEBUG - 2018-09-19 16:56:16 --> UTF-8 Support Enabled
INFO - 2018-09-19 16:56:16 --> Utf8 Class Initialized
INFO - 2018-09-19 16:56:16 --> URI Class Initialized
INFO - 2018-09-19 16:56:16 --> Router Class Initialized
INFO - 2018-09-19 16:56:16 --> Output Class Initialized
INFO - 2018-09-19 16:56:16 --> Security Class Initialized
DEBUG - 2018-09-19 16:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-19 16:56:16 --> CSRF cookie sent
INFO - 2018-09-19 16:56:16 --> Input Class Initialized
INFO - 2018-09-19 16:56:16 --> Language Class Initialized
INFO - 2018-09-19 16:56:16 --> Loader Class Initialized
INFO - 2018-09-19 16:56:16 --> Helper loaded: url_helper
INFO - 2018-09-19 16:56:16 --> Helper loaded: form_helper
INFO - 2018-09-19 16:56:16 --> Helper loaded: language_helper
DEBUG - 2018-09-19 16:56:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-19 16:56:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-19 16:56:16 --> User Agent Class Initialized
INFO - 2018-09-19 16:56:16 --> Controller Class Initialized
INFO - 2018-09-19 16:56:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-19 16:56:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-19 16:56:16 --> Pixel_Model class loaded
INFO - 2018-09-19 16:56:16 --> Database Driver Class Initialized
INFO - 2018-09-19 16:56:16 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 16:56:16 --> Database Driver Class Initialized
INFO - 2018-09-19 16:56:16 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 16:56:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-19 16:56:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-19 16:56:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-19 16:56:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-19 16:56:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-19 16:56:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-19 16:56:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-09-19 16:56:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-19 16:56:16 --> Final output sent to browser
DEBUG - 2018-09-19 16:56:16 --> Total execution time: 0.0539
INFO - 2018-09-19 16:56:22 --> Config Class Initialized
INFO - 2018-09-19 16:56:22 --> Hooks Class Initialized
DEBUG - 2018-09-19 16:56:22 --> UTF-8 Support Enabled
INFO - 2018-09-19 16:56:22 --> Utf8 Class Initialized
INFO - 2018-09-19 16:56:22 --> URI Class Initialized
INFO - 2018-09-19 16:56:22 --> Router Class Initialized
INFO - 2018-09-19 16:56:22 --> Output Class Initialized
INFO - 2018-09-19 16:56:22 --> Security Class Initialized
DEBUG - 2018-09-19 16:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-19 16:56:22 --> CSRF cookie sent
INFO - 2018-09-19 16:56:22 --> CSRF token verified
INFO - 2018-09-19 16:56:22 --> Input Class Initialized
INFO - 2018-09-19 16:56:22 --> Language Class Initialized
INFO - 2018-09-19 16:56:22 --> Loader Class Initialized
INFO - 2018-09-19 16:56:22 --> Helper loaded: url_helper
INFO - 2018-09-19 16:56:22 --> Helper loaded: form_helper
INFO - 2018-09-19 16:56:22 --> Helper loaded: language_helper
DEBUG - 2018-09-19 16:56:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-19 16:56:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-19 16:56:22 --> User Agent Class Initialized
INFO - 2018-09-19 16:56:22 --> Controller Class Initialized
INFO - 2018-09-19 16:56:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-19 16:56:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-19 16:56:22 --> Pixel_Model class loaded
INFO - 2018-09-19 16:56:22 --> Database Driver Class Initialized
INFO - 2018-09-19 16:56:22 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 16:56:22 --> Form Validation Class Initialized
INFO - 2018-09-19 16:56:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-19 16:56:22 --> Database Driver Class Initialized
INFO - 2018-09-19 16:56:22 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 16:56:22 --> Config Class Initialized
INFO - 2018-09-19 16:56:22 --> Hooks Class Initialized
DEBUG - 2018-09-19 16:56:22 --> UTF-8 Support Enabled
INFO - 2018-09-19 16:56:22 --> Utf8 Class Initialized
INFO - 2018-09-19 16:56:22 --> URI Class Initialized
INFO - 2018-09-19 16:56:22 --> Router Class Initialized
INFO - 2018-09-19 16:56:22 --> Output Class Initialized
INFO - 2018-09-19 16:56:22 --> Security Class Initialized
DEBUG - 2018-09-19 16:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-19 16:56:22 --> CSRF cookie sent
INFO - 2018-09-19 16:56:22 --> Input Class Initialized
INFO - 2018-09-19 16:56:22 --> Language Class Initialized
INFO - 2018-09-19 16:56:22 --> Loader Class Initialized
INFO - 2018-09-19 16:56:22 --> Helper loaded: url_helper
INFO - 2018-09-19 16:56:22 --> Helper loaded: form_helper
INFO - 2018-09-19 16:56:22 --> Helper loaded: language_helper
DEBUG - 2018-09-19 16:56:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-19 16:56:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-19 16:56:22 --> User Agent Class Initialized
INFO - 2018-09-19 16:56:22 --> Controller Class Initialized
INFO - 2018-09-19 16:56:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-19 16:56:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-19 16:56:22 --> Pixel_Model class loaded
INFO - 2018-09-19 16:56:22 --> Database Driver Class Initialized
INFO - 2018-09-19 16:56:22 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 16:56:22 --> Database Driver Class Initialized
INFO - 2018-09-19 16:56:22 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 16:56:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-19 16:56:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-19 16:56:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-09-19 16:56:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-19 16:56:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-19 16:56:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-19 16:56:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-19 16:56:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-09-19 16:56:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-19 16:56:22 --> Final output sent to browser
DEBUG - 2018-09-19 16:56:22 --> Total execution time: 0.0400
INFO - 2018-09-19 16:56:32 --> Config Class Initialized
INFO - 2018-09-19 16:56:32 --> Hooks Class Initialized
DEBUG - 2018-09-19 16:56:32 --> UTF-8 Support Enabled
INFO - 2018-09-19 16:56:32 --> Utf8 Class Initialized
INFO - 2018-09-19 16:56:32 --> URI Class Initialized
INFO - 2018-09-19 16:56:32 --> Router Class Initialized
INFO - 2018-09-19 16:56:32 --> Output Class Initialized
INFO - 2018-09-19 16:56:32 --> Security Class Initialized
DEBUG - 2018-09-19 16:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-19 16:56:32 --> CSRF cookie sent
INFO - 2018-09-19 16:56:32 --> CSRF token verified
INFO - 2018-09-19 16:56:32 --> Input Class Initialized
INFO - 2018-09-19 16:56:32 --> Language Class Initialized
INFO - 2018-09-19 16:56:32 --> Loader Class Initialized
INFO - 2018-09-19 16:56:32 --> Helper loaded: url_helper
INFO - 2018-09-19 16:56:32 --> Helper loaded: form_helper
INFO - 2018-09-19 16:56:32 --> Helper loaded: language_helper
DEBUG - 2018-09-19 16:56:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-19 16:56:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-19 16:56:32 --> User Agent Class Initialized
INFO - 2018-09-19 16:56:32 --> Controller Class Initialized
INFO - 2018-09-19 16:56:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-19 16:56:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-19 16:56:32 --> Pixel_Model class loaded
INFO - 2018-09-19 16:56:32 --> Database Driver Class Initialized
INFO - 2018-09-19 16:56:32 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 16:56:32 --> Form Validation Class Initialized
INFO - 2018-09-19 16:56:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-19 16:56:32 --> Database Driver Class Initialized
INFO - 2018-09-19 16:56:32 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 16:56:32 --> Config Class Initialized
INFO - 2018-09-19 16:56:32 --> Hooks Class Initialized
DEBUG - 2018-09-19 16:56:32 --> UTF-8 Support Enabled
INFO - 2018-09-19 16:56:32 --> Utf8 Class Initialized
INFO - 2018-09-19 16:56:32 --> URI Class Initialized
INFO - 2018-09-19 16:56:32 --> Router Class Initialized
INFO - 2018-09-19 16:56:32 --> Output Class Initialized
INFO - 2018-09-19 16:56:32 --> Security Class Initialized
DEBUG - 2018-09-19 16:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-19 16:56:33 --> CSRF cookie sent
INFO - 2018-09-19 16:56:33 --> Input Class Initialized
INFO - 2018-09-19 16:56:33 --> Language Class Initialized
INFO - 2018-09-19 16:56:33 --> Loader Class Initialized
INFO - 2018-09-19 16:56:33 --> Helper loaded: url_helper
INFO - 2018-09-19 16:56:33 --> Helper loaded: form_helper
INFO - 2018-09-19 16:56:33 --> Helper loaded: language_helper
DEBUG - 2018-09-19 16:56:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-19 16:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-19 16:56:33 --> User Agent Class Initialized
INFO - 2018-09-19 16:56:33 --> Controller Class Initialized
INFO - 2018-09-19 16:56:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-19 16:56:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-19 16:56:33 --> Pixel_Model class loaded
INFO - 2018-09-19 16:56:33 --> Database Driver Class Initialized
INFO - 2018-09-19 16:56:33 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 16:56:33 --> Database Driver Class Initialized
INFO - 2018-09-19 16:56:33 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 16:56:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-19 16:56:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-19 16:56:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-19 16:56:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-19 16:56:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-19 16:56:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-19 16:56:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-09-19 16:56:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-19 16:56:33 --> Final output sent to browser
DEBUG - 2018-09-19 16:56:33 --> Total execution time: 0.0468
INFO - 2018-09-19 16:56:40 --> Config Class Initialized
INFO - 2018-09-19 16:56:40 --> Hooks Class Initialized
DEBUG - 2018-09-19 16:56:40 --> UTF-8 Support Enabled
INFO - 2018-09-19 16:56:40 --> Utf8 Class Initialized
INFO - 2018-09-19 16:56:40 --> URI Class Initialized
INFO - 2018-09-19 16:56:40 --> Router Class Initialized
INFO - 2018-09-19 16:56:40 --> Output Class Initialized
INFO - 2018-09-19 16:56:40 --> Security Class Initialized
DEBUG - 2018-09-19 16:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-19 16:56:40 --> CSRF cookie sent
INFO - 2018-09-19 16:56:40 --> CSRF token verified
INFO - 2018-09-19 16:56:40 --> Input Class Initialized
INFO - 2018-09-19 16:56:40 --> Language Class Initialized
INFO - 2018-09-19 16:56:40 --> Loader Class Initialized
INFO - 2018-09-19 16:56:40 --> Helper loaded: url_helper
INFO - 2018-09-19 16:56:40 --> Helper loaded: form_helper
INFO - 2018-09-19 16:56:40 --> Helper loaded: language_helper
DEBUG - 2018-09-19 16:56:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-19 16:56:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-19 16:56:40 --> User Agent Class Initialized
INFO - 2018-09-19 16:56:40 --> Controller Class Initialized
INFO - 2018-09-19 16:56:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-19 16:56:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-19 16:56:40 --> Pixel_Model class loaded
INFO - 2018-09-19 16:56:40 --> Database Driver Class Initialized
INFO - 2018-09-19 16:56:40 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 16:56:40 --> Form Validation Class Initialized
INFO - 2018-09-19 16:56:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-19 16:56:40 --> Database Driver Class Initialized
INFO - 2018-09-19 16:56:40 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 16:56:40 --> Config Class Initialized
INFO - 2018-09-19 16:56:40 --> Hooks Class Initialized
DEBUG - 2018-09-19 16:56:40 --> UTF-8 Support Enabled
INFO - 2018-09-19 16:56:40 --> Utf8 Class Initialized
INFO - 2018-09-19 16:56:40 --> URI Class Initialized
INFO - 2018-09-19 16:56:40 --> Router Class Initialized
INFO - 2018-09-19 16:56:40 --> Output Class Initialized
INFO - 2018-09-19 16:56:40 --> Security Class Initialized
DEBUG - 2018-09-19 16:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-19 16:56:40 --> CSRF cookie sent
INFO - 2018-09-19 16:56:40 --> Input Class Initialized
INFO - 2018-09-19 16:56:40 --> Language Class Initialized
INFO - 2018-09-19 16:56:40 --> Loader Class Initialized
INFO - 2018-09-19 16:56:40 --> Helper loaded: url_helper
INFO - 2018-09-19 16:56:40 --> Helper loaded: form_helper
INFO - 2018-09-19 16:56:40 --> Helper loaded: language_helper
DEBUG - 2018-09-19 16:56:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-19 16:56:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-19 16:56:40 --> User Agent Class Initialized
INFO - 2018-09-19 16:56:40 --> Controller Class Initialized
INFO - 2018-09-19 16:56:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-19 16:56:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-19 16:56:40 --> Pixel_Model class loaded
INFO - 2018-09-19 16:56:40 --> Database Driver Class Initialized
INFO - 2018-09-19 16:56:40 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 16:56:40 --> Database Driver Class Initialized
INFO - 2018-09-19 16:56:40 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 16:56:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-19 16:56:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-19 16:56:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-19 16:56:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-19 16:56:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-19 16:56:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-19 16:56:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/cohabitation.php
INFO - 2018-09-19 16:56:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-19 16:56:40 --> Final output sent to browser
DEBUG - 2018-09-19 16:56:40 --> Total execution time: 0.0422
INFO - 2018-09-19 16:56:50 --> Config Class Initialized
INFO - 2018-09-19 16:56:50 --> Hooks Class Initialized
DEBUG - 2018-09-19 16:56:50 --> UTF-8 Support Enabled
INFO - 2018-09-19 16:56:50 --> Utf8 Class Initialized
INFO - 2018-09-19 16:56:50 --> URI Class Initialized
INFO - 2018-09-19 16:56:50 --> Router Class Initialized
INFO - 2018-09-19 16:56:50 --> Output Class Initialized
INFO - 2018-09-19 16:56:50 --> Security Class Initialized
DEBUG - 2018-09-19 16:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-19 16:56:50 --> CSRF cookie sent
INFO - 2018-09-19 16:56:50 --> CSRF token verified
INFO - 2018-09-19 16:56:50 --> Input Class Initialized
INFO - 2018-09-19 16:56:50 --> Language Class Initialized
INFO - 2018-09-19 16:56:50 --> Loader Class Initialized
INFO - 2018-09-19 16:56:50 --> Helper loaded: url_helper
INFO - 2018-09-19 16:56:50 --> Helper loaded: form_helper
INFO - 2018-09-19 16:56:50 --> Helper loaded: language_helper
DEBUG - 2018-09-19 16:56:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-19 16:56:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-19 16:56:50 --> User Agent Class Initialized
INFO - 2018-09-19 16:56:50 --> Controller Class Initialized
INFO - 2018-09-19 16:56:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-19 16:56:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-19 16:56:50 --> Pixel_Model class loaded
INFO - 2018-09-19 16:56:50 --> Database Driver Class Initialized
INFO - 2018-09-19 16:56:50 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 16:56:50 --> Form Validation Class Initialized
INFO - 2018-09-19 16:56:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-19 16:56:50 --> Database Driver Class Initialized
INFO - 2018-09-19 16:56:50 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 16:56:50 --> Config Class Initialized
INFO - 2018-09-19 16:56:50 --> Hooks Class Initialized
DEBUG - 2018-09-19 16:56:50 --> UTF-8 Support Enabled
INFO - 2018-09-19 16:56:50 --> Utf8 Class Initialized
INFO - 2018-09-19 16:56:50 --> URI Class Initialized
INFO - 2018-09-19 16:56:50 --> Router Class Initialized
INFO - 2018-09-19 16:56:50 --> Output Class Initialized
INFO - 2018-09-19 16:56:50 --> Security Class Initialized
DEBUG - 2018-09-19 16:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-19 16:56:50 --> CSRF cookie sent
INFO - 2018-09-19 16:56:50 --> Input Class Initialized
INFO - 2018-09-19 16:56:50 --> Language Class Initialized
INFO - 2018-09-19 16:56:50 --> Loader Class Initialized
INFO - 2018-09-19 16:56:50 --> Helper loaded: url_helper
INFO - 2018-09-19 16:56:50 --> Helper loaded: form_helper
INFO - 2018-09-19 16:56:50 --> Helper loaded: language_helper
DEBUG - 2018-09-19 16:56:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-19 16:56:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-19 16:56:50 --> User Agent Class Initialized
INFO - 2018-09-19 16:56:50 --> Controller Class Initialized
INFO - 2018-09-19 16:56:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-19 16:56:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-19 16:56:50 --> Pixel_Model class loaded
INFO - 2018-09-19 16:56:50 --> Database Driver Class Initialized
INFO - 2018-09-19 16:56:50 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 16:56:50 --> Database Driver Class Initialized
INFO - 2018-09-19 16:56:50 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 16:56:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-19 16:56:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-19 16:56:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-19 16:56:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-19 16:56:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-19 16:56:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-19 16:56:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-09-19 16:56:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-19 16:56:50 --> Final output sent to browser
DEBUG - 2018-09-19 16:56:50 --> Total execution time: 0.0435
INFO - 2018-09-19 16:57:03 --> Config Class Initialized
INFO - 2018-09-19 16:57:03 --> Hooks Class Initialized
DEBUG - 2018-09-19 16:57:03 --> UTF-8 Support Enabled
INFO - 2018-09-19 16:57:03 --> Utf8 Class Initialized
INFO - 2018-09-19 16:57:03 --> URI Class Initialized
INFO - 2018-09-19 16:57:03 --> Router Class Initialized
INFO - 2018-09-19 16:57:03 --> Output Class Initialized
INFO - 2018-09-19 16:57:03 --> Security Class Initialized
DEBUG - 2018-09-19 16:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-19 16:57:03 --> CSRF cookie sent
INFO - 2018-09-19 16:57:03 --> CSRF token verified
INFO - 2018-09-19 16:57:03 --> Input Class Initialized
INFO - 2018-09-19 16:57:03 --> Language Class Initialized
INFO - 2018-09-19 16:57:03 --> Loader Class Initialized
INFO - 2018-09-19 16:57:03 --> Helper loaded: url_helper
INFO - 2018-09-19 16:57:03 --> Helper loaded: form_helper
INFO - 2018-09-19 16:57:03 --> Helper loaded: language_helper
DEBUG - 2018-09-19 16:57:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-19 16:57:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-19 16:57:03 --> User Agent Class Initialized
INFO - 2018-09-19 16:57:03 --> Controller Class Initialized
INFO - 2018-09-19 16:57:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-19 16:57:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-19 16:57:03 --> Pixel_Model class loaded
INFO - 2018-09-19 16:57:03 --> Database Driver Class Initialized
INFO - 2018-09-19 16:57:03 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 16:57:03 --> Form Validation Class Initialized
INFO - 2018-09-19 16:57:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-19 16:57:03 --> Database Driver Class Initialized
INFO - 2018-09-19 16:57:03 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 16:57:03 --> Config Class Initialized
INFO - 2018-09-19 16:57:03 --> Hooks Class Initialized
DEBUG - 2018-09-19 16:57:03 --> UTF-8 Support Enabled
INFO - 2018-09-19 16:57:03 --> Utf8 Class Initialized
INFO - 2018-09-19 16:57:03 --> URI Class Initialized
INFO - 2018-09-19 16:57:03 --> Router Class Initialized
INFO - 2018-09-19 16:57:03 --> Output Class Initialized
INFO - 2018-09-19 16:57:03 --> Security Class Initialized
DEBUG - 2018-09-19 16:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-19 16:57:03 --> CSRF cookie sent
INFO - 2018-09-19 16:57:03 --> Input Class Initialized
INFO - 2018-09-19 16:57:03 --> Language Class Initialized
INFO - 2018-09-19 16:57:03 --> Loader Class Initialized
INFO - 2018-09-19 16:57:03 --> Helper loaded: url_helper
INFO - 2018-09-19 16:57:03 --> Helper loaded: form_helper
INFO - 2018-09-19 16:57:03 --> Helper loaded: language_helper
DEBUG - 2018-09-19 16:57:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-19 16:57:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-19 16:57:03 --> User Agent Class Initialized
INFO - 2018-09-19 16:57:03 --> Controller Class Initialized
INFO - 2018-09-19 16:57:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-19 16:57:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-19 16:57:03 --> Pixel_Model class loaded
INFO - 2018-09-19 16:57:03 --> Database Driver Class Initialized
INFO - 2018-09-19 16:57:03 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 16:57:03 --> Database Driver Class Initialized
INFO - 2018-09-19 16:57:03 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 16:57:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-19 16:57:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-19 16:57:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-19 16:57:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-19 16:57:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-19 16:57:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-19 16:57:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-09-19 16:57:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-19 16:57:03 --> Final output sent to browser
DEBUG - 2018-09-19 16:57:03 --> Total execution time: 0.0485
INFO - 2018-09-19 16:57:32 --> Config Class Initialized
INFO - 2018-09-19 16:57:32 --> Hooks Class Initialized
DEBUG - 2018-09-19 16:57:32 --> UTF-8 Support Enabled
INFO - 2018-09-19 16:57:32 --> Utf8 Class Initialized
INFO - 2018-09-19 16:57:32 --> URI Class Initialized
INFO - 2018-09-19 16:57:32 --> Router Class Initialized
INFO - 2018-09-19 16:57:32 --> Output Class Initialized
INFO - 2018-09-19 16:57:32 --> Security Class Initialized
DEBUG - 2018-09-19 16:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-19 16:57:32 --> CSRF cookie sent
INFO - 2018-09-19 16:57:32 --> CSRF token verified
INFO - 2018-09-19 16:57:32 --> Input Class Initialized
INFO - 2018-09-19 16:57:32 --> Language Class Initialized
INFO - 2018-09-19 16:57:32 --> Loader Class Initialized
INFO - 2018-09-19 16:57:32 --> Helper loaded: url_helper
INFO - 2018-09-19 16:57:32 --> Helper loaded: form_helper
INFO - 2018-09-19 16:57:32 --> Helper loaded: language_helper
DEBUG - 2018-09-19 16:57:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-19 16:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-19 16:57:32 --> User Agent Class Initialized
INFO - 2018-09-19 16:57:32 --> Controller Class Initialized
INFO - 2018-09-19 16:57:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-19 16:57:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-19 16:57:32 --> Pixel_Model class loaded
INFO - 2018-09-19 16:57:32 --> Database Driver Class Initialized
INFO - 2018-09-19 16:57:32 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 16:57:32 --> Form Validation Class Initialized
INFO - 2018-09-19 16:57:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-19 16:57:32 --> Database Driver Class Initialized
INFO - 2018-09-19 16:57:32 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 16:57:32 --> Config Class Initialized
INFO - 2018-09-19 16:57:32 --> Hooks Class Initialized
DEBUG - 2018-09-19 16:57:32 --> UTF-8 Support Enabled
INFO - 2018-09-19 16:57:32 --> Utf8 Class Initialized
INFO - 2018-09-19 16:57:32 --> URI Class Initialized
INFO - 2018-09-19 16:57:32 --> Router Class Initialized
INFO - 2018-09-19 16:57:32 --> Output Class Initialized
INFO - 2018-09-19 16:57:32 --> Security Class Initialized
DEBUG - 2018-09-19 16:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-19 16:57:32 --> CSRF cookie sent
INFO - 2018-09-19 16:57:32 --> Input Class Initialized
INFO - 2018-09-19 16:57:32 --> Language Class Initialized
INFO - 2018-09-19 16:57:32 --> Loader Class Initialized
INFO - 2018-09-19 16:57:32 --> Helper loaded: url_helper
INFO - 2018-09-19 16:57:32 --> Helper loaded: form_helper
INFO - 2018-09-19 16:57:32 --> Helper loaded: language_helper
DEBUG - 2018-09-19 16:57:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-19 16:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-19 16:57:32 --> User Agent Class Initialized
INFO - 2018-09-19 16:57:32 --> Controller Class Initialized
INFO - 2018-09-19 16:57:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-19 16:57:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-19 16:57:32 --> Pixel_Model class loaded
INFO - 2018-09-19 16:57:32 --> Database Driver Class Initialized
INFO - 2018-09-19 16:57:32 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 16:57:32 --> Database Driver Class Initialized
INFO - 2018-09-19 16:57:32 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 16:57:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-19 16:57:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-19 16:57:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-19 16:57:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-19 16:57:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-19 16:57:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-19 16:57:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-09-19 16:57:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-19 16:57:32 --> Final output sent to browser
DEBUG - 2018-09-19 16:57:32 --> Total execution time: 0.0479
INFO - 2018-09-19 16:57:39 --> Config Class Initialized
INFO - 2018-09-19 16:57:39 --> Hooks Class Initialized
DEBUG - 2018-09-19 16:57:39 --> UTF-8 Support Enabled
INFO - 2018-09-19 16:57:39 --> Utf8 Class Initialized
INFO - 2018-09-19 16:57:39 --> URI Class Initialized
INFO - 2018-09-19 16:57:39 --> Router Class Initialized
INFO - 2018-09-19 16:57:39 --> Output Class Initialized
INFO - 2018-09-19 16:57:39 --> Security Class Initialized
DEBUG - 2018-09-19 16:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-19 16:57:39 --> CSRF cookie sent
INFO - 2018-09-19 16:57:39 --> CSRF token verified
INFO - 2018-09-19 16:57:39 --> Input Class Initialized
INFO - 2018-09-19 16:57:39 --> Language Class Initialized
INFO - 2018-09-19 16:57:39 --> Loader Class Initialized
INFO - 2018-09-19 16:57:39 --> Helper loaded: url_helper
INFO - 2018-09-19 16:57:39 --> Helper loaded: form_helper
INFO - 2018-09-19 16:57:39 --> Helper loaded: language_helper
DEBUG - 2018-09-19 16:57:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-19 16:57:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-19 16:57:39 --> User Agent Class Initialized
INFO - 2018-09-19 16:57:39 --> Controller Class Initialized
INFO - 2018-09-19 16:57:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-19 16:57:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-19 16:57:39 --> Pixel_Model class loaded
INFO - 2018-09-19 16:57:39 --> Database Driver Class Initialized
INFO - 2018-09-19 16:57:39 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 16:57:39 --> Form Validation Class Initialized
INFO - 2018-09-19 16:57:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-19 16:57:39 --> Database Driver Class Initialized
INFO - 2018-09-19 16:57:39 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 16:57:40 --> Config Class Initialized
INFO - 2018-09-19 16:57:40 --> Hooks Class Initialized
DEBUG - 2018-09-19 16:57:40 --> UTF-8 Support Enabled
INFO - 2018-09-19 16:57:40 --> Utf8 Class Initialized
INFO - 2018-09-19 16:57:40 --> URI Class Initialized
INFO - 2018-09-19 16:57:40 --> Router Class Initialized
INFO - 2018-09-19 16:57:40 --> Output Class Initialized
INFO - 2018-09-19 16:57:40 --> Security Class Initialized
DEBUG - 2018-09-19 16:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-19 16:57:40 --> CSRF cookie sent
INFO - 2018-09-19 16:57:40 --> Input Class Initialized
INFO - 2018-09-19 16:57:40 --> Language Class Initialized
INFO - 2018-09-19 16:57:40 --> Loader Class Initialized
INFO - 2018-09-19 16:57:40 --> Helper loaded: url_helper
INFO - 2018-09-19 16:57:40 --> Helper loaded: form_helper
INFO - 2018-09-19 16:57:40 --> Helper loaded: language_helper
DEBUG - 2018-09-19 16:57:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-19 16:57:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-19 16:57:40 --> User Agent Class Initialized
INFO - 2018-09-19 16:57:40 --> Controller Class Initialized
INFO - 2018-09-19 16:57:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-19 16:57:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-19 16:57:40 --> Pixel_Model class loaded
INFO - 2018-09-19 16:57:40 --> Database Driver Class Initialized
INFO - 2018-09-19 16:57:40 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 16:57:40 --> Database Driver Class Initialized
INFO - 2018-09-19 16:57:40 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 16:57:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-19 16:57:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-19 16:57:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-19 16:57:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-19 16:57:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-19 16:57:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-19 16:57:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_owner.php
INFO - 2018-09-19 16:57:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-19 16:57:40 --> Final output sent to browser
DEBUG - 2018-09-19 16:57:40 --> Total execution time: 0.0509
INFO - 2018-09-19 16:57:51 --> Config Class Initialized
INFO - 2018-09-19 16:57:51 --> Hooks Class Initialized
DEBUG - 2018-09-19 16:57:51 --> UTF-8 Support Enabled
INFO - 2018-09-19 16:57:51 --> Utf8 Class Initialized
INFO - 2018-09-19 16:57:51 --> URI Class Initialized
INFO - 2018-09-19 16:57:51 --> Router Class Initialized
INFO - 2018-09-19 16:57:51 --> Output Class Initialized
INFO - 2018-09-19 16:57:51 --> Security Class Initialized
DEBUG - 2018-09-19 16:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-19 16:57:51 --> CSRF cookie sent
INFO - 2018-09-19 16:57:51 --> CSRF token verified
INFO - 2018-09-19 16:57:51 --> Input Class Initialized
INFO - 2018-09-19 16:57:51 --> Language Class Initialized
INFO - 2018-09-19 16:57:51 --> Loader Class Initialized
INFO - 2018-09-19 16:57:51 --> Helper loaded: url_helper
INFO - 2018-09-19 16:57:51 --> Helper loaded: form_helper
INFO - 2018-09-19 16:57:51 --> Helper loaded: language_helper
DEBUG - 2018-09-19 16:57:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-19 16:57:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-19 16:57:51 --> User Agent Class Initialized
INFO - 2018-09-19 16:57:51 --> Controller Class Initialized
INFO - 2018-09-19 16:57:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-19 16:57:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-19 16:57:51 --> Pixel_Model class loaded
INFO - 2018-09-19 16:57:51 --> Database Driver Class Initialized
INFO - 2018-09-19 16:57:51 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 16:57:51 --> Form Validation Class Initialized
INFO - 2018-09-19 16:57:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-19 16:57:51 --> Database Driver Class Initialized
INFO - 2018-09-19 16:57:51 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 16:57:51 --> Config Class Initialized
INFO - 2018-09-19 16:57:51 --> Hooks Class Initialized
DEBUG - 2018-09-19 16:57:51 --> UTF-8 Support Enabled
INFO - 2018-09-19 16:57:51 --> Utf8 Class Initialized
INFO - 2018-09-19 16:57:51 --> URI Class Initialized
INFO - 2018-09-19 16:57:51 --> Router Class Initialized
INFO - 2018-09-19 16:57:51 --> Output Class Initialized
INFO - 2018-09-19 16:57:51 --> Security Class Initialized
DEBUG - 2018-09-19 16:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-19 16:57:51 --> CSRF cookie sent
INFO - 2018-09-19 16:57:51 --> Input Class Initialized
INFO - 2018-09-19 16:57:51 --> Language Class Initialized
INFO - 2018-09-19 16:57:51 --> Loader Class Initialized
INFO - 2018-09-19 16:57:51 --> Helper loaded: url_helper
INFO - 2018-09-19 16:57:51 --> Helper loaded: form_helper
INFO - 2018-09-19 16:57:51 --> Helper loaded: language_helper
DEBUG - 2018-09-19 16:57:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-19 16:57:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-19 16:57:51 --> User Agent Class Initialized
INFO - 2018-09-19 16:57:51 --> Controller Class Initialized
INFO - 2018-09-19 16:57:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-19 16:57:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-19 16:57:51 --> Pixel_Model class loaded
INFO - 2018-09-19 16:57:51 --> Database Driver Class Initialized
INFO - 2018-09-19 16:57:51 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 16:57:51 --> Database Driver Class Initialized
INFO - 2018-09-19 16:57:51 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 16:57:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-19 16:57:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-19 16:57:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-19 16:57:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-19 16:57:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-19 16:57:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-19 16:57:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_value.php
INFO - 2018-09-19 16:57:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-19 16:57:51 --> Final output sent to browser
DEBUG - 2018-09-19 16:57:51 --> Total execution time: 0.0475
INFO - 2018-09-19 16:58:08 --> Config Class Initialized
INFO - 2018-09-19 16:58:08 --> Hooks Class Initialized
DEBUG - 2018-09-19 16:58:08 --> UTF-8 Support Enabled
INFO - 2018-09-19 16:58:08 --> Utf8 Class Initialized
INFO - 2018-09-19 16:58:08 --> URI Class Initialized
INFO - 2018-09-19 16:58:08 --> Router Class Initialized
INFO - 2018-09-19 16:58:08 --> Output Class Initialized
INFO - 2018-09-19 16:58:08 --> Security Class Initialized
DEBUG - 2018-09-19 16:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-19 16:58:08 --> CSRF cookie sent
INFO - 2018-09-19 16:58:08 --> Input Class Initialized
INFO - 2018-09-19 16:58:08 --> Language Class Initialized
INFO - 2018-09-19 16:58:08 --> Loader Class Initialized
INFO - 2018-09-19 16:58:08 --> Helper loaded: url_helper
INFO - 2018-09-19 16:58:08 --> Helper loaded: form_helper
INFO - 2018-09-19 16:58:08 --> Helper loaded: language_helper
DEBUG - 2018-09-19 16:58:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-19 16:58:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-19 16:58:08 --> User Agent Class Initialized
INFO - 2018-09-19 16:58:08 --> Controller Class Initialized
INFO - 2018-09-19 16:58:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-19 16:58:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-19 16:58:08 --> Pixel_Model class loaded
INFO - 2018-09-19 16:58:08 --> Database Driver Class Initialized
INFO - 2018-09-19 16:58:08 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 16:58:08 --> Database Driver Class Initialized
INFO - 2018-09-19 16:58:08 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 16:58:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-19 16:58:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-19 16:58:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-19 16:58:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-19 16:58:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-09-19 16:58:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-19 16:58:08 --> Final output sent to browser
DEBUG - 2018-09-19 16:58:08 --> Total execution time: 0.0605
INFO - 2018-09-19 16:58:56 --> Config Class Initialized
INFO - 2018-09-19 16:58:56 --> Hooks Class Initialized
DEBUG - 2018-09-19 16:58:56 --> UTF-8 Support Enabled
INFO - 2018-09-19 16:58:56 --> Utf8 Class Initialized
INFO - 2018-09-19 16:58:56 --> URI Class Initialized
INFO - 2018-09-19 16:58:56 --> Router Class Initialized
INFO - 2018-09-19 16:58:56 --> Output Class Initialized
INFO - 2018-09-19 16:58:56 --> Security Class Initialized
DEBUG - 2018-09-19 16:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-19 16:58:56 --> CSRF cookie sent
INFO - 2018-09-19 16:58:56 --> Input Class Initialized
INFO - 2018-09-19 16:58:56 --> Language Class Initialized
INFO - 2018-09-19 16:58:56 --> Loader Class Initialized
INFO - 2018-09-19 16:58:56 --> Helper loaded: url_helper
INFO - 2018-09-19 16:58:56 --> Helper loaded: form_helper
INFO - 2018-09-19 16:58:56 --> Helper loaded: language_helper
DEBUG - 2018-09-19 16:58:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-19 16:58:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-19 16:58:56 --> User Agent Class Initialized
INFO - 2018-09-19 16:58:56 --> Controller Class Initialized
INFO - 2018-09-19 16:58:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-19 16:58:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-19 16:58:56 --> Pixel_Model class loaded
INFO - 2018-09-19 16:58:56 --> Database Driver Class Initialized
INFO - 2018-09-19 16:58:56 --> Model "MyAccountModel" initialized
INFO - 2018-09-19 16:58:56 --> Config Class Initialized
INFO - 2018-09-19 16:58:56 --> Hooks Class Initialized
DEBUG - 2018-09-19 16:58:56 --> UTF-8 Support Enabled
INFO - 2018-09-19 16:58:56 --> Utf8 Class Initialized
INFO - 2018-09-19 16:58:56 --> URI Class Initialized
INFO - 2018-09-19 16:58:56 --> Router Class Initialized
INFO - 2018-09-19 16:58:56 --> Output Class Initialized
INFO - 2018-09-19 16:58:56 --> Security Class Initialized
DEBUG - 2018-09-19 16:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-19 16:58:56 --> CSRF cookie sent
INFO - 2018-09-19 16:58:56 --> Input Class Initialized
INFO - 2018-09-19 16:58:56 --> Language Class Initialized
INFO - 2018-09-19 16:58:56 --> Loader Class Initialized
INFO - 2018-09-19 16:58:56 --> Helper loaded: url_helper
INFO - 2018-09-19 16:58:56 --> Helper loaded: form_helper
INFO - 2018-09-19 16:58:56 --> Helper loaded: language_helper
DEBUG - 2018-09-19 16:58:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-19 16:58:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-19 16:58:56 --> User Agent Class Initialized
INFO - 2018-09-19 16:58:56 --> Controller Class Initialized
INFO - 2018-09-19 16:58:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-19 16:58:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-19 16:58:56 --> Pixel_Model class loaded
INFO - 2018-09-19 16:58:56 --> Database Driver Class Initialized
INFO - 2018-09-19 16:58:56 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 16:58:56 --> Database Driver Class Initialized
INFO - 2018-09-19 16:58:56 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 16:58:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-19 16:58:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-19 16:58:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-19 16:58:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-19 16:58:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-19 16:58:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-19 16:58:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_value.php
INFO - 2018-09-19 16:58:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-19 16:58:56 --> Final output sent to browser
DEBUG - 2018-09-19 16:58:56 --> Total execution time: 0.0462
INFO - 2018-09-19 17:10:22 --> Config Class Initialized
INFO - 2018-09-19 17:10:22 --> Hooks Class Initialized
DEBUG - 2018-09-19 17:10:22 --> UTF-8 Support Enabled
INFO - 2018-09-19 17:10:22 --> Utf8 Class Initialized
INFO - 2018-09-19 17:10:22 --> URI Class Initialized
DEBUG - 2018-09-19 17:10:22 --> No URI present. Default controller set.
INFO - 2018-09-19 17:10:22 --> Router Class Initialized
INFO - 2018-09-19 17:10:22 --> Output Class Initialized
INFO - 2018-09-19 17:10:22 --> Security Class Initialized
DEBUG - 2018-09-19 17:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-19 17:10:22 --> CSRF cookie sent
INFO - 2018-09-19 17:10:22 --> Input Class Initialized
INFO - 2018-09-19 17:10:22 --> Language Class Initialized
INFO - 2018-09-19 17:10:22 --> Loader Class Initialized
INFO - 2018-09-19 17:10:22 --> Helper loaded: url_helper
INFO - 2018-09-19 17:10:22 --> Helper loaded: form_helper
INFO - 2018-09-19 17:10:22 --> Helper loaded: language_helper
DEBUG - 2018-09-19 17:10:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-19 17:10:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-19 17:10:22 --> User Agent Class Initialized
INFO - 2018-09-19 17:10:22 --> Controller Class Initialized
INFO - 2018-09-19 17:10:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-19 17:10:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-19 17:10:22 --> Pixel_Model class loaded
INFO - 2018-09-19 17:10:22 --> Database Driver Class Initialized
INFO - 2018-09-19 17:10:22 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:10:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-19 17:10:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-19 17:10:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-09-19 17:10:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-19 17:10:22 --> Final output sent to browser
DEBUG - 2018-09-19 17:10:22 --> Total execution time: 0.0366
INFO - 2018-09-19 17:10:24 --> Config Class Initialized
INFO - 2018-09-19 17:10:24 --> Hooks Class Initialized
DEBUG - 2018-09-19 17:10:24 --> UTF-8 Support Enabled
INFO - 2018-09-19 17:10:24 --> Utf8 Class Initialized
INFO - 2018-09-19 17:10:24 --> URI Class Initialized
DEBUG - 2018-09-19 17:10:24 --> No URI present. Default controller set.
INFO - 2018-09-19 17:10:24 --> Router Class Initialized
INFO - 2018-09-19 17:10:24 --> Output Class Initialized
INFO - 2018-09-19 17:10:24 --> Security Class Initialized
DEBUG - 2018-09-19 17:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-19 17:10:24 --> CSRF cookie sent
INFO - 2018-09-19 17:10:24 --> Input Class Initialized
INFO - 2018-09-19 17:10:24 --> Language Class Initialized
INFO - 2018-09-19 17:10:24 --> Loader Class Initialized
INFO - 2018-09-19 17:10:24 --> Helper loaded: url_helper
INFO - 2018-09-19 17:10:24 --> Helper loaded: form_helper
INFO - 2018-09-19 17:10:24 --> Helper loaded: language_helper
DEBUG - 2018-09-19 17:10:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-19 17:10:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-19 17:10:24 --> User Agent Class Initialized
INFO - 2018-09-19 17:10:24 --> Controller Class Initialized
INFO - 2018-09-19 17:10:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-19 17:10:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-19 17:10:24 --> Pixel_Model class loaded
INFO - 2018-09-19 17:10:24 --> Database Driver Class Initialized
INFO - 2018-09-19 17:10:24 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:10:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-19 17:10:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-19 17:10:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-09-19 17:10:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-19 17:10:24 --> Final output sent to browser
DEBUG - 2018-09-19 17:10:24 --> Total execution time: 0.0345
INFO - 2018-09-19 17:10:53 --> Config Class Initialized
INFO - 2018-09-19 17:10:53 --> Hooks Class Initialized
DEBUG - 2018-09-19 17:10:53 --> UTF-8 Support Enabled
INFO - 2018-09-19 17:10:53 --> Utf8 Class Initialized
INFO - 2018-09-19 17:10:53 --> URI Class Initialized
INFO - 2018-09-19 17:10:53 --> Router Class Initialized
INFO - 2018-09-19 17:10:53 --> Output Class Initialized
INFO - 2018-09-19 17:10:53 --> Security Class Initialized
DEBUG - 2018-09-19 17:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-19 17:10:53 --> CSRF cookie sent
INFO - 2018-09-19 17:10:53 --> CSRF token verified
INFO - 2018-09-19 17:10:53 --> Input Class Initialized
INFO - 2018-09-19 17:10:53 --> Language Class Initialized
INFO - 2018-09-19 17:10:53 --> Loader Class Initialized
INFO - 2018-09-19 17:10:53 --> Helper loaded: url_helper
INFO - 2018-09-19 17:10:53 --> Helper loaded: form_helper
INFO - 2018-09-19 17:10:53 --> Helper loaded: language_helper
DEBUG - 2018-09-19 17:10:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-19 17:10:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-19 17:10:53 --> User Agent Class Initialized
INFO - 2018-09-19 17:10:53 --> Controller Class Initialized
INFO - 2018-09-19 17:10:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-19 17:10:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-19 17:10:53 --> Pixel_Model class loaded
INFO - 2018-09-19 17:10:53 --> Database Driver Class Initialized
INFO - 2018-09-19 17:10:53 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:10:53 --> Database Driver Class Initialized
INFO - 2018-09-19 17:10:53 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:10:53 --> Config Class Initialized
INFO - 2018-09-19 17:10:53 --> Hooks Class Initialized
DEBUG - 2018-09-19 17:10:53 --> UTF-8 Support Enabled
INFO - 2018-09-19 17:10:53 --> Utf8 Class Initialized
INFO - 2018-09-19 17:10:53 --> URI Class Initialized
INFO - 2018-09-19 17:10:53 --> Router Class Initialized
INFO - 2018-09-19 17:10:53 --> Output Class Initialized
INFO - 2018-09-19 17:10:53 --> Security Class Initialized
DEBUG - 2018-09-19 17:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-19 17:10:53 --> CSRF cookie sent
INFO - 2018-09-19 17:10:53 --> Input Class Initialized
INFO - 2018-09-19 17:10:53 --> Language Class Initialized
INFO - 2018-09-19 17:10:53 --> Loader Class Initialized
INFO - 2018-09-19 17:10:53 --> Helper loaded: url_helper
INFO - 2018-09-19 17:10:53 --> Helper loaded: form_helper
INFO - 2018-09-19 17:10:53 --> Helper loaded: language_helper
DEBUG - 2018-09-19 17:10:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-19 17:10:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-19 17:10:53 --> User Agent Class Initialized
INFO - 2018-09-19 17:10:53 --> Controller Class Initialized
INFO - 2018-09-19 17:10:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-19 17:10:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-19 17:10:53 --> Pixel_Model class loaded
INFO - 2018-09-19 17:10:53 --> Database Driver Class Initialized
INFO - 2018-09-19 17:10:53 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:10:53 --> Database Driver Class Initialized
INFO - 2018-09-19 17:10:53 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:10:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-19 17:10:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-19 17:10:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-19 17:10:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-19 17:10:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-19 17:10:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-19 17:10:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-09-19 17:10:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-19 17:10:53 --> Final output sent to browser
DEBUG - 2018-09-19 17:10:53 --> Total execution time: 0.0460
INFO - 2018-09-19 17:10:57 --> Config Class Initialized
INFO - 2018-09-19 17:10:57 --> Hooks Class Initialized
DEBUG - 2018-09-19 17:10:57 --> UTF-8 Support Enabled
INFO - 2018-09-19 17:10:57 --> Utf8 Class Initialized
INFO - 2018-09-19 17:10:57 --> URI Class Initialized
INFO - 2018-09-19 17:10:57 --> Router Class Initialized
INFO - 2018-09-19 17:10:57 --> Output Class Initialized
INFO - 2018-09-19 17:10:57 --> Security Class Initialized
DEBUG - 2018-09-19 17:10:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-19 17:10:57 --> CSRF cookie sent
INFO - 2018-09-19 17:10:57 --> CSRF token verified
INFO - 2018-09-19 17:10:57 --> Input Class Initialized
INFO - 2018-09-19 17:10:57 --> Language Class Initialized
INFO - 2018-09-19 17:10:57 --> Loader Class Initialized
INFO - 2018-09-19 17:10:57 --> Helper loaded: url_helper
INFO - 2018-09-19 17:10:57 --> Helper loaded: form_helper
INFO - 2018-09-19 17:10:57 --> Helper loaded: language_helper
DEBUG - 2018-09-19 17:10:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-19 17:10:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-19 17:10:57 --> User Agent Class Initialized
INFO - 2018-09-19 17:10:57 --> Controller Class Initialized
INFO - 2018-09-19 17:10:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-19 17:10:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-19 17:10:57 --> Pixel_Model class loaded
INFO - 2018-09-19 17:10:57 --> Database Driver Class Initialized
INFO - 2018-09-19 17:10:57 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:10:57 --> Form Validation Class Initialized
INFO - 2018-09-19 17:10:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-19 17:10:57 --> Database Driver Class Initialized
INFO - 2018-09-19 17:10:57 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:10:57 --> Config Class Initialized
INFO - 2018-09-19 17:10:57 --> Hooks Class Initialized
DEBUG - 2018-09-19 17:10:57 --> UTF-8 Support Enabled
INFO - 2018-09-19 17:10:57 --> Utf8 Class Initialized
INFO - 2018-09-19 17:10:57 --> URI Class Initialized
INFO - 2018-09-19 17:10:57 --> Router Class Initialized
INFO - 2018-09-19 17:10:57 --> Output Class Initialized
INFO - 2018-09-19 17:10:57 --> Security Class Initialized
DEBUG - 2018-09-19 17:10:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-19 17:10:57 --> CSRF cookie sent
INFO - 2018-09-19 17:10:57 --> Input Class Initialized
INFO - 2018-09-19 17:10:57 --> Language Class Initialized
INFO - 2018-09-19 17:10:57 --> Loader Class Initialized
INFO - 2018-09-19 17:10:57 --> Helper loaded: url_helper
INFO - 2018-09-19 17:10:57 --> Helper loaded: form_helper
INFO - 2018-09-19 17:10:57 --> Helper loaded: language_helper
DEBUG - 2018-09-19 17:10:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-19 17:10:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-19 17:10:57 --> User Agent Class Initialized
INFO - 2018-09-19 17:10:57 --> Controller Class Initialized
INFO - 2018-09-19 17:10:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-19 17:10:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-19 17:10:57 --> Pixel_Model class loaded
INFO - 2018-09-19 17:10:58 --> Database Driver Class Initialized
INFO - 2018-09-19 17:10:58 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:10:58 --> Database Driver Class Initialized
INFO - 2018-09-19 17:10:58 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:10:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-19 17:10:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-19 17:10:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-19 17:10:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-19 17:10:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-19 17:10:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-19 17:10:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-09-19 17:10:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-19 17:10:58 --> Final output sent to browser
DEBUG - 2018-09-19 17:10:58 --> Total execution time: 0.0481
INFO - 2018-09-19 17:11:06 --> Config Class Initialized
INFO - 2018-09-19 17:11:06 --> Hooks Class Initialized
DEBUG - 2018-09-19 17:11:06 --> UTF-8 Support Enabled
INFO - 2018-09-19 17:11:06 --> Utf8 Class Initialized
INFO - 2018-09-19 17:11:06 --> URI Class Initialized
INFO - 2018-09-19 17:11:06 --> Router Class Initialized
INFO - 2018-09-19 17:11:06 --> Output Class Initialized
INFO - 2018-09-19 17:11:06 --> Security Class Initialized
DEBUG - 2018-09-19 17:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-19 17:11:06 --> CSRF cookie sent
INFO - 2018-09-19 17:11:06 --> Input Class Initialized
INFO - 2018-09-19 17:11:06 --> Language Class Initialized
INFO - 2018-09-19 17:11:06 --> Loader Class Initialized
INFO - 2018-09-19 17:11:06 --> Helper loaded: url_helper
INFO - 2018-09-19 17:11:06 --> Helper loaded: form_helper
INFO - 2018-09-19 17:11:06 --> Helper loaded: language_helper
DEBUG - 2018-09-19 17:11:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-19 17:11:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-19 17:11:07 --> User Agent Class Initialized
INFO - 2018-09-19 17:11:07 --> Controller Class Initialized
INFO - 2018-09-19 17:11:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-19 17:11:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-19 17:11:07 --> Pixel_Model class loaded
INFO - 2018-09-19 17:11:07 --> Database Driver Class Initialized
INFO - 2018-09-19 17:11:07 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:11:07 --> Database Driver Class Initialized
INFO - 2018-09-19 17:11:07 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:11:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-19 17:11:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-19 17:11:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-19 17:11:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-19 17:11:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/save_exit.php
INFO - 2018-09-19 17:11:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-19 17:11:07 --> Final output sent to browser
DEBUG - 2018-09-19 17:11:07 --> Total execution time: 0.0457
INFO - 2018-09-19 17:11:10 --> Config Class Initialized
INFO - 2018-09-19 17:11:10 --> Hooks Class Initialized
DEBUG - 2018-09-19 17:11:10 --> UTF-8 Support Enabled
INFO - 2018-09-19 17:11:10 --> Utf8 Class Initialized
INFO - 2018-09-19 17:11:10 --> URI Class Initialized
INFO - 2018-09-19 17:11:10 --> Router Class Initialized
INFO - 2018-09-19 17:11:10 --> Output Class Initialized
INFO - 2018-09-19 17:11:10 --> Security Class Initialized
DEBUG - 2018-09-19 17:11:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-19 17:11:10 --> CSRF cookie sent
INFO - 2018-09-19 17:11:10 --> Input Class Initialized
INFO - 2018-09-19 17:11:10 --> Language Class Initialized
INFO - 2018-09-19 17:11:10 --> Loader Class Initialized
INFO - 2018-09-19 17:11:10 --> Helper loaded: url_helper
INFO - 2018-09-19 17:11:10 --> Helper loaded: form_helper
INFO - 2018-09-19 17:11:10 --> Helper loaded: language_helper
DEBUG - 2018-09-19 17:11:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-19 17:11:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-19 17:11:10 --> User Agent Class Initialized
INFO - 2018-09-19 17:11:10 --> Controller Class Initialized
INFO - 2018-09-19 17:11:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-19 17:11:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-19 17:11:10 --> Pixel_Model class loaded
INFO - 2018-09-19 17:11:10 --> Database Driver Class Initialized
INFO - 2018-09-19 17:11:10 --> Model "RegistrationModel" initialized
DEBUG - 2018-09-19 17:11:10 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-09-19 17:11:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-19 17:11:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-19 17:11:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-19 17:11:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-09-19 17:11:10 --> Could not find the language line "req_email"
INFO - 2018-09-19 17:11:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup.php
INFO - 2018-09-19 17:11:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-19 17:11:10 --> Final output sent to browser
DEBUG - 2018-09-19 17:11:10 --> Total execution time: 0.0401
INFO - 2018-09-19 17:11:11 --> Config Class Initialized
INFO - 2018-09-19 17:11:11 --> Hooks Class Initialized
DEBUG - 2018-09-19 17:11:11 --> UTF-8 Support Enabled
INFO - 2018-09-19 17:11:11 --> Utf8 Class Initialized
INFO - 2018-09-19 17:11:11 --> URI Class Initialized
INFO - 2018-09-19 17:11:11 --> Router Class Initialized
INFO - 2018-09-19 17:11:11 --> Output Class Initialized
INFO - 2018-09-19 17:11:11 --> Security Class Initialized
DEBUG - 2018-09-19 17:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-19 17:11:11 --> CSRF cookie sent
INFO - 2018-09-19 17:11:11 --> Input Class Initialized
INFO - 2018-09-19 17:11:11 --> Language Class Initialized
INFO - 2018-09-19 17:11:11 --> Loader Class Initialized
INFO - 2018-09-19 17:11:11 --> Helper loaded: url_helper
INFO - 2018-09-19 17:11:11 --> Helper loaded: form_helper
INFO - 2018-09-19 17:11:11 --> Helper loaded: language_helper
DEBUG - 2018-09-19 17:11:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-19 17:11:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-19 17:11:11 --> User Agent Class Initialized
INFO - 2018-09-19 17:11:11 --> Controller Class Initialized
INFO - 2018-09-19 17:11:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-19 17:11:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-19 17:11:11 --> Pixel_Model class loaded
INFO - 2018-09-19 17:11:11 --> Database Driver Class Initialized
INFO - 2018-09-19 17:11:11 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:11:11 --> Database Driver Class Initialized
INFO - 2018-09-19 17:11:11 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:11:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-19 17:11:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-19 17:11:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-19 17:11:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-19 17:11:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/save_exit.php
INFO - 2018-09-19 17:11:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-19 17:11:11 --> Final output sent to browser
DEBUG - 2018-09-19 17:11:11 --> Total execution time: 0.0551
INFO - 2018-09-19 17:11:12 --> Config Class Initialized
INFO - 2018-09-19 17:11:12 --> Hooks Class Initialized
DEBUG - 2018-09-19 17:11:12 --> UTF-8 Support Enabled
INFO - 2018-09-19 17:11:12 --> Utf8 Class Initialized
INFO - 2018-09-19 17:11:12 --> URI Class Initialized
INFO - 2018-09-19 17:11:12 --> Router Class Initialized
INFO - 2018-09-19 17:11:12 --> Output Class Initialized
INFO - 2018-09-19 17:11:12 --> Security Class Initialized
DEBUG - 2018-09-19 17:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-19 17:11:12 --> CSRF cookie sent
INFO - 2018-09-19 17:11:12 --> Input Class Initialized
INFO - 2018-09-19 17:11:12 --> Language Class Initialized
INFO - 2018-09-19 17:11:12 --> Loader Class Initialized
INFO - 2018-09-19 17:11:12 --> Helper loaded: url_helper
INFO - 2018-09-19 17:11:12 --> Helper loaded: form_helper
INFO - 2018-09-19 17:11:12 --> Helper loaded: language_helper
DEBUG - 2018-09-19 17:11:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-19 17:11:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-19 17:11:12 --> User Agent Class Initialized
INFO - 2018-09-19 17:11:12 --> Controller Class Initialized
INFO - 2018-09-19 17:11:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-19 17:11:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-19 17:11:12 --> Pixel_Model class loaded
INFO - 2018-09-19 17:11:12 --> Database Driver Class Initialized
INFO - 2018-09-19 17:11:12 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:11:12 --> Database Driver Class Initialized
INFO - 2018-09-19 17:11:12 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:11:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-19 17:11:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-19 17:11:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-19 17:11:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-19 17:11:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-19 17:11:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-19 17:11:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-09-19 17:11:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-19 17:11:12 --> Final output sent to browser
DEBUG - 2018-09-19 17:11:12 --> Total execution time: 0.0394
INFO - 2018-09-19 17:11:13 --> Config Class Initialized
INFO - 2018-09-19 17:11:13 --> Hooks Class Initialized
DEBUG - 2018-09-19 17:11:13 --> UTF-8 Support Enabled
INFO - 2018-09-19 17:11:13 --> Utf8 Class Initialized
INFO - 2018-09-19 17:11:13 --> URI Class Initialized
INFO - 2018-09-19 17:11:13 --> Router Class Initialized
INFO - 2018-09-19 17:11:13 --> Output Class Initialized
INFO - 2018-09-19 17:11:13 --> Security Class Initialized
DEBUG - 2018-09-19 17:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-19 17:11:13 --> CSRF cookie sent
INFO - 2018-09-19 17:11:13 --> CSRF token verified
INFO - 2018-09-19 17:11:13 --> Input Class Initialized
INFO - 2018-09-19 17:11:13 --> Language Class Initialized
INFO - 2018-09-19 17:11:13 --> Loader Class Initialized
INFO - 2018-09-19 17:11:13 --> Helper loaded: url_helper
INFO - 2018-09-19 17:11:13 --> Helper loaded: form_helper
INFO - 2018-09-19 17:11:13 --> Helper loaded: language_helper
DEBUG - 2018-09-19 17:11:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-19 17:11:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-19 17:11:13 --> User Agent Class Initialized
INFO - 2018-09-19 17:11:13 --> Controller Class Initialized
INFO - 2018-09-19 17:11:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-19 17:11:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-19 17:11:13 --> Pixel_Model class loaded
INFO - 2018-09-19 17:11:13 --> Database Driver Class Initialized
INFO - 2018-09-19 17:11:13 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:11:13 --> Form Validation Class Initialized
INFO - 2018-09-19 17:11:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-19 17:11:13 --> Database Driver Class Initialized
INFO - 2018-09-19 17:11:13 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:11:13 --> Config Class Initialized
INFO - 2018-09-19 17:11:13 --> Hooks Class Initialized
DEBUG - 2018-09-19 17:11:13 --> UTF-8 Support Enabled
INFO - 2018-09-19 17:11:13 --> Utf8 Class Initialized
INFO - 2018-09-19 17:11:13 --> URI Class Initialized
INFO - 2018-09-19 17:11:13 --> Router Class Initialized
INFO - 2018-09-19 17:11:13 --> Output Class Initialized
INFO - 2018-09-19 17:11:13 --> Security Class Initialized
DEBUG - 2018-09-19 17:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-19 17:11:13 --> CSRF cookie sent
INFO - 2018-09-19 17:11:13 --> Input Class Initialized
INFO - 2018-09-19 17:11:13 --> Language Class Initialized
INFO - 2018-09-19 17:11:13 --> Loader Class Initialized
INFO - 2018-09-19 17:11:13 --> Helper loaded: url_helper
INFO - 2018-09-19 17:11:13 --> Helper loaded: form_helper
INFO - 2018-09-19 17:11:13 --> Helper loaded: language_helper
DEBUG - 2018-09-19 17:11:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-19 17:11:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-19 17:11:13 --> User Agent Class Initialized
INFO - 2018-09-19 17:11:13 --> Controller Class Initialized
INFO - 2018-09-19 17:11:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-19 17:11:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-19 17:11:13 --> Pixel_Model class loaded
INFO - 2018-09-19 17:11:13 --> Database Driver Class Initialized
INFO - 2018-09-19 17:11:13 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:11:13 --> Database Driver Class Initialized
INFO - 2018-09-19 17:11:13 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:11:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-19 17:11:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-19 17:11:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-09-19 17:11:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-19 17:11:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-19 17:11:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-19 17:11:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-19 17:11:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-09-19 17:11:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-19 17:11:13 --> Final output sent to browser
DEBUG - 2018-09-19 17:11:13 --> Total execution time: 0.0345
INFO - 2018-09-19 17:11:17 --> Config Class Initialized
INFO - 2018-09-19 17:11:17 --> Hooks Class Initialized
DEBUG - 2018-09-19 17:11:17 --> UTF-8 Support Enabled
INFO - 2018-09-19 17:11:17 --> Utf8 Class Initialized
INFO - 2018-09-19 17:11:17 --> URI Class Initialized
INFO - 2018-09-19 17:11:17 --> Router Class Initialized
INFO - 2018-09-19 17:11:17 --> Output Class Initialized
INFO - 2018-09-19 17:11:17 --> Security Class Initialized
DEBUG - 2018-09-19 17:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-19 17:11:17 --> CSRF cookie sent
INFO - 2018-09-19 17:11:17 --> CSRF token verified
INFO - 2018-09-19 17:11:17 --> Input Class Initialized
INFO - 2018-09-19 17:11:17 --> Language Class Initialized
INFO - 2018-09-19 17:11:17 --> Loader Class Initialized
INFO - 2018-09-19 17:11:17 --> Helper loaded: url_helper
INFO - 2018-09-19 17:11:17 --> Helper loaded: form_helper
INFO - 2018-09-19 17:11:17 --> Helper loaded: language_helper
DEBUG - 2018-09-19 17:11:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-19 17:11:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-19 17:11:17 --> User Agent Class Initialized
INFO - 2018-09-19 17:11:17 --> Controller Class Initialized
INFO - 2018-09-19 17:11:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-19 17:11:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-19 17:11:17 --> Pixel_Model class loaded
INFO - 2018-09-19 17:11:17 --> Database Driver Class Initialized
INFO - 2018-09-19 17:11:17 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:11:17 --> Form Validation Class Initialized
INFO - 2018-09-19 17:11:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-19 17:11:17 --> Database Driver Class Initialized
INFO - 2018-09-19 17:11:17 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:11:18 --> Config Class Initialized
INFO - 2018-09-19 17:11:18 --> Hooks Class Initialized
DEBUG - 2018-09-19 17:11:18 --> UTF-8 Support Enabled
INFO - 2018-09-19 17:11:18 --> Utf8 Class Initialized
INFO - 2018-09-19 17:11:18 --> URI Class Initialized
INFO - 2018-09-19 17:11:18 --> Router Class Initialized
INFO - 2018-09-19 17:11:18 --> Output Class Initialized
INFO - 2018-09-19 17:11:18 --> Security Class Initialized
DEBUG - 2018-09-19 17:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-19 17:11:18 --> CSRF cookie sent
INFO - 2018-09-19 17:11:18 --> Input Class Initialized
INFO - 2018-09-19 17:11:18 --> Language Class Initialized
INFO - 2018-09-19 17:11:18 --> Loader Class Initialized
INFO - 2018-09-19 17:11:18 --> Helper loaded: url_helper
INFO - 2018-09-19 17:11:18 --> Helper loaded: form_helper
INFO - 2018-09-19 17:11:18 --> Helper loaded: language_helper
DEBUG - 2018-09-19 17:11:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-19 17:11:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-19 17:11:18 --> User Agent Class Initialized
INFO - 2018-09-19 17:11:18 --> Controller Class Initialized
INFO - 2018-09-19 17:11:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-19 17:11:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-19 17:11:18 --> Pixel_Model class loaded
INFO - 2018-09-19 17:11:18 --> Database Driver Class Initialized
INFO - 2018-09-19 17:11:18 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:11:18 --> Database Driver Class Initialized
INFO - 2018-09-19 17:11:18 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:11:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-19 17:11:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-19 17:11:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-19 17:11:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-19 17:11:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-19 17:11:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-19 17:11:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-09-19 17:11:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-19 17:11:18 --> Final output sent to browser
DEBUG - 2018-09-19 17:11:18 --> Total execution time: 0.0396
INFO - 2018-09-19 17:11:28 --> Config Class Initialized
INFO - 2018-09-19 17:11:28 --> Hooks Class Initialized
DEBUG - 2018-09-19 17:11:28 --> UTF-8 Support Enabled
INFO - 2018-09-19 17:11:28 --> Utf8 Class Initialized
INFO - 2018-09-19 17:11:28 --> URI Class Initialized
INFO - 2018-09-19 17:11:28 --> Router Class Initialized
INFO - 2018-09-19 17:11:28 --> Output Class Initialized
INFO - 2018-09-19 17:11:28 --> Security Class Initialized
DEBUG - 2018-09-19 17:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-19 17:11:28 --> CSRF cookie sent
INFO - 2018-09-19 17:11:28 --> CSRF token verified
INFO - 2018-09-19 17:11:28 --> Input Class Initialized
INFO - 2018-09-19 17:11:28 --> Language Class Initialized
INFO - 2018-09-19 17:11:28 --> Loader Class Initialized
INFO - 2018-09-19 17:11:28 --> Helper loaded: url_helper
INFO - 2018-09-19 17:11:28 --> Helper loaded: form_helper
INFO - 2018-09-19 17:11:28 --> Helper loaded: language_helper
DEBUG - 2018-09-19 17:11:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-19 17:11:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-19 17:11:28 --> User Agent Class Initialized
INFO - 2018-09-19 17:11:28 --> Controller Class Initialized
INFO - 2018-09-19 17:11:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-19 17:11:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-19 17:11:28 --> Pixel_Model class loaded
INFO - 2018-09-19 17:11:28 --> Database Driver Class Initialized
INFO - 2018-09-19 17:11:28 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:11:28 --> Form Validation Class Initialized
INFO - 2018-09-19 17:11:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-19 17:11:28 --> Database Driver Class Initialized
INFO - 2018-09-19 17:11:28 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:11:28 --> Config Class Initialized
INFO - 2018-09-19 17:11:28 --> Hooks Class Initialized
DEBUG - 2018-09-19 17:11:28 --> UTF-8 Support Enabled
INFO - 2018-09-19 17:11:28 --> Utf8 Class Initialized
INFO - 2018-09-19 17:11:28 --> URI Class Initialized
INFO - 2018-09-19 17:11:28 --> Router Class Initialized
INFO - 2018-09-19 17:11:28 --> Output Class Initialized
INFO - 2018-09-19 17:11:28 --> Security Class Initialized
DEBUG - 2018-09-19 17:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-19 17:11:28 --> CSRF cookie sent
INFO - 2018-09-19 17:11:28 --> Input Class Initialized
INFO - 2018-09-19 17:11:28 --> Language Class Initialized
INFO - 2018-09-19 17:11:28 --> Loader Class Initialized
INFO - 2018-09-19 17:11:28 --> Helper loaded: url_helper
INFO - 2018-09-19 17:11:28 --> Helper loaded: form_helper
INFO - 2018-09-19 17:11:28 --> Helper loaded: language_helper
DEBUG - 2018-09-19 17:11:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-19 17:11:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-19 17:11:28 --> User Agent Class Initialized
INFO - 2018-09-19 17:11:28 --> Controller Class Initialized
INFO - 2018-09-19 17:11:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-19 17:11:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-19 17:11:28 --> Pixel_Model class loaded
INFO - 2018-09-19 17:11:28 --> Database Driver Class Initialized
INFO - 2018-09-19 17:11:28 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:11:28 --> Database Driver Class Initialized
INFO - 2018-09-19 17:11:28 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:11:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-19 17:11:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-19 17:11:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-19 17:11:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-19 17:11:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-19 17:11:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-19 17:11:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/marriage.php
INFO - 2018-09-19 17:11:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-19 17:11:28 --> Final output sent to browser
DEBUG - 2018-09-19 17:11:28 --> Total execution time: 0.0487
INFO - 2018-09-19 17:11:42 --> Config Class Initialized
INFO - 2018-09-19 17:11:42 --> Hooks Class Initialized
DEBUG - 2018-09-19 17:11:42 --> UTF-8 Support Enabled
INFO - 2018-09-19 17:11:42 --> Utf8 Class Initialized
INFO - 2018-09-19 17:11:42 --> URI Class Initialized
INFO - 2018-09-19 17:11:42 --> Router Class Initialized
INFO - 2018-09-19 17:11:42 --> Output Class Initialized
INFO - 2018-09-19 17:11:42 --> Security Class Initialized
DEBUG - 2018-09-19 17:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-19 17:11:42 --> CSRF cookie sent
INFO - 2018-09-19 17:11:42 --> CSRF token verified
INFO - 2018-09-19 17:11:42 --> Input Class Initialized
INFO - 2018-09-19 17:11:42 --> Language Class Initialized
INFO - 2018-09-19 17:11:42 --> Loader Class Initialized
INFO - 2018-09-19 17:11:42 --> Helper loaded: url_helper
INFO - 2018-09-19 17:11:42 --> Helper loaded: form_helper
INFO - 2018-09-19 17:11:42 --> Helper loaded: language_helper
DEBUG - 2018-09-19 17:11:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-19 17:11:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-19 17:11:42 --> User Agent Class Initialized
INFO - 2018-09-19 17:11:42 --> Controller Class Initialized
INFO - 2018-09-19 17:11:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-19 17:11:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-19 17:11:42 --> Pixel_Model class loaded
INFO - 2018-09-19 17:11:42 --> Database Driver Class Initialized
INFO - 2018-09-19 17:11:42 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:11:42 --> Form Validation Class Initialized
INFO - 2018-09-19 17:11:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-19 17:11:42 --> Database Driver Class Initialized
INFO - 2018-09-19 17:11:42 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:11:42 --> Config Class Initialized
INFO - 2018-09-19 17:11:42 --> Hooks Class Initialized
DEBUG - 2018-09-19 17:11:42 --> UTF-8 Support Enabled
INFO - 2018-09-19 17:11:42 --> Utf8 Class Initialized
INFO - 2018-09-19 17:11:42 --> URI Class Initialized
INFO - 2018-09-19 17:11:42 --> Router Class Initialized
INFO - 2018-09-19 17:11:42 --> Output Class Initialized
INFO - 2018-09-19 17:11:42 --> Security Class Initialized
DEBUG - 2018-09-19 17:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-19 17:11:42 --> CSRF cookie sent
INFO - 2018-09-19 17:11:42 --> Input Class Initialized
INFO - 2018-09-19 17:11:42 --> Language Class Initialized
INFO - 2018-09-19 17:11:42 --> Loader Class Initialized
INFO - 2018-09-19 17:11:42 --> Helper loaded: url_helper
INFO - 2018-09-19 17:11:42 --> Helper loaded: form_helper
INFO - 2018-09-19 17:11:42 --> Helper loaded: language_helper
DEBUG - 2018-09-19 17:11:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-19 17:11:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-19 17:11:42 --> User Agent Class Initialized
INFO - 2018-09-19 17:11:42 --> Controller Class Initialized
INFO - 2018-09-19 17:11:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-19 17:11:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-19 17:11:42 --> Pixel_Model class loaded
INFO - 2018-09-19 17:11:42 --> Database Driver Class Initialized
INFO - 2018-09-19 17:11:42 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:11:42 --> Database Driver Class Initialized
INFO - 2018-09-19 17:11:42 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:11:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-19 17:11:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-19 17:11:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-19 17:11:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-19 17:11:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-19 17:11:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-19 17:11:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-09-19 17:11:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-19 17:11:42 --> Final output sent to browser
DEBUG - 2018-09-19 17:11:42 --> Total execution time: 0.0528
INFO - 2018-09-19 17:12:00 --> Config Class Initialized
INFO - 2018-09-19 17:12:00 --> Hooks Class Initialized
DEBUG - 2018-09-19 17:12:00 --> UTF-8 Support Enabled
INFO - 2018-09-19 17:12:00 --> Utf8 Class Initialized
INFO - 2018-09-19 17:12:00 --> URI Class Initialized
INFO - 2018-09-19 17:12:00 --> Router Class Initialized
INFO - 2018-09-19 17:12:00 --> Output Class Initialized
INFO - 2018-09-19 17:12:00 --> Security Class Initialized
DEBUG - 2018-09-19 17:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-19 17:12:00 --> CSRF cookie sent
INFO - 2018-09-19 17:12:00 --> CSRF token verified
INFO - 2018-09-19 17:12:00 --> Input Class Initialized
INFO - 2018-09-19 17:12:00 --> Language Class Initialized
INFO - 2018-09-19 17:12:00 --> Loader Class Initialized
INFO - 2018-09-19 17:12:00 --> Helper loaded: url_helper
INFO - 2018-09-19 17:12:00 --> Helper loaded: form_helper
INFO - 2018-09-19 17:12:00 --> Helper loaded: language_helper
DEBUG - 2018-09-19 17:12:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-19 17:12:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-19 17:12:00 --> User Agent Class Initialized
INFO - 2018-09-19 17:12:00 --> Controller Class Initialized
INFO - 2018-09-19 17:12:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-19 17:12:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-19 17:12:00 --> Pixel_Model class loaded
INFO - 2018-09-19 17:12:00 --> Database Driver Class Initialized
INFO - 2018-09-19 17:12:00 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:12:00 --> Form Validation Class Initialized
INFO - 2018-09-19 17:12:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-19 17:12:00 --> Database Driver Class Initialized
INFO - 2018-09-19 17:12:00 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:12:00 --> Config Class Initialized
INFO - 2018-09-19 17:12:00 --> Hooks Class Initialized
DEBUG - 2018-09-19 17:12:00 --> UTF-8 Support Enabled
INFO - 2018-09-19 17:12:00 --> Utf8 Class Initialized
INFO - 2018-09-19 17:12:00 --> URI Class Initialized
INFO - 2018-09-19 17:12:00 --> Router Class Initialized
INFO - 2018-09-19 17:12:00 --> Output Class Initialized
INFO - 2018-09-19 17:12:00 --> Security Class Initialized
DEBUG - 2018-09-19 17:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-19 17:12:00 --> CSRF cookie sent
INFO - 2018-09-19 17:12:00 --> Input Class Initialized
INFO - 2018-09-19 17:12:00 --> Language Class Initialized
INFO - 2018-09-19 17:12:00 --> Loader Class Initialized
INFO - 2018-09-19 17:12:00 --> Helper loaded: url_helper
INFO - 2018-09-19 17:12:00 --> Helper loaded: form_helper
INFO - 2018-09-19 17:12:00 --> Helper loaded: language_helper
DEBUG - 2018-09-19 17:12:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-19 17:12:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-19 17:12:00 --> User Agent Class Initialized
INFO - 2018-09-19 17:12:00 --> Controller Class Initialized
INFO - 2018-09-19 17:12:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-19 17:12:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-19 17:12:00 --> Pixel_Model class loaded
INFO - 2018-09-19 17:12:00 --> Database Driver Class Initialized
INFO - 2018-09-19 17:12:00 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:12:00 --> Database Driver Class Initialized
INFO - 2018-09-19 17:12:00 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:12:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-19 17:12:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-19 17:12:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-19 17:12:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-19 17:12:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-19 17:12:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-19 17:12:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-09-19 17:12:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-19 17:12:00 --> Final output sent to browser
DEBUG - 2018-09-19 17:12:00 --> Total execution time: 0.0454
INFO - 2018-09-19 17:12:14 --> Config Class Initialized
INFO - 2018-09-19 17:12:14 --> Hooks Class Initialized
DEBUG - 2018-09-19 17:12:14 --> UTF-8 Support Enabled
INFO - 2018-09-19 17:12:14 --> Utf8 Class Initialized
INFO - 2018-09-19 17:12:14 --> URI Class Initialized
INFO - 2018-09-19 17:12:14 --> Router Class Initialized
INFO - 2018-09-19 17:12:14 --> Output Class Initialized
INFO - 2018-09-19 17:12:14 --> Security Class Initialized
DEBUG - 2018-09-19 17:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-19 17:12:14 --> CSRF cookie sent
INFO - 2018-09-19 17:12:14 --> CSRF token verified
INFO - 2018-09-19 17:12:14 --> Input Class Initialized
INFO - 2018-09-19 17:12:14 --> Language Class Initialized
INFO - 2018-09-19 17:12:14 --> Loader Class Initialized
INFO - 2018-09-19 17:12:14 --> Helper loaded: url_helper
INFO - 2018-09-19 17:12:14 --> Helper loaded: form_helper
INFO - 2018-09-19 17:12:14 --> Helper loaded: language_helper
DEBUG - 2018-09-19 17:12:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-19 17:12:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-19 17:12:14 --> User Agent Class Initialized
INFO - 2018-09-19 17:12:14 --> Controller Class Initialized
INFO - 2018-09-19 17:12:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-19 17:12:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-19 17:12:14 --> Pixel_Model class loaded
INFO - 2018-09-19 17:12:14 --> Database Driver Class Initialized
INFO - 2018-09-19 17:12:14 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:12:14 --> Form Validation Class Initialized
INFO - 2018-09-19 17:12:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-19 17:12:14 --> Database Driver Class Initialized
INFO - 2018-09-19 17:12:14 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:12:14 --> Config Class Initialized
INFO - 2018-09-19 17:12:14 --> Hooks Class Initialized
DEBUG - 2018-09-19 17:12:14 --> UTF-8 Support Enabled
INFO - 2018-09-19 17:12:14 --> Utf8 Class Initialized
INFO - 2018-09-19 17:12:14 --> URI Class Initialized
INFO - 2018-09-19 17:12:14 --> Router Class Initialized
INFO - 2018-09-19 17:12:14 --> Output Class Initialized
INFO - 2018-09-19 17:12:14 --> Security Class Initialized
DEBUG - 2018-09-19 17:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-19 17:12:14 --> CSRF cookie sent
INFO - 2018-09-19 17:12:14 --> Input Class Initialized
INFO - 2018-09-19 17:12:14 --> Language Class Initialized
INFO - 2018-09-19 17:12:14 --> Loader Class Initialized
INFO - 2018-09-19 17:12:14 --> Helper loaded: url_helper
INFO - 2018-09-19 17:12:14 --> Helper loaded: form_helper
INFO - 2018-09-19 17:12:14 --> Helper loaded: language_helper
DEBUG - 2018-09-19 17:12:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-19 17:12:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-19 17:12:14 --> User Agent Class Initialized
INFO - 2018-09-19 17:12:14 --> Controller Class Initialized
INFO - 2018-09-19 17:12:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-19 17:12:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-19 17:12:14 --> Pixel_Model class loaded
INFO - 2018-09-19 17:12:14 --> Database Driver Class Initialized
INFO - 2018-09-19 17:12:14 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:12:14 --> Database Driver Class Initialized
INFO - 2018-09-19 17:12:14 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:12:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-19 17:12:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-19 17:12:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-19 17:12:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-19 17:12:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-19 17:12:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-19 17:12:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-09-19 17:12:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-19 17:12:14 --> Final output sent to browser
DEBUG - 2018-09-19 17:12:14 --> Total execution time: 0.0488
INFO - 2018-09-19 17:12:37 --> Config Class Initialized
INFO - 2018-09-19 17:12:37 --> Hooks Class Initialized
DEBUG - 2018-09-19 17:12:37 --> UTF-8 Support Enabled
INFO - 2018-09-19 17:12:37 --> Utf8 Class Initialized
INFO - 2018-09-19 17:12:37 --> URI Class Initialized
INFO - 2018-09-19 17:12:37 --> Router Class Initialized
INFO - 2018-09-19 17:12:37 --> Output Class Initialized
INFO - 2018-09-19 17:12:37 --> Security Class Initialized
DEBUG - 2018-09-19 17:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-19 17:12:37 --> CSRF cookie sent
INFO - 2018-09-19 17:12:37 --> CSRF token verified
INFO - 2018-09-19 17:12:37 --> Input Class Initialized
INFO - 2018-09-19 17:12:37 --> Language Class Initialized
INFO - 2018-09-19 17:12:37 --> Loader Class Initialized
INFO - 2018-09-19 17:12:37 --> Helper loaded: url_helper
INFO - 2018-09-19 17:12:37 --> Helper loaded: form_helper
INFO - 2018-09-19 17:12:37 --> Helper loaded: language_helper
DEBUG - 2018-09-19 17:12:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-19 17:12:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-19 17:12:37 --> User Agent Class Initialized
INFO - 2018-09-19 17:12:37 --> Controller Class Initialized
INFO - 2018-09-19 17:12:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-19 17:12:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-19 17:12:37 --> Pixel_Model class loaded
INFO - 2018-09-19 17:12:37 --> Database Driver Class Initialized
INFO - 2018-09-19 17:12:37 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:12:37 --> Form Validation Class Initialized
INFO - 2018-09-19 17:12:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-19 17:12:37 --> Database Driver Class Initialized
INFO - 2018-09-19 17:12:37 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:12:37 --> Config Class Initialized
INFO - 2018-09-19 17:12:37 --> Hooks Class Initialized
DEBUG - 2018-09-19 17:12:37 --> UTF-8 Support Enabled
INFO - 2018-09-19 17:12:37 --> Utf8 Class Initialized
INFO - 2018-09-19 17:12:37 --> URI Class Initialized
INFO - 2018-09-19 17:12:37 --> Router Class Initialized
INFO - 2018-09-19 17:12:37 --> Output Class Initialized
INFO - 2018-09-19 17:12:37 --> Security Class Initialized
DEBUG - 2018-09-19 17:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-19 17:12:37 --> CSRF cookie sent
INFO - 2018-09-19 17:12:37 --> Input Class Initialized
INFO - 2018-09-19 17:12:37 --> Language Class Initialized
INFO - 2018-09-19 17:12:37 --> Loader Class Initialized
INFO - 2018-09-19 17:12:37 --> Helper loaded: url_helper
INFO - 2018-09-19 17:12:37 --> Helper loaded: form_helper
INFO - 2018-09-19 17:12:37 --> Helper loaded: language_helper
DEBUG - 2018-09-19 17:12:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-19 17:12:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-19 17:12:37 --> User Agent Class Initialized
INFO - 2018-09-19 17:12:37 --> Controller Class Initialized
INFO - 2018-09-19 17:12:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-19 17:12:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-19 17:12:37 --> Pixel_Model class loaded
INFO - 2018-09-19 17:12:37 --> Database Driver Class Initialized
INFO - 2018-09-19 17:12:37 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:12:37 --> Database Driver Class Initialized
INFO - 2018-09-19 17:12:37 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:12:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-19 17:12:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-19 17:12:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-19 17:12:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-19 17:12:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-19 17:12:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-19 17:12:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-09-19 17:12:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-19 17:12:37 --> Final output sent to browser
DEBUG - 2018-09-19 17:12:37 --> Total execution time: 0.0381
INFO - 2018-09-19 17:12:53 --> Config Class Initialized
INFO - 2018-09-19 17:12:53 --> Hooks Class Initialized
DEBUG - 2018-09-19 17:12:53 --> UTF-8 Support Enabled
INFO - 2018-09-19 17:12:53 --> Utf8 Class Initialized
INFO - 2018-09-19 17:12:53 --> URI Class Initialized
INFO - 2018-09-19 17:12:53 --> Router Class Initialized
INFO - 2018-09-19 17:12:53 --> Output Class Initialized
INFO - 2018-09-19 17:12:53 --> Security Class Initialized
DEBUG - 2018-09-19 17:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-19 17:12:53 --> CSRF cookie sent
INFO - 2018-09-19 17:12:53 --> CSRF token verified
INFO - 2018-09-19 17:12:53 --> Input Class Initialized
INFO - 2018-09-19 17:12:53 --> Language Class Initialized
INFO - 2018-09-19 17:12:53 --> Loader Class Initialized
INFO - 2018-09-19 17:12:53 --> Helper loaded: url_helper
INFO - 2018-09-19 17:12:53 --> Helper loaded: form_helper
INFO - 2018-09-19 17:12:53 --> Helper loaded: language_helper
DEBUG - 2018-09-19 17:12:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-19 17:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-19 17:12:53 --> User Agent Class Initialized
INFO - 2018-09-19 17:12:53 --> Controller Class Initialized
INFO - 2018-09-19 17:12:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-19 17:12:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-19 17:12:53 --> Pixel_Model class loaded
INFO - 2018-09-19 17:12:53 --> Database Driver Class Initialized
INFO - 2018-09-19 17:12:53 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:12:53 --> Form Validation Class Initialized
INFO - 2018-09-19 17:12:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-19 17:12:53 --> Database Driver Class Initialized
INFO - 2018-09-19 17:12:53 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:12:53 --> Config Class Initialized
INFO - 2018-09-19 17:12:53 --> Hooks Class Initialized
DEBUG - 2018-09-19 17:12:53 --> UTF-8 Support Enabled
INFO - 2018-09-19 17:12:53 --> Utf8 Class Initialized
INFO - 2018-09-19 17:12:53 --> URI Class Initialized
INFO - 2018-09-19 17:12:53 --> Router Class Initialized
INFO - 2018-09-19 17:12:53 --> Output Class Initialized
INFO - 2018-09-19 17:12:53 --> Security Class Initialized
DEBUG - 2018-09-19 17:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-19 17:12:53 --> CSRF cookie sent
INFO - 2018-09-19 17:12:53 --> Input Class Initialized
INFO - 2018-09-19 17:12:53 --> Language Class Initialized
INFO - 2018-09-19 17:12:53 --> Loader Class Initialized
INFO - 2018-09-19 17:12:53 --> Helper loaded: url_helper
INFO - 2018-09-19 17:12:53 --> Helper loaded: form_helper
INFO - 2018-09-19 17:12:53 --> Helper loaded: language_helper
DEBUG - 2018-09-19 17:12:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-19 17:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-19 17:12:53 --> User Agent Class Initialized
INFO - 2018-09-19 17:12:53 --> Controller Class Initialized
INFO - 2018-09-19 17:12:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-19 17:12:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-19 17:12:53 --> Pixel_Model class loaded
INFO - 2018-09-19 17:12:53 --> Database Driver Class Initialized
INFO - 2018-09-19 17:12:53 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:12:53 --> Database Driver Class Initialized
INFO - 2018-09-19 17:12:53 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:12:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-19 17:12:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-19 17:12:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-19 17:12:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-19 17:12:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-19 17:12:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-19 17:12:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_owner.php
INFO - 2018-09-19 17:12:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-19 17:12:53 --> Final output sent to browser
DEBUG - 2018-09-19 17:12:53 --> Total execution time: 0.0444
INFO - 2018-09-19 17:12:57 --> Config Class Initialized
INFO - 2018-09-19 17:12:57 --> Hooks Class Initialized
DEBUG - 2018-09-19 17:12:57 --> UTF-8 Support Enabled
INFO - 2018-09-19 17:12:57 --> Utf8 Class Initialized
INFO - 2018-09-19 17:12:57 --> URI Class Initialized
INFO - 2018-09-19 17:12:57 --> Router Class Initialized
INFO - 2018-09-19 17:12:57 --> Output Class Initialized
INFO - 2018-09-19 17:12:57 --> Security Class Initialized
DEBUG - 2018-09-19 17:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-19 17:12:57 --> CSRF cookie sent
INFO - 2018-09-19 17:12:57 --> Input Class Initialized
INFO - 2018-09-19 17:12:57 --> Language Class Initialized
INFO - 2018-09-19 17:12:57 --> Loader Class Initialized
INFO - 2018-09-19 17:12:57 --> Helper loaded: url_helper
INFO - 2018-09-19 17:12:57 --> Helper loaded: form_helper
INFO - 2018-09-19 17:12:57 --> Helper loaded: language_helper
DEBUG - 2018-09-19 17:12:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-19 17:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-19 17:12:57 --> User Agent Class Initialized
INFO - 2018-09-19 17:12:57 --> Controller Class Initialized
INFO - 2018-09-19 17:12:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-19 17:12:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-19 17:12:57 --> Pixel_Model class loaded
INFO - 2018-09-19 17:12:57 --> Database Driver Class Initialized
INFO - 2018-09-19 17:12:57 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:12:57 --> Database Driver Class Initialized
INFO - 2018-09-19 17:12:57 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:12:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-19 17:12:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-19 17:12:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-19 17:12:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-19 17:12:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-09-19 17:12:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-19 17:12:57 --> Final output sent to browser
DEBUG - 2018-09-19 17:12:57 --> Total execution time: 0.0450
INFO - 2018-09-19 17:13:14 --> Config Class Initialized
INFO - 2018-09-19 17:13:14 --> Hooks Class Initialized
DEBUG - 2018-09-19 17:13:14 --> UTF-8 Support Enabled
INFO - 2018-09-19 17:13:14 --> Utf8 Class Initialized
INFO - 2018-09-19 17:13:14 --> URI Class Initialized
INFO - 2018-09-19 17:13:14 --> Router Class Initialized
INFO - 2018-09-19 17:13:14 --> Output Class Initialized
INFO - 2018-09-19 17:13:14 --> Security Class Initialized
DEBUG - 2018-09-19 17:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-19 17:13:14 --> CSRF cookie sent
INFO - 2018-09-19 17:13:14 --> Input Class Initialized
INFO - 2018-09-19 17:13:14 --> Language Class Initialized
INFO - 2018-09-19 17:13:14 --> Loader Class Initialized
INFO - 2018-09-19 17:13:14 --> Helper loaded: url_helper
INFO - 2018-09-19 17:13:14 --> Helper loaded: form_helper
INFO - 2018-09-19 17:13:14 --> Helper loaded: language_helper
DEBUG - 2018-09-19 17:13:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-19 17:13:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-19 17:13:14 --> User Agent Class Initialized
INFO - 2018-09-19 17:13:14 --> Controller Class Initialized
INFO - 2018-09-19 17:13:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-19 17:13:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-19 17:13:14 --> Pixel_Model class loaded
INFO - 2018-09-19 17:13:14 --> Database Driver Class Initialized
INFO - 2018-09-19 17:13:14 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:13:14 --> Database Driver Class Initialized
INFO - 2018-09-19 17:13:14 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:13:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-19 17:13:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-19 17:13:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-19 17:13:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-19 17:13:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-19 17:13:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-19 17:13:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_owner.php
INFO - 2018-09-19 17:13:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-19 17:13:14 --> Final output sent to browser
DEBUG - 2018-09-19 17:13:14 --> Total execution time: 0.0487
INFO - 2018-09-19 17:13:16 --> Config Class Initialized
INFO - 2018-09-19 17:13:16 --> Hooks Class Initialized
DEBUG - 2018-09-19 17:13:16 --> UTF-8 Support Enabled
INFO - 2018-09-19 17:13:16 --> Utf8 Class Initialized
INFO - 2018-09-19 17:13:16 --> URI Class Initialized
INFO - 2018-09-19 17:13:16 --> Router Class Initialized
INFO - 2018-09-19 17:13:16 --> Output Class Initialized
INFO - 2018-09-19 17:13:16 --> Security Class Initialized
DEBUG - 2018-09-19 17:13:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-19 17:13:16 --> CSRF cookie sent
INFO - 2018-09-19 17:13:16 --> CSRF token verified
INFO - 2018-09-19 17:13:16 --> Input Class Initialized
INFO - 2018-09-19 17:13:16 --> Language Class Initialized
INFO - 2018-09-19 17:13:16 --> Loader Class Initialized
INFO - 2018-09-19 17:13:16 --> Helper loaded: url_helper
INFO - 2018-09-19 17:13:16 --> Helper loaded: form_helper
INFO - 2018-09-19 17:13:16 --> Helper loaded: language_helper
DEBUG - 2018-09-19 17:13:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-19 17:13:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-19 17:13:16 --> User Agent Class Initialized
INFO - 2018-09-19 17:13:16 --> Controller Class Initialized
INFO - 2018-09-19 17:13:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-19 17:13:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-19 17:13:16 --> Pixel_Model class loaded
INFO - 2018-09-19 17:13:16 --> Database Driver Class Initialized
INFO - 2018-09-19 17:13:16 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:13:16 --> Form Validation Class Initialized
INFO - 2018-09-19 17:13:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-19 17:13:16 --> Database Driver Class Initialized
INFO - 2018-09-19 17:13:16 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:13:16 --> Config Class Initialized
INFO - 2018-09-19 17:13:16 --> Hooks Class Initialized
DEBUG - 2018-09-19 17:13:16 --> UTF-8 Support Enabled
INFO - 2018-09-19 17:13:16 --> Utf8 Class Initialized
INFO - 2018-09-19 17:13:16 --> URI Class Initialized
INFO - 2018-09-19 17:13:16 --> Router Class Initialized
INFO - 2018-09-19 17:13:16 --> Output Class Initialized
INFO - 2018-09-19 17:13:16 --> Security Class Initialized
DEBUG - 2018-09-19 17:13:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-19 17:13:16 --> CSRF cookie sent
INFO - 2018-09-19 17:13:16 --> Input Class Initialized
INFO - 2018-09-19 17:13:16 --> Language Class Initialized
INFO - 2018-09-19 17:13:16 --> Loader Class Initialized
INFO - 2018-09-19 17:13:16 --> Helper loaded: url_helper
INFO - 2018-09-19 17:13:16 --> Helper loaded: form_helper
INFO - 2018-09-19 17:13:16 --> Helper loaded: language_helper
DEBUG - 2018-09-19 17:13:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-19 17:13:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-19 17:13:16 --> User Agent Class Initialized
INFO - 2018-09-19 17:13:16 --> Controller Class Initialized
INFO - 2018-09-19 17:13:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-19 17:13:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-19 17:13:16 --> Pixel_Model class loaded
INFO - 2018-09-19 17:13:16 --> Database Driver Class Initialized
INFO - 2018-09-19 17:13:16 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:13:16 --> Database Driver Class Initialized
INFO - 2018-09-19 17:13:16 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:13:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-19 17:13:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-19 17:13:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-19 17:13:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-19 17:13:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-19 17:13:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-19 17:13:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_value.php
INFO - 2018-09-19 17:13:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-19 17:13:16 --> Final output sent to browser
DEBUG - 2018-09-19 17:13:16 --> Total execution time: 0.0432
INFO - 2018-09-19 17:14:09 --> Config Class Initialized
INFO - 2018-09-19 17:14:09 --> Hooks Class Initialized
DEBUG - 2018-09-19 17:14:09 --> UTF-8 Support Enabled
INFO - 2018-09-19 17:14:09 --> Utf8 Class Initialized
INFO - 2018-09-19 17:14:09 --> URI Class Initialized
INFO - 2018-09-19 17:14:09 --> Router Class Initialized
INFO - 2018-09-19 17:14:09 --> Output Class Initialized
INFO - 2018-09-19 17:14:09 --> Security Class Initialized
DEBUG - 2018-09-19 17:14:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-19 17:14:09 --> CSRF cookie sent
INFO - 2018-09-19 17:14:09 --> CSRF token verified
INFO - 2018-09-19 17:14:09 --> Input Class Initialized
INFO - 2018-09-19 17:14:09 --> Language Class Initialized
INFO - 2018-09-19 17:14:09 --> Loader Class Initialized
INFO - 2018-09-19 17:14:09 --> Helper loaded: url_helper
INFO - 2018-09-19 17:14:09 --> Helper loaded: form_helper
INFO - 2018-09-19 17:14:09 --> Helper loaded: language_helper
DEBUG - 2018-09-19 17:14:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-19 17:14:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-19 17:14:09 --> User Agent Class Initialized
INFO - 2018-09-19 17:14:09 --> Controller Class Initialized
INFO - 2018-09-19 17:14:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-19 17:14:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-19 17:14:09 --> Pixel_Model class loaded
INFO - 2018-09-19 17:14:10 --> Database Driver Class Initialized
INFO - 2018-09-19 17:14:10 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:14:10 --> Form Validation Class Initialized
INFO - 2018-09-19 17:14:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-19 17:14:10 --> Database Driver Class Initialized
INFO - 2018-09-19 17:14:10 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:14:10 --> Config Class Initialized
INFO - 2018-09-19 17:14:10 --> Hooks Class Initialized
DEBUG - 2018-09-19 17:14:10 --> UTF-8 Support Enabled
INFO - 2018-09-19 17:14:10 --> Utf8 Class Initialized
INFO - 2018-09-19 17:14:10 --> URI Class Initialized
INFO - 2018-09-19 17:14:10 --> Router Class Initialized
INFO - 2018-09-19 17:14:10 --> Output Class Initialized
INFO - 2018-09-19 17:14:10 --> Security Class Initialized
DEBUG - 2018-09-19 17:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-19 17:14:10 --> CSRF cookie sent
INFO - 2018-09-19 17:14:10 --> Input Class Initialized
INFO - 2018-09-19 17:14:10 --> Language Class Initialized
INFO - 2018-09-19 17:14:10 --> Loader Class Initialized
INFO - 2018-09-19 17:14:10 --> Helper loaded: url_helper
INFO - 2018-09-19 17:14:10 --> Helper loaded: form_helper
INFO - 2018-09-19 17:14:10 --> Helper loaded: language_helper
DEBUG - 2018-09-19 17:14:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-19 17:14:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-19 17:14:10 --> User Agent Class Initialized
INFO - 2018-09-19 17:14:10 --> Controller Class Initialized
INFO - 2018-09-19 17:14:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-19 17:14:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-19 17:14:10 --> Pixel_Model class loaded
INFO - 2018-09-19 17:14:10 --> Database Driver Class Initialized
INFO - 2018-09-19 17:14:10 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:14:10 --> Database Driver Class Initialized
INFO - 2018-09-19 17:14:10 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:14:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-19 17:14:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-19 17:14:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-19 17:14:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-19 17:14:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-19 17:14:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-19 17:14:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/merriage_home_title.php
INFO - 2018-09-19 17:14:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-19 17:14:10 --> Final output sent to browser
DEBUG - 2018-09-19 17:14:10 --> Total execution time: 0.0459
INFO - 2018-09-19 17:14:23 --> Config Class Initialized
INFO - 2018-09-19 17:14:23 --> Hooks Class Initialized
DEBUG - 2018-09-19 17:14:23 --> UTF-8 Support Enabled
INFO - 2018-09-19 17:14:23 --> Utf8 Class Initialized
INFO - 2018-09-19 17:14:23 --> URI Class Initialized
INFO - 2018-09-19 17:14:23 --> Router Class Initialized
INFO - 2018-09-19 17:14:23 --> Output Class Initialized
INFO - 2018-09-19 17:14:23 --> Security Class Initialized
DEBUG - 2018-09-19 17:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-19 17:14:23 --> CSRF cookie sent
INFO - 2018-09-19 17:14:23 --> CSRF token verified
INFO - 2018-09-19 17:14:23 --> Input Class Initialized
INFO - 2018-09-19 17:14:23 --> Language Class Initialized
INFO - 2018-09-19 17:14:23 --> Loader Class Initialized
INFO - 2018-09-19 17:14:23 --> Helper loaded: url_helper
INFO - 2018-09-19 17:14:23 --> Helper loaded: form_helper
INFO - 2018-09-19 17:14:23 --> Helper loaded: language_helper
DEBUG - 2018-09-19 17:14:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-19 17:14:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-19 17:14:23 --> User Agent Class Initialized
INFO - 2018-09-19 17:14:23 --> Controller Class Initialized
INFO - 2018-09-19 17:14:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-19 17:14:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-19 17:14:23 --> Pixel_Model class loaded
INFO - 2018-09-19 17:14:23 --> Database Driver Class Initialized
INFO - 2018-09-19 17:14:23 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:14:23 --> Form Validation Class Initialized
INFO - 2018-09-19 17:14:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-19 17:14:23 --> Database Driver Class Initialized
INFO - 2018-09-19 17:14:23 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:14:23 --> Config Class Initialized
INFO - 2018-09-19 17:14:23 --> Hooks Class Initialized
DEBUG - 2018-09-19 17:14:23 --> UTF-8 Support Enabled
INFO - 2018-09-19 17:14:23 --> Utf8 Class Initialized
INFO - 2018-09-19 17:14:23 --> URI Class Initialized
INFO - 2018-09-19 17:14:23 --> Router Class Initialized
INFO - 2018-09-19 17:14:23 --> Output Class Initialized
INFO - 2018-09-19 17:14:23 --> Security Class Initialized
DEBUG - 2018-09-19 17:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-19 17:14:23 --> CSRF cookie sent
INFO - 2018-09-19 17:14:23 --> Input Class Initialized
INFO - 2018-09-19 17:14:23 --> Language Class Initialized
INFO - 2018-09-19 17:14:23 --> Loader Class Initialized
INFO - 2018-09-19 17:14:23 --> Helper loaded: url_helper
INFO - 2018-09-19 17:14:23 --> Helper loaded: form_helper
INFO - 2018-09-19 17:14:23 --> Helper loaded: language_helper
DEBUG - 2018-09-19 17:14:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-19 17:14:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-19 17:14:23 --> User Agent Class Initialized
INFO - 2018-09-19 17:14:23 --> Controller Class Initialized
INFO - 2018-09-19 17:14:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-19 17:14:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-19 17:14:23 --> Pixel_Model class loaded
INFO - 2018-09-19 17:14:23 --> Database Driver Class Initialized
INFO - 2018-09-19 17:14:23 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:14:23 --> Database Driver Class Initialized
INFO - 2018-09-19 17:14:23 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:14:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-19 17:14:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-19 17:14:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-19 17:14:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-19 17:14:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-19 17:14:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-19 17:14:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-09-19 17:14:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-19 17:14:23 --> Final output sent to browser
DEBUG - 2018-09-19 17:14:23 --> Total execution time: 0.0526
INFO - 2018-09-19 17:14:37 --> Config Class Initialized
INFO - 2018-09-19 17:14:37 --> Hooks Class Initialized
DEBUG - 2018-09-19 17:14:37 --> UTF-8 Support Enabled
INFO - 2018-09-19 17:14:37 --> Utf8 Class Initialized
INFO - 2018-09-19 17:14:37 --> URI Class Initialized
INFO - 2018-09-19 17:14:37 --> Router Class Initialized
INFO - 2018-09-19 17:14:37 --> Output Class Initialized
INFO - 2018-09-19 17:14:37 --> Security Class Initialized
DEBUG - 2018-09-19 17:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-19 17:14:37 --> CSRF cookie sent
INFO - 2018-09-19 17:14:37 --> CSRF token verified
INFO - 2018-09-19 17:14:37 --> Input Class Initialized
INFO - 2018-09-19 17:14:37 --> Language Class Initialized
INFO - 2018-09-19 17:14:37 --> Loader Class Initialized
INFO - 2018-09-19 17:14:37 --> Helper loaded: url_helper
INFO - 2018-09-19 17:14:37 --> Helper loaded: form_helper
INFO - 2018-09-19 17:14:37 --> Helper loaded: language_helper
DEBUG - 2018-09-19 17:14:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-19 17:14:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-19 17:14:37 --> User Agent Class Initialized
INFO - 2018-09-19 17:14:37 --> Controller Class Initialized
INFO - 2018-09-19 17:14:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-19 17:14:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-19 17:14:37 --> Pixel_Model class loaded
INFO - 2018-09-19 17:14:37 --> Database Driver Class Initialized
INFO - 2018-09-19 17:14:37 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:14:37 --> Form Validation Class Initialized
INFO - 2018-09-19 17:14:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-19 17:14:37 --> Database Driver Class Initialized
INFO - 2018-09-19 17:14:37 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:14:38 --> Config Class Initialized
INFO - 2018-09-19 17:14:38 --> Hooks Class Initialized
DEBUG - 2018-09-19 17:14:38 --> UTF-8 Support Enabled
INFO - 2018-09-19 17:14:38 --> Utf8 Class Initialized
INFO - 2018-09-19 17:14:38 --> URI Class Initialized
INFO - 2018-09-19 17:14:38 --> Router Class Initialized
INFO - 2018-09-19 17:14:38 --> Output Class Initialized
INFO - 2018-09-19 17:14:38 --> Security Class Initialized
DEBUG - 2018-09-19 17:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-19 17:14:38 --> CSRF cookie sent
INFO - 2018-09-19 17:14:38 --> Input Class Initialized
INFO - 2018-09-19 17:14:38 --> Language Class Initialized
INFO - 2018-09-19 17:14:38 --> Loader Class Initialized
INFO - 2018-09-19 17:14:38 --> Helper loaded: url_helper
INFO - 2018-09-19 17:14:38 --> Helper loaded: form_helper
INFO - 2018-09-19 17:14:38 --> Helper loaded: language_helper
DEBUG - 2018-09-19 17:14:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-19 17:14:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-19 17:14:38 --> User Agent Class Initialized
INFO - 2018-09-19 17:14:38 --> Controller Class Initialized
INFO - 2018-09-19 17:14:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-19 17:14:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-19 17:14:38 --> Pixel_Model class loaded
INFO - 2018-09-19 17:14:38 --> Database Driver Class Initialized
INFO - 2018-09-19 17:14:38 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:14:38 --> Config Class Initialized
INFO - 2018-09-19 17:14:38 --> Hooks Class Initialized
DEBUG - 2018-09-19 17:14:38 --> UTF-8 Support Enabled
INFO - 2018-09-19 17:14:38 --> Utf8 Class Initialized
INFO - 2018-09-19 17:14:38 --> URI Class Initialized
INFO - 2018-09-19 17:14:38 --> Router Class Initialized
INFO - 2018-09-19 17:14:38 --> Output Class Initialized
INFO - 2018-09-19 17:14:38 --> Security Class Initialized
DEBUG - 2018-09-19 17:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-19 17:14:38 --> CSRF cookie sent
INFO - 2018-09-19 17:14:38 --> Input Class Initialized
INFO - 2018-09-19 17:14:38 --> Language Class Initialized
INFO - 2018-09-19 17:14:38 --> Loader Class Initialized
INFO - 2018-09-19 17:14:38 --> Helper loaded: url_helper
INFO - 2018-09-19 17:14:38 --> Helper loaded: form_helper
INFO - 2018-09-19 17:14:38 --> Helper loaded: language_helper
DEBUG - 2018-09-19 17:14:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-19 17:14:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-19 17:14:38 --> User Agent Class Initialized
INFO - 2018-09-19 17:14:38 --> Controller Class Initialized
INFO - 2018-09-19 17:14:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-19 17:14:38 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-09-19 17:14:38 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-09-19 17:14:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-19 17:14:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-19 17:14:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-19 17:14:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-09-19 17:14:38 --> Could not find the language line "req_email"
INFO - 2018-09-19 17:14:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-09-19 17:14:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-19 17:14:38 --> Final output sent to browser
DEBUG - 2018-09-19 17:14:38 --> Total execution time: 0.0232
INFO - 2018-09-19 17:14:43 --> Config Class Initialized
INFO - 2018-09-19 17:14:43 --> Hooks Class Initialized
DEBUG - 2018-09-19 17:14:43 --> UTF-8 Support Enabled
INFO - 2018-09-19 17:14:43 --> Utf8 Class Initialized
INFO - 2018-09-19 17:14:43 --> URI Class Initialized
INFO - 2018-09-19 17:14:43 --> Router Class Initialized
INFO - 2018-09-19 17:14:43 --> Output Class Initialized
INFO - 2018-09-19 17:14:43 --> Security Class Initialized
DEBUG - 2018-09-19 17:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-19 17:14:43 --> CSRF cookie sent
INFO - 2018-09-19 17:14:43 --> Input Class Initialized
INFO - 2018-09-19 17:14:43 --> Language Class Initialized
INFO - 2018-09-19 17:14:43 --> Loader Class Initialized
INFO - 2018-09-19 17:14:43 --> Helper loaded: url_helper
INFO - 2018-09-19 17:14:43 --> Helper loaded: form_helper
INFO - 2018-09-19 17:14:43 --> Helper loaded: language_helper
DEBUG - 2018-09-19 17:14:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-19 17:14:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-19 17:14:43 --> User Agent Class Initialized
INFO - 2018-09-19 17:14:43 --> Controller Class Initialized
INFO - 2018-09-19 17:14:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-19 17:14:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-19 17:14:43 --> Pixel_Model class loaded
INFO - 2018-09-19 17:14:43 --> Database Driver Class Initialized
INFO - 2018-09-19 17:14:43 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:14:43 --> Database Driver Class Initialized
INFO - 2018-09-19 17:14:43 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:14:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-19 17:14:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-19 17:14:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-19 17:14:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-19 17:14:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-19 17:14:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-19 17:14:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-09-19 17:14:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-19 17:14:43 --> Final output sent to browser
DEBUG - 2018-09-19 17:14:43 --> Total execution time: 0.0451
INFO - 2018-09-19 17:14:44 --> Config Class Initialized
INFO - 2018-09-19 17:14:44 --> Hooks Class Initialized
DEBUG - 2018-09-19 17:14:44 --> UTF-8 Support Enabled
INFO - 2018-09-19 17:14:44 --> Utf8 Class Initialized
INFO - 2018-09-19 17:14:44 --> URI Class Initialized
INFO - 2018-09-19 17:14:44 --> Router Class Initialized
INFO - 2018-09-19 17:14:44 --> Output Class Initialized
INFO - 2018-09-19 17:14:44 --> Security Class Initialized
DEBUG - 2018-09-19 17:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-19 17:14:44 --> CSRF cookie sent
INFO - 2018-09-19 17:14:44 --> Input Class Initialized
INFO - 2018-09-19 17:14:44 --> Language Class Initialized
INFO - 2018-09-19 17:14:44 --> Loader Class Initialized
INFO - 2018-09-19 17:14:44 --> Helper loaded: url_helper
INFO - 2018-09-19 17:14:44 --> Helper loaded: form_helper
INFO - 2018-09-19 17:14:44 --> Helper loaded: language_helper
DEBUG - 2018-09-19 17:14:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-19 17:14:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-19 17:14:44 --> User Agent Class Initialized
INFO - 2018-09-19 17:14:44 --> Controller Class Initialized
INFO - 2018-09-19 17:14:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-19 17:14:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-19 17:14:44 --> Pixel_Model class loaded
INFO - 2018-09-19 17:14:44 --> Database Driver Class Initialized
INFO - 2018-09-19 17:14:44 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:14:44 --> Database Driver Class Initialized
INFO - 2018-09-19 17:14:44 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:14:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-19 17:14:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-19 17:14:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-19 17:14:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-19 17:14:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-09-19 17:14:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-19 17:14:44 --> Final output sent to browser
DEBUG - 2018-09-19 17:14:44 --> Total execution time: 0.0457
INFO - 2018-09-19 17:15:03 --> Config Class Initialized
INFO - 2018-09-19 17:15:03 --> Hooks Class Initialized
DEBUG - 2018-09-19 17:15:03 --> UTF-8 Support Enabled
INFO - 2018-09-19 17:15:03 --> Utf8 Class Initialized
INFO - 2018-09-19 17:15:03 --> URI Class Initialized
INFO - 2018-09-19 17:15:03 --> Router Class Initialized
INFO - 2018-09-19 17:15:03 --> Output Class Initialized
INFO - 2018-09-19 17:15:03 --> Security Class Initialized
DEBUG - 2018-09-19 17:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-19 17:15:03 --> CSRF cookie sent
INFO - 2018-09-19 17:15:03 --> Input Class Initialized
INFO - 2018-09-19 17:15:03 --> Language Class Initialized
INFO - 2018-09-19 17:15:03 --> Loader Class Initialized
INFO - 2018-09-19 17:15:03 --> Helper loaded: url_helper
INFO - 2018-09-19 17:15:03 --> Helper loaded: form_helper
INFO - 2018-09-19 17:15:03 --> Helper loaded: language_helper
DEBUG - 2018-09-19 17:15:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-19 17:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-19 17:15:03 --> User Agent Class Initialized
INFO - 2018-09-19 17:15:03 --> Controller Class Initialized
INFO - 2018-09-19 17:15:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-19 17:15:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-19 17:15:03 --> Pixel_Model class loaded
INFO - 2018-09-19 17:15:03 --> Database Driver Class Initialized
INFO - 2018-09-19 17:15:03 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:15:03 --> Database Driver Class Initialized
INFO - 2018-09-19 17:15:03 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:15:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-19 17:15:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-19 17:15:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-19 17:15:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-19 17:15:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-19 17:15:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-19 17:15:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-09-19 17:15:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-19 17:15:03 --> Final output sent to browser
DEBUG - 2018-09-19 17:15:03 --> Total execution time: 0.0461
INFO - 2018-09-19 17:15:05 --> Config Class Initialized
INFO - 2018-09-19 17:15:05 --> Hooks Class Initialized
DEBUG - 2018-09-19 17:15:05 --> UTF-8 Support Enabled
INFO - 2018-09-19 17:15:05 --> Utf8 Class Initialized
INFO - 2018-09-19 17:15:05 --> URI Class Initialized
INFO - 2018-09-19 17:15:05 --> Router Class Initialized
INFO - 2018-09-19 17:15:05 --> Output Class Initialized
INFO - 2018-09-19 17:15:05 --> Security Class Initialized
DEBUG - 2018-09-19 17:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-19 17:15:05 --> CSRF cookie sent
INFO - 2018-09-19 17:15:05 --> Input Class Initialized
INFO - 2018-09-19 17:15:05 --> Language Class Initialized
INFO - 2018-09-19 17:15:05 --> Loader Class Initialized
INFO - 2018-09-19 17:15:05 --> Helper loaded: url_helper
INFO - 2018-09-19 17:15:05 --> Helper loaded: form_helper
INFO - 2018-09-19 17:15:05 --> Helper loaded: language_helper
DEBUG - 2018-09-19 17:15:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-19 17:15:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-19 17:15:05 --> User Agent Class Initialized
INFO - 2018-09-19 17:15:05 --> Controller Class Initialized
INFO - 2018-09-19 17:15:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-19 17:15:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-19 17:15:05 --> Pixel_Model class loaded
INFO - 2018-09-19 17:15:05 --> Database Driver Class Initialized
INFO - 2018-09-19 17:15:05 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:15:05 --> Database Driver Class Initialized
INFO - 2018-09-19 17:15:05 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:15:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-19 17:15:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-19 17:15:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-19 17:15:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-19 17:15:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-19 17:15:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-19 17:15:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/merriage_home_title.php
INFO - 2018-09-19 17:15:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-19 17:15:05 --> Final output sent to browser
DEBUG - 2018-09-19 17:15:05 --> Total execution time: 0.0456
INFO - 2018-09-19 17:15:08 --> Config Class Initialized
INFO - 2018-09-19 17:15:08 --> Hooks Class Initialized
DEBUG - 2018-09-19 17:15:08 --> UTF-8 Support Enabled
INFO - 2018-09-19 17:15:08 --> Utf8 Class Initialized
INFO - 2018-09-19 17:15:08 --> URI Class Initialized
INFO - 2018-09-19 17:15:08 --> Router Class Initialized
INFO - 2018-09-19 17:15:08 --> Output Class Initialized
INFO - 2018-09-19 17:15:08 --> Security Class Initialized
DEBUG - 2018-09-19 17:15:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-19 17:15:08 --> CSRF cookie sent
INFO - 2018-09-19 17:15:08 --> Input Class Initialized
INFO - 2018-09-19 17:15:08 --> Language Class Initialized
INFO - 2018-09-19 17:15:08 --> Loader Class Initialized
INFO - 2018-09-19 17:15:08 --> Helper loaded: url_helper
INFO - 2018-09-19 17:15:08 --> Helper loaded: form_helper
INFO - 2018-09-19 17:15:08 --> Helper loaded: language_helper
DEBUG - 2018-09-19 17:15:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-19 17:15:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-19 17:15:08 --> User Agent Class Initialized
INFO - 2018-09-19 17:15:08 --> Controller Class Initialized
INFO - 2018-09-19 17:15:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-19 17:15:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-19 17:15:08 --> Pixel_Model class loaded
INFO - 2018-09-19 17:15:08 --> Database Driver Class Initialized
INFO - 2018-09-19 17:15:08 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:15:08 --> Database Driver Class Initialized
INFO - 2018-09-19 17:15:08 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:15:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-19 17:15:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-19 17:15:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-19 17:15:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-19 17:15:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-19 17:15:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-19 17:15:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_value.php
INFO - 2018-09-19 17:15:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-19 17:15:08 --> Final output sent to browser
DEBUG - 2018-09-19 17:15:08 --> Total execution time: 0.0470
INFO - 2018-09-19 17:15:11 --> Config Class Initialized
INFO - 2018-09-19 17:15:11 --> Hooks Class Initialized
DEBUG - 2018-09-19 17:15:11 --> UTF-8 Support Enabled
INFO - 2018-09-19 17:15:11 --> Utf8 Class Initialized
INFO - 2018-09-19 17:15:11 --> URI Class Initialized
INFO - 2018-09-19 17:15:11 --> Router Class Initialized
INFO - 2018-09-19 17:15:11 --> Output Class Initialized
INFO - 2018-09-19 17:15:11 --> Security Class Initialized
DEBUG - 2018-09-19 17:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-19 17:15:11 --> CSRF cookie sent
INFO - 2018-09-19 17:15:11 --> Input Class Initialized
INFO - 2018-09-19 17:15:11 --> Language Class Initialized
INFO - 2018-09-19 17:15:11 --> Loader Class Initialized
INFO - 2018-09-19 17:15:11 --> Helper loaded: url_helper
INFO - 2018-09-19 17:15:11 --> Helper loaded: form_helper
INFO - 2018-09-19 17:15:11 --> Helper loaded: language_helper
DEBUG - 2018-09-19 17:15:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-19 17:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-19 17:15:11 --> User Agent Class Initialized
INFO - 2018-09-19 17:15:11 --> Controller Class Initialized
INFO - 2018-09-19 17:15:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-19 17:15:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-19 17:15:11 --> Pixel_Model class loaded
INFO - 2018-09-19 17:15:11 --> Database Driver Class Initialized
INFO - 2018-09-19 17:15:11 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:15:11 --> Database Driver Class Initialized
INFO - 2018-09-19 17:15:11 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:15:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-19 17:15:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-19 17:15:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-19 17:15:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-19 17:15:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-19 17:15:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-19 17:15:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_owner.php
INFO - 2018-09-19 17:15:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-19 17:15:11 --> Final output sent to browser
DEBUG - 2018-09-19 17:15:11 --> Total execution time: 0.0476
INFO - 2018-09-19 17:15:13 --> Config Class Initialized
INFO - 2018-09-19 17:15:13 --> Hooks Class Initialized
DEBUG - 2018-09-19 17:15:13 --> UTF-8 Support Enabled
INFO - 2018-09-19 17:15:13 --> Utf8 Class Initialized
INFO - 2018-09-19 17:15:13 --> URI Class Initialized
INFO - 2018-09-19 17:15:13 --> Router Class Initialized
INFO - 2018-09-19 17:15:13 --> Output Class Initialized
INFO - 2018-09-19 17:15:13 --> Security Class Initialized
DEBUG - 2018-09-19 17:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-19 17:15:13 --> CSRF cookie sent
INFO - 2018-09-19 17:15:13 --> Input Class Initialized
INFO - 2018-09-19 17:15:13 --> Language Class Initialized
INFO - 2018-09-19 17:15:13 --> Loader Class Initialized
INFO - 2018-09-19 17:15:13 --> Helper loaded: url_helper
INFO - 2018-09-19 17:15:13 --> Helper loaded: form_helper
INFO - 2018-09-19 17:15:13 --> Helper loaded: language_helper
DEBUG - 2018-09-19 17:15:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-19 17:15:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-19 17:15:13 --> User Agent Class Initialized
INFO - 2018-09-19 17:15:13 --> Controller Class Initialized
INFO - 2018-09-19 17:15:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-19 17:15:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-19 17:15:13 --> Pixel_Model class loaded
INFO - 2018-09-19 17:15:13 --> Database Driver Class Initialized
INFO - 2018-09-19 17:15:13 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:15:13 --> Database Driver Class Initialized
INFO - 2018-09-19 17:15:13 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:15:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-19 17:15:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-19 17:15:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-19 17:15:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-19 17:15:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-19 17:15:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-19 17:15:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-09-19 17:15:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-19 17:15:13 --> Final output sent to browser
DEBUG - 2018-09-19 17:15:13 --> Total execution time: 0.0454
INFO - 2018-09-19 17:15:13 --> Config Class Initialized
INFO - 2018-09-19 17:15:13 --> Hooks Class Initialized
DEBUG - 2018-09-19 17:15:13 --> UTF-8 Support Enabled
INFO - 2018-09-19 17:15:13 --> Utf8 Class Initialized
INFO - 2018-09-19 17:15:13 --> URI Class Initialized
INFO - 2018-09-19 17:15:13 --> Router Class Initialized
INFO - 2018-09-19 17:15:13 --> Output Class Initialized
INFO - 2018-09-19 17:15:13 --> Security Class Initialized
DEBUG - 2018-09-19 17:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-19 17:15:13 --> CSRF cookie sent
INFO - 2018-09-19 17:15:13 --> Input Class Initialized
INFO - 2018-09-19 17:15:13 --> Language Class Initialized
INFO - 2018-09-19 17:15:13 --> Loader Class Initialized
INFO - 2018-09-19 17:15:13 --> Helper loaded: url_helper
INFO - 2018-09-19 17:15:13 --> Helper loaded: form_helper
INFO - 2018-09-19 17:15:13 --> Helper loaded: language_helper
DEBUG - 2018-09-19 17:15:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-19 17:15:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-19 17:15:13 --> User Agent Class Initialized
INFO - 2018-09-19 17:15:13 --> Controller Class Initialized
INFO - 2018-09-19 17:15:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-19 17:15:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-19 17:15:13 --> Pixel_Model class loaded
INFO - 2018-09-19 17:15:13 --> Database Driver Class Initialized
INFO - 2018-09-19 17:15:13 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:15:14 --> Database Driver Class Initialized
INFO - 2018-09-19 17:15:14 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:15:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-19 17:15:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-19 17:15:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-19 17:15:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-19 17:15:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-19 17:15:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-19 17:15:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-09-19 17:15:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-19 17:15:14 --> Final output sent to browser
DEBUG - 2018-09-19 17:15:14 --> Total execution time: 0.0471
INFO - 2018-09-19 17:15:14 --> Config Class Initialized
INFO - 2018-09-19 17:15:14 --> Hooks Class Initialized
DEBUG - 2018-09-19 17:15:14 --> UTF-8 Support Enabled
INFO - 2018-09-19 17:15:14 --> Utf8 Class Initialized
INFO - 2018-09-19 17:15:14 --> URI Class Initialized
INFO - 2018-09-19 17:15:14 --> Router Class Initialized
INFO - 2018-09-19 17:15:14 --> Output Class Initialized
INFO - 2018-09-19 17:15:14 --> Security Class Initialized
DEBUG - 2018-09-19 17:15:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-19 17:15:14 --> CSRF cookie sent
INFO - 2018-09-19 17:15:14 --> Input Class Initialized
INFO - 2018-09-19 17:15:14 --> Language Class Initialized
INFO - 2018-09-19 17:15:14 --> Loader Class Initialized
INFO - 2018-09-19 17:15:14 --> Helper loaded: url_helper
INFO - 2018-09-19 17:15:14 --> Helper loaded: form_helper
INFO - 2018-09-19 17:15:14 --> Helper loaded: language_helper
DEBUG - 2018-09-19 17:15:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-19 17:15:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-19 17:15:14 --> User Agent Class Initialized
INFO - 2018-09-19 17:15:14 --> Controller Class Initialized
INFO - 2018-09-19 17:15:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-19 17:15:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-19 17:15:14 --> Pixel_Model class loaded
INFO - 2018-09-19 17:15:14 --> Database Driver Class Initialized
INFO - 2018-09-19 17:15:14 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:15:14 --> Database Driver Class Initialized
INFO - 2018-09-19 17:15:14 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:15:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-19 17:15:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-19 17:15:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-19 17:15:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-19 17:15:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-19 17:15:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-19 17:15:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-09-19 17:15:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-19 17:15:15 --> Final output sent to browser
DEBUG - 2018-09-19 17:15:15 --> Total execution time: 0.0463
INFO - 2018-09-19 17:15:16 --> Config Class Initialized
INFO - 2018-09-19 17:15:16 --> Hooks Class Initialized
DEBUG - 2018-09-19 17:15:16 --> UTF-8 Support Enabled
INFO - 2018-09-19 17:15:16 --> Utf8 Class Initialized
INFO - 2018-09-19 17:15:16 --> URI Class Initialized
INFO - 2018-09-19 17:15:16 --> Router Class Initialized
INFO - 2018-09-19 17:15:16 --> Output Class Initialized
INFO - 2018-09-19 17:15:16 --> Security Class Initialized
DEBUG - 2018-09-19 17:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-19 17:15:16 --> CSRF cookie sent
INFO - 2018-09-19 17:15:16 --> Input Class Initialized
INFO - 2018-09-19 17:15:16 --> Language Class Initialized
INFO - 2018-09-19 17:15:16 --> Loader Class Initialized
INFO - 2018-09-19 17:15:16 --> Helper loaded: url_helper
INFO - 2018-09-19 17:15:16 --> Helper loaded: form_helper
INFO - 2018-09-19 17:15:16 --> Helper loaded: language_helper
DEBUG - 2018-09-19 17:15:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-19 17:15:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-19 17:15:16 --> User Agent Class Initialized
INFO - 2018-09-19 17:15:16 --> Controller Class Initialized
INFO - 2018-09-19 17:15:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-19 17:15:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-19 17:15:16 --> Pixel_Model class loaded
INFO - 2018-09-19 17:15:16 --> Database Driver Class Initialized
INFO - 2018-09-19 17:15:16 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:15:16 --> Database Driver Class Initialized
INFO - 2018-09-19 17:15:16 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:15:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-19 17:15:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-19 17:15:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-19 17:15:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-19 17:15:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-19 17:15:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-19 17:15:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-09-19 17:15:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-19 17:15:16 --> Final output sent to browser
DEBUG - 2018-09-19 17:15:16 --> Total execution time: 0.0419
INFO - 2018-09-19 17:15:20 --> Config Class Initialized
INFO - 2018-09-19 17:15:20 --> Hooks Class Initialized
DEBUG - 2018-09-19 17:15:20 --> UTF-8 Support Enabled
INFO - 2018-09-19 17:15:20 --> Utf8 Class Initialized
INFO - 2018-09-19 17:15:20 --> URI Class Initialized
INFO - 2018-09-19 17:15:20 --> Router Class Initialized
INFO - 2018-09-19 17:15:20 --> Output Class Initialized
INFO - 2018-09-19 17:15:20 --> Security Class Initialized
DEBUG - 2018-09-19 17:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-19 17:15:20 --> CSRF cookie sent
INFO - 2018-09-19 17:15:20 --> Input Class Initialized
INFO - 2018-09-19 17:15:20 --> Language Class Initialized
INFO - 2018-09-19 17:15:20 --> Loader Class Initialized
INFO - 2018-09-19 17:15:20 --> Helper loaded: url_helper
INFO - 2018-09-19 17:15:20 --> Helper loaded: form_helper
INFO - 2018-09-19 17:15:20 --> Helper loaded: language_helper
DEBUG - 2018-09-19 17:15:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-19 17:15:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-19 17:15:20 --> User Agent Class Initialized
INFO - 2018-09-19 17:15:20 --> Controller Class Initialized
INFO - 2018-09-19 17:15:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-19 17:15:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-19 17:15:20 --> Pixel_Model class loaded
INFO - 2018-09-19 17:15:20 --> Database Driver Class Initialized
INFO - 2018-09-19 17:15:20 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:15:20 --> Database Driver Class Initialized
INFO - 2018-09-19 17:15:20 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:15:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-19 17:15:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-19 17:15:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-19 17:15:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-19 17:15:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-19 17:15:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-19 17:15:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/marriage.php
INFO - 2018-09-19 17:15:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-19 17:15:20 --> Final output sent to browser
DEBUG - 2018-09-19 17:15:20 --> Total execution time: 0.0416
INFO - 2018-09-19 17:15:23 --> Config Class Initialized
INFO - 2018-09-19 17:15:23 --> Hooks Class Initialized
DEBUG - 2018-09-19 17:15:23 --> UTF-8 Support Enabled
INFO - 2018-09-19 17:15:23 --> Utf8 Class Initialized
INFO - 2018-09-19 17:15:23 --> URI Class Initialized
INFO - 2018-09-19 17:15:23 --> Router Class Initialized
INFO - 2018-09-19 17:15:23 --> Output Class Initialized
INFO - 2018-09-19 17:15:23 --> Security Class Initialized
DEBUG - 2018-09-19 17:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-19 17:15:23 --> CSRF cookie sent
INFO - 2018-09-19 17:15:23 --> Input Class Initialized
INFO - 2018-09-19 17:15:23 --> Language Class Initialized
INFO - 2018-09-19 17:15:23 --> Loader Class Initialized
INFO - 2018-09-19 17:15:23 --> Helper loaded: url_helper
INFO - 2018-09-19 17:15:23 --> Helper loaded: form_helper
INFO - 2018-09-19 17:15:23 --> Helper loaded: language_helper
DEBUG - 2018-09-19 17:15:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-19 17:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-19 17:15:23 --> User Agent Class Initialized
INFO - 2018-09-19 17:15:23 --> Controller Class Initialized
INFO - 2018-09-19 17:15:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-19 17:15:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-19 17:15:23 --> Pixel_Model class loaded
INFO - 2018-09-19 17:15:23 --> Database Driver Class Initialized
INFO - 2018-09-19 17:15:23 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:15:23 --> Database Driver Class Initialized
INFO - 2018-09-19 17:15:23 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:15:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-19 17:15:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-19 17:15:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-19 17:15:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-19 17:15:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-19 17:15:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-19 17:15:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-09-19 17:15:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-19 17:15:23 --> Final output sent to browser
DEBUG - 2018-09-19 17:15:23 --> Total execution time: 0.0548
INFO - 2018-09-19 17:15:27 --> Config Class Initialized
INFO - 2018-09-19 17:15:27 --> Hooks Class Initialized
DEBUG - 2018-09-19 17:15:27 --> UTF-8 Support Enabled
INFO - 2018-09-19 17:15:27 --> Utf8 Class Initialized
INFO - 2018-09-19 17:15:27 --> URI Class Initialized
INFO - 2018-09-19 17:15:27 --> Router Class Initialized
INFO - 2018-09-19 17:15:27 --> Output Class Initialized
INFO - 2018-09-19 17:15:27 --> Security Class Initialized
DEBUG - 2018-09-19 17:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-19 17:15:27 --> CSRF cookie sent
INFO - 2018-09-19 17:15:27 --> Input Class Initialized
INFO - 2018-09-19 17:15:27 --> Language Class Initialized
INFO - 2018-09-19 17:15:27 --> Loader Class Initialized
INFO - 2018-09-19 17:15:27 --> Helper loaded: url_helper
INFO - 2018-09-19 17:15:27 --> Helper loaded: form_helper
INFO - 2018-09-19 17:15:27 --> Helper loaded: language_helper
DEBUG - 2018-09-19 17:15:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-19 17:15:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-19 17:15:27 --> User Agent Class Initialized
INFO - 2018-09-19 17:15:27 --> Controller Class Initialized
INFO - 2018-09-19 17:15:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-19 17:15:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-19 17:15:27 --> Pixel_Model class loaded
INFO - 2018-09-19 17:15:27 --> Database Driver Class Initialized
INFO - 2018-09-19 17:15:27 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:15:27 --> Database Driver Class Initialized
INFO - 2018-09-19 17:15:27 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:15:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-19 17:15:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-19 17:15:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-19 17:15:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-19 17:15:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-19 17:15:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-19 17:15:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/marriage.php
INFO - 2018-09-19 17:15:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-19 17:15:27 --> Final output sent to browser
DEBUG - 2018-09-19 17:15:27 --> Total execution time: 0.0392
INFO - 2018-09-19 17:15:28 --> Config Class Initialized
INFO - 2018-09-19 17:15:28 --> Hooks Class Initialized
DEBUG - 2018-09-19 17:15:28 --> UTF-8 Support Enabled
INFO - 2018-09-19 17:15:28 --> Utf8 Class Initialized
INFO - 2018-09-19 17:15:28 --> URI Class Initialized
INFO - 2018-09-19 17:15:28 --> Router Class Initialized
INFO - 2018-09-19 17:15:28 --> Output Class Initialized
INFO - 2018-09-19 17:15:28 --> Security Class Initialized
DEBUG - 2018-09-19 17:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-19 17:15:28 --> CSRF cookie sent
INFO - 2018-09-19 17:15:28 --> Input Class Initialized
INFO - 2018-09-19 17:15:28 --> Language Class Initialized
INFO - 2018-09-19 17:15:28 --> Loader Class Initialized
INFO - 2018-09-19 17:15:28 --> Helper loaded: url_helper
INFO - 2018-09-19 17:15:28 --> Helper loaded: form_helper
INFO - 2018-09-19 17:15:28 --> Helper loaded: language_helper
DEBUG - 2018-09-19 17:15:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-19 17:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-19 17:15:28 --> User Agent Class Initialized
INFO - 2018-09-19 17:15:28 --> Controller Class Initialized
INFO - 2018-09-19 17:15:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-19 17:15:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-19 17:15:28 --> Pixel_Model class loaded
INFO - 2018-09-19 17:15:28 --> Database Driver Class Initialized
INFO - 2018-09-19 17:15:28 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:15:28 --> Database Driver Class Initialized
INFO - 2018-09-19 17:15:28 --> Model "QuestionsModel" initialized
INFO - 2018-09-19 17:15:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-19 17:15:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-19 17:15:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-19 17:15:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-19 17:15:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-19 17:15:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-19 17:15:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-09-19 17:15:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-19 17:15:28 --> Final output sent to browser
DEBUG - 2018-09-19 17:15:28 --> Total execution time: 0.0382

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-09-20 13:41:12 --> Config Class Initialized
INFO - 2018-09-20 13:41:12 --> Hooks Class Initialized
DEBUG - 2018-09-20 13:41:12 --> UTF-8 Support Enabled
INFO - 2018-09-20 13:41:12 --> Utf8 Class Initialized
INFO - 2018-09-20 13:41:12 --> URI Class Initialized
DEBUG - 2018-09-20 13:41:12 --> No URI present. Default controller set.
INFO - 2018-09-20 13:41:12 --> Router Class Initialized
INFO - 2018-09-20 13:41:12 --> Output Class Initialized
INFO - 2018-09-20 13:41:12 --> Security Class Initialized
DEBUG - 2018-09-20 13:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-20 13:41:12 --> CSRF cookie sent
INFO - 2018-09-20 13:41:12 --> Input Class Initialized
INFO - 2018-09-20 13:41:12 --> Language Class Initialized
INFO - 2018-09-20 13:41:12 --> Loader Class Initialized
INFO - 2018-09-20 13:41:12 --> Helper loaded: url_helper
INFO - 2018-09-20 13:41:12 --> Helper loaded: form_helper
INFO - 2018-09-20 13:41:12 --> Helper loaded: language_helper
DEBUG - 2018-09-20 13:41:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-20 13:41:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-20 13:41:12 --> User Agent Class Initialized
INFO - 2018-09-20 13:41:12 --> Controller Class Initialized
INFO - 2018-09-20 13:41:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-20 13:41:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-20 13:41:12 --> Pixel_Model class loaded
INFO - 2018-09-20 13:41:12 --> Database Driver Class Initialized
INFO - 2018-09-20 13:41:12 --> Model "QuestionsModel" initialized
INFO - 2018-09-20 13:41:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-20 13:41:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-20 13:41:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-09-20 13:41:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-20 13:41:12 --> Final output sent to browser
DEBUG - 2018-09-20 13:41:12 --> Total execution time: 0.0445
INFO - 2018-09-20 13:41:12 --> Config Class Initialized
INFO - 2018-09-20 13:41:12 --> Hooks Class Initialized
DEBUG - 2018-09-20 13:41:12 --> UTF-8 Support Enabled
INFO - 2018-09-20 13:41:12 --> Utf8 Class Initialized
INFO - 2018-09-20 13:41:12 --> URI Class Initialized
DEBUG - 2018-09-20 13:41:12 --> No URI present. Default controller set.
INFO - 2018-09-20 13:41:12 --> Router Class Initialized
INFO - 2018-09-20 13:41:12 --> Output Class Initialized
INFO - 2018-09-20 13:41:12 --> Security Class Initialized
DEBUG - 2018-09-20 13:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-20 13:41:12 --> CSRF cookie sent
INFO - 2018-09-20 13:41:12 --> Input Class Initialized
INFO - 2018-09-20 13:41:12 --> Language Class Initialized
INFO - 2018-09-20 13:41:12 --> Loader Class Initialized
INFO - 2018-09-20 13:41:12 --> Helper loaded: url_helper
INFO - 2018-09-20 13:41:12 --> Helper loaded: form_helper
INFO - 2018-09-20 13:41:12 --> Helper loaded: language_helper
DEBUG - 2018-09-20 13:41:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-20 13:41:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-20 13:41:12 --> User Agent Class Initialized
INFO - 2018-09-20 13:41:12 --> Controller Class Initialized
INFO - 2018-09-20 13:41:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-20 13:41:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-20 13:41:12 --> Pixel_Model class loaded
INFO - 2018-09-20 13:41:12 --> Database Driver Class Initialized
INFO - 2018-09-20 13:41:12 --> Model "QuestionsModel" initialized
INFO - 2018-09-20 13:41:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-20 13:41:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-20 13:41:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-09-20 13:41:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-20 13:41:12 --> Final output sent to browser
DEBUG - 2018-09-20 13:41:12 --> Total execution time: 0.0367
INFO - 2018-09-20 13:41:18 --> Config Class Initialized
INFO - 2018-09-20 13:41:18 --> Hooks Class Initialized
DEBUG - 2018-09-20 13:41:18 --> UTF-8 Support Enabled
INFO - 2018-09-20 13:41:18 --> Utf8 Class Initialized
INFO - 2018-09-20 13:41:18 --> URI Class Initialized
INFO - 2018-09-20 13:41:18 --> Router Class Initialized
INFO - 2018-09-20 13:41:18 --> Output Class Initialized
INFO - 2018-09-20 13:41:18 --> Security Class Initialized
DEBUG - 2018-09-20 13:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-20 13:41:18 --> CSRF cookie sent
INFO - 2018-09-20 13:41:18 --> Input Class Initialized
INFO - 2018-09-20 13:41:18 --> Language Class Initialized
INFO - 2018-09-20 13:41:18 --> Loader Class Initialized
INFO - 2018-09-20 13:41:18 --> Helper loaded: url_helper
INFO - 2018-09-20 13:41:18 --> Helper loaded: form_helper
INFO - 2018-09-20 13:41:18 --> Helper loaded: language_helper
DEBUG - 2018-09-20 13:41:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-20 13:41:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-20 13:41:18 --> User Agent Class Initialized
INFO - 2018-09-20 13:41:18 --> Controller Class Initialized
INFO - 2018-09-20 13:41:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-20 13:41:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-20 13:41:18 --> Pixel_Model class loaded
INFO - 2018-09-20 13:41:18 --> Database Driver Class Initialized
INFO - 2018-09-20 13:41:18 --> Model "QuestionsModel" initialized
INFO - 2018-09-20 13:41:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-20 13:41:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-20 13:41:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-20 13:41:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-20 13:41:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-20 13:41:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-20 13:41:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-09-20 13:41:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-20 13:41:18 --> Final output sent to browser
DEBUG - 2018-09-20 13:41:18 --> Total execution time: 0.0419
INFO - 2018-09-20 13:41:20 --> Config Class Initialized
INFO - 2018-09-20 13:41:20 --> Hooks Class Initialized
DEBUG - 2018-09-20 13:41:20 --> UTF-8 Support Enabled
INFO - 2018-09-20 13:41:20 --> Utf8 Class Initialized
INFO - 2018-09-20 13:41:20 --> URI Class Initialized
INFO - 2018-09-20 13:41:20 --> Router Class Initialized
INFO - 2018-09-20 13:41:20 --> Output Class Initialized
INFO - 2018-09-20 13:41:20 --> Security Class Initialized
DEBUG - 2018-09-20 13:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-20 13:41:20 --> CSRF cookie sent
INFO - 2018-09-20 13:41:20 --> CSRF token verified
INFO - 2018-09-20 13:41:20 --> Input Class Initialized
INFO - 2018-09-20 13:41:20 --> Language Class Initialized
INFO - 2018-09-20 13:41:20 --> Loader Class Initialized
INFO - 2018-09-20 13:41:20 --> Helper loaded: url_helper
INFO - 2018-09-20 13:41:20 --> Helper loaded: form_helper
INFO - 2018-09-20 13:41:20 --> Helper loaded: language_helper
DEBUG - 2018-09-20 13:41:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-20 13:41:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-20 13:41:20 --> User Agent Class Initialized
INFO - 2018-09-20 13:41:20 --> Controller Class Initialized
INFO - 2018-09-20 13:41:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-20 13:41:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-20 13:41:20 --> Pixel_Model class loaded
INFO - 2018-09-20 13:41:20 --> Database Driver Class Initialized
INFO - 2018-09-20 13:41:20 --> Model "QuestionsModel" initialized
INFO - 2018-09-20 13:41:20 --> Database Driver Class Initialized
INFO - 2018-09-20 13:41:20 --> Model "QuestionsModel" initialized
INFO - 2018-09-20 13:41:20 --> Config Class Initialized
INFO - 2018-09-20 13:41:20 --> Hooks Class Initialized
DEBUG - 2018-09-20 13:41:20 --> UTF-8 Support Enabled
INFO - 2018-09-20 13:41:20 --> Utf8 Class Initialized
INFO - 2018-09-20 13:41:20 --> URI Class Initialized
INFO - 2018-09-20 13:41:20 --> Router Class Initialized
INFO - 2018-09-20 13:41:20 --> Output Class Initialized
INFO - 2018-09-20 13:41:20 --> Security Class Initialized
DEBUG - 2018-09-20 13:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-20 13:41:20 --> CSRF cookie sent
INFO - 2018-09-20 13:41:20 --> Input Class Initialized
INFO - 2018-09-20 13:41:20 --> Language Class Initialized
INFO - 2018-09-20 13:41:20 --> Loader Class Initialized
INFO - 2018-09-20 13:41:20 --> Helper loaded: url_helper
INFO - 2018-09-20 13:41:20 --> Helper loaded: form_helper
INFO - 2018-09-20 13:41:20 --> Helper loaded: language_helper
DEBUG - 2018-09-20 13:41:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-20 13:41:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-20 13:41:20 --> User Agent Class Initialized
INFO - 2018-09-20 13:41:20 --> Controller Class Initialized
INFO - 2018-09-20 13:41:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-20 13:41:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-20 13:41:20 --> Pixel_Model class loaded
INFO - 2018-09-20 13:41:20 --> Database Driver Class Initialized
INFO - 2018-09-20 13:41:20 --> Model "QuestionsModel" initialized
INFO - 2018-09-20 13:41:20 --> Database Driver Class Initialized
INFO - 2018-09-20 13:41:20 --> Model "QuestionsModel" initialized
INFO - 2018-09-20 13:41:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-20 13:41:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-20 13:41:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-20 13:41:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-20 13:41:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-20 13:41:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-20 13:41:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-09-20 13:41:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-20 13:41:20 --> Final output sent to browser
DEBUG - 2018-09-20 13:41:20 --> Total execution time: 0.0451
INFO - 2018-09-20 13:41:25 --> Config Class Initialized
INFO - 2018-09-20 13:41:25 --> Hooks Class Initialized
DEBUG - 2018-09-20 13:41:25 --> UTF-8 Support Enabled
INFO - 2018-09-20 13:41:25 --> Utf8 Class Initialized
INFO - 2018-09-20 13:41:25 --> URI Class Initialized
INFO - 2018-09-20 13:41:25 --> Router Class Initialized
INFO - 2018-09-20 13:41:25 --> Output Class Initialized
INFO - 2018-09-20 13:41:25 --> Security Class Initialized
DEBUG - 2018-09-20 13:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-20 13:41:25 --> CSRF cookie sent
INFO - 2018-09-20 13:41:25 --> CSRF token verified
INFO - 2018-09-20 13:41:25 --> Input Class Initialized
INFO - 2018-09-20 13:41:25 --> Language Class Initialized
INFO - 2018-09-20 13:41:25 --> Loader Class Initialized
INFO - 2018-09-20 13:41:25 --> Helper loaded: url_helper
INFO - 2018-09-20 13:41:25 --> Helper loaded: form_helper
INFO - 2018-09-20 13:41:25 --> Helper loaded: language_helper
DEBUG - 2018-09-20 13:41:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-20 13:41:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-20 13:41:25 --> User Agent Class Initialized
INFO - 2018-09-20 13:41:25 --> Controller Class Initialized
INFO - 2018-09-20 13:41:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-20 13:41:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-20 13:41:25 --> Pixel_Model class loaded
INFO - 2018-09-20 13:41:25 --> Database Driver Class Initialized
INFO - 2018-09-20 13:41:25 --> Model "QuestionsModel" initialized
INFO - 2018-09-20 13:41:25 --> Form Validation Class Initialized
INFO - 2018-09-20 13:41:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-20 13:41:25 --> Database Driver Class Initialized
INFO - 2018-09-20 13:41:25 --> Model "QuestionsModel" initialized
INFO - 2018-09-20 13:41:25 --> Config Class Initialized
INFO - 2018-09-20 13:41:25 --> Hooks Class Initialized
DEBUG - 2018-09-20 13:41:25 --> UTF-8 Support Enabled
INFO - 2018-09-20 13:41:25 --> Utf8 Class Initialized
INFO - 2018-09-20 13:41:25 --> URI Class Initialized
INFO - 2018-09-20 13:41:25 --> Router Class Initialized
INFO - 2018-09-20 13:41:25 --> Output Class Initialized
INFO - 2018-09-20 13:41:25 --> Security Class Initialized
DEBUG - 2018-09-20 13:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-20 13:41:25 --> CSRF cookie sent
INFO - 2018-09-20 13:41:25 --> Input Class Initialized
INFO - 2018-09-20 13:41:25 --> Language Class Initialized
INFO - 2018-09-20 13:41:25 --> Loader Class Initialized
INFO - 2018-09-20 13:41:25 --> Helper loaded: url_helper
INFO - 2018-09-20 13:41:25 --> Helper loaded: form_helper
INFO - 2018-09-20 13:41:25 --> Helper loaded: language_helper
DEBUG - 2018-09-20 13:41:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-20 13:41:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-20 13:41:25 --> User Agent Class Initialized
INFO - 2018-09-20 13:41:25 --> Controller Class Initialized
INFO - 2018-09-20 13:41:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-20 13:41:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-20 13:41:25 --> Pixel_Model class loaded
INFO - 2018-09-20 13:41:25 --> Database Driver Class Initialized
INFO - 2018-09-20 13:41:25 --> Model "QuestionsModel" initialized
INFO - 2018-09-20 13:41:25 --> Database Driver Class Initialized
INFO - 2018-09-20 13:41:25 --> Model "QuestionsModel" initialized
INFO - 2018-09-20 13:41:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-20 13:41:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-20 13:41:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-20 13:41:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-20 13:41:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-20 13:41:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-20 13:41:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-09-20 13:41:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-20 13:41:25 --> Final output sent to browser
DEBUG - 2018-09-20 13:41:25 --> Total execution time: 0.0463
INFO - 2018-09-20 13:41:27 --> Config Class Initialized
INFO - 2018-09-20 13:41:27 --> Hooks Class Initialized
DEBUG - 2018-09-20 13:41:27 --> UTF-8 Support Enabled
INFO - 2018-09-20 13:41:27 --> Utf8 Class Initialized
INFO - 2018-09-20 13:41:27 --> URI Class Initialized
INFO - 2018-09-20 13:41:27 --> Router Class Initialized
INFO - 2018-09-20 13:41:27 --> Output Class Initialized
INFO - 2018-09-20 13:41:27 --> Security Class Initialized
DEBUG - 2018-09-20 13:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-20 13:41:27 --> CSRF cookie sent
INFO - 2018-09-20 13:41:27 --> CSRF token verified
INFO - 2018-09-20 13:41:27 --> Input Class Initialized
INFO - 2018-09-20 13:41:27 --> Language Class Initialized
INFO - 2018-09-20 13:41:27 --> Loader Class Initialized
INFO - 2018-09-20 13:41:27 --> Helper loaded: url_helper
INFO - 2018-09-20 13:41:27 --> Helper loaded: form_helper
INFO - 2018-09-20 13:41:27 --> Helper loaded: language_helper
DEBUG - 2018-09-20 13:41:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-20 13:41:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-20 13:41:27 --> User Agent Class Initialized
INFO - 2018-09-20 13:41:27 --> Controller Class Initialized
INFO - 2018-09-20 13:41:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-20 13:41:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-20 13:41:27 --> Pixel_Model class loaded
INFO - 2018-09-20 13:41:27 --> Database Driver Class Initialized
INFO - 2018-09-20 13:41:27 --> Model "QuestionsModel" initialized
INFO - 2018-09-20 13:41:27 --> Form Validation Class Initialized
INFO - 2018-09-20 13:41:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-20 13:41:27 --> Database Driver Class Initialized
INFO - 2018-09-20 13:41:27 --> Model "QuestionsModel" initialized
INFO - 2018-09-20 13:41:27 --> Config Class Initialized
INFO - 2018-09-20 13:41:27 --> Hooks Class Initialized
DEBUG - 2018-09-20 13:41:27 --> UTF-8 Support Enabled
INFO - 2018-09-20 13:41:27 --> Utf8 Class Initialized
INFO - 2018-09-20 13:41:27 --> URI Class Initialized
INFO - 2018-09-20 13:41:27 --> Router Class Initialized
INFO - 2018-09-20 13:41:27 --> Output Class Initialized
INFO - 2018-09-20 13:41:27 --> Security Class Initialized
DEBUG - 2018-09-20 13:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-20 13:41:27 --> CSRF cookie sent
INFO - 2018-09-20 13:41:27 --> Input Class Initialized
INFO - 2018-09-20 13:41:27 --> Language Class Initialized
INFO - 2018-09-20 13:41:27 --> Loader Class Initialized
INFO - 2018-09-20 13:41:27 --> Helper loaded: url_helper
INFO - 2018-09-20 13:41:27 --> Helper loaded: form_helper
INFO - 2018-09-20 13:41:27 --> Helper loaded: language_helper
DEBUG - 2018-09-20 13:41:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-20 13:41:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-20 13:41:27 --> User Agent Class Initialized
INFO - 2018-09-20 13:41:27 --> Controller Class Initialized
INFO - 2018-09-20 13:41:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-20 13:41:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-20 13:41:27 --> Pixel_Model class loaded
INFO - 2018-09-20 13:41:27 --> Database Driver Class Initialized
INFO - 2018-09-20 13:41:27 --> Model "QuestionsModel" initialized
INFO - 2018-09-20 13:41:27 --> Database Driver Class Initialized
INFO - 2018-09-20 13:41:27 --> Model "QuestionsModel" initialized
INFO - 2018-09-20 13:41:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-20 13:41:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-20 13:41:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-09-20 13:41:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-20 13:41:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-20 13:41:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-20 13:41:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-20 13:41:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-09-20 13:41:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-20 13:41:27 --> Final output sent to browser
DEBUG - 2018-09-20 13:41:27 --> Total execution time: 0.0403
INFO - 2018-09-20 13:41:29 --> Config Class Initialized
INFO - 2018-09-20 13:41:29 --> Hooks Class Initialized
DEBUG - 2018-09-20 13:41:29 --> UTF-8 Support Enabled
INFO - 2018-09-20 13:41:29 --> Utf8 Class Initialized
INFO - 2018-09-20 13:41:29 --> URI Class Initialized
INFO - 2018-09-20 13:41:29 --> Router Class Initialized
INFO - 2018-09-20 13:41:29 --> Output Class Initialized
INFO - 2018-09-20 13:41:29 --> Security Class Initialized
DEBUG - 2018-09-20 13:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-20 13:41:29 --> CSRF cookie sent
INFO - 2018-09-20 13:41:29 --> CSRF token verified
INFO - 2018-09-20 13:41:29 --> Input Class Initialized
INFO - 2018-09-20 13:41:29 --> Language Class Initialized
INFO - 2018-09-20 13:41:29 --> Loader Class Initialized
INFO - 2018-09-20 13:41:29 --> Helper loaded: url_helper
INFO - 2018-09-20 13:41:29 --> Helper loaded: form_helper
INFO - 2018-09-20 13:41:29 --> Helper loaded: language_helper
DEBUG - 2018-09-20 13:41:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-20 13:41:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-20 13:41:29 --> User Agent Class Initialized
INFO - 2018-09-20 13:41:29 --> Controller Class Initialized
INFO - 2018-09-20 13:41:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-20 13:41:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-20 13:41:29 --> Pixel_Model class loaded
INFO - 2018-09-20 13:41:29 --> Database Driver Class Initialized
INFO - 2018-09-20 13:41:29 --> Model "QuestionsModel" initialized
INFO - 2018-09-20 13:41:29 --> Form Validation Class Initialized
INFO - 2018-09-20 13:41:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-20 13:41:29 --> Database Driver Class Initialized
INFO - 2018-09-20 13:41:29 --> Model "QuestionsModel" initialized
INFO - 2018-09-20 13:41:29 --> Config Class Initialized
INFO - 2018-09-20 13:41:29 --> Hooks Class Initialized
DEBUG - 2018-09-20 13:41:29 --> UTF-8 Support Enabled
INFO - 2018-09-20 13:41:29 --> Utf8 Class Initialized
INFO - 2018-09-20 13:41:29 --> URI Class Initialized
INFO - 2018-09-20 13:41:29 --> Router Class Initialized
INFO - 2018-09-20 13:41:29 --> Output Class Initialized
INFO - 2018-09-20 13:41:29 --> Security Class Initialized
DEBUG - 2018-09-20 13:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-20 13:41:29 --> CSRF cookie sent
INFO - 2018-09-20 13:41:29 --> Input Class Initialized
INFO - 2018-09-20 13:41:29 --> Language Class Initialized
INFO - 2018-09-20 13:41:29 --> Loader Class Initialized
INFO - 2018-09-20 13:41:29 --> Helper loaded: url_helper
INFO - 2018-09-20 13:41:29 --> Helper loaded: form_helper
INFO - 2018-09-20 13:41:29 --> Helper loaded: language_helper
DEBUG - 2018-09-20 13:41:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-20 13:41:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-20 13:41:29 --> User Agent Class Initialized
INFO - 2018-09-20 13:41:29 --> Controller Class Initialized
INFO - 2018-09-20 13:41:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-20 13:41:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-20 13:41:29 --> Pixel_Model class loaded
INFO - 2018-09-20 13:41:29 --> Database Driver Class Initialized
INFO - 2018-09-20 13:41:29 --> Model "QuestionsModel" initialized
INFO - 2018-09-20 13:41:29 --> Database Driver Class Initialized
INFO - 2018-09-20 13:41:29 --> Model "QuestionsModel" initialized
INFO - 2018-09-20 13:41:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-20 13:41:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-20 13:41:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-20 13:41:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-20 13:41:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-20 13:41:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-20 13:41:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-09-20 13:41:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-20 13:41:29 --> Final output sent to browser
DEBUG - 2018-09-20 13:41:29 --> Total execution time: 0.0393
INFO - 2018-09-20 13:41:38 --> Config Class Initialized
INFO - 2018-09-20 13:41:38 --> Hooks Class Initialized
DEBUG - 2018-09-20 13:41:38 --> UTF-8 Support Enabled
INFO - 2018-09-20 13:41:38 --> Utf8 Class Initialized
INFO - 2018-09-20 13:41:38 --> URI Class Initialized
INFO - 2018-09-20 13:41:38 --> Router Class Initialized
INFO - 2018-09-20 13:41:38 --> Output Class Initialized
INFO - 2018-09-20 13:41:38 --> Security Class Initialized
DEBUG - 2018-09-20 13:41:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-20 13:41:38 --> CSRF cookie sent
INFO - 2018-09-20 13:41:38 --> CSRF token verified
INFO - 2018-09-20 13:41:38 --> Input Class Initialized
INFO - 2018-09-20 13:41:38 --> Language Class Initialized
INFO - 2018-09-20 13:41:38 --> Loader Class Initialized
INFO - 2018-09-20 13:41:38 --> Helper loaded: url_helper
INFO - 2018-09-20 13:41:38 --> Helper loaded: form_helper
INFO - 2018-09-20 13:41:38 --> Helper loaded: language_helper
DEBUG - 2018-09-20 13:41:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-20 13:41:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-20 13:41:38 --> User Agent Class Initialized
INFO - 2018-09-20 13:41:38 --> Controller Class Initialized
INFO - 2018-09-20 13:41:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-20 13:41:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-20 13:41:38 --> Pixel_Model class loaded
INFO - 2018-09-20 13:41:38 --> Database Driver Class Initialized
INFO - 2018-09-20 13:41:38 --> Model "QuestionsModel" initialized
INFO - 2018-09-20 13:41:38 --> Form Validation Class Initialized
INFO - 2018-09-20 13:41:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-20 13:41:38 --> Database Driver Class Initialized
INFO - 2018-09-20 13:41:38 --> Model "QuestionsModel" initialized
INFO - 2018-09-20 13:41:38 --> Config Class Initialized
INFO - 2018-09-20 13:41:38 --> Hooks Class Initialized
DEBUG - 2018-09-20 13:41:38 --> UTF-8 Support Enabled
INFO - 2018-09-20 13:41:38 --> Utf8 Class Initialized
INFO - 2018-09-20 13:41:38 --> URI Class Initialized
INFO - 2018-09-20 13:41:38 --> Router Class Initialized
INFO - 2018-09-20 13:41:38 --> Output Class Initialized
INFO - 2018-09-20 13:41:38 --> Security Class Initialized
DEBUG - 2018-09-20 13:41:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-20 13:41:38 --> CSRF cookie sent
INFO - 2018-09-20 13:41:38 --> Input Class Initialized
INFO - 2018-09-20 13:41:38 --> Language Class Initialized
INFO - 2018-09-20 13:41:38 --> Loader Class Initialized
INFO - 2018-09-20 13:41:38 --> Helper loaded: url_helper
INFO - 2018-09-20 13:41:39 --> Helper loaded: form_helper
INFO - 2018-09-20 13:41:39 --> Helper loaded: language_helper
DEBUG - 2018-09-20 13:41:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-20 13:41:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-20 13:41:39 --> User Agent Class Initialized
INFO - 2018-09-20 13:41:39 --> Controller Class Initialized
INFO - 2018-09-20 13:41:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-20 13:41:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-20 13:41:39 --> Pixel_Model class loaded
INFO - 2018-09-20 13:41:39 --> Database Driver Class Initialized
INFO - 2018-09-20 13:41:39 --> Model "QuestionsModel" initialized
INFO - 2018-09-20 13:41:39 --> Database Driver Class Initialized
INFO - 2018-09-20 13:41:39 --> Model "QuestionsModel" initialized
INFO - 2018-09-20 13:41:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-20 13:41:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-20 13:41:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-20 13:41:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-20 13:41:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-20 13:41:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-20 13:41:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-09-20 13:41:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-20 13:41:39 --> Final output sent to browser
DEBUG - 2018-09-20 13:41:39 --> Total execution time: 0.0468
INFO - 2018-09-20 13:51:48 --> Config Class Initialized
INFO - 2018-09-20 13:51:48 --> Hooks Class Initialized
DEBUG - 2018-09-20 13:51:48 --> UTF-8 Support Enabled
INFO - 2018-09-20 13:51:48 --> Utf8 Class Initialized
INFO - 2018-09-20 13:51:48 --> URI Class Initialized
INFO - 2018-09-20 13:51:48 --> Router Class Initialized
INFO - 2018-09-20 13:51:48 --> Output Class Initialized
INFO - 2018-09-20 13:51:48 --> Security Class Initialized
DEBUG - 2018-09-20 13:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-20 13:51:48 --> CSRF cookie sent
INFO - 2018-09-20 13:51:48 --> CSRF token verified
INFO - 2018-09-20 13:51:48 --> Input Class Initialized
INFO - 2018-09-20 13:51:48 --> Language Class Initialized
INFO - 2018-09-20 13:51:48 --> Loader Class Initialized
INFO - 2018-09-20 13:51:48 --> Helper loaded: url_helper
INFO - 2018-09-20 13:51:48 --> Helper loaded: form_helper
INFO - 2018-09-20 13:51:48 --> Helper loaded: language_helper
DEBUG - 2018-09-20 13:51:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-20 13:51:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-20 13:51:48 --> User Agent Class Initialized
INFO - 2018-09-20 13:51:48 --> Controller Class Initialized
INFO - 2018-09-20 13:51:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-20 13:51:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-20 13:51:48 --> Pixel_Model class loaded
INFO - 2018-09-20 13:51:48 --> Database Driver Class Initialized
INFO - 2018-09-20 13:51:48 --> Model "QuestionsModel" initialized
INFO - 2018-09-20 13:51:48 --> Form Validation Class Initialized
INFO - 2018-09-20 13:51:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-20 13:51:48 --> Database Driver Class Initialized
INFO - 2018-09-20 13:51:48 --> Model "QuestionsModel" initialized
INFO - 2018-09-20 13:51:48 --> Config Class Initialized
INFO - 2018-09-20 13:51:48 --> Hooks Class Initialized
DEBUG - 2018-09-20 13:51:48 --> UTF-8 Support Enabled
INFO - 2018-09-20 13:51:48 --> Utf8 Class Initialized
INFO - 2018-09-20 13:51:48 --> URI Class Initialized
INFO - 2018-09-20 13:51:48 --> Router Class Initialized
INFO - 2018-09-20 13:51:48 --> Output Class Initialized
INFO - 2018-09-20 13:51:48 --> Security Class Initialized
DEBUG - 2018-09-20 13:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-20 13:51:48 --> CSRF cookie sent
INFO - 2018-09-20 13:51:48 --> Input Class Initialized
INFO - 2018-09-20 13:51:48 --> Language Class Initialized
INFO - 2018-09-20 13:51:48 --> Loader Class Initialized
INFO - 2018-09-20 13:51:48 --> Helper loaded: url_helper
INFO - 2018-09-20 13:51:48 --> Helper loaded: form_helper
INFO - 2018-09-20 13:51:48 --> Helper loaded: language_helper
DEBUG - 2018-09-20 13:51:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-20 13:51:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-20 13:51:48 --> User Agent Class Initialized
INFO - 2018-09-20 13:51:48 --> Controller Class Initialized
INFO - 2018-09-20 13:51:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-20 13:51:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-20 13:51:48 --> Pixel_Model class loaded
INFO - 2018-09-20 13:51:48 --> Database Driver Class Initialized
INFO - 2018-09-20 13:51:48 --> Model "QuestionsModel" initialized
INFO - 2018-09-20 13:51:48 --> Database Driver Class Initialized
INFO - 2018-09-20 13:51:48 --> Model "QuestionsModel" initialized
INFO - 2018-09-20 13:51:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-20 13:51:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-20 13:51:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-20 13:51:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-20 13:51:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-20 13:51:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-20 13:51:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_title.php
INFO - 2018-09-20 13:51:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-20 13:51:48 --> Final output sent to browser
DEBUG - 2018-09-20 13:51:48 --> Total execution time: 0.0554
INFO - 2018-09-20 21:01:13 --> Config Class Initialized
INFO - 2018-09-20 21:01:13 --> Hooks Class Initialized
DEBUG - 2018-09-20 21:01:13 --> UTF-8 Support Enabled
INFO - 2018-09-20 21:01:13 --> Utf8 Class Initialized
INFO - 2018-09-20 21:01:13 --> URI Class Initialized
DEBUG - 2018-09-20 21:01:13 --> No URI present. Default controller set.
INFO - 2018-09-20 21:01:13 --> Router Class Initialized
INFO - 2018-09-20 21:01:13 --> Output Class Initialized
INFO - 2018-09-20 21:01:13 --> Security Class Initialized
DEBUG - 2018-09-20 21:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-20 21:01:13 --> CSRF cookie sent
INFO - 2018-09-20 21:01:13 --> Input Class Initialized
INFO - 2018-09-20 21:01:13 --> Language Class Initialized
INFO - 2018-09-20 21:01:13 --> Loader Class Initialized
INFO - 2018-09-20 21:01:13 --> Helper loaded: url_helper
INFO - 2018-09-20 21:01:13 --> Helper loaded: form_helper
INFO - 2018-09-20 21:01:13 --> Helper loaded: language_helper
DEBUG - 2018-09-20 21:01:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-20 21:01:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-20 21:01:13 --> User Agent Class Initialized
INFO - 2018-09-20 21:01:13 --> Controller Class Initialized
INFO - 2018-09-20 21:01:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-20 21:01:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-20 21:01:13 --> Pixel_Model class loaded
INFO - 2018-09-20 21:01:13 --> Database Driver Class Initialized
INFO - 2018-09-20 21:01:13 --> Model "QuestionsModel" initialized
INFO - 2018-09-20 21:01:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-20 21:01:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-20 21:01:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-09-20 21:01:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-20 21:01:13 --> Final output sent to browser
DEBUG - 2018-09-20 21:01:13 --> Total execution time: 0.0344

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-09-23 19:09:15 --> Config Class Initialized
INFO - 2018-09-23 19:09:15 --> Hooks Class Initialized
DEBUG - 2018-09-23 19:09:15 --> UTF-8 Support Enabled
INFO - 2018-09-23 19:09:15 --> Utf8 Class Initialized
INFO - 2018-09-23 19:09:15 --> URI Class Initialized
DEBUG - 2018-09-23 19:09:15 --> No URI present. Default controller set.
INFO - 2018-09-23 19:09:15 --> Router Class Initialized
INFO - 2018-09-23 19:09:15 --> Output Class Initialized
INFO - 2018-09-23 19:09:15 --> Security Class Initialized
DEBUG - 2018-09-23 19:09:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-23 19:09:15 --> CSRF cookie sent
INFO - 2018-09-23 19:09:15 --> Input Class Initialized
INFO - 2018-09-23 19:09:15 --> Language Class Initialized
INFO - 2018-09-23 19:09:15 --> Loader Class Initialized
INFO - 2018-09-23 19:09:15 --> Helper loaded: url_helper
INFO - 2018-09-23 19:09:15 --> Helper loaded: form_helper
INFO - 2018-09-23 19:09:15 --> Helper loaded: language_helper
DEBUG - 2018-09-23 19:09:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-23 19:09:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-23 19:09:15 --> User Agent Class Initialized
INFO - 2018-09-23 19:09:15 --> Controller Class Initialized
INFO - 2018-09-23 19:09:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-23 19:09:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-23 19:09:15 --> Pixel_Model class loaded
INFO - 2018-09-23 19:09:15 --> Database Driver Class Initialized
INFO - 2018-09-23 19:09:15 --> Model "QuestionsModel" initialized
INFO - 2018-09-23 19:09:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-23 19:09:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-23 19:09:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-09-23 19:09:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-23 19:09:15 --> Final output sent to browser
DEBUG - 2018-09-23 19:09:15 --> Total execution time: 0.0343

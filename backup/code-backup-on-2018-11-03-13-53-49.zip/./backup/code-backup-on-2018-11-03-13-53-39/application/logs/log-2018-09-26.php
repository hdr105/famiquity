<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-09-26 14:29:51 --> Config Class Initialized
INFO - 2018-09-26 14:29:51 --> Hooks Class Initialized
DEBUG - 2018-09-26 14:29:51 --> UTF-8 Support Enabled
INFO - 2018-09-26 14:29:51 --> Utf8 Class Initialized
INFO - 2018-09-26 14:29:51 --> URI Class Initialized
DEBUG - 2018-09-26 14:29:51 --> No URI present. Default controller set.
INFO - 2018-09-26 14:29:51 --> Router Class Initialized
INFO - 2018-09-26 14:29:51 --> Output Class Initialized
INFO - 2018-09-26 14:29:51 --> Security Class Initialized
DEBUG - 2018-09-26 14:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 14:29:51 --> CSRF cookie sent
INFO - 2018-09-26 14:29:51 --> Input Class Initialized
INFO - 2018-09-26 14:29:51 --> Language Class Initialized
INFO - 2018-09-26 14:29:51 --> Loader Class Initialized
INFO - 2018-09-26 14:29:51 --> Helper loaded: url_helper
INFO - 2018-09-26 14:29:51 --> Helper loaded: form_helper
INFO - 2018-09-26 14:29:51 --> Helper loaded: language_helper
DEBUG - 2018-09-26 14:29:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 14:29:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 14:29:51 --> User Agent Class Initialized
INFO - 2018-09-26 14:29:51 --> Controller Class Initialized
INFO - 2018-09-26 14:29:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-26 14:29:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-26 14:29:51 --> Pixel_Model class loaded
INFO - 2018-09-26 14:29:51 --> Database Driver Class Initialized
INFO - 2018-09-26 14:29:51 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 14:29:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-26 14:29:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-26 14:29:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-09-26 14:29:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-26 14:29:51 --> Final output sent to browser
DEBUG - 2018-09-26 14:29:51 --> Total execution time: 0.0390
INFO - 2018-09-26 15:01:33 --> Config Class Initialized
INFO - 2018-09-26 15:01:33 --> Hooks Class Initialized
DEBUG - 2018-09-26 15:01:33 --> UTF-8 Support Enabled
INFO - 2018-09-26 15:01:33 --> Utf8 Class Initialized
INFO - 2018-09-26 15:01:33 --> URI Class Initialized
DEBUG - 2018-09-26 15:01:33 --> No URI present. Default controller set.
INFO - 2018-09-26 15:01:33 --> Router Class Initialized
INFO - 2018-09-26 15:01:33 --> Output Class Initialized
INFO - 2018-09-26 15:01:33 --> Security Class Initialized
DEBUG - 2018-09-26 15:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 15:01:33 --> CSRF cookie sent
INFO - 2018-09-26 15:01:33 --> Input Class Initialized
INFO - 2018-09-26 15:01:33 --> Language Class Initialized
INFO - 2018-09-26 15:01:33 --> Loader Class Initialized
INFO - 2018-09-26 15:01:33 --> Helper loaded: url_helper
INFO - 2018-09-26 15:01:33 --> Helper loaded: form_helper
INFO - 2018-09-26 15:01:33 --> Helper loaded: language_helper
DEBUG - 2018-09-26 15:01:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 15:01:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 15:01:33 --> User Agent Class Initialized
INFO - 2018-09-26 15:01:33 --> Controller Class Initialized
INFO - 2018-09-26 15:01:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-26 15:01:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-26 15:01:33 --> Pixel_Model class loaded
INFO - 2018-09-26 15:01:33 --> Database Driver Class Initialized
INFO - 2018-09-26 15:01:33 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 15:01:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-26 15:01:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-26 15:01:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-09-26 15:01:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-26 15:01:33 --> Final output sent to browser
DEBUG - 2018-09-26 15:01:33 --> Total execution time: 0.0370
INFO - 2018-09-26 15:01:34 --> Config Class Initialized
INFO - 2018-09-26 15:01:34 --> Hooks Class Initialized
DEBUG - 2018-09-26 15:01:34 --> UTF-8 Support Enabled
INFO - 2018-09-26 15:01:34 --> Utf8 Class Initialized
INFO - 2018-09-26 15:01:34 --> URI Class Initialized
DEBUG - 2018-09-26 15:01:34 --> No URI present. Default controller set.
INFO - 2018-09-26 15:01:34 --> Router Class Initialized
INFO - 2018-09-26 15:01:34 --> Output Class Initialized
INFO - 2018-09-26 15:01:34 --> Security Class Initialized
DEBUG - 2018-09-26 15:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 15:01:34 --> CSRF cookie sent
INFO - 2018-09-26 15:01:34 --> Input Class Initialized
INFO - 2018-09-26 15:01:34 --> Language Class Initialized
INFO - 2018-09-26 15:01:34 --> Loader Class Initialized
INFO - 2018-09-26 15:01:34 --> Helper loaded: url_helper
INFO - 2018-09-26 15:01:34 --> Helper loaded: form_helper
INFO - 2018-09-26 15:01:34 --> Helper loaded: language_helper
DEBUG - 2018-09-26 15:01:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 15:01:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 15:01:34 --> User Agent Class Initialized
INFO - 2018-09-26 15:01:34 --> Controller Class Initialized
INFO - 2018-09-26 15:01:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-26 15:01:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-26 15:01:34 --> Pixel_Model class loaded
INFO - 2018-09-26 15:01:34 --> Database Driver Class Initialized
INFO - 2018-09-26 15:01:34 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 15:01:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-26 15:01:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-26 15:01:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-09-26 15:01:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-26 15:01:34 --> Final output sent to browser
DEBUG - 2018-09-26 15:01:34 --> Total execution time: 0.0493
INFO - 2018-09-26 19:46:17 --> Config Class Initialized
INFO - 2018-09-26 19:46:17 --> Hooks Class Initialized
DEBUG - 2018-09-26 19:46:17 --> UTF-8 Support Enabled
INFO - 2018-09-26 19:46:17 --> Utf8 Class Initialized
INFO - 2018-09-26 19:46:17 --> URI Class Initialized
DEBUG - 2018-09-26 19:46:17 --> No URI present. Default controller set.
INFO - 2018-09-26 19:46:17 --> Router Class Initialized
INFO - 2018-09-26 19:46:17 --> Output Class Initialized
INFO - 2018-09-26 19:46:17 --> Security Class Initialized
DEBUG - 2018-09-26 19:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 19:46:17 --> CSRF cookie sent
INFO - 2018-09-26 19:46:17 --> Input Class Initialized
INFO - 2018-09-26 19:46:17 --> Language Class Initialized
INFO - 2018-09-26 19:46:17 --> Loader Class Initialized
INFO - 2018-09-26 19:46:17 --> Helper loaded: url_helper
INFO - 2018-09-26 19:46:17 --> Helper loaded: form_helper
INFO - 2018-09-26 19:46:17 --> Helper loaded: language_helper
DEBUG - 2018-09-26 19:46:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 19:46:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 19:46:17 --> User Agent Class Initialized
INFO - 2018-09-26 19:46:17 --> Controller Class Initialized
INFO - 2018-09-26 19:46:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-26 19:46:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-26 19:46:17 --> Pixel_Model class loaded
INFO - 2018-09-26 19:46:17 --> Database Driver Class Initialized
INFO - 2018-09-26 19:46:17 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 19:46:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-26 19:46:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-26 19:46:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-09-26 19:46:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-26 19:46:17 --> Final output sent to browser
DEBUG - 2018-09-26 19:46:17 --> Total execution time: 0.0430
INFO - 2018-09-26 19:46:18 --> Config Class Initialized
INFO - 2018-09-26 19:46:18 --> Hooks Class Initialized
DEBUG - 2018-09-26 19:46:18 --> UTF-8 Support Enabled
INFO - 2018-09-26 19:46:18 --> Utf8 Class Initialized
INFO - 2018-09-26 19:46:18 --> URI Class Initialized
DEBUG - 2018-09-26 19:46:18 --> No URI present. Default controller set.
INFO - 2018-09-26 19:46:18 --> Router Class Initialized
INFO - 2018-09-26 19:46:18 --> Output Class Initialized
INFO - 2018-09-26 19:46:18 --> Security Class Initialized
DEBUG - 2018-09-26 19:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 19:46:18 --> CSRF cookie sent
INFO - 2018-09-26 19:46:18 --> Input Class Initialized
INFO - 2018-09-26 19:46:18 --> Language Class Initialized
INFO - 2018-09-26 19:46:18 --> Loader Class Initialized
INFO - 2018-09-26 19:46:18 --> Helper loaded: url_helper
INFO - 2018-09-26 19:46:18 --> Helper loaded: form_helper
INFO - 2018-09-26 19:46:18 --> Helper loaded: language_helper
DEBUG - 2018-09-26 19:46:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 19:46:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 19:46:18 --> User Agent Class Initialized
INFO - 2018-09-26 19:46:18 --> Controller Class Initialized
INFO - 2018-09-26 19:46:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-26 19:46:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-26 19:46:18 --> Pixel_Model class loaded
INFO - 2018-09-26 19:46:18 --> Database Driver Class Initialized
INFO - 2018-09-26 19:46:18 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 19:46:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-26 19:46:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-26 19:46:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-09-26 19:46:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-26 19:46:18 --> Final output sent to browser
DEBUG - 2018-09-26 19:46:18 --> Total execution time: 0.0395
INFO - 2018-09-26 19:46:25 --> Config Class Initialized
INFO - 2018-09-26 19:46:25 --> Hooks Class Initialized
DEBUG - 2018-09-26 19:46:25 --> UTF-8 Support Enabled
INFO - 2018-09-26 19:46:25 --> Utf8 Class Initialized
INFO - 2018-09-26 19:46:25 --> URI Class Initialized
INFO - 2018-09-26 19:46:25 --> Router Class Initialized
INFO - 2018-09-26 19:46:25 --> Output Class Initialized
INFO - 2018-09-26 19:46:25 --> Security Class Initialized
DEBUG - 2018-09-26 19:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 19:46:25 --> CSRF cookie sent
INFO - 2018-09-26 19:46:25 --> CSRF token verified
INFO - 2018-09-26 19:46:25 --> Input Class Initialized
INFO - 2018-09-26 19:46:25 --> Language Class Initialized
INFO - 2018-09-26 19:46:25 --> Loader Class Initialized
INFO - 2018-09-26 19:46:25 --> Helper loaded: url_helper
INFO - 2018-09-26 19:46:25 --> Helper loaded: form_helper
INFO - 2018-09-26 19:46:25 --> Helper loaded: language_helper
DEBUG - 2018-09-26 19:46:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 19:46:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 19:46:25 --> User Agent Class Initialized
INFO - 2018-09-26 19:46:25 --> Controller Class Initialized
INFO - 2018-09-26 19:46:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-26 19:46:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-26 19:46:25 --> Pixel_Model class loaded
INFO - 2018-09-26 19:46:25 --> Database Driver Class Initialized
INFO - 2018-09-26 19:46:25 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 19:46:25 --> Database Driver Class Initialized
INFO - 2018-09-26 19:46:25 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 19:46:25 --> Config Class Initialized
INFO - 2018-09-26 19:46:25 --> Hooks Class Initialized
DEBUG - 2018-09-26 19:46:25 --> UTF-8 Support Enabled
INFO - 2018-09-26 19:46:25 --> Utf8 Class Initialized
INFO - 2018-09-26 19:46:25 --> URI Class Initialized
INFO - 2018-09-26 19:46:25 --> Router Class Initialized
INFO - 2018-09-26 19:46:25 --> Output Class Initialized
INFO - 2018-09-26 19:46:25 --> Security Class Initialized
DEBUG - 2018-09-26 19:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 19:46:25 --> CSRF cookie sent
INFO - 2018-09-26 19:46:25 --> Input Class Initialized
INFO - 2018-09-26 19:46:25 --> Language Class Initialized
INFO - 2018-09-26 19:46:25 --> Loader Class Initialized
INFO - 2018-09-26 19:46:25 --> Helper loaded: url_helper
INFO - 2018-09-26 19:46:25 --> Helper loaded: form_helper
INFO - 2018-09-26 19:46:25 --> Helper loaded: language_helper
DEBUG - 2018-09-26 19:46:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 19:46:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 19:46:25 --> User Agent Class Initialized
INFO - 2018-09-26 19:46:25 --> Controller Class Initialized
INFO - 2018-09-26 19:46:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-26 19:46:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-26 19:46:25 --> Pixel_Model class loaded
INFO - 2018-09-26 19:46:25 --> Database Driver Class Initialized
INFO - 2018-09-26 19:46:25 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 19:46:25 --> Database Driver Class Initialized
INFO - 2018-09-26 19:46:25 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 19:46:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-26 19:46:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-26 19:46:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-26 19:46:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-26 19:46:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-26 19:46:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-26 19:46:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-09-26 19:46:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-26 19:46:25 --> Final output sent to browser
DEBUG - 2018-09-26 19:46:25 --> Total execution time: 0.0599
INFO - 2018-09-26 19:46:29 --> Config Class Initialized
INFO - 2018-09-26 19:46:29 --> Hooks Class Initialized
DEBUG - 2018-09-26 19:46:29 --> UTF-8 Support Enabled
INFO - 2018-09-26 19:46:29 --> Utf8 Class Initialized
INFO - 2018-09-26 19:46:29 --> URI Class Initialized
INFO - 2018-09-26 19:46:29 --> Router Class Initialized
INFO - 2018-09-26 19:46:29 --> Output Class Initialized
INFO - 2018-09-26 19:46:29 --> Security Class Initialized
DEBUG - 2018-09-26 19:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 19:46:29 --> CSRF cookie sent
INFO - 2018-09-26 19:46:29 --> CSRF token verified
INFO - 2018-09-26 19:46:29 --> Input Class Initialized
INFO - 2018-09-26 19:46:29 --> Language Class Initialized
INFO - 2018-09-26 19:46:29 --> Loader Class Initialized
INFO - 2018-09-26 19:46:29 --> Helper loaded: url_helper
INFO - 2018-09-26 19:46:29 --> Helper loaded: form_helper
INFO - 2018-09-26 19:46:29 --> Helper loaded: language_helper
DEBUG - 2018-09-26 19:46:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 19:46:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 19:46:29 --> User Agent Class Initialized
INFO - 2018-09-26 19:46:29 --> Controller Class Initialized
INFO - 2018-09-26 19:46:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-26 19:46:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-26 19:46:29 --> Pixel_Model class loaded
INFO - 2018-09-26 19:46:29 --> Database Driver Class Initialized
INFO - 2018-09-26 19:46:29 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 19:46:29 --> Form Validation Class Initialized
INFO - 2018-09-26 19:46:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-26 19:46:29 --> Database Driver Class Initialized
INFO - 2018-09-26 19:46:29 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 19:46:29 --> Config Class Initialized
INFO - 2018-09-26 19:46:29 --> Hooks Class Initialized
DEBUG - 2018-09-26 19:46:29 --> UTF-8 Support Enabled
INFO - 2018-09-26 19:46:29 --> Utf8 Class Initialized
INFO - 2018-09-26 19:46:29 --> URI Class Initialized
INFO - 2018-09-26 19:46:29 --> Router Class Initialized
INFO - 2018-09-26 19:46:29 --> Output Class Initialized
INFO - 2018-09-26 19:46:29 --> Security Class Initialized
DEBUG - 2018-09-26 19:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 19:46:29 --> CSRF cookie sent
INFO - 2018-09-26 19:46:29 --> Input Class Initialized
INFO - 2018-09-26 19:46:29 --> Language Class Initialized
INFO - 2018-09-26 19:46:29 --> Loader Class Initialized
INFO - 2018-09-26 19:46:29 --> Helper loaded: url_helper
INFO - 2018-09-26 19:46:29 --> Helper loaded: form_helper
INFO - 2018-09-26 19:46:29 --> Helper loaded: language_helper
DEBUG - 2018-09-26 19:46:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 19:46:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 19:46:29 --> User Agent Class Initialized
INFO - 2018-09-26 19:46:29 --> Controller Class Initialized
INFO - 2018-09-26 19:46:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-26 19:46:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-26 19:46:29 --> Pixel_Model class loaded
INFO - 2018-09-26 19:46:29 --> Database Driver Class Initialized
INFO - 2018-09-26 19:46:29 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 19:46:29 --> Database Driver Class Initialized
INFO - 2018-09-26 19:46:29 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 19:46:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-26 19:46:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-26 19:46:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-26 19:46:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-26 19:46:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-26 19:46:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-26 19:46:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-09-26 19:46:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-26 19:46:29 --> Final output sent to browser
DEBUG - 2018-09-26 19:46:29 --> Total execution time: 0.0620
INFO - 2018-09-26 19:46:36 --> Config Class Initialized
INFO - 2018-09-26 19:46:36 --> Hooks Class Initialized
DEBUG - 2018-09-26 19:46:36 --> UTF-8 Support Enabled
INFO - 2018-09-26 19:46:36 --> Utf8 Class Initialized
INFO - 2018-09-26 19:46:36 --> URI Class Initialized
INFO - 2018-09-26 19:46:36 --> Router Class Initialized
INFO - 2018-09-26 19:46:36 --> Output Class Initialized
INFO - 2018-09-26 19:46:36 --> Security Class Initialized
DEBUG - 2018-09-26 19:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 19:46:36 --> CSRF cookie sent
INFO - 2018-09-26 19:46:36 --> CSRF token verified
INFO - 2018-09-26 19:46:36 --> Input Class Initialized
INFO - 2018-09-26 19:46:36 --> Language Class Initialized
INFO - 2018-09-26 19:46:36 --> Loader Class Initialized
INFO - 2018-09-26 19:46:36 --> Helper loaded: url_helper
INFO - 2018-09-26 19:46:36 --> Helper loaded: form_helper
INFO - 2018-09-26 19:46:36 --> Helper loaded: language_helper
DEBUG - 2018-09-26 19:46:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 19:46:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 19:46:36 --> User Agent Class Initialized
INFO - 2018-09-26 19:46:36 --> Controller Class Initialized
INFO - 2018-09-26 19:46:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-26 19:46:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-26 19:46:36 --> Pixel_Model class loaded
INFO - 2018-09-26 19:46:36 --> Database Driver Class Initialized
INFO - 2018-09-26 19:46:36 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 19:46:36 --> Form Validation Class Initialized
INFO - 2018-09-26 19:46:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-26 19:46:36 --> Database Driver Class Initialized
INFO - 2018-09-26 19:46:36 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 19:46:36 --> Config Class Initialized
INFO - 2018-09-26 19:46:36 --> Hooks Class Initialized
DEBUG - 2018-09-26 19:46:36 --> UTF-8 Support Enabled
INFO - 2018-09-26 19:46:36 --> Utf8 Class Initialized
INFO - 2018-09-26 19:46:36 --> URI Class Initialized
INFO - 2018-09-26 19:46:36 --> Router Class Initialized
INFO - 2018-09-26 19:46:36 --> Output Class Initialized
INFO - 2018-09-26 19:46:36 --> Security Class Initialized
DEBUG - 2018-09-26 19:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 19:46:36 --> CSRF cookie sent
INFO - 2018-09-26 19:46:36 --> Input Class Initialized
INFO - 2018-09-26 19:46:36 --> Language Class Initialized
INFO - 2018-09-26 19:46:36 --> Loader Class Initialized
INFO - 2018-09-26 19:46:36 --> Helper loaded: url_helper
INFO - 2018-09-26 19:46:36 --> Helper loaded: form_helper
INFO - 2018-09-26 19:46:36 --> Helper loaded: language_helper
DEBUG - 2018-09-26 19:46:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 19:46:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 19:46:36 --> User Agent Class Initialized
INFO - 2018-09-26 19:46:36 --> Controller Class Initialized
INFO - 2018-09-26 19:46:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-26 19:46:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-26 19:46:36 --> Pixel_Model class loaded
INFO - 2018-09-26 19:46:36 --> Database Driver Class Initialized
INFO - 2018-09-26 19:46:36 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 19:46:36 --> Database Driver Class Initialized
INFO - 2018-09-26 19:46:36 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 19:46:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-26 19:46:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-26 19:46:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-09-26 19:46:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-26 19:46:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-26 19:46:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-26 19:46:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-26 19:46:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-09-26 19:46:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-26 19:46:36 --> Final output sent to browser
DEBUG - 2018-09-26 19:46:36 --> Total execution time: 0.0395
INFO - 2018-09-26 19:46:46 --> Config Class Initialized
INFO - 2018-09-26 19:46:46 --> Hooks Class Initialized
DEBUG - 2018-09-26 19:46:46 --> UTF-8 Support Enabled
INFO - 2018-09-26 19:46:46 --> Utf8 Class Initialized
INFO - 2018-09-26 19:46:46 --> URI Class Initialized
INFO - 2018-09-26 19:46:46 --> Router Class Initialized
INFO - 2018-09-26 19:46:46 --> Output Class Initialized
INFO - 2018-09-26 19:46:46 --> Security Class Initialized
DEBUG - 2018-09-26 19:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 19:46:46 --> CSRF cookie sent
INFO - 2018-09-26 19:46:46 --> CSRF token verified
INFO - 2018-09-26 19:46:46 --> Input Class Initialized
INFO - 2018-09-26 19:46:46 --> Language Class Initialized
INFO - 2018-09-26 19:46:46 --> Loader Class Initialized
INFO - 2018-09-26 19:46:46 --> Helper loaded: url_helper
INFO - 2018-09-26 19:46:46 --> Helper loaded: form_helper
INFO - 2018-09-26 19:46:46 --> Helper loaded: language_helper
DEBUG - 2018-09-26 19:46:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 19:46:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 19:46:46 --> User Agent Class Initialized
INFO - 2018-09-26 19:46:46 --> Controller Class Initialized
INFO - 2018-09-26 19:46:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-26 19:46:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-26 19:46:46 --> Pixel_Model class loaded
INFO - 2018-09-26 19:46:46 --> Database Driver Class Initialized
INFO - 2018-09-26 19:46:46 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 19:46:46 --> Form Validation Class Initialized
INFO - 2018-09-26 19:46:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-26 19:46:46 --> Database Driver Class Initialized
INFO - 2018-09-26 19:46:46 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 19:46:46 --> Config Class Initialized
INFO - 2018-09-26 19:46:46 --> Hooks Class Initialized
DEBUG - 2018-09-26 19:46:46 --> UTF-8 Support Enabled
INFO - 2018-09-26 19:46:46 --> Utf8 Class Initialized
INFO - 2018-09-26 19:46:46 --> URI Class Initialized
INFO - 2018-09-26 19:46:46 --> Router Class Initialized
INFO - 2018-09-26 19:46:46 --> Output Class Initialized
INFO - 2018-09-26 19:46:46 --> Security Class Initialized
DEBUG - 2018-09-26 19:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 19:46:46 --> CSRF cookie sent
INFO - 2018-09-26 19:46:46 --> Input Class Initialized
INFO - 2018-09-26 19:46:46 --> Language Class Initialized
INFO - 2018-09-26 19:46:46 --> Loader Class Initialized
INFO - 2018-09-26 19:46:46 --> Helper loaded: url_helper
INFO - 2018-09-26 19:46:46 --> Helper loaded: form_helper
INFO - 2018-09-26 19:46:46 --> Helper loaded: language_helper
DEBUG - 2018-09-26 19:46:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 19:46:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 19:46:46 --> User Agent Class Initialized
INFO - 2018-09-26 19:46:46 --> Controller Class Initialized
INFO - 2018-09-26 19:46:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-26 19:46:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-26 19:46:46 --> Pixel_Model class loaded
INFO - 2018-09-26 19:46:46 --> Database Driver Class Initialized
INFO - 2018-09-26 19:46:46 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 19:46:46 --> Database Driver Class Initialized
INFO - 2018-09-26 19:46:46 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 19:46:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-26 19:46:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-26 19:46:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-26 19:46:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-26 19:46:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-26 19:46:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-26 19:46:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-09-26 19:46:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-26 19:46:46 --> Final output sent to browser
DEBUG - 2018-09-26 19:46:46 --> Total execution time: 0.0374
INFO - 2018-09-26 19:46:54 --> Config Class Initialized
INFO - 2018-09-26 19:46:54 --> Hooks Class Initialized
DEBUG - 2018-09-26 19:46:54 --> UTF-8 Support Enabled
INFO - 2018-09-26 19:46:54 --> Utf8 Class Initialized
INFO - 2018-09-26 19:46:54 --> URI Class Initialized
INFO - 2018-09-26 19:46:54 --> Router Class Initialized
INFO - 2018-09-26 19:46:54 --> Output Class Initialized
INFO - 2018-09-26 19:46:54 --> Security Class Initialized
DEBUG - 2018-09-26 19:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 19:46:54 --> CSRF cookie sent
INFO - 2018-09-26 19:46:54 --> CSRF token verified
INFO - 2018-09-26 19:46:54 --> Input Class Initialized
INFO - 2018-09-26 19:46:54 --> Language Class Initialized
INFO - 2018-09-26 19:46:54 --> Loader Class Initialized
INFO - 2018-09-26 19:46:54 --> Helper loaded: url_helper
INFO - 2018-09-26 19:46:54 --> Helper loaded: form_helper
INFO - 2018-09-26 19:46:54 --> Helper loaded: language_helper
DEBUG - 2018-09-26 19:46:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 19:46:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 19:46:54 --> User Agent Class Initialized
INFO - 2018-09-26 19:46:54 --> Controller Class Initialized
INFO - 2018-09-26 19:46:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-26 19:46:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-26 19:46:54 --> Pixel_Model class loaded
INFO - 2018-09-26 19:46:54 --> Database Driver Class Initialized
INFO - 2018-09-26 19:46:54 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 19:46:54 --> Form Validation Class Initialized
INFO - 2018-09-26 19:46:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-26 19:46:54 --> Database Driver Class Initialized
INFO - 2018-09-26 19:46:54 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 19:46:54 --> Config Class Initialized
INFO - 2018-09-26 19:46:54 --> Hooks Class Initialized
DEBUG - 2018-09-26 19:46:54 --> UTF-8 Support Enabled
INFO - 2018-09-26 19:46:54 --> Utf8 Class Initialized
INFO - 2018-09-26 19:46:54 --> URI Class Initialized
INFO - 2018-09-26 19:46:54 --> Router Class Initialized
INFO - 2018-09-26 19:46:54 --> Output Class Initialized
INFO - 2018-09-26 19:46:54 --> Security Class Initialized
DEBUG - 2018-09-26 19:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 19:46:54 --> CSRF cookie sent
INFO - 2018-09-26 19:46:54 --> Input Class Initialized
INFO - 2018-09-26 19:46:54 --> Language Class Initialized
INFO - 2018-09-26 19:46:54 --> Loader Class Initialized
INFO - 2018-09-26 19:46:54 --> Helper loaded: url_helper
INFO - 2018-09-26 19:46:54 --> Helper loaded: form_helper
INFO - 2018-09-26 19:46:54 --> Helper loaded: language_helper
DEBUG - 2018-09-26 19:46:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 19:46:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 19:46:54 --> User Agent Class Initialized
INFO - 2018-09-26 19:46:54 --> Controller Class Initialized
INFO - 2018-09-26 19:46:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-26 19:46:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-26 19:46:54 --> Pixel_Model class loaded
INFO - 2018-09-26 19:46:54 --> Database Driver Class Initialized
INFO - 2018-09-26 19:46:54 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 19:46:54 --> Database Driver Class Initialized
INFO - 2018-09-26 19:46:54 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 19:46:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-26 19:46:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-26 19:46:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-26 19:46:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-26 19:46:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-26 19:46:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-26 19:46:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-09-26 19:46:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-26 19:46:54 --> Final output sent to browser
DEBUG - 2018-09-26 19:46:54 --> Total execution time: 0.0447
INFO - 2018-09-26 19:46:59 --> Config Class Initialized
INFO - 2018-09-26 19:46:59 --> Hooks Class Initialized
DEBUG - 2018-09-26 19:46:59 --> UTF-8 Support Enabled
INFO - 2018-09-26 19:46:59 --> Utf8 Class Initialized
INFO - 2018-09-26 19:46:59 --> URI Class Initialized
INFO - 2018-09-26 19:46:59 --> Router Class Initialized
INFO - 2018-09-26 19:46:59 --> Output Class Initialized
INFO - 2018-09-26 19:46:59 --> Security Class Initialized
DEBUG - 2018-09-26 19:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 19:46:59 --> CSRF cookie sent
INFO - 2018-09-26 19:46:59 --> CSRF token verified
INFO - 2018-09-26 19:46:59 --> Input Class Initialized
INFO - 2018-09-26 19:46:59 --> Language Class Initialized
INFO - 2018-09-26 19:46:59 --> Loader Class Initialized
INFO - 2018-09-26 19:46:59 --> Helper loaded: url_helper
INFO - 2018-09-26 19:46:59 --> Helper loaded: form_helper
INFO - 2018-09-26 19:46:59 --> Helper loaded: language_helper
DEBUG - 2018-09-26 19:46:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 19:46:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 19:46:59 --> User Agent Class Initialized
INFO - 2018-09-26 19:46:59 --> Controller Class Initialized
INFO - 2018-09-26 19:46:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-26 19:46:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-26 19:46:59 --> Pixel_Model class loaded
INFO - 2018-09-26 19:46:59 --> Database Driver Class Initialized
INFO - 2018-09-26 19:46:59 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 19:46:59 --> Form Validation Class Initialized
INFO - 2018-09-26 19:46:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-26 19:46:59 --> Database Driver Class Initialized
INFO - 2018-09-26 19:46:59 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 19:46:59 --> Config Class Initialized
INFO - 2018-09-26 19:46:59 --> Hooks Class Initialized
DEBUG - 2018-09-26 19:46:59 --> UTF-8 Support Enabled
INFO - 2018-09-26 19:46:59 --> Utf8 Class Initialized
INFO - 2018-09-26 19:46:59 --> URI Class Initialized
INFO - 2018-09-26 19:46:59 --> Router Class Initialized
INFO - 2018-09-26 19:46:59 --> Output Class Initialized
INFO - 2018-09-26 19:46:59 --> Security Class Initialized
DEBUG - 2018-09-26 19:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 19:46:59 --> CSRF cookie sent
INFO - 2018-09-26 19:46:59 --> Input Class Initialized
INFO - 2018-09-26 19:46:59 --> Language Class Initialized
INFO - 2018-09-26 19:46:59 --> Loader Class Initialized
INFO - 2018-09-26 19:46:59 --> Helper loaded: url_helper
INFO - 2018-09-26 19:46:59 --> Helper loaded: form_helper
INFO - 2018-09-26 19:46:59 --> Helper loaded: language_helper
DEBUG - 2018-09-26 19:46:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 19:46:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 19:46:59 --> User Agent Class Initialized
INFO - 2018-09-26 19:46:59 --> Controller Class Initialized
INFO - 2018-09-26 19:46:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-26 19:46:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-26 19:46:59 --> Pixel_Model class loaded
INFO - 2018-09-26 19:46:59 --> Database Driver Class Initialized
INFO - 2018-09-26 19:46:59 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 19:46:59 --> Database Driver Class Initialized
INFO - 2018-09-26 19:46:59 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 19:46:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-26 19:46:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-26 19:46:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-26 19:46:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-26 19:46:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-26 19:46:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-26 19:46:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_title.php
INFO - 2018-09-26 19:46:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-26 19:46:59 --> Final output sent to browser
DEBUG - 2018-09-26 19:46:59 --> Total execution time: 0.0465
INFO - 2018-09-26 19:47:07 --> Config Class Initialized
INFO - 2018-09-26 19:47:07 --> Hooks Class Initialized
DEBUG - 2018-09-26 19:47:07 --> UTF-8 Support Enabled
INFO - 2018-09-26 19:47:07 --> Utf8 Class Initialized
INFO - 2018-09-26 19:47:07 --> URI Class Initialized
INFO - 2018-09-26 19:47:07 --> Router Class Initialized
INFO - 2018-09-26 19:47:07 --> Output Class Initialized
INFO - 2018-09-26 19:47:07 --> Security Class Initialized
DEBUG - 2018-09-26 19:47:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 19:47:07 --> CSRF cookie sent
INFO - 2018-09-26 19:47:07 --> CSRF token verified
INFO - 2018-09-26 19:47:07 --> Input Class Initialized
INFO - 2018-09-26 19:47:07 --> Language Class Initialized
INFO - 2018-09-26 19:47:07 --> Loader Class Initialized
INFO - 2018-09-26 19:47:07 --> Helper loaded: url_helper
INFO - 2018-09-26 19:47:07 --> Helper loaded: form_helper
INFO - 2018-09-26 19:47:07 --> Helper loaded: language_helper
DEBUG - 2018-09-26 19:47:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 19:47:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 19:47:07 --> User Agent Class Initialized
INFO - 2018-09-26 19:47:07 --> Controller Class Initialized
INFO - 2018-09-26 19:47:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-26 19:47:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-26 19:47:07 --> Pixel_Model class loaded
INFO - 2018-09-26 19:47:07 --> Database Driver Class Initialized
INFO - 2018-09-26 19:47:07 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 19:47:07 --> Form Validation Class Initialized
INFO - 2018-09-26 19:47:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-26 19:47:07 --> Database Driver Class Initialized
INFO - 2018-09-26 19:47:07 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 19:47:07 --> Config Class Initialized
INFO - 2018-09-26 19:47:07 --> Hooks Class Initialized
DEBUG - 2018-09-26 19:47:07 --> UTF-8 Support Enabled
INFO - 2018-09-26 19:47:07 --> Utf8 Class Initialized
INFO - 2018-09-26 19:47:07 --> URI Class Initialized
INFO - 2018-09-26 19:47:07 --> Router Class Initialized
INFO - 2018-09-26 19:47:07 --> Output Class Initialized
INFO - 2018-09-26 19:47:07 --> Security Class Initialized
DEBUG - 2018-09-26 19:47:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 19:47:07 --> CSRF cookie sent
INFO - 2018-09-26 19:47:07 --> Input Class Initialized
INFO - 2018-09-26 19:47:07 --> Language Class Initialized
INFO - 2018-09-26 19:47:07 --> Loader Class Initialized
INFO - 2018-09-26 19:47:07 --> Helper loaded: url_helper
INFO - 2018-09-26 19:47:07 --> Helper loaded: form_helper
INFO - 2018-09-26 19:47:07 --> Helper loaded: language_helper
DEBUG - 2018-09-26 19:47:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 19:47:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 19:47:07 --> User Agent Class Initialized
INFO - 2018-09-26 19:47:07 --> Controller Class Initialized
INFO - 2018-09-26 19:47:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-26 19:47:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-26 19:47:07 --> Pixel_Model class loaded
INFO - 2018-09-26 19:47:07 --> Database Driver Class Initialized
INFO - 2018-09-26 19:47:07 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 19:47:07 --> Database Driver Class Initialized
INFO - 2018-09-26 19:47:07 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 19:47:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-26 19:47:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-26 19:47:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-26 19:47:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-26 19:47:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-26 19:47:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-26 19:47:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-09-26 19:47:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-26 19:47:07 --> Final output sent to browser
DEBUG - 2018-09-26 19:47:07 --> Total execution time: 0.0475
INFO - 2018-09-26 19:47:13 --> Config Class Initialized
INFO - 2018-09-26 19:47:13 --> Hooks Class Initialized
DEBUG - 2018-09-26 19:47:13 --> UTF-8 Support Enabled
INFO - 2018-09-26 19:47:13 --> Utf8 Class Initialized
INFO - 2018-09-26 19:47:13 --> URI Class Initialized
INFO - 2018-09-26 19:47:13 --> Router Class Initialized
INFO - 2018-09-26 19:47:13 --> Output Class Initialized
INFO - 2018-09-26 19:47:13 --> Security Class Initialized
DEBUG - 2018-09-26 19:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 19:47:13 --> CSRF cookie sent
INFO - 2018-09-26 19:47:13 --> CSRF token verified
INFO - 2018-09-26 19:47:13 --> Input Class Initialized
INFO - 2018-09-26 19:47:13 --> Language Class Initialized
INFO - 2018-09-26 19:47:13 --> Loader Class Initialized
INFO - 2018-09-26 19:47:13 --> Helper loaded: url_helper
INFO - 2018-09-26 19:47:13 --> Helper loaded: form_helper
INFO - 2018-09-26 19:47:13 --> Helper loaded: language_helper
DEBUG - 2018-09-26 19:47:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 19:47:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 19:47:13 --> User Agent Class Initialized
INFO - 2018-09-26 19:47:14 --> Controller Class Initialized
INFO - 2018-09-26 19:47:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-26 19:47:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-26 19:47:14 --> Pixel_Model class loaded
INFO - 2018-09-26 19:47:14 --> Database Driver Class Initialized
INFO - 2018-09-26 19:47:14 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 19:47:14 --> Form Validation Class Initialized
INFO - 2018-09-26 19:47:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-26 19:47:14 --> Database Driver Class Initialized
INFO - 2018-09-26 19:47:14 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 19:47:14 --> Config Class Initialized
INFO - 2018-09-26 19:47:14 --> Hooks Class Initialized
DEBUG - 2018-09-26 19:47:14 --> UTF-8 Support Enabled
INFO - 2018-09-26 19:47:14 --> Utf8 Class Initialized
INFO - 2018-09-26 19:47:14 --> URI Class Initialized
INFO - 2018-09-26 19:47:14 --> Router Class Initialized
INFO - 2018-09-26 19:47:14 --> Output Class Initialized
INFO - 2018-09-26 19:47:14 --> Security Class Initialized
DEBUG - 2018-09-26 19:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 19:47:14 --> CSRF cookie sent
INFO - 2018-09-26 19:47:14 --> Input Class Initialized
INFO - 2018-09-26 19:47:14 --> Language Class Initialized
INFO - 2018-09-26 19:47:14 --> Loader Class Initialized
INFO - 2018-09-26 19:47:14 --> Helper loaded: url_helper
INFO - 2018-09-26 19:47:14 --> Helper loaded: form_helper
INFO - 2018-09-26 19:47:14 --> Helper loaded: language_helper
DEBUG - 2018-09-26 19:47:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 19:47:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 19:47:14 --> User Agent Class Initialized
INFO - 2018-09-26 19:47:14 --> Controller Class Initialized
INFO - 2018-09-26 19:47:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-26 19:47:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-26 19:47:14 --> Pixel_Model class loaded
INFO - 2018-09-26 19:47:14 --> Database Driver Class Initialized
INFO - 2018-09-26 19:47:14 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 19:47:14 --> Config Class Initialized
INFO - 2018-09-26 19:47:14 --> Hooks Class Initialized
DEBUG - 2018-09-26 19:47:14 --> UTF-8 Support Enabled
INFO - 2018-09-26 19:47:14 --> Utf8 Class Initialized
INFO - 2018-09-26 19:47:14 --> URI Class Initialized
INFO - 2018-09-26 19:47:14 --> Router Class Initialized
INFO - 2018-09-26 19:47:14 --> Output Class Initialized
INFO - 2018-09-26 19:47:14 --> Security Class Initialized
DEBUG - 2018-09-26 19:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 19:47:14 --> CSRF cookie sent
INFO - 2018-09-26 19:47:14 --> Input Class Initialized
INFO - 2018-09-26 19:47:14 --> Language Class Initialized
INFO - 2018-09-26 19:47:14 --> Loader Class Initialized
INFO - 2018-09-26 19:47:14 --> Helper loaded: url_helper
INFO - 2018-09-26 19:47:14 --> Helper loaded: form_helper
INFO - 2018-09-26 19:47:14 --> Helper loaded: language_helper
DEBUG - 2018-09-26 19:47:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 19:47:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 19:47:14 --> User Agent Class Initialized
INFO - 2018-09-26 19:47:14 --> Controller Class Initialized
INFO - 2018-09-26 19:47:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-26 19:47:14 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-09-26 19:47:14 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-09-26 19:47:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-26 19:47:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-26 19:47:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-26 19:47:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-09-26 19:47:14 --> Could not find the language line "req_email"
INFO - 2018-09-26 19:47:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-09-26 19:47:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-26 19:47:14 --> Final output sent to browser
DEBUG - 2018-09-26 19:47:14 --> Total execution time: 0.0273
INFO - 2018-09-26 20:32:51 --> Config Class Initialized
INFO - 2018-09-26 20:32:51 --> Hooks Class Initialized
DEBUG - 2018-09-26 20:32:51 --> UTF-8 Support Enabled
INFO - 2018-09-26 20:32:51 --> Utf8 Class Initialized
INFO - 2018-09-26 20:32:51 --> URI Class Initialized
DEBUG - 2018-09-26 20:32:51 --> No URI present. Default controller set.
INFO - 2018-09-26 20:32:51 --> Router Class Initialized
INFO - 2018-09-26 20:32:51 --> Output Class Initialized
INFO - 2018-09-26 20:32:51 --> Security Class Initialized
DEBUG - 2018-09-26 20:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 20:32:51 --> CSRF cookie sent
INFO - 2018-09-26 20:32:51 --> Input Class Initialized
INFO - 2018-09-26 20:32:51 --> Language Class Initialized
INFO - 2018-09-26 20:32:51 --> Loader Class Initialized
INFO - 2018-09-26 20:32:51 --> Helper loaded: url_helper
INFO - 2018-09-26 20:32:51 --> Helper loaded: form_helper
INFO - 2018-09-26 20:32:51 --> Helper loaded: language_helper
DEBUG - 2018-09-26 20:32:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 20:32:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 20:32:51 --> User Agent Class Initialized
INFO - 2018-09-26 20:32:51 --> Controller Class Initialized
INFO - 2018-09-26 20:32:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-26 20:32:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-26 20:32:51 --> Pixel_Model class loaded
INFO - 2018-09-26 20:32:51 --> Database Driver Class Initialized
INFO - 2018-09-26 20:32:51 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:32:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-26 20:32:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-26 20:32:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-09-26 20:32:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-26 20:32:51 --> Final output sent to browser
DEBUG - 2018-09-26 20:32:51 --> Total execution time: 0.0335
INFO - 2018-09-26 20:32:52 --> Config Class Initialized
INFO - 2018-09-26 20:32:52 --> Hooks Class Initialized
DEBUG - 2018-09-26 20:32:52 --> UTF-8 Support Enabled
INFO - 2018-09-26 20:32:52 --> Utf8 Class Initialized
INFO - 2018-09-26 20:32:52 --> URI Class Initialized
DEBUG - 2018-09-26 20:32:52 --> No URI present. Default controller set.
INFO - 2018-09-26 20:32:52 --> Router Class Initialized
INFO - 2018-09-26 20:32:52 --> Output Class Initialized
INFO - 2018-09-26 20:32:52 --> Security Class Initialized
DEBUG - 2018-09-26 20:32:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 20:32:52 --> CSRF cookie sent
INFO - 2018-09-26 20:32:52 --> Input Class Initialized
INFO - 2018-09-26 20:32:52 --> Language Class Initialized
INFO - 2018-09-26 20:32:52 --> Loader Class Initialized
INFO - 2018-09-26 20:32:52 --> Helper loaded: url_helper
INFO - 2018-09-26 20:32:52 --> Helper loaded: form_helper
INFO - 2018-09-26 20:32:52 --> Helper loaded: language_helper
DEBUG - 2018-09-26 20:32:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 20:32:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 20:32:52 --> User Agent Class Initialized
INFO - 2018-09-26 20:32:52 --> Controller Class Initialized
INFO - 2018-09-26 20:32:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-26 20:32:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-26 20:32:52 --> Pixel_Model class loaded
INFO - 2018-09-26 20:32:52 --> Database Driver Class Initialized
INFO - 2018-09-26 20:32:52 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:32:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-26 20:32:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-26 20:32:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-09-26 20:32:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-26 20:32:52 --> Final output sent to browser
DEBUG - 2018-09-26 20:32:52 --> Total execution time: 0.0321
INFO - 2018-09-26 20:33:05 --> Config Class Initialized
INFO - 2018-09-26 20:33:05 --> Hooks Class Initialized
DEBUG - 2018-09-26 20:33:05 --> UTF-8 Support Enabled
INFO - 2018-09-26 20:33:05 --> Utf8 Class Initialized
INFO - 2018-09-26 20:33:05 --> URI Class Initialized
INFO - 2018-09-26 20:33:05 --> Router Class Initialized
INFO - 2018-09-26 20:33:05 --> Output Class Initialized
INFO - 2018-09-26 20:33:05 --> Security Class Initialized
DEBUG - 2018-09-26 20:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 20:33:05 --> CSRF cookie sent
INFO - 2018-09-26 20:33:05 --> CSRF token verified
INFO - 2018-09-26 20:33:05 --> Input Class Initialized
INFO - 2018-09-26 20:33:05 --> Language Class Initialized
INFO - 2018-09-26 20:33:05 --> Loader Class Initialized
INFO - 2018-09-26 20:33:05 --> Helper loaded: url_helper
INFO - 2018-09-26 20:33:05 --> Helper loaded: form_helper
INFO - 2018-09-26 20:33:05 --> Helper loaded: language_helper
DEBUG - 2018-09-26 20:33:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 20:33:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 20:33:05 --> User Agent Class Initialized
INFO - 2018-09-26 20:33:05 --> Controller Class Initialized
INFO - 2018-09-26 20:33:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-26 20:33:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-26 20:33:05 --> Pixel_Model class loaded
INFO - 2018-09-26 20:33:05 --> Database Driver Class Initialized
INFO - 2018-09-26 20:33:05 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:33:05 --> Database Driver Class Initialized
INFO - 2018-09-26 20:33:05 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:33:05 --> Config Class Initialized
INFO - 2018-09-26 20:33:05 --> Hooks Class Initialized
DEBUG - 2018-09-26 20:33:05 --> UTF-8 Support Enabled
INFO - 2018-09-26 20:33:05 --> Utf8 Class Initialized
INFO - 2018-09-26 20:33:05 --> URI Class Initialized
INFO - 2018-09-26 20:33:05 --> Router Class Initialized
INFO - 2018-09-26 20:33:05 --> Output Class Initialized
INFO - 2018-09-26 20:33:05 --> Security Class Initialized
DEBUG - 2018-09-26 20:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 20:33:05 --> CSRF cookie sent
INFO - 2018-09-26 20:33:05 --> Input Class Initialized
INFO - 2018-09-26 20:33:05 --> Language Class Initialized
INFO - 2018-09-26 20:33:05 --> Loader Class Initialized
INFO - 2018-09-26 20:33:05 --> Helper loaded: url_helper
INFO - 2018-09-26 20:33:05 --> Helper loaded: form_helper
INFO - 2018-09-26 20:33:05 --> Helper loaded: language_helper
DEBUG - 2018-09-26 20:33:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 20:33:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 20:33:05 --> User Agent Class Initialized
INFO - 2018-09-26 20:33:05 --> Controller Class Initialized
INFO - 2018-09-26 20:33:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-26 20:33:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-26 20:33:05 --> Pixel_Model class loaded
INFO - 2018-09-26 20:33:05 --> Database Driver Class Initialized
INFO - 2018-09-26 20:33:05 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:33:05 --> Database Driver Class Initialized
INFO - 2018-09-26 20:33:05 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:33:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-26 20:33:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-26 20:33:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-26 20:33:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-26 20:33:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-26 20:33:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-26 20:33:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-09-26 20:33:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-26 20:33:05 --> Final output sent to browser
DEBUG - 2018-09-26 20:33:05 --> Total execution time: 0.0541
INFO - 2018-09-26 20:33:09 --> Config Class Initialized
INFO - 2018-09-26 20:33:09 --> Hooks Class Initialized
DEBUG - 2018-09-26 20:33:09 --> UTF-8 Support Enabled
INFO - 2018-09-26 20:33:09 --> Utf8 Class Initialized
INFO - 2018-09-26 20:33:09 --> URI Class Initialized
INFO - 2018-09-26 20:33:09 --> Router Class Initialized
INFO - 2018-09-26 20:33:09 --> Output Class Initialized
INFO - 2018-09-26 20:33:09 --> Security Class Initialized
DEBUG - 2018-09-26 20:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 20:33:09 --> CSRF cookie sent
INFO - 2018-09-26 20:33:09 --> CSRF token verified
INFO - 2018-09-26 20:33:09 --> Input Class Initialized
INFO - 2018-09-26 20:33:09 --> Language Class Initialized
INFO - 2018-09-26 20:33:09 --> Loader Class Initialized
INFO - 2018-09-26 20:33:09 --> Helper loaded: url_helper
INFO - 2018-09-26 20:33:09 --> Helper loaded: form_helper
INFO - 2018-09-26 20:33:09 --> Helper loaded: language_helper
DEBUG - 2018-09-26 20:33:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 20:33:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 20:33:09 --> User Agent Class Initialized
INFO - 2018-09-26 20:33:09 --> Controller Class Initialized
INFO - 2018-09-26 20:33:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-26 20:33:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-26 20:33:09 --> Pixel_Model class loaded
INFO - 2018-09-26 20:33:09 --> Database Driver Class Initialized
INFO - 2018-09-26 20:33:09 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:33:09 --> Form Validation Class Initialized
INFO - 2018-09-26 20:33:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-26 20:33:09 --> Database Driver Class Initialized
INFO - 2018-09-26 20:33:09 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:33:09 --> Config Class Initialized
INFO - 2018-09-26 20:33:09 --> Hooks Class Initialized
DEBUG - 2018-09-26 20:33:09 --> UTF-8 Support Enabled
INFO - 2018-09-26 20:33:09 --> Utf8 Class Initialized
INFO - 2018-09-26 20:33:09 --> URI Class Initialized
INFO - 2018-09-26 20:33:09 --> Router Class Initialized
INFO - 2018-09-26 20:33:09 --> Output Class Initialized
INFO - 2018-09-26 20:33:09 --> Security Class Initialized
DEBUG - 2018-09-26 20:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 20:33:09 --> CSRF cookie sent
INFO - 2018-09-26 20:33:09 --> Input Class Initialized
INFO - 2018-09-26 20:33:09 --> Language Class Initialized
INFO - 2018-09-26 20:33:09 --> Loader Class Initialized
INFO - 2018-09-26 20:33:09 --> Helper loaded: url_helper
INFO - 2018-09-26 20:33:09 --> Helper loaded: form_helper
INFO - 2018-09-26 20:33:09 --> Helper loaded: language_helper
DEBUG - 2018-09-26 20:33:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 20:33:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 20:33:09 --> User Agent Class Initialized
INFO - 2018-09-26 20:33:09 --> Controller Class Initialized
INFO - 2018-09-26 20:33:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-26 20:33:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-26 20:33:09 --> Pixel_Model class loaded
INFO - 2018-09-26 20:33:09 --> Database Driver Class Initialized
INFO - 2018-09-26 20:33:09 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:33:09 --> Database Driver Class Initialized
INFO - 2018-09-26 20:33:09 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:33:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-26 20:33:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-26 20:33:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-26 20:33:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-26 20:33:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-26 20:33:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-26 20:33:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-09-26 20:33:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-26 20:33:09 --> Final output sent to browser
DEBUG - 2018-09-26 20:33:09 --> Total execution time: 0.0808
INFO - 2018-09-26 20:33:13 --> Config Class Initialized
INFO - 2018-09-26 20:33:13 --> Hooks Class Initialized
DEBUG - 2018-09-26 20:33:13 --> UTF-8 Support Enabled
INFO - 2018-09-26 20:33:13 --> Utf8 Class Initialized
INFO - 2018-09-26 20:33:13 --> URI Class Initialized
INFO - 2018-09-26 20:33:13 --> Router Class Initialized
INFO - 2018-09-26 20:33:13 --> Output Class Initialized
INFO - 2018-09-26 20:33:13 --> Security Class Initialized
DEBUG - 2018-09-26 20:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 20:33:13 --> CSRF cookie sent
INFO - 2018-09-26 20:33:13 --> CSRF token verified
INFO - 2018-09-26 20:33:13 --> Input Class Initialized
INFO - 2018-09-26 20:33:13 --> Language Class Initialized
INFO - 2018-09-26 20:33:13 --> Loader Class Initialized
INFO - 2018-09-26 20:33:13 --> Helper loaded: url_helper
INFO - 2018-09-26 20:33:13 --> Helper loaded: form_helper
INFO - 2018-09-26 20:33:13 --> Helper loaded: language_helper
DEBUG - 2018-09-26 20:33:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 20:33:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 20:33:13 --> User Agent Class Initialized
INFO - 2018-09-26 20:33:13 --> Controller Class Initialized
INFO - 2018-09-26 20:33:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-26 20:33:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-26 20:33:13 --> Pixel_Model class loaded
INFO - 2018-09-26 20:33:13 --> Database Driver Class Initialized
INFO - 2018-09-26 20:33:13 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:33:13 --> Form Validation Class Initialized
INFO - 2018-09-26 20:33:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-26 20:33:13 --> Database Driver Class Initialized
INFO - 2018-09-26 20:33:13 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:33:13 --> Config Class Initialized
INFO - 2018-09-26 20:33:13 --> Hooks Class Initialized
DEBUG - 2018-09-26 20:33:13 --> UTF-8 Support Enabled
INFO - 2018-09-26 20:33:13 --> Utf8 Class Initialized
INFO - 2018-09-26 20:33:13 --> URI Class Initialized
INFO - 2018-09-26 20:33:13 --> Router Class Initialized
INFO - 2018-09-26 20:33:13 --> Output Class Initialized
INFO - 2018-09-26 20:33:13 --> Security Class Initialized
DEBUG - 2018-09-26 20:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 20:33:13 --> CSRF cookie sent
INFO - 2018-09-26 20:33:13 --> Input Class Initialized
INFO - 2018-09-26 20:33:13 --> Language Class Initialized
INFO - 2018-09-26 20:33:13 --> Loader Class Initialized
INFO - 2018-09-26 20:33:13 --> Helper loaded: url_helper
INFO - 2018-09-26 20:33:13 --> Helper loaded: form_helper
INFO - 2018-09-26 20:33:13 --> Helper loaded: language_helper
DEBUG - 2018-09-26 20:33:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 20:33:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 20:33:13 --> User Agent Class Initialized
INFO - 2018-09-26 20:33:13 --> Controller Class Initialized
INFO - 2018-09-26 20:33:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-26 20:33:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-26 20:33:13 --> Pixel_Model class loaded
INFO - 2018-09-26 20:33:13 --> Database Driver Class Initialized
INFO - 2018-09-26 20:33:13 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:33:13 --> Database Driver Class Initialized
INFO - 2018-09-26 20:33:13 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:33:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-26 20:33:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-26 20:33:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-09-26 20:33:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-26 20:33:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-26 20:33:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-26 20:33:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-26 20:33:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-09-26 20:33:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-26 20:33:13 --> Final output sent to browser
DEBUG - 2018-09-26 20:33:13 --> Total execution time: 0.0403
INFO - 2018-09-26 20:33:15 --> Config Class Initialized
INFO - 2018-09-26 20:33:15 --> Hooks Class Initialized
DEBUG - 2018-09-26 20:33:15 --> UTF-8 Support Enabled
INFO - 2018-09-26 20:33:15 --> Utf8 Class Initialized
INFO - 2018-09-26 20:33:15 --> URI Class Initialized
INFO - 2018-09-26 20:33:15 --> Router Class Initialized
INFO - 2018-09-26 20:33:15 --> Output Class Initialized
INFO - 2018-09-26 20:33:15 --> Security Class Initialized
DEBUG - 2018-09-26 20:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 20:33:15 --> CSRF cookie sent
INFO - 2018-09-26 20:33:15 --> CSRF token verified
INFO - 2018-09-26 20:33:15 --> Input Class Initialized
INFO - 2018-09-26 20:33:15 --> Language Class Initialized
INFO - 2018-09-26 20:33:15 --> Loader Class Initialized
INFO - 2018-09-26 20:33:15 --> Helper loaded: url_helper
INFO - 2018-09-26 20:33:15 --> Helper loaded: form_helper
INFO - 2018-09-26 20:33:15 --> Helper loaded: language_helper
DEBUG - 2018-09-26 20:33:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 20:33:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 20:33:15 --> User Agent Class Initialized
INFO - 2018-09-26 20:33:15 --> Controller Class Initialized
INFO - 2018-09-26 20:33:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-26 20:33:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-26 20:33:15 --> Pixel_Model class loaded
INFO - 2018-09-26 20:33:15 --> Database Driver Class Initialized
INFO - 2018-09-26 20:33:15 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:33:15 --> Form Validation Class Initialized
INFO - 2018-09-26 20:33:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-26 20:33:15 --> Database Driver Class Initialized
INFO - 2018-09-26 20:33:15 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:33:15 --> Config Class Initialized
INFO - 2018-09-26 20:33:15 --> Hooks Class Initialized
DEBUG - 2018-09-26 20:33:15 --> UTF-8 Support Enabled
INFO - 2018-09-26 20:33:15 --> Utf8 Class Initialized
INFO - 2018-09-26 20:33:15 --> URI Class Initialized
INFO - 2018-09-26 20:33:15 --> Router Class Initialized
INFO - 2018-09-26 20:33:15 --> Output Class Initialized
INFO - 2018-09-26 20:33:15 --> Security Class Initialized
DEBUG - 2018-09-26 20:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 20:33:15 --> CSRF cookie sent
INFO - 2018-09-26 20:33:15 --> Input Class Initialized
INFO - 2018-09-26 20:33:15 --> Language Class Initialized
INFO - 2018-09-26 20:33:15 --> Loader Class Initialized
INFO - 2018-09-26 20:33:15 --> Helper loaded: url_helper
INFO - 2018-09-26 20:33:15 --> Helper loaded: form_helper
INFO - 2018-09-26 20:33:15 --> Helper loaded: language_helper
DEBUG - 2018-09-26 20:33:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 20:33:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 20:33:15 --> User Agent Class Initialized
INFO - 2018-09-26 20:33:15 --> Controller Class Initialized
INFO - 2018-09-26 20:33:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-26 20:33:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-26 20:33:15 --> Pixel_Model class loaded
INFO - 2018-09-26 20:33:15 --> Database Driver Class Initialized
INFO - 2018-09-26 20:33:15 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:33:15 --> Database Driver Class Initialized
INFO - 2018-09-26 20:33:15 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:33:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-26 20:33:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-26 20:33:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-26 20:33:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-26 20:33:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-26 20:33:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-26 20:33:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-09-26 20:33:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-26 20:33:15 --> Final output sent to browser
DEBUG - 2018-09-26 20:33:15 --> Total execution time: 0.0425
INFO - 2018-09-26 20:33:29 --> Config Class Initialized
INFO - 2018-09-26 20:33:29 --> Hooks Class Initialized
DEBUG - 2018-09-26 20:33:29 --> UTF-8 Support Enabled
INFO - 2018-09-26 20:33:29 --> Utf8 Class Initialized
INFO - 2018-09-26 20:33:29 --> URI Class Initialized
INFO - 2018-09-26 20:33:29 --> Router Class Initialized
INFO - 2018-09-26 20:33:29 --> Output Class Initialized
INFO - 2018-09-26 20:33:29 --> Security Class Initialized
DEBUG - 2018-09-26 20:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 20:33:29 --> CSRF cookie sent
INFO - 2018-09-26 20:33:29 --> CSRF token verified
INFO - 2018-09-26 20:33:29 --> Input Class Initialized
INFO - 2018-09-26 20:33:29 --> Language Class Initialized
INFO - 2018-09-26 20:33:29 --> Loader Class Initialized
INFO - 2018-09-26 20:33:29 --> Helper loaded: url_helper
INFO - 2018-09-26 20:33:29 --> Helper loaded: form_helper
INFO - 2018-09-26 20:33:29 --> Helper loaded: language_helper
DEBUG - 2018-09-26 20:33:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 20:33:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 20:33:29 --> User Agent Class Initialized
INFO - 2018-09-26 20:33:29 --> Controller Class Initialized
INFO - 2018-09-26 20:33:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-26 20:33:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-26 20:33:29 --> Pixel_Model class loaded
INFO - 2018-09-26 20:33:29 --> Database Driver Class Initialized
INFO - 2018-09-26 20:33:29 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:33:29 --> Form Validation Class Initialized
INFO - 2018-09-26 20:33:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-26 20:33:29 --> Database Driver Class Initialized
INFO - 2018-09-26 20:33:29 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:33:29 --> Config Class Initialized
INFO - 2018-09-26 20:33:29 --> Hooks Class Initialized
DEBUG - 2018-09-26 20:33:29 --> UTF-8 Support Enabled
INFO - 2018-09-26 20:33:29 --> Utf8 Class Initialized
INFO - 2018-09-26 20:33:29 --> URI Class Initialized
INFO - 2018-09-26 20:33:29 --> Router Class Initialized
INFO - 2018-09-26 20:33:29 --> Output Class Initialized
INFO - 2018-09-26 20:33:29 --> Security Class Initialized
DEBUG - 2018-09-26 20:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 20:33:29 --> CSRF cookie sent
INFO - 2018-09-26 20:33:29 --> Input Class Initialized
INFO - 2018-09-26 20:33:29 --> Language Class Initialized
INFO - 2018-09-26 20:33:29 --> Loader Class Initialized
INFO - 2018-09-26 20:33:29 --> Helper loaded: url_helper
INFO - 2018-09-26 20:33:29 --> Helper loaded: form_helper
INFO - 2018-09-26 20:33:29 --> Helper loaded: language_helper
DEBUG - 2018-09-26 20:33:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 20:33:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 20:33:29 --> User Agent Class Initialized
INFO - 2018-09-26 20:33:29 --> Controller Class Initialized
INFO - 2018-09-26 20:33:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-26 20:33:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-26 20:33:29 --> Pixel_Model class loaded
INFO - 2018-09-26 20:33:29 --> Database Driver Class Initialized
INFO - 2018-09-26 20:33:29 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:33:29 --> Database Driver Class Initialized
INFO - 2018-09-26 20:33:29 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:33:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-26 20:33:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-26 20:33:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-26 20:33:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-26 20:33:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-26 20:33:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-26 20:33:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-09-26 20:33:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-26 20:33:29 --> Final output sent to browser
DEBUG - 2018-09-26 20:33:29 --> Total execution time: 0.0457
INFO - 2018-09-26 20:33:35 --> Config Class Initialized
INFO - 2018-09-26 20:33:35 --> Hooks Class Initialized
DEBUG - 2018-09-26 20:33:35 --> UTF-8 Support Enabled
INFO - 2018-09-26 20:33:35 --> Utf8 Class Initialized
INFO - 2018-09-26 20:33:35 --> URI Class Initialized
INFO - 2018-09-26 20:33:35 --> Router Class Initialized
INFO - 2018-09-26 20:33:35 --> Output Class Initialized
INFO - 2018-09-26 20:33:35 --> Security Class Initialized
DEBUG - 2018-09-26 20:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 20:33:35 --> CSRF cookie sent
INFO - 2018-09-26 20:33:35 --> CSRF token verified
INFO - 2018-09-26 20:33:35 --> Input Class Initialized
INFO - 2018-09-26 20:33:35 --> Language Class Initialized
INFO - 2018-09-26 20:33:35 --> Loader Class Initialized
INFO - 2018-09-26 20:33:35 --> Helper loaded: url_helper
INFO - 2018-09-26 20:33:35 --> Helper loaded: form_helper
INFO - 2018-09-26 20:33:35 --> Helper loaded: language_helper
DEBUG - 2018-09-26 20:33:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 20:33:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 20:33:35 --> User Agent Class Initialized
INFO - 2018-09-26 20:33:35 --> Controller Class Initialized
INFO - 2018-09-26 20:33:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-26 20:33:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-26 20:33:35 --> Pixel_Model class loaded
INFO - 2018-09-26 20:33:35 --> Database Driver Class Initialized
INFO - 2018-09-26 20:33:35 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:33:35 --> Form Validation Class Initialized
INFO - 2018-09-26 20:33:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-26 20:33:35 --> Database Driver Class Initialized
INFO - 2018-09-26 20:33:35 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:33:35 --> Config Class Initialized
INFO - 2018-09-26 20:33:35 --> Hooks Class Initialized
DEBUG - 2018-09-26 20:33:35 --> UTF-8 Support Enabled
INFO - 2018-09-26 20:33:35 --> Utf8 Class Initialized
INFO - 2018-09-26 20:33:35 --> URI Class Initialized
INFO - 2018-09-26 20:33:35 --> Router Class Initialized
INFO - 2018-09-26 20:33:35 --> Output Class Initialized
INFO - 2018-09-26 20:33:35 --> Security Class Initialized
DEBUG - 2018-09-26 20:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 20:33:35 --> CSRF cookie sent
INFO - 2018-09-26 20:33:35 --> Input Class Initialized
INFO - 2018-09-26 20:33:35 --> Language Class Initialized
INFO - 2018-09-26 20:33:35 --> Loader Class Initialized
INFO - 2018-09-26 20:33:35 --> Helper loaded: url_helper
INFO - 2018-09-26 20:33:35 --> Helper loaded: form_helper
INFO - 2018-09-26 20:33:35 --> Helper loaded: language_helper
DEBUG - 2018-09-26 20:33:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 20:33:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 20:33:35 --> User Agent Class Initialized
INFO - 2018-09-26 20:33:35 --> Controller Class Initialized
INFO - 2018-09-26 20:33:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-26 20:33:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-26 20:33:35 --> Pixel_Model class loaded
INFO - 2018-09-26 20:33:35 --> Database Driver Class Initialized
INFO - 2018-09-26 20:33:35 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:33:35 --> Database Driver Class Initialized
INFO - 2018-09-26 20:33:35 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:33:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-26 20:33:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-26 20:33:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-26 20:33:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-26 20:33:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-26 20:33:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-26 20:33:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_title.php
INFO - 2018-09-26 20:33:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-26 20:33:35 --> Final output sent to browser
DEBUG - 2018-09-26 20:33:35 --> Total execution time: 0.0514
INFO - 2018-09-26 20:33:52 --> Config Class Initialized
INFO - 2018-09-26 20:33:52 --> Hooks Class Initialized
DEBUG - 2018-09-26 20:33:52 --> UTF-8 Support Enabled
INFO - 2018-09-26 20:33:52 --> Utf8 Class Initialized
INFO - 2018-09-26 20:33:52 --> URI Class Initialized
INFO - 2018-09-26 20:33:52 --> Router Class Initialized
INFO - 2018-09-26 20:33:52 --> Output Class Initialized
INFO - 2018-09-26 20:33:52 --> Security Class Initialized
DEBUG - 2018-09-26 20:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 20:33:52 --> CSRF cookie sent
INFO - 2018-09-26 20:33:52 --> CSRF token verified
INFO - 2018-09-26 20:33:52 --> Input Class Initialized
INFO - 2018-09-26 20:33:52 --> Language Class Initialized
INFO - 2018-09-26 20:33:52 --> Loader Class Initialized
INFO - 2018-09-26 20:33:52 --> Helper loaded: url_helper
INFO - 2018-09-26 20:33:52 --> Helper loaded: form_helper
INFO - 2018-09-26 20:33:52 --> Helper loaded: language_helper
DEBUG - 2018-09-26 20:33:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 20:33:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 20:33:52 --> User Agent Class Initialized
INFO - 2018-09-26 20:33:52 --> Controller Class Initialized
INFO - 2018-09-26 20:33:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-26 20:33:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-26 20:33:52 --> Pixel_Model class loaded
INFO - 2018-09-26 20:33:52 --> Database Driver Class Initialized
INFO - 2018-09-26 20:33:52 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:33:52 --> Form Validation Class Initialized
INFO - 2018-09-26 20:33:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-26 20:33:52 --> Database Driver Class Initialized
INFO - 2018-09-26 20:33:52 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:33:52 --> Config Class Initialized
INFO - 2018-09-26 20:33:52 --> Hooks Class Initialized
DEBUG - 2018-09-26 20:33:52 --> UTF-8 Support Enabled
INFO - 2018-09-26 20:33:52 --> Utf8 Class Initialized
INFO - 2018-09-26 20:33:52 --> URI Class Initialized
INFO - 2018-09-26 20:33:52 --> Router Class Initialized
INFO - 2018-09-26 20:33:52 --> Output Class Initialized
INFO - 2018-09-26 20:33:52 --> Security Class Initialized
DEBUG - 2018-09-26 20:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 20:33:52 --> CSRF cookie sent
INFO - 2018-09-26 20:33:52 --> Input Class Initialized
INFO - 2018-09-26 20:33:52 --> Language Class Initialized
INFO - 2018-09-26 20:33:52 --> Loader Class Initialized
INFO - 2018-09-26 20:33:52 --> Helper loaded: url_helper
INFO - 2018-09-26 20:33:52 --> Helper loaded: form_helper
INFO - 2018-09-26 20:33:52 --> Helper loaded: language_helper
DEBUG - 2018-09-26 20:33:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 20:33:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 20:33:52 --> User Agent Class Initialized
INFO - 2018-09-26 20:33:52 --> Controller Class Initialized
INFO - 2018-09-26 20:33:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-26 20:33:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-26 20:33:52 --> Pixel_Model class loaded
INFO - 2018-09-26 20:33:52 --> Database Driver Class Initialized
INFO - 2018-09-26 20:33:52 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:33:52 --> Database Driver Class Initialized
INFO - 2018-09-26 20:33:52 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:33:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-26 20:33:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-26 20:33:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-26 20:33:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-26 20:33:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-26 20:33:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-26 20:33:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-09-26 20:33:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-26 20:33:52 --> Final output sent to browser
DEBUG - 2018-09-26 20:33:52 --> Total execution time: 0.0485
INFO - 2018-09-26 20:34:02 --> Config Class Initialized
INFO - 2018-09-26 20:34:02 --> Hooks Class Initialized
DEBUG - 2018-09-26 20:34:02 --> UTF-8 Support Enabled
INFO - 2018-09-26 20:34:02 --> Utf8 Class Initialized
INFO - 2018-09-26 20:34:02 --> URI Class Initialized
INFO - 2018-09-26 20:34:02 --> Router Class Initialized
INFO - 2018-09-26 20:34:02 --> Output Class Initialized
INFO - 2018-09-26 20:34:02 --> Security Class Initialized
DEBUG - 2018-09-26 20:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 20:34:02 --> CSRF cookie sent
INFO - 2018-09-26 20:34:02 --> CSRF token verified
INFO - 2018-09-26 20:34:02 --> Input Class Initialized
INFO - 2018-09-26 20:34:02 --> Language Class Initialized
INFO - 2018-09-26 20:34:02 --> Loader Class Initialized
INFO - 2018-09-26 20:34:02 --> Helper loaded: url_helper
INFO - 2018-09-26 20:34:02 --> Helper loaded: form_helper
INFO - 2018-09-26 20:34:02 --> Helper loaded: language_helper
DEBUG - 2018-09-26 20:34:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 20:34:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 20:34:02 --> User Agent Class Initialized
INFO - 2018-09-26 20:34:02 --> Controller Class Initialized
INFO - 2018-09-26 20:34:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-26 20:34:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-26 20:34:02 --> Pixel_Model class loaded
INFO - 2018-09-26 20:34:02 --> Database Driver Class Initialized
INFO - 2018-09-26 20:34:02 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:34:02 --> Form Validation Class Initialized
INFO - 2018-09-26 20:34:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-26 20:34:02 --> Database Driver Class Initialized
INFO - 2018-09-26 20:34:02 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:34:02 --> Config Class Initialized
INFO - 2018-09-26 20:34:02 --> Hooks Class Initialized
DEBUG - 2018-09-26 20:34:02 --> UTF-8 Support Enabled
INFO - 2018-09-26 20:34:02 --> Utf8 Class Initialized
INFO - 2018-09-26 20:34:02 --> URI Class Initialized
INFO - 2018-09-26 20:34:02 --> Router Class Initialized
INFO - 2018-09-26 20:34:02 --> Output Class Initialized
INFO - 2018-09-26 20:34:02 --> Security Class Initialized
DEBUG - 2018-09-26 20:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 20:34:02 --> CSRF cookie sent
INFO - 2018-09-26 20:34:02 --> Input Class Initialized
INFO - 2018-09-26 20:34:02 --> Language Class Initialized
INFO - 2018-09-26 20:34:02 --> Loader Class Initialized
INFO - 2018-09-26 20:34:02 --> Helper loaded: url_helper
INFO - 2018-09-26 20:34:02 --> Helper loaded: form_helper
INFO - 2018-09-26 20:34:02 --> Helper loaded: language_helper
DEBUG - 2018-09-26 20:34:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 20:34:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 20:34:02 --> User Agent Class Initialized
INFO - 2018-09-26 20:34:02 --> Controller Class Initialized
INFO - 2018-09-26 20:34:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-26 20:34:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-26 20:34:02 --> Pixel_Model class loaded
INFO - 2018-09-26 20:34:02 --> Database Driver Class Initialized
INFO - 2018-09-26 20:34:02 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:34:02 --> Database Driver Class Initialized
INFO - 2018-09-26 20:34:02 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:34:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-26 20:34:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-26 20:34:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-26 20:34:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-26 20:34:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-09-26 20:34:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-26 20:34:02 --> Final output sent to browser
DEBUG - 2018-09-26 20:34:02 --> Total execution time: 0.0528
INFO - 2018-09-26 20:34:07 --> Config Class Initialized
INFO - 2018-09-26 20:34:07 --> Hooks Class Initialized
DEBUG - 2018-09-26 20:34:07 --> UTF-8 Support Enabled
INFO - 2018-09-26 20:34:07 --> Utf8 Class Initialized
INFO - 2018-09-26 20:34:07 --> URI Class Initialized
INFO - 2018-09-26 20:34:07 --> Router Class Initialized
INFO - 2018-09-26 20:34:07 --> Output Class Initialized
INFO - 2018-09-26 20:34:07 --> Security Class Initialized
DEBUG - 2018-09-26 20:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 20:34:07 --> CSRF cookie sent
INFO - 2018-09-26 20:34:07 --> Input Class Initialized
INFO - 2018-09-26 20:34:07 --> Language Class Initialized
INFO - 2018-09-26 20:34:07 --> Loader Class Initialized
INFO - 2018-09-26 20:34:07 --> Helper loaded: url_helper
INFO - 2018-09-26 20:34:07 --> Helper loaded: form_helper
INFO - 2018-09-26 20:34:07 --> Helper loaded: language_helper
DEBUG - 2018-09-26 20:34:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 20:34:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 20:34:07 --> User Agent Class Initialized
INFO - 2018-09-26 20:34:07 --> Controller Class Initialized
INFO - 2018-09-26 20:34:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-26 20:34:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-26 20:34:07 --> Pixel_Model class loaded
INFO - 2018-09-26 20:34:07 --> Database Driver Class Initialized
INFO - 2018-09-26 20:34:07 --> Model "MyAccountModel" initialized
INFO - 2018-09-26 20:34:07 --> Config Class Initialized
INFO - 2018-09-26 20:34:07 --> Hooks Class Initialized
DEBUG - 2018-09-26 20:34:07 --> UTF-8 Support Enabled
INFO - 2018-09-26 20:34:07 --> Utf8 Class Initialized
INFO - 2018-09-26 20:34:07 --> URI Class Initialized
INFO - 2018-09-26 20:34:07 --> Router Class Initialized
INFO - 2018-09-26 20:34:07 --> Output Class Initialized
INFO - 2018-09-26 20:34:07 --> Security Class Initialized
DEBUG - 2018-09-26 20:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 20:34:07 --> CSRF cookie sent
INFO - 2018-09-26 20:34:07 --> Input Class Initialized
INFO - 2018-09-26 20:34:07 --> Language Class Initialized
INFO - 2018-09-26 20:34:07 --> Loader Class Initialized
INFO - 2018-09-26 20:34:07 --> Helper loaded: url_helper
INFO - 2018-09-26 20:34:07 --> Helper loaded: form_helper
INFO - 2018-09-26 20:34:07 --> Helper loaded: language_helper
DEBUG - 2018-09-26 20:34:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 20:34:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 20:34:07 --> User Agent Class Initialized
INFO - 2018-09-26 20:34:07 --> Controller Class Initialized
INFO - 2018-09-26 20:34:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-26 20:34:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-26 20:34:07 --> Pixel_Model class loaded
INFO - 2018-09-26 20:34:07 --> Database Driver Class Initialized
INFO - 2018-09-26 20:34:07 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:34:07 --> Database Driver Class Initialized
INFO - 2018-09-26 20:34:07 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:34:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-26 20:34:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-26 20:34:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-26 20:34:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-26 20:34:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-09-26 20:34:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-26 20:34:07 --> Final output sent to browser
DEBUG - 2018-09-26 20:34:07 --> Total execution time: 0.0472
INFO - 2018-09-26 20:34:09 --> Config Class Initialized
INFO - 2018-09-26 20:34:09 --> Hooks Class Initialized
DEBUG - 2018-09-26 20:34:09 --> UTF-8 Support Enabled
INFO - 2018-09-26 20:34:09 --> Utf8 Class Initialized
INFO - 2018-09-26 20:34:09 --> URI Class Initialized
INFO - 2018-09-26 20:34:09 --> Router Class Initialized
INFO - 2018-09-26 20:34:09 --> Output Class Initialized
INFO - 2018-09-26 20:34:09 --> Security Class Initialized
DEBUG - 2018-09-26 20:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 20:34:09 --> CSRF cookie sent
INFO - 2018-09-26 20:34:09 --> Input Class Initialized
INFO - 2018-09-26 20:34:09 --> Language Class Initialized
INFO - 2018-09-26 20:34:09 --> Loader Class Initialized
INFO - 2018-09-26 20:34:09 --> Helper loaded: url_helper
INFO - 2018-09-26 20:34:09 --> Helper loaded: form_helper
INFO - 2018-09-26 20:34:09 --> Helper loaded: language_helper
DEBUG - 2018-09-26 20:34:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 20:34:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 20:34:09 --> User Agent Class Initialized
INFO - 2018-09-26 20:34:09 --> Controller Class Initialized
INFO - 2018-09-26 20:34:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-26 20:34:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-26 20:34:09 --> Pixel_Model class loaded
INFO - 2018-09-26 20:34:09 --> Database Driver Class Initialized
INFO - 2018-09-26 20:34:09 --> Model "MyAccountModel" initialized
INFO - 2018-09-26 20:34:09 --> Config Class Initialized
INFO - 2018-09-26 20:34:09 --> Hooks Class Initialized
DEBUG - 2018-09-26 20:34:09 --> UTF-8 Support Enabled
INFO - 2018-09-26 20:34:09 --> Utf8 Class Initialized
INFO - 2018-09-26 20:34:09 --> URI Class Initialized
INFO - 2018-09-26 20:34:09 --> Router Class Initialized
INFO - 2018-09-26 20:34:09 --> Output Class Initialized
INFO - 2018-09-26 20:34:09 --> Security Class Initialized
DEBUG - 2018-09-26 20:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 20:34:09 --> CSRF cookie sent
INFO - 2018-09-26 20:34:09 --> Input Class Initialized
INFO - 2018-09-26 20:34:09 --> Language Class Initialized
INFO - 2018-09-26 20:34:09 --> Loader Class Initialized
INFO - 2018-09-26 20:34:09 --> Helper loaded: url_helper
INFO - 2018-09-26 20:34:09 --> Helper loaded: form_helper
INFO - 2018-09-26 20:34:09 --> Helper loaded: language_helper
DEBUG - 2018-09-26 20:34:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 20:34:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 20:34:09 --> User Agent Class Initialized
INFO - 2018-09-26 20:34:09 --> Controller Class Initialized
INFO - 2018-09-26 20:34:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-26 20:34:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-26 20:34:09 --> Pixel_Model class loaded
INFO - 2018-09-26 20:34:09 --> Database Driver Class Initialized
INFO - 2018-09-26 20:34:09 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:34:09 --> Database Driver Class Initialized
INFO - 2018-09-26 20:34:09 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:34:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-26 20:34:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-26 20:34:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-26 20:34:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-26 20:34:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-09-26 20:34:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-26 20:34:09 --> Final output sent to browser
DEBUG - 2018-09-26 20:34:09 --> Total execution time: 0.0569
INFO - 2018-09-26 20:35:21 --> Config Class Initialized
INFO - 2018-09-26 20:35:21 --> Hooks Class Initialized
DEBUG - 2018-09-26 20:35:21 --> UTF-8 Support Enabled
INFO - 2018-09-26 20:35:21 --> Utf8 Class Initialized
INFO - 2018-09-26 20:35:21 --> URI Class Initialized
INFO - 2018-09-26 20:35:21 --> Router Class Initialized
INFO - 2018-09-26 20:35:21 --> Output Class Initialized
INFO - 2018-09-26 20:35:21 --> Security Class Initialized
DEBUG - 2018-09-26 20:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 20:35:21 --> CSRF cookie sent
INFO - 2018-09-26 20:35:21 --> Input Class Initialized
INFO - 2018-09-26 20:35:21 --> Language Class Initialized
INFO - 2018-09-26 20:35:21 --> Loader Class Initialized
INFO - 2018-09-26 20:35:21 --> Helper loaded: url_helper
INFO - 2018-09-26 20:35:21 --> Helper loaded: form_helper
INFO - 2018-09-26 20:35:21 --> Helper loaded: language_helper
DEBUG - 2018-09-26 20:35:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 20:35:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 20:35:21 --> User Agent Class Initialized
INFO - 2018-09-26 20:35:21 --> Controller Class Initialized
INFO - 2018-09-26 20:35:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-26 20:35:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-26 20:35:21 --> Pixel_Model class loaded
INFO - 2018-09-26 20:35:21 --> Database Driver Class Initialized
INFO - 2018-09-26 20:35:21 --> Model "MyAccountModel" initialized
INFO - 2018-09-26 20:35:21 --> Config Class Initialized
INFO - 2018-09-26 20:35:21 --> Hooks Class Initialized
DEBUG - 2018-09-26 20:35:21 --> UTF-8 Support Enabled
INFO - 2018-09-26 20:35:21 --> Utf8 Class Initialized
INFO - 2018-09-26 20:35:21 --> URI Class Initialized
INFO - 2018-09-26 20:35:21 --> Router Class Initialized
INFO - 2018-09-26 20:35:21 --> Output Class Initialized
INFO - 2018-09-26 20:35:21 --> Security Class Initialized
DEBUG - 2018-09-26 20:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 20:35:21 --> CSRF cookie sent
INFO - 2018-09-26 20:35:21 --> Input Class Initialized
INFO - 2018-09-26 20:35:21 --> Language Class Initialized
INFO - 2018-09-26 20:35:21 --> Loader Class Initialized
INFO - 2018-09-26 20:35:21 --> Helper loaded: url_helper
INFO - 2018-09-26 20:35:21 --> Helper loaded: form_helper
INFO - 2018-09-26 20:35:21 --> Helper loaded: language_helper
DEBUG - 2018-09-26 20:35:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 20:35:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 20:35:21 --> User Agent Class Initialized
INFO - 2018-09-26 20:35:21 --> Controller Class Initialized
INFO - 2018-09-26 20:35:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-26 20:35:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-26 20:35:21 --> Pixel_Model class loaded
INFO - 2018-09-26 20:35:21 --> Database Driver Class Initialized
INFO - 2018-09-26 20:35:21 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:35:21 --> Database Driver Class Initialized
INFO - 2018-09-26 20:35:21 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:35:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-26 20:35:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-26 20:35:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-26 20:35:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-26 20:35:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-09-26 20:35:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-26 20:35:21 --> Final output sent to browser
DEBUG - 2018-09-26 20:35:21 --> Total execution time: 0.0668
INFO - 2018-09-26 20:37:32 --> Config Class Initialized
INFO - 2018-09-26 20:37:32 --> Hooks Class Initialized
DEBUG - 2018-09-26 20:37:32 --> UTF-8 Support Enabled
INFO - 2018-09-26 20:37:32 --> Utf8 Class Initialized
INFO - 2018-09-26 20:37:32 --> URI Class Initialized
INFO - 2018-09-26 20:37:32 --> Router Class Initialized
INFO - 2018-09-26 20:37:32 --> Output Class Initialized
INFO - 2018-09-26 20:37:32 --> Security Class Initialized
DEBUG - 2018-09-26 20:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 20:37:32 --> CSRF cookie sent
INFO - 2018-09-26 20:37:32 --> Input Class Initialized
INFO - 2018-09-26 20:37:32 --> Language Class Initialized
INFO - 2018-09-26 20:37:32 --> Loader Class Initialized
INFO - 2018-09-26 20:37:32 --> Helper loaded: url_helper
INFO - 2018-09-26 20:37:32 --> Helper loaded: form_helper
INFO - 2018-09-26 20:37:32 --> Helper loaded: language_helper
DEBUG - 2018-09-26 20:37:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 20:37:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 20:37:32 --> User Agent Class Initialized
INFO - 2018-09-26 20:37:32 --> Controller Class Initialized
INFO - 2018-09-26 20:37:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-26 20:37:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-26 20:37:32 --> Pixel_Model class loaded
INFO - 2018-09-26 20:37:32 --> Database Driver Class Initialized
INFO - 2018-09-26 20:37:32 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:37:32 --> Database Driver Class Initialized
INFO - 2018-09-26 20:37:32 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:37:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-26 20:37:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-26 20:37:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-26 20:37:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-26 20:37:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-09-26 20:37:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-26 20:37:32 --> Final output sent to browser
DEBUG - 2018-09-26 20:37:32 --> Total execution time: 0.0564
INFO - 2018-09-26 20:37:33 --> Config Class Initialized
INFO - 2018-09-26 20:37:33 --> Hooks Class Initialized
DEBUG - 2018-09-26 20:37:33 --> UTF-8 Support Enabled
INFO - 2018-09-26 20:37:33 --> Utf8 Class Initialized
INFO - 2018-09-26 20:37:33 --> URI Class Initialized
INFO - 2018-09-26 20:37:33 --> Router Class Initialized
INFO - 2018-09-26 20:37:33 --> Output Class Initialized
INFO - 2018-09-26 20:37:33 --> Security Class Initialized
DEBUG - 2018-09-26 20:37:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 20:37:33 --> CSRF cookie sent
INFO - 2018-09-26 20:37:33 --> Input Class Initialized
INFO - 2018-09-26 20:37:33 --> Language Class Initialized
INFO - 2018-09-26 20:37:33 --> Loader Class Initialized
INFO - 2018-09-26 20:37:33 --> Helper loaded: url_helper
INFO - 2018-09-26 20:37:33 --> Helper loaded: form_helper
INFO - 2018-09-26 20:37:33 --> Helper loaded: language_helper
DEBUG - 2018-09-26 20:37:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 20:37:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 20:37:33 --> User Agent Class Initialized
INFO - 2018-09-26 20:37:33 --> Controller Class Initialized
INFO - 2018-09-26 20:37:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-26 20:37:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-26 20:37:33 --> Pixel_Model class loaded
INFO - 2018-09-26 20:37:33 --> Database Driver Class Initialized
INFO - 2018-09-26 20:37:33 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:37:33 --> Database Driver Class Initialized
INFO - 2018-09-26 20:37:33 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:37:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-26 20:37:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-26 20:37:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-26 20:37:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-26 20:37:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-09-26 20:37:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-26 20:37:33 --> Final output sent to browser
DEBUG - 2018-09-26 20:37:33 --> Total execution time: 0.0526
INFO - 2018-09-26 20:37:34 --> Config Class Initialized
INFO - 2018-09-26 20:37:34 --> Hooks Class Initialized
DEBUG - 2018-09-26 20:37:34 --> UTF-8 Support Enabled
INFO - 2018-09-26 20:37:34 --> Utf8 Class Initialized
INFO - 2018-09-26 20:37:34 --> URI Class Initialized
INFO - 2018-09-26 20:37:34 --> Router Class Initialized
INFO - 2018-09-26 20:37:34 --> Output Class Initialized
INFO - 2018-09-26 20:37:34 --> Security Class Initialized
DEBUG - 2018-09-26 20:37:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 20:37:34 --> CSRF cookie sent
INFO - 2018-09-26 20:37:34 --> Input Class Initialized
INFO - 2018-09-26 20:37:34 --> Language Class Initialized
INFO - 2018-09-26 20:37:34 --> Loader Class Initialized
INFO - 2018-09-26 20:37:34 --> Helper loaded: url_helper
INFO - 2018-09-26 20:37:34 --> Helper loaded: form_helper
INFO - 2018-09-26 20:37:34 --> Helper loaded: language_helper
DEBUG - 2018-09-26 20:37:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 20:37:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 20:37:34 --> User Agent Class Initialized
INFO - 2018-09-26 20:37:34 --> Controller Class Initialized
INFO - 2018-09-26 20:37:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-26 20:37:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-26 20:37:34 --> Pixel_Model class loaded
INFO - 2018-09-26 20:37:34 --> Database Driver Class Initialized
INFO - 2018-09-26 20:37:34 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:37:34 --> Database Driver Class Initialized
INFO - 2018-09-26 20:37:34 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:37:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-26 20:37:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-26 20:37:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-26 20:37:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-26 20:37:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-09-26 20:37:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-26 20:37:34 --> Final output sent to browser
DEBUG - 2018-09-26 20:37:34 --> Total execution time: 0.0627
INFO - 2018-09-26 20:37:35 --> Config Class Initialized
INFO - 2018-09-26 20:37:35 --> Hooks Class Initialized
DEBUG - 2018-09-26 20:37:35 --> UTF-8 Support Enabled
INFO - 2018-09-26 20:37:35 --> Utf8 Class Initialized
INFO - 2018-09-26 20:37:35 --> URI Class Initialized
INFO - 2018-09-26 20:37:35 --> Router Class Initialized
INFO - 2018-09-26 20:37:35 --> Output Class Initialized
INFO - 2018-09-26 20:37:35 --> Security Class Initialized
DEBUG - 2018-09-26 20:37:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 20:37:35 --> CSRF cookie sent
INFO - 2018-09-26 20:37:35 --> Input Class Initialized
INFO - 2018-09-26 20:37:35 --> Language Class Initialized
INFO - 2018-09-26 20:37:35 --> Loader Class Initialized
INFO - 2018-09-26 20:37:35 --> Helper loaded: url_helper
INFO - 2018-09-26 20:37:35 --> Helper loaded: form_helper
INFO - 2018-09-26 20:37:35 --> Helper loaded: language_helper
DEBUG - 2018-09-26 20:37:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 20:37:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 20:37:35 --> User Agent Class Initialized
INFO - 2018-09-26 20:37:35 --> Controller Class Initialized
INFO - 2018-09-26 20:37:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-26 20:37:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-26 20:37:35 --> Pixel_Model class loaded
INFO - 2018-09-26 20:37:35 --> Database Driver Class Initialized
INFO - 2018-09-26 20:37:35 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:37:35 --> Database Driver Class Initialized
INFO - 2018-09-26 20:37:35 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:37:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-26 20:37:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-26 20:37:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-26 20:37:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-26 20:37:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-26 20:37:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-26 20:37:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-09-26 20:37:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-26 20:37:35 --> Final output sent to browser
DEBUG - 2018-09-26 20:37:35 --> Total execution time: 0.0593
INFO - 2018-09-26 20:37:56 --> Config Class Initialized
INFO - 2018-09-26 20:37:56 --> Hooks Class Initialized
DEBUG - 2018-09-26 20:37:56 --> UTF-8 Support Enabled
INFO - 2018-09-26 20:37:56 --> Utf8 Class Initialized
INFO - 2018-09-26 20:37:56 --> URI Class Initialized
INFO - 2018-09-26 20:37:56 --> Router Class Initialized
INFO - 2018-09-26 20:37:56 --> Output Class Initialized
INFO - 2018-09-26 20:37:56 --> Security Class Initialized
DEBUG - 2018-09-26 20:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 20:37:56 --> CSRF cookie sent
INFO - 2018-09-26 20:37:56 --> Input Class Initialized
INFO - 2018-09-26 20:37:56 --> Language Class Initialized
INFO - 2018-09-26 20:37:56 --> Loader Class Initialized
INFO - 2018-09-26 20:37:56 --> Helper loaded: url_helper
INFO - 2018-09-26 20:37:56 --> Helper loaded: form_helper
INFO - 2018-09-26 20:37:56 --> Helper loaded: language_helper
DEBUG - 2018-09-26 20:37:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 20:37:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 20:37:56 --> User Agent Class Initialized
INFO - 2018-09-26 20:37:56 --> Controller Class Initialized
INFO - 2018-09-26 20:37:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-26 20:37:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-26 20:37:56 --> Pixel_Model class loaded
INFO - 2018-09-26 20:37:56 --> Database Driver Class Initialized
INFO - 2018-09-26 20:37:56 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:37:56 --> Database Driver Class Initialized
INFO - 2018-09-26 20:37:56 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:37:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-26 20:37:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-26 20:37:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-26 20:37:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-26 20:37:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-26 20:37:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-26 20:37:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_title.php
INFO - 2018-09-26 20:37:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-26 20:37:56 --> Final output sent to browser
DEBUG - 2018-09-26 20:37:56 --> Total execution time: 0.0453
INFO - 2018-09-26 20:38:00 --> Config Class Initialized
INFO - 2018-09-26 20:38:00 --> Hooks Class Initialized
DEBUG - 2018-09-26 20:38:00 --> UTF-8 Support Enabled
INFO - 2018-09-26 20:38:00 --> Utf8 Class Initialized
INFO - 2018-09-26 20:38:00 --> URI Class Initialized
INFO - 2018-09-26 20:38:00 --> Router Class Initialized
INFO - 2018-09-26 20:38:00 --> Output Class Initialized
INFO - 2018-09-26 20:38:00 --> Security Class Initialized
DEBUG - 2018-09-26 20:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 20:38:00 --> CSRF cookie sent
INFO - 2018-09-26 20:38:00 --> Input Class Initialized
INFO - 2018-09-26 20:38:00 --> Language Class Initialized
INFO - 2018-09-26 20:38:00 --> Loader Class Initialized
INFO - 2018-09-26 20:38:00 --> Helper loaded: url_helper
INFO - 2018-09-26 20:38:00 --> Helper loaded: form_helper
INFO - 2018-09-26 20:38:00 --> Helper loaded: language_helper
DEBUG - 2018-09-26 20:38:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 20:38:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 20:38:00 --> User Agent Class Initialized
INFO - 2018-09-26 20:38:00 --> Controller Class Initialized
INFO - 2018-09-26 20:38:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-26 20:38:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-26 20:38:00 --> Pixel_Model class loaded
INFO - 2018-09-26 20:38:00 --> Database Driver Class Initialized
INFO - 2018-09-26 20:38:00 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:38:00 --> Database Driver Class Initialized
INFO - 2018-09-26 20:38:00 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:38:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-26 20:38:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-26 20:38:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-26 20:38:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-26 20:38:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-26 20:38:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-26 20:38:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-09-26 20:38:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-26 20:38:00 --> Final output sent to browser
DEBUG - 2018-09-26 20:38:00 --> Total execution time: 0.0452
INFO - 2018-09-26 20:38:03 --> Config Class Initialized
INFO - 2018-09-26 20:38:03 --> Hooks Class Initialized
DEBUG - 2018-09-26 20:38:03 --> UTF-8 Support Enabled
INFO - 2018-09-26 20:38:03 --> Utf8 Class Initialized
INFO - 2018-09-26 20:38:03 --> URI Class Initialized
INFO - 2018-09-26 20:38:03 --> Router Class Initialized
INFO - 2018-09-26 20:38:03 --> Output Class Initialized
INFO - 2018-09-26 20:38:03 --> Security Class Initialized
DEBUG - 2018-09-26 20:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 20:38:03 --> CSRF cookie sent
INFO - 2018-09-26 20:38:03 --> Input Class Initialized
INFO - 2018-09-26 20:38:03 --> Language Class Initialized
INFO - 2018-09-26 20:38:03 --> Loader Class Initialized
INFO - 2018-09-26 20:38:03 --> Helper loaded: url_helper
INFO - 2018-09-26 20:38:03 --> Helper loaded: form_helper
INFO - 2018-09-26 20:38:03 --> Helper loaded: language_helper
DEBUG - 2018-09-26 20:38:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 20:38:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 20:38:03 --> User Agent Class Initialized
INFO - 2018-09-26 20:38:03 --> Controller Class Initialized
INFO - 2018-09-26 20:38:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-26 20:38:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-26 20:38:03 --> Pixel_Model class loaded
INFO - 2018-09-26 20:38:03 --> Database Driver Class Initialized
INFO - 2018-09-26 20:38:03 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:38:03 --> Database Driver Class Initialized
INFO - 2018-09-26 20:38:03 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:38:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-26 20:38:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-26 20:38:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-26 20:38:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-26 20:38:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-26 20:38:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-26 20:38:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-09-26 20:38:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-26 20:38:03 --> Final output sent to browser
DEBUG - 2018-09-26 20:38:03 --> Total execution time: 0.0427
INFO - 2018-09-26 20:38:05 --> Config Class Initialized
INFO - 2018-09-26 20:38:05 --> Hooks Class Initialized
DEBUG - 2018-09-26 20:38:05 --> UTF-8 Support Enabled
INFO - 2018-09-26 20:38:05 --> Utf8 Class Initialized
INFO - 2018-09-26 20:38:05 --> URI Class Initialized
INFO - 2018-09-26 20:38:05 --> Router Class Initialized
INFO - 2018-09-26 20:38:05 --> Output Class Initialized
INFO - 2018-09-26 20:38:05 --> Security Class Initialized
DEBUG - 2018-09-26 20:38:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 20:38:05 --> CSRF cookie sent
INFO - 2018-09-26 20:38:05 --> Input Class Initialized
INFO - 2018-09-26 20:38:05 --> Language Class Initialized
INFO - 2018-09-26 20:38:05 --> Loader Class Initialized
INFO - 2018-09-26 20:38:05 --> Helper loaded: url_helper
INFO - 2018-09-26 20:38:05 --> Helper loaded: form_helper
INFO - 2018-09-26 20:38:05 --> Helper loaded: language_helper
DEBUG - 2018-09-26 20:38:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 20:38:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 20:38:05 --> User Agent Class Initialized
INFO - 2018-09-26 20:38:05 --> Controller Class Initialized
INFO - 2018-09-26 20:38:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-26 20:38:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-26 20:38:05 --> Pixel_Model class loaded
INFO - 2018-09-26 20:38:05 --> Database Driver Class Initialized
INFO - 2018-09-26 20:38:05 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:38:05 --> Database Driver Class Initialized
INFO - 2018-09-26 20:38:05 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:38:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-26 20:38:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-26 20:38:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-09-26 20:38:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-26 20:38:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-26 20:38:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-26 20:38:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-26 20:38:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-09-26 20:38:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-26 20:38:05 --> Final output sent to browser
DEBUG - 2018-09-26 20:38:05 --> Total execution time: 0.0463
INFO - 2018-09-26 20:38:08 --> Config Class Initialized
INFO - 2018-09-26 20:38:08 --> Hooks Class Initialized
DEBUG - 2018-09-26 20:38:08 --> UTF-8 Support Enabled
INFO - 2018-09-26 20:38:08 --> Utf8 Class Initialized
INFO - 2018-09-26 20:38:08 --> URI Class Initialized
INFO - 2018-09-26 20:38:08 --> Router Class Initialized
INFO - 2018-09-26 20:38:08 --> Output Class Initialized
INFO - 2018-09-26 20:38:08 --> Security Class Initialized
DEBUG - 2018-09-26 20:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 20:38:08 --> CSRF cookie sent
INFO - 2018-09-26 20:38:08 --> Input Class Initialized
INFO - 2018-09-26 20:38:08 --> Language Class Initialized
INFO - 2018-09-26 20:38:08 --> Loader Class Initialized
INFO - 2018-09-26 20:38:08 --> Helper loaded: url_helper
INFO - 2018-09-26 20:38:08 --> Helper loaded: form_helper
INFO - 2018-09-26 20:38:08 --> Helper loaded: language_helper
DEBUG - 2018-09-26 20:38:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 20:38:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 20:38:08 --> User Agent Class Initialized
INFO - 2018-09-26 20:38:08 --> Controller Class Initialized
INFO - 2018-09-26 20:38:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-26 20:38:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-26 20:38:08 --> Pixel_Model class loaded
INFO - 2018-09-26 20:38:08 --> Database Driver Class Initialized
INFO - 2018-09-26 20:38:08 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:38:08 --> Database Driver Class Initialized
INFO - 2018-09-26 20:38:08 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:38:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-26 20:38:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-26 20:38:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-26 20:38:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-26 20:38:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-26 20:38:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-26 20:38:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-09-26 20:38:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-26 20:38:08 --> Final output sent to browser
DEBUG - 2018-09-26 20:38:08 --> Total execution time: 0.0641
INFO - 2018-09-26 20:38:12 --> Config Class Initialized
INFO - 2018-09-26 20:38:12 --> Hooks Class Initialized
DEBUG - 2018-09-26 20:38:12 --> UTF-8 Support Enabled
INFO - 2018-09-26 20:38:12 --> Utf8 Class Initialized
INFO - 2018-09-26 20:38:12 --> URI Class Initialized
INFO - 2018-09-26 20:38:12 --> Router Class Initialized
INFO - 2018-09-26 20:38:12 --> Output Class Initialized
INFO - 2018-09-26 20:38:12 --> Security Class Initialized
DEBUG - 2018-09-26 20:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 20:38:12 --> CSRF cookie sent
INFO - 2018-09-26 20:38:12 --> CSRF token verified
INFO - 2018-09-26 20:38:12 --> Input Class Initialized
INFO - 2018-09-26 20:38:12 --> Language Class Initialized
INFO - 2018-09-26 20:38:12 --> Loader Class Initialized
INFO - 2018-09-26 20:38:12 --> Helper loaded: url_helper
INFO - 2018-09-26 20:38:12 --> Helper loaded: form_helper
INFO - 2018-09-26 20:38:12 --> Helper loaded: language_helper
DEBUG - 2018-09-26 20:38:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 20:38:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 20:38:12 --> User Agent Class Initialized
INFO - 2018-09-26 20:38:12 --> Controller Class Initialized
INFO - 2018-09-26 20:38:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-26 20:38:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-26 20:38:12 --> Pixel_Model class loaded
INFO - 2018-09-26 20:38:12 --> Database Driver Class Initialized
INFO - 2018-09-26 20:38:12 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:38:12 --> Form Validation Class Initialized
INFO - 2018-09-26 20:38:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-26 20:38:12 --> Database Driver Class Initialized
INFO - 2018-09-26 20:38:12 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:38:12 --> Config Class Initialized
INFO - 2018-09-26 20:38:12 --> Hooks Class Initialized
DEBUG - 2018-09-26 20:38:12 --> UTF-8 Support Enabled
INFO - 2018-09-26 20:38:12 --> Utf8 Class Initialized
INFO - 2018-09-26 20:38:12 --> URI Class Initialized
INFO - 2018-09-26 20:38:12 --> Router Class Initialized
INFO - 2018-09-26 20:38:12 --> Output Class Initialized
INFO - 2018-09-26 20:38:12 --> Security Class Initialized
DEBUG - 2018-09-26 20:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 20:38:12 --> CSRF cookie sent
INFO - 2018-09-26 20:38:12 --> Input Class Initialized
INFO - 2018-09-26 20:38:12 --> Language Class Initialized
INFO - 2018-09-26 20:38:12 --> Loader Class Initialized
INFO - 2018-09-26 20:38:12 --> Helper loaded: url_helper
INFO - 2018-09-26 20:38:12 --> Helper loaded: form_helper
INFO - 2018-09-26 20:38:12 --> Helper loaded: language_helper
DEBUG - 2018-09-26 20:38:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 20:38:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 20:38:12 --> User Agent Class Initialized
INFO - 2018-09-26 20:38:12 --> Controller Class Initialized
INFO - 2018-09-26 20:38:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-26 20:38:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-26 20:38:12 --> Pixel_Model class loaded
INFO - 2018-09-26 20:38:12 --> Database Driver Class Initialized
INFO - 2018-09-26 20:38:12 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:38:12 --> Database Driver Class Initialized
INFO - 2018-09-26 20:38:12 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:38:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-26 20:38:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-26 20:38:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-09-26 20:38:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-26 20:38:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-26 20:38:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-26 20:38:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-26 20:38:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-09-26 20:38:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-26 20:38:12 --> Final output sent to browser
DEBUG - 2018-09-26 20:38:12 --> Total execution time: 0.0402
INFO - 2018-09-26 20:38:13 --> Config Class Initialized
INFO - 2018-09-26 20:38:13 --> Hooks Class Initialized
DEBUG - 2018-09-26 20:38:13 --> UTF-8 Support Enabled
INFO - 2018-09-26 20:38:13 --> Utf8 Class Initialized
INFO - 2018-09-26 20:38:13 --> URI Class Initialized
INFO - 2018-09-26 20:38:13 --> Router Class Initialized
INFO - 2018-09-26 20:38:13 --> Output Class Initialized
INFO - 2018-09-26 20:38:13 --> Security Class Initialized
DEBUG - 2018-09-26 20:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 20:38:13 --> CSRF cookie sent
INFO - 2018-09-26 20:38:13 --> CSRF token verified
INFO - 2018-09-26 20:38:13 --> Input Class Initialized
INFO - 2018-09-26 20:38:13 --> Language Class Initialized
INFO - 2018-09-26 20:38:13 --> Loader Class Initialized
INFO - 2018-09-26 20:38:13 --> Helper loaded: url_helper
INFO - 2018-09-26 20:38:13 --> Helper loaded: form_helper
INFO - 2018-09-26 20:38:13 --> Helper loaded: language_helper
DEBUG - 2018-09-26 20:38:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 20:38:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 20:38:13 --> User Agent Class Initialized
INFO - 2018-09-26 20:38:13 --> Controller Class Initialized
INFO - 2018-09-26 20:38:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-26 20:38:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-26 20:38:13 --> Pixel_Model class loaded
INFO - 2018-09-26 20:38:13 --> Database Driver Class Initialized
INFO - 2018-09-26 20:38:13 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:38:13 --> Form Validation Class Initialized
INFO - 2018-09-26 20:38:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-26 20:38:13 --> Database Driver Class Initialized
INFO - 2018-09-26 20:38:13 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:38:13 --> Config Class Initialized
INFO - 2018-09-26 20:38:13 --> Hooks Class Initialized
DEBUG - 2018-09-26 20:38:13 --> UTF-8 Support Enabled
INFO - 2018-09-26 20:38:13 --> Utf8 Class Initialized
INFO - 2018-09-26 20:38:13 --> URI Class Initialized
INFO - 2018-09-26 20:38:13 --> Router Class Initialized
INFO - 2018-09-26 20:38:13 --> Output Class Initialized
INFO - 2018-09-26 20:38:13 --> Security Class Initialized
DEBUG - 2018-09-26 20:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 20:38:13 --> CSRF cookie sent
INFO - 2018-09-26 20:38:13 --> Input Class Initialized
INFO - 2018-09-26 20:38:13 --> Language Class Initialized
INFO - 2018-09-26 20:38:13 --> Loader Class Initialized
INFO - 2018-09-26 20:38:13 --> Helper loaded: url_helper
INFO - 2018-09-26 20:38:13 --> Helper loaded: form_helper
INFO - 2018-09-26 20:38:13 --> Helper loaded: language_helper
DEBUG - 2018-09-26 20:38:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 20:38:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 20:38:13 --> User Agent Class Initialized
INFO - 2018-09-26 20:38:13 --> Controller Class Initialized
INFO - 2018-09-26 20:38:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-26 20:38:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-26 20:38:13 --> Pixel_Model class loaded
INFO - 2018-09-26 20:38:13 --> Database Driver Class Initialized
INFO - 2018-09-26 20:38:13 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:38:13 --> Database Driver Class Initialized
INFO - 2018-09-26 20:38:13 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:38:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-26 20:38:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-26 20:38:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-26 20:38:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-26 20:38:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-26 20:38:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-26 20:38:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-09-26 20:38:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-26 20:38:13 --> Final output sent to browser
DEBUG - 2018-09-26 20:38:13 --> Total execution time: 0.0404
INFO - 2018-09-26 20:38:14 --> Config Class Initialized
INFO - 2018-09-26 20:38:14 --> Hooks Class Initialized
DEBUG - 2018-09-26 20:38:14 --> UTF-8 Support Enabled
INFO - 2018-09-26 20:38:14 --> Utf8 Class Initialized
INFO - 2018-09-26 20:38:14 --> URI Class Initialized
INFO - 2018-09-26 20:38:14 --> Router Class Initialized
INFO - 2018-09-26 20:38:14 --> Output Class Initialized
INFO - 2018-09-26 20:38:14 --> Security Class Initialized
DEBUG - 2018-09-26 20:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 20:38:14 --> CSRF cookie sent
INFO - 2018-09-26 20:38:14 --> CSRF token verified
INFO - 2018-09-26 20:38:14 --> Input Class Initialized
INFO - 2018-09-26 20:38:14 --> Language Class Initialized
INFO - 2018-09-26 20:38:14 --> Loader Class Initialized
INFO - 2018-09-26 20:38:14 --> Helper loaded: url_helper
INFO - 2018-09-26 20:38:14 --> Helper loaded: form_helper
INFO - 2018-09-26 20:38:14 --> Helper loaded: language_helper
DEBUG - 2018-09-26 20:38:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 20:38:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 20:38:14 --> User Agent Class Initialized
INFO - 2018-09-26 20:38:14 --> Controller Class Initialized
INFO - 2018-09-26 20:38:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-26 20:38:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-26 20:38:14 --> Pixel_Model class loaded
INFO - 2018-09-26 20:38:14 --> Database Driver Class Initialized
INFO - 2018-09-26 20:38:14 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:38:14 --> Form Validation Class Initialized
INFO - 2018-09-26 20:38:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-26 20:38:14 --> Database Driver Class Initialized
INFO - 2018-09-26 20:38:14 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:38:14 --> Config Class Initialized
INFO - 2018-09-26 20:38:14 --> Hooks Class Initialized
DEBUG - 2018-09-26 20:38:14 --> UTF-8 Support Enabled
INFO - 2018-09-26 20:38:14 --> Utf8 Class Initialized
INFO - 2018-09-26 20:38:14 --> URI Class Initialized
INFO - 2018-09-26 20:38:14 --> Router Class Initialized
INFO - 2018-09-26 20:38:14 --> Output Class Initialized
INFO - 2018-09-26 20:38:14 --> Security Class Initialized
DEBUG - 2018-09-26 20:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 20:38:14 --> CSRF cookie sent
INFO - 2018-09-26 20:38:14 --> Input Class Initialized
INFO - 2018-09-26 20:38:14 --> Language Class Initialized
INFO - 2018-09-26 20:38:14 --> Loader Class Initialized
INFO - 2018-09-26 20:38:14 --> Helper loaded: url_helper
INFO - 2018-09-26 20:38:14 --> Helper loaded: form_helper
INFO - 2018-09-26 20:38:14 --> Helper loaded: language_helper
DEBUG - 2018-09-26 20:38:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 20:38:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 20:38:14 --> User Agent Class Initialized
INFO - 2018-09-26 20:38:14 --> Controller Class Initialized
INFO - 2018-09-26 20:38:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-26 20:38:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-26 20:38:14 --> Pixel_Model class loaded
INFO - 2018-09-26 20:38:14 --> Database Driver Class Initialized
INFO - 2018-09-26 20:38:14 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:38:14 --> Database Driver Class Initialized
INFO - 2018-09-26 20:38:14 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:38:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-26 20:38:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-26 20:38:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-26 20:38:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-26 20:38:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-26 20:38:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-26 20:38:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-09-26 20:38:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-26 20:38:14 --> Final output sent to browser
DEBUG - 2018-09-26 20:38:14 --> Total execution time: 0.0439
INFO - 2018-09-26 20:38:19 --> Config Class Initialized
INFO - 2018-09-26 20:38:19 --> Hooks Class Initialized
DEBUG - 2018-09-26 20:38:19 --> UTF-8 Support Enabled
INFO - 2018-09-26 20:38:19 --> Utf8 Class Initialized
INFO - 2018-09-26 20:38:19 --> URI Class Initialized
INFO - 2018-09-26 20:38:19 --> Router Class Initialized
INFO - 2018-09-26 20:38:19 --> Output Class Initialized
INFO - 2018-09-26 20:38:19 --> Security Class Initialized
DEBUG - 2018-09-26 20:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 20:38:19 --> CSRF cookie sent
INFO - 2018-09-26 20:38:19 --> CSRF token verified
INFO - 2018-09-26 20:38:19 --> Input Class Initialized
INFO - 2018-09-26 20:38:19 --> Language Class Initialized
INFO - 2018-09-26 20:38:19 --> Loader Class Initialized
INFO - 2018-09-26 20:38:19 --> Helper loaded: url_helper
INFO - 2018-09-26 20:38:19 --> Helper loaded: form_helper
INFO - 2018-09-26 20:38:19 --> Helper loaded: language_helper
DEBUG - 2018-09-26 20:38:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 20:38:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 20:38:19 --> User Agent Class Initialized
INFO - 2018-09-26 20:38:19 --> Controller Class Initialized
INFO - 2018-09-26 20:38:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-26 20:38:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-26 20:38:19 --> Pixel_Model class loaded
INFO - 2018-09-26 20:38:19 --> Database Driver Class Initialized
INFO - 2018-09-26 20:38:19 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:38:19 --> Form Validation Class Initialized
INFO - 2018-09-26 20:38:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-26 20:38:19 --> Database Driver Class Initialized
INFO - 2018-09-26 20:38:19 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:38:19 --> Config Class Initialized
INFO - 2018-09-26 20:38:19 --> Hooks Class Initialized
DEBUG - 2018-09-26 20:38:19 --> UTF-8 Support Enabled
INFO - 2018-09-26 20:38:19 --> Utf8 Class Initialized
INFO - 2018-09-26 20:38:19 --> URI Class Initialized
INFO - 2018-09-26 20:38:19 --> Router Class Initialized
INFO - 2018-09-26 20:38:19 --> Output Class Initialized
INFO - 2018-09-26 20:38:19 --> Security Class Initialized
DEBUG - 2018-09-26 20:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 20:38:19 --> CSRF cookie sent
INFO - 2018-09-26 20:38:19 --> Input Class Initialized
INFO - 2018-09-26 20:38:19 --> Language Class Initialized
INFO - 2018-09-26 20:38:19 --> Loader Class Initialized
INFO - 2018-09-26 20:38:19 --> Helper loaded: url_helper
INFO - 2018-09-26 20:38:19 --> Helper loaded: form_helper
INFO - 2018-09-26 20:38:19 --> Helper loaded: language_helper
DEBUG - 2018-09-26 20:38:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 20:38:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 20:38:19 --> User Agent Class Initialized
INFO - 2018-09-26 20:38:19 --> Controller Class Initialized
INFO - 2018-09-26 20:38:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-26 20:38:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-26 20:38:19 --> Pixel_Model class loaded
INFO - 2018-09-26 20:38:19 --> Database Driver Class Initialized
INFO - 2018-09-26 20:38:19 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:38:19 --> Database Driver Class Initialized
INFO - 2018-09-26 20:38:19 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:38:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-26 20:38:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-26 20:38:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-26 20:38:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-26 20:38:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-26 20:38:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-26 20:38:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_title.php
INFO - 2018-09-26 20:38:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-26 20:38:19 --> Final output sent to browser
DEBUG - 2018-09-26 20:38:19 --> Total execution time: 0.0520
INFO - 2018-09-26 20:38:21 --> Config Class Initialized
INFO - 2018-09-26 20:38:21 --> Hooks Class Initialized
DEBUG - 2018-09-26 20:38:21 --> UTF-8 Support Enabled
INFO - 2018-09-26 20:38:21 --> Utf8 Class Initialized
INFO - 2018-09-26 20:38:21 --> URI Class Initialized
INFO - 2018-09-26 20:38:21 --> Router Class Initialized
INFO - 2018-09-26 20:38:21 --> Output Class Initialized
INFO - 2018-09-26 20:38:21 --> Security Class Initialized
DEBUG - 2018-09-26 20:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 20:38:21 --> CSRF cookie sent
INFO - 2018-09-26 20:38:21 --> CSRF token verified
INFO - 2018-09-26 20:38:21 --> Input Class Initialized
INFO - 2018-09-26 20:38:21 --> Language Class Initialized
INFO - 2018-09-26 20:38:21 --> Loader Class Initialized
INFO - 2018-09-26 20:38:21 --> Helper loaded: url_helper
INFO - 2018-09-26 20:38:21 --> Helper loaded: form_helper
INFO - 2018-09-26 20:38:21 --> Helper loaded: language_helper
DEBUG - 2018-09-26 20:38:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 20:38:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 20:38:21 --> User Agent Class Initialized
INFO - 2018-09-26 20:38:21 --> Controller Class Initialized
INFO - 2018-09-26 20:38:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-26 20:38:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-26 20:38:21 --> Pixel_Model class loaded
INFO - 2018-09-26 20:38:21 --> Database Driver Class Initialized
INFO - 2018-09-26 20:38:21 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:38:21 --> Form Validation Class Initialized
INFO - 2018-09-26 20:38:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-26 20:38:21 --> Database Driver Class Initialized
INFO - 2018-09-26 20:38:21 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:38:21 --> Config Class Initialized
INFO - 2018-09-26 20:38:21 --> Hooks Class Initialized
DEBUG - 2018-09-26 20:38:21 --> UTF-8 Support Enabled
INFO - 2018-09-26 20:38:21 --> Utf8 Class Initialized
INFO - 2018-09-26 20:38:21 --> URI Class Initialized
INFO - 2018-09-26 20:38:21 --> Router Class Initialized
INFO - 2018-09-26 20:38:21 --> Output Class Initialized
INFO - 2018-09-26 20:38:21 --> Security Class Initialized
DEBUG - 2018-09-26 20:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 20:38:21 --> CSRF cookie sent
INFO - 2018-09-26 20:38:21 --> Input Class Initialized
INFO - 2018-09-26 20:38:21 --> Language Class Initialized
INFO - 2018-09-26 20:38:21 --> Loader Class Initialized
INFO - 2018-09-26 20:38:21 --> Helper loaded: url_helper
INFO - 2018-09-26 20:38:21 --> Helper loaded: form_helper
INFO - 2018-09-26 20:38:21 --> Helper loaded: language_helper
DEBUG - 2018-09-26 20:38:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 20:38:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 20:38:21 --> User Agent Class Initialized
INFO - 2018-09-26 20:38:21 --> Controller Class Initialized
INFO - 2018-09-26 20:38:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-26 20:38:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-26 20:38:21 --> Pixel_Model class loaded
INFO - 2018-09-26 20:38:21 --> Database Driver Class Initialized
INFO - 2018-09-26 20:38:21 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:38:21 --> Database Driver Class Initialized
INFO - 2018-09-26 20:38:21 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:38:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-26 20:38:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-26 20:38:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-26 20:38:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-26 20:38:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-09-26 20:38:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-09-26 20:38:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-09-26 20:38:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-26 20:38:21 --> Final output sent to browser
DEBUG - 2018-09-26 20:38:21 --> Total execution time: 0.0494
INFO - 2018-09-26 20:38:23 --> Config Class Initialized
INFO - 2018-09-26 20:38:23 --> Hooks Class Initialized
DEBUG - 2018-09-26 20:38:23 --> UTF-8 Support Enabled
INFO - 2018-09-26 20:38:23 --> Utf8 Class Initialized
INFO - 2018-09-26 20:38:23 --> URI Class Initialized
INFO - 2018-09-26 20:38:23 --> Router Class Initialized
INFO - 2018-09-26 20:38:23 --> Output Class Initialized
INFO - 2018-09-26 20:38:23 --> Security Class Initialized
DEBUG - 2018-09-26 20:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 20:38:23 --> CSRF cookie sent
INFO - 2018-09-26 20:38:23 --> CSRF token verified
INFO - 2018-09-26 20:38:23 --> Input Class Initialized
INFO - 2018-09-26 20:38:23 --> Language Class Initialized
INFO - 2018-09-26 20:38:23 --> Loader Class Initialized
INFO - 2018-09-26 20:38:23 --> Helper loaded: url_helper
INFO - 2018-09-26 20:38:23 --> Helper loaded: form_helper
INFO - 2018-09-26 20:38:23 --> Helper loaded: language_helper
DEBUG - 2018-09-26 20:38:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 20:38:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 20:38:23 --> User Agent Class Initialized
INFO - 2018-09-26 20:38:23 --> Controller Class Initialized
INFO - 2018-09-26 20:38:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-26 20:38:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-26 20:38:23 --> Pixel_Model class loaded
INFO - 2018-09-26 20:38:23 --> Database Driver Class Initialized
INFO - 2018-09-26 20:38:23 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:38:23 --> Form Validation Class Initialized
INFO - 2018-09-26 20:38:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-26 20:38:23 --> Database Driver Class Initialized
INFO - 2018-09-26 20:38:23 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:38:23 --> Config Class Initialized
INFO - 2018-09-26 20:38:23 --> Hooks Class Initialized
DEBUG - 2018-09-26 20:38:23 --> UTF-8 Support Enabled
INFO - 2018-09-26 20:38:23 --> Utf8 Class Initialized
INFO - 2018-09-26 20:38:23 --> URI Class Initialized
INFO - 2018-09-26 20:38:23 --> Router Class Initialized
INFO - 2018-09-26 20:38:23 --> Output Class Initialized
INFO - 2018-09-26 20:38:23 --> Security Class Initialized
DEBUG - 2018-09-26 20:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 20:38:23 --> CSRF cookie sent
INFO - 2018-09-26 20:38:23 --> Input Class Initialized
INFO - 2018-09-26 20:38:23 --> Language Class Initialized
INFO - 2018-09-26 20:38:23 --> Loader Class Initialized
INFO - 2018-09-26 20:38:23 --> Helper loaded: url_helper
INFO - 2018-09-26 20:38:23 --> Helper loaded: form_helper
INFO - 2018-09-26 20:38:23 --> Helper loaded: language_helper
DEBUG - 2018-09-26 20:38:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 20:38:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 20:38:23 --> User Agent Class Initialized
INFO - 2018-09-26 20:38:23 --> Controller Class Initialized
INFO - 2018-09-26 20:38:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-09-26 20:38:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-09-26 20:38:23 --> Pixel_Model class loaded
INFO - 2018-09-26 20:38:23 --> Database Driver Class Initialized
INFO - 2018-09-26 20:38:23 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:38:23 --> Database Driver Class Initialized
INFO - 2018-09-26 20:38:23 --> Model "QuestionsModel" initialized
INFO - 2018-09-26 20:38:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-09-26 20:38:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-09-26 20:38:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-09-26 20:38:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-09-26 20:38:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-09-26 20:38:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-09-26 20:38:23 --> Final output sent to browser
DEBUG - 2018-09-26 20:38:23 --> Total execution time: 0.0502

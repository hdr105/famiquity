<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-10-01 14:23:43 --> Config Class Initialized
INFO - 2018-10-01 14:23:43 --> Hooks Class Initialized
DEBUG - 2018-10-01 14:23:43 --> UTF-8 Support Enabled
INFO - 2018-10-01 14:23:43 --> Utf8 Class Initialized
INFO - 2018-10-01 14:23:43 --> URI Class Initialized
DEBUG - 2018-10-01 14:23:43 --> No URI present. Default controller set.
INFO - 2018-10-01 14:23:43 --> Router Class Initialized
INFO - 2018-10-01 14:23:43 --> Output Class Initialized
INFO - 2018-10-01 14:23:43 --> Security Class Initialized
DEBUG - 2018-10-01 14:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 14:23:43 --> CSRF cookie sent
INFO - 2018-10-01 14:23:43 --> Input Class Initialized
INFO - 2018-10-01 14:23:43 --> Language Class Initialized
INFO - 2018-10-01 14:23:43 --> Loader Class Initialized
INFO - 2018-10-01 14:23:43 --> Helper loaded: url_helper
INFO - 2018-10-01 14:23:43 --> Helper loaded: form_helper
INFO - 2018-10-01 14:23:43 --> Helper loaded: language_helper
DEBUG - 2018-10-01 14:23:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 14:23:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 14:23:43 --> User Agent Class Initialized
INFO - 2018-10-01 14:23:43 --> Controller Class Initialized
INFO - 2018-10-01 14:23:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-01 14:23:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-01 14:23:43 --> Pixel_Model class loaded
INFO - 2018-10-01 14:23:43 --> Database Driver Class Initialized
INFO - 2018-10-01 14:23:43 --> Model "QuestionsModel" initialized
INFO - 2018-10-01 14:23:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-01 14:23:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-01 14:23:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-01 14:23:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-01 14:23:43 --> Final output sent to browser
DEBUG - 2018-10-01 14:23:43 --> Total execution time: 0.0374
INFO - 2018-10-01 14:23:44 --> Config Class Initialized
INFO - 2018-10-01 14:23:44 --> Hooks Class Initialized
DEBUG - 2018-10-01 14:23:44 --> UTF-8 Support Enabled
INFO - 2018-10-01 14:23:44 --> Utf8 Class Initialized
INFO - 2018-10-01 14:23:44 --> URI Class Initialized
DEBUG - 2018-10-01 14:23:44 --> No URI present. Default controller set.
INFO - 2018-10-01 14:23:44 --> Router Class Initialized
INFO - 2018-10-01 14:23:44 --> Output Class Initialized
INFO - 2018-10-01 14:23:44 --> Security Class Initialized
DEBUG - 2018-10-01 14:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 14:23:44 --> CSRF cookie sent
INFO - 2018-10-01 14:23:44 --> Input Class Initialized
INFO - 2018-10-01 14:23:44 --> Language Class Initialized
INFO - 2018-10-01 14:23:44 --> Loader Class Initialized
INFO - 2018-10-01 14:23:44 --> Helper loaded: url_helper
INFO - 2018-10-01 14:23:44 --> Helper loaded: form_helper
INFO - 2018-10-01 14:23:44 --> Helper loaded: language_helper
DEBUG - 2018-10-01 14:23:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 14:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 14:23:44 --> User Agent Class Initialized
INFO - 2018-10-01 14:23:44 --> Controller Class Initialized
INFO - 2018-10-01 14:23:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-01 14:23:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-01 14:23:44 --> Pixel_Model class loaded
INFO - 2018-10-01 14:23:44 --> Database Driver Class Initialized
INFO - 2018-10-01 14:23:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-01 14:23:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-01 14:23:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-01 14:23:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-01 14:23:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-01 14:23:44 --> Final output sent to browser
DEBUG - 2018-10-01 14:23:44 --> Total execution time: 0.0308
INFO - 2018-10-01 14:27:25 --> Config Class Initialized
INFO - 2018-10-01 14:27:25 --> Hooks Class Initialized
DEBUG - 2018-10-01 14:27:25 --> UTF-8 Support Enabled
INFO - 2018-10-01 14:27:25 --> Utf8 Class Initialized
INFO - 2018-10-01 14:27:25 --> URI Class Initialized
INFO - 2018-10-01 14:27:25 --> Router Class Initialized
INFO - 2018-10-01 14:27:25 --> Output Class Initialized
INFO - 2018-10-01 14:27:25 --> Security Class Initialized
DEBUG - 2018-10-01 14:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 14:27:25 --> CSRF cookie sent
INFO - 2018-10-01 14:27:25 --> CSRF token verified
INFO - 2018-10-01 14:27:25 --> Input Class Initialized
INFO - 2018-10-01 14:27:25 --> Language Class Initialized
INFO - 2018-10-01 14:27:25 --> Loader Class Initialized
INFO - 2018-10-01 14:27:25 --> Helper loaded: url_helper
INFO - 2018-10-01 14:27:25 --> Helper loaded: form_helper
INFO - 2018-10-01 14:27:25 --> Helper loaded: language_helper
DEBUG - 2018-10-01 14:27:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 14:27:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 14:27:25 --> User Agent Class Initialized
INFO - 2018-10-01 14:27:25 --> Controller Class Initialized
INFO - 2018-10-01 14:27:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-01 14:27:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-01 14:27:25 --> Pixel_Model class loaded
INFO - 2018-10-01 14:27:25 --> Database Driver Class Initialized
INFO - 2018-10-01 14:27:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-01 14:27:25 --> Database Driver Class Initialized
INFO - 2018-10-01 14:27:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-01 14:27:25 --> Config Class Initialized
INFO - 2018-10-01 14:27:25 --> Hooks Class Initialized
DEBUG - 2018-10-01 14:27:25 --> UTF-8 Support Enabled
INFO - 2018-10-01 14:27:25 --> Utf8 Class Initialized
INFO - 2018-10-01 14:27:25 --> URI Class Initialized
INFO - 2018-10-01 14:27:25 --> Router Class Initialized
INFO - 2018-10-01 14:27:25 --> Output Class Initialized
INFO - 2018-10-01 14:27:25 --> Security Class Initialized
DEBUG - 2018-10-01 14:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 14:27:25 --> CSRF cookie sent
INFO - 2018-10-01 14:27:25 --> Input Class Initialized
INFO - 2018-10-01 14:27:25 --> Language Class Initialized
INFO - 2018-10-01 14:27:25 --> Loader Class Initialized
INFO - 2018-10-01 14:27:25 --> Helper loaded: url_helper
INFO - 2018-10-01 14:27:25 --> Helper loaded: form_helper
INFO - 2018-10-01 14:27:25 --> Helper loaded: language_helper
DEBUG - 2018-10-01 14:27:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 14:27:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 14:27:25 --> User Agent Class Initialized
INFO - 2018-10-01 14:27:25 --> Controller Class Initialized
INFO - 2018-10-01 14:27:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-01 14:27:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-01 14:27:25 --> Pixel_Model class loaded
INFO - 2018-10-01 14:27:25 --> Database Driver Class Initialized
INFO - 2018-10-01 14:27:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-01 14:27:25 --> Database Driver Class Initialized
INFO - 2018-10-01 14:27:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-01 14:27:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-01 14:27:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-01 14:27:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-01 14:27:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-01 14:27:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-01 14:27:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-01 14:27:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-01 14:27:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-01 14:27:25 --> Final output sent to browser
DEBUG - 2018-10-01 14:27:25 --> Total execution time: 0.0758
INFO - 2018-10-01 14:27:41 --> Config Class Initialized
INFO - 2018-10-01 14:27:41 --> Hooks Class Initialized
DEBUG - 2018-10-01 14:27:41 --> UTF-8 Support Enabled
INFO - 2018-10-01 14:27:41 --> Utf8 Class Initialized
INFO - 2018-10-01 14:27:41 --> URI Class Initialized
INFO - 2018-10-01 14:27:41 --> Router Class Initialized
INFO - 2018-10-01 14:27:41 --> Output Class Initialized
INFO - 2018-10-01 14:27:41 --> Security Class Initialized
DEBUG - 2018-10-01 14:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 14:27:41 --> CSRF cookie sent
INFO - 2018-10-01 14:27:41 --> CSRF token verified
INFO - 2018-10-01 14:27:41 --> Input Class Initialized
INFO - 2018-10-01 14:27:41 --> Language Class Initialized
INFO - 2018-10-01 14:27:41 --> Loader Class Initialized
INFO - 2018-10-01 14:27:41 --> Helper loaded: url_helper
INFO - 2018-10-01 14:27:41 --> Helper loaded: form_helper
INFO - 2018-10-01 14:27:41 --> Helper loaded: language_helper
DEBUG - 2018-10-01 14:27:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 14:27:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 14:27:41 --> User Agent Class Initialized
INFO - 2018-10-01 14:27:41 --> Controller Class Initialized
INFO - 2018-10-01 14:27:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-01 14:27:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-01 14:27:41 --> Pixel_Model class loaded
INFO - 2018-10-01 14:27:41 --> Database Driver Class Initialized
INFO - 2018-10-01 14:27:41 --> Model "QuestionsModel" initialized
INFO - 2018-10-01 14:27:41 --> Form Validation Class Initialized
INFO - 2018-10-01 14:27:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-01 14:27:41 --> Database Driver Class Initialized
INFO - 2018-10-01 14:27:41 --> Model "QuestionsModel" initialized
INFO - 2018-10-01 14:27:41 --> Config Class Initialized
INFO - 2018-10-01 14:27:41 --> Hooks Class Initialized
DEBUG - 2018-10-01 14:27:41 --> UTF-8 Support Enabled
INFO - 2018-10-01 14:27:41 --> Utf8 Class Initialized
INFO - 2018-10-01 14:27:41 --> URI Class Initialized
INFO - 2018-10-01 14:27:41 --> Router Class Initialized
INFO - 2018-10-01 14:27:41 --> Output Class Initialized
INFO - 2018-10-01 14:27:41 --> Security Class Initialized
DEBUG - 2018-10-01 14:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 14:27:41 --> CSRF cookie sent
INFO - 2018-10-01 14:27:41 --> Input Class Initialized
INFO - 2018-10-01 14:27:41 --> Language Class Initialized
INFO - 2018-10-01 14:27:41 --> Loader Class Initialized
INFO - 2018-10-01 14:27:41 --> Helper loaded: url_helper
INFO - 2018-10-01 14:27:41 --> Helper loaded: form_helper
INFO - 2018-10-01 14:27:41 --> Helper loaded: language_helper
DEBUG - 2018-10-01 14:27:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 14:27:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 14:27:41 --> User Agent Class Initialized
INFO - 2018-10-01 14:27:41 --> Controller Class Initialized
INFO - 2018-10-01 14:27:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-01 14:27:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-01 14:27:41 --> Pixel_Model class loaded
INFO - 2018-10-01 14:27:41 --> Database Driver Class Initialized
INFO - 2018-10-01 14:27:41 --> Model "QuestionsModel" initialized
INFO - 2018-10-01 14:27:41 --> Database Driver Class Initialized
INFO - 2018-10-01 14:27:41 --> Model "QuestionsModel" initialized
INFO - 2018-10-01 14:27:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-01 14:27:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-01 14:27:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-01 14:27:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-01 14:27:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-01 14:27:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-01 14:27:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-10-01 14:27:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-01 14:27:41 --> Final output sent to browser
DEBUG - 2018-10-01 14:27:41 --> Total execution time: 0.0449
INFO - 2018-10-01 14:27:53 --> Config Class Initialized
INFO - 2018-10-01 14:27:53 --> Hooks Class Initialized
DEBUG - 2018-10-01 14:27:53 --> UTF-8 Support Enabled
INFO - 2018-10-01 14:27:53 --> Utf8 Class Initialized
INFO - 2018-10-01 14:27:53 --> URI Class Initialized
INFO - 2018-10-01 14:27:53 --> Router Class Initialized
INFO - 2018-10-01 14:27:53 --> Output Class Initialized
INFO - 2018-10-01 14:27:53 --> Security Class Initialized
DEBUG - 2018-10-01 14:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 14:27:53 --> CSRF cookie sent
INFO - 2018-10-01 14:27:53 --> CSRF token verified
INFO - 2018-10-01 14:27:53 --> Input Class Initialized
INFO - 2018-10-01 14:27:53 --> Language Class Initialized
INFO - 2018-10-01 14:27:53 --> Loader Class Initialized
INFO - 2018-10-01 14:27:53 --> Helper loaded: url_helper
INFO - 2018-10-01 14:27:53 --> Helper loaded: form_helper
INFO - 2018-10-01 14:27:53 --> Helper loaded: language_helper
DEBUG - 2018-10-01 14:27:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 14:27:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 14:27:53 --> User Agent Class Initialized
INFO - 2018-10-01 14:27:53 --> Controller Class Initialized
INFO - 2018-10-01 14:27:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-01 14:27:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-01 14:27:53 --> Pixel_Model class loaded
INFO - 2018-10-01 14:27:53 --> Database Driver Class Initialized
INFO - 2018-10-01 14:27:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-01 14:27:53 --> Form Validation Class Initialized
INFO - 2018-10-01 14:27:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-01 14:27:53 --> Database Driver Class Initialized
INFO - 2018-10-01 14:27:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-01 14:27:53 --> Config Class Initialized
INFO - 2018-10-01 14:27:53 --> Hooks Class Initialized
DEBUG - 2018-10-01 14:27:53 --> UTF-8 Support Enabled
INFO - 2018-10-01 14:27:53 --> Utf8 Class Initialized
INFO - 2018-10-01 14:27:53 --> URI Class Initialized
INFO - 2018-10-01 14:27:53 --> Router Class Initialized
INFO - 2018-10-01 14:27:53 --> Output Class Initialized
INFO - 2018-10-01 14:27:53 --> Security Class Initialized
DEBUG - 2018-10-01 14:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 14:27:53 --> CSRF cookie sent
INFO - 2018-10-01 14:27:53 --> Input Class Initialized
INFO - 2018-10-01 14:27:53 --> Language Class Initialized
INFO - 2018-10-01 14:27:53 --> Loader Class Initialized
INFO - 2018-10-01 14:27:53 --> Helper loaded: url_helper
INFO - 2018-10-01 14:27:53 --> Helper loaded: form_helper
INFO - 2018-10-01 14:27:53 --> Helper loaded: language_helper
DEBUG - 2018-10-01 14:27:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 14:27:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 14:27:53 --> User Agent Class Initialized
INFO - 2018-10-01 14:27:53 --> Controller Class Initialized
INFO - 2018-10-01 14:27:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-01 14:27:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-01 14:27:53 --> Pixel_Model class loaded
INFO - 2018-10-01 14:27:53 --> Database Driver Class Initialized
INFO - 2018-10-01 14:27:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-01 14:27:53 --> Database Driver Class Initialized
INFO - 2018-10-01 14:27:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-01 14:27:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-01 14:27:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-01 14:27:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-10-01 14:27:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-01 14:27:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-01 14:27:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-01 14:27:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-01 14:27:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-10-01 14:27:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-01 14:27:53 --> Final output sent to browser
DEBUG - 2018-10-01 14:27:53 --> Total execution time: 0.0411
INFO - 2018-10-01 14:28:25 --> Config Class Initialized
INFO - 2018-10-01 14:28:25 --> Hooks Class Initialized
DEBUG - 2018-10-01 14:28:25 --> UTF-8 Support Enabled
INFO - 2018-10-01 14:28:25 --> Utf8 Class Initialized
INFO - 2018-10-01 14:28:25 --> URI Class Initialized
INFO - 2018-10-01 14:28:25 --> Router Class Initialized
INFO - 2018-10-01 14:28:25 --> Output Class Initialized
INFO - 2018-10-01 14:28:25 --> Security Class Initialized
DEBUG - 2018-10-01 14:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 14:28:25 --> CSRF cookie sent
INFO - 2018-10-01 14:28:25 --> CSRF token verified
INFO - 2018-10-01 14:28:25 --> Input Class Initialized
INFO - 2018-10-01 14:28:25 --> Language Class Initialized
INFO - 2018-10-01 14:28:25 --> Loader Class Initialized
INFO - 2018-10-01 14:28:25 --> Helper loaded: url_helper
INFO - 2018-10-01 14:28:25 --> Helper loaded: form_helper
INFO - 2018-10-01 14:28:25 --> Helper loaded: language_helper
DEBUG - 2018-10-01 14:28:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 14:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 14:28:25 --> User Agent Class Initialized
INFO - 2018-10-01 14:28:25 --> Controller Class Initialized
INFO - 2018-10-01 14:28:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-01 14:28:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-01 14:28:25 --> Pixel_Model class loaded
INFO - 2018-10-01 14:28:25 --> Database Driver Class Initialized
INFO - 2018-10-01 14:28:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-01 14:28:25 --> Form Validation Class Initialized
INFO - 2018-10-01 14:28:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-01 14:28:25 --> Database Driver Class Initialized
INFO - 2018-10-01 14:28:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-01 14:28:25 --> Config Class Initialized
INFO - 2018-10-01 14:28:25 --> Hooks Class Initialized
DEBUG - 2018-10-01 14:28:25 --> UTF-8 Support Enabled
INFO - 2018-10-01 14:28:25 --> Utf8 Class Initialized
INFO - 2018-10-01 14:28:25 --> URI Class Initialized
INFO - 2018-10-01 14:28:25 --> Router Class Initialized
INFO - 2018-10-01 14:28:25 --> Output Class Initialized
INFO - 2018-10-01 14:28:25 --> Security Class Initialized
DEBUG - 2018-10-01 14:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 14:28:25 --> CSRF cookie sent
INFO - 2018-10-01 14:28:25 --> Input Class Initialized
INFO - 2018-10-01 14:28:25 --> Language Class Initialized
INFO - 2018-10-01 14:28:25 --> Loader Class Initialized
INFO - 2018-10-01 14:28:25 --> Helper loaded: url_helper
INFO - 2018-10-01 14:28:25 --> Helper loaded: form_helper
INFO - 2018-10-01 14:28:25 --> Helper loaded: language_helper
DEBUG - 2018-10-01 14:28:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 14:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 14:28:25 --> User Agent Class Initialized
INFO - 2018-10-01 14:28:25 --> Controller Class Initialized
INFO - 2018-10-01 14:28:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-01 14:28:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-01 14:28:25 --> Pixel_Model class loaded
INFO - 2018-10-01 14:28:25 --> Database Driver Class Initialized
INFO - 2018-10-01 14:28:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-01 14:28:25 --> Database Driver Class Initialized
INFO - 2018-10-01 14:28:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-01 14:28:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-01 14:28:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-01 14:28:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-01 14:28:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-01 14:28:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-01 14:28:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-01 14:28:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-01 14:28:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-01 14:28:25 --> Final output sent to browser
DEBUG - 2018-10-01 14:28:25 --> Total execution time: 0.0391
INFO - 2018-10-01 14:28:42 --> Config Class Initialized
INFO - 2018-10-01 14:28:42 --> Hooks Class Initialized
DEBUG - 2018-10-01 14:28:42 --> UTF-8 Support Enabled
INFO - 2018-10-01 14:28:42 --> Utf8 Class Initialized
INFO - 2018-10-01 14:28:42 --> URI Class Initialized
INFO - 2018-10-01 14:28:42 --> Router Class Initialized
INFO - 2018-10-01 14:28:42 --> Output Class Initialized
INFO - 2018-10-01 14:28:42 --> Security Class Initialized
DEBUG - 2018-10-01 14:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 14:28:42 --> CSRF cookie sent
INFO - 2018-10-01 14:28:42 --> CSRF token verified
INFO - 2018-10-01 14:28:42 --> Input Class Initialized
INFO - 2018-10-01 14:28:42 --> Language Class Initialized
INFO - 2018-10-01 14:28:42 --> Loader Class Initialized
INFO - 2018-10-01 14:28:42 --> Helper loaded: url_helper
INFO - 2018-10-01 14:28:42 --> Helper loaded: form_helper
INFO - 2018-10-01 14:28:42 --> Helper loaded: language_helper
DEBUG - 2018-10-01 14:28:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 14:28:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 14:28:42 --> User Agent Class Initialized
INFO - 2018-10-01 14:28:42 --> Controller Class Initialized
INFO - 2018-10-01 14:28:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-01 14:28:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-01 14:28:42 --> Pixel_Model class loaded
INFO - 2018-10-01 14:28:42 --> Database Driver Class Initialized
INFO - 2018-10-01 14:28:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-01 14:28:42 --> Form Validation Class Initialized
INFO - 2018-10-01 14:28:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-01 14:28:42 --> Database Driver Class Initialized
INFO - 2018-10-01 14:28:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-01 14:28:42 --> Config Class Initialized
INFO - 2018-10-01 14:28:42 --> Hooks Class Initialized
DEBUG - 2018-10-01 14:28:42 --> UTF-8 Support Enabled
INFO - 2018-10-01 14:28:42 --> Utf8 Class Initialized
INFO - 2018-10-01 14:28:42 --> URI Class Initialized
INFO - 2018-10-01 14:28:42 --> Router Class Initialized
INFO - 2018-10-01 14:28:42 --> Output Class Initialized
INFO - 2018-10-01 14:28:42 --> Security Class Initialized
DEBUG - 2018-10-01 14:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 14:28:42 --> CSRF cookie sent
INFO - 2018-10-01 14:28:42 --> Input Class Initialized
INFO - 2018-10-01 14:28:42 --> Language Class Initialized
INFO - 2018-10-01 14:28:42 --> Loader Class Initialized
INFO - 2018-10-01 14:28:42 --> Helper loaded: url_helper
INFO - 2018-10-01 14:28:42 --> Helper loaded: form_helper
INFO - 2018-10-01 14:28:42 --> Helper loaded: language_helper
DEBUG - 2018-10-01 14:28:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 14:28:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 14:28:42 --> User Agent Class Initialized
INFO - 2018-10-01 14:28:42 --> Controller Class Initialized
INFO - 2018-10-01 14:28:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-01 14:28:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-01 14:28:42 --> Pixel_Model class loaded
INFO - 2018-10-01 14:28:42 --> Database Driver Class Initialized
INFO - 2018-10-01 14:28:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-01 14:28:42 --> Database Driver Class Initialized
INFO - 2018-10-01 14:28:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-01 14:28:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-01 14:28:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-01 14:28:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-01 14:28:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-01 14:28:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-01 14:28:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-01 14:28:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-10-01 14:28:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-01 14:28:42 --> Final output sent to browser
DEBUG - 2018-10-01 14:28:42 --> Total execution time: 0.0458
INFO - 2018-10-01 14:28:49 --> Config Class Initialized
INFO - 2018-10-01 14:28:49 --> Hooks Class Initialized
DEBUG - 2018-10-01 14:28:49 --> UTF-8 Support Enabled
INFO - 2018-10-01 14:28:49 --> Utf8 Class Initialized
INFO - 2018-10-01 14:28:49 --> URI Class Initialized
INFO - 2018-10-01 14:28:49 --> Router Class Initialized
INFO - 2018-10-01 14:28:49 --> Output Class Initialized
INFO - 2018-10-01 14:28:49 --> Security Class Initialized
DEBUG - 2018-10-01 14:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 14:28:49 --> CSRF cookie sent
INFO - 2018-10-01 14:28:49 --> CSRF token verified
INFO - 2018-10-01 14:28:49 --> Input Class Initialized
INFO - 2018-10-01 14:28:49 --> Language Class Initialized
INFO - 2018-10-01 14:28:49 --> Loader Class Initialized
INFO - 2018-10-01 14:28:49 --> Helper loaded: url_helper
INFO - 2018-10-01 14:28:49 --> Helper loaded: form_helper
INFO - 2018-10-01 14:28:49 --> Helper loaded: language_helper
DEBUG - 2018-10-01 14:28:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 14:28:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 14:28:49 --> User Agent Class Initialized
INFO - 2018-10-01 14:28:49 --> Controller Class Initialized
INFO - 2018-10-01 14:28:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-01 14:28:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-01 14:28:49 --> Pixel_Model class loaded
INFO - 2018-10-01 14:28:49 --> Database Driver Class Initialized
INFO - 2018-10-01 14:28:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-01 14:28:49 --> Form Validation Class Initialized
INFO - 2018-10-01 14:28:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-01 14:28:49 --> Database Driver Class Initialized
INFO - 2018-10-01 14:28:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-01 14:28:49 --> Config Class Initialized
INFO - 2018-10-01 14:28:49 --> Hooks Class Initialized
DEBUG - 2018-10-01 14:28:49 --> UTF-8 Support Enabled
INFO - 2018-10-01 14:28:49 --> Utf8 Class Initialized
INFO - 2018-10-01 14:28:49 --> URI Class Initialized
INFO - 2018-10-01 14:28:49 --> Router Class Initialized
INFO - 2018-10-01 14:28:49 --> Output Class Initialized
INFO - 2018-10-01 14:28:49 --> Security Class Initialized
DEBUG - 2018-10-01 14:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 14:28:49 --> CSRF cookie sent
INFO - 2018-10-01 14:28:49 --> Input Class Initialized
INFO - 2018-10-01 14:28:49 --> Language Class Initialized
INFO - 2018-10-01 14:28:49 --> Loader Class Initialized
INFO - 2018-10-01 14:28:49 --> Helper loaded: url_helper
INFO - 2018-10-01 14:28:49 --> Helper loaded: form_helper
INFO - 2018-10-01 14:28:49 --> Helper loaded: language_helper
DEBUG - 2018-10-01 14:28:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 14:28:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 14:28:49 --> User Agent Class Initialized
INFO - 2018-10-01 14:28:49 --> Controller Class Initialized
INFO - 2018-10-01 14:28:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-01 14:28:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-01 14:28:49 --> Pixel_Model class loaded
INFO - 2018-10-01 14:28:49 --> Database Driver Class Initialized
INFO - 2018-10-01 14:28:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-01 14:28:49 --> Database Driver Class Initialized
INFO - 2018-10-01 14:28:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-01 14:28:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-01 14:28:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-01 14:28:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-01 14:28:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-01 14:28:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-01 14:28:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-01 14:28:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_title.php
INFO - 2018-10-01 14:28:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-01 14:28:49 --> Final output sent to browser
DEBUG - 2018-10-01 14:28:49 --> Total execution time: 0.0641
INFO - 2018-10-01 14:28:53 --> Config Class Initialized
INFO - 2018-10-01 14:28:53 --> Hooks Class Initialized
DEBUG - 2018-10-01 14:28:53 --> UTF-8 Support Enabled
INFO - 2018-10-01 14:28:53 --> Utf8 Class Initialized
INFO - 2018-10-01 14:28:53 --> URI Class Initialized
INFO - 2018-10-01 14:28:53 --> Router Class Initialized
INFO - 2018-10-01 14:28:53 --> Output Class Initialized
INFO - 2018-10-01 14:28:53 --> Security Class Initialized
DEBUG - 2018-10-01 14:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 14:28:53 --> CSRF cookie sent
INFO - 2018-10-01 14:28:53 --> CSRF token verified
INFO - 2018-10-01 14:28:53 --> Input Class Initialized
INFO - 2018-10-01 14:28:53 --> Language Class Initialized
INFO - 2018-10-01 14:28:53 --> Loader Class Initialized
INFO - 2018-10-01 14:28:53 --> Helper loaded: url_helper
INFO - 2018-10-01 14:28:53 --> Helper loaded: form_helper
INFO - 2018-10-01 14:28:53 --> Helper loaded: language_helper
DEBUG - 2018-10-01 14:28:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 14:28:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 14:28:53 --> User Agent Class Initialized
INFO - 2018-10-01 14:28:53 --> Controller Class Initialized
INFO - 2018-10-01 14:28:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-01 14:28:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-01 14:28:53 --> Pixel_Model class loaded
INFO - 2018-10-01 14:28:53 --> Database Driver Class Initialized
INFO - 2018-10-01 14:28:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-01 14:28:53 --> Form Validation Class Initialized
INFO - 2018-10-01 14:28:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-01 14:28:53 --> Database Driver Class Initialized
INFO - 2018-10-01 14:28:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-01 14:28:53 --> Config Class Initialized
INFO - 2018-10-01 14:28:53 --> Hooks Class Initialized
DEBUG - 2018-10-01 14:28:53 --> UTF-8 Support Enabled
INFO - 2018-10-01 14:28:53 --> Utf8 Class Initialized
INFO - 2018-10-01 14:28:53 --> URI Class Initialized
INFO - 2018-10-01 14:28:53 --> Router Class Initialized
INFO - 2018-10-01 14:28:53 --> Output Class Initialized
INFO - 2018-10-01 14:28:53 --> Security Class Initialized
DEBUG - 2018-10-01 14:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 14:28:53 --> CSRF cookie sent
INFO - 2018-10-01 14:28:53 --> Input Class Initialized
INFO - 2018-10-01 14:28:53 --> Language Class Initialized
INFO - 2018-10-01 14:28:53 --> Loader Class Initialized
INFO - 2018-10-01 14:28:53 --> Helper loaded: url_helper
INFO - 2018-10-01 14:28:53 --> Helper loaded: form_helper
INFO - 2018-10-01 14:28:53 --> Helper loaded: language_helper
DEBUG - 2018-10-01 14:28:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 14:28:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 14:28:53 --> User Agent Class Initialized
INFO - 2018-10-01 14:28:53 --> Controller Class Initialized
INFO - 2018-10-01 14:28:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-01 14:28:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-01 14:28:53 --> Pixel_Model class loaded
INFO - 2018-10-01 14:28:53 --> Database Driver Class Initialized
INFO - 2018-10-01 14:28:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-01 14:28:53 --> Database Driver Class Initialized
INFO - 2018-10-01 14:28:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-01 14:28:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-01 14:28:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-01 14:28:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-01 14:28:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-01 14:28:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-01 14:28:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-01 14:28:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-10-01 14:28:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-01 14:28:53 --> Final output sent to browser
DEBUG - 2018-10-01 14:28:53 --> Total execution time: 0.0592
INFO - 2018-10-01 14:29:00 --> Config Class Initialized
INFO - 2018-10-01 14:29:00 --> Hooks Class Initialized
DEBUG - 2018-10-01 14:29:00 --> UTF-8 Support Enabled
INFO - 2018-10-01 14:29:00 --> Utf8 Class Initialized
INFO - 2018-10-01 14:29:00 --> URI Class Initialized
INFO - 2018-10-01 14:29:00 --> Router Class Initialized
INFO - 2018-10-01 14:29:00 --> Output Class Initialized
INFO - 2018-10-01 14:29:00 --> Security Class Initialized
DEBUG - 2018-10-01 14:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 14:29:00 --> CSRF cookie sent
INFO - 2018-10-01 14:29:00 --> CSRF token verified
INFO - 2018-10-01 14:29:00 --> Input Class Initialized
INFO - 2018-10-01 14:29:00 --> Language Class Initialized
INFO - 2018-10-01 14:29:00 --> Loader Class Initialized
INFO - 2018-10-01 14:29:00 --> Helper loaded: url_helper
INFO - 2018-10-01 14:29:00 --> Helper loaded: form_helper
INFO - 2018-10-01 14:29:00 --> Helper loaded: language_helper
DEBUG - 2018-10-01 14:29:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 14:29:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 14:29:00 --> User Agent Class Initialized
INFO - 2018-10-01 14:29:00 --> Controller Class Initialized
INFO - 2018-10-01 14:29:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-01 14:29:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-01 14:29:00 --> Pixel_Model class loaded
INFO - 2018-10-01 14:29:00 --> Database Driver Class Initialized
INFO - 2018-10-01 14:29:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-01 14:29:00 --> Form Validation Class Initialized
INFO - 2018-10-01 14:29:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-01 14:29:00 --> Database Driver Class Initialized
INFO - 2018-10-01 14:29:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-01 14:29:00 --> Config Class Initialized
INFO - 2018-10-01 14:29:00 --> Hooks Class Initialized
DEBUG - 2018-10-01 14:29:00 --> UTF-8 Support Enabled
INFO - 2018-10-01 14:29:00 --> Utf8 Class Initialized
INFO - 2018-10-01 14:29:00 --> URI Class Initialized
INFO - 2018-10-01 14:29:00 --> Router Class Initialized
INFO - 2018-10-01 14:29:00 --> Output Class Initialized
INFO - 2018-10-01 14:29:00 --> Security Class Initialized
DEBUG - 2018-10-01 14:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 14:29:00 --> CSRF cookie sent
INFO - 2018-10-01 14:29:00 --> Input Class Initialized
INFO - 2018-10-01 14:29:00 --> Language Class Initialized
INFO - 2018-10-01 14:29:00 --> Loader Class Initialized
INFO - 2018-10-01 14:29:00 --> Helper loaded: url_helper
INFO - 2018-10-01 14:29:00 --> Helper loaded: form_helper
INFO - 2018-10-01 14:29:00 --> Helper loaded: language_helper
DEBUG - 2018-10-01 14:29:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 14:29:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 14:29:00 --> User Agent Class Initialized
INFO - 2018-10-01 14:29:00 --> Controller Class Initialized
INFO - 2018-10-01 14:29:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-01 14:29:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-01 14:29:00 --> Pixel_Model class loaded
INFO - 2018-10-01 14:29:00 --> Database Driver Class Initialized
INFO - 2018-10-01 14:29:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-01 14:29:00 --> Database Driver Class Initialized
INFO - 2018-10-01 14:29:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-01 14:29:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-01 14:29:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-01 14:29:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-01 14:29:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-01 14:29:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-10-01 14:29:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-01 14:29:00 --> Final output sent to browser
DEBUG - 2018-10-01 14:29:00 --> Total execution time: 0.0393
INFO - 2018-10-01 14:29:12 --> Config Class Initialized
INFO - 2018-10-01 14:29:12 --> Hooks Class Initialized
DEBUG - 2018-10-01 14:29:12 --> UTF-8 Support Enabled
INFO - 2018-10-01 14:29:12 --> Utf8 Class Initialized
INFO - 2018-10-01 14:29:12 --> URI Class Initialized
INFO - 2018-10-01 14:29:12 --> Router Class Initialized
INFO - 2018-10-01 14:29:12 --> Output Class Initialized
INFO - 2018-10-01 14:29:12 --> Security Class Initialized
DEBUG - 2018-10-01 14:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 14:29:12 --> CSRF cookie sent
INFO - 2018-10-01 14:29:12 --> Input Class Initialized
INFO - 2018-10-01 14:29:12 --> Language Class Initialized
INFO - 2018-10-01 14:29:12 --> Loader Class Initialized
INFO - 2018-10-01 14:29:12 --> Helper loaded: url_helper
INFO - 2018-10-01 14:29:12 --> Helper loaded: form_helper
INFO - 2018-10-01 14:29:12 --> Helper loaded: language_helper
DEBUG - 2018-10-01 14:29:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 14:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 14:29:12 --> User Agent Class Initialized
INFO - 2018-10-01 14:29:12 --> Controller Class Initialized
INFO - 2018-10-01 14:29:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-01 14:29:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-01 14:29:12 --> Pixel_Model class loaded
INFO - 2018-10-01 14:29:12 --> Database Driver Class Initialized
INFO - 2018-10-01 14:29:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-01 14:29:12 --> Config Class Initialized
INFO - 2018-10-01 14:29:12 --> Hooks Class Initialized
DEBUG - 2018-10-01 14:29:12 --> UTF-8 Support Enabled
INFO - 2018-10-01 14:29:12 --> Utf8 Class Initialized
INFO - 2018-10-01 14:29:12 --> URI Class Initialized
INFO - 2018-10-01 14:29:12 --> Router Class Initialized
INFO - 2018-10-01 14:29:12 --> Output Class Initialized
INFO - 2018-10-01 14:29:12 --> Security Class Initialized
DEBUG - 2018-10-01 14:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 14:29:12 --> CSRF cookie sent
INFO - 2018-10-01 14:29:12 --> Input Class Initialized
INFO - 2018-10-01 14:29:12 --> Language Class Initialized
INFO - 2018-10-01 14:29:12 --> Loader Class Initialized
INFO - 2018-10-01 14:29:12 --> Helper loaded: url_helper
INFO - 2018-10-01 14:29:12 --> Helper loaded: form_helper
INFO - 2018-10-01 14:29:12 --> Helper loaded: language_helper
DEBUG - 2018-10-01 14:29:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 14:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 14:29:12 --> User Agent Class Initialized
INFO - 2018-10-01 14:29:12 --> Controller Class Initialized
INFO - 2018-10-01 14:29:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-01 14:29:12 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-01 14:29:12 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-10-01 14:29:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-01 14:29:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-01 14:29:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-01 14:29:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-10-01 14:29:12 --> Could not find the language line "req_email"
INFO - 2018-10-01 14:29:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-10-01 14:29:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-01 14:29:12 --> Final output sent to browser
DEBUG - 2018-10-01 14:29:12 --> Total execution time: 0.0234
INFO - 2018-10-01 17:42:58 --> Config Class Initialized
INFO - 2018-10-01 17:42:58 --> Hooks Class Initialized
DEBUG - 2018-10-01 17:42:58 --> UTF-8 Support Enabled
INFO - 2018-10-01 17:42:58 --> Utf8 Class Initialized
INFO - 2018-10-01 17:42:58 --> URI Class Initialized
DEBUG - 2018-10-01 17:42:58 --> No URI present. Default controller set.
INFO - 2018-10-01 17:42:58 --> Router Class Initialized
INFO - 2018-10-01 17:42:58 --> Output Class Initialized
INFO - 2018-10-01 17:42:58 --> Security Class Initialized
DEBUG - 2018-10-01 17:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 17:42:58 --> CSRF cookie sent
INFO - 2018-10-01 17:42:58 --> Input Class Initialized
INFO - 2018-10-01 17:42:58 --> Language Class Initialized
INFO - 2018-10-01 17:42:58 --> Loader Class Initialized
INFO - 2018-10-01 17:42:58 --> Helper loaded: url_helper
INFO - 2018-10-01 17:42:58 --> Helper loaded: form_helper
INFO - 2018-10-01 17:42:58 --> Helper loaded: language_helper
DEBUG - 2018-10-01 17:42:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 17:42:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 17:42:58 --> User Agent Class Initialized
INFO - 2018-10-01 17:42:58 --> Controller Class Initialized
INFO - 2018-10-01 17:42:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-01 17:42:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-01 17:42:58 --> Pixel_Model class loaded
INFO - 2018-10-01 17:42:58 --> Database Driver Class Initialized
INFO - 2018-10-01 17:42:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-01 17:42:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-01 17:42:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-01 17:42:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-01 17:42:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-01 17:42:58 --> Final output sent to browser
DEBUG - 2018-10-01 17:42:58 --> Total execution time: 0.0352
INFO - 2018-10-01 18:22:44 --> Config Class Initialized
INFO - 2018-10-01 18:22:44 --> Hooks Class Initialized
DEBUG - 2018-10-01 18:22:44 --> UTF-8 Support Enabled
INFO - 2018-10-01 18:22:44 --> Utf8 Class Initialized
INFO - 2018-10-01 18:22:44 --> URI Class Initialized
DEBUG - 2018-10-01 18:22:44 --> No URI present. Default controller set.
INFO - 2018-10-01 18:22:44 --> Router Class Initialized
INFO - 2018-10-01 18:22:44 --> Output Class Initialized
INFO - 2018-10-01 18:22:44 --> Security Class Initialized
DEBUG - 2018-10-01 18:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 18:22:44 --> CSRF cookie sent
INFO - 2018-10-01 18:22:44 --> Input Class Initialized
INFO - 2018-10-01 18:22:44 --> Language Class Initialized
INFO - 2018-10-01 18:22:44 --> Loader Class Initialized
INFO - 2018-10-01 18:22:44 --> Helper loaded: url_helper
INFO - 2018-10-01 18:22:44 --> Helper loaded: form_helper
INFO - 2018-10-01 18:22:44 --> Helper loaded: language_helper
DEBUG - 2018-10-01 18:22:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 18:22:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 18:22:44 --> User Agent Class Initialized
INFO - 2018-10-01 18:22:44 --> Controller Class Initialized
INFO - 2018-10-01 18:22:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-01 18:22:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-01 18:22:44 --> Pixel_Model class loaded
INFO - 2018-10-01 18:22:44 --> Database Driver Class Initialized
INFO - 2018-10-01 18:22:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-01 18:22:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-01 18:22:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-01 18:22:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-01 18:22:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-01 18:22:44 --> Final output sent to browser
DEBUG - 2018-10-01 18:22:44 --> Total execution time: 0.0451
INFO - 2018-10-01 18:22:45 --> Config Class Initialized
INFO - 2018-10-01 18:22:45 --> Hooks Class Initialized
DEBUG - 2018-10-01 18:22:45 --> UTF-8 Support Enabled
INFO - 2018-10-01 18:22:45 --> Utf8 Class Initialized
INFO - 2018-10-01 18:22:45 --> URI Class Initialized
DEBUG - 2018-10-01 18:22:45 --> No URI present. Default controller set.
INFO - 2018-10-01 18:22:45 --> Router Class Initialized
INFO - 2018-10-01 18:22:45 --> Output Class Initialized
INFO - 2018-10-01 18:22:45 --> Security Class Initialized
DEBUG - 2018-10-01 18:22:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 18:22:45 --> CSRF cookie sent
INFO - 2018-10-01 18:22:45 --> Input Class Initialized
INFO - 2018-10-01 18:22:45 --> Language Class Initialized
INFO - 2018-10-01 18:22:45 --> Loader Class Initialized
INFO - 2018-10-01 18:22:45 --> Helper loaded: url_helper
INFO - 2018-10-01 18:22:46 --> Helper loaded: form_helper
INFO - 2018-10-01 18:22:46 --> Helper loaded: language_helper
DEBUG - 2018-10-01 18:22:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 18:22:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 18:22:46 --> User Agent Class Initialized
INFO - 2018-10-01 18:22:46 --> Controller Class Initialized
INFO - 2018-10-01 18:22:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-01 18:22:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-01 18:22:46 --> Pixel_Model class loaded
INFO - 2018-10-01 18:22:46 --> Database Driver Class Initialized
INFO - 2018-10-01 18:22:46 --> Model "QuestionsModel" initialized
INFO - 2018-10-01 18:22:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-01 18:22:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-01 18:22:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-01 18:22:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-01 18:22:46 --> Final output sent to browser
DEBUG - 2018-10-01 18:22:46 --> Total execution time: 0.0336
INFO - 2018-10-01 18:22:52 --> Config Class Initialized
INFO - 2018-10-01 18:22:52 --> Hooks Class Initialized
DEBUG - 2018-10-01 18:22:52 --> UTF-8 Support Enabled
INFO - 2018-10-01 18:22:52 --> Utf8 Class Initialized
INFO - 2018-10-01 18:22:52 --> URI Class Initialized
INFO - 2018-10-01 18:22:52 --> Router Class Initialized
INFO - 2018-10-01 18:22:52 --> Output Class Initialized
INFO - 2018-10-01 18:22:52 --> Security Class Initialized
DEBUG - 2018-10-01 18:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 18:22:52 --> CSRF cookie sent
INFO - 2018-10-01 18:22:52 --> Input Class Initialized
INFO - 2018-10-01 18:22:52 --> Language Class Initialized
INFO - 2018-10-01 18:22:52 --> Loader Class Initialized
INFO - 2018-10-01 18:22:52 --> Helper loaded: url_helper
INFO - 2018-10-01 18:22:52 --> Helper loaded: form_helper
INFO - 2018-10-01 18:22:52 --> Helper loaded: language_helper
DEBUG - 2018-10-01 18:22:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 18:22:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 18:22:52 --> User Agent Class Initialized
INFO - 2018-10-01 18:22:52 --> Controller Class Initialized
INFO - 2018-10-01 18:22:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-01 18:22:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-01 18:22:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-01 18:22:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-01 18:22:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-01 18:22:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-01 18:22:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-10-01 18:22:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-01 18:22:52 --> Final output sent to browser
DEBUG - 2018-10-01 18:22:52 --> Total execution time: 0.0274
INFO - 2018-10-01 18:22:57 --> Config Class Initialized
INFO - 2018-10-01 18:22:57 --> Hooks Class Initialized
DEBUG - 2018-10-01 18:22:57 --> UTF-8 Support Enabled
INFO - 2018-10-01 18:22:57 --> Utf8 Class Initialized
INFO - 2018-10-01 18:22:57 --> URI Class Initialized
INFO - 2018-10-01 18:22:57 --> Router Class Initialized
INFO - 2018-10-01 18:22:57 --> Output Class Initialized
INFO - 2018-10-01 18:22:57 --> Security Class Initialized
DEBUG - 2018-10-01 18:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 18:22:57 --> CSRF cookie sent
INFO - 2018-10-01 18:22:57 --> Input Class Initialized
INFO - 2018-10-01 18:22:57 --> Language Class Initialized
INFO - 2018-10-01 18:22:57 --> Loader Class Initialized
INFO - 2018-10-01 18:22:57 --> Helper loaded: url_helper
INFO - 2018-10-01 18:22:57 --> Helper loaded: form_helper
INFO - 2018-10-01 18:22:57 --> Helper loaded: language_helper
DEBUG - 2018-10-01 18:22:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 18:22:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 18:22:57 --> User Agent Class Initialized
INFO - 2018-10-01 18:22:57 --> Controller Class Initialized
INFO - 2018-10-01 18:22:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-01 18:22:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-01 18:22:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-01 18:22:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-01 18:22:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-01 18:22:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-01 18:22:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/preview.php
INFO - 2018-10-01 18:22:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-01 18:22:57 --> Final output sent to browser
DEBUG - 2018-10-01 18:22:57 --> Total execution time: 0.0394
INFO - 2018-10-01 18:23:03 --> Config Class Initialized
INFO - 2018-10-01 18:23:03 --> Hooks Class Initialized
DEBUG - 2018-10-01 18:23:03 --> UTF-8 Support Enabled
INFO - 2018-10-01 18:23:03 --> Utf8 Class Initialized
INFO - 2018-10-01 18:23:03 --> URI Class Initialized
INFO - 2018-10-01 18:23:03 --> Router Class Initialized
INFO - 2018-10-01 18:23:03 --> Output Class Initialized
INFO - 2018-10-01 18:23:03 --> Security Class Initialized
DEBUG - 2018-10-01 18:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 18:23:03 --> CSRF cookie sent
INFO - 2018-10-01 18:23:03 --> Input Class Initialized
INFO - 2018-10-01 18:23:03 --> Language Class Initialized
INFO - 2018-10-01 18:23:03 --> Loader Class Initialized
INFO - 2018-10-01 18:23:03 --> Helper loaded: url_helper
INFO - 2018-10-01 18:23:03 --> Helper loaded: form_helper
INFO - 2018-10-01 18:23:03 --> Helper loaded: language_helper
DEBUG - 2018-10-01 18:23:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 18:23:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 18:23:03 --> User Agent Class Initialized
INFO - 2018-10-01 18:23:03 --> Controller Class Initialized
INFO - 2018-10-01 18:23:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-01 18:23:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-01 18:23:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-01 18:23:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-01 18:23:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-01 18:23:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-01 18:23:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-10-01 18:23:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-01 18:23:03 --> Final output sent to browser
DEBUG - 2018-10-01 18:23:03 --> Total execution time: 0.0224
INFO - 2018-10-01 18:23:04 --> Config Class Initialized
INFO - 2018-10-01 18:23:04 --> Hooks Class Initialized
DEBUG - 2018-10-01 18:23:04 --> UTF-8 Support Enabled
INFO - 2018-10-01 18:23:04 --> Utf8 Class Initialized
INFO - 2018-10-01 18:23:04 --> URI Class Initialized
INFO - 2018-10-01 18:23:04 --> Router Class Initialized
INFO - 2018-10-01 18:23:04 --> Output Class Initialized
INFO - 2018-10-01 18:23:04 --> Security Class Initialized
DEBUG - 2018-10-01 18:23:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 18:23:04 --> CSRF cookie sent
INFO - 2018-10-01 18:23:04 --> Input Class Initialized
INFO - 2018-10-01 18:23:04 --> Language Class Initialized
ERROR - 2018-10-01 18:23:04 --> 404 Page Not Found: Faviconico/index
INFO - 2018-10-01 18:23:08 --> Config Class Initialized
INFO - 2018-10-01 18:23:08 --> Hooks Class Initialized
DEBUG - 2018-10-01 18:23:08 --> UTF-8 Support Enabled
INFO - 2018-10-01 18:23:08 --> Utf8 Class Initialized
INFO - 2018-10-01 18:23:08 --> URI Class Initialized
INFO - 2018-10-01 18:23:08 --> Router Class Initialized
INFO - 2018-10-01 18:23:08 --> Output Class Initialized
INFO - 2018-10-01 18:23:08 --> Security Class Initialized
DEBUG - 2018-10-01 18:23:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 18:23:08 --> CSRF cookie sent
INFO - 2018-10-01 18:23:08 --> Input Class Initialized
INFO - 2018-10-01 18:23:08 --> Language Class Initialized
INFO - 2018-10-01 18:23:08 --> Loader Class Initialized
INFO - 2018-10-01 18:23:08 --> Helper loaded: url_helper
INFO - 2018-10-01 18:23:08 --> Helper loaded: form_helper
INFO - 2018-10-01 18:23:08 --> Helper loaded: language_helper
DEBUG - 2018-10-01 18:23:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 18:23:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 18:23:08 --> User Agent Class Initialized
INFO - 2018-10-01 18:23:08 --> Controller Class Initialized
INFO - 2018-10-01 18:23:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-01 18:23:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-01 18:23:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-01 18:23:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-01 18:23:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-01 18:23:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-01 18:23:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-10-01 18:23:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-01 18:23:08 --> Final output sent to browser
DEBUG - 2018-10-01 18:23:08 --> Total execution time: 0.0257
INFO - 2018-10-01 18:23:09 --> Config Class Initialized
INFO - 2018-10-01 18:23:09 --> Hooks Class Initialized
DEBUG - 2018-10-01 18:23:09 --> UTF-8 Support Enabled
INFO - 2018-10-01 18:23:09 --> Utf8 Class Initialized
INFO - 2018-10-01 18:23:09 --> URI Class Initialized
INFO - 2018-10-01 18:23:09 --> Router Class Initialized
INFO - 2018-10-01 18:23:09 --> Output Class Initialized
INFO - 2018-10-01 18:23:09 --> Security Class Initialized
DEBUG - 2018-10-01 18:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 18:23:09 --> CSRF cookie sent
INFO - 2018-10-01 18:23:09 --> Input Class Initialized
INFO - 2018-10-01 18:23:09 --> Language Class Initialized
INFO - 2018-10-01 18:23:09 --> Loader Class Initialized
INFO - 2018-10-01 18:23:09 --> Helper loaded: url_helper
INFO - 2018-10-01 18:23:09 --> Helper loaded: form_helper
INFO - 2018-10-01 18:23:09 --> Helper loaded: language_helper
DEBUG - 2018-10-01 18:23:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 18:23:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 18:23:09 --> User Agent Class Initialized
INFO - 2018-10-01 18:23:09 --> Controller Class Initialized
INFO - 2018-10-01 18:23:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-01 18:23:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-01 18:23:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-01 18:23:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-01 18:23:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-01 18:23:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-01 18:23:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/faqs.php
INFO - 2018-10-01 18:23:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-01 18:23:09 --> Final output sent to browser
DEBUG - 2018-10-01 18:23:09 --> Total execution time: 0.0425
INFO - 2018-10-01 18:27:09 --> Config Class Initialized
INFO - 2018-10-01 18:27:09 --> Hooks Class Initialized
DEBUG - 2018-10-01 18:27:09 --> UTF-8 Support Enabled
INFO - 2018-10-01 18:27:09 --> Utf8 Class Initialized
INFO - 2018-10-01 18:27:09 --> URI Class Initialized
INFO - 2018-10-01 18:27:09 --> Router Class Initialized
INFO - 2018-10-01 18:27:09 --> Output Class Initialized
INFO - 2018-10-01 18:27:09 --> Security Class Initialized
DEBUG - 2018-10-01 18:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 18:27:09 --> CSRF cookie sent
INFO - 2018-10-01 18:27:09 --> Input Class Initialized
INFO - 2018-10-01 18:27:09 --> Language Class Initialized
INFO - 2018-10-01 18:27:09 --> Loader Class Initialized
INFO - 2018-10-01 18:27:09 --> Helper loaded: url_helper
INFO - 2018-10-01 18:27:09 --> Helper loaded: form_helper
INFO - 2018-10-01 18:27:09 --> Helper loaded: language_helper
DEBUG - 2018-10-01 18:27:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 18:27:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 18:27:09 --> User Agent Class Initialized
INFO - 2018-10-01 18:27:09 --> Controller Class Initialized
INFO - 2018-10-01 18:27:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-01 18:27:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-01 18:27:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-01 18:27:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-01 18:27:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-01 18:27:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-01 18:27:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-10-01 18:27:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-01 18:27:09 --> Final output sent to browser
DEBUG - 2018-10-01 18:27:09 --> Total execution time: 0.0362
INFO - 2018-10-01 18:27:11 --> Config Class Initialized
INFO - 2018-10-01 18:27:11 --> Hooks Class Initialized
DEBUG - 2018-10-01 18:27:11 --> UTF-8 Support Enabled
INFO - 2018-10-01 18:27:11 --> Utf8 Class Initialized
INFO - 2018-10-01 18:27:11 --> URI Class Initialized
INFO - 2018-10-01 18:27:11 --> Router Class Initialized
INFO - 2018-10-01 18:27:11 --> Output Class Initialized
INFO - 2018-10-01 18:27:11 --> Security Class Initialized
DEBUG - 2018-10-01 18:27:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 18:27:11 --> CSRF cookie sent
INFO - 2018-10-01 18:27:11 --> Input Class Initialized
INFO - 2018-10-01 18:27:11 --> Language Class Initialized
INFO - 2018-10-01 18:27:11 --> Loader Class Initialized
INFO - 2018-10-01 18:27:11 --> Helper loaded: url_helper
INFO - 2018-10-01 18:27:11 --> Helper loaded: form_helper
INFO - 2018-10-01 18:27:11 --> Helper loaded: language_helper
DEBUG - 2018-10-01 18:27:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 18:27:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 18:27:11 --> User Agent Class Initialized
INFO - 2018-10-01 18:27:11 --> Controller Class Initialized
INFO - 2018-10-01 18:27:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-01 18:27:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-01 18:27:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-01 18:27:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-01 18:27:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-01 18:27:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-01 18:27:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/faq_lawyer.php
INFO - 2018-10-01 18:27:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-01 18:27:11 --> Final output sent to browser
DEBUG - 2018-10-01 18:27:11 --> Total execution time: 0.0510
INFO - 2018-10-01 18:34:53 --> Config Class Initialized
INFO - 2018-10-01 18:34:53 --> Hooks Class Initialized
DEBUG - 2018-10-01 18:34:53 --> UTF-8 Support Enabled
INFO - 2018-10-01 18:34:53 --> Utf8 Class Initialized
INFO - 2018-10-01 18:34:53 --> URI Class Initialized
INFO - 2018-10-01 18:34:53 --> Router Class Initialized
INFO - 2018-10-01 18:34:53 --> Output Class Initialized
INFO - 2018-10-01 18:34:53 --> Security Class Initialized
DEBUG - 2018-10-01 18:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 18:34:53 --> CSRF cookie sent
INFO - 2018-10-01 18:34:53 --> Input Class Initialized
INFO - 2018-10-01 18:34:53 --> Language Class Initialized
INFO - 2018-10-01 18:34:53 --> Loader Class Initialized
INFO - 2018-10-01 18:34:53 --> Helper loaded: url_helper
INFO - 2018-10-01 18:34:53 --> Helper loaded: form_helper
INFO - 2018-10-01 18:34:53 --> Helper loaded: language_helper
DEBUG - 2018-10-01 18:34:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 18:34:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 18:34:53 --> User Agent Class Initialized
INFO - 2018-10-01 18:34:53 --> Controller Class Initialized
INFO - 2018-10-01 18:34:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-01 18:34:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-01 18:34:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-01 18:34:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-01 18:34:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-01 18:34:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-01 18:34:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-10-01 18:34:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-01 18:34:53 --> Final output sent to browser
DEBUG - 2018-10-01 18:34:53 --> Total execution time: 0.0219
INFO - 2018-10-01 18:34:56 --> Config Class Initialized
INFO - 2018-10-01 18:34:56 --> Hooks Class Initialized
DEBUG - 2018-10-01 18:34:56 --> UTF-8 Support Enabled
INFO - 2018-10-01 18:34:56 --> Utf8 Class Initialized
INFO - 2018-10-01 18:34:56 --> URI Class Initialized
INFO - 2018-10-01 18:34:56 --> Router Class Initialized
INFO - 2018-10-01 18:34:56 --> Output Class Initialized
INFO - 2018-10-01 18:34:56 --> Security Class Initialized
DEBUG - 2018-10-01 18:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 18:34:56 --> CSRF cookie sent
INFO - 2018-10-01 18:34:56 --> Input Class Initialized
INFO - 2018-10-01 18:34:56 --> Language Class Initialized
INFO - 2018-10-01 18:34:56 --> Loader Class Initialized
INFO - 2018-10-01 18:34:56 --> Helper loaded: url_helper
INFO - 2018-10-01 18:34:56 --> Helper loaded: form_helper
INFO - 2018-10-01 18:34:56 --> Helper loaded: language_helper
DEBUG - 2018-10-01 18:34:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 18:34:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 18:34:56 --> User Agent Class Initialized
INFO - 2018-10-01 18:34:56 --> Controller Class Initialized
INFO - 2018-10-01 18:34:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-01 18:34:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-01 18:34:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-01 18:34:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-01 18:34:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-01 18:34:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-01 18:34:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/911.php
INFO - 2018-10-01 18:34:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-01 18:34:56 --> Final output sent to browser
DEBUG - 2018-10-01 18:34:56 --> Total execution time: 0.0266

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-10-02 12:47:39 --> Config Class Initialized
INFO - 2018-10-02 12:47:39 --> Hooks Class Initialized
DEBUG - 2018-10-02 12:47:39 --> UTF-8 Support Enabled
INFO - 2018-10-02 12:47:39 --> Utf8 Class Initialized
INFO - 2018-10-02 12:47:39 --> URI Class Initialized
DEBUG - 2018-10-02 12:47:39 --> No URI present. Default controller set.
INFO - 2018-10-02 12:47:39 --> Router Class Initialized
INFO - 2018-10-02 12:47:39 --> Output Class Initialized
INFO - 2018-10-02 12:47:39 --> Security Class Initialized
DEBUG - 2018-10-02 12:47:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 12:47:39 --> CSRF cookie sent
INFO - 2018-10-02 12:47:39 --> Input Class Initialized
INFO - 2018-10-02 12:47:39 --> Language Class Initialized
INFO - 2018-10-02 12:47:39 --> Loader Class Initialized
INFO - 2018-10-02 12:47:39 --> Helper loaded: url_helper
INFO - 2018-10-02 12:47:40 --> Helper loaded: form_helper
INFO - 2018-10-02 12:47:40 --> Helper loaded: language_helper
DEBUG - 2018-10-02 12:47:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 12:47:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 12:47:40 --> User Agent Class Initialized
INFO - 2018-10-02 12:47:40 --> Controller Class Initialized
INFO - 2018-10-02 12:47:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-02 12:47:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-02 12:47:40 --> Pixel_Model class loaded
INFO - 2018-10-02 12:47:40 --> Database Driver Class Initialized
INFO - 2018-10-02 12:47:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-02 12:47:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-02 12:47:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-02 12:47:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-02 12:47:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-02 12:47:40 --> Final output sent to browser
DEBUG - 2018-10-02 12:47:40 --> Total execution time: 0.0391
INFO - 2018-10-02 12:47:49 --> Config Class Initialized
INFO - 2018-10-02 12:47:49 --> Hooks Class Initialized
DEBUG - 2018-10-02 12:47:49 --> UTF-8 Support Enabled
INFO - 2018-10-02 12:47:49 --> Utf8 Class Initialized
INFO - 2018-10-02 12:47:49 --> URI Class Initialized
INFO - 2018-10-02 12:47:49 --> Router Class Initialized
INFO - 2018-10-02 12:47:49 --> Output Class Initialized
INFO - 2018-10-02 12:47:49 --> Security Class Initialized
DEBUG - 2018-10-02 12:47:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 12:47:49 --> CSRF cookie sent
INFO - 2018-10-02 12:47:49 --> Input Class Initialized
INFO - 2018-10-02 12:47:49 --> Language Class Initialized
INFO - 2018-10-02 12:47:49 --> Loader Class Initialized
INFO - 2018-10-02 12:47:49 --> Helper loaded: url_helper
INFO - 2018-10-02 12:47:49 --> Helper loaded: form_helper
INFO - 2018-10-02 12:47:49 --> Helper loaded: language_helper
DEBUG - 2018-10-02 12:47:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 12:47:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 12:47:49 --> User Agent Class Initialized
INFO - 2018-10-02 12:47:49 --> Controller Class Initialized
INFO - 2018-10-02 12:47:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-02 12:47:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-02 12:47:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-02 12:47:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-02 12:47:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-02 12:47:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-02 12:47:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/professions.php
INFO - 2018-10-02 12:47:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-02 12:47:49 --> Final output sent to browser
DEBUG - 2018-10-02 12:47:49 --> Total execution time: 0.0238
INFO - 2018-10-02 12:47:54 --> Config Class Initialized
INFO - 2018-10-02 12:47:54 --> Hooks Class Initialized
DEBUG - 2018-10-02 12:47:54 --> UTF-8 Support Enabled
INFO - 2018-10-02 12:47:54 --> Utf8 Class Initialized
INFO - 2018-10-02 12:47:54 --> URI Class Initialized
INFO - 2018-10-02 12:47:54 --> Router Class Initialized
INFO - 2018-10-02 12:47:54 --> Output Class Initialized
INFO - 2018-10-02 12:47:54 --> Security Class Initialized
DEBUG - 2018-10-02 12:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 12:47:54 --> CSRF cookie sent
INFO - 2018-10-02 12:47:54 --> Input Class Initialized
INFO - 2018-10-02 12:47:54 --> Language Class Initialized
INFO - 2018-10-02 12:47:54 --> Loader Class Initialized
INFO - 2018-10-02 12:47:54 --> Helper loaded: url_helper
INFO - 2018-10-02 12:47:54 --> Helper loaded: form_helper
INFO - 2018-10-02 12:47:54 --> Helper loaded: language_helper
DEBUG - 2018-10-02 12:47:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 12:47:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 12:47:54 --> User Agent Class Initialized
INFO - 2018-10-02 12:47:54 --> Controller Class Initialized
INFO - 2018-10-02 12:47:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-02 12:47:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-02 12:47:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-02 12:47:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-02 12:47:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-02 12:47:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-02 12:47:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-10-02 12:47:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-02 12:47:54 --> Final output sent to browser
DEBUG - 2018-10-02 12:47:54 --> Total execution time: 0.0232
INFO - 2018-10-02 12:47:56 --> Config Class Initialized
INFO - 2018-10-02 12:47:56 --> Hooks Class Initialized
DEBUG - 2018-10-02 12:47:56 --> UTF-8 Support Enabled
INFO - 2018-10-02 12:47:56 --> Utf8 Class Initialized
INFO - 2018-10-02 12:47:56 --> URI Class Initialized
INFO - 2018-10-02 12:47:56 --> Router Class Initialized
INFO - 2018-10-02 12:47:56 --> Output Class Initialized
INFO - 2018-10-02 12:47:56 --> Security Class Initialized
DEBUG - 2018-10-02 12:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 12:47:56 --> CSRF cookie sent
INFO - 2018-10-02 12:47:56 --> Input Class Initialized
INFO - 2018-10-02 12:47:56 --> Language Class Initialized
INFO - 2018-10-02 12:47:56 --> Loader Class Initialized
INFO - 2018-10-02 12:47:56 --> Helper loaded: url_helper
INFO - 2018-10-02 12:47:56 --> Helper loaded: form_helper
INFO - 2018-10-02 12:47:56 --> Helper loaded: language_helper
DEBUG - 2018-10-02 12:47:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 12:47:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 12:47:56 --> User Agent Class Initialized
INFO - 2018-10-02 12:47:56 --> Controller Class Initialized
INFO - 2018-10-02 12:47:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-02 12:47:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-02 12:47:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-02 12:47:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-02 12:47:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-02 12:47:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-02 12:47:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/faq_lawyer.php
INFO - 2018-10-02 12:47:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-02 12:47:56 --> Final output sent to browser
DEBUG - 2018-10-02 12:47:56 --> Total execution time: 0.0216
INFO - 2018-10-02 12:48:30 --> Config Class Initialized
INFO - 2018-10-02 12:48:30 --> Hooks Class Initialized
DEBUG - 2018-10-02 12:48:30 --> UTF-8 Support Enabled
INFO - 2018-10-02 12:48:30 --> Utf8 Class Initialized
INFO - 2018-10-02 12:48:30 --> URI Class Initialized
INFO - 2018-10-02 12:48:30 --> Router Class Initialized
INFO - 2018-10-02 12:48:30 --> Output Class Initialized
INFO - 2018-10-02 12:48:30 --> Security Class Initialized
DEBUG - 2018-10-02 12:48:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 12:48:30 --> CSRF cookie sent
INFO - 2018-10-02 12:48:30 --> Input Class Initialized
INFO - 2018-10-02 12:48:30 --> Language Class Initialized
INFO - 2018-10-02 12:48:30 --> Loader Class Initialized
INFO - 2018-10-02 12:48:30 --> Helper loaded: url_helper
INFO - 2018-10-02 12:48:30 --> Helper loaded: form_helper
INFO - 2018-10-02 12:48:30 --> Helper loaded: language_helper
DEBUG - 2018-10-02 12:48:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 12:48:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 12:48:30 --> User Agent Class Initialized
INFO - 2018-10-02 12:48:30 --> Controller Class Initialized
INFO - 2018-10-02 12:48:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-02 12:48:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-02 12:48:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-02 12:48:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-02 12:48:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-02 12:48:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-02 12:48:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/faqs.php
INFO - 2018-10-02 12:48:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-02 12:48:30 --> Final output sent to browser
DEBUG - 2018-10-02 12:48:30 --> Total execution time: 0.0226
INFO - 2018-10-02 12:49:30 --> Config Class Initialized
INFO - 2018-10-02 12:49:30 --> Hooks Class Initialized
DEBUG - 2018-10-02 12:49:30 --> UTF-8 Support Enabled
INFO - 2018-10-02 12:49:30 --> Utf8 Class Initialized
INFO - 2018-10-02 12:49:30 --> URI Class Initialized
INFO - 2018-10-02 12:49:30 --> Router Class Initialized
INFO - 2018-10-02 12:49:30 --> Output Class Initialized
INFO - 2018-10-02 12:49:30 --> Security Class Initialized
DEBUG - 2018-10-02 12:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 12:49:30 --> CSRF cookie sent
INFO - 2018-10-02 12:49:30 --> Input Class Initialized
INFO - 2018-10-02 12:49:30 --> Language Class Initialized
INFO - 2018-10-02 12:49:30 --> Loader Class Initialized
INFO - 2018-10-02 12:49:30 --> Helper loaded: url_helper
INFO - 2018-10-02 12:49:30 --> Helper loaded: form_helper
INFO - 2018-10-02 12:49:30 --> Helper loaded: language_helper
DEBUG - 2018-10-02 12:49:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 12:49:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 12:49:30 --> User Agent Class Initialized
INFO - 2018-10-02 12:49:30 --> Controller Class Initialized
INFO - 2018-10-02 12:49:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-02 12:49:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-02 12:49:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-02 12:49:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-02 12:49:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-02 12:49:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-02 12:49:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-10-02 12:49:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-02 12:49:30 --> Final output sent to browser
DEBUG - 2018-10-02 12:49:30 --> Total execution time: 0.0238
INFO - 2018-10-02 12:49:33 --> Config Class Initialized
INFO - 2018-10-02 12:49:33 --> Hooks Class Initialized
DEBUG - 2018-10-02 12:49:33 --> UTF-8 Support Enabled
INFO - 2018-10-02 12:49:33 --> Utf8 Class Initialized
INFO - 2018-10-02 12:49:33 --> URI Class Initialized
INFO - 2018-10-02 12:49:33 --> Router Class Initialized
INFO - 2018-10-02 12:49:33 --> Output Class Initialized
INFO - 2018-10-02 12:49:33 --> Security Class Initialized
DEBUG - 2018-10-02 12:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 12:49:33 --> CSRF cookie sent
INFO - 2018-10-02 12:49:33 --> Input Class Initialized
INFO - 2018-10-02 12:49:33 --> Language Class Initialized
INFO - 2018-10-02 12:49:33 --> Loader Class Initialized
INFO - 2018-10-02 12:49:33 --> Helper loaded: url_helper
INFO - 2018-10-02 12:49:33 --> Helper loaded: form_helper
INFO - 2018-10-02 12:49:33 --> Helper loaded: language_helper
DEBUG - 2018-10-02 12:49:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 12:49:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 12:49:33 --> User Agent Class Initialized
INFO - 2018-10-02 12:49:33 --> Controller Class Initialized
INFO - 2018-10-02 12:49:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-02 12:49:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-02 12:49:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-02 12:49:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-02 12:49:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-02 12:49:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-02 12:49:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/faq_lawyer.php
INFO - 2018-10-02 12:49:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-02 12:49:33 --> Final output sent to browser
DEBUG - 2018-10-02 12:49:33 --> Total execution time: 0.0221
INFO - 2018-10-02 13:24:08 --> Config Class Initialized
INFO - 2018-10-02 13:24:08 --> Hooks Class Initialized
DEBUG - 2018-10-02 13:24:08 --> UTF-8 Support Enabled
INFO - 2018-10-02 13:24:08 --> Utf8 Class Initialized
INFO - 2018-10-02 13:24:08 --> URI Class Initialized
DEBUG - 2018-10-02 13:24:08 --> No URI present. Default controller set.
INFO - 2018-10-02 13:24:08 --> Router Class Initialized
INFO - 2018-10-02 13:24:08 --> Output Class Initialized
INFO - 2018-10-02 13:24:08 --> Security Class Initialized
DEBUG - 2018-10-02 13:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 13:24:08 --> CSRF cookie sent
INFO - 2018-10-02 13:24:08 --> Input Class Initialized
INFO - 2018-10-02 13:24:08 --> Language Class Initialized
INFO - 2018-10-02 13:24:08 --> Loader Class Initialized
INFO - 2018-10-02 13:24:08 --> Helper loaded: url_helper
INFO - 2018-10-02 13:24:08 --> Helper loaded: form_helper
INFO - 2018-10-02 13:24:08 --> Helper loaded: language_helper
DEBUG - 2018-10-02 13:24:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 13:24:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 13:24:08 --> User Agent Class Initialized
INFO - 2018-10-02 13:24:08 --> Controller Class Initialized
INFO - 2018-10-02 13:24:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-02 13:24:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-02 13:24:08 --> Pixel_Model class loaded
INFO - 2018-10-02 13:24:08 --> Database Driver Class Initialized
INFO - 2018-10-02 13:24:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-02 13:24:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-02 13:24:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-02 13:24:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-02 13:24:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-02 13:24:08 --> Final output sent to browser
DEBUG - 2018-10-02 13:24:08 --> Total execution time: 0.0361
INFO - 2018-10-02 13:24:09 --> Config Class Initialized
INFO - 2018-10-02 13:24:09 --> Hooks Class Initialized
DEBUG - 2018-10-02 13:24:09 --> UTF-8 Support Enabled
INFO - 2018-10-02 13:24:09 --> Utf8 Class Initialized
INFO - 2018-10-02 13:24:09 --> URI Class Initialized
DEBUG - 2018-10-02 13:24:09 --> No URI present. Default controller set.
INFO - 2018-10-02 13:24:09 --> Router Class Initialized
INFO - 2018-10-02 13:24:09 --> Output Class Initialized
INFO - 2018-10-02 13:24:09 --> Security Class Initialized
DEBUG - 2018-10-02 13:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 13:24:09 --> CSRF cookie sent
INFO - 2018-10-02 13:24:09 --> Input Class Initialized
INFO - 2018-10-02 13:24:09 --> Language Class Initialized
INFO - 2018-10-02 13:24:09 --> Loader Class Initialized
INFO - 2018-10-02 13:24:09 --> Helper loaded: url_helper
INFO - 2018-10-02 13:24:09 --> Helper loaded: form_helper
INFO - 2018-10-02 13:24:09 --> Helper loaded: language_helper
DEBUG - 2018-10-02 13:24:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 13:24:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 13:24:09 --> User Agent Class Initialized
INFO - 2018-10-02 13:24:09 --> Controller Class Initialized
INFO - 2018-10-02 13:24:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-02 13:24:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-02 13:24:09 --> Pixel_Model class loaded
INFO - 2018-10-02 13:24:09 --> Database Driver Class Initialized
INFO - 2018-10-02 13:24:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-02 13:24:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-02 13:24:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-02 13:24:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-02 13:24:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-02 13:24:09 --> Final output sent to browser
DEBUG - 2018-10-02 13:24:09 --> Total execution time: 0.0391
INFO - 2018-10-02 13:24:11 --> Config Class Initialized
INFO - 2018-10-02 13:24:11 --> Hooks Class Initialized
DEBUG - 2018-10-02 13:24:11 --> UTF-8 Support Enabled
INFO - 2018-10-02 13:24:11 --> Utf8 Class Initialized
INFO - 2018-10-02 13:24:11 --> URI Class Initialized
INFO - 2018-10-02 13:24:11 --> Router Class Initialized
INFO - 2018-10-02 13:24:11 --> Output Class Initialized
INFO - 2018-10-02 13:24:11 --> Security Class Initialized
DEBUG - 2018-10-02 13:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 13:24:11 --> CSRF cookie sent
INFO - 2018-10-02 13:24:11 --> Input Class Initialized
INFO - 2018-10-02 13:24:11 --> Language Class Initialized
INFO - 2018-10-02 13:24:11 --> Loader Class Initialized
INFO - 2018-10-02 13:24:11 --> Helper loaded: url_helper
INFO - 2018-10-02 13:24:11 --> Helper loaded: form_helper
INFO - 2018-10-02 13:24:11 --> Helper loaded: language_helper
DEBUG - 2018-10-02 13:24:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 13:24:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 13:24:11 --> User Agent Class Initialized
INFO - 2018-10-02 13:24:11 --> Controller Class Initialized
INFO - 2018-10-02 13:24:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-02 13:24:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-02 13:24:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-02 13:24:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-02 13:24:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-02 13:24:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-02 13:24:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-10-02 13:24:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-02 13:24:11 --> Final output sent to browser
DEBUG - 2018-10-02 13:24:11 --> Total execution time: 0.0270
INFO - 2018-10-02 13:24:14 --> Config Class Initialized
INFO - 2018-10-02 13:24:14 --> Hooks Class Initialized
DEBUG - 2018-10-02 13:24:14 --> UTF-8 Support Enabled
INFO - 2018-10-02 13:24:14 --> Utf8 Class Initialized
INFO - 2018-10-02 13:24:14 --> URI Class Initialized
INFO - 2018-10-02 13:24:14 --> Router Class Initialized
INFO - 2018-10-02 13:24:14 --> Output Class Initialized
INFO - 2018-10-02 13:24:14 --> Security Class Initialized
DEBUG - 2018-10-02 13:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 13:24:14 --> CSRF cookie sent
INFO - 2018-10-02 13:24:14 --> Input Class Initialized
INFO - 2018-10-02 13:24:14 --> Language Class Initialized
INFO - 2018-10-02 13:24:14 --> Loader Class Initialized
INFO - 2018-10-02 13:24:14 --> Helper loaded: url_helper
INFO - 2018-10-02 13:24:14 --> Helper loaded: form_helper
INFO - 2018-10-02 13:24:14 --> Helper loaded: language_helper
DEBUG - 2018-10-02 13:24:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 13:24:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 13:24:14 --> User Agent Class Initialized
INFO - 2018-10-02 13:24:14 --> Controller Class Initialized
INFO - 2018-10-02 13:24:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-02 13:24:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-02 13:24:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-02 13:24:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-02 13:24:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-02 13:24:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-02 13:24:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/faqs.php
INFO - 2018-10-02 13:24:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-02 13:24:14 --> Final output sent to browser
DEBUG - 2018-10-02 13:24:14 --> Total execution time: 0.0348
INFO - 2018-10-02 13:26:28 --> Config Class Initialized
INFO - 2018-10-02 13:26:28 --> Hooks Class Initialized
DEBUG - 2018-10-02 13:26:28 --> UTF-8 Support Enabled
INFO - 2018-10-02 13:26:28 --> Utf8 Class Initialized
INFO - 2018-10-02 13:26:28 --> URI Class Initialized
DEBUG - 2018-10-02 13:26:28 --> No URI present. Default controller set.
INFO - 2018-10-02 13:26:28 --> Router Class Initialized
INFO - 2018-10-02 13:26:28 --> Output Class Initialized
INFO - 2018-10-02 13:26:28 --> Security Class Initialized
DEBUG - 2018-10-02 13:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 13:26:28 --> CSRF cookie sent
INFO - 2018-10-02 13:26:28 --> Input Class Initialized
INFO - 2018-10-02 13:26:28 --> Language Class Initialized
INFO - 2018-10-02 13:26:28 --> Loader Class Initialized
INFO - 2018-10-02 13:26:28 --> Helper loaded: url_helper
INFO - 2018-10-02 13:26:28 --> Helper loaded: form_helper
INFO - 2018-10-02 13:26:28 --> Helper loaded: language_helper
DEBUG - 2018-10-02 13:26:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 13:26:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 13:26:28 --> User Agent Class Initialized
INFO - 2018-10-02 13:26:28 --> Controller Class Initialized
INFO - 2018-10-02 13:26:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-02 13:26:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-02 13:26:28 --> Pixel_Model class loaded
INFO - 2018-10-02 13:26:28 --> Database Driver Class Initialized
INFO - 2018-10-02 13:26:28 --> Model "QuestionsModel" initialized
INFO - 2018-10-02 13:26:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-02 13:26:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-02 13:26:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-02 13:26:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-02 13:26:28 --> Final output sent to browser
DEBUG - 2018-10-02 13:26:28 --> Total execution time: 0.0393
INFO - 2018-10-02 13:26:30 --> Config Class Initialized
INFO - 2018-10-02 13:26:30 --> Hooks Class Initialized
DEBUG - 2018-10-02 13:26:30 --> UTF-8 Support Enabled
INFO - 2018-10-02 13:26:30 --> Utf8 Class Initialized
INFO - 2018-10-02 13:26:30 --> URI Class Initialized
DEBUG - 2018-10-02 13:26:30 --> No URI present. Default controller set.
INFO - 2018-10-02 13:26:30 --> Router Class Initialized
INFO - 2018-10-02 13:26:30 --> Output Class Initialized
INFO - 2018-10-02 13:26:30 --> Security Class Initialized
DEBUG - 2018-10-02 13:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 13:26:30 --> CSRF cookie sent
INFO - 2018-10-02 13:26:30 --> Input Class Initialized
INFO - 2018-10-02 13:26:30 --> Language Class Initialized
INFO - 2018-10-02 13:26:30 --> Loader Class Initialized
INFO - 2018-10-02 13:26:30 --> Helper loaded: url_helper
INFO - 2018-10-02 13:26:30 --> Helper loaded: form_helper
INFO - 2018-10-02 13:26:30 --> Helper loaded: language_helper
DEBUG - 2018-10-02 13:26:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 13:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 13:26:30 --> User Agent Class Initialized
INFO - 2018-10-02 13:26:30 --> Controller Class Initialized
INFO - 2018-10-02 13:26:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-02 13:26:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-02 13:26:30 --> Pixel_Model class loaded
INFO - 2018-10-02 13:26:30 --> Database Driver Class Initialized
INFO - 2018-10-02 13:26:30 --> Model "QuestionsModel" initialized
INFO - 2018-10-02 13:26:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-02 13:26:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-02 13:26:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-02 13:26:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-02 13:26:30 --> Final output sent to browser
DEBUG - 2018-10-02 13:26:30 --> Total execution time: 0.0387
INFO - 2018-10-02 13:38:52 --> Config Class Initialized
INFO - 2018-10-02 13:38:52 --> Hooks Class Initialized
DEBUG - 2018-10-02 13:38:52 --> UTF-8 Support Enabled
INFO - 2018-10-02 13:38:52 --> Utf8 Class Initialized
INFO - 2018-10-02 13:38:52 --> URI Class Initialized
INFO - 2018-10-02 13:38:52 --> Router Class Initialized
INFO - 2018-10-02 13:38:52 --> Output Class Initialized
INFO - 2018-10-02 13:38:52 --> Security Class Initialized
DEBUG - 2018-10-02 13:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 13:38:52 --> CSRF cookie sent
INFO - 2018-10-02 13:38:52 --> Input Class Initialized
INFO - 2018-10-02 13:38:52 --> Language Class Initialized
INFO - 2018-10-02 13:38:52 --> Loader Class Initialized
INFO - 2018-10-02 13:38:52 --> Helper loaded: url_helper
INFO - 2018-10-02 13:38:52 --> Helper loaded: form_helper
INFO - 2018-10-02 13:38:52 --> Helper loaded: language_helper
DEBUG - 2018-10-02 13:38:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 13:38:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 13:38:52 --> User Agent Class Initialized
INFO - 2018-10-02 13:38:52 --> Controller Class Initialized
INFO - 2018-10-02 13:38:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-02 13:38:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-02 13:38:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-02 13:38:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-02 13:38:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-02 13:38:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-02 13:38:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/advisors.php
INFO - 2018-10-02 13:38:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-02 13:38:52 --> Final output sent to browser
DEBUG - 2018-10-02 13:38:52 --> Total execution time: 0.0234
INFO - 2018-10-02 13:38:54 --> Config Class Initialized
INFO - 2018-10-02 13:38:54 --> Hooks Class Initialized
DEBUG - 2018-10-02 13:38:54 --> UTF-8 Support Enabled
INFO - 2018-10-02 13:38:54 --> Utf8 Class Initialized
INFO - 2018-10-02 13:38:54 --> URI Class Initialized
INFO - 2018-10-02 13:38:54 --> Router Class Initialized
INFO - 2018-10-02 13:38:54 --> Output Class Initialized
INFO - 2018-10-02 13:38:54 --> Security Class Initialized
DEBUG - 2018-10-02 13:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 13:38:54 --> CSRF cookie sent
INFO - 2018-10-02 13:38:54 --> Input Class Initialized
INFO - 2018-10-02 13:38:54 --> Language Class Initialized
INFO - 2018-10-02 13:38:54 --> Loader Class Initialized
INFO - 2018-10-02 13:38:54 --> Helper loaded: url_helper
INFO - 2018-10-02 13:38:54 --> Helper loaded: form_helper
INFO - 2018-10-02 13:38:54 --> Helper loaded: language_helper
DEBUG - 2018-10-02 13:38:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 13:38:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 13:38:54 --> User Agent Class Initialized
INFO - 2018-10-02 13:38:54 --> Controller Class Initialized
INFO - 2018-10-02 13:38:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-02 13:38:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-02 13:38:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-02 13:38:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-02 13:38:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-02 13:38:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-02 13:38:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/faqs.php
INFO - 2018-10-02 13:38:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-02 13:38:54 --> Final output sent to browser
DEBUG - 2018-10-02 13:38:54 --> Total execution time: 0.0299
INFO - 2018-10-02 14:05:34 --> Config Class Initialized
INFO - 2018-10-02 14:05:34 --> Hooks Class Initialized
DEBUG - 2018-10-02 14:05:34 --> UTF-8 Support Enabled
INFO - 2018-10-02 14:05:34 --> Utf8 Class Initialized
INFO - 2018-10-02 14:05:34 --> URI Class Initialized
DEBUG - 2018-10-02 14:05:34 --> No URI present. Default controller set.
INFO - 2018-10-02 14:05:34 --> Router Class Initialized
INFO - 2018-10-02 14:05:34 --> Output Class Initialized
INFO - 2018-10-02 14:05:34 --> Security Class Initialized
DEBUG - 2018-10-02 14:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 14:05:34 --> CSRF cookie sent
INFO - 2018-10-02 14:05:34 --> Input Class Initialized
INFO - 2018-10-02 14:05:34 --> Language Class Initialized
INFO - 2018-10-02 14:05:34 --> Loader Class Initialized
INFO - 2018-10-02 14:05:34 --> Helper loaded: url_helper
INFO - 2018-10-02 14:05:34 --> Helper loaded: form_helper
INFO - 2018-10-02 14:05:34 --> Helper loaded: language_helper
DEBUG - 2018-10-02 14:05:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 14:05:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 14:05:34 --> User Agent Class Initialized
INFO - 2018-10-02 14:05:34 --> Controller Class Initialized
INFO - 2018-10-02 14:05:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-02 14:05:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-02 14:05:34 --> Pixel_Model class loaded
INFO - 2018-10-02 14:05:34 --> Database Driver Class Initialized
INFO - 2018-10-02 14:05:34 --> Model "QuestionsModel" initialized
INFO - 2018-10-02 14:05:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-02 14:05:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-02 14:05:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-02 14:05:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-02 14:05:34 --> Final output sent to browser
DEBUG - 2018-10-02 14:05:34 --> Total execution time: 0.0403
INFO - 2018-10-02 14:05:41 --> Config Class Initialized
INFO - 2018-10-02 14:05:41 --> Hooks Class Initialized
DEBUG - 2018-10-02 14:05:41 --> UTF-8 Support Enabled
INFO - 2018-10-02 14:05:41 --> Utf8 Class Initialized
INFO - 2018-10-02 14:05:41 --> URI Class Initialized
INFO - 2018-10-02 14:05:41 --> Router Class Initialized
INFO - 2018-10-02 14:05:41 --> Output Class Initialized
INFO - 2018-10-02 14:05:41 --> Security Class Initialized
DEBUG - 2018-10-02 14:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 14:05:41 --> CSRF cookie sent
INFO - 2018-10-02 14:05:41 --> CSRF token verified
INFO - 2018-10-02 14:05:41 --> Input Class Initialized
INFO - 2018-10-02 14:05:41 --> Language Class Initialized
INFO - 2018-10-02 14:05:41 --> Loader Class Initialized
INFO - 2018-10-02 14:05:41 --> Helper loaded: url_helper
INFO - 2018-10-02 14:05:41 --> Helper loaded: form_helper
INFO - 2018-10-02 14:05:41 --> Helper loaded: language_helper
DEBUG - 2018-10-02 14:05:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 14:05:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 14:05:41 --> User Agent Class Initialized
INFO - 2018-10-02 14:05:41 --> Controller Class Initialized
INFO - 2018-10-02 14:05:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-02 14:05:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-02 14:05:41 --> Pixel_Model class loaded
INFO - 2018-10-02 14:05:41 --> Database Driver Class Initialized
INFO - 2018-10-02 14:05:41 --> Model "QuestionsModel" initialized
INFO - 2018-10-02 14:05:41 --> Database Driver Class Initialized
INFO - 2018-10-02 14:05:41 --> Model "QuestionsModel" initialized
INFO - 2018-10-02 14:05:41 --> Config Class Initialized
INFO - 2018-10-02 14:05:41 --> Hooks Class Initialized
DEBUG - 2018-10-02 14:05:41 --> UTF-8 Support Enabled
INFO - 2018-10-02 14:05:41 --> Utf8 Class Initialized
INFO - 2018-10-02 14:05:41 --> URI Class Initialized
INFO - 2018-10-02 14:05:41 --> Router Class Initialized
INFO - 2018-10-02 14:05:41 --> Output Class Initialized
INFO - 2018-10-02 14:05:41 --> Security Class Initialized
DEBUG - 2018-10-02 14:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 14:05:41 --> CSRF cookie sent
INFO - 2018-10-02 14:05:41 --> Input Class Initialized
INFO - 2018-10-02 14:05:41 --> Language Class Initialized
INFO - 2018-10-02 14:05:41 --> Loader Class Initialized
INFO - 2018-10-02 14:05:41 --> Helper loaded: url_helper
INFO - 2018-10-02 14:05:41 --> Helper loaded: form_helper
INFO - 2018-10-02 14:05:41 --> Helper loaded: language_helper
DEBUG - 2018-10-02 14:05:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 14:05:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 14:05:41 --> User Agent Class Initialized
INFO - 2018-10-02 14:05:41 --> Controller Class Initialized
INFO - 2018-10-02 14:05:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-02 14:05:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-02 14:05:41 --> Pixel_Model class loaded
INFO - 2018-10-02 14:05:41 --> Database Driver Class Initialized
INFO - 2018-10-02 14:05:41 --> Model "QuestionsModel" initialized
INFO - 2018-10-02 14:05:41 --> Database Driver Class Initialized
INFO - 2018-10-02 14:05:41 --> Model "QuestionsModel" initialized
INFO - 2018-10-02 14:05:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-02 14:05:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-02 14:05:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-02 14:05:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-02 14:05:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-02 14:05:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-02 14:05:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-02 14:05:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-02 14:05:41 --> Final output sent to browser
DEBUG - 2018-10-02 14:05:41 --> Total execution time: 0.0470
INFO - 2018-10-02 14:05:48 --> Config Class Initialized
INFO - 2018-10-02 14:05:48 --> Hooks Class Initialized
DEBUG - 2018-10-02 14:05:48 --> UTF-8 Support Enabled
INFO - 2018-10-02 14:05:48 --> Utf8 Class Initialized
INFO - 2018-10-02 14:05:48 --> URI Class Initialized
INFO - 2018-10-02 14:05:48 --> Router Class Initialized
INFO - 2018-10-02 14:05:48 --> Output Class Initialized
INFO - 2018-10-02 14:05:48 --> Security Class Initialized
DEBUG - 2018-10-02 14:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 14:05:48 --> CSRF cookie sent
INFO - 2018-10-02 14:05:48 --> CSRF token verified
INFO - 2018-10-02 14:05:48 --> Input Class Initialized
INFO - 2018-10-02 14:05:48 --> Language Class Initialized
INFO - 2018-10-02 14:05:48 --> Loader Class Initialized
INFO - 2018-10-02 14:05:48 --> Helper loaded: url_helper
INFO - 2018-10-02 14:05:48 --> Helper loaded: form_helper
INFO - 2018-10-02 14:05:48 --> Helper loaded: language_helper
DEBUG - 2018-10-02 14:05:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 14:05:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 14:05:48 --> User Agent Class Initialized
INFO - 2018-10-02 14:05:48 --> Controller Class Initialized
INFO - 2018-10-02 14:05:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-02 14:05:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-02 14:05:48 --> Pixel_Model class loaded
INFO - 2018-10-02 14:05:48 --> Database Driver Class Initialized
INFO - 2018-10-02 14:05:48 --> Model "QuestionsModel" initialized
INFO - 2018-10-02 14:05:48 --> Form Validation Class Initialized
INFO - 2018-10-02 14:05:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-02 14:05:48 --> Database Driver Class Initialized
INFO - 2018-10-02 14:05:48 --> Model "QuestionsModel" initialized
INFO - 2018-10-02 14:05:48 --> Config Class Initialized
INFO - 2018-10-02 14:05:48 --> Hooks Class Initialized
DEBUG - 2018-10-02 14:05:48 --> UTF-8 Support Enabled
INFO - 2018-10-02 14:05:48 --> Utf8 Class Initialized
INFO - 2018-10-02 14:05:48 --> URI Class Initialized
INFO - 2018-10-02 14:05:48 --> Router Class Initialized
INFO - 2018-10-02 14:05:48 --> Output Class Initialized
INFO - 2018-10-02 14:05:48 --> Security Class Initialized
DEBUG - 2018-10-02 14:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 14:05:48 --> CSRF cookie sent
INFO - 2018-10-02 14:05:48 --> Input Class Initialized
INFO - 2018-10-02 14:05:48 --> Language Class Initialized
INFO - 2018-10-02 14:05:48 --> Loader Class Initialized
INFO - 2018-10-02 14:05:48 --> Helper loaded: url_helper
INFO - 2018-10-02 14:05:48 --> Helper loaded: form_helper
INFO - 2018-10-02 14:05:48 --> Helper loaded: language_helper
DEBUG - 2018-10-02 14:05:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 14:05:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 14:05:48 --> User Agent Class Initialized
INFO - 2018-10-02 14:05:48 --> Controller Class Initialized
INFO - 2018-10-02 14:05:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-02 14:05:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-02 14:05:48 --> Pixel_Model class loaded
INFO - 2018-10-02 14:05:48 --> Database Driver Class Initialized
INFO - 2018-10-02 14:05:48 --> Model "QuestionsModel" initialized
INFO - 2018-10-02 14:05:48 --> Database Driver Class Initialized
INFO - 2018-10-02 14:05:48 --> Model "QuestionsModel" initialized
INFO - 2018-10-02 14:05:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-02 14:05:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-02 14:05:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-02 14:05:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-02 14:05:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-02 14:05:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-02 14:05:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-10-02 14:05:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-02 14:05:48 --> Final output sent to browser
DEBUG - 2018-10-02 14:05:48 --> Total execution time: 0.0461
INFO - 2018-10-02 14:05:51 --> Config Class Initialized
INFO - 2018-10-02 14:05:51 --> Hooks Class Initialized
DEBUG - 2018-10-02 14:05:51 --> UTF-8 Support Enabled
INFO - 2018-10-02 14:05:51 --> Utf8 Class Initialized
INFO - 2018-10-02 14:05:51 --> URI Class Initialized
DEBUG - 2018-10-02 14:05:51 --> No URI present. Default controller set.
INFO - 2018-10-02 14:05:51 --> Router Class Initialized
INFO - 2018-10-02 14:05:51 --> Output Class Initialized
INFO - 2018-10-02 14:05:51 --> Security Class Initialized
DEBUG - 2018-10-02 14:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 14:05:51 --> CSRF cookie sent
INFO - 2018-10-02 14:05:51 --> Input Class Initialized
INFO - 2018-10-02 14:05:51 --> Language Class Initialized
INFO - 2018-10-02 14:05:51 --> Loader Class Initialized
INFO - 2018-10-02 14:05:51 --> Helper loaded: url_helper
INFO - 2018-10-02 14:05:51 --> Helper loaded: form_helper
INFO - 2018-10-02 14:05:51 --> Helper loaded: language_helper
DEBUG - 2018-10-02 14:05:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 14:05:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 14:05:51 --> User Agent Class Initialized
INFO - 2018-10-02 14:05:51 --> Controller Class Initialized
INFO - 2018-10-02 14:05:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-02 14:05:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-02 14:05:51 --> Pixel_Model class loaded
INFO - 2018-10-02 14:05:51 --> Database Driver Class Initialized
INFO - 2018-10-02 14:05:51 --> Model "QuestionsModel" initialized
INFO - 2018-10-02 14:05:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-02 14:05:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-02 14:05:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-02 14:05:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-02 14:05:51 --> Final output sent to browser
DEBUG - 2018-10-02 14:05:51 --> Total execution time: 0.0365
INFO - 2018-10-02 14:05:51 --> Config Class Initialized
INFO - 2018-10-02 14:05:51 --> Hooks Class Initialized
DEBUG - 2018-10-02 14:05:51 --> UTF-8 Support Enabled
INFO - 2018-10-02 14:05:51 --> Utf8 Class Initialized
INFO - 2018-10-02 14:05:51 --> URI Class Initialized
INFO - 2018-10-02 14:05:51 --> Router Class Initialized
INFO - 2018-10-02 14:05:51 --> Output Class Initialized
INFO - 2018-10-02 14:05:51 --> Security Class Initialized
DEBUG - 2018-10-02 14:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 14:05:51 --> CSRF cookie sent
INFO - 2018-10-02 14:05:51 --> CSRF token verified
INFO - 2018-10-02 14:05:51 --> Input Class Initialized
INFO - 2018-10-02 14:05:51 --> Language Class Initialized
INFO - 2018-10-02 14:05:51 --> Loader Class Initialized
INFO - 2018-10-02 14:05:51 --> Helper loaded: url_helper
INFO - 2018-10-02 14:05:51 --> Helper loaded: form_helper
INFO - 2018-10-02 14:05:51 --> Helper loaded: language_helper
DEBUG - 2018-10-02 14:05:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 14:05:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 14:05:51 --> User Agent Class Initialized
INFO - 2018-10-02 14:05:51 --> Controller Class Initialized
INFO - 2018-10-02 14:05:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-02 14:05:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-02 14:05:51 --> Pixel_Model class loaded
INFO - 2018-10-02 14:05:51 --> Database Driver Class Initialized
INFO - 2018-10-02 14:05:51 --> Model "QuestionsModel" initialized
INFO - 2018-10-02 14:05:51 --> Form Validation Class Initialized
INFO - 2018-10-02 14:05:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-02 14:05:51 --> Database Driver Class Initialized
INFO - 2018-10-02 14:05:51 --> Model "QuestionsModel" initialized
INFO - 2018-10-02 14:05:51 --> Config Class Initialized
INFO - 2018-10-02 14:05:51 --> Hooks Class Initialized
DEBUG - 2018-10-02 14:05:51 --> UTF-8 Support Enabled
INFO - 2018-10-02 14:05:51 --> Utf8 Class Initialized
INFO - 2018-10-02 14:05:51 --> URI Class Initialized
INFO - 2018-10-02 14:05:51 --> Router Class Initialized
INFO - 2018-10-02 14:05:51 --> Output Class Initialized
INFO - 2018-10-02 14:05:51 --> Security Class Initialized
DEBUG - 2018-10-02 14:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 14:05:51 --> CSRF cookie sent
INFO - 2018-10-02 14:05:51 --> Input Class Initialized
INFO - 2018-10-02 14:05:51 --> Language Class Initialized
INFO - 2018-10-02 14:05:51 --> Loader Class Initialized
INFO - 2018-10-02 14:05:51 --> Helper loaded: url_helper
INFO - 2018-10-02 14:05:51 --> Helper loaded: form_helper
INFO - 2018-10-02 14:05:51 --> Helper loaded: language_helper
DEBUG - 2018-10-02 14:05:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 14:05:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 14:05:51 --> User Agent Class Initialized
INFO - 2018-10-02 14:05:51 --> Controller Class Initialized
INFO - 2018-10-02 14:05:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-02 14:05:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-02 14:05:51 --> Pixel_Model class loaded
INFO - 2018-10-02 14:05:51 --> Database Driver Class Initialized
INFO - 2018-10-02 14:05:51 --> Model "QuestionsModel" initialized
INFO - 2018-10-02 14:05:51 --> Database Driver Class Initialized
INFO - 2018-10-02 14:05:51 --> Model "QuestionsModel" initialized
INFO - 2018-10-02 14:05:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-02 14:05:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-02 14:05:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-10-02 14:05:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-02 14:05:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-02 14:05:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-02 14:05:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-02 14:05:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-10-02 14:05:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-02 14:05:51 --> Final output sent to browser
DEBUG - 2018-10-02 14:05:51 --> Total execution time: 0.0387
INFO - 2018-10-02 14:05:55 --> Config Class Initialized
INFO - 2018-10-02 14:05:55 --> Hooks Class Initialized
DEBUG - 2018-10-02 14:05:55 --> UTF-8 Support Enabled
INFO - 2018-10-02 14:05:55 --> Utf8 Class Initialized
INFO - 2018-10-02 14:05:55 --> URI Class Initialized
INFO - 2018-10-02 14:05:55 --> Router Class Initialized
INFO - 2018-10-02 14:05:55 --> Output Class Initialized
INFO - 2018-10-02 14:05:55 --> Security Class Initialized
DEBUG - 2018-10-02 14:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 14:05:55 --> CSRF cookie sent
INFO - 2018-10-02 14:05:55 --> CSRF token verified
INFO - 2018-10-02 14:05:55 --> Input Class Initialized
INFO - 2018-10-02 14:05:55 --> Language Class Initialized
INFO - 2018-10-02 14:05:55 --> Loader Class Initialized
INFO - 2018-10-02 14:05:55 --> Helper loaded: url_helper
INFO - 2018-10-02 14:05:55 --> Helper loaded: form_helper
INFO - 2018-10-02 14:05:55 --> Helper loaded: language_helper
DEBUG - 2018-10-02 14:05:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 14:05:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 14:05:55 --> User Agent Class Initialized
INFO - 2018-10-02 14:05:55 --> Controller Class Initialized
INFO - 2018-10-02 14:05:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-02 14:05:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-02 14:05:55 --> Pixel_Model class loaded
INFO - 2018-10-02 14:05:55 --> Database Driver Class Initialized
INFO - 2018-10-02 14:05:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-02 14:05:55 --> Database Driver Class Initialized
INFO - 2018-10-02 14:05:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-02 14:05:56 --> Config Class Initialized
INFO - 2018-10-02 14:05:56 --> Hooks Class Initialized
DEBUG - 2018-10-02 14:05:56 --> UTF-8 Support Enabled
INFO - 2018-10-02 14:05:56 --> Utf8 Class Initialized
INFO - 2018-10-02 14:05:56 --> URI Class Initialized
INFO - 2018-10-02 14:05:56 --> Router Class Initialized
INFO - 2018-10-02 14:05:56 --> Output Class Initialized
INFO - 2018-10-02 14:05:56 --> Security Class Initialized
DEBUG - 2018-10-02 14:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 14:05:56 --> CSRF cookie sent
INFO - 2018-10-02 14:05:56 --> Input Class Initialized
INFO - 2018-10-02 14:05:56 --> Language Class Initialized
INFO - 2018-10-02 14:05:56 --> Loader Class Initialized
INFO - 2018-10-02 14:05:56 --> Helper loaded: url_helper
INFO - 2018-10-02 14:05:56 --> Helper loaded: form_helper
INFO - 2018-10-02 14:05:56 --> Helper loaded: language_helper
DEBUG - 2018-10-02 14:05:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 14:05:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 14:05:56 --> User Agent Class Initialized
INFO - 2018-10-02 14:05:56 --> Controller Class Initialized
INFO - 2018-10-02 14:05:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-02 14:05:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-02 14:05:56 --> Pixel_Model class loaded
INFO - 2018-10-02 14:05:56 --> Database Driver Class Initialized
INFO - 2018-10-02 14:05:56 --> Model "QuestionsModel" initialized
INFO - 2018-10-02 14:05:56 --> Database Driver Class Initialized
INFO - 2018-10-02 14:05:56 --> Model "QuestionsModel" initialized
INFO - 2018-10-02 14:05:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-02 14:05:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-02 14:05:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-02 14:05:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-02 14:05:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-02 14:05:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-02 14:05:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-02 14:05:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-02 14:05:56 --> Final output sent to browser
DEBUG - 2018-10-02 14:05:56 --> Total execution time: 0.0469
INFO - 2018-10-02 14:06:00 --> Config Class Initialized
INFO - 2018-10-02 14:06:00 --> Hooks Class Initialized
DEBUG - 2018-10-02 14:06:00 --> UTF-8 Support Enabled
INFO - 2018-10-02 14:06:00 --> Utf8 Class Initialized
INFO - 2018-10-02 14:06:00 --> URI Class Initialized
INFO - 2018-10-02 14:06:00 --> Router Class Initialized
INFO - 2018-10-02 14:06:00 --> Output Class Initialized
INFO - 2018-10-02 14:06:00 --> Security Class Initialized
DEBUG - 2018-10-02 14:06:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 14:06:00 --> CSRF cookie sent
INFO - 2018-10-02 14:06:00 --> CSRF token verified
INFO - 2018-10-02 14:06:00 --> Input Class Initialized
INFO - 2018-10-02 14:06:00 --> Language Class Initialized
INFO - 2018-10-02 14:06:00 --> Loader Class Initialized
INFO - 2018-10-02 14:06:00 --> Helper loaded: url_helper
INFO - 2018-10-02 14:06:00 --> Helper loaded: form_helper
INFO - 2018-10-02 14:06:00 --> Helper loaded: language_helper
DEBUG - 2018-10-02 14:06:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 14:06:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 14:06:00 --> User Agent Class Initialized
INFO - 2018-10-02 14:06:00 --> Controller Class Initialized
INFO - 2018-10-02 14:06:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-02 14:06:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-02 14:06:00 --> Pixel_Model class loaded
INFO - 2018-10-02 14:06:00 --> Database Driver Class Initialized
INFO - 2018-10-02 14:06:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-02 14:06:00 --> Form Validation Class Initialized
INFO - 2018-10-02 14:06:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-02 14:06:00 --> Database Driver Class Initialized
INFO - 2018-10-02 14:06:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-02 14:06:00 --> Config Class Initialized
INFO - 2018-10-02 14:06:00 --> Hooks Class Initialized
DEBUG - 2018-10-02 14:06:00 --> UTF-8 Support Enabled
INFO - 2018-10-02 14:06:00 --> Utf8 Class Initialized
INFO - 2018-10-02 14:06:00 --> URI Class Initialized
INFO - 2018-10-02 14:06:00 --> Router Class Initialized
INFO - 2018-10-02 14:06:00 --> Output Class Initialized
INFO - 2018-10-02 14:06:00 --> Security Class Initialized
DEBUG - 2018-10-02 14:06:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 14:06:00 --> CSRF cookie sent
INFO - 2018-10-02 14:06:00 --> Input Class Initialized
INFO - 2018-10-02 14:06:00 --> Language Class Initialized
INFO - 2018-10-02 14:06:00 --> Loader Class Initialized
INFO - 2018-10-02 14:06:00 --> Helper loaded: url_helper
INFO - 2018-10-02 14:06:00 --> Helper loaded: form_helper
INFO - 2018-10-02 14:06:00 --> Helper loaded: language_helper
DEBUG - 2018-10-02 14:06:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 14:06:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 14:06:00 --> User Agent Class Initialized
INFO - 2018-10-02 14:06:00 --> Controller Class Initialized
INFO - 2018-10-02 14:06:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-02 14:06:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-02 14:06:00 --> Pixel_Model class loaded
INFO - 2018-10-02 14:06:00 --> Database Driver Class Initialized
INFO - 2018-10-02 14:06:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-02 14:06:00 --> Database Driver Class Initialized
INFO - 2018-10-02 14:06:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-02 14:06:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-02 14:06:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-02 14:06:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-02 14:06:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-02 14:06:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-02 14:06:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-02 14:06:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-10-02 14:06:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-02 14:06:00 --> Final output sent to browser
DEBUG - 2018-10-02 14:06:00 --> Total execution time: 0.0465
INFO - 2018-10-02 14:06:04 --> Config Class Initialized
INFO - 2018-10-02 14:06:04 --> Hooks Class Initialized
DEBUG - 2018-10-02 14:06:04 --> UTF-8 Support Enabled
INFO - 2018-10-02 14:06:04 --> Utf8 Class Initialized
INFO - 2018-10-02 14:06:04 --> URI Class Initialized
INFO - 2018-10-02 14:06:04 --> Router Class Initialized
INFO - 2018-10-02 14:06:04 --> Output Class Initialized
INFO - 2018-10-02 14:06:04 --> Security Class Initialized
DEBUG - 2018-10-02 14:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 14:06:04 --> CSRF cookie sent
INFO - 2018-10-02 14:06:04 --> CSRF token verified
INFO - 2018-10-02 14:06:04 --> Input Class Initialized
INFO - 2018-10-02 14:06:04 --> Language Class Initialized
INFO - 2018-10-02 14:06:04 --> Loader Class Initialized
INFO - 2018-10-02 14:06:04 --> Helper loaded: url_helper
INFO - 2018-10-02 14:06:04 --> Helper loaded: form_helper
INFO - 2018-10-02 14:06:04 --> Helper loaded: language_helper
DEBUG - 2018-10-02 14:06:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 14:06:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 14:06:04 --> User Agent Class Initialized
INFO - 2018-10-02 14:06:04 --> Controller Class Initialized
INFO - 2018-10-02 14:06:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-02 14:06:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-02 14:06:04 --> Pixel_Model class loaded
INFO - 2018-10-02 14:06:04 --> Database Driver Class Initialized
INFO - 2018-10-02 14:06:04 --> Model "QuestionsModel" initialized
INFO - 2018-10-02 14:06:04 --> Form Validation Class Initialized
INFO - 2018-10-02 14:06:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-02 14:06:04 --> Database Driver Class Initialized
INFO - 2018-10-02 14:06:04 --> Model "QuestionsModel" initialized
INFO - 2018-10-02 14:06:04 --> Config Class Initialized
INFO - 2018-10-02 14:06:04 --> Hooks Class Initialized
DEBUG - 2018-10-02 14:06:04 --> UTF-8 Support Enabled
INFO - 2018-10-02 14:06:04 --> Utf8 Class Initialized
INFO - 2018-10-02 14:06:04 --> URI Class Initialized
INFO - 2018-10-02 14:06:04 --> Router Class Initialized
INFO - 2018-10-02 14:06:04 --> Output Class Initialized
INFO - 2018-10-02 14:06:04 --> Security Class Initialized
DEBUG - 2018-10-02 14:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 14:06:04 --> CSRF cookie sent
INFO - 2018-10-02 14:06:04 --> Input Class Initialized
INFO - 2018-10-02 14:06:04 --> Language Class Initialized
INFO - 2018-10-02 14:06:04 --> Loader Class Initialized
INFO - 2018-10-02 14:06:04 --> Helper loaded: url_helper
INFO - 2018-10-02 14:06:04 --> Helper loaded: form_helper
INFO - 2018-10-02 14:06:04 --> Helper loaded: language_helper
DEBUG - 2018-10-02 14:06:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 14:06:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 14:06:04 --> User Agent Class Initialized
INFO - 2018-10-02 14:06:04 --> Controller Class Initialized
INFO - 2018-10-02 14:06:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-02 14:06:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-02 14:06:04 --> Pixel_Model class loaded
INFO - 2018-10-02 14:06:04 --> Database Driver Class Initialized
INFO - 2018-10-02 14:06:04 --> Model "QuestionsModel" initialized
INFO - 2018-10-02 14:06:04 --> Database Driver Class Initialized
INFO - 2018-10-02 14:06:04 --> Model "QuestionsModel" initialized
INFO - 2018-10-02 14:06:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-02 14:06:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-02 14:06:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-10-02 14:06:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-02 14:06:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-02 14:06:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-02 14:06:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-02 14:06:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-10-02 14:06:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-02 14:06:04 --> Final output sent to browser
DEBUG - 2018-10-02 14:06:04 --> Total execution time: 0.0390
INFO - 2018-10-02 14:07:13 --> Config Class Initialized
INFO - 2018-10-02 14:07:13 --> Hooks Class Initialized
DEBUG - 2018-10-02 14:07:13 --> UTF-8 Support Enabled
INFO - 2018-10-02 14:07:13 --> Utf8 Class Initialized
INFO - 2018-10-02 14:07:13 --> URI Class Initialized
INFO - 2018-10-02 14:07:13 --> Router Class Initialized
INFO - 2018-10-02 14:07:13 --> Output Class Initialized
INFO - 2018-10-02 14:07:13 --> Security Class Initialized
DEBUG - 2018-10-02 14:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 14:07:13 --> CSRF cookie sent
INFO - 2018-10-02 14:07:13 --> Input Class Initialized
INFO - 2018-10-02 14:07:13 --> Language Class Initialized
INFO - 2018-10-02 14:07:13 --> Loader Class Initialized
INFO - 2018-10-02 14:07:13 --> Helper loaded: url_helper
INFO - 2018-10-02 14:07:13 --> Helper loaded: form_helper
INFO - 2018-10-02 14:07:13 --> Helper loaded: language_helper
DEBUG - 2018-10-02 14:07:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 14:07:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 14:07:13 --> User Agent Class Initialized
INFO - 2018-10-02 14:07:13 --> Controller Class Initialized
INFO - 2018-10-02 14:07:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-02 14:07:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-02 14:07:13 --> Pixel_Model class loaded
INFO - 2018-10-02 14:07:13 --> Database Driver Class Initialized
INFO - 2018-10-02 14:07:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-02 14:07:13 --> Database Driver Class Initialized
INFO - 2018-10-02 14:07:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-02 14:07:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-02 14:07:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-02 14:07:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-02 14:07:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-02 14:07:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-02 14:07:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-02 14:07:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-10-02 14:07:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-02 14:07:13 --> Final output sent to browser
DEBUG - 2018-10-02 14:07:13 --> Total execution time: 0.0454
INFO - 2018-10-02 14:07:13 --> Config Class Initialized
INFO - 2018-10-02 14:07:13 --> Hooks Class Initialized
DEBUG - 2018-10-02 14:07:13 --> UTF-8 Support Enabled
INFO - 2018-10-02 14:07:13 --> Utf8 Class Initialized
INFO - 2018-10-02 14:07:13 --> URI Class Initialized
INFO - 2018-10-02 14:07:13 --> Router Class Initialized
INFO - 2018-10-02 14:07:13 --> Output Class Initialized
INFO - 2018-10-02 14:07:13 --> Security Class Initialized
DEBUG - 2018-10-02 14:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 14:07:13 --> CSRF cookie sent
INFO - 2018-10-02 14:07:13 --> Input Class Initialized
INFO - 2018-10-02 14:07:13 --> Language Class Initialized
INFO - 2018-10-02 14:07:13 --> Loader Class Initialized
INFO - 2018-10-02 14:07:13 --> Helper loaded: url_helper
INFO - 2018-10-02 14:07:13 --> Helper loaded: form_helper
INFO - 2018-10-02 14:07:13 --> Helper loaded: language_helper
DEBUG - 2018-10-02 14:07:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 14:07:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 14:07:13 --> User Agent Class Initialized
INFO - 2018-10-02 14:07:13 --> Controller Class Initialized
INFO - 2018-10-02 14:07:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-02 14:07:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-02 14:07:13 --> Pixel_Model class loaded
INFO - 2018-10-02 14:07:13 --> Database Driver Class Initialized
INFO - 2018-10-02 14:07:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-02 14:07:13 --> Database Driver Class Initialized
INFO - 2018-10-02 14:07:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-02 14:07:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-02 14:07:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-02 14:07:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-02 14:07:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-02 14:07:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-02 14:07:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-02 14:07:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-02 14:07:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-02 14:07:13 --> Final output sent to browser
DEBUG - 2018-10-02 14:07:13 --> Total execution time: 0.0413
INFO - 2018-10-02 14:07:14 --> Config Class Initialized
INFO - 2018-10-02 14:07:14 --> Hooks Class Initialized
DEBUG - 2018-10-02 14:07:14 --> UTF-8 Support Enabled
INFO - 2018-10-02 14:07:14 --> Utf8 Class Initialized
INFO - 2018-10-02 14:07:14 --> URI Class Initialized
DEBUG - 2018-10-02 14:07:14 --> No URI present. Default controller set.
INFO - 2018-10-02 14:07:14 --> Router Class Initialized
INFO - 2018-10-02 14:07:14 --> Output Class Initialized
INFO - 2018-10-02 14:07:14 --> Security Class Initialized
DEBUG - 2018-10-02 14:07:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 14:07:14 --> CSRF cookie sent
INFO - 2018-10-02 14:07:14 --> Input Class Initialized
INFO - 2018-10-02 14:07:14 --> Language Class Initialized
INFO - 2018-10-02 14:07:14 --> Loader Class Initialized
INFO - 2018-10-02 14:07:14 --> Helper loaded: url_helper
INFO - 2018-10-02 14:07:14 --> Helper loaded: form_helper
INFO - 2018-10-02 14:07:14 --> Helper loaded: language_helper
DEBUG - 2018-10-02 14:07:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 14:07:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 14:07:14 --> User Agent Class Initialized
INFO - 2018-10-02 14:07:14 --> Controller Class Initialized
INFO - 2018-10-02 14:07:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-02 14:07:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-02 14:07:14 --> Pixel_Model class loaded
INFO - 2018-10-02 14:07:14 --> Database Driver Class Initialized
INFO - 2018-10-02 14:07:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-02 14:07:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-02 14:07:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-02 14:07:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-02 14:07:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-02 14:07:14 --> Final output sent to browser
DEBUG - 2018-10-02 14:07:14 --> Total execution time: 0.0356
INFO - 2018-10-02 14:07:16 --> Config Class Initialized
INFO - 2018-10-02 14:07:16 --> Hooks Class Initialized
DEBUG - 2018-10-02 14:07:16 --> UTF-8 Support Enabled
INFO - 2018-10-02 14:07:16 --> Utf8 Class Initialized
INFO - 2018-10-02 14:07:16 --> URI Class Initialized
DEBUG - 2018-10-02 14:07:16 --> No URI present. Default controller set.
INFO - 2018-10-02 14:07:16 --> Router Class Initialized
INFO - 2018-10-02 14:07:16 --> Output Class Initialized
INFO - 2018-10-02 14:07:16 --> Security Class Initialized
DEBUG - 2018-10-02 14:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 14:07:16 --> CSRF cookie sent
INFO - 2018-10-02 14:07:16 --> Input Class Initialized
INFO - 2018-10-02 14:07:16 --> Language Class Initialized
INFO - 2018-10-02 14:07:16 --> Loader Class Initialized
INFO - 2018-10-02 14:07:16 --> Helper loaded: url_helper
INFO - 2018-10-02 14:07:16 --> Helper loaded: form_helper
INFO - 2018-10-02 14:07:16 --> Helper loaded: language_helper
DEBUG - 2018-10-02 14:07:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 14:07:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 14:07:16 --> User Agent Class Initialized
INFO - 2018-10-02 14:07:16 --> Controller Class Initialized
INFO - 2018-10-02 14:07:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-02 14:07:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-02 14:07:16 --> Pixel_Model class loaded
INFO - 2018-10-02 14:07:16 --> Database Driver Class Initialized
INFO - 2018-10-02 14:07:16 --> Model "QuestionsModel" initialized
INFO - 2018-10-02 14:07:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-02 14:07:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-02 14:07:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-02 14:07:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-02 14:07:16 --> Final output sent to browser
DEBUG - 2018-10-02 14:07:16 --> Total execution time: 0.0363
INFO - 2018-10-02 14:07:53 --> Config Class Initialized
INFO - 2018-10-02 14:07:53 --> Hooks Class Initialized
DEBUG - 2018-10-02 14:07:53 --> UTF-8 Support Enabled
INFO - 2018-10-02 14:07:53 --> Utf8 Class Initialized
INFO - 2018-10-02 14:07:53 --> URI Class Initialized
INFO - 2018-10-02 14:07:53 --> Router Class Initialized
INFO - 2018-10-02 14:07:53 --> Output Class Initialized
INFO - 2018-10-02 14:07:53 --> Security Class Initialized
DEBUG - 2018-10-02 14:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 14:07:53 --> CSRF cookie sent
INFO - 2018-10-02 14:07:53 --> CSRF token verified
INFO - 2018-10-02 14:07:53 --> Input Class Initialized
INFO - 2018-10-02 14:07:53 --> Language Class Initialized
INFO - 2018-10-02 14:07:54 --> Loader Class Initialized
INFO - 2018-10-02 14:07:54 --> Helper loaded: url_helper
INFO - 2018-10-02 14:07:54 --> Helper loaded: form_helper
INFO - 2018-10-02 14:07:54 --> Helper loaded: language_helper
DEBUG - 2018-10-02 14:07:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 14:07:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 14:07:54 --> User Agent Class Initialized
INFO - 2018-10-02 14:07:54 --> Controller Class Initialized
INFO - 2018-10-02 14:07:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-02 14:07:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-02 14:07:54 --> Pixel_Model class loaded
INFO - 2018-10-02 14:07:54 --> Database Driver Class Initialized
INFO - 2018-10-02 14:07:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-02 14:07:54 --> Database Driver Class Initialized
INFO - 2018-10-02 14:07:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-02 14:07:54 --> Config Class Initialized
INFO - 2018-10-02 14:07:54 --> Hooks Class Initialized
DEBUG - 2018-10-02 14:07:54 --> UTF-8 Support Enabled
INFO - 2018-10-02 14:07:54 --> Utf8 Class Initialized
INFO - 2018-10-02 14:07:54 --> URI Class Initialized
INFO - 2018-10-02 14:07:54 --> Router Class Initialized
INFO - 2018-10-02 14:07:54 --> Output Class Initialized
INFO - 2018-10-02 14:07:54 --> Security Class Initialized
DEBUG - 2018-10-02 14:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 14:07:54 --> CSRF cookie sent
INFO - 2018-10-02 14:07:54 --> Input Class Initialized
INFO - 2018-10-02 14:07:54 --> Language Class Initialized
INFO - 2018-10-02 14:07:54 --> Loader Class Initialized
INFO - 2018-10-02 14:07:54 --> Helper loaded: url_helper
INFO - 2018-10-02 14:07:54 --> Helper loaded: form_helper
INFO - 2018-10-02 14:07:54 --> Helper loaded: language_helper
DEBUG - 2018-10-02 14:07:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 14:07:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 14:07:54 --> User Agent Class Initialized
INFO - 2018-10-02 14:07:54 --> Controller Class Initialized
INFO - 2018-10-02 14:07:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-02 14:07:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-02 14:07:54 --> Pixel_Model class loaded
INFO - 2018-10-02 14:07:54 --> Database Driver Class Initialized
INFO - 2018-10-02 14:07:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-02 14:07:54 --> Database Driver Class Initialized
INFO - 2018-10-02 14:07:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-02 14:07:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-02 14:07:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-02 14:07:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-10-02 14:07:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-02 14:07:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-02 14:07:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-02 14:07:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-02 14:07:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-10-02 14:07:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-02 14:07:54 --> Final output sent to browser
DEBUG - 2018-10-02 14:07:54 --> Total execution time: 0.0487
INFO - 2018-10-02 14:07:56 --> Config Class Initialized
INFO - 2018-10-02 14:07:56 --> Hooks Class Initialized
DEBUG - 2018-10-02 14:07:56 --> UTF-8 Support Enabled
INFO - 2018-10-02 14:07:56 --> Utf8 Class Initialized
INFO - 2018-10-02 14:07:56 --> URI Class Initialized
INFO - 2018-10-02 14:07:56 --> Router Class Initialized
INFO - 2018-10-02 14:07:56 --> Output Class Initialized
INFO - 2018-10-02 14:07:56 --> Security Class Initialized
DEBUG - 2018-10-02 14:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 14:07:56 --> CSRF cookie sent
INFO - 2018-10-02 14:07:56 --> CSRF token verified
INFO - 2018-10-02 14:07:56 --> Input Class Initialized
INFO - 2018-10-02 14:07:56 --> Language Class Initialized
INFO - 2018-10-02 14:07:56 --> Loader Class Initialized
INFO - 2018-10-02 14:07:56 --> Helper loaded: url_helper
INFO - 2018-10-02 14:07:56 --> Helper loaded: form_helper
INFO - 2018-10-02 14:07:56 --> Helper loaded: language_helper
DEBUG - 2018-10-02 14:07:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 14:07:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 14:07:56 --> User Agent Class Initialized
INFO - 2018-10-02 14:07:56 --> Controller Class Initialized
INFO - 2018-10-02 14:07:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-02 14:07:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-02 14:07:56 --> Pixel_Model class loaded
INFO - 2018-10-02 14:07:56 --> Database Driver Class Initialized
INFO - 2018-10-02 14:07:56 --> Model "QuestionsModel" initialized
INFO - 2018-10-02 14:07:56 --> Form Validation Class Initialized
INFO - 2018-10-02 14:07:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-02 14:07:56 --> Database Driver Class Initialized
INFO - 2018-10-02 14:07:56 --> Model "QuestionsModel" initialized
INFO - 2018-10-02 14:07:56 --> Config Class Initialized
INFO - 2018-10-02 14:07:56 --> Hooks Class Initialized
DEBUG - 2018-10-02 14:07:56 --> UTF-8 Support Enabled
INFO - 2018-10-02 14:07:56 --> Utf8 Class Initialized
INFO - 2018-10-02 14:07:56 --> URI Class Initialized
INFO - 2018-10-02 14:07:56 --> Router Class Initialized
INFO - 2018-10-02 14:07:56 --> Output Class Initialized
INFO - 2018-10-02 14:07:56 --> Security Class Initialized
DEBUG - 2018-10-02 14:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 14:07:56 --> CSRF cookie sent
INFO - 2018-10-02 14:07:56 --> Input Class Initialized
INFO - 2018-10-02 14:07:56 --> Language Class Initialized
INFO - 2018-10-02 14:07:56 --> Loader Class Initialized
INFO - 2018-10-02 14:07:56 --> Helper loaded: url_helper
INFO - 2018-10-02 14:07:56 --> Helper loaded: form_helper
INFO - 2018-10-02 14:07:56 --> Helper loaded: language_helper
DEBUG - 2018-10-02 14:07:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 14:07:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 14:07:56 --> User Agent Class Initialized
INFO - 2018-10-02 14:07:56 --> Controller Class Initialized
INFO - 2018-10-02 14:07:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-02 14:07:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-02 14:07:56 --> Pixel_Model class loaded
INFO - 2018-10-02 14:07:56 --> Database Driver Class Initialized
INFO - 2018-10-02 14:07:56 --> Model "QuestionsModel" initialized
INFO - 2018-10-02 14:07:56 --> Database Driver Class Initialized
INFO - 2018-10-02 14:07:56 --> Model "QuestionsModel" initialized
INFO - 2018-10-02 14:07:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-02 14:07:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-02 14:07:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-02 14:07:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-02 14:07:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-02 14:07:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-02 14:07:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-02 14:07:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-02 14:07:56 --> Final output sent to browser
DEBUG - 2018-10-02 14:07:56 --> Total execution time: 0.0404
INFO - 2018-10-02 14:07:58 --> Config Class Initialized
INFO - 2018-10-02 14:07:58 --> Hooks Class Initialized
DEBUG - 2018-10-02 14:07:58 --> UTF-8 Support Enabled
INFO - 2018-10-02 14:07:58 --> Utf8 Class Initialized
INFO - 2018-10-02 14:07:58 --> URI Class Initialized
INFO - 2018-10-02 14:07:58 --> Router Class Initialized
INFO - 2018-10-02 14:07:58 --> Output Class Initialized
INFO - 2018-10-02 14:07:58 --> Security Class Initialized
DEBUG - 2018-10-02 14:07:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 14:07:58 --> CSRF cookie sent
INFO - 2018-10-02 14:07:58 --> Input Class Initialized
INFO - 2018-10-02 14:07:58 --> Language Class Initialized
INFO - 2018-10-02 14:07:58 --> Loader Class Initialized
INFO - 2018-10-02 14:07:58 --> Helper loaded: url_helper
INFO - 2018-10-02 14:07:58 --> Helper loaded: form_helper
INFO - 2018-10-02 14:07:58 --> Helper loaded: language_helper
DEBUG - 2018-10-02 14:07:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 14:07:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 14:07:58 --> User Agent Class Initialized
INFO - 2018-10-02 14:07:58 --> Controller Class Initialized
INFO - 2018-10-02 14:07:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-02 14:07:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-02 14:07:58 --> Pixel_Model class loaded
INFO - 2018-10-02 14:07:58 --> Database Driver Class Initialized
INFO - 2018-10-02 14:07:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-02 14:07:58 --> Database Driver Class Initialized
INFO - 2018-10-02 14:07:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-02 14:07:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-02 14:07:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-02 14:07:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-10-02 14:07:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-02 14:07:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-02 14:07:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-02 14:07:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-02 14:07:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-10-02 14:07:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-02 14:07:58 --> Final output sent to browser
DEBUG - 2018-10-02 14:07:58 --> Total execution time: 0.0411
INFO - 2018-10-02 14:08:31 --> Config Class Initialized
INFO - 2018-10-02 14:08:31 --> Hooks Class Initialized
DEBUG - 2018-10-02 14:08:31 --> UTF-8 Support Enabled
INFO - 2018-10-02 14:08:31 --> Utf8 Class Initialized
INFO - 2018-10-02 14:08:31 --> URI Class Initialized
INFO - 2018-10-02 14:08:31 --> Router Class Initialized
INFO - 2018-10-02 14:08:31 --> Output Class Initialized
INFO - 2018-10-02 14:08:31 --> Security Class Initialized
DEBUG - 2018-10-02 14:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 14:08:31 --> CSRF cookie sent
INFO - 2018-10-02 14:08:31 --> Input Class Initialized
INFO - 2018-10-02 14:08:31 --> Language Class Initialized
INFO - 2018-10-02 14:08:31 --> Loader Class Initialized
INFO - 2018-10-02 14:08:31 --> Helper loaded: url_helper
INFO - 2018-10-02 14:08:31 --> Helper loaded: form_helper
INFO - 2018-10-02 14:08:31 --> Helper loaded: language_helper
DEBUG - 2018-10-02 14:08:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 14:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 14:08:31 --> User Agent Class Initialized
INFO - 2018-10-02 14:08:31 --> Controller Class Initialized
INFO - 2018-10-02 14:08:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-02 14:08:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-02 14:08:31 --> Pixel_Model class loaded
INFO - 2018-10-02 14:08:31 --> Database Driver Class Initialized
INFO - 2018-10-02 14:08:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-02 14:08:31 --> Database Driver Class Initialized
INFO - 2018-10-02 14:08:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-02 14:08:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-02 14:08:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-02 14:08:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-02 14:08:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-02 14:08:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-02 14:08:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-02 14:08:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-02 14:08:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-02 14:08:31 --> Final output sent to browser
DEBUG - 2018-10-02 14:08:31 --> Total execution time: 0.0607
INFO - 2018-10-02 14:08:33 --> Config Class Initialized
INFO - 2018-10-02 14:08:33 --> Hooks Class Initialized
DEBUG - 2018-10-02 14:08:33 --> UTF-8 Support Enabled
INFO - 2018-10-02 14:08:33 --> Utf8 Class Initialized
INFO - 2018-10-02 14:08:33 --> URI Class Initialized
INFO - 2018-10-02 14:08:33 --> Router Class Initialized
INFO - 2018-10-02 14:08:33 --> Output Class Initialized
INFO - 2018-10-02 14:08:33 --> Security Class Initialized
DEBUG - 2018-10-02 14:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 14:08:33 --> CSRF cookie sent
INFO - 2018-10-02 14:08:33 --> Input Class Initialized
INFO - 2018-10-02 14:08:33 --> Language Class Initialized
INFO - 2018-10-02 14:08:33 --> Loader Class Initialized
INFO - 2018-10-02 14:08:33 --> Helper loaded: url_helper
INFO - 2018-10-02 14:08:33 --> Helper loaded: form_helper
INFO - 2018-10-02 14:08:33 --> Helper loaded: language_helper
DEBUG - 2018-10-02 14:08:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 14:08:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 14:08:33 --> User Agent Class Initialized
INFO - 2018-10-02 14:08:33 --> Controller Class Initialized
INFO - 2018-10-02 14:08:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-02 14:08:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-02 14:08:33 --> Pixel_Model class loaded
INFO - 2018-10-02 14:08:33 --> Database Driver Class Initialized
INFO - 2018-10-02 14:08:33 --> Model "QuestionsModel" initialized
INFO - 2018-10-02 14:08:33 --> Database Driver Class Initialized
INFO - 2018-10-02 14:08:33 --> Model "QuestionsModel" initialized
INFO - 2018-10-02 14:08:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-02 14:08:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-02 14:08:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-10-02 14:08:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-02 14:08:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-02 14:08:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-02 14:08:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-02 14:08:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-10-02 14:08:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-02 14:08:33 --> Final output sent to browser
DEBUG - 2018-10-02 14:08:33 --> Total execution time: 0.0412
INFO - 2018-10-02 14:08:34 --> Config Class Initialized
INFO - 2018-10-02 14:08:34 --> Hooks Class Initialized
DEBUG - 2018-10-02 14:08:34 --> UTF-8 Support Enabled
INFO - 2018-10-02 14:08:34 --> Utf8 Class Initialized
INFO - 2018-10-02 14:08:34 --> URI Class Initialized
DEBUG - 2018-10-02 14:08:34 --> No URI present. Default controller set.
INFO - 2018-10-02 14:08:34 --> Router Class Initialized
INFO - 2018-10-02 14:08:34 --> Output Class Initialized
INFO - 2018-10-02 14:08:34 --> Security Class Initialized
DEBUG - 2018-10-02 14:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 14:08:34 --> CSRF cookie sent
INFO - 2018-10-02 14:08:34 --> Input Class Initialized
INFO - 2018-10-02 14:08:34 --> Language Class Initialized
INFO - 2018-10-02 14:08:34 --> Loader Class Initialized
INFO - 2018-10-02 14:08:34 --> Helper loaded: url_helper
INFO - 2018-10-02 14:08:34 --> Helper loaded: form_helper
INFO - 2018-10-02 14:08:34 --> Helper loaded: language_helper
DEBUG - 2018-10-02 14:08:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 14:08:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 14:08:34 --> User Agent Class Initialized
INFO - 2018-10-02 14:08:34 --> Controller Class Initialized
INFO - 2018-10-02 14:08:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-02 14:08:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-02 14:08:34 --> Pixel_Model class loaded
INFO - 2018-10-02 14:08:34 --> Database Driver Class Initialized
INFO - 2018-10-02 14:08:34 --> Model "QuestionsModel" initialized
INFO - 2018-10-02 14:08:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-02 14:08:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-02 14:08:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-02 14:08:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-02 14:08:34 --> Final output sent to browser
DEBUG - 2018-10-02 14:08:34 --> Total execution time: 0.0478
INFO - 2018-10-02 18:16:18 --> Config Class Initialized
INFO - 2018-10-02 18:16:18 --> Hooks Class Initialized
DEBUG - 2018-10-02 18:16:18 --> UTF-8 Support Enabled
INFO - 2018-10-02 18:16:18 --> Utf8 Class Initialized
INFO - 2018-10-02 18:16:18 --> URI Class Initialized
DEBUG - 2018-10-02 18:16:18 --> No URI present. Default controller set.
INFO - 2018-10-02 18:16:18 --> Router Class Initialized
INFO - 2018-10-02 18:16:18 --> Output Class Initialized
INFO - 2018-10-02 18:16:18 --> Security Class Initialized
DEBUG - 2018-10-02 18:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 18:16:18 --> CSRF cookie sent
INFO - 2018-10-02 18:16:18 --> Input Class Initialized
INFO - 2018-10-02 18:16:18 --> Language Class Initialized
INFO - 2018-10-02 18:16:18 --> Loader Class Initialized
INFO - 2018-10-02 18:16:18 --> Helper loaded: url_helper
INFO - 2018-10-02 18:16:18 --> Helper loaded: form_helper
INFO - 2018-10-02 18:16:18 --> Helper loaded: language_helper
DEBUG - 2018-10-02 18:16:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 18:16:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 18:16:18 --> User Agent Class Initialized
INFO - 2018-10-02 18:16:18 --> Controller Class Initialized
INFO - 2018-10-02 18:16:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-02 18:16:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-02 18:16:18 --> Pixel_Model class loaded
INFO - 2018-10-02 18:16:18 --> Database Driver Class Initialized
INFO - 2018-10-02 18:16:18 --> Model "QuestionsModel" initialized
INFO - 2018-10-02 18:16:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-02 18:16:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-02 18:16:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-02 18:16:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-02 18:16:18 --> Final output sent to browser
DEBUG - 2018-10-02 18:16:18 --> Total execution time: 0.0360
INFO - 2018-10-02 18:19:31 --> Config Class Initialized
INFO - 2018-10-02 18:19:31 --> Hooks Class Initialized
DEBUG - 2018-10-02 18:19:31 --> UTF-8 Support Enabled
INFO - 2018-10-02 18:19:31 --> Utf8 Class Initialized
INFO - 2018-10-02 18:19:31 --> URI Class Initialized
DEBUG - 2018-10-02 18:19:31 --> No URI present. Default controller set.
INFO - 2018-10-02 18:19:31 --> Router Class Initialized
INFO - 2018-10-02 18:19:31 --> Output Class Initialized
INFO - 2018-10-02 18:19:31 --> Security Class Initialized
DEBUG - 2018-10-02 18:19:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 18:19:31 --> CSRF cookie sent
INFO - 2018-10-02 18:19:31 --> Input Class Initialized
INFO - 2018-10-02 18:19:31 --> Language Class Initialized
INFO - 2018-10-02 18:19:31 --> Loader Class Initialized
INFO - 2018-10-02 18:19:31 --> Helper loaded: url_helper
INFO - 2018-10-02 18:19:31 --> Helper loaded: form_helper
INFO - 2018-10-02 18:19:31 --> Helper loaded: language_helper
DEBUG - 2018-10-02 18:19:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 18:19:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 18:19:31 --> User Agent Class Initialized
INFO - 2018-10-02 18:19:31 --> Controller Class Initialized
INFO - 2018-10-02 18:19:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-02 18:19:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-02 18:19:31 --> Pixel_Model class loaded
INFO - 2018-10-02 18:19:31 --> Database Driver Class Initialized
INFO - 2018-10-02 18:19:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-02 18:19:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-02 18:19:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-02 18:19:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-02 18:19:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-02 18:19:31 --> Final output sent to browser
DEBUG - 2018-10-02 18:19:31 --> Total execution time: 0.0365
INFO - 2018-10-02 18:19:38 --> Config Class Initialized
INFO - 2018-10-02 18:19:38 --> Hooks Class Initialized
DEBUG - 2018-10-02 18:19:38 --> UTF-8 Support Enabled
INFO - 2018-10-02 18:19:38 --> Utf8 Class Initialized
INFO - 2018-10-02 18:19:38 --> URI Class Initialized
DEBUG - 2018-10-02 18:19:38 --> No URI present. Default controller set.
INFO - 2018-10-02 18:19:38 --> Router Class Initialized
INFO - 2018-10-02 18:19:38 --> Output Class Initialized
INFO - 2018-10-02 18:19:38 --> Security Class Initialized
DEBUG - 2018-10-02 18:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 18:19:38 --> CSRF cookie sent
INFO - 2018-10-02 18:19:38 --> Input Class Initialized
INFO - 2018-10-02 18:19:38 --> Language Class Initialized
INFO - 2018-10-02 18:19:38 --> Loader Class Initialized
INFO - 2018-10-02 18:19:38 --> Helper loaded: url_helper
INFO - 2018-10-02 18:19:38 --> Helper loaded: form_helper
INFO - 2018-10-02 18:19:38 --> Helper loaded: language_helper
DEBUG - 2018-10-02 18:19:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 18:19:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 18:19:38 --> User Agent Class Initialized
INFO - 2018-10-02 18:19:38 --> Controller Class Initialized
INFO - 2018-10-02 18:19:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-02 18:19:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-02 18:19:38 --> Pixel_Model class loaded
INFO - 2018-10-02 18:19:38 --> Database Driver Class Initialized
INFO - 2018-10-02 18:19:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-02 18:19:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-02 18:19:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-02 18:19:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-02 18:19:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-02 18:19:38 --> Final output sent to browser
DEBUG - 2018-10-02 18:19:38 --> Total execution time: 0.0439
INFO - 2018-10-02 19:35:03 --> Config Class Initialized
INFO - 2018-10-02 19:35:03 --> Hooks Class Initialized
DEBUG - 2018-10-02 19:35:03 --> UTF-8 Support Enabled
INFO - 2018-10-02 19:35:03 --> Utf8 Class Initialized
INFO - 2018-10-02 19:35:03 --> URI Class Initialized
INFO - 2018-10-02 19:35:03 --> Router Class Initialized
INFO - 2018-10-02 19:35:03 --> Output Class Initialized
INFO - 2018-10-02 19:35:03 --> Security Class Initialized
DEBUG - 2018-10-02 19:35:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 19:35:03 --> CSRF cookie sent
INFO - 2018-10-02 19:35:03 --> Input Class Initialized
INFO - 2018-10-02 19:35:03 --> Language Class Initialized
ERROR - 2018-10-02 19:35:03 --> 404 Page Not Found: 401shtml/index
INFO - 2018-10-02 19:35:04 --> Config Class Initialized
INFO - 2018-10-02 19:35:04 --> Hooks Class Initialized
DEBUG - 2018-10-02 19:35:04 --> UTF-8 Support Enabled
INFO - 2018-10-02 19:35:04 --> Utf8 Class Initialized
INFO - 2018-10-02 19:35:04 --> URI Class Initialized
INFO - 2018-10-02 19:35:04 --> Router Class Initialized
INFO - 2018-10-02 19:35:04 --> Output Class Initialized
INFO - 2018-10-02 19:35:04 --> Security Class Initialized
DEBUG - 2018-10-02 19:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 19:35:04 --> CSRF cookie sent
INFO - 2018-10-02 19:35:04 --> Input Class Initialized
INFO - 2018-10-02 19:35:04 --> Language Class Initialized
ERROR - 2018-10-02 19:35:04 --> 404 Page Not Found: Faviconico/index
INFO - 2018-10-02 19:35:12 --> Config Class Initialized
INFO - 2018-10-02 19:35:12 --> Hooks Class Initialized
DEBUG - 2018-10-02 19:35:12 --> UTF-8 Support Enabled
INFO - 2018-10-02 19:35:12 --> Utf8 Class Initialized
INFO - 2018-10-02 19:35:12 --> URI Class Initialized
DEBUG - 2018-10-02 19:35:12 --> No URI present. Default controller set.
INFO - 2018-10-02 19:35:12 --> Router Class Initialized
INFO - 2018-10-02 19:35:12 --> Output Class Initialized
INFO - 2018-10-02 19:35:12 --> Security Class Initialized
DEBUG - 2018-10-02 19:35:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 19:35:12 --> CSRF cookie sent
INFO - 2018-10-02 19:35:12 --> Input Class Initialized
INFO - 2018-10-02 19:35:12 --> Language Class Initialized
INFO - 2018-10-02 19:35:12 --> Loader Class Initialized
INFO - 2018-10-02 19:35:12 --> Helper loaded: url_helper
INFO - 2018-10-02 19:35:12 --> Helper loaded: form_helper
INFO - 2018-10-02 19:35:12 --> Helper loaded: language_helper
DEBUG - 2018-10-02 19:35:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 19:35:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 19:35:12 --> User Agent Class Initialized
INFO - 2018-10-02 19:35:12 --> Controller Class Initialized
INFO - 2018-10-02 19:35:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-02 19:35:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-02 19:35:12 --> Pixel_Model class loaded
INFO - 2018-10-02 19:35:12 --> Database Driver Class Initialized
INFO - 2018-10-02 19:35:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-02 19:35:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-02 19:35:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-02 19:35:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-02 19:35:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-02 19:35:12 --> Final output sent to browser
DEBUG - 2018-10-02 19:35:12 --> Total execution time: 0.0371
INFO - 2018-10-02 19:42:46 --> Config Class Initialized
INFO - 2018-10-02 19:42:46 --> Hooks Class Initialized
DEBUG - 2018-10-02 19:42:46 --> UTF-8 Support Enabled
INFO - 2018-10-02 19:42:46 --> Utf8 Class Initialized
INFO - 2018-10-02 19:42:46 --> URI Class Initialized
DEBUG - 2018-10-02 19:42:46 --> No URI present. Default controller set.
INFO - 2018-10-02 19:42:46 --> Router Class Initialized
INFO - 2018-10-02 19:42:46 --> Output Class Initialized
INFO - 2018-10-02 19:42:46 --> Security Class Initialized
DEBUG - 2018-10-02 19:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 19:42:46 --> CSRF cookie sent
INFO - 2018-10-02 19:42:46 --> Input Class Initialized
INFO - 2018-10-02 19:42:46 --> Language Class Initialized
INFO - 2018-10-02 19:42:46 --> Loader Class Initialized
INFO - 2018-10-02 19:42:46 --> Helper loaded: url_helper
INFO - 2018-10-02 19:42:46 --> Helper loaded: form_helper
INFO - 2018-10-02 19:42:46 --> Helper loaded: language_helper
DEBUG - 2018-10-02 19:42:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 19:42:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 19:42:46 --> User Agent Class Initialized
INFO - 2018-10-02 19:42:46 --> Controller Class Initialized
INFO - 2018-10-02 19:42:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-02 19:42:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-02 19:42:46 --> Pixel_Model class loaded
INFO - 2018-10-02 19:42:46 --> Database Driver Class Initialized
INFO - 2018-10-02 19:42:46 --> Model "QuestionsModel" initialized
INFO - 2018-10-02 19:42:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-02 19:42:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-02 19:42:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-02 19:42:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-02 19:42:46 --> Final output sent to browser
DEBUG - 2018-10-02 19:42:46 --> Total execution time: 0.0531

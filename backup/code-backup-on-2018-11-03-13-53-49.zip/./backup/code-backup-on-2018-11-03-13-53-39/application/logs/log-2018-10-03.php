<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-10-03 22:51:39 --> Config Class Initialized
INFO - 2018-10-03 22:51:39 --> Hooks Class Initialized
DEBUG - 2018-10-03 22:51:39 --> UTF-8 Support Enabled
INFO - 2018-10-03 22:51:39 --> Utf8 Class Initialized
INFO - 2018-10-03 22:51:39 --> URI Class Initialized
DEBUG - 2018-10-03 22:51:39 --> No URI present. Default controller set.
INFO - 2018-10-03 22:51:39 --> Router Class Initialized
INFO - 2018-10-03 22:51:39 --> Output Class Initialized
INFO - 2018-10-03 22:51:39 --> Security Class Initialized
DEBUG - 2018-10-03 22:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-03 22:51:39 --> CSRF cookie sent
INFO - 2018-10-03 22:51:39 --> Input Class Initialized
INFO - 2018-10-03 22:51:39 --> Language Class Initialized
INFO - 2018-10-03 22:51:39 --> Loader Class Initialized
INFO - 2018-10-03 22:51:39 --> Helper loaded: url_helper
INFO - 2018-10-03 22:51:39 --> Helper loaded: form_helper
INFO - 2018-10-03 22:51:39 --> Helper loaded: language_helper
DEBUG - 2018-10-03 22:51:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-03 22:51:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-03 22:51:39 --> User Agent Class Initialized
INFO - 2018-10-03 22:51:39 --> Controller Class Initialized
INFO - 2018-10-03 22:51:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-03 22:51:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-03 22:51:39 --> Pixel_Model class loaded
INFO - 2018-10-03 22:51:39 --> Database Driver Class Initialized
INFO - 2018-10-03 22:51:39 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:51:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-03 22:51:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-03 22:51:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-03 22:51:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-03 22:51:39 --> Final output sent to browser
DEBUG - 2018-10-03 22:51:39 --> Total execution time: 0.0358
INFO - 2018-10-03 22:51:40 --> Config Class Initialized
INFO - 2018-10-03 22:51:40 --> Hooks Class Initialized
DEBUG - 2018-10-03 22:51:40 --> UTF-8 Support Enabled
INFO - 2018-10-03 22:51:40 --> Utf8 Class Initialized
INFO - 2018-10-03 22:51:40 --> URI Class Initialized
DEBUG - 2018-10-03 22:51:40 --> No URI present. Default controller set.
INFO - 2018-10-03 22:51:40 --> Router Class Initialized
INFO - 2018-10-03 22:51:40 --> Output Class Initialized
INFO - 2018-10-03 22:51:40 --> Security Class Initialized
DEBUG - 2018-10-03 22:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-03 22:51:40 --> CSRF cookie sent
INFO - 2018-10-03 22:51:40 --> Input Class Initialized
INFO - 2018-10-03 22:51:40 --> Language Class Initialized
INFO - 2018-10-03 22:51:40 --> Loader Class Initialized
INFO - 2018-10-03 22:51:40 --> Helper loaded: url_helper
INFO - 2018-10-03 22:51:40 --> Helper loaded: form_helper
INFO - 2018-10-03 22:51:40 --> Helper loaded: language_helper
DEBUG - 2018-10-03 22:51:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-03 22:51:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-03 22:51:40 --> User Agent Class Initialized
INFO - 2018-10-03 22:51:40 --> Controller Class Initialized
INFO - 2018-10-03 22:51:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-03 22:51:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-03 22:51:40 --> Pixel_Model class loaded
INFO - 2018-10-03 22:51:40 --> Database Driver Class Initialized
INFO - 2018-10-03 22:51:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:51:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-03 22:51:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-03 22:51:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-03 22:51:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-03 22:51:40 --> Final output sent to browser
DEBUG - 2018-10-03 22:51:40 --> Total execution time: 0.0355
INFO - 2018-10-03 22:51:48 --> Config Class Initialized
INFO - 2018-10-03 22:51:48 --> Hooks Class Initialized
DEBUG - 2018-10-03 22:51:48 --> UTF-8 Support Enabled
INFO - 2018-10-03 22:51:48 --> Utf8 Class Initialized
INFO - 2018-10-03 22:51:48 --> URI Class Initialized
INFO - 2018-10-03 22:51:48 --> Router Class Initialized
INFO - 2018-10-03 22:51:48 --> Output Class Initialized
INFO - 2018-10-03 22:51:48 --> Security Class Initialized
DEBUG - 2018-10-03 22:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-03 22:51:48 --> CSRF cookie sent
INFO - 2018-10-03 22:51:48 --> CSRF token verified
INFO - 2018-10-03 22:51:48 --> Input Class Initialized
INFO - 2018-10-03 22:51:48 --> Language Class Initialized
INFO - 2018-10-03 22:51:48 --> Loader Class Initialized
INFO - 2018-10-03 22:51:48 --> Helper loaded: url_helper
INFO - 2018-10-03 22:51:48 --> Helper loaded: form_helper
INFO - 2018-10-03 22:51:48 --> Helper loaded: language_helper
DEBUG - 2018-10-03 22:51:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-03 22:51:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-03 22:51:48 --> User Agent Class Initialized
INFO - 2018-10-03 22:51:48 --> Controller Class Initialized
INFO - 2018-10-03 22:51:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-03 22:51:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-03 22:51:48 --> Pixel_Model class loaded
INFO - 2018-10-03 22:51:48 --> Database Driver Class Initialized
INFO - 2018-10-03 22:51:48 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:51:48 --> Database Driver Class Initialized
INFO - 2018-10-03 22:51:48 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:51:48 --> Config Class Initialized
INFO - 2018-10-03 22:51:48 --> Hooks Class Initialized
DEBUG - 2018-10-03 22:51:48 --> UTF-8 Support Enabled
INFO - 2018-10-03 22:51:48 --> Utf8 Class Initialized
INFO - 2018-10-03 22:51:48 --> URI Class Initialized
INFO - 2018-10-03 22:51:48 --> Router Class Initialized
INFO - 2018-10-03 22:51:48 --> Output Class Initialized
INFO - 2018-10-03 22:51:48 --> Security Class Initialized
DEBUG - 2018-10-03 22:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-03 22:51:48 --> CSRF cookie sent
INFO - 2018-10-03 22:51:48 --> Input Class Initialized
INFO - 2018-10-03 22:51:48 --> Language Class Initialized
INFO - 2018-10-03 22:51:48 --> Loader Class Initialized
INFO - 2018-10-03 22:51:48 --> Helper loaded: url_helper
INFO - 2018-10-03 22:51:48 --> Helper loaded: form_helper
INFO - 2018-10-03 22:51:48 --> Helper loaded: language_helper
DEBUG - 2018-10-03 22:51:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-03 22:51:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-03 22:51:48 --> User Agent Class Initialized
INFO - 2018-10-03 22:51:48 --> Controller Class Initialized
INFO - 2018-10-03 22:51:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-03 22:51:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-03 22:51:48 --> Pixel_Model class loaded
INFO - 2018-10-03 22:51:48 --> Database Driver Class Initialized
INFO - 2018-10-03 22:51:48 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:51:48 --> Database Driver Class Initialized
INFO - 2018-10-03 22:51:48 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:51:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-03 22:51:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-03 22:51:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-03 22:51:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-03 22:51:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-03 22:51:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-03 22:51:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-03 22:51:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-03 22:51:48 --> Final output sent to browser
DEBUG - 2018-10-03 22:51:48 --> Total execution time: 0.0626
INFO - 2018-10-03 22:52:04 --> Config Class Initialized
INFO - 2018-10-03 22:52:04 --> Hooks Class Initialized
DEBUG - 2018-10-03 22:52:04 --> UTF-8 Support Enabled
INFO - 2018-10-03 22:52:04 --> Utf8 Class Initialized
INFO - 2018-10-03 22:52:04 --> URI Class Initialized
INFO - 2018-10-03 22:52:04 --> Router Class Initialized
INFO - 2018-10-03 22:52:04 --> Output Class Initialized
INFO - 2018-10-03 22:52:04 --> Security Class Initialized
DEBUG - 2018-10-03 22:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-03 22:52:04 --> CSRF cookie sent
INFO - 2018-10-03 22:52:04 --> CSRF token verified
INFO - 2018-10-03 22:52:04 --> Input Class Initialized
INFO - 2018-10-03 22:52:04 --> Language Class Initialized
INFO - 2018-10-03 22:52:04 --> Loader Class Initialized
INFO - 2018-10-03 22:52:04 --> Helper loaded: url_helper
INFO - 2018-10-03 22:52:04 --> Helper loaded: form_helper
INFO - 2018-10-03 22:52:04 --> Helper loaded: language_helper
DEBUG - 2018-10-03 22:52:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-03 22:52:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-03 22:52:04 --> User Agent Class Initialized
INFO - 2018-10-03 22:52:04 --> Controller Class Initialized
INFO - 2018-10-03 22:52:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-03 22:52:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-03 22:52:04 --> Pixel_Model class loaded
INFO - 2018-10-03 22:52:04 --> Database Driver Class Initialized
INFO - 2018-10-03 22:52:04 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:52:04 --> Form Validation Class Initialized
INFO - 2018-10-03 22:52:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-03 22:52:04 --> Database Driver Class Initialized
INFO - 2018-10-03 22:52:04 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:52:04 --> Config Class Initialized
INFO - 2018-10-03 22:52:04 --> Hooks Class Initialized
DEBUG - 2018-10-03 22:52:04 --> UTF-8 Support Enabled
INFO - 2018-10-03 22:52:04 --> Utf8 Class Initialized
INFO - 2018-10-03 22:52:04 --> URI Class Initialized
INFO - 2018-10-03 22:52:04 --> Router Class Initialized
INFO - 2018-10-03 22:52:04 --> Output Class Initialized
INFO - 2018-10-03 22:52:04 --> Security Class Initialized
DEBUG - 2018-10-03 22:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-03 22:52:04 --> CSRF cookie sent
INFO - 2018-10-03 22:52:04 --> Input Class Initialized
INFO - 2018-10-03 22:52:04 --> Language Class Initialized
INFO - 2018-10-03 22:52:04 --> Loader Class Initialized
INFO - 2018-10-03 22:52:04 --> Helper loaded: url_helper
INFO - 2018-10-03 22:52:04 --> Helper loaded: form_helper
INFO - 2018-10-03 22:52:04 --> Helper loaded: language_helper
DEBUG - 2018-10-03 22:52:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-03 22:52:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-03 22:52:04 --> User Agent Class Initialized
INFO - 2018-10-03 22:52:04 --> Controller Class Initialized
INFO - 2018-10-03 22:52:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-03 22:52:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-03 22:52:04 --> Pixel_Model class loaded
INFO - 2018-10-03 22:52:04 --> Database Driver Class Initialized
INFO - 2018-10-03 22:52:04 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:52:04 --> Database Driver Class Initialized
INFO - 2018-10-03 22:52:04 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:52:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-03 22:52:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-03 22:52:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-03 22:52:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-03 22:52:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-03 22:52:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-03 22:52:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-10-03 22:52:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-03 22:52:04 --> Final output sent to browser
DEBUG - 2018-10-03 22:52:04 --> Total execution time: 0.0546
INFO - 2018-10-03 22:52:12 --> Config Class Initialized
INFO - 2018-10-03 22:52:12 --> Hooks Class Initialized
DEBUG - 2018-10-03 22:52:12 --> UTF-8 Support Enabled
INFO - 2018-10-03 22:52:12 --> Utf8 Class Initialized
INFO - 2018-10-03 22:52:12 --> URI Class Initialized
INFO - 2018-10-03 22:52:12 --> Router Class Initialized
INFO - 2018-10-03 22:52:12 --> Output Class Initialized
INFO - 2018-10-03 22:52:12 --> Security Class Initialized
DEBUG - 2018-10-03 22:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-03 22:52:12 --> CSRF cookie sent
INFO - 2018-10-03 22:52:12 --> CSRF token verified
INFO - 2018-10-03 22:52:12 --> Input Class Initialized
INFO - 2018-10-03 22:52:12 --> Language Class Initialized
INFO - 2018-10-03 22:52:12 --> Loader Class Initialized
INFO - 2018-10-03 22:52:12 --> Helper loaded: url_helper
INFO - 2018-10-03 22:52:12 --> Helper loaded: form_helper
INFO - 2018-10-03 22:52:12 --> Helper loaded: language_helper
DEBUG - 2018-10-03 22:52:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-03 22:52:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-03 22:52:12 --> User Agent Class Initialized
INFO - 2018-10-03 22:52:12 --> Controller Class Initialized
INFO - 2018-10-03 22:52:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-03 22:52:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-03 22:52:12 --> Pixel_Model class loaded
INFO - 2018-10-03 22:52:12 --> Database Driver Class Initialized
INFO - 2018-10-03 22:52:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:52:12 --> Form Validation Class Initialized
INFO - 2018-10-03 22:52:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-03 22:52:12 --> Database Driver Class Initialized
INFO - 2018-10-03 22:52:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:52:12 --> Config Class Initialized
INFO - 2018-10-03 22:52:12 --> Hooks Class Initialized
DEBUG - 2018-10-03 22:52:12 --> UTF-8 Support Enabled
INFO - 2018-10-03 22:52:12 --> Utf8 Class Initialized
INFO - 2018-10-03 22:52:12 --> URI Class Initialized
INFO - 2018-10-03 22:52:12 --> Router Class Initialized
INFO - 2018-10-03 22:52:12 --> Output Class Initialized
INFO - 2018-10-03 22:52:12 --> Security Class Initialized
DEBUG - 2018-10-03 22:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-03 22:52:12 --> CSRF cookie sent
INFO - 2018-10-03 22:52:12 --> Input Class Initialized
INFO - 2018-10-03 22:52:12 --> Language Class Initialized
INFO - 2018-10-03 22:52:13 --> Loader Class Initialized
INFO - 2018-10-03 22:52:13 --> Helper loaded: url_helper
INFO - 2018-10-03 22:52:13 --> Helper loaded: form_helper
INFO - 2018-10-03 22:52:13 --> Helper loaded: language_helper
DEBUG - 2018-10-03 22:52:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-03 22:52:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-03 22:52:13 --> User Agent Class Initialized
INFO - 2018-10-03 22:52:13 --> Controller Class Initialized
INFO - 2018-10-03 22:52:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-03 22:52:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-03 22:52:13 --> Pixel_Model class loaded
INFO - 2018-10-03 22:52:13 --> Database Driver Class Initialized
INFO - 2018-10-03 22:52:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:52:13 --> Database Driver Class Initialized
INFO - 2018-10-03 22:52:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:52:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-03 22:52:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-03 22:52:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-10-03 22:52:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-03 22:52:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-03 22:52:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-03 22:52:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-03 22:52:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-10-03 22:52:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-03 22:52:13 --> Final output sent to browser
DEBUG - 2018-10-03 22:52:13 --> Total execution time: 0.0441
INFO - 2018-10-03 22:52:17 --> Config Class Initialized
INFO - 2018-10-03 22:52:17 --> Hooks Class Initialized
DEBUG - 2018-10-03 22:52:17 --> UTF-8 Support Enabled
INFO - 2018-10-03 22:52:17 --> Utf8 Class Initialized
INFO - 2018-10-03 22:52:17 --> URI Class Initialized
INFO - 2018-10-03 22:52:17 --> Router Class Initialized
INFO - 2018-10-03 22:52:17 --> Output Class Initialized
INFO - 2018-10-03 22:52:17 --> Security Class Initialized
DEBUG - 2018-10-03 22:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-03 22:52:17 --> CSRF cookie sent
INFO - 2018-10-03 22:52:17 --> CSRF token verified
INFO - 2018-10-03 22:52:17 --> Input Class Initialized
INFO - 2018-10-03 22:52:17 --> Language Class Initialized
INFO - 2018-10-03 22:52:17 --> Loader Class Initialized
INFO - 2018-10-03 22:52:17 --> Helper loaded: url_helper
INFO - 2018-10-03 22:52:17 --> Helper loaded: form_helper
INFO - 2018-10-03 22:52:17 --> Helper loaded: language_helper
DEBUG - 2018-10-03 22:52:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-03 22:52:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-03 22:52:17 --> User Agent Class Initialized
INFO - 2018-10-03 22:52:17 --> Controller Class Initialized
INFO - 2018-10-03 22:52:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-03 22:52:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-03 22:52:17 --> Pixel_Model class loaded
INFO - 2018-10-03 22:52:17 --> Database Driver Class Initialized
INFO - 2018-10-03 22:52:17 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:52:17 --> Form Validation Class Initialized
INFO - 2018-10-03 22:52:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-03 22:52:17 --> Database Driver Class Initialized
INFO - 2018-10-03 22:52:17 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:52:17 --> Config Class Initialized
INFO - 2018-10-03 22:52:17 --> Hooks Class Initialized
DEBUG - 2018-10-03 22:52:17 --> UTF-8 Support Enabled
INFO - 2018-10-03 22:52:17 --> Utf8 Class Initialized
INFO - 2018-10-03 22:52:17 --> URI Class Initialized
INFO - 2018-10-03 22:52:17 --> Router Class Initialized
INFO - 2018-10-03 22:52:17 --> Output Class Initialized
INFO - 2018-10-03 22:52:17 --> Security Class Initialized
DEBUG - 2018-10-03 22:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-03 22:52:17 --> CSRF cookie sent
INFO - 2018-10-03 22:52:17 --> Input Class Initialized
INFO - 2018-10-03 22:52:17 --> Language Class Initialized
INFO - 2018-10-03 22:52:17 --> Loader Class Initialized
INFO - 2018-10-03 22:52:17 --> Helper loaded: url_helper
INFO - 2018-10-03 22:52:17 --> Helper loaded: form_helper
INFO - 2018-10-03 22:52:17 --> Helper loaded: language_helper
DEBUG - 2018-10-03 22:52:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-03 22:52:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-03 22:52:17 --> User Agent Class Initialized
INFO - 2018-10-03 22:52:17 --> Controller Class Initialized
INFO - 2018-10-03 22:52:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-03 22:52:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-03 22:52:17 --> Pixel_Model class loaded
INFO - 2018-10-03 22:52:17 --> Database Driver Class Initialized
INFO - 2018-10-03 22:52:17 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:52:17 --> Database Driver Class Initialized
INFO - 2018-10-03 22:52:17 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:52:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-03 22:52:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-03 22:52:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-03 22:52:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-03 22:52:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-03 22:52:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-03 22:52:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-03 22:52:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-03 22:52:17 --> Final output sent to browser
DEBUG - 2018-10-03 22:52:17 --> Total execution time: 0.0676
INFO - 2018-10-03 22:52:27 --> Config Class Initialized
INFO - 2018-10-03 22:52:27 --> Hooks Class Initialized
DEBUG - 2018-10-03 22:52:27 --> UTF-8 Support Enabled
INFO - 2018-10-03 22:52:27 --> Utf8 Class Initialized
INFO - 2018-10-03 22:52:27 --> URI Class Initialized
INFO - 2018-10-03 22:52:27 --> Router Class Initialized
INFO - 2018-10-03 22:52:27 --> Output Class Initialized
INFO - 2018-10-03 22:52:27 --> Security Class Initialized
DEBUG - 2018-10-03 22:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-03 22:52:27 --> CSRF cookie sent
INFO - 2018-10-03 22:52:27 --> CSRF token verified
INFO - 2018-10-03 22:52:27 --> Input Class Initialized
INFO - 2018-10-03 22:52:27 --> Language Class Initialized
INFO - 2018-10-03 22:52:27 --> Loader Class Initialized
INFO - 2018-10-03 22:52:27 --> Helper loaded: url_helper
INFO - 2018-10-03 22:52:27 --> Helper loaded: form_helper
INFO - 2018-10-03 22:52:27 --> Helper loaded: language_helper
DEBUG - 2018-10-03 22:52:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-03 22:52:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-03 22:52:27 --> User Agent Class Initialized
INFO - 2018-10-03 22:52:27 --> Controller Class Initialized
INFO - 2018-10-03 22:52:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-03 22:52:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-03 22:52:27 --> Pixel_Model class loaded
INFO - 2018-10-03 22:52:27 --> Database Driver Class Initialized
INFO - 2018-10-03 22:52:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:52:27 --> Form Validation Class Initialized
INFO - 2018-10-03 22:52:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-03 22:52:27 --> Database Driver Class Initialized
INFO - 2018-10-03 22:52:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:52:28 --> Config Class Initialized
INFO - 2018-10-03 22:52:28 --> Hooks Class Initialized
DEBUG - 2018-10-03 22:52:28 --> UTF-8 Support Enabled
INFO - 2018-10-03 22:52:28 --> Utf8 Class Initialized
INFO - 2018-10-03 22:52:28 --> URI Class Initialized
INFO - 2018-10-03 22:52:28 --> Router Class Initialized
INFO - 2018-10-03 22:52:28 --> Output Class Initialized
INFO - 2018-10-03 22:52:28 --> Security Class Initialized
DEBUG - 2018-10-03 22:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-03 22:52:28 --> CSRF cookie sent
INFO - 2018-10-03 22:52:28 --> Input Class Initialized
INFO - 2018-10-03 22:52:28 --> Language Class Initialized
INFO - 2018-10-03 22:52:28 --> Loader Class Initialized
INFO - 2018-10-03 22:52:28 --> Helper loaded: url_helper
INFO - 2018-10-03 22:52:28 --> Helper loaded: form_helper
INFO - 2018-10-03 22:52:28 --> Helper loaded: language_helper
DEBUG - 2018-10-03 22:52:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-03 22:52:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-03 22:52:28 --> User Agent Class Initialized
INFO - 2018-10-03 22:52:28 --> Controller Class Initialized
INFO - 2018-10-03 22:52:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-03 22:52:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-03 22:52:28 --> Pixel_Model class loaded
INFO - 2018-10-03 22:52:28 --> Database Driver Class Initialized
INFO - 2018-10-03 22:52:28 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:52:28 --> Database Driver Class Initialized
INFO - 2018-10-03 22:52:28 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:52:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-03 22:52:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-03 22:52:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-03 22:52:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-03 22:52:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-03 22:52:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-03 22:52:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/marriage.php
INFO - 2018-10-03 22:52:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-03 22:52:28 --> Final output sent to browser
DEBUG - 2018-10-03 22:52:28 --> Total execution time: 0.0396
INFO - 2018-10-03 22:52:37 --> Config Class Initialized
INFO - 2018-10-03 22:52:37 --> Hooks Class Initialized
DEBUG - 2018-10-03 22:52:37 --> UTF-8 Support Enabled
INFO - 2018-10-03 22:52:37 --> Utf8 Class Initialized
INFO - 2018-10-03 22:52:37 --> URI Class Initialized
INFO - 2018-10-03 22:52:37 --> Router Class Initialized
INFO - 2018-10-03 22:52:37 --> Output Class Initialized
INFO - 2018-10-03 22:52:37 --> Security Class Initialized
DEBUG - 2018-10-03 22:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-03 22:52:37 --> CSRF cookie sent
INFO - 2018-10-03 22:52:37 --> CSRF token verified
INFO - 2018-10-03 22:52:37 --> Input Class Initialized
INFO - 2018-10-03 22:52:37 --> Language Class Initialized
INFO - 2018-10-03 22:52:37 --> Loader Class Initialized
INFO - 2018-10-03 22:52:37 --> Helper loaded: url_helper
INFO - 2018-10-03 22:52:37 --> Helper loaded: form_helper
INFO - 2018-10-03 22:52:37 --> Helper loaded: language_helper
DEBUG - 2018-10-03 22:52:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-03 22:52:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-03 22:52:37 --> User Agent Class Initialized
INFO - 2018-10-03 22:52:37 --> Controller Class Initialized
INFO - 2018-10-03 22:52:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-03 22:52:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-03 22:52:37 --> Pixel_Model class loaded
INFO - 2018-10-03 22:52:37 --> Database Driver Class Initialized
INFO - 2018-10-03 22:52:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:52:37 --> Form Validation Class Initialized
INFO - 2018-10-03 22:52:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-03 22:52:37 --> Database Driver Class Initialized
INFO - 2018-10-03 22:52:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:52:37 --> Config Class Initialized
INFO - 2018-10-03 22:52:37 --> Hooks Class Initialized
DEBUG - 2018-10-03 22:52:37 --> UTF-8 Support Enabled
INFO - 2018-10-03 22:52:37 --> Utf8 Class Initialized
INFO - 2018-10-03 22:52:37 --> URI Class Initialized
INFO - 2018-10-03 22:52:37 --> Router Class Initialized
INFO - 2018-10-03 22:52:37 --> Output Class Initialized
INFO - 2018-10-03 22:52:37 --> Security Class Initialized
DEBUG - 2018-10-03 22:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-03 22:52:37 --> CSRF cookie sent
INFO - 2018-10-03 22:52:37 --> Input Class Initialized
INFO - 2018-10-03 22:52:37 --> Language Class Initialized
INFO - 2018-10-03 22:52:37 --> Loader Class Initialized
INFO - 2018-10-03 22:52:37 --> Helper loaded: url_helper
INFO - 2018-10-03 22:52:37 --> Helper loaded: form_helper
INFO - 2018-10-03 22:52:37 --> Helper loaded: language_helper
DEBUG - 2018-10-03 22:52:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-03 22:52:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-03 22:52:37 --> User Agent Class Initialized
INFO - 2018-10-03 22:52:37 --> Controller Class Initialized
INFO - 2018-10-03 22:52:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-03 22:52:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-03 22:52:37 --> Pixel_Model class loaded
INFO - 2018-10-03 22:52:37 --> Database Driver Class Initialized
INFO - 2018-10-03 22:52:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:52:37 --> Database Driver Class Initialized
INFO - 2018-10-03 22:52:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:52:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-03 22:52:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-03 22:52:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-03 22:52:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-03 22:52:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-03 22:52:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-03 22:52:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-10-03 22:52:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-03 22:52:37 --> Final output sent to browser
DEBUG - 2018-10-03 22:52:37 --> Total execution time: 0.0395
INFO - 2018-10-03 22:52:43 --> Config Class Initialized
INFO - 2018-10-03 22:52:43 --> Hooks Class Initialized
DEBUG - 2018-10-03 22:52:43 --> UTF-8 Support Enabled
INFO - 2018-10-03 22:52:43 --> Utf8 Class Initialized
INFO - 2018-10-03 22:52:43 --> URI Class Initialized
INFO - 2018-10-03 22:52:43 --> Router Class Initialized
INFO - 2018-10-03 22:52:43 --> Output Class Initialized
INFO - 2018-10-03 22:52:43 --> Security Class Initialized
DEBUG - 2018-10-03 22:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-03 22:52:43 --> CSRF cookie sent
INFO - 2018-10-03 22:52:43 --> CSRF token verified
INFO - 2018-10-03 22:52:43 --> Input Class Initialized
INFO - 2018-10-03 22:52:43 --> Language Class Initialized
INFO - 2018-10-03 22:52:43 --> Loader Class Initialized
INFO - 2018-10-03 22:52:43 --> Helper loaded: url_helper
INFO - 2018-10-03 22:52:43 --> Helper loaded: form_helper
INFO - 2018-10-03 22:52:43 --> Helper loaded: language_helper
DEBUG - 2018-10-03 22:52:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-03 22:52:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-03 22:52:43 --> User Agent Class Initialized
INFO - 2018-10-03 22:52:43 --> Controller Class Initialized
INFO - 2018-10-03 22:52:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-03 22:52:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-03 22:52:43 --> Pixel_Model class loaded
INFO - 2018-10-03 22:52:43 --> Database Driver Class Initialized
INFO - 2018-10-03 22:52:43 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:52:43 --> Form Validation Class Initialized
INFO - 2018-10-03 22:52:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-03 22:52:43 --> Database Driver Class Initialized
INFO - 2018-10-03 22:52:43 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:52:43 --> Config Class Initialized
INFO - 2018-10-03 22:52:43 --> Hooks Class Initialized
DEBUG - 2018-10-03 22:52:43 --> UTF-8 Support Enabled
INFO - 2018-10-03 22:52:43 --> Utf8 Class Initialized
INFO - 2018-10-03 22:52:43 --> URI Class Initialized
INFO - 2018-10-03 22:52:43 --> Router Class Initialized
INFO - 2018-10-03 22:52:43 --> Output Class Initialized
INFO - 2018-10-03 22:52:43 --> Security Class Initialized
DEBUG - 2018-10-03 22:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-03 22:52:43 --> CSRF cookie sent
INFO - 2018-10-03 22:52:43 --> Input Class Initialized
INFO - 2018-10-03 22:52:43 --> Language Class Initialized
INFO - 2018-10-03 22:52:43 --> Loader Class Initialized
INFO - 2018-10-03 22:52:43 --> Helper loaded: url_helper
INFO - 2018-10-03 22:52:43 --> Helper loaded: form_helper
INFO - 2018-10-03 22:52:43 --> Helper loaded: language_helper
DEBUG - 2018-10-03 22:52:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-03 22:52:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-03 22:52:43 --> User Agent Class Initialized
INFO - 2018-10-03 22:52:43 --> Controller Class Initialized
INFO - 2018-10-03 22:52:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-03 22:52:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-03 22:52:43 --> Pixel_Model class loaded
INFO - 2018-10-03 22:52:43 --> Database Driver Class Initialized
INFO - 2018-10-03 22:52:43 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:52:43 --> Database Driver Class Initialized
INFO - 2018-10-03 22:52:43 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:52:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-03 22:52:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-03 22:52:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-03 22:52:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-03 22:52:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-03 22:52:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-03 22:52:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-10-03 22:52:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-03 22:52:43 --> Final output sent to browser
DEBUG - 2018-10-03 22:52:43 --> Total execution time: 0.0476
INFO - 2018-10-03 22:52:51 --> Config Class Initialized
INFO - 2018-10-03 22:52:51 --> Hooks Class Initialized
DEBUG - 2018-10-03 22:52:51 --> UTF-8 Support Enabled
INFO - 2018-10-03 22:52:51 --> Utf8 Class Initialized
INFO - 2018-10-03 22:52:51 --> URI Class Initialized
INFO - 2018-10-03 22:52:51 --> Router Class Initialized
INFO - 2018-10-03 22:52:51 --> Output Class Initialized
INFO - 2018-10-03 22:52:51 --> Security Class Initialized
DEBUG - 2018-10-03 22:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-03 22:52:51 --> CSRF cookie sent
INFO - 2018-10-03 22:52:51 --> CSRF token verified
INFO - 2018-10-03 22:52:51 --> Input Class Initialized
INFO - 2018-10-03 22:52:51 --> Language Class Initialized
INFO - 2018-10-03 22:52:51 --> Loader Class Initialized
INFO - 2018-10-03 22:52:51 --> Helper loaded: url_helper
INFO - 2018-10-03 22:52:51 --> Helper loaded: form_helper
INFO - 2018-10-03 22:52:51 --> Helper loaded: language_helper
DEBUG - 2018-10-03 22:52:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-03 22:52:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-03 22:52:51 --> User Agent Class Initialized
INFO - 2018-10-03 22:52:51 --> Controller Class Initialized
INFO - 2018-10-03 22:52:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-03 22:52:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-03 22:52:51 --> Pixel_Model class loaded
INFO - 2018-10-03 22:52:51 --> Database Driver Class Initialized
INFO - 2018-10-03 22:52:51 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:52:51 --> Form Validation Class Initialized
INFO - 2018-10-03 22:52:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-03 22:52:51 --> Database Driver Class Initialized
INFO - 2018-10-03 22:52:51 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:52:52 --> Config Class Initialized
INFO - 2018-10-03 22:52:52 --> Hooks Class Initialized
DEBUG - 2018-10-03 22:52:52 --> UTF-8 Support Enabled
INFO - 2018-10-03 22:52:52 --> Utf8 Class Initialized
INFO - 2018-10-03 22:52:52 --> URI Class Initialized
INFO - 2018-10-03 22:52:52 --> Router Class Initialized
INFO - 2018-10-03 22:52:52 --> Output Class Initialized
INFO - 2018-10-03 22:52:52 --> Security Class Initialized
DEBUG - 2018-10-03 22:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-03 22:52:52 --> CSRF cookie sent
INFO - 2018-10-03 22:52:52 --> Input Class Initialized
INFO - 2018-10-03 22:52:52 --> Language Class Initialized
INFO - 2018-10-03 22:52:52 --> Loader Class Initialized
INFO - 2018-10-03 22:52:52 --> Helper loaded: url_helper
INFO - 2018-10-03 22:52:52 --> Helper loaded: form_helper
INFO - 2018-10-03 22:52:52 --> Helper loaded: language_helper
DEBUG - 2018-10-03 22:52:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-03 22:52:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-03 22:52:52 --> User Agent Class Initialized
INFO - 2018-10-03 22:52:52 --> Controller Class Initialized
INFO - 2018-10-03 22:52:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-03 22:52:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-03 22:52:52 --> Pixel_Model class loaded
INFO - 2018-10-03 22:52:52 --> Database Driver Class Initialized
INFO - 2018-10-03 22:52:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:52:52 --> Database Driver Class Initialized
INFO - 2018-10-03 22:52:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:52:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-03 22:52:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-03 22:52:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-03 22:52:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-03 22:52:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-03 22:52:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-03 22:52:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-10-03 22:52:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-03 22:52:52 --> Final output sent to browser
DEBUG - 2018-10-03 22:52:52 --> Total execution time: 0.0508
INFO - 2018-10-03 22:53:05 --> Config Class Initialized
INFO - 2018-10-03 22:53:05 --> Hooks Class Initialized
DEBUG - 2018-10-03 22:53:05 --> UTF-8 Support Enabled
INFO - 2018-10-03 22:53:05 --> Utf8 Class Initialized
INFO - 2018-10-03 22:53:05 --> URI Class Initialized
INFO - 2018-10-03 22:53:05 --> Router Class Initialized
INFO - 2018-10-03 22:53:05 --> Output Class Initialized
INFO - 2018-10-03 22:53:05 --> Security Class Initialized
DEBUG - 2018-10-03 22:53:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-03 22:53:05 --> CSRF cookie sent
INFO - 2018-10-03 22:53:05 --> CSRF token verified
INFO - 2018-10-03 22:53:05 --> Input Class Initialized
INFO - 2018-10-03 22:53:05 --> Language Class Initialized
INFO - 2018-10-03 22:53:05 --> Loader Class Initialized
INFO - 2018-10-03 22:53:05 --> Helper loaded: url_helper
INFO - 2018-10-03 22:53:05 --> Helper loaded: form_helper
INFO - 2018-10-03 22:53:05 --> Helper loaded: language_helper
DEBUG - 2018-10-03 22:53:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-03 22:53:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-03 22:53:05 --> User Agent Class Initialized
INFO - 2018-10-03 22:53:05 --> Controller Class Initialized
INFO - 2018-10-03 22:53:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-03 22:53:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-03 22:53:05 --> Pixel_Model class loaded
INFO - 2018-10-03 22:53:05 --> Database Driver Class Initialized
INFO - 2018-10-03 22:53:05 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:53:05 --> Form Validation Class Initialized
INFO - 2018-10-03 22:53:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-03 22:53:05 --> Database Driver Class Initialized
INFO - 2018-10-03 22:53:05 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:53:05 --> Config Class Initialized
INFO - 2018-10-03 22:53:05 --> Hooks Class Initialized
DEBUG - 2018-10-03 22:53:05 --> UTF-8 Support Enabled
INFO - 2018-10-03 22:53:05 --> Utf8 Class Initialized
INFO - 2018-10-03 22:53:05 --> URI Class Initialized
INFO - 2018-10-03 22:53:05 --> Router Class Initialized
INFO - 2018-10-03 22:53:05 --> Output Class Initialized
INFO - 2018-10-03 22:53:05 --> Security Class Initialized
DEBUG - 2018-10-03 22:53:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-03 22:53:05 --> CSRF cookie sent
INFO - 2018-10-03 22:53:05 --> Input Class Initialized
INFO - 2018-10-03 22:53:05 --> Language Class Initialized
INFO - 2018-10-03 22:53:05 --> Loader Class Initialized
INFO - 2018-10-03 22:53:05 --> Helper loaded: url_helper
INFO - 2018-10-03 22:53:05 --> Helper loaded: form_helper
INFO - 2018-10-03 22:53:05 --> Helper loaded: language_helper
DEBUG - 2018-10-03 22:53:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-03 22:53:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-03 22:53:05 --> User Agent Class Initialized
INFO - 2018-10-03 22:53:05 --> Controller Class Initialized
INFO - 2018-10-03 22:53:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-03 22:53:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-03 22:53:05 --> Pixel_Model class loaded
INFO - 2018-10-03 22:53:05 --> Database Driver Class Initialized
INFO - 2018-10-03 22:53:05 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:53:05 --> Database Driver Class Initialized
INFO - 2018-10-03 22:53:05 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:53:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-03 22:53:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-03 22:53:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-03 22:53:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-03 22:53:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-03 22:53:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-03 22:53:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-10-03 22:53:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-03 22:53:05 --> Final output sent to browser
DEBUG - 2018-10-03 22:53:05 --> Total execution time: 0.0460
INFO - 2018-10-03 22:53:12 --> Config Class Initialized
INFO - 2018-10-03 22:53:12 --> Hooks Class Initialized
DEBUG - 2018-10-03 22:53:12 --> UTF-8 Support Enabled
INFO - 2018-10-03 22:53:12 --> Utf8 Class Initialized
INFO - 2018-10-03 22:53:12 --> URI Class Initialized
INFO - 2018-10-03 22:53:12 --> Router Class Initialized
INFO - 2018-10-03 22:53:12 --> Output Class Initialized
INFO - 2018-10-03 22:53:12 --> Security Class Initialized
DEBUG - 2018-10-03 22:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-03 22:53:12 --> CSRF cookie sent
INFO - 2018-10-03 22:53:12 --> CSRF token verified
INFO - 2018-10-03 22:53:12 --> Input Class Initialized
INFO - 2018-10-03 22:53:12 --> Language Class Initialized
INFO - 2018-10-03 22:53:12 --> Loader Class Initialized
INFO - 2018-10-03 22:53:12 --> Helper loaded: url_helper
INFO - 2018-10-03 22:53:12 --> Helper loaded: form_helper
INFO - 2018-10-03 22:53:12 --> Helper loaded: language_helper
DEBUG - 2018-10-03 22:53:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-03 22:53:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-03 22:53:12 --> User Agent Class Initialized
INFO - 2018-10-03 22:53:12 --> Controller Class Initialized
INFO - 2018-10-03 22:53:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-03 22:53:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-03 22:53:12 --> Pixel_Model class loaded
INFO - 2018-10-03 22:53:12 --> Database Driver Class Initialized
INFO - 2018-10-03 22:53:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:53:12 --> Form Validation Class Initialized
INFO - 2018-10-03 22:53:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-03 22:53:12 --> Database Driver Class Initialized
INFO - 2018-10-03 22:53:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:53:12 --> Config Class Initialized
INFO - 2018-10-03 22:53:12 --> Hooks Class Initialized
DEBUG - 2018-10-03 22:53:12 --> UTF-8 Support Enabled
INFO - 2018-10-03 22:53:12 --> Utf8 Class Initialized
INFO - 2018-10-03 22:53:12 --> URI Class Initialized
INFO - 2018-10-03 22:53:12 --> Router Class Initialized
INFO - 2018-10-03 22:53:12 --> Output Class Initialized
INFO - 2018-10-03 22:53:12 --> Security Class Initialized
DEBUG - 2018-10-03 22:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-03 22:53:12 --> CSRF cookie sent
INFO - 2018-10-03 22:53:12 --> Input Class Initialized
INFO - 2018-10-03 22:53:12 --> Language Class Initialized
INFO - 2018-10-03 22:53:12 --> Loader Class Initialized
INFO - 2018-10-03 22:53:12 --> Helper loaded: url_helper
INFO - 2018-10-03 22:53:12 --> Helper loaded: form_helper
INFO - 2018-10-03 22:53:12 --> Helper loaded: language_helper
DEBUG - 2018-10-03 22:53:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-03 22:53:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-03 22:53:12 --> User Agent Class Initialized
INFO - 2018-10-03 22:53:12 --> Controller Class Initialized
INFO - 2018-10-03 22:53:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-03 22:53:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-03 22:53:12 --> Pixel_Model class loaded
INFO - 2018-10-03 22:53:12 --> Database Driver Class Initialized
INFO - 2018-10-03 22:53:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:53:12 --> Database Driver Class Initialized
INFO - 2018-10-03 22:53:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:53:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-03 22:53:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-03 22:53:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-03 22:53:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-03 22:53:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-03 22:53:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-03 22:53:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_owner.php
INFO - 2018-10-03 22:53:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-03 22:53:12 --> Final output sent to browser
DEBUG - 2018-10-03 22:53:12 --> Total execution time: 0.0463
INFO - 2018-10-03 22:53:14 --> Config Class Initialized
INFO - 2018-10-03 22:53:14 --> Hooks Class Initialized
DEBUG - 2018-10-03 22:53:14 --> UTF-8 Support Enabled
INFO - 2018-10-03 22:53:14 --> Utf8 Class Initialized
INFO - 2018-10-03 22:53:14 --> URI Class Initialized
INFO - 2018-10-03 22:53:14 --> Router Class Initialized
INFO - 2018-10-03 22:53:14 --> Output Class Initialized
INFO - 2018-10-03 22:53:14 --> Security Class Initialized
DEBUG - 2018-10-03 22:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-03 22:53:14 --> CSRF cookie sent
INFO - 2018-10-03 22:53:14 --> CSRF token verified
INFO - 2018-10-03 22:53:14 --> Input Class Initialized
INFO - 2018-10-03 22:53:14 --> Language Class Initialized
INFO - 2018-10-03 22:53:14 --> Loader Class Initialized
INFO - 2018-10-03 22:53:14 --> Helper loaded: url_helper
INFO - 2018-10-03 22:53:14 --> Helper loaded: form_helper
INFO - 2018-10-03 22:53:14 --> Helper loaded: language_helper
DEBUG - 2018-10-03 22:53:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-03 22:53:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-03 22:53:14 --> User Agent Class Initialized
INFO - 2018-10-03 22:53:14 --> Controller Class Initialized
INFO - 2018-10-03 22:53:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-03 22:53:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-03 22:53:14 --> Pixel_Model class loaded
INFO - 2018-10-03 22:53:14 --> Database Driver Class Initialized
INFO - 2018-10-03 22:53:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:53:14 --> Form Validation Class Initialized
INFO - 2018-10-03 22:53:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-03 22:53:14 --> Database Driver Class Initialized
INFO - 2018-10-03 22:53:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:53:15 --> Config Class Initialized
INFO - 2018-10-03 22:53:15 --> Hooks Class Initialized
DEBUG - 2018-10-03 22:53:15 --> UTF-8 Support Enabled
INFO - 2018-10-03 22:53:15 --> Utf8 Class Initialized
INFO - 2018-10-03 22:53:15 --> URI Class Initialized
INFO - 2018-10-03 22:53:15 --> Router Class Initialized
INFO - 2018-10-03 22:53:15 --> Output Class Initialized
INFO - 2018-10-03 22:53:15 --> Security Class Initialized
DEBUG - 2018-10-03 22:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-03 22:53:15 --> CSRF cookie sent
INFO - 2018-10-03 22:53:15 --> Input Class Initialized
INFO - 2018-10-03 22:53:15 --> Language Class Initialized
INFO - 2018-10-03 22:53:15 --> Loader Class Initialized
INFO - 2018-10-03 22:53:15 --> Helper loaded: url_helper
INFO - 2018-10-03 22:53:15 --> Helper loaded: form_helper
INFO - 2018-10-03 22:53:15 --> Helper loaded: language_helper
DEBUG - 2018-10-03 22:53:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-03 22:53:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-03 22:53:15 --> User Agent Class Initialized
INFO - 2018-10-03 22:53:15 --> Controller Class Initialized
INFO - 2018-10-03 22:53:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-03 22:53:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-03 22:53:15 --> Pixel_Model class loaded
INFO - 2018-10-03 22:53:15 --> Database Driver Class Initialized
INFO - 2018-10-03 22:53:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:53:15 --> Database Driver Class Initialized
INFO - 2018-10-03 22:53:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:53:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-03 22:53:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-03 22:53:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-03 22:53:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-03 22:53:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-03 22:53:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-03 22:53:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_value.php
INFO - 2018-10-03 22:53:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-03 22:53:15 --> Final output sent to browser
DEBUG - 2018-10-03 22:53:15 --> Total execution time: 0.0514
INFO - 2018-10-03 22:53:28 --> Config Class Initialized
INFO - 2018-10-03 22:53:28 --> Hooks Class Initialized
DEBUG - 2018-10-03 22:53:28 --> UTF-8 Support Enabled
INFO - 2018-10-03 22:53:28 --> Utf8 Class Initialized
INFO - 2018-10-03 22:53:28 --> URI Class Initialized
INFO - 2018-10-03 22:53:28 --> Router Class Initialized
INFO - 2018-10-03 22:53:28 --> Output Class Initialized
INFO - 2018-10-03 22:53:28 --> Security Class Initialized
DEBUG - 2018-10-03 22:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-03 22:53:28 --> CSRF cookie sent
INFO - 2018-10-03 22:53:28 --> CSRF token verified
INFO - 2018-10-03 22:53:28 --> Input Class Initialized
INFO - 2018-10-03 22:53:28 --> Language Class Initialized
INFO - 2018-10-03 22:53:28 --> Loader Class Initialized
INFO - 2018-10-03 22:53:28 --> Helper loaded: url_helper
INFO - 2018-10-03 22:53:28 --> Helper loaded: form_helper
INFO - 2018-10-03 22:53:28 --> Helper loaded: language_helper
DEBUG - 2018-10-03 22:53:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-03 22:53:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-03 22:53:28 --> User Agent Class Initialized
INFO - 2018-10-03 22:53:28 --> Controller Class Initialized
INFO - 2018-10-03 22:53:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-03 22:53:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-03 22:53:28 --> Pixel_Model class loaded
INFO - 2018-10-03 22:53:28 --> Database Driver Class Initialized
INFO - 2018-10-03 22:53:28 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:53:28 --> Form Validation Class Initialized
INFO - 2018-10-03 22:53:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-03 22:53:28 --> Database Driver Class Initialized
INFO - 2018-10-03 22:53:28 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:53:28 --> Config Class Initialized
INFO - 2018-10-03 22:53:28 --> Hooks Class Initialized
DEBUG - 2018-10-03 22:53:28 --> UTF-8 Support Enabled
INFO - 2018-10-03 22:53:28 --> Utf8 Class Initialized
INFO - 2018-10-03 22:53:28 --> URI Class Initialized
INFO - 2018-10-03 22:53:28 --> Router Class Initialized
INFO - 2018-10-03 22:53:28 --> Output Class Initialized
INFO - 2018-10-03 22:53:28 --> Security Class Initialized
DEBUG - 2018-10-03 22:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-03 22:53:28 --> CSRF cookie sent
INFO - 2018-10-03 22:53:28 --> Input Class Initialized
INFO - 2018-10-03 22:53:28 --> Language Class Initialized
INFO - 2018-10-03 22:53:28 --> Loader Class Initialized
INFO - 2018-10-03 22:53:28 --> Helper loaded: url_helper
INFO - 2018-10-03 22:53:28 --> Helper loaded: form_helper
INFO - 2018-10-03 22:53:28 --> Helper loaded: language_helper
DEBUG - 2018-10-03 22:53:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-03 22:53:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-03 22:53:28 --> User Agent Class Initialized
INFO - 2018-10-03 22:53:28 --> Controller Class Initialized
INFO - 2018-10-03 22:53:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-03 22:53:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-03 22:53:28 --> Pixel_Model class loaded
INFO - 2018-10-03 22:53:28 --> Database Driver Class Initialized
INFO - 2018-10-03 22:53:28 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:53:28 --> Database Driver Class Initialized
INFO - 2018-10-03 22:53:28 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:53:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-03 22:53:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-03 22:53:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-03 22:53:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-03 22:53:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-03 22:53:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-03 22:53:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/merriage_home_title.php
INFO - 2018-10-03 22:53:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-03 22:53:28 --> Final output sent to browser
DEBUG - 2018-10-03 22:53:28 --> Total execution time: 0.0686
INFO - 2018-10-03 22:53:35 --> Config Class Initialized
INFO - 2018-10-03 22:53:35 --> Hooks Class Initialized
DEBUG - 2018-10-03 22:53:35 --> UTF-8 Support Enabled
INFO - 2018-10-03 22:53:35 --> Utf8 Class Initialized
INFO - 2018-10-03 22:53:35 --> URI Class Initialized
INFO - 2018-10-03 22:53:35 --> Router Class Initialized
INFO - 2018-10-03 22:53:35 --> Output Class Initialized
INFO - 2018-10-03 22:53:35 --> Security Class Initialized
DEBUG - 2018-10-03 22:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-03 22:53:35 --> CSRF cookie sent
INFO - 2018-10-03 22:53:35 --> CSRF token verified
INFO - 2018-10-03 22:53:35 --> Input Class Initialized
INFO - 2018-10-03 22:53:35 --> Language Class Initialized
INFO - 2018-10-03 22:53:35 --> Loader Class Initialized
INFO - 2018-10-03 22:53:35 --> Helper loaded: url_helper
INFO - 2018-10-03 22:53:35 --> Helper loaded: form_helper
INFO - 2018-10-03 22:53:35 --> Helper loaded: language_helper
DEBUG - 2018-10-03 22:53:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-03 22:53:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-03 22:53:35 --> User Agent Class Initialized
INFO - 2018-10-03 22:53:35 --> Controller Class Initialized
INFO - 2018-10-03 22:53:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-03 22:53:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-03 22:53:35 --> Pixel_Model class loaded
INFO - 2018-10-03 22:53:35 --> Database Driver Class Initialized
INFO - 2018-10-03 22:53:35 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:53:35 --> Form Validation Class Initialized
INFO - 2018-10-03 22:53:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-03 22:53:35 --> Database Driver Class Initialized
INFO - 2018-10-03 22:53:35 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:53:35 --> Config Class Initialized
INFO - 2018-10-03 22:53:35 --> Hooks Class Initialized
DEBUG - 2018-10-03 22:53:35 --> UTF-8 Support Enabled
INFO - 2018-10-03 22:53:35 --> Utf8 Class Initialized
INFO - 2018-10-03 22:53:35 --> URI Class Initialized
INFO - 2018-10-03 22:53:35 --> Router Class Initialized
INFO - 2018-10-03 22:53:35 --> Output Class Initialized
INFO - 2018-10-03 22:53:35 --> Security Class Initialized
DEBUG - 2018-10-03 22:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-03 22:53:35 --> CSRF cookie sent
INFO - 2018-10-03 22:53:35 --> Input Class Initialized
INFO - 2018-10-03 22:53:35 --> Language Class Initialized
INFO - 2018-10-03 22:53:35 --> Loader Class Initialized
INFO - 2018-10-03 22:53:35 --> Helper loaded: url_helper
INFO - 2018-10-03 22:53:35 --> Helper loaded: form_helper
INFO - 2018-10-03 22:53:35 --> Helper loaded: language_helper
DEBUG - 2018-10-03 22:53:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-03 22:53:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-03 22:53:35 --> User Agent Class Initialized
INFO - 2018-10-03 22:53:35 --> Controller Class Initialized
INFO - 2018-10-03 22:53:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-03 22:53:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-03 22:53:35 --> Pixel_Model class loaded
INFO - 2018-10-03 22:53:35 --> Database Driver Class Initialized
INFO - 2018-10-03 22:53:35 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:53:35 --> Database Driver Class Initialized
INFO - 2018-10-03 22:53:35 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:53:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-03 22:53:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-03 22:53:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-03 22:53:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-03 22:53:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-03 22:53:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-03 22:53:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-10-03 22:53:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-03 22:53:35 --> Final output sent to browser
DEBUG - 2018-10-03 22:53:35 --> Total execution time: 0.0557
INFO - 2018-10-03 22:53:42 --> Config Class Initialized
INFO - 2018-10-03 22:53:42 --> Hooks Class Initialized
DEBUG - 2018-10-03 22:53:42 --> UTF-8 Support Enabled
INFO - 2018-10-03 22:53:42 --> Utf8 Class Initialized
INFO - 2018-10-03 22:53:42 --> URI Class Initialized
INFO - 2018-10-03 22:53:42 --> Router Class Initialized
INFO - 2018-10-03 22:53:42 --> Output Class Initialized
INFO - 2018-10-03 22:53:42 --> Security Class Initialized
DEBUG - 2018-10-03 22:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-03 22:53:42 --> CSRF cookie sent
INFO - 2018-10-03 22:53:42 --> CSRF token verified
INFO - 2018-10-03 22:53:42 --> Input Class Initialized
INFO - 2018-10-03 22:53:42 --> Language Class Initialized
INFO - 2018-10-03 22:53:42 --> Loader Class Initialized
INFO - 2018-10-03 22:53:42 --> Helper loaded: url_helper
INFO - 2018-10-03 22:53:42 --> Helper loaded: form_helper
INFO - 2018-10-03 22:53:42 --> Helper loaded: language_helper
DEBUG - 2018-10-03 22:53:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-03 22:53:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-03 22:53:42 --> User Agent Class Initialized
INFO - 2018-10-03 22:53:42 --> Controller Class Initialized
INFO - 2018-10-03 22:53:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-03 22:53:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-03 22:53:42 --> Pixel_Model class loaded
INFO - 2018-10-03 22:53:42 --> Database Driver Class Initialized
INFO - 2018-10-03 22:53:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:53:42 --> Form Validation Class Initialized
INFO - 2018-10-03 22:53:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-03 22:53:42 --> Database Driver Class Initialized
INFO - 2018-10-03 22:53:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:53:42 --> Config Class Initialized
INFO - 2018-10-03 22:53:42 --> Hooks Class Initialized
DEBUG - 2018-10-03 22:53:42 --> UTF-8 Support Enabled
INFO - 2018-10-03 22:53:42 --> Utf8 Class Initialized
INFO - 2018-10-03 22:53:42 --> URI Class Initialized
INFO - 2018-10-03 22:53:42 --> Router Class Initialized
INFO - 2018-10-03 22:53:42 --> Output Class Initialized
INFO - 2018-10-03 22:53:42 --> Security Class Initialized
DEBUG - 2018-10-03 22:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-03 22:53:42 --> CSRF cookie sent
INFO - 2018-10-03 22:53:42 --> Input Class Initialized
INFO - 2018-10-03 22:53:42 --> Language Class Initialized
INFO - 2018-10-03 22:53:42 --> Loader Class Initialized
INFO - 2018-10-03 22:53:42 --> Helper loaded: url_helper
INFO - 2018-10-03 22:53:42 --> Helper loaded: form_helper
INFO - 2018-10-03 22:53:42 --> Helper loaded: language_helper
DEBUG - 2018-10-03 22:53:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-03 22:53:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-03 22:53:42 --> User Agent Class Initialized
INFO - 2018-10-03 22:53:42 --> Controller Class Initialized
INFO - 2018-10-03 22:53:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-03 22:53:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-03 22:53:42 --> Pixel_Model class loaded
INFO - 2018-10-03 22:53:42 --> Database Driver Class Initialized
INFO - 2018-10-03 22:53:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:53:42 --> Database Driver Class Initialized
INFO - 2018-10-03 22:53:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:53:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-03 22:53:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-03 22:53:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-03 22:53:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-03 22:53:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-10-03 22:53:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-03 22:53:42 --> Final output sent to browser
DEBUG - 2018-10-03 22:53:42 --> Total execution time: 0.0566
INFO - 2018-10-03 22:54:11 --> Config Class Initialized
INFO - 2018-10-03 22:54:11 --> Hooks Class Initialized
DEBUG - 2018-10-03 22:54:11 --> UTF-8 Support Enabled
INFO - 2018-10-03 22:54:11 --> Utf8 Class Initialized
INFO - 2018-10-03 22:54:11 --> URI Class Initialized
INFO - 2018-10-03 22:54:11 --> Router Class Initialized
INFO - 2018-10-03 22:54:11 --> Output Class Initialized
INFO - 2018-10-03 22:54:11 --> Security Class Initialized
DEBUG - 2018-10-03 22:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-03 22:54:11 --> CSRF cookie sent
INFO - 2018-10-03 22:54:11 --> Input Class Initialized
INFO - 2018-10-03 22:54:11 --> Language Class Initialized
INFO - 2018-10-03 22:54:11 --> Loader Class Initialized
INFO - 2018-10-03 22:54:11 --> Helper loaded: url_helper
INFO - 2018-10-03 22:54:11 --> Helper loaded: form_helper
INFO - 2018-10-03 22:54:11 --> Helper loaded: language_helper
DEBUG - 2018-10-03 22:54:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-03 22:54:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-03 22:54:11 --> User Agent Class Initialized
INFO - 2018-10-03 22:54:11 --> Controller Class Initialized
INFO - 2018-10-03 22:54:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-03 22:54:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-03 22:54:11 --> Pixel_Model class loaded
INFO - 2018-10-03 22:54:11 --> Database Driver Class Initialized
INFO - 2018-10-03 22:54:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:54:11 --> Config Class Initialized
INFO - 2018-10-03 22:54:11 --> Hooks Class Initialized
DEBUG - 2018-10-03 22:54:11 --> UTF-8 Support Enabled
INFO - 2018-10-03 22:54:11 --> Utf8 Class Initialized
INFO - 2018-10-03 22:54:11 --> URI Class Initialized
INFO - 2018-10-03 22:54:11 --> Router Class Initialized
INFO - 2018-10-03 22:54:11 --> Output Class Initialized
INFO - 2018-10-03 22:54:11 --> Security Class Initialized
DEBUG - 2018-10-03 22:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-03 22:54:11 --> CSRF cookie sent
INFO - 2018-10-03 22:54:11 --> Input Class Initialized
INFO - 2018-10-03 22:54:11 --> Language Class Initialized
INFO - 2018-10-03 22:54:11 --> Loader Class Initialized
INFO - 2018-10-03 22:54:11 --> Helper loaded: url_helper
INFO - 2018-10-03 22:54:11 --> Helper loaded: form_helper
INFO - 2018-10-03 22:54:11 --> Helper loaded: language_helper
DEBUG - 2018-10-03 22:54:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-03 22:54:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-03 22:54:11 --> User Agent Class Initialized
INFO - 2018-10-03 22:54:11 --> Controller Class Initialized
INFO - 2018-10-03 22:54:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-03 22:54:11 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-03 22:54:11 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-10-03 22:54:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-03 22:54:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-03 22:54:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-03 22:54:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-10-03 22:54:11 --> Could not find the language line "req_email"
INFO - 2018-10-03 22:54:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-10-03 22:54:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-03 22:54:11 --> Final output sent to browser
DEBUG - 2018-10-03 22:54:11 --> Total execution time: 0.0200
INFO - 2018-10-03 22:54:14 --> Config Class Initialized
INFO - 2018-10-03 22:54:14 --> Hooks Class Initialized
DEBUG - 2018-10-03 22:54:14 --> UTF-8 Support Enabled
INFO - 2018-10-03 22:54:14 --> Utf8 Class Initialized
INFO - 2018-10-03 22:54:14 --> URI Class Initialized
INFO - 2018-10-03 22:54:14 --> Router Class Initialized
INFO - 2018-10-03 22:54:14 --> Output Class Initialized
INFO - 2018-10-03 22:54:14 --> Security Class Initialized
DEBUG - 2018-10-03 22:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-03 22:54:14 --> CSRF cookie sent
INFO - 2018-10-03 22:54:14 --> Input Class Initialized
INFO - 2018-10-03 22:54:14 --> Language Class Initialized
INFO - 2018-10-03 22:54:14 --> Loader Class Initialized
INFO - 2018-10-03 22:54:14 --> Helper loaded: url_helper
INFO - 2018-10-03 22:54:14 --> Helper loaded: form_helper
INFO - 2018-10-03 22:54:14 --> Helper loaded: language_helper
DEBUG - 2018-10-03 22:54:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-03 22:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-03 22:54:14 --> User Agent Class Initialized
INFO - 2018-10-03 22:54:14 --> Controller Class Initialized
INFO - 2018-10-03 22:54:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-03 22:54:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-03 22:54:14 --> Pixel_Model class loaded
INFO - 2018-10-03 22:54:14 --> Database Driver Class Initialized
INFO - 2018-10-03 22:54:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:54:14 --> Database Driver Class Initialized
INFO - 2018-10-03 22:54:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:54:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-03 22:54:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-03 22:54:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-03 22:54:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-03 22:54:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-10-03 22:54:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-03 22:54:14 --> Final output sent to browser
DEBUG - 2018-10-03 22:54:14 --> Total execution time: 0.0649
INFO - 2018-10-03 22:54:15 --> Config Class Initialized
INFO - 2018-10-03 22:54:15 --> Hooks Class Initialized
DEBUG - 2018-10-03 22:54:15 --> UTF-8 Support Enabled
INFO - 2018-10-03 22:54:15 --> Utf8 Class Initialized
INFO - 2018-10-03 22:54:15 --> URI Class Initialized
INFO - 2018-10-03 22:54:15 --> Router Class Initialized
INFO - 2018-10-03 22:54:15 --> Output Class Initialized
INFO - 2018-10-03 22:54:15 --> Security Class Initialized
DEBUG - 2018-10-03 22:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-03 22:54:15 --> CSRF cookie sent
INFO - 2018-10-03 22:54:15 --> Input Class Initialized
INFO - 2018-10-03 22:54:15 --> Language Class Initialized
INFO - 2018-10-03 22:54:15 --> Loader Class Initialized
INFO - 2018-10-03 22:54:15 --> Helper loaded: url_helper
INFO - 2018-10-03 22:54:15 --> Helper loaded: form_helper
INFO - 2018-10-03 22:54:15 --> Helper loaded: language_helper
DEBUG - 2018-10-03 22:54:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-03 22:54:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-03 22:54:15 --> User Agent Class Initialized
INFO - 2018-10-03 22:54:15 --> Controller Class Initialized
INFO - 2018-10-03 22:54:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-03 22:54:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-03 22:54:15 --> Pixel_Model class loaded
INFO - 2018-10-03 22:54:15 --> Database Driver Class Initialized
INFO - 2018-10-03 22:54:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:54:15 --> Database Driver Class Initialized
INFO - 2018-10-03 22:54:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:54:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-03 22:54:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-03 22:54:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-03 22:54:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-03 22:54:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-03 22:54:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-03 22:54:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-10-03 22:54:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-03 22:54:15 --> Final output sent to browser
DEBUG - 2018-10-03 22:54:15 --> Total execution time: 0.0469
INFO - 2018-10-03 22:54:19 --> Config Class Initialized
INFO - 2018-10-03 22:54:19 --> Hooks Class Initialized
DEBUG - 2018-10-03 22:54:19 --> UTF-8 Support Enabled
INFO - 2018-10-03 22:54:19 --> Utf8 Class Initialized
INFO - 2018-10-03 22:54:19 --> URI Class Initialized
INFO - 2018-10-03 22:54:19 --> Router Class Initialized
INFO - 2018-10-03 22:54:19 --> Output Class Initialized
INFO - 2018-10-03 22:54:19 --> Security Class Initialized
DEBUG - 2018-10-03 22:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-03 22:54:19 --> CSRF cookie sent
INFO - 2018-10-03 22:54:19 --> Input Class Initialized
INFO - 2018-10-03 22:54:19 --> Language Class Initialized
INFO - 2018-10-03 22:54:19 --> Loader Class Initialized
INFO - 2018-10-03 22:54:19 --> Helper loaded: url_helper
INFO - 2018-10-03 22:54:19 --> Helper loaded: form_helper
INFO - 2018-10-03 22:54:19 --> Helper loaded: language_helper
DEBUG - 2018-10-03 22:54:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-03 22:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-03 22:54:19 --> User Agent Class Initialized
INFO - 2018-10-03 22:54:19 --> Controller Class Initialized
INFO - 2018-10-03 22:54:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-03 22:54:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-03 22:54:20 --> Pixel_Model class loaded
INFO - 2018-10-03 22:54:20 --> Database Driver Class Initialized
INFO - 2018-10-03 22:54:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:54:20 --> Database Driver Class Initialized
INFO - 2018-10-03 22:54:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:54:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-03 22:54:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-03 22:54:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-03 22:54:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-03 22:54:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-03 22:54:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-03 22:54:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/merriage_home_title.php
INFO - 2018-10-03 22:54:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-03 22:54:20 --> Final output sent to browser
DEBUG - 2018-10-03 22:54:20 --> Total execution time: 0.0451
INFO - 2018-10-03 22:54:23 --> Config Class Initialized
INFO - 2018-10-03 22:54:23 --> Hooks Class Initialized
DEBUG - 2018-10-03 22:54:23 --> UTF-8 Support Enabled
INFO - 2018-10-03 22:54:23 --> Utf8 Class Initialized
INFO - 2018-10-03 22:54:23 --> URI Class Initialized
INFO - 2018-10-03 22:54:23 --> Router Class Initialized
INFO - 2018-10-03 22:54:23 --> Output Class Initialized
INFO - 2018-10-03 22:54:23 --> Security Class Initialized
DEBUG - 2018-10-03 22:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-03 22:54:23 --> CSRF cookie sent
INFO - 2018-10-03 22:54:23 --> Input Class Initialized
INFO - 2018-10-03 22:54:23 --> Language Class Initialized
INFO - 2018-10-03 22:54:23 --> Loader Class Initialized
INFO - 2018-10-03 22:54:23 --> Helper loaded: url_helper
INFO - 2018-10-03 22:54:23 --> Helper loaded: form_helper
INFO - 2018-10-03 22:54:23 --> Helper loaded: language_helper
DEBUG - 2018-10-03 22:54:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-03 22:54:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-03 22:54:23 --> User Agent Class Initialized
INFO - 2018-10-03 22:54:23 --> Controller Class Initialized
INFO - 2018-10-03 22:54:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-03 22:54:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-03 22:54:23 --> Pixel_Model class loaded
INFO - 2018-10-03 22:54:23 --> Database Driver Class Initialized
INFO - 2018-10-03 22:54:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:54:23 --> Database Driver Class Initialized
INFO - 2018-10-03 22:54:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:54:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-03 22:54:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-03 22:54:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-03 22:54:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-03 22:54:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-03 22:54:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-03 22:54:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_value.php
INFO - 2018-10-03 22:54:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-03 22:54:23 --> Final output sent to browser
DEBUG - 2018-10-03 22:54:23 --> Total execution time: 0.0498
INFO - 2018-10-03 22:54:37 --> Config Class Initialized
INFO - 2018-10-03 22:54:37 --> Hooks Class Initialized
DEBUG - 2018-10-03 22:54:37 --> UTF-8 Support Enabled
INFO - 2018-10-03 22:54:37 --> Utf8 Class Initialized
INFO - 2018-10-03 22:54:37 --> URI Class Initialized
INFO - 2018-10-03 22:54:37 --> Router Class Initialized
INFO - 2018-10-03 22:54:37 --> Output Class Initialized
INFO - 2018-10-03 22:54:37 --> Security Class Initialized
DEBUG - 2018-10-03 22:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-03 22:54:37 --> CSRF cookie sent
INFO - 2018-10-03 22:54:37 --> Input Class Initialized
INFO - 2018-10-03 22:54:37 --> Language Class Initialized
INFO - 2018-10-03 22:54:37 --> Loader Class Initialized
INFO - 2018-10-03 22:54:37 --> Helper loaded: url_helper
INFO - 2018-10-03 22:54:37 --> Helper loaded: form_helper
INFO - 2018-10-03 22:54:37 --> Helper loaded: language_helper
DEBUG - 2018-10-03 22:54:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-03 22:54:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-03 22:54:37 --> User Agent Class Initialized
INFO - 2018-10-03 22:54:37 --> Controller Class Initialized
INFO - 2018-10-03 22:54:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-03 22:54:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-03 22:54:37 --> Pixel_Model class loaded
INFO - 2018-10-03 22:54:37 --> Database Driver Class Initialized
INFO - 2018-10-03 22:54:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:54:37 --> Database Driver Class Initialized
INFO - 2018-10-03 22:54:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:54:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-03 22:54:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-03 22:54:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-03 22:54:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-03 22:54:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-03 22:54:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-03 22:54:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/merriage_home_title.php
INFO - 2018-10-03 22:54:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-03 22:54:37 --> Final output sent to browser
DEBUG - 2018-10-03 22:54:37 --> Total execution time: 0.0466
INFO - 2018-10-03 22:54:38 --> Config Class Initialized
INFO - 2018-10-03 22:54:38 --> Hooks Class Initialized
DEBUG - 2018-10-03 22:54:38 --> UTF-8 Support Enabled
INFO - 2018-10-03 22:54:38 --> Utf8 Class Initialized
INFO - 2018-10-03 22:54:38 --> URI Class Initialized
INFO - 2018-10-03 22:54:38 --> Router Class Initialized
INFO - 2018-10-03 22:54:38 --> Output Class Initialized
INFO - 2018-10-03 22:54:38 --> Security Class Initialized
DEBUG - 2018-10-03 22:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-03 22:54:38 --> CSRF cookie sent
INFO - 2018-10-03 22:54:38 --> Input Class Initialized
INFO - 2018-10-03 22:54:38 --> Language Class Initialized
INFO - 2018-10-03 22:54:38 --> Loader Class Initialized
INFO - 2018-10-03 22:54:38 --> Helper loaded: url_helper
INFO - 2018-10-03 22:54:38 --> Helper loaded: form_helper
INFO - 2018-10-03 22:54:38 --> Helper loaded: language_helper
DEBUG - 2018-10-03 22:54:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-03 22:54:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-03 22:54:38 --> User Agent Class Initialized
INFO - 2018-10-03 22:54:38 --> Controller Class Initialized
INFO - 2018-10-03 22:54:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-03 22:54:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-03 22:54:38 --> Pixel_Model class loaded
INFO - 2018-10-03 22:54:38 --> Database Driver Class Initialized
INFO - 2018-10-03 22:54:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:54:38 --> Database Driver Class Initialized
INFO - 2018-10-03 22:54:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:54:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-03 22:54:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-03 22:54:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-03 22:54:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-03 22:54:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-03 22:54:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-03 22:54:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-10-03 22:54:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-03 22:54:38 --> Final output sent to browser
DEBUG - 2018-10-03 22:54:38 --> Total execution time: 0.0571
INFO - 2018-10-03 22:54:40 --> Config Class Initialized
INFO - 2018-10-03 22:54:40 --> Hooks Class Initialized
DEBUG - 2018-10-03 22:54:40 --> UTF-8 Support Enabled
INFO - 2018-10-03 22:54:40 --> Utf8 Class Initialized
INFO - 2018-10-03 22:54:40 --> URI Class Initialized
INFO - 2018-10-03 22:54:40 --> Router Class Initialized
INFO - 2018-10-03 22:54:40 --> Output Class Initialized
INFO - 2018-10-03 22:54:40 --> Security Class Initialized
DEBUG - 2018-10-03 22:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-03 22:54:40 --> CSRF cookie sent
INFO - 2018-10-03 22:54:40 --> Input Class Initialized
INFO - 2018-10-03 22:54:40 --> Language Class Initialized
INFO - 2018-10-03 22:54:40 --> Loader Class Initialized
INFO - 2018-10-03 22:54:40 --> Helper loaded: url_helper
INFO - 2018-10-03 22:54:40 --> Helper loaded: form_helper
INFO - 2018-10-03 22:54:40 --> Helper loaded: language_helper
DEBUG - 2018-10-03 22:54:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-03 22:54:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-03 22:54:40 --> User Agent Class Initialized
INFO - 2018-10-03 22:54:40 --> Controller Class Initialized
INFO - 2018-10-03 22:54:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-03 22:54:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-03 22:54:40 --> Pixel_Model class loaded
INFO - 2018-10-03 22:54:40 --> Database Driver Class Initialized
INFO - 2018-10-03 22:54:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:54:40 --> Database Driver Class Initialized
INFO - 2018-10-03 22:54:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:54:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-03 22:54:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-03 22:54:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-03 22:54:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-03 22:54:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-10-03 22:54:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-03 22:54:40 --> Final output sent to browser
DEBUG - 2018-10-03 22:54:40 --> Total execution time: 0.0561
INFO - 2018-10-03 22:54:44 --> Config Class Initialized
INFO - 2018-10-03 22:54:44 --> Hooks Class Initialized
DEBUG - 2018-10-03 22:54:44 --> UTF-8 Support Enabled
INFO - 2018-10-03 22:54:44 --> Utf8 Class Initialized
INFO - 2018-10-03 22:54:44 --> URI Class Initialized
INFO - 2018-10-03 22:54:44 --> Router Class Initialized
INFO - 2018-10-03 22:54:44 --> Output Class Initialized
INFO - 2018-10-03 22:54:44 --> Security Class Initialized
DEBUG - 2018-10-03 22:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-03 22:54:44 --> CSRF cookie sent
INFO - 2018-10-03 22:54:44 --> Input Class Initialized
INFO - 2018-10-03 22:54:44 --> Language Class Initialized
INFO - 2018-10-03 22:54:44 --> Loader Class Initialized
INFO - 2018-10-03 22:54:44 --> Helper loaded: url_helper
INFO - 2018-10-03 22:54:44 --> Helper loaded: form_helper
INFO - 2018-10-03 22:54:44 --> Helper loaded: language_helper
DEBUG - 2018-10-03 22:54:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-03 22:54:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-03 22:54:44 --> User Agent Class Initialized
INFO - 2018-10-03 22:54:44 --> Controller Class Initialized
INFO - 2018-10-03 22:54:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-03 22:54:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-03 22:54:44 --> Pixel_Model class loaded
INFO - 2018-10-03 22:54:44 --> Database Driver Class Initialized
INFO - 2018-10-03 22:54:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:54:44 --> Database Driver Class Initialized
INFO - 2018-10-03 22:54:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:54:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-03 22:54:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-03 22:54:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-03 22:54:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-03 22:54:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-03 22:54:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-03 22:54:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-10-03 22:54:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-03 22:54:44 --> Final output sent to browser
DEBUG - 2018-10-03 22:54:44 --> Total execution time: 0.0467
INFO - 2018-10-03 22:54:45 --> Config Class Initialized
INFO - 2018-10-03 22:54:45 --> Hooks Class Initialized
DEBUG - 2018-10-03 22:54:45 --> UTF-8 Support Enabled
INFO - 2018-10-03 22:54:45 --> Utf8 Class Initialized
INFO - 2018-10-03 22:54:45 --> URI Class Initialized
INFO - 2018-10-03 22:54:45 --> Router Class Initialized
INFO - 2018-10-03 22:54:45 --> Output Class Initialized
INFO - 2018-10-03 22:54:45 --> Security Class Initialized
DEBUG - 2018-10-03 22:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-03 22:54:45 --> CSRF cookie sent
INFO - 2018-10-03 22:54:45 --> Input Class Initialized
INFO - 2018-10-03 22:54:45 --> Language Class Initialized
INFO - 2018-10-03 22:54:45 --> Loader Class Initialized
INFO - 2018-10-03 22:54:45 --> Helper loaded: url_helper
INFO - 2018-10-03 22:54:45 --> Helper loaded: form_helper
INFO - 2018-10-03 22:54:45 --> Helper loaded: language_helper
DEBUG - 2018-10-03 22:54:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-03 22:54:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-03 22:54:45 --> User Agent Class Initialized
INFO - 2018-10-03 22:54:45 --> Controller Class Initialized
INFO - 2018-10-03 22:54:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-03 22:54:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-03 22:54:45 --> Pixel_Model class loaded
INFO - 2018-10-03 22:54:45 --> Database Driver Class Initialized
INFO - 2018-10-03 22:54:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:54:45 --> Database Driver Class Initialized
INFO - 2018-10-03 22:54:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:54:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-03 22:54:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-03 22:54:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-03 22:54:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-03 22:54:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-03 22:54:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-03 22:54:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/merriage_home_title.php
INFO - 2018-10-03 22:54:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-03 22:54:45 --> Final output sent to browser
DEBUG - 2018-10-03 22:54:45 --> Total execution time: 0.0536
INFO - 2018-10-03 22:54:46 --> Config Class Initialized
INFO - 2018-10-03 22:54:46 --> Hooks Class Initialized
DEBUG - 2018-10-03 22:54:46 --> UTF-8 Support Enabled
INFO - 2018-10-03 22:54:46 --> Utf8 Class Initialized
INFO - 2018-10-03 22:54:46 --> URI Class Initialized
INFO - 2018-10-03 22:54:46 --> Router Class Initialized
INFO - 2018-10-03 22:54:46 --> Output Class Initialized
INFO - 2018-10-03 22:54:46 --> Security Class Initialized
DEBUG - 2018-10-03 22:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-03 22:54:46 --> CSRF cookie sent
INFO - 2018-10-03 22:54:46 --> Input Class Initialized
INFO - 2018-10-03 22:54:46 --> Language Class Initialized
INFO - 2018-10-03 22:54:46 --> Loader Class Initialized
INFO - 2018-10-03 22:54:46 --> Helper loaded: url_helper
INFO - 2018-10-03 22:54:46 --> Helper loaded: form_helper
INFO - 2018-10-03 22:54:46 --> Helper loaded: language_helper
DEBUG - 2018-10-03 22:54:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-03 22:54:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-03 22:54:46 --> User Agent Class Initialized
INFO - 2018-10-03 22:54:46 --> Controller Class Initialized
INFO - 2018-10-03 22:54:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-03 22:54:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-03 22:54:46 --> Pixel_Model class loaded
INFO - 2018-10-03 22:54:46 --> Database Driver Class Initialized
INFO - 2018-10-03 22:54:46 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:54:46 --> Database Driver Class Initialized
INFO - 2018-10-03 22:54:46 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:54:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-03 22:54:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-03 22:54:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-03 22:54:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-03 22:54:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-03 22:54:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-03 22:54:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_value.php
INFO - 2018-10-03 22:54:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-03 22:54:46 --> Final output sent to browser
DEBUG - 2018-10-03 22:54:46 --> Total execution time: 0.0386
INFO - 2018-10-03 22:54:51 --> Config Class Initialized
INFO - 2018-10-03 22:54:51 --> Hooks Class Initialized
DEBUG - 2018-10-03 22:54:51 --> UTF-8 Support Enabled
INFO - 2018-10-03 22:54:51 --> Utf8 Class Initialized
INFO - 2018-10-03 22:54:51 --> URI Class Initialized
INFO - 2018-10-03 22:54:51 --> Router Class Initialized
INFO - 2018-10-03 22:54:51 --> Output Class Initialized
INFO - 2018-10-03 22:54:51 --> Security Class Initialized
DEBUG - 2018-10-03 22:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-03 22:54:51 --> CSRF cookie sent
INFO - 2018-10-03 22:54:51 --> Input Class Initialized
INFO - 2018-10-03 22:54:51 --> Language Class Initialized
INFO - 2018-10-03 22:54:51 --> Loader Class Initialized
INFO - 2018-10-03 22:54:51 --> Helper loaded: url_helper
INFO - 2018-10-03 22:54:51 --> Helper loaded: form_helper
INFO - 2018-10-03 22:54:51 --> Helper loaded: language_helper
DEBUG - 2018-10-03 22:54:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-03 22:54:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-03 22:54:51 --> User Agent Class Initialized
INFO - 2018-10-03 22:54:51 --> Controller Class Initialized
INFO - 2018-10-03 22:54:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-03 22:54:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-03 22:54:51 --> Pixel_Model class loaded
INFO - 2018-10-03 22:54:51 --> Database Driver Class Initialized
INFO - 2018-10-03 22:54:51 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:54:51 --> Database Driver Class Initialized
INFO - 2018-10-03 22:54:51 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:54:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-03 22:54:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-03 22:54:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-03 22:54:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-03 22:54:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-03 22:54:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-03 22:54:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_owner.php
INFO - 2018-10-03 22:54:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-03 22:54:51 --> Final output sent to browser
DEBUG - 2018-10-03 22:54:51 --> Total execution time: 0.0711
INFO - 2018-10-03 22:54:52 --> Config Class Initialized
INFO - 2018-10-03 22:54:52 --> Hooks Class Initialized
DEBUG - 2018-10-03 22:54:52 --> UTF-8 Support Enabled
INFO - 2018-10-03 22:54:52 --> Utf8 Class Initialized
INFO - 2018-10-03 22:54:52 --> URI Class Initialized
INFO - 2018-10-03 22:54:52 --> Router Class Initialized
INFO - 2018-10-03 22:54:52 --> Output Class Initialized
INFO - 2018-10-03 22:54:52 --> Security Class Initialized
DEBUG - 2018-10-03 22:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-03 22:54:52 --> CSRF cookie sent
INFO - 2018-10-03 22:54:52 --> Input Class Initialized
INFO - 2018-10-03 22:54:52 --> Language Class Initialized
INFO - 2018-10-03 22:54:52 --> Loader Class Initialized
INFO - 2018-10-03 22:54:52 --> Helper loaded: url_helper
INFO - 2018-10-03 22:54:52 --> Helper loaded: form_helper
INFO - 2018-10-03 22:54:52 --> Helper loaded: language_helper
DEBUG - 2018-10-03 22:54:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-03 22:54:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-03 22:54:52 --> User Agent Class Initialized
INFO - 2018-10-03 22:54:52 --> Controller Class Initialized
INFO - 2018-10-03 22:54:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-03 22:54:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-03 22:54:52 --> Pixel_Model class loaded
INFO - 2018-10-03 22:54:52 --> Database Driver Class Initialized
INFO - 2018-10-03 22:54:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:54:52 --> Database Driver Class Initialized
INFO - 2018-10-03 22:54:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:54:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-03 22:54:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-03 22:54:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-03 22:54:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-03 22:54:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-03 22:54:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-03 22:54:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-10-03 22:54:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-03 22:54:52 --> Final output sent to browser
DEBUG - 2018-10-03 22:54:52 --> Total execution time: 0.0544
INFO - 2018-10-03 22:54:58 --> Config Class Initialized
INFO - 2018-10-03 22:54:58 --> Hooks Class Initialized
DEBUG - 2018-10-03 22:54:58 --> UTF-8 Support Enabled
INFO - 2018-10-03 22:54:58 --> Utf8 Class Initialized
INFO - 2018-10-03 22:54:58 --> URI Class Initialized
INFO - 2018-10-03 22:54:58 --> Router Class Initialized
INFO - 2018-10-03 22:54:58 --> Output Class Initialized
INFO - 2018-10-03 22:54:58 --> Security Class Initialized
DEBUG - 2018-10-03 22:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-03 22:54:58 --> CSRF cookie sent
INFO - 2018-10-03 22:54:58 --> Input Class Initialized
INFO - 2018-10-03 22:54:58 --> Language Class Initialized
INFO - 2018-10-03 22:54:58 --> Loader Class Initialized
INFO - 2018-10-03 22:54:58 --> Helper loaded: url_helper
INFO - 2018-10-03 22:54:58 --> Helper loaded: form_helper
INFO - 2018-10-03 22:54:58 --> Helper loaded: language_helper
DEBUG - 2018-10-03 22:54:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-03 22:54:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-03 22:54:58 --> User Agent Class Initialized
INFO - 2018-10-03 22:54:58 --> Controller Class Initialized
INFO - 2018-10-03 22:54:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-03 22:54:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-03 22:54:58 --> Pixel_Model class loaded
INFO - 2018-10-03 22:54:58 --> Database Driver Class Initialized
INFO - 2018-10-03 22:54:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:54:58 --> Database Driver Class Initialized
INFO - 2018-10-03 22:54:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:54:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-03 22:54:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-03 22:54:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-03 22:54:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-03 22:54:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-03 22:54:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-03 22:54:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-10-03 22:54:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-03 22:54:58 --> Final output sent to browser
DEBUG - 2018-10-03 22:54:58 --> Total execution time: 0.0656
INFO - 2018-10-03 22:55:01 --> Config Class Initialized
INFO - 2018-10-03 22:55:01 --> Hooks Class Initialized
DEBUG - 2018-10-03 22:55:01 --> UTF-8 Support Enabled
INFO - 2018-10-03 22:55:01 --> Utf8 Class Initialized
INFO - 2018-10-03 22:55:01 --> URI Class Initialized
INFO - 2018-10-03 22:55:01 --> Router Class Initialized
INFO - 2018-10-03 22:55:01 --> Output Class Initialized
INFO - 2018-10-03 22:55:01 --> Security Class Initialized
DEBUG - 2018-10-03 22:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-03 22:55:01 --> CSRF cookie sent
INFO - 2018-10-03 22:55:01 --> Input Class Initialized
INFO - 2018-10-03 22:55:01 --> Language Class Initialized
INFO - 2018-10-03 22:55:01 --> Loader Class Initialized
INFO - 2018-10-03 22:55:01 --> Helper loaded: url_helper
INFO - 2018-10-03 22:55:01 --> Helper loaded: form_helper
INFO - 2018-10-03 22:55:01 --> Helper loaded: language_helper
DEBUG - 2018-10-03 22:55:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-03 22:55:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-03 22:55:01 --> User Agent Class Initialized
INFO - 2018-10-03 22:55:01 --> Controller Class Initialized
INFO - 2018-10-03 22:55:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-03 22:55:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-03 22:55:01 --> Pixel_Model class loaded
INFO - 2018-10-03 22:55:01 --> Database Driver Class Initialized
INFO - 2018-10-03 22:55:01 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:55:01 --> Database Driver Class Initialized
INFO - 2018-10-03 22:55:01 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:55:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-03 22:55:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-03 22:55:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-03 22:55:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-03 22:55:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-03 22:55:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-03 22:55:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-10-03 22:55:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-03 22:55:01 --> Final output sent to browser
DEBUG - 2018-10-03 22:55:01 --> Total execution time: 0.0686
INFO - 2018-10-03 22:55:06 --> Config Class Initialized
INFO - 2018-10-03 22:55:06 --> Hooks Class Initialized
DEBUG - 2018-10-03 22:55:06 --> UTF-8 Support Enabled
INFO - 2018-10-03 22:55:06 --> Utf8 Class Initialized
INFO - 2018-10-03 22:55:06 --> URI Class Initialized
INFO - 2018-10-03 22:55:06 --> Router Class Initialized
INFO - 2018-10-03 22:55:06 --> Output Class Initialized
INFO - 2018-10-03 22:55:06 --> Security Class Initialized
DEBUG - 2018-10-03 22:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-03 22:55:06 --> CSRF cookie sent
INFO - 2018-10-03 22:55:06 --> Input Class Initialized
INFO - 2018-10-03 22:55:06 --> Language Class Initialized
INFO - 2018-10-03 22:55:06 --> Loader Class Initialized
INFO - 2018-10-03 22:55:06 --> Helper loaded: url_helper
INFO - 2018-10-03 22:55:06 --> Helper loaded: form_helper
INFO - 2018-10-03 22:55:06 --> Helper loaded: language_helper
DEBUG - 2018-10-03 22:55:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-03 22:55:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-03 22:55:06 --> User Agent Class Initialized
INFO - 2018-10-03 22:55:06 --> Controller Class Initialized
INFO - 2018-10-03 22:55:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-03 22:55:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-03 22:55:06 --> Pixel_Model class loaded
INFO - 2018-10-03 22:55:06 --> Database Driver Class Initialized
INFO - 2018-10-03 22:55:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:55:06 --> Database Driver Class Initialized
INFO - 2018-10-03 22:55:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:55:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-03 22:55:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-03 22:55:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-03 22:55:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-03 22:55:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-03 22:55:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-03 22:55:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_owner.php
INFO - 2018-10-03 22:55:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-03 22:55:06 --> Final output sent to browser
DEBUG - 2018-10-03 22:55:06 --> Total execution time: 0.0455
INFO - 2018-10-03 22:55:07 --> Config Class Initialized
INFO - 2018-10-03 22:55:07 --> Hooks Class Initialized
DEBUG - 2018-10-03 22:55:07 --> UTF-8 Support Enabled
INFO - 2018-10-03 22:55:07 --> Utf8 Class Initialized
INFO - 2018-10-03 22:55:07 --> URI Class Initialized
INFO - 2018-10-03 22:55:07 --> Router Class Initialized
INFO - 2018-10-03 22:55:07 --> Output Class Initialized
INFO - 2018-10-03 22:55:07 --> Security Class Initialized
DEBUG - 2018-10-03 22:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-03 22:55:07 --> CSRF cookie sent
INFO - 2018-10-03 22:55:07 --> Input Class Initialized
INFO - 2018-10-03 22:55:07 --> Language Class Initialized
INFO - 2018-10-03 22:55:07 --> Loader Class Initialized
INFO - 2018-10-03 22:55:07 --> Helper loaded: url_helper
INFO - 2018-10-03 22:55:07 --> Helper loaded: form_helper
INFO - 2018-10-03 22:55:07 --> Helper loaded: language_helper
DEBUG - 2018-10-03 22:55:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-03 22:55:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-03 22:55:07 --> User Agent Class Initialized
INFO - 2018-10-03 22:55:07 --> Controller Class Initialized
INFO - 2018-10-03 22:55:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-03 22:55:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-03 22:55:07 --> Pixel_Model class loaded
INFO - 2018-10-03 22:55:07 --> Database Driver Class Initialized
INFO - 2018-10-03 22:55:07 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:55:07 --> Database Driver Class Initialized
INFO - 2018-10-03 22:55:07 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:55:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-03 22:55:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-03 22:55:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-03 22:55:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-03 22:55:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-03 22:55:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-03 22:55:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-10-03 22:55:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-03 22:55:07 --> Final output sent to browser
DEBUG - 2018-10-03 22:55:07 --> Total execution time: 0.0668
INFO - 2018-10-03 22:55:08 --> Config Class Initialized
INFO - 2018-10-03 22:55:08 --> Hooks Class Initialized
DEBUG - 2018-10-03 22:55:08 --> UTF-8 Support Enabled
INFO - 2018-10-03 22:55:08 --> Utf8 Class Initialized
INFO - 2018-10-03 22:55:08 --> URI Class Initialized
INFO - 2018-10-03 22:55:08 --> Router Class Initialized
INFO - 2018-10-03 22:55:08 --> Output Class Initialized
INFO - 2018-10-03 22:55:08 --> Security Class Initialized
DEBUG - 2018-10-03 22:55:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-03 22:55:08 --> CSRF cookie sent
INFO - 2018-10-03 22:55:08 --> Input Class Initialized
INFO - 2018-10-03 22:55:08 --> Language Class Initialized
INFO - 2018-10-03 22:55:08 --> Loader Class Initialized
INFO - 2018-10-03 22:55:08 --> Helper loaded: url_helper
INFO - 2018-10-03 22:55:08 --> Helper loaded: form_helper
INFO - 2018-10-03 22:55:08 --> Helper loaded: language_helper
DEBUG - 2018-10-03 22:55:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-03 22:55:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-03 22:55:08 --> User Agent Class Initialized
INFO - 2018-10-03 22:55:08 --> Controller Class Initialized
INFO - 2018-10-03 22:55:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-03 22:55:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-03 22:55:08 --> Pixel_Model class loaded
INFO - 2018-10-03 22:55:08 --> Database Driver Class Initialized
INFO - 2018-10-03 22:55:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:55:08 --> Database Driver Class Initialized
INFO - 2018-10-03 22:55:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:55:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-03 22:55:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-03 22:55:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-03 22:55:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-03 22:55:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-03 22:55:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-03 22:55:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-10-03 22:55:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-03 22:55:08 --> Final output sent to browser
DEBUG - 2018-10-03 22:55:08 --> Total execution time: 0.0527
INFO - 2018-10-03 22:55:14 --> Config Class Initialized
INFO - 2018-10-03 22:55:14 --> Hooks Class Initialized
DEBUG - 2018-10-03 22:55:14 --> UTF-8 Support Enabled
INFO - 2018-10-03 22:55:14 --> Utf8 Class Initialized
INFO - 2018-10-03 22:55:14 --> URI Class Initialized
INFO - 2018-10-03 22:55:14 --> Router Class Initialized
INFO - 2018-10-03 22:55:14 --> Output Class Initialized
INFO - 2018-10-03 22:55:14 --> Security Class Initialized
DEBUG - 2018-10-03 22:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-03 22:55:14 --> CSRF cookie sent
INFO - 2018-10-03 22:55:14 --> Input Class Initialized
INFO - 2018-10-03 22:55:14 --> Language Class Initialized
INFO - 2018-10-03 22:55:14 --> Loader Class Initialized
INFO - 2018-10-03 22:55:14 --> Helper loaded: url_helper
INFO - 2018-10-03 22:55:14 --> Helper loaded: form_helper
INFO - 2018-10-03 22:55:14 --> Helper loaded: language_helper
DEBUG - 2018-10-03 22:55:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-03 22:55:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-03 22:55:14 --> User Agent Class Initialized
INFO - 2018-10-03 22:55:14 --> Controller Class Initialized
INFO - 2018-10-03 22:55:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-03 22:55:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-03 22:55:14 --> Pixel_Model class loaded
INFO - 2018-10-03 22:55:14 --> Database Driver Class Initialized
INFO - 2018-10-03 22:55:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:55:14 --> Database Driver Class Initialized
INFO - 2018-10-03 22:55:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:55:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-03 22:55:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-03 22:55:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-03 22:55:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-03 22:55:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-03 22:55:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-03 22:55:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-10-03 22:55:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-03 22:55:14 --> Final output sent to browser
DEBUG - 2018-10-03 22:55:14 --> Total execution time: 0.0490
INFO - 2018-10-03 22:55:18 --> Config Class Initialized
INFO - 2018-10-03 22:55:18 --> Hooks Class Initialized
DEBUG - 2018-10-03 22:55:18 --> UTF-8 Support Enabled
INFO - 2018-10-03 22:55:18 --> Utf8 Class Initialized
INFO - 2018-10-03 22:55:18 --> URI Class Initialized
INFO - 2018-10-03 22:55:18 --> Router Class Initialized
INFO - 2018-10-03 22:55:18 --> Output Class Initialized
INFO - 2018-10-03 22:55:18 --> Security Class Initialized
DEBUG - 2018-10-03 22:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-03 22:55:18 --> CSRF cookie sent
INFO - 2018-10-03 22:55:18 --> Input Class Initialized
INFO - 2018-10-03 22:55:18 --> Language Class Initialized
INFO - 2018-10-03 22:55:18 --> Loader Class Initialized
INFO - 2018-10-03 22:55:18 --> Helper loaded: url_helper
INFO - 2018-10-03 22:55:18 --> Helper loaded: form_helper
INFO - 2018-10-03 22:55:18 --> Helper loaded: language_helper
DEBUG - 2018-10-03 22:55:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-03 22:55:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-03 22:55:18 --> User Agent Class Initialized
INFO - 2018-10-03 22:55:18 --> Controller Class Initialized
INFO - 2018-10-03 22:55:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-03 22:55:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-03 22:55:18 --> Pixel_Model class loaded
INFO - 2018-10-03 22:55:18 --> Database Driver Class Initialized
INFO - 2018-10-03 22:55:18 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:55:18 --> Database Driver Class Initialized
INFO - 2018-10-03 22:55:18 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:55:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-03 22:55:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-03 22:55:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-03 22:55:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-03 22:55:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-03 22:55:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-03 22:55:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-10-03 22:55:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-03 22:55:18 --> Final output sent to browser
DEBUG - 2018-10-03 22:55:18 --> Total execution time: 0.0384
INFO - 2018-10-03 22:55:20 --> Config Class Initialized
INFO - 2018-10-03 22:55:20 --> Hooks Class Initialized
DEBUG - 2018-10-03 22:55:20 --> UTF-8 Support Enabled
INFO - 2018-10-03 22:55:20 --> Utf8 Class Initialized
INFO - 2018-10-03 22:55:20 --> URI Class Initialized
INFO - 2018-10-03 22:55:20 --> Router Class Initialized
INFO - 2018-10-03 22:55:20 --> Output Class Initialized
INFO - 2018-10-03 22:55:20 --> Security Class Initialized
DEBUG - 2018-10-03 22:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-03 22:55:20 --> CSRF cookie sent
INFO - 2018-10-03 22:55:20 --> Input Class Initialized
INFO - 2018-10-03 22:55:20 --> Language Class Initialized
INFO - 2018-10-03 22:55:20 --> Loader Class Initialized
INFO - 2018-10-03 22:55:20 --> Helper loaded: url_helper
INFO - 2018-10-03 22:55:20 --> Helper loaded: form_helper
INFO - 2018-10-03 22:55:20 --> Helper loaded: language_helper
DEBUG - 2018-10-03 22:55:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-03 22:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-03 22:55:20 --> User Agent Class Initialized
INFO - 2018-10-03 22:55:20 --> Controller Class Initialized
INFO - 2018-10-03 22:55:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-03 22:55:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-03 22:55:20 --> Pixel_Model class loaded
INFO - 2018-10-03 22:55:20 --> Database Driver Class Initialized
INFO - 2018-10-03 22:55:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:55:20 --> Database Driver Class Initialized
INFO - 2018-10-03 22:55:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:55:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-03 22:55:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-03 22:55:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-03 22:55:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-03 22:55:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-03 22:55:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-03 22:55:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/marriage.php
INFO - 2018-10-03 22:55:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-03 22:55:20 --> Final output sent to browser
DEBUG - 2018-10-03 22:55:20 --> Total execution time: 0.0449
INFO - 2018-10-03 22:55:21 --> Config Class Initialized
INFO - 2018-10-03 22:55:21 --> Hooks Class Initialized
DEBUG - 2018-10-03 22:55:21 --> UTF-8 Support Enabled
INFO - 2018-10-03 22:55:21 --> Utf8 Class Initialized
INFO - 2018-10-03 22:55:21 --> URI Class Initialized
INFO - 2018-10-03 22:55:21 --> Router Class Initialized
INFO - 2018-10-03 22:55:21 --> Output Class Initialized
INFO - 2018-10-03 22:55:21 --> Security Class Initialized
DEBUG - 2018-10-03 22:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-03 22:55:21 --> CSRF cookie sent
INFO - 2018-10-03 22:55:21 --> Input Class Initialized
INFO - 2018-10-03 22:55:21 --> Language Class Initialized
INFO - 2018-10-03 22:55:21 --> Loader Class Initialized
INFO - 2018-10-03 22:55:21 --> Helper loaded: url_helper
INFO - 2018-10-03 22:55:21 --> Helper loaded: form_helper
INFO - 2018-10-03 22:55:21 --> Helper loaded: language_helper
DEBUG - 2018-10-03 22:55:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-03 22:55:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-03 22:55:21 --> User Agent Class Initialized
INFO - 2018-10-03 22:55:21 --> Controller Class Initialized
INFO - 2018-10-03 22:55:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-03 22:55:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-03 22:55:21 --> Pixel_Model class loaded
INFO - 2018-10-03 22:55:21 --> Database Driver Class Initialized
INFO - 2018-10-03 22:55:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:55:21 --> Database Driver Class Initialized
INFO - 2018-10-03 22:55:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:55:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-03 22:55:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-03 22:55:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-03 22:55:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-03 22:55:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-03 22:55:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-03 22:55:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-03 22:55:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-03 22:55:21 --> Final output sent to browser
DEBUG - 2018-10-03 22:55:21 --> Total execution time: 0.0386
INFO - 2018-10-03 22:55:25 --> Config Class Initialized
INFO - 2018-10-03 22:55:25 --> Hooks Class Initialized
DEBUG - 2018-10-03 22:55:25 --> UTF-8 Support Enabled
INFO - 2018-10-03 22:55:25 --> Utf8 Class Initialized
INFO - 2018-10-03 22:55:25 --> URI Class Initialized
INFO - 2018-10-03 22:55:25 --> Router Class Initialized
INFO - 2018-10-03 22:55:25 --> Output Class Initialized
INFO - 2018-10-03 22:55:25 --> Security Class Initialized
DEBUG - 2018-10-03 22:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-03 22:55:25 --> CSRF cookie sent
INFO - 2018-10-03 22:55:25 --> Input Class Initialized
INFO - 2018-10-03 22:55:25 --> Language Class Initialized
INFO - 2018-10-03 22:55:25 --> Loader Class Initialized
INFO - 2018-10-03 22:55:25 --> Helper loaded: url_helper
INFO - 2018-10-03 22:55:25 --> Helper loaded: form_helper
INFO - 2018-10-03 22:55:25 --> Helper loaded: language_helper
DEBUG - 2018-10-03 22:55:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-03 22:55:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-03 22:55:25 --> User Agent Class Initialized
INFO - 2018-10-03 22:55:25 --> Controller Class Initialized
INFO - 2018-10-03 22:55:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-03 22:55:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-03 22:55:25 --> Pixel_Model class loaded
INFO - 2018-10-03 22:55:25 --> Database Driver Class Initialized
INFO - 2018-10-03 22:55:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:55:25 --> Database Driver Class Initialized
INFO - 2018-10-03 22:55:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:55:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-03 22:55:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-03 22:55:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-10-03 22:55:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-03 22:55:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-03 22:55:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-03 22:55:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-03 22:55:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-10-03 22:55:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-03 22:55:25 --> Final output sent to browser
DEBUG - 2018-10-03 22:55:25 --> Total execution time: 0.0395
INFO - 2018-10-03 22:55:26 --> Config Class Initialized
INFO - 2018-10-03 22:55:26 --> Hooks Class Initialized
DEBUG - 2018-10-03 22:55:26 --> UTF-8 Support Enabled
INFO - 2018-10-03 22:55:26 --> Utf8 Class Initialized
INFO - 2018-10-03 22:55:26 --> URI Class Initialized
INFO - 2018-10-03 22:55:26 --> Router Class Initialized
INFO - 2018-10-03 22:55:26 --> Output Class Initialized
INFO - 2018-10-03 22:55:26 --> Security Class Initialized
DEBUG - 2018-10-03 22:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-03 22:55:26 --> CSRF cookie sent
INFO - 2018-10-03 22:55:26 --> Input Class Initialized
INFO - 2018-10-03 22:55:26 --> Language Class Initialized
INFO - 2018-10-03 22:55:26 --> Loader Class Initialized
INFO - 2018-10-03 22:55:26 --> Helper loaded: url_helper
INFO - 2018-10-03 22:55:26 --> Helper loaded: form_helper
INFO - 2018-10-03 22:55:26 --> Helper loaded: language_helper
DEBUG - 2018-10-03 22:55:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-03 22:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-03 22:55:26 --> User Agent Class Initialized
INFO - 2018-10-03 22:55:26 --> Controller Class Initialized
INFO - 2018-10-03 22:55:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-03 22:55:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-03 22:55:26 --> Pixel_Model class loaded
INFO - 2018-10-03 22:55:26 --> Database Driver Class Initialized
INFO - 2018-10-03 22:55:26 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:55:26 --> Database Driver Class Initialized
INFO - 2018-10-03 22:55:26 --> Model "QuestionsModel" initialized
INFO - 2018-10-03 22:55:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-03 22:55:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-03 22:55:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-03 22:55:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-03 22:55:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-03 22:55:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-03 22:55:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-10-03 22:55:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-03 22:55:26 --> Final output sent to browser
DEBUG - 2018-10-03 22:55:26 --> Total execution time: 0.0448

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-10-05 18:22:13 --> Config Class Initialized
INFO - 2018-10-05 18:22:13 --> Hooks Class Initialized
DEBUG - 2018-10-05 18:22:13 --> UTF-8 Support Enabled
INFO - 2018-10-05 18:22:13 --> Utf8 Class Initialized
INFO - 2018-10-05 18:22:13 --> URI Class Initialized
DEBUG - 2018-10-05 18:22:13 --> No URI present. Default controller set.
INFO - 2018-10-05 18:22:13 --> Router Class Initialized
INFO - 2018-10-05 18:22:13 --> Output Class Initialized
INFO - 2018-10-05 18:22:13 --> Security Class Initialized
DEBUG - 2018-10-05 18:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-05 18:22:13 --> CSRF cookie sent
INFO - 2018-10-05 18:22:13 --> Input Class Initialized
INFO - 2018-10-05 18:22:13 --> Language Class Initialized
INFO - 2018-10-05 18:22:13 --> Loader Class Initialized
INFO - 2018-10-05 18:22:13 --> Helper loaded: url_helper
INFO - 2018-10-05 18:22:13 --> Helper loaded: form_helper
INFO - 2018-10-05 18:22:13 --> Helper loaded: language_helper
DEBUG - 2018-10-05 18:22:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-05 18:22:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-05 18:22:13 --> User Agent Class Initialized
INFO - 2018-10-05 18:22:13 --> Controller Class Initialized
INFO - 2018-10-05 18:22:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-05 18:22:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-05 18:22:13 --> Pixel_Model class loaded
INFO - 2018-10-05 18:22:13 --> Database Driver Class Initialized
INFO - 2018-10-05 18:22:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-05 18:22:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-05 18:22:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-05 18:22:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-05 18:22:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-05 18:22:13 --> Final output sent to browser
DEBUG - 2018-10-05 18:22:13 --> Total execution time: 0.0358
INFO - 2018-10-05 18:22:23 --> Config Class Initialized
INFO - 2018-10-05 18:22:23 --> Hooks Class Initialized
DEBUG - 2018-10-05 18:22:23 --> UTF-8 Support Enabled
INFO - 2018-10-05 18:22:23 --> Utf8 Class Initialized
INFO - 2018-10-05 18:22:23 --> URI Class Initialized
INFO - 2018-10-05 18:22:23 --> Router Class Initialized
INFO - 2018-10-05 18:22:23 --> Output Class Initialized
INFO - 2018-10-05 18:22:23 --> Security Class Initialized
DEBUG - 2018-10-05 18:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-05 18:22:23 --> CSRF cookie sent
INFO - 2018-10-05 18:22:23 --> Input Class Initialized
INFO - 2018-10-05 18:22:23 --> Language Class Initialized
INFO - 2018-10-05 18:22:23 --> Loader Class Initialized
INFO - 2018-10-05 18:22:23 --> Helper loaded: url_helper
INFO - 2018-10-05 18:22:23 --> Helper loaded: form_helper
INFO - 2018-10-05 18:22:23 --> Helper loaded: language_helper
DEBUG - 2018-10-05 18:22:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-05 18:22:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-05 18:22:23 --> User Agent Class Initialized
INFO - 2018-10-05 18:22:23 --> Controller Class Initialized
INFO - 2018-10-05 18:22:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-05 18:22:23 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-05 18:22:23 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-10-05 18:22:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-05 18:22:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-05 18:22:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-05 18:22:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-10-05 18:22:23 --> Could not find the language line "req_email"
INFO - 2018-10-05 18:22:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-10-05 18:22:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-05 18:22:23 --> Final output sent to browser
DEBUG - 2018-10-05 18:22:23 --> Total execution time: 0.0228
INFO - 2018-10-05 18:22:28 --> Config Class Initialized
INFO - 2018-10-05 18:22:28 --> Hooks Class Initialized
DEBUG - 2018-10-05 18:22:28 --> UTF-8 Support Enabled
INFO - 2018-10-05 18:22:28 --> Utf8 Class Initialized
INFO - 2018-10-05 18:22:28 --> URI Class Initialized
INFO - 2018-10-05 18:22:28 --> Router Class Initialized
INFO - 2018-10-05 18:22:28 --> Output Class Initialized
INFO - 2018-10-05 18:22:28 --> Security Class Initialized
DEBUG - 2018-10-05 18:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-05 18:22:28 --> CSRF cookie sent
INFO - 2018-10-05 18:22:28 --> Input Class Initialized
INFO - 2018-10-05 18:22:28 --> Language Class Initialized
INFO - 2018-10-05 18:22:28 --> Loader Class Initialized
INFO - 2018-10-05 18:22:28 --> Helper loaded: url_helper
INFO - 2018-10-05 18:22:28 --> Helper loaded: form_helper
INFO - 2018-10-05 18:22:28 --> Helper loaded: language_helper
DEBUG - 2018-10-05 18:22:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-05 18:22:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-05 18:22:28 --> User Agent Class Initialized
INFO - 2018-10-05 18:22:28 --> Controller Class Initialized
INFO - 2018-10-05 18:22:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-05 18:22:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-05 18:22:28 --> Pixel_Model class loaded
INFO - 2018-10-05 18:22:28 --> Database Driver Class Initialized
INFO - 2018-10-05 18:22:28 --> Model "QuestionsModel" initialized
INFO - 2018-10-05 18:22:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-05 18:22:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-05 18:22:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-05 18:22:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-05 18:22:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-05 18:22:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-05 18:22:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-10-05 18:22:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-05 18:22:28 --> Final output sent to browser
DEBUG - 2018-10-05 18:22:28 --> Total execution time: 0.0424
INFO - 2018-10-05 18:22:31 --> Config Class Initialized
INFO - 2018-10-05 18:22:31 --> Hooks Class Initialized
DEBUG - 2018-10-05 18:22:31 --> UTF-8 Support Enabled
INFO - 2018-10-05 18:22:31 --> Utf8 Class Initialized
INFO - 2018-10-05 18:22:31 --> URI Class Initialized
INFO - 2018-10-05 18:22:31 --> Router Class Initialized
INFO - 2018-10-05 18:22:31 --> Output Class Initialized
INFO - 2018-10-05 18:22:31 --> Security Class Initialized
DEBUG - 2018-10-05 18:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-05 18:22:31 --> CSRF cookie sent
INFO - 2018-10-05 18:22:31 --> CSRF token verified
INFO - 2018-10-05 18:22:31 --> Input Class Initialized
INFO - 2018-10-05 18:22:31 --> Language Class Initialized
INFO - 2018-10-05 18:22:31 --> Loader Class Initialized
INFO - 2018-10-05 18:22:31 --> Helper loaded: url_helper
INFO - 2018-10-05 18:22:31 --> Helper loaded: form_helper
INFO - 2018-10-05 18:22:31 --> Helper loaded: language_helper
DEBUG - 2018-10-05 18:22:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-05 18:22:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-05 18:22:31 --> User Agent Class Initialized
INFO - 2018-10-05 18:22:31 --> Controller Class Initialized
INFO - 2018-10-05 18:22:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-05 18:22:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-05 18:22:31 --> Pixel_Model class loaded
INFO - 2018-10-05 18:22:31 --> Database Driver Class Initialized
INFO - 2018-10-05 18:22:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-05 18:22:31 --> Database Driver Class Initialized
INFO - 2018-10-05 18:22:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-05 18:22:31 --> Config Class Initialized
INFO - 2018-10-05 18:22:31 --> Hooks Class Initialized
DEBUG - 2018-10-05 18:22:31 --> UTF-8 Support Enabled
INFO - 2018-10-05 18:22:31 --> Utf8 Class Initialized
INFO - 2018-10-05 18:22:31 --> URI Class Initialized
INFO - 2018-10-05 18:22:31 --> Router Class Initialized
INFO - 2018-10-05 18:22:31 --> Output Class Initialized
INFO - 2018-10-05 18:22:31 --> Security Class Initialized
DEBUG - 2018-10-05 18:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-05 18:22:31 --> CSRF cookie sent
INFO - 2018-10-05 18:22:31 --> Input Class Initialized
INFO - 2018-10-05 18:22:31 --> Language Class Initialized
INFO - 2018-10-05 18:22:31 --> Loader Class Initialized
INFO - 2018-10-05 18:22:31 --> Helper loaded: url_helper
INFO - 2018-10-05 18:22:31 --> Helper loaded: form_helper
INFO - 2018-10-05 18:22:31 --> Helper loaded: language_helper
DEBUG - 2018-10-05 18:22:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-05 18:22:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-05 18:22:31 --> User Agent Class Initialized
INFO - 2018-10-05 18:22:31 --> Controller Class Initialized
INFO - 2018-10-05 18:22:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-05 18:22:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-05 18:22:31 --> Pixel_Model class loaded
INFO - 2018-10-05 18:22:31 --> Database Driver Class Initialized
INFO - 2018-10-05 18:22:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-05 18:22:31 --> Database Driver Class Initialized
INFO - 2018-10-05 18:22:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-05 18:22:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-05 18:22:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-05 18:22:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-05 18:22:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-05 18:22:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-05 18:22:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-05 18:22:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-05 18:22:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-05 18:22:31 --> Final output sent to browser
DEBUG - 2018-10-05 18:22:31 --> Total execution time: 0.0628
INFO - 2018-10-05 18:24:54 --> Config Class Initialized
INFO - 2018-10-05 18:24:54 --> Hooks Class Initialized
DEBUG - 2018-10-05 18:24:54 --> UTF-8 Support Enabled
INFO - 2018-10-05 18:24:54 --> Utf8 Class Initialized
INFO - 2018-10-05 18:24:54 --> URI Class Initialized
INFO - 2018-10-05 18:24:54 --> Router Class Initialized
INFO - 2018-10-05 18:24:54 --> Output Class Initialized
INFO - 2018-10-05 18:24:54 --> Security Class Initialized
DEBUG - 2018-10-05 18:24:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-05 18:24:54 --> CSRF cookie sent
INFO - 2018-10-05 18:24:54 --> Input Class Initialized
INFO - 2018-10-05 18:24:54 --> Language Class Initialized
INFO - 2018-10-05 18:24:54 --> Loader Class Initialized
INFO - 2018-10-05 18:24:54 --> Helper loaded: url_helper
INFO - 2018-10-05 18:24:54 --> Helper loaded: form_helper
INFO - 2018-10-05 18:24:54 --> Helper loaded: language_helper
DEBUG - 2018-10-05 18:24:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-05 18:24:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-05 18:24:54 --> User Agent Class Initialized
INFO - 2018-10-05 18:24:54 --> Controller Class Initialized
INFO - 2018-10-05 18:24:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-05 18:24:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-05 18:24:54 --> Pixel_Model class loaded
INFO - 2018-10-05 18:24:55 --> Database Driver Class Initialized
INFO - 2018-10-05 18:24:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-05 18:24:55 --> Database Driver Class Initialized
INFO - 2018-10-05 18:24:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-05 18:24:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-05 18:24:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-05 18:24:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-05 18:24:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-05 18:24:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-05 18:24:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-05 18:24:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-05 18:24:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-05 18:24:55 --> Final output sent to browser
DEBUG - 2018-10-05 18:24:55 --> Total execution time: 0.0450

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-10-08 21:48:00 --> Config Class Initialized
INFO - 2018-10-08 21:48:00 --> Hooks Class Initialized
DEBUG - 2018-10-08 21:48:00 --> UTF-8 Support Enabled
INFO - 2018-10-08 21:48:00 --> Utf8 Class Initialized
INFO - 2018-10-08 21:48:00 --> URI Class Initialized
DEBUG - 2018-10-08 21:48:00 --> No URI present. Default controller set.
INFO - 2018-10-08 21:48:00 --> Router Class Initialized
INFO - 2018-10-08 21:48:00 --> Output Class Initialized
INFO - 2018-10-08 21:48:00 --> Security Class Initialized
DEBUG - 2018-10-08 21:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 21:48:00 --> CSRF cookie sent
INFO - 2018-10-08 21:48:00 --> Input Class Initialized
INFO - 2018-10-08 21:48:00 --> Language Class Initialized
INFO - 2018-10-08 21:48:00 --> Loader Class Initialized
INFO - 2018-10-08 21:48:00 --> Helper loaded: url_helper
INFO - 2018-10-08 21:48:00 --> Helper loaded: form_helper
INFO - 2018-10-08 21:48:00 --> Helper loaded: language_helper
DEBUG - 2018-10-08 21:48:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-08 21:48:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 21:48:00 --> User Agent Class Initialized
INFO - 2018-10-08 21:48:00 --> Controller Class Initialized
INFO - 2018-10-08 21:48:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-08 21:48:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-08 21:48:00 --> Pixel_Model class loaded
INFO - 2018-10-08 21:48:00 --> Database Driver Class Initialized
INFO - 2018-10-08 21:48:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-08 21:48:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-08 21:48:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-08 21:48:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-08 21:48:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-08 21:48:00 --> Final output sent to browser
DEBUG - 2018-10-08 21:48:00 --> Total execution time: 0.0339
INFO - 2018-10-08 21:48:01 --> Config Class Initialized
INFO - 2018-10-08 21:48:01 --> Hooks Class Initialized
DEBUG - 2018-10-08 21:48:01 --> UTF-8 Support Enabled
INFO - 2018-10-08 21:48:01 --> Utf8 Class Initialized
INFO - 2018-10-08 21:48:01 --> URI Class Initialized
INFO - 2018-10-08 21:48:01 --> Router Class Initialized
INFO - 2018-10-08 21:48:01 --> Output Class Initialized
INFO - 2018-10-08 21:48:01 --> Security Class Initialized
DEBUG - 2018-10-08 21:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 21:48:01 --> CSRF cookie sent
INFO - 2018-10-08 21:48:01 --> Input Class Initialized
INFO - 2018-10-08 21:48:01 --> Language Class Initialized
ERROR - 2018-10-08 21:48:01 --> 404 Page Not Found: Assets/css
INFO - 2018-10-08 21:48:05 --> Config Class Initialized
INFO - 2018-10-08 21:48:05 --> Hooks Class Initialized
DEBUG - 2018-10-08 21:48:05 --> UTF-8 Support Enabled
INFO - 2018-10-08 21:48:05 --> Utf8 Class Initialized
INFO - 2018-10-08 21:48:05 --> URI Class Initialized
INFO - 2018-10-08 21:48:05 --> Router Class Initialized
INFO - 2018-10-08 21:48:05 --> Output Class Initialized
INFO - 2018-10-08 21:48:05 --> Security Class Initialized
DEBUG - 2018-10-08 21:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 21:48:05 --> CSRF cookie sent
INFO - 2018-10-08 21:48:05 --> Input Class Initialized
INFO - 2018-10-08 21:48:05 --> Language Class Initialized
INFO - 2018-10-08 21:48:05 --> Loader Class Initialized
INFO - 2018-10-08 21:48:05 --> Helper loaded: url_helper
INFO - 2018-10-08 21:48:05 --> Helper loaded: form_helper
INFO - 2018-10-08 21:48:05 --> Helper loaded: language_helper
DEBUG - 2018-10-08 21:48:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-08 21:48:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 21:48:05 --> User Agent Class Initialized
INFO - 2018-10-08 21:48:05 --> Controller Class Initialized
INFO - 2018-10-08 21:48:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-08 21:48:05 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-08 21:48:05 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-10-08 21:48:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-08 21:48:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-08 21:48:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-08 21:48:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-10-08 21:48:05 --> Could not find the language line "req_email"
INFO - 2018-10-08 21:48:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-10-08 21:48:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-08 21:48:05 --> Final output sent to browser
DEBUG - 2018-10-08 21:48:05 --> Total execution time: 0.0263
INFO - 2018-10-08 21:48:06 --> Config Class Initialized
INFO - 2018-10-08 21:48:06 --> Hooks Class Initialized
DEBUG - 2018-10-08 21:48:06 --> UTF-8 Support Enabled
INFO - 2018-10-08 21:48:06 --> Utf8 Class Initialized
INFO - 2018-10-08 21:48:06 --> URI Class Initialized
INFO - 2018-10-08 21:48:06 --> Router Class Initialized
INFO - 2018-10-08 21:48:06 --> Output Class Initialized
INFO - 2018-10-08 21:48:06 --> Security Class Initialized
DEBUG - 2018-10-08 21:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 21:48:06 --> CSRF cookie sent
INFO - 2018-10-08 21:48:06 --> Input Class Initialized
INFO - 2018-10-08 21:48:06 --> Language Class Initialized
ERROR - 2018-10-08 21:48:06 --> 404 Page Not Found: Assets/css
INFO - 2018-10-08 21:48:12 --> Config Class Initialized
INFO - 2018-10-08 21:48:12 --> Hooks Class Initialized
DEBUG - 2018-10-08 21:48:12 --> UTF-8 Support Enabled
INFO - 2018-10-08 21:48:12 --> Utf8 Class Initialized
INFO - 2018-10-08 21:48:12 --> URI Class Initialized
INFO - 2018-10-08 21:48:12 --> Router Class Initialized
INFO - 2018-10-08 21:48:12 --> Output Class Initialized
INFO - 2018-10-08 21:48:12 --> Security Class Initialized
DEBUG - 2018-10-08 21:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 21:48:12 --> CSRF cookie sent
INFO - 2018-10-08 21:48:12 --> CSRF token verified
INFO - 2018-10-08 21:48:12 --> Input Class Initialized
INFO - 2018-10-08 21:48:12 --> Language Class Initialized
INFO - 2018-10-08 21:48:12 --> Loader Class Initialized
INFO - 2018-10-08 21:48:12 --> Helper loaded: url_helper
INFO - 2018-10-08 21:48:12 --> Helper loaded: form_helper
INFO - 2018-10-08 21:48:12 --> Helper loaded: language_helper
DEBUG - 2018-10-08 21:48:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-08 21:48:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 21:48:12 --> User Agent Class Initialized
INFO - 2018-10-08 21:48:12 --> Controller Class Initialized
INFO - 2018-10-08 21:48:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-08 21:48:12 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-08 21:48:12 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-10-08 21:48:12 --> Form Validation Class Initialized
INFO - 2018-10-08 21:48:12 --> Pixel_Model class loaded
INFO - 2018-10-08 21:48:12 --> Database Driver Class Initialized
INFO - 2018-10-08 21:48:12 --> Model "AuthenticationModel" initialized
INFO - 2018-10-08 21:48:12 --> Config Class Initialized
INFO - 2018-10-08 21:48:12 --> Hooks Class Initialized
DEBUG - 2018-10-08 21:48:12 --> UTF-8 Support Enabled
INFO - 2018-10-08 21:48:12 --> Utf8 Class Initialized
INFO - 2018-10-08 21:48:12 --> URI Class Initialized
DEBUG - 2018-10-08 21:48:12 --> No URI present. Default controller set.
INFO - 2018-10-08 21:48:12 --> Router Class Initialized
INFO - 2018-10-08 21:48:12 --> Output Class Initialized
INFO - 2018-10-08 21:48:12 --> Security Class Initialized
DEBUG - 2018-10-08 21:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 21:48:12 --> CSRF cookie sent
INFO - 2018-10-08 21:48:12 --> Input Class Initialized
INFO - 2018-10-08 21:48:12 --> Language Class Initialized
INFO - 2018-10-08 21:48:12 --> Loader Class Initialized
INFO - 2018-10-08 21:48:12 --> Helper loaded: url_helper
INFO - 2018-10-08 21:48:12 --> Helper loaded: form_helper
INFO - 2018-10-08 21:48:12 --> Helper loaded: language_helper
DEBUG - 2018-10-08 21:48:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-08 21:48:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 21:48:12 --> User Agent Class Initialized
INFO - 2018-10-08 21:48:12 --> Controller Class Initialized
INFO - 2018-10-08 21:48:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-08 21:48:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-08 21:48:12 --> Pixel_Model class loaded
INFO - 2018-10-08 21:48:12 --> Database Driver Class Initialized
INFO - 2018-10-08 21:48:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-08 21:48:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-08 21:48:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-08 21:48:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-08 21:48:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-08 21:48:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-08 21:48:12 --> Final output sent to browser
DEBUG - 2018-10-08 21:48:12 --> Total execution time: 0.0354
INFO - 2018-10-08 21:48:13 --> Config Class Initialized
INFO - 2018-10-08 21:48:13 --> Hooks Class Initialized
DEBUG - 2018-10-08 21:48:13 --> UTF-8 Support Enabled
INFO - 2018-10-08 21:48:13 --> Utf8 Class Initialized
INFO - 2018-10-08 21:48:13 --> URI Class Initialized
INFO - 2018-10-08 21:48:13 --> Router Class Initialized
INFO - 2018-10-08 21:48:13 --> Output Class Initialized
INFO - 2018-10-08 21:48:13 --> Security Class Initialized
DEBUG - 2018-10-08 21:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 21:48:13 --> CSRF cookie sent
INFO - 2018-10-08 21:48:13 --> Input Class Initialized
INFO - 2018-10-08 21:48:13 --> Language Class Initialized
ERROR - 2018-10-08 21:48:13 --> 404 Page Not Found: Assets/css
INFO - 2018-10-08 21:48:17 --> Config Class Initialized
INFO - 2018-10-08 21:48:17 --> Hooks Class Initialized
DEBUG - 2018-10-08 21:48:17 --> UTF-8 Support Enabled
INFO - 2018-10-08 21:48:17 --> Utf8 Class Initialized
INFO - 2018-10-08 21:48:17 --> URI Class Initialized
INFO - 2018-10-08 21:48:17 --> Router Class Initialized
INFO - 2018-10-08 21:48:17 --> Output Class Initialized
INFO - 2018-10-08 21:48:17 --> Security Class Initialized
DEBUG - 2018-10-08 21:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 21:48:17 --> CSRF cookie sent
INFO - 2018-10-08 21:48:17 --> Input Class Initialized
INFO - 2018-10-08 21:48:17 --> Language Class Initialized
ERROR - 2018-10-08 21:48:17 --> 404 Page Not Found: Life-decision-ordering/index
INFO - 2018-10-08 21:48:17 --> Config Class Initialized
INFO - 2018-10-08 21:48:17 --> Hooks Class Initialized
DEBUG - 2018-10-08 21:48:17 --> UTF-8 Support Enabled
INFO - 2018-10-08 21:48:17 --> Utf8 Class Initialized
INFO - 2018-10-08 21:48:17 --> URI Class Initialized
INFO - 2018-10-08 21:48:17 --> Router Class Initialized
INFO - 2018-10-08 21:48:17 --> Output Class Initialized
INFO - 2018-10-08 21:48:17 --> Security Class Initialized
DEBUG - 2018-10-08 21:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 21:48:17 --> CSRF cookie sent
INFO - 2018-10-08 21:48:17 --> Input Class Initialized
INFO - 2018-10-08 21:48:17 --> Language Class Initialized
ERROR - 2018-10-08 21:48:17 --> 404 Page Not Found: Faviconico/index
INFO - 2018-10-08 21:48:33 --> Config Class Initialized
INFO - 2018-10-08 21:48:33 --> Hooks Class Initialized
DEBUG - 2018-10-08 21:48:33 --> UTF-8 Support Enabled
INFO - 2018-10-08 21:48:33 --> Utf8 Class Initialized
INFO - 2018-10-08 21:48:33 --> URI Class Initialized
INFO - 2018-10-08 21:48:33 --> Router Class Initialized
INFO - 2018-10-08 21:48:33 --> Output Class Initialized
INFO - 2018-10-08 21:48:33 --> Security Class Initialized
DEBUG - 2018-10-08 21:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 21:48:33 --> CSRF cookie sent
INFO - 2018-10-08 21:48:33 --> Input Class Initialized
INFO - 2018-10-08 21:48:33 --> Language Class Initialized
INFO - 2018-10-08 21:48:33 --> Loader Class Initialized
INFO - 2018-10-08 21:48:33 --> Helper loaded: url_helper
INFO - 2018-10-08 21:48:33 --> Helper loaded: form_helper
INFO - 2018-10-08 21:48:33 --> Helper loaded: language_helper
DEBUG - 2018-10-08 21:48:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-08 21:48:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 21:48:33 --> User Agent Class Initialized
INFO - 2018-10-08 21:48:33 --> Controller Class Initialized
INFO - 2018-10-08 21:48:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-08 21:48:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-08 21:48:33 --> Pixel_Model class loaded
INFO - 2018-10-08 21:48:33 --> Database Driver Class Initialized
INFO - 2018-10-08 21:48:33 --> Model "MyAccountModel" initialized
INFO - 2018-10-08 21:48:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-08 21:48:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-08 21:48:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-08 21:48:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-08 21:48:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-08 21:48:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/change_order.php
INFO - 2018-10-08 21:48:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-08 21:48:33 --> Final output sent to browser
DEBUG - 2018-10-08 21:48:33 --> Total execution time: 0.0481
INFO - 2018-10-08 21:48:34 --> Config Class Initialized
INFO - 2018-10-08 21:48:34 --> Hooks Class Initialized
DEBUG - 2018-10-08 21:48:34 --> UTF-8 Support Enabled
INFO - 2018-10-08 21:48:34 --> Utf8 Class Initialized
INFO - 2018-10-08 21:48:34 --> URI Class Initialized
INFO - 2018-10-08 21:48:34 --> Router Class Initialized
INFO - 2018-10-08 21:48:34 --> Output Class Initialized
INFO - 2018-10-08 21:48:34 --> Security Class Initialized
DEBUG - 2018-10-08 21:48:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 21:48:34 --> CSRF cookie sent
INFO - 2018-10-08 21:48:34 --> Input Class Initialized
INFO - 2018-10-08 21:48:34 --> Language Class Initialized
ERROR - 2018-10-08 21:48:34 --> 404 Page Not Found: Assets/css
INFO - 2018-10-08 21:48:37 --> Config Class Initialized
INFO - 2018-10-08 21:48:37 --> Hooks Class Initialized
DEBUG - 2018-10-08 21:48:37 --> UTF-8 Support Enabled
INFO - 2018-10-08 21:48:37 --> Utf8 Class Initialized
INFO - 2018-10-08 21:48:37 --> URI Class Initialized
INFO - 2018-10-08 21:48:37 --> Router Class Initialized
INFO - 2018-10-08 21:48:37 --> Output Class Initialized
INFO - 2018-10-08 21:48:37 --> Security Class Initialized
DEBUG - 2018-10-08 21:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 21:48:37 --> CSRF cookie sent
INFO - 2018-10-08 21:48:37 --> Input Class Initialized
INFO - 2018-10-08 21:48:37 --> Language Class Initialized
INFO - 2018-10-08 21:48:37 --> Loader Class Initialized
INFO - 2018-10-08 21:48:37 --> Helper loaded: url_helper
INFO - 2018-10-08 21:48:37 --> Helper loaded: form_helper
INFO - 2018-10-08 21:48:37 --> Helper loaded: language_helper
DEBUG - 2018-10-08 21:48:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-08 21:48:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 21:48:37 --> User Agent Class Initialized
INFO - 2018-10-08 21:48:37 --> Controller Class Initialized
INFO - 2018-10-08 21:48:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-08 21:48:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-08 21:48:37 --> Pixel_Model class loaded
INFO - 2018-10-08 21:48:37 --> Database Driver Class Initialized
INFO - 2018-10-08 21:48:37 --> Model "MyAccountModel" initialized
INFO - 2018-10-08 21:48:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-08 21:48:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-08 21:48:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-08 21:48:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-08 21:48:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-08 21:48:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/change_order.php
INFO - 2018-10-08 21:48:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-08 21:48:37 --> Final output sent to browser
DEBUG - 2018-10-08 21:48:37 --> Total execution time: 0.0359
INFO - 2018-10-08 21:48:38 --> Config Class Initialized
INFO - 2018-10-08 21:48:38 --> Hooks Class Initialized
DEBUG - 2018-10-08 21:48:38 --> UTF-8 Support Enabled
INFO - 2018-10-08 21:48:38 --> Utf8 Class Initialized
INFO - 2018-10-08 21:48:38 --> URI Class Initialized
INFO - 2018-10-08 21:48:38 --> Router Class Initialized
INFO - 2018-10-08 21:48:38 --> Output Class Initialized
INFO - 2018-10-08 21:48:38 --> Security Class Initialized
DEBUG - 2018-10-08 21:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 21:48:38 --> CSRF cookie sent
INFO - 2018-10-08 21:48:38 --> Input Class Initialized
INFO - 2018-10-08 21:48:38 --> Language Class Initialized
ERROR - 2018-10-08 21:48:38 --> 404 Page Not Found: Assets/css
INFO - 2018-10-08 21:48:50 --> Config Class Initialized
INFO - 2018-10-08 21:48:50 --> Hooks Class Initialized
DEBUG - 2018-10-08 21:48:50 --> UTF-8 Support Enabled
INFO - 2018-10-08 21:48:50 --> Utf8 Class Initialized
INFO - 2018-10-08 21:48:50 --> URI Class Initialized
INFO - 2018-10-08 21:48:50 --> Router Class Initialized
INFO - 2018-10-08 21:48:50 --> Output Class Initialized
INFO - 2018-10-08 21:48:50 --> Security Class Initialized
DEBUG - 2018-10-08 21:48:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 21:48:50 --> CSRF cookie sent
INFO - 2018-10-08 21:48:50 --> Input Class Initialized
INFO - 2018-10-08 21:48:50 --> Language Class Initialized
INFO - 2018-10-08 21:48:50 --> Loader Class Initialized
INFO - 2018-10-08 21:48:50 --> Helper loaded: url_helper
INFO - 2018-10-08 21:48:50 --> Helper loaded: form_helper
INFO - 2018-10-08 21:48:50 --> Helper loaded: language_helper
DEBUG - 2018-10-08 21:48:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-08 21:48:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 21:48:50 --> User Agent Class Initialized
INFO - 2018-10-08 21:48:50 --> Controller Class Initialized
INFO - 2018-10-08 21:48:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-08 21:48:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-08 21:48:50 --> Pixel_Model class loaded
INFO - 2018-10-08 21:48:50 --> Database Driver Class Initialized
INFO - 2018-10-08 21:48:50 --> Model "MyAccountModel" initialized
INFO - 2018-10-08 21:48:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-08 21:48:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-08 21:48:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-08 21:48:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-08 21:48:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-08 21:48:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/change_order.php
INFO - 2018-10-08 21:48:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-08 21:48:50 --> Final output sent to browser
DEBUG - 2018-10-08 21:48:50 --> Total execution time: 0.0357
INFO - 2018-10-08 21:48:50 --> Config Class Initialized
INFO - 2018-10-08 21:48:50 --> Hooks Class Initialized
DEBUG - 2018-10-08 21:48:50 --> UTF-8 Support Enabled
INFO - 2018-10-08 21:48:50 --> Utf8 Class Initialized
INFO - 2018-10-08 21:48:50 --> URI Class Initialized
INFO - 2018-10-08 21:48:50 --> Router Class Initialized
INFO - 2018-10-08 21:48:50 --> Output Class Initialized
INFO - 2018-10-08 21:48:50 --> Security Class Initialized
DEBUG - 2018-10-08 21:48:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 21:48:50 --> CSRF cookie sent
INFO - 2018-10-08 21:48:50 --> Input Class Initialized
INFO - 2018-10-08 21:48:50 --> Language Class Initialized
INFO - 2018-10-08 21:48:50 --> Loader Class Initialized
INFO - 2018-10-08 21:48:50 --> Helper loaded: url_helper
INFO - 2018-10-08 21:48:50 --> Helper loaded: form_helper
INFO - 2018-10-08 21:48:50 --> Helper loaded: language_helper
DEBUG - 2018-10-08 21:48:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-08 21:48:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 21:48:50 --> User Agent Class Initialized
INFO - 2018-10-08 21:48:50 --> Controller Class Initialized
INFO - 2018-10-08 21:48:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-08 21:48:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-08 21:48:50 --> Pixel_Model class loaded
INFO - 2018-10-08 21:48:50 --> Database Driver Class Initialized
INFO - 2018-10-08 21:48:50 --> Model "MyAccountModel" initialized
INFO - 2018-10-08 21:48:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-08 21:48:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-08 21:48:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-08 21:48:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-08 21:48:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-08 21:48:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/change_order.php
INFO - 2018-10-08 21:48:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-08 21:48:50 --> Final output sent to browser
DEBUG - 2018-10-08 21:48:50 --> Total execution time: 0.0359
INFO - 2018-10-08 21:48:54 --> Config Class Initialized
INFO - 2018-10-08 21:48:54 --> Hooks Class Initialized
DEBUG - 2018-10-08 21:48:54 --> UTF-8 Support Enabled
INFO - 2018-10-08 21:48:54 --> Utf8 Class Initialized
INFO - 2018-10-08 21:48:54 --> URI Class Initialized
INFO - 2018-10-08 21:48:54 --> Router Class Initialized
INFO - 2018-10-08 21:48:54 --> Output Class Initialized
INFO - 2018-10-08 21:48:54 --> Security Class Initialized
DEBUG - 2018-10-08 21:48:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 21:48:54 --> CSRF cookie sent
INFO - 2018-10-08 21:48:54 --> Input Class Initialized
INFO - 2018-10-08 21:48:54 --> Language Class Initialized
INFO - 2018-10-08 21:48:54 --> Loader Class Initialized
INFO - 2018-10-08 21:48:54 --> Helper loaded: url_helper
INFO - 2018-10-08 21:48:54 --> Helper loaded: form_helper
INFO - 2018-10-08 21:48:54 --> Helper loaded: language_helper
DEBUG - 2018-10-08 21:48:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-08 21:48:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 21:48:54 --> User Agent Class Initialized
INFO - 2018-10-08 21:48:54 --> Controller Class Initialized
INFO - 2018-10-08 21:48:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-08 21:48:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-08 21:48:54 --> Pixel_Model class loaded
INFO - 2018-10-08 21:48:54 --> Database Driver Class Initialized
INFO - 2018-10-08 21:48:54 --> Model "MyAccountModel" initialized
INFO - 2018-10-08 21:48:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-08 21:48:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-08 21:48:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-08 21:48:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-08 21:48:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-08 21:48:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/change_order.php
INFO - 2018-10-08 21:48:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-08 21:48:54 --> Final output sent to browser
DEBUG - 2018-10-08 21:48:54 --> Total execution time: 0.0345
INFO - 2018-10-08 21:49:00 --> Config Class Initialized
INFO - 2018-10-08 21:49:00 --> Hooks Class Initialized
DEBUG - 2018-10-08 21:49:00 --> UTF-8 Support Enabled
INFO - 2018-10-08 21:49:00 --> Utf8 Class Initialized
INFO - 2018-10-08 21:49:00 --> URI Class Initialized
INFO - 2018-10-08 21:49:00 --> Router Class Initialized
INFO - 2018-10-08 21:49:00 --> Output Class Initialized
INFO - 2018-10-08 21:49:00 --> Security Class Initialized
DEBUG - 2018-10-08 21:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 21:49:00 --> CSRF cookie sent
INFO - 2018-10-08 21:49:00 --> Input Class Initialized
INFO - 2018-10-08 21:49:00 --> Language Class Initialized
INFO - 2018-10-08 21:49:00 --> Loader Class Initialized
INFO - 2018-10-08 21:49:00 --> Helper loaded: url_helper
INFO - 2018-10-08 21:49:00 --> Helper loaded: form_helper
INFO - 2018-10-08 21:49:00 --> Helper loaded: language_helper
DEBUG - 2018-10-08 21:49:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-08 21:49:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 21:49:00 --> User Agent Class Initialized
INFO - 2018-10-08 21:49:00 --> Controller Class Initialized
INFO - 2018-10-08 21:49:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-08 21:49:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-08 21:49:00 --> Pixel_Model class loaded
INFO - 2018-10-08 21:49:00 --> Database Driver Class Initialized
INFO - 2018-10-08 21:49:00 --> Model "MyAccountModel" initialized
INFO - 2018-10-08 21:49:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-08 21:49:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-08 21:49:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-08 21:49:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-08 21:49:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-08 21:49:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/change_order.php
INFO - 2018-10-08 21:49:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-08 21:49:00 --> Final output sent to browser
DEBUG - 2018-10-08 21:49:00 --> Total execution time: 0.0494
INFO - 2018-10-08 21:49:02 --> Config Class Initialized
INFO - 2018-10-08 21:49:02 --> Hooks Class Initialized
DEBUG - 2018-10-08 21:49:02 --> UTF-8 Support Enabled
INFO - 2018-10-08 21:49:02 --> Utf8 Class Initialized
INFO - 2018-10-08 21:49:02 --> URI Class Initialized
INFO - 2018-10-08 21:49:02 --> Router Class Initialized
INFO - 2018-10-08 21:49:02 --> Output Class Initialized
INFO - 2018-10-08 21:49:02 --> Security Class Initialized
DEBUG - 2018-10-08 21:49:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 21:49:02 --> CSRF cookie sent
INFO - 2018-10-08 21:49:02 --> Input Class Initialized
INFO - 2018-10-08 21:49:02 --> Language Class Initialized
INFO - 2018-10-08 21:49:02 --> Loader Class Initialized
INFO - 2018-10-08 21:49:02 --> Helper loaded: url_helper
INFO - 2018-10-08 21:49:02 --> Helper loaded: form_helper
INFO - 2018-10-08 21:49:02 --> Helper loaded: language_helper
DEBUG - 2018-10-08 21:49:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-08 21:49:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 21:49:02 --> User Agent Class Initialized
INFO - 2018-10-08 21:49:02 --> Controller Class Initialized
INFO - 2018-10-08 21:49:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-08 21:49:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-08 21:49:02 --> CSRF cookie sent
INFO - 2018-10-08 21:49:02 --> Config Class Initialized
INFO - 2018-10-08 21:49:02 --> Hooks Class Initialized
DEBUG - 2018-10-08 21:49:02 --> UTF-8 Support Enabled
INFO - 2018-10-08 21:49:02 --> Utf8 Class Initialized
INFO - 2018-10-08 21:49:02 --> URI Class Initialized
DEBUG - 2018-10-08 21:49:02 --> No URI present. Default controller set.
INFO - 2018-10-08 21:49:02 --> Router Class Initialized
INFO - 2018-10-08 21:49:03 --> Output Class Initialized
INFO - 2018-10-08 21:49:03 --> Security Class Initialized
DEBUG - 2018-10-08 21:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 21:49:03 --> CSRF cookie sent
INFO - 2018-10-08 21:49:03 --> Input Class Initialized
INFO - 2018-10-08 21:49:03 --> Language Class Initialized
INFO - 2018-10-08 21:49:03 --> Loader Class Initialized
INFO - 2018-10-08 21:49:03 --> Helper loaded: url_helper
INFO - 2018-10-08 21:49:03 --> Helper loaded: form_helper
INFO - 2018-10-08 21:49:03 --> Helper loaded: language_helper
DEBUG - 2018-10-08 21:49:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-08 21:49:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 21:49:03 --> User Agent Class Initialized
INFO - 2018-10-08 21:49:03 --> Controller Class Initialized
INFO - 2018-10-08 21:49:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-08 21:49:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-08 21:49:03 --> Pixel_Model class loaded
INFO - 2018-10-08 21:49:03 --> Database Driver Class Initialized
INFO - 2018-10-08 21:49:03 --> Model "QuestionsModel" initialized
INFO - 2018-10-08 21:49:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-08 21:49:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-08 21:49:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-08 21:49:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-08 21:49:03 --> Final output sent to browser
DEBUG - 2018-10-08 21:49:03 --> Total execution time: 0.0415

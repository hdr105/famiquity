<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-10-09 12:27:06 --> Config Class Initialized
INFO - 2018-10-09 12:27:06 --> Hooks Class Initialized
DEBUG - 2018-10-09 12:27:06 --> UTF-8 Support Enabled
INFO - 2018-10-09 12:27:06 --> Utf8 Class Initialized
INFO - 2018-10-09 12:27:06 --> URI Class Initialized
DEBUG - 2018-10-09 12:27:06 --> No URI present. Default controller set.
INFO - 2018-10-09 12:27:06 --> Router Class Initialized
INFO - 2018-10-09 12:27:06 --> Output Class Initialized
INFO - 2018-10-09 12:27:06 --> Security Class Initialized
DEBUG - 2018-10-09 12:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 12:27:06 --> CSRF cookie sent
INFO - 2018-10-09 12:27:06 --> Input Class Initialized
INFO - 2018-10-09 12:27:06 --> Language Class Initialized
INFO - 2018-10-09 12:27:06 --> Loader Class Initialized
INFO - 2018-10-09 12:27:06 --> Helper loaded: url_helper
INFO - 2018-10-09 12:27:06 --> Helper loaded: form_helper
INFO - 2018-10-09 12:27:06 --> Helper loaded: language_helper
DEBUG - 2018-10-09 12:27:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 12:27:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 12:27:06 --> User Agent Class Initialized
INFO - 2018-10-09 12:27:06 --> Controller Class Initialized
INFO - 2018-10-09 12:27:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 12:27:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 12:27:06 --> Pixel_Model class loaded
INFO - 2018-10-09 12:27:06 --> Database Driver Class Initialized
INFO - 2018-10-09 12:27:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 12:27:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 12:27:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 12:27:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-09 12:27:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 12:27:06 --> Final output sent to browser
DEBUG - 2018-10-09 12:27:06 --> Total execution time: 0.0351
INFO - 2018-10-09 12:27:06 --> Config Class Initialized
INFO - 2018-10-09 12:27:06 --> Hooks Class Initialized
DEBUG - 2018-10-09 12:27:06 --> UTF-8 Support Enabled
INFO - 2018-10-09 12:27:06 --> Utf8 Class Initialized
INFO - 2018-10-09 12:27:06 --> URI Class Initialized
DEBUG - 2018-10-09 12:27:06 --> No URI present. Default controller set.
INFO - 2018-10-09 12:27:06 --> Router Class Initialized
INFO - 2018-10-09 12:27:06 --> Output Class Initialized
INFO - 2018-10-09 12:27:06 --> Security Class Initialized
DEBUG - 2018-10-09 12:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 12:27:06 --> CSRF cookie sent
INFO - 2018-10-09 12:27:06 --> Input Class Initialized
INFO - 2018-10-09 12:27:06 --> Language Class Initialized
INFO - 2018-10-09 12:27:06 --> Loader Class Initialized
INFO - 2018-10-09 12:27:06 --> Helper loaded: url_helper
INFO - 2018-10-09 12:27:06 --> Helper loaded: form_helper
INFO - 2018-10-09 12:27:06 --> Helper loaded: language_helper
DEBUG - 2018-10-09 12:27:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 12:27:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 12:27:06 --> User Agent Class Initialized
INFO - 2018-10-09 12:27:06 --> Controller Class Initialized
INFO - 2018-10-09 12:27:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 12:27:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 12:27:06 --> Pixel_Model class loaded
INFO - 2018-10-09 12:27:06 --> Database Driver Class Initialized
INFO - 2018-10-09 12:27:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 12:27:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 12:27:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 12:27:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-09 12:27:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 12:27:06 --> Final output sent to browser
DEBUG - 2018-10-09 12:27:06 --> Total execution time: 0.0312
INFO - 2018-10-09 12:35:35 --> Config Class Initialized
INFO - 2018-10-09 12:35:35 --> Hooks Class Initialized
DEBUG - 2018-10-09 12:35:35 --> UTF-8 Support Enabled
INFO - 2018-10-09 12:35:35 --> Utf8 Class Initialized
INFO - 2018-10-09 12:35:35 --> URI Class Initialized
INFO - 2018-10-09 12:35:35 --> Router Class Initialized
INFO - 2018-10-09 12:35:35 --> Output Class Initialized
INFO - 2018-10-09 12:35:35 --> Security Class Initialized
DEBUG - 2018-10-09 12:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 12:35:35 --> CSRF cookie sent
INFO - 2018-10-09 12:35:35 --> Input Class Initialized
INFO - 2018-10-09 12:35:35 --> Language Class Initialized
INFO - 2018-10-09 12:35:35 --> Loader Class Initialized
INFO - 2018-10-09 12:35:35 --> Helper loaded: url_helper
INFO - 2018-10-09 12:35:35 --> Helper loaded: form_helper
INFO - 2018-10-09 12:35:35 --> Helper loaded: language_helper
DEBUG - 2018-10-09 12:35:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 12:35:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 12:35:35 --> User Agent Class Initialized
INFO - 2018-10-09 12:35:35 --> Controller Class Initialized
INFO - 2018-10-09 12:35:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 12:35:35 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-09 12:35:35 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-10-09 12:35:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 12:35:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 12:35:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 12:35:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-10-09 12:35:35 --> Could not find the language line "req_email"
INFO - 2018-10-09 12:35:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-10-09 12:35:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 12:35:35 --> Final output sent to browser
DEBUG - 2018-10-09 12:35:35 --> Total execution time: 0.0222
INFO - 2018-10-09 12:35:39 --> Config Class Initialized
INFO - 2018-10-09 12:35:39 --> Hooks Class Initialized
DEBUG - 2018-10-09 12:35:39 --> UTF-8 Support Enabled
INFO - 2018-10-09 12:35:39 --> Utf8 Class Initialized
INFO - 2018-10-09 12:35:39 --> URI Class Initialized
INFO - 2018-10-09 12:35:39 --> Router Class Initialized
INFO - 2018-10-09 12:35:39 --> Output Class Initialized
INFO - 2018-10-09 12:35:39 --> Security Class Initialized
DEBUG - 2018-10-09 12:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 12:35:39 --> CSRF cookie sent
INFO - 2018-10-09 12:35:39 --> CSRF token verified
INFO - 2018-10-09 12:35:39 --> Input Class Initialized
INFO - 2018-10-09 12:35:39 --> Language Class Initialized
INFO - 2018-10-09 12:35:39 --> Loader Class Initialized
INFO - 2018-10-09 12:35:39 --> Helper loaded: url_helper
INFO - 2018-10-09 12:35:39 --> Helper loaded: form_helper
INFO - 2018-10-09 12:35:39 --> Helper loaded: language_helper
DEBUG - 2018-10-09 12:35:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 12:35:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 12:35:39 --> User Agent Class Initialized
INFO - 2018-10-09 12:35:39 --> Controller Class Initialized
INFO - 2018-10-09 12:35:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 12:35:39 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-09 12:35:39 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-10-09 12:35:39 --> Form Validation Class Initialized
INFO - 2018-10-09 12:35:39 --> Pixel_Model class loaded
INFO - 2018-10-09 12:35:39 --> Database Driver Class Initialized
INFO - 2018-10-09 12:35:39 --> Model "AuthenticationModel" initialized
INFO - 2018-10-09 12:35:39 --> Config Class Initialized
INFO - 2018-10-09 12:35:39 --> Hooks Class Initialized
DEBUG - 2018-10-09 12:35:39 --> UTF-8 Support Enabled
INFO - 2018-10-09 12:35:39 --> Utf8 Class Initialized
INFO - 2018-10-09 12:35:39 --> URI Class Initialized
INFO - 2018-10-09 12:35:39 --> Router Class Initialized
INFO - 2018-10-09 12:35:39 --> Output Class Initialized
INFO - 2018-10-09 12:35:39 --> Security Class Initialized
DEBUG - 2018-10-09 12:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 12:35:39 --> CSRF cookie sent
INFO - 2018-10-09 12:35:39 --> Input Class Initialized
INFO - 2018-10-09 12:35:39 --> Language Class Initialized
INFO - 2018-10-09 12:35:39 --> Loader Class Initialized
INFO - 2018-10-09 12:35:39 --> Helper loaded: url_helper
INFO - 2018-10-09 12:35:39 --> Helper loaded: form_helper
INFO - 2018-10-09 12:35:39 --> Helper loaded: language_helper
DEBUG - 2018-10-09 12:35:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 12:35:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 12:35:39 --> User Agent Class Initialized
INFO - 2018-10-09 12:35:39 --> Controller Class Initialized
INFO - 2018-10-09 12:35:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 12:35:39 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-09 12:35:39 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-10-09 12:35:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 12:35:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 12:35:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 12:35:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 12:35:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_soft_error.php
ERROR - 2018-10-09 12:35:39 --> Could not find the language line "req_email"
INFO - 2018-10-09 12:35:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-10-09 12:35:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 12:35:39 --> Final output sent to browser
DEBUG - 2018-10-09 12:35:39 --> Total execution time: 0.0287
INFO - 2018-10-09 12:35:49 --> Config Class Initialized
INFO - 2018-10-09 12:35:49 --> Hooks Class Initialized
DEBUG - 2018-10-09 12:35:49 --> UTF-8 Support Enabled
INFO - 2018-10-09 12:35:49 --> Utf8 Class Initialized
INFO - 2018-10-09 12:35:49 --> URI Class Initialized
INFO - 2018-10-09 12:35:49 --> Router Class Initialized
INFO - 2018-10-09 12:35:49 --> Output Class Initialized
INFO - 2018-10-09 12:35:49 --> Security Class Initialized
DEBUG - 2018-10-09 12:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 12:35:49 --> CSRF cookie sent
INFO - 2018-10-09 12:35:49 --> CSRF token verified
INFO - 2018-10-09 12:35:49 --> Input Class Initialized
INFO - 2018-10-09 12:35:49 --> Language Class Initialized
INFO - 2018-10-09 12:35:49 --> Loader Class Initialized
INFO - 2018-10-09 12:35:49 --> Helper loaded: url_helper
INFO - 2018-10-09 12:35:49 --> Helper loaded: form_helper
INFO - 2018-10-09 12:35:49 --> Helper loaded: language_helper
DEBUG - 2018-10-09 12:35:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 12:35:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 12:35:49 --> User Agent Class Initialized
INFO - 2018-10-09 12:35:49 --> Controller Class Initialized
INFO - 2018-10-09 12:35:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 12:35:49 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-09 12:35:49 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-10-09 12:35:49 --> Form Validation Class Initialized
INFO - 2018-10-09 12:35:49 --> Pixel_Model class loaded
INFO - 2018-10-09 12:35:49 --> Database Driver Class Initialized
INFO - 2018-10-09 12:35:49 --> Model "AuthenticationModel" initialized
INFO - 2018-10-09 12:35:49 --> Config Class Initialized
INFO - 2018-10-09 12:35:49 --> Hooks Class Initialized
DEBUG - 2018-10-09 12:35:49 --> UTF-8 Support Enabled
INFO - 2018-10-09 12:35:49 --> Utf8 Class Initialized
INFO - 2018-10-09 12:35:49 --> URI Class Initialized
DEBUG - 2018-10-09 12:35:49 --> No URI present. Default controller set.
INFO - 2018-10-09 12:35:49 --> Router Class Initialized
INFO - 2018-10-09 12:35:49 --> Output Class Initialized
INFO - 2018-10-09 12:35:49 --> Security Class Initialized
DEBUG - 2018-10-09 12:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 12:35:49 --> CSRF cookie sent
INFO - 2018-10-09 12:35:49 --> Input Class Initialized
INFO - 2018-10-09 12:35:49 --> Language Class Initialized
INFO - 2018-10-09 12:35:49 --> Loader Class Initialized
INFO - 2018-10-09 12:35:49 --> Helper loaded: url_helper
INFO - 2018-10-09 12:35:49 --> Helper loaded: form_helper
INFO - 2018-10-09 12:35:49 --> Helper loaded: language_helper
DEBUG - 2018-10-09 12:35:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 12:35:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 12:35:49 --> User Agent Class Initialized
INFO - 2018-10-09 12:35:49 --> Controller Class Initialized
INFO - 2018-10-09 12:35:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 12:35:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 12:35:49 --> Pixel_Model class loaded
INFO - 2018-10-09 12:35:49 --> Database Driver Class Initialized
INFO - 2018-10-09 12:35:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 12:35:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 12:35:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-10-09 12:35:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 12:35:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-09 12:35:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 12:35:49 --> Final output sent to browser
DEBUG - 2018-10-09 12:35:49 --> Total execution time: 0.0463
INFO - 2018-10-09 12:35:55 --> Config Class Initialized
INFO - 2018-10-09 12:35:55 --> Hooks Class Initialized
DEBUG - 2018-10-09 12:35:55 --> UTF-8 Support Enabled
INFO - 2018-10-09 12:35:55 --> Utf8 Class Initialized
INFO - 2018-10-09 12:35:55 --> URI Class Initialized
INFO - 2018-10-09 12:35:55 --> Router Class Initialized
INFO - 2018-10-09 12:35:55 --> Output Class Initialized
INFO - 2018-10-09 12:35:55 --> Security Class Initialized
DEBUG - 2018-10-09 12:35:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 12:35:55 --> CSRF cookie sent
INFO - 2018-10-09 12:35:55 --> Input Class Initialized
INFO - 2018-10-09 12:35:55 --> Language Class Initialized
INFO - 2018-10-09 12:35:55 --> Loader Class Initialized
INFO - 2018-10-09 12:35:55 --> Helper loaded: url_helper
INFO - 2018-10-09 12:35:55 --> Helper loaded: form_helper
INFO - 2018-10-09 12:35:55 --> Helper loaded: language_helper
DEBUG - 2018-10-09 12:35:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 12:35:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 12:35:55 --> User Agent Class Initialized
INFO - 2018-10-09 12:35:55 --> Controller Class Initialized
INFO - 2018-10-09 12:35:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 12:35:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 12:35:55 --> Pixel_Model class loaded
INFO - 2018-10-09 12:35:55 --> Database Driver Class Initialized
INFO - 2018-10-09 12:35:55 --> Model "MyAccountModel" initialized
INFO - 2018-10-09 12:35:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 12:35:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-10-09 12:35:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 12:35:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 12:35:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 12:35:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/import_enduser.php
INFO - 2018-10-09 12:35:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 12:35:55 --> Final output sent to browser
DEBUG - 2018-10-09 12:35:55 --> Total execution time: 0.0496
INFO - 2018-10-09 12:35:57 --> Config Class Initialized
INFO - 2018-10-09 12:35:57 --> Hooks Class Initialized
DEBUG - 2018-10-09 12:35:57 --> UTF-8 Support Enabled
INFO - 2018-10-09 12:35:57 --> Utf8 Class Initialized
INFO - 2018-10-09 12:35:57 --> URI Class Initialized
INFO - 2018-10-09 12:35:57 --> Router Class Initialized
INFO - 2018-10-09 12:35:57 --> Output Class Initialized
INFO - 2018-10-09 12:35:57 --> Security Class Initialized
DEBUG - 2018-10-09 12:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 12:35:57 --> CSRF cookie sent
INFO - 2018-10-09 12:35:57 --> Input Class Initialized
INFO - 2018-10-09 12:35:57 --> Language Class Initialized
INFO - 2018-10-09 12:35:57 --> Loader Class Initialized
INFO - 2018-10-09 12:35:57 --> Helper loaded: url_helper
INFO - 2018-10-09 12:35:57 --> Helper loaded: form_helper
INFO - 2018-10-09 12:35:57 --> Helper loaded: language_helper
DEBUG - 2018-10-09 12:35:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 12:35:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 12:35:57 --> User Agent Class Initialized
INFO - 2018-10-09 12:35:57 --> Controller Class Initialized
INFO - 2018-10-09 12:35:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 12:35:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 12:35:57 --> Pixel_Model class loaded
INFO - 2018-10-09 12:35:57 --> Database Driver Class Initialized
INFO - 2018-10-09 12:35:57 --> Model "MyAccountModel" initialized
INFO - 2018-10-09 12:35:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 12:35:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-10-09 12:35:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 12:35:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 12:35:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-10-09 12:35:57 --> Could not find the language line "req_email"
INFO - 2018-10-09 12:35:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/add_client.php
INFO - 2018-10-09 12:35:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 12:35:57 --> Final output sent to browser
DEBUG - 2018-10-09 12:35:57 --> Total execution time: 0.0469
INFO - 2018-10-09 12:36:32 --> Config Class Initialized
INFO - 2018-10-09 12:36:32 --> Hooks Class Initialized
DEBUG - 2018-10-09 12:36:32 --> UTF-8 Support Enabled
INFO - 2018-10-09 12:36:32 --> Utf8 Class Initialized
INFO - 2018-10-09 12:36:32 --> URI Class Initialized
INFO - 2018-10-09 12:36:32 --> Router Class Initialized
INFO - 2018-10-09 12:36:32 --> Output Class Initialized
INFO - 2018-10-09 12:36:32 --> Security Class Initialized
DEBUG - 2018-10-09 12:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 12:36:32 --> CSRF cookie sent
INFO - 2018-10-09 12:36:32 --> CSRF token verified
INFO - 2018-10-09 12:36:32 --> Input Class Initialized
INFO - 2018-10-09 12:36:32 --> Language Class Initialized
INFO - 2018-10-09 12:36:32 --> Loader Class Initialized
INFO - 2018-10-09 12:36:32 --> Helper loaded: url_helper
INFO - 2018-10-09 12:36:32 --> Helper loaded: form_helper
INFO - 2018-10-09 12:36:32 --> Helper loaded: language_helper
DEBUG - 2018-10-09 12:36:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 12:36:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 12:36:32 --> User Agent Class Initialized
INFO - 2018-10-09 12:36:32 --> Controller Class Initialized
INFO - 2018-10-09 12:36:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 12:36:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 12:36:32 --> Form Validation Class Initialized
INFO - 2018-10-09 12:36:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 12:36:32 --> Pixel_Model class loaded
INFO - 2018-10-09 12:36:32 --> Database Driver Class Initialized
INFO - 2018-10-09 12:36:32 --> Model "RegistrationModel" initialized
INFO - 2018-10-09 12:36:32 --> Database Driver Class Initialized
INFO - 2018-10-09 12:36:32 --> Model "MyAccountModel" initialized
INFO - 2018-10-09 12:36:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 12:36:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-10-09 12:36:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 12:36:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 12:36:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 12:36:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_errors.php
ERROR - 2018-10-09 12:36:32 --> Could not find the language line "req_email"
INFO - 2018-10-09 12:36:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/add_client.php
INFO - 2018-10-09 12:36:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 12:36:32 --> Final output sent to browser
DEBUG - 2018-10-09 12:36:32 --> Total execution time: 0.0531
INFO - 2018-10-09 12:36:43 --> Config Class Initialized
INFO - 2018-10-09 12:36:43 --> Hooks Class Initialized
DEBUG - 2018-10-09 12:36:43 --> UTF-8 Support Enabled
INFO - 2018-10-09 12:36:43 --> Utf8 Class Initialized
INFO - 2018-10-09 12:36:43 --> URI Class Initialized
INFO - 2018-10-09 12:36:43 --> Router Class Initialized
INFO - 2018-10-09 12:36:43 --> Output Class Initialized
INFO - 2018-10-09 12:36:43 --> Security Class Initialized
DEBUG - 2018-10-09 12:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 12:36:43 --> CSRF cookie sent
INFO - 2018-10-09 12:36:43 --> CSRF token verified
INFO - 2018-10-09 12:36:43 --> Input Class Initialized
INFO - 2018-10-09 12:36:43 --> Language Class Initialized
INFO - 2018-10-09 12:36:43 --> Loader Class Initialized
INFO - 2018-10-09 12:36:43 --> Helper loaded: url_helper
INFO - 2018-10-09 12:36:43 --> Helper loaded: form_helper
INFO - 2018-10-09 12:36:43 --> Helper loaded: language_helper
DEBUG - 2018-10-09 12:36:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 12:36:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 12:36:43 --> User Agent Class Initialized
INFO - 2018-10-09 12:36:43 --> Controller Class Initialized
INFO - 2018-10-09 12:36:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 12:36:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 12:36:43 --> Form Validation Class Initialized
INFO - 2018-10-09 12:36:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 12:36:43 --> Pixel_Model class loaded
INFO - 2018-10-09 12:36:43 --> Database Driver Class Initialized
INFO - 2018-10-09 12:36:43 --> Model "RegistrationModel" initialized
INFO - 2018-10-09 12:36:43 --> Helper loaded: string_helper
INFO - 2018-10-09 12:36:43 --> Language file loaded: language/en/notifications_lang.php
INFO - 2018-10-09 12:36:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/emails/_buttons.php
INFO - 2018-10-09 12:36:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/emails/header.php
INFO - 2018-10-09 12:36:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/emails/footer.php
INFO - 2018-10-09 12:36:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/emails/generic.php
INFO - 2018-10-09 12:36:43 --> Email Class Initialized
INFO - 2018-10-09 12:36:44 --> Language file loaded: language/english/email_lang.php
INFO - 2018-10-09 12:36:44 --> Config Class Initialized
INFO - 2018-10-09 12:36:44 --> Hooks Class Initialized
DEBUG - 2018-10-09 12:36:44 --> UTF-8 Support Enabled
INFO - 2018-10-09 12:36:44 --> Utf8 Class Initialized
INFO - 2018-10-09 12:36:44 --> URI Class Initialized
INFO - 2018-10-09 12:36:44 --> Router Class Initialized
INFO - 2018-10-09 12:36:44 --> Output Class Initialized
INFO - 2018-10-09 12:36:44 --> Security Class Initialized
DEBUG - 2018-10-09 12:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 12:36:44 --> CSRF cookie sent
INFO - 2018-10-09 12:36:44 --> Input Class Initialized
INFO - 2018-10-09 12:36:44 --> Language Class Initialized
INFO - 2018-10-09 12:36:44 --> Loader Class Initialized
INFO - 2018-10-09 12:36:44 --> Helper loaded: url_helper
INFO - 2018-10-09 12:36:44 --> Helper loaded: form_helper
INFO - 2018-10-09 12:36:44 --> Helper loaded: language_helper
DEBUG - 2018-10-09 12:36:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 12:36:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 12:36:44 --> User Agent Class Initialized
INFO - 2018-10-09 12:36:44 --> Controller Class Initialized
INFO - 2018-10-09 12:36:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 12:36:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 12:36:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 12:36:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-10-09 12:36:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 12:36:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 12:36:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 12:36:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/success_message.php
INFO - 2018-10-09 12:36:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 12:36:44 --> Final output sent to browser
DEBUG - 2018-10-09 12:36:44 --> Total execution time: 0.0287
INFO - 2018-10-09 12:37:36 --> Config Class Initialized
INFO - 2018-10-09 12:37:36 --> Hooks Class Initialized
DEBUG - 2018-10-09 12:37:36 --> UTF-8 Support Enabled
INFO - 2018-10-09 12:37:36 --> Utf8 Class Initialized
INFO - 2018-10-09 12:37:36 --> URI Class Initialized
INFO - 2018-10-09 12:37:36 --> Router Class Initialized
INFO - 2018-10-09 12:37:36 --> Output Class Initialized
INFO - 2018-10-09 12:37:36 --> Security Class Initialized
DEBUG - 2018-10-09 12:37:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 12:37:36 --> CSRF cookie sent
INFO - 2018-10-09 12:37:36 --> Input Class Initialized
INFO - 2018-10-09 12:37:36 --> Language Class Initialized
INFO - 2018-10-09 12:37:37 --> Loader Class Initialized
INFO - 2018-10-09 12:37:37 --> Helper loaded: url_helper
INFO - 2018-10-09 12:37:37 --> Helper loaded: form_helper
INFO - 2018-10-09 12:37:37 --> Helper loaded: language_helper
DEBUG - 2018-10-09 12:37:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 12:37:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 12:37:37 --> User Agent Class Initialized
INFO - 2018-10-09 12:37:37 --> Controller Class Initialized
INFO - 2018-10-09 12:37:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 12:37:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 12:37:37 --> CSRF cookie sent
INFO - 2018-10-09 12:37:37 --> Config Class Initialized
INFO - 2018-10-09 12:37:37 --> Hooks Class Initialized
DEBUG - 2018-10-09 12:37:37 --> UTF-8 Support Enabled
INFO - 2018-10-09 12:37:37 --> Utf8 Class Initialized
INFO - 2018-10-09 12:37:37 --> URI Class Initialized
DEBUG - 2018-10-09 12:37:37 --> No URI present. Default controller set.
INFO - 2018-10-09 12:37:37 --> Router Class Initialized
INFO - 2018-10-09 12:37:37 --> Output Class Initialized
INFO - 2018-10-09 12:37:37 --> Security Class Initialized
DEBUG - 2018-10-09 12:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 12:37:37 --> CSRF cookie sent
INFO - 2018-10-09 12:37:37 --> Input Class Initialized
INFO - 2018-10-09 12:37:37 --> Language Class Initialized
INFO - 2018-10-09 12:37:37 --> Loader Class Initialized
INFO - 2018-10-09 12:37:37 --> Helper loaded: url_helper
INFO - 2018-10-09 12:37:37 --> Helper loaded: form_helper
INFO - 2018-10-09 12:37:37 --> Helper loaded: language_helper
DEBUG - 2018-10-09 12:37:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 12:37:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 12:37:37 --> User Agent Class Initialized
INFO - 2018-10-09 12:37:37 --> Controller Class Initialized
INFO - 2018-10-09 12:37:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 12:37:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 12:37:37 --> Pixel_Model class loaded
INFO - 2018-10-09 12:37:37 --> Database Driver Class Initialized
INFO - 2018-10-09 12:37:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 12:37:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 12:37:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 12:37:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-09 12:37:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 12:37:37 --> Final output sent to browser
DEBUG - 2018-10-09 12:37:37 --> Total execution time: 0.0363
INFO - 2018-10-09 12:37:39 --> Config Class Initialized
INFO - 2018-10-09 12:37:39 --> Hooks Class Initialized
DEBUG - 2018-10-09 12:37:39 --> UTF-8 Support Enabled
INFO - 2018-10-09 12:37:39 --> Utf8 Class Initialized
INFO - 2018-10-09 12:37:39 --> URI Class Initialized
INFO - 2018-10-09 12:37:39 --> Router Class Initialized
INFO - 2018-10-09 12:37:39 --> Output Class Initialized
INFO - 2018-10-09 12:37:39 --> Security Class Initialized
DEBUG - 2018-10-09 12:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 12:37:39 --> CSRF cookie sent
INFO - 2018-10-09 12:37:39 --> Input Class Initialized
INFO - 2018-10-09 12:37:39 --> Language Class Initialized
INFO - 2018-10-09 12:37:39 --> Loader Class Initialized
INFO - 2018-10-09 12:37:39 --> Helper loaded: url_helper
INFO - 2018-10-09 12:37:39 --> Helper loaded: form_helper
INFO - 2018-10-09 12:37:39 --> Helper loaded: language_helper
DEBUG - 2018-10-09 12:37:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 12:37:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 12:37:39 --> User Agent Class Initialized
INFO - 2018-10-09 12:37:39 --> Controller Class Initialized
INFO - 2018-10-09 12:37:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 12:37:39 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-09 12:37:39 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-10-09 12:37:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 12:37:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 12:37:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 12:37:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-10-09 12:37:39 --> Could not find the language line "req_email"
INFO - 2018-10-09 12:37:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-10-09 12:37:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 12:37:39 --> Final output sent to browser
DEBUG - 2018-10-09 12:37:39 --> Total execution time: 0.0236
INFO - 2018-10-09 12:37:48 --> Config Class Initialized
INFO - 2018-10-09 12:37:48 --> Hooks Class Initialized
DEBUG - 2018-10-09 12:37:48 --> UTF-8 Support Enabled
INFO - 2018-10-09 12:37:48 --> Utf8 Class Initialized
INFO - 2018-10-09 12:37:48 --> URI Class Initialized
INFO - 2018-10-09 12:37:48 --> Router Class Initialized
INFO - 2018-10-09 12:37:48 --> Output Class Initialized
INFO - 2018-10-09 12:37:48 --> Security Class Initialized
DEBUG - 2018-10-09 12:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 12:37:48 --> CSRF cookie sent
INFO - 2018-10-09 12:37:48 --> CSRF token verified
INFO - 2018-10-09 12:37:48 --> Input Class Initialized
INFO - 2018-10-09 12:37:48 --> Language Class Initialized
INFO - 2018-10-09 12:37:48 --> Loader Class Initialized
INFO - 2018-10-09 12:37:48 --> Helper loaded: url_helper
INFO - 2018-10-09 12:37:48 --> Helper loaded: form_helper
INFO - 2018-10-09 12:37:48 --> Helper loaded: language_helper
DEBUG - 2018-10-09 12:37:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 12:37:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 12:37:48 --> User Agent Class Initialized
INFO - 2018-10-09 12:37:48 --> Controller Class Initialized
INFO - 2018-10-09 12:37:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 12:37:48 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-09 12:37:48 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-10-09 12:37:48 --> Form Validation Class Initialized
INFO - 2018-10-09 12:37:48 --> Pixel_Model class loaded
INFO - 2018-10-09 12:37:48 --> Database Driver Class Initialized
INFO - 2018-10-09 12:37:48 --> Model "AuthenticationModel" initialized
INFO - 2018-10-09 12:37:49 --> Config Class Initialized
INFO - 2018-10-09 12:37:49 --> Hooks Class Initialized
DEBUG - 2018-10-09 12:37:49 --> UTF-8 Support Enabled
INFO - 2018-10-09 12:37:49 --> Utf8 Class Initialized
INFO - 2018-10-09 12:37:49 --> URI Class Initialized
DEBUG - 2018-10-09 12:37:49 --> No URI present. Default controller set.
INFO - 2018-10-09 12:37:49 --> Router Class Initialized
INFO - 2018-10-09 12:37:49 --> Output Class Initialized
INFO - 2018-10-09 12:37:49 --> Security Class Initialized
DEBUG - 2018-10-09 12:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 12:37:49 --> CSRF cookie sent
INFO - 2018-10-09 12:37:49 --> Input Class Initialized
INFO - 2018-10-09 12:37:49 --> Language Class Initialized
INFO - 2018-10-09 12:37:49 --> Loader Class Initialized
INFO - 2018-10-09 12:37:49 --> Helper loaded: url_helper
INFO - 2018-10-09 12:37:49 --> Helper loaded: form_helper
INFO - 2018-10-09 12:37:49 --> Helper loaded: language_helper
DEBUG - 2018-10-09 12:37:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 12:37:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 12:37:49 --> User Agent Class Initialized
INFO - 2018-10-09 12:37:49 --> Controller Class Initialized
INFO - 2018-10-09 12:37:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 12:37:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 12:37:49 --> Pixel_Model class loaded
INFO - 2018-10-09 12:37:49 --> Database Driver Class Initialized
INFO - 2018-10-09 12:37:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 12:37:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 12:37:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-10-09 12:37:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 12:37:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-09 12:37:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 12:37:49 --> Final output sent to browser
DEBUG - 2018-10-09 12:37:49 --> Total execution time: 0.0370
INFO - 2018-10-09 12:38:09 --> Config Class Initialized
INFO - 2018-10-09 12:38:09 --> Hooks Class Initialized
DEBUG - 2018-10-09 12:38:09 --> UTF-8 Support Enabled
INFO - 2018-10-09 12:38:09 --> Utf8 Class Initialized
INFO - 2018-10-09 12:38:09 --> URI Class Initialized
INFO - 2018-10-09 12:38:09 --> Router Class Initialized
INFO - 2018-10-09 12:38:09 --> Output Class Initialized
INFO - 2018-10-09 12:38:09 --> Security Class Initialized
DEBUG - 2018-10-09 12:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 12:38:09 --> CSRF cookie sent
INFO - 2018-10-09 12:38:09 --> Input Class Initialized
INFO - 2018-10-09 12:38:09 --> Language Class Initialized
INFO - 2018-10-09 12:38:09 --> Loader Class Initialized
INFO - 2018-10-09 12:38:09 --> Helper loaded: url_helper
INFO - 2018-10-09 12:38:09 --> Helper loaded: form_helper
INFO - 2018-10-09 12:38:09 --> Helper loaded: language_helper
DEBUG - 2018-10-09 12:38:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 12:38:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 12:38:09 --> User Agent Class Initialized
INFO - 2018-10-09 12:38:09 --> Controller Class Initialized
INFO - 2018-10-09 12:38:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 12:38:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 12:38:09 --> Pixel_Model class loaded
INFO - 2018-10-09 12:38:09 --> Database Driver Class Initialized
INFO - 2018-10-09 12:38:09 --> Model "MyAccountModel" initialized
INFO - 2018-10-09 12:38:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 12:38:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-10-09 12:38:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 12:38:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 12:38:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 12:38:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/import_enduser.php
INFO - 2018-10-09 12:38:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 12:38:09 --> Final output sent to browser
DEBUG - 2018-10-09 12:38:09 --> Total execution time: 0.0547
INFO - 2018-10-09 12:38:13 --> Config Class Initialized
INFO - 2018-10-09 12:38:13 --> Hooks Class Initialized
DEBUG - 2018-10-09 12:38:13 --> UTF-8 Support Enabled
INFO - 2018-10-09 12:38:13 --> Utf8 Class Initialized
INFO - 2018-10-09 12:38:13 --> URI Class Initialized
DEBUG - 2018-10-09 12:38:13 --> No URI present. Default controller set.
INFO - 2018-10-09 12:38:13 --> Router Class Initialized
INFO - 2018-10-09 12:38:13 --> Output Class Initialized
INFO - 2018-10-09 12:38:13 --> Security Class Initialized
DEBUG - 2018-10-09 12:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 12:38:13 --> CSRF cookie sent
INFO - 2018-10-09 12:38:13 --> Input Class Initialized
INFO - 2018-10-09 12:38:13 --> Language Class Initialized
INFO - 2018-10-09 12:38:13 --> Loader Class Initialized
INFO - 2018-10-09 12:38:13 --> Helper loaded: url_helper
INFO - 2018-10-09 12:38:13 --> Helper loaded: form_helper
INFO - 2018-10-09 12:38:13 --> Helper loaded: language_helper
DEBUG - 2018-10-09 12:38:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 12:38:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 12:38:13 --> User Agent Class Initialized
INFO - 2018-10-09 12:38:13 --> Controller Class Initialized
INFO - 2018-10-09 12:38:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 12:38:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 12:38:13 --> Pixel_Model class loaded
INFO - 2018-10-09 12:38:13 --> Database Driver Class Initialized
INFO - 2018-10-09 12:38:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 12:38:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 12:38:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-10-09 12:38:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 12:38:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-09 12:38:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 12:38:13 --> Final output sent to browser
DEBUG - 2018-10-09 12:38:13 --> Total execution time: 0.0542
INFO - 2018-10-09 12:38:16 --> Config Class Initialized
INFO - 2018-10-09 12:38:16 --> Hooks Class Initialized
DEBUG - 2018-10-09 12:38:16 --> UTF-8 Support Enabled
INFO - 2018-10-09 12:38:16 --> Utf8 Class Initialized
INFO - 2018-10-09 12:38:16 --> URI Class Initialized
INFO - 2018-10-09 12:38:16 --> Router Class Initialized
INFO - 2018-10-09 12:38:16 --> Output Class Initialized
INFO - 2018-10-09 12:38:16 --> Security Class Initialized
DEBUG - 2018-10-09 12:38:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 12:38:16 --> CSRF cookie sent
INFO - 2018-10-09 12:38:16 --> Input Class Initialized
INFO - 2018-10-09 12:38:16 --> Language Class Initialized
INFO - 2018-10-09 12:38:16 --> Loader Class Initialized
INFO - 2018-10-09 12:38:16 --> Helper loaded: url_helper
INFO - 2018-10-09 12:38:16 --> Helper loaded: form_helper
INFO - 2018-10-09 12:38:16 --> Helper loaded: language_helper
DEBUG - 2018-10-09 12:38:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 12:38:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 12:38:16 --> User Agent Class Initialized
INFO - 2018-10-09 12:38:16 --> Controller Class Initialized
INFO - 2018-10-09 12:38:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 12:38:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 12:38:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 12:38:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-10-09 12:38:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 12:38:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 12:38:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 12:38:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-10-09 12:38:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 12:38:16 --> Final output sent to browser
DEBUG - 2018-10-09 12:38:16 --> Total execution time: 0.0331
INFO - 2018-10-09 12:38:26 --> Config Class Initialized
INFO - 2018-10-09 12:38:26 --> Hooks Class Initialized
DEBUG - 2018-10-09 12:38:26 --> UTF-8 Support Enabled
INFO - 2018-10-09 12:38:26 --> Utf8 Class Initialized
INFO - 2018-10-09 12:38:26 --> URI Class Initialized
INFO - 2018-10-09 12:38:26 --> Router Class Initialized
INFO - 2018-10-09 12:38:26 --> Output Class Initialized
INFO - 2018-10-09 12:38:26 --> Security Class Initialized
DEBUG - 2018-10-09 12:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 12:38:26 --> CSRF cookie sent
INFO - 2018-10-09 12:38:26 --> Input Class Initialized
INFO - 2018-10-09 12:38:26 --> Language Class Initialized
INFO - 2018-10-09 12:38:26 --> Loader Class Initialized
INFO - 2018-10-09 12:38:26 --> Helper loaded: url_helper
INFO - 2018-10-09 12:38:26 --> Helper loaded: form_helper
INFO - 2018-10-09 12:38:26 --> Helper loaded: language_helper
DEBUG - 2018-10-09 12:38:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 12:38:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 12:38:26 --> User Agent Class Initialized
INFO - 2018-10-09 12:38:26 --> Controller Class Initialized
INFO - 2018-10-09 12:38:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 12:38:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 12:38:26 --> Pixel_Model class loaded
INFO - 2018-10-09 12:38:26 --> Database Driver Class Initialized
INFO - 2018-10-09 12:38:26 --> Model "MyAccountModel" initialized
INFO - 2018-10-09 12:38:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-09 12:38:26 --> Pagination Class Initialized
INFO - 2018-10-09 12:38:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 12:38:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-10-09 12:38:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 12:38:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 12:38:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 12:38:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/client_list.php
INFO - 2018-10-09 12:38:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 12:38:26 --> Final output sent to browser
DEBUG - 2018-10-09 12:38:26 --> Total execution time: 0.0353
INFO - 2018-10-09 12:38:28 --> Config Class Initialized
INFO - 2018-10-09 12:38:28 --> Hooks Class Initialized
DEBUG - 2018-10-09 12:38:28 --> UTF-8 Support Enabled
INFO - 2018-10-09 12:38:28 --> Utf8 Class Initialized
INFO - 2018-10-09 12:38:28 --> URI Class Initialized
INFO - 2018-10-09 12:38:28 --> Router Class Initialized
INFO - 2018-10-09 12:38:28 --> Output Class Initialized
INFO - 2018-10-09 12:38:28 --> Security Class Initialized
DEBUG - 2018-10-09 12:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 12:38:28 --> CSRF cookie sent
INFO - 2018-10-09 12:38:28 --> Input Class Initialized
INFO - 2018-10-09 12:38:28 --> Language Class Initialized
INFO - 2018-10-09 12:38:28 --> Loader Class Initialized
INFO - 2018-10-09 12:38:28 --> Helper loaded: url_helper
INFO - 2018-10-09 12:38:28 --> Helper loaded: form_helper
INFO - 2018-10-09 12:38:28 --> Helper loaded: language_helper
DEBUG - 2018-10-09 12:38:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 12:38:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 12:38:28 --> User Agent Class Initialized
INFO - 2018-10-09 12:38:28 --> Controller Class Initialized
INFO - 2018-10-09 12:38:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 12:38:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 12:38:28 --> Pixel_Model class loaded
INFO - 2018-10-09 12:38:28 --> Database Driver Class Initialized
INFO - 2018-10-09 12:38:28 --> Model "MyAccountModel" initialized
INFO - 2018-10-09 12:38:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-09 12:38:28 --> Pagination Class Initialized
INFO - 2018-10-09 12:38:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 12:38:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-10-09 12:38:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 12:38:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 12:38:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 12:38:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/client_list.php
INFO - 2018-10-09 12:38:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 12:38:28 --> Final output sent to browser
DEBUG - 2018-10-09 12:38:28 --> Total execution time: 0.0416
INFO - 2018-10-09 12:46:33 --> Config Class Initialized
INFO - 2018-10-09 12:46:33 --> Hooks Class Initialized
DEBUG - 2018-10-09 12:46:33 --> UTF-8 Support Enabled
INFO - 2018-10-09 12:46:33 --> Utf8 Class Initialized
INFO - 2018-10-09 12:46:33 --> URI Class Initialized
DEBUG - 2018-10-09 12:46:33 --> No URI present. Default controller set.
INFO - 2018-10-09 12:46:33 --> Router Class Initialized
INFO - 2018-10-09 12:46:33 --> Output Class Initialized
INFO - 2018-10-09 12:46:33 --> Security Class Initialized
DEBUG - 2018-10-09 12:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 12:46:33 --> CSRF cookie sent
INFO - 2018-10-09 12:46:33 --> Input Class Initialized
INFO - 2018-10-09 12:46:33 --> Language Class Initialized
INFO - 2018-10-09 12:46:33 --> Loader Class Initialized
INFO - 2018-10-09 12:46:33 --> Helper loaded: url_helper
INFO - 2018-10-09 12:46:33 --> Helper loaded: form_helper
INFO - 2018-10-09 12:46:33 --> Helper loaded: language_helper
DEBUG - 2018-10-09 12:46:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 12:46:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 12:46:33 --> User Agent Class Initialized
INFO - 2018-10-09 12:46:33 --> Controller Class Initialized
INFO - 2018-10-09 12:46:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 12:46:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 12:46:33 --> Pixel_Model class loaded
INFO - 2018-10-09 12:46:33 --> Database Driver Class Initialized
INFO - 2018-10-09 12:46:33 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 12:46:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 12:46:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-10-09 12:46:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 12:46:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-09 12:46:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 12:46:33 --> Final output sent to browser
DEBUG - 2018-10-09 12:46:33 --> Total execution time: 0.0351
INFO - 2018-10-09 12:46:42 --> Config Class Initialized
INFO - 2018-10-09 12:46:42 --> Hooks Class Initialized
DEBUG - 2018-10-09 12:46:42 --> UTF-8 Support Enabled
INFO - 2018-10-09 12:46:42 --> Utf8 Class Initialized
INFO - 2018-10-09 12:46:42 --> URI Class Initialized
INFO - 2018-10-09 12:46:42 --> Router Class Initialized
INFO - 2018-10-09 12:46:42 --> Output Class Initialized
INFO - 2018-10-09 12:46:42 --> Security Class Initialized
DEBUG - 2018-10-09 12:46:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 12:46:42 --> CSRF cookie sent
INFO - 2018-10-09 12:46:42 --> Input Class Initialized
INFO - 2018-10-09 12:46:42 --> Language Class Initialized
ERROR - 2018-10-09 12:46:42 --> 404 Page Not Found: My-account/index
INFO - 2018-10-09 12:46:42 --> Config Class Initialized
INFO - 2018-10-09 12:46:42 --> Hooks Class Initialized
DEBUG - 2018-10-09 12:46:42 --> UTF-8 Support Enabled
INFO - 2018-10-09 12:46:42 --> Utf8 Class Initialized
INFO - 2018-10-09 12:46:42 --> URI Class Initialized
INFO - 2018-10-09 12:46:42 --> Router Class Initialized
INFO - 2018-10-09 12:46:42 --> Output Class Initialized
INFO - 2018-10-09 12:46:42 --> Security Class Initialized
DEBUG - 2018-10-09 12:46:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 12:46:42 --> CSRF cookie sent
INFO - 2018-10-09 12:46:42 --> Input Class Initialized
INFO - 2018-10-09 12:46:42 --> Language Class Initialized
ERROR - 2018-10-09 12:46:42 --> 404 Page Not Found: Faviconico/index
INFO - 2018-10-09 12:47:02 --> Config Class Initialized
INFO - 2018-10-09 12:47:02 --> Hooks Class Initialized
DEBUG - 2018-10-09 12:47:02 --> UTF-8 Support Enabled
INFO - 2018-10-09 12:47:02 --> Utf8 Class Initialized
INFO - 2018-10-09 12:47:02 --> URI Class Initialized
INFO - 2018-10-09 12:47:02 --> Router Class Initialized
INFO - 2018-10-09 12:47:02 --> Output Class Initialized
INFO - 2018-10-09 12:47:02 --> Security Class Initialized
DEBUG - 2018-10-09 12:47:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 12:47:02 --> CSRF cookie sent
INFO - 2018-10-09 12:47:02 --> Input Class Initialized
INFO - 2018-10-09 12:47:02 --> Language Class Initialized
ERROR - 2018-10-09 12:47:02 --> 404 Page Not Found: Myaccount/index
INFO - 2018-10-09 12:47:06 --> Config Class Initialized
INFO - 2018-10-09 12:47:06 --> Hooks Class Initialized
DEBUG - 2018-10-09 12:47:06 --> UTF-8 Support Enabled
INFO - 2018-10-09 12:47:06 --> Utf8 Class Initialized
INFO - 2018-10-09 12:47:06 --> URI Class Initialized
DEBUG - 2018-10-09 12:47:06 --> No URI present. Default controller set.
INFO - 2018-10-09 12:47:06 --> Router Class Initialized
INFO - 2018-10-09 12:47:06 --> Output Class Initialized
INFO - 2018-10-09 12:47:06 --> Security Class Initialized
DEBUG - 2018-10-09 12:47:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 12:47:06 --> CSRF cookie sent
INFO - 2018-10-09 12:47:06 --> Input Class Initialized
INFO - 2018-10-09 12:47:06 --> Language Class Initialized
INFO - 2018-10-09 12:47:06 --> Loader Class Initialized
INFO - 2018-10-09 12:47:06 --> Helper loaded: url_helper
INFO - 2018-10-09 12:47:06 --> Helper loaded: form_helper
INFO - 2018-10-09 12:47:06 --> Helper loaded: language_helper
DEBUG - 2018-10-09 12:47:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 12:47:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 12:47:06 --> User Agent Class Initialized
INFO - 2018-10-09 12:47:06 --> Controller Class Initialized
INFO - 2018-10-09 12:47:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 12:47:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 12:47:06 --> Pixel_Model class loaded
INFO - 2018-10-09 12:47:06 --> Database Driver Class Initialized
INFO - 2018-10-09 12:47:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 12:47:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 12:47:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-10-09 12:47:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 12:47:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-09 12:47:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 12:47:06 --> Final output sent to browser
DEBUG - 2018-10-09 12:47:06 --> Total execution time: 0.0533
INFO - 2018-10-09 12:47:07 --> Config Class Initialized
INFO - 2018-10-09 12:47:07 --> Hooks Class Initialized
DEBUG - 2018-10-09 12:47:07 --> UTF-8 Support Enabled
INFO - 2018-10-09 12:47:07 --> Utf8 Class Initialized
INFO - 2018-10-09 12:47:07 --> URI Class Initialized
DEBUG - 2018-10-09 12:47:07 --> No URI present. Default controller set.
INFO - 2018-10-09 12:47:07 --> Router Class Initialized
INFO - 2018-10-09 12:47:07 --> Output Class Initialized
INFO - 2018-10-09 12:47:07 --> Security Class Initialized
DEBUG - 2018-10-09 12:47:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 12:47:07 --> CSRF cookie sent
INFO - 2018-10-09 12:47:07 --> Input Class Initialized
INFO - 2018-10-09 12:47:07 --> Language Class Initialized
INFO - 2018-10-09 12:47:07 --> Loader Class Initialized
INFO - 2018-10-09 12:47:07 --> Helper loaded: url_helper
INFO - 2018-10-09 12:47:07 --> Helper loaded: form_helper
INFO - 2018-10-09 12:47:07 --> Helper loaded: language_helper
DEBUG - 2018-10-09 12:47:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 12:47:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 12:47:07 --> User Agent Class Initialized
INFO - 2018-10-09 12:47:07 --> Controller Class Initialized
INFO - 2018-10-09 12:47:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 12:47:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 12:47:07 --> Pixel_Model class loaded
INFO - 2018-10-09 12:47:07 --> Database Driver Class Initialized
INFO - 2018-10-09 12:47:07 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 12:47:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 12:47:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-10-09 12:47:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 12:47:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-09 12:47:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 12:47:07 --> Final output sent to browser
DEBUG - 2018-10-09 12:47:07 --> Total execution time: 0.0481
INFO - 2018-10-09 12:47:10 --> Config Class Initialized
INFO - 2018-10-09 12:47:10 --> Hooks Class Initialized
DEBUG - 2018-10-09 12:47:10 --> UTF-8 Support Enabled
INFO - 2018-10-09 12:47:10 --> Utf8 Class Initialized
INFO - 2018-10-09 12:47:10 --> URI Class Initialized
INFO - 2018-10-09 12:47:10 --> Router Class Initialized
INFO - 2018-10-09 12:47:10 --> Output Class Initialized
INFO - 2018-10-09 12:47:10 --> Security Class Initialized
DEBUG - 2018-10-09 12:47:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 12:47:10 --> CSRF cookie sent
INFO - 2018-10-09 12:47:10 --> Input Class Initialized
INFO - 2018-10-09 12:47:10 --> Language Class Initialized
INFO - 2018-10-09 12:47:10 --> Loader Class Initialized
INFO - 2018-10-09 12:47:10 --> Helper loaded: url_helper
INFO - 2018-10-09 12:47:10 --> Helper loaded: form_helper
INFO - 2018-10-09 12:47:10 --> Helper loaded: language_helper
DEBUG - 2018-10-09 12:47:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 12:47:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 12:47:10 --> User Agent Class Initialized
INFO - 2018-10-09 12:47:10 --> Controller Class Initialized
INFO - 2018-10-09 12:47:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 12:47:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 12:47:10 --> Pixel_Model class loaded
INFO - 2018-10-09 12:47:10 --> Database Driver Class Initialized
INFO - 2018-10-09 12:47:10 --> Model "MyAccountModel" initialized
INFO - 2018-10-09 12:47:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 12:47:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-10-09 12:47:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 12:47:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 12:47:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 12:47:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/import_enduser.php
INFO - 2018-10-09 12:47:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 12:47:10 --> Final output sent to browser
DEBUG - 2018-10-09 12:47:10 --> Total execution time: 0.0490
INFO - 2018-10-09 12:47:15 --> Config Class Initialized
INFO - 2018-10-09 12:47:15 --> Hooks Class Initialized
DEBUG - 2018-10-09 12:47:15 --> UTF-8 Support Enabled
INFO - 2018-10-09 12:47:15 --> Utf8 Class Initialized
INFO - 2018-10-09 12:47:15 --> URI Class Initialized
INFO - 2018-10-09 12:47:15 --> Router Class Initialized
INFO - 2018-10-09 12:47:15 --> Output Class Initialized
INFO - 2018-10-09 12:47:15 --> Security Class Initialized
DEBUG - 2018-10-09 12:47:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 12:47:15 --> CSRF cookie sent
INFO - 2018-10-09 12:47:15 --> Input Class Initialized
INFO - 2018-10-09 12:47:15 --> Language Class Initialized
INFO - 2018-10-09 12:47:15 --> Loader Class Initialized
INFO - 2018-10-09 12:47:15 --> Helper loaded: url_helper
INFO - 2018-10-09 12:47:15 --> Helper loaded: form_helper
INFO - 2018-10-09 12:47:15 --> Helper loaded: language_helper
DEBUG - 2018-10-09 12:47:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 12:47:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 12:47:15 --> User Agent Class Initialized
INFO - 2018-10-09 12:47:15 --> Controller Class Initialized
INFO - 2018-10-09 12:47:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 12:47:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 12:47:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 12:47:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_fa_nav.php
INFO - 2018-10-09 12:47:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 12:47:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 12:47:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 12:47:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/wedding_gifts.php
INFO - 2018-10-09 12:47:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 12:47:15 --> Final output sent to browser
DEBUG - 2018-10-09 12:47:15 --> Total execution time: 0.0234
INFO - 2018-10-09 12:48:19 --> Config Class Initialized
INFO - 2018-10-09 12:48:19 --> Hooks Class Initialized
DEBUG - 2018-10-09 12:48:19 --> UTF-8 Support Enabled
INFO - 2018-10-09 12:48:19 --> Utf8 Class Initialized
INFO - 2018-10-09 12:48:19 --> URI Class Initialized
INFO - 2018-10-09 12:48:19 --> Router Class Initialized
INFO - 2018-10-09 12:48:19 --> Output Class Initialized
INFO - 2018-10-09 12:48:19 --> Security Class Initialized
DEBUG - 2018-10-09 12:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 12:48:19 --> CSRF cookie sent
INFO - 2018-10-09 12:48:19 --> Input Class Initialized
INFO - 2018-10-09 12:48:19 --> Language Class Initialized
INFO - 2018-10-09 12:48:19 --> Loader Class Initialized
INFO - 2018-10-09 12:48:19 --> Helper loaded: url_helper
INFO - 2018-10-09 12:48:19 --> Helper loaded: form_helper
INFO - 2018-10-09 12:48:19 --> Helper loaded: language_helper
DEBUG - 2018-10-09 12:48:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 12:48:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 12:48:19 --> User Agent Class Initialized
INFO - 2018-10-09 12:48:19 --> Controller Class Initialized
INFO - 2018-10-09 12:48:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 12:48:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 12:48:19 --> CSRF cookie sent
INFO - 2018-10-09 12:48:19 --> Config Class Initialized
INFO - 2018-10-09 12:48:19 --> Hooks Class Initialized
DEBUG - 2018-10-09 12:48:19 --> UTF-8 Support Enabled
INFO - 2018-10-09 12:48:19 --> Utf8 Class Initialized
INFO - 2018-10-09 12:48:19 --> URI Class Initialized
DEBUG - 2018-10-09 12:48:19 --> No URI present. Default controller set.
INFO - 2018-10-09 12:48:19 --> Router Class Initialized
INFO - 2018-10-09 12:48:19 --> Output Class Initialized
INFO - 2018-10-09 12:48:19 --> Security Class Initialized
DEBUG - 2018-10-09 12:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 12:48:19 --> CSRF cookie sent
INFO - 2018-10-09 12:48:19 --> Input Class Initialized
INFO - 2018-10-09 12:48:19 --> Language Class Initialized
INFO - 2018-10-09 12:48:19 --> Loader Class Initialized
INFO - 2018-10-09 12:48:19 --> Helper loaded: url_helper
INFO - 2018-10-09 12:48:19 --> Helper loaded: form_helper
INFO - 2018-10-09 12:48:19 --> Helper loaded: language_helper
DEBUG - 2018-10-09 12:48:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 12:48:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 12:48:19 --> User Agent Class Initialized
INFO - 2018-10-09 12:48:19 --> Controller Class Initialized
INFO - 2018-10-09 12:48:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 12:48:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 12:48:19 --> Pixel_Model class loaded
INFO - 2018-10-09 12:48:19 --> Database Driver Class Initialized
INFO - 2018-10-09 12:48:19 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 12:48:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 12:48:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 12:48:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-09 12:48:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 12:48:19 --> Final output sent to browser
DEBUG - 2018-10-09 12:48:19 --> Total execution time: 0.0417
INFO - 2018-10-09 12:48:22 --> Config Class Initialized
INFO - 2018-10-09 12:48:22 --> Hooks Class Initialized
DEBUG - 2018-10-09 12:48:22 --> UTF-8 Support Enabled
INFO - 2018-10-09 12:48:22 --> Utf8 Class Initialized
INFO - 2018-10-09 12:48:22 --> URI Class Initialized
INFO - 2018-10-09 12:48:22 --> Router Class Initialized
INFO - 2018-10-09 12:48:22 --> Output Class Initialized
INFO - 2018-10-09 12:48:22 --> Security Class Initialized
DEBUG - 2018-10-09 12:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 12:48:22 --> CSRF cookie sent
INFO - 2018-10-09 12:48:22 --> Input Class Initialized
INFO - 2018-10-09 12:48:22 --> Language Class Initialized
INFO - 2018-10-09 12:48:22 --> Loader Class Initialized
INFO - 2018-10-09 12:48:22 --> Helper loaded: url_helper
INFO - 2018-10-09 12:48:22 --> Helper loaded: form_helper
INFO - 2018-10-09 12:48:22 --> Helper loaded: language_helper
DEBUG - 2018-10-09 12:48:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 12:48:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 12:48:22 --> User Agent Class Initialized
INFO - 2018-10-09 12:48:22 --> Controller Class Initialized
INFO - 2018-10-09 12:48:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 12:48:22 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-09 12:48:22 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-10-09 12:48:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 12:48:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 12:48:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 12:48:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-10-09 12:48:22 --> Could not find the language line "req_email"
INFO - 2018-10-09 12:48:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-10-09 12:48:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 12:48:22 --> Final output sent to browser
DEBUG - 2018-10-09 12:48:22 --> Total execution time: 0.0367
INFO - 2018-10-09 12:48:37 --> Config Class Initialized
INFO - 2018-10-09 12:48:37 --> Hooks Class Initialized
DEBUG - 2018-10-09 12:48:37 --> UTF-8 Support Enabled
INFO - 2018-10-09 12:48:37 --> Utf8 Class Initialized
INFO - 2018-10-09 12:48:37 --> URI Class Initialized
INFO - 2018-10-09 12:48:37 --> Router Class Initialized
INFO - 2018-10-09 12:48:37 --> Output Class Initialized
INFO - 2018-10-09 12:48:37 --> Security Class Initialized
DEBUG - 2018-10-09 12:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 12:48:37 --> CSRF cookie sent
INFO - 2018-10-09 12:48:37 --> CSRF token verified
INFO - 2018-10-09 12:48:37 --> Input Class Initialized
INFO - 2018-10-09 12:48:37 --> Language Class Initialized
INFO - 2018-10-09 12:48:37 --> Loader Class Initialized
INFO - 2018-10-09 12:48:37 --> Helper loaded: url_helper
INFO - 2018-10-09 12:48:37 --> Helper loaded: form_helper
INFO - 2018-10-09 12:48:37 --> Helper loaded: language_helper
DEBUG - 2018-10-09 12:48:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 12:48:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 12:48:37 --> User Agent Class Initialized
INFO - 2018-10-09 12:48:37 --> Controller Class Initialized
INFO - 2018-10-09 12:48:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 12:48:37 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-09 12:48:37 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-10-09 12:48:37 --> Form Validation Class Initialized
INFO - 2018-10-09 12:48:37 --> Pixel_Model class loaded
INFO - 2018-10-09 12:48:37 --> Database Driver Class Initialized
INFO - 2018-10-09 12:48:37 --> Model "AuthenticationModel" initialized
INFO - 2018-10-09 12:48:37 --> Config Class Initialized
INFO - 2018-10-09 12:48:37 --> Hooks Class Initialized
DEBUG - 2018-10-09 12:48:37 --> UTF-8 Support Enabled
INFO - 2018-10-09 12:48:37 --> Utf8 Class Initialized
INFO - 2018-10-09 12:48:37 --> URI Class Initialized
DEBUG - 2018-10-09 12:48:37 --> No URI present. Default controller set.
INFO - 2018-10-09 12:48:37 --> Router Class Initialized
INFO - 2018-10-09 12:48:37 --> Output Class Initialized
INFO - 2018-10-09 12:48:37 --> Security Class Initialized
DEBUG - 2018-10-09 12:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 12:48:37 --> CSRF cookie sent
INFO - 2018-10-09 12:48:37 --> Input Class Initialized
INFO - 2018-10-09 12:48:37 --> Language Class Initialized
INFO - 2018-10-09 12:48:37 --> Loader Class Initialized
INFO - 2018-10-09 12:48:37 --> Helper loaded: url_helper
INFO - 2018-10-09 12:48:37 --> Helper loaded: form_helper
INFO - 2018-10-09 12:48:37 --> Helper loaded: language_helper
DEBUG - 2018-10-09 12:48:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 12:48:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 12:48:37 --> User Agent Class Initialized
INFO - 2018-10-09 12:48:37 --> Controller Class Initialized
INFO - 2018-10-09 12:48:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 12:48:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 12:48:37 --> Pixel_Model class loaded
INFO - 2018-10-09 12:48:37 --> Database Driver Class Initialized
INFO - 2018-10-09 12:48:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 12:48:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 12:48:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-09 12:48:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 12:48:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-09 12:48:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 12:48:37 --> Final output sent to browser
DEBUG - 2018-10-09 12:48:37 --> Total execution time: 0.0382
INFO - 2018-10-09 12:48:57 --> Config Class Initialized
INFO - 2018-10-09 12:48:57 --> Hooks Class Initialized
DEBUG - 2018-10-09 12:48:57 --> UTF-8 Support Enabled
INFO - 2018-10-09 12:48:57 --> Utf8 Class Initialized
INFO - 2018-10-09 12:48:57 --> URI Class Initialized
INFO - 2018-10-09 12:48:57 --> Router Class Initialized
INFO - 2018-10-09 12:48:57 --> Output Class Initialized
INFO - 2018-10-09 12:48:57 --> Security Class Initialized
DEBUG - 2018-10-09 12:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 12:48:57 --> CSRF cookie sent
INFO - 2018-10-09 12:48:57 --> Input Class Initialized
INFO - 2018-10-09 12:48:57 --> Language Class Initialized
INFO - 2018-10-09 12:48:57 --> Loader Class Initialized
INFO - 2018-10-09 12:48:57 --> Helper loaded: url_helper
INFO - 2018-10-09 12:48:57 --> Helper loaded: form_helper
INFO - 2018-10-09 12:48:57 --> Helper loaded: language_helper
DEBUG - 2018-10-09 12:48:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 12:48:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 12:48:57 --> User Agent Class Initialized
INFO - 2018-10-09 12:48:57 --> Controller Class Initialized
INFO - 2018-10-09 12:48:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 12:48:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 12:48:57 --> Pixel_Model class loaded
INFO - 2018-10-09 12:48:57 --> Database Driver Class Initialized
INFO - 2018-10-09 12:48:57 --> Model "MyAccountModel" initialized
INFO - 2018-10-09 12:48:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 12:48:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-09 12:48:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 12:48:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 12:48:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 12:48:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/change_order.php
INFO - 2018-10-09 12:48:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 12:48:57 --> Final output sent to browser
DEBUG - 2018-10-09 12:48:57 --> Total execution time: 0.0353
INFO - 2018-10-09 12:49:18 --> Config Class Initialized
INFO - 2018-10-09 12:49:18 --> Hooks Class Initialized
DEBUG - 2018-10-09 12:49:18 --> UTF-8 Support Enabled
INFO - 2018-10-09 12:49:18 --> Utf8 Class Initialized
INFO - 2018-10-09 12:49:18 --> URI Class Initialized
INFO - 2018-10-09 12:49:18 --> Router Class Initialized
INFO - 2018-10-09 12:49:18 --> Output Class Initialized
INFO - 2018-10-09 12:49:18 --> Security Class Initialized
DEBUG - 2018-10-09 12:49:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 12:49:18 --> CSRF cookie sent
INFO - 2018-10-09 12:49:18 --> Input Class Initialized
INFO - 2018-10-09 12:49:18 --> Language Class Initialized
INFO - 2018-10-09 12:49:18 --> Loader Class Initialized
INFO - 2018-10-09 12:49:18 --> Helper loaded: url_helper
INFO - 2018-10-09 12:49:18 --> Helper loaded: form_helper
INFO - 2018-10-09 12:49:18 --> Helper loaded: language_helper
DEBUG - 2018-10-09 12:49:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 12:49:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 12:49:18 --> User Agent Class Initialized
INFO - 2018-10-09 12:49:18 --> Controller Class Initialized
INFO - 2018-10-09 12:49:18 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 12:49:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 12:49:18 --> Pixel_Model class loaded
INFO - 2018-10-09 12:49:18 --> Database Driver Class Initialized
INFO - 2018-10-09 12:49:18 --> Model "MyAccountModel" initialized
INFO - 2018-10-09 12:49:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-09 12:49:18 --> Pagination Class Initialized
INFO - 2018-10-09 12:49:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 12:49:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-09 12:49:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 12:49:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 12:49:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 12:49:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/question_list.php
INFO - 2018-10-09 12:49:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 12:49:18 --> Final output sent to browser
DEBUG - 2018-10-09 12:49:18 --> Total execution time: 0.0461
INFO - 2018-10-09 12:49:26 --> Config Class Initialized
INFO - 2018-10-09 12:49:26 --> Hooks Class Initialized
DEBUG - 2018-10-09 12:49:26 --> UTF-8 Support Enabled
INFO - 2018-10-09 12:49:26 --> Utf8 Class Initialized
INFO - 2018-10-09 12:49:26 --> URI Class Initialized
INFO - 2018-10-09 12:49:26 --> Router Class Initialized
INFO - 2018-10-09 12:49:26 --> Output Class Initialized
INFO - 2018-10-09 12:49:26 --> Security Class Initialized
DEBUG - 2018-10-09 12:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 12:49:26 --> CSRF cookie sent
INFO - 2018-10-09 12:49:26 --> Input Class Initialized
INFO - 2018-10-09 12:49:26 --> Language Class Initialized
INFO - 2018-10-09 12:49:26 --> Loader Class Initialized
INFO - 2018-10-09 12:49:26 --> Helper loaded: url_helper
INFO - 2018-10-09 12:49:26 --> Helper loaded: form_helper
INFO - 2018-10-09 12:49:26 --> Helper loaded: language_helper
DEBUG - 2018-10-09 12:49:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 12:49:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 12:49:26 --> User Agent Class Initialized
INFO - 2018-10-09 12:49:26 --> Controller Class Initialized
INFO - 2018-10-09 12:49:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 12:49:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 12:49:26 --> Pixel_Model class loaded
INFO - 2018-10-09 12:49:26 --> Database Driver Class Initialized
INFO - 2018-10-09 12:49:26 --> Model "MyAccountModel" initialized
INFO - 2018-10-09 12:49:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 12:49:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-09 12:49:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 12:49:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 12:49:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 12:49:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/edit_question.php
INFO - 2018-10-09 12:49:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 12:49:26 --> Final output sent to browser
DEBUG - 2018-10-09 12:49:26 --> Total execution time: 0.0336
INFO - 2018-10-09 12:49:29 --> Config Class Initialized
INFO - 2018-10-09 12:49:29 --> Hooks Class Initialized
DEBUG - 2018-10-09 12:49:29 --> UTF-8 Support Enabled
INFO - 2018-10-09 12:49:29 --> Utf8 Class Initialized
INFO - 2018-10-09 12:49:29 --> URI Class Initialized
INFO - 2018-10-09 12:49:29 --> Router Class Initialized
INFO - 2018-10-09 12:49:29 --> Output Class Initialized
INFO - 2018-10-09 12:49:29 --> Security Class Initialized
DEBUG - 2018-10-09 12:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 12:49:29 --> CSRF cookie sent
INFO - 2018-10-09 12:49:29 --> Input Class Initialized
INFO - 2018-10-09 12:49:29 --> Language Class Initialized
INFO - 2018-10-09 12:49:29 --> Loader Class Initialized
INFO - 2018-10-09 12:49:29 --> Helper loaded: url_helper
INFO - 2018-10-09 12:49:29 --> Helper loaded: form_helper
INFO - 2018-10-09 12:49:29 --> Helper loaded: language_helper
DEBUG - 2018-10-09 12:49:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 12:49:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 12:49:29 --> User Agent Class Initialized
INFO - 2018-10-09 12:49:29 --> Controller Class Initialized
INFO - 2018-10-09 12:49:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 12:49:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 12:49:29 --> Pixel_Model class loaded
INFO - 2018-10-09 12:49:29 --> Database Driver Class Initialized
INFO - 2018-10-09 12:49:29 --> Model "MyAccountModel" initialized
INFO - 2018-10-09 12:49:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-09 12:49:29 --> Pagination Class Initialized
INFO - 2018-10-09 12:49:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 12:49:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-09 12:49:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 12:49:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 12:49:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 12:49:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/question_list.php
INFO - 2018-10-09 12:49:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 12:49:29 --> Final output sent to browser
DEBUG - 2018-10-09 12:49:29 --> Total execution time: 0.0392
INFO - 2018-10-09 12:49:51 --> Config Class Initialized
INFO - 2018-10-09 12:49:51 --> Hooks Class Initialized
DEBUG - 2018-10-09 12:49:51 --> UTF-8 Support Enabled
INFO - 2018-10-09 12:49:51 --> Utf8 Class Initialized
INFO - 2018-10-09 12:49:51 --> URI Class Initialized
INFO - 2018-10-09 12:49:51 --> Router Class Initialized
INFO - 2018-10-09 12:49:51 --> Output Class Initialized
INFO - 2018-10-09 12:49:51 --> Security Class Initialized
DEBUG - 2018-10-09 12:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 12:49:51 --> CSRF cookie sent
INFO - 2018-10-09 12:49:51 --> Input Class Initialized
INFO - 2018-10-09 12:49:51 --> Language Class Initialized
INFO - 2018-10-09 12:49:51 --> Loader Class Initialized
INFO - 2018-10-09 12:49:51 --> Helper loaded: url_helper
INFO - 2018-10-09 12:49:51 --> Helper loaded: form_helper
INFO - 2018-10-09 12:49:51 --> Helper loaded: language_helper
DEBUG - 2018-10-09 12:49:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 12:49:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 12:49:51 --> User Agent Class Initialized
INFO - 2018-10-09 12:49:51 --> Controller Class Initialized
INFO - 2018-10-09 12:49:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 12:49:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 12:49:51 --> Pixel_Model class loaded
INFO - 2018-10-09 12:49:51 --> Database Driver Class Initialized
INFO - 2018-10-09 12:49:51 --> Model "MyAccountModel" initialized
INFO - 2018-10-09 12:49:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 12:49:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-09 12:49:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 12:49:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 12:49:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 12:49:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/change_order.php
INFO - 2018-10-09 12:49:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 12:49:51 --> Final output sent to browser
DEBUG - 2018-10-09 12:49:51 --> Total execution time: 0.0476
INFO - 2018-10-09 13:01:34 --> Config Class Initialized
INFO - 2018-10-09 13:01:34 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:01:34 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:01:34 --> Utf8 Class Initialized
INFO - 2018-10-09 13:01:34 --> URI Class Initialized
INFO - 2018-10-09 13:01:34 --> Router Class Initialized
INFO - 2018-10-09 13:01:34 --> Output Class Initialized
INFO - 2018-10-09 13:01:34 --> Security Class Initialized
DEBUG - 2018-10-09 13:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:01:34 --> CSRF cookie sent
INFO - 2018-10-09 13:01:34 --> Input Class Initialized
INFO - 2018-10-09 13:01:34 --> Language Class Initialized
INFO - 2018-10-09 13:01:34 --> Loader Class Initialized
INFO - 2018-10-09 13:01:34 --> Helper loaded: url_helper
INFO - 2018-10-09 13:01:34 --> Helper loaded: form_helper
INFO - 2018-10-09 13:01:34 --> Helper loaded: language_helper
DEBUG - 2018-10-09 13:01:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 13:01:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:01:34 --> User Agent Class Initialized
INFO - 2018-10-09 13:01:34 --> Controller Class Initialized
INFO - 2018-10-09 13:01:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 13:01:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 13:01:34 --> Pixel_Model class loaded
INFO - 2018-10-09 13:01:34 --> Database Driver Class Initialized
INFO - 2018-10-09 13:01:34 --> Model "MyAccountModel" initialized
INFO - 2018-10-09 13:01:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 13:01:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-09 13:01:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 13:01:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 13:01:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 13:01:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/change_order.php
INFO - 2018-10-09 13:01:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 13:01:34 --> Final output sent to browser
DEBUG - 2018-10-09 13:01:34 --> Total execution time: 0.0367
INFO - 2018-10-09 13:10:04 --> Config Class Initialized
INFO - 2018-10-09 13:10:04 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:10:04 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:10:04 --> Utf8 Class Initialized
INFO - 2018-10-09 13:10:04 --> URI Class Initialized
INFO - 2018-10-09 13:10:04 --> Router Class Initialized
INFO - 2018-10-09 13:10:04 --> Output Class Initialized
INFO - 2018-10-09 13:10:04 --> Security Class Initialized
DEBUG - 2018-10-09 13:10:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:10:04 --> CSRF cookie sent
INFO - 2018-10-09 13:10:04 --> Input Class Initialized
INFO - 2018-10-09 13:10:04 --> Language Class Initialized
INFO - 2018-10-09 13:10:04 --> Loader Class Initialized
INFO - 2018-10-09 13:10:04 --> Helper loaded: url_helper
INFO - 2018-10-09 13:10:04 --> Helper loaded: form_helper
INFO - 2018-10-09 13:10:04 --> Helper loaded: language_helper
DEBUG - 2018-10-09 13:10:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 13:10:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:10:04 --> User Agent Class Initialized
INFO - 2018-10-09 13:10:04 --> Controller Class Initialized
INFO - 2018-10-09 13:10:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 13:10:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 13:10:04 --> Pixel_Model class loaded
INFO - 2018-10-09 13:10:04 --> Database Driver Class Initialized
INFO - 2018-10-09 13:10:04 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:10:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 13:10:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-09 13:10:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 13:10:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 13:10:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 13:10:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 13:10:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 13:10:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-10-09 13:10:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 13:10:04 --> Final output sent to browser
DEBUG - 2018-10-09 13:10:04 --> Total execution time: 0.0531
INFO - 2018-10-09 13:10:08 --> Config Class Initialized
INFO - 2018-10-09 13:10:08 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:10:08 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:10:08 --> Utf8 Class Initialized
INFO - 2018-10-09 13:10:08 --> URI Class Initialized
INFO - 2018-10-09 13:10:08 --> Router Class Initialized
INFO - 2018-10-09 13:10:08 --> Output Class Initialized
INFO - 2018-10-09 13:10:08 --> Security Class Initialized
DEBUG - 2018-10-09 13:10:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:10:08 --> CSRF cookie sent
INFO - 2018-10-09 13:10:08 --> CSRF token verified
INFO - 2018-10-09 13:10:08 --> Input Class Initialized
INFO - 2018-10-09 13:10:08 --> Language Class Initialized
INFO - 2018-10-09 13:10:08 --> Loader Class Initialized
INFO - 2018-10-09 13:10:08 --> Helper loaded: url_helper
INFO - 2018-10-09 13:10:08 --> Helper loaded: form_helper
INFO - 2018-10-09 13:10:08 --> Helper loaded: language_helper
DEBUG - 2018-10-09 13:10:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 13:10:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:10:08 --> User Agent Class Initialized
INFO - 2018-10-09 13:10:08 --> Controller Class Initialized
INFO - 2018-10-09 13:10:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 13:10:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 13:10:08 --> Pixel_Model class loaded
INFO - 2018-10-09 13:10:08 --> Database Driver Class Initialized
INFO - 2018-10-09 13:10:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:10:08 --> Form Validation Class Initialized
INFO - 2018-10-09 13:10:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 13:10:08 --> Database Driver Class Initialized
INFO - 2018-10-09 13:10:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:10:08 --> Config Class Initialized
INFO - 2018-10-09 13:10:08 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:10:08 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:10:08 --> Utf8 Class Initialized
INFO - 2018-10-09 13:10:08 --> URI Class Initialized
INFO - 2018-10-09 13:10:08 --> Router Class Initialized
INFO - 2018-10-09 13:10:08 --> Output Class Initialized
INFO - 2018-10-09 13:10:08 --> Security Class Initialized
DEBUG - 2018-10-09 13:10:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:10:08 --> CSRF cookie sent
INFO - 2018-10-09 13:10:08 --> Input Class Initialized
INFO - 2018-10-09 13:10:08 --> Language Class Initialized
INFO - 2018-10-09 13:10:08 --> Loader Class Initialized
INFO - 2018-10-09 13:10:08 --> Helper loaded: url_helper
INFO - 2018-10-09 13:10:08 --> Helper loaded: form_helper
INFO - 2018-10-09 13:10:08 --> Helper loaded: language_helper
DEBUG - 2018-10-09 13:10:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 13:10:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:10:08 --> User Agent Class Initialized
INFO - 2018-10-09 13:10:08 --> Controller Class Initialized
INFO - 2018-10-09 13:10:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 13:10:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 13:10:08 --> Pixel_Model class loaded
INFO - 2018-10-09 13:10:08 --> Database Driver Class Initialized
INFO - 2018-10-09 13:10:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:10:08 --> Database Driver Class Initialized
INFO - 2018-10-09 13:10:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:10:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 13:10:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-09 13:10:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 13:10:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 13:10:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 13:10:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 13:10:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 13:10:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-09 13:10:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 13:10:08 --> Final output sent to browser
DEBUG - 2018-10-09 13:10:08 --> Total execution time: 0.0480
INFO - 2018-10-09 13:10:10 --> Config Class Initialized
INFO - 2018-10-09 13:10:10 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:10:10 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:10:10 --> Utf8 Class Initialized
INFO - 2018-10-09 13:10:10 --> URI Class Initialized
INFO - 2018-10-09 13:10:10 --> Router Class Initialized
INFO - 2018-10-09 13:10:10 --> Output Class Initialized
INFO - 2018-10-09 13:10:10 --> Security Class Initialized
DEBUG - 2018-10-09 13:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:10:10 --> CSRF cookie sent
INFO - 2018-10-09 13:10:10 --> CSRF token verified
INFO - 2018-10-09 13:10:10 --> Input Class Initialized
INFO - 2018-10-09 13:10:10 --> Language Class Initialized
INFO - 2018-10-09 13:10:10 --> Loader Class Initialized
INFO - 2018-10-09 13:10:10 --> Helper loaded: url_helper
INFO - 2018-10-09 13:10:10 --> Helper loaded: form_helper
INFO - 2018-10-09 13:10:10 --> Helper loaded: language_helper
DEBUG - 2018-10-09 13:10:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 13:10:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:10:10 --> User Agent Class Initialized
INFO - 2018-10-09 13:10:10 --> Controller Class Initialized
INFO - 2018-10-09 13:10:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 13:10:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 13:10:10 --> Pixel_Model class loaded
INFO - 2018-10-09 13:10:10 --> Database Driver Class Initialized
INFO - 2018-10-09 13:10:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:10:10 --> Form Validation Class Initialized
INFO - 2018-10-09 13:10:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 13:10:10 --> Database Driver Class Initialized
INFO - 2018-10-09 13:10:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:10:11 --> Config Class Initialized
INFO - 2018-10-09 13:10:11 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:10:11 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:10:11 --> Utf8 Class Initialized
INFO - 2018-10-09 13:10:11 --> URI Class Initialized
INFO - 2018-10-09 13:10:11 --> Router Class Initialized
INFO - 2018-10-09 13:10:11 --> Output Class Initialized
INFO - 2018-10-09 13:10:11 --> Security Class Initialized
DEBUG - 2018-10-09 13:10:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:10:11 --> CSRF cookie sent
INFO - 2018-10-09 13:10:11 --> Input Class Initialized
INFO - 2018-10-09 13:10:11 --> Language Class Initialized
INFO - 2018-10-09 13:10:11 --> Loader Class Initialized
INFO - 2018-10-09 13:10:11 --> Helper loaded: url_helper
INFO - 2018-10-09 13:10:11 --> Helper loaded: form_helper
INFO - 2018-10-09 13:10:11 --> Helper loaded: language_helper
DEBUG - 2018-10-09 13:10:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 13:10:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:10:11 --> User Agent Class Initialized
INFO - 2018-10-09 13:10:11 --> Controller Class Initialized
INFO - 2018-10-09 13:10:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 13:10:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 13:10:11 --> Pixel_Model class loaded
INFO - 2018-10-09 13:10:11 --> Database Driver Class Initialized
INFO - 2018-10-09 13:10:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:10:11 --> Database Driver Class Initialized
INFO - 2018-10-09 13:10:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:10:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 13:10:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-09 13:10:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 13:10:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 13:10:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 13:10:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 13:10:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 13:10:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-10-09 13:10:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 13:10:11 --> Final output sent to browser
DEBUG - 2018-10-09 13:10:11 --> Total execution time: 0.0475
INFO - 2018-10-09 13:10:12 --> Config Class Initialized
INFO - 2018-10-09 13:10:12 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:10:12 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:10:12 --> Utf8 Class Initialized
INFO - 2018-10-09 13:10:12 --> URI Class Initialized
INFO - 2018-10-09 13:10:12 --> Router Class Initialized
INFO - 2018-10-09 13:10:12 --> Output Class Initialized
INFO - 2018-10-09 13:10:12 --> Security Class Initialized
DEBUG - 2018-10-09 13:10:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:10:12 --> CSRF cookie sent
INFO - 2018-10-09 13:10:12 --> CSRF token verified
INFO - 2018-10-09 13:10:12 --> Input Class Initialized
INFO - 2018-10-09 13:10:12 --> Language Class Initialized
INFO - 2018-10-09 13:10:12 --> Loader Class Initialized
INFO - 2018-10-09 13:10:12 --> Helper loaded: url_helper
INFO - 2018-10-09 13:10:12 --> Helper loaded: form_helper
INFO - 2018-10-09 13:10:12 --> Helper loaded: language_helper
DEBUG - 2018-10-09 13:10:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 13:10:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:10:12 --> User Agent Class Initialized
INFO - 2018-10-09 13:10:12 --> Controller Class Initialized
INFO - 2018-10-09 13:10:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 13:10:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 13:10:12 --> Pixel_Model class loaded
INFO - 2018-10-09 13:10:12 --> Database Driver Class Initialized
INFO - 2018-10-09 13:10:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:10:12 --> Form Validation Class Initialized
INFO - 2018-10-09 13:10:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 13:10:12 --> Database Driver Class Initialized
INFO - 2018-10-09 13:10:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:10:12 --> Config Class Initialized
INFO - 2018-10-09 13:10:12 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:10:12 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:10:12 --> Utf8 Class Initialized
INFO - 2018-10-09 13:10:12 --> URI Class Initialized
INFO - 2018-10-09 13:10:12 --> Router Class Initialized
INFO - 2018-10-09 13:10:12 --> Output Class Initialized
INFO - 2018-10-09 13:10:12 --> Security Class Initialized
DEBUG - 2018-10-09 13:10:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:10:12 --> CSRF cookie sent
INFO - 2018-10-09 13:10:12 --> Input Class Initialized
INFO - 2018-10-09 13:10:12 --> Language Class Initialized
INFO - 2018-10-09 13:10:12 --> Loader Class Initialized
INFO - 2018-10-09 13:10:12 --> Helper loaded: url_helper
INFO - 2018-10-09 13:10:12 --> Helper loaded: form_helper
INFO - 2018-10-09 13:10:12 --> Helper loaded: language_helper
DEBUG - 2018-10-09 13:10:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 13:10:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:10:12 --> User Agent Class Initialized
INFO - 2018-10-09 13:10:12 --> Controller Class Initialized
INFO - 2018-10-09 13:10:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 13:10:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 13:10:12 --> Pixel_Model class loaded
INFO - 2018-10-09 13:10:12 --> Database Driver Class Initialized
INFO - 2018-10-09 13:10:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:10:12 --> Database Driver Class Initialized
INFO - 2018-10-09 13:10:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:10:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 13:10:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-09 13:10:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 13:10:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-10-09 13:10:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 13:10:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 13:10:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 13:10:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 13:10:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-10-09 13:10:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 13:10:12 --> Final output sent to browser
DEBUG - 2018-10-09 13:10:12 --> Total execution time: 0.0442
INFO - 2018-10-09 13:10:19 --> Config Class Initialized
INFO - 2018-10-09 13:10:19 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:10:19 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:10:19 --> Utf8 Class Initialized
INFO - 2018-10-09 13:10:19 --> URI Class Initialized
INFO - 2018-10-09 13:10:19 --> Router Class Initialized
INFO - 2018-10-09 13:10:19 --> Output Class Initialized
INFO - 2018-10-09 13:10:19 --> Security Class Initialized
DEBUG - 2018-10-09 13:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:10:19 --> CSRF cookie sent
INFO - 2018-10-09 13:10:19 --> CSRF token verified
INFO - 2018-10-09 13:10:19 --> Input Class Initialized
INFO - 2018-10-09 13:10:19 --> Language Class Initialized
INFO - 2018-10-09 13:10:19 --> Loader Class Initialized
INFO - 2018-10-09 13:10:19 --> Helper loaded: url_helper
INFO - 2018-10-09 13:10:19 --> Helper loaded: form_helper
INFO - 2018-10-09 13:10:19 --> Helper loaded: language_helper
DEBUG - 2018-10-09 13:10:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 13:10:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:10:19 --> User Agent Class Initialized
INFO - 2018-10-09 13:10:19 --> Controller Class Initialized
INFO - 2018-10-09 13:10:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 13:10:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 13:10:19 --> Pixel_Model class loaded
INFO - 2018-10-09 13:10:19 --> Database Driver Class Initialized
INFO - 2018-10-09 13:10:19 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:10:19 --> Form Validation Class Initialized
INFO - 2018-10-09 13:10:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 13:10:19 --> Database Driver Class Initialized
INFO - 2018-10-09 13:10:19 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:10:19 --> Config Class Initialized
INFO - 2018-10-09 13:10:19 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:10:19 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:10:19 --> Utf8 Class Initialized
INFO - 2018-10-09 13:10:19 --> URI Class Initialized
INFO - 2018-10-09 13:10:19 --> Router Class Initialized
INFO - 2018-10-09 13:10:19 --> Output Class Initialized
INFO - 2018-10-09 13:10:19 --> Security Class Initialized
DEBUG - 2018-10-09 13:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:10:19 --> CSRF cookie sent
INFO - 2018-10-09 13:10:19 --> Input Class Initialized
INFO - 2018-10-09 13:10:19 --> Language Class Initialized
INFO - 2018-10-09 13:10:19 --> Loader Class Initialized
INFO - 2018-10-09 13:10:19 --> Helper loaded: url_helper
INFO - 2018-10-09 13:10:19 --> Helper loaded: form_helper
INFO - 2018-10-09 13:10:19 --> Helper loaded: language_helper
DEBUG - 2018-10-09 13:10:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 13:10:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:10:19 --> User Agent Class Initialized
INFO - 2018-10-09 13:10:19 --> Controller Class Initialized
INFO - 2018-10-09 13:10:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 13:10:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 13:10:19 --> Pixel_Model class loaded
INFO - 2018-10-09 13:10:19 --> Database Driver Class Initialized
INFO - 2018-10-09 13:10:19 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:10:19 --> Database Driver Class Initialized
INFO - 2018-10-09 13:10:19 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:10:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 13:10:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-09 13:10:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 13:10:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 13:10:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 13:10:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 13:10:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 13:10:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-09 13:10:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 13:10:19 --> Final output sent to browser
DEBUG - 2018-10-09 13:10:19 --> Total execution time: 0.0419
INFO - 2018-10-09 13:10:27 --> Config Class Initialized
INFO - 2018-10-09 13:10:27 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:10:27 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:10:27 --> Utf8 Class Initialized
INFO - 2018-10-09 13:10:27 --> URI Class Initialized
INFO - 2018-10-09 13:10:27 --> Router Class Initialized
INFO - 2018-10-09 13:10:27 --> Output Class Initialized
INFO - 2018-10-09 13:10:27 --> Security Class Initialized
DEBUG - 2018-10-09 13:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:10:27 --> CSRF cookie sent
INFO - 2018-10-09 13:10:27 --> CSRF token verified
INFO - 2018-10-09 13:10:27 --> Input Class Initialized
INFO - 2018-10-09 13:10:27 --> Language Class Initialized
INFO - 2018-10-09 13:10:27 --> Loader Class Initialized
INFO - 2018-10-09 13:10:27 --> Helper loaded: url_helper
INFO - 2018-10-09 13:10:27 --> Helper loaded: form_helper
INFO - 2018-10-09 13:10:27 --> Helper loaded: language_helper
DEBUG - 2018-10-09 13:10:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 13:10:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:10:27 --> User Agent Class Initialized
INFO - 2018-10-09 13:10:27 --> Controller Class Initialized
INFO - 2018-10-09 13:10:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 13:10:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 13:10:27 --> Pixel_Model class loaded
INFO - 2018-10-09 13:10:27 --> Database Driver Class Initialized
INFO - 2018-10-09 13:10:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:10:27 --> Form Validation Class Initialized
INFO - 2018-10-09 13:10:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 13:10:27 --> Database Driver Class Initialized
INFO - 2018-10-09 13:10:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:10:27 --> Config Class Initialized
INFO - 2018-10-09 13:10:27 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:10:27 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:10:27 --> Utf8 Class Initialized
INFO - 2018-10-09 13:10:27 --> URI Class Initialized
INFO - 2018-10-09 13:10:27 --> Router Class Initialized
INFO - 2018-10-09 13:10:27 --> Output Class Initialized
INFO - 2018-10-09 13:10:27 --> Security Class Initialized
DEBUG - 2018-10-09 13:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:10:27 --> CSRF cookie sent
INFO - 2018-10-09 13:10:27 --> Input Class Initialized
INFO - 2018-10-09 13:10:27 --> Language Class Initialized
INFO - 2018-10-09 13:10:27 --> Loader Class Initialized
INFO - 2018-10-09 13:10:27 --> Helper loaded: url_helper
INFO - 2018-10-09 13:10:27 --> Helper loaded: form_helper
INFO - 2018-10-09 13:10:27 --> Helper loaded: language_helper
DEBUG - 2018-10-09 13:10:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 13:10:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:10:27 --> User Agent Class Initialized
INFO - 2018-10-09 13:10:27 --> Controller Class Initialized
INFO - 2018-10-09 13:10:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 13:10:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 13:10:27 --> Pixel_Model class loaded
INFO - 2018-10-09 13:10:27 --> Database Driver Class Initialized
INFO - 2018-10-09 13:10:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:10:27 --> Database Driver Class Initialized
INFO - 2018-10-09 13:10:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:10:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 13:10:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-09 13:10:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 13:10:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 13:10:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 13:10:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 13:10:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 13:10:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/marriage.php
INFO - 2018-10-09 13:10:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 13:10:27 --> Final output sent to browser
DEBUG - 2018-10-09 13:10:27 --> Total execution time: 0.0392
INFO - 2018-10-09 13:10:33 --> Config Class Initialized
INFO - 2018-10-09 13:10:33 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:10:33 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:10:33 --> Utf8 Class Initialized
INFO - 2018-10-09 13:10:33 --> URI Class Initialized
INFO - 2018-10-09 13:10:33 --> Router Class Initialized
INFO - 2018-10-09 13:10:33 --> Output Class Initialized
INFO - 2018-10-09 13:10:33 --> Security Class Initialized
DEBUG - 2018-10-09 13:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:10:33 --> CSRF cookie sent
INFO - 2018-10-09 13:10:33 --> CSRF token verified
INFO - 2018-10-09 13:10:33 --> Input Class Initialized
INFO - 2018-10-09 13:10:33 --> Language Class Initialized
INFO - 2018-10-09 13:10:33 --> Loader Class Initialized
INFO - 2018-10-09 13:10:33 --> Helper loaded: url_helper
INFO - 2018-10-09 13:10:33 --> Helper loaded: form_helper
INFO - 2018-10-09 13:10:33 --> Helper loaded: language_helper
DEBUG - 2018-10-09 13:10:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 13:10:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:10:33 --> User Agent Class Initialized
INFO - 2018-10-09 13:10:33 --> Controller Class Initialized
INFO - 2018-10-09 13:10:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 13:10:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 13:10:33 --> Pixel_Model class loaded
INFO - 2018-10-09 13:10:33 --> Database Driver Class Initialized
INFO - 2018-10-09 13:10:33 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:10:33 --> Form Validation Class Initialized
INFO - 2018-10-09 13:10:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 13:10:33 --> Database Driver Class Initialized
INFO - 2018-10-09 13:10:33 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:10:33 --> Config Class Initialized
INFO - 2018-10-09 13:10:33 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:10:33 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:10:33 --> Utf8 Class Initialized
INFO - 2018-10-09 13:10:33 --> URI Class Initialized
INFO - 2018-10-09 13:10:33 --> Router Class Initialized
INFO - 2018-10-09 13:10:33 --> Output Class Initialized
INFO - 2018-10-09 13:10:33 --> Security Class Initialized
DEBUG - 2018-10-09 13:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:10:33 --> CSRF cookie sent
INFO - 2018-10-09 13:10:33 --> Input Class Initialized
INFO - 2018-10-09 13:10:33 --> Language Class Initialized
INFO - 2018-10-09 13:10:33 --> Loader Class Initialized
INFO - 2018-10-09 13:10:33 --> Helper loaded: url_helper
INFO - 2018-10-09 13:10:33 --> Helper loaded: form_helper
INFO - 2018-10-09 13:10:33 --> Helper loaded: language_helper
DEBUG - 2018-10-09 13:10:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 13:10:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:10:33 --> User Agent Class Initialized
INFO - 2018-10-09 13:10:33 --> Controller Class Initialized
INFO - 2018-10-09 13:10:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 13:10:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 13:10:33 --> Pixel_Model class loaded
INFO - 2018-10-09 13:10:34 --> Database Driver Class Initialized
INFO - 2018-10-09 13:10:34 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:10:34 --> Database Driver Class Initialized
INFO - 2018-10-09 13:10:34 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:10:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 13:10:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-09 13:10:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 13:10:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 13:10:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 13:10:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 13:10:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 13:10:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-10-09 13:10:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 13:10:34 --> Final output sent to browser
DEBUG - 2018-10-09 13:10:34 --> Total execution time: 0.0396
INFO - 2018-10-09 13:10:50 --> Config Class Initialized
INFO - 2018-10-09 13:10:50 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:10:50 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:10:50 --> Utf8 Class Initialized
INFO - 2018-10-09 13:10:50 --> URI Class Initialized
INFO - 2018-10-09 13:10:50 --> Router Class Initialized
INFO - 2018-10-09 13:10:50 --> Output Class Initialized
INFO - 2018-10-09 13:10:50 --> Security Class Initialized
DEBUG - 2018-10-09 13:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:10:50 --> CSRF cookie sent
INFO - 2018-10-09 13:10:50 --> CSRF token verified
INFO - 2018-10-09 13:10:50 --> Input Class Initialized
INFO - 2018-10-09 13:10:50 --> Language Class Initialized
INFO - 2018-10-09 13:10:50 --> Loader Class Initialized
INFO - 2018-10-09 13:10:50 --> Helper loaded: url_helper
INFO - 2018-10-09 13:10:50 --> Helper loaded: form_helper
INFO - 2018-10-09 13:10:50 --> Helper loaded: language_helper
DEBUG - 2018-10-09 13:10:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 13:10:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:10:50 --> User Agent Class Initialized
INFO - 2018-10-09 13:10:50 --> Controller Class Initialized
INFO - 2018-10-09 13:10:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 13:10:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 13:10:50 --> Pixel_Model class loaded
INFO - 2018-10-09 13:10:50 --> Database Driver Class Initialized
INFO - 2018-10-09 13:10:50 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:10:50 --> Form Validation Class Initialized
INFO - 2018-10-09 13:10:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 13:10:50 --> Database Driver Class Initialized
INFO - 2018-10-09 13:10:50 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:10:50 --> Config Class Initialized
INFO - 2018-10-09 13:10:50 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:10:50 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:10:50 --> Utf8 Class Initialized
INFO - 2018-10-09 13:10:50 --> URI Class Initialized
INFO - 2018-10-09 13:10:50 --> Router Class Initialized
INFO - 2018-10-09 13:10:50 --> Output Class Initialized
INFO - 2018-10-09 13:10:50 --> Security Class Initialized
DEBUG - 2018-10-09 13:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:10:50 --> CSRF cookie sent
INFO - 2018-10-09 13:10:50 --> Input Class Initialized
INFO - 2018-10-09 13:10:50 --> Language Class Initialized
INFO - 2018-10-09 13:10:50 --> Loader Class Initialized
INFO - 2018-10-09 13:10:50 --> Helper loaded: url_helper
INFO - 2018-10-09 13:10:50 --> Helper loaded: form_helper
INFO - 2018-10-09 13:10:50 --> Helper loaded: language_helper
DEBUG - 2018-10-09 13:10:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 13:10:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:10:50 --> User Agent Class Initialized
INFO - 2018-10-09 13:10:50 --> Controller Class Initialized
INFO - 2018-10-09 13:10:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 13:10:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 13:10:50 --> Pixel_Model class loaded
INFO - 2018-10-09 13:10:51 --> Database Driver Class Initialized
INFO - 2018-10-09 13:10:51 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:10:51 --> Database Driver Class Initialized
INFO - 2018-10-09 13:10:51 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:10:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 13:10:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-09 13:10:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 13:10:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 13:10:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 13:10:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 13:10:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 13:10:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-10-09 13:10:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 13:10:51 --> Final output sent to browser
DEBUG - 2018-10-09 13:10:51 --> Total execution time: 0.0458
INFO - 2018-10-09 13:11:07 --> Config Class Initialized
INFO - 2018-10-09 13:11:07 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:11:07 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:11:07 --> Utf8 Class Initialized
INFO - 2018-10-09 13:11:07 --> URI Class Initialized
INFO - 2018-10-09 13:11:07 --> Router Class Initialized
INFO - 2018-10-09 13:11:07 --> Output Class Initialized
INFO - 2018-10-09 13:11:07 --> Security Class Initialized
DEBUG - 2018-10-09 13:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:11:07 --> CSRF cookie sent
INFO - 2018-10-09 13:11:07 --> CSRF token verified
INFO - 2018-10-09 13:11:07 --> Input Class Initialized
INFO - 2018-10-09 13:11:07 --> Language Class Initialized
INFO - 2018-10-09 13:11:07 --> Loader Class Initialized
INFO - 2018-10-09 13:11:07 --> Helper loaded: url_helper
INFO - 2018-10-09 13:11:07 --> Helper loaded: form_helper
INFO - 2018-10-09 13:11:07 --> Helper loaded: language_helper
DEBUG - 2018-10-09 13:11:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 13:11:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:11:07 --> User Agent Class Initialized
INFO - 2018-10-09 13:11:07 --> Controller Class Initialized
INFO - 2018-10-09 13:11:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 13:11:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 13:11:07 --> Pixel_Model class loaded
INFO - 2018-10-09 13:11:07 --> Database Driver Class Initialized
INFO - 2018-10-09 13:11:07 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:11:07 --> Form Validation Class Initialized
INFO - 2018-10-09 13:11:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 13:11:07 --> Database Driver Class Initialized
INFO - 2018-10-09 13:11:07 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:11:07 --> Config Class Initialized
INFO - 2018-10-09 13:11:07 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:11:07 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:11:07 --> Utf8 Class Initialized
INFO - 2018-10-09 13:11:07 --> URI Class Initialized
INFO - 2018-10-09 13:11:07 --> Router Class Initialized
INFO - 2018-10-09 13:11:07 --> Output Class Initialized
INFO - 2018-10-09 13:11:07 --> Security Class Initialized
DEBUG - 2018-10-09 13:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:11:07 --> CSRF cookie sent
INFO - 2018-10-09 13:11:07 --> Input Class Initialized
INFO - 2018-10-09 13:11:07 --> Language Class Initialized
INFO - 2018-10-09 13:11:07 --> Loader Class Initialized
INFO - 2018-10-09 13:11:07 --> Helper loaded: url_helper
INFO - 2018-10-09 13:11:07 --> Helper loaded: form_helper
INFO - 2018-10-09 13:11:07 --> Helper loaded: language_helper
DEBUG - 2018-10-09 13:11:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 13:11:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:11:07 --> User Agent Class Initialized
INFO - 2018-10-09 13:11:07 --> Controller Class Initialized
INFO - 2018-10-09 13:11:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 13:11:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 13:11:07 --> Pixel_Model class loaded
INFO - 2018-10-09 13:11:07 --> Database Driver Class Initialized
INFO - 2018-10-09 13:11:07 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:11:07 --> Database Driver Class Initialized
INFO - 2018-10-09 13:11:07 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:11:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 13:11:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-09 13:11:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 13:11:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 13:11:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 13:11:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 13:11:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 13:11:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-10-09 13:11:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 13:11:07 --> Final output sent to browser
DEBUG - 2018-10-09 13:11:07 --> Total execution time: 0.0476
INFO - 2018-10-09 13:11:20 --> Config Class Initialized
INFO - 2018-10-09 13:11:20 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:11:20 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:11:20 --> Utf8 Class Initialized
INFO - 2018-10-09 13:11:20 --> URI Class Initialized
INFO - 2018-10-09 13:11:20 --> Router Class Initialized
INFO - 2018-10-09 13:11:20 --> Output Class Initialized
INFO - 2018-10-09 13:11:20 --> Security Class Initialized
DEBUG - 2018-10-09 13:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:11:20 --> CSRF cookie sent
INFO - 2018-10-09 13:11:20 --> CSRF token verified
INFO - 2018-10-09 13:11:20 --> Input Class Initialized
INFO - 2018-10-09 13:11:20 --> Language Class Initialized
INFO - 2018-10-09 13:11:20 --> Loader Class Initialized
INFO - 2018-10-09 13:11:20 --> Helper loaded: url_helper
INFO - 2018-10-09 13:11:20 --> Helper loaded: form_helper
INFO - 2018-10-09 13:11:20 --> Helper loaded: language_helper
DEBUG - 2018-10-09 13:11:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 13:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:11:20 --> User Agent Class Initialized
INFO - 2018-10-09 13:11:20 --> Controller Class Initialized
INFO - 2018-10-09 13:11:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 13:11:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 13:11:20 --> Pixel_Model class loaded
INFO - 2018-10-09 13:11:20 --> Database Driver Class Initialized
INFO - 2018-10-09 13:11:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:11:20 --> Form Validation Class Initialized
INFO - 2018-10-09 13:11:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 13:11:20 --> Database Driver Class Initialized
INFO - 2018-10-09 13:11:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:11:20 --> Config Class Initialized
INFO - 2018-10-09 13:11:20 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:11:20 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:11:20 --> Utf8 Class Initialized
INFO - 2018-10-09 13:11:20 --> URI Class Initialized
INFO - 2018-10-09 13:11:20 --> Router Class Initialized
INFO - 2018-10-09 13:11:20 --> Output Class Initialized
INFO - 2018-10-09 13:11:20 --> Security Class Initialized
DEBUG - 2018-10-09 13:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:11:20 --> CSRF cookie sent
INFO - 2018-10-09 13:11:20 --> Input Class Initialized
INFO - 2018-10-09 13:11:20 --> Language Class Initialized
INFO - 2018-10-09 13:11:20 --> Loader Class Initialized
INFO - 2018-10-09 13:11:20 --> Helper loaded: url_helper
INFO - 2018-10-09 13:11:20 --> Helper loaded: form_helper
INFO - 2018-10-09 13:11:20 --> Helper loaded: language_helper
DEBUG - 2018-10-09 13:11:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 13:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:11:20 --> User Agent Class Initialized
INFO - 2018-10-09 13:11:20 --> Controller Class Initialized
INFO - 2018-10-09 13:11:20 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 13:11:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 13:11:20 --> Pixel_Model class loaded
INFO - 2018-10-09 13:11:20 --> Database Driver Class Initialized
INFO - 2018-10-09 13:11:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:11:20 --> Database Driver Class Initialized
INFO - 2018-10-09 13:11:20 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:11:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 13:11:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-09 13:11:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 13:11:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 13:11:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 13:11:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 13:11:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 13:11:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-10-09 13:11:20 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 13:11:20 --> Final output sent to browser
DEBUG - 2018-10-09 13:11:20 --> Total execution time: 0.0617
INFO - 2018-10-09 13:11:22 --> Config Class Initialized
INFO - 2018-10-09 13:11:22 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:11:22 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:11:22 --> Utf8 Class Initialized
INFO - 2018-10-09 13:11:22 --> URI Class Initialized
INFO - 2018-10-09 13:11:22 --> Router Class Initialized
INFO - 2018-10-09 13:11:22 --> Output Class Initialized
INFO - 2018-10-09 13:11:22 --> Security Class Initialized
DEBUG - 2018-10-09 13:11:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:11:22 --> CSRF cookie sent
INFO - 2018-10-09 13:11:22 --> CSRF token verified
INFO - 2018-10-09 13:11:22 --> Input Class Initialized
INFO - 2018-10-09 13:11:22 --> Language Class Initialized
INFO - 2018-10-09 13:11:22 --> Loader Class Initialized
INFO - 2018-10-09 13:11:22 --> Helper loaded: url_helper
INFO - 2018-10-09 13:11:22 --> Helper loaded: form_helper
INFO - 2018-10-09 13:11:22 --> Helper loaded: language_helper
DEBUG - 2018-10-09 13:11:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 13:11:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:11:22 --> User Agent Class Initialized
INFO - 2018-10-09 13:11:22 --> Controller Class Initialized
INFO - 2018-10-09 13:11:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 13:11:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 13:11:22 --> Pixel_Model class loaded
INFO - 2018-10-09 13:11:22 --> Database Driver Class Initialized
INFO - 2018-10-09 13:11:22 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:11:22 --> Form Validation Class Initialized
INFO - 2018-10-09 13:11:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 13:11:22 --> Database Driver Class Initialized
INFO - 2018-10-09 13:11:22 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:11:22 --> Config Class Initialized
INFO - 2018-10-09 13:11:22 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:11:22 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:11:22 --> Utf8 Class Initialized
INFO - 2018-10-09 13:11:22 --> URI Class Initialized
INFO - 2018-10-09 13:11:22 --> Router Class Initialized
INFO - 2018-10-09 13:11:22 --> Output Class Initialized
INFO - 2018-10-09 13:11:22 --> Security Class Initialized
DEBUG - 2018-10-09 13:11:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:11:22 --> CSRF cookie sent
INFO - 2018-10-09 13:11:22 --> Input Class Initialized
INFO - 2018-10-09 13:11:22 --> Language Class Initialized
INFO - 2018-10-09 13:11:22 --> Loader Class Initialized
INFO - 2018-10-09 13:11:22 --> Helper loaded: url_helper
INFO - 2018-10-09 13:11:22 --> Helper loaded: form_helper
INFO - 2018-10-09 13:11:22 --> Helper loaded: language_helper
DEBUG - 2018-10-09 13:11:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 13:11:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:11:22 --> User Agent Class Initialized
INFO - 2018-10-09 13:11:22 --> Controller Class Initialized
INFO - 2018-10-09 13:11:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 13:11:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 13:11:22 --> Pixel_Model class loaded
INFO - 2018-10-09 13:11:22 --> Database Driver Class Initialized
INFO - 2018-10-09 13:11:22 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:11:22 --> Database Driver Class Initialized
INFO - 2018-10-09 13:11:22 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:11:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 13:11:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-09 13:11:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 13:11:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 13:11:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 13:11:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 13:11:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 13:11:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_owner.php
INFO - 2018-10-09 13:11:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 13:11:22 --> Final output sent to browser
DEBUG - 2018-10-09 13:11:22 --> Total execution time: 0.0515
INFO - 2018-10-09 13:11:25 --> Config Class Initialized
INFO - 2018-10-09 13:11:25 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:11:25 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:11:25 --> Utf8 Class Initialized
INFO - 2018-10-09 13:11:25 --> URI Class Initialized
INFO - 2018-10-09 13:11:25 --> Router Class Initialized
INFO - 2018-10-09 13:11:25 --> Output Class Initialized
INFO - 2018-10-09 13:11:25 --> Security Class Initialized
DEBUG - 2018-10-09 13:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:11:25 --> CSRF cookie sent
INFO - 2018-10-09 13:11:25 --> CSRF token verified
INFO - 2018-10-09 13:11:25 --> Input Class Initialized
INFO - 2018-10-09 13:11:25 --> Language Class Initialized
INFO - 2018-10-09 13:11:25 --> Loader Class Initialized
INFO - 2018-10-09 13:11:25 --> Helper loaded: url_helper
INFO - 2018-10-09 13:11:25 --> Helper loaded: form_helper
INFO - 2018-10-09 13:11:25 --> Helper loaded: language_helper
DEBUG - 2018-10-09 13:11:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 13:11:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:11:25 --> User Agent Class Initialized
INFO - 2018-10-09 13:11:25 --> Controller Class Initialized
INFO - 2018-10-09 13:11:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 13:11:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 13:11:25 --> Pixel_Model class loaded
INFO - 2018-10-09 13:11:25 --> Database Driver Class Initialized
INFO - 2018-10-09 13:11:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:11:25 --> Form Validation Class Initialized
INFO - 2018-10-09 13:11:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 13:11:25 --> Database Driver Class Initialized
INFO - 2018-10-09 13:11:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:11:25 --> Config Class Initialized
INFO - 2018-10-09 13:11:25 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:11:25 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:11:25 --> Utf8 Class Initialized
INFO - 2018-10-09 13:11:25 --> URI Class Initialized
INFO - 2018-10-09 13:11:25 --> Router Class Initialized
INFO - 2018-10-09 13:11:25 --> Output Class Initialized
INFO - 2018-10-09 13:11:25 --> Security Class Initialized
DEBUG - 2018-10-09 13:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:11:25 --> CSRF cookie sent
INFO - 2018-10-09 13:11:25 --> Input Class Initialized
INFO - 2018-10-09 13:11:25 --> Language Class Initialized
INFO - 2018-10-09 13:11:25 --> Loader Class Initialized
INFO - 2018-10-09 13:11:25 --> Helper loaded: url_helper
INFO - 2018-10-09 13:11:25 --> Helper loaded: form_helper
INFO - 2018-10-09 13:11:25 --> Helper loaded: language_helper
DEBUG - 2018-10-09 13:11:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 13:11:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:11:25 --> User Agent Class Initialized
INFO - 2018-10-09 13:11:25 --> Controller Class Initialized
INFO - 2018-10-09 13:11:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 13:11:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 13:11:25 --> Pixel_Model class loaded
INFO - 2018-10-09 13:11:25 --> Database Driver Class Initialized
INFO - 2018-10-09 13:11:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:11:25 --> Database Driver Class Initialized
INFO - 2018-10-09 13:11:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:11:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 13:11:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-09 13:11:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 13:11:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 13:11:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 13:11:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 13:11:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 13:11:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_value.php
INFO - 2018-10-09 13:11:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 13:11:25 --> Final output sent to browser
DEBUG - 2018-10-09 13:11:25 --> Total execution time: 0.0560
INFO - 2018-10-09 13:11:42 --> Config Class Initialized
INFO - 2018-10-09 13:11:42 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:11:42 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:11:42 --> Utf8 Class Initialized
INFO - 2018-10-09 13:11:42 --> URI Class Initialized
INFO - 2018-10-09 13:11:42 --> Router Class Initialized
INFO - 2018-10-09 13:11:42 --> Output Class Initialized
INFO - 2018-10-09 13:11:42 --> Security Class Initialized
DEBUG - 2018-10-09 13:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:11:42 --> CSRF cookie sent
INFO - 2018-10-09 13:11:42 --> CSRF token verified
INFO - 2018-10-09 13:11:42 --> Input Class Initialized
INFO - 2018-10-09 13:11:42 --> Language Class Initialized
INFO - 2018-10-09 13:11:42 --> Loader Class Initialized
INFO - 2018-10-09 13:11:42 --> Helper loaded: url_helper
INFO - 2018-10-09 13:11:42 --> Helper loaded: form_helper
INFO - 2018-10-09 13:11:42 --> Helper loaded: language_helper
DEBUG - 2018-10-09 13:11:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 13:11:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:11:42 --> User Agent Class Initialized
INFO - 2018-10-09 13:11:42 --> Controller Class Initialized
INFO - 2018-10-09 13:11:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 13:11:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 13:11:42 --> Pixel_Model class loaded
INFO - 2018-10-09 13:11:42 --> Database Driver Class Initialized
INFO - 2018-10-09 13:11:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:11:42 --> Form Validation Class Initialized
INFO - 2018-10-09 13:11:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 13:11:42 --> Database Driver Class Initialized
INFO - 2018-10-09 13:11:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:11:42 --> Config Class Initialized
INFO - 2018-10-09 13:11:42 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:11:42 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:11:42 --> Utf8 Class Initialized
INFO - 2018-10-09 13:11:42 --> URI Class Initialized
INFO - 2018-10-09 13:11:42 --> Router Class Initialized
INFO - 2018-10-09 13:11:42 --> Output Class Initialized
INFO - 2018-10-09 13:11:42 --> Security Class Initialized
DEBUG - 2018-10-09 13:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:11:42 --> CSRF cookie sent
INFO - 2018-10-09 13:11:42 --> Input Class Initialized
INFO - 2018-10-09 13:11:42 --> Language Class Initialized
INFO - 2018-10-09 13:11:42 --> Loader Class Initialized
INFO - 2018-10-09 13:11:42 --> Helper loaded: url_helper
INFO - 2018-10-09 13:11:42 --> Helper loaded: form_helper
INFO - 2018-10-09 13:11:42 --> Helper loaded: language_helper
DEBUG - 2018-10-09 13:11:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 13:11:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:11:42 --> User Agent Class Initialized
INFO - 2018-10-09 13:11:42 --> Controller Class Initialized
INFO - 2018-10-09 13:11:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 13:11:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 13:11:42 --> Pixel_Model class loaded
INFO - 2018-10-09 13:11:42 --> Database Driver Class Initialized
INFO - 2018-10-09 13:11:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:11:42 --> Database Driver Class Initialized
INFO - 2018-10-09 13:11:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:11:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 13:11:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-09 13:11:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 13:11:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 13:11:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 13:11:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 13:11:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 13:11:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/merriage_home_title.php
INFO - 2018-10-09 13:11:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 13:11:42 --> Final output sent to browser
DEBUG - 2018-10-09 13:11:42 --> Total execution time: 0.0581
INFO - 2018-10-09 13:11:54 --> Config Class Initialized
INFO - 2018-10-09 13:11:54 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:11:54 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:11:54 --> Utf8 Class Initialized
INFO - 2018-10-09 13:11:54 --> URI Class Initialized
INFO - 2018-10-09 13:11:54 --> Router Class Initialized
INFO - 2018-10-09 13:11:54 --> Output Class Initialized
INFO - 2018-10-09 13:11:54 --> Security Class Initialized
DEBUG - 2018-10-09 13:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:11:54 --> CSRF cookie sent
INFO - 2018-10-09 13:11:54 --> CSRF token verified
INFO - 2018-10-09 13:11:54 --> Input Class Initialized
INFO - 2018-10-09 13:11:54 --> Language Class Initialized
INFO - 2018-10-09 13:11:54 --> Loader Class Initialized
INFO - 2018-10-09 13:11:54 --> Helper loaded: url_helper
INFO - 2018-10-09 13:11:54 --> Helper loaded: form_helper
INFO - 2018-10-09 13:11:54 --> Helper loaded: language_helper
DEBUG - 2018-10-09 13:11:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 13:11:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:11:54 --> User Agent Class Initialized
INFO - 2018-10-09 13:11:54 --> Controller Class Initialized
INFO - 2018-10-09 13:11:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 13:11:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 13:11:54 --> Pixel_Model class loaded
INFO - 2018-10-09 13:11:54 --> Database Driver Class Initialized
INFO - 2018-10-09 13:11:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:11:54 --> Form Validation Class Initialized
INFO - 2018-10-09 13:11:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 13:11:54 --> Database Driver Class Initialized
INFO - 2018-10-09 13:11:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:11:54 --> Config Class Initialized
INFO - 2018-10-09 13:11:54 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:11:54 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:11:54 --> Utf8 Class Initialized
INFO - 2018-10-09 13:11:54 --> URI Class Initialized
INFO - 2018-10-09 13:11:54 --> Router Class Initialized
INFO - 2018-10-09 13:11:54 --> Output Class Initialized
INFO - 2018-10-09 13:11:54 --> Security Class Initialized
DEBUG - 2018-10-09 13:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:11:54 --> CSRF cookie sent
INFO - 2018-10-09 13:11:54 --> Input Class Initialized
INFO - 2018-10-09 13:11:54 --> Language Class Initialized
INFO - 2018-10-09 13:11:54 --> Loader Class Initialized
INFO - 2018-10-09 13:11:54 --> Helper loaded: url_helper
INFO - 2018-10-09 13:11:54 --> Helper loaded: form_helper
INFO - 2018-10-09 13:11:54 --> Helper loaded: language_helper
DEBUG - 2018-10-09 13:11:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 13:11:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:11:54 --> User Agent Class Initialized
INFO - 2018-10-09 13:11:54 --> Controller Class Initialized
INFO - 2018-10-09 13:11:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 13:11:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 13:11:54 --> Pixel_Model class loaded
INFO - 2018-10-09 13:11:54 --> Database Driver Class Initialized
INFO - 2018-10-09 13:11:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:11:54 --> Database Driver Class Initialized
INFO - 2018-10-09 13:11:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:11:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 13:11:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-09 13:11:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 13:11:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 13:11:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 13:11:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 13:11:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 13:11:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-10-09 13:11:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 13:11:54 --> Final output sent to browser
DEBUG - 2018-10-09 13:11:54 --> Total execution time: 0.0536
INFO - 2018-10-09 13:11:58 --> Config Class Initialized
INFO - 2018-10-09 13:11:58 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:11:58 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:11:58 --> Utf8 Class Initialized
INFO - 2018-10-09 13:11:58 --> URI Class Initialized
INFO - 2018-10-09 13:11:58 --> Router Class Initialized
INFO - 2018-10-09 13:11:58 --> Output Class Initialized
INFO - 2018-10-09 13:11:58 --> Security Class Initialized
DEBUG - 2018-10-09 13:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:11:58 --> CSRF cookie sent
INFO - 2018-10-09 13:11:58 --> CSRF token verified
INFO - 2018-10-09 13:11:58 --> Input Class Initialized
INFO - 2018-10-09 13:11:58 --> Language Class Initialized
INFO - 2018-10-09 13:11:58 --> Loader Class Initialized
INFO - 2018-10-09 13:11:58 --> Helper loaded: url_helper
INFO - 2018-10-09 13:11:58 --> Helper loaded: form_helper
INFO - 2018-10-09 13:11:58 --> Helper loaded: language_helper
DEBUG - 2018-10-09 13:11:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 13:11:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:11:59 --> User Agent Class Initialized
INFO - 2018-10-09 13:11:59 --> Controller Class Initialized
INFO - 2018-10-09 13:11:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 13:11:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 13:11:59 --> Pixel_Model class loaded
INFO - 2018-10-09 13:11:59 --> Database Driver Class Initialized
INFO - 2018-10-09 13:11:59 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:11:59 --> Form Validation Class Initialized
INFO - 2018-10-09 13:11:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 13:11:59 --> Database Driver Class Initialized
INFO - 2018-10-09 13:11:59 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:11:59 --> Config Class Initialized
INFO - 2018-10-09 13:11:59 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:11:59 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:11:59 --> Utf8 Class Initialized
INFO - 2018-10-09 13:11:59 --> URI Class Initialized
INFO - 2018-10-09 13:11:59 --> Router Class Initialized
INFO - 2018-10-09 13:11:59 --> Output Class Initialized
INFO - 2018-10-09 13:11:59 --> Security Class Initialized
DEBUG - 2018-10-09 13:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:11:59 --> CSRF cookie sent
INFO - 2018-10-09 13:11:59 --> Input Class Initialized
INFO - 2018-10-09 13:11:59 --> Language Class Initialized
INFO - 2018-10-09 13:11:59 --> Loader Class Initialized
INFO - 2018-10-09 13:11:59 --> Helper loaded: url_helper
INFO - 2018-10-09 13:11:59 --> Helper loaded: form_helper
INFO - 2018-10-09 13:11:59 --> Helper loaded: language_helper
DEBUG - 2018-10-09 13:11:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 13:11:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:11:59 --> User Agent Class Initialized
INFO - 2018-10-09 13:11:59 --> Controller Class Initialized
INFO - 2018-10-09 13:11:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 13:11:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 13:11:59 --> Pixel_Model class loaded
INFO - 2018-10-09 13:11:59 --> Database Driver Class Initialized
INFO - 2018-10-09 13:11:59 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:11:59 --> Database Driver Class Initialized
INFO - 2018-10-09 13:11:59 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:11:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 13:11:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-09 13:11:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 13:11:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 13:11:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 13:11:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 13:11:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 13:11:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids_info.php
INFO - 2018-10-09 13:11:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 13:11:59 --> Final output sent to browser
DEBUG - 2018-10-09 13:11:59 --> Total execution time: 0.0470
INFO - 2018-10-09 13:12:03 --> Config Class Initialized
INFO - 2018-10-09 13:12:03 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:12:03 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:12:03 --> Utf8 Class Initialized
INFO - 2018-10-09 13:12:03 --> URI Class Initialized
INFO - 2018-10-09 13:12:03 --> Router Class Initialized
INFO - 2018-10-09 13:12:03 --> Output Class Initialized
INFO - 2018-10-09 13:12:03 --> Security Class Initialized
DEBUG - 2018-10-09 13:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:12:03 --> CSRF cookie sent
INFO - 2018-10-09 13:12:03 --> Input Class Initialized
INFO - 2018-10-09 13:12:03 --> Language Class Initialized
INFO - 2018-10-09 13:12:03 --> Loader Class Initialized
INFO - 2018-10-09 13:12:03 --> Helper loaded: url_helper
INFO - 2018-10-09 13:12:03 --> Helper loaded: form_helper
INFO - 2018-10-09 13:12:03 --> Helper loaded: language_helper
DEBUG - 2018-10-09 13:12:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 13:12:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:12:03 --> User Agent Class Initialized
INFO - 2018-10-09 13:12:03 --> Controller Class Initialized
INFO - 2018-10-09 13:12:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 13:12:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 13:12:03 --> Pixel_Model class loaded
INFO - 2018-10-09 13:12:03 --> Database Driver Class Initialized
INFO - 2018-10-09 13:12:03 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:12:03 --> Database Driver Class Initialized
INFO - 2018-10-09 13:12:03 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:12:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 13:12:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-09 13:12:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 13:12:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 13:12:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 13:12:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-10-09 13:12:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 13:12:03 --> Final output sent to browser
DEBUG - 2018-10-09 13:12:03 --> Total execution time: 0.0446
INFO - 2018-10-09 13:12:09 --> Config Class Initialized
INFO - 2018-10-09 13:12:09 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:12:09 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:12:09 --> Utf8 Class Initialized
INFO - 2018-10-09 13:12:09 --> URI Class Initialized
INFO - 2018-10-09 13:12:09 --> Router Class Initialized
INFO - 2018-10-09 13:12:09 --> Output Class Initialized
INFO - 2018-10-09 13:12:09 --> Security Class Initialized
DEBUG - 2018-10-09 13:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:12:09 --> CSRF cookie sent
INFO - 2018-10-09 13:12:09 --> Input Class Initialized
INFO - 2018-10-09 13:12:09 --> Language Class Initialized
INFO - 2018-10-09 13:12:09 --> Loader Class Initialized
INFO - 2018-10-09 13:12:09 --> Helper loaded: url_helper
INFO - 2018-10-09 13:12:09 --> Helper loaded: form_helper
INFO - 2018-10-09 13:12:09 --> Helper loaded: language_helper
DEBUG - 2018-10-09 13:12:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 13:12:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:12:09 --> User Agent Class Initialized
INFO - 2018-10-09 13:12:09 --> Controller Class Initialized
INFO - 2018-10-09 13:12:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 13:12:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 13:12:09 --> Pixel_Model class loaded
INFO - 2018-10-09 13:12:09 --> Database Driver Class Initialized
INFO - 2018-10-09 13:12:09 --> Model "MyAccountModel" initialized
INFO - 2018-10-09 13:12:09 --> Config Class Initialized
INFO - 2018-10-09 13:12:09 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:12:09 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:12:09 --> Utf8 Class Initialized
INFO - 2018-10-09 13:12:09 --> URI Class Initialized
INFO - 2018-10-09 13:12:09 --> Router Class Initialized
INFO - 2018-10-09 13:12:09 --> Output Class Initialized
INFO - 2018-10-09 13:12:09 --> Security Class Initialized
DEBUG - 2018-10-09 13:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:12:09 --> CSRF cookie sent
INFO - 2018-10-09 13:12:09 --> Input Class Initialized
INFO - 2018-10-09 13:12:09 --> Language Class Initialized
INFO - 2018-10-09 13:12:09 --> Loader Class Initialized
INFO - 2018-10-09 13:12:09 --> Helper loaded: url_helper
INFO - 2018-10-09 13:12:09 --> Helper loaded: form_helper
INFO - 2018-10-09 13:12:09 --> Helper loaded: language_helper
DEBUG - 2018-10-09 13:12:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 13:12:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:12:09 --> User Agent Class Initialized
INFO - 2018-10-09 13:12:09 --> Controller Class Initialized
INFO - 2018-10-09 13:12:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 13:12:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 13:12:09 --> Pixel_Model class loaded
INFO - 2018-10-09 13:12:09 --> Database Driver Class Initialized
INFO - 2018-10-09 13:12:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:12:09 --> Database Driver Class Initialized
INFO - 2018-10-09 13:12:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:12:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 13:12:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-09 13:12:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 13:12:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 13:12:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 13:12:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 13:12:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 13:12:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids_info.php
INFO - 2018-10-09 13:12:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 13:12:09 --> Final output sent to browser
DEBUG - 2018-10-09 13:12:09 --> Total execution time: 0.0478
INFO - 2018-10-09 13:12:11 --> Config Class Initialized
INFO - 2018-10-09 13:12:11 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:12:11 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:12:11 --> Utf8 Class Initialized
INFO - 2018-10-09 13:12:11 --> URI Class Initialized
INFO - 2018-10-09 13:12:11 --> Router Class Initialized
INFO - 2018-10-09 13:12:11 --> Output Class Initialized
INFO - 2018-10-09 13:12:11 --> Security Class Initialized
DEBUG - 2018-10-09 13:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:12:11 --> CSRF cookie sent
INFO - 2018-10-09 13:12:11 --> Input Class Initialized
INFO - 2018-10-09 13:12:11 --> Language Class Initialized
INFO - 2018-10-09 13:12:11 --> Loader Class Initialized
INFO - 2018-10-09 13:12:11 --> Helper loaded: url_helper
INFO - 2018-10-09 13:12:11 --> Helper loaded: form_helper
INFO - 2018-10-09 13:12:11 --> Helper loaded: language_helper
DEBUG - 2018-10-09 13:12:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 13:12:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:12:11 --> User Agent Class Initialized
INFO - 2018-10-09 13:12:11 --> Controller Class Initialized
INFO - 2018-10-09 13:12:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 13:12:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 13:12:11 --> Pixel_Model class loaded
INFO - 2018-10-09 13:12:11 --> Database Driver Class Initialized
INFO - 2018-10-09 13:12:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:12:11 --> Database Driver Class Initialized
INFO - 2018-10-09 13:12:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:12:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 13:12:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-09 13:12:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 13:12:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 13:12:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 13:12:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 13:12:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 13:12:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-10-09 13:12:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 13:12:11 --> Final output sent to browser
DEBUG - 2018-10-09 13:12:11 --> Total execution time: 0.0637
INFO - 2018-10-09 13:12:13 --> Config Class Initialized
INFO - 2018-10-09 13:12:13 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:12:13 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:12:13 --> Utf8 Class Initialized
INFO - 2018-10-09 13:12:13 --> URI Class Initialized
INFO - 2018-10-09 13:12:13 --> Router Class Initialized
INFO - 2018-10-09 13:12:13 --> Output Class Initialized
INFO - 2018-10-09 13:12:13 --> Security Class Initialized
DEBUG - 2018-10-09 13:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:12:13 --> CSRF cookie sent
INFO - 2018-10-09 13:12:13 --> Input Class Initialized
INFO - 2018-10-09 13:12:13 --> Language Class Initialized
INFO - 2018-10-09 13:12:13 --> Loader Class Initialized
INFO - 2018-10-09 13:12:13 --> Helper loaded: url_helper
INFO - 2018-10-09 13:12:13 --> Helper loaded: form_helper
INFO - 2018-10-09 13:12:13 --> Helper loaded: language_helper
DEBUG - 2018-10-09 13:12:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 13:12:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:12:13 --> User Agent Class Initialized
INFO - 2018-10-09 13:12:13 --> Controller Class Initialized
INFO - 2018-10-09 13:12:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 13:12:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 13:12:13 --> Pixel_Model class loaded
INFO - 2018-10-09 13:12:13 --> Database Driver Class Initialized
INFO - 2018-10-09 13:12:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:12:13 --> Database Driver Class Initialized
INFO - 2018-10-09 13:12:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:12:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 13:12:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-09 13:12:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 13:12:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 13:12:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 13:12:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 13:12:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 13:12:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/merriage_home_title.php
INFO - 2018-10-09 13:12:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 13:12:13 --> Final output sent to browser
DEBUG - 2018-10-09 13:12:13 --> Total execution time: 0.0457
INFO - 2018-10-09 13:12:14 --> Config Class Initialized
INFO - 2018-10-09 13:12:14 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:12:14 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:12:14 --> Utf8 Class Initialized
INFO - 2018-10-09 13:12:14 --> URI Class Initialized
INFO - 2018-10-09 13:12:14 --> Router Class Initialized
INFO - 2018-10-09 13:12:14 --> Output Class Initialized
INFO - 2018-10-09 13:12:14 --> Security Class Initialized
DEBUG - 2018-10-09 13:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:12:14 --> CSRF cookie sent
INFO - 2018-10-09 13:12:14 --> Input Class Initialized
INFO - 2018-10-09 13:12:14 --> Language Class Initialized
INFO - 2018-10-09 13:12:14 --> Loader Class Initialized
INFO - 2018-10-09 13:12:14 --> Helper loaded: url_helper
INFO - 2018-10-09 13:12:14 --> Helper loaded: form_helper
INFO - 2018-10-09 13:12:14 --> Helper loaded: language_helper
DEBUG - 2018-10-09 13:12:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 13:12:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:12:14 --> User Agent Class Initialized
INFO - 2018-10-09 13:12:14 --> Controller Class Initialized
INFO - 2018-10-09 13:12:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 13:12:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 13:12:14 --> Pixel_Model class loaded
INFO - 2018-10-09 13:12:14 --> Database Driver Class Initialized
INFO - 2018-10-09 13:12:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:12:14 --> Database Driver Class Initialized
INFO - 2018-10-09 13:12:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:12:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 13:12:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-09 13:12:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 13:12:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 13:12:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 13:12:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 13:12:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 13:12:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_value.php
INFO - 2018-10-09 13:12:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 13:12:14 --> Final output sent to browser
DEBUG - 2018-10-09 13:12:14 --> Total execution time: 0.0655
INFO - 2018-10-09 13:12:23 --> Config Class Initialized
INFO - 2018-10-09 13:12:23 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:12:23 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:12:23 --> Utf8 Class Initialized
INFO - 2018-10-09 13:12:23 --> URI Class Initialized
INFO - 2018-10-09 13:12:23 --> Router Class Initialized
INFO - 2018-10-09 13:12:23 --> Output Class Initialized
INFO - 2018-10-09 13:12:23 --> Security Class Initialized
DEBUG - 2018-10-09 13:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:12:23 --> CSRF cookie sent
INFO - 2018-10-09 13:12:23 --> Input Class Initialized
INFO - 2018-10-09 13:12:23 --> Language Class Initialized
INFO - 2018-10-09 13:12:23 --> Loader Class Initialized
INFO - 2018-10-09 13:12:23 --> Helper loaded: url_helper
INFO - 2018-10-09 13:12:23 --> Helper loaded: form_helper
INFO - 2018-10-09 13:12:23 --> Helper loaded: language_helper
DEBUG - 2018-10-09 13:12:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 13:12:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:12:23 --> User Agent Class Initialized
INFO - 2018-10-09 13:12:23 --> Controller Class Initialized
INFO - 2018-10-09 13:12:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 13:12:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 13:12:23 --> Pixel_Model class loaded
INFO - 2018-10-09 13:12:23 --> Database Driver Class Initialized
INFO - 2018-10-09 13:12:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:12:23 --> Database Driver Class Initialized
INFO - 2018-10-09 13:12:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:12:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 13:12:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-09 13:12:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 13:12:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 13:12:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 13:12:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 13:12:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 13:12:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_owner.php
INFO - 2018-10-09 13:12:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 13:12:23 --> Final output sent to browser
DEBUG - 2018-10-09 13:12:23 --> Total execution time: 0.0463
INFO - 2018-10-09 13:12:25 --> Config Class Initialized
INFO - 2018-10-09 13:12:25 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:12:25 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:12:25 --> Utf8 Class Initialized
INFO - 2018-10-09 13:12:25 --> URI Class Initialized
INFO - 2018-10-09 13:12:25 --> Router Class Initialized
INFO - 2018-10-09 13:12:25 --> Output Class Initialized
INFO - 2018-10-09 13:12:25 --> Security Class Initialized
DEBUG - 2018-10-09 13:12:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:12:25 --> CSRF cookie sent
INFO - 2018-10-09 13:12:25 --> Input Class Initialized
INFO - 2018-10-09 13:12:25 --> Language Class Initialized
INFO - 2018-10-09 13:12:25 --> Loader Class Initialized
INFO - 2018-10-09 13:12:25 --> Helper loaded: url_helper
INFO - 2018-10-09 13:12:25 --> Helper loaded: form_helper
INFO - 2018-10-09 13:12:25 --> Helper loaded: language_helper
DEBUG - 2018-10-09 13:12:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 13:12:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:12:25 --> User Agent Class Initialized
INFO - 2018-10-09 13:12:25 --> Controller Class Initialized
INFO - 2018-10-09 13:12:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 13:12:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 13:12:25 --> Pixel_Model class loaded
INFO - 2018-10-09 13:12:25 --> Database Driver Class Initialized
INFO - 2018-10-09 13:12:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:12:25 --> Database Driver Class Initialized
INFO - 2018-10-09 13:12:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:12:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 13:12:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-09 13:12:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 13:12:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 13:12:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 13:12:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 13:12:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 13:12:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-10-09 13:12:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 13:12:25 --> Final output sent to browser
DEBUG - 2018-10-09 13:12:25 --> Total execution time: 0.0463
INFO - 2018-10-09 13:12:26 --> Config Class Initialized
INFO - 2018-10-09 13:12:26 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:12:26 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:12:26 --> Utf8 Class Initialized
INFO - 2018-10-09 13:12:26 --> URI Class Initialized
INFO - 2018-10-09 13:12:26 --> Router Class Initialized
INFO - 2018-10-09 13:12:26 --> Output Class Initialized
INFO - 2018-10-09 13:12:26 --> Security Class Initialized
DEBUG - 2018-10-09 13:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:12:26 --> CSRF cookie sent
INFO - 2018-10-09 13:12:26 --> Input Class Initialized
INFO - 2018-10-09 13:12:26 --> Language Class Initialized
INFO - 2018-10-09 13:12:26 --> Loader Class Initialized
INFO - 2018-10-09 13:12:26 --> Helper loaded: url_helper
INFO - 2018-10-09 13:12:26 --> Helper loaded: form_helper
INFO - 2018-10-09 13:12:26 --> Helper loaded: language_helper
DEBUG - 2018-10-09 13:12:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 13:12:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:12:26 --> User Agent Class Initialized
INFO - 2018-10-09 13:12:26 --> Controller Class Initialized
INFO - 2018-10-09 13:12:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 13:12:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 13:12:26 --> Pixel_Model class loaded
INFO - 2018-10-09 13:12:26 --> Database Driver Class Initialized
INFO - 2018-10-09 13:12:26 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:12:26 --> Database Driver Class Initialized
INFO - 2018-10-09 13:12:26 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:12:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 13:12:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-09 13:12:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 13:12:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 13:12:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 13:12:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 13:12:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 13:12:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-10-09 13:12:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 13:12:26 --> Final output sent to browser
DEBUG - 2018-10-09 13:12:26 --> Total execution time: 0.0588
INFO - 2018-10-09 13:12:27 --> Config Class Initialized
INFO - 2018-10-09 13:12:27 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:12:27 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:12:27 --> Utf8 Class Initialized
INFO - 2018-10-09 13:12:27 --> URI Class Initialized
INFO - 2018-10-09 13:12:27 --> Router Class Initialized
INFO - 2018-10-09 13:12:27 --> Output Class Initialized
INFO - 2018-10-09 13:12:27 --> Security Class Initialized
DEBUG - 2018-10-09 13:12:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:12:27 --> CSRF cookie sent
INFO - 2018-10-09 13:12:27 --> Input Class Initialized
INFO - 2018-10-09 13:12:27 --> Language Class Initialized
INFO - 2018-10-09 13:12:27 --> Loader Class Initialized
INFO - 2018-10-09 13:12:27 --> Helper loaded: url_helper
INFO - 2018-10-09 13:12:27 --> Helper loaded: form_helper
INFO - 2018-10-09 13:12:27 --> Helper loaded: language_helper
DEBUG - 2018-10-09 13:12:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 13:12:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:12:27 --> User Agent Class Initialized
INFO - 2018-10-09 13:12:27 --> Controller Class Initialized
INFO - 2018-10-09 13:12:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 13:12:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 13:12:27 --> Pixel_Model class loaded
INFO - 2018-10-09 13:12:27 --> Database Driver Class Initialized
INFO - 2018-10-09 13:12:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:12:27 --> Database Driver Class Initialized
INFO - 2018-10-09 13:12:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:12:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 13:12:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-09 13:12:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 13:12:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 13:12:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 13:12:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 13:12:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 13:12:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-10-09 13:12:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 13:12:27 --> Final output sent to browser
DEBUG - 2018-10-09 13:12:27 --> Total execution time: 0.0533
INFO - 2018-10-09 13:12:30 --> Config Class Initialized
INFO - 2018-10-09 13:12:30 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:12:30 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:12:30 --> Utf8 Class Initialized
INFO - 2018-10-09 13:12:30 --> URI Class Initialized
INFO - 2018-10-09 13:12:30 --> Router Class Initialized
INFO - 2018-10-09 13:12:30 --> Output Class Initialized
INFO - 2018-10-09 13:12:30 --> Security Class Initialized
DEBUG - 2018-10-09 13:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:12:30 --> CSRF cookie sent
INFO - 2018-10-09 13:12:30 --> Input Class Initialized
INFO - 2018-10-09 13:12:30 --> Language Class Initialized
INFO - 2018-10-09 13:12:30 --> Loader Class Initialized
INFO - 2018-10-09 13:12:30 --> Helper loaded: url_helper
INFO - 2018-10-09 13:12:30 --> Helper loaded: form_helper
INFO - 2018-10-09 13:12:30 --> Helper loaded: language_helper
DEBUG - 2018-10-09 13:12:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 13:12:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:12:30 --> User Agent Class Initialized
INFO - 2018-10-09 13:12:30 --> Controller Class Initialized
INFO - 2018-10-09 13:12:30 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 13:12:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 13:12:30 --> Pixel_Model class loaded
INFO - 2018-10-09 13:12:30 --> Database Driver Class Initialized
INFO - 2018-10-09 13:12:30 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:12:30 --> Database Driver Class Initialized
INFO - 2018-10-09 13:12:30 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:12:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 13:12:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-09 13:12:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 13:12:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 13:12:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 13:12:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 13:12:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 13:12:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-10-09 13:12:30 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 13:12:30 --> Final output sent to browser
DEBUG - 2018-10-09 13:12:30 --> Total execution time: 0.0480
INFO - 2018-10-09 13:12:31 --> Config Class Initialized
INFO - 2018-10-09 13:12:31 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:12:31 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:12:31 --> Utf8 Class Initialized
INFO - 2018-10-09 13:12:31 --> URI Class Initialized
INFO - 2018-10-09 13:12:31 --> Router Class Initialized
INFO - 2018-10-09 13:12:31 --> Output Class Initialized
INFO - 2018-10-09 13:12:31 --> Security Class Initialized
DEBUG - 2018-10-09 13:12:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:12:31 --> CSRF cookie sent
INFO - 2018-10-09 13:12:31 --> Input Class Initialized
INFO - 2018-10-09 13:12:31 --> Language Class Initialized
INFO - 2018-10-09 13:12:31 --> Loader Class Initialized
INFO - 2018-10-09 13:12:31 --> Helper loaded: url_helper
INFO - 2018-10-09 13:12:31 --> Helper loaded: form_helper
INFO - 2018-10-09 13:12:31 --> Helper loaded: language_helper
DEBUG - 2018-10-09 13:12:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 13:12:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:12:31 --> User Agent Class Initialized
INFO - 2018-10-09 13:12:31 --> Controller Class Initialized
INFO - 2018-10-09 13:12:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 13:12:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 13:12:31 --> Pixel_Model class loaded
INFO - 2018-10-09 13:12:31 --> Database Driver Class Initialized
INFO - 2018-10-09 13:12:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:12:31 --> Database Driver Class Initialized
INFO - 2018-10-09 13:12:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:12:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 13:12:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-09 13:12:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 13:12:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 13:12:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 13:12:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 13:12:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 13:12:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/marriage.php
INFO - 2018-10-09 13:12:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 13:12:31 --> Final output sent to browser
DEBUG - 2018-10-09 13:12:31 --> Total execution time: 0.0394
INFO - 2018-10-09 13:12:33 --> Config Class Initialized
INFO - 2018-10-09 13:12:33 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:12:33 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:12:33 --> Utf8 Class Initialized
INFO - 2018-10-09 13:12:33 --> URI Class Initialized
INFO - 2018-10-09 13:12:33 --> Router Class Initialized
INFO - 2018-10-09 13:12:33 --> Output Class Initialized
INFO - 2018-10-09 13:12:33 --> Security Class Initialized
DEBUG - 2018-10-09 13:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:12:33 --> CSRF cookie sent
INFO - 2018-10-09 13:12:33 --> Input Class Initialized
INFO - 2018-10-09 13:12:33 --> Language Class Initialized
INFO - 2018-10-09 13:12:33 --> Loader Class Initialized
INFO - 2018-10-09 13:12:33 --> Helper loaded: url_helper
INFO - 2018-10-09 13:12:33 --> Helper loaded: form_helper
INFO - 2018-10-09 13:12:33 --> Helper loaded: language_helper
DEBUG - 2018-10-09 13:12:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 13:12:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:12:33 --> User Agent Class Initialized
INFO - 2018-10-09 13:12:33 --> Controller Class Initialized
INFO - 2018-10-09 13:12:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 13:12:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 13:12:33 --> Pixel_Model class loaded
INFO - 2018-10-09 13:12:33 --> Database Driver Class Initialized
INFO - 2018-10-09 13:12:33 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:12:33 --> Database Driver Class Initialized
INFO - 2018-10-09 13:12:33 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:12:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 13:12:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-09 13:12:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 13:12:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 13:12:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 13:12:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 13:12:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 13:12:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-09 13:12:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 13:12:33 --> Final output sent to browser
DEBUG - 2018-10-09 13:12:33 --> Total execution time: 0.0392
INFO - 2018-10-09 13:13:46 --> Config Class Initialized
INFO - 2018-10-09 13:13:46 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:13:46 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:13:46 --> Utf8 Class Initialized
INFO - 2018-10-09 13:13:46 --> URI Class Initialized
INFO - 2018-10-09 13:13:46 --> Router Class Initialized
INFO - 2018-10-09 13:13:46 --> Output Class Initialized
INFO - 2018-10-09 13:13:46 --> Security Class Initialized
DEBUG - 2018-10-09 13:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:13:46 --> CSRF cookie sent
INFO - 2018-10-09 13:13:46 --> CSRF token verified
INFO - 2018-10-09 13:13:46 --> Input Class Initialized
INFO - 2018-10-09 13:13:46 --> Language Class Initialized
INFO - 2018-10-09 13:13:46 --> Loader Class Initialized
INFO - 2018-10-09 13:13:46 --> Helper loaded: url_helper
INFO - 2018-10-09 13:13:46 --> Helper loaded: form_helper
INFO - 2018-10-09 13:13:46 --> Helper loaded: language_helper
DEBUG - 2018-10-09 13:13:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 13:13:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:13:46 --> User Agent Class Initialized
INFO - 2018-10-09 13:13:46 --> Controller Class Initialized
INFO - 2018-10-09 13:13:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 13:13:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 13:13:46 --> Pixel_Model class loaded
INFO - 2018-10-09 13:13:46 --> Database Driver Class Initialized
INFO - 2018-10-09 13:13:46 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:13:46 --> Form Validation Class Initialized
INFO - 2018-10-09 13:13:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 13:13:46 --> Database Driver Class Initialized
INFO - 2018-10-09 13:13:46 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:13:46 --> Config Class Initialized
INFO - 2018-10-09 13:13:46 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:13:46 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:13:46 --> Utf8 Class Initialized
INFO - 2018-10-09 13:13:46 --> URI Class Initialized
INFO - 2018-10-09 13:13:46 --> Router Class Initialized
INFO - 2018-10-09 13:13:46 --> Output Class Initialized
INFO - 2018-10-09 13:13:46 --> Security Class Initialized
DEBUG - 2018-10-09 13:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:13:46 --> CSRF cookie sent
INFO - 2018-10-09 13:13:46 --> Input Class Initialized
INFO - 2018-10-09 13:13:46 --> Language Class Initialized
INFO - 2018-10-09 13:13:46 --> Loader Class Initialized
INFO - 2018-10-09 13:13:46 --> Helper loaded: url_helper
INFO - 2018-10-09 13:13:46 --> Helper loaded: form_helper
INFO - 2018-10-09 13:13:46 --> Helper loaded: language_helper
DEBUG - 2018-10-09 13:13:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 13:13:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:13:46 --> User Agent Class Initialized
INFO - 2018-10-09 13:13:46 --> Controller Class Initialized
INFO - 2018-10-09 13:13:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 13:13:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 13:13:46 --> Pixel_Model class loaded
INFO - 2018-10-09 13:13:46 --> Database Driver Class Initialized
INFO - 2018-10-09 13:13:46 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:13:46 --> Database Driver Class Initialized
INFO - 2018-10-09 13:13:46 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:13:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 13:13:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-09 13:13:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 13:13:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 13:13:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 13:13:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 13:13:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 13:13:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/marriage.php
INFO - 2018-10-09 13:13:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 13:13:46 --> Final output sent to browser
DEBUG - 2018-10-09 13:13:46 --> Total execution time: 0.0439
INFO - 2018-10-09 13:13:48 --> Config Class Initialized
INFO - 2018-10-09 13:13:48 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:13:48 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:13:48 --> Utf8 Class Initialized
INFO - 2018-10-09 13:13:48 --> URI Class Initialized
INFO - 2018-10-09 13:13:48 --> Router Class Initialized
INFO - 2018-10-09 13:13:48 --> Output Class Initialized
INFO - 2018-10-09 13:13:48 --> Security Class Initialized
DEBUG - 2018-10-09 13:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:13:48 --> CSRF cookie sent
INFO - 2018-10-09 13:13:48 --> CSRF token verified
INFO - 2018-10-09 13:13:48 --> Input Class Initialized
INFO - 2018-10-09 13:13:48 --> Language Class Initialized
INFO - 2018-10-09 13:13:48 --> Loader Class Initialized
INFO - 2018-10-09 13:13:48 --> Helper loaded: url_helper
INFO - 2018-10-09 13:13:48 --> Helper loaded: form_helper
INFO - 2018-10-09 13:13:48 --> Helper loaded: language_helper
DEBUG - 2018-10-09 13:13:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 13:13:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:13:48 --> User Agent Class Initialized
INFO - 2018-10-09 13:13:48 --> Controller Class Initialized
INFO - 2018-10-09 13:13:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 13:13:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 13:13:48 --> Pixel_Model class loaded
INFO - 2018-10-09 13:13:48 --> Database Driver Class Initialized
INFO - 2018-10-09 13:13:48 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:13:48 --> Form Validation Class Initialized
INFO - 2018-10-09 13:13:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 13:13:48 --> Database Driver Class Initialized
INFO - 2018-10-09 13:13:48 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:13:48 --> Config Class Initialized
INFO - 2018-10-09 13:13:48 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:13:48 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:13:48 --> Utf8 Class Initialized
INFO - 2018-10-09 13:13:48 --> URI Class Initialized
INFO - 2018-10-09 13:13:48 --> Router Class Initialized
INFO - 2018-10-09 13:13:48 --> Output Class Initialized
INFO - 2018-10-09 13:13:48 --> Security Class Initialized
DEBUG - 2018-10-09 13:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:13:48 --> CSRF cookie sent
INFO - 2018-10-09 13:13:48 --> Input Class Initialized
INFO - 2018-10-09 13:13:48 --> Language Class Initialized
INFO - 2018-10-09 13:13:48 --> Loader Class Initialized
INFO - 2018-10-09 13:13:48 --> Helper loaded: url_helper
INFO - 2018-10-09 13:13:48 --> Helper loaded: form_helper
INFO - 2018-10-09 13:13:48 --> Helper loaded: language_helper
DEBUG - 2018-10-09 13:13:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 13:13:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:13:48 --> User Agent Class Initialized
INFO - 2018-10-09 13:13:48 --> Controller Class Initialized
INFO - 2018-10-09 13:13:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 13:13:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 13:13:48 --> Pixel_Model class loaded
INFO - 2018-10-09 13:13:48 --> Database Driver Class Initialized
INFO - 2018-10-09 13:13:48 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:13:48 --> Database Driver Class Initialized
INFO - 2018-10-09 13:13:48 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:13:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 13:13:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-09 13:13:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 13:13:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 13:13:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 13:13:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 13:13:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 13:13:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-10-09 13:13:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 13:13:48 --> Final output sent to browser
DEBUG - 2018-10-09 13:13:48 --> Total execution time: 0.0410
INFO - 2018-10-09 13:13:50 --> Config Class Initialized
INFO - 2018-10-09 13:13:50 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:13:50 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:13:50 --> Utf8 Class Initialized
INFO - 2018-10-09 13:13:50 --> URI Class Initialized
INFO - 2018-10-09 13:13:50 --> Router Class Initialized
INFO - 2018-10-09 13:13:50 --> Output Class Initialized
INFO - 2018-10-09 13:13:50 --> Security Class Initialized
DEBUG - 2018-10-09 13:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:13:50 --> CSRF cookie sent
INFO - 2018-10-09 13:13:50 --> CSRF token verified
INFO - 2018-10-09 13:13:50 --> Input Class Initialized
INFO - 2018-10-09 13:13:50 --> Language Class Initialized
INFO - 2018-10-09 13:13:50 --> Loader Class Initialized
INFO - 2018-10-09 13:13:50 --> Helper loaded: url_helper
INFO - 2018-10-09 13:13:50 --> Helper loaded: form_helper
INFO - 2018-10-09 13:13:50 --> Helper loaded: language_helper
DEBUG - 2018-10-09 13:13:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 13:13:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:13:50 --> User Agent Class Initialized
INFO - 2018-10-09 13:13:50 --> Controller Class Initialized
INFO - 2018-10-09 13:13:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 13:13:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 13:13:50 --> Pixel_Model class loaded
INFO - 2018-10-09 13:13:50 --> Database Driver Class Initialized
INFO - 2018-10-09 13:13:50 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:13:50 --> Form Validation Class Initialized
INFO - 2018-10-09 13:13:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 13:13:50 --> Database Driver Class Initialized
INFO - 2018-10-09 13:13:50 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:13:50 --> Config Class Initialized
INFO - 2018-10-09 13:13:50 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:13:50 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:13:50 --> Utf8 Class Initialized
INFO - 2018-10-09 13:13:50 --> URI Class Initialized
INFO - 2018-10-09 13:13:50 --> Router Class Initialized
INFO - 2018-10-09 13:13:50 --> Output Class Initialized
INFO - 2018-10-09 13:13:50 --> Security Class Initialized
DEBUG - 2018-10-09 13:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:13:50 --> CSRF cookie sent
INFO - 2018-10-09 13:13:50 --> Input Class Initialized
INFO - 2018-10-09 13:13:50 --> Language Class Initialized
INFO - 2018-10-09 13:13:50 --> Loader Class Initialized
INFO - 2018-10-09 13:13:50 --> Helper loaded: url_helper
INFO - 2018-10-09 13:13:50 --> Helper loaded: form_helper
INFO - 2018-10-09 13:13:50 --> Helper loaded: language_helper
DEBUG - 2018-10-09 13:13:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 13:13:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:13:50 --> User Agent Class Initialized
INFO - 2018-10-09 13:13:50 --> Controller Class Initialized
INFO - 2018-10-09 13:13:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 13:13:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 13:13:50 --> Pixel_Model class loaded
INFO - 2018-10-09 13:13:50 --> Database Driver Class Initialized
INFO - 2018-10-09 13:13:50 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:13:50 --> Database Driver Class Initialized
INFO - 2018-10-09 13:13:50 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:13:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 13:13:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-09 13:13:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 13:13:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 13:13:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 13:13:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 13:13:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 13:13:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-10-09 13:13:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 13:13:50 --> Final output sent to browser
DEBUG - 2018-10-09 13:13:50 --> Total execution time: 0.0461
INFO - 2018-10-09 13:13:52 --> Config Class Initialized
INFO - 2018-10-09 13:13:52 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:13:52 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:13:52 --> Utf8 Class Initialized
INFO - 2018-10-09 13:13:52 --> URI Class Initialized
INFO - 2018-10-09 13:13:52 --> Router Class Initialized
INFO - 2018-10-09 13:13:52 --> Output Class Initialized
INFO - 2018-10-09 13:13:52 --> Security Class Initialized
DEBUG - 2018-10-09 13:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:13:53 --> CSRF cookie sent
INFO - 2018-10-09 13:13:53 --> CSRF token verified
INFO - 2018-10-09 13:13:53 --> Input Class Initialized
INFO - 2018-10-09 13:13:53 --> Language Class Initialized
INFO - 2018-10-09 13:13:53 --> Loader Class Initialized
INFO - 2018-10-09 13:13:53 --> Helper loaded: url_helper
INFO - 2018-10-09 13:13:53 --> Helper loaded: form_helper
INFO - 2018-10-09 13:13:53 --> Helper loaded: language_helper
DEBUG - 2018-10-09 13:13:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 13:13:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:13:53 --> User Agent Class Initialized
INFO - 2018-10-09 13:13:53 --> Controller Class Initialized
INFO - 2018-10-09 13:13:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 13:13:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 13:13:53 --> Pixel_Model class loaded
INFO - 2018-10-09 13:13:53 --> Database Driver Class Initialized
INFO - 2018-10-09 13:13:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:13:53 --> Form Validation Class Initialized
INFO - 2018-10-09 13:13:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 13:13:53 --> Database Driver Class Initialized
INFO - 2018-10-09 13:13:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:13:53 --> Config Class Initialized
INFO - 2018-10-09 13:13:53 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:13:53 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:13:53 --> Utf8 Class Initialized
INFO - 2018-10-09 13:13:53 --> URI Class Initialized
INFO - 2018-10-09 13:13:53 --> Router Class Initialized
INFO - 2018-10-09 13:13:53 --> Output Class Initialized
INFO - 2018-10-09 13:13:53 --> Security Class Initialized
DEBUG - 2018-10-09 13:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:13:53 --> CSRF cookie sent
INFO - 2018-10-09 13:13:53 --> Input Class Initialized
INFO - 2018-10-09 13:13:53 --> Language Class Initialized
INFO - 2018-10-09 13:13:53 --> Loader Class Initialized
INFO - 2018-10-09 13:13:53 --> Helper loaded: url_helper
INFO - 2018-10-09 13:13:53 --> Helper loaded: form_helper
INFO - 2018-10-09 13:13:53 --> Helper loaded: language_helper
DEBUG - 2018-10-09 13:13:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 13:13:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:13:53 --> User Agent Class Initialized
INFO - 2018-10-09 13:13:53 --> Controller Class Initialized
INFO - 2018-10-09 13:13:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 13:13:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 13:13:53 --> Pixel_Model class loaded
INFO - 2018-10-09 13:13:53 --> Database Driver Class Initialized
INFO - 2018-10-09 13:13:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:13:53 --> Database Driver Class Initialized
INFO - 2018-10-09 13:13:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:13:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 13:13:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-09 13:13:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 13:13:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 13:13:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 13:13:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 13:13:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 13:13:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-10-09 13:13:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 13:13:53 --> Final output sent to browser
DEBUG - 2018-10-09 13:13:53 --> Total execution time: 0.0454
INFO - 2018-10-09 13:13:54 --> Config Class Initialized
INFO - 2018-10-09 13:13:54 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:13:54 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:13:54 --> Utf8 Class Initialized
INFO - 2018-10-09 13:13:54 --> URI Class Initialized
INFO - 2018-10-09 13:13:54 --> Router Class Initialized
INFO - 2018-10-09 13:13:54 --> Output Class Initialized
INFO - 2018-10-09 13:13:54 --> Security Class Initialized
DEBUG - 2018-10-09 13:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:13:54 --> CSRF cookie sent
INFO - 2018-10-09 13:13:54 --> CSRF token verified
INFO - 2018-10-09 13:13:54 --> Input Class Initialized
INFO - 2018-10-09 13:13:54 --> Language Class Initialized
INFO - 2018-10-09 13:13:54 --> Loader Class Initialized
INFO - 2018-10-09 13:13:54 --> Helper loaded: url_helper
INFO - 2018-10-09 13:13:54 --> Helper loaded: form_helper
INFO - 2018-10-09 13:13:54 --> Helper loaded: language_helper
DEBUG - 2018-10-09 13:13:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 13:13:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:13:54 --> User Agent Class Initialized
INFO - 2018-10-09 13:13:54 --> Controller Class Initialized
INFO - 2018-10-09 13:13:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 13:13:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 13:13:54 --> Pixel_Model class loaded
INFO - 2018-10-09 13:13:54 --> Database Driver Class Initialized
INFO - 2018-10-09 13:13:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:13:54 --> Form Validation Class Initialized
INFO - 2018-10-09 13:13:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 13:13:54 --> Database Driver Class Initialized
INFO - 2018-10-09 13:13:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:13:54 --> Config Class Initialized
INFO - 2018-10-09 13:13:54 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:13:54 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:13:54 --> Utf8 Class Initialized
INFO - 2018-10-09 13:13:54 --> URI Class Initialized
INFO - 2018-10-09 13:13:54 --> Router Class Initialized
INFO - 2018-10-09 13:13:54 --> Output Class Initialized
INFO - 2018-10-09 13:13:54 --> Security Class Initialized
DEBUG - 2018-10-09 13:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:13:54 --> CSRF cookie sent
INFO - 2018-10-09 13:13:54 --> Input Class Initialized
INFO - 2018-10-09 13:13:54 --> Language Class Initialized
INFO - 2018-10-09 13:13:54 --> Loader Class Initialized
INFO - 2018-10-09 13:13:54 --> Helper loaded: url_helper
INFO - 2018-10-09 13:13:54 --> Helper loaded: form_helper
INFO - 2018-10-09 13:13:54 --> Helper loaded: language_helper
DEBUG - 2018-10-09 13:13:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 13:13:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:13:54 --> User Agent Class Initialized
INFO - 2018-10-09 13:13:54 --> Controller Class Initialized
INFO - 2018-10-09 13:13:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 13:13:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 13:13:54 --> Pixel_Model class loaded
INFO - 2018-10-09 13:13:54 --> Database Driver Class Initialized
INFO - 2018-10-09 13:13:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:13:54 --> Database Driver Class Initialized
INFO - 2018-10-09 13:13:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:13:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 13:13:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-09 13:13:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 13:13:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 13:13:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 13:13:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 13:13:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 13:13:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-10-09 13:13:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 13:13:54 --> Final output sent to browser
DEBUG - 2018-10-09 13:13:54 --> Total execution time: 0.0550
INFO - 2018-10-09 13:13:55 --> Config Class Initialized
INFO - 2018-10-09 13:13:55 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:13:55 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:13:55 --> Utf8 Class Initialized
INFO - 2018-10-09 13:13:55 --> URI Class Initialized
INFO - 2018-10-09 13:13:55 --> Router Class Initialized
INFO - 2018-10-09 13:13:55 --> Output Class Initialized
INFO - 2018-10-09 13:13:55 --> Security Class Initialized
DEBUG - 2018-10-09 13:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:13:55 --> CSRF cookie sent
INFO - 2018-10-09 13:13:55 --> CSRF token verified
INFO - 2018-10-09 13:13:55 --> Input Class Initialized
INFO - 2018-10-09 13:13:55 --> Language Class Initialized
INFO - 2018-10-09 13:13:55 --> Loader Class Initialized
INFO - 2018-10-09 13:13:55 --> Helper loaded: url_helper
INFO - 2018-10-09 13:13:55 --> Helper loaded: form_helper
INFO - 2018-10-09 13:13:55 --> Helper loaded: language_helper
DEBUG - 2018-10-09 13:13:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 13:13:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:13:55 --> User Agent Class Initialized
INFO - 2018-10-09 13:13:55 --> Controller Class Initialized
INFO - 2018-10-09 13:13:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 13:13:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 13:13:55 --> Pixel_Model class loaded
INFO - 2018-10-09 13:13:55 --> Database Driver Class Initialized
INFO - 2018-10-09 13:13:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:13:55 --> Form Validation Class Initialized
INFO - 2018-10-09 13:13:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 13:13:55 --> Database Driver Class Initialized
INFO - 2018-10-09 13:13:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:13:55 --> Config Class Initialized
INFO - 2018-10-09 13:13:55 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:13:55 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:13:55 --> Utf8 Class Initialized
INFO - 2018-10-09 13:13:55 --> URI Class Initialized
INFO - 2018-10-09 13:13:55 --> Router Class Initialized
INFO - 2018-10-09 13:13:55 --> Output Class Initialized
INFO - 2018-10-09 13:13:55 --> Security Class Initialized
DEBUG - 2018-10-09 13:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:13:55 --> CSRF cookie sent
INFO - 2018-10-09 13:13:55 --> Input Class Initialized
INFO - 2018-10-09 13:13:55 --> Language Class Initialized
INFO - 2018-10-09 13:13:55 --> Loader Class Initialized
INFO - 2018-10-09 13:13:55 --> Helper loaded: url_helper
INFO - 2018-10-09 13:13:55 --> Helper loaded: form_helper
INFO - 2018-10-09 13:13:55 --> Helper loaded: language_helper
DEBUG - 2018-10-09 13:13:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 13:13:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:13:55 --> User Agent Class Initialized
INFO - 2018-10-09 13:13:55 --> Controller Class Initialized
INFO - 2018-10-09 13:13:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 13:13:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 13:13:55 --> Pixel_Model class loaded
INFO - 2018-10-09 13:13:55 --> Database Driver Class Initialized
INFO - 2018-10-09 13:13:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:13:56 --> Database Driver Class Initialized
INFO - 2018-10-09 13:13:56 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:13:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 13:13:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-09 13:13:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 13:13:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 13:13:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 13:13:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 13:13:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 13:13:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_owner.php
INFO - 2018-10-09 13:13:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 13:13:56 --> Final output sent to browser
DEBUG - 2018-10-09 13:13:56 --> Total execution time: 0.0489
INFO - 2018-10-09 13:14:40 --> Config Class Initialized
INFO - 2018-10-09 13:14:40 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:14:40 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:14:40 --> Utf8 Class Initialized
INFO - 2018-10-09 13:14:40 --> URI Class Initialized
INFO - 2018-10-09 13:14:40 --> Router Class Initialized
INFO - 2018-10-09 13:14:40 --> Output Class Initialized
INFO - 2018-10-09 13:14:40 --> Security Class Initialized
DEBUG - 2018-10-09 13:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:14:40 --> CSRF cookie sent
INFO - 2018-10-09 13:14:40 --> CSRF token verified
INFO - 2018-10-09 13:14:40 --> Input Class Initialized
INFO - 2018-10-09 13:14:40 --> Language Class Initialized
INFO - 2018-10-09 13:14:40 --> Loader Class Initialized
INFO - 2018-10-09 13:14:40 --> Helper loaded: url_helper
INFO - 2018-10-09 13:14:40 --> Helper loaded: form_helper
INFO - 2018-10-09 13:14:40 --> Helper loaded: language_helper
DEBUG - 2018-10-09 13:14:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 13:14:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:14:40 --> User Agent Class Initialized
INFO - 2018-10-09 13:14:40 --> Controller Class Initialized
INFO - 2018-10-09 13:14:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 13:14:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 13:14:40 --> Pixel_Model class loaded
INFO - 2018-10-09 13:14:40 --> Database Driver Class Initialized
INFO - 2018-10-09 13:14:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:14:40 --> Form Validation Class Initialized
INFO - 2018-10-09 13:14:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 13:14:40 --> Database Driver Class Initialized
INFO - 2018-10-09 13:14:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:14:40 --> Config Class Initialized
INFO - 2018-10-09 13:14:40 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:14:40 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:14:40 --> Utf8 Class Initialized
INFO - 2018-10-09 13:14:40 --> URI Class Initialized
INFO - 2018-10-09 13:14:40 --> Router Class Initialized
INFO - 2018-10-09 13:14:40 --> Output Class Initialized
INFO - 2018-10-09 13:14:40 --> Security Class Initialized
DEBUG - 2018-10-09 13:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:14:40 --> CSRF cookie sent
INFO - 2018-10-09 13:14:40 --> Input Class Initialized
INFO - 2018-10-09 13:14:40 --> Language Class Initialized
INFO - 2018-10-09 13:14:40 --> Loader Class Initialized
INFO - 2018-10-09 13:14:40 --> Helper loaded: url_helper
INFO - 2018-10-09 13:14:40 --> Helper loaded: form_helper
INFO - 2018-10-09 13:14:40 --> Helper loaded: language_helper
DEBUG - 2018-10-09 13:14:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 13:14:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:14:40 --> User Agent Class Initialized
INFO - 2018-10-09 13:14:40 --> Controller Class Initialized
INFO - 2018-10-09 13:14:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 13:14:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 13:14:40 --> Pixel_Model class loaded
INFO - 2018-10-09 13:14:40 --> Database Driver Class Initialized
INFO - 2018-10-09 13:14:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:14:40 --> Database Driver Class Initialized
INFO - 2018-10-09 13:14:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:14:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 13:14:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-09 13:14:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 13:14:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 13:14:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 13:14:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 13:14:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 13:14:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_value.php
INFO - 2018-10-09 13:14:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 13:14:40 --> Final output sent to browser
DEBUG - 2018-10-09 13:14:40 --> Total execution time: 0.0502
INFO - 2018-10-09 13:18:08 --> Config Class Initialized
INFO - 2018-10-09 13:18:08 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:18:08 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:18:08 --> Utf8 Class Initialized
INFO - 2018-10-09 13:18:08 --> URI Class Initialized
INFO - 2018-10-09 13:18:08 --> Router Class Initialized
INFO - 2018-10-09 13:18:08 --> Output Class Initialized
INFO - 2018-10-09 13:18:08 --> Security Class Initialized
DEBUG - 2018-10-09 13:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:18:08 --> CSRF cookie sent
INFO - 2018-10-09 13:18:08 --> CSRF token verified
INFO - 2018-10-09 13:18:08 --> Input Class Initialized
INFO - 2018-10-09 13:18:08 --> Language Class Initialized
INFO - 2018-10-09 13:18:08 --> Loader Class Initialized
INFO - 2018-10-09 13:18:08 --> Helper loaded: url_helper
INFO - 2018-10-09 13:18:08 --> Helper loaded: form_helper
INFO - 2018-10-09 13:18:08 --> Helper loaded: language_helper
DEBUG - 2018-10-09 13:18:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 13:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:18:08 --> User Agent Class Initialized
INFO - 2018-10-09 13:18:08 --> Controller Class Initialized
INFO - 2018-10-09 13:18:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 13:18:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 13:18:08 --> Pixel_Model class loaded
INFO - 2018-10-09 13:18:08 --> Database Driver Class Initialized
INFO - 2018-10-09 13:18:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:18:08 --> Form Validation Class Initialized
INFO - 2018-10-09 13:18:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 13:18:08 --> Database Driver Class Initialized
INFO - 2018-10-09 13:18:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:18:09 --> Config Class Initialized
INFO - 2018-10-09 13:18:09 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:18:09 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:18:09 --> Utf8 Class Initialized
INFO - 2018-10-09 13:18:09 --> URI Class Initialized
INFO - 2018-10-09 13:18:09 --> Router Class Initialized
INFO - 2018-10-09 13:18:09 --> Output Class Initialized
INFO - 2018-10-09 13:18:09 --> Security Class Initialized
DEBUG - 2018-10-09 13:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:18:09 --> CSRF cookie sent
INFO - 2018-10-09 13:18:09 --> Input Class Initialized
INFO - 2018-10-09 13:18:09 --> Language Class Initialized
INFO - 2018-10-09 13:18:09 --> Loader Class Initialized
INFO - 2018-10-09 13:18:09 --> Helper loaded: url_helper
INFO - 2018-10-09 13:18:09 --> Helper loaded: form_helper
INFO - 2018-10-09 13:18:09 --> Helper loaded: language_helper
DEBUG - 2018-10-09 13:18:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 13:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:18:09 --> User Agent Class Initialized
INFO - 2018-10-09 13:18:09 --> Controller Class Initialized
INFO - 2018-10-09 13:18:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 13:18:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 13:18:09 --> Pixel_Model class loaded
INFO - 2018-10-09 13:18:09 --> Database Driver Class Initialized
INFO - 2018-10-09 13:18:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:18:09 --> Database Driver Class Initialized
INFO - 2018-10-09 13:18:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:18:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 13:18:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-09 13:18:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 13:18:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 13:18:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 13:18:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 13:18:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 13:18:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/merriage_home_title.php
INFO - 2018-10-09 13:18:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 13:18:09 --> Final output sent to browser
DEBUG - 2018-10-09 13:18:09 --> Total execution time: 0.0582
INFO - 2018-10-09 13:18:10 --> Config Class Initialized
INFO - 2018-10-09 13:18:10 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:18:10 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:18:10 --> Utf8 Class Initialized
INFO - 2018-10-09 13:18:10 --> URI Class Initialized
INFO - 2018-10-09 13:18:10 --> Router Class Initialized
INFO - 2018-10-09 13:18:10 --> Output Class Initialized
INFO - 2018-10-09 13:18:10 --> Security Class Initialized
DEBUG - 2018-10-09 13:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:18:10 --> CSRF cookie sent
INFO - 2018-10-09 13:18:10 --> CSRF token verified
INFO - 2018-10-09 13:18:10 --> Input Class Initialized
INFO - 2018-10-09 13:18:10 --> Language Class Initialized
INFO - 2018-10-09 13:18:10 --> Loader Class Initialized
INFO - 2018-10-09 13:18:10 --> Helper loaded: url_helper
INFO - 2018-10-09 13:18:10 --> Helper loaded: form_helper
INFO - 2018-10-09 13:18:10 --> Helper loaded: language_helper
DEBUG - 2018-10-09 13:18:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 13:18:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:18:10 --> User Agent Class Initialized
INFO - 2018-10-09 13:18:10 --> Controller Class Initialized
INFO - 2018-10-09 13:18:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 13:18:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 13:18:10 --> Pixel_Model class loaded
INFO - 2018-10-09 13:18:10 --> Database Driver Class Initialized
INFO - 2018-10-09 13:18:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:18:10 --> Form Validation Class Initialized
INFO - 2018-10-09 13:18:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 13:18:10 --> Database Driver Class Initialized
INFO - 2018-10-09 13:18:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:18:10 --> Config Class Initialized
INFO - 2018-10-09 13:18:10 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:18:10 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:18:10 --> Utf8 Class Initialized
INFO - 2018-10-09 13:18:10 --> URI Class Initialized
INFO - 2018-10-09 13:18:10 --> Router Class Initialized
INFO - 2018-10-09 13:18:10 --> Output Class Initialized
INFO - 2018-10-09 13:18:10 --> Security Class Initialized
DEBUG - 2018-10-09 13:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:18:10 --> CSRF cookie sent
INFO - 2018-10-09 13:18:10 --> Input Class Initialized
INFO - 2018-10-09 13:18:10 --> Language Class Initialized
INFO - 2018-10-09 13:18:10 --> Loader Class Initialized
INFO - 2018-10-09 13:18:10 --> Helper loaded: url_helper
INFO - 2018-10-09 13:18:10 --> Helper loaded: form_helper
INFO - 2018-10-09 13:18:10 --> Helper loaded: language_helper
DEBUG - 2018-10-09 13:18:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 13:18:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:18:10 --> User Agent Class Initialized
INFO - 2018-10-09 13:18:10 --> Controller Class Initialized
INFO - 2018-10-09 13:18:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 13:18:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 13:18:10 --> Pixel_Model class loaded
INFO - 2018-10-09 13:18:10 --> Database Driver Class Initialized
INFO - 2018-10-09 13:18:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:18:10 --> Database Driver Class Initialized
INFO - 2018-10-09 13:18:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:18:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 13:18:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-09 13:18:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 13:18:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 13:18:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 13:18:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 13:18:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 13:18:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-10-09 13:18:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 13:18:10 --> Final output sent to browser
DEBUG - 2018-10-09 13:18:10 --> Total execution time: 0.0478
INFO - 2018-10-09 13:18:11 --> Config Class Initialized
INFO - 2018-10-09 13:18:11 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:18:11 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:18:11 --> Utf8 Class Initialized
INFO - 2018-10-09 13:18:11 --> URI Class Initialized
INFO - 2018-10-09 13:18:11 --> Router Class Initialized
INFO - 2018-10-09 13:18:11 --> Output Class Initialized
INFO - 2018-10-09 13:18:11 --> Security Class Initialized
DEBUG - 2018-10-09 13:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:18:11 --> CSRF cookie sent
INFO - 2018-10-09 13:18:11 --> Input Class Initialized
INFO - 2018-10-09 13:18:11 --> Language Class Initialized
INFO - 2018-10-09 13:18:11 --> Loader Class Initialized
INFO - 2018-10-09 13:18:11 --> Helper loaded: url_helper
INFO - 2018-10-09 13:18:11 --> Helper loaded: form_helper
INFO - 2018-10-09 13:18:11 --> Helper loaded: language_helper
DEBUG - 2018-10-09 13:18:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 13:18:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:18:11 --> User Agent Class Initialized
INFO - 2018-10-09 13:18:11 --> Controller Class Initialized
INFO - 2018-10-09 13:18:11 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 13:18:11 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 13:18:11 --> Pixel_Model class loaded
INFO - 2018-10-09 13:18:11 --> Database Driver Class Initialized
INFO - 2018-10-09 13:18:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:18:11 --> Database Driver Class Initialized
INFO - 2018-10-09 13:18:11 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:18:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 13:18:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-09 13:18:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 13:18:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 13:18:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 13:18:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-10-09 13:18:11 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 13:18:11 --> Final output sent to browser
DEBUG - 2018-10-09 13:18:11 --> Total execution time: 0.0500
INFO - 2018-10-09 13:19:04 --> Config Class Initialized
INFO - 2018-10-09 13:19:04 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:19:04 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:19:04 --> Utf8 Class Initialized
INFO - 2018-10-09 13:19:04 --> URI Class Initialized
INFO - 2018-10-09 13:19:04 --> Router Class Initialized
INFO - 2018-10-09 13:19:04 --> Output Class Initialized
INFO - 2018-10-09 13:19:04 --> Security Class Initialized
DEBUG - 2018-10-09 13:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:19:04 --> CSRF cookie sent
INFO - 2018-10-09 13:19:04 --> Input Class Initialized
INFO - 2018-10-09 13:19:04 --> Language Class Initialized
INFO - 2018-10-09 13:19:04 --> Loader Class Initialized
INFO - 2018-10-09 13:19:04 --> Helper loaded: url_helper
INFO - 2018-10-09 13:19:04 --> Helper loaded: form_helper
INFO - 2018-10-09 13:19:04 --> Helper loaded: language_helper
DEBUG - 2018-10-09 13:19:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 13:19:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:19:04 --> User Agent Class Initialized
INFO - 2018-10-09 13:19:04 --> Controller Class Initialized
INFO - 2018-10-09 13:19:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 13:19:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 13:19:04 --> Pixel_Model class loaded
INFO - 2018-10-09 13:19:04 --> Database Driver Class Initialized
INFO - 2018-10-09 13:19:04 --> Model "MyAccountModel" initialized
INFO - 2018-10-09 13:19:04 --> Config Class Initialized
INFO - 2018-10-09 13:19:04 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:19:04 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:19:04 --> Utf8 Class Initialized
INFO - 2018-10-09 13:19:04 --> URI Class Initialized
INFO - 2018-10-09 13:19:04 --> Router Class Initialized
INFO - 2018-10-09 13:19:04 --> Output Class Initialized
INFO - 2018-10-09 13:19:04 --> Security Class Initialized
DEBUG - 2018-10-09 13:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:19:04 --> CSRF cookie sent
INFO - 2018-10-09 13:19:04 --> Input Class Initialized
INFO - 2018-10-09 13:19:04 --> Language Class Initialized
INFO - 2018-10-09 13:19:04 --> Loader Class Initialized
INFO - 2018-10-09 13:19:04 --> Helper loaded: url_helper
INFO - 2018-10-09 13:19:04 --> Helper loaded: form_helper
INFO - 2018-10-09 13:19:04 --> Helper loaded: language_helper
DEBUG - 2018-10-09 13:19:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 13:19:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:19:04 --> User Agent Class Initialized
INFO - 2018-10-09 13:19:04 --> Controller Class Initialized
INFO - 2018-10-09 13:19:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 13:19:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 13:19:04 --> Pixel_Model class loaded
INFO - 2018-10-09 13:19:04 --> Database Driver Class Initialized
INFO - 2018-10-09 13:19:04 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:19:04 --> Database Driver Class Initialized
INFO - 2018-10-09 13:19:04 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:19:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 13:19:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-09 13:19:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 13:19:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 13:19:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 13:19:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 13:19:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 13:19:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-10-09 13:19:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 13:19:04 --> Final output sent to browser
DEBUG - 2018-10-09 13:19:04 --> Total execution time: 0.0596
INFO - 2018-10-09 13:19:07 --> Config Class Initialized
INFO - 2018-10-09 13:19:07 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:19:07 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:19:07 --> Utf8 Class Initialized
INFO - 2018-10-09 13:19:07 --> URI Class Initialized
INFO - 2018-10-09 13:19:07 --> Router Class Initialized
INFO - 2018-10-09 13:19:07 --> Output Class Initialized
INFO - 2018-10-09 13:19:07 --> Security Class Initialized
DEBUG - 2018-10-09 13:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:19:07 --> CSRF cookie sent
INFO - 2018-10-09 13:19:07 --> Input Class Initialized
INFO - 2018-10-09 13:19:07 --> Language Class Initialized
INFO - 2018-10-09 13:19:07 --> Loader Class Initialized
INFO - 2018-10-09 13:19:07 --> Helper loaded: url_helper
INFO - 2018-10-09 13:19:07 --> Helper loaded: form_helper
INFO - 2018-10-09 13:19:07 --> Helper loaded: language_helper
DEBUG - 2018-10-09 13:19:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 13:19:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:19:07 --> User Agent Class Initialized
INFO - 2018-10-09 13:19:07 --> Controller Class Initialized
INFO - 2018-10-09 13:19:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 13:19:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 13:19:07 --> Pixel_Model class loaded
INFO - 2018-10-09 13:19:07 --> Database Driver Class Initialized
INFO - 2018-10-09 13:19:07 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:19:07 --> Database Driver Class Initialized
INFO - 2018-10-09 13:19:07 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:19:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 13:19:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-09 13:19:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 13:19:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 13:19:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 13:19:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 13:19:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 13:19:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/merriage_home_title.php
INFO - 2018-10-09 13:19:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 13:19:07 --> Final output sent to browser
DEBUG - 2018-10-09 13:19:07 --> Total execution time: 0.0464
INFO - 2018-10-09 13:19:08 --> Config Class Initialized
INFO - 2018-10-09 13:19:08 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:19:08 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:19:08 --> Utf8 Class Initialized
INFO - 2018-10-09 13:19:08 --> URI Class Initialized
INFO - 2018-10-09 13:19:08 --> Router Class Initialized
INFO - 2018-10-09 13:19:08 --> Output Class Initialized
INFO - 2018-10-09 13:19:08 --> Security Class Initialized
DEBUG - 2018-10-09 13:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:19:08 --> CSRF cookie sent
INFO - 2018-10-09 13:19:08 --> Input Class Initialized
INFO - 2018-10-09 13:19:08 --> Language Class Initialized
INFO - 2018-10-09 13:19:08 --> Loader Class Initialized
INFO - 2018-10-09 13:19:08 --> Helper loaded: url_helper
INFO - 2018-10-09 13:19:08 --> Helper loaded: form_helper
INFO - 2018-10-09 13:19:08 --> Helper loaded: language_helper
DEBUG - 2018-10-09 13:19:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 13:19:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:19:08 --> User Agent Class Initialized
INFO - 2018-10-09 13:19:08 --> Controller Class Initialized
INFO - 2018-10-09 13:19:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 13:19:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 13:19:08 --> Pixel_Model class loaded
INFO - 2018-10-09 13:19:08 --> Database Driver Class Initialized
INFO - 2018-10-09 13:19:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:19:08 --> Database Driver Class Initialized
INFO - 2018-10-09 13:19:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:19:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 13:19:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-09 13:19:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 13:19:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 13:19:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 13:19:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-10-09 13:19:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 13:19:08 --> Final output sent to browser
DEBUG - 2018-10-09 13:19:08 --> Total execution time: 0.0453
INFO - 2018-10-09 13:22:16 --> Config Class Initialized
INFO - 2018-10-09 13:22:16 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:22:16 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:22:16 --> Utf8 Class Initialized
INFO - 2018-10-09 13:22:16 --> URI Class Initialized
INFO - 2018-10-09 13:22:16 --> Router Class Initialized
INFO - 2018-10-09 13:22:16 --> Output Class Initialized
INFO - 2018-10-09 13:22:16 --> Security Class Initialized
DEBUG - 2018-10-09 13:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:22:16 --> CSRF cookie sent
INFO - 2018-10-09 13:22:16 --> Input Class Initialized
INFO - 2018-10-09 13:22:16 --> Language Class Initialized
ERROR - 2018-10-09 13:22:16 --> 404 Page Not Found: 401shtml/index
INFO - 2018-10-09 13:22:16 --> Config Class Initialized
INFO - 2018-10-09 13:22:16 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:22:16 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:22:16 --> Utf8 Class Initialized
INFO - 2018-10-09 13:22:16 --> URI Class Initialized
INFO - 2018-10-09 13:22:16 --> Router Class Initialized
INFO - 2018-10-09 13:22:16 --> Output Class Initialized
INFO - 2018-10-09 13:22:16 --> Security Class Initialized
DEBUG - 2018-10-09 13:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:22:16 --> CSRF cookie sent
INFO - 2018-10-09 13:22:16 --> Input Class Initialized
INFO - 2018-10-09 13:22:16 --> Language Class Initialized
ERROR - 2018-10-09 13:22:16 --> 404 Page Not Found: Faviconico/index
INFO - 2018-10-09 13:22:22 --> Config Class Initialized
INFO - 2018-10-09 13:22:22 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:22:22 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:22:22 --> Utf8 Class Initialized
INFO - 2018-10-09 13:22:22 --> URI Class Initialized
DEBUG - 2018-10-09 13:22:22 --> No URI present. Default controller set.
INFO - 2018-10-09 13:22:22 --> Router Class Initialized
INFO - 2018-10-09 13:22:22 --> Output Class Initialized
INFO - 2018-10-09 13:22:22 --> Security Class Initialized
DEBUG - 2018-10-09 13:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:22:22 --> CSRF cookie sent
INFO - 2018-10-09 13:22:22 --> Input Class Initialized
INFO - 2018-10-09 13:22:22 --> Language Class Initialized
INFO - 2018-10-09 13:22:22 --> Loader Class Initialized
INFO - 2018-10-09 13:22:22 --> Helper loaded: url_helper
INFO - 2018-10-09 13:22:22 --> Helper loaded: form_helper
INFO - 2018-10-09 13:22:22 --> Helper loaded: language_helper
DEBUG - 2018-10-09 13:22:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 13:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:22:22 --> User Agent Class Initialized
INFO - 2018-10-09 13:22:22 --> Controller Class Initialized
INFO - 2018-10-09 13:22:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 13:22:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 13:22:22 --> Pixel_Model class loaded
INFO - 2018-10-09 13:22:22 --> Database Driver Class Initialized
INFO - 2018-10-09 13:22:22 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:22:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 13:22:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 13:22:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-09 13:22:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 13:22:22 --> Final output sent to browser
DEBUG - 2018-10-09 13:22:22 --> Total execution time: 0.0415
INFO - 2018-10-09 13:22:25 --> Config Class Initialized
INFO - 2018-10-09 13:22:25 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:22:25 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:22:25 --> Utf8 Class Initialized
INFO - 2018-10-09 13:22:25 --> URI Class Initialized
INFO - 2018-10-09 13:22:25 --> Router Class Initialized
INFO - 2018-10-09 13:22:25 --> Output Class Initialized
INFO - 2018-10-09 13:22:25 --> Security Class Initialized
DEBUG - 2018-10-09 13:22:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:22:25 --> CSRF cookie sent
INFO - 2018-10-09 13:22:25 --> Input Class Initialized
INFO - 2018-10-09 13:22:25 --> Language Class Initialized
INFO - 2018-10-09 13:22:25 --> Loader Class Initialized
INFO - 2018-10-09 13:22:25 --> Helper loaded: url_helper
INFO - 2018-10-09 13:22:25 --> Helper loaded: form_helper
INFO - 2018-10-09 13:22:25 --> Helper loaded: language_helper
DEBUG - 2018-10-09 13:22:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 13:22:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:22:25 --> User Agent Class Initialized
INFO - 2018-10-09 13:22:25 --> Controller Class Initialized
INFO - 2018-10-09 13:22:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 13:22:25 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-09 13:22:25 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-10-09 13:22:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 13:22:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 13:22:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 13:22:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-10-09 13:22:25 --> Could not find the language line "req_email"
INFO - 2018-10-09 13:22:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-10-09 13:22:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 13:22:25 --> Final output sent to browser
DEBUG - 2018-10-09 13:22:25 --> Total execution time: 0.0268
INFO - 2018-10-09 13:22:52 --> Config Class Initialized
INFO - 2018-10-09 13:22:52 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:22:52 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:22:52 --> Utf8 Class Initialized
INFO - 2018-10-09 13:22:52 --> URI Class Initialized
INFO - 2018-10-09 13:22:52 --> Router Class Initialized
INFO - 2018-10-09 13:22:52 --> Output Class Initialized
INFO - 2018-10-09 13:22:52 --> Security Class Initialized
DEBUG - 2018-10-09 13:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:22:52 --> CSRF cookie sent
INFO - 2018-10-09 13:22:52 --> CSRF token verified
INFO - 2018-10-09 13:22:52 --> Input Class Initialized
INFO - 2018-10-09 13:22:52 --> Language Class Initialized
INFO - 2018-10-09 13:22:52 --> Loader Class Initialized
INFO - 2018-10-09 13:22:52 --> Helper loaded: url_helper
INFO - 2018-10-09 13:22:52 --> Helper loaded: form_helper
INFO - 2018-10-09 13:22:52 --> Helper loaded: language_helper
DEBUG - 2018-10-09 13:22:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 13:22:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:22:52 --> User Agent Class Initialized
INFO - 2018-10-09 13:22:52 --> Controller Class Initialized
INFO - 2018-10-09 13:22:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 13:22:52 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-09 13:22:52 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-10-09 13:22:52 --> Form Validation Class Initialized
INFO - 2018-10-09 13:22:52 --> Pixel_Model class loaded
INFO - 2018-10-09 13:22:52 --> Database Driver Class Initialized
INFO - 2018-10-09 13:22:52 --> Model "AuthenticationModel" initialized
INFO - 2018-10-09 13:22:52 --> Config Class Initialized
INFO - 2018-10-09 13:22:52 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:22:52 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:22:52 --> Utf8 Class Initialized
INFO - 2018-10-09 13:22:52 --> URI Class Initialized
INFO - 2018-10-09 13:22:52 --> Router Class Initialized
INFO - 2018-10-09 13:22:52 --> Output Class Initialized
INFO - 2018-10-09 13:22:52 --> Security Class Initialized
DEBUG - 2018-10-09 13:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:22:52 --> CSRF cookie sent
INFO - 2018-10-09 13:22:52 --> Input Class Initialized
INFO - 2018-10-09 13:22:52 --> Language Class Initialized
INFO - 2018-10-09 13:22:52 --> Loader Class Initialized
INFO - 2018-10-09 13:22:52 --> Helper loaded: url_helper
INFO - 2018-10-09 13:22:52 --> Helper loaded: form_helper
INFO - 2018-10-09 13:22:52 --> Helper loaded: language_helper
DEBUG - 2018-10-09 13:22:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 13:22:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:22:52 --> User Agent Class Initialized
INFO - 2018-10-09 13:22:52 --> Controller Class Initialized
INFO - 2018-10-09 13:22:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 13:22:52 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-09 13:22:52 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-10-09 13:22:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 13:22:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 13:22:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 13:22:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 13:22:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_soft_error.php
ERROR - 2018-10-09 13:22:52 --> Could not find the language line "req_email"
INFO - 2018-10-09 13:22:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-10-09 13:22:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 13:22:52 --> Final output sent to browser
DEBUG - 2018-10-09 13:22:52 --> Total execution time: 0.0231
INFO - 2018-10-09 13:23:22 --> Config Class Initialized
INFO - 2018-10-09 13:23:22 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:23:22 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:23:22 --> Utf8 Class Initialized
INFO - 2018-10-09 13:23:22 --> URI Class Initialized
INFO - 2018-10-09 13:23:22 --> Router Class Initialized
INFO - 2018-10-09 13:23:22 --> Output Class Initialized
INFO - 2018-10-09 13:23:22 --> Security Class Initialized
DEBUG - 2018-10-09 13:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:23:22 --> CSRF cookie sent
INFO - 2018-10-09 13:23:22 --> CSRF token verified
INFO - 2018-10-09 13:23:22 --> Input Class Initialized
INFO - 2018-10-09 13:23:22 --> Language Class Initialized
INFO - 2018-10-09 13:23:22 --> Loader Class Initialized
INFO - 2018-10-09 13:23:22 --> Helper loaded: url_helper
INFO - 2018-10-09 13:23:22 --> Helper loaded: form_helper
INFO - 2018-10-09 13:23:22 --> Helper loaded: language_helper
DEBUG - 2018-10-09 13:23:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 13:23:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:23:22 --> User Agent Class Initialized
INFO - 2018-10-09 13:23:22 --> Controller Class Initialized
INFO - 2018-10-09 13:23:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 13:23:22 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-09 13:23:22 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-10-09 13:23:22 --> Form Validation Class Initialized
INFO - 2018-10-09 13:23:22 --> Pixel_Model class loaded
INFO - 2018-10-09 13:23:22 --> Database Driver Class Initialized
INFO - 2018-10-09 13:23:22 --> Model "AuthenticationModel" initialized
INFO - 2018-10-09 13:23:23 --> Config Class Initialized
INFO - 2018-10-09 13:23:23 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:23:23 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:23:23 --> Utf8 Class Initialized
INFO - 2018-10-09 13:23:23 --> URI Class Initialized
DEBUG - 2018-10-09 13:23:23 --> No URI present. Default controller set.
INFO - 2018-10-09 13:23:23 --> Router Class Initialized
INFO - 2018-10-09 13:23:23 --> Output Class Initialized
INFO - 2018-10-09 13:23:23 --> Security Class Initialized
DEBUG - 2018-10-09 13:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:23:23 --> CSRF cookie sent
INFO - 2018-10-09 13:23:23 --> Input Class Initialized
INFO - 2018-10-09 13:23:23 --> Language Class Initialized
INFO - 2018-10-09 13:23:23 --> Loader Class Initialized
INFO - 2018-10-09 13:23:23 --> Helper loaded: url_helper
INFO - 2018-10-09 13:23:23 --> Helper loaded: form_helper
INFO - 2018-10-09 13:23:23 --> Helper loaded: language_helper
DEBUG - 2018-10-09 13:23:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 13:23:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:23:23 --> User Agent Class Initialized
INFO - 2018-10-09 13:23:23 --> Controller Class Initialized
INFO - 2018-10-09 13:23:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 13:23:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 13:23:23 --> Pixel_Model class loaded
INFO - 2018-10-09 13:23:23 --> Database Driver Class Initialized
INFO - 2018-10-09 13:23:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:23:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 13:23:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-09 13:23:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 13:23:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-09 13:23:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 13:23:23 --> Final output sent to browser
DEBUG - 2018-10-09 13:23:23 --> Total execution time: 0.0508
INFO - 2018-10-09 13:23:38 --> Config Class Initialized
INFO - 2018-10-09 13:23:38 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:23:38 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:23:38 --> Utf8 Class Initialized
INFO - 2018-10-09 13:23:38 --> URI Class Initialized
INFO - 2018-10-09 13:23:38 --> Router Class Initialized
INFO - 2018-10-09 13:23:38 --> Output Class Initialized
INFO - 2018-10-09 13:23:38 --> Security Class Initialized
DEBUG - 2018-10-09 13:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:23:38 --> CSRF cookie sent
INFO - 2018-10-09 13:23:38 --> Input Class Initialized
INFO - 2018-10-09 13:23:38 --> Language Class Initialized
INFO - 2018-10-09 13:23:38 --> Loader Class Initialized
INFO - 2018-10-09 13:23:38 --> Helper loaded: url_helper
INFO - 2018-10-09 13:23:38 --> Helper loaded: form_helper
INFO - 2018-10-09 13:23:38 --> Helper loaded: language_helper
DEBUG - 2018-10-09 13:23:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 13:23:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:23:38 --> User Agent Class Initialized
INFO - 2018-10-09 13:23:38 --> Controller Class Initialized
INFO - 2018-10-09 13:23:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 13:23:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 13:23:38 --> Pixel_Model class loaded
INFO - 2018-10-09 13:23:38 --> Database Driver Class Initialized
INFO - 2018-10-09 13:23:38 --> Model "MyAccountModel" initialized
INFO - 2018-10-09 13:23:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 13:23:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-09 13:23:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 13:23:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 13:23:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 13:23:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/change_order.php
INFO - 2018-10-09 13:23:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 13:23:38 --> Final output sent to browser
DEBUG - 2018-10-09 13:23:38 --> Total execution time: 0.0385
INFO - 2018-10-09 13:23:44 --> Config Class Initialized
INFO - 2018-10-09 13:23:44 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:23:44 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:23:44 --> Utf8 Class Initialized
INFO - 2018-10-09 13:23:44 --> URI Class Initialized
DEBUG - 2018-10-09 13:23:44 --> No URI present. Default controller set.
INFO - 2018-10-09 13:23:44 --> Router Class Initialized
INFO - 2018-10-09 13:23:44 --> Output Class Initialized
INFO - 2018-10-09 13:23:44 --> Security Class Initialized
DEBUG - 2018-10-09 13:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:23:44 --> CSRF cookie sent
INFO - 2018-10-09 13:23:44 --> Input Class Initialized
INFO - 2018-10-09 13:23:44 --> Language Class Initialized
INFO - 2018-10-09 13:23:44 --> Loader Class Initialized
INFO - 2018-10-09 13:23:44 --> Helper loaded: url_helper
INFO - 2018-10-09 13:23:44 --> Helper loaded: form_helper
INFO - 2018-10-09 13:23:44 --> Helper loaded: language_helper
DEBUG - 2018-10-09 13:23:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 13:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:23:44 --> User Agent Class Initialized
INFO - 2018-10-09 13:23:44 --> Controller Class Initialized
INFO - 2018-10-09 13:23:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 13:23:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 13:23:44 --> Pixel_Model class loaded
INFO - 2018-10-09 13:23:44 --> Database Driver Class Initialized
INFO - 2018-10-09 13:23:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 13:23:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 13:23:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-09 13:23:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 13:23:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-09 13:23:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 13:23:44 --> Final output sent to browser
DEBUG - 2018-10-09 13:23:44 --> Total execution time: 0.0502
INFO - 2018-10-09 13:23:50 --> Config Class Initialized
INFO - 2018-10-09 13:23:50 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:23:50 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:23:50 --> Utf8 Class Initialized
INFO - 2018-10-09 13:23:50 --> URI Class Initialized
INFO - 2018-10-09 13:23:50 --> Router Class Initialized
INFO - 2018-10-09 13:23:50 --> Output Class Initialized
INFO - 2018-10-09 13:23:50 --> Security Class Initialized
DEBUG - 2018-10-09 13:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:23:50 --> CSRF cookie sent
INFO - 2018-10-09 13:23:50 --> Input Class Initialized
INFO - 2018-10-09 13:23:50 --> Language Class Initialized
INFO - 2018-10-09 13:23:50 --> Loader Class Initialized
INFO - 2018-10-09 13:23:50 --> Helper loaded: url_helper
INFO - 2018-10-09 13:23:50 --> Helper loaded: form_helper
INFO - 2018-10-09 13:23:50 --> Helper loaded: language_helper
DEBUG - 2018-10-09 13:23:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 13:23:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:23:50 --> User Agent Class Initialized
INFO - 2018-10-09 13:23:50 --> Controller Class Initialized
INFO - 2018-10-09 13:23:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 13:23:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 13:23:50 --> Pixel_Model class loaded
INFO - 2018-10-09 13:23:50 --> Database Driver Class Initialized
INFO - 2018-10-09 13:23:50 --> Model "MyAccountModel" initialized
INFO - 2018-10-09 13:23:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 13:23:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-09 13:23:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 13:23:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 13:23:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 13:23:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/change_order.php
INFO - 2018-10-09 13:23:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 13:23:50 --> Final output sent to browser
DEBUG - 2018-10-09 13:23:50 --> Total execution time: 0.0482
INFO - 2018-10-09 16:42:00 --> Config Class Initialized
INFO - 2018-10-09 16:42:00 --> Hooks Class Initialized
DEBUG - 2018-10-09 16:42:00 --> UTF-8 Support Enabled
INFO - 2018-10-09 16:42:00 --> Utf8 Class Initialized
INFO - 2018-10-09 16:42:00 --> URI Class Initialized
INFO - 2018-10-09 16:42:00 --> Router Class Initialized
INFO - 2018-10-09 16:42:00 --> Output Class Initialized
INFO - 2018-10-09 16:42:00 --> Security Class Initialized
DEBUG - 2018-10-09 16:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 16:42:00 --> CSRF cookie sent
INFO - 2018-10-09 16:42:05 --> Config Class Initialized
INFO - 2018-10-09 16:42:05 --> Hooks Class Initialized
DEBUG - 2018-10-09 16:42:05 --> UTF-8 Support Enabled
INFO - 2018-10-09 16:42:05 --> Utf8 Class Initialized
INFO - 2018-10-09 16:42:05 --> URI Class Initialized
INFO - 2018-10-09 16:42:05 --> Router Class Initialized
INFO - 2018-10-09 16:42:05 --> Output Class Initialized
INFO - 2018-10-09 16:42:05 --> Security Class Initialized
DEBUG - 2018-10-09 16:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 16:42:05 --> CSRF cookie sent
INFO - 2018-10-09 16:42:05 --> Input Class Initialized
INFO - 2018-10-09 16:42:05 --> Language Class Initialized
INFO - 2018-10-09 16:42:05 --> Loader Class Initialized
INFO - 2018-10-09 16:42:05 --> Helper loaded: url_helper
INFO - 2018-10-09 16:42:05 --> Helper loaded: form_helper
INFO - 2018-10-09 16:42:05 --> Helper loaded: language_helper
DEBUG - 2018-10-09 16:42:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 16:42:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 16:42:05 --> User Agent Class Initialized
INFO - 2018-10-09 16:42:05 --> Controller Class Initialized
INFO - 2018-10-09 16:42:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 16:42:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 16:42:06 --> Config Class Initialized
INFO - 2018-10-09 16:42:06 --> Hooks Class Initialized
DEBUG - 2018-10-09 16:42:06 --> UTF-8 Support Enabled
INFO - 2018-10-09 16:42:06 --> Utf8 Class Initialized
INFO - 2018-10-09 16:42:06 --> URI Class Initialized
INFO - 2018-10-09 16:42:06 --> Router Class Initialized
INFO - 2018-10-09 16:42:06 --> Output Class Initialized
INFO - 2018-10-09 16:42:06 --> Security Class Initialized
DEBUG - 2018-10-09 16:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 16:42:06 --> CSRF cookie sent
INFO - 2018-10-09 16:42:06 --> Input Class Initialized
INFO - 2018-10-09 16:42:06 --> Language Class Initialized
INFO - 2018-10-09 16:42:06 --> Loader Class Initialized
INFO - 2018-10-09 16:42:06 --> Helper loaded: url_helper
INFO - 2018-10-09 16:42:06 --> Helper loaded: form_helper
INFO - 2018-10-09 16:42:06 --> Helper loaded: language_helper
DEBUG - 2018-10-09 16:42:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 16:42:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 16:42:06 --> User Agent Class Initialized
INFO - 2018-10-09 16:42:06 --> Controller Class Initialized
INFO - 2018-10-09 16:42:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 16:42:06 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-09 16:42:06 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-10-09 16:42:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 16:42:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 16:42:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 16:42:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-10-09 16:42:06 --> Could not find the language line "req_email"
INFO - 2018-10-09 16:42:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-10-09 16:42:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 16:42:06 --> Final output sent to browser
DEBUG - 2018-10-09 16:42:06 --> Total execution time: 0.0333
INFO - 2018-10-09 17:38:15 --> Config Class Initialized
INFO - 2018-10-09 17:38:15 --> Hooks Class Initialized
DEBUG - 2018-10-09 17:38:15 --> UTF-8 Support Enabled
INFO - 2018-10-09 17:38:15 --> Utf8 Class Initialized
INFO - 2018-10-09 17:38:15 --> URI Class Initialized
DEBUG - 2018-10-09 17:38:15 --> No URI present. Default controller set.
INFO - 2018-10-09 17:38:15 --> Router Class Initialized
INFO - 2018-10-09 17:38:15 --> Output Class Initialized
INFO - 2018-10-09 17:38:15 --> Security Class Initialized
DEBUG - 2018-10-09 17:38:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 17:38:15 --> CSRF cookie sent
INFO - 2018-10-09 17:38:15 --> Input Class Initialized
INFO - 2018-10-09 17:38:15 --> Language Class Initialized
INFO - 2018-10-09 17:38:15 --> Loader Class Initialized
INFO - 2018-10-09 17:38:15 --> Helper loaded: url_helper
INFO - 2018-10-09 17:38:15 --> Helper loaded: form_helper
INFO - 2018-10-09 17:38:15 --> Helper loaded: language_helper
DEBUG - 2018-10-09 17:38:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 17:38:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 17:38:15 --> User Agent Class Initialized
INFO - 2018-10-09 17:38:15 --> Controller Class Initialized
INFO - 2018-10-09 17:38:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 17:38:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 17:38:15 --> Pixel_Model class loaded
INFO - 2018-10-09 17:38:15 --> Database Driver Class Initialized
INFO - 2018-10-09 17:38:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 17:38:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 17:38:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 17:38:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-09 17:38:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 17:38:15 --> Final output sent to browser
DEBUG - 2018-10-09 17:38:15 --> Total execution time: 0.0361
INFO - 2018-10-09 18:42:41 --> Config Class Initialized
INFO - 2018-10-09 18:42:41 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:42:41 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:42:41 --> Utf8 Class Initialized
INFO - 2018-10-09 18:42:41 --> URI Class Initialized
INFO - 2018-10-09 18:42:41 --> Router Class Initialized
INFO - 2018-10-09 18:42:41 --> Output Class Initialized
INFO - 2018-10-09 18:42:41 --> Security Class Initialized
DEBUG - 2018-10-09 18:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:42:41 --> CSRF cookie sent
INFO - 2018-10-09 18:42:41 --> Input Class Initialized
INFO - 2018-10-09 18:42:41 --> Language Class Initialized
INFO - 2018-10-09 18:42:41 --> Loader Class Initialized
INFO - 2018-10-09 18:42:41 --> Helper loaded: url_helper
INFO - 2018-10-09 18:42:41 --> Helper loaded: form_helper
INFO - 2018-10-09 18:42:41 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:42:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:42:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:42:41 --> User Agent Class Initialized
INFO - 2018-10-09 18:42:41 --> Controller Class Initialized
INFO - 2018-10-09 18:42:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:42:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:42:41 --> Pixel_Model class loaded
INFO - 2018-10-09 18:42:41 --> Database Driver Class Initialized
INFO - 2018-10-09 18:42:41 --> Model "MyAccountModel" initialized
ERROR - 2018-10-09 18:42:41 --> 404 Page Not Found: 
INFO - 2018-10-09 18:42:46 --> Config Class Initialized
INFO - 2018-10-09 18:42:46 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:42:46 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:42:46 --> Utf8 Class Initialized
INFO - 2018-10-09 18:42:46 --> URI Class Initialized
DEBUG - 2018-10-09 18:42:46 --> No URI present. Default controller set.
INFO - 2018-10-09 18:42:46 --> Router Class Initialized
INFO - 2018-10-09 18:42:46 --> Output Class Initialized
INFO - 2018-10-09 18:42:46 --> Security Class Initialized
DEBUG - 2018-10-09 18:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:42:46 --> CSRF cookie sent
INFO - 2018-10-09 18:42:46 --> Input Class Initialized
INFO - 2018-10-09 18:42:46 --> Language Class Initialized
INFO - 2018-10-09 18:42:46 --> Loader Class Initialized
INFO - 2018-10-09 18:42:46 --> Helper loaded: url_helper
INFO - 2018-10-09 18:42:46 --> Helper loaded: form_helper
INFO - 2018-10-09 18:42:46 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:42:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:42:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:42:46 --> User Agent Class Initialized
INFO - 2018-10-09 18:42:46 --> Controller Class Initialized
INFO - 2018-10-09 18:42:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:42:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:42:46 --> Pixel_Model class loaded
INFO - 2018-10-09 18:42:46 --> Database Driver Class Initialized
INFO - 2018-10-09 18:42:46 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:42:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 18:42:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 18:42:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-09 18:42:46 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 18:42:46 --> Final output sent to browser
DEBUG - 2018-10-09 18:42:46 --> Total execution time: 0.0371
INFO - 2018-10-09 18:42:47 --> Config Class Initialized
INFO - 2018-10-09 18:42:47 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:42:47 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:42:47 --> Utf8 Class Initialized
INFO - 2018-10-09 18:42:47 --> URI Class Initialized
DEBUG - 2018-10-09 18:42:47 --> No URI present. Default controller set.
INFO - 2018-10-09 18:42:47 --> Router Class Initialized
INFO - 2018-10-09 18:42:47 --> Output Class Initialized
INFO - 2018-10-09 18:42:47 --> Security Class Initialized
DEBUG - 2018-10-09 18:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:42:47 --> CSRF cookie sent
INFO - 2018-10-09 18:42:47 --> Input Class Initialized
INFO - 2018-10-09 18:42:47 --> Language Class Initialized
INFO - 2018-10-09 18:42:47 --> Loader Class Initialized
INFO - 2018-10-09 18:42:47 --> Helper loaded: url_helper
INFO - 2018-10-09 18:42:47 --> Helper loaded: form_helper
INFO - 2018-10-09 18:42:47 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:42:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:42:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:42:47 --> User Agent Class Initialized
INFO - 2018-10-09 18:42:47 --> Controller Class Initialized
INFO - 2018-10-09 18:42:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:42:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:42:47 --> Pixel_Model class loaded
INFO - 2018-10-09 18:42:47 --> Database Driver Class Initialized
INFO - 2018-10-09 18:42:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:42:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 18:42:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 18:42:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-09 18:42:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 18:42:47 --> Final output sent to browser
DEBUG - 2018-10-09 18:42:47 --> Total execution time: 0.0519
INFO - 2018-10-09 18:42:50 --> Config Class Initialized
INFO - 2018-10-09 18:42:50 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:42:50 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:42:50 --> Utf8 Class Initialized
INFO - 2018-10-09 18:42:50 --> URI Class Initialized
INFO - 2018-10-09 18:42:50 --> Router Class Initialized
INFO - 2018-10-09 18:42:50 --> Output Class Initialized
INFO - 2018-10-09 18:42:50 --> Security Class Initialized
DEBUG - 2018-10-09 18:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:42:50 --> CSRF cookie sent
INFO - 2018-10-09 18:42:50 --> Input Class Initialized
INFO - 2018-10-09 18:42:50 --> Language Class Initialized
INFO - 2018-10-09 18:42:50 --> Loader Class Initialized
INFO - 2018-10-09 18:42:50 --> Helper loaded: url_helper
INFO - 2018-10-09 18:42:50 --> Helper loaded: form_helper
INFO - 2018-10-09 18:42:50 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:42:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:42:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:42:50 --> User Agent Class Initialized
INFO - 2018-10-09 18:42:50 --> Controller Class Initialized
INFO - 2018-10-09 18:42:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:42:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:42:50 --> Pixel_Model class loaded
INFO - 2018-10-09 18:42:50 --> Database Driver Class Initialized
INFO - 2018-10-09 18:42:50 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:42:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 18:42:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 18:42:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 18:42:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 18:42:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 18:42:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 18:42:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-10-09 18:42:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 18:42:50 --> Final output sent to browser
DEBUG - 2018-10-09 18:42:50 --> Total execution time: 0.0405
INFO - 2018-10-09 18:42:56 --> Config Class Initialized
INFO - 2018-10-09 18:42:56 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:42:56 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:42:56 --> Utf8 Class Initialized
INFO - 2018-10-09 18:42:56 --> URI Class Initialized
INFO - 2018-10-09 18:42:56 --> Router Class Initialized
INFO - 2018-10-09 18:42:56 --> Output Class Initialized
INFO - 2018-10-09 18:42:56 --> Security Class Initialized
DEBUG - 2018-10-09 18:42:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:42:56 --> CSRF cookie sent
INFO - 2018-10-09 18:42:56 --> CSRF token verified
INFO - 2018-10-09 18:42:56 --> Input Class Initialized
INFO - 2018-10-09 18:42:56 --> Language Class Initialized
INFO - 2018-10-09 18:42:56 --> Loader Class Initialized
INFO - 2018-10-09 18:42:56 --> Helper loaded: url_helper
INFO - 2018-10-09 18:42:56 --> Helper loaded: form_helper
INFO - 2018-10-09 18:42:56 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:42:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:42:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:42:56 --> User Agent Class Initialized
INFO - 2018-10-09 18:42:56 --> Controller Class Initialized
INFO - 2018-10-09 18:42:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:42:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:42:56 --> Pixel_Model class loaded
INFO - 2018-10-09 18:42:56 --> Database Driver Class Initialized
INFO - 2018-10-09 18:42:56 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:42:56 --> Database Driver Class Initialized
INFO - 2018-10-09 18:42:56 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:42:57 --> Config Class Initialized
INFO - 2018-10-09 18:42:57 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:42:57 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:42:57 --> Utf8 Class Initialized
INFO - 2018-10-09 18:42:57 --> URI Class Initialized
INFO - 2018-10-09 18:42:57 --> Router Class Initialized
INFO - 2018-10-09 18:42:57 --> Output Class Initialized
INFO - 2018-10-09 18:42:57 --> Security Class Initialized
DEBUG - 2018-10-09 18:42:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:42:57 --> CSRF cookie sent
INFO - 2018-10-09 18:42:57 --> Input Class Initialized
INFO - 2018-10-09 18:42:57 --> Language Class Initialized
INFO - 2018-10-09 18:42:57 --> Loader Class Initialized
INFO - 2018-10-09 18:42:57 --> Helper loaded: url_helper
INFO - 2018-10-09 18:42:57 --> Helper loaded: form_helper
INFO - 2018-10-09 18:42:57 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:42:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:42:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:42:57 --> User Agent Class Initialized
INFO - 2018-10-09 18:42:57 --> Controller Class Initialized
INFO - 2018-10-09 18:42:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:42:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:42:57 --> Pixel_Model class loaded
INFO - 2018-10-09 18:42:57 --> Database Driver Class Initialized
INFO - 2018-10-09 18:42:57 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:42:57 --> Database Driver Class Initialized
INFO - 2018-10-09 18:42:57 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:42:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 18:42:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 18:42:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 18:42:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 18:42:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 18:42:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 18:42:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-09 18:42:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 18:42:57 --> Final output sent to browser
DEBUG - 2018-10-09 18:42:57 --> Total execution time: 0.0477
INFO - 2018-10-09 18:42:59 --> Config Class Initialized
INFO - 2018-10-09 18:42:59 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:42:59 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:42:59 --> Utf8 Class Initialized
INFO - 2018-10-09 18:42:59 --> URI Class Initialized
INFO - 2018-10-09 18:42:59 --> Router Class Initialized
INFO - 2018-10-09 18:42:59 --> Output Class Initialized
INFO - 2018-10-09 18:42:59 --> Security Class Initialized
DEBUG - 2018-10-09 18:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:42:59 --> CSRF cookie sent
INFO - 2018-10-09 18:42:59 --> CSRF token verified
INFO - 2018-10-09 18:42:59 --> Input Class Initialized
INFO - 2018-10-09 18:42:59 --> Language Class Initialized
INFO - 2018-10-09 18:42:59 --> Loader Class Initialized
INFO - 2018-10-09 18:42:59 --> Helper loaded: url_helper
INFO - 2018-10-09 18:42:59 --> Helper loaded: form_helper
INFO - 2018-10-09 18:42:59 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:42:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:42:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:42:59 --> User Agent Class Initialized
INFO - 2018-10-09 18:42:59 --> Controller Class Initialized
INFO - 2018-10-09 18:42:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:42:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:42:59 --> Pixel_Model class loaded
INFO - 2018-10-09 18:42:59 --> Database Driver Class Initialized
INFO - 2018-10-09 18:42:59 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:42:59 --> Form Validation Class Initialized
INFO - 2018-10-09 18:42:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 18:42:59 --> Database Driver Class Initialized
INFO - 2018-10-09 18:42:59 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:42:59 --> Config Class Initialized
INFO - 2018-10-09 18:42:59 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:42:59 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:42:59 --> Utf8 Class Initialized
INFO - 2018-10-09 18:42:59 --> URI Class Initialized
INFO - 2018-10-09 18:42:59 --> Router Class Initialized
INFO - 2018-10-09 18:42:59 --> Output Class Initialized
INFO - 2018-10-09 18:42:59 --> Security Class Initialized
DEBUG - 2018-10-09 18:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:42:59 --> CSRF cookie sent
INFO - 2018-10-09 18:42:59 --> Input Class Initialized
INFO - 2018-10-09 18:42:59 --> Language Class Initialized
INFO - 2018-10-09 18:42:59 --> Loader Class Initialized
INFO - 2018-10-09 18:42:59 --> Helper loaded: url_helper
INFO - 2018-10-09 18:42:59 --> Helper loaded: form_helper
INFO - 2018-10-09 18:42:59 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:42:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:42:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:42:59 --> User Agent Class Initialized
INFO - 2018-10-09 18:42:59 --> Controller Class Initialized
INFO - 2018-10-09 18:42:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:42:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:42:59 --> Pixel_Model class loaded
INFO - 2018-10-09 18:42:59 --> Database Driver Class Initialized
INFO - 2018-10-09 18:42:59 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:42:59 --> Database Driver Class Initialized
INFO - 2018-10-09 18:42:59 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:42:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 18:42:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 18:42:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 18:42:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 18:42:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 18:42:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 18:42:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-10-09 18:42:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 18:42:59 --> Final output sent to browser
DEBUG - 2018-10-09 18:42:59 --> Total execution time: 0.0474
INFO - 2018-10-09 18:43:01 --> Config Class Initialized
INFO - 2018-10-09 18:43:01 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:43:01 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:43:01 --> Utf8 Class Initialized
INFO - 2018-10-09 18:43:01 --> URI Class Initialized
INFO - 2018-10-09 18:43:01 --> Router Class Initialized
INFO - 2018-10-09 18:43:01 --> Output Class Initialized
INFO - 2018-10-09 18:43:01 --> Security Class Initialized
DEBUG - 2018-10-09 18:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:43:01 --> CSRF cookie sent
INFO - 2018-10-09 18:43:01 --> CSRF token verified
INFO - 2018-10-09 18:43:01 --> Input Class Initialized
INFO - 2018-10-09 18:43:01 --> Language Class Initialized
INFO - 2018-10-09 18:43:01 --> Loader Class Initialized
INFO - 2018-10-09 18:43:01 --> Helper loaded: url_helper
INFO - 2018-10-09 18:43:01 --> Helper loaded: form_helper
INFO - 2018-10-09 18:43:01 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:43:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:43:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:43:01 --> User Agent Class Initialized
INFO - 2018-10-09 18:43:01 --> Controller Class Initialized
INFO - 2018-10-09 18:43:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:43:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:43:02 --> Pixel_Model class loaded
INFO - 2018-10-09 18:43:02 --> Database Driver Class Initialized
INFO - 2018-10-09 18:43:02 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:43:02 --> Form Validation Class Initialized
INFO - 2018-10-09 18:43:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 18:43:02 --> Database Driver Class Initialized
INFO - 2018-10-09 18:43:02 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:43:02 --> Config Class Initialized
INFO - 2018-10-09 18:43:02 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:43:02 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:43:02 --> Utf8 Class Initialized
INFO - 2018-10-09 18:43:02 --> URI Class Initialized
INFO - 2018-10-09 18:43:02 --> Router Class Initialized
INFO - 2018-10-09 18:43:02 --> Output Class Initialized
INFO - 2018-10-09 18:43:02 --> Security Class Initialized
DEBUG - 2018-10-09 18:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:43:02 --> CSRF cookie sent
INFO - 2018-10-09 18:43:02 --> Input Class Initialized
INFO - 2018-10-09 18:43:02 --> Language Class Initialized
INFO - 2018-10-09 18:43:02 --> Loader Class Initialized
INFO - 2018-10-09 18:43:02 --> Helper loaded: url_helper
INFO - 2018-10-09 18:43:02 --> Helper loaded: form_helper
INFO - 2018-10-09 18:43:02 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:43:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:43:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:43:02 --> User Agent Class Initialized
INFO - 2018-10-09 18:43:02 --> Controller Class Initialized
INFO - 2018-10-09 18:43:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:43:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:43:02 --> Pixel_Model class loaded
INFO - 2018-10-09 18:43:02 --> Database Driver Class Initialized
INFO - 2018-10-09 18:43:02 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:43:02 --> Database Driver Class Initialized
INFO - 2018-10-09 18:43:02 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:43:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 18:43:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 18:43:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-10-09 18:43:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 18:43:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 18:43:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 18:43:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 18:43:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-10-09 18:43:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 18:43:02 --> Final output sent to browser
DEBUG - 2018-10-09 18:43:02 --> Total execution time: 0.0381
INFO - 2018-10-09 18:43:08 --> Config Class Initialized
INFO - 2018-10-09 18:43:08 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:43:08 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:43:08 --> Utf8 Class Initialized
INFO - 2018-10-09 18:43:08 --> URI Class Initialized
INFO - 2018-10-09 18:43:08 --> Router Class Initialized
INFO - 2018-10-09 18:43:08 --> Output Class Initialized
INFO - 2018-10-09 18:43:08 --> Security Class Initialized
DEBUG - 2018-10-09 18:43:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:43:08 --> CSRF cookie sent
INFO - 2018-10-09 18:43:08 --> CSRF token verified
INFO - 2018-10-09 18:43:08 --> Input Class Initialized
INFO - 2018-10-09 18:43:08 --> Language Class Initialized
INFO - 2018-10-09 18:43:08 --> Loader Class Initialized
INFO - 2018-10-09 18:43:08 --> Helper loaded: url_helper
INFO - 2018-10-09 18:43:08 --> Helper loaded: form_helper
INFO - 2018-10-09 18:43:08 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:43:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:43:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:43:08 --> User Agent Class Initialized
INFO - 2018-10-09 18:43:08 --> Controller Class Initialized
INFO - 2018-10-09 18:43:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:43:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:43:08 --> Pixel_Model class loaded
INFO - 2018-10-09 18:43:08 --> Database Driver Class Initialized
INFO - 2018-10-09 18:43:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:43:08 --> Form Validation Class Initialized
INFO - 2018-10-09 18:43:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 18:43:08 --> Database Driver Class Initialized
INFO - 2018-10-09 18:43:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:43:08 --> Config Class Initialized
INFO - 2018-10-09 18:43:08 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:43:08 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:43:08 --> Utf8 Class Initialized
INFO - 2018-10-09 18:43:08 --> URI Class Initialized
INFO - 2018-10-09 18:43:08 --> Router Class Initialized
INFO - 2018-10-09 18:43:08 --> Output Class Initialized
INFO - 2018-10-09 18:43:08 --> Security Class Initialized
DEBUG - 2018-10-09 18:43:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:43:08 --> CSRF cookie sent
INFO - 2018-10-09 18:43:08 --> Input Class Initialized
INFO - 2018-10-09 18:43:08 --> Language Class Initialized
INFO - 2018-10-09 18:43:08 --> Loader Class Initialized
INFO - 2018-10-09 18:43:08 --> Helper loaded: url_helper
INFO - 2018-10-09 18:43:08 --> Helper loaded: form_helper
INFO - 2018-10-09 18:43:08 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:43:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:43:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:43:08 --> User Agent Class Initialized
INFO - 2018-10-09 18:43:08 --> Controller Class Initialized
INFO - 2018-10-09 18:43:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:43:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:43:08 --> Pixel_Model class loaded
INFO - 2018-10-09 18:43:08 --> Database Driver Class Initialized
INFO - 2018-10-09 18:43:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:43:08 --> Database Driver Class Initialized
INFO - 2018-10-09 18:43:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:43:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 18:43:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 18:43:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 18:43:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 18:43:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 18:43:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 18:43:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-09 18:43:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 18:43:08 --> Final output sent to browser
DEBUG - 2018-10-09 18:43:08 --> Total execution time: 0.0473
INFO - 2018-10-09 18:46:36 --> Config Class Initialized
INFO - 2018-10-09 18:46:36 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:46:36 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:46:36 --> Utf8 Class Initialized
INFO - 2018-10-09 18:46:36 --> URI Class Initialized
INFO - 2018-10-09 18:46:36 --> Router Class Initialized
INFO - 2018-10-09 18:46:36 --> Output Class Initialized
INFO - 2018-10-09 18:46:36 --> Security Class Initialized
DEBUG - 2018-10-09 18:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:46:36 --> CSRF cookie sent
INFO - 2018-10-09 18:46:36 --> CSRF token verified
INFO - 2018-10-09 18:46:36 --> Input Class Initialized
INFO - 2018-10-09 18:46:36 --> Language Class Initialized
INFO - 2018-10-09 18:46:36 --> Loader Class Initialized
INFO - 2018-10-09 18:46:36 --> Helper loaded: url_helper
INFO - 2018-10-09 18:46:36 --> Helper loaded: form_helper
INFO - 2018-10-09 18:46:36 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:46:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:46:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:46:36 --> User Agent Class Initialized
INFO - 2018-10-09 18:46:36 --> Controller Class Initialized
INFO - 2018-10-09 18:46:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:46:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:46:36 --> Pixel_Model class loaded
INFO - 2018-10-09 18:46:36 --> Database Driver Class Initialized
INFO - 2018-10-09 18:46:36 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:46:36 --> Form Validation Class Initialized
INFO - 2018-10-09 18:46:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 18:46:36 --> Database Driver Class Initialized
INFO - 2018-10-09 18:46:36 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:46:36 --> Config Class Initialized
INFO - 2018-10-09 18:46:36 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:46:36 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:46:36 --> Utf8 Class Initialized
INFO - 2018-10-09 18:46:36 --> URI Class Initialized
INFO - 2018-10-09 18:46:36 --> Router Class Initialized
INFO - 2018-10-09 18:46:36 --> Output Class Initialized
INFO - 2018-10-09 18:46:36 --> Security Class Initialized
DEBUG - 2018-10-09 18:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:46:36 --> CSRF cookie sent
INFO - 2018-10-09 18:46:36 --> Input Class Initialized
INFO - 2018-10-09 18:46:36 --> Language Class Initialized
INFO - 2018-10-09 18:46:36 --> Loader Class Initialized
INFO - 2018-10-09 18:46:36 --> Helper loaded: url_helper
INFO - 2018-10-09 18:46:36 --> Helper loaded: form_helper
INFO - 2018-10-09 18:46:36 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:46:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:46:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:46:36 --> User Agent Class Initialized
INFO - 2018-10-09 18:46:36 --> Controller Class Initialized
INFO - 2018-10-09 18:46:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:46:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:46:36 --> Pixel_Model class loaded
INFO - 2018-10-09 18:46:36 --> Database Driver Class Initialized
INFO - 2018-10-09 18:46:36 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:46:36 --> Database Driver Class Initialized
INFO - 2018-10-09 18:46:36 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:46:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 18:46:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 18:46:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 18:46:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 18:46:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 18:46:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 18:46:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/marriage.php
INFO - 2018-10-09 18:46:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 18:46:36 --> Final output sent to browser
DEBUG - 2018-10-09 18:46:36 --> Total execution time: 0.0385
INFO - 2018-10-09 18:46:42 --> Config Class Initialized
INFO - 2018-10-09 18:46:42 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:46:42 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:46:42 --> Utf8 Class Initialized
INFO - 2018-10-09 18:46:42 --> URI Class Initialized
INFO - 2018-10-09 18:46:42 --> Router Class Initialized
INFO - 2018-10-09 18:46:42 --> Output Class Initialized
INFO - 2018-10-09 18:46:42 --> Security Class Initialized
DEBUG - 2018-10-09 18:46:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:46:42 --> CSRF cookie sent
INFO - 2018-10-09 18:46:42 --> CSRF token verified
INFO - 2018-10-09 18:46:42 --> Input Class Initialized
INFO - 2018-10-09 18:46:42 --> Language Class Initialized
INFO - 2018-10-09 18:46:42 --> Loader Class Initialized
INFO - 2018-10-09 18:46:42 --> Helper loaded: url_helper
INFO - 2018-10-09 18:46:42 --> Helper loaded: form_helper
INFO - 2018-10-09 18:46:42 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:46:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:46:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:46:42 --> User Agent Class Initialized
INFO - 2018-10-09 18:46:42 --> Controller Class Initialized
INFO - 2018-10-09 18:46:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:46:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:46:42 --> Pixel_Model class loaded
INFO - 2018-10-09 18:46:42 --> Database Driver Class Initialized
INFO - 2018-10-09 18:46:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:46:42 --> Form Validation Class Initialized
INFO - 2018-10-09 18:46:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 18:46:42 --> Database Driver Class Initialized
INFO - 2018-10-09 18:46:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:46:42 --> Config Class Initialized
INFO - 2018-10-09 18:46:42 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:46:42 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:46:42 --> Utf8 Class Initialized
INFO - 2018-10-09 18:46:42 --> URI Class Initialized
INFO - 2018-10-09 18:46:42 --> Router Class Initialized
INFO - 2018-10-09 18:46:42 --> Output Class Initialized
INFO - 2018-10-09 18:46:42 --> Security Class Initialized
DEBUG - 2018-10-09 18:46:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:46:42 --> CSRF cookie sent
INFO - 2018-10-09 18:46:42 --> Input Class Initialized
INFO - 2018-10-09 18:46:42 --> Language Class Initialized
INFO - 2018-10-09 18:46:42 --> Loader Class Initialized
INFO - 2018-10-09 18:46:42 --> Helper loaded: url_helper
INFO - 2018-10-09 18:46:42 --> Helper loaded: form_helper
INFO - 2018-10-09 18:46:42 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:46:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:46:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:46:42 --> User Agent Class Initialized
INFO - 2018-10-09 18:46:42 --> Controller Class Initialized
INFO - 2018-10-09 18:46:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:46:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:46:42 --> Pixel_Model class loaded
INFO - 2018-10-09 18:46:42 --> Database Driver Class Initialized
INFO - 2018-10-09 18:46:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:46:42 --> Database Driver Class Initialized
INFO - 2018-10-09 18:46:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:46:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 18:46:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 18:46:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 18:46:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 18:46:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 18:46:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 18:46:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-10-09 18:46:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 18:46:42 --> Final output sent to browser
DEBUG - 2018-10-09 18:46:42 --> Total execution time: 0.0343
INFO - 2018-10-09 18:52:06 --> Config Class Initialized
INFO - 2018-10-09 18:52:06 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:52:06 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:52:06 --> Utf8 Class Initialized
INFO - 2018-10-09 18:52:06 --> URI Class Initialized
INFO - 2018-10-09 18:52:06 --> Router Class Initialized
INFO - 2018-10-09 18:52:06 --> Output Class Initialized
INFO - 2018-10-09 18:52:06 --> Security Class Initialized
DEBUG - 2018-10-09 18:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:52:06 --> CSRF cookie sent
INFO - 2018-10-09 18:52:06 --> CSRF token verified
INFO - 2018-10-09 18:52:06 --> Input Class Initialized
INFO - 2018-10-09 18:52:06 --> Language Class Initialized
INFO - 2018-10-09 18:52:06 --> Loader Class Initialized
INFO - 2018-10-09 18:52:06 --> Helper loaded: url_helper
INFO - 2018-10-09 18:52:06 --> Helper loaded: form_helper
INFO - 2018-10-09 18:52:06 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:52:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:52:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:52:06 --> User Agent Class Initialized
INFO - 2018-10-09 18:52:06 --> Controller Class Initialized
INFO - 2018-10-09 18:52:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:52:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:52:06 --> Pixel_Model class loaded
INFO - 2018-10-09 18:52:06 --> Database Driver Class Initialized
INFO - 2018-10-09 18:52:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:52:06 --> Form Validation Class Initialized
INFO - 2018-10-09 18:52:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 18:52:06 --> Database Driver Class Initialized
INFO - 2018-10-09 18:52:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:52:06 --> Config Class Initialized
INFO - 2018-10-09 18:52:06 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:52:06 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:52:06 --> Utf8 Class Initialized
INFO - 2018-10-09 18:52:06 --> URI Class Initialized
INFO - 2018-10-09 18:52:06 --> Router Class Initialized
INFO - 2018-10-09 18:52:06 --> Output Class Initialized
INFO - 2018-10-09 18:52:06 --> Security Class Initialized
DEBUG - 2018-10-09 18:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:52:06 --> CSRF cookie sent
INFO - 2018-10-09 18:52:06 --> Input Class Initialized
INFO - 2018-10-09 18:52:06 --> Language Class Initialized
INFO - 2018-10-09 18:52:06 --> Loader Class Initialized
INFO - 2018-10-09 18:52:06 --> Helper loaded: url_helper
INFO - 2018-10-09 18:52:06 --> Helper loaded: form_helper
INFO - 2018-10-09 18:52:06 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:52:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:52:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:52:06 --> User Agent Class Initialized
INFO - 2018-10-09 18:52:06 --> Controller Class Initialized
INFO - 2018-10-09 18:52:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:52:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:52:06 --> Pixel_Model class loaded
INFO - 2018-10-09 18:52:06 --> Database Driver Class Initialized
INFO - 2018-10-09 18:52:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:52:06 --> Database Driver Class Initialized
INFO - 2018-10-09 18:52:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:52:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 18:52:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 18:52:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 18:52:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 18:52:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 18:52:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 18:52:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-10-09 18:52:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 18:52:06 --> Final output sent to browser
DEBUG - 2018-10-09 18:52:06 --> Total execution time: 0.0463
INFO - 2018-10-09 18:52:15 --> Config Class Initialized
INFO - 2018-10-09 18:52:15 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:52:15 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:52:15 --> Utf8 Class Initialized
INFO - 2018-10-09 18:52:15 --> URI Class Initialized
INFO - 2018-10-09 18:52:15 --> Router Class Initialized
INFO - 2018-10-09 18:52:15 --> Output Class Initialized
INFO - 2018-10-09 18:52:15 --> Security Class Initialized
DEBUG - 2018-10-09 18:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:52:15 --> CSRF cookie sent
INFO - 2018-10-09 18:52:15 --> CSRF token verified
INFO - 2018-10-09 18:52:15 --> Input Class Initialized
INFO - 2018-10-09 18:52:15 --> Language Class Initialized
INFO - 2018-10-09 18:52:15 --> Loader Class Initialized
INFO - 2018-10-09 18:52:15 --> Helper loaded: url_helper
INFO - 2018-10-09 18:52:15 --> Helper loaded: form_helper
INFO - 2018-10-09 18:52:15 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:52:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:52:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:52:15 --> User Agent Class Initialized
INFO - 2018-10-09 18:52:15 --> Controller Class Initialized
INFO - 2018-10-09 18:52:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:52:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:52:15 --> Pixel_Model class loaded
INFO - 2018-10-09 18:52:15 --> Database Driver Class Initialized
INFO - 2018-10-09 18:52:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:52:15 --> Form Validation Class Initialized
INFO - 2018-10-09 18:52:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 18:52:15 --> Database Driver Class Initialized
INFO - 2018-10-09 18:52:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:52:15 --> Config Class Initialized
INFO - 2018-10-09 18:52:15 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:52:15 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:52:15 --> Utf8 Class Initialized
INFO - 2018-10-09 18:52:15 --> URI Class Initialized
INFO - 2018-10-09 18:52:15 --> Router Class Initialized
INFO - 2018-10-09 18:52:15 --> Output Class Initialized
INFO - 2018-10-09 18:52:15 --> Security Class Initialized
DEBUG - 2018-10-09 18:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:52:15 --> CSRF cookie sent
INFO - 2018-10-09 18:52:15 --> Input Class Initialized
INFO - 2018-10-09 18:52:15 --> Language Class Initialized
INFO - 2018-10-09 18:52:16 --> Loader Class Initialized
INFO - 2018-10-09 18:52:16 --> Helper loaded: url_helper
INFO - 2018-10-09 18:52:16 --> Helper loaded: form_helper
INFO - 2018-10-09 18:52:16 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:52:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:52:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:52:16 --> User Agent Class Initialized
INFO - 2018-10-09 18:52:16 --> Controller Class Initialized
INFO - 2018-10-09 18:52:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:52:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:52:16 --> Pixel_Model class loaded
INFO - 2018-10-09 18:52:16 --> Database Driver Class Initialized
INFO - 2018-10-09 18:52:16 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:52:16 --> Database Driver Class Initialized
INFO - 2018-10-09 18:52:16 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:52:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 18:52:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 18:52:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 18:52:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 18:52:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 18:52:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 18:52:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-10-09 18:52:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 18:52:16 --> Final output sent to browser
DEBUG - 2018-10-09 18:52:16 --> Total execution time: 0.0493
INFO - 2018-10-09 18:52:21 --> Config Class Initialized
INFO - 2018-10-09 18:52:21 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:52:21 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:52:21 --> Utf8 Class Initialized
INFO - 2018-10-09 18:52:21 --> URI Class Initialized
INFO - 2018-10-09 18:52:21 --> Router Class Initialized
INFO - 2018-10-09 18:52:21 --> Output Class Initialized
INFO - 2018-10-09 18:52:21 --> Security Class Initialized
DEBUG - 2018-10-09 18:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:52:21 --> CSRF cookie sent
INFO - 2018-10-09 18:52:21 --> CSRF token verified
INFO - 2018-10-09 18:52:21 --> Input Class Initialized
INFO - 2018-10-09 18:52:21 --> Language Class Initialized
INFO - 2018-10-09 18:52:21 --> Loader Class Initialized
INFO - 2018-10-09 18:52:21 --> Helper loaded: url_helper
INFO - 2018-10-09 18:52:21 --> Helper loaded: form_helper
INFO - 2018-10-09 18:52:21 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:52:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:52:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:52:21 --> User Agent Class Initialized
INFO - 2018-10-09 18:52:21 --> Controller Class Initialized
INFO - 2018-10-09 18:52:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:52:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:52:21 --> Pixel_Model class loaded
INFO - 2018-10-09 18:52:21 --> Database Driver Class Initialized
INFO - 2018-10-09 18:52:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:52:21 --> Form Validation Class Initialized
INFO - 2018-10-09 18:52:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 18:52:21 --> Database Driver Class Initialized
INFO - 2018-10-09 18:52:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:52:21 --> Config Class Initialized
INFO - 2018-10-09 18:52:21 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:52:21 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:52:21 --> Utf8 Class Initialized
INFO - 2018-10-09 18:52:21 --> URI Class Initialized
INFO - 2018-10-09 18:52:21 --> Router Class Initialized
INFO - 2018-10-09 18:52:21 --> Output Class Initialized
INFO - 2018-10-09 18:52:21 --> Security Class Initialized
DEBUG - 2018-10-09 18:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:52:21 --> CSRF cookie sent
INFO - 2018-10-09 18:52:21 --> Input Class Initialized
INFO - 2018-10-09 18:52:21 --> Language Class Initialized
INFO - 2018-10-09 18:52:21 --> Loader Class Initialized
INFO - 2018-10-09 18:52:21 --> Helper loaded: url_helper
INFO - 2018-10-09 18:52:21 --> Helper loaded: form_helper
INFO - 2018-10-09 18:52:21 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:52:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:52:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:52:21 --> User Agent Class Initialized
INFO - 2018-10-09 18:52:21 --> Controller Class Initialized
INFO - 2018-10-09 18:52:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:52:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:52:21 --> Pixel_Model class loaded
INFO - 2018-10-09 18:52:21 --> Database Driver Class Initialized
INFO - 2018-10-09 18:52:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:52:21 --> Database Driver Class Initialized
INFO - 2018-10-09 18:52:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:52:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 18:52:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 18:52:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 18:52:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 18:52:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 18:52:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 18:52:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-10-09 18:52:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 18:52:21 --> Final output sent to browser
DEBUG - 2018-10-09 18:52:21 --> Total execution time: 0.0450
INFO - 2018-10-09 18:52:45 --> Config Class Initialized
INFO - 2018-10-09 18:52:45 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:52:45 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:52:45 --> Utf8 Class Initialized
INFO - 2018-10-09 18:52:45 --> URI Class Initialized
INFO - 2018-10-09 18:52:45 --> Router Class Initialized
INFO - 2018-10-09 18:52:45 --> Output Class Initialized
INFO - 2018-10-09 18:52:45 --> Security Class Initialized
DEBUG - 2018-10-09 18:52:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:52:45 --> CSRF cookie sent
INFO - 2018-10-09 18:52:45 --> CSRF token verified
INFO - 2018-10-09 18:52:45 --> Input Class Initialized
INFO - 2018-10-09 18:52:45 --> Language Class Initialized
INFO - 2018-10-09 18:52:45 --> Loader Class Initialized
INFO - 2018-10-09 18:52:45 --> Helper loaded: url_helper
INFO - 2018-10-09 18:52:45 --> Helper loaded: form_helper
INFO - 2018-10-09 18:52:45 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:52:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:52:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:52:45 --> User Agent Class Initialized
INFO - 2018-10-09 18:52:45 --> Controller Class Initialized
INFO - 2018-10-09 18:52:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:52:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:52:45 --> Pixel_Model class loaded
INFO - 2018-10-09 18:52:45 --> Database Driver Class Initialized
INFO - 2018-10-09 18:52:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:52:45 --> Form Validation Class Initialized
INFO - 2018-10-09 18:52:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 18:52:45 --> Database Driver Class Initialized
INFO - 2018-10-09 18:52:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:52:45 --> Config Class Initialized
INFO - 2018-10-09 18:52:45 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:52:45 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:52:45 --> Utf8 Class Initialized
INFO - 2018-10-09 18:52:45 --> URI Class Initialized
INFO - 2018-10-09 18:52:45 --> Router Class Initialized
INFO - 2018-10-09 18:52:45 --> Output Class Initialized
INFO - 2018-10-09 18:52:45 --> Security Class Initialized
DEBUG - 2018-10-09 18:52:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:52:45 --> CSRF cookie sent
INFO - 2018-10-09 18:52:45 --> Input Class Initialized
INFO - 2018-10-09 18:52:45 --> Language Class Initialized
INFO - 2018-10-09 18:52:45 --> Loader Class Initialized
INFO - 2018-10-09 18:52:45 --> Helper loaded: url_helper
INFO - 2018-10-09 18:52:45 --> Helper loaded: form_helper
INFO - 2018-10-09 18:52:45 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:52:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:52:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:52:45 --> User Agent Class Initialized
INFO - 2018-10-09 18:52:45 --> Controller Class Initialized
INFO - 2018-10-09 18:52:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:52:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:52:45 --> Pixel_Model class loaded
INFO - 2018-10-09 18:52:45 --> Database Driver Class Initialized
INFO - 2018-10-09 18:52:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:52:45 --> Database Driver Class Initialized
INFO - 2018-10-09 18:52:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:52:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 18:52:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 18:52:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 18:52:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 18:52:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 18:52:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 18:52:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_owner.php
INFO - 2018-10-09 18:52:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 18:52:45 --> Final output sent to browser
DEBUG - 2018-10-09 18:52:45 --> Total execution time: 0.0477
INFO - 2018-10-09 18:52:48 --> Config Class Initialized
INFO - 2018-10-09 18:52:48 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:52:48 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:52:48 --> Utf8 Class Initialized
INFO - 2018-10-09 18:52:48 --> URI Class Initialized
INFO - 2018-10-09 18:52:48 --> Router Class Initialized
INFO - 2018-10-09 18:52:48 --> Output Class Initialized
INFO - 2018-10-09 18:52:48 --> Security Class Initialized
DEBUG - 2018-10-09 18:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:52:48 --> CSRF cookie sent
INFO - 2018-10-09 18:52:48 --> CSRF token verified
INFO - 2018-10-09 18:52:48 --> Input Class Initialized
INFO - 2018-10-09 18:52:48 --> Language Class Initialized
INFO - 2018-10-09 18:52:48 --> Loader Class Initialized
INFO - 2018-10-09 18:52:48 --> Helper loaded: url_helper
INFO - 2018-10-09 18:52:48 --> Helper loaded: form_helper
INFO - 2018-10-09 18:52:48 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:52:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:52:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:52:48 --> User Agent Class Initialized
INFO - 2018-10-09 18:52:48 --> Controller Class Initialized
INFO - 2018-10-09 18:52:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:52:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:52:48 --> Pixel_Model class loaded
INFO - 2018-10-09 18:52:48 --> Database Driver Class Initialized
INFO - 2018-10-09 18:52:48 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:52:48 --> Form Validation Class Initialized
INFO - 2018-10-09 18:52:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 18:52:48 --> Database Driver Class Initialized
INFO - 2018-10-09 18:52:48 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:52:48 --> Config Class Initialized
INFO - 2018-10-09 18:52:48 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:52:48 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:52:48 --> Utf8 Class Initialized
INFO - 2018-10-09 18:52:48 --> URI Class Initialized
INFO - 2018-10-09 18:52:48 --> Router Class Initialized
INFO - 2018-10-09 18:52:48 --> Output Class Initialized
INFO - 2018-10-09 18:52:48 --> Security Class Initialized
DEBUG - 2018-10-09 18:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:52:48 --> CSRF cookie sent
INFO - 2018-10-09 18:52:48 --> Input Class Initialized
INFO - 2018-10-09 18:52:48 --> Language Class Initialized
INFO - 2018-10-09 18:52:48 --> Loader Class Initialized
INFO - 2018-10-09 18:52:48 --> Helper loaded: url_helper
INFO - 2018-10-09 18:52:48 --> Helper loaded: form_helper
INFO - 2018-10-09 18:52:48 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:52:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:52:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:52:48 --> User Agent Class Initialized
INFO - 2018-10-09 18:52:48 --> Controller Class Initialized
INFO - 2018-10-09 18:52:48 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:52:48 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:52:48 --> Pixel_Model class loaded
INFO - 2018-10-09 18:52:48 --> Database Driver Class Initialized
INFO - 2018-10-09 18:52:48 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:52:48 --> Database Driver Class Initialized
INFO - 2018-10-09 18:52:48 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:52:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 18:52:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 18:52:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 18:52:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 18:52:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 18:52:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 18:52:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_value.php
INFO - 2018-10-09 18:52:48 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 18:52:48 --> Final output sent to browser
DEBUG - 2018-10-09 18:52:48 --> Total execution time: 0.0454
INFO - 2018-10-09 18:52:55 --> Config Class Initialized
INFO - 2018-10-09 18:52:55 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:52:55 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:52:55 --> Utf8 Class Initialized
INFO - 2018-10-09 18:52:55 --> URI Class Initialized
INFO - 2018-10-09 18:52:55 --> Router Class Initialized
INFO - 2018-10-09 18:52:55 --> Output Class Initialized
INFO - 2018-10-09 18:52:55 --> Security Class Initialized
DEBUG - 2018-10-09 18:52:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:52:55 --> CSRF cookie sent
INFO - 2018-10-09 18:52:55 --> CSRF token verified
INFO - 2018-10-09 18:52:55 --> Input Class Initialized
INFO - 2018-10-09 18:52:55 --> Language Class Initialized
INFO - 2018-10-09 18:52:55 --> Loader Class Initialized
INFO - 2018-10-09 18:52:55 --> Helper loaded: url_helper
INFO - 2018-10-09 18:52:55 --> Helper loaded: form_helper
INFO - 2018-10-09 18:52:55 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:52:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:52:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:52:55 --> User Agent Class Initialized
INFO - 2018-10-09 18:52:55 --> Controller Class Initialized
INFO - 2018-10-09 18:52:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:52:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:52:55 --> Pixel_Model class loaded
INFO - 2018-10-09 18:52:55 --> Database Driver Class Initialized
INFO - 2018-10-09 18:52:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:52:55 --> Form Validation Class Initialized
INFO - 2018-10-09 18:52:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 18:52:55 --> Database Driver Class Initialized
INFO - 2018-10-09 18:52:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:52:55 --> Config Class Initialized
INFO - 2018-10-09 18:52:55 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:52:55 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:52:55 --> Utf8 Class Initialized
INFO - 2018-10-09 18:52:55 --> URI Class Initialized
INFO - 2018-10-09 18:52:55 --> Router Class Initialized
INFO - 2018-10-09 18:52:55 --> Output Class Initialized
INFO - 2018-10-09 18:52:55 --> Security Class Initialized
DEBUG - 2018-10-09 18:52:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:52:55 --> CSRF cookie sent
INFO - 2018-10-09 18:52:55 --> Input Class Initialized
INFO - 2018-10-09 18:52:55 --> Language Class Initialized
INFO - 2018-10-09 18:52:55 --> Loader Class Initialized
INFO - 2018-10-09 18:52:55 --> Helper loaded: url_helper
INFO - 2018-10-09 18:52:55 --> Helper loaded: form_helper
INFO - 2018-10-09 18:52:55 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:52:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:52:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:52:55 --> User Agent Class Initialized
INFO - 2018-10-09 18:52:55 --> Controller Class Initialized
INFO - 2018-10-09 18:52:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:52:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:52:55 --> Pixel_Model class loaded
INFO - 2018-10-09 18:52:55 --> Database Driver Class Initialized
INFO - 2018-10-09 18:52:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:52:55 --> Database Driver Class Initialized
INFO - 2018-10-09 18:52:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:52:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 18:52:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 18:52:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 18:52:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 18:52:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 18:52:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 18:52:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/merriage_home_title.php
INFO - 2018-10-09 18:52:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 18:52:55 --> Final output sent to browser
DEBUG - 2018-10-09 18:52:55 --> Total execution time: 0.0465
INFO - 2018-10-09 18:52:58 --> Config Class Initialized
INFO - 2018-10-09 18:52:58 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:52:58 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:52:58 --> Utf8 Class Initialized
INFO - 2018-10-09 18:52:58 --> URI Class Initialized
INFO - 2018-10-09 18:52:58 --> Router Class Initialized
INFO - 2018-10-09 18:52:58 --> Output Class Initialized
INFO - 2018-10-09 18:52:58 --> Security Class Initialized
DEBUG - 2018-10-09 18:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:52:58 --> CSRF cookie sent
INFO - 2018-10-09 18:52:58 --> CSRF token verified
INFO - 2018-10-09 18:52:58 --> Input Class Initialized
INFO - 2018-10-09 18:52:58 --> Language Class Initialized
INFO - 2018-10-09 18:52:58 --> Loader Class Initialized
INFO - 2018-10-09 18:52:58 --> Helper loaded: url_helper
INFO - 2018-10-09 18:52:58 --> Helper loaded: form_helper
INFO - 2018-10-09 18:52:58 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:52:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:52:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:52:58 --> User Agent Class Initialized
INFO - 2018-10-09 18:52:58 --> Controller Class Initialized
INFO - 2018-10-09 18:52:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:52:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:52:58 --> Pixel_Model class loaded
INFO - 2018-10-09 18:52:58 --> Database Driver Class Initialized
INFO - 2018-10-09 18:52:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:52:58 --> Form Validation Class Initialized
INFO - 2018-10-09 18:52:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 18:52:58 --> Database Driver Class Initialized
INFO - 2018-10-09 18:52:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:52:58 --> Config Class Initialized
INFO - 2018-10-09 18:52:58 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:52:58 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:52:58 --> Utf8 Class Initialized
INFO - 2018-10-09 18:52:58 --> URI Class Initialized
INFO - 2018-10-09 18:52:58 --> Router Class Initialized
INFO - 2018-10-09 18:52:58 --> Output Class Initialized
INFO - 2018-10-09 18:52:58 --> Security Class Initialized
DEBUG - 2018-10-09 18:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:52:58 --> CSRF cookie sent
INFO - 2018-10-09 18:52:58 --> Input Class Initialized
INFO - 2018-10-09 18:52:58 --> Language Class Initialized
INFO - 2018-10-09 18:52:58 --> Loader Class Initialized
INFO - 2018-10-09 18:52:58 --> Helper loaded: url_helper
INFO - 2018-10-09 18:52:58 --> Helper loaded: form_helper
INFO - 2018-10-09 18:52:58 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:52:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:52:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:52:58 --> User Agent Class Initialized
INFO - 2018-10-09 18:52:58 --> Controller Class Initialized
INFO - 2018-10-09 18:52:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:52:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:52:58 --> Pixel_Model class loaded
INFO - 2018-10-09 18:52:58 --> Database Driver Class Initialized
INFO - 2018-10-09 18:52:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:52:58 --> Database Driver Class Initialized
INFO - 2018-10-09 18:52:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:52:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 18:52:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 18:52:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 18:52:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 18:52:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 18:52:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 18:52:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-10-09 18:52:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 18:52:58 --> Final output sent to browser
DEBUG - 2018-10-09 18:52:58 --> Total execution time: 0.0480
INFO - 2018-10-09 18:53:01 --> Config Class Initialized
INFO - 2018-10-09 18:53:01 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:53:01 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:53:01 --> Utf8 Class Initialized
INFO - 2018-10-09 18:53:01 --> URI Class Initialized
INFO - 2018-10-09 18:53:01 --> Router Class Initialized
INFO - 2018-10-09 18:53:01 --> Output Class Initialized
INFO - 2018-10-09 18:53:01 --> Security Class Initialized
DEBUG - 2018-10-09 18:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:53:01 --> CSRF cookie sent
INFO - 2018-10-09 18:53:01 --> Input Class Initialized
INFO - 2018-10-09 18:53:01 --> Language Class Initialized
INFO - 2018-10-09 18:53:01 --> Loader Class Initialized
INFO - 2018-10-09 18:53:01 --> Helper loaded: url_helper
INFO - 2018-10-09 18:53:01 --> Helper loaded: form_helper
INFO - 2018-10-09 18:53:01 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:53:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:53:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:53:01 --> User Agent Class Initialized
INFO - 2018-10-09 18:53:01 --> Controller Class Initialized
INFO - 2018-10-09 18:53:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:53:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:53:01 --> Pixel_Model class loaded
INFO - 2018-10-09 18:53:01 --> Database Driver Class Initialized
INFO - 2018-10-09 18:53:01 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:53:01 --> Database Driver Class Initialized
INFO - 2018-10-09 18:53:01 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:53:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 18:53:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 18:53:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 18:53:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 18:53:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-10-09 18:53:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 18:53:01 --> Final output sent to browser
DEBUG - 2018-10-09 18:53:01 --> Total execution time: 0.0467
INFO - 2018-10-09 18:53:10 --> Config Class Initialized
INFO - 2018-10-09 18:53:10 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:53:10 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:53:10 --> Utf8 Class Initialized
INFO - 2018-10-09 18:53:10 --> URI Class Initialized
INFO - 2018-10-09 18:53:10 --> Router Class Initialized
INFO - 2018-10-09 18:53:10 --> Output Class Initialized
INFO - 2018-10-09 18:53:10 --> Security Class Initialized
DEBUG - 2018-10-09 18:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:53:10 --> CSRF cookie sent
INFO - 2018-10-09 18:53:10 --> Input Class Initialized
INFO - 2018-10-09 18:53:10 --> Language Class Initialized
INFO - 2018-10-09 18:53:10 --> Loader Class Initialized
INFO - 2018-10-09 18:53:10 --> Helper loaded: url_helper
INFO - 2018-10-09 18:53:10 --> Helper loaded: form_helper
INFO - 2018-10-09 18:53:10 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:53:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:53:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:53:10 --> User Agent Class Initialized
INFO - 2018-10-09 18:53:10 --> Controller Class Initialized
INFO - 2018-10-09 18:53:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:53:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:53:10 --> Pixel_Model class loaded
INFO - 2018-10-09 18:53:10 --> Database Driver Class Initialized
INFO - 2018-10-09 18:53:10 --> Model "MyAccountModel" initialized
INFO - 2018-10-09 18:53:10 --> Config Class Initialized
INFO - 2018-10-09 18:53:10 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:53:10 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:53:10 --> Utf8 Class Initialized
INFO - 2018-10-09 18:53:10 --> URI Class Initialized
INFO - 2018-10-09 18:53:10 --> Router Class Initialized
INFO - 2018-10-09 18:53:10 --> Output Class Initialized
INFO - 2018-10-09 18:53:10 --> Security Class Initialized
DEBUG - 2018-10-09 18:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:53:10 --> CSRF cookie sent
INFO - 2018-10-09 18:53:10 --> Input Class Initialized
INFO - 2018-10-09 18:53:10 --> Language Class Initialized
INFO - 2018-10-09 18:53:10 --> Loader Class Initialized
INFO - 2018-10-09 18:53:10 --> Helper loaded: url_helper
INFO - 2018-10-09 18:53:10 --> Helper loaded: form_helper
INFO - 2018-10-09 18:53:10 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:53:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:53:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:53:10 --> User Agent Class Initialized
INFO - 2018-10-09 18:53:10 --> Controller Class Initialized
INFO - 2018-10-09 18:53:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:53:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:53:10 --> Pixel_Model class loaded
INFO - 2018-10-09 18:53:10 --> Database Driver Class Initialized
INFO - 2018-10-09 18:53:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:53:10 --> Database Driver Class Initialized
INFO - 2018-10-09 18:53:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:53:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 18:53:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 18:53:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 18:53:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 18:53:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 18:53:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 18:53:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-10-09 18:53:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 18:53:10 --> Final output sent to browser
DEBUG - 2018-10-09 18:53:10 --> Total execution time: 0.0681
INFO - 2018-10-09 18:53:12 --> Config Class Initialized
INFO - 2018-10-09 18:53:12 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:53:12 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:53:12 --> Utf8 Class Initialized
INFO - 2018-10-09 18:53:12 --> URI Class Initialized
INFO - 2018-10-09 18:53:12 --> Router Class Initialized
INFO - 2018-10-09 18:53:12 --> Output Class Initialized
INFO - 2018-10-09 18:53:12 --> Security Class Initialized
DEBUG - 2018-10-09 18:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:53:12 --> CSRF cookie sent
INFO - 2018-10-09 18:53:12 --> Input Class Initialized
INFO - 2018-10-09 18:53:12 --> Language Class Initialized
INFO - 2018-10-09 18:53:12 --> Loader Class Initialized
INFO - 2018-10-09 18:53:12 --> Helper loaded: url_helper
INFO - 2018-10-09 18:53:12 --> Helper loaded: form_helper
INFO - 2018-10-09 18:53:12 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:53:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:53:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:53:12 --> User Agent Class Initialized
INFO - 2018-10-09 18:53:12 --> Controller Class Initialized
INFO - 2018-10-09 18:53:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:53:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:53:12 --> Pixel_Model class loaded
INFO - 2018-10-09 18:53:12 --> Database Driver Class Initialized
INFO - 2018-10-09 18:53:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:53:12 --> Database Driver Class Initialized
INFO - 2018-10-09 18:53:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:53:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 18:53:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 18:53:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 18:53:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 18:53:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 18:53:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 18:53:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/merriage_home_title.php
INFO - 2018-10-09 18:53:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 18:53:12 --> Final output sent to browser
DEBUG - 2018-10-09 18:53:12 --> Total execution time: 0.0457
INFO - 2018-10-09 18:53:13 --> Config Class Initialized
INFO - 2018-10-09 18:53:13 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:53:13 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:53:13 --> Utf8 Class Initialized
INFO - 2018-10-09 18:53:13 --> URI Class Initialized
INFO - 2018-10-09 18:53:13 --> Router Class Initialized
INFO - 2018-10-09 18:53:13 --> Output Class Initialized
INFO - 2018-10-09 18:53:13 --> Security Class Initialized
DEBUG - 2018-10-09 18:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:53:13 --> CSRF cookie sent
INFO - 2018-10-09 18:53:13 --> Input Class Initialized
INFO - 2018-10-09 18:53:13 --> Language Class Initialized
INFO - 2018-10-09 18:53:13 --> Loader Class Initialized
INFO - 2018-10-09 18:53:13 --> Helper loaded: url_helper
INFO - 2018-10-09 18:53:13 --> Helper loaded: form_helper
INFO - 2018-10-09 18:53:13 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:53:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:53:13 --> User Agent Class Initialized
INFO - 2018-10-09 18:53:13 --> Controller Class Initialized
INFO - 2018-10-09 18:53:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:53:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:53:13 --> Pixel_Model class loaded
INFO - 2018-10-09 18:53:13 --> Database Driver Class Initialized
INFO - 2018-10-09 18:53:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:53:13 --> Database Driver Class Initialized
INFO - 2018-10-09 18:53:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:53:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 18:53:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 18:53:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 18:53:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 18:53:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 18:53:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 18:53:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_value.php
INFO - 2018-10-09 18:53:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 18:53:13 --> Final output sent to browser
DEBUG - 2018-10-09 18:53:13 --> Total execution time: 0.0485
INFO - 2018-10-09 18:53:14 --> Config Class Initialized
INFO - 2018-10-09 18:53:14 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:53:14 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:53:14 --> Utf8 Class Initialized
INFO - 2018-10-09 18:53:14 --> URI Class Initialized
INFO - 2018-10-09 18:53:14 --> Router Class Initialized
INFO - 2018-10-09 18:53:14 --> Output Class Initialized
INFO - 2018-10-09 18:53:14 --> Security Class Initialized
DEBUG - 2018-10-09 18:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:53:14 --> CSRF cookie sent
INFO - 2018-10-09 18:53:14 --> Input Class Initialized
INFO - 2018-10-09 18:53:14 --> Language Class Initialized
INFO - 2018-10-09 18:53:14 --> Loader Class Initialized
INFO - 2018-10-09 18:53:14 --> Helper loaded: url_helper
INFO - 2018-10-09 18:53:14 --> Helper loaded: form_helper
INFO - 2018-10-09 18:53:14 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:53:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:53:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:53:14 --> User Agent Class Initialized
INFO - 2018-10-09 18:53:14 --> Controller Class Initialized
INFO - 2018-10-09 18:53:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:53:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:53:14 --> Pixel_Model class loaded
INFO - 2018-10-09 18:53:14 --> Database Driver Class Initialized
INFO - 2018-10-09 18:53:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:53:14 --> Database Driver Class Initialized
INFO - 2018-10-09 18:53:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:53:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 18:53:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 18:53:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 18:53:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 18:53:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 18:53:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 18:53:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_owner.php
INFO - 2018-10-09 18:53:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 18:53:14 --> Final output sent to browser
DEBUG - 2018-10-09 18:53:14 --> Total execution time: 0.0643
INFO - 2018-10-09 18:53:16 --> Config Class Initialized
INFO - 2018-10-09 18:53:16 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:53:16 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:53:16 --> Utf8 Class Initialized
INFO - 2018-10-09 18:53:16 --> URI Class Initialized
INFO - 2018-10-09 18:53:16 --> Router Class Initialized
INFO - 2018-10-09 18:53:16 --> Output Class Initialized
INFO - 2018-10-09 18:53:16 --> Security Class Initialized
DEBUG - 2018-10-09 18:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:53:16 --> CSRF cookie sent
INFO - 2018-10-09 18:53:16 --> Input Class Initialized
INFO - 2018-10-09 18:53:16 --> Language Class Initialized
INFO - 2018-10-09 18:53:16 --> Loader Class Initialized
INFO - 2018-10-09 18:53:16 --> Helper loaded: url_helper
INFO - 2018-10-09 18:53:16 --> Helper loaded: form_helper
INFO - 2018-10-09 18:53:16 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:53:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:53:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:53:16 --> User Agent Class Initialized
INFO - 2018-10-09 18:53:16 --> Controller Class Initialized
INFO - 2018-10-09 18:53:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:53:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:53:16 --> Pixel_Model class loaded
INFO - 2018-10-09 18:53:16 --> Database Driver Class Initialized
INFO - 2018-10-09 18:53:16 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:53:16 --> Database Driver Class Initialized
INFO - 2018-10-09 18:53:16 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:53:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 18:53:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 18:53:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 18:53:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 18:53:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 18:53:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 18:53:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-10-09 18:53:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 18:53:16 --> Final output sent to browser
DEBUG - 2018-10-09 18:53:16 --> Total execution time: 0.0672
INFO - 2018-10-09 18:53:17 --> Config Class Initialized
INFO - 2018-10-09 18:53:17 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:53:17 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:53:17 --> Utf8 Class Initialized
INFO - 2018-10-09 18:53:17 --> URI Class Initialized
INFO - 2018-10-09 18:53:17 --> Router Class Initialized
INFO - 2018-10-09 18:53:17 --> Output Class Initialized
INFO - 2018-10-09 18:53:17 --> Security Class Initialized
DEBUG - 2018-10-09 18:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:53:17 --> CSRF cookie sent
INFO - 2018-10-09 18:53:17 --> Input Class Initialized
INFO - 2018-10-09 18:53:17 --> Language Class Initialized
INFO - 2018-10-09 18:53:17 --> Loader Class Initialized
INFO - 2018-10-09 18:53:17 --> Helper loaded: url_helper
INFO - 2018-10-09 18:53:17 --> Helper loaded: form_helper
INFO - 2018-10-09 18:53:17 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:53:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:53:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:53:17 --> User Agent Class Initialized
INFO - 2018-10-09 18:53:17 --> Controller Class Initialized
INFO - 2018-10-09 18:53:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:53:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:53:17 --> Pixel_Model class loaded
INFO - 2018-10-09 18:53:17 --> Database Driver Class Initialized
INFO - 2018-10-09 18:53:17 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:53:17 --> Database Driver Class Initialized
INFO - 2018-10-09 18:53:17 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:53:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 18:53:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 18:53:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 18:53:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 18:53:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 18:53:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 18:53:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-10-09 18:53:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 18:53:17 --> Final output sent to browser
DEBUG - 2018-10-09 18:53:17 --> Total execution time: 0.0657
INFO - 2018-10-09 18:53:19 --> Config Class Initialized
INFO - 2018-10-09 18:53:19 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:53:19 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:53:19 --> Utf8 Class Initialized
INFO - 2018-10-09 18:53:19 --> URI Class Initialized
INFO - 2018-10-09 18:53:19 --> Router Class Initialized
INFO - 2018-10-09 18:53:19 --> Output Class Initialized
INFO - 2018-10-09 18:53:19 --> Security Class Initialized
DEBUG - 2018-10-09 18:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:53:19 --> CSRF cookie sent
INFO - 2018-10-09 18:53:19 --> Input Class Initialized
INFO - 2018-10-09 18:53:19 --> Language Class Initialized
INFO - 2018-10-09 18:53:19 --> Loader Class Initialized
INFO - 2018-10-09 18:53:19 --> Helper loaded: url_helper
INFO - 2018-10-09 18:53:19 --> Helper loaded: form_helper
INFO - 2018-10-09 18:53:19 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:53:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:53:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:53:19 --> User Agent Class Initialized
INFO - 2018-10-09 18:53:19 --> Controller Class Initialized
INFO - 2018-10-09 18:53:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:53:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:53:19 --> Pixel_Model class loaded
INFO - 2018-10-09 18:53:19 --> Database Driver Class Initialized
INFO - 2018-10-09 18:53:19 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:53:19 --> Database Driver Class Initialized
INFO - 2018-10-09 18:53:19 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:53:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 18:53:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 18:53:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 18:53:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 18:53:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 18:53:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 18:53:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-10-09 18:53:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 18:53:19 --> Final output sent to browser
DEBUG - 2018-10-09 18:53:19 --> Total execution time: 0.0449
INFO - 2018-10-09 18:53:21 --> Config Class Initialized
INFO - 2018-10-09 18:53:21 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:53:21 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:53:21 --> Utf8 Class Initialized
INFO - 2018-10-09 18:53:21 --> URI Class Initialized
INFO - 2018-10-09 18:53:21 --> Router Class Initialized
INFO - 2018-10-09 18:53:21 --> Output Class Initialized
INFO - 2018-10-09 18:53:21 --> Security Class Initialized
DEBUG - 2018-10-09 18:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:53:21 --> CSRF cookie sent
INFO - 2018-10-09 18:53:21 --> Input Class Initialized
INFO - 2018-10-09 18:53:21 --> Language Class Initialized
INFO - 2018-10-09 18:53:21 --> Loader Class Initialized
INFO - 2018-10-09 18:53:21 --> Helper loaded: url_helper
INFO - 2018-10-09 18:53:21 --> Helper loaded: form_helper
INFO - 2018-10-09 18:53:21 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:53:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:53:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:53:21 --> User Agent Class Initialized
INFO - 2018-10-09 18:53:21 --> Controller Class Initialized
INFO - 2018-10-09 18:53:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:53:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:53:21 --> Pixel_Model class loaded
INFO - 2018-10-09 18:53:21 --> Database Driver Class Initialized
INFO - 2018-10-09 18:53:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:53:21 --> Database Driver Class Initialized
INFO - 2018-10-09 18:53:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:53:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 18:53:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 18:53:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 18:53:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 18:53:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 18:53:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 18:53:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-10-09 18:53:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 18:53:21 --> Final output sent to browser
DEBUG - 2018-10-09 18:53:21 --> Total execution time: 0.0391
INFO - 2018-10-09 18:53:23 --> Config Class Initialized
INFO - 2018-10-09 18:53:23 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:53:23 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:53:23 --> Utf8 Class Initialized
INFO - 2018-10-09 18:53:23 --> URI Class Initialized
INFO - 2018-10-09 18:53:23 --> Router Class Initialized
INFO - 2018-10-09 18:53:23 --> Output Class Initialized
INFO - 2018-10-09 18:53:23 --> Security Class Initialized
DEBUG - 2018-10-09 18:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:53:23 --> CSRF cookie sent
INFO - 2018-10-09 18:53:23 --> Input Class Initialized
INFO - 2018-10-09 18:53:23 --> Language Class Initialized
INFO - 2018-10-09 18:53:23 --> Loader Class Initialized
INFO - 2018-10-09 18:53:23 --> Helper loaded: url_helper
INFO - 2018-10-09 18:53:23 --> Helper loaded: form_helper
INFO - 2018-10-09 18:53:23 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:53:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:53:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:53:23 --> User Agent Class Initialized
INFO - 2018-10-09 18:53:23 --> Controller Class Initialized
INFO - 2018-10-09 18:53:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:53:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:53:23 --> Pixel_Model class loaded
INFO - 2018-10-09 18:53:23 --> Database Driver Class Initialized
INFO - 2018-10-09 18:53:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:53:23 --> Database Driver Class Initialized
INFO - 2018-10-09 18:53:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:53:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 18:53:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 18:53:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 18:53:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 18:53:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 18:53:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 18:53:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/marriage.php
INFO - 2018-10-09 18:53:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 18:53:23 --> Final output sent to browser
DEBUG - 2018-10-09 18:53:23 --> Total execution time: 0.0411
INFO - 2018-10-09 18:53:24 --> Config Class Initialized
INFO - 2018-10-09 18:53:24 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:53:24 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:53:24 --> Utf8 Class Initialized
INFO - 2018-10-09 18:53:24 --> URI Class Initialized
INFO - 2018-10-09 18:53:24 --> Router Class Initialized
INFO - 2018-10-09 18:53:24 --> Output Class Initialized
INFO - 2018-10-09 18:53:24 --> Security Class Initialized
DEBUG - 2018-10-09 18:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:53:24 --> CSRF cookie sent
INFO - 2018-10-09 18:53:24 --> Input Class Initialized
INFO - 2018-10-09 18:53:24 --> Language Class Initialized
INFO - 2018-10-09 18:53:24 --> Loader Class Initialized
INFO - 2018-10-09 18:53:24 --> Helper loaded: url_helper
INFO - 2018-10-09 18:53:24 --> Helper loaded: form_helper
INFO - 2018-10-09 18:53:24 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:53:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:53:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:53:24 --> User Agent Class Initialized
INFO - 2018-10-09 18:53:24 --> Controller Class Initialized
INFO - 2018-10-09 18:53:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:53:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:53:24 --> Pixel_Model class loaded
INFO - 2018-10-09 18:53:24 --> Database Driver Class Initialized
INFO - 2018-10-09 18:53:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:53:24 --> Database Driver Class Initialized
INFO - 2018-10-09 18:53:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:53:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 18:53:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 18:53:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 18:53:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 18:53:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 18:53:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 18:53:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-09 18:53:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 18:53:24 --> Final output sent to browser
DEBUG - 2018-10-09 18:53:24 --> Total execution time: 0.0558
INFO - 2018-10-09 18:53:40 --> Config Class Initialized
INFO - 2018-10-09 18:53:40 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:53:40 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:53:40 --> Utf8 Class Initialized
INFO - 2018-10-09 18:53:40 --> URI Class Initialized
INFO - 2018-10-09 18:53:40 --> Router Class Initialized
INFO - 2018-10-09 18:53:40 --> Output Class Initialized
INFO - 2018-10-09 18:53:40 --> Security Class Initialized
DEBUG - 2018-10-09 18:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:53:40 --> CSRF cookie sent
INFO - 2018-10-09 18:53:40 --> CSRF token verified
INFO - 2018-10-09 18:53:40 --> Input Class Initialized
INFO - 2018-10-09 18:53:40 --> Language Class Initialized
INFO - 2018-10-09 18:53:40 --> Loader Class Initialized
INFO - 2018-10-09 18:53:40 --> Helper loaded: url_helper
INFO - 2018-10-09 18:53:40 --> Helper loaded: form_helper
INFO - 2018-10-09 18:53:40 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:53:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:53:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:53:41 --> User Agent Class Initialized
INFO - 2018-10-09 18:53:41 --> Controller Class Initialized
INFO - 2018-10-09 18:53:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:53:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:53:41 --> Pixel_Model class loaded
INFO - 2018-10-09 18:53:41 --> Database Driver Class Initialized
INFO - 2018-10-09 18:53:41 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:53:41 --> Form Validation Class Initialized
INFO - 2018-10-09 18:53:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 18:53:41 --> Database Driver Class Initialized
INFO - 2018-10-09 18:53:41 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:53:41 --> Config Class Initialized
INFO - 2018-10-09 18:53:41 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:53:41 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:53:41 --> Utf8 Class Initialized
INFO - 2018-10-09 18:53:41 --> URI Class Initialized
INFO - 2018-10-09 18:53:41 --> Router Class Initialized
INFO - 2018-10-09 18:53:41 --> Output Class Initialized
INFO - 2018-10-09 18:53:41 --> Security Class Initialized
DEBUG - 2018-10-09 18:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:53:41 --> CSRF cookie sent
INFO - 2018-10-09 18:53:41 --> Input Class Initialized
INFO - 2018-10-09 18:53:41 --> Language Class Initialized
INFO - 2018-10-09 18:53:41 --> Loader Class Initialized
INFO - 2018-10-09 18:53:41 --> Helper loaded: url_helper
INFO - 2018-10-09 18:53:41 --> Helper loaded: form_helper
INFO - 2018-10-09 18:53:41 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:53:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:53:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:53:41 --> User Agent Class Initialized
INFO - 2018-10-09 18:53:41 --> Controller Class Initialized
INFO - 2018-10-09 18:53:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:53:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:53:41 --> Pixel_Model class loaded
INFO - 2018-10-09 18:53:41 --> Database Driver Class Initialized
INFO - 2018-10-09 18:53:41 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:53:41 --> Database Driver Class Initialized
INFO - 2018-10-09 18:53:41 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:53:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 18:53:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 18:53:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 18:53:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 18:53:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 18:53:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 18:53:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/marriage.php
INFO - 2018-10-09 18:53:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 18:53:41 --> Final output sent to browser
DEBUG - 2018-10-09 18:53:41 --> Total execution time: 0.0409
INFO - 2018-10-09 18:53:42 --> Config Class Initialized
INFO - 2018-10-09 18:53:42 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:53:42 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:53:42 --> Utf8 Class Initialized
INFO - 2018-10-09 18:53:42 --> URI Class Initialized
INFO - 2018-10-09 18:53:42 --> Router Class Initialized
INFO - 2018-10-09 18:53:42 --> Output Class Initialized
INFO - 2018-10-09 18:53:42 --> Security Class Initialized
DEBUG - 2018-10-09 18:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:53:42 --> CSRF cookie sent
INFO - 2018-10-09 18:53:42 --> CSRF token verified
INFO - 2018-10-09 18:53:42 --> Input Class Initialized
INFO - 2018-10-09 18:53:42 --> Language Class Initialized
INFO - 2018-10-09 18:53:42 --> Loader Class Initialized
INFO - 2018-10-09 18:53:42 --> Helper loaded: url_helper
INFO - 2018-10-09 18:53:42 --> Helper loaded: form_helper
INFO - 2018-10-09 18:53:42 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:53:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:53:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:53:42 --> User Agent Class Initialized
INFO - 2018-10-09 18:53:42 --> Controller Class Initialized
INFO - 2018-10-09 18:53:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:53:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:53:42 --> Pixel_Model class loaded
INFO - 2018-10-09 18:53:42 --> Database Driver Class Initialized
INFO - 2018-10-09 18:53:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:53:42 --> Form Validation Class Initialized
INFO - 2018-10-09 18:53:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 18:53:42 --> Database Driver Class Initialized
INFO - 2018-10-09 18:53:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:53:42 --> Config Class Initialized
INFO - 2018-10-09 18:53:42 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:53:42 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:53:42 --> Utf8 Class Initialized
INFO - 2018-10-09 18:53:42 --> URI Class Initialized
INFO - 2018-10-09 18:53:42 --> Router Class Initialized
INFO - 2018-10-09 18:53:42 --> Output Class Initialized
INFO - 2018-10-09 18:53:42 --> Security Class Initialized
DEBUG - 2018-10-09 18:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:53:42 --> CSRF cookie sent
INFO - 2018-10-09 18:53:42 --> Input Class Initialized
INFO - 2018-10-09 18:53:42 --> Language Class Initialized
INFO - 2018-10-09 18:53:42 --> Loader Class Initialized
INFO - 2018-10-09 18:53:42 --> Helper loaded: url_helper
INFO - 2018-10-09 18:53:42 --> Helper loaded: form_helper
INFO - 2018-10-09 18:53:42 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:53:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:53:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:53:42 --> User Agent Class Initialized
INFO - 2018-10-09 18:53:42 --> Controller Class Initialized
INFO - 2018-10-09 18:53:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:53:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:53:42 --> Pixel_Model class loaded
INFO - 2018-10-09 18:53:42 --> Database Driver Class Initialized
INFO - 2018-10-09 18:53:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:53:42 --> Database Driver Class Initialized
INFO - 2018-10-09 18:53:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:53:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 18:53:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 18:53:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 18:53:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 18:53:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 18:53:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 18:53:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-10-09 18:53:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 18:53:42 --> Final output sent to browser
DEBUG - 2018-10-09 18:53:42 --> Total execution time: 0.0401
INFO - 2018-10-09 18:53:44 --> Config Class Initialized
INFO - 2018-10-09 18:53:44 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:53:44 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:53:44 --> Utf8 Class Initialized
INFO - 2018-10-09 18:53:44 --> URI Class Initialized
INFO - 2018-10-09 18:53:44 --> Router Class Initialized
INFO - 2018-10-09 18:53:44 --> Output Class Initialized
INFO - 2018-10-09 18:53:44 --> Security Class Initialized
DEBUG - 2018-10-09 18:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:53:44 --> CSRF cookie sent
INFO - 2018-10-09 18:53:44 --> CSRF token verified
INFO - 2018-10-09 18:53:44 --> Input Class Initialized
INFO - 2018-10-09 18:53:44 --> Language Class Initialized
INFO - 2018-10-09 18:53:44 --> Loader Class Initialized
INFO - 2018-10-09 18:53:44 --> Helper loaded: url_helper
INFO - 2018-10-09 18:53:44 --> Helper loaded: form_helper
INFO - 2018-10-09 18:53:44 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:53:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:53:44 --> User Agent Class Initialized
INFO - 2018-10-09 18:53:44 --> Controller Class Initialized
INFO - 2018-10-09 18:53:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:53:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:53:44 --> Pixel_Model class loaded
INFO - 2018-10-09 18:53:44 --> Database Driver Class Initialized
INFO - 2018-10-09 18:53:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:53:44 --> Form Validation Class Initialized
INFO - 2018-10-09 18:53:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 18:53:44 --> Database Driver Class Initialized
INFO - 2018-10-09 18:53:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:53:44 --> Config Class Initialized
INFO - 2018-10-09 18:53:44 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:53:44 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:53:44 --> Utf8 Class Initialized
INFO - 2018-10-09 18:53:44 --> URI Class Initialized
INFO - 2018-10-09 18:53:44 --> Router Class Initialized
INFO - 2018-10-09 18:53:44 --> Output Class Initialized
INFO - 2018-10-09 18:53:44 --> Security Class Initialized
DEBUG - 2018-10-09 18:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:53:44 --> CSRF cookie sent
INFO - 2018-10-09 18:53:44 --> Input Class Initialized
INFO - 2018-10-09 18:53:44 --> Language Class Initialized
INFO - 2018-10-09 18:53:44 --> Loader Class Initialized
INFO - 2018-10-09 18:53:44 --> Helper loaded: url_helper
INFO - 2018-10-09 18:53:44 --> Helper loaded: form_helper
INFO - 2018-10-09 18:53:44 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:53:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:53:44 --> User Agent Class Initialized
INFO - 2018-10-09 18:53:44 --> Controller Class Initialized
INFO - 2018-10-09 18:53:44 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:53:44 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:53:44 --> Pixel_Model class loaded
INFO - 2018-10-09 18:53:44 --> Database Driver Class Initialized
INFO - 2018-10-09 18:53:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:53:44 --> Database Driver Class Initialized
INFO - 2018-10-09 18:53:44 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:53:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 18:53:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 18:53:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 18:53:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 18:53:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 18:53:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 18:53:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-10-09 18:53:44 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 18:53:44 --> Final output sent to browser
DEBUG - 2018-10-09 18:53:44 --> Total execution time: 0.0435
INFO - 2018-10-09 18:54:04 --> Config Class Initialized
INFO - 2018-10-09 18:54:04 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:54:04 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:54:04 --> Utf8 Class Initialized
INFO - 2018-10-09 18:54:04 --> URI Class Initialized
INFO - 2018-10-09 18:54:04 --> Router Class Initialized
INFO - 2018-10-09 18:54:04 --> Output Class Initialized
INFO - 2018-10-09 18:54:04 --> Security Class Initialized
DEBUG - 2018-10-09 18:54:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:54:04 --> CSRF cookie sent
INFO - 2018-10-09 18:54:04 --> CSRF token verified
INFO - 2018-10-09 18:54:04 --> Input Class Initialized
INFO - 2018-10-09 18:54:04 --> Language Class Initialized
INFO - 2018-10-09 18:54:04 --> Loader Class Initialized
INFO - 2018-10-09 18:54:04 --> Helper loaded: url_helper
INFO - 2018-10-09 18:54:04 --> Helper loaded: form_helper
INFO - 2018-10-09 18:54:04 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:54:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:54:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:54:04 --> User Agent Class Initialized
INFO - 2018-10-09 18:54:04 --> Controller Class Initialized
INFO - 2018-10-09 18:54:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:54:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:54:04 --> Pixel_Model class loaded
INFO - 2018-10-09 18:54:04 --> Database Driver Class Initialized
INFO - 2018-10-09 18:54:04 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:54:04 --> Form Validation Class Initialized
INFO - 2018-10-09 18:54:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 18:54:04 --> Database Driver Class Initialized
INFO - 2018-10-09 18:54:04 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:54:04 --> Config Class Initialized
INFO - 2018-10-09 18:54:04 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:54:04 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:54:04 --> Utf8 Class Initialized
INFO - 2018-10-09 18:54:04 --> URI Class Initialized
INFO - 2018-10-09 18:54:04 --> Router Class Initialized
INFO - 2018-10-09 18:54:04 --> Output Class Initialized
INFO - 2018-10-09 18:54:04 --> Security Class Initialized
DEBUG - 2018-10-09 18:54:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:54:04 --> CSRF cookie sent
INFO - 2018-10-09 18:54:04 --> Input Class Initialized
INFO - 2018-10-09 18:54:04 --> Language Class Initialized
INFO - 2018-10-09 18:54:04 --> Loader Class Initialized
INFO - 2018-10-09 18:54:04 --> Helper loaded: url_helper
INFO - 2018-10-09 18:54:04 --> Helper loaded: form_helper
INFO - 2018-10-09 18:54:04 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:54:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:54:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:54:04 --> User Agent Class Initialized
INFO - 2018-10-09 18:54:04 --> Controller Class Initialized
INFO - 2018-10-09 18:54:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:54:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:54:04 --> Pixel_Model class loaded
INFO - 2018-10-09 18:54:04 --> Database Driver Class Initialized
INFO - 2018-10-09 18:54:04 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:54:04 --> Database Driver Class Initialized
INFO - 2018-10-09 18:54:04 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:54:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 18:54:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 18:54:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 18:54:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 18:54:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 18:54:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 18:54:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-10-09 18:54:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 18:54:04 --> Final output sent to browser
DEBUG - 2018-10-09 18:54:04 --> Total execution time: 0.0462
INFO - 2018-10-09 18:54:06 --> Config Class Initialized
INFO - 2018-10-09 18:54:06 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:54:06 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:54:06 --> Utf8 Class Initialized
INFO - 2018-10-09 18:54:06 --> URI Class Initialized
INFO - 2018-10-09 18:54:06 --> Router Class Initialized
INFO - 2018-10-09 18:54:06 --> Output Class Initialized
INFO - 2018-10-09 18:54:06 --> Security Class Initialized
DEBUG - 2018-10-09 18:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:54:06 --> CSRF cookie sent
INFO - 2018-10-09 18:54:06 --> CSRF token verified
INFO - 2018-10-09 18:54:06 --> Input Class Initialized
INFO - 2018-10-09 18:54:06 --> Language Class Initialized
INFO - 2018-10-09 18:54:06 --> Loader Class Initialized
INFO - 2018-10-09 18:54:06 --> Helper loaded: url_helper
INFO - 2018-10-09 18:54:06 --> Helper loaded: form_helper
INFO - 2018-10-09 18:54:06 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:54:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:54:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:54:06 --> User Agent Class Initialized
INFO - 2018-10-09 18:54:06 --> Controller Class Initialized
INFO - 2018-10-09 18:54:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:54:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:54:06 --> Pixel_Model class loaded
INFO - 2018-10-09 18:54:06 --> Database Driver Class Initialized
INFO - 2018-10-09 18:54:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:54:06 --> Form Validation Class Initialized
INFO - 2018-10-09 18:54:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 18:54:06 --> Database Driver Class Initialized
INFO - 2018-10-09 18:54:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:54:06 --> Config Class Initialized
INFO - 2018-10-09 18:54:06 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:54:06 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:54:06 --> Utf8 Class Initialized
INFO - 2018-10-09 18:54:06 --> URI Class Initialized
INFO - 2018-10-09 18:54:06 --> Router Class Initialized
INFO - 2018-10-09 18:54:06 --> Output Class Initialized
INFO - 2018-10-09 18:54:06 --> Security Class Initialized
DEBUG - 2018-10-09 18:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:54:06 --> CSRF cookie sent
INFO - 2018-10-09 18:54:06 --> Input Class Initialized
INFO - 2018-10-09 18:54:06 --> Language Class Initialized
INFO - 2018-10-09 18:54:06 --> Loader Class Initialized
INFO - 2018-10-09 18:54:06 --> Helper loaded: url_helper
INFO - 2018-10-09 18:54:06 --> Helper loaded: form_helper
INFO - 2018-10-09 18:54:06 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:54:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:54:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:54:06 --> User Agent Class Initialized
INFO - 2018-10-09 18:54:06 --> Controller Class Initialized
INFO - 2018-10-09 18:54:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:54:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:54:06 --> Pixel_Model class loaded
INFO - 2018-10-09 18:54:06 --> Database Driver Class Initialized
INFO - 2018-10-09 18:54:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:54:06 --> Database Driver Class Initialized
INFO - 2018-10-09 18:54:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:54:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 18:54:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 18:54:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 18:54:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 18:54:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 18:54:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 18:54:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-10-09 18:54:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 18:54:06 --> Final output sent to browser
DEBUG - 2018-10-09 18:54:06 --> Total execution time: 0.0468
INFO - 2018-10-09 18:54:07 --> Config Class Initialized
INFO - 2018-10-09 18:54:07 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:54:07 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:54:07 --> Utf8 Class Initialized
INFO - 2018-10-09 18:54:07 --> URI Class Initialized
INFO - 2018-10-09 18:54:07 --> Router Class Initialized
INFO - 2018-10-09 18:54:07 --> Output Class Initialized
INFO - 2018-10-09 18:54:07 --> Security Class Initialized
DEBUG - 2018-10-09 18:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:54:07 --> CSRF cookie sent
INFO - 2018-10-09 18:54:07 --> CSRF token verified
INFO - 2018-10-09 18:54:07 --> Input Class Initialized
INFO - 2018-10-09 18:54:07 --> Language Class Initialized
INFO - 2018-10-09 18:54:07 --> Loader Class Initialized
INFO - 2018-10-09 18:54:07 --> Helper loaded: url_helper
INFO - 2018-10-09 18:54:07 --> Helper loaded: form_helper
INFO - 2018-10-09 18:54:07 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:54:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:54:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:54:07 --> User Agent Class Initialized
INFO - 2018-10-09 18:54:07 --> Controller Class Initialized
INFO - 2018-10-09 18:54:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:54:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:54:07 --> Pixel_Model class loaded
INFO - 2018-10-09 18:54:07 --> Database Driver Class Initialized
INFO - 2018-10-09 18:54:07 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:54:07 --> Form Validation Class Initialized
INFO - 2018-10-09 18:54:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 18:54:07 --> Database Driver Class Initialized
INFO - 2018-10-09 18:54:07 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:54:07 --> Config Class Initialized
INFO - 2018-10-09 18:54:07 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:54:07 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:54:07 --> Utf8 Class Initialized
INFO - 2018-10-09 18:54:07 --> URI Class Initialized
INFO - 2018-10-09 18:54:07 --> Router Class Initialized
INFO - 2018-10-09 18:54:07 --> Output Class Initialized
INFO - 2018-10-09 18:54:07 --> Security Class Initialized
DEBUG - 2018-10-09 18:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:54:07 --> CSRF cookie sent
INFO - 2018-10-09 18:54:07 --> Input Class Initialized
INFO - 2018-10-09 18:54:07 --> Language Class Initialized
INFO - 2018-10-09 18:54:08 --> Loader Class Initialized
INFO - 2018-10-09 18:54:08 --> Helper loaded: url_helper
INFO - 2018-10-09 18:54:08 --> Helper loaded: form_helper
INFO - 2018-10-09 18:54:08 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:54:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:54:08 --> User Agent Class Initialized
INFO - 2018-10-09 18:54:08 --> Controller Class Initialized
INFO - 2018-10-09 18:54:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:54:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:54:08 --> Pixel_Model class loaded
INFO - 2018-10-09 18:54:08 --> Database Driver Class Initialized
INFO - 2018-10-09 18:54:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:54:08 --> Database Driver Class Initialized
INFO - 2018-10-09 18:54:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:54:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 18:54:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 18:54:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 18:54:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 18:54:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 18:54:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 18:54:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_owner.php
INFO - 2018-10-09 18:54:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 18:54:08 --> Final output sent to browser
DEBUG - 2018-10-09 18:54:08 --> Total execution time: 0.0450
INFO - 2018-10-09 18:54:09 --> Config Class Initialized
INFO - 2018-10-09 18:54:09 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:54:09 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:54:09 --> Utf8 Class Initialized
INFO - 2018-10-09 18:54:09 --> URI Class Initialized
INFO - 2018-10-09 18:54:09 --> Router Class Initialized
INFO - 2018-10-09 18:54:09 --> Output Class Initialized
INFO - 2018-10-09 18:54:09 --> Security Class Initialized
DEBUG - 2018-10-09 18:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:54:09 --> CSRF cookie sent
INFO - 2018-10-09 18:54:09 --> CSRF token verified
INFO - 2018-10-09 18:54:09 --> Input Class Initialized
INFO - 2018-10-09 18:54:09 --> Language Class Initialized
INFO - 2018-10-09 18:54:09 --> Loader Class Initialized
INFO - 2018-10-09 18:54:09 --> Helper loaded: url_helper
INFO - 2018-10-09 18:54:09 --> Helper loaded: form_helper
INFO - 2018-10-09 18:54:09 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:54:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:54:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:54:09 --> User Agent Class Initialized
INFO - 2018-10-09 18:54:09 --> Controller Class Initialized
INFO - 2018-10-09 18:54:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:54:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:54:09 --> Pixel_Model class loaded
INFO - 2018-10-09 18:54:09 --> Database Driver Class Initialized
INFO - 2018-10-09 18:54:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:54:09 --> Form Validation Class Initialized
INFO - 2018-10-09 18:54:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 18:54:09 --> Database Driver Class Initialized
INFO - 2018-10-09 18:54:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:54:09 --> Config Class Initialized
INFO - 2018-10-09 18:54:09 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:54:09 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:54:09 --> Utf8 Class Initialized
INFO - 2018-10-09 18:54:09 --> URI Class Initialized
INFO - 2018-10-09 18:54:09 --> Router Class Initialized
INFO - 2018-10-09 18:54:09 --> Output Class Initialized
INFO - 2018-10-09 18:54:09 --> Security Class Initialized
DEBUG - 2018-10-09 18:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:54:09 --> CSRF cookie sent
INFO - 2018-10-09 18:54:09 --> Input Class Initialized
INFO - 2018-10-09 18:54:09 --> Language Class Initialized
INFO - 2018-10-09 18:54:09 --> Loader Class Initialized
INFO - 2018-10-09 18:54:09 --> Helper loaded: url_helper
INFO - 2018-10-09 18:54:09 --> Helper loaded: form_helper
INFO - 2018-10-09 18:54:09 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:54:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:54:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:54:09 --> User Agent Class Initialized
INFO - 2018-10-09 18:54:09 --> Controller Class Initialized
INFO - 2018-10-09 18:54:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:54:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:54:09 --> Pixel_Model class loaded
INFO - 2018-10-09 18:54:09 --> Database Driver Class Initialized
INFO - 2018-10-09 18:54:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:54:09 --> Database Driver Class Initialized
INFO - 2018-10-09 18:54:09 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:54:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 18:54:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 18:54:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 18:54:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 18:54:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 18:54:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 18:54:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_value.php
INFO - 2018-10-09 18:54:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 18:54:09 --> Final output sent to browser
DEBUG - 2018-10-09 18:54:09 --> Total execution time: 0.0537
INFO - 2018-10-09 18:54:15 --> Config Class Initialized
INFO - 2018-10-09 18:54:15 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:54:15 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:54:15 --> Utf8 Class Initialized
INFO - 2018-10-09 18:54:15 --> URI Class Initialized
INFO - 2018-10-09 18:54:15 --> Router Class Initialized
INFO - 2018-10-09 18:54:15 --> Output Class Initialized
INFO - 2018-10-09 18:54:15 --> Security Class Initialized
DEBUG - 2018-10-09 18:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:54:15 --> CSRF cookie sent
INFO - 2018-10-09 18:54:15 --> Input Class Initialized
INFO - 2018-10-09 18:54:15 --> Language Class Initialized
INFO - 2018-10-09 18:54:15 --> Loader Class Initialized
INFO - 2018-10-09 18:54:15 --> Helper loaded: url_helper
INFO - 2018-10-09 18:54:15 --> Helper loaded: form_helper
INFO - 2018-10-09 18:54:15 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:54:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:54:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:54:15 --> User Agent Class Initialized
INFO - 2018-10-09 18:54:15 --> Controller Class Initialized
INFO - 2018-10-09 18:54:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:54:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:54:15 --> Pixel_Model class loaded
INFO - 2018-10-09 18:54:15 --> Database Driver Class Initialized
INFO - 2018-10-09 18:54:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:54:15 --> Database Driver Class Initialized
INFO - 2018-10-09 18:54:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:54:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 18:54:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 18:54:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 18:54:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 18:54:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 18:54:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 18:54:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_owner.php
INFO - 2018-10-09 18:54:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 18:54:15 --> Final output sent to browser
DEBUG - 2018-10-09 18:54:15 --> Total execution time: 0.0470
INFO - 2018-10-09 18:54:16 --> Config Class Initialized
INFO - 2018-10-09 18:54:16 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:54:16 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:54:16 --> Utf8 Class Initialized
INFO - 2018-10-09 18:54:16 --> URI Class Initialized
INFO - 2018-10-09 18:54:16 --> Router Class Initialized
INFO - 2018-10-09 18:54:16 --> Output Class Initialized
INFO - 2018-10-09 18:54:16 --> Security Class Initialized
DEBUG - 2018-10-09 18:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:54:16 --> CSRF cookie sent
INFO - 2018-10-09 18:54:16 --> Input Class Initialized
INFO - 2018-10-09 18:54:16 --> Language Class Initialized
INFO - 2018-10-09 18:54:16 --> Loader Class Initialized
INFO - 2018-10-09 18:54:16 --> Helper loaded: url_helper
INFO - 2018-10-09 18:54:16 --> Helper loaded: form_helper
INFO - 2018-10-09 18:54:16 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:54:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:54:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:54:16 --> User Agent Class Initialized
INFO - 2018-10-09 18:54:16 --> Controller Class Initialized
INFO - 2018-10-09 18:54:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:54:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:54:16 --> Pixel_Model class loaded
INFO - 2018-10-09 18:54:16 --> Database Driver Class Initialized
INFO - 2018-10-09 18:54:16 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:54:16 --> Database Driver Class Initialized
INFO - 2018-10-09 18:54:16 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:54:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 18:54:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 18:54:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 18:54:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 18:54:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 18:54:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 18:54:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-10-09 18:54:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 18:54:16 --> Final output sent to browser
DEBUG - 2018-10-09 18:54:16 --> Total execution time: 0.0716
INFO - 2018-10-09 18:54:17 --> Config Class Initialized
INFO - 2018-10-09 18:54:17 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:54:17 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:54:17 --> Utf8 Class Initialized
INFO - 2018-10-09 18:54:17 --> URI Class Initialized
INFO - 2018-10-09 18:54:17 --> Router Class Initialized
INFO - 2018-10-09 18:54:17 --> Output Class Initialized
INFO - 2018-10-09 18:54:17 --> Security Class Initialized
DEBUG - 2018-10-09 18:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:54:17 --> CSRF cookie sent
INFO - 2018-10-09 18:54:17 --> Input Class Initialized
INFO - 2018-10-09 18:54:17 --> Language Class Initialized
INFO - 2018-10-09 18:54:17 --> Loader Class Initialized
INFO - 2018-10-09 18:54:17 --> Helper loaded: url_helper
INFO - 2018-10-09 18:54:17 --> Helper loaded: form_helper
INFO - 2018-10-09 18:54:17 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:54:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:54:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:54:17 --> User Agent Class Initialized
INFO - 2018-10-09 18:54:17 --> Controller Class Initialized
INFO - 2018-10-09 18:54:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:54:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:54:18 --> Pixel_Model class loaded
INFO - 2018-10-09 18:54:18 --> Database Driver Class Initialized
INFO - 2018-10-09 18:54:18 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:54:18 --> Database Driver Class Initialized
INFO - 2018-10-09 18:54:18 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:54:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 18:54:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 18:54:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 18:54:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 18:54:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 18:54:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 18:54:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-10-09 18:54:18 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 18:54:18 --> Final output sent to browser
DEBUG - 2018-10-09 18:54:18 --> Total execution time: 0.0454
INFO - 2018-10-09 18:54:19 --> Config Class Initialized
INFO - 2018-10-09 18:54:19 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:54:19 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:54:19 --> Utf8 Class Initialized
INFO - 2018-10-09 18:54:19 --> URI Class Initialized
INFO - 2018-10-09 18:54:19 --> Router Class Initialized
INFO - 2018-10-09 18:54:19 --> Output Class Initialized
INFO - 2018-10-09 18:54:19 --> Security Class Initialized
DEBUG - 2018-10-09 18:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:54:19 --> CSRF cookie sent
INFO - 2018-10-09 18:54:19 --> Input Class Initialized
INFO - 2018-10-09 18:54:19 --> Language Class Initialized
INFO - 2018-10-09 18:54:19 --> Loader Class Initialized
INFO - 2018-10-09 18:54:19 --> Helper loaded: url_helper
INFO - 2018-10-09 18:54:19 --> Helper loaded: form_helper
INFO - 2018-10-09 18:54:19 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:54:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:54:19 --> User Agent Class Initialized
INFO - 2018-10-09 18:54:19 --> Controller Class Initialized
INFO - 2018-10-09 18:54:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:54:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:54:19 --> Pixel_Model class loaded
INFO - 2018-10-09 18:54:19 --> Database Driver Class Initialized
INFO - 2018-10-09 18:54:19 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:54:19 --> Database Driver Class Initialized
INFO - 2018-10-09 18:54:19 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:54:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 18:54:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 18:54:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 18:54:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 18:54:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 18:54:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 18:54:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-10-09 18:54:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 18:54:19 --> Final output sent to browser
DEBUG - 2018-10-09 18:54:19 --> Total execution time: 0.0562
INFO - 2018-10-09 18:54:24 --> Config Class Initialized
INFO - 2018-10-09 18:54:24 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:54:24 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:54:24 --> Utf8 Class Initialized
INFO - 2018-10-09 18:54:24 --> URI Class Initialized
INFO - 2018-10-09 18:54:24 --> Router Class Initialized
INFO - 2018-10-09 18:54:24 --> Output Class Initialized
INFO - 2018-10-09 18:54:24 --> Security Class Initialized
DEBUG - 2018-10-09 18:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:54:24 --> CSRF cookie sent
INFO - 2018-10-09 18:54:24 --> Input Class Initialized
INFO - 2018-10-09 18:54:24 --> Language Class Initialized
INFO - 2018-10-09 18:54:24 --> Loader Class Initialized
INFO - 2018-10-09 18:54:24 --> Helper loaded: url_helper
INFO - 2018-10-09 18:54:24 --> Helper loaded: form_helper
INFO - 2018-10-09 18:54:24 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:54:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:54:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:54:24 --> User Agent Class Initialized
INFO - 2018-10-09 18:54:24 --> Controller Class Initialized
INFO - 2018-10-09 18:54:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:54:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:54:24 --> Pixel_Model class loaded
INFO - 2018-10-09 18:54:24 --> Database Driver Class Initialized
INFO - 2018-10-09 18:54:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:54:24 --> Database Driver Class Initialized
INFO - 2018-10-09 18:54:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:54:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 18:54:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 18:54:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 18:54:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 18:54:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 18:54:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 18:54:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-10-09 18:54:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 18:54:24 --> Final output sent to browser
DEBUG - 2018-10-09 18:54:24 --> Total execution time: 0.0550
INFO - 2018-10-09 18:54:29 --> Config Class Initialized
INFO - 2018-10-09 18:54:29 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:54:29 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:54:29 --> Utf8 Class Initialized
INFO - 2018-10-09 18:54:29 --> URI Class Initialized
INFO - 2018-10-09 18:54:29 --> Router Class Initialized
INFO - 2018-10-09 18:54:29 --> Output Class Initialized
INFO - 2018-10-09 18:54:29 --> Security Class Initialized
DEBUG - 2018-10-09 18:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:54:29 --> CSRF cookie sent
INFO - 2018-10-09 18:54:29 --> CSRF token verified
INFO - 2018-10-09 18:54:29 --> Input Class Initialized
INFO - 2018-10-09 18:54:29 --> Language Class Initialized
INFO - 2018-10-09 18:54:29 --> Loader Class Initialized
INFO - 2018-10-09 18:54:29 --> Helper loaded: url_helper
INFO - 2018-10-09 18:54:29 --> Helper loaded: form_helper
INFO - 2018-10-09 18:54:29 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:54:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:54:29 --> User Agent Class Initialized
INFO - 2018-10-09 18:54:29 --> Controller Class Initialized
INFO - 2018-10-09 18:54:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:54:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:54:29 --> Pixel_Model class loaded
INFO - 2018-10-09 18:54:29 --> Database Driver Class Initialized
INFO - 2018-10-09 18:54:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:54:29 --> Form Validation Class Initialized
INFO - 2018-10-09 18:54:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 18:54:29 --> Database Driver Class Initialized
INFO - 2018-10-09 18:54:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:54:29 --> Config Class Initialized
INFO - 2018-10-09 18:54:29 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:54:29 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:54:29 --> Utf8 Class Initialized
INFO - 2018-10-09 18:54:29 --> URI Class Initialized
INFO - 2018-10-09 18:54:29 --> Router Class Initialized
INFO - 2018-10-09 18:54:29 --> Output Class Initialized
INFO - 2018-10-09 18:54:29 --> Security Class Initialized
DEBUG - 2018-10-09 18:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:54:29 --> CSRF cookie sent
INFO - 2018-10-09 18:54:29 --> Input Class Initialized
INFO - 2018-10-09 18:54:29 --> Language Class Initialized
INFO - 2018-10-09 18:54:29 --> Loader Class Initialized
INFO - 2018-10-09 18:54:29 --> Helper loaded: url_helper
INFO - 2018-10-09 18:54:29 --> Helper loaded: form_helper
INFO - 2018-10-09 18:54:29 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:54:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:54:29 --> User Agent Class Initialized
INFO - 2018-10-09 18:54:29 --> Controller Class Initialized
INFO - 2018-10-09 18:54:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:54:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:54:29 --> Pixel_Model class loaded
INFO - 2018-10-09 18:54:29 --> Database Driver Class Initialized
INFO - 2018-10-09 18:54:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:54:29 --> Database Driver Class Initialized
INFO - 2018-10-09 18:54:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:54:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 18:54:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 18:54:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 18:54:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 18:54:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 18:54:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 18:54:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-10-09 18:54:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 18:54:29 --> Final output sent to browser
DEBUG - 2018-10-09 18:54:29 --> Total execution time: 0.0442
INFO - 2018-10-09 18:54:34 --> Config Class Initialized
INFO - 2018-10-09 18:54:34 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:54:34 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:54:34 --> Utf8 Class Initialized
INFO - 2018-10-09 18:54:34 --> URI Class Initialized
INFO - 2018-10-09 18:54:34 --> Router Class Initialized
INFO - 2018-10-09 18:54:34 --> Output Class Initialized
INFO - 2018-10-09 18:54:34 --> Security Class Initialized
DEBUG - 2018-10-09 18:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:54:34 --> CSRF cookie sent
INFO - 2018-10-09 18:54:34 --> CSRF token verified
INFO - 2018-10-09 18:54:34 --> Input Class Initialized
INFO - 2018-10-09 18:54:34 --> Language Class Initialized
INFO - 2018-10-09 18:54:34 --> Loader Class Initialized
INFO - 2018-10-09 18:54:34 --> Helper loaded: url_helper
INFO - 2018-10-09 18:54:34 --> Helper loaded: form_helper
INFO - 2018-10-09 18:54:34 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:54:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:54:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:54:34 --> User Agent Class Initialized
INFO - 2018-10-09 18:54:34 --> Controller Class Initialized
INFO - 2018-10-09 18:54:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:54:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:54:34 --> Pixel_Model class loaded
INFO - 2018-10-09 18:54:34 --> Database Driver Class Initialized
INFO - 2018-10-09 18:54:34 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:54:34 --> Form Validation Class Initialized
INFO - 2018-10-09 18:54:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 18:54:34 --> Database Driver Class Initialized
INFO - 2018-10-09 18:54:34 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:54:34 --> Config Class Initialized
INFO - 2018-10-09 18:54:34 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:54:34 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:54:34 --> Utf8 Class Initialized
INFO - 2018-10-09 18:54:34 --> URI Class Initialized
INFO - 2018-10-09 18:54:34 --> Router Class Initialized
INFO - 2018-10-09 18:54:34 --> Output Class Initialized
INFO - 2018-10-09 18:54:34 --> Security Class Initialized
DEBUG - 2018-10-09 18:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:54:34 --> CSRF cookie sent
INFO - 2018-10-09 18:54:34 --> Input Class Initialized
INFO - 2018-10-09 18:54:34 --> Language Class Initialized
INFO - 2018-10-09 18:54:34 --> Loader Class Initialized
INFO - 2018-10-09 18:54:34 --> Helper loaded: url_helper
INFO - 2018-10-09 18:54:34 --> Helper loaded: form_helper
INFO - 2018-10-09 18:54:34 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:54:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:54:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:54:34 --> User Agent Class Initialized
INFO - 2018-10-09 18:54:34 --> Controller Class Initialized
INFO - 2018-10-09 18:54:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:54:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:54:34 --> Pixel_Model class loaded
INFO - 2018-10-09 18:54:34 --> Database Driver Class Initialized
INFO - 2018-10-09 18:54:34 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:54:34 --> Database Driver Class Initialized
INFO - 2018-10-09 18:54:34 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:54:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 18:54:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 18:54:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 18:54:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 18:54:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 18:54:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 18:54:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-10-09 18:54:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 18:54:34 --> Final output sent to browser
DEBUG - 2018-10-09 18:54:34 --> Total execution time: 0.0461
INFO - 2018-10-09 18:54:35 --> Config Class Initialized
INFO - 2018-10-09 18:54:35 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:54:35 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:54:35 --> Utf8 Class Initialized
INFO - 2018-10-09 18:54:35 --> URI Class Initialized
INFO - 2018-10-09 18:54:35 --> Router Class Initialized
INFO - 2018-10-09 18:54:35 --> Output Class Initialized
INFO - 2018-10-09 18:54:35 --> Security Class Initialized
DEBUG - 2018-10-09 18:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:54:35 --> CSRF cookie sent
INFO - 2018-10-09 18:54:35 --> CSRF token verified
INFO - 2018-10-09 18:54:35 --> Input Class Initialized
INFO - 2018-10-09 18:54:35 --> Language Class Initialized
INFO - 2018-10-09 18:54:35 --> Loader Class Initialized
INFO - 2018-10-09 18:54:35 --> Helper loaded: url_helper
INFO - 2018-10-09 18:54:35 --> Helper loaded: form_helper
INFO - 2018-10-09 18:54:35 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:54:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:54:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:54:35 --> User Agent Class Initialized
INFO - 2018-10-09 18:54:35 --> Controller Class Initialized
INFO - 2018-10-09 18:54:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:54:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:54:35 --> Pixel_Model class loaded
INFO - 2018-10-09 18:54:35 --> Database Driver Class Initialized
INFO - 2018-10-09 18:54:35 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:54:35 --> Form Validation Class Initialized
INFO - 2018-10-09 18:54:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 18:54:35 --> Database Driver Class Initialized
INFO - 2018-10-09 18:54:35 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:54:35 --> Config Class Initialized
INFO - 2018-10-09 18:54:35 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:54:35 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:54:35 --> Utf8 Class Initialized
INFO - 2018-10-09 18:54:35 --> URI Class Initialized
INFO - 2018-10-09 18:54:35 --> Router Class Initialized
INFO - 2018-10-09 18:54:35 --> Output Class Initialized
INFO - 2018-10-09 18:54:35 --> Security Class Initialized
DEBUG - 2018-10-09 18:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:54:35 --> CSRF cookie sent
INFO - 2018-10-09 18:54:35 --> Input Class Initialized
INFO - 2018-10-09 18:54:35 --> Language Class Initialized
INFO - 2018-10-09 18:54:35 --> Loader Class Initialized
INFO - 2018-10-09 18:54:35 --> Helper loaded: url_helper
INFO - 2018-10-09 18:54:35 --> Helper loaded: form_helper
INFO - 2018-10-09 18:54:35 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:54:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:54:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:54:35 --> User Agent Class Initialized
INFO - 2018-10-09 18:54:35 --> Controller Class Initialized
INFO - 2018-10-09 18:54:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:54:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:54:35 --> Pixel_Model class loaded
INFO - 2018-10-09 18:54:35 --> Database Driver Class Initialized
INFO - 2018-10-09 18:54:35 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:54:35 --> Database Driver Class Initialized
INFO - 2018-10-09 18:54:35 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:54:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 18:54:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 18:54:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 18:54:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 18:54:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 18:54:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 18:54:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-10-09 18:54:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 18:54:35 --> Final output sent to browser
DEBUG - 2018-10-09 18:54:35 --> Total execution time: 0.0491
INFO - 2018-10-09 18:54:37 --> Config Class Initialized
INFO - 2018-10-09 18:54:37 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:54:37 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:54:37 --> Utf8 Class Initialized
INFO - 2018-10-09 18:54:37 --> URI Class Initialized
INFO - 2018-10-09 18:54:37 --> Router Class Initialized
INFO - 2018-10-09 18:54:37 --> Output Class Initialized
INFO - 2018-10-09 18:54:37 --> Security Class Initialized
DEBUG - 2018-10-09 18:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:54:37 --> CSRF cookie sent
INFO - 2018-10-09 18:54:37 --> CSRF token verified
INFO - 2018-10-09 18:54:37 --> Input Class Initialized
INFO - 2018-10-09 18:54:37 --> Language Class Initialized
INFO - 2018-10-09 18:54:37 --> Loader Class Initialized
INFO - 2018-10-09 18:54:37 --> Helper loaded: url_helper
INFO - 2018-10-09 18:54:37 --> Helper loaded: form_helper
INFO - 2018-10-09 18:54:37 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:54:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:54:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:54:37 --> User Agent Class Initialized
INFO - 2018-10-09 18:54:37 --> Controller Class Initialized
INFO - 2018-10-09 18:54:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:54:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:54:37 --> Pixel_Model class loaded
INFO - 2018-10-09 18:54:37 --> Database Driver Class Initialized
INFO - 2018-10-09 18:54:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:54:37 --> Form Validation Class Initialized
INFO - 2018-10-09 18:54:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 18:54:37 --> Database Driver Class Initialized
INFO - 2018-10-09 18:54:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:54:37 --> Config Class Initialized
INFO - 2018-10-09 18:54:37 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:54:37 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:54:37 --> Utf8 Class Initialized
INFO - 2018-10-09 18:54:37 --> URI Class Initialized
INFO - 2018-10-09 18:54:37 --> Router Class Initialized
INFO - 2018-10-09 18:54:37 --> Output Class Initialized
INFO - 2018-10-09 18:54:37 --> Security Class Initialized
DEBUG - 2018-10-09 18:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:54:37 --> CSRF cookie sent
INFO - 2018-10-09 18:54:37 --> Input Class Initialized
INFO - 2018-10-09 18:54:37 --> Language Class Initialized
INFO - 2018-10-09 18:54:37 --> Loader Class Initialized
INFO - 2018-10-09 18:54:37 --> Helper loaded: url_helper
INFO - 2018-10-09 18:54:37 --> Helper loaded: form_helper
INFO - 2018-10-09 18:54:37 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:54:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:54:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:54:37 --> User Agent Class Initialized
INFO - 2018-10-09 18:54:37 --> Controller Class Initialized
INFO - 2018-10-09 18:54:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:54:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:54:37 --> Pixel_Model class loaded
INFO - 2018-10-09 18:54:37 --> Database Driver Class Initialized
INFO - 2018-10-09 18:54:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:54:37 --> Database Driver Class Initialized
INFO - 2018-10-09 18:54:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:54:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 18:54:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 18:54:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 18:54:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 18:54:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 18:54:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 18:54:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_owner.php
INFO - 2018-10-09 18:54:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 18:54:37 --> Final output sent to browser
DEBUG - 2018-10-09 18:54:37 --> Total execution time: 0.0550
INFO - 2018-10-09 18:54:38 --> Config Class Initialized
INFO - 2018-10-09 18:54:38 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:54:38 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:54:38 --> Utf8 Class Initialized
INFO - 2018-10-09 18:54:38 --> URI Class Initialized
INFO - 2018-10-09 18:54:38 --> Router Class Initialized
INFO - 2018-10-09 18:54:38 --> Output Class Initialized
INFO - 2018-10-09 18:54:38 --> Security Class Initialized
DEBUG - 2018-10-09 18:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:54:38 --> CSRF cookie sent
INFO - 2018-10-09 18:54:38 --> CSRF token verified
INFO - 2018-10-09 18:54:38 --> Input Class Initialized
INFO - 2018-10-09 18:54:38 --> Language Class Initialized
INFO - 2018-10-09 18:54:38 --> Loader Class Initialized
INFO - 2018-10-09 18:54:38 --> Helper loaded: url_helper
INFO - 2018-10-09 18:54:38 --> Helper loaded: form_helper
INFO - 2018-10-09 18:54:38 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:54:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:54:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:54:38 --> User Agent Class Initialized
INFO - 2018-10-09 18:54:38 --> Controller Class Initialized
INFO - 2018-10-09 18:54:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:54:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:54:38 --> Pixel_Model class loaded
INFO - 2018-10-09 18:54:38 --> Database Driver Class Initialized
INFO - 2018-10-09 18:54:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:54:38 --> Form Validation Class Initialized
INFO - 2018-10-09 18:54:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 18:54:38 --> Database Driver Class Initialized
INFO - 2018-10-09 18:54:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:54:38 --> Config Class Initialized
INFO - 2018-10-09 18:54:38 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:54:38 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:54:38 --> Utf8 Class Initialized
INFO - 2018-10-09 18:54:38 --> URI Class Initialized
INFO - 2018-10-09 18:54:38 --> Router Class Initialized
INFO - 2018-10-09 18:54:38 --> Output Class Initialized
INFO - 2018-10-09 18:54:38 --> Security Class Initialized
DEBUG - 2018-10-09 18:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:54:38 --> CSRF cookie sent
INFO - 2018-10-09 18:54:38 --> Input Class Initialized
INFO - 2018-10-09 18:54:38 --> Language Class Initialized
INFO - 2018-10-09 18:54:38 --> Loader Class Initialized
INFO - 2018-10-09 18:54:38 --> Helper loaded: url_helper
INFO - 2018-10-09 18:54:38 --> Helper loaded: form_helper
INFO - 2018-10-09 18:54:38 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:54:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:54:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:54:38 --> User Agent Class Initialized
INFO - 2018-10-09 18:54:38 --> Controller Class Initialized
INFO - 2018-10-09 18:54:38 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:54:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:54:38 --> Pixel_Model class loaded
INFO - 2018-10-09 18:54:38 --> Database Driver Class Initialized
INFO - 2018-10-09 18:54:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:54:38 --> Database Driver Class Initialized
INFO - 2018-10-09 18:54:38 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:54:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 18:54:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 18:54:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 18:54:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 18:54:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 18:54:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 18:54:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_value.php
INFO - 2018-10-09 18:54:38 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 18:54:38 --> Final output sent to browser
DEBUG - 2018-10-09 18:54:38 --> Total execution time: 0.0567
INFO - 2018-10-09 18:54:43 --> Config Class Initialized
INFO - 2018-10-09 18:54:43 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:54:43 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:54:43 --> Utf8 Class Initialized
INFO - 2018-10-09 18:54:43 --> URI Class Initialized
INFO - 2018-10-09 18:54:43 --> Router Class Initialized
INFO - 2018-10-09 18:54:43 --> Output Class Initialized
INFO - 2018-10-09 18:54:43 --> Security Class Initialized
DEBUG - 2018-10-09 18:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:54:43 --> CSRF cookie sent
INFO - 2018-10-09 18:54:43 --> Input Class Initialized
INFO - 2018-10-09 18:54:43 --> Language Class Initialized
INFO - 2018-10-09 18:54:43 --> Loader Class Initialized
INFO - 2018-10-09 18:54:43 --> Helper loaded: url_helper
INFO - 2018-10-09 18:54:43 --> Helper loaded: form_helper
INFO - 2018-10-09 18:54:43 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:54:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:54:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:54:43 --> User Agent Class Initialized
INFO - 2018-10-09 18:54:43 --> Controller Class Initialized
INFO - 2018-10-09 18:54:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:54:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:54:43 --> Pixel_Model class loaded
INFO - 2018-10-09 18:54:43 --> Database Driver Class Initialized
INFO - 2018-10-09 18:54:43 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:54:43 --> Database Driver Class Initialized
INFO - 2018-10-09 18:54:43 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:54:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 18:54:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 18:54:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 18:54:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 18:54:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-10-09 18:54:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 18:54:43 --> Final output sent to browser
DEBUG - 2018-10-09 18:54:43 --> Total execution time: 0.0479
INFO - 2018-10-09 18:54:49 --> Config Class Initialized
INFO - 2018-10-09 18:54:49 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:54:49 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:54:49 --> Utf8 Class Initialized
INFO - 2018-10-09 18:54:49 --> URI Class Initialized
INFO - 2018-10-09 18:54:49 --> Router Class Initialized
INFO - 2018-10-09 18:54:49 --> Output Class Initialized
INFO - 2018-10-09 18:54:49 --> Security Class Initialized
DEBUG - 2018-10-09 18:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:54:49 --> CSRF cookie sent
INFO - 2018-10-09 18:54:49 --> Input Class Initialized
INFO - 2018-10-09 18:54:49 --> Language Class Initialized
INFO - 2018-10-09 18:54:49 --> Loader Class Initialized
INFO - 2018-10-09 18:54:49 --> Helper loaded: url_helper
INFO - 2018-10-09 18:54:49 --> Helper loaded: form_helper
INFO - 2018-10-09 18:54:49 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:54:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:54:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:54:49 --> User Agent Class Initialized
INFO - 2018-10-09 18:54:49 --> Controller Class Initialized
INFO - 2018-10-09 18:54:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:54:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:54:49 --> Pixel_Model class loaded
INFO - 2018-10-09 18:54:49 --> Database Driver Class Initialized
INFO - 2018-10-09 18:54:49 --> Model "MyAccountModel" initialized
INFO - 2018-10-09 18:54:49 --> Config Class Initialized
INFO - 2018-10-09 18:54:49 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:54:49 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:54:49 --> Utf8 Class Initialized
INFO - 2018-10-09 18:54:49 --> URI Class Initialized
INFO - 2018-10-09 18:54:49 --> Router Class Initialized
INFO - 2018-10-09 18:54:49 --> Output Class Initialized
INFO - 2018-10-09 18:54:49 --> Security Class Initialized
DEBUG - 2018-10-09 18:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:54:49 --> CSRF cookie sent
INFO - 2018-10-09 18:54:49 --> Input Class Initialized
INFO - 2018-10-09 18:54:49 --> Language Class Initialized
INFO - 2018-10-09 18:54:49 --> Loader Class Initialized
INFO - 2018-10-09 18:54:49 --> Helper loaded: url_helper
INFO - 2018-10-09 18:54:49 --> Helper loaded: form_helper
INFO - 2018-10-09 18:54:49 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:54:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:54:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:54:49 --> User Agent Class Initialized
INFO - 2018-10-09 18:54:49 --> Controller Class Initialized
INFO - 2018-10-09 18:54:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:54:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:54:49 --> Pixel_Model class loaded
INFO - 2018-10-09 18:54:49 --> Database Driver Class Initialized
INFO - 2018-10-09 18:54:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:54:49 --> Database Driver Class Initialized
INFO - 2018-10-09 18:54:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:54:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 18:54:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 18:54:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 18:54:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 18:54:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 18:54:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 18:54:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_value.php
INFO - 2018-10-09 18:54:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 18:54:49 --> Final output sent to browser
DEBUG - 2018-10-09 18:54:49 --> Total execution time: 0.0474
INFO - 2018-10-09 18:54:55 --> Config Class Initialized
INFO - 2018-10-09 18:54:55 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:54:55 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:54:55 --> Utf8 Class Initialized
INFO - 2018-10-09 18:54:55 --> URI Class Initialized
INFO - 2018-10-09 18:54:55 --> Router Class Initialized
INFO - 2018-10-09 18:54:55 --> Output Class Initialized
INFO - 2018-10-09 18:54:55 --> Security Class Initialized
DEBUG - 2018-10-09 18:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:54:55 --> CSRF cookie sent
INFO - 2018-10-09 18:54:55 --> CSRF token verified
INFO - 2018-10-09 18:54:55 --> Input Class Initialized
INFO - 2018-10-09 18:54:55 --> Language Class Initialized
INFO - 2018-10-09 18:54:55 --> Loader Class Initialized
INFO - 2018-10-09 18:54:55 --> Helper loaded: url_helper
INFO - 2018-10-09 18:54:55 --> Helper loaded: form_helper
INFO - 2018-10-09 18:54:55 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:54:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:54:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:54:55 --> User Agent Class Initialized
INFO - 2018-10-09 18:54:55 --> Controller Class Initialized
INFO - 2018-10-09 18:54:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:54:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:54:55 --> Pixel_Model class loaded
INFO - 2018-10-09 18:54:55 --> Database Driver Class Initialized
INFO - 2018-10-09 18:54:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:54:55 --> Form Validation Class Initialized
INFO - 2018-10-09 18:54:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 18:54:55 --> Database Driver Class Initialized
INFO - 2018-10-09 18:54:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:54:55 --> Config Class Initialized
INFO - 2018-10-09 18:54:55 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:54:55 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:54:55 --> Utf8 Class Initialized
INFO - 2018-10-09 18:54:55 --> URI Class Initialized
INFO - 2018-10-09 18:54:55 --> Router Class Initialized
INFO - 2018-10-09 18:54:55 --> Output Class Initialized
INFO - 2018-10-09 18:54:55 --> Security Class Initialized
DEBUG - 2018-10-09 18:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:54:55 --> CSRF cookie sent
INFO - 2018-10-09 18:54:55 --> Input Class Initialized
INFO - 2018-10-09 18:54:55 --> Language Class Initialized
INFO - 2018-10-09 18:54:55 --> Loader Class Initialized
INFO - 2018-10-09 18:54:55 --> Helper loaded: url_helper
INFO - 2018-10-09 18:54:55 --> Helper loaded: form_helper
INFO - 2018-10-09 18:54:55 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:54:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:54:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:54:55 --> User Agent Class Initialized
INFO - 2018-10-09 18:54:55 --> Controller Class Initialized
INFO - 2018-10-09 18:54:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:54:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:54:55 --> Pixel_Model class loaded
INFO - 2018-10-09 18:54:55 --> Database Driver Class Initialized
INFO - 2018-10-09 18:54:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:54:55 --> Database Driver Class Initialized
INFO - 2018-10-09 18:54:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:54:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 18:54:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 18:54:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 18:54:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 18:54:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 18:54:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 18:54:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/merriage_home_title.php
INFO - 2018-10-09 18:54:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 18:54:55 --> Final output sent to browser
DEBUG - 2018-10-09 18:54:55 --> Total execution time: 0.0471
INFO - 2018-10-09 18:54:57 --> Config Class Initialized
INFO - 2018-10-09 18:54:57 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:54:57 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:54:57 --> Utf8 Class Initialized
INFO - 2018-10-09 18:54:57 --> URI Class Initialized
INFO - 2018-10-09 18:54:57 --> Router Class Initialized
INFO - 2018-10-09 18:54:57 --> Output Class Initialized
INFO - 2018-10-09 18:54:57 --> Security Class Initialized
DEBUG - 2018-10-09 18:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:54:57 --> CSRF cookie sent
INFO - 2018-10-09 18:54:57 --> Input Class Initialized
INFO - 2018-10-09 18:54:57 --> Language Class Initialized
INFO - 2018-10-09 18:54:57 --> Loader Class Initialized
INFO - 2018-10-09 18:54:57 --> Helper loaded: url_helper
INFO - 2018-10-09 18:54:57 --> Helper loaded: form_helper
INFO - 2018-10-09 18:54:57 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:54:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:54:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:54:57 --> User Agent Class Initialized
INFO - 2018-10-09 18:54:57 --> Controller Class Initialized
INFO - 2018-10-09 18:54:57 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:54:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:54:57 --> Pixel_Model class loaded
INFO - 2018-10-09 18:54:57 --> Database Driver Class Initialized
INFO - 2018-10-09 18:54:57 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:54:57 --> Database Driver Class Initialized
INFO - 2018-10-09 18:54:57 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:54:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 18:54:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 18:54:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 18:54:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 18:54:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-10-09 18:54:57 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 18:54:57 --> Final output sent to browser
DEBUG - 2018-10-09 18:54:57 --> Total execution time: 0.0560
INFO - 2018-10-09 18:59:25 --> Config Class Initialized
INFO - 2018-10-09 18:59:25 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:59:25 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:59:25 --> Utf8 Class Initialized
INFO - 2018-10-09 18:59:25 --> URI Class Initialized
INFO - 2018-10-09 18:59:25 --> Router Class Initialized
INFO - 2018-10-09 18:59:25 --> Output Class Initialized
INFO - 2018-10-09 18:59:25 --> Security Class Initialized
DEBUG - 2018-10-09 18:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:59:25 --> CSRF cookie sent
INFO - 2018-10-09 18:59:25 --> Input Class Initialized
INFO - 2018-10-09 18:59:25 --> Language Class Initialized
INFO - 2018-10-09 18:59:25 --> Loader Class Initialized
INFO - 2018-10-09 18:59:25 --> Helper loaded: url_helper
INFO - 2018-10-09 18:59:25 --> Helper loaded: form_helper
INFO - 2018-10-09 18:59:25 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:59:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:59:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:59:25 --> User Agent Class Initialized
INFO - 2018-10-09 18:59:25 --> Controller Class Initialized
INFO - 2018-10-09 18:59:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:59:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:59:25 --> Pixel_Model class loaded
INFO - 2018-10-09 18:59:25 --> Database Driver Class Initialized
INFO - 2018-10-09 18:59:25 --> Model "MyAccountModel" initialized
INFO - 2018-10-09 18:59:25 --> Config Class Initialized
INFO - 2018-10-09 18:59:25 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:59:25 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:59:25 --> Utf8 Class Initialized
INFO - 2018-10-09 18:59:25 --> URI Class Initialized
INFO - 2018-10-09 18:59:25 --> Router Class Initialized
INFO - 2018-10-09 18:59:25 --> Output Class Initialized
INFO - 2018-10-09 18:59:25 --> Security Class Initialized
DEBUG - 2018-10-09 18:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:59:25 --> CSRF cookie sent
INFO - 2018-10-09 18:59:25 --> Input Class Initialized
INFO - 2018-10-09 18:59:25 --> Language Class Initialized
INFO - 2018-10-09 18:59:25 --> Loader Class Initialized
INFO - 2018-10-09 18:59:25 --> Helper loaded: url_helper
INFO - 2018-10-09 18:59:25 --> Helper loaded: form_helper
INFO - 2018-10-09 18:59:25 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:59:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:59:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:59:25 --> User Agent Class Initialized
INFO - 2018-10-09 18:59:25 --> Controller Class Initialized
INFO - 2018-10-09 18:59:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:59:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:59:25 --> Pixel_Model class loaded
INFO - 2018-10-09 18:59:25 --> Database Driver Class Initialized
INFO - 2018-10-09 18:59:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:59:25 --> Database Driver Class Initialized
INFO - 2018-10-09 18:59:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:59:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 18:59:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 18:59:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 18:59:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 18:59:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 18:59:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 18:59:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/merriage_home_title.php
INFO - 2018-10-09 18:59:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 18:59:25 --> Final output sent to browser
DEBUG - 2018-10-09 18:59:25 --> Total execution time: 0.0578
INFO - 2018-10-09 18:59:27 --> Config Class Initialized
INFO - 2018-10-09 18:59:27 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:59:27 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:59:27 --> Utf8 Class Initialized
INFO - 2018-10-09 18:59:27 --> URI Class Initialized
INFO - 2018-10-09 18:59:27 --> Router Class Initialized
INFO - 2018-10-09 18:59:27 --> Output Class Initialized
INFO - 2018-10-09 18:59:27 --> Security Class Initialized
DEBUG - 2018-10-09 18:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:59:27 --> CSRF cookie sent
INFO - 2018-10-09 18:59:27 --> Input Class Initialized
INFO - 2018-10-09 18:59:27 --> Language Class Initialized
INFO - 2018-10-09 18:59:27 --> Loader Class Initialized
INFO - 2018-10-09 18:59:27 --> Helper loaded: url_helper
INFO - 2018-10-09 18:59:27 --> Helper loaded: form_helper
INFO - 2018-10-09 18:59:27 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:59:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:59:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:59:27 --> User Agent Class Initialized
INFO - 2018-10-09 18:59:27 --> Controller Class Initialized
INFO - 2018-10-09 18:59:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:59:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:59:27 --> Pixel_Model class loaded
INFO - 2018-10-09 18:59:27 --> Database Driver Class Initialized
INFO - 2018-10-09 18:59:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:59:27 --> Database Driver Class Initialized
INFO - 2018-10-09 18:59:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:59:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 18:59:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 18:59:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 18:59:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 18:59:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 18:59:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 18:59:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_value.php
INFO - 2018-10-09 18:59:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 18:59:27 --> Final output sent to browser
DEBUG - 2018-10-09 18:59:27 --> Total execution time: 0.0527
INFO - 2018-10-09 18:59:28 --> Config Class Initialized
INFO - 2018-10-09 18:59:28 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:59:28 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:59:28 --> Utf8 Class Initialized
INFO - 2018-10-09 18:59:28 --> URI Class Initialized
INFO - 2018-10-09 18:59:28 --> Router Class Initialized
INFO - 2018-10-09 18:59:28 --> Output Class Initialized
INFO - 2018-10-09 18:59:28 --> Security Class Initialized
DEBUG - 2018-10-09 18:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:59:28 --> CSRF cookie sent
INFO - 2018-10-09 18:59:28 --> Input Class Initialized
INFO - 2018-10-09 18:59:28 --> Language Class Initialized
INFO - 2018-10-09 18:59:28 --> Loader Class Initialized
INFO - 2018-10-09 18:59:28 --> Helper loaded: url_helper
INFO - 2018-10-09 18:59:28 --> Helper loaded: form_helper
INFO - 2018-10-09 18:59:28 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:59:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:59:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:59:28 --> User Agent Class Initialized
INFO - 2018-10-09 18:59:28 --> Controller Class Initialized
INFO - 2018-10-09 18:59:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:59:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:59:28 --> Pixel_Model class loaded
INFO - 2018-10-09 18:59:28 --> Database Driver Class Initialized
INFO - 2018-10-09 18:59:28 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:59:28 --> Database Driver Class Initialized
INFO - 2018-10-09 18:59:28 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:59:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 18:59:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 18:59:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 18:59:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 18:59:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 18:59:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 18:59:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_owner.php
INFO - 2018-10-09 18:59:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 18:59:28 --> Final output sent to browser
DEBUG - 2018-10-09 18:59:28 --> Total execution time: 0.0520
INFO - 2018-10-09 18:59:29 --> Config Class Initialized
INFO - 2018-10-09 18:59:29 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:59:29 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:59:29 --> Utf8 Class Initialized
INFO - 2018-10-09 18:59:29 --> URI Class Initialized
INFO - 2018-10-09 18:59:29 --> Router Class Initialized
INFO - 2018-10-09 18:59:29 --> Output Class Initialized
INFO - 2018-10-09 18:59:29 --> Security Class Initialized
DEBUG - 2018-10-09 18:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:59:29 --> CSRF cookie sent
INFO - 2018-10-09 18:59:29 --> Input Class Initialized
INFO - 2018-10-09 18:59:29 --> Language Class Initialized
INFO - 2018-10-09 18:59:29 --> Loader Class Initialized
INFO - 2018-10-09 18:59:29 --> Helper loaded: url_helper
INFO - 2018-10-09 18:59:29 --> Helper loaded: form_helper
INFO - 2018-10-09 18:59:29 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:59:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:59:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:59:29 --> User Agent Class Initialized
INFO - 2018-10-09 18:59:29 --> Controller Class Initialized
INFO - 2018-10-09 18:59:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:59:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:59:29 --> Pixel_Model class loaded
INFO - 2018-10-09 18:59:29 --> Database Driver Class Initialized
INFO - 2018-10-09 18:59:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:59:29 --> Database Driver Class Initialized
INFO - 2018-10-09 18:59:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:59:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 18:59:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 18:59:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 18:59:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 18:59:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 18:59:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 18:59:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-10-09 18:59:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 18:59:29 --> Final output sent to browser
DEBUG - 2018-10-09 18:59:29 --> Total execution time: 0.0453
INFO - 2018-10-09 18:59:31 --> Config Class Initialized
INFO - 2018-10-09 18:59:31 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:59:31 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:59:31 --> Utf8 Class Initialized
INFO - 2018-10-09 18:59:31 --> URI Class Initialized
INFO - 2018-10-09 18:59:31 --> Router Class Initialized
INFO - 2018-10-09 18:59:31 --> Output Class Initialized
INFO - 2018-10-09 18:59:31 --> Security Class Initialized
DEBUG - 2018-10-09 18:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:59:31 --> CSRF cookie sent
INFO - 2018-10-09 18:59:31 --> Input Class Initialized
INFO - 2018-10-09 18:59:31 --> Language Class Initialized
INFO - 2018-10-09 18:59:31 --> Loader Class Initialized
INFO - 2018-10-09 18:59:31 --> Helper loaded: url_helper
INFO - 2018-10-09 18:59:31 --> Helper loaded: form_helper
INFO - 2018-10-09 18:59:31 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:59:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:59:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:59:31 --> User Agent Class Initialized
INFO - 2018-10-09 18:59:31 --> Controller Class Initialized
INFO - 2018-10-09 18:59:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:59:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:59:31 --> Pixel_Model class loaded
INFO - 2018-10-09 18:59:31 --> Database Driver Class Initialized
INFO - 2018-10-09 18:59:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:59:31 --> Database Driver Class Initialized
INFO - 2018-10-09 18:59:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:59:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 18:59:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 18:59:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 18:59:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 18:59:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 18:59:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 18:59:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-10-09 18:59:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 18:59:31 --> Final output sent to browser
DEBUG - 2018-10-09 18:59:31 --> Total execution time: 0.0470
INFO - 2018-10-09 18:59:32 --> Config Class Initialized
INFO - 2018-10-09 18:59:32 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:59:32 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:59:32 --> Utf8 Class Initialized
INFO - 2018-10-09 18:59:32 --> URI Class Initialized
INFO - 2018-10-09 18:59:32 --> Router Class Initialized
INFO - 2018-10-09 18:59:32 --> Output Class Initialized
INFO - 2018-10-09 18:59:32 --> Security Class Initialized
DEBUG - 2018-10-09 18:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:59:32 --> CSRF cookie sent
INFO - 2018-10-09 18:59:32 --> Input Class Initialized
INFO - 2018-10-09 18:59:32 --> Language Class Initialized
INFO - 2018-10-09 18:59:32 --> Loader Class Initialized
INFO - 2018-10-09 18:59:32 --> Helper loaded: url_helper
INFO - 2018-10-09 18:59:32 --> Helper loaded: form_helper
INFO - 2018-10-09 18:59:32 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:59:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:59:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:59:32 --> User Agent Class Initialized
INFO - 2018-10-09 18:59:32 --> Controller Class Initialized
INFO - 2018-10-09 18:59:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:59:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:59:32 --> Pixel_Model class loaded
INFO - 2018-10-09 18:59:32 --> Database Driver Class Initialized
INFO - 2018-10-09 18:59:32 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:59:32 --> Database Driver Class Initialized
INFO - 2018-10-09 18:59:32 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:59:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 18:59:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 18:59:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 18:59:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 18:59:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 18:59:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 18:59:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-10-09 18:59:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 18:59:32 --> Final output sent to browser
DEBUG - 2018-10-09 18:59:32 --> Total execution time: 0.0487
INFO - 2018-10-09 18:59:34 --> Config Class Initialized
INFO - 2018-10-09 18:59:34 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:59:34 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:59:34 --> Utf8 Class Initialized
INFO - 2018-10-09 18:59:34 --> URI Class Initialized
INFO - 2018-10-09 18:59:34 --> Router Class Initialized
INFO - 2018-10-09 18:59:34 --> Output Class Initialized
INFO - 2018-10-09 18:59:34 --> Security Class Initialized
DEBUG - 2018-10-09 18:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:59:34 --> CSRF cookie sent
INFO - 2018-10-09 18:59:34 --> Input Class Initialized
INFO - 2018-10-09 18:59:34 --> Language Class Initialized
INFO - 2018-10-09 18:59:34 --> Loader Class Initialized
INFO - 2018-10-09 18:59:34 --> Helper loaded: url_helper
INFO - 2018-10-09 18:59:34 --> Helper loaded: form_helper
INFO - 2018-10-09 18:59:34 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:59:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:59:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:59:34 --> User Agent Class Initialized
INFO - 2018-10-09 18:59:34 --> Controller Class Initialized
INFO - 2018-10-09 18:59:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:59:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:59:34 --> Pixel_Model class loaded
INFO - 2018-10-09 18:59:34 --> Database Driver Class Initialized
INFO - 2018-10-09 18:59:34 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:59:34 --> Database Driver Class Initialized
INFO - 2018-10-09 18:59:34 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:59:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 18:59:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 18:59:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 18:59:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 18:59:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 18:59:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 18:59:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-10-09 18:59:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 18:59:34 --> Final output sent to browser
DEBUG - 2018-10-09 18:59:34 --> Total execution time: 0.0379
INFO - 2018-10-09 18:59:35 --> Config Class Initialized
INFO - 2018-10-09 18:59:35 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:59:35 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:59:35 --> Utf8 Class Initialized
INFO - 2018-10-09 18:59:35 --> URI Class Initialized
INFO - 2018-10-09 18:59:35 --> Router Class Initialized
INFO - 2018-10-09 18:59:35 --> Output Class Initialized
INFO - 2018-10-09 18:59:35 --> Security Class Initialized
DEBUG - 2018-10-09 18:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:59:35 --> CSRF cookie sent
INFO - 2018-10-09 18:59:35 --> Input Class Initialized
INFO - 2018-10-09 18:59:35 --> Language Class Initialized
INFO - 2018-10-09 18:59:35 --> Loader Class Initialized
INFO - 2018-10-09 18:59:35 --> Helper loaded: url_helper
INFO - 2018-10-09 18:59:35 --> Helper loaded: form_helper
INFO - 2018-10-09 18:59:35 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:59:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:59:35 --> User Agent Class Initialized
INFO - 2018-10-09 18:59:35 --> Controller Class Initialized
INFO - 2018-10-09 18:59:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:59:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:59:35 --> Pixel_Model class loaded
INFO - 2018-10-09 18:59:35 --> Database Driver Class Initialized
INFO - 2018-10-09 18:59:35 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:59:35 --> Database Driver Class Initialized
INFO - 2018-10-09 18:59:35 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:59:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 18:59:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 18:59:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 18:59:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 18:59:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 18:59:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 18:59:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/marriage.php
INFO - 2018-10-09 18:59:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 18:59:35 --> Final output sent to browser
DEBUG - 2018-10-09 18:59:35 --> Total execution time: 0.0508
INFO - 2018-10-09 18:59:36 --> Config Class Initialized
INFO - 2018-10-09 18:59:36 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:59:36 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:59:36 --> Utf8 Class Initialized
INFO - 2018-10-09 18:59:36 --> URI Class Initialized
INFO - 2018-10-09 18:59:36 --> Router Class Initialized
INFO - 2018-10-09 18:59:36 --> Output Class Initialized
INFO - 2018-10-09 18:59:36 --> Security Class Initialized
DEBUG - 2018-10-09 18:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:59:36 --> CSRF cookie sent
INFO - 2018-10-09 18:59:36 --> Input Class Initialized
INFO - 2018-10-09 18:59:36 --> Language Class Initialized
INFO - 2018-10-09 18:59:36 --> Loader Class Initialized
INFO - 2018-10-09 18:59:36 --> Helper loaded: url_helper
INFO - 2018-10-09 18:59:36 --> Helper loaded: form_helper
INFO - 2018-10-09 18:59:36 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:59:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:59:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:59:36 --> User Agent Class Initialized
INFO - 2018-10-09 18:59:36 --> Controller Class Initialized
INFO - 2018-10-09 18:59:36 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:59:36 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:59:36 --> Pixel_Model class loaded
INFO - 2018-10-09 18:59:36 --> Database Driver Class Initialized
INFO - 2018-10-09 18:59:36 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:59:36 --> Database Driver Class Initialized
INFO - 2018-10-09 18:59:36 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:59:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 18:59:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 18:59:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 18:59:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 18:59:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 18:59:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 18:59:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-09 18:59:36 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 18:59:36 --> Final output sent to browser
DEBUG - 2018-10-09 18:59:36 --> Total execution time: 0.0406
INFO - 2018-10-09 18:59:43 --> Config Class Initialized
INFO - 2018-10-09 18:59:43 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:59:43 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:59:43 --> Utf8 Class Initialized
INFO - 2018-10-09 18:59:43 --> URI Class Initialized
INFO - 2018-10-09 18:59:43 --> Router Class Initialized
INFO - 2018-10-09 18:59:43 --> Output Class Initialized
INFO - 2018-10-09 18:59:43 --> Security Class Initialized
DEBUG - 2018-10-09 18:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:59:43 --> CSRF cookie sent
INFO - 2018-10-09 18:59:43 --> Input Class Initialized
INFO - 2018-10-09 18:59:43 --> Language Class Initialized
INFO - 2018-10-09 18:59:43 --> Loader Class Initialized
INFO - 2018-10-09 18:59:43 --> Helper loaded: url_helper
INFO - 2018-10-09 18:59:43 --> Helper loaded: form_helper
INFO - 2018-10-09 18:59:43 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:59:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:59:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:59:43 --> User Agent Class Initialized
INFO - 2018-10-09 18:59:43 --> Controller Class Initialized
INFO - 2018-10-09 18:59:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:59:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:59:43 --> Pixel_Model class loaded
INFO - 2018-10-09 18:59:43 --> Database Driver Class Initialized
INFO - 2018-10-09 18:59:43 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:59:43 --> Database Driver Class Initialized
INFO - 2018-10-09 18:59:43 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:59:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 18:59:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 18:59:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-10-09 18:59:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 18:59:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 18:59:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 18:59:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 18:59:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-10-09 18:59:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 18:59:43 --> Final output sent to browser
DEBUG - 2018-10-09 18:59:43 --> Total execution time: 0.0397
INFO - 2018-10-09 18:59:45 --> Config Class Initialized
INFO - 2018-10-09 18:59:45 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:59:45 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:59:45 --> Utf8 Class Initialized
INFO - 2018-10-09 18:59:45 --> URI Class Initialized
INFO - 2018-10-09 18:59:45 --> Router Class Initialized
INFO - 2018-10-09 18:59:45 --> Output Class Initialized
INFO - 2018-10-09 18:59:45 --> Security Class Initialized
DEBUG - 2018-10-09 18:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:59:45 --> CSRF cookie sent
INFO - 2018-10-09 18:59:45 --> Input Class Initialized
INFO - 2018-10-09 18:59:45 --> Language Class Initialized
INFO - 2018-10-09 18:59:45 --> Loader Class Initialized
INFO - 2018-10-09 18:59:45 --> Helper loaded: url_helper
INFO - 2018-10-09 18:59:45 --> Helper loaded: form_helper
INFO - 2018-10-09 18:59:45 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:59:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:59:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:59:45 --> User Agent Class Initialized
INFO - 2018-10-09 18:59:45 --> Controller Class Initialized
INFO - 2018-10-09 18:59:45 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:59:45 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:59:45 --> Pixel_Model class loaded
INFO - 2018-10-09 18:59:45 --> Database Driver Class Initialized
INFO - 2018-10-09 18:59:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:59:45 --> Database Driver Class Initialized
INFO - 2018-10-09 18:59:45 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:59:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 18:59:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 18:59:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 18:59:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 18:59:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 18:59:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 18:59:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-10-09 18:59:45 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 18:59:45 --> Final output sent to browser
DEBUG - 2018-10-09 18:59:45 --> Total execution time: 0.0481
INFO - 2018-10-09 18:59:46 --> Config Class Initialized
INFO - 2018-10-09 18:59:46 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:59:46 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:59:46 --> Utf8 Class Initialized
INFO - 2018-10-09 18:59:46 --> URI Class Initialized
INFO - 2018-10-09 18:59:46 --> Router Class Initialized
INFO - 2018-10-09 18:59:46 --> Output Class Initialized
INFO - 2018-10-09 18:59:46 --> Security Class Initialized
DEBUG - 2018-10-09 18:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:59:46 --> CSRF cookie sent
INFO - 2018-10-09 18:59:46 --> CSRF token verified
INFO - 2018-10-09 18:59:46 --> Input Class Initialized
INFO - 2018-10-09 18:59:46 --> Language Class Initialized
INFO - 2018-10-09 18:59:46 --> Loader Class Initialized
INFO - 2018-10-09 18:59:46 --> Helper loaded: url_helper
INFO - 2018-10-09 18:59:46 --> Helper loaded: form_helper
INFO - 2018-10-09 18:59:46 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:59:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:59:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:59:46 --> User Agent Class Initialized
INFO - 2018-10-09 18:59:46 --> Controller Class Initialized
INFO - 2018-10-09 18:59:46 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:59:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:59:46 --> Pixel_Model class loaded
INFO - 2018-10-09 18:59:46 --> Database Driver Class Initialized
INFO - 2018-10-09 18:59:46 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:59:46 --> Form Validation Class Initialized
INFO - 2018-10-09 18:59:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 18:59:46 --> Database Driver Class Initialized
INFO - 2018-10-09 18:59:46 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:59:47 --> Config Class Initialized
INFO - 2018-10-09 18:59:47 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:59:47 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:59:47 --> Utf8 Class Initialized
INFO - 2018-10-09 18:59:47 --> URI Class Initialized
INFO - 2018-10-09 18:59:47 --> Router Class Initialized
INFO - 2018-10-09 18:59:47 --> Output Class Initialized
INFO - 2018-10-09 18:59:47 --> Security Class Initialized
DEBUG - 2018-10-09 18:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:59:47 --> CSRF cookie sent
INFO - 2018-10-09 18:59:47 --> Input Class Initialized
INFO - 2018-10-09 18:59:47 --> Language Class Initialized
INFO - 2018-10-09 18:59:47 --> Loader Class Initialized
INFO - 2018-10-09 18:59:47 --> Helper loaded: url_helper
INFO - 2018-10-09 18:59:47 --> Helper loaded: form_helper
INFO - 2018-10-09 18:59:47 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:59:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:59:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:59:47 --> User Agent Class Initialized
INFO - 2018-10-09 18:59:47 --> Controller Class Initialized
INFO - 2018-10-09 18:59:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:59:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:59:47 --> Pixel_Model class loaded
INFO - 2018-10-09 18:59:47 --> Database Driver Class Initialized
INFO - 2018-10-09 18:59:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:59:47 --> Database Driver Class Initialized
INFO - 2018-10-09 18:59:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:59:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 18:59:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 18:59:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-10-09 18:59:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 18:59:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 18:59:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 18:59:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 18:59:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-10-09 18:59:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 18:59:47 --> Final output sent to browser
DEBUG - 2018-10-09 18:59:47 --> Total execution time: 0.0390
INFO - 2018-10-09 18:59:47 --> Config Class Initialized
INFO - 2018-10-09 18:59:47 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:59:47 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:59:47 --> Utf8 Class Initialized
INFO - 2018-10-09 18:59:47 --> URI Class Initialized
INFO - 2018-10-09 18:59:47 --> Router Class Initialized
INFO - 2018-10-09 18:59:47 --> Output Class Initialized
INFO - 2018-10-09 18:59:47 --> Security Class Initialized
DEBUG - 2018-10-09 18:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:59:47 --> CSRF cookie sent
INFO - 2018-10-09 18:59:47 --> CSRF token verified
INFO - 2018-10-09 18:59:47 --> Input Class Initialized
INFO - 2018-10-09 18:59:47 --> Language Class Initialized
INFO - 2018-10-09 18:59:47 --> Loader Class Initialized
INFO - 2018-10-09 18:59:47 --> Helper loaded: url_helper
INFO - 2018-10-09 18:59:47 --> Helper loaded: form_helper
INFO - 2018-10-09 18:59:47 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:59:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:59:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:59:47 --> User Agent Class Initialized
INFO - 2018-10-09 18:59:47 --> Controller Class Initialized
INFO - 2018-10-09 18:59:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:59:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:59:47 --> Pixel_Model class loaded
INFO - 2018-10-09 18:59:47 --> Database Driver Class Initialized
INFO - 2018-10-09 18:59:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:59:47 --> Form Validation Class Initialized
INFO - 2018-10-09 18:59:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 18:59:47 --> Database Driver Class Initialized
INFO - 2018-10-09 18:59:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:59:47 --> Config Class Initialized
INFO - 2018-10-09 18:59:47 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:59:47 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:59:47 --> Utf8 Class Initialized
INFO - 2018-10-09 18:59:47 --> URI Class Initialized
INFO - 2018-10-09 18:59:47 --> Router Class Initialized
INFO - 2018-10-09 18:59:47 --> Output Class Initialized
INFO - 2018-10-09 18:59:47 --> Security Class Initialized
DEBUG - 2018-10-09 18:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:59:47 --> CSRF cookie sent
INFO - 2018-10-09 18:59:47 --> Input Class Initialized
INFO - 2018-10-09 18:59:47 --> Language Class Initialized
INFO - 2018-10-09 18:59:47 --> Loader Class Initialized
INFO - 2018-10-09 18:59:47 --> Helper loaded: url_helper
INFO - 2018-10-09 18:59:47 --> Helper loaded: form_helper
INFO - 2018-10-09 18:59:47 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:59:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:59:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:59:47 --> User Agent Class Initialized
INFO - 2018-10-09 18:59:47 --> Controller Class Initialized
INFO - 2018-10-09 18:59:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:59:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:59:47 --> Pixel_Model class loaded
INFO - 2018-10-09 18:59:47 --> Database Driver Class Initialized
INFO - 2018-10-09 18:59:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:59:47 --> Database Driver Class Initialized
INFO - 2018-10-09 18:59:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:59:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 18:59:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 18:59:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 18:59:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 18:59:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 18:59:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 18:59:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-09 18:59:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 18:59:47 --> Final output sent to browser
DEBUG - 2018-10-09 18:59:47 --> Total execution time: 0.0384
INFO - 2018-10-09 18:59:51 --> Config Class Initialized
INFO - 2018-10-09 18:59:51 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:59:51 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:59:51 --> Utf8 Class Initialized
INFO - 2018-10-09 18:59:51 --> URI Class Initialized
INFO - 2018-10-09 18:59:51 --> Router Class Initialized
INFO - 2018-10-09 18:59:51 --> Output Class Initialized
INFO - 2018-10-09 18:59:51 --> Security Class Initialized
DEBUG - 2018-10-09 18:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:59:51 --> CSRF cookie sent
INFO - 2018-10-09 18:59:51 --> CSRF token verified
INFO - 2018-10-09 18:59:51 --> Input Class Initialized
INFO - 2018-10-09 18:59:51 --> Language Class Initialized
INFO - 2018-10-09 18:59:51 --> Loader Class Initialized
INFO - 2018-10-09 18:59:51 --> Helper loaded: url_helper
INFO - 2018-10-09 18:59:51 --> Helper loaded: form_helper
INFO - 2018-10-09 18:59:51 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:59:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:59:51 --> User Agent Class Initialized
INFO - 2018-10-09 18:59:51 --> Controller Class Initialized
INFO - 2018-10-09 18:59:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:59:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:59:51 --> Pixel_Model class loaded
INFO - 2018-10-09 18:59:51 --> Database Driver Class Initialized
INFO - 2018-10-09 18:59:51 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:59:51 --> Form Validation Class Initialized
INFO - 2018-10-09 18:59:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 18:59:51 --> Database Driver Class Initialized
INFO - 2018-10-09 18:59:51 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:59:51 --> Config Class Initialized
INFO - 2018-10-09 18:59:51 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:59:51 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:59:51 --> Utf8 Class Initialized
INFO - 2018-10-09 18:59:51 --> URI Class Initialized
INFO - 2018-10-09 18:59:51 --> Router Class Initialized
INFO - 2018-10-09 18:59:51 --> Output Class Initialized
INFO - 2018-10-09 18:59:51 --> Security Class Initialized
DEBUG - 2018-10-09 18:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:59:51 --> CSRF cookie sent
INFO - 2018-10-09 18:59:51 --> Input Class Initialized
INFO - 2018-10-09 18:59:51 --> Language Class Initialized
INFO - 2018-10-09 18:59:51 --> Loader Class Initialized
INFO - 2018-10-09 18:59:51 --> Helper loaded: url_helper
INFO - 2018-10-09 18:59:51 --> Helper loaded: form_helper
INFO - 2018-10-09 18:59:51 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:59:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:59:51 --> User Agent Class Initialized
INFO - 2018-10-09 18:59:51 --> Controller Class Initialized
INFO - 2018-10-09 18:59:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:59:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:59:51 --> Pixel_Model class loaded
INFO - 2018-10-09 18:59:51 --> Database Driver Class Initialized
INFO - 2018-10-09 18:59:51 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:59:51 --> Database Driver Class Initialized
INFO - 2018-10-09 18:59:51 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:59:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 18:59:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 18:59:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 18:59:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 18:59:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 18:59:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 18:59:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/marriage.php
INFO - 2018-10-09 18:59:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 18:59:51 --> Final output sent to browser
DEBUG - 2018-10-09 18:59:51 --> Total execution time: 0.0333
INFO - 2018-10-09 18:59:52 --> Config Class Initialized
INFO - 2018-10-09 18:59:52 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:59:52 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:59:52 --> Utf8 Class Initialized
INFO - 2018-10-09 18:59:52 --> URI Class Initialized
INFO - 2018-10-09 18:59:52 --> Router Class Initialized
INFO - 2018-10-09 18:59:52 --> Output Class Initialized
INFO - 2018-10-09 18:59:52 --> Security Class Initialized
DEBUG - 2018-10-09 18:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:59:52 --> CSRF cookie sent
INFO - 2018-10-09 18:59:52 --> CSRF token verified
INFO - 2018-10-09 18:59:52 --> Input Class Initialized
INFO - 2018-10-09 18:59:52 --> Language Class Initialized
INFO - 2018-10-09 18:59:52 --> Loader Class Initialized
INFO - 2018-10-09 18:59:52 --> Helper loaded: url_helper
INFO - 2018-10-09 18:59:52 --> Helper loaded: form_helper
INFO - 2018-10-09 18:59:52 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:59:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:59:52 --> User Agent Class Initialized
INFO - 2018-10-09 18:59:52 --> Controller Class Initialized
INFO - 2018-10-09 18:59:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:59:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:59:52 --> Pixel_Model class loaded
INFO - 2018-10-09 18:59:52 --> Database Driver Class Initialized
INFO - 2018-10-09 18:59:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:59:52 --> Form Validation Class Initialized
INFO - 2018-10-09 18:59:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 18:59:52 --> Database Driver Class Initialized
INFO - 2018-10-09 18:59:52 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:59:52 --> Config Class Initialized
INFO - 2018-10-09 18:59:52 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:59:52 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:59:52 --> Utf8 Class Initialized
INFO - 2018-10-09 18:59:52 --> URI Class Initialized
INFO - 2018-10-09 18:59:52 --> Router Class Initialized
INFO - 2018-10-09 18:59:52 --> Output Class Initialized
INFO - 2018-10-09 18:59:52 --> Security Class Initialized
DEBUG - 2018-10-09 18:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:59:52 --> CSRF cookie sent
INFO - 2018-10-09 18:59:52 --> Input Class Initialized
INFO - 2018-10-09 18:59:52 --> Language Class Initialized
INFO - 2018-10-09 18:59:52 --> Loader Class Initialized
INFO - 2018-10-09 18:59:52 --> Helper loaded: url_helper
INFO - 2018-10-09 18:59:52 --> Helper loaded: form_helper
INFO - 2018-10-09 18:59:52 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:59:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:59:53 --> User Agent Class Initialized
INFO - 2018-10-09 18:59:53 --> Controller Class Initialized
INFO - 2018-10-09 18:59:53 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:59:53 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:59:53 --> Pixel_Model class loaded
INFO - 2018-10-09 18:59:53 --> Database Driver Class Initialized
INFO - 2018-10-09 18:59:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:59:53 --> Database Driver Class Initialized
INFO - 2018-10-09 18:59:53 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:59:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 18:59:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 18:59:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 18:59:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 18:59:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 18:59:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 18:59:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-10-09 18:59:53 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 18:59:53 --> Final output sent to browser
DEBUG - 2018-10-09 18:59:53 --> Total execution time: 0.0474
INFO - 2018-10-09 18:59:54 --> Config Class Initialized
INFO - 2018-10-09 18:59:54 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:59:54 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:59:54 --> Utf8 Class Initialized
INFO - 2018-10-09 18:59:54 --> URI Class Initialized
INFO - 2018-10-09 18:59:54 --> Router Class Initialized
INFO - 2018-10-09 18:59:54 --> Output Class Initialized
INFO - 2018-10-09 18:59:54 --> Security Class Initialized
DEBUG - 2018-10-09 18:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:59:54 --> CSRF cookie sent
INFO - 2018-10-09 18:59:54 --> CSRF token verified
INFO - 2018-10-09 18:59:54 --> Input Class Initialized
INFO - 2018-10-09 18:59:54 --> Language Class Initialized
INFO - 2018-10-09 18:59:54 --> Loader Class Initialized
INFO - 2018-10-09 18:59:54 --> Helper loaded: url_helper
INFO - 2018-10-09 18:59:54 --> Helper loaded: form_helper
INFO - 2018-10-09 18:59:54 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:59:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:59:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:59:54 --> User Agent Class Initialized
INFO - 2018-10-09 18:59:54 --> Controller Class Initialized
INFO - 2018-10-09 18:59:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:59:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:59:54 --> Pixel_Model class loaded
INFO - 2018-10-09 18:59:54 --> Database Driver Class Initialized
INFO - 2018-10-09 18:59:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:59:54 --> Form Validation Class Initialized
INFO - 2018-10-09 18:59:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 18:59:54 --> Database Driver Class Initialized
INFO - 2018-10-09 18:59:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:59:54 --> Config Class Initialized
INFO - 2018-10-09 18:59:54 --> Hooks Class Initialized
DEBUG - 2018-10-09 18:59:54 --> UTF-8 Support Enabled
INFO - 2018-10-09 18:59:54 --> Utf8 Class Initialized
INFO - 2018-10-09 18:59:54 --> URI Class Initialized
INFO - 2018-10-09 18:59:54 --> Router Class Initialized
INFO - 2018-10-09 18:59:54 --> Output Class Initialized
INFO - 2018-10-09 18:59:54 --> Security Class Initialized
DEBUG - 2018-10-09 18:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 18:59:54 --> CSRF cookie sent
INFO - 2018-10-09 18:59:54 --> Input Class Initialized
INFO - 2018-10-09 18:59:54 --> Language Class Initialized
INFO - 2018-10-09 18:59:54 --> Loader Class Initialized
INFO - 2018-10-09 18:59:54 --> Helper loaded: url_helper
INFO - 2018-10-09 18:59:54 --> Helper loaded: form_helper
INFO - 2018-10-09 18:59:54 --> Helper loaded: language_helper
DEBUG - 2018-10-09 18:59:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 18:59:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 18:59:54 --> User Agent Class Initialized
INFO - 2018-10-09 18:59:54 --> Controller Class Initialized
INFO - 2018-10-09 18:59:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 18:59:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 18:59:54 --> Pixel_Model class loaded
INFO - 2018-10-09 18:59:54 --> Database Driver Class Initialized
INFO - 2018-10-09 18:59:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:59:54 --> Database Driver Class Initialized
INFO - 2018-10-09 18:59:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 18:59:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 18:59:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 18:59:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 18:59:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 18:59:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 18:59:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 18:59:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-10-09 18:59:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 18:59:54 --> Final output sent to browser
DEBUG - 2018-10-09 18:59:54 --> Total execution time: 0.0485
INFO - 2018-10-09 19:00:00 --> Config Class Initialized
INFO - 2018-10-09 19:00:00 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:00:00 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:00:00 --> Utf8 Class Initialized
INFO - 2018-10-09 19:00:00 --> URI Class Initialized
INFO - 2018-10-09 19:00:00 --> Router Class Initialized
INFO - 2018-10-09 19:00:00 --> Output Class Initialized
INFO - 2018-10-09 19:00:00 --> Security Class Initialized
DEBUG - 2018-10-09 19:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:00:00 --> CSRF cookie sent
INFO - 2018-10-09 19:00:00 --> CSRF token verified
INFO - 2018-10-09 19:00:00 --> Input Class Initialized
INFO - 2018-10-09 19:00:00 --> Language Class Initialized
INFO - 2018-10-09 19:00:00 --> Loader Class Initialized
INFO - 2018-10-09 19:00:00 --> Helper loaded: url_helper
INFO - 2018-10-09 19:00:00 --> Helper loaded: form_helper
INFO - 2018-10-09 19:00:00 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:00:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:00:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:00:00 --> User Agent Class Initialized
INFO - 2018-10-09 19:00:00 --> Controller Class Initialized
INFO - 2018-10-09 19:00:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 19:00:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 19:00:00 --> Pixel_Model class loaded
INFO - 2018-10-09 19:00:00 --> Database Driver Class Initialized
INFO - 2018-10-09 19:00:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:00:00 --> Form Validation Class Initialized
INFO - 2018-10-09 19:00:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 19:00:00 --> Database Driver Class Initialized
INFO - 2018-10-09 19:00:00 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:00:00 --> Config Class Initialized
INFO - 2018-10-09 19:00:00 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:00:00 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:00:00 --> Utf8 Class Initialized
INFO - 2018-10-09 19:00:00 --> URI Class Initialized
INFO - 2018-10-09 19:00:00 --> Router Class Initialized
INFO - 2018-10-09 19:00:00 --> Output Class Initialized
INFO - 2018-10-09 19:00:00 --> Security Class Initialized
DEBUG - 2018-10-09 19:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:00:00 --> CSRF cookie sent
INFO - 2018-10-09 19:00:00 --> Input Class Initialized
INFO - 2018-10-09 19:00:00 --> Language Class Initialized
INFO - 2018-10-09 19:00:00 --> Loader Class Initialized
INFO - 2018-10-09 19:00:00 --> Helper loaded: url_helper
INFO - 2018-10-09 19:00:00 --> Helper loaded: form_helper
INFO - 2018-10-09 19:00:00 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:00:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:00:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:00:00 --> User Agent Class Initialized
INFO - 2018-10-09 19:00:00 --> Controller Class Initialized
INFO - 2018-10-09 19:00:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 19:00:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 19:00:01 --> Pixel_Model class loaded
INFO - 2018-10-09 19:00:01 --> Database Driver Class Initialized
INFO - 2018-10-09 19:00:01 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:00:01 --> Database Driver Class Initialized
INFO - 2018-10-09 19:00:01 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:00:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 19:00:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 19:00:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 19:00:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 19:00:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 19:00:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 19:00:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-10-09 19:00:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 19:00:01 --> Final output sent to browser
DEBUG - 2018-10-09 19:00:01 --> Total execution time: 0.0433
INFO - 2018-10-09 19:00:03 --> Config Class Initialized
INFO - 2018-10-09 19:00:03 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:00:03 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:00:03 --> Utf8 Class Initialized
INFO - 2018-10-09 19:00:03 --> URI Class Initialized
INFO - 2018-10-09 19:00:03 --> Router Class Initialized
INFO - 2018-10-09 19:00:03 --> Output Class Initialized
INFO - 2018-10-09 19:00:03 --> Security Class Initialized
DEBUG - 2018-10-09 19:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:00:03 --> CSRF cookie sent
INFO - 2018-10-09 19:00:03 --> CSRF token verified
INFO - 2018-10-09 19:00:03 --> Input Class Initialized
INFO - 2018-10-09 19:00:03 --> Language Class Initialized
INFO - 2018-10-09 19:00:03 --> Loader Class Initialized
INFO - 2018-10-09 19:00:03 --> Helper loaded: url_helper
INFO - 2018-10-09 19:00:03 --> Helper loaded: form_helper
INFO - 2018-10-09 19:00:03 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:00:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:00:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:00:03 --> User Agent Class Initialized
INFO - 2018-10-09 19:00:03 --> Controller Class Initialized
INFO - 2018-10-09 19:00:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 19:00:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 19:00:03 --> Pixel_Model class loaded
INFO - 2018-10-09 19:00:03 --> Database Driver Class Initialized
INFO - 2018-10-09 19:00:03 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:00:03 --> Form Validation Class Initialized
INFO - 2018-10-09 19:00:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 19:00:03 --> Database Driver Class Initialized
INFO - 2018-10-09 19:00:03 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:00:03 --> Config Class Initialized
INFO - 2018-10-09 19:00:03 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:00:03 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:00:03 --> Utf8 Class Initialized
INFO - 2018-10-09 19:00:03 --> URI Class Initialized
INFO - 2018-10-09 19:00:03 --> Router Class Initialized
INFO - 2018-10-09 19:00:03 --> Output Class Initialized
INFO - 2018-10-09 19:00:03 --> Security Class Initialized
DEBUG - 2018-10-09 19:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:00:03 --> CSRF cookie sent
INFO - 2018-10-09 19:00:03 --> Input Class Initialized
INFO - 2018-10-09 19:00:03 --> Language Class Initialized
INFO - 2018-10-09 19:00:03 --> Loader Class Initialized
INFO - 2018-10-09 19:00:03 --> Helper loaded: url_helper
INFO - 2018-10-09 19:00:03 --> Helper loaded: form_helper
INFO - 2018-10-09 19:00:03 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:00:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:00:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:00:03 --> User Agent Class Initialized
INFO - 2018-10-09 19:00:03 --> Controller Class Initialized
INFO - 2018-10-09 19:00:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 19:00:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 19:00:03 --> Pixel_Model class loaded
INFO - 2018-10-09 19:00:03 --> Database Driver Class Initialized
INFO - 2018-10-09 19:00:03 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:00:03 --> Database Driver Class Initialized
INFO - 2018-10-09 19:00:03 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:00:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 19:00:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 19:00:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 19:00:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 19:00:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 19:00:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 19:00:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-10-09 19:00:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 19:00:03 --> Final output sent to browser
DEBUG - 2018-10-09 19:00:03 --> Total execution time: 0.0637
INFO - 2018-10-09 19:00:05 --> Config Class Initialized
INFO - 2018-10-09 19:00:05 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:00:05 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:00:05 --> Utf8 Class Initialized
INFO - 2018-10-09 19:00:05 --> URI Class Initialized
INFO - 2018-10-09 19:00:05 --> Router Class Initialized
INFO - 2018-10-09 19:00:05 --> Output Class Initialized
INFO - 2018-10-09 19:00:05 --> Security Class Initialized
DEBUG - 2018-10-09 19:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:00:05 --> CSRF cookie sent
INFO - 2018-10-09 19:00:05 --> CSRF token verified
INFO - 2018-10-09 19:00:05 --> Input Class Initialized
INFO - 2018-10-09 19:00:05 --> Language Class Initialized
INFO - 2018-10-09 19:00:05 --> Loader Class Initialized
INFO - 2018-10-09 19:00:05 --> Helper loaded: url_helper
INFO - 2018-10-09 19:00:05 --> Helper loaded: form_helper
INFO - 2018-10-09 19:00:05 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:00:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:00:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:00:05 --> User Agent Class Initialized
INFO - 2018-10-09 19:00:05 --> Controller Class Initialized
INFO - 2018-10-09 19:00:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 19:00:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 19:00:05 --> Pixel_Model class loaded
INFO - 2018-10-09 19:00:05 --> Database Driver Class Initialized
INFO - 2018-10-09 19:00:05 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:00:05 --> Form Validation Class Initialized
INFO - 2018-10-09 19:00:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 19:00:05 --> Database Driver Class Initialized
INFO - 2018-10-09 19:00:05 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:00:05 --> Config Class Initialized
INFO - 2018-10-09 19:00:05 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:00:05 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:00:05 --> Utf8 Class Initialized
INFO - 2018-10-09 19:00:05 --> URI Class Initialized
INFO - 2018-10-09 19:00:05 --> Router Class Initialized
INFO - 2018-10-09 19:00:05 --> Output Class Initialized
INFO - 2018-10-09 19:00:05 --> Security Class Initialized
DEBUG - 2018-10-09 19:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:00:05 --> CSRF cookie sent
INFO - 2018-10-09 19:00:05 --> Input Class Initialized
INFO - 2018-10-09 19:00:05 --> Language Class Initialized
INFO - 2018-10-09 19:00:05 --> Loader Class Initialized
INFO - 2018-10-09 19:00:05 --> Helper loaded: url_helper
INFO - 2018-10-09 19:00:05 --> Helper loaded: form_helper
INFO - 2018-10-09 19:00:05 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:00:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:00:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:00:05 --> User Agent Class Initialized
INFO - 2018-10-09 19:00:05 --> Controller Class Initialized
INFO - 2018-10-09 19:00:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 19:00:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 19:00:05 --> Pixel_Model class loaded
INFO - 2018-10-09 19:00:05 --> Database Driver Class Initialized
INFO - 2018-10-09 19:00:05 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:00:05 --> Database Driver Class Initialized
INFO - 2018-10-09 19:00:05 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:00:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 19:00:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 19:00:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 19:00:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 19:00:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 19:00:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 19:00:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_owner.php
INFO - 2018-10-09 19:00:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 19:00:05 --> Final output sent to browser
DEBUG - 2018-10-09 19:00:05 --> Total execution time: 0.0514
INFO - 2018-10-09 19:00:06 --> Config Class Initialized
INFO - 2018-10-09 19:00:06 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:00:06 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:00:06 --> Utf8 Class Initialized
INFO - 2018-10-09 19:00:06 --> URI Class Initialized
INFO - 2018-10-09 19:00:06 --> Router Class Initialized
INFO - 2018-10-09 19:00:06 --> Output Class Initialized
INFO - 2018-10-09 19:00:06 --> Security Class Initialized
DEBUG - 2018-10-09 19:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:00:06 --> CSRF cookie sent
INFO - 2018-10-09 19:00:06 --> CSRF token verified
INFO - 2018-10-09 19:00:06 --> Input Class Initialized
INFO - 2018-10-09 19:00:06 --> Language Class Initialized
INFO - 2018-10-09 19:00:06 --> Loader Class Initialized
INFO - 2018-10-09 19:00:06 --> Helper loaded: url_helper
INFO - 2018-10-09 19:00:06 --> Helper loaded: form_helper
INFO - 2018-10-09 19:00:06 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:00:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:00:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:00:06 --> User Agent Class Initialized
INFO - 2018-10-09 19:00:06 --> Controller Class Initialized
INFO - 2018-10-09 19:00:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 19:00:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 19:00:06 --> Pixel_Model class loaded
INFO - 2018-10-09 19:00:06 --> Database Driver Class Initialized
INFO - 2018-10-09 19:00:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:00:06 --> Form Validation Class Initialized
INFO - 2018-10-09 19:00:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 19:00:06 --> Database Driver Class Initialized
INFO - 2018-10-09 19:00:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:00:07 --> Config Class Initialized
INFO - 2018-10-09 19:00:07 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:00:07 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:00:07 --> Utf8 Class Initialized
INFO - 2018-10-09 19:00:07 --> URI Class Initialized
INFO - 2018-10-09 19:00:07 --> Router Class Initialized
INFO - 2018-10-09 19:00:07 --> Output Class Initialized
INFO - 2018-10-09 19:00:07 --> Security Class Initialized
DEBUG - 2018-10-09 19:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:00:07 --> CSRF cookie sent
INFO - 2018-10-09 19:00:07 --> Input Class Initialized
INFO - 2018-10-09 19:00:07 --> Language Class Initialized
INFO - 2018-10-09 19:00:07 --> Loader Class Initialized
INFO - 2018-10-09 19:00:07 --> Helper loaded: url_helper
INFO - 2018-10-09 19:00:07 --> Helper loaded: form_helper
INFO - 2018-10-09 19:00:07 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:00:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:00:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:00:07 --> User Agent Class Initialized
INFO - 2018-10-09 19:00:07 --> Controller Class Initialized
INFO - 2018-10-09 19:00:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 19:00:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 19:00:07 --> Pixel_Model class loaded
INFO - 2018-10-09 19:00:07 --> Database Driver Class Initialized
INFO - 2018-10-09 19:00:07 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:00:07 --> Database Driver Class Initialized
INFO - 2018-10-09 19:00:07 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:00:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 19:00:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 19:00:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 19:00:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 19:00:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 19:00:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 19:00:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_value.php
INFO - 2018-10-09 19:00:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 19:00:07 --> Final output sent to browser
DEBUG - 2018-10-09 19:00:07 --> Total execution time: 0.0447
INFO - 2018-10-09 19:00:12 --> Config Class Initialized
INFO - 2018-10-09 19:00:12 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:00:12 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:00:12 --> Utf8 Class Initialized
INFO - 2018-10-09 19:00:12 --> URI Class Initialized
INFO - 2018-10-09 19:00:12 --> Router Class Initialized
INFO - 2018-10-09 19:00:12 --> Output Class Initialized
INFO - 2018-10-09 19:00:12 --> Security Class Initialized
DEBUG - 2018-10-09 19:00:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:00:12 --> CSRF cookie sent
INFO - 2018-10-09 19:00:12 --> CSRF token verified
INFO - 2018-10-09 19:00:12 --> Input Class Initialized
INFO - 2018-10-09 19:00:12 --> Language Class Initialized
INFO - 2018-10-09 19:00:12 --> Loader Class Initialized
INFO - 2018-10-09 19:00:12 --> Helper loaded: url_helper
INFO - 2018-10-09 19:00:12 --> Helper loaded: form_helper
INFO - 2018-10-09 19:00:12 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:00:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:00:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:00:12 --> User Agent Class Initialized
INFO - 2018-10-09 19:00:12 --> Controller Class Initialized
INFO - 2018-10-09 19:00:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 19:00:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 19:00:12 --> Pixel_Model class loaded
INFO - 2018-10-09 19:00:12 --> Database Driver Class Initialized
INFO - 2018-10-09 19:00:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:00:12 --> Form Validation Class Initialized
INFO - 2018-10-09 19:00:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 19:00:12 --> Database Driver Class Initialized
INFO - 2018-10-09 19:00:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:00:12 --> Config Class Initialized
INFO - 2018-10-09 19:00:12 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:00:12 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:00:12 --> Utf8 Class Initialized
INFO - 2018-10-09 19:00:12 --> URI Class Initialized
INFO - 2018-10-09 19:00:12 --> Router Class Initialized
INFO - 2018-10-09 19:00:12 --> Output Class Initialized
INFO - 2018-10-09 19:00:12 --> Security Class Initialized
DEBUG - 2018-10-09 19:00:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:00:12 --> CSRF cookie sent
INFO - 2018-10-09 19:00:12 --> Input Class Initialized
INFO - 2018-10-09 19:00:12 --> Language Class Initialized
INFO - 2018-10-09 19:00:12 --> Loader Class Initialized
INFO - 2018-10-09 19:00:12 --> Helper loaded: url_helper
INFO - 2018-10-09 19:00:12 --> Helper loaded: form_helper
INFO - 2018-10-09 19:00:12 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:00:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:00:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:00:12 --> User Agent Class Initialized
INFO - 2018-10-09 19:00:12 --> Controller Class Initialized
INFO - 2018-10-09 19:00:12 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 19:00:12 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 19:00:12 --> Pixel_Model class loaded
INFO - 2018-10-09 19:00:12 --> Database Driver Class Initialized
INFO - 2018-10-09 19:00:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:00:12 --> Database Driver Class Initialized
INFO - 2018-10-09 19:00:12 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:00:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 19:00:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 19:00:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 19:00:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 19:00:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 19:00:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 19:00:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/merriage_home_title.php
INFO - 2018-10-09 19:00:12 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 19:00:12 --> Final output sent to browser
DEBUG - 2018-10-09 19:00:12 --> Total execution time: 0.0456
INFO - 2018-10-09 19:00:15 --> Config Class Initialized
INFO - 2018-10-09 19:00:15 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:00:15 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:00:15 --> Utf8 Class Initialized
INFO - 2018-10-09 19:00:15 --> URI Class Initialized
INFO - 2018-10-09 19:00:15 --> Router Class Initialized
INFO - 2018-10-09 19:00:15 --> Output Class Initialized
INFO - 2018-10-09 19:00:15 --> Security Class Initialized
DEBUG - 2018-10-09 19:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:00:15 --> CSRF cookie sent
INFO - 2018-10-09 19:00:15 --> CSRF token verified
INFO - 2018-10-09 19:00:15 --> Input Class Initialized
INFO - 2018-10-09 19:00:15 --> Language Class Initialized
INFO - 2018-10-09 19:00:15 --> Loader Class Initialized
INFO - 2018-10-09 19:00:15 --> Helper loaded: url_helper
INFO - 2018-10-09 19:00:15 --> Helper loaded: form_helper
INFO - 2018-10-09 19:00:15 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:00:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:00:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:00:15 --> User Agent Class Initialized
INFO - 2018-10-09 19:00:15 --> Controller Class Initialized
INFO - 2018-10-09 19:00:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 19:00:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 19:00:15 --> Pixel_Model class loaded
INFO - 2018-10-09 19:00:15 --> Database Driver Class Initialized
INFO - 2018-10-09 19:00:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:00:15 --> Form Validation Class Initialized
INFO - 2018-10-09 19:00:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 19:00:15 --> Database Driver Class Initialized
INFO - 2018-10-09 19:00:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:00:15 --> Config Class Initialized
INFO - 2018-10-09 19:00:15 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:00:15 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:00:15 --> Utf8 Class Initialized
INFO - 2018-10-09 19:00:15 --> URI Class Initialized
INFO - 2018-10-09 19:00:15 --> Router Class Initialized
INFO - 2018-10-09 19:00:15 --> Output Class Initialized
INFO - 2018-10-09 19:00:15 --> Security Class Initialized
DEBUG - 2018-10-09 19:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:00:15 --> CSRF cookie sent
INFO - 2018-10-09 19:00:15 --> Input Class Initialized
INFO - 2018-10-09 19:00:15 --> Language Class Initialized
INFO - 2018-10-09 19:00:15 --> Loader Class Initialized
INFO - 2018-10-09 19:00:15 --> Helper loaded: url_helper
INFO - 2018-10-09 19:00:15 --> Helper loaded: form_helper
INFO - 2018-10-09 19:00:15 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:00:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:00:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:00:15 --> User Agent Class Initialized
INFO - 2018-10-09 19:00:15 --> Controller Class Initialized
INFO - 2018-10-09 19:00:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 19:00:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 19:00:15 --> Pixel_Model class loaded
INFO - 2018-10-09 19:00:15 --> Database Driver Class Initialized
INFO - 2018-10-09 19:00:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:00:15 --> Database Driver Class Initialized
INFO - 2018-10-09 19:00:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:00:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 19:00:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 19:00:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 19:00:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 19:00:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 19:00:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 19:00:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-10-09 19:00:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 19:00:15 --> Final output sent to browser
DEBUG - 2018-10-09 19:00:15 --> Total execution time: 0.0400
INFO - 2018-10-09 19:00:16 --> Config Class Initialized
INFO - 2018-10-09 19:00:16 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:00:16 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:00:16 --> Utf8 Class Initialized
INFO - 2018-10-09 19:00:16 --> URI Class Initialized
INFO - 2018-10-09 19:00:16 --> Router Class Initialized
INFO - 2018-10-09 19:00:16 --> Output Class Initialized
INFO - 2018-10-09 19:00:16 --> Security Class Initialized
DEBUG - 2018-10-09 19:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:00:16 --> CSRF cookie sent
INFO - 2018-10-09 19:00:16 --> CSRF token verified
INFO - 2018-10-09 19:00:16 --> Input Class Initialized
INFO - 2018-10-09 19:00:16 --> Language Class Initialized
INFO - 2018-10-09 19:00:16 --> Loader Class Initialized
INFO - 2018-10-09 19:00:16 --> Helper loaded: url_helper
INFO - 2018-10-09 19:00:16 --> Helper loaded: form_helper
INFO - 2018-10-09 19:00:16 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:00:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:00:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:00:16 --> User Agent Class Initialized
INFO - 2018-10-09 19:00:16 --> Controller Class Initialized
INFO - 2018-10-09 19:00:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 19:00:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 19:00:16 --> Pixel_Model class loaded
INFO - 2018-10-09 19:00:16 --> Database Driver Class Initialized
INFO - 2018-10-09 19:00:16 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:00:16 --> Form Validation Class Initialized
INFO - 2018-10-09 19:00:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 19:00:16 --> Database Driver Class Initialized
INFO - 2018-10-09 19:00:16 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:00:16 --> Config Class Initialized
INFO - 2018-10-09 19:00:16 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:00:16 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:00:16 --> Utf8 Class Initialized
INFO - 2018-10-09 19:00:16 --> URI Class Initialized
INFO - 2018-10-09 19:00:16 --> Router Class Initialized
INFO - 2018-10-09 19:00:16 --> Output Class Initialized
INFO - 2018-10-09 19:00:16 --> Security Class Initialized
DEBUG - 2018-10-09 19:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:00:16 --> CSRF cookie sent
INFO - 2018-10-09 19:00:16 --> Input Class Initialized
INFO - 2018-10-09 19:00:16 --> Language Class Initialized
INFO - 2018-10-09 19:00:16 --> Loader Class Initialized
INFO - 2018-10-09 19:00:16 --> Helper loaded: url_helper
INFO - 2018-10-09 19:00:16 --> Helper loaded: form_helper
INFO - 2018-10-09 19:00:16 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:00:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:00:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:00:16 --> User Agent Class Initialized
INFO - 2018-10-09 19:00:16 --> Controller Class Initialized
INFO - 2018-10-09 19:00:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 19:00:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 19:00:16 --> Pixel_Model class loaded
INFO - 2018-10-09 19:00:16 --> Database Driver Class Initialized
INFO - 2018-10-09 19:00:16 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:00:16 --> Database Driver Class Initialized
INFO - 2018-10-09 19:00:16 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:00:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 19:00:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 19:00:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 19:00:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 19:00:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-10-09 19:00:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 19:00:16 --> Final output sent to browser
DEBUG - 2018-10-09 19:00:16 --> Total execution time: 0.0596
INFO - 2018-10-09 19:03:51 --> Config Class Initialized
INFO - 2018-10-09 19:03:51 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:03:51 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:03:51 --> Utf8 Class Initialized
INFO - 2018-10-09 19:03:51 --> URI Class Initialized
INFO - 2018-10-09 19:03:51 --> Router Class Initialized
INFO - 2018-10-09 19:03:51 --> Output Class Initialized
INFO - 2018-10-09 19:03:51 --> Security Class Initialized
DEBUG - 2018-10-09 19:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:03:51 --> CSRF cookie sent
INFO - 2018-10-09 19:03:51 --> Input Class Initialized
INFO - 2018-10-09 19:03:51 --> Language Class Initialized
INFO - 2018-10-09 19:03:51 --> Loader Class Initialized
INFO - 2018-10-09 19:03:51 --> Helper loaded: url_helper
INFO - 2018-10-09 19:03:51 --> Helper loaded: form_helper
INFO - 2018-10-09 19:03:51 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:03:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:03:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:03:51 --> User Agent Class Initialized
INFO - 2018-10-09 19:03:51 --> Controller Class Initialized
INFO - 2018-10-09 19:03:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 19:03:51 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 19:03:51 --> Pixel_Model class loaded
INFO - 2018-10-09 19:03:51 --> Database Driver Class Initialized
INFO - 2018-10-09 19:03:51 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:03:51 --> Config Class Initialized
INFO - 2018-10-09 19:03:51 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:03:51 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:03:51 --> Utf8 Class Initialized
INFO - 2018-10-09 19:03:51 --> URI Class Initialized
INFO - 2018-10-09 19:03:51 --> Router Class Initialized
INFO - 2018-10-09 19:03:51 --> Output Class Initialized
INFO - 2018-10-09 19:03:51 --> Security Class Initialized
DEBUG - 2018-10-09 19:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:03:51 --> CSRF cookie sent
INFO - 2018-10-09 19:03:51 --> Input Class Initialized
INFO - 2018-10-09 19:03:51 --> Language Class Initialized
INFO - 2018-10-09 19:03:51 --> Loader Class Initialized
INFO - 2018-10-09 19:03:51 --> Helper loaded: url_helper
INFO - 2018-10-09 19:03:51 --> Helper loaded: form_helper
INFO - 2018-10-09 19:03:51 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:03:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:03:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:03:51 --> User Agent Class Initialized
INFO - 2018-10-09 19:03:51 --> Controller Class Initialized
INFO - 2018-10-09 19:03:51 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 19:03:51 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-09 19:03:51 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-10-09 19:03:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 19:03:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 19:03:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 19:03:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-10-09 19:03:51 --> Could not find the language line "req_email"
INFO - 2018-10-09 19:03:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-10-09 19:03:51 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 19:03:51 --> Final output sent to browser
DEBUG - 2018-10-09 19:03:51 --> Total execution time: 0.0228
INFO - 2018-10-09 19:03:55 --> Config Class Initialized
INFO - 2018-10-09 19:03:55 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:03:55 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:03:55 --> Utf8 Class Initialized
INFO - 2018-10-09 19:03:55 --> URI Class Initialized
INFO - 2018-10-09 19:03:55 --> Router Class Initialized
INFO - 2018-10-09 19:03:55 --> Output Class Initialized
INFO - 2018-10-09 19:03:55 --> Security Class Initialized
DEBUG - 2018-10-09 19:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:03:55 --> CSRF cookie sent
INFO - 2018-10-09 19:03:55 --> Input Class Initialized
INFO - 2018-10-09 19:03:55 --> Language Class Initialized
INFO - 2018-10-09 19:03:55 --> Loader Class Initialized
INFO - 2018-10-09 19:03:55 --> Helper loaded: url_helper
INFO - 2018-10-09 19:03:55 --> Helper loaded: form_helper
INFO - 2018-10-09 19:03:55 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:03:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:03:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:03:55 --> User Agent Class Initialized
INFO - 2018-10-09 19:03:55 --> Controller Class Initialized
INFO - 2018-10-09 19:03:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 19:03:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 19:03:55 --> Pixel_Model class loaded
INFO - 2018-10-09 19:03:55 --> Database Driver Class Initialized
INFO - 2018-10-09 19:03:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:03:55 --> Database Driver Class Initialized
INFO - 2018-10-09 19:03:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:03:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 19:03:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 19:03:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 19:03:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 19:03:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-10-09 19:03:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 19:03:55 --> Final output sent to browser
DEBUG - 2018-10-09 19:03:55 --> Total execution time: 0.0621
INFO - 2018-10-09 19:03:56 --> Config Class Initialized
INFO - 2018-10-09 19:03:56 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:03:56 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:03:56 --> Utf8 Class Initialized
INFO - 2018-10-09 19:03:56 --> URI Class Initialized
INFO - 2018-10-09 19:03:56 --> Router Class Initialized
INFO - 2018-10-09 19:03:56 --> Output Class Initialized
INFO - 2018-10-09 19:03:56 --> Security Class Initialized
DEBUG - 2018-10-09 19:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:03:56 --> CSRF cookie sent
INFO - 2018-10-09 19:03:56 --> Input Class Initialized
INFO - 2018-10-09 19:03:56 --> Language Class Initialized
INFO - 2018-10-09 19:03:56 --> Loader Class Initialized
INFO - 2018-10-09 19:03:56 --> Helper loaded: url_helper
INFO - 2018-10-09 19:03:56 --> Helper loaded: form_helper
INFO - 2018-10-09 19:03:56 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:03:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:03:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:03:56 --> User Agent Class Initialized
INFO - 2018-10-09 19:03:56 --> Controller Class Initialized
INFO - 2018-10-09 19:03:56 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 19:03:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 19:03:56 --> Pixel_Model class loaded
INFO - 2018-10-09 19:03:56 --> Database Driver Class Initialized
INFO - 2018-10-09 19:03:56 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:03:56 --> Database Driver Class Initialized
INFO - 2018-10-09 19:03:56 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:03:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 19:03:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 19:03:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 19:03:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 19:03:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 19:03:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 19:03:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-10-09 19:03:56 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 19:03:56 --> Final output sent to browser
DEBUG - 2018-10-09 19:03:56 --> Total execution time: 0.0614
INFO - 2018-10-09 19:03:58 --> Config Class Initialized
INFO - 2018-10-09 19:03:58 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:03:58 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:03:58 --> Utf8 Class Initialized
INFO - 2018-10-09 19:03:58 --> URI Class Initialized
INFO - 2018-10-09 19:03:58 --> Router Class Initialized
INFO - 2018-10-09 19:03:58 --> Output Class Initialized
INFO - 2018-10-09 19:03:58 --> Security Class Initialized
DEBUG - 2018-10-09 19:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:03:58 --> CSRF cookie sent
INFO - 2018-10-09 19:03:58 --> Input Class Initialized
INFO - 2018-10-09 19:03:58 --> Language Class Initialized
INFO - 2018-10-09 19:03:58 --> Loader Class Initialized
INFO - 2018-10-09 19:03:58 --> Helper loaded: url_helper
INFO - 2018-10-09 19:03:58 --> Helper loaded: form_helper
INFO - 2018-10-09 19:03:58 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:03:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:03:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:03:58 --> User Agent Class Initialized
INFO - 2018-10-09 19:03:58 --> Controller Class Initialized
INFO - 2018-10-09 19:03:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 19:03:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 19:03:58 --> Pixel_Model class loaded
INFO - 2018-10-09 19:03:58 --> Database Driver Class Initialized
INFO - 2018-10-09 19:03:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:03:58 --> Database Driver Class Initialized
INFO - 2018-10-09 19:03:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:03:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 19:03:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 19:03:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 19:03:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 19:03:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 19:03:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 19:03:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/merriage_home_title.php
INFO - 2018-10-09 19:03:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 19:03:58 --> Final output sent to browser
DEBUG - 2018-10-09 19:03:58 --> Total execution time: 0.0476
INFO - 2018-10-09 19:03:59 --> Config Class Initialized
INFO - 2018-10-09 19:03:59 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:03:59 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:03:59 --> Utf8 Class Initialized
INFO - 2018-10-09 19:03:59 --> URI Class Initialized
INFO - 2018-10-09 19:03:59 --> Router Class Initialized
INFO - 2018-10-09 19:03:59 --> Output Class Initialized
INFO - 2018-10-09 19:03:59 --> Security Class Initialized
DEBUG - 2018-10-09 19:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:03:59 --> CSRF cookie sent
INFO - 2018-10-09 19:03:59 --> Input Class Initialized
INFO - 2018-10-09 19:03:59 --> Language Class Initialized
INFO - 2018-10-09 19:03:59 --> Loader Class Initialized
INFO - 2018-10-09 19:03:59 --> Helper loaded: url_helper
INFO - 2018-10-09 19:03:59 --> Helper loaded: form_helper
INFO - 2018-10-09 19:03:59 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:03:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:03:59 --> User Agent Class Initialized
INFO - 2018-10-09 19:03:59 --> Controller Class Initialized
INFO - 2018-10-09 19:03:59 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 19:03:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 19:03:59 --> Pixel_Model class loaded
INFO - 2018-10-09 19:03:59 --> Database Driver Class Initialized
INFO - 2018-10-09 19:03:59 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:03:59 --> Database Driver Class Initialized
INFO - 2018-10-09 19:03:59 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:03:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 19:03:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 19:03:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 19:03:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 19:03:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 19:03:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 19:03:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_value.php
INFO - 2018-10-09 19:03:59 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 19:03:59 --> Final output sent to browser
DEBUG - 2018-10-09 19:03:59 --> Total execution time: 0.0477
INFO - 2018-10-09 19:04:01 --> Config Class Initialized
INFO - 2018-10-09 19:04:01 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:04:01 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:04:01 --> Utf8 Class Initialized
INFO - 2018-10-09 19:04:01 --> URI Class Initialized
INFO - 2018-10-09 19:04:01 --> Router Class Initialized
INFO - 2018-10-09 19:04:01 --> Output Class Initialized
INFO - 2018-10-09 19:04:01 --> Security Class Initialized
DEBUG - 2018-10-09 19:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:04:01 --> CSRF cookie sent
INFO - 2018-10-09 19:04:01 --> Input Class Initialized
INFO - 2018-10-09 19:04:01 --> Language Class Initialized
INFO - 2018-10-09 19:04:01 --> Loader Class Initialized
INFO - 2018-10-09 19:04:01 --> Helper loaded: url_helper
INFO - 2018-10-09 19:04:01 --> Helper loaded: form_helper
INFO - 2018-10-09 19:04:01 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:04:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:04:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:04:01 --> User Agent Class Initialized
INFO - 2018-10-09 19:04:01 --> Controller Class Initialized
INFO - 2018-10-09 19:04:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 19:04:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 19:04:01 --> Pixel_Model class loaded
INFO - 2018-10-09 19:04:01 --> Database Driver Class Initialized
INFO - 2018-10-09 19:04:01 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:04:01 --> Database Driver Class Initialized
INFO - 2018-10-09 19:04:01 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:04:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 19:04:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 19:04:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 19:04:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 19:04:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 19:04:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 19:04:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_owner.php
INFO - 2018-10-09 19:04:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 19:04:01 --> Final output sent to browser
DEBUG - 2018-10-09 19:04:01 --> Total execution time: 0.0530
INFO - 2018-10-09 19:04:03 --> Config Class Initialized
INFO - 2018-10-09 19:04:03 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:04:03 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:04:03 --> Utf8 Class Initialized
INFO - 2018-10-09 19:04:03 --> URI Class Initialized
INFO - 2018-10-09 19:04:03 --> Router Class Initialized
INFO - 2018-10-09 19:04:03 --> Output Class Initialized
INFO - 2018-10-09 19:04:03 --> Security Class Initialized
DEBUG - 2018-10-09 19:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:04:03 --> CSRF cookie sent
INFO - 2018-10-09 19:04:03 --> Input Class Initialized
INFO - 2018-10-09 19:04:03 --> Language Class Initialized
INFO - 2018-10-09 19:04:03 --> Loader Class Initialized
INFO - 2018-10-09 19:04:03 --> Helper loaded: url_helper
INFO - 2018-10-09 19:04:03 --> Helper loaded: form_helper
INFO - 2018-10-09 19:04:03 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:04:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:04:03 --> User Agent Class Initialized
INFO - 2018-10-09 19:04:03 --> Controller Class Initialized
INFO - 2018-10-09 19:04:03 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 19:04:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 19:04:03 --> Pixel_Model class loaded
INFO - 2018-10-09 19:04:03 --> Database Driver Class Initialized
INFO - 2018-10-09 19:04:03 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:04:03 --> Database Driver Class Initialized
INFO - 2018-10-09 19:04:03 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:04:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 19:04:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 19:04:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 19:04:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 19:04:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 19:04:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 19:04:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance_maintained.php
INFO - 2018-10-09 19:04:03 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 19:04:03 --> Final output sent to browser
DEBUG - 2018-10-09 19:04:03 --> Total execution time: 0.0507
INFO - 2018-10-09 19:04:04 --> Config Class Initialized
INFO - 2018-10-09 19:04:04 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:04:04 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:04:04 --> Utf8 Class Initialized
INFO - 2018-10-09 19:04:04 --> URI Class Initialized
INFO - 2018-10-09 19:04:04 --> Router Class Initialized
INFO - 2018-10-09 19:04:04 --> Output Class Initialized
INFO - 2018-10-09 19:04:04 --> Security Class Initialized
DEBUG - 2018-10-09 19:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:04:04 --> CSRF cookie sent
INFO - 2018-10-09 19:04:04 --> Input Class Initialized
INFO - 2018-10-09 19:04:04 --> Language Class Initialized
INFO - 2018-10-09 19:04:04 --> Loader Class Initialized
INFO - 2018-10-09 19:04:04 --> Helper loaded: url_helper
INFO - 2018-10-09 19:04:04 --> Helper loaded: form_helper
INFO - 2018-10-09 19:04:04 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:04:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:04:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:04:04 --> User Agent Class Initialized
INFO - 2018-10-09 19:04:04 --> Controller Class Initialized
INFO - 2018-10-09 19:04:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 19:04:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 19:04:04 --> Pixel_Model class loaded
INFO - 2018-10-09 19:04:04 --> Database Driver Class Initialized
INFO - 2018-10-09 19:04:04 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:04:04 --> Database Driver Class Initialized
INFO - 2018-10-09 19:04:04 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:04:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 19:04:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 19:04:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 19:04:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 19:04:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 19:04:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 19:04:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/inheritance.php
INFO - 2018-10-09 19:04:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 19:04:04 --> Final output sent to browser
DEBUG - 2018-10-09 19:04:04 --> Total execution time: 0.0450
INFO - 2018-10-09 19:04:06 --> Config Class Initialized
INFO - 2018-10-09 19:04:06 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:04:06 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:04:06 --> Utf8 Class Initialized
INFO - 2018-10-09 19:04:06 --> URI Class Initialized
INFO - 2018-10-09 19:04:06 --> Router Class Initialized
INFO - 2018-10-09 19:04:06 --> Output Class Initialized
INFO - 2018-10-09 19:04:06 --> Security Class Initialized
DEBUG - 2018-10-09 19:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:04:06 --> CSRF cookie sent
INFO - 2018-10-09 19:04:06 --> Input Class Initialized
INFO - 2018-10-09 19:04:06 --> Language Class Initialized
INFO - 2018-10-09 19:04:06 --> Loader Class Initialized
INFO - 2018-10-09 19:04:06 --> Helper loaded: url_helper
INFO - 2018-10-09 19:04:06 --> Helper loaded: form_helper
INFO - 2018-10-09 19:04:06 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:04:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:04:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:04:06 --> User Agent Class Initialized
INFO - 2018-10-09 19:04:06 --> Controller Class Initialized
INFO - 2018-10-09 19:04:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 19:04:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 19:04:06 --> Pixel_Model class loaded
INFO - 2018-10-09 19:04:06 --> Database Driver Class Initialized
INFO - 2018-10-09 19:04:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:04:06 --> Database Driver Class Initialized
INFO - 2018-10-09 19:04:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:04:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 19:04:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 19:04:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 19:04:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 19:04:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 19:04:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 19:04:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-10-09 19:04:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 19:04:06 --> Final output sent to browser
DEBUG - 2018-10-09 19:04:06 --> Total execution time: 0.0452
INFO - 2018-10-09 19:04:08 --> Config Class Initialized
INFO - 2018-10-09 19:04:08 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:04:08 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:04:08 --> Utf8 Class Initialized
INFO - 2018-10-09 19:04:08 --> URI Class Initialized
INFO - 2018-10-09 19:04:08 --> Router Class Initialized
INFO - 2018-10-09 19:04:08 --> Output Class Initialized
INFO - 2018-10-09 19:04:08 --> Security Class Initialized
DEBUG - 2018-10-09 19:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:04:08 --> CSRF cookie sent
INFO - 2018-10-09 19:04:08 --> Input Class Initialized
INFO - 2018-10-09 19:04:08 --> Language Class Initialized
INFO - 2018-10-09 19:04:08 --> Loader Class Initialized
INFO - 2018-10-09 19:04:08 --> Helper loaded: url_helper
INFO - 2018-10-09 19:04:08 --> Helper loaded: form_helper
INFO - 2018-10-09 19:04:08 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:04:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:04:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:04:08 --> User Agent Class Initialized
INFO - 2018-10-09 19:04:08 --> Controller Class Initialized
INFO - 2018-10-09 19:04:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 19:04:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 19:04:08 --> Pixel_Model class loaded
INFO - 2018-10-09 19:04:08 --> Database Driver Class Initialized
INFO - 2018-10-09 19:04:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:04:08 --> Database Driver Class Initialized
INFO - 2018-10-09 19:04:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:04:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 19:04:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 19:04:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 19:04:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 19:04:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 19:04:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 19:04:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-10-09 19:04:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 19:04:08 --> Final output sent to browser
DEBUG - 2018-10-09 19:04:08 --> Total execution time: 0.0389
INFO - 2018-10-09 19:04:13 --> Config Class Initialized
INFO - 2018-10-09 19:04:13 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:04:13 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:04:13 --> Utf8 Class Initialized
INFO - 2018-10-09 19:04:13 --> URI Class Initialized
INFO - 2018-10-09 19:04:13 --> Router Class Initialized
INFO - 2018-10-09 19:04:13 --> Output Class Initialized
INFO - 2018-10-09 19:04:13 --> Security Class Initialized
DEBUG - 2018-10-09 19:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:04:13 --> CSRF cookie sent
INFO - 2018-10-09 19:04:13 --> CSRF token verified
INFO - 2018-10-09 19:04:13 --> Input Class Initialized
INFO - 2018-10-09 19:04:13 --> Language Class Initialized
INFO - 2018-10-09 19:04:13 --> Loader Class Initialized
INFO - 2018-10-09 19:04:13 --> Helper loaded: url_helper
INFO - 2018-10-09 19:04:13 --> Helper loaded: form_helper
INFO - 2018-10-09 19:04:13 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:04:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:04:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:04:13 --> User Agent Class Initialized
INFO - 2018-10-09 19:04:13 --> Controller Class Initialized
INFO - 2018-10-09 19:04:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 19:04:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 19:04:13 --> Pixel_Model class loaded
INFO - 2018-10-09 19:04:13 --> Database Driver Class Initialized
INFO - 2018-10-09 19:04:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:04:13 --> Form Validation Class Initialized
INFO - 2018-10-09 19:04:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 19:04:13 --> Database Driver Class Initialized
INFO - 2018-10-09 19:04:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:04:13 --> Config Class Initialized
INFO - 2018-10-09 19:04:13 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:04:13 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:04:13 --> Utf8 Class Initialized
INFO - 2018-10-09 19:04:13 --> URI Class Initialized
INFO - 2018-10-09 19:04:13 --> Router Class Initialized
INFO - 2018-10-09 19:04:13 --> Output Class Initialized
INFO - 2018-10-09 19:04:13 --> Security Class Initialized
DEBUG - 2018-10-09 19:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:04:13 --> CSRF cookie sent
INFO - 2018-10-09 19:04:13 --> Input Class Initialized
INFO - 2018-10-09 19:04:13 --> Language Class Initialized
INFO - 2018-10-09 19:04:13 --> Loader Class Initialized
INFO - 2018-10-09 19:04:13 --> Helper loaded: url_helper
INFO - 2018-10-09 19:04:13 --> Helper loaded: form_helper
INFO - 2018-10-09 19:04:13 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:04:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:04:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:04:13 --> User Agent Class Initialized
INFO - 2018-10-09 19:04:13 --> Controller Class Initialized
INFO - 2018-10-09 19:04:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 19:04:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 19:04:13 --> Pixel_Model class loaded
INFO - 2018-10-09 19:04:13 --> Database Driver Class Initialized
INFO - 2018-10-09 19:04:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:04:13 --> Database Driver Class Initialized
INFO - 2018-10-09 19:04:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:04:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 19:04:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 19:04:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 19:04:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 19:04:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 19:04:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 19:04:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-10-09 19:04:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 19:04:13 --> Final output sent to browser
DEBUG - 2018-10-09 19:04:13 --> Total execution time: 0.0442
INFO - 2018-10-09 19:04:14 --> Config Class Initialized
INFO - 2018-10-09 19:04:14 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:04:14 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:04:14 --> Utf8 Class Initialized
INFO - 2018-10-09 19:04:14 --> URI Class Initialized
INFO - 2018-10-09 19:04:14 --> Router Class Initialized
INFO - 2018-10-09 19:04:14 --> Output Class Initialized
INFO - 2018-10-09 19:04:14 --> Security Class Initialized
DEBUG - 2018-10-09 19:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:04:14 --> CSRF cookie sent
INFO - 2018-10-09 19:04:14 --> Input Class Initialized
INFO - 2018-10-09 19:04:14 --> Language Class Initialized
INFO - 2018-10-09 19:04:14 --> Loader Class Initialized
INFO - 2018-10-09 19:04:14 --> Helper loaded: url_helper
INFO - 2018-10-09 19:04:14 --> Helper loaded: form_helper
INFO - 2018-10-09 19:04:14 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:04:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:04:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:04:14 --> User Agent Class Initialized
INFO - 2018-10-09 19:04:14 --> Controller Class Initialized
INFO - 2018-10-09 19:04:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 19:04:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 19:04:14 --> Pixel_Model class loaded
INFO - 2018-10-09 19:04:14 --> Database Driver Class Initialized
INFO - 2018-10-09 19:04:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:04:14 --> Database Driver Class Initialized
INFO - 2018-10-09 19:04:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:04:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 19:04:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 19:04:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 19:04:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 19:04:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-10-09 19:04:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 19:04:14 --> Final output sent to browser
DEBUG - 2018-10-09 19:04:14 --> Total execution time: 0.0640
INFO - 2018-10-09 19:04:22 --> Config Class Initialized
INFO - 2018-10-09 19:04:22 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:04:22 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:04:22 --> Utf8 Class Initialized
INFO - 2018-10-09 19:04:22 --> URI Class Initialized
INFO - 2018-10-09 19:04:22 --> Router Class Initialized
INFO - 2018-10-09 19:04:22 --> Output Class Initialized
INFO - 2018-10-09 19:04:22 --> Security Class Initialized
DEBUG - 2018-10-09 19:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:04:22 --> CSRF cookie sent
INFO - 2018-10-09 19:04:22 --> Input Class Initialized
INFO - 2018-10-09 19:04:22 --> Language Class Initialized
INFO - 2018-10-09 19:04:22 --> Loader Class Initialized
INFO - 2018-10-09 19:04:22 --> Helper loaded: url_helper
INFO - 2018-10-09 19:04:22 --> Helper loaded: form_helper
INFO - 2018-10-09 19:04:22 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:04:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:04:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:04:22 --> User Agent Class Initialized
INFO - 2018-10-09 19:04:22 --> Controller Class Initialized
INFO - 2018-10-09 19:04:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 19:04:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 19:04:22 --> Pixel_Model class loaded
INFO - 2018-10-09 19:04:22 --> Database Driver Class Initialized
INFO - 2018-10-09 19:04:22 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:04:22 --> Database Driver Class Initialized
INFO - 2018-10-09 19:04:22 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:04:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 19:04:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 19:04:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 19:04:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 19:04:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 19:04:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 19:04:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-10-09 19:04:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 19:04:22 --> Final output sent to browser
DEBUG - 2018-10-09 19:04:22 --> Total execution time: 0.0468
INFO - 2018-10-09 19:04:23 --> Config Class Initialized
INFO - 2018-10-09 19:04:23 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:04:23 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:04:23 --> Utf8 Class Initialized
INFO - 2018-10-09 19:04:23 --> URI Class Initialized
INFO - 2018-10-09 19:04:23 --> Router Class Initialized
INFO - 2018-10-09 19:04:23 --> Output Class Initialized
INFO - 2018-10-09 19:04:23 --> Security Class Initialized
DEBUG - 2018-10-09 19:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:04:23 --> CSRF cookie sent
INFO - 2018-10-09 19:04:23 --> Input Class Initialized
INFO - 2018-10-09 19:04:23 --> Language Class Initialized
INFO - 2018-10-09 19:04:23 --> Loader Class Initialized
INFO - 2018-10-09 19:04:23 --> Helper loaded: url_helper
INFO - 2018-10-09 19:04:23 --> Helper loaded: form_helper
INFO - 2018-10-09 19:04:23 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:04:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:04:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:04:23 --> User Agent Class Initialized
INFO - 2018-10-09 19:04:23 --> Controller Class Initialized
INFO - 2018-10-09 19:04:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 19:04:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 19:04:23 --> Pixel_Model class loaded
INFO - 2018-10-09 19:04:23 --> Database Driver Class Initialized
INFO - 2018-10-09 19:04:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:04:23 --> Database Driver Class Initialized
INFO - 2018-10-09 19:04:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:04:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 19:04:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 19:04:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 19:04:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 19:04:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 19:04:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 19:04:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-10-09 19:04:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 19:04:23 --> Final output sent to browser
DEBUG - 2018-10-09 19:04:23 --> Total execution time: 0.0474
INFO - 2018-10-09 19:04:28 --> Config Class Initialized
INFO - 2018-10-09 19:04:28 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:04:28 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:04:28 --> Utf8 Class Initialized
INFO - 2018-10-09 19:04:28 --> URI Class Initialized
INFO - 2018-10-09 19:04:28 --> Router Class Initialized
INFO - 2018-10-09 19:04:28 --> Output Class Initialized
INFO - 2018-10-09 19:04:28 --> Security Class Initialized
DEBUG - 2018-10-09 19:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:04:28 --> CSRF cookie sent
INFO - 2018-10-09 19:04:28 --> CSRF token verified
INFO - 2018-10-09 19:04:28 --> Input Class Initialized
INFO - 2018-10-09 19:04:28 --> Language Class Initialized
INFO - 2018-10-09 19:04:28 --> Loader Class Initialized
INFO - 2018-10-09 19:04:28 --> Helper loaded: url_helper
INFO - 2018-10-09 19:04:28 --> Helper loaded: form_helper
INFO - 2018-10-09 19:04:28 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:04:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:04:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:04:28 --> User Agent Class Initialized
INFO - 2018-10-09 19:04:28 --> Controller Class Initialized
INFO - 2018-10-09 19:04:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 19:04:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 19:04:28 --> Pixel_Model class loaded
INFO - 2018-10-09 19:04:28 --> Database Driver Class Initialized
INFO - 2018-10-09 19:04:28 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:04:28 --> Form Validation Class Initialized
INFO - 2018-10-09 19:04:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 19:04:28 --> Database Driver Class Initialized
INFO - 2018-10-09 19:04:28 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:04:28 --> Config Class Initialized
INFO - 2018-10-09 19:04:28 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:04:28 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:04:28 --> Utf8 Class Initialized
INFO - 2018-10-09 19:04:28 --> URI Class Initialized
INFO - 2018-10-09 19:04:28 --> Router Class Initialized
INFO - 2018-10-09 19:04:28 --> Output Class Initialized
INFO - 2018-10-09 19:04:28 --> Security Class Initialized
DEBUG - 2018-10-09 19:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:04:28 --> CSRF cookie sent
INFO - 2018-10-09 19:04:28 --> Input Class Initialized
INFO - 2018-10-09 19:04:28 --> Language Class Initialized
INFO - 2018-10-09 19:04:28 --> Loader Class Initialized
INFO - 2018-10-09 19:04:28 --> Helper loaded: url_helper
INFO - 2018-10-09 19:04:28 --> Helper loaded: form_helper
INFO - 2018-10-09 19:04:28 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:04:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:04:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:04:28 --> User Agent Class Initialized
INFO - 2018-10-09 19:04:28 --> Controller Class Initialized
INFO - 2018-10-09 19:04:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 19:04:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 19:04:28 --> Pixel_Model class loaded
INFO - 2018-10-09 19:04:28 --> Database Driver Class Initialized
INFO - 2018-10-09 19:04:28 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:04:28 --> Database Driver Class Initialized
INFO - 2018-10-09 19:04:28 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:04:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 19:04:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 19:04:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 19:04:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 19:04:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 19:04:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 19:04:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-10-09 19:04:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 19:04:28 --> Final output sent to browser
DEBUG - 2018-10-09 19:04:28 --> Total execution time: 0.0441
INFO - 2018-10-09 19:04:29 --> Config Class Initialized
INFO - 2018-10-09 19:04:29 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:04:29 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:04:29 --> Utf8 Class Initialized
INFO - 2018-10-09 19:04:29 --> URI Class Initialized
INFO - 2018-10-09 19:04:29 --> Router Class Initialized
INFO - 2018-10-09 19:04:29 --> Output Class Initialized
INFO - 2018-10-09 19:04:29 --> Security Class Initialized
DEBUG - 2018-10-09 19:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:04:29 --> CSRF cookie sent
INFO - 2018-10-09 19:04:29 --> Input Class Initialized
INFO - 2018-10-09 19:04:29 --> Language Class Initialized
INFO - 2018-10-09 19:04:29 --> Loader Class Initialized
INFO - 2018-10-09 19:04:29 --> Helper loaded: url_helper
INFO - 2018-10-09 19:04:29 --> Helper loaded: form_helper
INFO - 2018-10-09 19:04:29 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:04:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:04:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:04:29 --> User Agent Class Initialized
INFO - 2018-10-09 19:04:29 --> Controller Class Initialized
INFO - 2018-10-09 19:04:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 19:04:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 19:04:29 --> Pixel_Model class loaded
INFO - 2018-10-09 19:04:29 --> Database Driver Class Initialized
INFO - 2018-10-09 19:04:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:04:29 --> Database Driver Class Initialized
INFO - 2018-10-09 19:04:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:04:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 19:04:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 19:04:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 19:04:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 19:04:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-10-09 19:04:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 19:04:29 --> Final output sent to browser
DEBUG - 2018-10-09 19:04:29 --> Total execution time: 0.0467
INFO - 2018-10-09 19:06:08 --> Config Class Initialized
INFO - 2018-10-09 19:06:08 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:06:08 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:06:08 --> Utf8 Class Initialized
INFO - 2018-10-09 19:06:08 --> URI Class Initialized
INFO - 2018-10-09 19:06:08 --> Router Class Initialized
INFO - 2018-10-09 19:06:08 --> Output Class Initialized
INFO - 2018-10-09 19:06:08 --> Security Class Initialized
DEBUG - 2018-10-09 19:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:06:08 --> CSRF cookie sent
INFO - 2018-10-09 19:06:08 --> Input Class Initialized
INFO - 2018-10-09 19:06:08 --> Language Class Initialized
INFO - 2018-10-09 19:06:08 --> Loader Class Initialized
INFO - 2018-10-09 19:06:08 --> Helper loaded: url_helper
INFO - 2018-10-09 19:06:08 --> Helper loaded: form_helper
INFO - 2018-10-09 19:06:08 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:06:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:06:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:06:08 --> User Agent Class Initialized
INFO - 2018-10-09 19:06:08 --> Controller Class Initialized
INFO - 2018-10-09 19:06:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 19:06:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 19:06:08 --> Pixel_Model class loaded
INFO - 2018-10-09 19:06:08 --> Database Driver Class Initialized
INFO - 2018-10-09 19:06:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:06:08 --> Database Driver Class Initialized
INFO - 2018-10-09 19:06:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:06:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 19:06:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 19:06:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 19:06:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 19:06:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 19:06:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 19:06:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-10-09 19:06:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 19:06:08 --> Final output sent to browser
DEBUG - 2018-10-09 19:06:08 --> Total execution time: 0.0473
INFO - 2018-10-09 19:06:13 --> Config Class Initialized
INFO - 2018-10-09 19:06:13 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:06:13 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:06:13 --> Utf8 Class Initialized
INFO - 2018-10-09 19:06:13 --> URI Class Initialized
INFO - 2018-10-09 19:06:13 --> Router Class Initialized
INFO - 2018-10-09 19:06:13 --> Output Class Initialized
INFO - 2018-10-09 19:06:13 --> Security Class Initialized
DEBUG - 2018-10-09 19:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:06:13 --> CSRF cookie sent
INFO - 2018-10-09 19:06:13 --> Input Class Initialized
INFO - 2018-10-09 19:06:13 --> Language Class Initialized
INFO - 2018-10-09 19:06:13 --> Loader Class Initialized
INFO - 2018-10-09 19:06:13 --> Helper loaded: url_helper
INFO - 2018-10-09 19:06:13 --> Helper loaded: form_helper
INFO - 2018-10-09 19:06:13 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:06:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:06:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:06:13 --> User Agent Class Initialized
INFO - 2018-10-09 19:06:13 --> Controller Class Initialized
INFO - 2018-10-09 19:06:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 19:06:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 19:06:13 --> Pixel_Model class loaded
INFO - 2018-10-09 19:06:13 --> Database Driver Class Initialized
INFO - 2018-10-09 19:06:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:06:13 --> Database Driver Class Initialized
INFO - 2018-10-09 19:06:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:06:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 19:06:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 19:06:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 19:06:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 19:06:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-10-09 19:06:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 19:06:13 --> Final output sent to browser
DEBUG - 2018-10-09 19:06:13 --> Total execution time: 0.0492
INFO - 2018-10-09 19:06:14 --> Config Class Initialized
INFO - 2018-10-09 19:06:14 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:06:14 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:06:14 --> Utf8 Class Initialized
INFO - 2018-10-09 19:06:14 --> URI Class Initialized
INFO - 2018-10-09 19:06:14 --> Router Class Initialized
INFO - 2018-10-09 19:06:14 --> Output Class Initialized
INFO - 2018-10-09 19:06:14 --> Security Class Initialized
DEBUG - 2018-10-09 19:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:06:14 --> CSRF cookie sent
INFO - 2018-10-09 19:06:14 --> Input Class Initialized
INFO - 2018-10-09 19:06:14 --> Language Class Initialized
INFO - 2018-10-09 19:06:14 --> Loader Class Initialized
INFO - 2018-10-09 19:06:14 --> Helper loaded: url_helper
INFO - 2018-10-09 19:06:14 --> Helper loaded: form_helper
INFO - 2018-10-09 19:06:14 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:06:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:06:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:06:14 --> User Agent Class Initialized
INFO - 2018-10-09 19:06:14 --> Controller Class Initialized
INFO - 2018-10-09 19:06:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 19:06:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 19:06:14 --> Pixel_Model class loaded
INFO - 2018-10-09 19:06:14 --> Database Driver Class Initialized
INFO - 2018-10-09 19:06:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:06:14 --> Database Driver Class Initialized
INFO - 2018-10-09 19:06:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:06:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 19:06:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 19:06:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 19:06:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 19:06:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 19:06:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 19:06:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-10-09 19:06:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 19:06:14 --> Final output sent to browser
DEBUG - 2018-10-09 19:06:14 --> Total execution time: 0.0474
INFO - 2018-10-09 19:06:15 --> Config Class Initialized
INFO - 2018-10-09 19:06:15 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:06:15 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:06:15 --> Utf8 Class Initialized
INFO - 2018-10-09 19:06:15 --> URI Class Initialized
INFO - 2018-10-09 19:06:15 --> Router Class Initialized
INFO - 2018-10-09 19:06:15 --> Output Class Initialized
INFO - 2018-10-09 19:06:15 --> Security Class Initialized
DEBUG - 2018-10-09 19:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:06:15 --> CSRF cookie sent
INFO - 2018-10-09 19:06:15 --> Input Class Initialized
INFO - 2018-10-09 19:06:15 --> Language Class Initialized
INFO - 2018-10-09 19:06:15 --> Loader Class Initialized
INFO - 2018-10-09 19:06:15 --> Helper loaded: url_helper
INFO - 2018-10-09 19:06:15 --> Helper loaded: form_helper
INFO - 2018-10-09 19:06:15 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:06:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:06:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:06:15 --> User Agent Class Initialized
INFO - 2018-10-09 19:06:15 --> Controller Class Initialized
INFO - 2018-10-09 19:06:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 19:06:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 19:06:15 --> Pixel_Model class loaded
INFO - 2018-10-09 19:06:15 --> Database Driver Class Initialized
INFO - 2018-10-09 19:06:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:06:15 --> Database Driver Class Initialized
INFO - 2018-10-09 19:06:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:06:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 19:06:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 19:06:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 19:06:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 19:06:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 19:06:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 19:06:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-10-09 19:06:15 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 19:06:15 --> Final output sent to browser
DEBUG - 2018-10-09 19:06:15 --> Total execution time: 0.0388
INFO - 2018-10-09 19:06:17 --> Config Class Initialized
INFO - 2018-10-09 19:06:17 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:06:17 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:06:17 --> Utf8 Class Initialized
INFO - 2018-10-09 19:06:17 --> URI Class Initialized
INFO - 2018-10-09 19:06:17 --> Router Class Initialized
INFO - 2018-10-09 19:06:17 --> Output Class Initialized
INFO - 2018-10-09 19:06:17 --> Security Class Initialized
DEBUG - 2018-10-09 19:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:06:17 --> CSRF cookie sent
INFO - 2018-10-09 19:06:17 --> Input Class Initialized
INFO - 2018-10-09 19:06:17 --> Language Class Initialized
INFO - 2018-10-09 19:06:17 --> Loader Class Initialized
INFO - 2018-10-09 19:06:17 --> Helper loaded: url_helper
INFO - 2018-10-09 19:06:17 --> Helper loaded: form_helper
INFO - 2018-10-09 19:06:17 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:06:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:06:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:06:17 --> User Agent Class Initialized
INFO - 2018-10-09 19:06:17 --> Controller Class Initialized
INFO - 2018-10-09 19:06:17 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 19:06:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 19:06:17 --> Pixel_Model class loaded
INFO - 2018-10-09 19:06:17 --> Database Driver Class Initialized
INFO - 2018-10-09 19:06:17 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:06:17 --> Database Driver Class Initialized
INFO - 2018-10-09 19:06:17 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:06:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 19:06:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 19:06:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 19:06:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 19:06:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 19:06:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 19:06:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/marriage.php
INFO - 2018-10-09 19:06:17 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 19:06:17 --> Final output sent to browser
DEBUG - 2018-10-09 19:06:17 --> Total execution time: 0.0474
INFO - 2018-10-09 19:06:19 --> Config Class Initialized
INFO - 2018-10-09 19:06:19 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:06:19 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:06:19 --> Utf8 Class Initialized
INFO - 2018-10-09 19:06:19 --> URI Class Initialized
INFO - 2018-10-09 19:06:19 --> Router Class Initialized
INFO - 2018-10-09 19:06:19 --> Output Class Initialized
INFO - 2018-10-09 19:06:19 --> Security Class Initialized
DEBUG - 2018-10-09 19:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:06:19 --> CSRF cookie sent
INFO - 2018-10-09 19:06:19 --> CSRF token verified
INFO - 2018-10-09 19:06:19 --> Input Class Initialized
INFO - 2018-10-09 19:06:19 --> Language Class Initialized
INFO - 2018-10-09 19:06:19 --> Loader Class Initialized
INFO - 2018-10-09 19:06:19 --> Helper loaded: url_helper
INFO - 2018-10-09 19:06:19 --> Helper loaded: form_helper
INFO - 2018-10-09 19:06:19 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:06:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:06:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:06:19 --> User Agent Class Initialized
INFO - 2018-10-09 19:06:19 --> Controller Class Initialized
INFO - 2018-10-09 19:06:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 19:06:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 19:06:19 --> Pixel_Model class loaded
INFO - 2018-10-09 19:06:19 --> Database Driver Class Initialized
INFO - 2018-10-09 19:06:19 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:06:19 --> Form Validation Class Initialized
INFO - 2018-10-09 19:06:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 19:06:19 --> Database Driver Class Initialized
INFO - 2018-10-09 19:06:19 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:06:19 --> Config Class Initialized
INFO - 2018-10-09 19:06:19 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:06:19 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:06:19 --> Utf8 Class Initialized
INFO - 2018-10-09 19:06:19 --> URI Class Initialized
INFO - 2018-10-09 19:06:19 --> Router Class Initialized
INFO - 2018-10-09 19:06:19 --> Output Class Initialized
INFO - 2018-10-09 19:06:19 --> Security Class Initialized
DEBUG - 2018-10-09 19:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:06:19 --> CSRF cookie sent
INFO - 2018-10-09 19:06:19 --> Input Class Initialized
INFO - 2018-10-09 19:06:19 --> Language Class Initialized
INFO - 2018-10-09 19:06:19 --> Loader Class Initialized
INFO - 2018-10-09 19:06:19 --> Helper loaded: url_helper
INFO - 2018-10-09 19:06:19 --> Helper loaded: form_helper
INFO - 2018-10-09 19:06:19 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:06:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:06:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:06:19 --> User Agent Class Initialized
INFO - 2018-10-09 19:06:19 --> Controller Class Initialized
INFO - 2018-10-09 19:06:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 19:06:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 19:06:19 --> Pixel_Model class loaded
INFO - 2018-10-09 19:06:19 --> Database Driver Class Initialized
INFO - 2018-10-09 19:06:19 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:06:19 --> Database Driver Class Initialized
INFO - 2018-10-09 19:06:19 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:06:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 19:06:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 19:06:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 19:06:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 19:06:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 19:06:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 19:06:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/kids.php
INFO - 2018-10-09 19:06:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 19:06:19 --> Final output sent to browser
DEBUG - 2018-10-09 19:06:19 --> Total execution time: 0.0393
INFO - 2018-10-09 19:06:23 --> Config Class Initialized
INFO - 2018-10-09 19:06:23 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:06:23 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:06:23 --> Utf8 Class Initialized
INFO - 2018-10-09 19:06:23 --> URI Class Initialized
INFO - 2018-10-09 19:06:23 --> Router Class Initialized
INFO - 2018-10-09 19:06:23 --> Output Class Initialized
INFO - 2018-10-09 19:06:23 --> Security Class Initialized
DEBUG - 2018-10-09 19:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:06:23 --> CSRF cookie sent
INFO - 2018-10-09 19:06:23 --> CSRF token verified
INFO - 2018-10-09 19:06:23 --> Input Class Initialized
INFO - 2018-10-09 19:06:23 --> Language Class Initialized
INFO - 2018-10-09 19:06:23 --> Loader Class Initialized
INFO - 2018-10-09 19:06:23 --> Helper loaded: url_helper
INFO - 2018-10-09 19:06:23 --> Helper loaded: form_helper
INFO - 2018-10-09 19:06:23 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:06:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:06:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:06:23 --> User Agent Class Initialized
INFO - 2018-10-09 19:06:23 --> Controller Class Initialized
INFO - 2018-10-09 19:06:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 19:06:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 19:06:23 --> Pixel_Model class loaded
INFO - 2018-10-09 19:06:23 --> Database Driver Class Initialized
INFO - 2018-10-09 19:06:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:06:23 --> Form Validation Class Initialized
INFO - 2018-10-09 19:06:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 19:06:23 --> Database Driver Class Initialized
INFO - 2018-10-09 19:06:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:06:23 --> Config Class Initialized
INFO - 2018-10-09 19:06:23 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:06:23 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:06:23 --> Utf8 Class Initialized
INFO - 2018-10-09 19:06:23 --> URI Class Initialized
INFO - 2018-10-09 19:06:23 --> Router Class Initialized
INFO - 2018-10-09 19:06:23 --> Output Class Initialized
INFO - 2018-10-09 19:06:23 --> Security Class Initialized
DEBUG - 2018-10-09 19:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:06:23 --> CSRF cookie sent
INFO - 2018-10-09 19:06:23 --> Input Class Initialized
INFO - 2018-10-09 19:06:23 --> Language Class Initialized
INFO - 2018-10-09 19:06:23 --> Loader Class Initialized
INFO - 2018-10-09 19:06:23 --> Helper loaded: url_helper
INFO - 2018-10-09 19:06:23 --> Helper loaded: form_helper
INFO - 2018-10-09 19:06:23 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:06:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:06:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:06:23 --> User Agent Class Initialized
INFO - 2018-10-09 19:06:23 --> Controller Class Initialized
INFO - 2018-10-09 19:06:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 19:06:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 19:06:23 --> Pixel_Model class loaded
INFO - 2018-10-09 19:06:23 --> Database Driver Class Initialized
INFO - 2018-10-09 19:06:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:06:23 --> Database Driver Class Initialized
INFO - 2018-10-09 19:06:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:06:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 19:06:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 19:06:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 19:06:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 19:06:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 19:06:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 19:06:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-10-09 19:06:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 19:06:23 --> Final output sent to browser
DEBUG - 2018-10-09 19:06:23 --> Total execution time: 0.0447
INFO - 2018-10-09 19:06:24 --> Config Class Initialized
INFO - 2018-10-09 19:06:24 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:06:24 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:06:24 --> Utf8 Class Initialized
INFO - 2018-10-09 19:06:24 --> URI Class Initialized
INFO - 2018-10-09 19:06:24 --> Router Class Initialized
INFO - 2018-10-09 19:06:24 --> Output Class Initialized
INFO - 2018-10-09 19:06:24 --> Security Class Initialized
DEBUG - 2018-10-09 19:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:06:24 --> CSRF cookie sent
INFO - 2018-10-09 19:06:24 --> Input Class Initialized
INFO - 2018-10-09 19:06:24 --> Language Class Initialized
INFO - 2018-10-09 19:06:24 --> Loader Class Initialized
INFO - 2018-10-09 19:06:24 --> Helper loaded: url_helper
INFO - 2018-10-09 19:06:24 --> Helper loaded: form_helper
INFO - 2018-10-09 19:06:24 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:06:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:06:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:06:24 --> User Agent Class Initialized
INFO - 2018-10-09 19:06:24 --> Controller Class Initialized
INFO - 2018-10-09 19:06:24 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 19:06:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 19:06:24 --> Pixel_Model class loaded
INFO - 2018-10-09 19:06:24 --> Database Driver Class Initialized
INFO - 2018-10-09 19:06:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:06:24 --> Database Driver Class Initialized
INFO - 2018-10-09 19:06:24 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:06:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 19:06:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 19:06:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 19:06:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 19:06:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-10-09 19:06:24 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 19:06:24 --> Final output sent to browser
DEBUG - 2018-10-09 19:06:24 --> Total execution time: 0.0476
INFO - 2018-10-09 19:26:49 --> Config Class Initialized
INFO - 2018-10-09 19:26:49 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:26:49 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:26:49 --> Utf8 Class Initialized
INFO - 2018-10-09 19:26:49 --> URI Class Initialized
INFO - 2018-10-09 19:26:49 --> Router Class Initialized
INFO - 2018-10-09 19:26:49 --> Output Class Initialized
INFO - 2018-10-09 19:26:49 --> Security Class Initialized
DEBUG - 2018-10-09 19:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:26:49 --> CSRF cookie sent
INFO - 2018-10-09 19:26:49 --> Input Class Initialized
INFO - 2018-10-09 19:26:49 --> Language Class Initialized
INFO - 2018-10-09 19:26:49 --> Loader Class Initialized
INFO - 2018-10-09 19:26:49 --> Helper loaded: url_helper
INFO - 2018-10-09 19:26:49 --> Helper loaded: form_helper
INFO - 2018-10-09 19:26:49 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:26:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:26:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:26:49 --> User Agent Class Initialized
ERROR - 2018-10-09 19:26:49 --> Severity: Parsing Error --> syntax error, unexpected '$risk' (T_VARIABLE) /home/fxp6bn7rqemh/public_html/application/libraries/Smart.php 608
INFO - 2018-10-09 19:26:51 --> Config Class Initialized
INFO - 2018-10-09 19:26:51 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:26:51 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:26:51 --> Utf8 Class Initialized
INFO - 2018-10-09 19:26:51 --> URI Class Initialized
INFO - 2018-10-09 19:26:51 --> Router Class Initialized
INFO - 2018-10-09 19:26:51 --> Output Class Initialized
INFO - 2018-10-09 19:26:51 --> Security Class Initialized
DEBUG - 2018-10-09 19:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:26:51 --> CSRF cookie sent
INFO - 2018-10-09 19:26:51 --> Input Class Initialized
INFO - 2018-10-09 19:26:51 --> Language Class Initialized
INFO - 2018-10-09 19:26:51 --> Loader Class Initialized
INFO - 2018-10-09 19:26:51 --> Helper loaded: url_helper
INFO - 2018-10-09 19:26:51 --> Helper loaded: form_helper
INFO - 2018-10-09 19:26:51 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:26:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:26:51 --> User Agent Class Initialized
ERROR - 2018-10-09 19:26:51 --> Severity: Parsing Error --> syntax error, unexpected '$risk' (T_VARIABLE) /home/fxp6bn7rqemh/public_html/application/libraries/Smart.php 608
INFO - 2018-10-09 19:26:52 --> Config Class Initialized
INFO - 2018-10-09 19:26:52 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:26:52 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:26:52 --> Utf8 Class Initialized
INFO - 2018-10-09 19:26:52 --> URI Class Initialized
INFO - 2018-10-09 19:26:52 --> Router Class Initialized
INFO - 2018-10-09 19:26:52 --> Output Class Initialized
INFO - 2018-10-09 19:26:52 --> Security Class Initialized
DEBUG - 2018-10-09 19:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:26:52 --> CSRF cookie sent
INFO - 2018-10-09 19:26:52 --> Input Class Initialized
INFO - 2018-10-09 19:26:52 --> Language Class Initialized
INFO - 2018-10-09 19:26:52 --> Loader Class Initialized
INFO - 2018-10-09 19:26:52 --> Helper loaded: url_helper
INFO - 2018-10-09 19:26:52 --> Helper loaded: form_helper
INFO - 2018-10-09 19:26:52 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:26:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:26:52 --> User Agent Class Initialized
ERROR - 2018-10-09 19:26:52 --> Severity: Parsing Error --> syntax error, unexpected '$risk' (T_VARIABLE) /home/fxp6bn7rqemh/public_html/application/libraries/Smart.php 608
INFO - 2018-10-09 19:26:53 --> Config Class Initialized
INFO - 2018-10-09 19:26:53 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:26:53 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:26:53 --> Utf8 Class Initialized
INFO - 2018-10-09 19:26:53 --> URI Class Initialized
INFO - 2018-10-09 19:26:53 --> Router Class Initialized
INFO - 2018-10-09 19:26:53 --> Output Class Initialized
INFO - 2018-10-09 19:26:53 --> Security Class Initialized
DEBUG - 2018-10-09 19:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:26:53 --> CSRF cookie sent
INFO - 2018-10-09 19:26:53 --> Input Class Initialized
INFO - 2018-10-09 19:26:53 --> Language Class Initialized
INFO - 2018-10-09 19:26:53 --> Loader Class Initialized
INFO - 2018-10-09 19:26:53 --> Helper loaded: url_helper
INFO - 2018-10-09 19:26:53 --> Helper loaded: form_helper
INFO - 2018-10-09 19:26:53 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:26:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:26:53 --> User Agent Class Initialized
ERROR - 2018-10-09 19:26:53 --> Severity: Parsing Error --> syntax error, unexpected '$risk' (T_VARIABLE) /home/fxp6bn7rqemh/public_html/application/libraries/Smart.php 608
INFO - 2018-10-09 19:26:54 --> Config Class Initialized
INFO - 2018-10-09 19:26:54 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:26:54 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:26:54 --> Utf8 Class Initialized
INFO - 2018-10-09 19:26:54 --> URI Class Initialized
INFO - 2018-10-09 19:26:54 --> Router Class Initialized
INFO - 2018-10-09 19:26:54 --> Output Class Initialized
INFO - 2018-10-09 19:26:54 --> Security Class Initialized
DEBUG - 2018-10-09 19:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:26:54 --> CSRF cookie sent
INFO - 2018-10-09 19:26:54 --> Input Class Initialized
INFO - 2018-10-09 19:26:54 --> Language Class Initialized
INFO - 2018-10-09 19:26:54 --> Loader Class Initialized
INFO - 2018-10-09 19:26:54 --> Helper loaded: url_helper
INFO - 2018-10-09 19:26:54 --> Helper loaded: form_helper
INFO - 2018-10-09 19:26:54 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:26:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:26:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:26:54 --> User Agent Class Initialized
ERROR - 2018-10-09 19:26:54 --> Severity: Parsing Error --> syntax error, unexpected '$risk' (T_VARIABLE) /home/fxp6bn7rqemh/public_html/application/libraries/Smart.php 608
INFO - 2018-10-09 19:26:56 --> Config Class Initialized
INFO - 2018-10-09 19:26:56 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:26:56 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:26:56 --> Utf8 Class Initialized
INFO - 2018-10-09 19:26:56 --> URI Class Initialized
DEBUG - 2018-10-09 19:26:56 --> No URI present. Default controller set.
INFO - 2018-10-09 19:26:56 --> Router Class Initialized
INFO - 2018-10-09 19:26:56 --> Output Class Initialized
INFO - 2018-10-09 19:26:56 --> Security Class Initialized
DEBUG - 2018-10-09 19:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:26:56 --> CSRF cookie sent
INFO - 2018-10-09 19:26:56 --> Input Class Initialized
INFO - 2018-10-09 19:26:56 --> Language Class Initialized
INFO - 2018-10-09 19:26:56 --> Loader Class Initialized
INFO - 2018-10-09 19:26:56 --> Helper loaded: url_helper
INFO - 2018-10-09 19:26:56 --> Helper loaded: form_helper
INFO - 2018-10-09 19:26:56 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:26:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:26:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:26:56 --> User Agent Class Initialized
ERROR - 2018-10-09 19:26:56 --> Severity: Parsing Error --> syntax error, unexpected '$risk' (T_VARIABLE) /home/fxp6bn7rqemh/public_html/application/libraries/Smart.php 608
INFO - 2018-10-09 19:26:57 --> Config Class Initialized
INFO - 2018-10-09 19:26:57 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:26:57 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:26:57 --> Utf8 Class Initialized
INFO - 2018-10-09 19:26:57 --> URI Class Initialized
DEBUG - 2018-10-09 19:26:57 --> No URI present. Default controller set.
INFO - 2018-10-09 19:26:57 --> Router Class Initialized
INFO - 2018-10-09 19:26:57 --> Output Class Initialized
INFO - 2018-10-09 19:26:57 --> Security Class Initialized
DEBUG - 2018-10-09 19:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:26:57 --> CSRF cookie sent
INFO - 2018-10-09 19:26:57 --> Input Class Initialized
INFO - 2018-10-09 19:26:57 --> Language Class Initialized
INFO - 2018-10-09 19:26:57 --> Loader Class Initialized
INFO - 2018-10-09 19:26:57 --> Helper loaded: url_helper
INFO - 2018-10-09 19:26:57 --> Helper loaded: form_helper
INFO - 2018-10-09 19:26:57 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:26:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:26:57 --> User Agent Class Initialized
ERROR - 2018-10-09 19:26:57 --> Severity: Parsing Error --> syntax error, unexpected '$risk' (T_VARIABLE) /home/fxp6bn7rqemh/public_html/application/libraries/Smart.php 608
INFO - 2018-10-09 19:27:10 --> Config Class Initialized
INFO - 2018-10-09 19:27:10 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:27:10 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:27:10 --> Utf8 Class Initialized
INFO - 2018-10-09 19:27:10 --> URI Class Initialized
DEBUG - 2018-10-09 19:27:10 --> No URI present. Default controller set.
INFO - 2018-10-09 19:27:10 --> Router Class Initialized
INFO - 2018-10-09 19:27:10 --> Output Class Initialized
INFO - 2018-10-09 19:27:10 --> Security Class Initialized
DEBUG - 2018-10-09 19:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:27:10 --> CSRF cookie sent
INFO - 2018-10-09 19:27:10 --> Input Class Initialized
INFO - 2018-10-09 19:27:10 --> Language Class Initialized
INFO - 2018-10-09 19:27:10 --> Loader Class Initialized
INFO - 2018-10-09 19:27:10 --> Helper loaded: url_helper
INFO - 2018-10-09 19:27:10 --> Helper loaded: form_helper
INFO - 2018-10-09 19:27:10 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:27:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:27:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:27:10 --> User Agent Class Initialized
ERROR - 2018-10-09 19:27:10 --> Severity: Parsing Error --> syntax error, unexpected '$risk' (T_VARIABLE) /home/fxp6bn7rqemh/public_html/application/libraries/Smart.php 608
INFO - 2018-10-09 19:27:55 --> Config Class Initialized
INFO - 2018-10-09 19:27:55 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:27:55 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:27:55 --> Utf8 Class Initialized
INFO - 2018-10-09 19:27:55 --> URI Class Initialized
DEBUG - 2018-10-09 19:27:55 --> No URI present. Default controller set.
INFO - 2018-10-09 19:27:55 --> Router Class Initialized
INFO - 2018-10-09 19:27:55 --> Output Class Initialized
INFO - 2018-10-09 19:27:55 --> Security Class Initialized
DEBUG - 2018-10-09 19:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:27:55 --> CSRF cookie sent
INFO - 2018-10-09 19:27:55 --> Input Class Initialized
INFO - 2018-10-09 19:27:55 --> Language Class Initialized
INFO - 2018-10-09 19:27:55 --> Loader Class Initialized
INFO - 2018-10-09 19:27:55 --> Helper loaded: url_helper
INFO - 2018-10-09 19:27:55 --> Helper loaded: form_helper
INFO - 2018-10-09 19:27:55 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:27:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:27:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:27:55 --> User Agent Class Initialized
ERROR - 2018-10-09 19:27:55 --> Severity: Parsing Error --> syntax error, unexpected '$risk' (T_VARIABLE) /home/fxp6bn7rqemh/public_html/application/libraries/Smart.php 609
INFO - 2018-10-09 19:28:39 --> Config Class Initialized
INFO - 2018-10-09 19:28:39 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:28:39 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:28:39 --> Utf8 Class Initialized
INFO - 2018-10-09 19:28:39 --> URI Class Initialized
DEBUG - 2018-10-09 19:28:39 --> No URI present. Default controller set.
INFO - 2018-10-09 19:28:39 --> Router Class Initialized
INFO - 2018-10-09 19:28:39 --> Output Class Initialized
INFO - 2018-10-09 19:28:39 --> Security Class Initialized
DEBUG - 2018-10-09 19:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:28:39 --> CSRF cookie sent
INFO - 2018-10-09 19:28:39 --> Input Class Initialized
INFO - 2018-10-09 19:28:39 --> Language Class Initialized
INFO - 2018-10-09 19:28:39 --> Loader Class Initialized
INFO - 2018-10-09 19:28:39 --> Helper loaded: url_helper
INFO - 2018-10-09 19:28:39 --> Helper loaded: form_helper
INFO - 2018-10-09 19:28:39 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:28:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:28:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:28:39 --> User Agent Class Initialized
INFO - 2018-10-09 19:28:39 --> Controller Class Initialized
INFO - 2018-10-09 19:28:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 19:28:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 19:28:39 --> Pixel_Model class loaded
INFO - 2018-10-09 19:28:39 --> Database Driver Class Initialized
INFO - 2018-10-09 19:28:39 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:28:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 19:28:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 19:28:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-09 19:28:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 19:28:39 --> Final output sent to browser
DEBUG - 2018-10-09 19:28:39 --> Total execution time: 0.0530
INFO - 2018-10-09 19:28:42 --> Config Class Initialized
INFO - 2018-10-09 19:28:42 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:28:42 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:28:42 --> Utf8 Class Initialized
INFO - 2018-10-09 19:28:42 --> URI Class Initialized
INFO - 2018-10-09 19:28:42 --> Router Class Initialized
INFO - 2018-10-09 19:28:42 --> Output Class Initialized
INFO - 2018-10-09 19:28:42 --> Security Class Initialized
DEBUG - 2018-10-09 19:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:28:42 --> CSRF cookie sent
INFO - 2018-10-09 19:28:42 --> Input Class Initialized
INFO - 2018-10-09 19:28:42 --> Language Class Initialized
INFO - 2018-10-09 19:28:42 --> Loader Class Initialized
INFO - 2018-10-09 19:28:42 --> Helper loaded: url_helper
INFO - 2018-10-09 19:28:42 --> Helper loaded: form_helper
INFO - 2018-10-09 19:28:42 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:28:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:28:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:28:42 --> User Agent Class Initialized
INFO - 2018-10-09 19:28:42 --> Controller Class Initialized
INFO - 2018-10-09 19:28:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 19:28:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 19:28:42 --> Pixel_Model class loaded
INFO - 2018-10-09 19:28:42 --> Database Driver Class Initialized
INFO - 2018-10-09 19:28:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:28:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 19:28:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 19:28:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 19:28:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 19:28:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 19:28:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 19:28:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-10-09 19:28:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 19:28:42 --> Final output sent to browser
DEBUG - 2018-10-09 19:28:42 --> Total execution time: 0.0516
INFO - 2018-10-09 19:28:43 --> Config Class Initialized
INFO - 2018-10-09 19:28:43 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:28:43 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:28:43 --> Utf8 Class Initialized
INFO - 2018-10-09 19:28:43 --> URI Class Initialized
INFO - 2018-10-09 19:28:43 --> Router Class Initialized
INFO - 2018-10-09 19:28:43 --> Output Class Initialized
INFO - 2018-10-09 19:28:43 --> Security Class Initialized
DEBUG - 2018-10-09 19:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:28:43 --> CSRF cookie sent
INFO - 2018-10-09 19:28:43 --> CSRF token verified
INFO - 2018-10-09 19:28:43 --> Input Class Initialized
INFO - 2018-10-09 19:28:43 --> Language Class Initialized
INFO - 2018-10-09 19:28:43 --> Loader Class Initialized
INFO - 2018-10-09 19:28:43 --> Helper loaded: url_helper
INFO - 2018-10-09 19:28:43 --> Helper loaded: form_helper
INFO - 2018-10-09 19:28:43 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:28:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:28:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:28:43 --> User Agent Class Initialized
INFO - 2018-10-09 19:28:43 --> Controller Class Initialized
INFO - 2018-10-09 19:28:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 19:28:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 19:28:43 --> Pixel_Model class loaded
INFO - 2018-10-09 19:28:43 --> Database Driver Class Initialized
INFO - 2018-10-09 19:28:43 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:28:43 --> Database Driver Class Initialized
INFO - 2018-10-09 19:28:43 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:28:43 --> Config Class Initialized
INFO - 2018-10-09 19:28:43 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:28:43 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:28:43 --> Utf8 Class Initialized
INFO - 2018-10-09 19:28:43 --> URI Class Initialized
INFO - 2018-10-09 19:28:43 --> Router Class Initialized
INFO - 2018-10-09 19:28:43 --> Output Class Initialized
INFO - 2018-10-09 19:28:43 --> Security Class Initialized
DEBUG - 2018-10-09 19:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:28:43 --> CSRF cookie sent
INFO - 2018-10-09 19:28:43 --> Input Class Initialized
INFO - 2018-10-09 19:28:43 --> Language Class Initialized
INFO - 2018-10-09 19:28:43 --> Loader Class Initialized
INFO - 2018-10-09 19:28:43 --> Helper loaded: url_helper
INFO - 2018-10-09 19:28:43 --> Helper loaded: form_helper
INFO - 2018-10-09 19:28:43 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:28:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:28:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:28:43 --> User Agent Class Initialized
INFO - 2018-10-09 19:28:43 --> Controller Class Initialized
INFO - 2018-10-09 19:28:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 19:28:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 19:28:43 --> Pixel_Model class loaded
INFO - 2018-10-09 19:28:43 --> Database Driver Class Initialized
INFO - 2018-10-09 19:28:43 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:28:43 --> Database Driver Class Initialized
INFO - 2018-10-09 19:28:43 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:28:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 19:28:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 19:28:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 19:28:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 19:28:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 19:28:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 19:28:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-09 19:28:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 19:28:43 --> Final output sent to browser
DEBUG - 2018-10-09 19:28:43 --> Total execution time: 0.0581
INFO - 2018-10-09 19:28:47 --> Config Class Initialized
INFO - 2018-10-09 19:28:47 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:28:47 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:28:47 --> Utf8 Class Initialized
INFO - 2018-10-09 19:28:47 --> URI Class Initialized
INFO - 2018-10-09 19:28:47 --> Router Class Initialized
INFO - 2018-10-09 19:28:47 --> Output Class Initialized
INFO - 2018-10-09 19:28:47 --> Security Class Initialized
DEBUG - 2018-10-09 19:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:28:47 --> CSRF cookie sent
INFO - 2018-10-09 19:28:47 --> CSRF token verified
INFO - 2018-10-09 19:28:47 --> Input Class Initialized
INFO - 2018-10-09 19:28:47 --> Language Class Initialized
INFO - 2018-10-09 19:28:47 --> Loader Class Initialized
INFO - 2018-10-09 19:28:47 --> Helper loaded: url_helper
INFO - 2018-10-09 19:28:47 --> Helper loaded: form_helper
INFO - 2018-10-09 19:28:47 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:28:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:28:47 --> User Agent Class Initialized
INFO - 2018-10-09 19:28:47 --> Controller Class Initialized
INFO - 2018-10-09 19:28:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 19:28:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 19:28:47 --> Pixel_Model class loaded
INFO - 2018-10-09 19:28:47 --> Database Driver Class Initialized
INFO - 2018-10-09 19:28:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:28:47 --> Form Validation Class Initialized
INFO - 2018-10-09 19:28:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 19:28:47 --> Database Driver Class Initialized
INFO - 2018-10-09 19:28:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:28:47 --> Config Class Initialized
INFO - 2018-10-09 19:28:47 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:28:47 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:28:47 --> Utf8 Class Initialized
INFO - 2018-10-09 19:28:47 --> URI Class Initialized
INFO - 2018-10-09 19:28:47 --> Router Class Initialized
INFO - 2018-10-09 19:28:47 --> Output Class Initialized
INFO - 2018-10-09 19:28:47 --> Security Class Initialized
DEBUG - 2018-10-09 19:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:28:47 --> CSRF cookie sent
INFO - 2018-10-09 19:28:47 --> Input Class Initialized
INFO - 2018-10-09 19:28:47 --> Language Class Initialized
INFO - 2018-10-09 19:28:47 --> Loader Class Initialized
INFO - 2018-10-09 19:28:47 --> Helper loaded: url_helper
INFO - 2018-10-09 19:28:47 --> Helper loaded: form_helper
INFO - 2018-10-09 19:28:47 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:28:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:28:47 --> User Agent Class Initialized
INFO - 2018-10-09 19:28:47 --> Controller Class Initialized
INFO - 2018-10-09 19:28:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 19:28:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 19:28:47 --> Pixel_Model class loaded
INFO - 2018-10-09 19:28:47 --> Database Driver Class Initialized
INFO - 2018-10-09 19:28:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:28:47 --> Database Driver Class Initialized
INFO - 2018-10-09 19:28:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:28:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 19:28:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 19:28:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 19:28:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 19:28:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 19:28:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 19:28:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-10-09 19:28:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 19:28:47 --> Final output sent to browser
DEBUG - 2018-10-09 19:28:47 --> Total execution time: 0.0542
INFO - 2018-10-09 19:28:49 --> Config Class Initialized
INFO - 2018-10-09 19:28:49 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:28:49 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:28:49 --> Utf8 Class Initialized
INFO - 2018-10-09 19:28:49 --> URI Class Initialized
INFO - 2018-10-09 19:28:49 --> Router Class Initialized
INFO - 2018-10-09 19:28:49 --> Output Class Initialized
INFO - 2018-10-09 19:28:49 --> Security Class Initialized
DEBUG - 2018-10-09 19:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:28:49 --> CSRF cookie sent
INFO - 2018-10-09 19:28:49 --> CSRF token verified
INFO - 2018-10-09 19:28:49 --> Input Class Initialized
INFO - 2018-10-09 19:28:49 --> Language Class Initialized
INFO - 2018-10-09 19:28:49 --> Loader Class Initialized
INFO - 2018-10-09 19:28:49 --> Helper loaded: url_helper
INFO - 2018-10-09 19:28:49 --> Helper loaded: form_helper
INFO - 2018-10-09 19:28:49 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:28:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:28:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:28:49 --> User Agent Class Initialized
INFO - 2018-10-09 19:28:49 --> Controller Class Initialized
INFO - 2018-10-09 19:28:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 19:28:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 19:28:49 --> Pixel_Model class loaded
INFO - 2018-10-09 19:28:49 --> Database Driver Class Initialized
INFO - 2018-10-09 19:28:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:28:49 --> Form Validation Class Initialized
INFO - 2018-10-09 19:28:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 19:28:49 --> Database Driver Class Initialized
INFO - 2018-10-09 19:28:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:28:49 --> Config Class Initialized
INFO - 2018-10-09 19:28:49 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:28:49 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:28:49 --> Utf8 Class Initialized
INFO - 2018-10-09 19:28:49 --> URI Class Initialized
INFO - 2018-10-09 19:28:49 --> Router Class Initialized
INFO - 2018-10-09 19:28:49 --> Output Class Initialized
INFO - 2018-10-09 19:28:49 --> Security Class Initialized
DEBUG - 2018-10-09 19:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:28:49 --> CSRF cookie sent
INFO - 2018-10-09 19:28:49 --> Input Class Initialized
INFO - 2018-10-09 19:28:49 --> Language Class Initialized
INFO - 2018-10-09 19:28:49 --> Loader Class Initialized
INFO - 2018-10-09 19:28:49 --> Helper loaded: url_helper
INFO - 2018-10-09 19:28:49 --> Helper loaded: form_helper
INFO - 2018-10-09 19:28:49 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:28:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:28:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:28:49 --> User Agent Class Initialized
INFO - 2018-10-09 19:28:49 --> Controller Class Initialized
INFO - 2018-10-09 19:28:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 19:28:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 19:28:49 --> Pixel_Model class loaded
INFO - 2018-10-09 19:28:49 --> Database Driver Class Initialized
INFO - 2018-10-09 19:28:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:28:49 --> Database Driver Class Initialized
INFO - 2018-10-09 19:28:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:28:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 19:28:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 19:28:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-10-09 19:28:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 19:28:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 19:28:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 19:28:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 19:28:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-10-09 19:28:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 19:28:49 --> Final output sent to browser
DEBUG - 2018-10-09 19:28:49 --> Total execution time: 0.0405
INFO - 2018-10-09 19:28:50 --> Config Class Initialized
INFO - 2018-10-09 19:28:50 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:28:50 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:28:50 --> Utf8 Class Initialized
INFO - 2018-10-09 19:28:50 --> URI Class Initialized
INFO - 2018-10-09 19:28:50 --> Router Class Initialized
INFO - 2018-10-09 19:28:50 --> Output Class Initialized
INFO - 2018-10-09 19:28:50 --> Security Class Initialized
DEBUG - 2018-10-09 19:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:28:50 --> CSRF cookie sent
INFO - 2018-10-09 19:28:50 --> CSRF token verified
INFO - 2018-10-09 19:28:50 --> Input Class Initialized
INFO - 2018-10-09 19:28:50 --> Language Class Initialized
INFO - 2018-10-09 19:28:50 --> Loader Class Initialized
INFO - 2018-10-09 19:28:50 --> Helper loaded: url_helper
INFO - 2018-10-09 19:28:50 --> Helper loaded: form_helper
INFO - 2018-10-09 19:28:50 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:28:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:28:50 --> User Agent Class Initialized
INFO - 2018-10-09 19:28:50 --> Controller Class Initialized
INFO - 2018-10-09 19:28:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 19:28:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 19:28:50 --> Pixel_Model class loaded
INFO - 2018-10-09 19:28:50 --> Database Driver Class Initialized
INFO - 2018-10-09 19:28:50 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:28:50 --> Form Validation Class Initialized
INFO - 2018-10-09 19:28:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 19:28:50 --> Database Driver Class Initialized
INFO - 2018-10-09 19:28:50 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:28:50 --> Config Class Initialized
INFO - 2018-10-09 19:28:50 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:28:50 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:28:50 --> Utf8 Class Initialized
INFO - 2018-10-09 19:28:50 --> URI Class Initialized
INFO - 2018-10-09 19:28:50 --> Router Class Initialized
INFO - 2018-10-09 19:28:50 --> Output Class Initialized
INFO - 2018-10-09 19:28:50 --> Security Class Initialized
DEBUG - 2018-10-09 19:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:28:50 --> CSRF cookie sent
INFO - 2018-10-09 19:28:50 --> Input Class Initialized
INFO - 2018-10-09 19:28:50 --> Language Class Initialized
INFO - 2018-10-09 19:28:50 --> Loader Class Initialized
INFO - 2018-10-09 19:28:50 --> Helper loaded: url_helper
INFO - 2018-10-09 19:28:50 --> Helper loaded: form_helper
INFO - 2018-10-09 19:28:50 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:28:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:28:50 --> User Agent Class Initialized
INFO - 2018-10-09 19:28:50 --> Controller Class Initialized
INFO - 2018-10-09 19:28:50 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 19:28:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 19:28:50 --> Pixel_Model class loaded
INFO - 2018-10-09 19:28:50 --> Database Driver Class Initialized
INFO - 2018-10-09 19:28:50 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:28:50 --> Database Driver Class Initialized
INFO - 2018-10-09 19:28:50 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:28:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 19:28:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 19:28:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 19:28:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 19:28:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 19:28:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 19:28:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-09 19:28:50 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 19:28:50 --> Final output sent to browser
DEBUG - 2018-10-09 19:28:50 --> Total execution time: 0.0402
INFO - 2018-10-09 19:29:01 --> Config Class Initialized
INFO - 2018-10-09 19:29:01 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:29:01 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:29:01 --> Utf8 Class Initialized
INFO - 2018-10-09 19:29:01 --> URI Class Initialized
INFO - 2018-10-09 19:29:01 --> Router Class Initialized
INFO - 2018-10-09 19:29:01 --> Output Class Initialized
INFO - 2018-10-09 19:29:01 --> Security Class Initialized
DEBUG - 2018-10-09 19:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:29:01 --> CSRF cookie sent
INFO - 2018-10-09 19:29:01 --> CSRF token verified
INFO - 2018-10-09 19:29:01 --> Input Class Initialized
INFO - 2018-10-09 19:29:01 --> Language Class Initialized
INFO - 2018-10-09 19:29:01 --> Loader Class Initialized
INFO - 2018-10-09 19:29:01 --> Helper loaded: url_helper
INFO - 2018-10-09 19:29:01 --> Helper loaded: form_helper
INFO - 2018-10-09 19:29:01 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:29:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:29:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:29:01 --> User Agent Class Initialized
INFO - 2018-10-09 19:29:01 --> Controller Class Initialized
INFO - 2018-10-09 19:29:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 19:29:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 19:29:01 --> Pixel_Model class loaded
INFO - 2018-10-09 19:29:01 --> Database Driver Class Initialized
INFO - 2018-10-09 19:29:01 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:29:01 --> Form Validation Class Initialized
INFO - 2018-10-09 19:29:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 19:29:01 --> Database Driver Class Initialized
INFO - 2018-10-09 19:29:01 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:29:01 --> Config Class Initialized
INFO - 2018-10-09 19:29:01 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:29:01 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:29:01 --> Utf8 Class Initialized
INFO - 2018-10-09 19:29:01 --> URI Class Initialized
INFO - 2018-10-09 19:29:01 --> Router Class Initialized
INFO - 2018-10-09 19:29:01 --> Output Class Initialized
INFO - 2018-10-09 19:29:01 --> Security Class Initialized
DEBUG - 2018-10-09 19:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:29:01 --> CSRF cookie sent
INFO - 2018-10-09 19:29:01 --> Input Class Initialized
INFO - 2018-10-09 19:29:01 --> Language Class Initialized
INFO - 2018-10-09 19:29:01 --> Loader Class Initialized
INFO - 2018-10-09 19:29:01 --> Helper loaded: url_helper
INFO - 2018-10-09 19:29:01 --> Helper loaded: form_helper
INFO - 2018-10-09 19:29:01 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:29:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:29:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:29:01 --> User Agent Class Initialized
INFO - 2018-10-09 19:29:01 --> Controller Class Initialized
INFO - 2018-10-09 19:29:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 19:29:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 19:29:01 --> Pixel_Model class loaded
INFO - 2018-10-09 19:29:01 --> Database Driver Class Initialized
INFO - 2018-10-09 19:29:01 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:29:01 --> Database Driver Class Initialized
INFO - 2018-10-09 19:29:01 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:29:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 19:29:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 19:29:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 19:29:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 19:29:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 19:29:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 19:29:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-10-09 19:29:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 19:29:01 --> Final output sent to browser
DEBUG - 2018-10-09 19:29:01 --> Total execution time: 0.0465
INFO - 2018-10-09 19:29:06 --> Config Class Initialized
INFO - 2018-10-09 19:29:06 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:29:06 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:29:06 --> Utf8 Class Initialized
INFO - 2018-10-09 19:29:06 --> URI Class Initialized
INFO - 2018-10-09 19:29:06 --> Router Class Initialized
INFO - 2018-10-09 19:29:06 --> Output Class Initialized
INFO - 2018-10-09 19:29:06 --> Security Class Initialized
DEBUG - 2018-10-09 19:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:29:06 --> CSRF cookie sent
INFO - 2018-10-09 19:29:06 --> CSRF token verified
INFO - 2018-10-09 19:29:06 --> Input Class Initialized
INFO - 2018-10-09 19:29:06 --> Language Class Initialized
INFO - 2018-10-09 19:29:06 --> Loader Class Initialized
INFO - 2018-10-09 19:29:06 --> Helper loaded: url_helper
INFO - 2018-10-09 19:29:06 --> Helper loaded: form_helper
INFO - 2018-10-09 19:29:06 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:29:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:29:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:29:06 --> User Agent Class Initialized
INFO - 2018-10-09 19:29:06 --> Controller Class Initialized
INFO - 2018-10-09 19:29:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 19:29:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 19:29:06 --> Pixel_Model class loaded
INFO - 2018-10-09 19:29:06 --> Database Driver Class Initialized
INFO - 2018-10-09 19:29:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:29:06 --> Form Validation Class Initialized
INFO - 2018-10-09 19:29:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 19:29:06 --> Database Driver Class Initialized
INFO - 2018-10-09 19:29:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:29:06 --> Config Class Initialized
INFO - 2018-10-09 19:29:06 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:29:06 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:29:06 --> Utf8 Class Initialized
INFO - 2018-10-09 19:29:06 --> URI Class Initialized
INFO - 2018-10-09 19:29:06 --> Router Class Initialized
INFO - 2018-10-09 19:29:06 --> Output Class Initialized
INFO - 2018-10-09 19:29:06 --> Security Class Initialized
DEBUG - 2018-10-09 19:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:29:06 --> CSRF cookie sent
INFO - 2018-10-09 19:29:06 --> Input Class Initialized
INFO - 2018-10-09 19:29:06 --> Language Class Initialized
INFO - 2018-10-09 19:29:06 --> Loader Class Initialized
INFO - 2018-10-09 19:29:06 --> Helper loaded: url_helper
INFO - 2018-10-09 19:29:06 --> Helper loaded: form_helper
INFO - 2018-10-09 19:29:06 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:29:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:29:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:29:06 --> User Agent Class Initialized
INFO - 2018-10-09 19:29:06 --> Controller Class Initialized
INFO - 2018-10-09 19:29:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 19:29:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 19:29:06 --> Pixel_Model class loaded
INFO - 2018-10-09 19:29:06 --> Database Driver Class Initialized
INFO - 2018-10-09 19:29:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:29:06 --> Database Driver Class Initialized
INFO - 2018-10-09 19:29:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:29:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 19:29:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 19:29:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 19:29:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 19:29:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 19:29:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 19:29:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_title.php
INFO - 2018-10-09 19:29:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 19:29:06 --> Final output sent to browser
DEBUG - 2018-10-09 19:29:06 --> Total execution time: 0.0499
INFO - 2018-10-09 19:29:08 --> Config Class Initialized
INFO - 2018-10-09 19:29:08 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:29:08 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:29:08 --> Utf8 Class Initialized
INFO - 2018-10-09 19:29:08 --> URI Class Initialized
INFO - 2018-10-09 19:29:08 --> Router Class Initialized
INFO - 2018-10-09 19:29:08 --> Output Class Initialized
INFO - 2018-10-09 19:29:08 --> Security Class Initialized
DEBUG - 2018-10-09 19:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:29:08 --> CSRF cookie sent
INFO - 2018-10-09 19:29:08 --> CSRF token verified
INFO - 2018-10-09 19:29:08 --> Input Class Initialized
INFO - 2018-10-09 19:29:08 --> Language Class Initialized
INFO - 2018-10-09 19:29:08 --> Loader Class Initialized
INFO - 2018-10-09 19:29:08 --> Helper loaded: url_helper
INFO - 2018-10-09 19:29:08 --> Helper loaded: form_helper
INFO - 2018-10-09 19:29:08 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:29:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:29:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:29:08 --> User Agent Class Initialized
INFO - 2018-10-09 19:29:08 --> Controller Class Initialized
INFO - 2018-10-09 19:29:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 19:29:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 19:29:08 --> Pixel_Model class loaded
INFO - 2018-10-09 19:29:08 --> Database Driver Class Initialized
INFO - 2018-10-09 19:29:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:29:08 --> Form Validation Class Initialized
INFO - 2018-10-09 19:29:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 19:29:08 --> Database Driver Class Initialized
INFO - 2018-10-09 19:29:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:29:08 --> Config Class Initialized
INFO - 2018-10-09 19:29:08 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:29:08 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:29:08 --> Utf8 Class Initialized
INFO - 2018-10-09 19:29:08 --> URI Class Initialized
INFO - 2018-10-09 19:29:08 --> Router Class Initialized
INFO - 2018-10-09 19:29:08 --> Output Class Initialized
INFO - 2018-10-09 19:29:08 --> Security Class Initialized
DEBUG - 2018-10-09 19:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:29:08 --> CSRF cookie sent
INFO - 2018-10-09 19:29:08 --> Input Class Initialized
INFO - 2018-10-09 19:29:08 --> Language Class Initialized
INFO - 2018-10-09 19:29:08 --> Loader Class Initialized
INFO - 2018-10-09 19:29:08 --> Helper loaded: url_helper
INFO - 2018-10-09 19:29:08 --> Helper loaded: form_helper
INFO - 2018-10-09 19:29:08 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:29:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:29:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:29:08 --> User Agent Class Initialized
INFO - 2018-10-09 19:29:08 --> Controller Class Initialized
INFO - 2018-10-09 19:29:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 19:29:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 19:29:08 --> Pixel_Model class loaded
INFO - 2018-10-09 19:29:08 --> Database Driver Class Initialized
INFO - 2018-10-09 19:29:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:29:08 --> Database Driver Class Initialized
INFO - 2018-10-09 19:29:08 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:29:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 19:29:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 19:29:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 19:29:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 19:29:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 19:29:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 19:29:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-10-09 19:29:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 19:29:08 --> Final output sent to browser
DEBUG - 2018-10-09 19:29:08 --> Total execution time: 0.0640
INFO - 2018-10-09 19:29:10 --> Config Class Initialized
INFO - 2018-10-09 19:29:10 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:29:10 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:29:10 --> Utf8 Class Initialized
INFO - 2018-10-09 19:29:10 --> URI Class Initialized
INFO - 2018-10-09 19:29:10 --> Router Class Initialized
INFO - 2018-10-09 19:29:10 --> Output Class Initialized
INFO - 2018-10-09 19:29:10 --> Security Class Initialized
DEBUG - 2018-10-09 19:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:29:10 --> CSRF cookie sent
INFO - 2018-10-09 19:29:10 --> CSRF token verified
INFO - 2018-10-09 19:29:10 --> Input Class Initialized
INFO - 2018-10-09 19:29:10 --> Language Class Initialized
INFO - 2018-10-09 19:29:10 --> Loader Class Initialized
INFO - 2018-10-09 19:29:10 --> Helper loaded: url_helper
INFO - 2018-10-09 19:29:10 --> Helper loaded: form_helper
INFO - 2018-10-09 19:29:10 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:29:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:29:10 --> User Agent Class Initialized
INFO - 2018-10-09 19:29:10 --> Controller Class Initialized
INFO - 2018-10-09 19:29:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 19:29:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 19:29:10 --> Pixel_Model class loaded
INFO - 2018-10-09 19:29:10 --> Database Driver Class Initialized
INFO - 2018-10-09 19:29:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:29:10 --> Form Validation Class Initialized
INFO - 2018-10-09 19:29:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 19:29:10 --> Database Driver Class Initialized
INFO - 2018-10-09 19:29:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:29:10 --> Config Class Initialized
INFO - 2018-10-09 19:29:10 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:29:10 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:29:10 --> Utf8 Class Initialized
INFO - 2018-10-09 19:29:10 --> URI Class Initialized
INFO - 2018-10-09 19:29:10 --> Router Class Initialized
INFO - 2018-10-09 19:29:10 --> Output Class Initialized
INFO - 2018-10-09 19:29:10 --> Security Class Initialized
DEBUG - 2018-10-09 19:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:29:10 --> CSRF cookie sent
INFO - 2018-10-09 19:29:10 --> Input Class Initialized
INFO - 2018-10-09 19:29:10 --> Language Class Initialized
INFO - 2018-10-09 19:29:10 --> Loader Class Initialized
INFO - 2018-10-09 19:29:10 --> Helper loaded: url_helper
INFO - 2018-10-09 19:29:10 --> Helper loaded: form_helper
INFO - 2018-10-09 19:29:10 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:29:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:29:10 --> User Agent Class Initialized
INFO - 2018-10-09 19:29:10 --> Controller Class Initialized
INFO - 2018-10-09 19:29:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 19:29:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 19:29:10 --> Pixel_Model class loaded
INFO - 2018-10-09 19:29:10 --> Database Driver Class Initialized
INFO - 2018-10-09 19:29:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:29:10 --> Database Driver Class Initialized
INFO - 2018-10-09 19:29:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:29:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 19:29:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 19:29:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 19:29:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 19:29:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-10-09 19:29:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 19:29:10 --> Final output sent to browser
DEBUG - 2018-10-09 19:29:10 --> Total execution time: 0.0467
INFO - 2018-10-09 19:30:32 --> Config Class Initialized
INFO - 2018-10-09 19:30:32 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:30:32 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:30:32 --> Utf8 Class Initialized
INFO - 2018-10-09 19:30:32 --> URI Class Initialized
INFO - 2018-10-09 19:30:32 --> Router Class Initialized
INFO - 2018-10-09 19:30:32 --> Output Class Initialized
INFO - 2018-10-09 19:30:32 --> Security Class Initialized
DEBUG - 2018-10-09 19:30:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:30:32 --> CSRF cookie sent
INFO - 2018-10-09 19:30:32 --> Input Class Initialized
INFO - 2018-10-09 19:30:32 --> Language Class Initialized
INFO - 2018-10-09 19:30:32 --> Loader Class Initialized
INFO - 2018-10-09 19:30:32 --> Helper loaded: url_helper
INFO - 2018-10-09 19:30:32 --> Helper loaded: form_helper
INFO - 2018-10-09 19:30:32 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:30:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:30:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:30:32 --> User Agent Class Initialized
ERROR - 2018-10-09 19:30:32 --> Severity: Parsing Error --> syntax error, unexpected '$risk' (T_VARIABLE) /home/fxp6bn7rqemh/public_html/application/libraries/Smart.php 609
INFO - 2018-10-09 19:30:34 --> Config Class Initialized
INFO - 2018-10-09 19:30:34 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:30:34 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:30:34 --> Utf8 Class Initialized
INFO - 2018-10-09 19:30:34 --> URI Class Initialized
INFO - 2018-10-09 19:30:34 --> Router Class Initialized
INFO - 2018-10-09 19:30:34 --> Output Class Initialized
INFO - 2018-10-09 19:30:34 --> Security Class Initialized
DEBUG - 2018-10-09 19:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:30:34 --> CSRF cookie sent
INFO - 2018-10-09 19:30:34 --> Input Class Initialized
INFO - 2018-10-09 19:30:34 --> Language Class Initialized
INFO - 2018-10-09 19:30:34 --> Loader Class Initialized
INFO - 2018-10-09 19:30:34 --> Helper loaded: url_helper
INFO - 2018-10-09 19:30:34 --> Helper loaded: form_helper
INFO - 2018-10-09 19:30:34 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:30:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:30:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:30:34 --> User Agent Class Initialized
ERROR - 2018-10-09 19:30:34 --> Severity: Parsing Error --> syntax error, unexpected '$risk' (T_VARIABLE) /home/fxp6bn7rqemh/public_html/application/libraries/Smart.php 609
INFO - 2018-10-09 19:30:37 --> Config Class Initialized
INFO - 2018-10-09 19:30:37 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:30:37 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:30:37 --> Utf8 Class Initialized
INFO - 2018-10-09 19:30:37 --> URI Class Initialized
INFO - 2018-10-09 19:30:37 --> Router Class Initialized
INFO - 2018-10-09 19:30:37 --> Output Class Initialized
INFO - 2018-10-09 19:30:37 --> Security Class Initialized
DEBUG - 2018-10-09 19:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:30:37 --> CSRF cookie sent
INFO - 2018-10-09 19:30:37 --> Input Class Initialized
INFO - 2018-10-09 19:30:37 --> Language Class Initialized
INFO - 2018-10-09 19:30:37 --> Loader Class Initialized
INFO - 2018-10-09 19:30:37 --> Helper loaded: url_helper
INFO - 2018-10-09 19:30:37 --> Helper loaded: form_helper
INFO - 2018-10-09 19:30:37 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:30:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:30:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:30:37 --> User Agent Class Initialized
ERROR - 2018-10-09 19:30:37 --> Severity: Parsing Error --> syntax error, unexpected '$risk' (T_VARIABLE) /home/fxp6bn7rqemh/public_html/application/libraries/Smart.php 609
INFO - 2018-10-09 19:30:55 --> Config Class Initialized
INFO - 2018-10-09 19:30:55 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:30:55 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:30:55 --> Utf8 Class Initialized
INFO - 2018-10-09 19:30:55 --> URI Class Initialized
INFO - 2018-10-09 19:30:55 --> Router Class Initialized
INFO - 2018-10-09 19:30:55 --> Output Class Initialized
INFO - 2018-10-09 19:30:55 --> Security Class Initialized
DEBUG - 2018-10-09 19:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:30:55 --> CSRF cookie sent
INFO - 2018-10-09 19:30:55 --> Input Class Initialized
INFO - 2018-10-09 19:30:55 --> Language Class Initialized
INFO - 2018-10-09 19:30:55 --> Loader Class Initialized
INFO - 2018-10-09 19:30:55 --> Helper loaded: url_helper
INFO - 2018-10-09 19:30:55 --> Helper loaded: form_helper
INFO - 2018-10-09 19:30:55 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:30:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:30:55 --> User Agent Class Initialized
INFO - 2018-10-09 19:30:55 --> Controller Class Initialized
INFO - 2018-10-09 19:30:55 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 19:30:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 19:30:55 --> Pixel_Model class loaded
INFO - 2018-10-09 19:30:55 --> Database Driver Class Initialized
INFO - 2018-10-09 19:30:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:30:55 --> Database Driver Class Initialized
INFO - 2018-10-09 19:30:55 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:30:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 19:30:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 19:30:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 19:30:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 19:30:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-10-09 19:30:55 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 19:30:55 --> Final output sent to browser
DEBUG - 2018-10-09 19:30:55 --> Total execution time: 0.0474
INFO - 2018-10-09 19:33:18 --> Config Class Initialized
INFO - 2018-10-09 19:33:18 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:33:18 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:33:18 --> Utf8 Class Initialized
INFO - 2018-10-09 19:33:18 --> URI Class Initialized
INFO - 2018-10-09 19:33:18 --> Router Class Initialized
INFO - 2018-10-09 19:33:18 --> Output Class Initialized
INFO - 2018-10-09 19:33:18 --> Security Class Initialized
DEBUG - 2018-10-09 19:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:33:18 --> CSRF cookie sent
INFO - 2018-10-09 19:33:18 --> Input Class Initialized
INFO - 2018-10-09 19:33:18 --> Language Class Initialized
INFO - 2018-10-09 19:33:18 --> Loader Class Initialized
INFO - 2018-10-09 19:33:18 --> Helper loaded: url_helper
INFO - 2018-10-09 19:33:18 --> Helper loaded: form_helper
INFO - 2018-10-09 19:33:18 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:33:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:33:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:33:18 --> User Agent Class Initialized
ERROR - 2018-10-09 19:33:18 --> Severity: Parsing Error --> syntax error, unexpected '$risk' (T_VARIABLE) /home/fxp6bn7rqemh/public_html/application/libraries/Smart.php 609
INFO - 2018-10-09 19:33:33 --> Config Class Initialized
INFO - 2018-10-09 19:33:33 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:33:33 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:33:33 --> Utf8 Class Initialized
INFO - 2018-10-09 19:33:33 --> URI Class Initialized
INFO - 2018-10-09 19:33:33 --> Router Class Initialized
INFO - 2018-10-09 19:33:33 --> Output Class Initialized
INFO - 2018-10-09 19:33:33 --> Security Class Initialized
DEBUG - 2018-10-09 19:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:33:33 --> CSRF cookie sent
INFO - 2018-10-09 19:33:33 --> Input Class Initialized
INFO - 2018-10-09 19:33:33 --> Language Class Initialized
INFO - 2018-10-09 19:33:33 --> Loader Class Initialized
INFO - 2018-10-09 19:33:33 --> Helper loaded: url_helper
INFO - 2018-10-09 19:33:33 --> Helper loaded: form_helper
INFO - 2018-10-09 19:33:33 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:33:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:33:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:33:33 --> User Agent Class Initialized
ERROR - 2018-10-09 19:33:33 --> Severity: Parsing Error --> syntax error, unexpected '$risk' (T_VARIABLE) /home/fxp6bn7rqemh/public_html/application/libraries/Smart.php 609
INFO - 2018-10-09 19:33:36 --> Config Class Initialized
INFO - 2018-10-09 19:33:36 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:33:36 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:33:36 --> Utf8 Class Initialized
INFO - 2018-10-09 19:33:36 --> URI Class Initialized
INFO - 2018-10-09 19:33:36 --> Router Class Initialized
INFO - 2018-10-09 19:33:36 --> Output Class Initialized
INFO - 2018-10-09 19:33:36 --> Security Class Initialized
DEBUG - 2018-10-09 19:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:33:36 --> CSRF cookie sent
INFO - 2018-10-09 19:33:36 --> Input Class Initialized
INFO - 2018-10-09 19:33:36 --> Language Class Initialized
INFO - 2018-10-09 19:33:36 --> Loader Class Initialized
INFO - 2018-10-09 19:33:36 --> Helper loaded: url_helper
INFO - 2018-10-09 19:33:36 --> Helper loaded: form_helper
INFO - 2018-10-09 19:33:36 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:33:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:33:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:33:36 --> User Agent Class Initialized
ERROR - 2018-10-09 19:33:36 --> Severity: Parsing Error --> syntax error, unexpected '$risk' (T_VARIABLE) /home/fxp6bn7rqemh/public_html/application/libraries/Smart.php 609
INFO - 2018-10-09 19:33:37 --> Config Class Initialized
INFO - 2018-10-09 19:33:37 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:33:37 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:33:37 --> Utf8 Class Initialized
INFO - 2018-10-09 19:33:37 --> URI Class Initialized
INFO - 2018-10-09 19:33:37 --> Router Class Initialized
INFO - 2018-10-09 19:33:37 --> Output Class Initialized
INFO - 2018-10-09 19:33:37 --> Security Class Initialized
DEBUG - 2018-10-09 19:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:33:37 --> CSRF cookie sent
INFO - 2018-10-09 19:33:37 --> Input Class Initialized
INFO - 2018-10-09 19:33:37 --> Language Class Initialized
INFO - 2018-10-09 19:33:37 --> Loader Class Initialized
INFO - 2018-10-09 19:33:37 --> Helper loaded: url_helper
INFO - 2018-10-09 19:33:37 --> Helper loaded: form_helper
INFO - 2018-10-09 19:33:37 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:33:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:33:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:33:37 --> User Agent Class Initialized
ERROR - 2018-10-09 19:33:37 --> Severity: Parsing Error --> syntax error, unexpected '$risk' (T_VARIABLE) /home/fxp6bn7rqemh/public_html/application/libraries/Smart.php 609
INFO - 2018-10-09 19:33:38 --> Config Class Initialized
INFO - 2018-10-09 19:33:38 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:33:38 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:33:38 --> Utf8 Class Initialized
INFO - 2018-10-09 19:33:38 --> URI Class Initialized
INFO - 2018-10-09 19:33:38 --> Router Class Initialized
INFO - 2018-10-09 19:33:38 --> Output Class Initialized
INFO - 2018-10-09 19:33:38 --> Security Class Initialized
DEBUG - 2018-10-09 19:33:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:33:38 --> CSRF cookie sent
INFO - 2018-10-09 19:33:38 --> Input Class Initialized
INFO - 2018-10-09 19:33:38 --> Language Class Initialized
INFO - 2018-10-09 19:33:38 --> Loader Class Initialized
INFO - 2018-10-09 19:33:38 --> Helper loaded: url_helper
INFO - 2018-10-09 19:33:38 --> Helper loaded: form_helper
INFO - 2018-10-09 19:33:38 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:33:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:33:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:33:38 --> User Agent Class Initialized
ERROR - 2018-10-09 19:33:38 --> Severity: Parsing Error --> syntax error, unexpected '$risk' (T_VARIABLE) /home/fxp6bn7rqemh/public_html/application/libraries/Smart.php 609
INFO - 2018-10-09 19:33:41 --> Config Class Initialized
INFO - 2018-10-09 19:33:41 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:33:41 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:33:41 --> Utf8 Class Initialized
INFO - 2018-10-09 19:33:41 --> URI Class Initialized
INFO - 2018-10-09 19:33:41 --> Router Class Initialized
INFO - 2018-10-09 19:33:41 --> Output Class Initialized
INFO - 2018-10-09 19:33:41 --> Security Class Initialized
DEBUG - 2018-10-09 19:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:33:41 --> CSRF cookie sent
INFO - 2018-10-09 19:33:41 --> Input Class Initialized
INFO - 2018-10-09 19:33:41 --> Language Class Initialized
INFO - 2018-10-09 19:33:41 --> Loader Class Initialized
INFO - 2018-10-09 19:33:41 --> Helper loaded: url_helper
INFO - 2018-10-09 19:33:41 --> Helper loaded: form_helper
INFO - 2018-10-09 19:33:41 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:33:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:33:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:33:41 --> User Agent Class Initialized
ERROR - 2018-10-09 19:33:41 --> Severity: Parsing Error --> syntax error, unexpected '$risk' (T_VARIABLE) /home/fxp6bn7rqemh/public_html/application/libraries/Smart.php 609
INFO - 2018-10-09 19:33:58 --> Config Class Initialized
INFO - 2018-10-09 19:33:58 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:33:58 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:33:58 --> Utf8 Class Initialized
INFO - 2018-10-09 19:33:58 --> URI Class Initialized
INFO - 2018-10-09 19:33:58 --> Router Class Initialized
INFO - 2018-10-09 19:33:58 --> Output Class Initialized
INFO - 2018-10-09 19:33:58 --> Security Class Initialized
DEBUG - 2018-10-09 19:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:33:58 --> CSRF cookie sent
INFO - 2018-10-09 19:33:58 --> Input Class Initialized
INFO - 2018-10-09 19:33:58 --> Language Class Initialized
INFO - 2018-10-09 19:33:58 --> Loader Class Initialized
INFO - 2018-10-09 19:33:58 --> Helper loaded: url_helper
INFO - 2018-10-09 19:33:58 --> Helper loaded: form_helper
INFO - 2018-10-09 19:33:58 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:33:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:33:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:33:58 --> User Agent Class Initialized
ERROR - 2018-10-09 19:33:58 --> Severity: Parsing Error --> syntax error, unexpected '$risk' (T_VARIABLE) /home/fxp6bn7rqemh/public_html/application/libraries/Smart.php 609
INFO - 2018-10-09 19:33:59 --> Config Class Initialized
INFO - 2018-10-09 19:33:59 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:33:59 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:33:59 --> Utf8 Class Initialized
INFO - 2018-10-09 19:33:59 --> URI Class Initialized
INFO - 2018-10-09 19:33:59 --> Router Class Initialized
INFO - 2018-10-09 19:33:59 --> Output Class Initialized
INFO - 2018-10-09 19:33:59 --> Security Class Initialized
DEBUG - 2018-10-09 19:33:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:33:59 --> CSRF cookie sent
INFO - 2018-10-09 19:33:59 --> Input Class Initialized
INFO - 2018-10-09 19:33:59 --> Language Class Initialized
INFO - 2018-10-09 19:33:59 --> Loader Class Initialized
INFO - 2018-10-09 19:33:59 --> Helper loaded: url_helper
INFO - 2018-10-09 19:33:59 --> Helper loaded: form_helper
INFO - 2018-10-09 19:33:59 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:33:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:33:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:33:59 --> User Agent Class Initialized
ERROR - 2018-10-09 19:33:59 --> Severity: Parsing Error --> syntax error, unexpected '$risk' (T_VARIABLE) /home/fxp6bn7rqemh/public_html/application/libraries/Smart.php 609
INFO - 2018-10-09 19:34:00 --> Config Class Initialized
INFO - 2018-10-09 19:34:00 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:34:00 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:34:00 --> Utf8 Class Initialized
INFO - 2018-10-09 19:34:00 --> URI Class Initialized
INFO - 2018-10-09 19:34:00 --> Router Class Initialized
INFO - 2018-10-09 19:34:00 --> Output Class Initialized
INFO - 2018-10-09 19:34:00 --> Security Class Initialized
DEBUG - 2018-10-09 19:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:34:00 --> CSRF cookie sent
INFO - 2018-10-09 19:34:00 --> Input Class Initialized
INFO - 2018-10-09 19:34:00 --> Language Class Initialized
INFO - 2018-10-09 19:34:00 --> Loader Class Initialized
INFO - 2018-10-09 19:34:00 --> Helper loaded: url_helper
INFO - 2018-10-09 19:34:00 --> Helper loaded: form_helper
INFO - 2018-10-09 19:34:00 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:34:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:34:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:34:00 --> User Agent Class Initialized
ERROR - 2018-10-09 19:34:00 --> Severity: Parsing Error --> syntax error, unexpected '$risk' (T_VARIABLE) /home/fxp6bn7rqemh/public_html/application/libraries/Smart.php 609
INFO - 2018-10-09 19:34:41 --> Config Class Initialized
INFO - 2018-10-09 19:34:41 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:34:41 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:34:41 --> Utf8 Class Initialized
INFO - 2018-10-09 19:34:41 --> URI Class Initialized
INFO - 2018-10-09 19:34:41 --> Router Class Initialized
INFO - 2018-10-09 19:34:41 --> Output Class Initialized
INFO - 2018-10-09 19:34:41 --> Security Class Initialized
DEBUG - 2018-10-09 19:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:34:41 --> CSRF cookie sent
INFO - 2018-10-09 19:34:41 --> Input Class Initialized
INFO - 2018-10-09 19:34:41 --> Language Class Initialized
INFO - 2018-10-09 19:34:41 --> Loader Class Initialized
INFO - 2018-10-09 19:34:41 --> Helper loaded: url_helper
INFO - 2018-10-09 19:34:41 --> Helper loaded: form_helper
INFO - 2018-10-09 19:34:41 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:34:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:34:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:34:41 --> User Agent Class Initialized
INFO - 2018-10-09 19:34:41 --> Controller Class Initialized
INFO - 2018-10-09 19:34:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 19:34:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 19:34:41 --> Pixel_Model class loaded
INFO - 2018-10-09 19:34:41 --> Database Driver Class Initialized
INFO - 2018-10-09 19:34:41 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:34:41 --> Database Driver Class Initialized
INFO - 2018-10-09 19:34:41 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:34:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 19:34:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 19:34:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 19:34:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 19:34:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 19:34:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 19:34:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-10-09 19:34:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 19:34:41 --> Final output sent to browser
DEBUG - 2018-10-09 19:34:41 --> Total execution time: 0.0506
INFO - 2018-10-09 19:34:43 --> Config Class Initialized
INFO - 2018-10-09 19:34:43 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:34:43 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:34:43 --> Utf8 Class Initialized
INFO - 2018-10-09 19:34:43 --> URI Class Initialized
INFO - 2018-10-09 19:34:43 --> Router Class Initialized
INFO - 2018-10-09 19:34:43 --> Output Class Initialized
INFO - 2018-10-09 19:34:43 --> Security Class Initialized
DEBUG - 2018-10-09 19:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:34:43 --> CSRF cookie sent
INFO - 2018-10-09 19:34:43 --> Input Class Initialized
INFO - 2018-10-09 19:34:43 --> Language Class Initialized
INFO - 2018-10-09 19:34:43 --> Loader Class Initialized
INFO - 2018-10-09 19:34:43 --> Helper loaded: url_helper
INFO - 2018-10-09 19:34:43 --> Helper loaded: form_helper
INFO - 2018-10-09 19:34:43 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:34:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:34:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:34:43 --> User Agent Class Initialized
INFO - 2018-10-09 19:34:43 --> Controller Class Initialized
INFO - 2018-10-09 19:34:43 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 19:34:43 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 19:34:43 --> Pixel_Model class loaded
INFO - 2018-10-09 19:34:43 --> Database Driver Class Initialized
INFO - 2018-10-09 19:34:43 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:34:43 --> Database Driver Class Initialized
INFO - 2018-10-09 19:34:43 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:34:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 19:34:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 19:34:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 19:34:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 19:34:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-10-09 19:34:43 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 19:34:43 --> Final output sent to browser
DEBUG - 2018-10-09 19:34:43 --> Total execution time: 0.0479
INFO - 2018-10-09 19:34:47 --> Config Class Initialized
INFO - 2018-10-09 19:34:47 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:34:47 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:34:47 --> Utf8 Class Initialized
INFO - 2018-10-09 19:34:47 --> URI Class Initialized
INFO - 2018-10-09 19:34:47 --> Router Class Initialized
INFO - 2018-10-09 19:34:47 --> Output Class Initialized
INFO - 2018-10-09 19:34:47 --> Security Class Initialized
DEBUG - 2018-10-09 19:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:34:47 --> CSRF cookie sent
INFO - 2018-10-09 19:34:47 --> Input Class Initialized
INFO - 2018-10-09 19:34:47 --> Language Class Initialized
INFO - 2018-10-09 19:34:47 --> Loader Class Initialized
INFO - 2018-10-09 19:34:47 --> Helper loaded: url_helper
INFO - 2018-10-09 19:34:47 --> Helper loaded: form_helper
INFO - 2018-10-09 19:34:47 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:34:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:34:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:34:47 --> User Agent Class Initialized
INFO - 2018-10-09 19:34:47 --> Controller Class Initialized
INFO - 2018-10-09 19:34:47 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 19:34:47 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 19:34:47 --> Pixel_Model class loaded
INFO - 2018-10-09 19:34:47 --> Database Driver Class Initialized
INFO - 2018-10-09 19:34:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:34:47 --> Database Driver Class Initialized
INFO - 2018-10-09 19:34:47 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:34:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 19:34:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 19:34:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 19:34:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 19:34:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 19:34:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 19:34:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-10-09 19:34:47 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 19:34:47 --> Final output sent to browser
DEBUG - 2018-10-09 19:34:47 --> Total execution time: 0.0661
INFO - 2018-10-09 19:44:40 --> Config Class Initialized
INFO - 2018-10-09 19:44:40 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:44:40 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:44:40 --> Utf8 Class Initialized
INFO - 2018-10-09 19:44:40 --> URI Class Initialized
DEBUG - 2018-10-09 19:44:40 --> No URI present. Default controller set.
INFO - 2018-10-09 19:44:40 --> Router Class Initialized
INFO - 2018-10-09 19:44:40 --> Output Class Initialized
INFO - 2018-10-09 19:44:40 --> Security Class Initialized
DEBUG - 2018-10-09 19:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:44:40 --> CSRF cookie sent
INFO - 2018-10-09 19:44:40 --> Input Class Initialized
INFO - 2018-10-09 19:44:40 --> Language Class Initialized
INFO - 2018-10-09 19:44:40 --> Loader Class Initialized
INFO - 2018-10-09 19:44:40 --> Helper loaded: url_helper
INFO - 2018-10-09 19:44:40 --> Helper loaded: form_helper
INFO - 2018-10-09 19:44:40 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:44:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:44:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:44:40 --> User Agent Class Initialized
INFO - 2018-10-09 19:44:40 --> Controller Class Initialized
INFO - 2018-10-09 19:44:40 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 19:44:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 19:44:40 --> Pixel_Model class loaded
INFO - 2018-10-09 19:44:40 --> Database Driver Class Initialized
INFO - 2018-10-09 19:44:40 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:44:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 19:44:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 19:44:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-09 19:44:40 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 19:44:40 --> Final output sent to browser
DEBUG - 2018-10-09 19:44:40 --> Total execution time: 0.0429
INFO - 2018-10-09 19:44:49 --> Config Class Initialized
INFO - 2018-10-09 19:44:49 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:44:49 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:44:49 --> Utf8 Class Initialized
INFO - 2018-10-09 19:44:49 --> URI Class Initialized
INFO - 2018-10-09 19:44:49 --> Router Class Initialized
INFO - 2018-10-09 19:44:49 --> Output Class Initialized
INFO - 2018-10-09 19:44:49 --> Security Class Initialized
DEBUG - 2018-10-09 19:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:44:49 --> CSRF cookie sent
INFO - 2018-10-09 19:44:49 --> Input Class Initialized
INFO - 2018-10-09 19:44:49 --> Language Class Initialized
INFO - 2018-10-09 19:44:49 --> Loader Class Initialized
INFO - 2018-10-09 19:44:49 --> Helper loaded: url_helper
INFO - 2018-10-09 19:44:49 --> Helper loaded: form_helper
INFO - 2018-10-09 19:44:49 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:44:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:44:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:44:49 --> User Agent Class Initialized
INFO - 2018-10-09 19:44:49 --> Controller Class Initialized
INFO - 2018-10-09 19:44:49 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 19:44:49 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 19:44:49 --> Pixel_Model class loaded
INFO - 2018-10-09 19:44:49 --> Database Driver Class Initialized
INFO - 2018-10-09 19:44:49 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:44:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 19:44:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 19:44:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 19:44:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 19:44:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 19:44:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 19:44:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-10-09 19:44:49 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 19:44:49 --> Final output sent to browser
DEBUG - 2018-10-09 19:44:49 --> Total execution time: 0.0500
INFO - 2018-10-09 19:44:54 --> Config Class Initialized
INFO - 2018-10-09 19:44:54 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:44:54 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:44:54 --> Utf8 Class Initialized
INFO - 2018-10-09 19:44:54 --> URI Class Initialized
INFO - 2018-10-09 19:44:54 --> Router Class Initialized
INFO - 2018-10-09 19:44:54 --> Output Class Initialized
INFO - 2018-10-09 19:44:54 --> Security Class Initialized
DEBUG - 2018-10-09 19:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:44:54 --> CSRF cookie sent
INFO - 2018-10-09 19:44:54 --> CSRF token verified
INFO - 2018-10-09 19:44:54 --> Input Class Initialized
INFO - 2018-10-09 19:44:54 --> Language Class Initialized
INFO - 2018-10-09 19:44:54 --> Loader Class Initialized
INFO - 2018-10-09 19:44:54 --> Helper loaded: url_helper
INFO - 2018-10-09 19:44:54 --> Helper loaded: form_helper
INFO - 2018-10-09 19:44:54 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:44:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:44:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:44:54 --> User Agent Class Initialized
INFO - 2018-10-09 19:44:54 --> Controller Class Initialized
INFO - 2018-10-09 19:44:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 19:44:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 19:44:54 --> Pixel_Model class loaded
INFO - 2018-10-09 19:44:54 --> Database Driver Class Initialized
INFO - 2018-10-09 19:44:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:44:54 --> Database Driver Class Initialized
INFO - 2018-10-09 19:44:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:44:54 --> Config Class Initialized
INFO - 2018-10-09 19:44:54 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:44:54 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:44:54 --> Utf8 Class Initialized
INFO - 2018-10-09 19:44:54 --> URI Class Initialized
INFO - 2018-10-09 19:44:54 --> Router Class Initialized
INFO - 2018-10-09 19:44:54 --> Output Class Initialized
INFO - 2018-10-09 19:44:54 --> Security Class Initialized
DEBUG - 2018-10-09 19:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:44:54 --> CSRF cookie sent
INFO - 2018-10-09 19:44:54 --> Input Class Initialized
INFO - 2018-10-09 19:44:54 --> Language Class Initialized
INFO - 2018-10-09 19:44:54 --> Loader Class Initialized
INFO - 2018-10-09 19:44:54 --> Helper loaded: url_helper
INFO - 2018-10-09 19:44:54 --> Helper loaded: form_helper
INFO - 2018-10-09 19:44:54 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:44:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:44:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:44:54 --> User Agent Class Initialized
INFO - 2018-10-09 19:44:54 --> Controller Class Initialized
INFO - 2018-10-09 19:44:54 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 19:44:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 19:44:54 --> Pixel_Model class loaded
INFO - 2018-10-09 19:44:54 --> Database Driver Class Initialized
INFO - 2018-10-09 19:44:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:44:54 --> Database Driver Class Initialized
INFO - 2018-10-09 19:44:54 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:44:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 19:44:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 19:44:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 19:44:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 19:44:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 19:44:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 19:44:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-09 19:44:54 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 19:44:54 --> Final output sent to browser
DEBUG - 2018-10-09 19:44:54 --> Total execution time: 0.0546
INFO - 2018-10-09 19:44:58 --> Config Class Initialized
INFO - 2018-10-09 19:44:58 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:44:58 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:44:58 --> Utf8 Class Initialized
INFO - 2018-10-09 19:44:58 --> URI Class Initialized
INFO - 2018-10-09 19:44:58 --> Router Class Initialized
INFO - 2018-10-09 19:44:58 --> Output Class Initialized
INFO - 2018-10-09 19:44:58 --> Security Class Initialized
DEBUG - 2018-10-09 19:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:44:58 --> CSRF cookie sent
INFO - 2018-10-09 19:44:58 --> CSRF token verified
INFO - 2018-10-09 19:44:58 --> Input Class Initialized
INFO - 2018-10-09 19:44:58 --> Language Class Initialized
INFO - 2018-10-09 19:44:58 --> Loader Class Initialized
INFO - 2018-10-09 19:44:58 --> Helper loaded: url_helper
INFO - 2018-10-09 19:44:58 --> Helper loaded: form_helper
INFO - 2018-10-09 19:44:58 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:44:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:44:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:44:58 --> User Agent Class Initialized
INFO - 2018-10-09 19:44:58 --> Controller Class Initialized
INFO - 2018-10-09 19:44:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 19:44:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 19:44:58 --> Pixel_Model class loaded
INFO - 2018-10-09 19:44:58 --> Database Driver Class Initialized
INFO - 2018-10-09 19:44:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:44:58 --> Form Validation Class Initialized
INFO - 2018-10-09 19:44:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 19:44:58 --> Database Driver Class Initialized
INFO - 2018-10-09 19:44:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:44:58 --> Config Class Initialized
INFO - 2018-10-09 19:44:58 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:44:58 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:44:58 --> Utf8 Class Initialized
INFO - 2018-10-09 19:44:58 --> URI Class Initialized
INFO - 2018-10-09 19:44:58 --> Router Class Initialized
INFO - 2018-10-09 19:44:58 --> Output Class Initialized
INFO - 2018-10-09 19:44:58 --> Security Class Initialized
DEBUG - 2018-10-09 19:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:44:58 --> CSRF cookie sent
INFO - 2018-10-09 19:44:58 --> Input Class Initialized
INFO - 2018-10-09 19:44:58 --> Language Class Initialized
INFO - 2018-10-09 19:44:58 --> Loader Class Initialized
INFO - 2018-10-09 19:44:58 --> Helper loaded: url_helper
INFO - 2018-10-09 19:44:58 --> Helper loaded: form_helper
INFO - 2018-10-09 19:44:58 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:44:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:44:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:44:58 --> User Agent Class Initialized
INFO - 2018-10-09 19:44:58 --> Controller Class Initialized
INFO - 2018-10-09 19:44:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 19:44:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 19:44:58 --> Pixel_Model class loaded
INFO - 2018-10-09 19:44:58 --> Database Driver Class Initialized
INFO - 2018-10-09 19:44:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:44:58 --> Database Driver Class Initialized
INFO - 2018-10-09 19:44:58 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:44:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 19:44:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 19:44:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 19:44:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 19:44:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 19:44:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 19:44:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-10-09 19:44:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 19:44:58 --> Final output sent to browser
DEBUG - 2018-10-09 19:44:58 --> Total execution time: 0.0565
INFO - 2018-10-09 19:45:01 --> Config Class Initialized
INFO - 2018-10-09 19:45:01 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:45:01 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:45:01 --> Utf8 Class Initialized
INFO - 2018-10-09 19:45:01 --> URI Class Initialized
INFO - 2018-10-09 19:45:01 --> Router Class Initialized
INFO - 2018-10-09 19:45:01 --> Output Class Initialized
INFO - 2018-10-09 19:45:01 --> Security Class Initialized
DEBUG - 2018-10-09 19:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:45:01 --> CSRF cookie sent
INFO - 2018-10-09 19:45:01 --> Input Class Initialized
INFO - 2018-10-09 19:45:01 --> Language Class Initialized
INFO - 2018-10-09 19:45:01 --> Loader Class Initialized
INFO - 2018-10-09 19:45:01 --> Helper loaded: url_helper
INFO - 2018-10-09 19:45:01 --> Helper loaded: form_helper
INFO - 2018-10-09 19:45:01 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:45:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:45:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:45:01 --> User Agent Class Initialized
INFO - 2018-10-09 19:45:01 --> Controller Class Initialized
INFO - 2018-10-09 19:45:01 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 19:45:01 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 19:45:01 --> Pixel_Model class loaded
INFO - 2018-10-09 19:45:01 --> Database Driver Class Initialized
INFO - 2018-10-09 19:45:01 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:45:01 --> Database Driver Class Initialized
INFO - 2018-10-09 19:45:01 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:45:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 19:45:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 19:45:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 19:45:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 19:45:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/save_exit.php
INFO - 2018-10-09 19:45:01 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 19:45:01 --> Final output sent to browser
DEBUG - 2018-10-09 19:45:01 --> Total execution time: 0.0460
INFO - 2018-10-09 19:45:02 --> Config Class Initialized
INFO - 2018-10-09 19:45:02 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:45:02 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:45:02 --> Utf8 Class Initialized
INFO - 2018-10-09 19:45:02 --> URI Class Initialized
INFO - 2018-10-09 19:45:02 --> Router Class Initialized
INFO - 2018-10-09 19:45:02 --> Output Class Initialized
INFO - 2018-10-09 19:45:02 --> Security Class Initialized
DEBUG - 2018-10-09 19:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:45:02 --> CSRF cookie sent
INFO - 2018-10-09 19:45:02 --> Input Class Initialized
INFO - 2018-10-09 19:45:02 --> Language Class Initialized
INFO - 2018-10-09 19:45:02 --> Loader Class Initialized
INFO - 2018-10-09 19:45:02 --> Helper loaded: url_helper
INFO - 2018-10-09 19:45:02 --> Helper loaded: form_helper
INFO - 2018-10-09 19:45:02 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:45:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:45:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:45:02 --> User Agent Class Initialized
INFO - 2018-10-09 19:45:02 --> Controller Class Initialized
INFO - 2018-10-09 19:45:02 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 19:45:02 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 19:45:02 --> Pixel_Model class loaded
INFO - 2018-10-09 19:45:02 --> Database Driver Class Initialized
INFO - 2018-10-09 19:45:02 --> Model "RegistrationModel" initialized
DEBUG - 2018-10-09 19:45:02 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-10-09 19:45:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 19:45:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 19:45:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 19:45:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-10-09 19:45:02 --> Could not find the language line "req_email"
INFO - 2018-10-09 19:45:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup.php
INFO - 2018-10-09 19:45:02 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 19:45:02 --> Final output sent to browser
DEBUG - 2018-10-09 19:45:02 --> Total execution time: 0.0886
INFO - 2018-10-09 19:45:04 --> Config Class Initialized
INFO - 2018-10-09 19:45:04 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:45:04 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:45:04 --> Utf8 Class Initialized
INFO - 2018-10-09 19:45:04 --> URI Class Initialized
INFO - 2018-10-09 19:45:04 --> Router Class Initialized
INFO - 2018-10-09 19:45:04 --> Output Class Initialized
INFO - 2018-10-09 19:45:04 --> Security Class Initialized
DEBUG - 2018-10-09 19:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:45:04 --> CSRF cookie sent
INFO - 2018-10-09 19:45:04 --> Input Class Initialized
INFO - 2018-10-09 19:45:04 --> Language Class Initialized
INFO - 2018-10-09 19:45:04 --> Loader Class Initialized
INFO - 2018-10-09 19:45:04 --> Helper loaded: url_helper
INFO - 2018-10-09 19:45:04 --> Helper loaded: form_helper
INFO - 2018-10-09 19:45:04 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:45:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:45:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:45:04 --> User Agent Class Initialized
INFO - 2018-10-09 19:45:04 --> Controller Class Initialized
INFO - 2018-10-09 19:45:04 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 19:45:04 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 19:45:04 --> Pixel_Model class loaded
INFO - 2018-10-09 19:45:04 --> Database Driver Class Initialized
INFO - 2018-10-09 19:45:04 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:45:04 --> Database Driver Class Initialized
INFO - 2018-10-09 19:45:04 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:45:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 19:45:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 19:45:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 19:45:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 19:45:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/save_exit.php
INFO - 2018-10-09 19:45:04 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 19:45:04 --> Final output sent to browser
DEBUG - 2018-10-09 19:45:04 --> Total execution time: 0.0468
INFO - 2018-10-09 19:45:06 --> Config Class Initialized
INFO - 2018-10-09 19:45:06 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:45:06 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:45:06 --> Utf8 Class Initialized
INFO - 2018-10-09 19:45:06 --> URI Class Initialized
INFO - 2018-10-09 19:45:06 --> Router Class Initialized
INFO - 2018-10-09 19:45:06 --> Output Class Initialized
INFO - 2018-10-09 19:45:06 --> Security Class Initialized
DEBUG - 2018-10-09 19:45:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:45:06 --> CSRF cookie sent
INFO - 2018-10-09 19:45:06 --> Input Class Initialized
INFO - 2018-10-09 19:45:06 --> Language Class Initialized
INFO - 2018-10-09 19:45:06 --> Loader Class Initialized
INFO - 2018-10-09 19:45:06 --> Helper loaded: url_helper
INFO - 2018-10-09 19:45:06 --> Helper loaded: form_helper
INFO - 2018-10-09 19:45:06 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:45:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:45:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:45:06 --> User Agent Class Initialized
INFO - 2018-10-09 19:45:06 --> Controller Class Initialized
INFO - 2018-10-09 19:45:06 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 19:45:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 19:45:06 --> Pixel_Model class loaded
INFO - 2018-10-09 19:45:06 --> Database Driver Class Initialized
INFO - 2018-10-09 19:45:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:45:06 --> Database Driver Class Initialized
INFO - 2018-10-09 19:45:06 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:45:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 19:45:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 19:45:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 19:45:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 19:45:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 19:45:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 19:45:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-10-09 19:45:06 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 19:45:06 --> Final output sent to browser
DEBUG - 2018-10-09 19:45:06 --> Total execution time: 0.0465
INFO - 2018-10-09 19:45:07 --> Config Class Initialized
INFO - 2018-10-09 19:45:07 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:45:07 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:45:07 --> Utf8 Class Initialized
INFO - 2018-10-09 19:45:07 --> URI Class Initialized
INFO - 2018-10-09 19:45:07 --> Router Class Initialized
INFO - 2018-10-09 19:45:07 --> Output Class Initialized
INFO - 2018-10-09 19:45:07 --> Security Class Initialized
DEBUG - 2018-10-09 19:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:45:07 --> CSRF cookie sent
INFO - 2018-10-09 19:45:07 --> CSRF token verified
INFO - 2018-10-09 19:45:07 --> Input Class Initialized
INFO - 2018-10-09 19:45:07 --> Language Class Initialized
INFO - 2018-10-09 19:45:07 --> Loader Class Initialized
INFO - 2018-10-09 19:45:07 --> Helper loaded: url_helper
INFO - 2018-10-09 19:45:07 --> Helper loaded: form_helper
INFO - 2018-10-09 19:45:07 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:45:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:45:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:45:07 --> User Agent Class Initialized
INFO - 2018-10-09 19:45:07 --> Controller Class Initialized
INFO - 2018-10-09 19:45:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 19:45:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 19:45:07 --> Pixel_Model class loaded
INFO - 2018-10-09 19:45:07 --> Database Driver Class Initialized
INFO - 2018-10-09 19:45:07 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:45:07 --> Form Validation Class Initialized
INFO - 2018-10-09 19:45:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 19:45:07 --> Database Driver Class Initialized
INFO - 2018-10-09 19:45:07 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:45:07 --> Config Class Initialized
INFO - 2018-10-09 19:45:07 --> Hooks Class Initialized
DEBUG - 2018-10-09 19:45:07 --> UTF-8 Support Enabled
INFO - 2018-10-09 19:45:07 --> Utf8 Class Initialized
INFO - 2018-10-09 19:45:07 --> URI Class Initialized
INFO - 2018-10-09 19:45:07 --> Router Class Initialized
INFO - 2018-10-09 19:45:07 --> Output Class Initialized
INFO - 2018-10-09 19:45:07 --> Security Class Initialized
DEBUG - 2018-10-09 19:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 19:45:07 --> CSRF cookie sent
INFO - 2018-10-09 19:45:07 --> Input Class Initialized
INFO - 2018-10-09 19:45:07 --> Language Class Initialized
INFO - 2018-10-09 19:45:07 --> Loader Class Initialized
INFO - 2018-10-09 19:45:07 --> Helper loaded: url_helper
INFO - 2018-10-09 19:45:07 --> Helper loaded: form_helper
INFO - 2018-10-09 19:45:07 --> Helper loaded: language_helper
DEBUG - 2018-10-09 19:45:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 19:45:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 19:45:07 --> User Agent Class Initialized
INFO - 2018-10-09 19:45:07 --> Controller Class Initialized
INFO - 2018-10-09 19:45:07 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 19:45:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 19:45:07 --> Pixel_Model class loaded
INFO - 2018-10-09 19:45:07 --> Database Driver Class Initialized
INFO - 2018-10-09 19:45:07 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:45:07 --> Database Driver Class Initialized
INFO - 2018-10-09 19:45:07 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 19:45:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 19:45:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 19:45:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-10-09 19:45:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 19:45:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 19:45:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 19:45:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 19:45:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-10-09 19:45:07 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 19:45:07 --> Final output sent to browser
DEBUG - 2018-10-09 19:45:07 --> Total execution time: 0.0396
INFO - 2018-10-09 20:02:26 --> Config Class Initialized
INFO - 2018-10-09 20:02:26 --> Hooks Class Initialized
DEBUG - 2018-10-09 20:02:26 --> UTF-8 Support Enabled
INFO - 2018-10-09 20:02:26 --> Utf8 Class Initialized
INFO - 2018-10-09 20:02:26 --> URI Class Initialized
DEBUG - 2018-10-09 20:02:26 --> No URI present. Default controller set.
INFO - 2018-10-09 20:02:26 --> Router Class Initialized
INFO - 2018-10-09 20:02:26 --> Output Class Initialized
INFO - 2018-10-09 20:02:26 --> Security Class Initialized
DEBUG - 2018-10-09 20:02:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 20:02:26 --> CSRF cookie sent
INFO - 2018-10-09 20:02:26 --> Input Class Initialized
INFO - 2018-10-09 20:02:26 --> Language Class Initialized
INFO - 2018-10-09 20:02:26 --> Loader Class Initialized
INFO - 2018-10-09 20:02:26 --> Helper loaded: url_helper
INFO - 2018-10-09 20:02:26 --> Helper loaded: form_helper
INFO - 2018-10-09 20:02:26 --> Helper loaded: language_helper
DEBUG - 2018-10-09 20:02:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 20:02:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 20:02:26 --> User Agent Class Initialized
INFO - 2018-10-09 20:02:26 --> Controller Class Initialized
INFO - 2018-10-09 20:02:26 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 20:02:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 20:02:26 --> Pixel_Model class loaded
INFO - 2018-10-09 20:02:26 --> Database Driver Class Initialized
INFO - 2018-10-09 20:02:26 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 20:02:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 20:02:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 20:02:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-09 20:02:26 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 20:02:26 --> Final output sent to browser
DEBUG - 2018-10-09 20:02:26 --> Total execution time: 0.0352
INFO - 2018-10-09 20:07:27 --> Config Class Initialized
INFO - 2018-10-09 20:07:27 --> Hooks Class Initialized
DEBUG - 2018-10-09 20:07:27 --> UTF-8 Support Enabled
INFO - 2018-10-09 20:07:27 --> Utf8 Class Initialized
INFO - 2018-10-09 20:07:27 --> URI Class Initialized
INFO - 2018-10-09 20:07:27 --> Router Class Initialized
INFO - 2018-10-09 20:07:27 --> Output Class Initialized
INFO - 2018-10-09 20:07:27 --> Security Class Initialized
DEBUG - 2018-10-09 20:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 20:07:27 --> CSRF cookie sent
INFO - 2018-10-09 20:07:27 --> CSRF token verified
INFO - 2018-10-09 20:07:27 --> Input Class Initialized
INFO - 2018-10-09 20:07:27 --> Language Class Initialized
INFO - 2018-10-09 20:07:27 --> Loader Class Initialized
INFO - 2018-10-09 20:07:27 --> Helper loaded: url_helper
INFO - 2018-10-09 20:07:27 --> Helper loaded: form_helper
INFO - 2018-10-09 20:07:27 --> Helper loaded: language_helper
DEBUG - 2018-10-09 20:07:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 20:07:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 20:07:27 --> User Agent Class Initialized
INFO - 2018-10-09 20:07:27 --> Controller Class Initialized
INFO - 2018-10-09 20:07:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 20:07:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 20:07:27 --> Pixel_Model class loaded
INFO - 2018-10-09 20:07:27 --> Database Driver Class Initialized
INFO - 2018-10-09 20:07:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 20:07:27 --> Form Validation Class Initialized
INFO - 2018-10-09 20:07:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 20:07:27 --> Database Driver Class Initialized
INFO - 2018-10-09 20:07:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 20:07:27 --> Config Class Initialized
INFO - 2018-10-09 20:07:27 --> Hooks Class Initialized
DEBUG - 2018-10-09 20:07:27 --> UTF-8 Support Enabled
INFO - 2018-10-09 20:07:27 --> Utf8 Class Initialized
INFO - 2018-10-09 20:07:27 --> URI Class Initialized
INFO - 2018-10-09 20:07:27 --> Router Class Initialized
INFO - 2018-10-09 20:07:27 --> Output Class Initialized
INFO - 2018-10-09 20:07:27 --> Security Class Initialized
DEBUG - 2018-10-09 20:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 20:07:27 --> CSRF cookie sent
INFO - 2018-10-09 20:07:27 --> Input Class Initialized
INFO - 2018-10-09 20:07:27 --> Language Class Initialized
INFO - 2018-10-09 20:07:27 --> Loader Class Initialized
INFO - 2018-10-09 20:07:27 --> Helper loaded: url_helper
INFO - 2018-10-09 20:07:27 --> Helper loaded: form_helper
INFO - 2018-10-09 20:07:27 --> Helper loaded: language_helper
DEBUG - 2018-10-09 20:07:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 20:07:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 20:07:27 --> User Agent Class Initialized
INFO - 2018-10-09 20:07:27 --> Controller Class Initialized
INFO - 2018-10-09 20:07:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 20:07:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 20:07:27 --> Pixel_Model class loaded
INFO - 2018-10-09 20:07:27 --> Database Driver Class Initialized
INFO - 2018-10-09 20:07:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 20:07:27 --> Database Driver Class Initialized
INFO - 2018-10-09 20:07:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 20:07:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 20:07:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 20:07:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 20:07:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 20:07:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-10-09 20:07:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 20:07:27 --> Final output sent to browser
DEBUG - 2018-10-09 20:07:27 --> Total execution time: 0.0464
INFO - 2018-10-09 20:07:28 --> Config Class Initialized
INFO - 2018-10-09 20:07:28 --> Hooks Class Initialized
DEBUG - 2018-10-09 20:07:28 --> UTF-8 Support Enabled
INFO - 2018-10-09 20:07:28 --> Utf8 Class Initialized
INFO - 2018-10-09 20:07:28 --> URI Class Initialized
INFO - 2018-10-09 20:07:28 --> Router Class Initialized
INFO - 2018-10-09 20:07:28 --> Output Class Initialized
INFO - 2018-10-09 20:07:28 --> Security Class Initialized
DEBUG - 2018-10-09 20:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 20:07:28 --> CSRF cookie sent
INFO - 2018-10-09 20:07:28 --> Input Class Initialized
INFO - 2018-10-09 20:07:28 --> Language Class Initialized
INFO - 2018-10-09 20:07:28 --> Loader Class Initialized
INFO - 2018-10-09 20:07:28 --> Helper loaded: url_helper
INFO - 2018-10-09 20:07:28 --> Helper loaded: form_helper
INFO - 2018-10-09 20:07:28 --> Helper loaded: language_helper
DEBUG - 2018-10-09 20:07:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 20:07:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 20:07:28 --> User Agent Class Initialized
INFO - 2018-10-09 20:07:28 --> Controller Class Initialized
INFO - 2018-10-09 20:07:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 20:07:28 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 20:07:28 --> Pixel_Model class loaded
INFO - 2018-10-09 20:07:28 --> Database Driver Class Initialized
INFO - 2018-10-09 20:07:28 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 20:07:28 --> Config Class Initialized
INFO - 2018-10-09 20:07:28 --> Hooks Class Initialized
DEBUG - 2018-10-09 20:07:28 --> UTF-8 Support Enabled
INFO - 2018-10-09 20:07:28 --> Utf8 Class Initialized
INFO - 2018-10-09 20:07:28 --> URI Class Initialized
INFO - 2018-10-09 20:07:28 --> Router Class Initialized
INFO - 2018-10-09 20:07:28 --> Output Class Initialized
INFO - 2018-10-09 20:07:28 --> Security Class Initialized
DEBUG - 2018-10-09 20:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 20:07:28 --> CSRF cookie sent
INFO - 2018-10-09 20:07:28 --> Input Class Initialized
INFO - 2018-10-09 20:07:28 --> Language Class Initialized
INFO - 2018-10-09 20:07:28 --> Loader Class Initialized
INFO - 2018-10-09 20:07:28 --> Helper loaded: url_helper
INFO - 2018-10-09 20:07:28 --> Helper loaded: form_helper
INFO - 2018-10-09 20:07:28 --> Helper loaded: language_helper
DEBUG - 2018-10-09 20:07:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 20:07:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 20:07:28 --> User Agent Class Initialized
INFO - 2018-10-09 20:07:28 --> Controller Class Initialized
INFO - 2018-10-09 20:07:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 20:07:28 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-09 20:07:28 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-10-09 20:07:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 20:07:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 20:07:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 20:07:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-10-09 20:07:28 --> Could not find the language line "req_email"
INFO - 2018-10-09 20:07:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-10-09 20:07:28 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 20:07:28 --> Final output sent to browser
DEBUG - 2018-10-09 20:07:28 --> Total execution time: 0.0244
INFO - 2018-10-09 20:07:31 --> Config Class Initialized
INFO - 2018-10-09 20:07:31 --> Hooks Class Initialized
DEBUG - 2018-10-09 20:07:31 --> UTF-8 Support Enabled
INFO - 2018-10-09 20:07:31 --> Utf8 Class Initialized
INFO - 2018-10-09 20:07:31 --> URI Class Initialized
INFO - 2018-10-09 20:07:31 --> Router Class Initialized
INFO - 2018-10-09 20:07:31 --> Output Class Initialized
INFO - 2018-10-09 20:07:31 --> Security Class Initialized
DEBUG - 2018-10-09 20:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 20:07:31 --> CSRF cookie sent
INFO - 2018-10-09 20:07:31 --> Input Class Initialized
INFO - 2018-10-09 20:07:31 --> Language Class Initialized
INFO - 2018-10-09 20:07:31 --> Loader Class Initialized
INFO - 2018-10-09 20:07:31 --> Helper loaded: url_helper
INFO - 2018-10-09 20:07:31 --> Helper loaded: form_helper
INFO - 2018-10-09 20:07:31 --> Helper loaded: language_helper
DEBUG - 2018-10-09 20:07:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 20:07:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 20:07:31 --> User Agent Class Initialized
INFO - 2018-10-09 20:07:31 --> Controller Class Initialized
INFO - 2018-10-09 20:07:31 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 20:07:31 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 20:07:31 --> Pixel_Model class loaded
INFO - 2018-10-09 20:07:31 --> Database Driver Class Initialized
INFO - 2018-10-09 20:07:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 20:07:31 --> Database Driver Class Initialized
INFO - 2018-10-09 20:07:31 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 20:07:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 20:07:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 20:07:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 20:07:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 20:07:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-10-09 20:07:31 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 20:07:31 --> Final output sent to browser
DEBUG - 2018-10-09 20:07:31 --> Total execution time: 0.0453
INFO - 2018-10-09 20:07:32 --> Config Class Initialized
INFO - 2018-10-09 20:07:32 --> Hooks Class Initialized
DEBUG - 2018-10-09 20:07:32 --> UTF-8 Support Enabled
INFO - 2018-10-09 20:07:32 --> Utf8 Class Initialized
INFO - 2018-10-09 20:07:32 --> URI Class Initialized
INFO - 2018-10-09 20:07:32 --> Router Class Initialized
INFO - 2018-10-09 20:07:32 --> Output Class Initialized
INFO - 2018-10-09 20:07:32 --> Security Class Initialized
DEBUG - 2018-10-09 20:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 20:07:32 --> CSRF cookie sent
INFO - 2018-10-09 20:07:32 --> Input Class Initialized
INFO - 2018-10-09 20:07:32 --> Language Class Initialized
INFO - 2018-10-09 20:07:32 --> Loader Class Initialized
INFO - 2018-10-09 20:07:32 --> Helper loaded: url_helper
INFO - 2018-10-09 20:07:32 --> Helper loaded: form_helper
INFO - 2018-10-09 20:07:32 --> Helper loaded: language_helper
DEBUG - 2018-10-09 20:07:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 20:07:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 20:07:32 --> User Agent Class Initialized
INFO - 2018-10-09 20:07:32 --> Controller Class Initialized
INFO - 2018-10-09 20:07:32 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 20:07:32 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 20:07:32 --> Pixel_Model class loaded
INFO - 2018-10-09 20:07:32 --> Database Driver Class Initialized
INFO - 2018-10-09 20:07:32 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 20:07:32 --> Database Driver Class Initialized
INFO - 2018-10-09 20:07:32 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 20:07:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 20:07:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 20:07:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 20:07:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 20:07:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 20:07:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 20:07:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/financial.php
INFO - 2018-10-09 20:07:32 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 20:07:32 --> Final output sent to browser
DEBUG - 2018-10-09 20:07:32 --> Total execution time: 0.0471
INFO - 2018-10-09 20:07:33 --> Config Class Initialized
INFO - 2018-10-09 20:07:33 --> Hooks Class Initialized
DEBUG - 2018-10-09 20:07:33 --> UTF-8 Support Enabled
INFO - 2018-10-09 20:07:33 --> Utf8 Class Initialized
INFO - 2018-10-09 20:07:33 --> URI Class Initialized
INFO - 2018-10-09 20:07:33 --> Router Class Initialized
INFO - 2018-10-09 20:07:33 --> Output Class Initialized
INFO - 2018-10-09 20:07:33 --> Security Class Initialized
DEBUG - 2018-10-09 20:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 20:07:33 --> CSRF cookie sent
INFO - 2018-10-09 20:07:33 --> Input Class Initialized
INFO - 2018-10-09 20:07:33 --> Language Class Initialized
INFO - 2018-10-09 20:07:33 --> Loader Class Initialized
INFO - 2018-10-09 20:07:33 --> Helper loaded: url_helper
INFO - 2018-10-09 20:07:33 --> Helper loaded: form_helper
INFO - 2018-10-09 20:07:33 --> Helper loaded: language_helper
DEBUG - 2018-10-09 20:07:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 20:07:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 20:07:33 --> User Agent Class Initialized
INFO - 2018-10-09 20:07:33 --> Controller Class Initialized
INFO - 2018-10-09 20:07:33 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 20:07:33 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 20:07:33 --> Pixel_Model class loaded
INFO - 2018-10-09 20:07:33 --> Database Driver Class Initialized
INFO - 2018-10-09 20:07:33 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 20:07:33 --> Database Driver Class Initialized
INFO - 2018-10-09 20:07:33 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 20:07:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 20:07:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 20:07:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 20:07:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 20:07:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 20:07:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 20:07:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_title.php
INFO - 2018-10-09 20:07:33 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 20:07:33 --> Final output sent to browser
DEBUG - 2018-10-09 20:07:33 --> Total execution time: 0.0475
INFO - 2018-10-09 20:07:34 --> Config Class Initialized
INFO - 2018-10-09 20:07:34 --> Hooks Class Initialized
DEBUG - 2018-10-09 20:07:34 --> UTF-8 Support Enabled
INFO - 2018-10-09 20:07:34 --> Utf8 Class Initialized
INFO - 2018-10-09 20:07:34 --> URI Class Initialized
INFO - 2018-10-09 20:07:34 --> Router Class Initialized
INFO - 2018-10-09 20:07:34 --> Output Class Initialized
INFO - 2018-10-09 20:07:34 --> Security Class Initialized
DEBUG - 2018-10-09 20:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 20:07:34 --> CSRF cookie sent
INFO - 2018-10-09 20:07:34 --> Input Class Initialized
INFO - 2018-10-09 20:07:34 --> Language Class Initialized
INFO - 2018-10-09 20:07:34 --> Loader Class Initialized
INFO - 2018-10-09 20:07:34 --> Helper loaded: url_helper
INFO - 2018-10-09 20:07:34 --> Helper loaded: form_helper
INFO - 2018-10-09 20:07:34 --> Helper loaded: language_helper
DEBUG - 2018-10-09 20:07:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 20:07:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 20:07:34 --> User Agent Class Initialized
INFO - 2018-10-09 20:07:34 --> Controller Class Initialized
INFO - 2018-10-09 20:07:34 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 20:07:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 20:07:34 --> Pixel_Model class loaded
INFO - 2018-10-09 20:07:34 --> Database Driver Class Initialized
INFO - 2018-10-09 20:07:34 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 20:07:34 --> Database Driver Class Initialized
INFO - 2018-10-09 20:07:34 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 20:07:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 20:07:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 20:07:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 20:07:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 20:07:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 20:07:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 20:07:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-10-09 20:07:34 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 20:07:34 --> Final output sent to browser
DEBUG - 2018-10-09 20:07:34 --> Total execution time: 0.0462
INFO - 2018-10-09 20:07:34 --> Config Class Initialized
INFO - 2018-10-09 20:07:34 --> Hooks Class Initialized
DEBUG - 2018-10-09 20:07:34 --> UTF-8 Support Enabled
INFO - 2018-10-09 20:07:34 --> Utf8 Class Initialized
INFO - 2018-10-09 20:07:34 --> URI Class Initialized
INFO - 2018-10-09 20:07:35 --> Router Class Initialized
INFO - 2018-10-09 20:07:35 --> Output Class Initialized
INFO - 2018-10-09 20:07:35 --> Security Class Initialized
DEBUG - 2018-10-09 20:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 20:07:35 --> CSRF cookie sent
INFO - 2018-10-09 20:07:35 --> Input Class Initialized
INFO - 2018-10-09 20:07:35 --> Language Class Initialized
INFO - 2018-10-09 20:07:35 --> Loader Class Initialized
INFO - 2018-10-09 20:07:35 --> Helper loaded: url_helper
INFO - 2018-10-09 20:07:35 --> Helper loaded: form_helper
INFO - 2018-10-09 20:07:35 --> Helper loaded: language_helper
DEBUG - 2018-10-09 20:07:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 20:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 20:07:35 --> User Agent Class Initialized
INFO - 2018-10-09 20:07:35 --> Controller Class Initialized
INFO - 2018-10-09 20:07:35 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 20:07:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 20:07:35 --> Pixel_Model class loaded
INFO - 2018-10-09 20:07:35 --> Database Driver Class Initialized
INFO - 2018-10-09 20:07:35 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 20:07:35 --> Database Driver Class Initialized
INFO - 2018-10-09 20:07:35 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 20:07:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 20:07:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 20:07:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 20:07:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 20:07:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 20:07:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 20:07:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-09 20:07:35 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 20:07:35 --> Final output sent to browser
DEBUG - 2018-10-09 20:07:35 --> Total execution time: 0.0412
INFO - 2018-10-09 20:07:37 --> Config Class Initialized
INFO - 2018-10-09 20:07:37 --> Hooks Class Initialized
DEBUG - 2018-10-09 20:07:37 --> UTF-8 Support Enabled
INFO - 2018-10-09 20:07:37 --> Utf8 Class Initialized
INFO - 2018-10-09 20:07:37 --> URI Class Initialized
INFO - 2018-10-09 20:07:37 --> Router Class Initialized
INFO - 2018-10-09 20:07:37 --> Output Class Initialized
INFO - 2018-10-09 20:07:37 --> Security Class Initialized
DEBUG - 2018-10-09 20:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 20:07:37 --> CSRF cookie sent
INFO - 2018-10-09 20:07:37 --> Input Class Initialized
INFO - 2018-10-09 20:07:37 --> Language Class Initialized
INFO - 2018-10-09 20:07:37 --> Loader Class Initialized
INFO - 2018-10-09 20:07:37 --> Helper loaded: url_helper
INFO - 2018-10-09 20:07:37 --> Helper loaded: form_helper
INFO - 2018-10-09 20:07:37 --> Helper loaded: language_helper
DEBUG - 2018-10-09 20:07:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 20:07:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 20:07:37 --> User Agent Class Initialized
INFO - 2018-10-09 20:07:37 --> Controller Class Initialized
INFO - 2018-10-09 20:07:37 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 20:07:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 20:07:37 --> Pixel_Model class loaded
INFO - 2018-10-09 20:07:37 --> Database Driver Class Initialized
INFO - 2018-10-09 20:07:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 20:07:37 --> Database Driver Class Initialized
INFO - 2018-10-09 20:07:37 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 20:07:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 20:07:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 20:07:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 20:07:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 20:07:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/save_exit.php
INFO - 2018-10-09 20:07:37 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 20:07:37 --> Final output sent to browser
DEBUG - 2018-10-09 20:07:37 --> Total execution time: 0.0462
INFO - 2018-10-09 20:07:39 --> Config Class Initialized
INFO - 2018-10-09 20:07:39 --> Hooks Class Initialized
DEBUG - 2018-10-09 20:07:39 --> UTF-8 Support Enabled
INFO - 2018-10-09 20:07:39 --> Utf8 Class Initialized
INFO - 2018-10-09 20:07:39 --> URI Class Initialized
INFO - 2018-10-09 20:07:39 --> Router Class Initialized
INFO - 2018-10-09 20:07:39 --> Output Class Initialized
INFO - 2018-10-09 20:07:39 --> Security Class Initialized
DEBUG - 2018-10-09 20:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 20:07:39 --> CSRF cookie sent
INFO - 2018-10-09 20:07:39 --> Input Class Initialized
INFO - 2018-10-09 20:07:39 --> Language Class Initialized
INFO - 2018-10-09 20:07:39 --> Loader Class Initialized
INFO - 2018-10-09 20:07:39 --> Helper loaded: url_helper
INFO - 2018-10-09 20:07:39 --> Helper loaded: form_helper
INFO - 2018-10-09 20:07:39 --> Helper loaded: language_helper
DEBUG - 2018-10-09 20:07:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 20:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 20:07:39 --> User Agent Class Initialized
INFO - 2018-10-09 20:07:39 --> Controller Class Initialized
INFO - 2018-10-09 20:07:39 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 20:07:39 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 20:07:39 --> Pixel_Model class loaded
INFO - 2018-10-09 20:07:39 --> Database Driver Class Initialized
INFO - 2018-10-09 20:07:39 --> Model "RegistrationModel" initialized
DEBUG - 2018-10-09 20:07:39 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-10-09 20:07:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 20:07:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 20:07:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 20:07:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-10-09 20:07:39 --> Could not find the language line "req_email"
INFO - 2018-10-09 20:07:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/register/signup.php
INFO - 2018-10-09 20:07:39 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 20:07:39 --> Final output sent to browser
DEBUG - 2018-10-09 20:07:39 --> Total execution time: 0.0345
INFO - 2018-10-09 20:07:42 --> Config Class Initialized
INFO - 2018-10-09 20:07:42 --> Hooks Class Initialized
DEBUG - 2018-10-09 20:07:42 --> UTF-8 Support Enabled
INFO - 2018-10-09 20:07:42 --> Utf8 Class Initialized
INFO - 2018-10-09 20:07:42 --> URI Class Initialized
INFO - 2018-10-09 20:07:42 --> Router Class Initialized
INFO - 2018-10-09 20:07:42 --> Output Class Initialized
INFO - 2018-10-09 20:07:42 --> Security Class Initialized
DEBUG - 2018-10-09 20:07:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 20:07:42 --> CSRF cookie sent
INFO - 2018-10-09 20:07:42 --> Input Class Initialized
INFO - 2018-10-09 20:07:42 --> Language Class Initialized
INFO - 2018-10-09 20:07:42 --> Loader Class Initialized
INFO - 2018-10-09 20:07:42 --> Helper loaded: url_helper
INFO - 2018-10-09 20:07:42 --> Helper loaded: form_helper
INFO - 2018-10-09 20:07:42 --> Helper loaded: language_helper
DEBUG - 2018-10-09 20:07:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 20:07:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 20:07:42 --> User Agent Class Initialized
INFO - 2018-10-09 20:07:42 --> Controller Class Initialized
INFO - 2018-10-09 20:07:42 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 20:07:42 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 20:07:42 --> Pixel_Model class loaded
INFO - 2018-10-09 20:07:42 --> Database Driver Class Initialized
INFO - 2018-10-09 20:07:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 20:07:42 --> Database Driver Class Initialized
INFO - 2018-10-09 20:07:42 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 20:07:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 20:07:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 20:07:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 20:07:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 20:07:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/save_exit.php
INFO - 2018-10-09 20:07:42 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 20:07:42 --> Final output sent to browser
DEBUG - 2018-10-09 20:07:42 --> Total execution time: 0.0613
INFO - 2018-10-09 20:08:22 --> Config Class Initialized
INFO - 2018-10-09 20:08:22 --> Hooks Class Initialized
DEBUG - 2018-10-09 20:08:22 --> UTF-8 Support Enabled
INFO - 2018-10-09 20:08:22 --> Utf8 Class Initialized
INFO - 2018-10-09 20:08:22 --> URI Class Initialized
INFO - 2018-10-09 20:08:22 --> Router Class Initialized
INFO - 2018-10-09 20:08:22 --> Output Class Initialized
INFO - 2018-10-09 20:08:22 --> Security Class Initialized
DEBUG - 2018-10-09 20:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 20:08:22 --> CSRF cookie sent
INFO - 2018-10-09 20:08:22 --> Input Class Initialized
INFO - 2018-10-09 20:08:22 --> Language Class Initialized
INFO - 2018-10-09 20:08:22 --> Loader Class Initialized
INFO - 2018-10-09 20:08:22 --> Helper loaded: url_helper
INFO - 2018-10-09 20:08:22 --> Helper loaded: form_helper
INFO - 2018-10-09 20:08:22 --> Helper loaded: language_helper
DEBUG - 2018-10-09 20:08:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 20:08:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 20:08:22 --> User Agent Class Initialized
INFO - 2018-10-09 20:08:22 --> Controller Class Initialized
INFO - 2018-10-09 20:08:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 20:08:22 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-09 20:08:22 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-10-09 20:08:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 20:08:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 20:08:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 20:08:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-10-09 20:08:22 --> Could not find the language line "req_email"
INFO - 2018-10-09 20:08:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-10-09 20:08:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 20:08:22 --> Final output sent to browser
DEBUG - 2018-10-09 20:08:22 --> Total execution time: 0.0229
INFO - 2018-10-09 20:08:28 --> Config Class Initialized
INFO - 2018-10-09 20:08:28 --> Hooks Class Initialized
DEBUG - 2018-10-09 20:08:28 --> UTF-8 Support Enabled
INFO - 2018-10-09 20:08:28 --> Utf8 Class Initialized
INFO - 2018-10-09 20:08:28 --> URI Class Initialized
INFO - 2018-10-09 20:08:28 --> Router Class Initialized
INFO - 2018-10-09 20:08:28 --> Output Class Initialized
INFO - 2018-10-09 20:08:28 --> Security Class Initialized
DEBUG - 2018-10-09 20:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 20:08:28 --> CSRF cookie sent
INFO - 2018-10-09 20:08:28 --> CSRF token verified
INFO - 2018-10-09 20:08:28 --> Input Class Initialized
INFO - 2018-10-09 20:08:28 --> Language Class Initialized
INFO - 2018-10-09 20:08:28 --> Loader Class Initialized
INFO - 2018-10-09 20:08:28 --> Helper loaded: url_helper
INFO - 2018-10-09 20:08:28 --> Helper loaded: form_helper
INFO - 2018-10-09 20:08:28 --> Helper loaded: language_helper
DEBUG - 2018-10-09 20:08:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 20:08:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 20:08:28 --> User Agent Class Initialized
INFO - 2018-10-09 20:08:28 --> Controller Class Initialized
INFO - 2018-10-09 20:08:28 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 20:08:28 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-09 20:08:28 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-10-09 20:08:28 --> Form Validation Class Initialized
INFO - 2018-10-09 20:08:28 --> Pixel_Model class loaded
INFO - 2018-10-09 20:08:28 --> Database Driver Class Initialized
INFO - 2018-10-09 20:08:28 --> Model "AuthenticationModel" initialized
INFO - 2018-10-09 20:08:28 --> Database Driver Class Initialized
INFO - 2018-10-09 20:08:28 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 20:08:28 --> Config Class Initialized
INFO - 2018-10-09 20:08:28 --> Hooks Class Initialized
DEBUG - 2018-10-09 20:08:28 --> UTF-8 Support Enabled
INFO - 2018-10-09 20:08:28 --> Utf8 Class Initialized
INFO - 2018-10-09 20:08:28 --> URI Class Initialized
DEBUG - 2018-10-09 20:08:28 --> No URI present. Default controller set.
INFO - 2018-10-09 20:08:28 --> Router Class Initialized
INFO - 2018-10-09 20:08:28 --> Output Class Initialized
INFO - 2018-10-09 20:08:28 --> Security Class Initialized
DEBUG - 2018-10-09 20:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 20:08:28 --> CSRF cookie sent
INFO - 2018-10-09 20:08:28 --> Input Class Initialized
INFO - 2018-10-09 20:08:28 --> Language Class Initialized
INFO - 2018-10-09 20:08:28 --> Loader Class Initialized
INFO - 2018-10-09 20:08:29 --> Helper loaded: url_helper
INFO - 2018-10-09 20:08:29 --> Helper loaded: form_helper
INFO - 2018-10-09 20:08:29 --> Helper loaded: language_helper
DEBUG - 2018-10-09 20:08:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 20:08:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 20:08:29 --> User Agent Class Initialized
INFO - 2018-10-09 20:08:29 --> Controller Class Initialized
INFO - 2018-10-09 20:08:29 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 20:08:29 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 20:08:29 --> Pixel_Model class loaded
INFO - 2018-10-09 20:08:29 --> Database Driver Class Initialized
INFO - 2018-10-09 20:08:29 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 20:08:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 20:08:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-09 20:08:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 20:08:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/home.php
INFO - 2018-10-09 20:08:29 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 20:08:29 --> Final output sent to browser
DEBUG - 2018-10-09 20:08:29 --> Total execution time: 0.0522
INFO - 2018-10-09 20:08:52 --> Config Class Initialized
INFO - 2018-10-09 20:08:52 --> Hooks Class Initialized
DEBUG - 2018-10-09 20:08:52 --> UTF-8 Support Enabled
INFO - 2018-10-09 20:08:52 --> Utf8 Class Initialized
INFO - 2018-10-09 20:08:52 --> URI Class Initialized
INFO - 2018-10-09 20:08:52 --> Router Class Initialized
INFO - 2018-10-09 20:08:52 --> Output Class Initialized
INFO - 2018-10-09 20:08:52 --> Security Class Initialized
DEBUG - 2018-10-09 20:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 20:08:52 --> CSRF cookie sent
INFO - 2018-10-09 20:08:52 --> Input Class Initialized
INFO - 2018-10-09 20:08:52 --> Language Class Initialized
INFO - 2018-10-09 20:08:52 --> Loader Class Initialized
INFO - 2018-10-09 20:08:52 --> Helper loaded: url_helper
INFO - 2018-10-09 20:08:52 --> Helper loaded: form_helper
INFO - 2018-10-09 20:08:52 --> Helper loaded: language_helper
DEBUG - 2018-10-09 20:08:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 20:08:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 20:08:52 --> User Agent Class Initialized
INFO - 2018-10-09 20:08:52 --> Controller Class Initialized
INFO - 2018-10-09 20:08:52 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 20:08:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 20:08:52 --> Pixel_Model class loaded
INFO - 2018-10-09 20:08:52 --> Database Driver Class Initialized
INFO - 2018-10-09 20:08:52 --> Model "MyAccountModel" initialized
INFO - 2018-10-09 20:08:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 20:08:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-09 20:08:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 20:08:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 20:08:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 20:08:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/change_order.php
INFO - 2018-10-09 20:08:52 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 20:08:52 --> Final output sent to browser
DEBUG - 2018-10-09 20:08:52 --> Total execution time: 0.0358
INFO - 2018-10-09 20:09:08 --> Config Class Initialized
INFO - 2018-10-09 20:09:08 --> Hooks Class Initialized
DEBUG - 2018-10-09 20:09:08 --> UTF-8 Support Enabled
INFO - 2018-10-09 20:09:08 --> Utf8 Class Initialized
INFO - 2018-10-09 20:09:08 --> URI Class Initialized
INFO - 2018-10-09 20:09:08 --> Router Class Initialized
INFO - 2018-10-09 20:09:08 --> Output Class Initialized
INFO - 2018-10-09 20:09:08 --> Security Class Initialized
DEBUG - 2018-10-09 20:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 20:09:08 --> CSRF cookie sent
INFO - 2018-10-09 20:09:08 --> CSRF token verified
INFO - 2018-10-09 20:09:08 --> Input Class Initialized
INFO - 2018-10-09 20:09:08 --> Language Class Initialized
INFO - 2018-10-09 20:09:08 --> Loader Class Initialized
INFO - 2018-10-09 20:09:08 --> Helper loaded: url_helper
INFO - 2018-10-09 20:09:08 --> Helper loaded: form_helper
INFO - 2018-10-09 20:09:08 --> Helper loaded: language_helper
DEBUG - 2018-10-09 20:09:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 20:09:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 20:09:08 --> User Agent Class Initialized
INFO - 2018-10-09 20:09:08 --> Controller Class Initialized
INFO - 2018-10-09 20:09:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 20:09:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 20:09:08 --> Form Validation Class Initialized
INFO - 2018-10-09 20:09:08 --> Pixel_Model class loaded
INFO - 2018-10-09 20:09:08 --> Database Driver Class Initialized
INFO - 2018-10-09 20:09:08 --> Model "MyAccountModel" initialized
INFO - 2018-10-09 20:09:08 --> Config Class Initialized
INFO - 2018-10-09 20:09:08 --> Hooks Class Initialized
DEBUG - 2018-10-09 20:09:08 --> UTF-8 Support Enabled
INFO - 2018-10-09 20:09:08 --> Utf8 Class Initialized
INFO - 2018-10-09 20:09:08 --> URI Class Initialized
INFO - 2018-10-09 20:09:08 --> Router Class Initialized
INFO - 2018-10-09 20:09:08 --> Output Class Initialized
INFO - 2018-10-09 20:09:08 --> Security Class Initialized
DEBUG - 2018-10-09 20:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 20:09:08 --> CSRF cookie sent
INFO - 2018-10-09 20:09:08 --> Input Class Initialized
INFO - 2018-10-09 20:09:08 --> Language Class Initialized
INFO - 2018-10-09 20:09:08 --> Loader Class Initialized
INFO - 2018-10-09 20:09:08 --> Helper loaded: url_helper
INFO - 2018-10-09 20:09:08 --> Helper loaded: form_helper
INFO - 2018-10-09 20:09:08 --> Helper loaded: language_helper
DEBUG - 2018-10-09 20:09:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 20:09:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 20:09:08 --> User Agent Class Initialized
INFO - 2018-10-09 20:09:08 --> Controller Class Initialized
INFO - 2018-10-09 20:09:08 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 20:09:08 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 20:09:08 --> Pixel_Model class loaded
INFO - 2018-10-09 20:09:08 --> Database Driver Class Initialized
INFO - 2018-10-09 20:09:08 --> Model "MyAccountModel" initialized
INFO - 2018-10-09 20:09:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 20:09:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-09 20:09:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 20:09:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 20:09:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 20:09:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/change_order.php
INFO - 2018-10-09 20:09:08 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 20:09:08 --> Final output sent to browser
DEBUG - 2018-10-09 20:09:08 --> Total execution time: 0.0333
INFO - 2018-10-09 20:09:14 --> Config Class Initialized
INFO - 2018-10-09 20:09:14 --> Hooks Class Initialized
DEBUG - 2018-10-09 20:09:14 --> UTF-8 Support Enabled
INFO - 2018-10-09 20:09:14 --> Utf8 Class Initialized
INFO - 2018-10-09 20:09:14 --> URI Class Initialized
INFO - 2018-10-09 20:09:14 --> Router Class Initialized
INFO - 2018-10-09 20:09:14 --> Output Class Initialized
INFO - 2018-10-09 20:09:14 --> Security Class Initialized
DEBUG - 2018-10-09 20:09:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 20:09:14 --> CSRF cookie sent
INFO - 2018-10-09 20:09:14 --> CSRF token verified
INFO - 2018-10-09 20:09:14 --> Input Class Initialized
INFO - 2018-10-09 20:09:14 --> Language Class Initialized
INFO - 2018-10-09 20:09:14 --> Loader Class Initialized
INFO - 2018-10-09 20:09:14 --> Helper loaded: url_helper
INFO - 2018-10-09 20:09:14 --> Helper loaded: form_helper
INFO - 2018-10-09 20:09:14 --> Helper loaded: language_helper
DEBUG - 2018-10-09 20:09:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 20:09:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 20:09:14 --> User Agent Class Initialized
INFO - 2018-10-09 20:09:14 --> Controller Class Initialized
INFO - 2018-10-09 20:09:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 20:09:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 20:09:14 --> Form Validation Class Initialized
INFO - 2018-10-09 20:09:14 --> Pixel_Model class loaded
INFO - 2018-10-09 20:09:14 --> Database Driver Class Initialized
INFO - 2018-10-09 20:09:14 --> Model "MyAccountModel" initialized
INFO - 2018-10-09 20:09:14 --> Config Class Initialized
INFO - 2018-10-09 20:09:14 --> Hooks Class Initialized
DEBUG - 2018-10-09 20:09:14 --> UTF-8 Support Enabled
INFO - 2018-10-09 20:09:14 --> Utf8 Class Initialized
INFO - 2018-10-09 20:09:14 --> URI Class Initialized
INFO - 2018-10-09 20:09:14 --> Router Class Initialized
INFO - 2018-10-09 20:09:14 --> Output Class Initialized
INFO - 2018-10-09 20:09:14 --> Security Class Initialized
DEBUG - 2018-10-09 20:09:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 20:09:14 --> CSRF cookie sent
INFO - 2018-10-09 20:09:14 --> Input Class Initialized
INFO - 2018-10-09 20:09:14 --> Language Class Initialized
INFO - 2018-10-09 20:09:14 --> Loader Class Initialized
INFO - 2018-10-09 20:09:14 --> Helper loaded: url_helper
INFO - 2018-10-09 20:09:14 --> Helper loaded: form_helper
INFO - 2018-10-09 20:09:14 --> Helper loaded: language_helper
DEBUG - 2018-10-09 20:09:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 20:09:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 20:09:14 --> User Agent Class Initialized
INFO - 2018-10-09 20:09:14 --> Controller Class Initialized
INFO - 2018-10-09 20:09:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 20:09:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 20:09:14 --> Pixel_Model class loaded
INFO - 2018-10-09 20:09:14 --> Database Driver Class Initialized
INFO - 2018-10-09 20:09:14 --> Model "MyAccountModel" initialized
INFO - 2018-10-09 20:09:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 20:09:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-09 20:09:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 20:09:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 20:09:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 20:09:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/change_order.php
INFO - 2018-10-09 20:09:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 20:09:14 --> Final output sent to browser
DEBUG - 2018-10-09 20:09:14 --> Total execution time: 0.0403
INFO - 2018-10-09 20:09:41 --> Config Class Initialized
INFO - 2018-10-09 20:09:41 --> Hooks Class Initialized
DEBUG - 2018-10-09 20:09:41 --> UTF-8 Support Enabled
INFO - 2018-10-09 20:09:41 --> Utf8 Class Initialized
INFO - 2018-10-09 20:09:41 --> URI Class Initialized
INFO - 2018-10-09 20:09:41 --> Router Class Initialized
INFO - 2018-10-09 20:09:41 --> Output Class Initialized
INFO - 2018-10-09 20:09:41 --> Security Class Initialized
DEBUG - 2018-10-09 20:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 20:09:41 --> CSRF cookie sent
INFO - 2018-10-09 20:09:41 --> Input Class Initialized
INFO - 2018-10-09 20:09:41 --> Language Class Initialized
INFO - 2018-10-09 20:09:41 --> Loader Class Initialized
INFO - 2018-10-09 20:09:41 --> Helper loaded: url_helper
INFO - 2018-10-09 20:09:41 --> Helper loaded: form_helper
INFO - 2018-10-09 20:09:41 --> Helper loaded: language_helper
DEBUG - 2018-10-09 20:09:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 20:09:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 20:09:41 --> User Agent Class Initialized
INFO - 2018-10-09 20:09:41 --> Controller Class Initialized
INFO - 2018-10-09 20:09:41 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 20:09:41 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 20:09:41 --> Pixel_Model class loaded
INFO - 2018-10-09 20:09:41 --> Database Driver Class Initialized
INFO - 2018-10-09 20:09:41 --> Model "MyAccountModel" initialized
INFO - 2018-10-09 20:09:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 20:09:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-09 20:09:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 20:09:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 20:09:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 20:09:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/change_order.php
INFO - 2018-10-09 20:09:41 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 20:09:41 --> Final output sent to browser
DEBUG - 2018-10-09 20:09:41 --> Total execution time: 0.0508
INFO - 2018-10-09 20:09:57 --> Config Class Initialized
INFO - 2018-10-09 20:09:57 --> Hooks Class Initialized
DEBUG - 2018-10-09 20:09:57 --> UTF-8 Support Enabled
INFO - 2018-10-09 20:09:57 --> Utf8 Class Initialized
INFO - 2018-10-09 20:09:57 --> URI Class Initialized
INFO - 2018-10-09 20:09:57 --> Router Class Initialized
INFO - 2018-10-09 20:09:57 --> Output Class Initialized
INFO - 2018-10-09 20:09:57 --> Security Class Initialized
DEBUG - 2018-10-09 20:09:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 20:09:57 --> CSRF cookie sent
INFO - 2018-10-09 20:09:57 --> CSRF token verified
INFO - 2018-10-09 20:09:57 --> Input Class Initialized
INFO - 2018-10-09 20:09:57 --> Language Class Initialized
INFO - 2018-10-09 20:09:57 --> Loader Class Initialized
INFO - 2018-10-09 20:09:57 --> Helper loaded: url_helper
INFO - 2018-10-09 20:09:57 --> Helper loaded: form_helper
INFO - 2018-10-09 20:09:57 --> Helper loaded: language_helper
DEBUG - 2018-10-09 20:09:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 20:09:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 20:09:57 --> User Agent Class Initialized
INFO - 2018-10-09 20:09:58 --> Controller Class Initialized
INFO - 2018-10-09 20:09:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 20:09:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 20:09:58 --> Form Validation Class Initialized
INFO - 2018-10-09 20:09:58 --> Pixel_Model class loaded
INFO - 2018-10-09 20:09:58 --> Database Driver Class Initialized
INFO - 2018-10-09 20:09:58 --> Model "MyAccountModel" initialized
INFO - 2018-10-09 20:09:58 --> Config Class Initialized
INFO - 2018-10-09 20:09:58 --> Hooks Class Initialized
DEBUG - 2018-10-09 20:09:58 --> UTF-8 Support Enabled
INFO - 2018-10-09 20:09:58 --> Utf8 Class Initialized
INFO - 2018-10-09 20:09:58 --> URI Class Initialized
INFO - 2018-10-09 20:09:58 --> Router Class Initialized
INFO - 2018-10-09 20:09:58 --> Output Class Initialized
INFO - 2018-10-09 20:09:58 --> Security Class Initialized
DEBUG - 2018-10-09 20:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 20:09:58 --> CSRF cookie sent
INFO - 2018-10-09 20:09:58 --> Input Class Initialized
INFO - 2018-10-09 20:09:58 --> Language Class Initialized
INFO - 2018-10-09 20:09:58 --> Loader Class Initialized
INFO - 2018-10-09 20:09:58 --> Helper loaded: url_helper
INFO - 2018-10-09 20:09:58 --> Helper loaded: form_helper
INFO - 2018-10-09 20:09:58 --> Helper loaded: language_helper
DEBUG - 2018-10-09 20:09:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 20:09:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 20:09:58 --> User Agent Class Initialized
INFO - 2018-10-09 20:09:58 --> Controller Class Initialized
INFO - 2018-10-09 20:09:58 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 20:09:58 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 20:09:58 --> Pixel_Model class loaded
INFO - 2018-10-09 20:09:58 --> Database Driver Class Initialized
INFO - 2018-10-09 20:09:58 --> Model "MyAccountModel" initialized
INFO - 2018-10-09 20:09:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 20:09:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-09 20:09:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 20:09:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 20:09:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 20:09:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/change_order.php
INFO - 2018-10-09 20:09:58 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 20:09:58 --> Final output sent to browser
DEBUG - 2018-10-09 20:09:58 --> Total execution time: 0.0512
INFO - 2018-10-09 20:10:10 --> Config Class Initialized
INFO - 2018-10-09 20:10:10 --> Hooks Class Initialized
DEBUG - 2018-10-09 20:10:10 --> UTF-8 Support Enabled
INFO - 2018-10-09 20:10:10 --> Utf8 Class Initialized
INFO - 2018-10-09 20:10:10 --> URI Class Initialized
INFO - 2018-10-09 20:10:10 --> Router Class Initialized
INFO - 2018-10-09 20:10:10 --> Output Class Initialized
INFO - 2018-10-09 20:10:10 --> Security Class Initialized
DEBUG - 2018-10-09 20:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 20:10:10 --> CSRF cookie sent
INFO - 2018-10-09 20:10:10 --> Input Class Initialized
INFO - 2018-10-09 20:10:10 --> Language Class Initialized
INFO - 2018-10-09 20:10:10 --> Loader Class Initialized
INFO - 2018-10-09 20:10:10 --> Helper loaded: url_helper
INFO - 2018-10-09 20:10:10 --> Helper loaded: form_helper
INFO - 2018-10-09 20:10:10 --> Helper loaded: language_helper
DEBUG - 2018-10-09 20:10:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 20:10:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 20:10:10 --> User Agent Class Initialized
INFO - 2018-10-09 20:10:10 --> Controller Class Initialized
INFO - 2018-10-09 20:10:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 20:10:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 20:10:10 --> Pixel_Model class loaded
INFO - 2018-10-09 20:10:10 --> Database Driver Class Initialized
INFO - 2018-10-09 20:10:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 20:10:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 20:10:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-09 20:10:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 20:10:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 20:10:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 20:10:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 20:10:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 20:10:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-10-09 20:10:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 20:10:10 --> Final output sent to browser
DEBUG - 2018-10-09 20:10:10 --> Total execution time: 0.0384
INFO - 2018-10-09 20:10:13 --> Config Class Initialized
INFO - 2018-10-09 20:10:13 --> Hooks Class Initialized
DEBUG - 2018-10-09 20:10:13 --> UTF-8 Support Enabled
INFO - 2018-10-09 20:10:13 --> Utf8 Class Initialized
INFO - 2018-10-09 20:10:13 --> URI Class Initialized
INFO - 2018-10-09 20:10:13 --> Router Class Initialized
INFO - 2018-10-09 20:10:13 --> Output Class Initialized
INFO - 2018-10-09 20:10:13 --> Security Class Initialized
DEBUG - 2018-10-09 20:10:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 20:10:13 --> CSRF cookie sent
INFO - 2018-10-09 20:10:13 --> CSRF token verified
INFO - 2018-10-09 20:10:13 --> Input Class Initialized
INFO - 2018-10-09 20:10:13 --> Language Class Initialized
INFO - 2018-10-09 20:10:13 --> Loader Class Initialized
INFO - 2018-10-09 20:10:13 --> Helper loaded: url_helper
INFO - 2018-10-09 20:10:13 --> Helper loaded: form_helper
INFO - 2018-10-09 20:10:13 --> Helper loaded: language_helper
DEBUG - 2018-10-09 20:10:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 20:10:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 20:10:13 --> User Agent Class Initialized
INFO - 2018-10-09 20:10:13 --> Controller Class Initialized
INFO - 2018-10-09 20:10:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 20:10:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 20:10:13 --> Pixel_Model class loaded
INFO - 2018-10-09 20:10:13 --> Database Driver Class Initialized
INFO - 2018-10-09 20:10:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 20:10:13 --> Form Validation Class Initialized
INFO - 2018-10-09 20:10:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 20:10:13 --> Database Driver Class Initialized
INFO - 2018-10-09 20:10:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 20:10:13 --> Config Class Initialized
INFO - 2018-10-09 20:10:13 --> Hooks Class Initialized
DEBUG - 2018-10-09 20:10:13 --> UTF-8 Support Enabled
INFO - 2018-10-09 20:10:13 --> Utf8 Class Initialized
INFO - 2018-10-09 20:10:13 --> URI Class Initialized
INFO - 2018-10-09 20:10:13 --> Router Class Initialized
INFO - 2018-10-09 20:10:13 --> Output Class Initialized
INFO - 2018-10-09 20:10:13 --> Security Class Initialized
DEBUG - 2018-10-09 20:10:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 20:10:13 --> CSRF cookie sent
INFO - 2018-10-09 20:10:13 --> Input Class Initialized
INFO - 2018-10-09 20:10:13 --> Language Class Initialized
INFO - 2018-10-09 20:10:13 --> Loader Class Initialized
INFO - 2018-10-09 20:10:13 --> Helper loaded: url_helper
INFO - 2018-10-09 20:10:13 --> Helper loaded: form_helper
INFO - 2018-10-09 20:10:13 --> Helper loaded: language_helper
DEBUG - 2018-10-09 20:10:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 20:10:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 20:10:13 --> User Agent Class Initialized
INFO - 2018-10-09 20:10:13 --> Controller Class Initialized
INFO - 2018-10-09 20:10:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 20:10:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 20:10:13 --> Pixel_Model class loaded
INFO - 2018-10-09 20:10:13 --> Database Driver Class Initialized
INFO - 2018-10-09 20:10:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 20:10:13 --> Database Driver Class Initialized
INFO - 2018-10-09 20:10:13 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 20:10:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 20:10:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-09 20:10:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 20:10:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 20:10:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 20:10:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 20:10:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 20:10:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-09 20:10:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 20:10:13 --> Final output sent to browser
DEBUG - 2018-10-09 20:10:13 --> Total execution time: 0.0470
INFO - 2018-10-09 20:10:14 --> Config Class Initialized
INFO - 2018-10-09 20:10:14 --> Hooks Class Initialized
DEBUG - 2018-10-09 20:10:14 --> UTF-8 Support Enabled
INFO - 2018-10-09 20:10:14 --> Utf8 Class Initialized
INFO - 2018-10-09 20:10:14 --> URI Class Initialized
INFO - 2018-10-09 20:10:14 --> Router Class Initialized
INFO - 2018-10-09 20:10:14 --> Output Class Initialized
INFO - 2018-10-09 20:10:14 --> Security Class Initialized
DEBUG - 2018-10-09 20:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 20:10:14 --> CSRF cookie sent
INFO - 2018-10-09 20:10:14 --> CSRF token verified
INFO - 2018-10-09 20:10:14 --> Input Class Initialized
INFO - 2018-10-09 20:10:14 --> Language Class Initialized
INFO - 2018-10-09 20:10:14 --> Loader Class Initialized
INFO - 2018-10-09 20:10:14 --> Helper loaded: url_helper
INFO - 2018-10-09 20:10:14 --> Helper loaded: form_helper
INFO - 2018-10-09 20:10:14 --> Helper loaded: language_helper
DEBUG - 2018-10-09 20:10:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 20:10:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 20:10:14 --> User Agent Class Initialized
INFO - 2018-10-09 20:10:14 --> Controller Class Initialized
INFO - 2018-10-09 20:10:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 20:10:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 20:10:14 --> Pixel_Model class loaded
INFO - 2018-10-09 20:10:14 --> Database Driver Class Initialized
INFO - 2018-10-09 20:10:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 20:10:14 --> Form Validation Class Initialized
INFO - 2018-10-09 20:10:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 20:10:14 --> Database Driver Class Initialized
INFO - 2018-10-09 20:10:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 20:10:14 --> Config Class Initialized
INFO - 2018-10-09 20:10:14 --> Hooks Class Initialized
DEBUG - 2018-10-09 20:10:14 --> UTF-8 Support Enabled
INFO - 2018-10-09 20:10:14 --> Utf8 Class Initialized
INFO - 2018-10-09 20:10:14 --> URI Class Initialized
INFO - 2018-10-09 20:10:14 --> Router Class Initialized
INFO - 2018-10-09 20:10:14 --> Output Class Initialized
INFO - 2018-10-09 20:10:14 --> Security Class Initialized
DEBUG - 2018-10-09 20:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 20:10:14 --> CSRF cookie sent
INFO - 2018-10-09 20:10:14 --> Input Class Initialized
INFO - 2018-10-09 20:10:14 --> Language Class Initialized
INFO - 2018-10-09 20:10:14 --> Loader Class Initialized
INFO - 2018-10-09 20:10:14 --> Helper loaded: url_helper
INFO - 2018-10-09 20:10:14 --> Helper loaded: form_helper
INFO - 2018-10-09 20:10:14 --> Helper loaded: language_helper
DEBUG - 2018-10-09 20:10:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 20:10:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 20:10:14 --> User Agent Class Initialized
INFO - 2018-10-09 20:10:14 --> Controller Class Initialized
INFO - 2018-10-09 20:10:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 20:10:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 20:10:14 --> Pixel_Model class loaded
INFO - 2018-10-09 20:10:14 --> Database Driver Class Initialized
INFO - 2018-10-09 20:10:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 20:10:14 --> Database Driver Class Initialized
INFO - 2018-10-09 20:10:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 20:10:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 20:10:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-09 20:10:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 20:10:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 20:10:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 20:10:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 20:10:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 20:10:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-10-09 20:10:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 20:10:14 --> Final output sent to browser
DEBUG - 2018-10-09 20:10:14 --> Total execution time: 0.0541
INFO - 2018-10-09 20:10:15 --> Config Class Initialized
INFO - 2018-10-09 20:10:15 --> Hooks Class Initialized
DEBUG - 2018-10-09 20:10:15 --> UTF-8 Support Enabled
INFO - 2018-10-09 20:10:15 --> Utf8 Class Initialized
INFO - 2018-10-09 20:10:15 --> URI Class Initialized
INFO - 2018-10-09 20:10:15 --> Router Class Initialized
INFO - 2018-10-09 20:10:15 --> Output Class Initialized
INFO - 2018-10-09 20:10:15 --> Security Class Initialized
DEBUG - 2018-10-09 20:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 20:10:15 --> CSRF cookie sent
INFO - 2018-10-09 20:10:15 --> CSRF token verified
INFO - 2018-10-09 20:10:15 --> Input Class Initialized
INFO - 2018-10-09 20:10:15 --> Language Class Initialized
INFO - 2018-10-09 20:10:15 --> Loader Class Initialized
INFO - 2018-10-09 20:10:15 --> Helper loaded: url_helper
INFO - 2018-10-09 20:10:15 --> Helper loaded: form_helper
INFO - 2018-10-09 20:10:15 --> Helper loaded: language_helper
DEBUG - 2018-10-09 20:10:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 20:10:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 20:10:15 --> User Agent Class Initialized
INFO - 2018-10-09 20:10:15 --> Controller Class Initialized
INFO - 2018-10-09 20:10:15 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 20:10:15 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 20:10:15 --> Pixel_Model class loaded
INFO - 2018-10-09 20:10:15 --> Database Driver Class Initialized
INFO - 2018-10-09 20:10:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 20:10:15 --> Form Validation Class Initialized
INFO - 2018-10-09 20:10:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 20:10:15 --> Database Driver Class Initialized
INFO - 2018-10-09 20:10:15 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 20:10:16 --> Config Class Initialized
INFO - 2018-10-09 20:10:16 --> Hooks Class Initialized
DEBUG - 2018-10-09 20:10:16 --> UTF-8 Support Enabled
INFO - 2018-10-09 20:10:16 --> Utf8 Class Initialized
INFO - 2018-10-09 20:10:16 --> URI Class Initialized
INFO - 2018-10-09 20:10:16 --> Router Class Initialized
INFO - 2018-10-09 20:10:16 --> Output Class Initialized
INFO - 2018-10-09 20:10:16 --> Security Class Initialized
DEBUG - 2018-10-09 20:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 20:10:16 --> CSRF cookie sent
INFO - 2018-10-09 20:10:16 --> Input Class Initialized
INFO - 2018-10-09 20:10:16 --> Language Class Initialized
INFO - 2018-10-09 20:10:16 --> Loader Class Initialized
INFO - 2018-10-09 20:10:16 --> Helper loaded: url_helper
INFO - 2018-10-09 20:10:16 --> Helper loaded: form_helper
INFO - 2018-10-09 20:10:16 --> Helper loaded: language_helper
DEBUG - 2018-10-09 20:10:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 20:10:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 20:10:16 --> User Agent Class Initialized
INFO - 2018-10-09 20:10:16 --> Controller Class Initialized
INFO - 2018-10-09 20:10:16 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 20:10:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 20:10:16 --> Pixel_Model class loaded
INFO - 2018-10-09 20:10:16 --> Database Driver Class Initialized
INFO - 2018-10-09 20:10:16 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 20:10:16 --> Database Driver Class Initialized
INFO - 2018-10-09 20:10:16 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 20:10:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 20:10:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-09 20:10:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 20:10:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-10-09 20:10:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 20:10:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 20:10:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 20:10:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 20:10:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-10-09 20:10:16 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 20:10:16 --> Final output sent to browser
DEBUG - 2018-10-09 20:10:16 --> Total execution time: 0.0402
INFO - 2018-10-09 20:21:00 --> Config Class Initialized
INFO - 2018-10-09 20:21:00 --> Hooks Class Initialized
DEBUG - 2018-10-09 20:21:00 --> UTF-8 Support Enabled
INFO - 2018-10-09 20:21:00 --> Utf8 Class Initialized
INFO - 2018-10-09 20:21:00 --> URI Class Initialized
INFO - 2018-10-09 20:21:00 --> Router Class Initialized
INFO - 2018-10-09 20:21:00 --> Output Class Initialized
INFO - 2018-10-09 20:21:00 --> Security Class Initialized
DEBUG - 2018-10-09 20:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 20:21:00 --> CSRF cookie sent
INFO - 2018-10-09 20:21:00 --> Input Class Initialized
INFO - 2018-10-09 20:21:00 --> Language Class Initialized
INFO - 2018-10-09 20:21:00 --> Loader Class Initialized
INFO - 2018-10-09 20:21:00 --> Helper loaded: url_helper
INFO - 2018-10-09 20:21:00 --> Helper loaded: form_helper
INFO - 2018-10-09 20:21:00 --> Helper loaded: language_helper
DEBUG - 2018-10-09 20:21:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 20:21:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 20:21:00 --> User Agent Class Initialized
INFO - 2018-10-09 20:21:00 --> Controller Class Initialized
INFO - 2018-10-09 20:21:00 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 20:21:00 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 20:21:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 20:21:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-09 20:21:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 20:21:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 20:21:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 20:21:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-10-09 20:21:00 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 20:21:00 --> Final output sent to browser
DEBUG - 2018-10-09 20:21:00 --> Total execution time: 0.0253
INFO - 2018-10-09 20:21:09 --> Config Class Initialized
INFO - 2018-10-09 20:21:09 --> Hooks Class Initialized
DEBUG - 2018-10-09 20:21:09 --> UTF-8 Support Enabled
INFO - 2018-10-09 20:21:09 --> Utf8 Class Initialized
INFO - 2018-10-09 20:21:09 --> URI Class Initialized
INFO - 2018-10-09 20:21:09 --> Router Class Initialized
INFO - 2018-10-09 20:21:09 --> Output Class Initialized
INFO - 2018-10-09 20:21:09 --> Security Class Initialized
DEBUG - 2018-10-09 20:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 20:21:09 --> CSRF cookie sent
INFO - 2018-10-09 20:21:09 --> Input Class Initialized
INFO - 2018-10-09 20:21:09 --> Language Class Initialized
INFO - 2018-10-09 20:21:09 --> Loader Class Initialized
INFO - 2018-10-09 20:21:09 --> Helper loaded: url_helper
INFO - 2018-10-09 20:21:09 --> Helper loaded: form_helper
INFO - 2018-10-09 20:21:09 --> Helper loaded: language_helper
DEBUG - 2018-10-09 20:21:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 20:21:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 20:21:09 --> User Agent Class Initialized
INFO - 2018-10-09 20:21:09 --> Controller Class Initialized
INFO - 2018-10-09 20:21:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 20:21:09 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 20:21:09 --> Config Class Initialized
INFO - 2018-10-09 20:21:09 --> Hooks Class Initialized
DEBUG - 2018-10-09 20:21:09 --> UTF-8 Support Enabled
INFO - 2018-10-09 20:21:09 --> Utf8 Class Initialized
INFO - 2018-10-09 20:21:09 --> URI Class Initialized
INFO - 2018-10-09 20:21:09 --> Router Class Initialized
INFO - 2018-10-09 20:21:09 --> Output Class Initialized
INFO - 2018-10-09 20:21:09 --> Security Class Initialized
DEBUG - 2018-10-09 20:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 20:21:09 --> CSRF cookie sent
INFO - 2018-10-09 20:21:09 --> Input Class Initialized
INFO - 2018-10-09 20:21:09 --> Language Class Initialized
INFO - 2018-10-09 20:21:09 --> Loader Class Initialized
INFO - 2018-10-09 20:21:09 --> Helper loaded: url_helper
INFO - 2018-10-09 20:21:09 --> Helper loaded: form_helper
INFO - 2018-10-09 20:21:09 --> Helper loaded: language_helper
DEBUG - 2018-10-09 20:21:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 20:21:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 20:21:09 --> User Agent Class Initialized
INFO - 2018-10-09 20:21:09 --> Controller Class Initialized
INFO - 2018-10-09 20:21:09 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 20:21:09 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-09 20:21:09 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-10-09 20:21:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 20:21:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-09 20:21:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 20:21:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 20:21:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-10-09 20:21:09 --> Could not find the language line "req_email"
INFO - 2018-10-09 20:21:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-10-09 20:21:09 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 20:21:09 --> Final output sent to browser
DEBUG - 2018-10-09 20:21:09 --> Total execution time: 0.0223
INFO - 2018-10-09 20:21:13 --> Config Class Initialized
INFO - 2018-10-09 20:21:13 --> Hooks Class Initialized
DEBUG - 2018-10-09 20:21:13 --> UTF-8 Support Enabled
INFO - 2018-10-09 20:21:13 --> Utf8 Class Initialized
INFO - 2018-10-09 20:21:13 --> URI Class Initialized
INFO - 2018-10-09 20:21:13 --> Router Class Initialized
INFO - 2018-10-09 20:21:13 --> Output Class Initialized
INFO - 2018-10-09 20:21:13 --> Security Class Initialized
DEBUG - 2018-10-09 20:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 20:21:13 --> CSRF cookie sent
INFO - 2018-10-09 20:21:13 --> Input Class Initialized
INFO - 2018-10-09 20:21:13 --> Language Class Initialized
INFO - 2018-10-09 20:21:13 --> Loader Class Initialized
INFO - 2018-10-09 20:21:13 --> Helper loaded: url_helper
INFO - 2018-10-09 20:21:13 --> Helper loaded: form_helper
INFO - 2018-10-09 20:21:13 --> Helper loaded: language_helper
DEBUG - 2018-10-09 20:21:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 20:21:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 20:21:13 --> User Agent Class Initialized
INFO - 2018-10-09 20:21:13 --> Controller Class Initialized
INFO - 2018-10-09 20:21:13 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 20:21:13 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 20:21:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 20:21:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-09 20:21:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 20:21:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 20:21:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 20:21:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-10-09 20:21:13 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 20:21:13 --> Final output sent to browser
DEBUG - 2018-10-09 20:21:13 --> Total execution time: 0.0231
INFO - 2018-10-09 20:22:22 --> Config Class Initialized
INFO - 2018-10-09 20:22:22 --> Hooks Class Initialized
DEBUG - 2018-10-09 20:22:22 --> UTF-8 Support Enabled
INFO - 2018-10-09 20:22:22 --> Utf8 Class Initialized
INFO - 2018-10-09 20:22:22 --> URI Class Initialized
INFO - 2018-10-09 20:22:22 --> Router Class Initialized
INFO - 2018-10-09 20:22:22 --> Output Class Initialized
INFO - 2018-10-09 20:22:22 --> Security Class Initialized
DEBUG - 2018-10-09 20:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 20:22:22 --> CSRF cookie sent
INFO - 2018-10-09 20:22:22 --> Input Class Initialized
INFO - 2018-10-09 20:22:22 --> Language Class Initialized
INFO - 2018-10-09 20:22:22 --> Loader Class Initialized
INFO - 2018-10-09 20:22:22 --> Helper loaded: url_helper
INFO - 2018-10-09 20:22:22 --> Helper loaded: form_helper
INFO - 2018-10-09 20:22:22 --> Helper loaded: language_helper
DEBUG - 2018-10-09 20:22:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 20:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 20:22:22 --> User Agent Class Initialized
INFO - 2018-10-09 20:22:22 --> Controller Class Initialized
INFO - 2018-10-09 20:22:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 20:22:22 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 20:22:22 --> Config Class Initialized
INFO - 2018-10-09 20:22:22 --> Hooks Class Initialized
DEBUG - 2018-10-09 20:22:22 --> UTF-8 Support Enabled
INFO - 2018-10-09 20:22:22 --> Utf8 Class Initialized
INFO - 2018-10-09 20:22:22 --> URI Class Initialized
INFO - 2018-10-09 20:22:22 --> Router Class Initialized
INFO - 2018-10-09 20:22:22 --> Output Class Initialized
INFO - 2018-10-09 20:22:22 --> Security Class Initialized
DEBUG - 2018-10-09 20:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 20:22:22 --> CSRF cookie sent
INFO - 2018-10-09 20:22:22 --> Input Class Initialized
INFO - 2018-10-09 20:22:22 --> Language Class Initialized
INFO - 2018-10-09 20:22:22 --> Loader Class Initialized
INFO - 2018-10-09 20:22:22 --> Helper loaded: url_helper
INFO - 2018-10-09 20:22:22 --> Helper loaded: form_helper
INFO - 2018-10-09 20:22:22 --> Helper loaded: language_helper
DEBUG - 2018-10-09 20:22:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 20:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 20:22:22 --> User Agent Class Initialized
INFO - 2018-10-09 20:22:22 --> Controller Class Initialized
INFO - 2018-10-09 20:22:22 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 20:22:22 --> Language file loaded: language/en/form_validation_lang.php
DEBUG - 2018-10-09 20:22:22 --> Config file loaded: /home/fxp6bn7rqemh/public_html/application/config/recaptcha.php
INFO - 2018-10-09 20:22:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 20:22:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-09 20:22:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 20:22:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 20:22:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
ERROR - 2018-10-09 20:22:22 --> Could not find the language line "req_email"
INFO - 2018-10-09 20:22:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/myaccount/signin.php
INFO - 2018-10-09 20:22:22 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 20:22:22 --> Final output sent to browser
DEBUG - 2018-10-09 20:22:22 --> Total execution time: 0.0238
INFO - 2018-10-09 20:22:25 --> Config Class Initialized
INFO - 2018-10-09 20:22:25 --> Hooks Class Initialized
DEBUG - 2018-10-09 20:22:25 --> UTF-8 Support Enabled
INFO - 2018-10-09 20:22:25 --> Utf8 Class Initialized
INFO - 2018-10-09 20:22:25 --> URI Class Initialized
INFO - 2018-10-09 20:22:25 --> Router Class Initialized
INFO - 2018-10-09 20:22:25 --> Output Class Initialized
INFO - 2018-10-09 20:22:25 --> Security Class Initialized
DEBUG - 2018-10-09 20:22:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 20:22:25 --> CSRF cookie sent
INFO - 2018-10-09 20:22:25 --> Input Class Initialized
INFO - 2018-10-09 20:22:25 --> Language Class Initialized
INFO - 2018-10-09 20:22:25 --> Loader Class Initialized
INFO - 2018-10-09 20:22:25 --> Helper loaded: url_helper
INFO - 2018-10-09 20:22:25 --> Helper loaded: form_helper
INFO - 2018-10-09 20:22:25 --> Helper loaded: language_helper
DEBUG - 2018-10-09 20:22:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 20:22:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 20:22:25 --> User Agent Class Initialized
INFO - 2018-10-09 20:22:25 --> Controller Class Initialized
INFO - 2018-10-09 20:22:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 20:22:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 20:22:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 20:22:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-09 20:22:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 20:22:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 20:22:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 20:22:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/lawyers.php
INFO - 2018-10-09 20:22:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 20:22:25 --> Final output sent to browser
DEBUG - 2018-10-09 20:22:25 --> Total execution time: 0.0709
INFO - 2018-10-09 20:26:40 --> Config Class Initialized
INFO - 2018-10-09 20:26:40 --> Hooks Class Initialized
DEBUG - 2018-10-09 20:26:40 --> UTF-8 Support Enabled
INFO - 2018-10-09 20:26:40 --> Utf8 Class Initialized
INFO - 2018-10-09 20:26:40 --> URI Class Initialized
INFO - 2018-10-09 20:26:40 --> Router Class Initialized
INFO - 2018-10-09 20:26:40 --> Output Class Initialized
INFO - 2018-10-09 20:26:40 --> Security Class Initialized
DEBUG - 2018-10-09 20:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 20:26:40 --> CSRF cookie sent
INFO - 2018-10-09 20:26:40 --> Input Class Initialized
INFO - 2018-10-09 20:26:40 --> Language Class Initialized
ERROR - 2018-10-09 20:26:40 --> 404 Page Not Found: Assets/css
INFO - 2018-10-09 20:27:05 --> Config Class Initialized
INFO - 2018-10-09 20:27:05 --> Hooks Class Initialized
DEBUG - 2018-10-09 20:27:05 --> UTF-8 Support Enabled
INFO - 2018-10-09 20:27:05 --> Utf8 Class Initialized
INFO - 2018-10-09 20:27:05 --> URI Class Initialized
INFO - 2018-10-09 20:27:05 --> Router Class Initialized
INFO - 2018-10-09 20:27:05 --> Output Class Initialized
INFO - 2018-10-09 20:27:05 --> Security Class Initialized
DEBUG - 2018-10-09 20:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 20:27:05 --> CSRF cookie sent
INFO - 2018-10-09 20:27:05 --> Input Class Initialized
INFO - 2018-10-09 20:27:05 --> Language Class Initialized
INFO - 2018-10-09 20:27:05 --> Loader Class Initialized
INFO - 2018-10-09 20:27:05 --> Helper loaded: url_helper
INFO - 2018-10-09 20:27:05 --> Helper loaded: form_helper
INFO - 2018-10-09 20:27:05 --> Helper loaded: language_helper
DEBUG - 2018-10-09 20:27:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 20:27:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 20:27:05 --> User Agent Class Initialized
INFO - 2018-10-09 20:27:05 --> Controller Class Initialized
INFO - 2018-10-09 20:27:05 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 20:27:05 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 20:27:05 --> Pixel_Model class loaded
INFO - 2018-10-09 20:27:05 --> Database Driver Class Initialized
INFO - 2018-10-09 20:27:05 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 20:27:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 20:27:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-09 20:27:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 20:27:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 20:27:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 20:27:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 20:27:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 20:27:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/start_questions.php
INFO - 2018-10-09 20:27:05 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 20:27:05 --> Final output sent to browser
DEBUG - 2018-10-09 20:27:05 --> Total execution time: 0.0478
INFO - 2018-10-09 20:27:05 --> Config Class Initialized
INFO - 2018-10-09 20:27:05 --> Hooks Class Initialized
DEBUG - 2018-10-09 20:27:05 --> UTF-8 Support Enabled
INFO - 2018-10-09 20:27:05 --> Utf8 Class Initialized
INFO - 2018-10-09 20:27:05 --> URI Class Initialized
INFO - 2018-10-09 20:27:05 --> Router Class Initialized
INFO - 2018-10-09 20:27:05 --> Output Class Initialized
INFO - 2018-10-09 20:27:05 --> Security Class Initialized
DEBUG - 2018-10-09 20:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 20:27:05 --> CSRF cookie sent
INFO - 2018-10-09 20:27:05 --> Input Class Initialized
INFO - 2018-10-09 20:27:05 --> Language Class Initialized
ERROR - 2018-10-09 20:27:05 --> 404 Page Not Found: Assets/css
INFO - 2018-10-09 20:27:10 --> Config Class Initialized
INFO - 2018-10-09 20:27:10 --> Hooks Class Initialized
DEBUG - 2018-10-09 20:27:10 --> UTF-8 Support Enabled
INFO - 2018-10-09 20:27:10 --> Utf8 Class Initialized
INFO - 2018-10-09 20:27:10 --> URI Class Initialized
INFO - 2018-10-09 20:27:10 --> Router Class Initialized
INFO - 2018-10-09 20:27:10 --> Output Class Initialized
INFO - 2018-10-09 20:27:10 --> Security Class Initialized
DEBUG - 2018-10-09 20:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 20:27:10 --> CSRF cookie sent
INFO - 2018-10-09 20:27:10 --> CSRF token verified
INFO - 2018-10-09 20:27:10 --> Input Class Initialized
INFO - 2018-10-09 20:27:10 --> Language Class Initialized
INFO - 2018-10-09 20:27:10 --> Loader Class Initialized
INFO - 2018-10-09 20:27:10 --> Helper loaded: url_helper
INFO - 2018-10-09 20:27:10 --> Helper loaded: form_helper
INFO - 2018-10-09 20:27:10 --> Helper loaded: language_helper
DEBUG - 2018-10-09 20:27:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 20:27:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 20:27:10 --> User Agent Class Initialized
INFO - 2018-10-09 20:27:10 --> Controller Class Initialized
INFO - 2018-10-09 20:27:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 20:27:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 20:27:10 --> Pixel_Model class loaded
INFO - 2018-10-09 20:27:10 --> Database Driver Class Initialized
INFO - 2018-10-09 20:27:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 20:27:10 --> Form Validation Class Initialized
INFO - 2018-10-09 20:27:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 20:27:10 --> Database Driver Class Initialized
INFO - 2018-10-09 20:27:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 20:27:10 --> Config Class Initialized
INFO - 2018-10-09 20:27:10 --> Hooks Class Initialized
DEBUG - 2018-10-09 20:27:10 --> UTF-8 Support Enabled
INFO - 2018-10-09 20:27:10 --> Utf8 Class Initialized
INFO - 2018-10-09 20:27:10 --> URI Class Initialized
INFO - 2018-10-09 20:27:10 --> Router Class Initialized
INFO - 2018-10-09 20:27:10 --> Output Class Initialized
INFO - 2018-10-09 20:27:10 --> Security Class Initialized
DEBUG - 2018-10-09 20:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 20:27:10 --> CSRF cookie sent
INFO - 2018-10-09 20:27:10 --> Input Class Initialized
INFO - 2018-10-09 20:27:10 --> Language Class Initialized
INFO - 2018-10-09 20:27:10 --> Loader Class Initialized
INFO - 2018-10-09 20:27:10 --> Helper loaded: url_helper
INFO - 2018-10-09 20:27:10 --> Helper loaded: form_helper
INFO - 2018-10-09 20:27:10 --> Helper loaded: language_helper
DEBUG - 2018-10-09 20:27:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 20:27:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 20:27:10 --> User Agent Class Initialized
INFO - 2018-10-09 20:27:10 --> Controller Class Initialized
INFO - 2018-10-09 20:27:10 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 20:27:10 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 20:27:10 --> Pixel_Model class loaded
INFO - 2018-10-09 20:27:10 --> Database Driver Class Initialized
INFO - 2018-10-09 20:27:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 20:27:10 --> Database Driver Class Initialized
INFO - 2018-10-09 20:27:10 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 20:27:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 20:27:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-09 20:27:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 20:27:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 20:27:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 20:27:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 20:27:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 20:27:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/people_confide.php
INFO - 2018-10-09 20:27:10 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 20:27:10 --> Final output sent to browser
DEBUG - 2018-10-09 20:27:10 --> Total execution time: 0.0520
INFO - 2018-10-09 20:27:11 --> Config Class Initialized
INFO - 2018-10-09 20:27:11 --> Hooks Class Initialized
DEBUG - 2018-10-09 20:27:11 --> UTF-8 Support Enabled
INFO - 2018-10-09 20:27:11 --> Utf8 Class Initialized
INFO - 2018-10-09 20:27:11 --> URI Class Initialized
INFO - 2018-10-09 20:27:11 --> Router Class Initialized
INFO - 2018-10-09 20:27:11 --> Output Class Initialized
INFO - 2018-10-09 20:27:11 --> Security Class Initialized
DEBUG - 2018-10-09 20:27:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 20:27:11 --> CSRF cookie sent
INFO - 2018-10-09 20:27:11 --> Input Class Initialized
INFO - 2018-10-09 20:27:11 --> Language Class Initialized
ERROR - 2018-10-09 20:27:11 --> 404 Page Not Found: Assets/css
INFO - 2018-10-09 20:28:23 --> Config Class Initialized
INFO - 2018-10-09 20:28:23 --> Hooks Class Initialized
DEBUG - 2018-10-09 20:28:23 --> UTF-8 Support Enabled
INFO - 2018-10-09 20:28:23 --> Utf8 Class Initialized
INFO - 2018-10-09 20:28:23 --> URI Class Initialized
INFO - 2018-10-09 20:28:23 --> Router Class Initialized
INFO - 2018-10-09 20:28:23 --> Output Class Initialized
INFO - 2018-10-09 20:28:23 --> Security Class Initialized
DEBUG - 2018-10-09 20:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 20:28:23 --> CSRF cookie sent
INFO - 2018-10-09 20:28:23 --> CSRF token verified
INFO - 2018-10-09 20:28:23 --> Input Class Initialized
INFO - 2018-10-09 20:28:23 --> Language Class Initialized
INFO - 2018-10-09 20:28:23 --> Loader Class Initialized
INFO - 2018-10-09 20:28:23 --> Helper loaded: url_helper
INFO - 2018-10-09 20:28:23 --> Helper loaded: form_helper
INFO - 2018-10-09 20:28:23 --> Helper loaded: language_helper
DEBUG - 2018-10-09 20:28:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 20:28:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 20:28:23 --> User Agent Class Initialized
INFO - 2018-10-09 20:28:23 --> Controller Class Initialized
INFO - 2018-10-09 20:28:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 20:28:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 20:28:23 --> Pixel_Model class loaded
INFO - 2018-10-09 20:28:23 --> Database Driver Class Initialized
INFO - 2018-10-09 20:28:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 20:28:23 --> Form Validation Class Initialized
INFO - 2018-10-09 20:28:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 20:28:23 --> Database Driver Class Initialized
INFO - 2018-10-09 20:28:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 20:28:23 --> Config Class Initialized
INFO - 2018-10-09 20:28:23 --> Hooks Class Initialized
DEBUG - 2018-10-09 20:28:23 --> UTF-8 Support Enabled
INFO - 2018-10-09 20:28:23 --> Utf8 Class Initialized
INFO - 2018-10-09 20:28:23 --> URI Class Initialized
INFO - 2018-10-09 20:28:23 --> Router Class Initialized
INFO - 2018-10-09 20:28:23 --> Output Class Initialized
INFO - 2018-10-09 20:28:23 --> Security Class Initialized
DEBUG - 2018-10-09 20:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 20:28:23 --> CSRF cookie sent
INFO - 2018-10-09 20:28:23 --> Input Class Initialized
INFO - 2018-10-09 20:28:23 --> Language Class Initialized
INFO - 2018-10-09 20:28:23 --> Loader Class Initialized
INFO - 2018-10-09 20:28:23 --> Helper loaded: url_helper
INFO - 2018-10-09 20:28:23 --> Helper loaded: form_helper
INFO - 2018-10-09 20:28:23 --> Helper loaded: language_helper
DEBUG - 2018-10-09 20:28:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 20:28:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 20:28:23 --> User Agent Class Initialized
INFO - 2018-10-09 20:28:23 --> Controller Class Initialized
INFO - 2018-10-09 20:28:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 20:28:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 20:28:23 --> Pixel_Model class loaded
INFO - 2018-10-09 20:28:23 --> Database Driver Class Initialized
INFO - 2018-10-09 20:28:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 20:28:23 --> Database Driver Class Initialized
INFO - 2018-10-09 20:28:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 20:28:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 20:28:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-09 20:28:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 20:28:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 20:28:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 20:28:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 20:28:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 20:28:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/your_job.php
INFO - 2018-10-09 20:28:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 20:28:23 --> Final output sent to browser
DEBUG - 2018-10-09 20:28:23 --> Total execution time: 0.0447
INFO - 2018-10-09 20:28:24 --> Config Class Initialized
INFO - 2018-10-09 20:28:24 --> Hooks Class Initialized
DEBUG - 2018-10-09 20:28:24 --> UTF-8 Support Enabled
INFO - 2018-10-09 20:28:24 --> Utf8 Class Initialized
INFO - 2018-10-09 20:28:24 --> URI Class Initialized
INFO - 2018-10-09 20:28:24 --> Router Class Initialized
INFO - 2018-10-09 20:28:24 --> Output Class Initialized
INFO - 2018-10-09 20:28:24 --> Security Class Initialized
DEBUG - 2018-10-09 20:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 20:28:24 --> CSRF cookie sent
INFO - 2018-10-09 20:28:24 --> Input Class Initialized
INFO - 2018-10-09 20:28:24 --> Language Class Initialized
ERROR - 2018-10-09 20:28:24 --> 404 Page Not Found: Assets/css
INFO - 2018-10-09 20:29:13 --> Config Class Initialized
INFO - 2018-10-09 20:29:13 --> Hooks Class Initialized
DEBUG - 2018-10-09 20:29:13 --> UTF-8 Support Enabled
INFO - 2018-10-09 20:29:13 --> Utf8 Class Initialized
INFO - 2018-10-09 20:29:13 --> URI Class Initialized
INFO - 2018-10-09 20:29:13 --> Router Class Initialized
INFO - 2018-10-09 20:29:13 --> Output Class Initialized
INFO - 2018-10-09 20:29:13 --> Security Class Initialized
DEBUG - 2018-10-09 20:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 20:29:13 --> CSRF cookie sent
INFO - 2018-10-09 20:29:13 --> CSRF token verified
INFO - 2018-10-09 20:29:13 --> Input Class Initialized
INFO - 2018-10-09 20:29:13 --> Language Class Initialized
INFO - 2018-10-09 20:29:13 --> Loader Class Initialized
INFO - 2018-10-09 20:29:13 --> Helper loaded: url_helper
INFO - 2018-10-09 20:29:13 --> Helper loaded: form_helper
INFO - 2018-10-09 20:29:13 --> Helper loaded: language_helper
DEBUG - 2018-10-09 20:29:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 20:29:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 20:29:13 --> User Agent Class Initialized
INFO - 2018-10-09 20:29:14 --> Controller Class Initialized
INFO - 2018-10-09 20:29:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 20:29:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 20:29:14 --> Pixel_Model class loaded
INFO - 2018-10-09 20:29:14 --> Database Driver Class Initialized
INFO - 2018-10-09 20:29:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 20:29:14 --> Form Validation Class Initialized
INFO - 2018-10-09 20:29:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 20:29:14 --> Database Driver Class Initialized
INFO - 2018-10-09 20:29:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 20:29:14 --> Config Class Initialized
INFO - 2018-10-09 20:29:14 --> Hooks Class Initialized
DEBUG - 2018-10-09 20:29:14 --> UTF-8 Support Enabled
INFO - 2018-10-09 20:29:14 --> Utf8 Class Initialized
INFO - 2018-10-09 20:29:14 --> URI Class Initialized
INFO - 2018-10-09 20:29:14 --> Router Class Initialized
INFO - 2018-10-09 20:29:14 --> Output Class Initialized
INFO - 2018-10-09 20:29:14 --> Security Class Initialized
DEBUG - 2018-10-09 20:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 20:29:14 --> CSRF cookie sent
INFO - 2018-10-09 20:29:14 --> Input Class Initialized
INFO - 2018-10-09 20:29:14 --> Language Class Initialized
INFO - 2018-10-09 20:29:14 --> Loader Class Initialized
INFO - 2018-10-09 20:29:14 --> Helper loaded: url_helper
INFO - 2018-10-09 20:29:14 --> Helper loaded: form_helper
INFO - 2018-10-09 20:29:14 --> Helper loaded: language_helper
DEBUG - 2018-10-09 20:29:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 20:29:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 20:29:14 --> User Agent Class Initialized
INFO - 2018-10-09 20:29:14 --> Controller Class Initialized
INFO - 2018-10-09 20:29:14 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 20:29:14 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 20:29:14 --> Pixel_Model class loaded
INFO - 2018-10-09 20:29:14 --> Database Driver Class Initialized
INFO - 2018-10-09 20:29:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 20:29:14 --> Database Driver Class Initialized
INFO - 2018-10-09 20:29:14 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 20:29:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 20:29:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-09 20:29:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 20:29:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner.php
INFO - 2018-10-09 20:29:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 20:29:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 20:29:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 20:29:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 20:29:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/relation_ship_status.php
INFO - 2018-10-09 20:29:14 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 20:29:14 --> Final output sent to browser
DEBUG - 2018-10-09 20:29:14 --> Total execution time: 0.0482
INFO - 2018-10-09 20:29:14 --> Config Class Initialized
INFO - 2018-10-09 20:29:14 --> Hooks Class Initialized
DEBUG - 2018-10-09 20:29:14 --> UTF-8 Support Enabled
INFO - 2018-10-09 20:29:14 --> Utf8 Class Initialized
INFO - 2018-10-09 20:29:14 --> URI Class Initialized
INFO - 2018-10-09 20:29:14 --> Router Class Initialized
INFO - 2018-10-09 20:29:14 --> Output Class Initialized
INFO - 2018-10-09 20:29:14 --> Security Class Initialized
DEBUG - 2018-10-09 20:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 20:29:14 --> CSRF cookie sent
INFO - 2018-10-09 20:29:14 --> Input Class Initialized
INFO - 2018-10-09 20:29:14 --> Language Class Initialized
ERROR - 2018-10-09 20:29:14 --> 404 Page Not Found: Assets/css
INFO - 2018-10-09 20:29:18 --> Config Class Initialized
INFO - 2018-10-09 20:29:18 --> Hooks Class Initialized
DEBUG - 2018-10-09 20:29:18 --> UTF-8 Support Enabled
INFO - 2018-10-09 20:29:18 --> Utf8 Class Initialized
INFO - 2018-10-09 20:29:18 --> URI Class Initialized
INFO - 2018-10-09 20:29:18 --> Router Class Initialized
INFO - 2018-10-09 20:29:18 --> Output Class Initialized
INFO - 2018-10-09 20:29:18 --> Security Class Initialized
DEBUG - 2018-10-09 20:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 20:29:18 --> CSRF cookie sent
INFO - 2018-10-09 20:29:18 --> CSRF token verified
INFO - 2018-10-09 20:29:18 --> Input Class Initialized
INFO - 2018-10-09 20:29:18 --> Language Class Initialized
INFO - 2018-10-09 20:29:18 --> Loader Class Initialized
INFO - 2018-10-09 20:29:18 --> Helper loaded: url_helper
INFO - 2018-10-09 20:29:18 --> Helper loaded: form_helper
INFO - 2018-10-09 20:29:18 --> Helper loaded: language_helper
DEBUG - 2018-10-09 20:29:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 20:29:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 20:29:19 --> User Agent Class Initialized
INFO - 2018-10-09 20:29:19 --> Controller Class Initialized
INFO - 2018-10-09 20:29:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 20:29:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 20:29:19 --> Pixel_Model class loaded
INFO - 2018-10-09 20:29:19 --> Database Driver Class Initialized
INFO - 2018-10-09 20:29:19 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 20:29:19 --> Form Validation Class Initialized
INFO - 2018-10-09 20:29:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 20:29:19 --> Database Driver Class Initialized
INFO - 2018-10-09 20:29:19 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 20:29:19 --> Config Class Initialized
INFO - 2018-10-09 20:29:19 --> Hooks Class Initialized
DEBUG - 2018-10-09 20:29:19 --> UTF-8 Support Enabled
INFO - 2018-10-09 20:29:19 --> Utf8 Class Initialized
INFO - 2018-10-09 20:29:19 --> URI Class Initialized
INFO - 2018-10-09 20:29:19 --> Router Class Initialized
INFO - 2018-10-09 20:29:19 --> Output Class Initialized
INFO - 2018-10-09 20:29:19 --> Security Class Initialized
DEBUG - 2018-10-09 20:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 20:29:19 --> CSRF cookie sent
INFO - 2018-10-09 20:29:19 --> Input Class Initialized
INFO - 2018-10-09 20:29:19 --> Language Class Initialized
INFO - 2018-10-09 20:29:19 --> Loader Class Initialized
INFO - 2018-10-09 20:29:19 --> Helper loaded: url_helper
INFO - 2018-10-09 20:29:19 --> Helper loaded: form_helper
INFO - 2018-10-09 20:29:19 --> Helper loaded: language_helper
DEBUG - 2018-10-09 20:29:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 20:29:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 20:29:19 --> User Agent Class Initialized
INFO - 2018-10-09 20:29:19 --> Controller Class Initialized
INFO - 2018-10-09 20:29:19 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 20:29:19 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 20:29:19 --> Pixel_Model class loaded
INFO - 2018-10-09 20:29:19 --> Database Driver Class Initialized
INFO - 2018-10-09 20:29:19 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 20:29:19 --> Database Driver Class Initialized
INFO - 2018-10-09 20:29:19 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 20:29:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 20:29:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-09 20:29:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 20:29:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 20:29:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 20:29:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 20:29:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 20:29:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/income.php
INFO - 2018-10-09 20:29:19 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 20:29:19 --> Final output sent to browser
DEBUG - 2018-10-09 20:29:19 --> Total execution time: 0.0435
INFO - 2018-10-09 20:29:19 --> Config Class Initialized
INFO - 2018-10-09 20:29:19 --> Hooks Class Initialized
DEBUG - 2018-10-09 20:29:19 --> UTF-8 Support Enabled
INFO - 2018-10-09 20:29:19 --> Utf8 Class Initialized
INFO - 2018-10-09 20:29:19 --> URI Class Initialized
INFO - 2018-10-09 20:29:19 --> Router Class Initialized
INFO - 2018-10-09 20:29:19 --> Output Class Initialized
INFO - 2018-10-09 20:29:19 --> Security Class Initialized
DEBUG - 2018-10-09 20:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 20:29:19 --> CSRF cookie sent
INFO - 2018-10-09 20:29:19 --> Input Class Initialized
INFO - 2018-10-09 20:29:19 --> Language Class Initialized
ERROR - 2018-10-09 20:29:19 --> 404 Page Not Found: Assets/css
INFO - 2018-10-09 20:29:21 --> Config Class Initialized
INFO - 2018-10-09 20:29:21 --> Hooks Class Initialized
DEBUG - 2018-10-09 20:29:21 --> UTF-8 Support Enabled
INFO - 2018-10-09 20:29:21 --> Utf8 Class Initialized
INFO - 2018-10-09 20:29:21 --> URI Class Initialized
INFO - 2018-10-09 20:29:21 --> Router Class Initialized
INFO - 2018-10-09 20:29:21 --> Output Class Initialized
INFO - 2018-10-09 20:29:21 --> Security Class Initialized
DEBUG - 2018-10-09 20:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 20:29:21 --> CSRF cookie sent
INFO - 2018-10-09 20:29:21 --> CSRF token verified
INFO - 2018-10-09 20:29:21 --> Input Class Initialized
INFO - 2018-10-09 20:29:21 --> Language Class Initialized
INFO - 2018-10-09 20:29:21 --> Loader Class Initialized
INFO - 2018-10-09 20:29:21 --> Helper loaded: url_helper
INFO - 2018-10-09 20:29:21 --> Helper loaded: form_helper
INFO - 2018-10-09 20:29:21 --> Helper loaded: language_helper
DEBUG - 2018-10-09 20:29:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 20:29:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 20:29:21 --> User Agent Class Initialized
INFO - 2018-10-09 20:29:21 --> Controller Class Initialized
INFO - 2018-10-09 20:29:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 20:29:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 20:29:21 --> Pixel_Model class loaded
INFO - 2018-10-09 20:29:21 --> Database Driver Class Initialized
INFO - 2018-10-09 20:29:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 20:29:21 --> Form Validation Class Initialized
INFO - 2018-10-09 20:29:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 20:29:21 --> Database Driver Class Initialized
INFO - 2018-10-09 20:29:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 20:29:21 --> Config Class Initialized
INFO - 2018-10-09 20:29:21 --> Hooks Class Initialized
DEBUG - 2018-10-09 20:29:21 --> UTF-8 Support Enabled
INFO - 2018-10-09 20:29:21 --> Utf8 Class Initialized
INFO - 2018-10-09 20:29:21 --> URI Class Initialized
INFO - 2018-10-09 20:29:21 --> Router Class Initialized
INFO - 2018-10-09 20:29:21 --> Output Class Initialized
INFO - 2018-10-09 20:29:21 --> Security Class Initialized
DEBUG - 2018-10-09 20:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 20:29:21 --> CSRF cookie sent
INFO - 2018-10-09 20:29:21 --> Input Class Initialized
INFO - 2018-10-09 20:29:21 --> Language Class Initialized
INFO - 2018-10-09 20:29:21 --> Loader Class Initialized
INFO - 2018-10-09 20:29:21 --> Helper loaded: url_helper
INFO - 2018-10-09 20:29:21 --> Helper loaded: form_helper
INFO - 2018-10-09 20:29:21 --> Helper loaded: language_helper
DEBUG - 2018-10-09 20:29:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 20:29:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 20:29:21 --> User Agent Class Initialized
INFO - 2018-10-09 20:29:21 --> Controller Class Initialized
INFO - 2018-10-09 20:29:21 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 20:29:21 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 20:29:21 --> Pixel_Model class loaded
INFO - 2018-10-09 20:29:21 --> Database Driver Class Initialized
INFO - 2018-10-09 20:29:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 20:29:21 --> Database Driver Class Initialized
INFO - 2018-10-09 20:29:21 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 20:29:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 20:29:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-09 20:29:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 20:29:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 20:29:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 20:29:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 20:29:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 20:29:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-10-09 20:29:21 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 20:29:21 --> Final output sent to browser
DEBUG - 2018-10-09 20:29:21 --> Total execution time: 0.0510
INFO - 2018-10-09 20:29:22 --> Config Class Initialized
INFO - 2018-10-09 20:29:22 --> Hooks Class Initialized
DEBUG - 2018-10-09 20:29:22 --> UTF-8 Support Enabled
INFO - 2018-10-09 20:29:22 --> Utf8 Class Initialized
INFO - 2018-10-09 20:29:22 --> URI Class Initialized
INFO - 2018-10-09 20:29:22 --> Router Class Initialized
INFO - 2018-10-09 20:29:22 --> Output Class Initialized
INFO - 2018-10-09 20:29:22 --> Security Class Initialized
DEBUG - 2018-10-09 20:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 20:29:22 --> CSRF cookie sent
INFO - 2018-10-09 20:29:22 --> Input Class Initialized
INFO - 2018-10-09 20:29:22 --> Language Class Initialized
ERROR - 2018-10-09 20:29:22 --> 404 Page Not Found: Assets/css
INFO - 2018-10-09 20:29:23 --> Config Class Initialized
INFO - 2018-10-09 20:29:23 --> Hooks Class Initialized
DEBUG - 2018-10-09 20:29:23 --> UTF-8 Support Enabled
INFO - 2018-10-09 20:29:23 --> Utf8 Class Initialized
INFO - 2018-10-09 20:29:23 --> URI Class Initialized
INFO - 2018-10-09 20:29:23 --> Router Class Initialized
INFO - 2018-10-09 20:29:23 --> Output Class Initialized
INFO - 2018-10-09 20:29:23 --> Security Class Initialized
DEBUG - 2018-10-09 20:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 20:29:23 --> CSRF cookie sent
INFO - 2018-10-09 20:29:23 --> CSRF token verified
INFO - 2018-10-09 20:29:23 --> Input Class Initialized
INFO - 2018-10-09 20:29:23 --> Language Class Initialized
INFO - 2018-10-09 20:29:23 --> Loader Class Initialized
INFO - 2018-10-09 20:29:23 --> Helper loaded: url_helper
INFO - 2018-10-09 20:29:23 --> Helper loaded: form_helper
INFO - 2018-10-09 20:29:23 --> Helper loaded: language_helper
DEBUG - 2018-10-09 20:29:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 20:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 20:29:23 --> User Agent Class Initialized
INFO - 2018-10-09 20:29:23 --> Controller Class Initialized
INFO - 2018-10-09 20:29:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 20:29:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 20:29:23 --> Pixel_Model class loaded
INFO - 2018-10-09 20:29:23 --> Database Driver Class Initialized
INFO - 2018-10-09 20:29:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 20:29:23 --> Form Validation Class Initialized
INFO - 2018-10-09 20:29:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-09 20:29:23 --> Database Driver Class Initialized
INFO - 2018-10-09 20:29:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 20:29:23 --> Config Class Initialized
INFO - 2018-10-09 20:29:23 --> Hooks Class Initialized
DEBUG - 2018-10-09 20:29:23 --> UTF-8 Support Enabled
INFO - 2018-10-09 20:29:23 --> Utf8 Class Initialized
INFO - 2018-10-09 20:29:23 --> URI Class Initialized
INFO - 2018-10-09 20:29:23 --> Router Class Initialized
INFO - 2018-10-09 20:29:23 --> Output Class Initialized
INFO - 2018-10-09 20:29:23 --> Security Class Initialized
DEBUG - 2018-10-09 20:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 20:29:23 --> CSRF cookie sent
INFO - 2018-10-09 20:29:23 --> Input Class Initialized
INFO - 2018-10-09 20:29:23 --> Language Class Initialized
INFO - 2018-10-09 20:29:23 --> Loader Class Initialized
INFO - 2018-10-09 20:29:23 --> Helper loaded: url_helper
INFO - 2018-10-09 20:29:23 --> Helper loaded: form_helper
INFO - 2018-10-09 20:29:23 --> Helper loaded: language_helper
DEBUG - 2018-10-09 20:29:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 20:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 20:29:23 --> User Agent Class Initialized
INFO - 2018-10-09 20:29:23 --> Controller Class Initialized
INFO - 2018-10-09 20:29:23 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 20:29:23 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 20:29:23 --> Pixel_Model class loaded
INFO - 2018-10-09 20:29:23 --> Database Driver Class Initialized
INFO - 2018-10-09 20:29:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 20:29:23 --> Database Driver Class Initialized
INFO - 2018-10-09 20:29:23 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 20:29:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 20:29:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-09 20:29:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 20:29:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 20:29:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 20:29:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 20:29:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 20:29:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/home_title.php
INFO - 2018-10-09 20:29:23 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 20:29:23 --> Final output sent to browser
DEBUG - 2018-10-09 20:29:23 --> Total execution time: 0.0493
INFO - 2018-10-09 20:29:24 --> Config Class Initialized
INFO - 2018-10-09 20:29:24 --> Hooks Class Initialized
DEBUG - 2018-10-09 20:29:24 --> UTF-8 Support Enabled
INFO - 2018-10-09 20:29:24 --> Utf8 Class Initialized
INFO - 2018-10-09 20:29:24 --> URI Class Initialized
INFO - 2018-10-09 20:29:24 --> Router Class Initialized
INFO - 2018-10-09 20:29:24 --> Output Class Initialized
INFO - 2018-10-09 20:29:24 --> Security Class Initialized
DEBUG - 2018-10-09 20:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 20:29:24 --> CSRF cookie sent
INFO - 2018-10-09 20:29:24 --> Input Class Initialized
INFO - 2018-10-09 20:29:24 --> Language Class Initialized
ERROR - 2018-10-09 20:29:24 --> 404 Page Not Found: Assets/css
INFO - 2018-10-09 20:29:25 --> Config Class Initialized
INFO - 2018-10-09 20:29:25 --> Hooks Class Initialized
DEBUG - 2018-10-09 20:29:25 --> UTF-8 Support Enabled
INFO - 2018-10-09 20:29:25 --> Utf8 Class Initialized
INFO - 2018-10-09 20:29:25 --> URI Class Initialized
INFO - 2018-10-09 20:29:25 --> Router Class Initialized
INFO - 2018-10-09 20:29:25 --> Output Class Initialized
INFO - 2018-10-09 20:29:25 --> Security Class Initialized
DEBUG - 2018-10-09 20:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 20:29:25 --> CSRF cookie sent
INFO - 2018-10-09 20:29:25 --> Input Class Initialized
INFO - 2018-10-09 20:29:25 --> Language Class Initialized
INFO - 2018-10-09 20:29:25 --> Loader Class Initialized
INFO - 2018-10-09 20:29:25 --> Helper loaded: url_helper
INFO - 2018-10-09 20:29:25 --> Helper loaded: form_helper
INFO - 2018-10-09 20:29:25 --> Helper loaded: language_helper
DEBUG - 2018-10-09 20:29:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 20:29:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 20:29:25 --> User Agent Class Initialized
INFO - 2018-10-09 20:29:25 --> Controller Class Initialized
INFO - 2018-10-09 20:29:25 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 20:29:25 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 20:29:25 --> Pixel_Model class loaded
INFO - 2018-10-09 20:29:25 --> Database Driver Class Initialized
INFO - 2018-10-09 20:29:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 20:29:25 --> Database Driver Class Initialized
INFO - 2018-10-09 20:29:25 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 20:29:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 20:29:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-09 20:29:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 20:29:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 20:29:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 20:29:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_bar.php
INFO - 2018-10-09 20:29:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_buttons.php
INFO - 2018-10-09 20:29:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/pension.php
INFO - 2018-10-09 20:29:25 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 20:29:25 --> Final output sent to browser
DEBUG - 2018-10-09 20:29:25 --> Total execution time: 0.0469
INFO - 2018-10-09 20:29:25 --> Config Class Initialized
INFO - 2018-10-09 20:29:25 --> Hooks Class Initialized
DEBUG - 2018-10-09 20:29:25 --> UTF-8 Support Enabled
INFO - 2018-10-09 20:29:25 --> Utf8 Class Initialized
INFO - 2018-10-09 20:29:25 --> URI Class Initialized
INFO - 2018-10-09 20:29:25 --> Router Class Initialized
INFO - 2018-10-09 20:29:25 --> Output Class Initialized
INFO - 2018-10-09 20:29:25 --> Security Class Initialized
DEBUG - 2018-10-09 20:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 20:29:25 --> CSRF cookie sent
INFO - 2018-10-09 20:29:25 --> Input Class Initialized
INFO - 2018-10-09 20:29:25 --> Language Class Initialized
ERROR - 2018-10-09 20:29:25 --> 404 Page Not Found: Assets/css
INFO - 2018-10-09 20:29:27 --> Config Class Initialized
INFO - 2018-10-09 20:29:27 --> Hooks Class Initialized
DEBUG - 2018-10-09 20:29:27 --> UTF-8 Support Enabled
INFO - 2018-10-09 20:29:27 --> Utf8 Class Initialized
INFO - 2018-10-09 20:29:27 --> URI Class Initialized
INFO - 2018-10-09 20:29:27 --> Router Class Initialized
INFO - 2018-10-09 20:29:27 --> Output Class Initialized
INFO - 2018-10-09 20:29:27 --> Security Class Initialized
DEBUG - 2018-10-09 20:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 20:29:27 --> CSRF cookie sent
INFO - 2018-10-09 20:29:27 --> Input Class Initialized
INFO - 2018-10-09 20:29:27 --> Language Class Initialized
INFO - 2018-10-09 20:29:27 --> Loader Class Initialized
INFO - 2018-10-09 20:29:27 --> Helper loaded: url_helper
INFO - 2018-10-09 20:29:27 --> Helper loaded: form_helper
INFO - 2018-10-09 20:29:27 --> Helper loaded: language_helper
DEBUG - 2018-10-09 20:29:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-09 20:29:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 20:29:27 --> User Agent Class Initialized
INFO - 2018-10-09 20:29:27 --> Controller Class Initialized
INFO - 2018-10-09 20:29:27 --> Language file loaded: language/en/common_lang.php
INFO - 2018-10-09 20:29:27 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2018-10-09 20:29:27 --> Pixel_Model class loaded
INFO - 2018-10-09 20:29:27 --> Database Driver Class Initialized
INFO - 2018-10-09 20:29:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 20:29:27 --> Database Driver Class Initialized
INFO - 2018-10-09 20:29:27 --> Model "QuestionsModel" initialized
INFO - 2018-10-09 20:29:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_basic_nav.php
INFO - 2018-10-09 20:29:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_admin_nav.php
INFO - 2018-10-09 20:29:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_header.php
INFO - 2018-10-09 20:29:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_banner_empty.php
INFO - 2018-10-09 20:29:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_page_header.php
INFO - 2018-10-09 20:29:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/questions/risk_report.php
INFO - 2018-10-09 20:29:27 --> File loaded: /home/fxp6bn7rqemh/public_html/application/views/shared/_footer.php
INFO - 2018-10-09 20:29:27 --> Final output sent to browser
DEBUG - 2018-10-09 20:29:27 --> Total execution time: 0.0552
INFO - 2018-10-09 20:29:27 --> Config Class Initialized
INFO - 2018-10-09 20:29:27 --> Hooks Class Initialized
DEBUG - 2018-10-09 20:29:27 --> UTF-8 Support Enabled
INFO - 2018-10-09 20:29:27 --> Utf8 Class Initialized
INFO - 2018-10-09 20:29:27 --> URI Class Initialized
INFO - 2018-10-09 20:29:27 --> Router Class Initialized
INFO - 2018-10-09 20:29:27 --> Output Class Initialized
INFO - 2018-10-09 20:29:27 --> Security Class Initialized
DEBUG - 2018-10-09 20:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 20:29:27 --> CSRF cookie sent
INFO - 2018-10-09 20:29:27 --> Input Class Initialized
INFO - 2018-10-09 20:29:27 --> Language Class Initialized
ERROR - 2018-10-09 20:29:27 --> 404 Page Not Found: Assets/css
